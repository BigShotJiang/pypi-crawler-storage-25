# Writing Methods

## Method Directory Layout

A method is a self-contained directory with two required files:

| File | Purpose |
|---|---|
| `{method_name}.py` | Python script containing the implementation |
| `method.yaml` | Contract file declaring inputs, outputs, params, and env |

The script filename must match the directory name. For example, a method called `preprocess` lives in a directory named `preprocess/` and its script is `preprocess.py`.

### Where methods live

**Nested under a module (typical):**
```
modules/{module_name}/{method_name}/
  {method_name}.py
  method.yaml
```
Example: `modules/binary_label_classification/train_classifier/train_classifier.py`

**Flat standalone:**
```
methods/{method_name}/
  {method_name}.py
  method.yaml
```
Example: `methods/feature_qc/feature_qc.py`

Both layouts are registered the same way:
```bash
pm register-method modules/my_analysis/preprocess --module my_analysis
pm register-method methods/feature_qc --module data_tools
```

At registration, the method directory is snapshotted into `methods/{method_name}/` for code fingerprinting, regardless of where the source lives.

## Writing the Python Script

The `@pm_method` decorator marks your entry function. The decorator itself is a no-op at import time -- it simply registers the function. The actual dispatch happens when `pm_method_main()` is called.

### Minimal example

```python
import pandas as pd
from pm.method import pm_method, pm_method_main

@pm_method
def filter_data(inputs, params):
    # inputs: dict[str, list[Path]] or None
    # params: dict with values from method.yaml + pipeline overrides
    df = pd.read_csv(inputs["data"][0])
    threshold = params.get("threshold", 0.5)
    filtered = df[df["score"] > threshold]
    return filtered

if __name__ == "__main__":
    pm_method_main()
```

### Function signature

The decorated function receives two arguments:

1. **`inputs`** -- `dict[str, list[Path]]` or `None`. Keys are input slot names from `method.yaml`. Each value is a list of resolved file paths. `None` when the node has no upstream input (e.g., a data-generating root node). Methods own their I/O: read files using whatever library fits the slot type.
2. **`params`** -- `dict` of parameter values, populated from `method.yaml` defaults merged with pipeline-level overrides.

The AST scanner strips `inputs` and `params` from the parameter list when discovering tracked parameters at registration, so only additional user-defined parameters are recorded in the database.

### Return values

The framework normalizes your return value via `_parse_return()`:

| Return pattern | Interpretation |
|---|---|
| `DataFrame` | Primary output named `"output"`, no metrics |
| `(DataFrame, dict)` | Primary output named `"output"` + metrics dict |
| `(dict, dict)` | Named outputs dict + metrics dict |
| `dict` (single) | Named outputs dict, no metrics |
| `None` | No outputs, no metrics |

Output names must match the output slot names declared in `method.yaml`. Returning an undeclared output name raises `ContractViolation`.

## The Contract File (method.yaml)

Every method should have a `method.yaml` that declares its inputs, outputs, and parameters. Methods without a `method.yaml` are still valid but won't have slot-level metadata in the database or canvas widgets.

### Example

```yaml
inputs:
  data:
    type: csv
    required: true
    description: "Labeled cell CSV"

outputs:
  predictions:
    type: csv
    required: true
    description: "Per-cell predictions"
  model:
    type: model
    required: true

params:
  threshold:
    type: float
    required: false
    default: 0.5
  feature_pairs:
    type: list
    required: true

executor: python
env: inherit
```

### Input slot fields

| Field | Type | Default | Purpose |
|---|---|---|---|
| `type` | str | `"csv"` | `csv`, `parquet`, `pickle`, `png`, `any` |
| `required` | bool | `true` | Fail if not wired in the pipeline |
| `multiple` | bool | `false` | Accept a list of files (fan-in) |
| `description` | str | `""` | Human-readable description |
| `columns` | dict | None | Column presence spec (see below) |

### Output slot fields

| Field | Type | Default | Purpose |
|---|---|---|---|
| `type` | str | `"csv"` | `csv`, `parquet`, `directory`, `model`, etc. |
| `multiple` | bool | `false` | Produces N files |
| `description` | str | `""` | Human-readable description |
| `columns` | dict | None | Column presence spec |
| `contents` | list[dict] | None | Directory content assertions |

### Param fields

| Field | Type | Default | Purpose |
|---|---|---|---|
| `type` | str | `"str"` | `str`, `int`, `float`, `bool`, `list`, `dict` |
| `required` | bool | `true` | Fail if not provided at runtime |
| `default` | any | None | Default value used when not overridden |
| `description` | str | `""` | Human-readable description |

### Column presence validation

For `csv` and `parquet` slots, you can declare expected columns via the `columns` key:

```yaml
inputs:
  data:
    type: csv
    columns:
      strict: ["cell_index", "condition", "proliferative"]
      patterns: ["*_intensity"]
```

| Key | Purpose |
|---|---|
| `strict` | Exact column names that must be present |
| `from_params` | Columns derived from runtime params via cartesian expansion |
| `patterns` | fnmatch-style globs; at least one column must match each pattern |

Input column validation is a **hard gate** -- missing columns block execution. Output column validation is a **soft check** -- mismatches produce warnings but do not fail the run.

### How contracts are validated

At `register-method` time, method outputs are checked against module contracts: every required module output must appear in the method's output slots. At pipeline load time, link wiring is validated against the declared slots, and static cross-step column compatibility is checked for `strict` columns between connected steps.

## Environment Isolation

Each method can run in its own isolated pixi or conda environment, preventing dependency conflicts between methods in the same pipeline. Environment isolation is configured via the `env` key in `method.yaml`.

### Env spec format

| Spec | Meaning |
|---|---|
| `inherit` | Use the project's own Python (default if `env` is omitted) |
| `pixi:<name>` | Standalone pixi project, default env |
| `pixi:<project>:<env>` | Pixi project with an explicit env name |
| `conda:<name>` | Conda environment by name |

Bare names without a prefix (e.g., `image-io` instead of `pixi:image-io`) are rejected with a `ValueError` at registration time. At execution time, resolution failure is caught and silently falls back to the project Python (`sys.executable`).

### Example

```yaml
# method.yaml
inputs:
  images:
    type: directory
outputs:
  features:
    type: csv
env: pixi:image-io
```

### Pixi root configuration

Pixi environment directories are located under a configurable root, set in `.pm/wf-canvas.toml`:

```toml
[pixi]
root = ".pixi"   # relative to project root, or absolute

[conda]
root = "/home/user/anaconda3"   # optional
```

### Resolution cascade

1. **`pixi:<name>`** -- globs `{pixi_root}/{name}-*/envs/default`. Exactly one match required.
2. **`pixi:<project>:<env>`** -- globs `{pixi_root}/{project}-*/envs/{env}`. Exactly one match required.
3. **`conda:<name>`** -- checks `{conda_root}/envs/{name}` directly. Falls back to `conda info --base` if `conda_root` is not configured.

Pixi stores environments with a hash suffix (`{name}-{hash}/envs/{env}`), so the glob pattern `{name}-*` handles this layout.

### When resolution happens

- **Registration** (`pm register-method`): `_resolve_env()` validates the environment exists and has a Python binary. Fails fast if missing.
- **Execution** (`run_step`): Re-resolves the env spec to handle hash changes from `pixi install` between registration and execution. Falls back to `sys.executable` if resolution fails.
- **Snakefile generation**: Pre-resolves all named environments into an `ENV_PYTHON_PATHS` dict. Each rule selects the correct interpreter from this dict.

When dispatching to a non-inherit environment, the PATH is rewritten to prioritize the target environment's directories, preventing ABI-mismatch issues from the parent environment's DLLs.

## Module Contracts

Module contracts define required outputs and metrics that every method in a module must produce. They sit above method contracts and enforce domain-wide guarantees.

### module.yaml format

Declare module contracts in `modules/{module_name}/module.yaml`:

```yaml
description: Train and apply binary classifiers on labeled cell data
contracts:
  - type: output
    name: model
    value_type: model
    required: true
  - type: metric
    name: mcc
    value_type: float
    required: true
```

Each contract entry has:

| Field | Type | Default | Purpose |
|---|---|---|---|
| `type` | str | -- | `output` or `metric` |
| `name` | str | -- | Required output/metric name |
| `value_type` | str | None | Expected type (e.g., `float`, `model`, `.csv`) |
| `required` | bool | `true` | Whether the contract is enforced |

### CLI alternative

Module contracts can also be passed as JSON via the CLI:

```bash
pm register-module --name my_analysis --contracts '[{"type": "output", "name": "model", "value_type": "model", "required": true}]'
```

The `--contracts` CLI flag and `module.yaml` serve the same purpose. When both are provided, the CLI `--contracts` flag takes precedence and `module.yaml` is used as a fallback.

### Enforcement

| When | What happens |
|---|---|
| `pm register-method` | Every required module output must appear in the method's output slots. Missing outputs fail registration. |
| `@pm_method` return | After the function returns, `_execute_pm_method` checks that all required contract outputs and metrics are present. Missing ones raise `ContractViolation`. |

Module contracts and method contracts compose: method contracts define the I/O shape (slots), while module contracts guarantee that certain named outputs and metrics are always produced.

## RunContext: The Runtime Interface

When your method runs inside a pipeline, the framework handles all the wiring. Your script doesn't know or care which orchestrator launched it -- it interacts with the world through `RunContext` and a few environment variables.

### How it works

1. `run_step` sets `PM_*` environment variables and launches your script as a subprocess.
2. `pm_method_main()` creates a `RunContext` from those env vars.
3. `RunContext.load_input()` reads `PM_INPUT_PATHS` and returns your input files.
4. Your function runs, returns outputs and metrics.
5. The framework saves outputs, validates contracts, and writes `metrics.json`.

### Environment variables

| Variable | Purpose |
|---|---|
| `PM_RUN_ID` | Unique run identifier (int) |
| `PM_RUN_DIR` | Directory for this run's outputs |
| `PM_SAMPLE` | Current sample name |
| `PM_PARAMS` | JSON-encoded params dict |
| `PM_INPUT_PATHS` | JSON-encoded `dict[str, list[str]]` of input slot paths |
| `PM_NODE_ID` | Node identifier within the pipeline |
| `PM_PIPELINE_ID` | Pipeline identifier for this execution |
| `PM_VARIANT` | Variant name for this run |

### RunContext API

**`load_input()`** -- Returns `dict[str, list[Path]]` where keys are input slot names and values are lists of resolved file paths. Returns `None` when the node has no upstream input. Methods own their I/O: the slot type in `method.yaml` describes what's at the path, not how to deserialize it.

**`save_module(name, data, ext)`** -- Save a contract-required output. The file is written to `PM_RUN_DIR/{name}{ext}`. The name must match a declared output slot. The engine validates these against module contracts after execution.

**`save(filename, data)`** -- Save a free-form output (not contract-validated). Written to `PM_RUN_DIR/{filename}`.

**`log_metrics(metrics)`** -- Record a dict of metrics. Can be called multiple times; values are merged.

**`finalize()`** -- Writes `metrics.json` to `PM_RUN_DIR`. Called automatically by the framework after your function returns.

### Supported data types for save

`save_module()` and `save()` dispatch writes based on the data type:

| Data type | Behavior |
|---|---|
| `pandas.DataFrame` | `.csv` extension writes CSV; anything else writes Parquet |
| `matplotlib.Figure` | Saved as image (PNG at 150 DPI) |
| `bytes` | Written as raw bytes |
| `str` | Written as text |
| `Path` | Copied from the source path (files or directories) |

### What you don't need to do

You never call `RunContext` directly in the `@pm_method` pattern -- the framework creates it, loads inputs, and passes them to your function. After your function returns, the framework handles `save_module()`, `log_metrics()`, and `finalize()` automatically based on your return value. The `RunContext` API is documented here for understanding and for advanced use cases outside the standard decorator pattern.

## Next Steps

Once you've written your method:

- **Register it** -- Use `pm register-module` to create the module, then `pm register-method` to register the method and validate its contracts.
- **Inspect results** -- After a pipeline run, use `pm pipeline-summary` to review outcomes, or browse the `.runs/` directory for per-run outputs and metrics.
