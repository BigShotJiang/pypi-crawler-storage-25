# Canvas Visual Builder

## Overview

Canvas is a browser-based visual interface for building and monitoring pipelines. Launch it with `pm canvas` (default port 8500).

Canvas has two views:

- **Builder** -- a drag-and-drop node-graph editor for creating pipelines visually. Wire method nodes together, configure parameters, validate the graph, and run the pipeline -- all from the browser.
- **History** -- a run history viewer for inspecting past pipeline executions. Browse runs, view lineage chains, inspect metadata/params/metrics, and download artifacts.

## System Nodes

Pipeline inputs are provided through **system nodes** -- special non-method nodes that serve as data sources for the DAG. System nodes are the only valid root nodes in a pipeline; every method node must have at least one incoming edge.

Two system node types exist:

- **Input Selector** -- a sample picker that selects registered samples from the project database as pipeline inputs. Queries `GET /api/pm/samples` to populate the picker.
- **Run Reference** -- a previous-run output picker that selects outputs from completed pipeline runs as static inputs to downstream steps. Queries `GET /api/pm/completed-runs` to populate the picker.

The system-node-only-roots constraint is enforced during both validation (`POST /api/workflow/validate`) and pipeline loading (`load_pipeline`). A method node with no upstream connection is rejected as an invalid root.

## Builder Basics

The Builder view is a Svelte Flow node-graph editor with three panels: a sidebar palette on the left, the canvas in the center, and an inspector panel on the right.

**Node palette:** The left sidebar lists all registered methods grouped by module, with a search bar at the top. System nodes (Input Selector, Run Reference) appear above a divider at the top of the palette. Each method shows slot badges and `MULTI` indicators for fan-in inputs.

**Drag-and-drop:** Drag a method from the palette onto the canvas to create a node. Nodes display typed input slots (left side) and output slots (right side), color-coded by domain type:

| Type | Color | Hex |
|---|---|---|
| AnnData | blue | `#4A90D9` |
| Labels | amber | `#E9A847` |
| FeatureSet | green | `#50C878` |
| Array | purple | `#9B59B6` |
| Figure | red | `#E74C3C` |
| DataFrame | orange | `#F39C12` |
| Path | teal | `#1ABC9C` |
| String / Number | grey | `#95A5A6` |

**Connections:** Click an output slot and drag to a compatible input slot. Type-mismatched connections are blocked. Fan-in inputs (`multiple: true`) accept multiple incoming connections.

**Param editing:** Select a node to open the inspector panel. Method nodes show form controls: text fields for strings, number spinners for int/float, toggles for booleans, and a JSON editor for list/dict params. System nodes show their respective pickers (sample picker or run picker).

**Import / Export:** Import a pipeline JSON file to recreate nodes and connections automatically. Export the current graph as pipeline JSON (`{nodes, links, samples}`) compatible with `pm run-pipeline`.

**Validate and Run:** Click Validate to check the graph against registered methods via `POST /api/workflow/validate`. If valid, click Run to execute. A polling loop provides live per-node status feedback during execution. Undo/redo is available via Ctrl+Z / Ctrl+Y (50-entry snapshot stack).

## History Basics

Switch to the History tab to browse past pipeline executions.

**Loading a project:** Enter the project path and click Load. If Canvas was launched from the project directory, it auto-loads.

**Filters:** Narrow down runs using:
- Sample name (multi-select from root runs)
- Module and method (multi-select dropdowns)
- Time range
- Favorites (star runs to bookmark them; stored in localStorage)
- Text search across run metadata

**Path view:** Runs are displayed as horizontal lineage chains -- one row per terminal node, with arrows showing parent-child relationships. Click any run card to open the detail panel.

**Detail panel:** Shows run metadata (ID, method, sample, status, timing), parameters, metrics, and artifacts. PNG artifacts display inline thumbnails with a lightbox viewer. Artifacts can be downloaded individually or exported in bulk as a zip file.

**Descendant tree:** Click the lineage button on any run to see its full descendant tree. The tree view shows recursive children with connector glyphs, indentation, and collapse toggles. Click "Back to Paths" to return to the main view.

## Next Steps

See the **CLI Reference** for the full list of `pm` commands, including `pm run-pipeline` for running pipelines from the command line, `pm register-module` / `pm register-method` for registering pipeline components, and `pm cache` for managing run archives.
