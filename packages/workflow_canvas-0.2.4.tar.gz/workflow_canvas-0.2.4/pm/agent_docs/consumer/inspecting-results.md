# Inspecting Results

## Runs and Outputs

A **run** is a single method execution tracked by the system. Each run has:

- **Run ID** -- a unique identifier assigned at creation.
- **Status** -- `running`, `completed`, or `failed`. Cache-hit runs are stored with status `completed` and a `cache_source_run_id` field pointing to the original run whose outputs were reused (the `"cached"` label only appears in pipeline outcome sidecar JSON, not in the Run record itself).
- **Timing** -- start and end timestamps.
- **Parameters** -- the exact param values used for this execution.
- **Sample** -- which data source was processed.

### Where outputs live

Outputs move through two locations during their lifecycle:

| Phase | Path | Purpose |
|---|---|---|
| During execution | `.runs/workspace/{pipeline_id}/{node_id}/{sample}/{variant}/` | Active workspace for the running step |
| After completion | `.runs/{run_id}/` and DVC cache | Permanent archive |

Archiving is **deferred** (ADR-007 Phase 2, ADR-011): pipeline steps write outputs with `content_hash = NULL`, and after the full pipeline completes, `archive_outputs` hashes and caches all un-archived `RunOutput` rows in a single batch pass. This eliminates blocking I/O between pipeline steps.

### The three-temperature model for output retrieval

When a downstream step needs an output from an earlier run, `resolve_input` checks three tiers:

1. **HOT** -- the archive file exists on disk at `.runs/{id}/`. Return immediately.
2. **WARM** -- the archive was pruned but the DVC local cache still has the hash. `restore_from_cache` materializes it.
3. **COLD** -- the local cache is empty. `pull_cache` fetches from the remote, then restores.

## Lineage

Every run traces back to its upstream steps through **lineage** -- a directed graph of parent-child relationships that ultimately roots at registered samples.

### How lineage is stored

Lineage is stored as a chain of `RunInput` rows. Each `RunInput` links a run to its `source_run_id` (the run that produced the input it consumed):

```
Run A (root sample) --> RunOutput --> RunInput (source_run_id=A) --> Run B --> RunOutput --> RunInput (source_run_id=B) --> Run C
```

### Fan-in support

A single run can have **multiple parents** when it consumes outputs from more than one upstream step. Each parent is recorded as a separate `RunInput` row with a distinct `source_run_id`.

### Cache audit runs

When a step hits the cache (identical inputs + params + code), a cache-hit audit run is created with `cache_source_run_id` set. These audit rows appear in lineage like normal runs, ensuring every pipeline execution is fully traceable.

### Querying lineage

`get_lineage(run_id)` uses a SQLite **recursive CTE** to walk the full ancestor chain:

```sql
WITH RECURSIVE ancestors AS (
    SELECT run_id, source_run_id FROM run_inputs WHERE run_id = :target
    UNION ALL
    SELECT ri.run_id, ri.source_run_id
    FROM run_inputs ri JOIN ancestors a ON ri.run_id = a.source_run_id
)
SELECT * FROM ancestors;
```

This returns every ancestor run in the DAG, from the target run back to the original sample registrations.

## Using Canvas for Inspection

The **Canvas** web application provides a visual interface for browsing and inspecting pipeline results.

### Loading a project

Open the Canvas History tab and enter the project path (or it auto-loads from the current working directory).

### Filtering runs

Use the filter controls to narrow down results:

- **Data source** -- filter by sample name.
- **Time range** -- restrict to a date window.
- **Module and method** -- multi-select to show only specific analysis steps.
- **Favorites** -- star runs for quick access, then filter to show only starred.
- **Text search** -- free-text search across run metadata.

### Path view (lineage chains)

Runs are grouped by sample and displayed as horizontal chains with arrows showing lineage flow. Click any run card to open the detail panel.

### Detail panel

The detail panel for a selected run shows:

- **Metadata** -- run ID, method, sample, status, and timing.
- **Parameters** -- the exact param values used.
- **Metrics** -- numeric results logged by the method.
- **Artifacts** -- output files. PNG artifacts show inline thumbnails with a lightbox viewer. Artifacts can be downloaded individually or in bulk.

### Lineage tree

Click the lineage button on any run card to see its **primary parent chain** and descendants. Canvas lineage follows the single `parentRunId` link, so it shows one ancestor chain only. For full fan-in lineage (where a node has multiple parents), use the `pm lineage` CLI command or the `get_lineage()` library function from `pm.lineage`, which walks the full DAG via recursive CTE.

### Bulk export

Enable checkbox mode, select multiple runs, and export filtered artifacts as a zip file (all types, or CSV-only).

## Next Steps

- **[Canvas User Guide](../features/canvas/user-guide.json)** -- explore the full Canvas interface including the Pipeline Builder and advanced History features.
- **[CLI Reference](../features/core-pipeline/interfaces/cli.json)** -- complete reference for all `pm` commands.
