# Registering Modules, Methods, and Samples

## Registering a Module

A **module** is a logical grouping of related methods that share a common contract (declared input/output types).

### Command

```bash
pm register-module --name my_analysis \
  [--module-dir modules/my_analysis] \
  [--description "My analysis module"] \
  [--contracts '[{"input_slots": [...], "output_slots": [...]}]']
```

### Two ways to supply contracts

| Source | When used |
|---|---|
| `module.yaml` inside `--module-dir` | File is parsed automatically via `parse_module_yaml()` |
| `--contracts` CLI flag (JSON) | Required when no `--module-dir` or no `module.yaml` |

### What happens in the database

1. A **Module** row is upserted (matched by name).
2. One **ModuleContract** row is created for each contract entry, defining the input/output slot types that all methods in the module must satisfy.

Modules are idempotent to re-register -- calling the command again with the same name updates the existing row.

## Registering a Method

A **method** is a single analysis step -- a Python function decorated with `@pm_method` that lives in a directory under a module.

### Command

```bash
pm register-method modules/my_analysis/preprocess --module my_analysis
```

### What the command does (step by step)

1. **Locate and scan script** -- finds `{method_name}.py` in the given directory and AST-parses it to extract function signatures.
2. **Resolve module** -- looks up the parent module in the database (raises `ValueError` if not found).
3. **Upsert Method row** -- creates or updates the method record, storing the script path and resolved environment name (from `method.yaml`, defaulting to `"inherit"`).
4. **Sync tracked functions and parameters** -- clears existing `TrackedFunction` and `ParamDef` rows for this method, then inserts fresh rows from the AST scan results. Each tracked function gets an ordinal and its parameters are stored with name, type annotation, and default value.
5. **Store method contract** -- records `input_slots`, `output_slots`, `params_schema`, and `executor` from `method.yaml`. At least one input slot must be declared (raises `ValueError` otherwise).
6. **Validate against module contract** -- checks that the method's declared outputs satisfy the parent module's required outputs.
7. **Git commit** -- commits the method directory to version control so the code version is captured in the cache key.
8. **Copy source snapshot** -- copies source files to `methods/{method_name}/` so the code fingerprint is always computed from the registered copy.

### Key constraints

- Every method must declare at least one input slot.
- Method outputs must satisfy the parent module's contract (required outputs must be present).
- The `@pm_method` decorator is required for AST discovery to work.

## Registering a Sample

A **sample** is a data file (typically CSV) that serves as the root input to a pipeline.

### Command

```bash
pm register-sample --name CFPAC_ERKi --source /data/raw/cfpac_erki.csv
```

### Prerequisites

DVC must be configured. Your `wf-canvas.toml` must include a `[dvc]` section (created automatically by `pm init` when `auto_init = true`). Registration will error if this section is missing.

### What the command does

1. **Content-hash** -- computes an MD5 hash of the source file via `hash_path()`.
2. **DVC cache store** -- copies the file into the DVC content-addressed cache (`cache_file()`), following ADR-009.
3. **DB row** -- creates a `Sample` row storing `file_size`, `file_mtime`, `registration_mode`, and `content_hash`.
4. **Remote push** -- best-effort push to the DVC remote via `push_cache()` (skips gracefully on failure).

### Important: `data/samples/` is ephemeral

The `data/samples/` directory is an **ephemeral workspace**, not a permanent copy destination. The DVC cache is the sole authoritative store. Before pipeline execution, `pm restore-sample` materializes the file from the cache into the workspace. The `registered_path` on the Sample row records where the file *will be* restored, not where it currently lives.

Only `"copy"` mode is currently implemented; `"link"` mode raises `NotImplementedError`.

### Restoring samples

```bash
pm restore-sample --name CFPAC_ERKi
```

Looks up `Sample.content_hash`, calls `restore_from_cache()` (with integrity verification), and falls back to `pull_cache()` if the local cache is empty. The `restore_sample` Snakemake rule integrates this into the DAG for lazy, on-demand restore during pipeline execution.

## Next Steps

- **[Inspecting Results](inspecting-results.json)** -- learn how to browse runs, trace lineage, and view outputs after pipeline execution.
- **[Canvas](../features/canvas/user-guide.json)** -- use the visual Pipeline Builder and Run History interface.
