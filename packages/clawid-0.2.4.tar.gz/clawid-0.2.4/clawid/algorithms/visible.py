"""
Visible watermark overlay for clawID.

Provides two modes:
  embed_visible()    — free-form text overlay (semi-transparent)
  embed_text_stamp() — compact metadata pill readable by AI vision models via OCR.
                       AI models excel at OCR; they cannot decode QR binary data.
                       This is the recommended approach for "AI-readable" watermarking.
"""

import os
from PIL import Image, ImageDraw, ImageFont


# Common system font paths — tried in order, first match wins
_FONT_CANDIDATES = [
    # macOS
    '/System/Library/Fonts/Helvetica.ttc',
    '/System/Library/Fonts/Arial.ttf',
    '/Library/Fonts/Arial.ttf',
    # Linux
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
    '/usr/share/fonts/truetype/freefont/FreeSans.ttf',
    # Windows
    'C:/Windows/Fonts/arial.ttf',
    'C:/Windows/Fonts/segoeui.ttf',
]

_POSITIONS = {
    'top-left',
    'top-right',
    'bottom-left',
    'bottom-right',
    'center',
}


def embed_visible(
    image: Image.Image,
    text: str,
    position: str = 'bottom-right',
    opacity: float = 0.6,
    font_size: int = 20,
    padding: int = 12,
) -> Image.Image:
    """
    Add a visible text watermark to an image.

    Args:
        image:     RGB PIL Image
        text:      watermark text to display
        position:  one of top-left / top-right / bottom-left / bottom-right / center
        opacity:   text opacity 0.0–1.0  (default 0.6)
        font_size: font size in pixels   (default 20)
        padding:   distance from image edge in pixels (default 12)

    Returns:
        Watermarked RGB PIL Image
    """
    if position not in _POSITIONS:
        raise ValueError(f"position must be one of {sorted(_POSITIONS)}, got '{position}'")
    if not 0.0 <= opacity <= 1.0:
        raise ValueError(f"opacity must be between 0.0 and 1.0, got {opacity}")

    img = image.convert('RGBA')
    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    font = _load_font(font_size)

    # Measure text
    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    w, h = img.size

    x, y = _resolve_position(position, w, h, text_w, text_h, padding)
    alpha = int(255 * opacity)

    # Shadow (50% of main opacity) for readability on any background
    draw.text((x + 1, y + 1), text, font=font, fill=(0, 0, 0, alpha // 2))
    # Main text (white)
    draw.text((x, y), text, font=font, fill=(255, 255, 255, alpha))

    return Image.alpha_composite(img, overlay).convert('RGB')


def embed_text_stamp(
    image: Image.Image,
    metadata: dict,
    position: str = 'bottom-right',
    font_size: int = 13,
    opacity: float = 0.88,
    padding: int = 10,
    bg_color: tuple = (0, 0, 0),
    text_color: tuple = (255, 255, 255),
) -> Image.Image:
    """
    Embed metadata as a compact readable text pill — directly interpretable by
    any AI vision model via OCR. No QR decoding required.

    AI models (GPT-4V, Gemini, Grok, Claude) are excellent at OCR — they can
    read small text reliably even at font_size=11. They CANNOT decode QR binary
    data. This makes a text stamp far more reliable for "AI reads the metadata"
    use cases.

    The stamp looks like:
      ┌──────────────────────────────────────────────┐
      │ 🐾 clawID · @creator · hawky.ai · gen_abc123 │
      │ id:a3f7c2d1 · 2024-01-15T10:30Z              │
      └──────────────────────────────────────────────┘

    Args:
        image:      RGB PIL Image
        metadata:   dict with uid, platform, asset_id, clawid, ts fields
        position:   corner placement
        font_size:  text size in px (default 13 — small but AI-readable)
        opacity:    pill background opacity 0–1 (default 0.88)
        padding:    margin from image edge in px
        bg_color:   pill background RGB (default black)
        text_color: text RGB (default white)

    Returns:
        Watermarked RGB PIL Image with metadata text pill
    """
    img = image.convert('RGBA')
    W, H = img.size

    font = _load_font(font_size)

    # Build compact two-line label
    import datetime
    ts = metadata.get('ts', '')
    ts_str = ''
    if ts:
        try:
            ts_str = datetime.datetime.utcfromtimestamp(int(ts)).strftime('%Y-%m-%dT%H:%MZ')
        except Exception:
            ts_str = str(ts)

    uid       = metadata.get('uid', '')
    platform  = metadata.get('platform', '')
    asset_id  = metadata.get('asset_id', '')
    clawid    = metadata.get('clawid', '')
    clawid_short = clawid[:8] if clawid else ''

    # Line 1: identity
    parts1 = ['clawID']
    if uid:       parts1.append(uid)
    if platform:  parts1.append(platform)
    if asset_id:  parts1.append(asset_id)
    line1 = ' · '.join(parts1)

    # Line 2: IDs
    parts2 = []
    if clawid_short: parts2.append(f'id:{clawid_short}')
    if ts_str:       parts2.append(ts_str)
    line2 = ' · '.join(parts2)

    lines = [l for l in [line1, line2] if l]

    # Measure text block
    draw_tmp = ImageDraw.Draw(Image.new('RGBA', (1, 1)))
    line_sizes = [draw_tmp.textbbox((0, 0), l, font=font) for l in lines]
    text_w = max(b[2] - b[0] for b in line_sizes)
    line_h = max(b[3] - b[1] for b in line_sizes)
    line_gap = 3
    text_h = line_h * len(lines) + line_gap * (len(lines) - 1)

    inner_pad = 6
    pill_w = text_w + inner_pad * 2
    pill_h = text_h + inner_pad * 2

    # Position
    positions = {
        'bottom-right': (W - pill_w - padding, H - pill_h - padding),
        'bottom-left':  (padding,               H - pill_h - padding),
        'top-right':    (W - pill_w - padding,  padding),
        'top-left':     (padding,               padding),
        'center':       ((W - pill_w) // 2,     (H - pill_h) // 2),
    }
    px, py = positions.get(position, positions['bottom-right'])

    # Draw pill background
    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    bg_alpha = int(255 * opacity)
    draw.rounded_rectangle(
        [px, py, px + pill_w, py + pill_h],
        radius=4,
        fill=(*bg_color, bg_alpha),
    )

    # Draw text lines
    for i, line in enumerate(lines):
        ty = py + inner_pad + i * (line_h + line_gap)
        tx = px + inner_pad
        draw.text((tx, ty), line, font=font, fill=(*text_color, 255))

    result = Image.alpha_composite(img, overlay)
    return result.convert('RGB')


def _resolve_position(position, w, h, text_w, text_h, padding):
    mapping = {
        'top-left':     (padding, padding),
        'top-right':    (w - text_w - padding, padding),
        'bottom-left':  (padding, h - text_h - padding),
        'bottom-right': (w - text_w - padding, h - text_h - padding),
        'center':       ((w - text_w) // 2, (h - text_h) // 2),
    }
    return mapping[position]


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    for path in _FONT_CANDIDATES:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()
