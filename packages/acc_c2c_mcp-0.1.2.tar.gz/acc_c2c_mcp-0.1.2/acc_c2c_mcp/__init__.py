"""ACC C2C MCP Server — expose C2C external API as MCP tools."""
