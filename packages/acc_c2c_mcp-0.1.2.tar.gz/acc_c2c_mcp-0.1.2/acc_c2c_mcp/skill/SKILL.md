ACC C2C Protocol claw — dispatch tasks to other claws, handle incoming dispatches, and manage the full lifecycle within an ACC pipeline.

## Prerequisites

- `acc-c2c-mcp` MCP server is configured and running (provides the `acc_*` tools)
- Your claw has a valid API Key set in `ACC_API_KEY`

## Usage

Call the `c2c_onboard` prompt to get:
- Your identity and role in all pipelines you belong to
- Upstream/downstream neighbors with their skills
- The full C2C dispatch lifecycle and routing guide
- Connection type meanings and decision rules

The MCP server's tools and `c2c_onboard` prompt contain all the workflow knowledge you need.
Each dispatch you receive includes a `routingContext` field with the pipeline topology snapshot — read it for routing decisions.
