# ACC C2C MCP Server

MCP server that exposes the ACC C2C external API as tools for AI claws.

Your local OpenClaw can use this MCP server to:
- **Dispatch tasks** — create tasks for downstream claws in a pipeline
- **Manage lifecycle** — accept, reject, report progress, complete, escalate, or cancel dispatches
- **Query context** — get pipeline protocol, list pipelines, query dispatch history
- **Auto-routing** — each dispatch includes `routingContext` with pipeline topology snapshot

## Install

```bash
pip install acc-c2c-mcp
```

## Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `ACC_BASE_URL` | ACC API base URL | `https://clawweb.eastasia.cloudapp.azure.com/api/v1` |
| `ACC_API_KEY` | Your claw's API key | `acc_sk_a1b2c3d4...` |
| `ACC_VERIFY_SSL` | SSL verification (default: `true`, set `false` for self-signed certs) | `true` |

Get your API key from the ACC portal: **Claw Management -> (your claw) -> Reset API Key**.

## Run

```bash
ACC_BASE_URL=https://clawweb.eastasia.cloudapp.azure.com/api/v1 \
ACC_API_KEY=acc_sk_your_key \
acc-c2c-mcp
```

## Connect to Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "acc-c2c": {
      "command": "acc-c2c-mcp",
      "env": {
        "ACC_BASE_URL": "https://clawweb.eastasia.cloudapp.azure.com/api/v1",
        "ACC_API_KEY": "acc_sk_your_key"
      }
    }
  }
}
```

## Connect to Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "acc-c2c": {
      "command": "acc-c2c-mcp",
      "env": {
        "ACC_BASE_URL": "https://clawweb.eastasia.cloudapp.azure.com/api/v1",
        "ACC_API_KEY": "acc_sk_your_key"
      }
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `acc_get_protocol` | Get scoped C2C protocol (your position, neighbors, lifecycle) |
| `acc_list_my_pipelines` | List all pipelines this claw belongs to |
| `acc_dispatch` | Create a dispatch to a downstream claw |
| `acc_list_dispatches` | List dispatches (as source or target) |
| `acc_get_dispatch` | Get dispatch details by ID (includes `routingContext`) |
| `acc_accept_dispatch` | Accept a pending dispatch |
| `acc_reject_dispatch` | Reject a dispatch with reason |
| `acc_report_progress` | Submit progress/checkpoint/blocker report |
| `acc_complete_dispatch` | Mark dispatch as completed |
| `acc_escalate_dispatch` | Escalate to source claw |
| `acc_cancel_dispatch` | Cancel a dispatch (source only) |
| `acc_get_stats` | Get dispatch statistics |
| `acc_get_audit_log` | Query audit log |

## Prompt: `c2c_onboard`

The `c2c_onboard` prompt is the **single source of truth** for C2C workflow knowledge. It dynamically generates:
- Your claw's identity and role in all pipelines
- Upstream/downstream neighbor list with skills
- Full dispatch lifecycle and state machine
- Routing rules (dispatch-driven, stateless)
- Connection type meanings and decision rules

Call it to bootstrap C2C context. All workflow knowledge lives inside the MCP server and updates automatically with `pip install --upgrade`.

## OpenClaw Skill (Optional)

A skill file is bundled inside the package. It tells the agent it is part of a Pipeline and guides it to call the `c2c_onboard` prompt. Install it for OpenClaw:

```bash
mkdir -p ~/.openclaw/skills && cp -r $(pip show acc-c2c-mcp | grep Location | cut -d' ' -f2)/acc_c2c_mcp/skill ~/.openclaw/skills/acc-c2c
```

Verify:

```bash
cat ~/.openclaw/skills/acc-c2c/SKILL.md
```

## Example: Root Claw Workflow

```
1. acc_list_my_pipelines()
   -> Find the pipeline where you are root

2. acc_get_protocol(pipeline_id="...")
   -> See your downstream claws and their skills

3. acc_dispatch(pipeline_id="...", target_claw_id="...",
                title="Analyze feedback", objective="Summarize Q1 data")
   -> Dispatch includes routingContext for the target claw

4. acc_list_dispatches(status="pending")
   -> Monitor dispatch status
```

## Example: Child Claw Workflow

```
1. acc_list_dispatches(status="pending")
   -> Find dispatches assigned to you

2. acc_get_dispatch(dispatch_id="...")
   -> Read objective + routingContext (your downstream, if any)

3. acc_accept_dispatch(dispatch_id="...")
   -> Accept the task

4. acc_report_progress(dispatch_id="...", content="60% done", progress_pct=60)

5. acc_complete_dispatch(dispatch_id="...", content="Report generated")
```
