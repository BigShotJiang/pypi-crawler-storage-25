"""Evidence queue system.

Provides:
- :func:`queue_task` — creates queue entries (called by Evidence.queue())
- :class:`QueueRunner` — executes pending jobs with parallel workers
- :func:`load_results` — merges completed results into an Evidence instance
- :func:`read_manifest` — reads the manifest for status/log display

Queue files live in ``DATAPATH/queue/``:

- ``manifest.json`` — list of queue commands
- ``jobs/<queue_id>__<task>__<evidence_id>.json`` — per-file job status
- ``results/<evidence_id>__<output_key>.json`` — per-file result data

After all jobs complete, :func:`load_results` merges results into Evidence
and :func:`cleanup` removes jobs/ and results/ (manifest stays as log).
"""

import json
import math
import time
import os
from pathlib import Path
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed

from dlist import Dlist
from dlist.helpers import getDitem, flattenDict


# ─── Timestamps ──────────────────────────────────────────────────────

def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ─── Manifest I/O ───────────────────────────────────────────────────

def _queue_dir(data_path):
    """Return the queue directory path, creating it if needed."""
    qdir = Path(data_path) / 'queue'
    qdir.mkdir(parents=True, exist_ok=True)
    return qdir


def _manifest_path(data_path):
    return _queue_dir(data_path) / 'manifest.json'


def read_manifest(data_path):
    """Read the manifest file. Returns list of queue command dicts."""
    mp = _manifest_path(data_path)
    if mp.exists():
        with open(mp, 'r') as f:
            return json.load(f)
    return []


def _write_manifest(data_path, manifest):
    """Write the manifest file."""
    mp = _manifest_path(data_path)
    mp.parent.mkdir(parents=True, exist_ok=True)
    with open(mp, 'w') as f:
        json.dump(manifest, f, indent='   ')


# ─── Job I/O ────────────────────────────────────────────────────────

def _jobs_dir(data_path):
    jdir = _queue_dir(data_path) / 'jobs'
    jdir.mkdir(parents=True, exist_ok=True)
    return jdir


def _results_dir(data_path):
    rdir = _queue_dir(data_path) / 'results'
    rdir.mkdir(parents=True, exist_ok=True)
    return rdir


def _job_path(data_path, queue_id, task_name, evidence_id):
    return _jobs_dir(data_path) / f'{queue_id}__{task_name}__{evidence_id}.json'


def _result_path(data_path, evidence_id, output_key):
    return _results_dir(data_path) / f'{evidence_id}__{output_key}.json'


def _error_report_path(data_path, queue_id):
    """Return the error report file path for a queue command."""
    return _queue_dir(data_path) / f'{queue_id}_errors.json'


def _read_job(path):
    with open(path, 'r') as f:
        return json.load(f)


def _write_job(path, job):
    with open(path, 'w') as f:
        json.dump(job, f, indent='   ')


def _write_result(path, result):
    with open(path, 'w') as f:
        json.dump(result, f, indent='   ')


# ─── Dependency inference ────────────────────────────────────────────

def _infer_dependencies(manifest, inputL, ev):
    """Infer which earlier queue commands must finish first.

    For each input key, extract the top-level root (before first __).
    If that root is NOT present in the current Evidence data but IS
    produced by an earlier queue command, add that command as a dependency.

    Parameters:
        manifest (list): current manifest entries
        inputL (list): input keys for the new queue command
        ev: Evidence instance (to check existing data)

    Returns:
        list of queue_id strings
    """
    deps = []
    for inp in inputL:
        root = inp.split('__')[0] if '__' in inp else inp
        # Check if this key root already exists in the database
        has_key = False
        for d in ev:
            flat = flattenDict(d, charSep=ev.charSep)
            if any(k == root or k.startswith(root + ev.charSep) for k in flat):
                has_key = True
                break
        if has_key:
            continue
        # Check if any earlier queue command produces this root
        for entry in manifest:
            if entry['output_key'] == root and entry['queue_id'] not in deps:
                deps.append(entry['queue_id'])
    return deps


# ─── Queue creation ─────────────────────────────────────────────────

def _next_queue_id(manifest):
    """Generate next queue ID (Q001, Q002, ...)."""
    if not manifest:
        return 'Q001'
    nums = []
    for entry in manifest:
        qid = entry.get('queue_id', '')
        if qid.startswith('Q') and qid[1:].isdigit():
            nums.append(int(qid[1:]))
    return f'Q{max(nums) + 1:03d}' if nums else 'Q001'


def queue_task(ev, task_name, inputL, outputL, query=None):
    """Create queue entries for a task.

    Parameters:
        ev: Evidence instance (loaded, with data)
        task_name (str): registered task name (from tasks.py)
        inputL (list): input keys (same as map())
        outputL (list): output keys (same as map())
        query (dict): filter query (same as map())

    Returns:
        str: the queue_id assigned to this command
    """
    data_path = ev.data_path

    # Read or create manifest
    manifest = read_manifest(data_path)

    # Generate queue ID
    queue_id = _next_queue_id(manifest)

    # Determine output key (first outputL entry, top-level root)
    output_key = outputL[0].split('__')[0] if outputL else task_name

    # Infer dependencies
    after = _infer_dependencies(manifest, inputL, ev)

    # Filter records matching query
    if query:
        subset = ev.filter(**query)
    else:
        subset = ev

    # Create job files
    job_count = 0
    for d in subset:
        eid = d.get(ev.id, '')
        if not eid:
            continue
        # Get input values from all inputL keys
        inputs = []
        skip = False
        for key in inputL:
            val = getDitem(d, key, charSep=ev.charSep)
            if val == {} or val == '' or val is None:
                skip = True
                break
            inputs.append(str(val))
        if skip or not inputs:
            continue

        job = {
            'queue_id': queue_id,
            'task': task_name,
            'evidence_id': eid,
            'input': inputs[0],
            'inputs': inputs,
            'output_key': output_key,
            'output_path': outputL[0] if outputL else task_name,
            'status': 'pending',
            'queued_at': _now(),
            'started_at': None,
            'finished_at': None,
        }
        jp = _job_path(data_path, queue_id, task_name, eid)
        _write_job(jp, job)
        job_count += 1

    # Add to manifest
    entry = {
        'queue_id': queue_id,
        'task': task_name,
        'output_key': output_key,
        'inputL': inputL,
        'outputL': outputL,
        'query': query or {},
        'after': after,
        'file_count': job_count,
        'queued_at': _now(),
        'finished_at': None,
        'status': 'pending',
    }
    manifest.append(entry)
    _write_manifest(data_path, manifest)

    dep_str = f'after {", ".join(after)}' if after else 'no dependencies'
    print(f'{queue_id}: {task_name} → {job_count} files queued ({dep_str})')

    return queue_id


# ─── Queue Runner ────────────────────────────────────────────────────

def _run_single_job(job_path_str, data_path_str):
    """Execute a single job. Called in a worker process.

    Reads the job file, runs the task, writes the result file,
    updates the job file status. Returns (evidence_id, success).
    """
    job_path = Path(job_path_str)
    data_path = Path(data_path_str)

    with open(job_path, 'r') as f:
        job = json.load(f)

    # Mark as running
    job['started_at'] = _now()
    job['status'] = 'running'
    with open(job_path, 'w') as f:
        json.dump(job, f, indent='   ')

    # Import and run the task
    from .tasks import REGISTRY
    task_fn = REGISTRY.get(job['task'])
    if task_fn is None:
        job['status'] = 'error'
        job['finished_at'] = _now()
        job['error'] = f"Unknown task: {job['task']}"
        with open(job_path, 'w') as f:
            json.dump(job, f, indent='   ')
        return (job['evidence_id'], False)

    try:
        inputs = job.get('inputs', [job['input']])
        result = task_fn(*inputs)
    except Exception as e:
        job['status'] = 'error'
        job['finished_at'] = _now()
        job['error'] = str(e)
        with open(job_path, 'w') as f:
            json.dump(job, f, indent='   ')
        
        # Append to error report
        error_entry = {
            'evidence_id': job['evidence_id'],
            'task': job['task'],
            'input': job.get('input', ''),
            'error_message': str(e),
            'timestamp': _now()
        }
        report_path = _error_report_path(data_path, job['queue_id'])
        # Use file locking to prevent race conditions with concurrent writes
        import fcntl
        try:
            # Read existing errors or create new list with file lock
            if report_path.exists():
                with open(report_path, 'r') as f:
                    fcntl.flock(f.fileno(), fcntl.LOCK_SH)  # Shared lock for reading
                    errors = json.load(f)
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            else:
                errors = []
            errors.append(error_entry)
            # Write with exclusive lock
            with open(report_path, 'w') as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)  # Exclusive lock for writing
                json.dump(errors, f, indent='   ')
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except (ImportError, AttributeError):
            # Windows doesn't have fcntl, use retry mechanism
            import time
            max_retries = 5
            for attempt in range(max_retries):
                try:
                    if report_path.exists():
                        with open(report_path, 'r') as f:
                            errors = json.load(f)
                    else:
                        errors = []
                    errors.append(error_entry)
                    with open(report_path, 'w') as f:
                        json.dump(errors, f, indent='   ')
                    break
                except json.JSONDecodeError:
                    # File was being written by another process, wait and retry
                    if attempt < max_retries - 1:
                        time.sleep(0.1 * (attempt + 1))
                    else:
                        # Last attempt failed, write just this error
                        with open(report_path, 'w') as f:
                            json.dump([error_entry], f, indent='   ')
        
        return (job['evidence_id'], False)

    # Write result (each file writes its own result file — no collisions)
    if result and result != '':
        rp = _result_path(data_path, job['evidence_id'], job['output_key'])
        # Build nested dict from output_path (e.g. 'file__hasthumb' → {'file': {'hasthumb': result}})
        output_path = job.get('output_path', job['output_key'])
        parts = output_path.split('__')
        nested = result
        for key in reversed(parts):
            nested = {key: nested}
        _write_result(rp, nested)

    # Mark done
    job['status'] = 'done'
    job['finished_at'] = _now()
    with open(job_path, 'w') as f:
        json.dump(job, f, indent='   ')

    return (job['evidence_id'], True)


class QueueRunner:
    """Executes pending queue jobs respecting dependencies.

    Parameters:
        data_path (Path): DATAPATH directory
        workers (int): number of parallel workers (default: CPU count - 1, min 1)
        cancel_file (Path): if this file exists, stop after current jobs
    """

    def __init__(self, data_path, workers=None):
        self.data_path = Path(data_path)
        cpus = os.cpu_count() or 2
        self.workers = workers or max(1, math.ceil(cpus / 3))
        self._cancel_path = _queue_dir(self.data_path) / '.cancel'

    def run(self):
        """Execute all pending queue commands in dependency order."""
        # Remove stale cancel flag
        if self._cancel_path.exists():
            self._cancel_path.unlink()

        # Reset any 'running' jobs to 'pending' (recovery after crash)
        self._reset_running_jobs()

        manifest = read_manifest(self.data_path)
        if not manifest:
            print('No queue commands found.')
            return

        pending_ids = [e['queue_id'] for e in manifest if e['status'] != 'done']
        if not pending_ids:
            print('All queue commands already done.')
            return

        cpus = os.cpu_count() or '?'
        print(f'Queue runner: {len(pending_ids)} commands, '
              f'{self.workers} workers (CPUs: {cpus})')
        print()

        changed = True
        while changed and not self._cancelled():
            changed = False
            manifest = read_manifest(self.data_path)

            for entry in manifest:
                if entry['status'] == 'done':
                    continue
                if self._cancelled():
                    break

                # Check dependencies
                done_ids = {e['queue_id'] for e in manifest if e['status'] == 'done'}
                waiting = [d for d in entry.get('after', []) if d not in done_ids]
                if waiting:
                    print(f"  {entry['queue_id']}: {entry['task']} "
                          f"— waiting for {', '.join(waiting)}")
                    continue

                # Run this queue command
                t0 = time.time()
                print(f"Running {entry['queue_id']}: {entry['task']} "
                      f"({entry['file_count']} files)")
                self._run_command(entry)
                elapsed = time.time() - t0
                print(f"  {entry['queue_id']} done in {elapsed:.1f}s")
                print()
                changed = True

                # Reload manifest after running
                break  # restart the loop to re-check dependencies

        if self._cancelled():
            print('\nQueue cancelled by user.')
            if self._cancel_path.exists():
                self._cancel_path.unlink()
            return

        # Silent load: merge results into Evidence
        print()
        print('All queue commands done. Merging results...')
        self._silent_load()
        print('Done.')

    def _run_command(self, entry):
        """Run all jobs for a single queue command."""
        queue_id = entry['queue_id']
        task_name = entry['task']

        # Collect pending job files for this command
        jobs_dir = _jobs_dir(self.data_path)
        prefix = f'{queue_id}__{task_name}__'
        job_files = sorted(
            p for p in jobs_dir.iterdir()
            if p.name.startswith(prefix) and p.suffix == '.json'
        )

        # Filter to pending/running only
        pending_jobs = []
        for jp in job_files:
            job = _read_job(jp)
            if job['status'] in ('pending', 'running'):
                pending_jobs.append(str(jp))

        if not pending_jobs:
            self._mark_command_done(queue_id)
            return

        done_count = entry['file_count'] - len(pending_jobs)
        total = entry['file_count']
        errors = 0

        with ProcessPoolExecutor(max_workers=self.workers) as executor:
            futures = {
                executor.submit(_run_single_job, jp, str(self.data_path)): jp
                for jp in pending_jobs
            }
            for future in as_completed(futures):
                if self._cancelled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    return
                eid, success = future.result()
                done_count += 1
                if not success:
                    errors += 1
                print(f'  [{done_count}/{total}] {eid}'
                      f'{" (error)" if not success else ""}',
                      end='\r')

        print()  # newline after progress
        if errors:
            print(f'  {errors} errors in {queue_id}')
            # Error report is already being written by _run_single_job during execution

        self._mark_command_done(queue_id)

    def _mark_command_done(self, queue_id):
        """Update manifest to mark a queue command as done."""
        manifest = read_manifest(self.data_path)
        for entry in manifest:
            if entry['queue_id'] == queue_id:
                entry['status'] = 'done'
                entry['finished_at'] = _now()
                break
        _write_manifest(self.data_path, manifest)

    def _reset_running_jobs(self):
        """Reset any 'running' jobs to 'pending' (crash recovery)."""
        jobs_dir = _jobs_dir(self.data_path)
        if not jobs_dir.exists():
            return
        for jp in jobs_dir.iterdir():
            if jp.suffix != '.json':
                continue
            job = _read_job(jp)
            if job.get('status') == 'running':
                job['status'] = 'pending'
                job['started_at'] = None
                _write_job(jp, job)

    def _cancelled(self):
        """Check if cancel was requested."""
        return self._cancel_path.exists()

    def _silent_load(self):
        """Merge results into Evidence and save."""
        from .main import Evidence, Mode, DATAPATH

        # Load current database
        ev = Evidence(mode=Mode.LOAD)

        # Read all result files
        rdir = _results_dir(self.data_path)
        if not rdir.exists():
            return

        merged = 0
        for rp in sorted(rdir.iterdir()):
            if rp.suffix != '.json':
                continue
            # Parse filename: E0001__exif.json
            stem = rp.stem
            parts = stem.split('__', 1)
            if len(parts) != 2:
                continue
            eid, output_key = parts

            with open(rp, 'r') as f:
                result_data = json.load(f)

            # Merge into the Evidence record
            try:
                ev[eid] = result_data
                merged += 1
            except (KeyError, ValueError):
                print(f'  Warning: {eid} not found in Evidence, skipping')

        if merged > 0:
            ev.save()
            print(f'  Merged {merged} results into database.')

        # Cleanup: remove jobs/ and results/, keep manifest
        self._cleanup()

    def _cleanup(self):
        """Remove jobs/ and results/ directories after merge."""
        import shutil
        jobs_dir = _jobs_dir(self.data_path)
        results_dir = _results_dir(self.data_path)
        if jobs_dir.exists():
            shutil.rmtree(jobs_dir)
        if results_dir.exists():
            shutil.rmtree(results_dir)


# ─── Cancel helper ───────────────────────────────────────────────────

def request_cancel(data_path):
    """Create the cancel flag file."""
    cancel_path = _queue_dir(data_path) / '.cancel'
    cancel_path.touch()
    print('Cancel requested. Queue will stop after current jobs finish.')


# ─── Status helpers ──────────────────────────────────────────────────

def get_status(data_path):
    """Get status summary of running and pending queue commands.

    Returns:
        dict with 'running', 'pending', 'done' lists of manifest entries,
        and per-command job counts.
    """
    manifest = read_manifest(data_path)
    status = {'running': [], 'pending': [], 'done': []}

    for entry in manifest:
        s = entry.get('status', 'pending')
        if s in status:
            status[s].append(entry)
        else:
            status.setdefault(s, []).append(entry)

    # For running/pending commands, count job statuses
    jobs_dir = _jobs_dir(data_path)
    if jobs_dir.exists():
        for entry in status.get('running', []) + status.get('pending', []):
            qid = entry['queue_id']
            task_name = entry['task']
            prefix = f'{qid}__{task_name}__'
            counts = {'pending': 0, 'running': 0, 'done': 0, 'error': 0}
            for jp in jobs_dir.iterdir():
                if jp.name.startswith(prefix) and jp.suffix == '.json':
                    job = _read_job(jp)
                    js = job.get('status', 'pending')
                    counts[js] = counts.get(js, 0) + 1
            entry['job_counts'] = counts

    return status
