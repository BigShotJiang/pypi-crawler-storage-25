"""Evidence configuration management with TOML storage and Rich CLI."""

import sys
from importlib.metadata import version
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import toml
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
console = Console()

def _normalize_path(path: str) -> str:
    """Normalize path: handle trailing slashes and Windows backslashes."""
    # Convert Windows backslashes to forward slashes for consistency
    path = path.replace('\\', '/')
    # Remove trailing slash if present
    path = path.rstrip('/')
    return path

def _default_config_dir() -> Path:
    """Return the platform-appropriate config directory for Evidence."""
    if sys.platform == 'win32':
        # %APPDATA%\evidence (e.g. C:\Users\user\AppData\Roaming\evidence)
        appdata = Path.home() / 'AppData' / 'Roaming' / 'evidence'
        return appdata
    return Path.home() / '.config' / 'evidence'

class ConfigError(Exception):
    """Configuration related errors."""
    pass

class EvidenceConfig:
    """Manages Evidence profiles with TOML storage and Rich interface."""
    
    def __init__(self, config_file: Optional[Path] = None):
        if config_file is None:
            config_file = _default_config_dir() / 'profiles.toml'
        self.config_file = config_file
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        
    def load_config(self) -> Dict:
        """Load configuration from TOML file."""
        if not self.config_file.exists():
            return {"profiles": {}, "current": None}
        
        try:
            with open(self.config_file, 'r') as f:
                return toml.load(f)
        except (toml.TomlDecodeError, IOError) as e:
            console.print(f"[red]Error loading config: {e}[/red]")
            return {"profiles": {}, "current": None}
    
    def save_config(self, config: Dict):
        """Save configuration to TOML file."""
        try:
            with open(self.config_file, 'w') as f:
                toml.dump(config, f)
        except IOError as e:
            console.print(f"[red]Error saving config: {e}[/red]")
            raise ConfigError(f"Failed to save config: {e}")
    
    def add_profile(self, name: str, evidence_paths: List[str], data_path: str, description: str = ""):
        """Add or update a profile."""
        config = self.load_config()
        if "profiles" not in config:
            config["profiles"] = {}
        # Normalize paths
        normalized_evidence = [_normalize_path(p) for p in evidence_paths]
        normalized_data = _normalize_path(data_path)
        config["profiles"][name] = {
            "evidence_paths": normalized_evidence,
            "data_path": normalized_data,
            "description": description
        }
        self.save_config(config)
        console.print(f"[green]Profile '{name}' saved successfully[/green]")
    
    def list_profiles(self) -> List[str]:
        """List all available profiles."""
        config = self.load_config()
        return list(config.get("profiles", {}).keys())
    
    def find_profile_case_insensitive(self, name: str) -> Optional[str]:
        """Find a profile by name, case-insensitive. Returns correct-case name or None."""
        profiles = self.list_profiles()
        name_lower = name.lower()
        for p in profiles:
            if p.lower() == name_lower:
                return p
        return None
    
    def get_current_profile(self) -> Optional[str]:
        """Get currently selected profile."""
        config = self.load_config()
        return config.get("current")
    
    def set_current_profile(self, profile_name: str) -> Dict:
        """Set current profile."""
        config = self.load_config()
        
        if profile_name not in config["profiles"]:
            raise ConfigError(f"Profile '{profile_name}' not found")
        
        profile_data = config["profiles"][profile_name]
        
        config["current"] = profile_name
        self.save_config(config)
        
        console.print(f"[green]Profile '{profile_name}' activated[/green]")
        return profile_data
    
    def get_profile_info(self, profile_name: str) -> Dict:
        """Get information about a specific profile."""
        config = self.load_config()
        return config["profiles"].get(profile_name, {})
    
    def remove_profile(self, profile_name: str):
        """Remove a profile."""
        config = self.load_config()
        
        if profile_name not in config["profiles"]:
            raise ConfigError(f"Profile '{profile_name}' not found")
        
        del config["profiles"][profile_name]
        
        if config.get("current") == profile_name:
            config["current"] = None
        
        self.save_config(config)
        console.print(f"[green]Profile '{profile_name}' removed[/green]")
    
    def create_sample_config(self):
        """Create a sample configuration file."""
        sample_config = {
            "profiles": {
                "test_case": {
                    "evidence_paths": ["/home/user/Projects/test/evidence"],
                    "data_path": "/home/user/Projects/test/data",
                    "description": "Test case for development"
                },
                "case_001": {
                    "evidence_paths": [
                        "/home/user/Projects/case001/evidence1",
                        "/home/user/Projects/case001/evidence2"
                    ],
                    "data_path": "/home/user/Projects/case001/data",
                    "description": "First forensics case"
                }
            },
            "current": None
        }
        self.save_config(sample_config)
        console.print(f"[green]Sample config created at {self.config_file}[/green]")
    
    def validate_paths(self, evidence_paths: List[str], data_path: str) -> Tuple[List[str], bool]:
        """Validate that paths exist."""
        missing_evidence = [p for p in evidence_paths if not Path(p).is_dir()]
        data_exists = Path(data_path).is_dir()
        
        return missing_evidence, data_exists
    
    def show_profile_table(self):
        """Display profiles in a rich table."""
        config = self.load_config()
        current = self.get_current_profile()
        
        if not config["profiles"]:
            console.print("[yellow]No profiles found[/yellow]")
            return
        
        table = Table(title="Evidence Profiles")
        table.add_column("Profile", style="cyan")
        table.add_column("Evidence Paths", style="green")
        table.add_column("Data Path", style="blue")
        table.add_column("Description", style="white")
        
        for name, profile in config["profiles"].items():
            label = f"✓ {name}" if name == current else f"  {name}"
            evidence_str = "\n".join(profile["evidence_paths"])
            table.add_row(
                label,
                evidence_str,
                profile["data_path"],
                profile.get("description", "")
            )
        
        console.print(table)
    
    def show_current_info(self):
        """Show current profile information."""
        current = self.get_current_profile()
        
        if not current:
            console.print("[yellow]No profile currently selected[/yellow]")
            return
        
        profile_data = self.get_profile_info(current)
        
        panel_content = f"""
[bold]Profile:[/bold] {current}
[bold]Evidence Paths:[/bold]
{chr(10).join(f'  • {path}' for path in profile_data['evidence_paths'])}
[bold]Data Path:[/bold] {profile_data['data_path']}
[bold]Description:[/bold] {profile_data.get('description', 'No description')}
        """.strip()
        
        panel = Panel(
            panel_content,
            title=f"Current Profile: {current}",
            border_style="green"
        )
        console.print(panel)

def _interactive_select(config: EvidenceConfig) -> Optional[str]:
    """Show profiles and let user pick one. Returns profile name or None."""
    profiles = config.list_profiles()
    
    if not profiles:
        console.print("[yellow]No profiles found[/yellow]")
        return None
    
    config.show_profile_table()
    
    console.print()
    choice = Prompt.ask(
        f"Select profile (1-{len(profiles)})",
        choices=[str(i) for i in range(1, len(profiles) + 1)]
    )
    
    return profiles[int(choice) - 1]

# CLI Interface
def _version_callback(value: bool):
    if value:
        print(f"forensic-evidence {version('forensic-evidence')}")
        raise typer.Exit()

app = typer.Typer(
    help="Evidence configuration manager",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
)

@app.callback()
def app_callback(
    version: Optional[bool] = typer.Option(None, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
):
    pass

@app.command()
def select(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Select a profile interactively."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    profiles = config.list_profiles()
    
    if not profiles:
        if Confirm.ask("No profiles found. Create sample configuration?"):
            config.create_sample_config()
            profiles = config.list_profiles()
        else:
            console.print("[red]No profiles available. Exiting.[/red]")
            raise typer.Exit(1)
    
    current = config.get_current_profile()
    
    console.print("\n[bold cyan]Available Profiles:[/bold cyan]")
    for i, profile in enumerate(profiles, 1):
        marker = "[green]*[/green]" if profile == current else "[dim] [/dim]"
        console.print(f"{marker} {i:2d}: {profile}")
    
    choice = Prompt.ask(
        f"\nSelect profile (1-{len(profiles)})",
        choices=[str(i) for i in range(1, len(profiles) + 1)]
    )
    
    selected = profiles[int(choice) - 1]
    
    try:
        profile_data = config.set_current_profile(selected)
        
        panel_content = f"""
[bold]Evidence Paths:[/bold]
{chr(10).join(f'  • {path}' for path in profile_data['evidence_paths'])}
[bold]Data Path:[/bold] {profile_data['data_path']}
        """.strip()
        
        panel = Panel(
            panel_content,
            title=f"Profile '{selected}' Activated",
            border_style="green"
        )
        console.print(panel)
        
    except Exception as e:
        console.print(f"[red]Error activating profile: {e}[/red]")
        raise typer.Exit(1)

@app.command()
def show(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Show current profile information."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    config.show_current_info()

@app.command("list")
def list_profiles_cmd(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """List all available profiles."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    config.show_profile_table()

@app.command()
def add(
    name: str = typer.Argument(..., help="Profile name"),
    evidence_paths: str = typer.Argument(..., help="Evidence directories (semicolon-separated)"),
    data_path: str = typer.Argument(..., help="Data directory"),
    description: str = typer.Option("", "--description", "-d", help="Profile description"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Add a new profile."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    
    paths = [_normalize_path(p.strip()) for p in evidence_paths.split(';') if p.strip()]
    normalized_data = _normalize_path(data_path)
    
    dp = Path(normalized_data)
    if not dp.exists():
        dp.mkdir(parents=True, exist_ok=True)
        console.print(f"[cyan]Created data directory: {dp}[/cyan]")
    elif (dp / "database").is_dir():
        console.print(f"[yellow]A database already exists in data path: {dp}[/yellow]")
    
    try:
        config.add_profile(name, paths, normalized_data, description)
    except Exception as e:
        console.print(f"[red]Error adding profile: {e}[/red]")
        raise typer.Exit(1)

@app.command()
def edit(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Edit an existing profile interactively."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    
    profiles = config.list_profiles()
    if not profiles:
        console.print("[yellow]No profiles found[/yellow]")
        raise typer.Exit(1)
    
    current = config.get_current_profile()
    
    console.print("\n[bold cyan]Available Profiles:[/bold cyan]")
    for i, profile in enumerate(profiles, 1):
        marker = "[green]*[/green]" if profile == current else "[dim] [/dim]"
        console.print(f"{marker} {i:2d}: {profile}")
    
    choice = Prompt.ask(
        f"\nSelect profile to edit (1-{len(profiles)})",
        choices=[str(i) for i in range(1, len(profiles) + 1)]
    )
    
    name = profiles[int(choice) - 1]
    profile_data = config.get_profile_info(name)
    
    console.print(f"\n[bold cyan]Editing profile: {name}[/bold cyan]")
    console.print("[dim]Press Enter to keep current value[/dim]\n")
    
    # Ask for profile name (with default)
    new_name = Prompt.ask("Profile name", default=name)
    
    # Ask for evidence paths (with default)
    current_evidence = ";".join(profile_data["evidence_paths"])
    new_evidence = Prompt.ask("Evidence paths (semicolon-separated)", default=current_evidence)
    
    # Ask for data path (with default)
    new_data = Prompt.ask("Data path", default=profile_data["data_path"])
    
    # Ask for description (with default)
    new_desc = Prompt.ask("Description", default=profile_data.get("description", ""))
    
    paths = [_normalize_path(p.strip()) for p in new_evidence.split(';') if p.strip()]
    normalized_data = _normalize_path(new_data)
    
    # If name changed, remove old profile and add new one
    if new_name != name:
        config.remove_profile(name)
    
    if Confirm.ask("Save changes?"):
        config.add_profile(new_name, paths, normalized_data, new_desc)
        console.print(f"[green]Profile '{new_name}' updated successfully[/green]")
    else:
        console.print("[yellow]Changes discarded[/yellow]")

@app.command()
def remove(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Remove a profile."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    profiles = config.list_profiles()
    
    if not profiles:
        console.print("[yellow]No profiles found[/yellow]")
        raise typer.Exit(1)
    
    current = config.get_current_profile()
    
    console.print("\n[bold cyan]Available Profiles:[/bold cyan]")
    for i, profile in enumerate(profiles, 1):
        marker = "[green]*[/green]" if profile == current else "[dim] [/dim]"
        console.print(f"{marker} {i:2d}: {profile}")
    
    choice = Prompt.ask(
        f"\nSelect profile to remove (1-{len(profiles)})",
        choices=[str(i) for i in range(1, len(profiles) + 1)]
    )
    
    name = profiles[int(choice) - 1]
    
    if not Confirm.ask(f"\nRemove profile '[bold]{name}[/bold]'?"):
        console.print("[yellow]Cancelled[/yellow]")
        return
    
    try:
        config.remove_profile(name)
    except ConfigError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

@app.command()
def init(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Initialize configuration with sample profiles."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    config.create_sample_config()

@app.command()
def datapath(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Print the data path for the current profile.

    Usage:  cd $(evidence-setup datapath)
    """
    config = EvidenceConfig(Path(config_file) if config_file else None)
    current = config.get_current_profile()
    if not current:
        sys.stderr.write("No profile selected. Run 'evidence-setup select'.\n")
        raise typer.Exit(1)
    profile_data = config.get_profile_info(current)
    print(profile_data["data_path"])


@app.command()
def dpath(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Shortcut for datapath."""
    datapath(config_file)


@app.command()
def evidencepath(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Print the evidence path for the current profile.

    Usage:  cd $(evidence-setup evidencepath)
    """
    config = EvidenceConfig(Path(config_file) if config_file else None)
    current = config.get_current_profile()
    if not current:
        sys.stderr.write("No profile selected. Run 'evidence-setup select'.\n")
        raise typer.Exit(1)
    profile_data = config.get_profile_info(current)
    print(profile_data["evidence_paths"][0])


@app.command()
def epath(
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Shortcut for evidencepath."""
    evidencepath(config_file)


# ─── CLI subcommands for scripting ───────────────────────────────────

cli_app = typer.Typer(help="Scripting-friendly subcommands", no_args_is_help=True)
app.add_typer(cli_app, name="cli")


@cli_app.command()
def query(
    name: str = typer.Argument(..., help="Profile name to search (case-insensitive)"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Look up a profile name case-insensitively. Prints correct-case name or exits 1."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    found = config.find_profile_case_insensitive(name)
    if found:
        print(found)
    else:
        raise typer.Exit(1)


@cli_app.command()
def setdata(
    profile: str = typer.Argument(..., help="Profile name (case-insensitive)"),
    datapath: str = typer.Argument(..., help="Data path to set"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Set the data path for a profile. Creates profile if it doesn't exist."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    found = config.find_profile_case_insensitive(profile)
    
    if found:
        profile_data = config.get_profile_info(found)
        evidence_paths = profile_data.get("evidence_paths", [])
        description = profile_data.get("description", "")
    else:
        evidence_paths = []
        description = "Obsidian Vault"
    
    config.add_profile(profile, evidence_paths, datapath, description)


@cli_app.command()
def setevidence(
    profile: str = typer.Argument(..., help="Profile name (case-insensitive)"),
    evidence_path: str = typer.Argument(..., help="Evidence path to set"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Set the evidence path for a profile. Fails if profile doesn't exist."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    found = config.find_profile_case_insensitive(profile)
    
    if not found:
        console.print(f"[red]Profile '{profile}' not found[/red]")
        raise typer.Exit(1)
    
    profile_data = config.get_profile_info(found)
    data_path = profile_data.get("data_path", "")
    description = profile_data.get("description", "")
    
    config.add_profile(found, [evidence_path], data_path, description)


@cli_app.command()
def select(
    profile: str = typer.Argument(..., help="Profile name to select (case-insensitive)"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Select a profile by name (case-insensitive)."""
    config = EvidenceConfig(Path(config_file) if config_file else None)
    found = config.find_profile_case_insensitive(profile)
    
    if not found:
        console.print(f"[red]Profile '{profile}' not found[/red]")
        raise typer.Exit(1)
    
    config.set_current_profile(found)


def main():
    """Main CLI entry point."""
    app()

# For importing in Evidence class
def load_config(validate_evidence: bool = True) -> Tuple[str, List[Path], Path]:
    """Load current configuration for Evidence class.
    
    Returns (profile_name, evidence_paths, data_path).
    Raises ConfigError if no profile is selected or paths don't exist.
    
    Parameters:
        validate_evidence: if True (default), raises ConfigError when evidence
            directories are missing. Set to False for tools that only need
            the data directory (e.g. idf, fname).
    """
    config = EvidenceConfig()
    
    current = config.get_current_profile()
    if not current:
        raise ConfigError("No profile selected. Run 'evidence-setup select' to choose a profile.")
    
    profile_data = config.get_profile_info(current)
    profile_name = current
    evidence_paths = [Path(p) for p in profile_data["evidence_paths"]]
    data_path = Path(profile_data["data_path"])
    
    # Strict path validation
    if validate_evidence:
        missing = [str(p) for p in evidence_paths if not p.is_dir()]
        if missing:
            raise ConfigError(
                f"Evidence directories not found: {', '.join(missing)}\n"
                f"Check that the directories exist or the drives are mounted."
            )
    
    if not data_path.is_dir():
        raise ConfigError(
            f"Data directory not found: {data_path}\n"
            f"Check that the directory exists or the drive is mounted."
        )
    
    return profile_name, evidence_paths, data_path
