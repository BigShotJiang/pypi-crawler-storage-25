"""Evidence formatting utilities

Separated from the old dlist strFileEv method for future refactoring.
"""

from dlist.helpers import flattenDict, chars


def strFileEv(ev):
    '''Pretty Output for Evidence file listing

    Displays a tree of directories and files with IDs.
    Requires keys: id, file__dir, file__fil
    '''

    out = ''
    c = chars
    sep = c.he * 70
    last = False

    out += sep + '\n'
    out += c.vt + '\n'
    dirs = ev.vals('file__dir')
    for i, Dir in enumerate(dirs):
        fs = ev.filter(file__dir=Dir)
        if len(fs) != 0:
            last = False
            try:
                dirs[i + 1]    ### test: not last
                out += c.tr + c.ra + ' ' + Dir + '\n'
            except:
                last = True
                out += c.lR + c.ra + ' ' + Dir + '\n'
        ### Lista de archivos
        if last:
            out += '   ' + c.vt + '\n'
            out += _str_list(fs, ['id', 'file__fil'],
                             start='   ' + c.tr + c.ra + ' ',
                             lstart='   ' + c.lR + c.ra + ' ')
        else:
            out += c.vl + '  ' + c.vt + '\n'
            out += _str_list(fs, ['id', 'file__fil'],
                             start=c.vl + '  ' + c.tr + c.ra + ' ',
                             lstart=c.vl + '  ' + c.lR + c.ra + ' ')

    out += sep
    return out


def _str_list(dl, keys, start='', lstart=None, sep='   ', end='\n'):
    '''Simple string list of keys for a Dlist

    Parameters:
        dl: Dlist instance
        keys: list of keys to display
        start: prefix for each line
        lstart: prefix for last line (defaults to start)
        sep: separator between columns
        end: line ending
    '''
    if lstart is None:
        lstart = start

    out = ''
    for idx, item in enumerate(dl):
        D = flattenDict(item, charSep=dl.charSep)
        is_last = (idx == len(dl) - 1)
        prefix = lstart if is_last else start

        parts = []
        for k in keys:
            if k in D:
                parts.append(D[k])
            else:
                parts.append(' --- ')

        out += prefix + sep.join(parts) + end

    return out
