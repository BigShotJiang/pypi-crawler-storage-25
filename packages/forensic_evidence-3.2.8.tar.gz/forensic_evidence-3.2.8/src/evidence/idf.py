"""Evidence ID resolver.

Given an incomplete id, returns the full pathname of the file.
Uses DuckDB to query JSON files directly — no Evidence class needed.

From bash you can invoke as::

    mpv $(idf e08)
    mpv $(idf 42)
    mpv $(idf c3)

Supported input formats:
    - ``42``    → E0042 (default prefix E)
    - ``e42``   → E0042
    - ``E42``   → E0042
    - ``a12``   → A0012 (archive prefix, in files.json)
    - ``c3``    → C0003 (custom prefix, looks up idcs.json → files.json)
"""

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import duckdb

from .config import load_config


# ─── ID Parsing ──────────────────────────────────────────────────────

DIGI = 4
FMT = "E{{:0{:d}d}}".format(DIGI)


@dataclass
class ParsedID:
    """Result of parsing an ID string."""
    prefix: str       # e.g. 'E', 'A', 'C'
    number: int       # e.g. 42
    full_id: str      # e.g. 'E0042'


def parse_id(s: str) -> Optional[ParsedID]:
    """Parse an ID string into prefix, number, and formatted ID.

    Returns None if the input cannot be parsed.
    """
    s = str(s).strip()
    if not s:
        return None

    prefix = "E"

    # Detect prefix letter
    if s[0].isalpha():
        prefix = s[0].upper()
        s = s[1:]

    # Parse number
    try:
        number = int(s)
    except ValueError:
        return None

    if number < 0:
        return None

    # Build full ID string
    full_id = FMT.replace('E', prefix).format(number)

    return ParsedID(prefix=prefix, number=number, full_id=full_id)


# ─── DuckDB Resolution ──────────────────────────────────────────────

def _query_files_json(db_path: Path, target_id: str) -> Optional[str]:
    """Query files.json for an id, return the 'fn' field or None."""
    files_json = db_path / "files.json"
    if not files_json.exists():
        return None

    con = duckdb.connect()
    result = con.execute(
        "SELECT file.fn FROM read_json_auto(?) WHERE id = ?",
        [str(files_json), target_id]
    ).fetchone()
    con.close()

    return result[0] if result else None


def _query_custom_prefix(db_path: Path, parsed: ParsedID) -> Optional[str]:
    """Query id<prefix>s.json for a custom prefix, then look up in files.json."""
    id_file = db_path / f"id{parsed.prefix.lower()}s.json"
    if not id_file.exists():
        print(f"idf: {id_file.name} not found", file=sys.stderr)
        return None

    con = duckdb.connect()

    # Find the main 'id' for this custom prefix id
    id_key = f"id{parsed.prefix.lower()}"
    result = con.execute(
        f"SELECT id FROM read_json_auto(?) WHERE \"{id_key}\" = ?",
        [str(id_file), parsed.full_id]
    ).fetchone()

    # Try shorter format (e.g. C003 instead of C0003)
    if result is None:
        short_id = parsed.full_id[0] + parsed.full_id[2:]
        result = con.execute(
            f"SELECT id FROM read_json_auto(?) WHERE \"{id_key}\" = ?",
            [str(id_file), short_id]
        ).fetchone()

    con.close()

    if result is None:
        return None

    # Now look up the main id in files.json
    main_id = result[0]
    return _query_files_json(db_path, main_id)


def resolve_id(s: str) -> Optional[str]:
    """Parse an ID string and return the full pathname, or None.

    Queries JSON files with DuckDB — does not load the Evidence class.
    """
    parsed = parse_id(s)
    if parsed is None:
        print(f"idf: cannot parse '{s}'", file=sys.stderr)
        return None

    # Get paths from config
    try:
        _profile, evidence_paths, data_path = load_config(validate_evidence=False)
    except Exception as e:
        print(f"idf: {e}", file=sys.stderr)
        return None

    evidence_root = evidence_paths[0]
    db_path = data_path / "database"

    if not db_path.exists():
        print(f"idf: database directory not found: {db_path}", file=sys.stderr)
        return None

    # Query
    if parsed.prefix in ("E", "A"):
        fn = _query_files_json(db_path, parsed.full_id)
    else:
        fn = _query_custom_prefix(db_path, parsed)

    if fn is None:
        print(f"idf: '{parsed.full_id}' not found", file=sys.stderr)
        return None

    # Reconstruct full path: EVIDENCE + fn
    return str(evidence_root / fn.lstrip("/"))


# ─── CLI ─────────────────────────────────────────────────────────────

def main():
    """Entry point for the ``idf`` command."""
    if len(sys.argv) < 2:
        print("Usage: idf <id>", file=sys.stderr)
        print("  e.g.: idf e42  →  prints full path of E0042", file=sys.stderr)
        return 1

    path = resolve_id(sys.argv[1])
    if path:
        print(path)
        return 0
    return 1


if __name__ == '__main__':
    sys.exit(main())
