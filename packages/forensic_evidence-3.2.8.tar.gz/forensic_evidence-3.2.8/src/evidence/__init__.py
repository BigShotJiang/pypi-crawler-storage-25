"""Evidence - Audiovisual Forensics Suite."""

from .config import EvidenceConfig, load_config, ConfigError

__version__ = "2.0.0"
__all__ = [
    "EvidenceConfig", "load_config", "ConfigError",
]

def __getattr__(name):
    """Lazy import for Evidence class and mode constants (requires dlist)."""
    _main_names = {"Evidence", "Mode"}
    if name in _main_names:
        from . import main as _main
        return getattr(_main, name)
    raise AttributeError(f"module 'evidence' has no attribute {name!r}")
