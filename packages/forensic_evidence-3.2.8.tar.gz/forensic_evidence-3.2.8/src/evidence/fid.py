"""Evidence reverse ID resolver.

Given a filename (partial or full), returns the best ID for that file.
Prefers custom prefix IDs (G0296, V0012, W0005) over the default E-prefix.

From bash::

    fid g296                →  G0296
    fid "WhatsApp Video"    →  G0296
    fid test_5              →  E0042

Designed to complement ``fname`` (name → path) and ``idf`` (id → path).
"""

import sys
from pathlib import Path
from typing import Optional, List, Tuple

import duckdb

from .config import load_config
from .idf import parse_id, resolve_id


# ─── Reverse lookup: filename → id ──────────────────────────────────

def _find_id_by_filename(db_path: Path, name: str) -> Optional[str]:
    """Search files.json for a file matching *name*, return its E-id.

    Tries exact stem match first, then LIKE pattern.
    """
    files_json = db_path / "files.json"
    if not files_json.exists():
        return None

    con = duckdb.connect()

    # Exact stem match: fil = name.ext
    result = con.execute(
        """SELECT id FROM read_json_auto(?)
           WHERE file.fil LIKE ?
           LIMIT 1""",
        [str(files_json), f"{name}.%"]
    ).fetchone()

    # Broader match: fn contains name anywhere
    if result is None:
        result = con.execute(
            """SELECT id FROM read_json_auto(?)
               WHERE file.fn LIKE ?
               LIMIT 1""",
            [str(files_json), f"%{name}%"]
        ).fetchone()

    con.close()
    return result[0] if result else None


def _find_id_by_path(db_path: Path, evidence_root: Path, rel_or_abs: str) -> Optional[str]:
    """Find E-id for a relative or absolute path."""
    files_json = db_path / "files.json"
    if not files_json.exists():
        return None

    # Normalise to relative path (as stored in files.json)
    p = Path(rel_or_abs)
    if p.is_absolute():
        try:
            rel = "/" + str(p.relative_to(evidence_root))
        except ValueError:
            rel = str(p)
    else:
        rel = "/" + rel_or_abs.lstrip("/")

    con = duckdb.connect()
    result = con.execute(
        """SELECT id FROM read_json_auto(?)
           WHERE file.fn = ?
           LIMIT 1""",
        [str(files_json), rel]
    ).fetchone()
    con.close()
    return result[0] if result else None


def _get_idx_files(db_path: Path) -> List[Path]:
    """Return all id<x>s.json files in the database directory."""
    return sorted(db_path.glob("id?s.json"))


def _lookup_custom_id(db_path: Path, eid: str) -> Optional[str]:
    """Given an E-id, search all idx files for a custom prefix ID.

    Returns the first custom ID found (e.g. G0296), or None.
    """
    for id_file in _get_idx_files(db_path):
        # Derive the column name: idgs.json → idg
        col = id_file.stem[:-1]  # "idgs" → "idg"

        con = duckdb.connect()
        result = con.execute(
            f'SELECT "{col}" FROM read_json_auto(?) WHERE id = ? LIMIT 1',
            [str(id_file), eid]
        ).fetchone()
        con.close()

        if result and result[0]:
            return result[0]

    return None


def resolve_fid(s: str) -> Optional[str]:
    """Resolve any filename input into the best ID.

    Resolution order:
        1. Absolute path → find E-id → check custom IDs
        2. Relative path with '/' → prepend evidence root, then same
        3. Bare name → fuzzy search in files.json → check custom IDs

    Returns the custom prefix ID if one exists, otherwise the E-id.
    """
    s = s.strip()
    if not s:
        return None

    try:
        _profile, evidence_paths, data_path = load_config(validate_evidence=False)
    except Exception as e:
        print(f"fid: {e}", file=sys.stderr)
        return None

    evidence_root = evidence_paths[0]
    db_path = data_path / "database"

    if not db_path.exists():
        print(f"fid: database directory not found: {db_path}", file=sys.stderr)
        return None

    eid = None

    # 0. Try as Evidence ID (e.g. g296, e42, 10)
    parsed = parse_id(s)
    if parsed is not None:
        # Look up the E-id for this parsed ID
        from .idf import _query_files_json, _query_custom_prefix
        if parsed.prefix in ("E", "A"):
            fn = _query_files_json(db_path, parsed.full_id)
            if fn is not None:
                eid = parsed.full_id
        else:
            fn = _query_custom_prefix(db_path, parsed)
            if fn is not None:
                # _query_custom_prefix returns the filename via files.json;
                # we need the E-id, so look it up from the idx file
                id_file = db_path / f"id{parsed.prefix.lower()}s.json"
                if id_file.exists():
                    con = duckdb.connect()
                    id_key = f"id{parsed.prefix.lower()}"
                    result = con.execute(
                        f'SELECT id FROM read_json_auto(?) WHERE "{id_key}" = ? LIMIT 1',
                        [str(id_file), parsed.full_id]
                    ).fetchone()
                    if result is None:
                        short_id = parsed.full_id[0] + parsed.full_id[2:]
                        result = con.execute(
                            f'SELECT id FROM read_json_auto(?) WHERE "{id_key}" = ? LIMIT 1',
                            [str(id_file), short_id]
                        ).fetchone()
                    con.close()
                    if result:
                        eid = result[0]

    # 1. Absolute path
    if eid is None and s.startswith("/"):
        eid = _find_id_by_path(db_path, evidence_root, s)

    # 2. Relative path with '/'
    elif eid is None and "/" in s:
        eid = _find_id_by_path(db_path, evidence_root, s)

    # 3. Bare name → fuzzy search
    if eid is None:
        eid = _find_id_by_filename(db_path, s)

    if eid is None:
        return None

    # Check for a custom prefix ID
    custom = _lookup_custom_id(db_path, eid)
    return custom if custom else eid


# ─── CLI ─────────────────────────────────────────────────────────────

def main():
    """Entry point for the ``fid`` command."""
    if len(sys.argv) < 2:
        print("Usage: fid <filename|path>", file=sys.stderr)
        print("  Resolves any filename to its Evidence ID.", file=sys.stderr)
        print("  Prefers custom IDs (G0296) over default (E0042).", file=sys.stderr)
        print("  e.g.: fid WhatsApp", file=sys.stderr)
        print("        fid test_5.mp4", file=sys.stderr)
        print("        fid /full/path/to/file.mp4", file=sys.stderr)
        return 1

    result = resolve_fid(sys.argv[1])
    if result:
        print(result)
        return 0

    print(f"fid: '{sys.argv[1]}' not found", file=sys.stderr)
    return 1


if __name__ == '__main__':
    sys.exit(main())
