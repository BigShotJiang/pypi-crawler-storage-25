"""Task registry for the Evidence queue system.

Tasks are Python functions registered by name. The queue runner
looks up tasks by name and calls them with the file path.

Built-in tasks wrap the descriptor functions from :mod:`evidence.descriptors`.

To register a custom task::

    from evidence.tasks import task

    @task('my_analysis')
    def my_analysis(file_path):
        # ... process file ...
        return {'key': 'value'}
"""

REGISTRY = {}


def task(name):
    """Decorator to register a queue task by name.

    Parameters:
        name (str): unique task name used in queue manifest

    Returns:
        decorator that registers the function
    """
    def wrapper(fn):
        REGISTRY[name] = fn
        return fn
    return wrapper


# ─── Built-in tasks ─────────────────────────────────────────────────

@task('exif')
def _exif_task(file_path):
    """Extract EXIF metadata via exiftool."""
    from . import descriptors as fdesc
    result = fdesc.exif(file_path)
    # exif returns [dict] due to @outFmt decorator
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('snd_info')
def _snd_info_task(file_path):
    """Extract audio metadata via soxi."""
    from . import descriptors as fdesc
    result = fdesc.sndInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('img_info')
def _img_info_task(file_path):
    """Extract image metadata via Pillow."""
    from . import descriptors as fdesc
    result = fdesc.imgInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('vid_info')
def _vid_info_task(file_path):
    """Extract video metadata via ffprobe."""
    from . import descriptors as fdesc
    result = fdesc.vidInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('hash')
def _hash_task(file_path):
    """Calculate SHA3-256 hash."""
    from . import descriptors as fdesc
    result = fdesc.hash(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('thumb')
def _thumb_task(file_path, evidence_id, ev_type):
    """Generate a JPEG thumbnail.

    Receives file path, evidence ID, and type from the queue.
    Items with type 'X' get hasthumb='n' without generating any file.
    Returns ``"y"`` for a real thumbnail, ``"n"`` for a placeholder or skipped.
    """
    if ev_type == 'X':
        return 'n'

    import filetype as _ft
    import mimetypes as _mt
    from .thumbs import make_thumb, THUMB_EXT
    from .config import load_config

    # Detect MIME
    kind = _ft.guess(file_path)
    if kind:
        mime = kind.mime
    else:
        guessed, _ = _mt.guess_type(file_path)
        mime = guessed or ''

    _profile, _evidence_paths, data_path = load_config()
    thumbs_dir = data_path / 'thumbs'
    thumbs_dir.mkdir(parents=True, exist_ok=True)
    dst = str(thumbs_dir / f"{evidence_id}{THUMB_EXT}")
    _ok, is_real = make_thumb(file_path, dst, mime)
    return 'y' if is_real else 'n'
