"""evidence-show: CLI command to display evidence summary.

Uses DuckDB to query the JSON database directly for fast read-only access.
Falls back to Dlist only for the ``struct`` subcommand (tree view).

Usage::

    evidence-show                    # all files grouped by directory
    evidence-show files              # same as above
    evidence-show files --dirs       # list directories only
    evidence-show files --dir /cam1  # files in one directory
    evidence-show struct             # structure tree (depth=0)
    evidence-show struct --root exif --depth 2 --top 5
"""

from pathlib import Path
from typing import Optional

import duckdb
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import load_config, ConfigError

app = typer.Typer(
    help="Show evidence summary for the current profile",
    invoke_without_command=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
console = Console()


# ── DuckDB helpers ───────────────────────────────────────────────────

def _db_path(data_path: Path) -> Path:
    return data_path / "database"


def _query(db: Path, sql: str, params=None):
    """Run a SQL query against the evidence database."""
    con = duckdb.connect()
    if params:
        return con.execute(sql, params).fetchall()
    return con.execute(sql).fetchall()


def _stats_query(db: Path):
    """Get record counts via DuckDB join of files.json + types.json."""
    f = db / "files.json"
    t = db / "types.json"
    row = _query(db, f"""
        SELECT
            count(*)                                    as total,
            count(*) FILTER (t.type = 'E')              as evidence,
            count(*) FILTER (t.type = 'A')              as archive,
            count(*) FILTER (f.file.mime.type = 'video') as video,
            count(*) FILTER (f.file.mime.type = 'image') as image,
            count(*) FILTER (f.file.mime.type = 'audio') as audio
        FROM read_json_auto('{f}') f
        JOIN read_json_auto('{t}') t USING (id)
    """)[0]
    return dict(total=row[0], evidence=row[1], archive=row[2],
                video=row[3], image=row[4], audio=row[5])


def _dirs_query(db: Path):
    """Get directories with file counts."""
    f = db / "files.json"
    return _query(db, f"""
        SELECT file.dir as dir, count(*) as n
        FROM read_json_auto('{f}')
        GROUP BY file.dir
        ORDER BY file.dir
    """)


def _files_in_dir_query(db: Path, dir_name: str):
    """Get files in a specific directory."""
    f = db / "files.json"
    t = db / "types.json"
    return _query(db, f"""
        SELECT t.id, f.file.fil as fil
        FROM read_json_auto('{f}') f
        JOIN read_json_auto('{t}') t USING (id)
        WHERE f.file.dir = '{dir_name}'
        ORDER BY t.id
    """)


def _all_files_query(db: Path):
    """Get all files grouped by directory for the tree listing."""
    f = db / "files.json"
    t = db / "types.json"
    return _query(db, f"""
        SELECT f.file.dir as dir, t.id, f.file.fil as fil
        FROM read_json_auto('{f}') f
        JOIN read_json_auto('{t}') t USING (id)
        ORDER BY f.file.dir, t.id
    """)


# ── Dlist loader (struct only) ───────────────────────────────────────

def _load_evidence(files=[], quiet=True):
    """Load Evidence instance, suppressing its default print output."""
    import io
    import contextlib

    from .main import Evidence, Mode

    if quiet:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            ev = Evidence(mode=Mode.LOAD, files=files)
    else:
        ev = Evidence(mode=Mode.LOAD, files=files)
    return ev


# ── Display helpers ──────────────────────────────────────────────────

def _header_panel(profile_name, evidence_path, data_path, stats):
    """Print profile header with stats from a dict."""
    s = stats
    paths = (
        f"[bold]Evidence:[/bold] {evidence_path}\n"
        f"[bold]Data:[/bold]     {data_path}\n"
    )
    panel = Panel(
        Text.from_markup(paths),
        title=f"Profile: {profile_name}",
        subtitle=(f"E {s['evidence']}  "
                  f"(V {s['video']} I {s['image']} A {s['audio']})  ·  "
                  f"A {s['archive']}  ·  Total {s['total']}"),
        border_style="cyan",
    )
    console.print(panel)


def _print_file_tree(rows):
    """Print a directory/file tree from (dir, id, fil) rows."""
    from dlist.helpers import chars
    c = chars
    sep = c.he * 70

    # Group by directory
    dirs = {}
    for dir_name, eid, fil in rows:
        dirs.setdefault(dir_name, []).append((eid, fil))

    out = sep + '\n' + c.vt + '\n'
    dir_list = list(dirs.keys())

    for i, d in enumerate(dir_list):
        is_last_dir = (i == len(dir_list) - 1)
        branch = c.lR if is_last_dir else c.tr
        out += f'{branch}{c.ra} {d}\n'

        files = dirs[d]
        v_prefix = '   ' if is_last_dir else c.vl + '  '
        out += v_prefix + c.vt + '\n'

        for j, (eid, fil) in enumerate(files):
            is_last_file = (j == len(files) - 1)
            fb = c.lR if is_last_file else c.tr
            out += f'{v_prefix}{fb}{c.ra} {eid}   {fil}\n'

    out += sep
    return out


def _check_db():
    """Load config and verify database exists. Returns (profile, paths, data_path)."""
    try:
        profile_name, evidence_paths, data_path = load_config()
    except ConfigError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    db = _db_path(data_path)
    if not (db / "files.json").exists():
        console.print("[yellow]No evidence database found. Run a scan first.[/yellow]")
        raise typer.Exit(1)

    return profile_name, evidence_paths, data_path


# ── Commands ─────────────────────────────────────────────────────────

@app.callback(invoke_without_command=True)
def default(ctx: typer.Context):
    """Show evidence summary for the current profile."""
    if ctx.invoked_subcommand is None:
        _files_cmd(dirs=False, dir_name=None)


@app.command("files")
def files(
    dirs: bool = typer.Option(False, "--dirs",
                              help="List directories only"),
    dir_name: Optional[str] = typer.Option(None, "--dir",
                                           help="List files in a specific directory"),
):
    """List evidence files grouped by directory."""
    _files_cmd(dirs=dirs, dir_name=dir_name)


def _files_cmd(dirs: bool, dir_name: Optional[str]):
    """Implementation for the files subcommand."""
    profile_name, evidence_paths, data_path = _check_db()
    db = _db_path(data_path)
    stats = _stats_query(db)

    _header_panel(profile_name, evidence_paths[0], data_path, stats)
    console.print()

    if dirs:
        for d, n in _dirs_query(db):
            console.print(f"  [bold]{d}[/bold]  [dim]({n} files)[/dim]")
    elif dir_name is not None:
        if not dir_name.startswith('/'):
            dir_name = '/' + dir_name
        if not dir_name.endswith('/'):
            dir_name = dir_name + '/'
        rows = _files_in_dir_query(db, dir_name)
        if not rows:
            console.print(f"[yellow]No files in '{dir_name}'[/yellow]")
        else:
            # Build tree rows with dir column for _print_file_tree
            full_rows = [(dir_name, eid, fil) for eid, fil in rows]
            console.print(_print_file_tree(full_rows))
    else:
        rows = _all_files_query(db)
        console.print(_print_file_tree(rows))


@app.command("struct")
def struct(
    root: str = typer.Option("", "--root", "-r",
                             help="Root key to zoom into (e.g. 'exif', 'file')"),
    depth: int = typer.Option(0, "--depth", "-d",
                              help="Max depth of branches to expand (0=keys only)"),
    top: int = typer.Option(2, "--top", "-t",
                            help="Number of top values to show per leaf"),
):
    """Show data structure tree (loads all data)."""
    profile_name, evidence_paths, data_path = _check_db()
    db = _db_path(data_path)
    stats = _stats_query(db)

    _header_panel(profile_name, evidence_paths[0], data_path, stats)
    console.print()

    ev = _load_evidence(files=[])
    ev.tree(root=root, top=top, depth=depth)
