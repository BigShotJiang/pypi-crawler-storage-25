"""Filename abstraction for evidence files."""

from pathlib import Path


class Filename():
    '''Abstraction for filenames
    filenames can be declared
    * by full path (begins with /)
    * by evidence path (root in EVIDENCE)
    * by reference to database id

    properties:
        evpath, fullpath: Path objects
        name: str filename or db_id, el más corto
        db_id:  id de la base de datos, si existe

    methods:
        __str__(self)  gives full path
        __repr__(self) gives constructor
        exists(self)
        open(self, *args, **kwargs)
        data_ext(self, ext, mkdir=False)  retorna Filename en el espacio de datos, con una extensión agregada. 
        xtras(self) devuelve la lista de archivos extra asociados en formato: 
                    {ext1:[lo inter], ext2:[lo inter]}
                    el archivo asociado tiene la forma: DATAPATH/evpath.inter.ext
    '''

    def __init__(self, str_in, typ=None, verb=False, db=True,
                 evidence_path=None, data_path=None, ev_instance=None):
        '''str_in (str) string de entrada - sin expandibles ('.', '..', '~','cwd')
           typ    (str,None) tipo de entrada ['full','ev','db'] 
           evidence_path (Path): root evidence directory
           data_path (Path): root data directory
           ev_instance: Evidence instance for db queries (avoids circular import)
           no hay chequeo de existencia
        '''
        
        self.evpath = None
        self.db_id  = None
        self.name   = None
        self.ev     = ev_instance
        self.query_db = db
        self.EVIDENCE = evidence_path
        self.DATAPATH = data_path

        self.fullpath, self.typ = self.set_fullpath(str_in, typ, verb)

        ### Complete variables
        # evpath
        if self.EVIDENCE and self.fullpath.is_relative_to(self.EVIDENCE):
            self.evpath = self.fullpath.relative_to(self.EVIDENCE)
            if self.typ == 'full':
                self.typ = 'ev'

        # db_id
        if self.typ == 'db':
            self.db_id = str_in
        elif self.typ == 'ev':
            self.db_id = self.db_query_by_fname(self.evpath)
            if self.db_id is not None:
                self.typ = 'db'

        # name
        if self.typ == 'db':
            self.name = self.db_id
        else:
            self.name = str(self.fullpath.stem)

    def set_fullpath(self, str_in, typ, verb):

        path_in = Path(str_in)
        
        ### Explicit types
        if typ == 'full':
            if path_in.is_absolute():
                fullpath = path_in
            else:
                fullpath = Path('/', path_in)
        elif typ == 'ev':
            if path_in.is_absolute():
                if verb:
                    print(f"Filename Error: [{str_in}] type '{typ}' cannot be absolute path")
                fullpath = None
            else:
                fullpath = self.EVIDENCE / path_in
        elif typ == 'db':
            fname = self.db_query_by_id(str_in)
            if fname is None:
                if verb:
                    print(f"Filename Error: '{str_in}' not found in database")
                fullpath = None
            else:
                fullpath = self.EVIDENCE / fname

        elif typ is not None:
            if verb:
                print(f"Filename Error: [{str_in}] type '{typ}' not recognized")
                fullpath = None
        else:
            ## typ=None:  Implicit types
            if path_in.is_absolute():
                typ = 'full'
                fullpath = path_in
            else:
                if '/' in str_in:
                    typ = 'ev'
                    fullpath = self.EVIDENCE / path_in
                else:
                    typ = 'db'
                    fname = self.db_query_by_id(str_in)
                    if fname is not None:
                        fullpath = self.EVIDENCE / fname
                    else:
                        fullpath = None

        if fullpath is None:
            raise ValueError(f"incorrect parameters in Filename('{str_in}', '{typ}')")
        else:
            return fullpath, typ
        
    def db_query_by_id(self, id):
        if not self.query_db:
            return None
        if self.ev is None:
            # Lazy import to avoid circular dependency
            from .main import Evidence, LOAD
            self.ev = Evidence(mode=LOAD, files=['files'])

        try:
            return Path(self.ev.filter(id=id)[0]['file']['fn'][1:])
        except:
            return None        

    def db_query_by_fname(self, evpath):
        if not self.query_db:
            return None
            
        if self.ev is None:
            # Lazy import to avoid circular dependency
            from .main import Evidence, LOAD
            self.ev = Evidence(mode=LOAD, files=['files'])

        try:
            return self.ev.filter(file_fn='/'+str(evpath))[0]['id']
        except:
            return None

    def __str__(self):
        return str(self.fullpath)
    def __repr__(self):
        if self.typ == 'full':
            return f"Filename('{self.fullpath}', '{self.typ}')"
        elif self.typ == 'ev':
            return f"Filename('{self.evpath}', '{self.typ}')"
        elif  self.typ == 'db':
            return f"Filename('{self.db_id}', '{self.typ}')"

    def data_ext(self, ext, mkdir=False):
        if not ext.startswith('.'):
            ext = '.' + ext

        if self.typ == 'full':
            return Filename(str(self.fullpath) + ext,
                           evidence_path=self.EVIDENCE,
                           data_path=self.DATAPATH,
                           ev_instance=self.ev)
        else:
            PATH = self.DATAPATH / self.evpath
            if mkdir:
                PATH.parent.mkdir(parents=True, exist_ok=True)
            return Filename(str(PATH) + ext,
                           evidence_path=self.EVIDENCE,
                           data_path=self.DATAPATH,
                           ev_instance=self.ev)

    def xtras(self):
        PATH = self.DATAPATH / self.evpath
        xtrapaths = PATH.parent.glob(self.evpath.name+'.*')
        xtrapaths = [str(item) for item in xtrapaths]

        exts = [item[len(str(PATH))+1:] for item in xtrapaths]
        exts = [item for item in exts if len(item)!=0 ]

        return exts

    def exists(self):
        return self.fullpath.is_file()

    def open(self, *args, **kwargs):
        return self.fullpath.open(*args, **kwargs)
