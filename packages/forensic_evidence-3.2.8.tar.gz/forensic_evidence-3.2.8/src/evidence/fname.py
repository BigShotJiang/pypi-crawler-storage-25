"""Evidence filename resolver.

Resolves any input into a full pathname:
- Evidence IDs:       ``fname e10``  →  /full/path/to/file.mp4
- Bare numbers:       ``fname 42``   →  /full/path/to/file.mp4
- Relative paths:     ``fname tacho/vtests/test_5.mp4``  →  /full/path/...
- Partial filenames:  ``fname test_5``  →  /full/path/.../test_5.mp4
- Absolute paths:     ``fname /full/path/file.mp4``  →  /full/path/file.mp4

Designed to be used in bash functions::

    mpvf() { mpv "$(fname "$1")"; }
    vlcf() { vlc "$(fname "$1")"; }

Then::

    mpvf e10
    mpvf test_5
    mpvf tacho/vtests/test_5.mp4
"""

import sys
from pathlib import Path
from typing import Optional

import duckdb

from .config import load_config
from .idf import parse_id, resolve_id


# ─── Filename Resolution ─────────────────────────────────────────────

def _search_by_filename(db_path: Path, evidence_root: Path, name: str) -> Optional[str]:
    """Search files.json for a file whose name matches (without extension).

    Tries exact stem match first, then LIKE pattern.
    Returns the full path or None.
    """
    files_json = db_path / "files.json"
    if not files_json.exists():
        return None

    con = duckdb.connect()

    # Exact stem match: fn ends with /name.ext
    result = con.execute(
        """SELECT file.fn FROM read_json_auto(?)
           WHERE file.fil LIKE ?
           LIMIT 1""",
        [str(files_json), f"{name}.%"]
    ).fetchone()

    # Broader match: fn contains name anywhere
    if result is None:
        result = con.execute(
            """SELECT file.fn FROM read_json_auto(?)
               WHERE file.fn LIKE ?
               LIMIT 1""",
            [str(files_json), f"%{name}%"]
        ).fetchone()

    con.close()

    if result is None:
        return None

    fn = result[0]
    return str(evidence_root / fn.lstrip("/"))


def _resolve_ev_path(evidence_root: Path, rel_path: str) -> Optional[str]:
    """Resolve a path relative to the evidence root."""
    full = evidence_root / rel_path.lstrip("/")
    if full.exists():
        return str(full)
    return None


def resolve(s: str) -> Optional[str]:
    """Resolve any input into a full pathname.

    Resolution order (path checks first, no config needed):
        1. Absolute path → return as-is
        2. Relative path with '/' that exists on disk → return as-is

    Then (requires config/DB):
        3. Evidence ID (e10, 42, a3) → DuckDB lookup
        4. Relative path with '/' → prepend evidence root
        5. Bare name (test_5) → fuzzy search in files.json
    """
    s = s.strip()
    if not s:
        return None

    # 1. Absolute path — no config needed
    if s.startswith("/"):
        return s

    # 2. Relative path that exists on disk — no config needed
    p = Path(s)
    if "/" in s and p.exists():
        return str(p.resolve())

    # 3. Try as Evidence ID
    parsed = parse_id(s)
    if parsed is not None:
        result = resolve_id(s)
        if result is not None:
            return result

    # Get config for path-based lookups
    try:
        _profile, evidence_paths, data_path = load_config(validate_evidence=False)
    except Exception as e:
        print(f"fname: {e}", file=sys.stderr)
        return s

    evidence_root = evidence_paths[0]
    db_path = data_path / "database"

    # 4. Relative path with '/' → evidence-relative
    if "/" in s:
        result = _resolve_ev_path(evidence_root, s)
        if result is not None:
            return result

    # 5. Bare name → fuzzy search in files.json
    if db_path.exists():
        result = _search_by_filename(db_path, evidence_root, s)
        if result is not None:
            return result

    # Nothing found — return input unchanged
    return s


# ─── CLI ─────────────────────────────────────────────────────────────

def main():
    """Entry point for the ``fname`` command."""
    if len(sys.argv) < 2:
        print("Usage: fname <id|filename|path>", file=sys.stderr)
        print("  Resolves any input to a full pathname.", file=sys.stderr)
        print("  e.g.: fname e10", file=sys.stderr)
        print("        fname test_5", file=sys.stderr)
        print("        fname tacho/vtests/test_5.mp4", file=sys.stderr)
        return 1

    path = resolve(sys.argv[1])
    if path:
        print(path)
        return 0
    return 1


if __name__ == '__main__':
    sys.exit(main())
