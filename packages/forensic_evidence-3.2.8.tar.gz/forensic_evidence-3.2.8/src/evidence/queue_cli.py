"""evidence-queue: CLI for the Evidence queue system.

Usage::

    evidence-queue launch              # start processing pending jobs
    evidence-queue launch --workers 4  # with 4 parallel workers
    evidence-queue status              # show running + pending commands
    evidence-queue log                 # show full history
    evidence-queue report              # show error reports
    evidence-queue cancel              # stop after current jobs finish
"""

import json
import typer
from typing import Optional
from rich.console import Console
from rich.table import Table

from .config import load_config

app = typer.Typer(help="Evidence queue manager", invoke_without_command=True)
console = Console()


@app.callback()
def main(ctx: typer.Context):
    """Evidence queue manager."""
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())


def _get_data_path():
    """Load data path from config."""
    _profile, _evidence_paths, data_path = load_config(validate_evidence=False)
    return data_path


@app.command()
def launch(
    workers: Optional[int] = typer.Option(
        None, "--workers", "-w",
        help="Number of parallel workers (default: CPU count - 1)"
    ),
):
    """Start processing pending queue jobs."""
    from .queue import QueueRunner
    # Import tasks to ensure built-in tasks are registered
    from . import tasks  # noqa: F401

    data_path = _get_data_path()
    runner = QueueRunner(data_path, workers=workers)
    try:
        runner.run()
    finally:
        # Restore terminal echo (subprocesses can leave it disabled)
        import sys, os
        if sys.stdin.isatty():
            if os.name == 'nt':
                pass  # Windows doesn't have this issue
            else:
                os.system('stty sane')


@app.command()
def status():
    """Show running and pending queue commands with progress."""
    from .queue import get_status

    data_path = _get_data_path()
    st = get_status(data_path)

    running = st.get('running', [])
    pending = st.get('pending', [])

    if not running and not pending:
        console.print("[dim]No running or pending queue commands.[/dim]")
        return

    if running:
        table = Table(title="Running", show_header=True, header_style="bold green")
        table.add_column("ID", style="bold")
        table.add_column("Task")
        table.add_column("Progress")
        table.add_column("Queued at")

        for entry in running:
            counts = entry.get('job_counts', {})
            done = counts.get('done', 0)
            total = entry.get('file_count', 0)
            errors = counts.get('error', 0)
            running_n = counts.get('running', 0)
            progress = f"{done}/{total}"
            if running_n:
                progress += f" ({running_n} active)"
            if errors:
                progress += f" [red]{errors} errors[/red]"

            table.add_row(
                entry['queue_id'],
                entry['task'],
                progress,
                entry.get('queued_at', ''),
            )
        console.print(table)
        console.print()

    if pending:
        table = Table(title="Pending", show_header=True, header_style="bold yellow")
        table.add_column("ID", style="bold")
        table.add_column("Task")
        table.add_column("Files")
        table.add_column("Waiting for")
        table.add_column("Queued at")

        for entry in pending:
            after = ', '.join(entry.get('after', [])) or '—'
            table.add_row(
                entry['queue_id'],
                entry['task'],
                str(entry.get('file_count', 0)),
                after,
                entry.get('queued_at', ''),
            )
        console.print(table)


@app.command()
def log():
    """Show full queue history from manifest."""
    from .queue import read_manifest

    data_path = _get_data_path()
    manifest = read_manifest(data_path)

    if not manifest:
        console.print("[dim]No queue history.[/dim]")
        return

    table = Table(title="Queue History", show_header=True, header_style="bold")
    table.add_column("ID", style="bold")
    table.add_column("Task")
    table.add_column("Files", justify="right")
    table.add_column("Queued at")
    table.add_column("Finished at")
    table.add_column("Status")

    for entry in manifest:
        st = entry.get('status', 'pending')
        if st == 'done':
            status_str = "[green]done[/green]"
        elif st == 'running':
            status_str = "[yellow]running[/yellow]"
        elif st == 'error':
            status_str = "[red]error[/red]"
        else:
            status_str = "[dim]pending[/dim]"

        table.add_row(
            entry['queue_id'],
            entry['task'],
            str(entry.get('file_count', 0)),
            entry.get('queued_at', ''),
            entry.get('finished_at', '') or '—',
            status_str,
        )

    console.print(table)


@app.command()
def cancel():
    """Request cancellation — queue stops after current jobs finish."""
    from .queue import request_cancel

    data_path = _get_data_path()
    request_cancel(data_path)


@app.command()
def report():
    """Show error report for a queue command."""
    from .queue import read_manifest, _error_report_path, _queue_dir
    from rich.prompt import Prompt

    data_path = _get_data_path()
    manifest = read_manifest(data_path)
    
    if not manifest:
        console.print("[dim]No queue history.[/dim]")
        return
    
    # Find queue_ids with error reports
    queue_dir = _queue_dir(data_path)
    error_queues = []
    for entry in manifest:
        report_path = _error_report_path(data_path, entry['queue_id'])
        if report_path.exists():
            error_queues.append(entry)
    
    if not error_queues:
        console.print("[dim]No error reports found.[/dim]")
        return
    
    # Display menu
    console.print("\n[bold cyan]Queue Commands with Errors:[/bold cyan]")
    for i, entry in enumerate(error_queues, 1):
        console.print(f"  {i:2d}: {entry['queue_id']} - {entry['task']} ({entry.get('file_count', 0)} files)")
    
    choice = Prompt.ask(
        f"\nSelect queue to view (1-{len(error_queues)})",
        choices=[str(i) for i in range(1, len(error_queues) + 1)]
    )
    
    selected_entry = error_queues[int(choice) - 1]
    queue_id = selected_entry['queue_id']
    
    # Read error report
    report_path = _error_report_path(data_path, queue_id)
    with open(report_path, 'r') as f:
        errors = json.load(f)
    
    if not errors:
        console.print("[dim]No errors in report.[/dim]")
        return
    
    # Display error report in table
    table = Table(title=f"Error Report: {queue_id}", show_header=True, header_style="bold red")
    table.add_column("Evidence ID", style="bold")
    table.add_column("Task")
    table.add_column("Input")
    table.add_column("Error Message", style="red")
    table.add_column("Timestamp")
    
    for error in errors:
        table.add_row(
            error.get('evidence_id', ''),
            error.get('task', ''),
            error.get('input', '')[:50] + '...' if len(error.get('input', '')) > 50 else error.get('input', ''),
            error.get('error_message', '')[:60] + '...' if len(error.get('error_message', '')) > 60 else error.get('error_message', ''),
            error.get('timestamp', '')
        )
    
    console.print(table)
    console.print(f"\nTotal errors: {len(errors)}")
