"""Thumbnail generators for Evidence files.

Generates JPEG thumbnails for various file types:
  - Images (via Pillow)
  - Videos (via ffmpeg)
  - PDFs (via pymupdf / fitz)
  - Text files (rendered with Pillow)
  - DOCX files (converted to PDF via libreoffice, then rendered)

Thumbnails are stored in ``DATAPATH/thumbs/<evidence_id>.jpg``.
"""

import subprocess
from pathlib import Path

from PIL import Image

# ─── Settings ──────────────────────────────────────────────────────
THUMB_SIZE = (350, 350)
THUMB_EXT = ".jpg"
THUMB_QUALITY = 85


# ─── Generators ────────────────────────────────────────────────────

def _placeholder(dst: Path) -> bool:
    """Generate a gray placeholder with crossed diagonals."""
    try:
        from PIL import ImageDraw
        w, h = THUMB_SIZE
        im = Image.new("RGB", (w, h), color=(80, 80, 80))
        draw = ImageDraw.Draw(im)
        draw.line([(0, 0), (w, h)], fill=(120, 120, 120), width=2)
        draw.line([(w, 0), (0, h)], fill=(120, 120, 120), width=2)
        im.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_image(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from an image file."""
    try:
        with Image.open(src) as im:
            im.thumbnail(THUMB_SIZE)
            im = im.convert("RGB")
            im.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_video(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from a video, picking a frame at ~10% duration."""
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries",
             "format=duration", "-of", "default=noprint_wrappers=1:nokey=1",
             str(src)],
            capture_output=True, text=True, timeout=15,
        )
        duration = float(probe.stdout.strip()) if probe.returncode == 0 else 0
        seek = max(2, min(duration * 0.10, 30)) if duration > 4 else 0

        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(seek), "-i", str(src),
             "-frames:v", "1", "-q:v", "5",
             "-vf", f"scale='min({THUMB_SIZE[0]},iw)':'min({THUMB_SIZE[1]},ih)'"
                    ":force_original_aspect_ratio=decrease",
             str(dst)],
            capture_output=True, timeout=30,
        )
        return dst.exists()
    except Exception:
        return False


def _thumb_pdf(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from the first page of a PDF."""
    try:
        import fitz  # pymupdf
        doc = fitz.open(str(src))
        page = doc[0]
        mat = fitz.Matrix(2, 2)
        pix = page.get_pixmap(matrix=mat)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        doc.close()
        img.thumbnail(THUMB_SIZE)
        img.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_text(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail rendering the first lines of a text file."""
    try:
        from PIL import ImageDraw, ImageFont
        with open(src, 'r', errors='replace') as f:
            lines = []
            for i, line in enumerate(f):
                if i >= 30:
                    break
                lines.append(line.rstrip('\n')[:80])
        text = '\n'.join(lines) if lines else '(empty)'

        w, h = THUMB_SIZE
        im = Image.new("RGB", (w, h), color=(255, 255, 255))
        draw = ImageDraw.Draw(im)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
        except Exception:
            font = ImageFont.load_default()
        draw.text((8, 8), text, fill=(30, 30, 30), font=font)
        im.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_docx(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from a DOCX via LibreOffice PDF conversion."""
    import tempfile
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            subprocess.run(
                ["libreoffice", "--headless", "--convert-to", "pdf",
                 "--outdir", tmpdir, str(src)],
                capture_output=True, timeout=60,
            )
            pdfs = list(Path(tmpdir).glob("*.pdf"))
            if pdfs:
                return _thumb_pdf(pdfs[0], dst)
        return False
    except Exception:
        return False


# ─── Dispatcher ────────────────────────────────────────────────────

def make_thumb(src: str, dst: str, mime: str) -> tuple:
    """Create a thumbnail for a file, with placeholder fallback.

    Parameters:
        src: absolute path to the source file
        dst: absolute path for the output JPEG thumbnail
        mime: MIME type string (e.g. 'image/jpeg', 'video/mp4', 'application/pdf')

    Returns:
        (ok, is_real): ok=True if a file was created,
                       is_real=True if it's a real thumb (not a placeholder)
    """
    src_p = Path(src)
    dst_p = Path(dst)
    dst_p.parent.mkdir(parents=True, exist_ok=True)

    ok = False
    if mime.startswith('image/'):
        ok = _thumb_image(src_p, dst_p)
    elif mime.startswith('video/'):
        ok = _thumb_video(src_p, dst_p)
    elif mime == 'application/pdf':
        ok = _thumb_pdf(src_p, dst_p)
    elif mime.startswith('text/'):
        ok = _thumb_text(src_p, dst_p)
    elif mime in ('application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                  'application/msword'):
        ok = _thumb_docx(src_p, dst_p)

    if ok:
        return (True, True)

    # Fallback: placeholder
    ok = _placeholder(dst_p)
    return (ok, False)
