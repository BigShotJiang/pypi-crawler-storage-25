
Este archivo está sólo para demostrar algunas posibilidades de los links
`gotime`.

Estos links sólo funcionan con el ejemplo de prueba provisto en los tutorials.

- Desde la Galería puedo abrir una página sobre cada pieza de evidencia
- Al hacer click sobre la imagen, se abre una visualización

## Links audiovisuales

La evidencia audiovisual abre el programa `gotime` que permite generar links a los archivos que pueden usarse desde un documento `.md`. Esos links son textos copiados al portapapeles.

-  Con `Ctrl+f` copia al portapapeles un link al comienzo del archivo:  
   [oficina](gotime:///~/vids/oficina.mp4)
- Con `Ctrl+i` se copia con el ID como texto, al mismo link:
  [E0005](gotime:///~/vids/oficina.mp4)
- Con `Ctrl+l` se copia además el tiempo que estoy mirando en el video
  [E0005 @ 00:00:9.577](gotime:///~/vids/oficina.mp4?t=9.58)
- También, con el mismo comando, puedo copiar un rectángulo seleccionado:
  [E0005 @ 00:00:9.577](gotime:///~/vids/oficina.mp4?t=9.58&rect=468,254,162,89)
- Si estoy haciendo una serie de anotaciones sobre el mismo video, con `Ctrl+c` sólo muestra como texto el tiempo en el video.
- Puedo hacer links y anotaciones sobre otros videos en el mismo documento
	- [E0003 @ 00:01:34.211](gotime:///~/otros/arroyito.mkv?t=94.21) hidrante

Por el funcionamiento de `gotime`,  si el video no está abierto en una ventana,abre una ventana en el tiempo especificado, pero si está abierto, esa ventana va al tiempo que clickeamos.

Todos estos links funcionan localmente, pero son portátiles en el sentido que si otra computadora tiene activada la misma base de datos y tiene los archivos audiovisuales cargados, los links funcionan de la misma manera. 

### Links `https`

Si a cualquiera de los comandos anteriores se les agrega la tecla `Shift` (`Ctrl+F`-->`Shift+Ctrl+F`) obtenemos un link https, que hace lo mismo.    
Ese link tiene la desventaja que requiere conexión a internet para funcionar, pero 
puede pegarse a un google docs o a un mensaje de wasapp. Si el que hace click tiene La Pata instalado, el link hace lo mismo que si fuera local.  uhhh.

## Links a PDF


También es muy buena la manera en que se hacen links a los documentos en pdf. 

Desde la galería pueden abrir el documento haciendo click. El documento se abre dentro del obsidian. 

Si abren un documento de anotaciones y lo dejan en modo de edición, con el cursor adonde quiero anotar: cada vez que marco una frase del documento, me genera un link como este:

- [[conti.pdf#page=12&selection=7,27,9,26|conti, p.12]] cómo comienza la historia
- [[conti.pdf#page=18&selection=2,36,5,11&color=red|conti, p.18]] tremenda consideración
- [[conti.pdf#page=119&selection=2,0,11,19&color=red|conti, p.119]] olvidar al padre es no saber de quién es el impulso

y así puedo hace varias anotaciones y poner comentarios de manera de no perder la referencia del origen. uuuuhh. 

Es algo que uso para hacer anotaciones de los expedientes, y volver aa encontrarlas. 

Estos md también se pueden compartir y no queda nada anotado en el pdf mismo. 

---

