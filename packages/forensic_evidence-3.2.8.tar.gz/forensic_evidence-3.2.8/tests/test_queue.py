"""Tests for the Evidence queue system.

Tests:
1. Task registry
2. Queue creation (manifest, job files, dependency inference)
3. Queue runner (execution, resume, cancel)
4. Silent load (merge results, cleanup)
5. CLI commands (status, log)
"""

import os
import sys
import json
import shutil
import tempfile
import time
from pathlib import Path


# ─── Helpers ─────────────────────────────────────────────────────────

def _setup_env(ev_path, data_path):
    """Set env vars and reload evidence modules."""
    os.environ['EVIDENCE_PROFILE'] = 'test_queue'
    os.environ['EVIDENCE_PATHS'] = str(ev_path)
    os.environ['EVIDENCE_DATA'] = str(data_path)

    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith('evidence'):
            del sys.modules[mod_name]


def _cleanup_env():
    """Remove env vars."""
    os.environ.pop('EVIDENCE_PROFILE', None)
    os.environ.pop('EVIDENCE_PATHS', None)
    os.environ.pop('EVIDENCE_DATA', None)


def _create_test_files(ev_path):
    """Create minimal test files in evidence directory."""
    (ev_path / "disk1").mkdir()
    (ev_path / "disk1" / "photo1.jpg").write_bytes(
        b'\xff\xd8\xff\xe0' + b'\x00' * 100)
    (ev_path / "disk1" / "photo2.jpg").write_bytes(
        b'\xff\xd8\xff\xe0' + b'\x00' * 100)
    (ev_path / "disk1" / "doc.txt").write_text("hello")
    (ev_path / "disk2").mkdir()
    (ev_path / "disk2" / "notes.txt").write_text("world")


# ─── 1. Task Registry Tests ─────────────────────────────────────────

def test_task_registry():
    """Test the @task decorator and REGISTRY."""
    print("=" * 60)
    print("TASK REGISTRY TESTS")
    print("=" * 60)

    from evidence.tasks import REGISTRY, task

    # Built-in tasks should be registered
    assert 'exif' in REGISTRY, "exif task not registered"
    assert 'snd_info' in REGISTRY, "snd_info task not registered"
    assert 'img_info' in REGISTRY, "img_info task not registered"
    assert 'vid_info' in REGISTRY, "vid_info task not registered"
    assert 'hash' in REGISTRY, "hash task not registered"
    print(f"  ✓ {len(REGISTRY)} built-in tasks registered")

    # Register a custom task
    @task('test_task')
    def my_test_task(file_path):
        return {'test': True, 'path': file_path}

    assert 'test_task' in REGISTRY
    result = REGISTRY['test_task']('/fake/path.jpg')
    assert result == {'test': True, 'path': '/fake/path.jpg'}
    print("  ✓ Custom @task decorator works")

    # Clean up
    del REGISTRY['test_task']

    print()


# ─── 2. Queue Creation Tests ────────────────────────────────────────

def test_queue_creation():
    """Test Evidence.queue() creates manifest and job files."""
    print("=" * 60)
    print("QUEUE CREATION TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)
        _create_test_files(ev_path)
        _setup_env(ev_path, data_path)

        # Register a simple test task
        from evidence.tasks import REGISTRY, task

        @task('test_meta')
        def test_meta(file_path):
            return {'analyzed': True}

        from evidence.main import Evidence, Mode

        # SCAN to populate
        ev = Evidence(mode=Mode.SCAN)
        assert len(ev) > 0
        print(f"  ✓ SCAN found {len(ev)} files")

        # scan() auto-queues 4 built-in tasks (exif, snd_info, img_info, vid_info)
        from evidence.queue import read_manifest
        manifest = read_manifest(data_path)
        auto_count = len(manifest)
        assert auto_count >= 4, f"Expected at least 4 auto-queued tasks, got {auto_count}"
        print(f"  ✓ scan() auto-queued {auto_count} tasks")

        # Queue an additional task
        qid = ev.queue('test_meta',
                        inputL=['file__pathName'],
                        outputL=['meta'],
                        query={})
        assert qid == f'Q{auto_count + 1:03d}', f"Expected Q{auto_count + 1:03d}, got {qid}"
        print(f"  ✓ queue() returned {qid}")

        # Check manifest
        manifest = read_manifest(data_path)
        assert len(manifest) == auto_count + 1
        last = manifest[-1]
        assert last['queue_id'] == qid
        assert last['task'] == 'test_meta'
        assert last['status'] == 'pending'
        assert last['file_count'] == len(ev)
        print(f"  ✓ Manifest has {len(manifest)} entries, last with {last['file_count']} files")

        # Check job files exist for our task
        jobs_dir = data_path / 'queue' / 'jobs'
        assert jobs_dir.exists()
        job_files = list(jobs_dir.glob(f'{qid}__test_meta__*.json'))
        assert len(job_files) == len(ev), \
            f"Expected {len(ev)} job files, got {len(job_files)}"
        print(f"  ✓ {len(job_files)} job files created")

        # Check job file content
        job = json.loads(job_files[0].read_text())
        assert job['status'] == 'pending'
        assert job['task'] == 'test_meta'
        assert job['queued_at'] is not None
        assert job['started_at'] is None
        print("  ✓ Job file content correct")

        # Queue another task
        qid2 = ev.queue('test_meta',
                         inputL=['file__pathName'],
                         outputL=['meta2'],
                         query={})
        manifest = read_manifest(data_path)
        assert len(manifest) == auto_count + 2
        print(f"  ✓ Second queue command {qid2} added")

        # Clean up custom task
        del REGISTRY['test_meta']
        _cleanup_env()

    print()


# ─── 3. Dependency Inference Tests ───────────────────────────────────

def test_dependency_inference():
    """Test auto-inference of dependencies between queue commands."""
    print("=" * 60)
    print("DEPENDENCY INFERENCE TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)
        _create_test_files(ev_path)
        _setup_env(ev_path, data_path)

        from evidence.tasks import REGISTRY, task

        @task('extract_meta')
        def extract_meta(file_path):
            return {'info': 'test'}

        @task('analyze_meta')
        def analyze_meta(meta_info):
            return {'analysis': 'done'}

        from evidence.main import Evidence, Mode

        ev = Evidence(mode=Mode.SCAN)

        # scan() auto-queues 4 tasks
        from evidence.queue import read_manifest
        manifest = read_manifest(data_path)
        auto_count = len(manifest)

        # Queue a task that reads file__pathName (exists in DB), outputs 'meta'
        qid1 = ev.queue('extract_meta',
                         inputL=['file__pathName'],
                         outputL=['meta'])

        # Queue a task that reads meta__info (NOT in DB, produced by qid1)
        qid2 = ev.queue('analyze_meta',
                         inputL=['meta__info'],
                         outputL=['analysis'])

        manifest = read_manifest(data_path)
        entry1 = manifest[auto_count]      # extract_meta
        entry2 = manifest[auto_count + 1]  # analyze_meta

        # extract_meta should have no dependencies (file exists in DB)
        assert entry1['after'] == [], \
            f"{qid1} should have no deps, got {entry1['after']}"
        print(f"  ✓ {qid1} has no dependencies (input 'file' exists in DB)")

        # analyze_meta should depend on extract_meta (meta not in DB)
        assert qid1 in entry2['after'], \
            f"{qid2} should depend on {qid1}, got {entry2['after']}"
        print(f"  ✓ {qid2} depends on {qid1} (input 'meta' produced by {qid1})")

        del REGISTRY['extract_meta']
        del REGISTRY['analyze_meta']
        _cleanup_env()

    print()


# ─── 4. Queue Runner Tests ──────────────────────────────────────────

def test_queue_runner():
    """Test QueueRunner execution, result files, and silent load."""
    print("=" * 60)
    print("QUEUE RUNNER TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)
        _create_test_files(ev_path)
        _setup_env(ev_path, data_path)

        from evidence.tasks import REGISTRY, task

        @task('simple_test')
        def simple_test(file_path):
            return {'processed': True, 'path': str(file_path)}

        from evidence.main import Evidence, Mode

        ev = Evidence(mode=Mode.SCAN)
        n_files = len(ev)
        print(f"  ✓ SCAN found {n_files} files")

        # Queue the task
        qid = ev.queue('simple_test',
                        inputL=['file__pathName'],
                        outputL=['test_result'])
        print(f"  ✓ Queued {qid}")

        # Run the queue
        from evidence.queue import QueueRunner
        runner = QueueRunner(data_path, workers=2)
        runner.run()

        # Check all manifest entries are done
        from evidence.queue import read_manifest
        manifest = read_manifest(data_path)
        for entry in manifest:
            assert entry['status'] == 'done', \
                f"Expected done for {entry['queue_id']}, got {entry['status']}"
        assert manifest[-1]['finished_at'] is not None
        print(f"  ✓ All {len(manifest)} queue commands marked as done")

        # Jobs and results should be cleaned up
        jobs_dir = data_path / 'queue' / 'jobs'
        results_dir = data_path / 'queue' / 'results'
        assert not jobs_dir.exists(), "jobs/ should be cleaned up"
        assert not results_dir.exists(), "results/ should be cleaned up"
        print("  ✓ Jobs and results cleaned up")

        # Manifest should still exist
        assert (data_path / 'queue' / 'manifest.json').exists()
        print("  ✓ Manifest preserved as log")

        # Reload Evidence and check results were merged
        for mod_name in list(sys.modules.keys()):
            if mod_name.startswith('evidence'):
                del sys.modules[mod_name]
        from evidence.main import Evidence as Ev2, Mode as Mode2

        ev2 = Ev2(mode=Mode2.LOAD)
        assert len(ev2) == n_files

        # Check that test_result was merged into at least one record
        has_result = False
        for d in ev2:
            if 'test_result' in d:
                has_result = True
                val = d['test_result']
                assert 'processed' in val, \
                    f"Expected 'processed' key, got: {val}"
                break
        assert has_result, \
            f"test_result should be merged. Keys in first record: {list(ev2[0].keys())}"
        print("  ✓ Results merged into database after silent load")

        del REGISTRY['simple_test']
        _cleanup_env()

    print()


# ─── 5. Resume After Crash Tests ────────────────────────────────────

def test_resume():
    """Test that the runner resumes correctly after simulated crash."""
    print("=" * 60)
    print("RESUME TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)
        _create_test_files(ev_path)
        _setup_env(ev_path, data_path)

        from evidence.tasks import REGISTRY, task

        @task('resume_test')
        def resume_test(file_path):
            return {'resumed': True}

        from evidence.main import Evidence, Mode

        ev = Evidence(mode=Mode.SCAN)
        ev.queue('resume_test',
                 inputL=['file__pathName'],
                 outputL=['resume_data'])

        # Simulate crash: set some jobs to 'running'
        jobs_dir = data_path / 'queue' / 'jobs'
        job_files = sorted(jobs_dir.glob('*.json'))
        assert len(job_files) > 0

        # Mark first job as 'running' (simulating mid-execution crash)
        job = json.loads(job_files[0].read_text())
        job['status'] = 'running'
        job['started_at'] = '2026-02-19 22:00:00'
        job_files[0].write_text(json.dumps(job))

        # Runner should reset running→pending and process all
        from evidence.queue import QueueRunner
        runner = QueueRunner(data_path, workers=1)
        runner.run()

        from evidence.queue import read_manifest
        manifest = read_manifest(data_path)
        assert manifest[0]['status'] == 'done'
        print("  ✓ Runner recovered from simulated crash")

        del REGISTRY['resume_test']
        _cleanup_env()

    print()


# ─── 6. Status and Log Tests ────────────────────────────────────────

def test_status_and_log():
    """Test get_status and read_manifest for CLI display."""
    print("=" * 60)
    print("STATUS AND LOG TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)
        _create_test_files(ev_path)
        _setup_env(ev_path, data_path)

        from evidence.tasks import REGISTRY, task

        @task('status_test')
        def status_test(file_path):
            return {'ok': True}

        from evidence.main import Evidence, Mode

        ev = Evidence(mode=Mode.SCAN)
        ev.queue('status_test',
                 inputL=['file__pathName'],
                 outputL=['status_data'])

        # Check status before running (4 auto-queued + 1 manual)
        from evidence.queue import get_status
        st = get_status(data_path)
        total_pending = len(st['pending'])
        assert total_pending >= 1, f"Expected at least 1 pending, got {total_pending}"
        assert len(st['running']) == 0
        assert len(st['done']) == 0
        print(f"  ✓ Status shows {total_pending} pending commands")

        # Check job counts for the last (our manual) command
        entry = st['pending'][-1]
        counts = entry.get('job_counts', {})
        assert counts.get('pending', 0) == len(ev)
        print(f"  ✓ Job counts for {entry['queue_id']}: {counts['pending']} pending")

        # Run and check again
        from evidence.queue import QueueRunner
        runner = QueueRunner(data_path, workers=1)
        runner.run()

        from evidence.queue import read_manifest
        manifest = read_manifest(data_path)
        assert manifest[0]['status'] == 'done'
        assert manifest[0]['finished_at'] is not None
        print("  ✓ Log shows completed command with timestamp")

        del REGISTRY['status_test']
        _cleanup_env()

    print()


# ─── Run All ────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("\n🔍 Evidence Queue Test Suite\n")

    passed = 0
    failed = 0

    for test_fn in [
        test_task_registry,
        test_queue_creation,
        test_dependency_inference,
        test_queue_runner,
        test_resume,
        test_status_and_log,
    ]:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"\n  ✗ {test_fn.__name__} FAILED: {e}\n")
            import traceback
            traceback.print_exc()

    print("=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    sys.exit(1 if failed else 0)
