"""Full test script for Evidence package.

Tests:
1. Config module (EvidenceConfig, profiles, load_config)
2. Descriptors module (mtype)
3. Filename module
4. Main Evidence class (modes, scan, load, save)
"""

import os
import sys
import json
import shutil
import tempfile
from pathlib import Path

# ─── 1. Config Tests ────────────────────────────────────────────────

def test_config():
    """Test configuration management."""
    from evidence.config import EvidenceConfig, ConfigError, load_config

    print("=" * 60)
    print("CONFIG TESTS")
    print("=" * 60)

    # Use a temp config file
    with tempfile.NamedTemporaryFile(suffix='.toml', delete=False) as f:
        tmp_config = Path(f.name)

    try:
        config = EvidenceConfig(tmp_config)

        # Test: empty config
        profiles = config.list_profiles()
        assert profiles == [], f"Expected empty list, got {profiles}"
        print("  ✓ Empty config returns no profiles")

        # Test: add profile
        config.add_profile("test1", ["/tmp/ev1", "/tmp/ev2"], "/tmp/data1", "Test profile 1")
        profiles = config.list_profiles()
        assert "test1" in profiles, f"test1 not in {profiles}"
        print("  ✓ Add profile works")

        # Test: add second profile
        config.add_profile("test2", ["/tmp/ev3"], "/tmp/data2", "Test profile 2")
        profiles = config.list_profiles()
        assert len(profiles) == 2, f"Expected 2 profiles, got {len(profiles)}"
        print("  ✓ Multiple profiles work")

        # Test: get profile info
        info = config.get_profile_info("test1")
        assert info is not None
        assert info["evidence_paths"] == ["/tmp/ev1", "/tmp/ev2"]
        assert info["data_path"] == "/tmp/data1"
        assert info["description"] == "Test profile 1"
        print("  ✓ Get profile info works")

        # Test: select profile
        config.set_current_profile("test1")
        current = config.get_current_profile()
        assert current == "test1", f"Expected test1, got {current}"
        print("  ✓ Select profile works")

        # Test: switch profile
        config.set_current_profile("test2")
        current = config.get_current_profile()
        assert current == "test2", f"Expected test2, got {current}"
        print("  ✓ Switch profile works")

        # Test: remove profile
        config.remove_profile("test2")
        profiles = config.list_profiles()
        assert "test2" not in profiles
        assert len(profiles) == 1
        print("  ✓ Remove profile works")

        # Test: remove non-existent profile
        try:
            config.remove_profile("nonexistent")
            assert False, "Should have raised ConfigError"
        except ConfigError:
            print("  ✓ Remove non-existent profile raises ConfigError")

        # Test: load_config with no real dirs (should raise ConfigError)
        config.set_current_profile("test1")
        os.environ.pop('EVIDENCE_PROFILE', None)
        os.environ.pop('EVIDENCE_PATHS', None)
        os.environ.pop('EVIDENCE_DATA', None)

        # Monkey-patch to use our temp config
        original_init = EvidenceConfig.__init__
        def patched_init(self, config_file=None):
            original_init(self, tmp_config)
        EvidenceConfig.__init__ = patched_init

        try:
            load_config()
            assert False, "Should have raised ConfigError (dirs don't exist)"
        except ConfigError as e:
            assert "not found" in str(e)
            print("  ✓ load_config raises ConfigError for missing directories")
        finally:
            EvidenceConfig.__init__ = original_init

        # Test: load_config with env vars pointing to real dirs
        with tempfile.TemporaryDirectory() as ev_dir, \
             tempfile.TemporaryDirectory() as data_dir:
            os.environ['EVIDENCE_PROFILE'] = 'env_test'
            os.environ['EVIDENCE_PATHS'] = ev_dir
            os.environ['EVIDENCE_DATA'] = data_dir

            name, ev_paths, d_path = load_config()
            assert name == 'env_test'
            assert ev_paths == [Path(ev_dir)]
            assert d_path == Path(data_dir)
            print("  ✓ load_config from environment variables works")

            os.environ.pop('EVIDENCE_PROFILE')
            os.environ.pop('EVIDENCE_PATHS')
            os.environ.pop('EVIDENCE_DATA')

    finally:
        tmp_config.unlink(missing_ok=True)

    print()


# ─── 2. Descriptors Tests ───────────────────────────────────────────

def test_descriptors():
    """Test descriptor functions."""
    from evidence.descriptors import mtype, timeStamp

    print("=" * 60)
    print("DESCRIPTORS TESTS")
    print("=" * 60)

    # Test: timeStamp returns a string
    ts = timeStamp()
    assert isinstance(ts, str)
    assert len(ts) > 0
    print("  ✓ timeStamp returns valid string")

    # Test: mtype on a text file
    with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
        f.write(b"hello world")
        tmp_txt = f.name
    try:
        result = mtype(tmp_txt)
        assert isinstance(result, dict)
        assert 'ext' in result
        print(f"  ✓ mtype on .txt file: {result}")
    finally:
        os.unlink(tmp_txt)

    # Test: mtype on a JPEG file (with valid header bytes)
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as f:
        f.write(b'\xff\xd8\xff\xe0' + b'\x00' * 100)
        tmp_jpg = f.name
    try:
        result = mtype(tmp_jpg)
        assert isinstance(result, dict)
        assert result.get('type') == 'image'
        print(f"  ✓ mtype on .jpg file: {result}")
    finally:
        os.unlink(tmp_jpg)

    print()


# ─── 3. Filename Tests ──────────────────────────────────────────────

def test_filename():
    """Test Filename class."""
    from evidence.filename import Filename

    print("=" * 60)
    print("FILENAME TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)

        # Create a test file
        test_file = ev_path / "subdir" / "test.jpg"
        test_file.parent.mkdir(parents=True, exist_ok=True)
        test_file.write_text("fake image")

        # Test: full path
        fn = Filename(str(test_file), typ='full', db=False,
                     evidence_path=ev_path, data_path=data_path)
        assert fn.fullpath == test_file
        assert fn.typ == 'ev'  # should detect it's under EVIDENCE
        assert fn.evpath == Path("subdir/test.jpg")
        print(f"  ✓ Filename full path: {fn}")

        # Test: evidence-relative path
        fn2 = Filename("subdir/test.jpg", typ='ev', db=False,
                      evidence_path=ev_path, data_path=data_path)
        assert fn2.fullpath == test_file
        print(f"  ✓ Filename ev path: {fn2}")

        # Test: exists
        assert fn.exists()
        print("  ✓ Filename.exists() works")

        # Test: data_ext
        fn_ext = fn.data_ext('.json', mkdir=True)
        expected = data_path / "subdir" / "test.jpg.json"
        assert fn_ext.fullpath == expected
        print(f"  ✓ Filename.data_ext: {fn_ext}")

        # Test: xtras (no extras yet)
        xtras = fn.xtras()
        assert isinstance(xtras, list)
        print(f"  ✓ Filename.xtras: {xtras}")

        # Test: invalid path raises ValueError
        try:
            Filename("nonexistent_id", typ='db', db=False,
                    evidence_path=ev_path, data_path=data_path)
            assert False, "Should have raised ValueError"
        except ValueError:
            print("  ✓ Invalid db lookup raises ValueError")

        # Test: repr
        assert repr(fn2).startswith("Filename(")
        print(f"  ✓ Filename repr: {repr(fn2)}")

    print()


# ─── 4. Evidence Class Tests ────────────────────────────────────────

def test_evidence():
    """Test Evidence class with real temp directories."""
    print("=" * 60)
    print("EVIDENCE CLASS TESTS")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as ev_dir, \
         tempfile.TemporaryDirectory() as data_dir:

        ev_path = Path(ev_dir)
        data_path = Path(data_dir)

        # Create some test files
        (ev_path / "disk1").mkdir()
        (ev_path / "disk1" / "photo1.jpg").write_bytes(b'\xff\xd8\xff\xe0' + b'\x00' * 100)
        (ev_path / "disk1" / "photo2.jpg").write_bytes(b'\xff\xd8\xff\xe0' + b'\x00' * 100)
        (ev_path / "disk1" / "doc.txt").write_text("hello")
        (ev_path / "disk2").mkdir()
        (ev_path / "disk2" / "video.mp4").write_bytes(b'\x00' * 100)

        # Set env vars so load_config works
        os.environ['EVIDENCE_PROFILE'] = 'test_run'
        os.environ['EVIDENCE_PATHS'] = str(ev_path)
        os.environ['EVIDENCE_DATA'] = str(data_path)

        # Need to reload main module since it reads config at import time
        # Remove cached module to force re-import with new env
        for mod_name in list(sys.modules.keys()):
            if mod_name.startswith('evidence'):
                del sys.modules[mod_name]

        from evidence.main import Evidence, Mode

        # Test: SCAN mode
        print("\n  --- SCAN mode ---")
        ev = Evidence(mode=Mode.SCAN)
        assert len(ev) > 0, "SCAN should find files"
        print(f"  ✓ SCAN found {len(ev)} files")

        # Test: database directory created
        db_path = data_path / 'database'
        assert db_path.exists(), "database dir should exist"
        assert (db_path / 'files.json').exists(), "files.json should exist"
        print("  ✓ Database directory and files.json created")

        # Test: LOAD mode
        print("\n  --- LOAD mode ---")
        ev2 = Evidence(mode=Mode.LOAD)
        assert len(ev2) == len(ev), f"LOAD should have same count: {len(ev2)} vs {len(ev)}"
        print(f"  ✓ LOAD recovered {len(ev2)} files")

        # Test: idf
        item = ev2.idf('1')
        assert item is not None, "idf('1') should return an item"
        assert 'file' in item
        print(f"  ✓ idf('1') = {item['id']}")

        # Test: ZERO mode
        print("\n  --- ZERO mode ---")
        ev3 = Evidence(mode=Mode.ZERO)
        assert len(ev3) == 0, "ZERO should be empty"
        print("  ✓ ZERO mode creates empty evidence")

        # Test: re-SCAN after ZERO
        print("\n  --- Re-SCAN ---")
        ev4 = Evidence(mode=Mode.SCAN)
        assert len(ev4) > 0
        print(f"  ✓ Re-SCAN found {len(ev4)} files")

        # Cleanup env
        os.environ.pop('EVIDENCE_PROFILE')
        os.environ.pop('EVIDENCE_PATHS')
        os.environ.pop('EVIDENCE_DATA')

    print()


# ─── Run All ────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("\n🔍 Evidence Package Test Suite\n")

    passed = 0
    failed = 0

    for test_fn in [test_config, test_descriptors, test_filename, test_evidence]:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"\n  ✗ {test_fn.__name__} FAILED: {e}\n")
            import traceback
            traceback.print_exc()

    print("=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    sys.exit(1 if failed else 0)
