"""Tests for the v0.4.0 library-mutation surface.

Covers the unified ``update_prompt`` method and the admin-only helpers
(share / unshare / groups / transfer / activate) with query-param payloads
that match the real backend contract.
"""

from __future__ import annotations

import json
from urllib.parse import parse_qs, urlparse

import pytest
import responses

from ptm_client import (
    PTMClient,
    PTMConflictError,
    PTMError,
    PTMNotFoundError,
    PTMPermissionError,
    PTMValidationError,
)

BASE = "http://ptm.test"
TOKEN = "ptm_u_testtoken"


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> PTMClient:
    for k in ("CF_ACCESS_CLIENT_ID", "CF_ACCESS_CLIENT_SECRET", "CF_ACCESS_JWT"):
        monkeypatch.delenv(k, raising=False)
    return PTMClient(BASE, TOKEN)


def _body(index: int = 0) -> dict:
    return json.loads(responses.calls[index].request.body)


def _query(index: int = 0) -> dict[str, list[str]]:
    return parse_qs(urlparse(responses.calls[index].request.url).query)


# --- update_prompt --------------------------------------------------------


@responses.activate
def test_update_prompt_sends_only_non_none_fields(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={"prompt_id": "team.p1", "updated": ["team", "tags"]},
    )
    client.update_prompt(
        "team.p1",
        change_summary="retag for 2026",
        team="platform",
        tags=["infra", "runtime"],
        # left unchanged: name, service, description, prompt_text, tests, etc.
    )
    body = _body()
    assert body == {
        "change_summary": "retag for 2026",
        "team": "platform",
        "tags": ["infra", "runtime"],
    }


@responses.activate
def test_update_prompt_empty_list_clears(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={"prompt_id": "team.p1"},
    )
    client.update_prompt(
        "team.p1",
        change_summary="nuke tests",
        tests=[],
        tags=[],
    )
    body = _body()
    assert body["tests"] == []
    assert body["tags"] == []
    assert body["change_summary"] == "nuke tests"


@responses.activate
def test_update_prompt_full_content_replace(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={"prompt_id": "team.p1", "version_number": 5},
    )
    client.update_prompt(
        "team.p1",
        change_summary="rewrite for gpt54",
        prompt_text="You are {{role}}. Say hi to {{name}}.",
        tests=[{"description": "t1", "vars": {"role": "helper", "name": "a"}}],
        deepeval_metrics=[{"name": "answer_relevancy", "threshold": 0.7}],
        kpis=[{"name": "latency", "weight": 0.5}],
        provider_profiles=["openai_gpt54_mini"],
        judge_profile="openai_gpt41_mini",
    )
    body = _body()
    assert body["prompt_text"].startswith("You are")
    assert body["tests"][0]["description"] == "t1"
    assert body["deepeval_metrics"][0]["threshold"] == 0.7
    assert body["kpis"] == [{"name": "latency", "weight": 0.5}]
    assert body["provider_profiles"] == ["openai_gpt54_mini"]
    assert body["judge_profile"] == "openai_gpt41_mini"


@responses.activate
def test_update_prompt_set_active_false_adds_query(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={},
        match_querystring=False,
    )
    client.update_prompt(
        "team.p1",
        change_summary="preview",
        prompt_text="preview",
        set_active=False,
    )
    assert _query()["set_active"] == ["false"]


@responses.activate
def test_update_prompt_403_raises_permission_error(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/other.p",
        json={"detail": "Not the owner"},
        status=403,
    )
    with pytest.raises(PTMPermissionError) as exc_info:
        client.update_prompt("other.p", change_summary="x", team="z")
    assert exc_info.value.status_code == 403


@responses.activate
def test_update_prompt_404_raises_not_found(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/missing.p",
        json={"detail": "not found"},
        status=404,
    )
    with pytest.raises(PTMNotFoundError):
        client.update_prompt("missing.p", change_summary="x", description="z")


@responses.activate
def test_update_prompt_409_raises_conflict(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/repo.backed.p",
        json={"detail": "repository-backed"},
        status=409,
    )
    with pytest.raises(PTMConflictError) as exc_info:
        client.update_prompt("repo.backed.p", change_summary="x", prompt_text="y")
    assert "repository-backed" in str(exc_info.value) or "conflict" in str(exc_info.value).lower()


@responses.activate
def test_update_prompt_422_raises_validation(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={"detail": [{"loc": ["body", "prompt_text"], "msg": "too long"}]},
        status=422,
    )
    with pytest.raises(PTMValidationError) as exc_info:
        client.update_prompt("team.p1", change_summary="oversize", prompt_text="x")
    assert "Validation" in str(exc_info.value) or "validation" in str(exc_info.value)


@responses.activate
def test_error_subclasses_still_catch_as_ptm_error(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1",
        json={"detail": "x"},
        status=409,
    )
    with pytest.raises(PTMError):
        client.update_prompt("team.p1", change_summary="y", prompt_text="z")


# --- activate_prompt_version ----------------------------------------------


@responses.activate
def test_activate_prompt_version_puts_to_activate_path(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1/versions/3/activate",
        json={"prompt_id": "team.p1", "active_version": 3},
    )
    result = client.activate_prompt_version("team.p1", 3)
    assert result["active_version"] == 3
    body = _body()
    assert body == {}


@responses.activate
def test_activate_prompt_version_coerces_str_to_int(client: PTMClient) -> None:
    responses.add(
        responses.PUT,
        f"{BASE}/api/v1/prompts/team.p1/versions/7/activate",
        json={"active_version": 7},
    )
    client.activate_prompt_version("team.p1", "7")  # type: ignore[arg-type]
    # If path didn't match due to coercion, responses would have 404'd.


# --- admin-only helpers (query-string payloads) ---------------------------


@responses.activate
def test_share_prompt_no_body(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/share",
        json={"prompt_id": "team.p1", "moved_to": "default"},
    )
    client.share_prompt("team.p1")
    assert _body() == {}


@responses.activate
def test_unshare_prompt_uses_query_param(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/unshare",
        json={"prompt_id": "team.p1"},
        match_querystring=False,
    )
    client.unshare_prompt("team.p1", "grp-abc")
    assert _query()["group_id"] == ["grp-abc"]
    assert _body() == {}


@responses.activate
def test_add_prompt_to_group_query_params(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/groups",
        json={"prompt_id": "team.p1", "groups": ["grp-x"]},
        match_querystring=False,
    )
    client.add_prompt_to_group("team.p1", "grp-x", editable=True)
    q = _query()
    assert q["group_id"] == ["grp-x"]
    assert q["editable"] == ["true"]


@responses.activate
def test_add_prompt_to_group_default_editable_false(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/groups",
        json={},
        match_querystring=False,
    )
    client.add_prompt_to_group("team.p1", "grp-y")
    assert _query()["editable"] == ["false"]


@responses.activate
def test_remove_prompt_from_group_path_params(client: PTMClient) -> None:
    responses.add(
        responses.DELETE,
        f"{BASE}/api/v1/prompts/team.p1/groups/grp-z",
        status=204,
    )
    assert client.remove_prompt_from_group("team.p1", "grp-z") is None


@responses.activate
def test_transfer_prompt_ownership_uses_query_param(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/transfer",
        json={"prompt_id": "team.p1", "owner_user_id": "usr-42"},
        match_querystring=False,
    )
    client.transfer_prompt_ownership("team.p1", "usr-42")
    # Must send new_owner_id (not the old body key new_owner_user_id).
    q = _query()
    assert q["new_owner_id"] == ["usr-42"]
    assert _body() == {}


@responses.activate
def test_transfer_prompt_403_surfaces_actionable_error(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/transfer",
        json={"detail": "admin role required"},
        status=403,
        match_querystring=False,
    )
    with pytest.raises(PTMPermissionError) as exc_info:
        client.transfer_prompt_ownership("team.p1", "usr-42")
    # Message should mention ownership / admin.
    msg = str(exc_info.value)
    assert "admin" in msg.lower() or "own" in msg.lower()


@responses.activate
def test_url_encodes_group_id_with_special_chars(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/prompts/team.p1/unshare",
        json={},
        match_querystring=False,
    )
    client.unshare_prompt("team.p1", "grp with spaces")
    assert _query()["group_id"] == ["grp with spaces"]
