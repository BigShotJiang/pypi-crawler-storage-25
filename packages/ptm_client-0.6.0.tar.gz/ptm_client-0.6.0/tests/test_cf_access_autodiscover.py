"""Tests for Cloudflare Access auto-discovery + graceful non-JSON handling (v0.3.2)."""

from __future__ import annotations

import subprocess
from unittest.mock import patch

import pytest
import responses

from ptm_client import (
    CloudflareAccessError,
    PTMClient,
    PTMResponseError,
)

BASE = "http://ptm.test"
TOKEN = "ptm_u_testtoken"


@pytest.fixture
def clean_cf_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensure no explicit CF env vars leak between tests."""
    for key in (
        "CF_ACCESS_CLIENT_ID",
        "CF_ACCESS_CLIENT_SECRET",
        "CF_ACCESS_JWT",
        "PTM_CF_AUTO_DISCOVER",
    ):
        monkeypatch.delenv(key, raising=False)


# 1. Non-CF deployment: no cf-ray header, normal behavior, no cloudflared.


@responses.activate
def test_non_cf_deployment_no_auto_discover(clean_cf_env: None) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        json={"prompts": [{"prompt_id": "foo"}]},
    )
    with patch("ptm_client.client.shutil.which") as which_mock:
        which_mock.return_value = None  # cloudflared "absent"
        c = PTMClient(BASE, TOKEN)
        result = c.list_prompts()
    assert result == [{"prompt_id": "foo"}]
    which_mock.assert_not_called()  # detector never fired; no lookup


# 2. CF challenge + cloudflared absent -> actionable error.


@responses.activate
def test_cf_block_without_cloudflared_raises(clean_cf_env: None) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="Please authenticate via the warp client",
        status=302,
        headers={
            "cf-ray": "9ef99aadaa16d93b-SAN",
            "location": "https://15five.cloudflareaccess.com/cdn-cgi/access/login/ptm.test",
            "www-authenticate": "Cloudflare-Access",
        },
        content_type="text/plain; charset=utf-8",
    )
    with patch("ptm_client.client.shutil.which", return_value=None):
        c = PTMClient(BASE, TOKEN)
        with pytest.raises(CloudflareAccessError) as exc_info:
            c.list_prompts()
    msg = str(exc_info.value)
    assert "brew install cloudflared" in msg
    assert BASE in msg


# 3. CF challenge + cloudflared present but no cached session.


@responses.activate
def test_cf_block_cloudflared_no_session_raises(clean_cf_env: None) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="challenge",
        status=302,
        headers={
            "cf-ray": "ray",
            "location": "https://foo.cloudflareaccess.com/login",
        },
        content_type="text/html",
    )
    fake_run = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    with patch("ptm_client.client.shutil.which", return_value="/usr/local/bin/cloudflared"):
        with patch("ptm_client.client.subprocess.run", return_value=fake_run):
            c = PTMClient(BASE, TOKEN)
            with pytest.raises(CloudflareAccessError) as exc_info:
                c.list_prompts()
    msg = str(exc_info.value)
    assert "cloudflared access login" in msg
    assert BASE in msg


# 4. CF challenge + cloudflared returns valid JWT -> retry succeeds.


@responses.activate
def test_cf_block_cloudflared_returns_jwt_retries(clean_cf_env: None) -> None:
    # First response: CF block.
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="blocked",
        status=302,
        headers={"cf-ray": "ray", "www-authenticate": "Cloudflare-Access"},
        content_type="text/html",
    )
    # Second response: success after JWT injection.
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        json={"prompts": [{"prompt_id": "p1"}]},
    )
    fake_run = subprocess.CompletedProcess(
        args=[], returncode=0, stdout="eyJhbGc-real-jwt\n", stderr=""
    )
    with patch("ptm_client.client.shutil.which", return_value="/usr/local/bin/cloudflared"):
        with patch("ptm_client.client.subprocess.run", return_value=fake_run) as run_mock:
            c = PTMClient(BASE, TOKEN)
            result = c.list_prompts()
    assert result == [{"prompt_id": "p1"}]
    assert len(responses.calls) == 2
    # JWT header should appear on the retry call.
    retry_headers = responses.calls[1].request.headers
    assert retry_headers["CF-Access-Jwt-Assertion"] == "eyJhbGc-real-jwt"
    # cloudflared invoked exactly once with app=BASE
    run_mock.assert_called_once()
    args = run_mock.call_args.args[0]
    assert args == ["cloudflared", "access", "token", f"-app={BASE}"]
    # Cached JWT is now on the client.
    assert c._cached_cf_jwt == "eyJhbGc-real-jwt"


# 5. Cached JWT gets cleared + refreshed on a second CF block.


@responses.activate
def test_cf_cached_jwt_refreshed_on_second_block(clean_cf_env: None) -> None:
    # Seed: first request -> block -> cloudflared -> jwt-A -> retry succeeds.
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="blocked",
        status=302,
        headers={"cf-ray": "r", "www-authenticate": "Cloudflare-Access"},
        content_type="text/html",
    )
    responses.add(responses.GET, f"{BASE}/api/v1/prompts", json={"prompts": []})
    # Second logical request (list_runs): block again with stale JWT -> refresh -> jwt-B.
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs",
        body="blocked",
        status=302,
        headers={"cf-ray": "r", "www-authenticate": "Cloudflare-Access"},
        content_type="text/html",
    )
    responses.add(responses.GET, f"{BASE}/api/v1/runs", json={"runs": [], "total_active_count": 0})
    tokens = iter(["jwt-A\n", "jwt-B\n"])

    def fake_run(*_args, **_kwargs):
        return subprocess.CompletedProcess(args=[], returncode=0, stdout=next(tokens), stderr="")

    with patch("ptm_client.client.shutil.which", return_value="/usr/local/bin/cloudflared"):
        with patch("ptm_client.client.subprocess.run", side_effect=fake_run):
            c = PTMClient(BASE, TOKEN)
            c.list_prompts()
            assert c._cached_cf_jwt == "jwt-A"
            c.list_runs()
            assert c._cached_cf_jwt == "jwt-B"
    # Retry request on second call must carry the refreshed jwt-B, not jwt-A.
    assert responses.calls[3].request.headers["CF-Access-Jwt-Assertion"] == "jwt-B"


# 6. PTM_CF_AUTO_DISCOVER=false disables the shell-out path entirely.


@responses.activate
def test_cf_auto_discover_disabled_fails_fast(
    clean_cf_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("PTM_CF_AUTO_DISCOVER", "false")
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="blocked",
        status=302,
        headers={"cf-ray": "r", "www-authenticate": "Cloudflare-Access"},
        content_type="text/html",
    )
    with patch("ptm_client.client.shutil.which") as which_mock:
        with patch("ptm_client.client.subprocess.run") as run_mock:
            c = PTMClient(BASE, TOKEN)
            with pytest.raises(CloudflareAccessError, match="auto-discovery is disabled"):
                c.list_prompts()
    which_mock.assert_not_called()
    run_mock.assert_not_called()


# 7. Explicit CF_ACCESS_CLIENT_ID + SECRET: auto-discovery skipped (0.3.1 precedence preserved).


@responses.activate
def test_explicit_service_token_skips_auto_discover(
    clean_cf_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CF_ACCESS_CLIENT_ID", "cid")
    monkeypatch.setenv("CF_ACCESS_CLIENT_SECRET", "csec")
    # Simulate a still-failing request even with service-token headers (maybe wrong policy).
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="blocked",
        status=403,
        headers={"cf-ray": "r", "www-authenticate": "Cloudflare-Access"},
        content_type="text/html",
    )
    with patch("ptm_client.client.shutil.which") as which_mock:
        with patch("ptm_client.client.subprocess.run") as run_mock:
            c = PTMClient(BASE, TOKEN)
            with pytest.raises(CloudflareAccessError, match="auto-discovery is disabled"):
                c.list_prompts()
    # Service-token path wins; no cloudflared shell-out.
    which_mock.assert_not_called()
    run_mock.assert_not_called()
    # Request carried the service-token headers.
    headers = responses.calls[0].request.headers
    assert headers["CF-Access-Client-Id"] == "cid"
    assert headers["CF-Access-Client-Secret"] == "csec"


# 8. HTML response outside CF context raises PTMResponseError with body preview.


@responses.activate
def test_html_without_cf_raises_response_error(clean_cf_env: None) -> None:
    html_body = "<html><body>503 Service Unavailable</body></html>"
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body=html_body,
        status=200,
        content_type="text/html",
    )
    c = PTMClient(BASE, TOKEN)
    with pytest.raises(PTMResponseError) as exc_info:
        c.list_prompts()
    msg = str(exc_info.value)
    assert "Expected JSON" in msg
    assert "HTML" in msg


# 9. cf-access-aud / cf-access-domain alone are authoritative: CF-only,
# no origin emits them. Covers the cloud51 ptm-non-prod shape (2026-04-22):
# plain 401 text/html, cf-access-* only, no Location / WWW-Authenticate.


@responses.activate
def test_cf_block_detected_by_cf_access_aud_header_alone(clean_cf_env: None) -> None:
    """cf-access-aud alone counts as a CF challenge. Guards cloud51 non-redirect 401."""
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="<html>access denied</html>",
        status=401,
        headers={
            "cf-ray": "9f06b8e64c808a80-LAX",
            "cf-access-aud": ("9dc9cd775c82faf6314c86ab5dbed0cf7d6b8c096e1af4d81b87c59be6088fde"),
            "cf-access-domain": "ptm-api.i.cloud51.15five.com",
        },
        content_type="text/html",
    )
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        json={"prompts": [{"prompt_id": "p1"}]},
    )
    fake_run = subprocess.CompletedProcess(
        args=[], returncode=0, stdout="eyJhbGc-cloud51-jwt\n", stderr=""
    )
    with patch("ptm_client.client.shutil.which", return_value="/usr/local/bin/cloudflared"):
        with patch("ptm_client.client.subprocess.run", return_value=fake_run):
            c = PTMClient(BASE, TOKEN)
            result = c.list_prompts()
    assert result == [{"prompt_id": "p1"}]
    assert len(responses.calls) == 2
    retry_headers = responses.calls[1].request.headers
    assert retry_headers["CF-Access-Jwt-Assertion"] == "eyJhbGc-cloud51-jwt"


@responses.activate
def test_cf_block_detected_by_cf_access_domain_alone(clean_cf_env: None) -> None:
    """cf-access-domain alone is sufficient; CF may emit either header."""
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body="denied",
        status=403,
        headers={
            "cf-ray": "ray",
            "cf-access-domain": "ptm-api.i.cloud51.15five.com",
        },
        content_type="application/json",  # not html; still a CF challenge
    )
    with patch("ptm_client.client.shutil.which", return_value=None):
        c = PTMClient(BASE, TOKEN)
        with pytest.raises(CloudflareAccessError):
            c.list_prompts()


def test_is_cf_access_block_unit_cloud51_headers() -> None:
    """Unit check on cloud51's captured header set (WARP+session absent):
    no redirect, no WWW-Authenticate; cf-access-* is the only CF signal."""
    from unittest.mock import MagicMock

    from ptm_client.client import _is_cf_access_block

    resp = MagicMock()
    resp.status_code = 401
    resp.headers = {
        "date": "Wed, 22 Apr 2026 18:34:23 GMT",
        "content-type": "text/html",
        "referrer-policy": "same-origin",
        "cf-version": "20-068ebbc",
        "server": "cloudflare",
        "cf-ray": "9f06b8e64c808a80-LAX",
        "cf-access-aud": ("9dc9cd775c82faf6314c86ab5dbed0cf7d6b8c096e1af4d81b87c59be6088fde"),
        "cf-access-domain": "ptm-api.i.cloud51.15five.com",
        "cache-control": "private, max-age=0, no-store, no-cache, must-revalidate",
    }
    assert _is_cf_access_block(resp) is True
