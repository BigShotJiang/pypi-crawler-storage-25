"""
__init__.py

Handles Plotly visualizations for the RHEED mathematical simulations.
Operates completely distinctly from the numerical solvers.
Provides individual plot generation and a full 2x2 multi-axis dashboard.
"""

import os
from typing import Dict, Any, Literal

from PY_GROWTH.numpy.io import load_input_data, save_history_to_json

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
except ImportError:
    go = None
    make_subplots = None

def plot_layer_coverages(results: Dict[str, Any]) -> 'go.Figure':
    fig = go.Figure()
    time = results['time']
    coverage = results['coverage']
    num_layers = coverage.shape[1]
    
    for i in range(num_layers):
        fig.add_trace(go.Scatter(
            x=time, y=coverage[:, i], mode='lines+markers', 
            name=f'Layer {i+1}', 
            marker={"size": 3, "color": 'black'},
            line={"color": 'black', "width": 1.0, "dash": 'solid'}
        ))
        
    fig.update_layout(
        title="Layer Coverage over Time",
        xaxis_title="Time [t/\u03C4]", # \u03C4 is tau
        yaxis_title="Layer coverage \u03B8",
        template="plotly_white",
        hovermode="x unified"
    )
    return fig

def plot_intensity(results: Dict[str, Any]) -> 'go.Figure':
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=results['time'], y=results['intensity'], mode='lines',
        name='Intensity', line={"color": '#e63946', "width": 2}
    ))
    fig.update_layout(
        title="RHEED Intensity Oscillations",
        xaxis_title="Time [t/\u03C4]",
        yaxis_title="Diffracted Intensity",
        template="plotly_white",
        hovermode="x unified"
    )
    return fig

def plot_rms_roughness(results: Dict[str, Any]) -> 'go.Figure':
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=results['time'], y=results['rms_roughness'], mode='lines',
        name='RMS Roughness', line={"color": '#1d3557', "width": 2} # Nice blue
    ))
    fig.update_layout(
        title="Surface RMS Roughness",
        xaxis_title="Time [t/\u03C4]",
        yaxis_title="RMS roughness",
        template="plotly_white",
        hovermode="x unified"
    )
    return fig

def plot_final_coverage(results: Dict[str, Any]) -> 'go.Figure':
    """Generates a bar chart of the final deposited layer fractions."""
    fig = go.Figure()
    final_cov = results['coverage'][-1, :]
    layers = list(range(1, len(final_cov) + 1))
    
    fig.add_trace(go.Bar(
        x=layers, y=final_cov, 
        name='Final Coverage', 
        marker_color='#457b9d'
    ))
    fig.update_layout(
        title="Final Layer Deposited",
        xaxis_title="Layer deposited",
        yaxis_title="Layer coverage \u03B8",
        template="plotly_white",
        xaxis=dict(tickmode='linear', dtick=1)
    )
    return fig

def create_dashboard(results: Dict[str, Any], compute_engine: str = "Unknown") -> 'go.Figure':
    """Creates a comprehensive 2x2 subplot dashboard of all 4 key RHEED metrics."""
    if make_subplots is None:
        raise ImportError("Plotly is required for dashboard generation.")

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("(a) Layer Coverage", "(b) RHEED Intensity", 
                        "(c) RMS Roughness", "(d) Final Layer Deposited")
    )
    
    time = results['time']
    # (1,1) Layer Coverage
    coverage = results['coverage']
    num_layers = coverage.shape[1]
    for i in range(num_layers):
        fig.add_trace(
            go.Scatter(x=time, y=coverage[:, i], mode='lines+markers', 
                       marker={"size": 3, "color": 'black'},
                       line={"color": 'black', "width": 1.0}, showlegend=False),
            row=1, col=1
        )
        
    # (1,2) Intensity
    fig.add_trace(
        go.Scatter(x=time, y=results['intensity'], mode='lines', 
                   line={"color": '#e63946', "width": 2}, showlegend=False),
            row=1, col=2
    )
    
    # (2,1) RMS Roughness
    fig.add_trace(
        go.Scatter(x=time, y=results['rms_roughness'], mode='lines', 
                   line={"color": '#1d3557', "width": 2}, showlegend=False),
        row=2, col=1
    )
    
    # (2,2) Final Coverage
    final_cov = coverage[-1, :]
    layers = list(range(1, len(final_cov) + 1))
    fig.add_trace(
        go.Bar(x=layers, y=final_cov, marker_color='#457b9d', showlegend=False),
        row=2, col=2
    )
    
    model_name = results.get('model_type', '?')
    engine_str = compute_engine if compute_engine != "Unknown" else "Numeric"
    fig.update_layout(
        title_text=f"PY_GROWTH Dashboard ({engine_str} Engine - Model {model_name})",
        height=800, width=1100,
        template="plotly_white",
        showlegend=False
    )
    
    # Axes titles
    fig.update_xaxes(title_text="Time [t/τ]", row=1, col=1)
    fig.update_yaxes(title_text="Layer coverage", row=1, col=1)
    
    fig.update_xaxes(title_text="Time [t/τ]", row=1, col=2)
    fig.update_yaxes(title_text="Diffracted intensity", row=1, col=2)
    
    fig.update_xaxes(title_text="Time [t/τ]", row=2, col=1)
    fig.update_yaxes(title_text="RMS roughness", row=2, col=1)
    
    fig.update_xaxes(title_text="Layer deposited", row=2, col=2, tickmode='linear', dtick=2)
    fig.update_yaxes(title_text="Layer coverage", row=2, col=2)
    
    return fig

def run_and_plot_simulation(
    input_filepath: str = "D:/UMCS/Praca 2026 Andrzej/A C++ code for simulations of RHEED intensity oscillations within the kinematical approximation/inputData.dat",
    save_data: bool = False,
    save_plot: bool = False,
    output_dir: str = ".",
    compute_engine: Literal["NumPy", "Numba", "JAX"] = "NumPy"
) -> Dict[str, Any]:
    """
    Parses a target configuration file, runs a fresh mathematical simulation,
    and immediately displays the 2x2 dashboard of all results natively.
    """
    if go is None:
        raise ImportError("Plotly is required for visualization metrics. Please install it with: `pip install plotly`")

    # 1. Parse configuration parameters
    config = load_input_data(input_filepath)
    
    # 2. Select the compute engine dynamically
    engine = compute_engine.upper()
    if engine == "NUMPY":
        from PY_GROWTH.numpy.core import run_simulation
    elif engine == "NUMBA":
        from PY_GROWTH.numba.core import run_simulation
    elif engine == "JAX":
        from PY_GROWTH.jax.core import run_simulation
    else:
        raise ValueError(f"Unsupported compute_engine '{compute_engine}'. Choose 'NumPy', 'Numba', or 'JAX'.")

    # 3. Re-run mathematically separate simulation using the physics solvers
    results = run_simulation(
        model_type=config["model_type"],
        num_layers=config["num_layers"],
        t_max=config["t_max"],
        num_intervals=config["num_intervals"],
        an_kn=config["an_kn"],
        growth_rates=config["growth_rates"]
    )
    
    # 4. Check outputs and sequentially dump to disk if requested by notebook users
    if save_data:
        json_path = os.path.join(output_dir, f"simulation_results_{engine.lower()}.json")
        save_history_to_json(results, json_path)
        
    # 5. Generate the 2x2 multi-axis dashboard matching the textbook graphs
    dashboard = create_dashboard(results, compute_engine=compute_engine)
    
    if save_plot:
        plot_path = os.path.join(output_dir, f"intensity_dashboard_{engine.lower()}.html")
        dashboard.write_html(plot_path)
        
    # Triggers Jupyter's inline visual canvas
    dashboard.show()
    
    print(f"[{compute_engine} Engine] Math simulation completed in {results['execution_time_seconds']:.5f} seconds.\n")
    
    return results
