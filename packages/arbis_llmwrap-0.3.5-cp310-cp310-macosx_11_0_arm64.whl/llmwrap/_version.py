"""Package version; keep in sync with pyproject.toml when releasing."""
__version__ = "0.3.5"
