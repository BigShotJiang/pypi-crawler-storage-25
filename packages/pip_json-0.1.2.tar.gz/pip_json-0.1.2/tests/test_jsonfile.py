from __future__ import annotations

import json

from pip_json.jsonfile import find_requirements_file
from pip_json.jsonfile import lock_path
from pip_json.jsonfile import read_json
from pip_json.jsonfile import write_json


def test_find_requirements_file_in_current_dir(tmp_path):
    req = tmp_path / 'requirements.json'
    req.write_text('{"dependencies": {}}')
    result = find_requirements_file(tmp_path)
    assert result == req


def test_find_requirements_file_in_parent_dir(tmp_path):
    req = tmp_path / 'requirements.json'
    req.write_text('{"dependencies": {}}')
    subdir = tmp_path / 'subdir'
    subdir.mkdir()
    result = find_requirements_file(subdir)
    assert result == req


def test_find_requirements_file_creates_when_not_found(tmp_path):
    result = find_requirements_file(tmp_path)
    assert result == tmp_path / 'requirements.json'
    assert result.exists()
    data = json.loads(result.read_text())
    assert data == {'dependencies': {}}


def test_find_requirements_file_also_creates_lock_when_not_found(tmp_path):
    find_requirements_file(tmp_path)
    lock = tmp_path / 'requirements.lock.json'
    assert lock.exists()
    data = json.loads(lock.read_text())
    assert data == {'dependencies': {}}


def test_read_json(tmp_path):
    f = tmp_path / 'requirements.json'
    f.write_text('{"dependencies": {"requests": ">=2.0"}}')
    assert read_json(f) == {'dependencies': {'requests': '>=2.0'}}


def test_write_json(tmp_path):
    f = tmp_path / 'requirements.json'
    write_json(f, {'dependencies': {'requests': '>=2.0'}})
    data = json.loads(f.read_text())
    assert data == {'dependencies': {'requests': '>=2.0'}}


def test_write_json_uses_4_space_indent(tmp_path):
    f = tmp_path / 'requirements.json'
    write_json(f, {'dependencies': {'requests': '>=2.0'}})
    text = f.read_text()
    assert '    ' in text


def test_find_requirements_file_skips_directory_with_same_name(tmp_path):
    # Regression: a directory named requirements.json in an ancestor should
    # not be mistaken for the manifest file (IsADirectoryError in read_json).
    ancestor_dir = tmp_path / 'requirements.json'
    ancestor_dir.mkdir()
    subdir = ancestor_dir / 'myproject'
    subdir.mkdir()
    result = find_requirements_file(subdir)
    assert result.is_file()
    assert result == subdir / 'requirements.json'


def test_lock_path(tmp_path):
    req = tmp_path / 'requirements.json'
    assert lock_path(req) == tmp_path / 'requirements.lock.json'
