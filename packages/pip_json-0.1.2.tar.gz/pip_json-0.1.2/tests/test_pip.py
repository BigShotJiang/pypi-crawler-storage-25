from __future__ import annotations

import json
import sys
from unittest.mock import MagicMock
from unittest.mock import patch

import pytest

from pip_json.pip import pip_install
from pip_json.pip import pip_list


def _make_result(returncode=0, stdout='', stderr=''):
    result = MagicMock()
    result.returncode = returncode
    result.stdout = stdout
    result.stderr = stderr
    return result


def test_pip_install_calls_correct_command():
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = _make_result()
        pip_install(['requests>=2.0', 'flask'])
    args = mock_run.call_args[0][0]
    assert args[:3] == [sys.executable, '-m', 'pip']
    assert 'install' in args
    assert 'requests>=2.0' in args
    assert 'flask' in args


def test_pip_install_exits_on_failure():
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = _make_result(
            returncode=1, stderr='No matching distribution',
        )
        with pytest.raises(SystemExit) as exc_info:
            pip_install(['nonexistent-package-xyz'])
    assert exc_info.value.code == 1


def test_pip_list_returns_name_version_dict():
    packages = [
        {'name': 'requests', 'version': '2.32.5'},
        {'name': 'Flask', 'version': '3.1.0'},
    ]
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = _make_result(stdout=json.dumps(packages))
        result = pip_list()
    assert result['requests'] == '2.32.5'
    assert result['flask'] == '3.1.0'


def test_pip_list_canonicalizes_names():
    packages = [{'name': 'My-Package', 'version': '1.0.0'}]
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = _make_result(stdout=json.dumps(packages))
        result = pip_list()
    assert 'my-package' in result


def test_pip_list_raises_on_failure():
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = _make_result(returncode=1, stderr='error')
        with pytest.raises(RuntimeError):
            pip_list()
