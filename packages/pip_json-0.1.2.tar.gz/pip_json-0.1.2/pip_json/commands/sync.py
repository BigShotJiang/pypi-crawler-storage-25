from __future__ import annotations

from pathlib import Path

from packaging.utils import canonicalize_name

from pip_json.jsonfile import find_requirements_file
from pip_json.jsonfile import lock_path
from pip_json.jsonfile import read_json
from pip_json.jsonfile import write_json
from pip_json.pip import pip_install
from pip_json.pip import pip_list


def run() -> None:
    req_path = find_requirements_file(Path.cwd())
    req_data = read_json(req_path)
    deps: dict[str, str] = req_data.get('dependencies', {})

    specs = [
        (name + constraint) if constraint != '*' else name
        for name, constraint in deps.items()
    ]
    pip_install(specs)
    resolved = pip_list()

    lock_deps = {
        str(canonicalize_name(name)): resolved[str(canonicalize_name(name))]
        for name in deps
        if str(canonicalize_name(name)) in resolved
    }
    write_json(lock_path(req_path), {'dependencies': lock_deps})
