from __future__ import annotations

from pathlib import Path

from pip_json.jsonfile import find_lock_file
from pip_json.jsonfile import write_json
from pip_json.pip import pip_list


def run() -> None:
    resolved = pip_list()
    lock = find_lock_file(Path.cwd())
    write_json(lock, {'dependencies': resolved})
