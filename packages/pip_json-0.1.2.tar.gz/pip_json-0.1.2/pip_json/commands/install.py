from __future__ import annotations

import re
import sys
from pathlib import Path

from packaging.utils import canonicalize_name

from pip_json.jsonfile import find_requirements_file
from pip_json.jsonfile import lock_path
from pip_json.jsonfile import read_json
from pip_json.jsonfile import write_json
from pip_json.pip import pip_install
from pip_json.pip import pip_list

_SPEC_RE = re.compile(r'^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)(.*)')


def _parse_spec(spec: str) -> tuple[str, str]:
    """Return (canonical_name, constraint) from a pip spec string."""
    m = _SPEC_RE.match(spec)
    if not m:
        return str(canonicalize_name(spec)), '*'
    name = str(canonicalize_name(m.group(1)))
    constraint = m.group(3).strip() or '*'
    return name, constraint


def _is_path(arg: str) -> bool:
    return Path(arg).exists()


def run(args: list[str]) -> None:
    # Determine mode: all args are package specs, or all are paths (or no args)
    if args and all(not _is_path(a) for a in args):
        _install_named(args)
    else:
        _install_from_file(args)


def _install_named(specs: list[str]) -> None:
    parsed = [_parse_spec(s) for s in specs]
    pip_install(specs)
    resolved = pip_list()

    req_path = find_requirements_file(Path.cwd())
    req_data = read_json(req_path)

    for name, constraint in parsed:
        req_data['dependencies'][name] = constraint
    write_json(req_path, req_data)

    lock_deps = {
        str(canonicalize_name(name)): resolved[str(canonicalize_name(name))]
        for name in req_data['dependencies']
        if str(canonicalize_name(name)) in resolved
    }
    write_json(lock_path(req_path), {'dependencies': lock_deps})


def _install_from_file(args: list[str]) -> None:
    if args:
        start = Path(args[0]).resolve()
        if start.is_dir():
            req_path = start / 'requirements.json'
            if not req_path.exists():
                print(
                    f'No requirements.json found at {start}', file=sys.stderr,
                )
                sys.exit(1)
        elif start.is_file() and start.name == 'requirements.json':
            req_path = start
        else:
            print(
                f'Expected requirements.json, got: {args[0]}', file=sys.stderr,
            )
            sys.exit(1)
    else:
        req_path = find_requirements_file(Path.cwd())

    req_data = read_json(req_path)
    deps: dict[str, str] = req_data.get('dependencies', {})

    specs = [
        (name + constraint) if constraint != '*' else name
        for name, constraint in deps.items()
    ]
    pip_install(specs)
    resolved = pip_list()

    lock_deps = {
        str(canonicalize_name(name)): resolved[str(canonicalize_name(name))]
        for name in deps
        if str(canonicalize_name(name)) in resolved
    }
    write_json(lock_path(req_path), {'dependencies': lock_deps})
