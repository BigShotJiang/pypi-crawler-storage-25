from __future__ import annotations

import json
import subprocess
import sys

from packaging.utils import canonicalize_name


def pip_install(specs: list[str]) -> None:
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', *specs],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        sys.exit(result.returncode)


def pip_list() -> dict[str, str]:
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'list', '--format=json'],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    packages = json.loads(result.stdout)
    return {
        str(canonicalize_name(pkg['name'])): pkg['version']
        for pkg in packages
    }
