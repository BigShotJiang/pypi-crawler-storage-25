from __future__ import annotations

import json
from pathlib import Path
from typing import Any


REQUIREMENTS_FILE = 'requirements.json'
LOCK_FILE = 'requirements.lock.json'
_EMPTY: dict[str, Any] = {'dependencies': {}}


def find_requirements_file(start: Path) -> Path:
    current = start.resolve()
    while True:
        candidate = current / REQUIREMENTS_FILE
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            # Reached filesystem root — create in start dir
            req = start.resolve() / REQUIREMENTS_FILE
            write_json(req, _EMPTY)
            write_json(lock_path(req), _EMPTY)
            return req
        current = parent


def find_lock_file(start: Path) -> Path:
    current = start.resolve()
    while True:
        candidate = current / LOCK_FILE
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            lock = start.resolve() / LOCK_FILE
            write_json(lock, _EMPTY)
            return lock
        current = parent


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=4) + '\n')


def lock_path(req_path: Path) -> Path:
    return req_path.parent / LOCK_FILE
