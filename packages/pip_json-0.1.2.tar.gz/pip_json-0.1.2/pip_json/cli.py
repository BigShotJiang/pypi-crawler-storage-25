from __future__ import annotations

import sys


HELP_TEXT = """pip-json: manage pip dependencies via requirements.json

Usage:
  pip-json install [<path>]      Install from requirements.json
  pip-json install <pkg[constraint]>
                                 Install pkg(s) and save to requirements.json
  pip-json freeze                Capture environment to requirements.lock.json
  pip-json sync                  Install all deps from requirements.json
  pip-json help | -h | --help    Show this help
"""


def main() -> None:
    args = sys.argv[1:]
    if not args:
        print(HELP_TEXT)
        sys.exit(0)

    command, *rest = args

    if command in ('help', '-h', '--help'):
        print(HELP_TEXT)

    elif command == 'install':
        from pip_json.commands.install import run as install_run
        install_run(rest)

    elif command == 'freeze':
        from pip_json.commands.freeze import run as freeze_run
        freeze_run()

    elif command == 'sync':
        from pip_json.commands.sync import run as sync_run
        sync_run()

    else:
        print(f'Unknown command: {command}\n{HELP_TEXT}', file=sys.stderr)
        sys.exit(1)
