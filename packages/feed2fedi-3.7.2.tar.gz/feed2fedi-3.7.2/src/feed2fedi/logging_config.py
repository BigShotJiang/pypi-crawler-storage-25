"""Logging configuration loader for Feed2Fedi."""

import logging
import sys
from pathlib import Path
from typing import Any

import tomllib
from loguru import logger

_DEFAULT_CONFIG_PATH = Path("logging-config.toml")

# stdlib loggers that are too chatty at INFO
_QUIET_LOGGERS = ["httpx", "httpcore"]


class _InterceptHandler(logging.Handler):
    """Route stdlib logging records into loguru."""

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record via loguru.

        :param record: The stdlib LogRecord to forward.
        """
        try:
            level: str | int = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def _resolve_sink(sink: str) -> Any:
    """Resolve a sink string to the appropriate object.

    :param sink: Sink value from config ("sys.stdout", "sys.stderr", or a file path).
    :returns: sys.stdout, sys.stderr, or the original string for file paths.
    """
    if sink == "sys.stdout":
        return sys.stdout
    if sink == "sys.stderr":
        return sys.stderr
    return sink


def _resolve_colorize(value: Any) -> bool | None:
    """Normalise the colorize config value to what loguru expects.

    :param value: Raw value from TOML ("none", "true", "false", or a bool).
    :returns: True, False, or None.
    """
    if value is None or value in ("none", "null"):
        return None
    if value is True or value == "true":
        return True
    return False


def configure_logging(config_path: Path | None = None) -> None:
    """Configure loguru from a TOML config file.

    Reads ``[[handlers]]`` entries and passes each to ``logger.add()``.
    Falls back to stdout at INFO with a plain message format if no config
    file is found.

    :param config_path: Path to the logging config TOML. Defaults to
        ``./logging-config.toml`` in the current working directory.
    """
    logger.remove()

    resolved = config_path or _DEFAULT_CONFIG_PATH

    if resolved.exists():
        with resolved.open("rb") as fh:
            config = tomllib.load(fh)

        for handler in config.get("handlers", []):
            sink = _resolve_sink(handler["sink"])
            kwargs: dict[str, Any] = {
                "level": handler.get("level", "DEBUG"),
                "format": handler.get("format", "{message}"),
            }
            if "colorize" in handler:
                kwargs["colorize"] = _resolve_colorize(handler["colorize"])
            if "rotation" in handler:
                kwargs["rotation"] = handler["rotation"]
            if "retention" in handler:
                kwargs["retention"] = handler["retention"]
            logger.add(sink, **kwargs)
    else:
        logger.add(sys.stdout, level="INFO", format="{message}")

    # Bridge stdlib logging into loguru; suppress chatty third-party loggers
    logging.basicConfig(handlers=[_InterceptHandler()], level=0, force=True)
    for name in _QUIET_LOGGERS:
        logging.getLogger(name).setLevel(logging.WARNING)
