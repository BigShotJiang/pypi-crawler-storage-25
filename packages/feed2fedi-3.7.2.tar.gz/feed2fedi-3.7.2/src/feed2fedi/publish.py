"""Classes and methods needed to publish posts on a Fediverse instance."""

import asyncio
import calendar
import re
import tempfile
from datetime import datetime
from datetime import timedelta
from datetime import timezone
from pathlib import Path

import puremagic
import yt_dlp
import yt_dlp.utils
from feedparser import FeedParserDict
from httpx import AsyncClient
from loguru import logger
from longwei import APClient
from longwei import ClientError
from longwei import NetworkError
from longwei import RatelimitError
from longwei import Status
from stamina import retry

from feed2fedi.collect import FeedReader
from feed2fedi.collect import get_file
from feed2fedi.control import Actions
from feed2fedi.control import Configuration
from feed2fedi.control import FeedInfo
from feed2fedi.control import IgnoringLogger
from feed2fedi.control import PostRecorder
from feed2fedi.utils import parse_iso_duration


class Fediverse:
    """Helper class to publish posts on a fediverse instance from rss feed items."""

    def __init__(self, config: Configuration, post_recorder: PostRecorder) -> None:
        self.config = config
        self.post_recorder = post_recorder
        self.max_age: timedelta | None = None

    async def publish(
        self,
        items: list[FeedParserDict],
        feed: FeedInfo,
        post_limit: int | None,
        delay: timedelta | None,
        client: AsyncClient,
    ) -> int:
        """Publish posts to fediverse instance from content in the items list.

        :param post_limit: Optional; Number of statuses to post before returning
        :param items: Rss feed items to post
        :param feed: Section of config for current feed
        :param scheduled_at: datetime for when the statuses should be scheduled.
            None for immediate posting.
        :param client: httpx AsyncClient to use for posting to fedi instance.

        :returns int: Number of new statuses posted.
        """
        post_template = self._determine_post_template(feed_template=feed.post_template)
        fediverse = await self._connect_fediverse(client=client)

        max_size = fediverse.max_att_size

        if isinstance(feed.max_attachments, int):
            max_media = min(fediverse.max_attachments, feed.max_attachments)
        else:
            max_media = fediverse.max_attachments

        if feed.max_age:
            self.max_age = parse_iso_duration(feed.max_age)

        statuses_posted = 0

        for item in items:
            skip, sensitive, spoiler_text = await self._pre_publish_checks(item=item, feed=feed)
            if skip:
                continue

            try:
                status = Fediverse._determine_status(feed=feed, item=item, post_template=post_template)

                media_ids = await self._post_media(
                    fediverse=fediverse,
                    feed=feed,
                    item=item,
                    max_media=max_media,
                    max_size=max_size,
                    client=client,
                )
                logger.debug(f"Media IDs: {media_ids}")

                posted_status = await self._post_actual_status(
                    fediverse=fediverse,
                    media_ids=media_ids,
                    sensitive=sensitive,
                    spoiler_text=spoiler_text,
                    status=status,
                    delay=delay,
                )

                log_posted_status(posted_status=posted_status)

                await self.post_recorder.log_post(shared_url=item.link)

                statuses_posted += 1
                if post_limit and statuses_posted >= post_limit:
                    break
                elif feed.max_posts and statuses_posted >= feed.max_posts:
                    break

            except RatelimitError:
                reset = fediverse.ratelimit_reset
                seconds = (reset - datetime.now(timezone.utc)).total_seconds()
                logger.warning(
                    f"Rate limit hit — waiting until {reset:%Y-%m-%d %H:%M:%S %z} ({round(seconds)} seconds)"
                )
                await asyncio.sleep(delay=seconds)

            except (ClientError, KeyError) as error:
                logger.error(f"Encountered error: {error} — logging article to avoid repeat")
                await self.post_recorder.log_post(shared_url=item.link)
                continue

        return statuses_posted

    @staticmethod
    def _determine_status(feed: FeedInfo, item: FeedParserDict, post_template: str) -> str:
        """Build status from all info needed."""
        logger.debug(f"Feed prefix: {feed.prefix}")
        if feed.prefix:
            prefix = f"{feed.prefix} - "
        else:
            prefix = ""

        logger.debug(f"Item params: {item['params']}")
        # Convert literal \n to newlines before formatting
        template_with_newlines = post_template.replace("\\n", "\n")
        # Format conditional templates with [prefix]var[suffix] syntax
        formatted_template = Fediverse._format_conditional_template(template_with_newlines, item["params"])
        # Then apply standard formatting for any remaining variables
        status = prefix + formatted_template
        return status

    @staticmethod
    def _format_conditional_template(template: str, params: dict[str, str]) -> str:
        """Format template with conditional [prefix]var[suffix] syntax.

        Syntax: {[prefix]variable[suffix]}
        - prefix: shown before variable if variable is not empty
        - suffix: shown after variable if variable is not empty
        - Both prefix and suffix are optional
        - If variable is empty, nothing is shown (not even brackets)

        Examples:
        - {[Title: ]title} → "Title: ActualTitle" or ""
        - {[ / by]author} → " / by ActualAuthor" or ""
        - {author[ / by]} → "ActualAuthor / by" or ""
        - {[ by ]author[.]} → " by ActualAuthor." or ""

        :param template: Template string with conditional syntax
        :param params: Dictionary of template variables
        :return: Formatted string

        """
        # Pattern to match {[prefix]var[suffix]}, {var[suffix]}, and {[prefix]var}
        # \{(?:\[([^]]*)\])?(\w+)(?:\[([^]]*)\])?\}
        #  {   [prefix]?     var     [suffix]?   }
        pattern = r"\{(?:\[([^]]*)\])?(\w+)(?:\[([^]]*)\])?\}"

        def replace_match(match: re.Match) -> str:
            prefix = match.group(1) or ""
            var_name = match.group(2)
            suffix = match.group(3) or ""

            # Check if this is a conditional pattern (has prefix or suffix brackets)
            has_prefix_bracket = match.group(1) is not None
            has_suffix_bracket = match.group(3) is not None

            # Only process if it has at least one bracket (prefix or suffix)
            if not (has_prefix_bracket or has_suffix_bracket):
                # This is a standard {var} pattern, return as-is for str.format()
                return match.group(0)

            value = params.get(var_name, "")
            if value and value.strip():
                # Variable has non-empty value, include prefix + value + suffix
                return prefix + value + suffix
            else:
                # Variable is empty, show nothing
                return ""

        # Replace all conditional patterns
        result = re.sub(pattern, replace_match, template)

        # Format any remaining standard {var} patterns
        try:
            result = result.format(**params)
        except (KeyError, ValueError):
            # Some variables might not be in params, leave them as-is
            # ValueError can occur for malformed templates (e.g., unmatched braces)
            pass

        return result

    async def _pre_publish_checks(self, item: FeedParserDict, feed: FeedInfo) -> tuple[bool, bool, str | None]:
        """Check item before posting status."""
        skip = False
        sensitive = False
        spoiler_text: str | None = None

        if await self.post_recorder.duplicate_check(identifier=item.link):
            skip = True

        elif self._item_too_old(item=item):
            await self.post_recorder.log_post(shared_url=item.link)
            skip = True

        if not skip:
            skip, sensitive, spoiler_text = await self._apply_filters(feed, item)
            if skip:
                await self.post_recorder.log_post(shared_url=item.link)

        return skip, sensitive, spoiler_text

    @retry(on=NetworkError, attempts=3)
    async def _post_actual_status(  # noqa: PLR0913
        self,
        fediverse: APClient,
        media_ids: list[str] | None,
        sensitive: bool,
        spoiler_text: str | None,
        delay: timedelta | None,
        status: str,
    ) -> Status:
        """Post actual status. This has been refactored into its own method to be able to apply retry logic."""
        scheduled_at: datetime | None = None
        if delay:
            scheduled_at = datetime.now().astimezone() + delay

        logger.debug(
            f"Posting — status: {status!r}, visibility: {self.config.bot_post_visibility}, "
            f"media_ids: {media_ids}, sensitive: {sensitive}, "
            f"spoiler_text: {spoiler_text}, scheduled_at: {scheduled_at}"
        )
        posted_status = await fediverse.post_status(
            status=status,
            visibility=self.config.bot_post_visibility,
            media_ids=media_ids,
            sensitive=sensitive,
            spoiler_text=spoiler_text,
            scheduled_at=scheduled_at,
        )
        return posted_status

    async def _post_media(  # noqa: PLR0913
        self,
        fediverse: APClient,
        feed: FeedInfo,
        item: FeedParserDict,
        max_media: int,
        max_size: int,
        client: AsyncClient,
    ) -> list[str] | None:
        """Post media if configured to do so."""
        media_ids: list[str] | None = None
        if self.config.bot_post_media and max_media:
            media_ids = await Fediverse._post_video(
                fediverse=fediverse,
                item=item,
                post_videos=feed.post_videos,
                max_size=max_size,
            )

            if not media_ids:
                media_ids = await Fediverse._post_images(
                    fediverse=fediverse,
                    item=item,
                    max_images=max_media,
                    image_selector=self.config.bot_post_image_selector,
                    supported_mime_types=fediverse.supported_mime_types,
                    max_size=max_size,
                    client=client,
                )
        return media_ids

    def _item_too_old(self, item: FeedParserDict) -> bool:
        """Check if item is older than max_age."""
        if not self.max_age:
            return False

        logger.debug(f"Item dates — published: {item.get('published_parsed')}, updated: {item.get('updated_parsed')}")
        date_for_age = item.get("published_parsed")
        if date_for_age is None:
            date_for_age = item.get("updated_parsed")

        if date_for_age is None:
            # Neither published nor updated date has been supplied.
            # Since we are here we want to age check feed items and
            # since we don't have the information to determine the age
            # we return True to say it is likely too old and the
            # feed item should get skipped.
            return True

        timestamp = calendar.timegm(date_for_age)
        article_dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        age_of_article = datetime.now(timezone.utc) - article_dt
        logger.debug(f"Article age: {age_of_article}, max age: {self.max_age}")
        if self.max_age and age_of_article > self.max_age:
            return True

        return False

    @staticmethod
    async def _apply_filters(feed: FeedInfo, item: FeedParserDict) -> tuple[bool, bool, str | None]:
        """Apply filters to item."""
        filter_action_drop = False
        sensitive = False
        spoiler_text = None
        for item_filter in feed.filters:
            if item_filter.do_check(item):
                if item_filter.action == Actions.DROP:
                    filter_action_drop = True
                    break
                elif item_filter.action == Actions.SEARCH_REPLACE:
                    search = item_filter.action_params["search"]
                    replace = item_filter.action_params["replace"]
                    item["params"]["content_html"] = re.sub(search, replace, item["params"]["content_html"])
                    item["params"]["content_markdown"] = re.sub(search, replace, item["params"]["content_markdown"])
                    item["params"]["content_plaintext"] = re.sub(search, replace, item["params"]["content_plaintext"])
                elif item_filter.action == Actions.MARK_CW:
                    sensitive = True
                    spoiler_text = item_filter.action_params
        return filter_action_drop, sensitive, spoiler_text

    @staticmethod
    @retry(on=NetworkError, attempts=3)
    async def _post_video(
        fediverse: APClient,
        item: FeedParserDict,
        post_videos: bool,
        max_size: int,
    ) -> list[str]:
        """Post media to fediverse instance and return media ID.

        :param fediverse: ActivityPub api instance
        :param item: Feed item to load media from
        :param post_videos: Boolean indicating whether videos should be posted.
        :returns:
            List containing no, one  or multiple strings of the media id after upload
        """
        media_ids: list[str] = []
        filenames: list[str] = []

        if not post_videos:
            return media_ids

        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                filenames = await Fediverse._get_video(item, tmpdir=tmpdir)
            except yt_dlp.utils.DownloadError:
                # Skip and go to next processing type
                pass
            logger.debug(f"Downloaded video files: {filenames}")
            for filename in filenames:
                media_id = await Fediverse._upload_video_file(fediverse=fediverse, filename=filename, max_size=max_size)
                if media_id:
                    media_ids.append(media_id)

        return media_ids

    @staticmethod
    async def _upload_video_file(fediverse: APClient, filename: str, max_size: int) -> str | None:
        """Upload a single video file, clean it up, and return the media ID.

        :param fediverse: ActivityPub api instance
        :param filename: Path to the local video file.
        :param max_size: Maximum allowed file size in bytes.

        :returns:
            Media ID string on success, or None if skipped or no MIME type.

        """
        magic_info = puremagic.magic_file(filename=filename)
        mime_type = magic_info[0].mime_type
        file_stat = Path(filename).stat()
        logger.debug(f"Video file {filename}: size={file_stat.st_size}, max_size={max_size}")
        if file_stat.st_size > max_size:
            return None
        try:
            if mime_type:
                with Path(filename).open(mode="rb") as file:
                    media = await fediverse.post_media(file=file, mime_type=mime_type)
                return media.id
        except ClientError:
            raise
        finally:
            Path(filename).unlink()
        return None

    @staticmethod
    async def _get_video(item: FeedParserDict, tmpdir: str) -> list[str]:
        """Download videos."""
        filenames: list[str] = []
        ydl_opts = {
            "quiet": "true",
            "logger": IgnoringLogger(),
            "no_warnings": "true",
            "ignoreerrors": "true",
            "outtmpl": str(Path(tmpdir) / "%(id)s.%(ext)s"),
        }
        logger.debug(f"Extracting video from: {item.link}")
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(item.link, download=True)
            ydl_info = ydl.sanitize_info(info)
            logger.debug(f"yt-dlp info: {ydl_info}")
            if ydl_info and ydl_info.get("requested_downloads"):
                for dl in ydl_info.get("requested_downloads"):
                    if filename := dl.get("filepath"):
                        filenames.append(filename)
        return filenames

    @retry(on=NetworkError, attempts=3)
    async def _connect_fediverse(self, client: AsyncClient) -> APClient:
        fediverse = await APClient.create(
            instance=self.config.fedi_instance,
            client=client,
            access_token=self.config.fedi_access_token,
        )
        await fediverse.verify_credentials()

        return fediverse

    @staticmethod
    @retry(on=NetworkError, attempts=3)
    async def _post_images(  # noqa: PLR0913
        fediverse: APClient,
        item: FeedParserDict,
        image_selector: str,
        supported_mime_types: list[str],
        max_images: int,
        max_size: int,
        client: AsyncClient,
    ) -> list[str]:
        """Post media to fediverse instance and return media ID.

        :param fediverse: ActivityPub api instance
        :param item: Feed item to load media from
        :param max_images: number of images to post. Defaults to 1
        :param supported_mime_types:  List of strings representing mime types supported by the instance server
        :param client: Shared AsyncClient to use for image downloads.

        :returns:
            List containing no, one  or multiple strings of the media id after upload
        """
        logger.debug(f"Posting images: max_images={max_images}, max_size={max_size}")
        media_ids: list[str] = []
        media_urls = FeedReader.determine_image_url(item, image_selector)

        for url in media_urls:
            if len(media_ids) == max_images:
                break

            logger.debug(f"Processing image URL: {url}")
            with tempfile.TemporaryFile() as temp_image_file:
                mime_type = await get_file(
                    img_url=url, file=temp_image_file, supported_mime_types=supported_mime_types, client=client
                )
                temp_image_file.seek(0, 2)
                file_size = temp_image_file.tell()
                logger.debug(f"Image: mime={mime_type}, size={file_size} (max={max_size})")
                if mime_type and file_size <= max_size:
                    temp_image_file.seek(0)
                    media = await fediverse.post_media(
                        file=temp_image_file,
                        mime_type=mime_type,
                    )
                    logger.debug(f"Uploaded media: {media}")
                    if media.id is not None:
                        media_ids.append(media.id)

        return media_ids

    def _determine_post_template(self, feed_template: str | None) -> str:
        """Determine with post template to use."""
        post_template = self.config.bot_post_template
        if feed_template:
            post_template = feed_template

        return post_template


def log_posted_status(posted_status: Status) -> None:
    """Log what has been posted to the console."""
    if posted_status.content is not None:
        logger.info(f"Posted {posted_status.content} to Fediverse at\n{posted_status.url}")
    else:
        extra = posted_status.model_extra or {}
        logger.info(f"Scheduled {extra['params']['text']} to Fediverse for posting at\n{extra['scheduled_at']}")
