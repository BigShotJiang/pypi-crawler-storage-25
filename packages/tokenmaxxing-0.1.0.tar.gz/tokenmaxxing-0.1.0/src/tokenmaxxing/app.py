#!/usr/bin/env python3
"""Claude Session Monitor — menu bar app.

Sits in the menu bar (left of the clock) and shows a progress bar for your
Claude Code 5-hour session OR rolling 7-day usage. Click for details and
to switch which window the bar tracks.

Polls Anthropic's OAuth usage endpoint directly — same call Claude Code
uses internally. Authoritative numbers, zero tokens consumed per poll.

    GET https://api.anthropic.com/api/oauth/usage
    Authorization: Bearer <token from system keychain or ~/.claude/.credentials.json>
    anthropic-beta: oauth-2025-04-20

Install:
    pip install rumps
Run:
    python3 claude_limit_app.py
Detached:
    nohup python3 claude_limit_app.py >/dev/null 2>&1 &
"""

from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import rumps

try:
    from AppKit import (
        NSColor,
        NSMutableAttributedString,
        NSForegroundColorAttributeName,
    )
    _HAS_APPKIT = True
except ImportError:  # pragma: no cover
    _HAS_APPKIT = False

USAGE_URL = "https://api.anthropic.com/api/oauth/usage"
OAUTH_API_VERSION = "oauth-2025-04-20"
KEYCHAIN_SERVICE = "Claude Code-credentials"
CREDENTIALS_FILE = Path.home() / ".claude" / ".credentials.json"
DASHBOARD_URL = "https://claude.ai/settings/usage"
ENV_DASHBOARD_URL = "CLAUDE_DASHBOARD_URL"

# App UI
APP_NAME = "Claude"
LOADING_TEXT = "loading…"
TIMER_INTERVAL = 1

REFRESH_SECONDS = 300  # 5 min: OAuth usage endpoint has aggressive undocumented rate limits
REFRESH_MAX_BACKOFF = 1800  # Max backoff: 30 minutes
BACKOFF_EXP_CAP = 11  # 2^11 = 2048s, lets REFRESH_MAX_BACKOFF (1800s) become the binding cap
HTTP_TIMEOUT = 10
KEYCHAIN_TIMEOUT = 3
HTTP_STATUS_RATE_LIMITED = 429
HTTP_STATUS_UNAUTHORIZED = 401
BAR_WIDTH = 5

# Time units (seconds)
SECONDS_PER_DAY = 86400
SECONDS_PER_HOUR = 3600
SECONDS_PER_MINUTE = 60

# UI formatting
SEPARATOR = " · "
UNAVAILABLE = "—"
MARKER_SELECTED = "✓ "
MARKER_UNSELECTED = "  "
STATUS_RATE_LIMITED = " [rate limited]"
STATUS_STALE = " (stale)"
MENU_ICON = "◌ "

# Menu item labels
EXTRA_USAGE_LABEL = "Extra usage: "
PLAN_LABEL = "Plan: "
UPDATE_LABEL = "Updated: "

# View status strings
VIEW_UNAVAILABLE = "n/a"
NEVER_UPDATED = "never"
EXTRA_USAGE_OFF = "off"
EXTRA_USAGE_ENABLED = "enabled"

# Status emojis
EMOJI_UNKNOWN = "⚪"
EMOJI_OK = "🟢"
EMOJI_WARN = "🟡"
EMOJI_CRITICAL = "🔴"

# Color thresholds (utilization %)
WARN_PCT = 50.0   # green → yellow
CRIT_PCT = 80.0   # yellow → red

# Preference menu labels
PREF_LABEL_RESET_TIME = 'Show "resets at Fri 07:00"'
PREF_LABEL_ELAPSED_TIME = 'Show "resets in 4h10m"'
PREF_LABEL_HISTORY = "Show 7-day history"
PREF_LABEL_LAUNCH_AT_STARTUP = "Launch at login"

# LaunchAgent (auto-start at user login)
LAUNCH_AGENT_LABEL = "com.tokenmaxxing.app"
LAUNCH_AGENT_DIR = Path.home() / "Library" / "LaunchAgents"
LAUNCH_AGENT_FILE = LAUNCH_AGENT_DIR / f"{LAUNCH_AGENT_LABEL}.plist"
LAUNCH_AGENT_PLIST = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
{program_args}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>ProcessType</key>
    <string>Interactive</string>
    <key>StandardOutPath</key>
    <string>/tmp/tokenmaxxing.out</string>
    <key>StandardErrorPath</key>
    <string>/tmp/tokenmaxxing.err</string>
</dict>
</plist>
"""

# Time display labels
TIME_DISPLAY_RESETS = "resets at "
TIME_DISPLAY_IN = "in "
UPDATE_TIME_FORMAT = "%H:%M:%S"
DETAIL_ITEM_SPACER = "  "  # spacing between sections in detail list items

# Plan tier mappings
SUB_TYPE_MAP = {"pro": "Claude Pro", "max": "Claude Max", "free": "Free"}
RATE_LIMIT_TIER_MAP = {"tier1": "Tier 1", "tier2": "Tier 2", "tier3": "Tier 3", "tier4": "Tier 4"}

# (label, key in usage payload, default visible in detail list)
VIEWS = [
    ("Session (5h)", "five_hour"),
    ("Weekly (7d)", "seven_day"),
    ("Weekly Sonnet", "seven_day_sonnet"),
]
VIEW_LABEL = {key: label for label, key in VIEWS}
VIEW_PREFIX = {
    "five_hour": "Session ",
    "seven_day": "Weekly ",
    "seven_day_sonnet": "Weekly Sonnet ",
}
DEFAULT_VIEW = "five_hour"

# Per-user app data dir (history + launcher wrapper script)
APP_DATA_DIR = Path.home() / ".tokenmaxxing"
LAUNCHER_SCRIPT = APP_DATA_DIR / "tokenmaxxing"  # wrapper named "tokenmaxxing" so Login Items shows the friendly name

# History feature
HISTORY_DIR = APP_DATA_DIR
HISTORY_FILE = HISTORY_DIR / "history.json"
HISTORY_MAX_ENTRIES = 2000
HISTORY_DEDUPE_SECONDS = 300  # skip identical snapshot if <5min since last
HISTORY_BUCKETS = 7           # one per day for the 7-day sparkline
HISTORY_KEY_BY_VIEW = {
    "five_hour": "session_pct",
    "seven_day": "weekly_pct",
    "seven_day_sonnet": "weekly_sonnet_pct",
}
SPARK_CHARS = "▁▂▃▄▅▆▇█"
SPARK_GAP = " "
TREND_UP = "↑"
TREND_DOWN = "↓"
TREND_FLAT = "→"
TREND_THRESHOLD = 3.0  # pct points
HISTORY_LABEL = "7d: "
HISTORY_COLLECTING = "7d: collecting…"


def _load_history() -> list:
    """Read the on-disk history file. Returns [] on missing/corrupt file."""
    if not HISTORY_FILE.exists():
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return data[-HISTORY_MAX_ENTRIES:]
        print(f"history: {HISTORY_FILE} not a list; starting fresh", file=sys.stderr)
        return []
    except (OSError, json.JSONDecodeError) as e:
        print(f"history: load failed ({e}); starting fresh", file=sys.stderr)
        return []


def _save_history_atomic(entries: list) -> None:
    """Write entries to HISTORY_FILE atomically via tempfile + os.replace."""
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(HISTORY_DIR), prefix=".history.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(entries, f)
        os.replace(tmp_path, str(HISTORY_FILE))
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _launchagent_installed() -> bool:
    """True iff the LaunchAgent plist is on disk."""
    return LAUNCH_AGENT_FILE.exists()


def _resolve_python_invocation() -> list:
    """Build the python argv for launching tokenmaxxing.

    Adapts to how the app is currently being run:
      - installed via pip (`__package__` set):  python -m tokenmaxxing
      - standalone script:                      python /path/to/app.py
    """
    if __package__:
        return [sys.executable, "-m", "tokenmaxxing"]
    return [sys.executable, str(Path(__file__).resolve())]


def _write_launcher_script() -> Path:
    """Write a wrapper script literally named "tokenmaxxing" so
    System Settings → Login Items shows the friendly name instead of "python3.9"."""
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    quoted = " ".join(shlex.quote(a) for a in _resolve_python_invocation())
    LAUNCHER_SCRIPT.write_text(f"#!/bin/sh\nexec {quoted}\n", encoding="utf-8")
    LAUNCHER_SCRIPT.chmod(0o755)
    return LAUNCHER_SCRIPT


def _install_launchagent() -> None:
    """Write the LaunchAgent plist so tokenmaxxing starts on next login.

    We deliberately do NOT `launchctl load` here — that would spawn a duplicate
    instance immediately while the user already has one running. The plist is
    auto-loaded by launchd on next user login.
    """
    LAUNCH_AGENT_DIR.mkdir(parents=True, exist_ok=True)
    launcher = _write_launcher_script()
    program_args = f"        <string>{launcher}</string>"
    plist = LAUNCH_AGENT_PLIST.format(label=LAUNCH_AGENT_LABEL, program_args=program_args)
    LAUNCH_AGENT_FILE.write_text(plist, encoding="utf-8")


def _uninstall_launchagent() -> None:
    """Unload (if loaded) and delete the LaunchAgent plist."""
    if not LAUNCH_AGENT_FILE.exists():
        return
    try:
        subprocess.run(
            ["launchctl", "unload", str(LAUNCH_AGENT_FILE)],
            check=False, capture_output=True, timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        LAUNCH_AGENT_FILE.unlink()
    except OSError:
        pass


def _extract_pcts(payload: Optional[dict]):
    """Extract (session_pct, weekly_pct, weekly_sonnet_pct) from a usage payload."""
    def _pct(view):
        if isinstance(view, dict):
            v = view.get("utilization")
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    return None
        return None
    if not isinstance(payload, dict):
        return None, None, None
    return (_pct(payload.get("five_hour")),
            _pct(payload.get("seven_day")),
            _pct(payload.get("seven_day_sonnet")))


def _bucket_snapshots(snapshots: list, key: str, now_ts: int):
    """Return HISTORY_BUCKETS daily buckets ending at now_ts; each is a list of pct floats."""
    bucket_secs = SECONDS_PER_DAY
    cutoff = now_ts - HISTORY_BUCKETS * bucket_secs
    buckets = [[] for _ in range(HISTORY_BUCKETS)]
    for s in snapshots:
        ts = s.get("ts") if isinstance(s, dict) else None
        if not isinstance(ts, (int, float)) or ts < cutoff or ts > now_ts:
            continue
        idx = int((ts - cutoff) / bucket_secs)
        idx = max(0, min(HISTORY_BUCKETS - 1, idx))
        v = s.get(key)
        if v is None:
            continue
        try:
            buckets[idx].append(float(v))
        except (TypeError, ValueError):
            continue
    return buckets


def _render_sparkline(snapshots: list, key: str, now_ts: int) -> str:
    """Render last 7 daily buckets as a sparkline; trims leading empty buckets."""
    buckets = _bucket_snapshots(snapshots, key, now_ts)
    first_with_data = next((i for i, b in enumerate(buckets) if b), None)
    if first_with_data is None:
        return ""
    chars = []
    for b in buckets[first_with_data:]:
        if not b:
            chars.append(SPARK_GAP)
            continue
        avg = max(0.0, min(100.0, sum(b) / len(b)))
        idx = int(avg / 100.0 * (len(SPARK_CHARS) - 1) + 0.5)
        idx = max(0, min(len(SPARK_CHARS) - 1, idx))
        chars.append(SPARK_CHARS[idx])
    return "".join(chars)


def _compute_trend(snapshots: list, key: str, now_ts: int) -> str:
    """Compare avg of last 24h vs prior 24h. Returns ↑/↓/→, or '' if insufficient data."""
    last_start = now_ts - SECONDS_PER_DAY
    prior_start = now_ts - 2 * SECONDS_PER_DAY
    last_vals = []
    prior_vals = []
    for s in snapshots:
        if not isinstance(s, dict):
            continue
        ts = s.get("ts")
        v = s.get(key)
        if not isinstance(ts, (int, float)) or v is None:
            continue
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        if last_start <= ts <= now_ts:
            last_vals.append(v)
        elif prior_start <= ts < last_start:
            prior_vals.append(v)
    if not last_vals or not prior_vals:
        return ""
    delta = sum(last_vals) / len(last_vals) - sum(prior_vals) / len(prior_vals)
    if delta > TREND_THRESHOLD:
        return TREND_UP
    if delta < -TREND_THRESHOLD:
        return TREND_DOWN
    return TREND_FLAT


def _compute_min_max_avg(snapshots: list, key: str, now_ts: int):
    """Return (min, avg, max) over last 7 days, or (None, None, None) if no data."""
    cutoff = now_ts - HISTORY_BUCKETS * SECONDS_PER_DAY
    vals = []
    for s in snapshots:
        if not isinstance(s, dict):
            continue
        ts = s.get("ts")
        v = s.get(key)
        if not isinstance(ts, (int, float)) or v is None or ts < cutoff or ts > now_ts:
            continue
        try:
            vals.append(float(v))
        except (TypeError, ValueError):
            continue
    if not vals:
        return None, None, None
    return min(vals), sum(vals) / len(vals), max(vals)


def _get_oauth_data() -> Optional[dict]:
    """Read Claude Code's OAuth credentials from keychain or file. Returns the full claudeAiOauth dict."""
    user = os.environ.get("USER", "")
    try:
        out = subprocess.check_output(
            ["security", "find-generic-password",
             "-s", KEYCHAIN_SERVICE, "-a", user, "-w"],
            stderr=subprocess.DEVNULL,
            timeout=KEYCHAIN_TIMEOUT,
        )
        data = json.loads(out)
        oauth_data = data.get("claudeAiOauth")
        if oauth_data:
            return oauth_data
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired,
            json.JSONDecodeError):
        pass
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("claudeAiOauth")
        except (OSError, json.JSONDecodeError):
            return None
    return None


def get_access_token() -> Optional[str]:
    """Read Claude Code's OAuth access token. Keychain wins; file is fallback."""
    oauth_data = _get_oauth_data()
    return oauth_data.get("accessToken") if oauth_data else None


def fetch_usage(oauth_data: Optional[dict] = None):
    """Returns (payload_dict, error_str, is_rate_limited). One of payload/error is always None."""
    token = oauth_data.get("accessToken") if oauth_data else None
    if not token:
        return None, "no Claude Code token", False
    req = urllib.request.Request(
        USAGE_URL,
        headers={
            "Authorization": f"Bearer {token}",
            "anthropic-beta": OAUTH_API_VERSION,
            "User-Agent": "claude-limit-app/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8")), None, False
    except urllib.error.HTTPError as e:
        if e.code == HTTP_STATUS_RATE_LIMITED:
            return None, "rate limited — data is stale, retrying soon", True
        if e.code == HTTP_STATUS_UNAUTHORIZED:
            return None, "auth expired (run `claude` to refresh)", False
        return None, f"HTTP {e.code}", False
    except urllib.error.URLError as e:
        return None, f"net: {e.reason}", False
    except Exception as e:  # noqa: BLE001
        return None, str(e), False


def bar(pct: Optional[float], width: int = BAR_WIDTH) -> str:
    """Solid Unicode progress bar."""
    if pct is None:
        return "─" * width
    pct = max(0.0, min(100.0, float(pct)))
    full = int(round(pct / 100.0 * width))
    return "█" * full + "░" * (width - full)


def status_emoji(pct: Optional[float]) -> str:
    """Colored circle matching the title-bar tint."""
    if pct is None:
        return EMOJI_UNKNOWN
    if pct < WARN_PCT:
        return EMOJI_OK
    if pct < CRIT_PCT:
        return EMOJI_WARN
    return EMOJI_CRITICAL


def status_color(pct: Optional[float]):
    """NSColor for the menu-bar bar segment. Adapts to light/dark mode."""
    if not _HAS_APPKIT:
        return None
    if pct is None:
        return NSColor.labelColor()
    if pct < WARN_PCT:
        return NSColor.systemGreenColor()
    if pct < CRIT_PCT:
        return NSColor.systemYellowColor()
    return NSColor.systemRedColor()


def _utc_now() -> datetime:
    """Return current time in UTC timezone."""
    return datetime.now(timezone.utc)


def _parse_reset_time(reset_iso: Optional[str]) -> Optional[datetime]:
    """Parse ISO datetime string (with Z suffix) to timezone-aware datetime, or None."""
    if not reset_iso:
        return None
    try:
        dt = datetime.fromisoformat(reset_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, AttributeError):
        return None


def fmt_remaining(reset_iso: Optional[str]) -> str:
    reset = _parse_reset_time(reset_iso)
    if reset is None:
        return UNAVAILABLE
    secs = int((reset - _utc_now()).total_seconds())
    if secs <= 0:
        return "ready"
    d, secs = divmod(secs, SECONDS_PER_DAY)
    h, secs = divmod(secs, SECONDS_PER_HOUR)
    m = secs // SECONDS_PER_MINUTE
    if d:
        return f"{d}d{h}h"
    if h:
        return f"{h}h{m:02d}m"
    return f"{m}m"


def fmt_reset_clock(reset_iso: Optional[str]) -> str:
    reset = _parse_reset_time(reset_iso)
    if reset is None:
        return UNAVAILABLE
    if (reset - _utc_now()).total_seconds() <= 0:
        return "ready"
    return reset.astimezone().strftime("%a %H:%M")


def _calc_backoff(consecutive_failures: int) -> int:
    """Exponential backoff capped at REFRESH_MAX_BACKOFF (default 30 minutes)."""
    return min(2 ** min(consecutive_failures, BACKOFF_EXP_CAP), REFRESH_MAX_BACKOFF)


def _fmt_pct(pct: float) -> str:
    """Format percentage with no decimal places (e.g., '45%')."""
    return f"{pct:.0f}%"


def _fmt_credits(used: float, cap: float, currency: str) -> str:
    """Format credit display (e.g., '5.00/10.00 USD')."""
    if currency:
        return f"{used:.2f}/{cap:.2f} {currency}"
    return f"{used:.2f}/{cap:.2f}"


class ClaudeMonitorApp(rumps.App):
    def __init__(self):
        super().__init__(APP_NAME, title=f"{MENU_ICON}{APP_NAME}")

        self.current_view = DEFAULT_VIEW
        self.show_reset_time = True  # toggle between reset time vs elapsed time
        self.show_history = False    # opt-in: 7-day sparkline + min/avg/max rows
        self._latest = None         # last good payload
        self._latest_error = None   # last error string
        self._latest_at = None      # datetime of last good payload
        self._latest_plan = ""      # cached plan info (don't re-read on rate limit)
        self._is_rate_limited = False  # distinguish 429 from other errors
        self._pending = None        # (payload, error, is_rate_limited) staged from worker
        self._pending_lock = threading.Lock()
        self._wake = threading.Event()
        self._backoff_until = 0     # unix timestamp; worker won't poll until after this
        self._history_lock = threading.Lock()
        self._history = _load_history()

        # Detail rows: one per known view (clickable to switch)
        self._detail_items = {}
        for label, key in VIEWS:
            item = rumps.MenuItem(label, callback=self._make_switcher(key))
            self._detail_items[key] = item

        self.extra_item = rumps.MenuItem(f"{EXTRA_USAGE_LABEL}{UNAVAILABLE}")
        self.tier_item = rumps.MenuItem(f"{PLAN_LABEL}{UNAVAILABLE}")

        # Preference submenu for time display format + history toggle + autostart
        self.pref_reset = rumps.MenuItem(PREF_LABEL_RESET_TIME, callback=self._set_show_reset_time)
        self.pref_elapsed = rumps.MenuItem(PREF_LABEL_ELAPSED_TIME, callback=self._set_show_elapsed_time)
        self.pref_history = rumps.MenuItem(PREF_LABEL_HISTORY, callback=self._toggle_show_history)
        self.pref_launch = rumps.MenuItem(PREF_LABEL_LAUNCH_AT_STARTUP, callback=self._toggle_launch_at_startup)
        self.pref_reset.state = 1  # selected by default
        self.pref_history.state = 0  # off by default
        self.pref_launch.state = 1 if _launchagent_installed() else 0
        self._pref_menu = rumps.MenuItem("Preference")
        self._pref_menu.add(self.pref_reset)
        self._pref_menu.add(self.pref_elapsed)
        self._pref_menu.add(rumps.separator)
        self._pref_menu.add(self.pref_history)
        self._pref_menu.add(self.pref_launch)

        self.last_update_item = rumps.MenuItem(f"{UPDATE_LABEL}{UNAVAILABLE}")
        self.history_item = rumps.MenuItem(HISTORY_COLLECTING)
        self.stats_item = rumps.MenuItem(HISTORY_COLLECTING)
        self._dashboard_item = rumps.MenuItem("Open Claude dashboard…", callback=self._open_dashboard)
        self._refresh_item = rumps.MenuItem("Refresh now", callback=self._manual_refresh)

        self.menu = self._build_menu_items()

        self.title = f"{MENU_ICON}{LOADING_TEXT}"

        self._worker = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker.start()

        self._apply_timer = rumps.Timer(self._apply_pending, TIMER_INTERVAL)
        self._apply_timer.start()

    # ----- worker / dispatch -----

    def _worker_loop(self):
        consecutive_failures = 0
        while True:
            now = time.time()
            if now < self._backoff_until:
                self._wake.wait(timeout=min(REFRESH_SECONDS, self._backoff_until - now))
                self._wake.clear()
                continue

            oauth_data = _get_oauth_data()
            payload, err, is_rate_limited = fetch_usage(oauth_data)
            # Drop any Refresh-now clicks that arrived during the poll — the
            # in-flight poll already satisfies them, and re-polling immediately
            # can trip the OAuth endpoint's rate limit.
            self._wake.clear()
            with self._pending_lock:
                self._pending = (payload, err, is_rate_limited, oauth_data)

            if payload is not None:
                consecutive_failures = 0
                self._backoff_until = 0
                self._record_snapshot(payload)
            elif is_rate_limited:
                consecutive_failures += 1
                backoff = _calc_backoff(consecutive_failures)
                self._backoff_until = time.time() + backoff

            self._wake.wait(timeout=REFRESH_SECONDS)
            self._wake.clear()

    def _apply_pending(self, _sender):
        with self._pending_lock:
            staged = self._pending
            self._pending = None
        if staged is not None:
            payload, err, is_rate_limited, oauth_data = staged
            # Plan info comes from the keychain oauth_data, not the API
            # response — refresh it on every poll where we have keychain
            # data, even if the API fetch failed (e.g. 429 on first poll).
            if oauth_data:
                self._latest_plan = self._read_plan_info(oauth_data)
            if payload is not None:
                self._latest = payload
                self._latest_error = None
                self._is_rate_limited = False
                self._latest_at = _utc_now()
            else:
                self._latest_error = err
                self._is_rate_limited = is_rate_limited
        # Re-render every tick so elapsed-time displays ("in 5h10m") tick down
        # between polls instead of freezing for the full REFRESH_SECONDS interval.
        self._render()

    def _manual_refresh(self, _sender):
        self._wake.set()

    def _record_snapshot(self, payload):
        """Append a snapshot of the just-fetched payload, dedupe, persist atomically."""
        s, w, ws = _extract_pcts(payload)
        snapshot = {
            "ts": int(time.time()),
            "session_pct": s,
            "weekly_pct": w,
            "weekly_sonnet_pct": ws,
        }
        with self._history_lock:
            if self._history:
                last = self._history[-1] if isinstance(self._history[-1], dict) else {}
                last_ts = last.get("ts")
                if (last.get("session_pct") == s
                        and last.get("weekly_pct") == w
                        and last.get("weekly_sonnet_pct") == ws
                        and isinstance(last_ts, (int, float))
                        and snapshot["ts"] - int(last_ts) < HISTORY_DEDUPE_SECONDS):
                    return
            self._history.append(snapshot)
            if len(self._history) > HISTORY_MAX_ENTRIES:
                del self._history[:len(self._history) - HISTORY_MAX_ENTRIES]
            entries_to_save = list(self._history)
        try:
            _save_history_atomic(entries_to_save)
        except OSError as e:
            print(f"history: write failed: {e}", file=sys.stderr)

    # ----- view switching -----

    def _make_switcher(self, key):
        def _cb(_sender):
            self.current_view = key
            self._render()
        return _cb

    def _open_dashboard(self, _sender):
        url = os.environ.get(ENV_DASHBOARD_URL, DASHBOARD_URL)
        try:
            subprocess.Popen(["open", url])
        except OSError:
            pass

    def _set_show_reset_time(self, _sender):
        self.show_reset_time = True
        self._update_pref_states(True)
        self._render()

    def _set_show_elapsed_time(self, _sender):
        self.show_reset_time = False
        self._update_pref_states(False)
        self._render()

    def _update_pref_states(self, reset_selected: bool):
        """Update checkbox states for reset time / elapsed time preferences."""
        self.pref_reset.state = 1 if reset_selected else 0
        self.pref_elapsed.state = 0 if reset_selected else 1

    def _build_menu_items(self):
        """Build the menu list, conditionally including the 7-day history rows."""
        items = [
            self._detail_items["five_hour"],
            self._detail_items["seven_day"],
            self._detail_items["seven_day_sonnet"],
            None,
        ]
        if self.show_history:
            items.extend([self.history_item, self.stats_item, None])
        items.extend([
            self.tier_item,
            self.extra_item,
            None,
            self._pref_menu,
            self._dashboard_item,
            None,
            self.last_update_item,
            self._refresh_item,
        ])
        return items

    def _toggle_show_history(self, _sender):
        self.show_history = not self.show_history
        self.pref_history.state = 1 if self.show_history else 0
        self.menu.clear()
        for item in self._build_menu_items():
            self.menu.add(rumps.separator if item is None else item)
        self._render()

    def _toggle_launch_at_startup(self, _sender):
        if _launchagent_installed():
            _uninstall_launchagent()
            msg = "tokenmaxxing will no longer start automatically on login."
        else:
            _install_launchagent()
            msg = "tokenmaxxing will start automatically on next login."
        self.pref_launch.state = 1 if _launchagent_installed() else 0
        # Notification is best-effort: fails silently in unbundled apps
        try:
            rumps.notification("tokenmaxxing", "Launch at login", msg)
        except Exception:  # noqa: BLE001
            pass

    # ----- rendering -----

    def _get_time_value(self, resets_at: Optional[str]) -> str:
        """Format time display based on preference: reset time or remaining time."""
        if self.show_reset_time:
            return fmt_reset_clock(resets_at)
        return fmt_remaining(resets_at)

    def _fmt_time_display(self, resets_at: Optional[str]) -> str:
        """Format time display with prefix: 'resets at HH:MM' or 'in Xh Xm'."""
        time_value = self._get_time_value(resets_at)
        if time_value in (UNAVAILABLE, "ready"):
            return time_value
        if self.show_reset_time:
            return f"{TIME_DISPLAY_RESETS}{time_value}"
        return f"{TIME_DISPLAY_IN}{time_value}"

    def _fmt_update_time(self) -> str:
        """Format the last update timestamp or unavailable marker."""
        if self._latest_at:
            return self._latest_at.astimezone().strftime(UPDATE_TIME_FORMAT)
        return UNAVAILABLE

    def _fmt_extra_usage(self, extra: Optional[dict]) -> str:
        """Format extra usage menu item from payload dict."""
        extra = extra if isinstance(extra, dict) else {}
        if not extra.get("is_enabled"):
            return f"{EXTRA_USAGE_LABEL}{EXTRA_USAGE_OFF}"
        parts = []
        util = extra.get("utilization")
        if util is not None:
            parts.append(_fmt_pct(util))
        used = extra.get("used_credits")
        cap = extra.get("monthly_limit")
        if used is not None and cap is not None:
            currency = extra.get("currency") or ""
            parts.append(_fmt_credits(used, cap, currency))
        return EXTRA_USAGE_LABEL + (SEPARATOR.join(parts) or EXTRA_USAGE_ENABLED)

    def _get_status_suffix(self) -> str:
        """Return status suffix: ' [rate limited]', ' (stale)', or ''."""
        if self._is_rate_limited:
            return STATUS_RATE_LIMITED
        if self._latest_error:
            return STATUS_STALE
        return ""

    def _view_is_available(self, view) -> bool:
        """Check if a view dict has valid utilization data."""
        return isinstance(view, dict) and view.get("utilization") is not None

    def _status_button(self):
        """Reach the underlying NSStatusBarButton through rumps' wrapper."""
        try:
            return self._nsapp.nsstatusitem.button()
        except Exception:  # noqa: BLE001
            return None

    def _set_title(self, prefix: str, bar_text: str, tail: str, pct: Optional[float]):
        """Set the menu-bar title with the bar segment tinted by `pct`.

        Falls back to plain title if AppKit / the status button isn't ready
        yet (e.g. before `run()` finishes wiring up).
        """
        full = f"{prefix}{bar_text}{tail}"
        if _HAS_APPKIT:
            button = self._status_button()
            if button is not None:
                try:
                    attr = NSMutableAttributedString.alloc().initWithString_(full)
                    color = status_color(pct)
                    filled_len = bar_text.count("█")
                    if color is not None and filled_len > 0:
                        attr.addAttribute_value_range_(
                            NSForegroundColorAttributeName,
                            color,
                            (len(prefix), filled_len),
                        )
                    # The empty `░` segment inherits the default label color
                    # (white on dark menu bar, black on light) — no override.
                    button.setAttributedTitle_(attr)
                    return
                except Exception:  # noqa: BLE001
                    pass
        self.title = full

    def _render_history(self):
        """Refresh the sparkline+trend row and the min/avg/max row from in-memory history."""
        with self._history_lock:
            snapshots = list(self._history)
        key = HISTORY_KEY_BY_VIEW.get(self.current_view, "session_pct")
        now_ts = int(time.time())
        spark = _render_sparkline(snapshots, key, now_ts) if snapshots else ""
        if spark:
            trend = _compute_trend(snapshots, key, now_ts)
            self.history_item.title = (
                f"{HISTORY_LABEL}{spark} {trend}".rstrip() if trend
                else f"{HISTORY_LABEL}{spark}"
            )
        else:
            self.history_item.title = HISTORY_COLLECTING
        mn, avg, mx = _compute_min_max_avg(snapshots, key, now_ts)
        if mn is None:
            # Differentiate from history_item's "7d: collecting…" so the two
            # empty-state rows don't render identically next to each other.
            self.stats_item.title = (
                f"{HISTORY_LABEL}min {UNAVAILABLE}{SEPARATOR}"
                f"avg {UNAVAILABLE}{SEPARATOR}max {UNAVAILABLE}"
            )
        else:
            self.stats_item.title = (
                f"{HISTORY_LABEL}min {_fmt_pct(mn)}{SEPARATOR}"
                f"avg {_fmt_pct(avg)}{SEPARATOR}max {_fmt_pct(mx)}"
            )

    def _render(self):
        payload = self._latest
        err = self._latest_error
        status_suffix = self._get_status_suffix()
        if self.show_history:
            self._render_history()

        # No cached data yet: loading state (err is None) or error state (err is not None).
        # Either way, render markers/emoji on detail items so the user can see which view
        # is being tracked even before the first poll lands.
        if payload is None:
            if err is not None:
                self._set_title(MENU_ICON, "", err, None)
            for key, item in self._detail_items.items():
                marker = MARKER_SELECTED if key == self.current_view else MARKER_UNSELECTED
                item.title = f"{marker}{status_emoji(None)} {VIEW_LABEL[key]}: {UNAVAILABLE}"
            self.extra_item.title = f"{EXTRA_USAGE_LABEL}{UNAVAILABLE}"
            self.tier_item.title = f"{PLAN_LABEL}{self._latest_plan or UNAVAILABLE}"
            self.last_update_item.title = f"{UPDATE_LABEL}{NEVER_UPDATED}"
            return

        # menu-bar title from current_view
        view = payload.get(self.current_view)
        prefix = VIEW_PREFIX.get(self.current_view, "")

        if self._view_is_available(view):
            pct = float(view["utilization"])
            time_display = self._get_time_value(view.get("resets_at"))
            bar_text = bar(pct)
            tail = f" {_fmt_pct(pct)}{SEPARATOR}{time_display}{status_suffix}"
            self._set_title(prefix, bar_text, tail, pct)
        else:
            self._set_title(prefix, bar(None), f" {VIEW_UNAVAILABLE}{status_suffix}", None)

        # Detail rows for every known view
        for key, item in self._detail_items.items():
            v = payload.get(key)
            label = VIEW_LABEL[key]
            marker = MARKER_SELECTED if key == self.current_view else MARKER_UNSELECTED
            if not self._view_is_available(v):
                item.title = f"{marker}{status_emoji(None)} {label}: {VIEW_UNAVAILABLE}{status_suffix}"
                continue
            pct = v.get("utilization")
            resets = v.get("resets_at")
            emoji = status_emoji(pct)
            time_info = self._fmt_time_display(resets)
            item.title = (
                f"{marker}{emoji} {label}{DETAIL_ITEM_SPACER}{bar(pct)} {_fmt_pct(pct)}{DETAIL_ITEM_SPACER}"
                f"{time_info}{status_suffix}"
            )

        self.extra_item.title = self._fmt_extra_usage(payload.get("extra_usage")) + status_suffix

        # Plan info — use cached value (only updated on successful fetch)
        plan_text = self._latest_plan or UNAVAILABLE
        self.tier_item.title = f"{PLAN_LABEL}{plan_text}{status_suffix}"

        self.last_update_item.title = f"{UPDATE_LABEL}{self._fmt_update_time()}{status_suffix}"

    def _read_plan_info(self, oauth_data: Optional[dict] = None) -> str:
        """Format plan and tier info from OAuth data. Returns empty string if unavailable."""
        if not oauth_data:
            return ""

        sub = oauth_data.get("subscriptionType") or ""
        tier = oauth_data.get("rateLimitTier") or ""

        sub_name = SUB_TYPE_MAP.get(sub, sub)
        tier_name = RATE_LIMIT_TIER_MAP.get(tier, tier)

        return SEPARATOR.join(p for p in (sub_name, tier_name) if p)


def main():
    """Entry point for the `tokenmaxxing` console script."""
    ClaudeMonitorApp().run()


if __name__ == "__main__":
    main()
