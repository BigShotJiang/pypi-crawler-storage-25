"""tokenmaxxing — menu bar app for Claude Code session and weekly usage."""

__version__ = "0.1.0"

from tokenmaxxing.app import main

__all__ = ["main", "__version__"]
