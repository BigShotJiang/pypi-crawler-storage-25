"""Allows `python -m tokenmaxxing` to launch the menu bar app."""

from tokenmaxxing.app import main

if __name__ == "__main__":
    main()
