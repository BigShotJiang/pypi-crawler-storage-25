"""Helper for installing packages via winget on Windows.

The framework calls :func:`install` from ``BinaryTool.install_binary`` when the
tool defines ``winget_package``. Returns ``None`` on non-Windows systems or
when winget is not available — callers should then fall through to the OS
hook (``install_windows``).

A non-zero exit from winget surfaces as ``InstallReport(error=...)`` rather
than ``None``: when winget is present we treat its failure as the real error
instead of silently retrying another path.
"""

import os
import shutil
import subprocess
import sys

from .base import InstallReport
from .platform import detect


def is_available() -> bool:
    """True when running on Windows and the ``winget`` binary is on PATH."""
    try:
        plat = detect()
    except ValueError:
        return False
    if not plat.is_windows:
        return False
    return shutil.which("winget") is not None


def _refresh_process_path_from_user_registry() -> None:
    """Merge the user-scope PATH from the registry into ``os.environ['PATH']``.

    winget extends the user PATH (HKCU\\Environment\\Path) when it installs
    a package — many packages rely on that for their binaries to be findable.
    The current Python process inherited PATH at start time, so it doesn't
    see the registry update until a new shell is launched. This pulls in any
    new entries so sibling install steps (and ``shutil.which``) can locate
    the freshly installed binary in the same run.

    Best-effort: any error is swallowed silently (the caller falls back to
    explicit candidate-path probing).
    """
    if sys.platform != "win32":
        return
    try:
        import winreg
    except ImportError:
        return
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            user_path, _ = winreg.QueryValueEx(key, "Path")
    except OSError:
        return
    if not isinstance(user_path, str) or not user_path:
        return
    user_path = os.path.expandvars(user_path)
    current = os.environ.get("PATH", "")
    seen = {p.rstrip("\\/") for p in current.split(os.pathsep) if p}
    additions: list[str] = []
    for raw in user_path.split(os.pathsep):
        entry = raw.strip().strip('"')
        if not entry:
            continue
        if entry.rstrip("\\/") in seen:
            continue
        seen.add(entry.rstrip("\\/"))
        additions.append(entry)
    if not additions:
        return
    os.environ["PATH"] = os.pathsep.join(additions + ([current] if current else []))


def install(package_id: str) -> InstallReport | None:
    """Install ``package_id`` via winget. Returns ``None`` if winget unusable.

    Always passes ``--silent``, ``--accept-package-agreements`` and
    ``--accept-source-agreements`` for non-interactive automation.

    Quirks handled:

    - winget exits non-zero when the package is already installed with no
      upgrade available — treated as success (the binary is on disk).
    - After a successful install, the user-scope PATH (where winget often
      registers the package directory) is merged into the process PATH so
      ``shutil.which`` finds the binary without a shell restart.
    """
    if not is_available():
        return None
    cmd = [
        "winget",
        "install",
        "--id",
        package_id,
        "-e",
        "--source",
        "winget",
        "--silent",
        "--accept-package-agreements",
        "--accept-source-agreements",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, check=False)
    output = f"{r.stdout}\n{r.stderr}".lower()
    already_installed = (
        "no available upgrade" in output or "no newer package versions" in output or "already installed" in output
    )
    if r.returncode != 0 and not already_installed:
        return InstallReport(error=f"winget: {r.stderr.strip() or r.stdout.strip()}")
    _refresh_process_path_from_user_registry()
    method = "winget (already up-to-date)" if already_installed else "winget"
    return InstallReport(method=method)
