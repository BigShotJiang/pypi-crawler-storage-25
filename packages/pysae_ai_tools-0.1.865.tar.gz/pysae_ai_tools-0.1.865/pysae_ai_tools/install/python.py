"""Install Python (3.14, the version Pysae projects target) via uv.

uv manages the Python interpreter download and (with ``--default``) the shims
on PATH. The runtime itself lands under
``~/.local/share/uv/python/cpython-3.14.X-...`` and stays invokable through
``uv run --python 3.14`` regardless of the shim state.

This tool is OPTIONAL but ``default_selected=True`` — the package targets
3.14 (see CLAUDE.md), so most users want it pinned locally.

On Windows, ``do_install`` also disables the Microsoft Store
``python.exe`` / ``python3.exe`` App Execution Alias stubs so calling
``python`` from a fresh shell hits the uv-managed interpreter instead of
opening the Store dialog.
"""

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer

from .common.base import BaseTool, InstallReport, ToolState

PYTHON_TARGET = "3.14"

_MS_STORE_PYTHON_STUBS = ("python.exe", "python3.exe")

# Match every uv-managed cpython 3.14.x build, regardless of platform suffix.
_VERSION_RE = re.compile(r"cpython-(3\.14\.\d+)")


def _uv_path() -> str:
    return shutil.which("uv") or ""


def _uv_python_list_installed() -> list[str]:
    """Return non-empty lines from ``uv python list --only-installed``."""
    uv = _uv_path()
    if not uv:
        return []
    try:
        r = subprocess.run(
            [uv, "python", "list", "--only-installed"],
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
    except (OSError, subprocess.TimeoutExpired):
        return []
    if r.returncode != 0:
        return []
    return [line for line in r.stdout.splitlines() if line.strip()]


def _installed_target_version() -> str:
    """Return the highest installed 3.14.x version, or '' when none."""
    versions: list[str] = []
    for line in _uv_python_list_installed():
        match = _VERSION_RE.search(line)
        if match:
            versions.append(match.group(1))
    if not versions:
        return ""
    return max(versions, key=lambda v: tuple(int(x) for x in v.split(".")))


def _ms_store_python_stub_dir() -> Path | None:
    """Directory holding the Microsoft Store App Execution Alias stubs."""
    if sys.platform != "win32":
        return None
    local_app = os.environ.get("LOCALAPPDATA")
    if not local_app:
        return None
    apps_dir = Path(local_app) / "Microsoft" / "WindowsApps"
    return apps_dir if apps_dir.exists() else None


def _remove_ms_store_python_stubs() -> list[str]:
    """Delete the Microsoft Store ``python.exe`` / ``python3.exe`` aliases.

    These are 0-byte reparse points registered as Windows App Execution
    Aliases — they sit on PATH ahead of the uv-managed shims and hijack
    every ``python`` call to open the Store dialog ("Python was not found;
    run without arguments to install from the Microsoft Store"). A real
    Python install elsewhere doesn't help unless these are out of the way.

    Only removes 0-byte stubs (the alias signature) — any other file at
    the same path is left untouched. Idempotent and best-effort: missing
    files, permission errors, or unsupported platforms simply produce an
    empty list.
    """
    apps_dir = _ms_store_python_stub_dir()
    if apps_dir is None:
        return []
    removed: list[str] = []
    for name in _MS_STORE_PYTHON_STUBS:
        stub = apps_dir / name
        if not stub.exists():
            continue
        try:
            size = stub.stat().st_size
        except OSError:
            continue
        if size != 0:
            # Real binary placed there by another installer — leave it alone.
            continue
        try:
            stub.unlink()
        except OSError:
            continue
        removed.append(str(stub))
    return removed


def _uv_python_path(version_hint: str) -> str:
    """Best-effort: return the path uv resolves for ``version_hint``."""
    uv = _uv_path()
    if not uv:
        return ""
    try:
        r = subprocess.run(
            [uv, "python", "find", version_hint],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    if r.returncode != 0:
        return ""
    return r.stdout.strip()


class PythonTool(BaseTool):
    name = "python"
    cli_help = f"Install Python {PYTHON_TARGET} via uv"

    def get_state(self) -> ToolState:
        uv = _uv_path()
        version = _installed_target_version() if uv else ""
        installed = bool(version)
        path = _uv_python_path(PYTHON_TARGET) if installed else ""
        return ToolState(
            needs_install=not installed,
            needs_update=False,
            extra={
                "binary": {
                    "name": f"python{PYTHON_TARGET}",
                    "installed": installed,
                    "path": path,
                    "version": version,
                },
                "uv_available": bool(uv),
                "target": PYTHON_TARGET,
            },
        )

    def do_install(self) -> InstallReport:
        uv = _uv_path()
        if not uv:
            return InstallReport(
                error="uv not found on PATH — re-run install.sh / install.ps1 to bootstrap uv first",
            )
        # ``--default`` makes uv install shims (python, python3, python3.14)
        # under uv's bin dir, so the interpreter is usable outside ``uv run``.
        try:
            r = subprocess.run(
                [uv, "python", "install", "--default", PYTHON_TARGET],
                capture_output=True,
                text=True,
                check=False,
                timeout=600,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return InstallReport(error=f"uv python install: {exc}")
        if r.returncode != 0:
            # Older uv versions don't accept ``--default`` — retry without it.
            stderr = r.stderr or r.stdout
            if "--default" in stderr or "unexpected argument" in stderr.lower():
                try:
                    r = subprocess.run(
                        [uv, "python", "install", PYTHON_TARGET],
                        capture_output=True,
                        text=True,
                        check=False,
                        timeout=600,
                    )
                except (OSError, subprocess.TimeoutExpired) as exc:
                    return InstallReport(error=f"uv python install: {exc}")
            if r.returncode != 0:
                return InstallReport(error=(r.stderr or r.stdout).strip()[:500])

        version = _installed_target_version() or PYTHON_TARGET
        path = _uv_python_path(PYTHON_TARGET)
        report = InstallReport(version=version, path=path, method="uv")

        removed_stubs = _remove_ms_store_python_stubs()
        if removed_stubs:
            report.extra["ms_store_stubs_removed"] = removed_stubs
        return report

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        if not state.get("uv_available", True):
            return [("✗ uv not on PATH", typer.colors.RED)]
        target = state.get("target", PYTHON_TARGET)
        return [(f"target: {target}", typer.colors.BRIGHT_BLACK)]

    def format_check(self, state: ToolState) -> None:
        d = state.to_dict()
        bin_info = d.get("binary", {})
        if isinstance(bin_info, dict) and bin_info.get("installed"):
            typer.echo(f"python {PYTHON_TARGET}: {bin_info.get('version')} (managed by uv)")
        else:
            typer.echo(f"python {PYTHON_TARGET}: NOT installed")

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
            return
        line = f"python {PYTHON_TARGET} installed"
        if report.version:
            line += f" ({report.version})"
        if report.method:
            line += f" via {report.method}"
        typer.echo(line)
        if report.path:
            typer.echo(f"  path: {report.path}")
        removed = report.extra.get("ms_store_stubs_removed")
        if isinstance(removed, list) and removed:
            count = len(removed)
            typer.echo(f"  removed {count} Microsoft Store python stub{'s' if count > 1 else ''}")


_tool = PythonTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()


if __name__ == "__main__":
    cli()
