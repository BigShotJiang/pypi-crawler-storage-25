"""Meta-installer that runs every install-* skill in dependency order.

Strategy:
- Tools are grouped into tiers. Each tier installs in parallel-friendly groups
  but the meta-installer runs sequentially for clear log output.
- A tool can be REQUIRED (failure aborts), OPTIONAL (failure logged, continue),
  or SKIP_ON_MISSING_ENV (silently skipped when its env vars are absent).
- Each tool exposes a `get_state()` function that says whether work is needed.
  We call it first; if `needs_install` is false the tool is reported `skipped`.
"""

import importlib
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Annotated, Any

import typer


class Mode(StrEnum):
    REQUIRED = "required"
    OPTIONAL = "optional"


class Category(StrEnum):
    """High-level family of an install entry — used to group output.

    - ``LANGUAGE`` — language toolchain (uv, python, fnm, node, poetry, …).
    - ``CLI`` — locally-installed binary (aws, kubectl, terraform, …).
    - ``MCP`` — locally-installed MCP server registered in ``~/.claude.json``.
    - ``PLUGIN`` — Claude Code plugin (skills marketplace) under
      ``~/.claude/plugins/`` and ``~/.local/share/pysae-ai-tools/``.
    - ``EMBEDDED`` — synthetic entry, no install. Used for env-var
      groupings consumed by Pysae subcommands (e.g. ``slack-env``).
    """

    LANGUAGE = "language"
    CLI = "cli"
    MCP = "mcp"
    PLUGIN = "plugin"
    EMBEDDED = "embedded"


CATEGORY_HEADER: dict[Category, str] = {
    Category.LANGUAGE: "Language toolchains",
    Category.CLI: "CLI binaries",
    Category.MCP: "MCP servers",
    Category.PLUGIN: "Claude Code plugins",
    Category.EMBEDDED: "Embedded (env-only)",
}


@dataclass(frozen=True)
class Tool:
    """One install-* skill to orchestrate.

    Env vars come in two flavours:

    - ``env_pre_configure`` — resolved **before** the binary is installed.
      Gates the install in non-interactive mode (missing → tool skipped),
      because the values are typically baked in at install time (e.g. MCP
      servers writing tokens into ``~/.claude.json``).
    - ``env_post_configure`` — resolved **after** the binary is in place.
      Never blocks the install; used for configuration steps that *need*
      the binary first (e.g. ``aws configure`` requires the ``aws`` CLI
      on PATH).
    """

    name: str
    module: str  # import path, e.g. "pysae_ai_tools.install.glab"
    mode: Mode = Mode.OPTIONAL
    category: Category = Category.CLI
    env_pre_configure: tuple[str, ...] = ()  # vars resolved before install (gates install)
    env_post_configure: tuple[str, ...] = ()  # vars resolved after install (best-effort)
    env_help: dict[str, str] = field(default_factory=dict)  # var → how to get it
    default_selected: bool = True  # pre-checked in the first-run interactive checklist
    description: str = ""  # one-line summary shown in the configure checklist

    @property
    def env_vars(self) -> tuple[str, ...]:
        """All env vars declared by this tool, regardless of phase."""
        return self.env_pre_configure + self.env_post_configure

    @property
    def installed(self) -> bool:
        """Lightweight presence check — no ``get_state()``, no network calls.

        Answers "is this tool *here* on the system?" only — without
        verifying auth, config, or version freshness. Use
        :attr:`configured` when full readiness matters.

        - ``EMBEDDED`` → always True (no install).
        - ``CLI`` → binary on PATH (using the install module's
          ``binary_name`` / ``*_BIN`` constants / ``self.name``).
        - ``MCP`` → server entry registered in ``~/.claude.json``
          (cheap JSON read). Multi-server MCPs are considered installed
          when at least one of their server names is present.
        """
        import shutil

        if self.category is Category.EMBEDDED:
            return True

        try:
            mod = importlib.import_module(self.module)
        except Exception:  # noqa: BLE001
            return False

        if self.category is Category.MCP:
            from .common import mcp

            mcp_candidates: list[str] = []
            instance = getattr(mod, "_tool", None)
            if instance is not None:
                attr = getattr(instance, "server_name", None)
                if isinstance(attr, str) and attr:
                    mcp_candidates.append(attr)
            for const_name in ("SERVER_NAME", "DEV_NAME", "PROD_NAME"):
                value = getattr(mod, const_name, None)
                if isinstance(value, str) and value:
                    mcp_candidates.append(value)
            return any(mcp.get_server(name) is not None for name in mcp_candidates)

        # CLI — collect every plausible binary name from the install module:
        # ``_tool.binary_name``, any module-level ``*_BIN`` constant
        # (e.g. ``MONGOSH_BIN`` / ``DBTOOLS_BIN``), and finally ``self.name``.
        cli_candidates: list[str] = []
        instance = getattr(mod, "_tool", None)
        if instance is not None:
            attr = getattr(instance, "binary_name", None)
            if isinstance(attr, str) and attr:
                cli_candidates.append(attr)
        for attr_name in dir(mod):
            if attr_name.endswith("_BIN"):
                value = getattr(mod, attr_name, None)
                if isinstance(value, str) and value:
                    cli_candidates.append(value)
        if self.name not in cli_candidates:
            cli_candidates.append(self.name)
        return any(shutil.which(b) is not None for b in cli_candidates)

    @property
    def configured(self) -> bool:
        """Heavy readiness check — calls ``get_state()`` (may hit network).

        Returns True when the tool is installed *and* its state reports
        no pending install/update. Use when a downstream step needs the
        tool fully ready (auth ok, config in place, etc.).
        """
        try:
            get_state, _ = _resolve_callables(self.module)
            if get_state is None:
                return False
            return _state_is_installed(get_state())
        except Exception:  # noqa: BLE001
            return False


# Order matters: foundational tools first, dependents next.
TOOLS: tuple[Tool, ...] = (
    # Tier 1 — auth foundations (REQUIRED: many downstream tools need these)
    # uv must run first: python and poetry both rely on it.
    Tool(
        "uv",
        "pysae_ai_tools.install.uv",
        Mode.REQUIRED,
        category=Category.LANGUAGE,
        description="uv — Astral Python toolchain (gestionnaire d'interpréteurs et CLIs Python)",
    ),
    # aws-cli must run early: kubectl/EKS, mongodb-atlas-mcp (Secrets Manager), env secret all depend on it.
    Tool(
        "aws-cli",
        "pysae_ai_tools.install.aws_cli",
        Mode.REQUIRED,
        category=Category.CLI,
        # Post-configure: les valeurs sont écrites via `aws configure`,
        # qui a besoin du binaire sur PATH. Résolus APRÈS install.
        env_post_configure=("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_DEFAULT_REGION"),
        env_help={
            "AWS_ACCESS_KEY_ID": "saisi en interactif via `aws configure`, persisté dans ~/.aws/credentials",
            "AWS_SECRET_ACCESS_KEY": "saisi avec AWS_ACCESS_KEY_ID (paire), persisté dans ~/.aws/credentials",
            "AWS_DEFAULT_REGION": "écrite par `aws configure` dans ~/.aws/config (défaut Pysae : eu-west-3)",
        },
        description="AWS CLI — auth EKS, Secrets Manager, S3",
    ),
    Tool(
        "git",
        "pysae_ai_tools.install.git",
        Mode.REQUIRED,
        category=Category.CLI,
        description="Git — version control",
    ),
    Tool(
        "fnm",
        "pysae_ai_tools.install.fnm",
        Mode.REQUIRED,
        category=Category.LANGUAGE,
        description="fnm — Fast Node Manager (gestionnaire de versions Node)",
    ),
    Tool(
        "node",
        "pysae_ai_tools.install.node",
        Mode.REQUIRED,
        category=Category.LANGUAGE,
        description="Node.js (LTS) — runtime ; installe fnm si node manque",
    ),
    Tool(
        "python",
        "pysae_ai_tools.install.python",
        Mode.REQUIRED,
        category=Category.LANGUAGE,
        description="Python 3.14 — interpréteur géré par uv",
    ),
    Tool(
        "poetry",
        "pysae_ai_tools.install.poetry",
        Mode.REQUIRED,
        category=Category.LANGUAGE,
        description="Poetry — gestionnaire de dépendances Python (via uv tool)",
    ),
    Tool(
        "claude-code",
        "pysae_ai_tools.install.claude_code",
        Mode.REQUIRED,
        category=Category.CLI,
        # Anthropic's official installer is idempotent; running it again
        # bumps to the latest version, no env vars to gate.
        description="Claude Code CLI — Anthropic's terminal AI coding assistant",
    ),
    Tool(
        "claude-plugin",
        "pysae_ai_tools.install.claude_plugin",
        Mode.REQUIRED,
        category=Category.PLUGIN,
        # Auto-detects editable mode from the running package — installs
        # via symlinks when pysae_ai_tools itself is editable, deep-copies
        # otherwise. Must run after claude-code (uses ``claude plugin
        # marketplace add``).
        description="Pysae Claude Code skills + marketplace",
    ),
    Tool(
        "glab",
        "pysae_ai_tools.install.glab",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="GitLab CLI — MRs, issues, pipelines",
    ),
    Tool(
        "gh",
        "pysae_ai_tools.install.gh",
        Mode.OPTIONAL,
        category=Category.CLI,
        default_selected=False,
        description="GitHub CLI — PRs, issues, releases",
    ),
    # Tier 2 — Kubernetes stack (depends on aws-cli for EKS)
    Tool(
        "kubectl",
        "pysae_ai_tools.install.kubectl",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="kubectl — Kubernetes cluster CLI (pods, logs, exec)",
    ),
    Tool(
        "helm",
        "pysae_ai_tools.install.helm",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="Helm — Kubernetes chart templating and releases",
    ),
    Tool(
        "argocd",
        "pysae_ai_tools.install.argocd",
        Mode.OPTIONAL,
        category=Category.CLI,
        # Pre-configure : `do_install` lit les tokens et écrit
        # ~/.config/argocd/config pour authentifier les contextes dev/prod.
        # Auto-résolus depuis AWS Secrets Manager (pas de prompt nécessaire).
        env_pre_configure=("ARGOCD_DEV_TOKEN", "ARGOCD_PROD_TOKEN"),
        env_help={
            "ARGOCD_DEV_TOKEN": "AWS Secrets Manager (ai-tools/dev/secrets argocd-ai-tools-ci-token)",
            "ARGOCD_PROD_TOKEN": "AWS Secrets Manager (ai-tools/prod/secrets argocd-ai-tools-ci-token)",
        },
        description="ArgoCD CLI — GitOps deployments",
    ),
    # Tier 3 — generic tools
    Tool(
        "docker",
        "pysae_ai_tools.install.docker",
        Mode.OPTIONAL,
        category=Category.CLI,
        default_selected=False,
        description="Docker — containers",
    ),
    Tool(
        "terraform",
        "pysae_ai_tools.install.terraform",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="Terraform — infrastructure as code",
    ),
    Tool(
        "prefect",
        "pysae_ai_tools.install.prefect",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="Prefect CLI — workflow orchestration",
    ),
    Tool(
        "mongo-tools",
        "pysae_ai_tools.install.mongo_tools",
        Mode.OPTIONAL,
        category=Category.CLI,
        description="MongoDB tools — mongodump/restore/export",
    ),
    Tool(
        "postman",
        "pysae_ai_tools.install.postman",
        Mode.OPTIONAL,
        category=Category.CLI,
        default_selected=False,
        description="Postman / Newman CLI",
    ),
    # Tier 4 — MCP servers (no env vars needed)
    Tool(
        "chrome-mcp",
        "pysae_ai_tools.install.chrome_mcp",
        Mode.OPTIONAL,
        category=Category.MCP,
        description="MCP — Chrome DevTools (browser automation)",
    ),
    # Tier 5 — MCP servers requiring secrets
    Tool(
        "gitlab-mcp",
        "pysae_ai_tools.install.gitlab_mcp",
        Mode.OPTIONAL,
        category=Category.MCP,
        env_pre_configure=("GITLAB_PERSONAL_ACCESS_TOKEN",),
        env_help={
            "GITLAB_PERSONAL_ACCESS_TOKEN": (
                "glab config get token --host gitlab.com"
                "  # or GitLab → Preferences → Access Tokens → New Token (api scope)"
            ),
        },
        description="MCP — GitLab API (MRs, issues, jobs)",
    ),
    Tool(
        "datadog-mcp",
        "pysae_ai_tools.install.datadog_mcp",
        Mode.OPTIONAL,
        category=Category.MCP,
        env_pre_configure=("DD_API_KEY", "DD_APP_KEY"),
        env_help={
            "DD_API_KEY": "Datadog → Organization Settings → API Keys → New Key",
            "DD_APP_KEY": "Datadog → Organization Settings → Application Keys → New Key",
        },
        description="MCP — Datadog logs, metrics, monitors",
    ),
    Tool(
        "postman-mcp",
        "pysae_ai_tools.install.postman_mcp",
        Mode.OPTIONAL,
        category=Category.MCP,
        env_pre_configure=("POSTMAN_API_KEY",),
        env_help={
            "POSTMAN_API_KEY": "Postman → Settings → API Keys → Generate API Key",
        },
        default_selected=False,
        description="MCP — Postman collections and specs",
    ),
    # MongoDB MCP : split dev / prod — un utilisateur peut n'avoir accès
    # qu'à l'URI de dev (pas à celui de prod).
    Tool(
        "mongo-mcp-dev",
        "pysae_ai_tools.install.mongo_mcp_dev",
        Mode.OPTIONAL,
        category=Category.MCP,
        env_pre_configure=("MONGO_URI_DEV",),
        env_help={
            "MONGO_URI_DEV": "pysae-ai-tools env secret get pysae/local-dev/secrets api-mongo-uri --show-value",
        },
        description="MCP — MongoDB queries (dev, read/write)",
    ),
    Tool(
        "mongo-mcp-prod",
        "pysae_ai_tools.install.mongo_mcp_prod",
        Mode.OPTIONAL,
        category=Category.MCP,
        env_pre_configure=("MONGO_URI_PROD",),
        env_help={
            "MONGO_URI_PROD": "pysae-ai-tools env secret get pysae/local-prod/secrets api-mongo-uri --show-value",
        },
        description="MCP — MongoDB queries (prod, read-only)",
    ),
    Tool(
        "mongodb-atlas-mcp",
        "pysae_ai_tools.install.mongodb_atlas_mcp",
        Mode.OPTIONAL,
        category=Category.MCP,
        # Pulls keys from AWS Secrets Manager at install time — no env required.
        description="MCP — MongoDB Atlas cluster admin",
    ),
    # Tier 6 — outils embarqués (pas d'install locale, juste un groupage
    # d'env vars consommées par les sous-commandes Pysae).
    Tool(
        "slack-env",
        "pysae_ai_tools.install.slack",
        Mode.OPTIONAL,
        category=Category.EMBEDDED,
        # Vars consommées par `pysae-ai-tools slack …` (appels Slack API
        # directs depuis nos scripts, pas un MCP).
        env_pre_configure=("SLACK_BOT_TOKEN", "SLACK_USER_TOKEN", "SLACK_CLIENT_ID", "SLACK_CLIENT_SECRET"),
        env_help={
            "SLACK_BOT_TOKEN": (
                "AWS Secrets Manager (ai-tools/dev/secrets slack-app-token) ou OAuth via `slack get-token`"
            ),
            "SLACK_USER_TOKEN": "OAuth user-flow via `slack get-token --user-only` (cache local)",
            "SLACK_CLIENT_ID": "AWS Secrets Manager (ai-tools/dev/secrets slack-client-id)",
            "SLACK_CLIENT_SECRET": "AWS Secrets Manager (ai-tools/dev/secrets slack-client-secret)",
        },
        description="Slack — env vars pour les commandes `pysae-ai-tools slack` (appels API directs)",
    ),
)


@dataclass
class Result:
    name: str
    status: str  # "installed" | "updated" | "up-to-date" | "skipped" | "failed" | "manually-installed"
    detail: dict[str, Any] = field(default_factory=dict)
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"name": self.name, "status": self.status}
        if self.detail:
            out["detail"] = self.detail
        if self.error:
            out["error"] = self.error
        return out


def _resolve_callables(module_path: str) -> tuple[Callable[[], Any] | None, Callable[[], Any] | None]:
    """Return (get_state, do_install) callables from the tool module, if present."""
    mod = importlib.import_module(module_path)
    get_state = getattr(mod, "get_state", None)
    do_install = getattr(mod, "do_install", None)
    return get_state, do_install


def _state_needs_work(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates any work is needed (install or update)."""
    if state_obj is None:
        return True
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return True
    payload = to_dict()
    if not isinstance(payload, dict):
        return True
    for k, v in payload.items():
        if isinstance(k, str) and (k.startswith("needs_install") or k.startswith("needs_update")) and v:
            return True
    return False


def _state_is_installed(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates the tool is installed (ignoring updates)."""
    if state_obj is None:
        return False
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return False
    payload = to_dict()
    if not isinstance(payload, dict):
        return False
    # If any needs_install* key is True, it's not fully installed
    for k, v in payload.items():
        if isinstance(k, str) and k.startswith("needs_install") and v:
            return False
    # If we got state data, it means the tool is at least partially detectable
    # Check for explicit installed indicators
    if "binary" in payload and isinstance(payload["binary"], dict):
        return bool(payload["binary"].get("installed"))
    # If no needs_install is True and we have state data, consider it installed
    return True


def _install_one(tool: Tool, *, dry_run: bool, interactive: bool = False) -> Result:
    """Two-phase env handling around the binary install.

    1. **Pre-configure** — resolve ``tool.env_pre_configure`` *before*
       installing. Gates the install in non-interactive mode (missing →
       skipped) because the values are baked in at install time (e.g. MCP
       servers writing tokens into ``~/.claude.json``).
    2. **Install** — run ``do_install``. Skipped when ``get_state`` reports
       the tool already up-to-date.
    3. **Post-configure** — resolve ``tool.env_post_configure`` *after*
       the binary is in place. Best-effort — missing vars don't fail the
       install. Used for steps that need the binary itself (e.g. ``aws
       configure`` requires ``aws`` on PATH).
    """
    try:
        get_state, do_install = _resolve_callables(tool.module)
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=f"import: {exc}")

    import shutil

    # Phase 1 — pre-configure env vars (gates install).
    if tool.env_pre_configure:
        from .common.interactive import ensure_env_vars

        if not ensure_env_vars(tool.env_pre_configure, tool.name, tool.env_help, interactive=interactive):
            return Result(name=tool.name, status="skipped", detail={"reason": "missing env vars"})

    state_payload: dict[str, Any] = {}
    was_installed = False
    if get_state is not None:
        try:
            state_obj = get_state()
            state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
            was_installed = _state_is_installed(state_obj)
        except Exception:  # noqa: BLE001
            state_obj = None
            state_payload = {}
        if not _state_needs_work(state_obj):
            # Binary is up-to-date; still surface post-configure prompts so
            # the user can complete (or update) configuration without
            # reinstalling.
            _resolve_post_configure(tool, interactive=interactive)
            return Result(name=tool.name, status="up-to-date", detail=state_payload)
    if not was_installed:
        was_installed = shutil.which(tool.name) is not None

    success_status = "updated" if was_installed else "installed"

    if dry_run:
        return Result(name=tool.name, status=success_status, detail={"dry_run": True, **state_payload})

    if do_install is None:
        return Result(name=tool.name, status="failed", error="module has no do_install()")

    # Phase 2 — install the binary.
    try:
        report = do_install()
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=str(exc))

    payload = report.to_dict() if hasattr(report, "to_dict") else {}
    if isinstance(payload, dict) and payload.get("error"):
        return Result(name=tool.name, status="failed", error=str(payload["error"]), detail=payload)

    # Phase 3 — post-configure env vars (best-effort, never blocks).
    _resolve_post_configure(tool, interactive=interactive)

    return Result(name=tool.name, status=success_status, detail=payload if isinstance(payload, dict) else {})


def _resolve_post_configure(tool: Tool, *, interactive: bool) -> None:
    """Best-effort post-install env var resolution.

    Auto-resolves what it can; prompts the user when ``interactive=True``.
    Never gates the install — this runs *after* the binary is in place.
    Missing vars at the end are simply left unresolved; the tool's own
    runtime can complain or ask for them later.
    """
    if not tool.env_post_configure or all(os.environ.get(v) for v in tool.env_post_configure):
        return
    from .common.interactive import ensure_env_vars

    ensure_env_vars(tool.env_post_configure, tool.name, tool.env_help, interactive=interactive)


def install_all(
    *,
    dry_run: bool = False,
    interactive: bool = False,
    only: tuple[str, ...] = (),
    skip: tuple[str, ...] = (),
) -> list[Result]:
    results: list[Result] = []
    for tool in TOOLS:
        if only and tool.name not in only:
            continue
        if tool.name in skip:
            results.append(Result(name=tool.name, status="skipped", detail={"reason": "user-skipped"}))
            continue
        result = _install_one(tool, dry_run=dry_run, interactive=interactive)
        results.append(result)
        # On REQUIRED failure, abort the chain
        if tool.mode is Mode.REQUIRED and result.status == "failed":
            results.append(
                Result(name="__abort__", status="failed", error=f"{tool.name} is REQUIRED — aborting remaining tools")
            )
            break
    return results


def _extract_identity(tool: "Tool", payload: dict[str, Any]) -> list[tuple[str, str | None]]:
    """Extract identity/context lines by delegating to the tool's extract_identity method."""
    try:
        mod = importlib.import_module(tool.module)
        tool_instance = getattr(mod, "_tool", None)
        if tool_instance is not None and hasattr(tool_instance, "extract_identity"):
            return list(tool_instance.extract_identity(payload))
    except Exception:  # noqa: BLE001
        pass
    return []


def _render_tool_status(tool: Tool) -> str:
    """Render a single tool's status line. Returns the detected status
    (``installed`` / ``needs-update`` / ``missing``).
    """
    import shutil

    found = False
    state_payload: dict[str, Any] = {}

    try:
        get_state, _ = _resolve_callables(tool.module)
        if get_state is not None:
            state_obj = get_state()
            state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
            found = _state_is_installed(state_obj)
    except Exception:  # noqa: BLE001
        pass

    if not found and not state_payload:
        found = shutil.which(tool.name) is not None

    needs_update = found and any(
        isinstance(k, str) and k.startswith("needs_update") and v for k, v in state_payload.items()
    )
    auth_failed = found and ("auth_ok" in state_payload) and not state_payload.get("auth_ok")
    if not found:
        icon = "✗"
        color = typer.colors.RED
    elif needs_update:
        icon = "⬆"
        color = typer.colors.YELLOW
    elif auth_failed:
        icon = "⚠"
        color = typer.colors.YELLOW
    else:
        icon = "✓"
        color = typer.colors.GREEN
    env_parts: list[str] = []
    if not found:
        for var in tool.env_vars:
            if os.environ.get(var):
                env_parts.append(f"  ✓ ${var}")
            else:
                env_parts.append(f"  ✗ ${var}")

    identity_lines = _extract_identity(tool, state_payload)

    update_hint = ""
    if needs_update:
        current = state_payload.get("binary", {}).get("version", "")
        latest = state_payload.get("latest", "")
        if current and latest:
            update_hint = f" ({current} → {latest})"
        elif latest:
            update_hint = f" (→ {latest})"
    elif auth_failed:
        update_hint = " (auth required)"

    has_details = bool(identity_lines or env_parts)
    typer.secho(f"  {icon} {tool.name:<20}{update_hint}", fg=color, nl=not has_details)
    if has_details:
        typer.echo("")
    for text, line_color in identity_lines:
        typer.secho(f"      {text}", fg=line_color or typer.colors.BRIGHT_BLACK)
    for part in env_parts:
        var_set = part.startswith("  ✓")
        typer.secho(f"    {part}", fg=typer.colors.GREEN if var_set else typer.colors.YELLOW)

    if not found:
        return "missing"
    if needs_update:
        return "needs-update"
    if auth_failed:
        return "auth-required"
    return "installed"


def _status_one(tool: Tool) -> None:
    """Show status for a single tool."""
    _render_tool_status(tool)


SECTION_ENV = "🔑 Environment variables"
SECTION_SUMMARY = "📊 Summary"
SECTION_RULE = "─" * 60

# Display order for category sections — languages first (they bootstrap
# the rest), then CLIs, MCPs, plugins, embedded entries.
CATEGORY_ORDER: tuple[Category, ...] = (
    Category.LANGUAGE,
    Category.CLI,
    Category.MCP,
    Category.PLUGIN,
    Category.EMBEDDED,
)

CATEGORY_ICON: dict[Category, str] = {
    Category.LANGUAGE: "🌐",
    Category.CLI: "🔧",
    Category.MCP: "🔌",
    Category.PLUGIN: "🧩",
    Category.EMBEDDED: "📦",
}


def _section_header(title: str) -> None:
    typer.echo("")
    typer.echo(f"  {title}")
    typer.echo(f"  {SECTION_RULE}")


def _category_header(cat: Category) -> None:
    """Print a section header for a category (only when it has any tools)."""
    _section_header(f"{CATEGORY_ICON[cat]} {CATEGORY_HEADER[cat]}")


def _tools_by_category(tools: tuple[Tool, ...] = TOOLS) -> dict[Category, list[Tool]]:
    """Group ``tools`` by category, preserving original order within each."""
    grouped: dict[Category, list[Tool]] = {c: [] for c in CATEGORY_ORDER}
    for t in tools:
        grouped.setdefault(t.category, []).append(t)
    return grouped


def _status_all() -> None:
    """Show installed/missing tools and required environment variables, grouped by category."""
    counts = {"installed": 0, "needs-update": 0, "auth-required": 0, "missing": 0}
    grouped = _tools_by_category()
    for cat in CATEGORY_ORDER:
        bucket = grouped.get(cat) or []
        if not bucket:
            continue
        _category_header(cat)
        for tool in bucket:
            status = _render_tool_status(tool)
            counts[status] = counts.get(status, 0) + 1

    tools_with_env = [t for t in TOOLS if t.env_vars and not t.installed]
    if tools_with_env:
        _section_header(SECTION_ENV)
        for tool in tools_with_env:
            typer.echo(f"  {tool.name}:")
            for var in tool.env_vars:
                present = bool(os.environ.get(var))
                icon = "✓" if present else "✗"
                color = typer.colors.GREEN if present else typer.colors.YELLOW
                typer.secho(f"    {icon} ${var}", fg=color)
                if not present and var in tool.env_help:
                    typer.secho(f"      → {tool.env_help[var]}", fg=typer.colors.BRIGHT_BLACK)
            typer.echo("")

    _section_header(SECTION_SUMMARY)
    summary = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
    typer.echo(f"  {summary or 'no tools'}")


def _render_install_result(r: Result) -> None:
    """Render a single install result with icon + color, matching status style."""
    if r.status == "up-to-date":
        icon, color = "✓", typer.colors.GREEN
    elif r.status == "manually-installed":
        icon, color = "✓", typer.colors.GREEN
    elif r.status == "installed":
        icon, color = "⬆", typer.colors.YELLOW
    elif r.status == "updated":
        icon, color = "⬆", typer.colors.YELLOW
    elif r.status == "skipped":
        icon, color = "⊘", typer.colors.BRIGHT_BLACK
    else:  # failed
        icon, color = "✗", typer.colors.RED

    tool = _find_tool(r.name)
    mode_tag = f" ({tool.mode.value})" if tool is not None and tool.mode != Mode.OPTIONAL else ""

    suffix = ""
    if r.status in ("installed", "updated") and isinstance(r.detail, dict):
        version = r.detail.get("version", "")
        if version:
            suffix = f" → {version}"
    if r.error:
        suffix = f" — {r.error}"
    elif r.status == "skipped" and isinstance(r.detail, dict):
        reason = r.detail.get("reason")
        if reason:
            suffix = f" — {reason}"

    label = "manually installed" if r.status == "manually-installed" else r.status
    typer.secho(f"  {icon} {r.name:<20} {label}{suffix}{mode_tag}", fg=color)


def _result_for_unselected(tool: Tool) -> Result:
    """Build a Result for a tool excluded from the selection.

    If the tool happens to be installed already, surface it as
    ``manually-installed`` so the user sees normal output. Otherwise mark it
    grey-skipped.
    """
    try:
        get_state, _ = _resolve_callables(tool.module)
        if get_state is not None:
            state_obj = get_state()
            if _state_is_installed(state_obj):
                payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
                return Result(name=tool.name, status="manually-installed", detail=payload)
    except Exception:  # noqa: BLE001
        pass
    return Result(name=tool.name, status="skipped", detail={"reason": "not selected"})


def _resolve_env_section(tools: tuple[Tool, ...], *, interactive: bool) -> None:
    """Resolve every env var declared by ``tools`` upfront, in a dedicated section.

    Each distinct var is tried at most once (vars shared across tools are
    deduplicated). Vars already in the environment are left as-is. Auto-
    resolve runs unconditionally; the interactive prompt fires only when
    ``interactive=True`` and stdin is a TTY.

    No gating / no skipping happens here — the per-tool install phase
    (``_install_one``) handles ``env_pre_configure`` enforcement using
    whatever ended up in ``os.environ``.
    """
    from ..env.resolve import try_auto_resolve
    from .common.interactive import prompt_env_var

    seen: dict[str, str] = {}  # var → first tool that declared it (for help-text lookup)
    for tool in tools:
        for var in tool.env_vars:
            seen.setdefault(var, tool.name)

    if not seen:
        return

    _section_header(SECTION_ENV)
    for var, tool_name in seen.items():
        if os.environ.get(var):
            # Symmetric with the resolver-trace path: blank line + cyan
            # ``$VAR`` heading + indented green status. The blank line is
            # added by ``try_auto_resolve``'s ``_trace_header`` for the
            # other branch — we mirror it manually here.
            typer.echo("")
            typer.secho(f"  ${var}", fg=typer.colors.CYAN)
            typer.secho("    ✓ déjà défini dans l'environnement", fg=typer.colors.GREEN)
            continue
        if try_auto_resolve(var) is not None:
            continue
        if interactive:
            help_text = next((t.env_help.get(var, "") for t in tools if var in t.env_help), "")
            # ``persist=True`` writes the entered value to the on-disk env
            # cache so subsequent runs (when the upstream source — AWS
            # Secrets Manager, glab CLI, etc. — is still down) can reuse
            # it via try_auto_resolve's last-resort cache fallback.
            prompt_env_var(var, tool_name, help_text, persist=True)


def _install_pretty(
    *,
    skip: tuple[str, ...],
    interactive: bool,
    selection: set[str] | None = None,
) -> list[Result]:
    """Run the install pipeline with grouped 'Environment variables' + 'Tools' sections.

    ``selection`` lists tool names the user opted into. Tools outside the set
    are not installed but still rendered (as ``manually-installed`` if
    detected on the system, otherwise as ``skipped``). REQUIRED tools are
    forced into the selection.
    """
    if selection is not None:
        selection = set(selection) | {t.name for t in TOOLS if t.mode is Mode.REQUIRED}

    def _is_selected(tool_name: str) -> bool:
        return selection is None or tool_name in selection

    tools_to_run = tuple(t for t in TOOLS if t.name not in skip)
    grouped = _tools_by_category(tools_to_run)

    # Resolve every env var declared by the *selected* tools upfront, in a
    # single dedicated section. Per-tool fallback in ``_install_one``
    # short-circuits because ``os.environ`` is already populated.
    selected_tools = tuple(t for t in tools_to_run if _is_selected(t.name))
    _resolve_env_section(selected_tools, interactive=interactive)

    results: list[Result] = []
    aborted = False
    for cat in CATEGORY_ORDER:
        bucket = grouped.get(cat) or []
        if not bucket:
            continue
        _category_header(cat)
        for tool in bucket:
            if not _is_selected(tool.name):
                result = _result_for_unselected(tool)
            else:
                result = _install_one(tool, dry_run=False, interactive=interactive)
            results.append(result)
            _render_install_result(result)

            if tool.mode is Mode.REQUIRED and result.status == "failed":
                abort = Result(
                    name="__abort__",
                    status="failed",
                    error=f"{tool.name} is REQUIRED — aborting remaining tools",
                )
                results.append(abort)
                typer.secho(f"  ✗ aborted — {abort.error}", fg=typer.colors.RED)
                aborted = True
                break
        if aborted:
            break
    return results


def _find_tool(name: str) -> Tool | None:
    """Find a tool by name."""
    for t in TOOLS:
        if t.name == name:
            return t
    return None


TOOL_NAMES = [t.name for t in TOOLS]


# ---------------------------------------------------------------------------
# Unified CLI: pysae-ai-tools tools <command> [tool-name]
# ---------------------------------------------------------------------------

cli = typer.Typer(no_args_is_help=True, help="Install, check, and manage Pysae CLI tools and MCP servers")


@cli.command()
def status(
    tool_name: Annotated[str | None, typer.Argument(help="Tool name (default: all)")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Show installed/missing tools and required environment variables."""
    if tool_name:
        tool = _find_tool(tool_name)
        if not tool:
            typer.echo(f"Unknown tool: {tool_name}. Available: {', '.join(TOOL_NAMES)}", err=True)
            raise typer.Exit(code=1)
        if json_output:
            try:
                get_state, _ = _resolve_callables(tool.module)
                if get_state is not None:
                    state_obj = get_state()
                    typer.echo(json.dumps(state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}))
            except Exception as exc:  # noqa: BLE001
                typer.echo(json.dumps({"error": str(exc)}))
                raise typer.Exit(code=1) from None
        else:
            _status_one(tool)
    else:
        if json_output:
            # Collect state for each tool without installing or resolving env vars
            all_states: list[dict[str, Any]] = []
            for tool in TOOLS:
                try:
                    get_state_fn, _ = _resolve_callables(tool.module)
                    if get_state_fn is not None:
                        state_obj = get_state_fn()
                        d = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
                        d["name"] = tool.name
                        all_states.append(d)
                except Exception:  # noqa: BLE001
                    all_states.append({"name": tool.name, "error": "failed to get state"})
            typer.echo(json.dumps(all_states))
        else:
            _status_all()


def _checklist_label(tool: Tool) -> str:
    """Compose the dim-grey suffix shown next to each item in the checklist.

    The ``(NEW)`` marker is *not* part of this label — it's rendered
    separately (red + bold) via :attr:`Item.is_new` for visibility.
    """
    parts: list[str] = []
    if tool.description:
        parts.append(tool.description)
    if tool.mode is Mode.REQUIRED:
        parts.append("(required)")
    return " ".join(parts)


def _effective_known(initial: list[str] | None, known: list[str] | None) -> list[str] | None:
    """Resolve ``tools_known_at_save`` with a sensible legacy fallback.

    Pre-snapshot users only persisted ``tools_to_install`` — they're missing
    the ``tools_known_at_save`` snapshot introduced afterwards. To avoid
    flagging zero new tools forever for those users, treat the saved
    selection as the implicit snapshot: tools currently in ``TOOLS`` but
    absent from it are surfaced as NEW. This may falsely flag tools the
    user had explicitly deselected as NEW once, but the alternative
    (silently auto-extending or hiding new tools) is worse.
    """
    if known is not None:
        return known
    if initial is not None:
        return list(initial)
    return None


def _initial_selected_set(initial: list[str] | None, known: list[str] | None) -> set[str]:
    """Compute the pre-checked set for the configure checklist.

    Logic per tool:

    - REQUIRED → always checked (locked elsewhere).
    - First-time configure (``initial is None``) → use ``default_selected``.
    - Tool present in saved selection → checked (explicit yes).
    - Tool absent from saved selection but present in ``known`` (was visible
      at last save) → unchecked (explicit no).
    - Tool absent from both → **new tool** added in a newer version of the
      package: fall back to ``default_selected`` rather than silently
      treating it as deselected.
    """
    if initial is None:
        return {t.name for t in TOOLS if t.default_selected}

    saved = set(initial)
    effective_known = _effective_known(initial, known)
    known_set: set[str] | None = set(effective_known) if effective_known is not None else None

    selected: set[str] = set()
    for t in TOOLS:
        if t.name in saved:
            selected.add(t.name)
            continue
        if known_set is not None and t.name not in known_set and t.default_selected:
            selected.add(t.name)
    return selected


def _prompt_tool_selection(
    initial: list[str] | None,
    known: list[str] | None,
) -> list[str] | None:
    """Show the interactive checklist, grouped by category. Returns the
    chosen names, or ``None`` if the prompt cannot run.

    ``initial`` is the previously-saved selection (None → first run).
    ``known`` is the snapshot of tools that existed at that save — used
    to identify newly-added tools and apply their ``default_selected``.
    """
    from .common.checklist import Item
    from .common.checklist import prompt as checklist_prompt

    initial_set = _initial_selected_set(initial, known)
    grouped = _tools_by_category()
    effective_known = _effective_known(initial, known)
    new_tools: set[str] = (
        {t.name for t in TOOLS if t.name not in effective_known} if effective_known is not None else set()
    )

    items: list[Item] = []
    for cat in CATEGORY_ORDER:
        bucket = grouped.get(cat) or []
        if not bucket:
            continue
        section_label = f"{CATEGORY_ICON[cat]} {CATEGORY_HEADER[cat]}"
        for idx, t in enumerate(bucket):
            items.append(
                Item(
                    name=t.name,
                    label=_checklist_label(t),
                    selected=t.name in initial_set or t.mode is Mode.REQUIRED,
                    locked=t.mode is Mode.REQUIRED,
                    is_new=t.name in new_tools,
                    # Section header rendered just above the first item of each group.
                    header_above=section_label if idx == 0 else "",
                )
            )

    result = checklist_prompt(items, header="  Sélectionne les outils à installer :")
    if result is None:
        return None
    return [it.name for it in result if it.selected]


def _configure_env_vars(selected_tools: list[Tool]) -> None:
    """Walk env vars for the selected tools and prompt for missing ones.

    Pre-configure vars are walked unconditionally — they're needed before
    install, regardless of whether the binary is on the system yet.

    Post-configure vars are walked only for tools whose binary is already
    installed: configuring them earlier doesn't help (the binary is what
    powers the configuration step, e.g. ``aws configure``), and it would
    fail or lead to half-applied state.
    """
    from ..env.resolve import try_auto_resolve
    from .common.interactive import prompt_env_var

    seen: dict[str, str] = {}  # var → first tool name that needs it
    for tool in selected_tools:
        for var in tool.env_pre_configure:
            seen.setdefault(var, tool.name)
        if tool.installed:
            for var in tool.env_post_configure:
                seen.setdefault(var, tool.name)

    if not seen:
        return

    typer.echo("")
    typer.secho("  🔑 Variables d'environnement", fg=typer.colors.CYAN)

    for var, tool_name in seen.items():
        if os.environ.get(var):
            typer.secho(f"  ✓ ${var} (déjà défini)", fg=typer.colors.GREEN)
            continue
        if try_auto_resolve(var) is not None:
            continue
        env_help = next((t.env_help.get(var, "") for t in selected_tools if var in t.env_help), "")
        if prompt_env_var(var, tool_name, env_help, persist=True) is None:
            typer.secho(f"  ⊘ ${var} non renseigné — sera demandé à l'install", fg=typer.colors.BRIGHT_BLACK)


@cli.command()
def configure(
    reset: Annotated[
        bool,
        typer.Option("--reset", help="Ignore the saved selection and start from the defaults."),
    ] = False,
) -> None:
    """Configure which tools are installed by `tools install`."""
    from ..config import get_tools_known_at_save, get_tools_to_install, set_tools_to_install
    from .common.checklist import is_interactive

    if not is_interactive():
        typer.secho("FAILED: terminal is not interactive — cannot show the checklist.", err=True, fg=typer.colors.RED)
        raise typer.Exit(code=1)

    initial = None if reset else get_tools_to_install()
    known = None if reset else get_tools_known_at_save()
    selected = _prompt_tool_selection(initial, known)
    if selected is None:
        typer.secho("FAILED: terminal is not interactive — cannot show the checklist.", err=True, fg=typer.colors.RED)
        raise typer.Exit(code=1)

    set_tools_to_install(selected, known=TOOL_NAMES)
    typer.echo("")
    typer.secho(f"  Configuration enregistrée — {len(selected)} outil(s) sélectionné(s).", fg=typer.colors.GREEN)

    selected_tools = [t for t in TOOLS if t.name in selected]
    _configure_env_vars(selected_tools)


@cli.command()
def install(
    tool_name: Annotated[str | None, typer.Argument(help="Tool name (default: all)")] = None,
    skip: Annotated[
        list[str] | None,
        typer.Option("--skip", help="Skip these tools (repeatable)."),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
    interactive: Annotated[bool, typer.Option("--interactive", "-i", help="Prompt for missing env vars")] = False,
) -> None:
    """Install or update tools."""
    if tool_name:
        tool = _find_tool(tool_name)
        if not tool:
            typer.echo(f"Unknown tool: {tool_name}. Available: {', '.join(TOOL_NAMES)}", err=True)
            raise typer.Exit(code=1)
        result = _install_one(tool, dry_run=False, interactive=interactive)
        if json_output:
            typer.echo(json.dumps(result.to_dict()))
        else:
            _render_install_result(result)
        if result.status == "failed":
            raise typer.Exit(code=1)
        return

    from ..config import get_tools_known_at_save, get_tools_to_install, set_tools_to_install

    selected = get_tools_to_install()
    known = get_tools_known_at_save()
    effective_known = _effective_known(selected, known)

    # Detect tools that were added to the package since the last configure
    # save — typically after a self-update bumping the package version.
    # Legacy users (no snapshot) fall back to ``selected`` as the implicit
    # snapshot so newly-added tools still surface.
    new_tools = {t.name for t in TOOLS if t.name not in effective_known} if effective_known is not None else set()

    # Trigger the interactive checklist when:
    # - first run (nothing saved yet), OR
    # - the package now ships tools the user hasn't seen yet (NEW marker
    #   in the checklist lets them opt in/out explicitly).
    needs_prompt = selected is None or bool(new_tools)

    if not json_output and needs_prompt:
        chosen = _prompt_tool_selection(selected, known)
        if chosen is not None:
            set_tools_to_install(chosen, known=TOOL_NAMES)
            selected = chosen
        elif selected is not None and new_tools:
            # Non-interactive terminal — fall back to default_selected for
            # the new tools and persist the snapshot to silence subsequent
            # runs.
            merged = set(selected) | {t.name for t in TOOLS if t.name in new_tools and t.default_selected}
            selected = sorted(merged)
            set_tools_to_install(selected, known=TOOL_NAMES)
    elif json_output and selected is not None and new_tools:
        # JSON / CI mode — never prompt; auto-extend with new defaults so
        # CI runs are deterministic and the snapshot is kept in sync.
        merged = set(selected) | {t.name for t in TOOLS if t.name in new_tools and t.default_selected}
        if merged != set(selected):
            selected = sorted(merged)
            set_tools_to_install(selected, known=TOOL_NAMES)

    selection_set: set[str] | None = set(selected) if selected is not None else None

    if json_output:
        # In JSON mode, --skip still works; selection is honoured if persisted.
        skip_set = set(skip or ())
        if selection_set is not None:
            skip_set |= {t.name for t in TOOLS if t.name not in selection_set and t.mode is not Mode.REQUIRED}
        results = install_all(skip=tuple(skip_set), interactive=interactive)
        counts = {"installed": 0, "updated": 0, "up-to-date": 0, "skipped": 0, "failed": 0, "manually-installed": 0}
        for r in results:
            counts[r.status] = counts.get(r.status, 0) + 1
        typer.echo(json.dumps({"results": [r.to_dict() for r in results], "summary": counts}))
    else:
        results = _install_pretty(
            skip=tuple(skip or ()),
            interactive=interactive,
            selection=selection_set,
        )
        counts = {"installed": 0, "updated": 0, "up-to-date": 0, "skipped": 0, "failed": 0, "manually-installed": 0}
        for r in results:
            if r.name == "__abort__":
                continue
            counts[r.status] = counts.get(r.status, 0) + 1
        _section_header(SECTION_SUMMARY)
        summary = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
        typer.echo(f"  {summary or 'no tools processed'}")
        typer.secho(
            "  → Pour modifier la liste des outils installés : `pysae-ai-tools tools configure`",
            fg=typer.colors.BRIGHT_BLACK,
        )
    if counts["failed"]:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    cli()
