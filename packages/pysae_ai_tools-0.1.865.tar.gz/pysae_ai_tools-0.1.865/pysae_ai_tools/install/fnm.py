"""Install fnm — Fast Node Manager (Schniz/fnm).

Strategy:

- Windows: ``winget install Schniz.fnm``.
- macOS: ``brew install fnm``.
- Linux (and macOS without brew): the official ``curl|bash`` installer with
  ``--skip-shell`` — we own the dotfile wiring ourselves to stay idempotent.

After install, the tool wires ``eval "$(fnm env --use-on-cd)"`` (or the
PowerShell equivalent) into the user's shell profile(s) so ``node`` resolves
to the fnm-managed version in subsequent sessions.

This tool is OPTIONAL but ``default_selected=True`` — users whose Node is
already installed via another channel (apt, brew, manual installer) can
deselect it and rely on the existing ``node``.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer

from .common import binary, github, platform
from .common.base import BinaryTool, InstallReport, ToolState

FNM_INSTALL_URL = "https://fnm.vercel.app/install"
FNM_REPO = "Schniz/fnm"

FNM_INIT_BASH = 'eval "$(fnm env --use-on-cd --shell bash)"'
FNM_INIT_ZSH = 'eval "$(fnm env --use-on-cd --shell zsh)"'
FNM_INIT_PS = "fnm env --use-on-cd | Out-String | Invoke-Expression"

# Sentinel marker so subsequent runs detect a prior wiring even if the user
# reformats the surrounding block.
FNM_MARKER = "# pysae-ai-tools: fnm (Node.js)"


def find_fnm() -> str:
    """Locate the fnm binary, including common install dirs not yet on PATH.

    fnm's default install paths (``~/.local/share/fnm`` on Unix, the WinGet
    Links shim on Windows) may not be on the current process's PATH right
    after a fresh install — this helper covers them.
    """
    direct = shutil.which("fnm")
    if direct:
        return direct
    candidates: list[Path] = [
        Path.home() / ".local" / "share" / "fnm" / "fnm",
        Path.home() / ".fnm" / "fnm",
    ]
    if sys.platform == "win32":
        local_app = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        candidates.extend(
            [
                local_app / "Microsoft" / "WinGet" / "Links" / "fnm.exe",
                local_app / "fnm" / "fnm.exe",
            ]
        )
    for c in candidates:
        if c.exists():
            return str(c)
    return ""


def augment_path() -> None:
    """Make fnm + fnm-managed Node visible in the current Python process.

    fnm puts the default-aliased node under ``$FNM_DIR/aliases/default/bin``
    on Unix, and ``%APPDATA%\\fnm\\aliases\\default`` on Windows. Without
    prepending those, sibling install steps (e.g. node.py running
    ``fnm install --lts``) wouldn't see the binary in this session.
    """
    home = Path.home()
    extras: list[Path] = []

    fnm = find_fnm()
    if fnm:
        extras.append(Path(fnm).parent)

    if sys.platform == "win32":
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        extras.append(appdata / "fnm" / "aliases" / "default")
    else:
        extras.append(home / ".local" / "share" / "fnm" / "aliases" / "default" / "bin")

    current = os.environ.get("PATH", "")
    parts: list[str] = []
    seen: set[str] = set()
    for p in extras:
        if not p.exists():
            continue
        s = str(p)
        if s in seen:
            continue
        seen.add(s)
        parts.append(s)
    if current:
        parts.append(current)
    os.environ["PATH"] = os.pathsep.join(parts)


def _wire_dotfile(path: Path, line: str) -> bool:
    """Append the fnm init block to ``path`` when missing. Creates the file
    if absent. Returns True when the file was modified."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        existing = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
    except OSError:
        return False
    if FNM_MARKER in existing or "fnm env" in existing:
        return False
    block = f"\n{FNM_MARKER}\n{line}\n"
    try:
        new_content = existing.rstrip() + "\n" + block if existing else block.lstrip("\n")
        path.write_text(new_content, encoding="utf-8")
    except OSError:
        return False
    return True


def wire_shell_init(plat: platform.Platform) -> list[str]:
    """Append fnm init to user shell profile(s). Idempotent.

    Linux/macOS: ``~/.bashrc``, ``~/.bash_profile``, ``~/.zshrc``.
    Windows: PowerShell Core + Windows PowerShell profiles.

    Returns the list of files modified during this run.
    """
    home = Path.home()
    targets: list[tuple[Path, str]]
    if plat.is_windows:
        documents = home / "Documents"
        targets = [
            (documents / "PowerShell" / "profile.ps1", FNM_INIT_PS),
            (documents / "WindowsPowerShell" / "profile.ps1", FNM_INIT_PS),
        ]
    else:
        targets = [
            (home / ".bashrc", FNM_INIT_BASH),
            (home / ".bash_profile", FNM_INIT_BASH),
            (home / ".zshrc", FNM_INIT_ZSH),
        ]

    modified: list[str] = []
    for path, line in targets:
        if _wire_dotfile(path, line):
            modified.append(str(path))
    return modified


def shell_init_wired(plat: platform.Platform) -> bool:
    """Return True when at least one shell profile has fnm init wired."""
    home = Path.home()
    candidates: list[Path]
    if plat.is_windows:
        candidates = [
            home / "Documents" / "PowerShell" / "profile.ps1",
            home / "Documents" / "WindowsPowerShell" / "profile.ps1",
        ]
    else:
        candidates = [home / ".bashrc", home / ".bash_profile", home / ".zshrc"]
    for path in candidates:
        try:
            if path.exists() and "fnm env" in path.read_text(encoding="utf-8", errors="replace"):
                return True
        except OSError:
            continue
    return False


class FnmTool(BinaryTool):
    name = "fnm"
    binary_name = "fnm"
    cli_help = "Install fnm (Fast Node Manager) and wire its shell init"
    winget_package = "Schniz.fnm"
    brew_package = "fnm"

    def fetch_latest_version(self) -> str:
        try:
            tag = github.latest_release(FNM_REPO)
        except Exception:  # noqa: BLE001
            return ""
        return tag.lstrip("v")

    def get_state(self) -> ToolState:
        # Surface fnm even if its install dir isn't on the current PATH yet.
        augment_path()
        state = super().get_state()
        plat = platform.detect()

        located = find_fnm()
        installed = bool(located)
        if installed and not state.extra.get("binary", {}).get("installed"):
            # ``binary.status`` missed it because PATH didn't cover the install
            # dir — patch the payload so the tool reports as installed.
            state.extra["binary"] = {
                "name": self.binary_name,
                "installed": True,
                "path": located,
                "version": binary.get_version(located, version_arg=self.version_arg) or "",
            }
            state.needs_install = False

        wired = shell_init_wired(plat) if installed else False
        state.extra["shell_init_wired"] = wired
        if installed and not wired:
            # Binary in place but the user's shell still won't pick up node-by-fnm.
            state.needs_update = True
        return state

    def install_linux(self, plat: platform.Platform) -> InstallReport:
        return self._curl_install()

    def install_macos(self, plat: platform.Platform) -> InstallReport:
        # brew_package is set, so install_binary tries brew first and only
        # falls into install_macos when brew is unavailable.
        return self._curl_install()

    def install_windows(self, plat: platform.Platform) -> InstallReport:
        # winget_package is set; this hook fires only when winget is absent.
        return InstallReport(
            error="winget unavailable — install fnm manually: https://fnm.vercel.app",
        )

    def _curl_install(self) -> InstallReport:
        try:
            proc = subprocess.run(
                ["bash", "-c", f"curl -fsSL {FNM_INSTALL_URL} | bash -s -- --skip-shell"],
                capture_output=True,
                text=True,
                check=False,
                timeout=180,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return InstallReport(error=f"fnm installer failed: {exc}")
        if proc.returncode != 0:
            return InstallReport(error=(proc.stderr or proc.stdout).strip()[:500])
        return InstallReport(method="curl|bash")

    def do_install(self) -> InstallReport:
        # Try the package-manager / curl path first.
        report = self.install_binary()
        if report.error:
            return report

        augment_path()
        located = find_fnm()
        if not located:
            return InstallReport(error="fnm not found after install — check $PATH and re-run")

        plat = platform.detect()
        wired = wire_shell_init(plat)

        version = binary.get_version(located, version_arg=self.version_arg)
        report.version = version or report.version
        report.path = located
        report.extra.setdefault("shell_init", wired or "already wired")
        return report

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        wired = bool(state.get("shell_init_wired"))
        icon = "✓" if wired else "✗"
        color = typer.colors.GREEN if wired else typer.colors.YELLOW
        return [(f"{icon} shell init", color)]

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
            return
        line = "fnm installed"
        if report.version:
            line += f" ({report.version})"
        if report.method:
            line += f" via {report.method}"
        typer.echo(line)
        wired = report.extra.get("shell_init")
        if wired:
            label = ", ".join(wired) if isinstance(wired, list) and wired else (wired if wired else "no change")
            typer.echo(f"  shell init: {label}")


_tool = FnmTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()


if __name__ == "__main__":
    cli()
