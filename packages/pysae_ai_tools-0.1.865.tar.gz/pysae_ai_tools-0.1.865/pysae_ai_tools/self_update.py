"""Self-update pysae-ai-tools.

Two modes:
- **Git clone** (editable install): ``git pull`` + re-run ``install.sh``
- **PyPI install** (via uv): ``uv tool upgrade pysae-ai-tools``
"""

import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Annotated

import typer

import pysae_ai_tools

PACKAGE = "pysae-ai-tools"


def _repo_root() -> Path | None:
    """Return the repo root if running from a git checkout, else None."""
    pkg_dir = Path(pysae_ai_tools.__file__).resolve().parent
    candidate = pkg_dir.parent
    if (candidate / ".git").exists() and (candidate / "install.sh").exists():
        return candidate
    return None


def _run(cmd: list[str], cwd: Path | None = None) -> int:
    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    return subprocess.run(cmd, cwd=cwd).returncode


def _update_from_git(repo: Path, no_pull: bool, rebase: bool) -> None:
    """Update from git clone: pull + reinstall."""
    if not no_pull:
        pull_args = ["git", "-C", str(repo), "pull"]
        pull_args.append("--rebase" if rebase else "--ff-only")
        if _run(pull_args) != 0:
            print("FAILED: git pull failed. Resolve manually and retry.", file=sys.stderr)
            sys.exit(1)

    is_windows = os.name == "nt"
    ps1 = repo / "install.ps1"
    sh = repo / "install.sh"

    if is_windows and ps1.exists():
        rc = _run(["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ps1)])
    elif sh.exists():
        rc = _run(["bash", str(sh)])
    else:
        print(f"FAILED: no installer found in {repo}", file=sys.stderr)
        sys.exit(1)

    if rc != 0:
        print("FAILED: installer exited with errors.", file=sys.stderr)
        sys.exit(rc)


def _schedule_windows_deferred_upgrade() -> bool:
    """Spawn a detached cmd that finishes the upgrade after we exit.

    On Windows the running ``pysae-ai-tools.exe`` shim is locked, so
    ``uv tool upgrade`` succeeds at updating the venv but fails to copy
    the new shim onto the old one (os error 32). The bat polls for our
    PID, then re-runs the upgrade, the plugin install, and shell
    completion using the freshly-copied shim.
    """
    if os.name != "nt":
        return False

    pid = os.getpid()
    work_dir = tempfile.mkdtemp(prefix="pysae-update-")
    bat = os.path.join(work_dir, "update.cmd")
    log = os.path.join(work_dir, "update.log")

    lines = [
        "@echo off",
        # UTF-8 codepage so paths with accented characters (e.g. RémiAlvergnat)
        # are interpreted correctly by cmd.
        "chcp 65001 >nul",
        "timeout /t 3 /nobreak >nul",
        ":wait",
        f'tasklist /FI "PID eq {pid}" 2>nul | find "{pid}" >nul',
        "if not errorlevel 1 (",
        "    timeout /t 1 /nobreak >nul",
        "    goto wait",
        ")",
        "timeout /t 1 /nobreak >nul",
        f'uv tool upgrade {PACKAGE} >> "{log}" 2>&1',
        f'pysae-ai-tools tools install claude-plugin >> "{log}" 2>&1',
        f'pysae-ai-tools install-completion >> "{log}" 2>&1',
    ]
    script = "\r\n".join(lines) + "\r\n"
    with open(bat, "w", encoding="utf-8", newline="") as f:
        f.write(script)

    DETACHED_PROCESS = 0x00000008
    CREATE_NO_WINDOW = 0x08000000
    try:
        subprocess.Popen(
            ["cmd", "/c", bat],
            creationflags=DETACHED_PROCESS | CREATE_NO_WINDOW,
            close_fds=True,
        )
    except OSError as exc:
        print(f"Failed to schedule deferred upgrade: {exc}", file=sys.stderr)
        return False

    print(f"Log: {log}", file=sys.stderr)
    return True


def _is_windows_lock_error(stdout: str, stderr: str) -> bool:
    combined = (stdout + stderr).lower()
    return "os error 32" in combined or "ne peut pas accéder au fichier" in combined


def _update_from_pypi() -> None:
    """Update from PyPI via uv tool upgrade."""
    print("Updating from PyPI...", file=sys.stderr)

    cmd = ["uv", "tool", "upgrade", PACKAGE]
    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    result = subprocess.run(cmd, capture_output=True, text=True)
    sys.stdout.write(result.stdout)
    sys.stderr.write(result.stderr)

    if result.returncode != 0:
        # Windows file-lock case: the venv was upgraded but uv couldn't
        # overwrite the running shim. Schedule a deferred re-run.
        if os.name == "nt" and _is_windows_lock_error(result.stdout, result.stderr):
            if _schedule_windows_deferred_upgrade():
                print(
                    "\nScheduled deferred upgrade — will complete a few seconds after this process exits.",
                    file=sys.stderr,
                )
                print(
                    "Wait ~10s before running pysae-ai-tools again.",
                    file=sys.stderr,
                )
                return
        print("FAILED: uv tool upgrade failed.", file=sys.stderr)
        sys.exit(result.returncode)

    # Reinstall Claude Code plugin with the new version
    print("Updating Claude Code plugin...", file=sys.stderr)
    _run(["pysae-ai-tools", "tools", "install", "claude-plugin"])

    # Update shell completion
    from .install_completion import install_completion

    install_completion()


def main(
    no_pull: Annotated[bool, typer.Option("--no-pull", help="Skip git pull (only re-run installer)")] = False,
    rebase: Annotated[bool, typer.Option("--rebase", help="Use 'git pull --rebase' instead of '--ff-only'")] = False,
) -> None:
    """Update pysae-ai-tools to the latest version."""
    # Inherited by every child process we spawn (uv, tools install claude-plugin,
    # install_completion). Suppresses the version-check banner during the
    # update — otherwise the still-cached "Update available" message gets
    # re-printed by sub-invocations before the cache is cleared.
    os.environ["PYSAE_SKIP_VERSION_CHECK"] = "1"

    repo = _repo_root()

    if repo:
        print(f"Git checkout detected at {repo}", file=sys.stderr)
        _update_from_git(repo, no_pull, rebase)
    else:
        _update_from_pypi()

    print("\npysae-ai-tools is up to date.", file=sys.stderr)
