---
name: tools-install
description: >
  Install, update, or reconfigure any Pysae CLI or MCP server
  (aws-cli, node/fnm, glab, gh, kubectl, helm, argocd, docker, terraform,
  prefect, mongo-tools, postman, chrome-mcp, gitlab-mcp, datadog-mcp,
  postman-mcp, mongo-mcp, mongodb-atlas-mcp). Use when the user says
  /tools-install, /install-all, 'install aws', 'install glab',
  'install everything', 'setup my machine', 'install tous les outils',
  'configure tout', 'bootstrap dev env', or any request to install or
  update a CLI/MCP managed by pysae-ai-tools. To only check state
  without installing, prefer the `tools-status` skill.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Thin gateway over `pysae-ai-tools tools install`. All installation, update, version detection, and env-var resolution is handled by the CLI — this skill just drives it and covers the interactive auth steps the CLI cannot automate.

## Commands at a glance

| Goal | Command |
|---|---|
| Install/update every tool | `pysae-ai-tools tools install` |
| Install/update one tool | `pysae-ai-tools tools install <name>` |
| Skip some tools | `pysae-ai-tools tools install --skip docker --skip postman` |
| Prompt for missing env vars | `pysae-ai-tools tools install --interactive` |
| Machine-readable output | add `--json` |

The install run prints three sections:
- **🔑 Environment variables** — one line per auto-resolved var (MCP config or AWS Secrets Manager).
- **🔧 Tools** — one line per tool: `⬆ installed`, `✓ up-to-date`, `⊘ skipped`, or `✗ failed`.
- **📊 Summary** — counts (0-valued buckets omitted).

## Step 1 — Dry-run

Run `pysae-ai-tools tools status --json` first and show the user what would change. Only proceed to install if there is real work (`needs_install` or `needs_update` on at least one tool), or if the user explicitly asked for an install.

## Step 2 — Install

```bash
pysae-ai-tools tools install        # all tools
pysae-ai-tools tools install <name> # one tool
```

Aborts immediately on a `required` tool failure (`aws-cli`, `glab`). Optional tools that fail are logged; the chain continues. MCP servers whose env vars can't be resolved are marked `skipped` without failing the chain.

## Step 3 — Interactive auth (post-install, per tool)

`tools install` only handles binaries and MCP configs. The following steps are **NOT** automated — run them after install when the user needs access.

### aws-cli — SSO login + profile config
```bash
aws configure sso
aws sso login --profile pysae-dev
aws sso login --profile pysae-prod
aws sts get-caller-identity --profile pysae-dev
```

### glab — GitLab token
```bash
glab auth login --hostname gitlab.com
glab auth status
```

### gh — GitHub auth
```bash
gh auth login       # https + browser flow
gh auth status
```

### kubectl — EKS contexts
```bash
aws eks update-kubeconfig --name pysae-dev  --profile pysae-dev  --alias dev
aws eks update-kubeconfig --name pysae-prod --profile pysae-prod --alias prod
kubectl config use-context dev
kubectl get ns
```

### argocd — SSO
```bash
argocd login argocd.dev.pysae.com  --sso --grpc-web
argocd login argocd.prod.pysae.com --sso --grpc-web
argocd context
```

### docker — registry login (GitLab CR + AWS ECR)
```bash
docker login registry.gitlab.com -u "$USER" -p "$(glab auth token 2>/dev/null)"
aws ecr get-login-password --profile pysae-dev --region eu-west-3 \
  | docker login --username AWS --password-stdin 596368530845.dkr.ecr.eu-west-3.amazonaws.com
```

### prefect — Prefect Cloud
```bash
prefect cloud login
prefect profile ls
```

Run the login command in the background (`run_in_background: true`) and tell the user to approve in the browser that just opened. Wait for the background task before confirming success.

## Step 4 — MCP servers requiring secrets

`gitlab-mcp`, `datadog-mcp`, `postman-mcp`, and `mongo-mcp` need env vars. The CLI auto-resolves them when possible:
- `GITLAB_PERSONAL_ACCESS_TOKEN` — pulled from `glab config get token --host gitlab.com` (glab CLI must be authenticated first via `glab auth login --hostname gitlab.com`).
- `DD_API_KEY` / `DD_APP_KEY` / `POSTMAN_API_KEY` — read from existing MCP config in `~/.claude.json` if already installed once.
- `MONGO_URI_DEV` / `MONGO_URI_PROD` — pulled from AWS Secrets Manager (`pysae/{dev,prod}/secrets → api-mongo-uri`); falls back to an existing `mongodb-dev` / `mongodb-prod` MCP entry.
- `mongodb-atlas-mcp` — reads keys directly from AWS Secrets Manager (`pysae/mongodb-atlas/{dev,prod}`). No env vars needed when AWS auth is valid.

If a var still can't be resolved, either pass it inline or use `--interactive`:
```bash
DD_API_KEY=… DD_APP_KEY=… pysae-ai-tools tools install datadog-mcp
pysae-ai-tools tools install --interactive
```

## Step 5 — Verify

```bash
pysae-ai-tools tools status
```

All `required` tools should be `✓ up-to-date`. Optional tools may remain `skipped` (MCP secrets absent) or `failed` (manual-install cases like Docker Desktop on macOS/Windows).

## Order of tools

| # | Tool | Mode | Notes |
|---|---|---|---|
| 1 | aws-cli | required | Auth foundation; kubectl/mongodb-atlas-mcp/env-secret all depend on it |
| 2 | glab | required | Many skills break without it |
| 3 | gh | optional | GitHub CLI |
| 4 | kubectl | optional | Needs aws-cli for EKS auth |
| 5 | helm | optional | Reuses kubeconfig from kubectl |
| 6 | argocd | optional | Pysae dev/prod ArgoCD CLI |
| 7 | docker | optional | Docker Engine (Linux) / Docker Desktop manual (macOS/Windows) |
| 8 | terraform | optional | HashiCorp Terraform |
| 9 | prefect | optional | Prefect CLI via `uv tool install` |
| 10 | mongo-tools | optional | mongosh + mongodump suite |
| 11 | postman | optional | Postman desktop app |
| 12 | chrome-mcp | optional | No env required |
| 13 | gitlab-mcp | skip_on_missing_env | GITLAB_PERSONAL_ACCESS_TOKEN (auto-resolved via `glab config get token --host gitlab.com`) |
| 14 | datadog-mcp | skip_on_missing_env | DD_API_KEY + DD_APP_KEY |
| 15 | postman-mcp | skip_on_missing_env | POSTMAN_API_KEY |
| 16 | mongo-mcp | skip_on_missing_env | MONGO_URI_DEV + MONGO_URI_PROD |
| 17 | mongodb-atlas-mcp | optional | Pulls keys from AWS Secrets Manager |

## Gotchas

- **aws-cli is REQUIRED first.** Its failure aborts the chain.
- **Patch updates install every time.** AWS CLI ships weekly; expect `aws-cli` to report `⬆ installed` often.
- **`up-to-date` ≠ "fully configured".** The CLI checks binary presence and version. SSO sessions, contexts, and registry logins are NOT checked — run Step 3 when the user needs access.
- **Docker on macOS/Windows.** Script reports a manual install message; verify with `docker version` afterwards.
- **Windows install path.** Binaries land in `%LOCALAPPDATA%\Programs\pysae\bin`. Add once: `setx PATH "%PATH%;%LOCALAPPDATA%\Programs\pysae\bin"`.
- **Auto-update config.** `~/.config/pysae-ai-tools/config.toml` controls `auto_update` (default `true`). The CLI self-updates on next run when a newer version is detected.

$ARGUMENTS
