"""Codex Provider Adapter — OpenAI ChatGPT subscription via the official
``@openai/codex`` app-server.

OpenAI officially sanctions third-party harnesses on a ChatGPT
subscription (Altman, 2026-05-02: *"you can sign in to openclaw with
your chatgpt account now and use your subscription there"*). The
sanctioned mechanism — the one OpenClaw uses — is to drive the official
``codex app-server`` binary over local stdio JSON-RPC. The binary owns
OAuth (``~/.codex/auth.json``), token refresh, account identification
and the chatgpt.com transport. We identify as ourselves in the
handshake; no impersonation.

This replaces the previous hand-rolled HTTP client that POSTed directly
to ``chatgpt.com/backend-api/codex/responses``. That reimplementation
got cut off by OpenAI's edge with opaque ``503 upstream connect`` errors
once the backend required traffic through the versioned app-server
protocol. All of the old OAuth/JWT/SSE/refresh machinery is gone — the
binary does it now.

Statefulness: the app-server is thread-stateful (it retains conversation
history server-side per thread). Kestrel's adapter contract is stateless
(full history every call). We bridge by keying a Codex ``threadId`` to
kestrel's stable ``session_id``.

Tool calls: the app-server runs a *server-driven* tool loop —
``dynamicTools`` → server emits ``item/tool/call`` (server→client RPC)
mid-turn, expects an inline reply, then resumes. We bridge that to
kestrel's existing security-gated tool dispatcher via a per-turn
``tool_executor`` callback: every call still fires kestrel's
``PRE_TOOL_USE``/``POST_TOOL_USE`` hooks, ``SecurityHook``, the approval
queue, and denied-tool stripping — exactly as today. The adapter does
no execution itself; it just relays the call into kestrel's hooked
executor and the result back to the app-server.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import (
    Any, AsyncIterator, Awaitable, Callable, Dict, List, Optional, Tuple, Type, Union,
)

from pydantic import BaseModel

from kestrel_sdk.llm import ToolCallStarted

from .adapter import LLMAdapter, LLMResponse, ThinkingDelta, ToolCall
from .codex_app_server import CodexAppServerClient, CodexAppServerError
from .continuation_store import ContinuationStore, InMemoryContinuationStore
from .gpt5_overlay import prepend_gpt5_overlay
from .model_metadata import ModelInfo

logger = logging.getLogger(__name__)

# Signature of the kestrel-side tool executor the orchestrator wires in.
# Returns a dict with at minimum ``success: bool``; ``result`` carries
# the tool's payload (already passed through POST_TOOL_USE hooks).
# Async ``(name, args) -> (effective_args, result)``. The kestrel-side
# wrapper returns the post-hook args alongside the result so the
# adapter can record the *actually-executed* arguments into audit /
# UI breadcrumbs — pre-hook args may carry values a PRE_TOOL_USE
# redactor intentionally stripped.
ToolExecutor = Callable[
    [str, Dict[str, Any]],
    Awaitable[Tuple[Dict[str, Any], Any]],
]


def _extract_instructions_and_input(messages):
    """Split messages into instructions (system prompt) and the rest."""
    instructions = None
    input_messages = []
    for msg in messages:
        if msg.get("role") == "system":
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    p.get("text", "") for p in content
                    if isinstance(p, dict) and p.get("type") == "text"
                )
            instructions = content
        else:
            input_messages.append(msg)
    return instructions, input_messages


# Codex dynamicTool namespace for kestrel tools. The codex app-server
# has its own native tool surface (``spawn_agent``, ``shell``,
# ``apply_patch``, ``web_search``, ``read_file``, …) registered in a
# process-global handler registry inside ``codex_core``. Advertising a
# dynamicTool with the same name but no namespace collides with codex's
# own — the second registration panics with
# ``handler for tool <name> already registered`` and the app-server
# exits. Kestrel hit this with the SpawnFeature (``spawn_agent``,
# ``core = true`` in feature_registry.toml) as soon as a session
# triggered a second ``thread/start`` (model switch / config change
# / fingerprint mismatch).
#
# OpenClaw solves the same class of collision by namespacing every
# dynamicToolSpec under ``"openclaw"`` (kestrel-claw
# extensions/codex/src/app-server/dynamic-tools.ts:64). We follow the
# same pattern with ``"kestrel"``. The codex protocol's
# ``CodexDynamicToolCallParams`` carries ``namespace`` back to us on
# every ``item/tool/call``; the tool ``name`` field stays as-is, so
# kestrel-side dispatch via ``execute_named_tool`` continues to work
# without a stripping step.
_KESTREL_TOOL_NAMESPACE = "kestrel"


def _convert_tools_to_codex_dynamic_tools(tools):
    """Convert OpenAI function-tool defs to the app-server's
    ``CodexDynamicToolSpec`` shape: ``{name, description, inputSchema,
    namespace}``.

    The field name diverges from the Responses-API ``parameters`` and the
    wrapper ``{"type":"function", "function":{…}}`` is dropped — the
    app-server tool spec is its own protocol (see ``protocol.ts:67-71``
    in ``kestrel-claw/extensions/codex``).

    ``namespace`` is set to ``"kestrel"`` on every entry so our tools
    register in their own slot inside ``codex_core``'s tool handler
    registry, avoiding collisions with codex-native built-ins (most
    visibly ``spawn_agent``, which kestrel also exposes via the
    SpawnFeature).
    """
    if not tools:
        return None
    out = []
    for tool in tools:
        if tool.get("type") == "function":
            func = tool["function"]
            out.append({
                "name": func["name"],
                "description": func.get("description", ""),
                "inputSchema": func.get("parameters", {"type": "object"}),
                "namespace": _KESTREL_TOOL_NAMESPACE,
            })
    return out or None


def _msg_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            p.get("text", "") for p in content
            if isinstance(p, dict) and p.get("type") in ("text", "input_text")
        )
    return "" if content is None else str(content)


def _build_turn_input(input_messages: List[Dict[str, Any]], *, fresh_thread: bool) -> str:
    """Text to send for this turn.

    Existing thread: only the latest user message (server holds history).
    Fresh thread with prior history: seed a compact transcript so context
    isn't lost, then the latest user message.
    """
    last_user_idx = None
    for i in range(len(input_messages) - 1, -1, -1):
        if input_messages[i].get("role") == "user":
            last_user_idx = i
            break
    latest = (
        _msg_text(input_messages[last_user_idx]["content"])
        if last_user_idx is not None else ""
    )
    if not fresh_thread or last_user_idx in (None, 0):
        return latest
    lines = []
    for m in input_messages[:last_user_idx]:
        role = m.get("role", "user")
        txt = _msg_text(m.get("content"))
        if m.get("role") == "assistant" and m.get("tool_calls"):
            calls = ", ".join(
                tc.get("function", {}).get("name", "?") for tc in m["tool_calls"]
            )
            txt = (txt + f" [called tools: {calls}]").strip()
        if txt:
            lines.append(f"{role}: {txt}")
    if not lines:
        return latest
    return (
        "Conversation so far (for context):\n"
        + "\n".join(lines)
        + f"\n\nCurrent message:\n{latest}"
    )


def _usage_from(tu: dict) -> Dict[str, Optional[int]]:
    total = (tu or {}).get("total", {}) or {}
    inp = total.get("inputTokens")
    out = total.get("outputTokens")
    tot = total.get("totalTokens")
    if tot is None and (inp is not None or out is not None):
        tot = (inp or 0) + (out or 0)
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": tot,
        "cache_read_input_tokens": total.get("cachedInputTokens"),
    }


# Item types the app-server emits for a "the model invoked a tool" lifecycle.
# These all surface tool activity to the user — whether they ran inside the
# app-server (commandExecution, fileChange, webSearch) or were dispatched
# back to kestrel via item/tool/call (dynamicToolCall, mcpToolCall,
# functionCall, customToolCall). The chat-UI activity parser keys on the
# 🔧 / ✓ / ❌ marker lines we yield as TEXT for each of these — same wire
# protocol the orchestrator-dispatched path uses (see
# ``orchestrator_engine._stream_with_tools`` line "Calling {tc.name}...").
_TOOL_ITEM_TYPES = frozenset({
    "dynamicToolCall", "mcpToolCall", "functionCall", "function_call",
    "toolCall", "customToolCall",
    "commandExecution", "fileChange", "webSearch",
})

# These item types resolve to an inline kestrel tool-call (via the
# ``item/tool/call`` server→client RPC). They MUST be tracked in
# ``executed_tool_calls`` so the orchestrator can fold them into the
# persisted chat-history breadcrumbs. Other tool item types
# (commandExecution, fileChange, webSearch) run INSIDE the app-server's
# native sandbox — kestrel's hook stack never sees them, so they appear
# only as on-screen markers, never as executed_tool_calls entries.
_KESTREL_DISPATCHED_TOOL_ITEM_TYPES = frozenset({
    "dynamicToolCall", "mcpToolCall", "functionCall", "function_call",
    "toolCall", "customToolCall",
})


def _item_display_label(item: Dict[str, Any]) -> str:
    """Human label for an item/started or item/completed marker.

    Tools dispatched back to kestrel use the tool name; codex-native
    items (commandExecution, fileChange) use a stable short label so the
    chat-UI parser groups successive output lines under one card.
    """
    itype = item.get("type") or ""
    if itype == "commandExecution":
        return "shell"
    if itype == "fileChange":
        return "apply_patch"
    if itype == "webSearch":
        return "web_search"
    return item.get("name") or item.get("tool") or itype or "tool"


def _format_command_summary(command: Any) -> Optional[str]:
    """One-line preview of a shell command for the start marker.

    Strings stay as-is (truncated); list shapes (``["bash","-lc","..."]``)
    are joined with spaces so the user sees the actual command, not a
    JSON literal. Returns ``None`` when there is nothing worth showing.
    """
    if isinstance(command, str):
        text = command
    elif isinstance(command, list):
        text = " ".join(str(c) for c in command if c is not None)
    else:
        return None
    text = text.strip()
    if not text:
        return None
    # Single-line, capped — fits one marker line in chat without
    # collapsing a multi-line heredoc into noise.
    text = text.replace("\n", " ").replace("\r", " ")
    if len(text) > 200:
        text = text[:197] + "..."
    return text


def _result_to_codex_response(result: Any) -> Dict[str, Any]:
    """Marshal a kestrel tool result into the codex
    ``CodexDynamicToolCallResponse`` shape.

    Kestrel tool dispatchers conventionally return a dict with
    ``success: bool`` and either ``result`` (payload) or ``error`` (msg).
    Anything else is best-effort serialized.
    """
    if isinstance(result, dict):
        success = bool(result.get("success", True))
        if success and "result" in result:
            text = result["result"]
        elif "error" in result:
            text = result["error"]
        else:
            text = result
    else:
        success = True
        text = result
    if not isinstance(text, str):
        try:
            text = json.dumps(text, default=str)
        except Exception:
            text = str(text)
    return {
        "contentItems": [{"type": "inputText", "text": text}],
        "success": success,
    }


class CodexAdapter(LLMAdapter):
    """OpenAI ChatGPT-subscription adapter backed by the codex app-server."""

    def __init__(self, continuation_store: Optional[ContinuationStore] = None):
        self.name = "openai_plan"
        # Accepted for API stability; the app-server owns continuity via
        # server-side threads, so it is not used for replay anymore.
        self._continuation_store: ContinuationStore = (
            continuation_store if continuation_store is not None
            else InMemoryContinuationStore()
        )
        self._client: Optional[CodexAppServerClient] = None
        # session_id → (thread_id, fingerprint). The fingerprint guards
        # against silently reusing a thread whose initial config (model,
        # system prompt, tool set) no longer matches what the caller is
        # asking for — those settings only take effect at thread/start,
        # so a mismatch must force a fresh thread (loses server-side
        # history for that session, same posture as OpenClaw's
        # ``dynamicToolsFingerprint`` reset).
        self._session_threads: Dict[str, Tuple[str, str]] = {}
        # Per-session lock for ``_ensure_thread`` lookup-or-create — two
        # concurrent first calls on the same session_id would otherwise
        # both call thread/start and race to overwrite the cache,
        # leaving one thread orphaned with whichever turn was mid-flight.
        self._session_locks: Dict[str, "asyncio.Lock"] = {}
        # Per-thread serialization: the codex app-server allows only one
        # active turn per thread. Two concurrent ``_run_turn`` calls on
        # the same thread (same session_id) would race on the turn-sink
        # registration; the lock makes them queue cleanly instead.
        self._thread_locks: Dict[str, "asyncio.Lock"] = {}

    # ----------------------------------------------------------- app-server glue
    def _app_server(self) -> CodexAppServerClient:
        if self._client is None:
            self._client = CodexAppServerClient()
        return self._client

    @staticmethod
    def _model_param(model: str) -> Optional[str]:
        # The route's configured model is often "auto"; the app-server
        # rejects that. Omit so it uses the subscription default.
        if not model or model in ("auto", "default"):
            return None
        return model

    @staticmethod
    def _thread_fingerprint(
        model_param: Optional[str], instructions: Optional[str],
        dynamic_tools: Optional[List[Dict[str, Any]]],
    ) -> str:
        """Stable hash of every thread-scoped setting the app-server
        only consumes at thread/start. Used to invalidate a cached
        thread when the caller asks for different model/instructions/
        tools — those changes are otherwise silently ignored."""
        import hashlib

        payload = json.dumps(
            {
                "m": model_param or "",
                "i": instructions or "",
                "t": dynamic_tools or [],
            },
            sort_keys=True, separators=(",", ":"), default=str,
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    async def _ensure_thread(
        self, app: CodexAppServerClient, session_id: Optional[str],
        model: str, instructions: Optional[str],
        dynamic_tools: Optional[List[Dict[str, Any]]],
    ) -> Tuple[str, bool]:
        """Return ``(thread_id, is_fresh)`` for this session.

        ``dynamic_tools`` (codex spec shape) are registered at
        ``thread/start`` per the kestrel-claw reference — turn-level
        registration is a documented protocol option but not what
        OpenClaw uses, and empirically the model only sees tools when
        they're declared at the thread level.

        On a session whose cached thread was built with different
        model/instructions/tools, start a fresh thread (the app-server
        won't apply those changes to an existing thread). This loses
        server-side history for the session at that boundary —
        unavoidable given the protocol; mirrors OpenClaw's fingerprint
        reset behaviour.
        """
        m = self._model_param(model)
        fingerprint = self._thread_fingerprint(m, instructions, dynamic_tools)

        # Per-session lock; bare path for session-less calls (each
        # ephemeral thread is independent — no race possible).
        if session_id:
            lock = self._session_locks.setdefault(session_id, asyncio.Lock())
            await lock.acquire()
        else:
            lock = None
        try:
            if session_id and session_id in self._session_threads:
                cached_id, cached_fp = self._session_threads[session_id]
                if cached_fp == fingerprint:
                    return cached_id, False
                logger.info(
                    "codex session %s thread config changed (%s → %s); "
                    "starting fresh thread",
                    session_id, cached_fp, fingerprint,
                )
                # Cached thread no longer matches; drop it.
                self._session_threads.pop(session_id, None)
            # cwd: codex's native shell tool runs `cd` and resolves relative
            # paths against the thread cwd, not the process cwd. Without
            # this, ``pwd`` inside a shell tool returns whatever directory
            # the kestrel process happened to start in (often the install
            # prefix). Anchor the thread to the user's current working
            # directory so file lookups behave like an editor session.
            # ``KESTREL_CODEX_CWD`` overrides for daemon/agent runtimes
            # where ``Path.cwd()`` may not match the intended workspace.
            cwd = os.environ.get("KESTREL_CODEX_CWD") or str(Path.cwd())
            params: Dict[str, Any] = {"sandbox": "read-only", "cwd": cwd}
            if m:
                params["model"] = m
            if instructions:
                params["developerInstructions"] = instructions
            if dynamic_tools:
                params["dynamicTools"] = dynamic_tools
            result = await app.request("thread/start", params, timeout=60)
            thread_id = (result or {}).get("thread", {}).get("id")
            if not thread_id:
                raise CodexAppServerError(
                    f"thread/start returned no thread id: {result!r}"
                )
            if session_id:
                self._session_threads[session_id] = (thread_id, fingerprint)
            return thread_id, True
        finally:
            if lock is not None:
                lock.release()

    def _make_tool_call_handler(
        self, executor: ToolExecutor, thread_id: str,
        allowed_tools: frozenset,
        executed_log: Optional[List[Dict[str, Any]]] = None,
    ) -> Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]:
        """Wrap ``executor`` into an app-server ``item/tool/call``
        handler scoped to this turn's thread.

        Defenses:

        * ``threadId`` mismatch → reject (server-request handlers are
          keyed by method+thread; a stray callback for another turn
          must not execute against the wrong session).
        * ``tool`` name not in ``allowed_tools`` → reject. The advertised
          dynamic-tool set for this turn is the only thing the executor
          should run; a hallucinated/malformed tool name could otherwise
          resolve through the orchestrator's full registry, bypassing
          per-turn restrictions (denied-tool stripping, capability
          gating).

        ``executed_log`` (optional): each successful execution appends
        ``{id, name, arguments, result}`` so callers can surface the
        same chat-history breadcrumbs the orchestrator-dispatched path
        produces. ``id`` is the app-server's own ``callId`` so audit
        trails align with codex-side ids.
        """

        async def handler(params: Dict[str, Any]) -> Dict[str, Any]:
            if params.get("threadId") != thread_id:
                return {
                    "contentItems": [{
                        "type": "inputText",
                        "text": "tool call belonged to a different turn",
                    }],
                    "success": False,
                }
            name = params.get("tool") or params.get("name") or ""
            if name not in allowed_tools:
                logger.warning(
                    "codex requested tool %r not in advertised set %s; "
                    "refusing dispatch", name, sorted(allowed_tools),
                )
                return {
                    "contentItems": [{
                        "type": "inputText",
                        "text": (
                            f"tool {name!r} not advertised for this turn"
                        ),
                    }],
                    "success": False,
                }
            args = params.get("arguments") or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except ValueError:
                    args = {"_raw": args}
            call_id = params.get("callId") or params.get("id") or ""
            # The executor returns (effective_args, result) — effective
            # args are what actually ran after PRE_TOOL_USE hooks, so
            # the breadcrumb reflects the redacted/rewritten payload,
            # not the model's pre-hook arguments.
            effective_args: Dict[str, Any] = (
                args if isinstance(args, dict) else {}
            )
            try:
                ret = await executor(name, args)
            except Exception as e:
                logger.warning("tool_executor(%s) raised: %s", name, e)
                err_result = {"success": False, "error": f"{e}"}
                # Failed inline tool calls must remain observable —
                # mirrors the orchestrator-dispatched path, which
                # records error results in tool_results/tool_events.
                if executed_log is not None:
                    executed_log.append({
                        "id": call_id, "name": name,
                        "arguments": effective_args,
                        "result": err_result,
                    })
                return {
                    "contentItems": [{
                        "type": "inputText",
                        "text": f"tool {name!r} failed: {e}",
                    }],
                    "success": False,
                }
            # Real orchestrator-side executor returns (effective_args,
            # result). Permissive: simpler tools/tests may return just
            # the result — in which case effective_args == args.
            if (
                isinstance(ret, tuple) and len(ret) == 2
                and isinstance(ret[0], dict)
            ):
                effective_args, result = ret
            else:
                result = ret
            if executed_log is not None:
                executed_log.append({
                    "id": call_id, "name": name,
                    "arguments": effective_args,
                    "result": result,
                })
            return _result_to_codex_response(result)

        return handler

    async def _run_turn(
        self, model: str, messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]], session_id: Optional[str],
        tool_executor: Optional[ToolExecutor],
    ) -> AsyncIterator[dict]:
        """Drive one turn; yield normalized events:

        ``{"text": str}`` | ``{"thinking": str}`` |
        ``{"tool_call": ToolCall}`` | ``{"final": (text, [ToolCall], usage)}``
        """
        app = self._app_server()
        await app.ensure_started()
        instructions, input_messages = _extract_instructions_and_input(messages)
        # Nothing in the LLM pipeline calls contribute_system_prompt for
        # us — the adapter owns it (regresses the GPT-5 <persona_latch>
        # overlay otherwise).
        instructions = self.contribute_system_prompt(model, instructions)
        # Sanctioned subscription model + tools requires a hook-enforcing
        # executor (the app-server runs an inline tool loop). Without
        # one, the model would request tools and we'd have no safe way
        # to run them — fail loud rather than silently decline + corrupt
        # the loop.
        dyn = _convert_tools_to_codex_dynamic_tools(tools)
        if dyn and tool_executor is None:
            # The app-server runs tools inline mid-turn via item/tool/call;
            # without a kestrel-side executor wired through the orchestrator
            # we'd have no safe way to honor that callback. The only caller
            # that supplies tools today is the orchestrator (which always
            # passes ``tool_executor`` per ``_make_inline_tool_executor``).
            # If you're hitting this from anywhere else, route that
            # tool-using call through the orchestrator path, or pick
            # ``openai:api`` (the standard stateless interface composes
            # with kestrel's tool model directly).
            raise CodexAppServerError(
                "openai:plan (codex app-server) requires a tool_executor "
                "callback when tools are provided — orchestrator-driven "
                "dispatch only. For non-orchestrator tool-using callers, "
                "use openai:api or thread an executor through "
                "generate_with_messages / stream_with_tool_detection."
            )
        thread_id, fresh = await self._ensure_thread(
            app, session_id, model, instructions, dyn,
        )
        turn_input = _build_turn_input(input_messages, fresh_thread=fresh)

        # Serialize per-thread: the app-server runs one active turn per
        # thread; concurrent ``_run_turn`` calls that share a thread
        # (same session_id) must not race on the turn-sink / handler
        # registrations. ``setdefault`` keeps lock identity stable.
        lock = self._thread_locks.setdefault(thread_id, asyncio.Lock())
        await lock.acquire()

        # Per-turn record of every inline-executed tool call. Surfaced
        # on the final LLMResponse so the orchestrator can render
        # chat-history breadcrumbs generically (any adapter that runs
        # tools inline uses this same channel).
        executed_log: List[Dict[str, Any]] = []
        unregister = None
        if tool_executor is not None and dyn:
            # Only register an item/tool/call handler when tools were
            # actually advertised this turn. A handler on a text-only
            # turn would be a footgun — an unsolicited or hallucinated
            # tool request from the app-server could otherwise execute
            # against the orchestrator's full tool registry, bypassing
            # the per-turn restriction. Combined with the allow-set
            # check inside the handler, this is defense in depth.
            allowed_tools = frozenset(t["name"] for t in dyn if t.get("name"))
            # Thread-scoped registration: concurrent turns on different
            # threads each get their own ``item/tool/call`` handler and
            # the dispatcher routes by ``params.threadId``. Without
            # scoping, a second turn's registration would silently
            # overwrite an in-flight turn's handler.
            unregister = app.register_server_request_handler(
                "item/tool/call",
                self._make_tool_call_handler(
                    tool_executor, thread_id, allowed_tools, executed_log,
                ),
                thread_id=thread_id,
            )

        sink = app.open_turn_sink(thread_id)
        try:
            # dynamicTools are registered at thread/start (above); turn/start
            # only carries the user input.
            await app.request("turn/start", {
                "threadId": thread_id,
                "input": [{"type": "text", "text": turn_input}],
            }, timeout=60)

            text_parts: List[str] = []
            final_text: Optional[str] = None
            tool_calls: List[ToolCall] = []
            usage: Dict[str, Optional[int]] = {}
            seen_tool_ids: set = set()
            # Tool items the user has seen a "🔧 Calling X..." line for.
            # We dedupe BOTH on start and on complete so retries or
            # split-event quirks can't produce a stray marker line that
            # the chat-UI parser would group into a phantom card.
            started_item_ids: set = set()
            completed_item_ids: set = set()

            async for ev in app.iter_turn_events(sink):
                method = ev.get("method")
                p = ev.get("params") or {}
                if method == "item/agentMessage/delta":
                    delta = p.get("delta") or ""
                    if delta:
                        text_parts.append(delta)
                        yield {"text": delta}
                elif method in (
                    "item/reasoning/textDelta",
                    "item/reasoning/summaryTextDelta",
                ):
                    d = p.get("delta") or ""
                    if d:
                        yield {"thinking": d}
                elif method == "item/started":
                    # Tool activity marker for the chat-UI parser. Fires
                    # BEFORE the kestrel-dispatched ``item/tool/call`` RPC
                    # AND before codex-native tool execution
                    # (commandExecution / fileChange / webSearch), so the
                    # user sees "🔧 Calling X..." right as codex commits
                    # to using the tool — same UX timing as the
                    # orchestrator-dispatched path (which yields the same
                    # marker shape immediately after a tool_calls
                    # detection).
                    item = p.get("item") or {}
                    itype = item.get("type") or ""
                    iid = item.get("id") or item.get("callId") or ""
                    # Only dedupe when the protocol gives us an id;
                    # falling back to ``""`` would collapse every
                    # id-less item into one dedupe slot and silently
                    # drop subsequent start markers (codex P2).
                    already_started = bool(iid) and iid in started_item_ids
                    if itype in _TOOL_ITEM_TYPES and not already_started:
                        if iid:
                            started_item_ids.add(iid)
                        label = _item_display_label(item)
                        # Shell items get a one-line command preview so
                        # the user sees what's running, not just "shell"
                        # — codex's native shell is the dominant tool in
                        # this surface, and a bare "shell" marker is the
                        # bulk of what made the chat feel opaque in
                        # Nellie's session.
                        detail = (
                            _format_command_summary(item.get("command"))
                            if itype == "commandExecution" else None
                        )
                        line = (
                            f"\U0001f527 Calling {label}: {detail}...\n"
                            if detail else f"\U0001f527 Calling {label}...\n"
                        )
                        # NOT appended to ``text_parts`` — those rebuild
                        # ``LLMResponse.content`` as a clean string when
                        # the app-server doesn't deliver an agentMessage
                        # item/completed. Wire markers leaking into
                        # ``content`` would surface as literal "🔧"
                        # characters in audit logs, narration checks,
                        # and any non-chat reader of the response.
                        yield {"text": line}
                elif method == "item/completed":
                    item = p.get("item") or {}
                    itype = item.get("type")
                    iid = item.get("id") or item.get("callId") or ""
                    if itype == "agentMessage":
                        final_text = item.get("text") or final_text
                    elif itype in _TOOL_ITEM_TYPES:
                        # Completion marker. Emit even if we missed the
                        # paired item/started (some app-server builds
                        # collapse start+complete for very fast items)
                        # — without a completion line the chat-UI parser
                        # leaves the card in a "running" state forever.
                        # Same dedupe carve-out as item/started: only
                        # gate on iid when one was supplied; missing-id
                        # items always emit so they're not collapsed
                        # into a single phantom (codex P2).
                        already_completed = bool(iid) and iid in completed_item_ids
                        if already_completed:
                            # Defensive: never two ✓ lines for one item.
                            pass
                        else:
                            if iid:
                                completed_item_ids.add(iid)
                            label = _item_display_label(item)
                            status = (
                                item.get("status")
                                or item.get("state")
                                or ""
                            )
                            failed = (
                                isinstance(status, str)
                                and status.lower() in ("failed", "error", "blocked")
                            ) or bool(item.get("error"))
                            line = (
                                f"❌ {label} failed\n"
                                if failed
                                else f"✓ {label} complete\n"
                            )
                            # See start-marker note: NOT appended to
                            # ``text_parts``; markers stay on the wire,
                            # not in LLMResponse.content.
                            yield {"text": line}
                        # The kestrel-dispatched subset additionally
                        # surfaces ToolCallStarted for the honesty-layer
                        # revising sentinel + populates the executed_log
                        # the orchestrator folds into chat history. The
                        # codex-native subset (shell/patch/web) stays
                        # marker-only — those execute inside the
                        # app-server and have no kestrel-side audit row.
                        if itype in _KESTREL_DISPATCHED_TOOL_ITEM_TYPES:
                            # See dedupe carve-out above. The
                            # ``ToolCallStarted`` honesty-layer signal
                            # MUST fire per tool — collapsing two
                            # id-less calls into one would silently
                            # break narration auditing.
                            if iid and iid in seen_tool_ids:
                                continue
                            if iid:
                                seen_tool_ids.add(iid)
                            raw_args = item.get("arguments")
                            if isinstance(raw_args, str):
                                try:
                                    raw_args = json.loads(raw_args)
                                except ValueError:
                                    raw_args = {"_raw": raw_args}
                            tc = ToolCall(
                                id=iid,
                                name=item.get("name") or item.get("tool") or "",
                                arguments=(
                                    raw_args if isinstance(raw_args, dict) else {}
                                ),
                            )
                            # Critical: the app-server has ALREADY executed
                            # this tool inline via our item/tool/call handler.
                            # Yield ToolCallStarted for UI/honesty-layer
                            # signaling, but DO NOT add to ``tool_calls`` —
                            # surfacing it would make the orchestrator
                            # re-dispatch through ``_execute_tool_batch`` and
                            # duplicate every tool's side effects.
                            yield {"tool_call": tc}
                elif method == "thread/tokenUsage/updated":
                    usage = _usage_from(p.get("tokenUsage") or {})
                elif method == "turn/failed":
                    err = p.get("error") or p.get("turn", {}).get("error") or {}
                    raise CodexAppServerError(
                        f"codex turn failed: "
                        f"{err.get('message') or err or 'unknown'}"
                    )
                # turn/completed terminates iter_turn_events.

            content = final_text if final_text is not None else "".join(text_parts)
            yield {
                "final": (content or None, tool_calls or None, usage),
                # The orchestrator reads this via getattr(response,
                # "executed_tool_calls", None) and produces standard
                # chat-history breadcrumbs from it.
                "executed": list(executed_log),
            }
        finally:
            app.close_turn_sink(thread_id)
            if unregister is not None:
                unregister()
            lock.release()

    # --------------------------------------------------------------- public API
    async def get_response(
        self,
        client: Any,
        model: str,
        messages: List[Dict[str, Any]],
        format: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        response_format: Optional[Type[BaseModel]] = None,
        **kwargs,
    ) -> LLMResponse:
        session_id = kwargs.get("session_id")
        tool_executor = kwargs.get("tool_executor")
        content: Optional[str] = None
        tool_calls: Optional[List[ToolCall]] = None
        usage: Dict[str, Optional[int]] = {}
        executed: List[Dict[str, Any]] = []
        async for ev in self._run_turn(
            model, messages, tools, session_id, tool_executor
        ):
            if "final" in ev:
                content, tool_calls, usage = ev["final"]
                executed = ev.get("executed") or []
        resp = LLMResponse(
            content=content,
            tool_calls=tool_calls,
            input_tokens=usage.get("input_tokens"),
            output_tokens=usage.get("output_tokens"),
            total_tokens=usage.get("total_tokens"),
            cache_read_input_tokens=usage.get("cache_read_input_tokens"),
        )
        # Attach inline-executed tool record as a runtime attribute. The
        # SDK ``LLMResponse`` dataclass is not frozen, so this is a
        # legal (if currently undocumented) extension. A follow-up SDK
        # release will formalize ``executed_tool_calls`` as a typed
        # field; the orchestrator already reads via ``getattr`` so the
        # typed upgrade is a no-op behaviorally.
        if executed:
            resp.executed_tool_calls = executed
        return resp

    async def get_streaming_response(
        self,
        client: Any,
        model: str,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        response_format: Optional[Type[BaseModel]] = None,
        **kwargs,
    ) -> AsyncIterator[Union[str, ThinkingDelta]]:
        session_id = kwargs.get("session_id")
        # Tools intentionally not passed: text-only streaming surface.
        async for ev in self._run_turn(model, messages, None, session_id, None):
            if "text" in ev:
                yield ev["text"]
            elif "thinking" in ev:
                yield ThinkingDelta(ev["thinking"], provider="codex")

    async def get_streaming_response_with_tools(
        self,
        client: Any,
        model: str,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        response_format: Optional[Type[BaseModel]] = None,
        **kwargs,
    ) -> AsyncIterator[Union[str, ThinkingDelta, ToolCallStarted, LLMResponse]]:
        session_id = kwargs.get("session_id")
        tool_executor = kwargs.get("tool_executor")
        idx = 0
        async for ev in self._run_turn(
            model, messages, tools, session_id, tool_executor
        ):
            if "text" in ev:
                yield ev["text"]
            elif "thinking" in ev:
                yield ThinkingDelta(ev["thinking"], provider="codex")
            elif "tool_call" in ev:
                tc = ev["tool_call"]
                yield ToolCallStarted(idx, tc.id or None, tc.name or None)
                idx += 1
            elif "final" in ev:
                content, tcs, usage = ev["final"]
                resp = LLMResponse(
                    content=content,
                    tool_calls=tcs,
                    input_tokens=usage.get("input_tokens"),
                    output_tokens=usage.get("output_tokens"),
                    total_tokens=usage.get("total_tokens"),
                    cache_read_input_tokens=usage.get("cache_read_input_tokens"),
                )
                executed = ev.get("executed") or []
                if executed:
                    resp.executed_tool_calls = executed
                yield resp

    async def list_models(self, client: Any = None) -> List[ModelInfo]:
        """Model discovery is the canonical openai provider's job.

        Kept as ``NotImplementedError`` (unchanged contract): the plan
        route deliberately defers its catalog to ``openai:api``.
        """
        raise NotImplementedError(
            "OpenAI plan model discovery is provided by the canonical openai provider."
        )

    def contribute_system_prompt(
        self, model_id: str, base: Optional[str]
    ) -> Optional[str]:
        return prepend_gpt5_overlay(base, model_id)

    def cost_per_1m_tokens(self) -> Optional[Dict[str, float]]:
        return {"input": 0.0, "output": 0.0}

    def substrate_type(self) -> Optional[str]:
        return "gpt"

    def display_name(self) -> Optional[str]:
        return "OpenAI Codex (plan)"

    def key_env_var(self) -> Optional[str]:
        # Auth is delegated to the codex binary's ~/.codex/auth.json.
        return None

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
