"""Busca híbrida com expansão por grafo normativo."""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager
from ..utils.output import (
    extract_credits,
    extract_request_id,
    get_evidence_links,
    print_credits_footer,
    print_request_id_footer,
    render_evidence_lines_text,
    render_llm_output,
    resolve_output_format,
)

console = Console()
config_manager = ConfigManager()


def hybrid(
    query: str = typer.Argument(..., help="Pergunta jurídica"),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Quantidade de resultados (1-50)"),
    hops: int = typer.Option(1, "--hops", help="Saltos no grafo normativo (1 ou 2)"),
    graph_expansion: str = typer.Option(
        "bidirectional", "--graph-expansion",
        help="Tipo de expansão: bidirectional ou forward",
    ),
    token_budget: int = typer.Option(None, "--token-budget", help="Limite de tokens para contexto"),
    show_stats: bool = typer.Option(
        False, "--show-stats",
        help="Mostra estatísticas de expansão (seeds, graph_nodes, tokens) no rodapé"
    ),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json, text, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca semântica + expansão por grafo de citações normativas.

    Combina busca vetorial com navegação por relações entre normas via grafo.
    Ideal para encontrar artigos relacionados que citam ou são citados pelo resultado.

    Exemplo:
        vectorgov hybrid "Critérios de julgamento em licitações"
        vectorgov hybrid "Dispensa de licitação" --hops 2 --top-k 15
        vectorgov hybrid "ETP" --show-stats             # inclui estatisticas
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if top_k < 1 or top_k > 50:
            console.print("[red]Erro:[/red] --top-k deve estar entre 1 e 50.")
            raise typer.Exit(1)

        if hops not in (1, 2):
            console.print("[red]Erro:[/red] --hops deve ser 1 ou 2.")
            raise typer.Exit(1)

        if graph_expansion not in ("bidirectional", "forward"):
            console.print("[red]Erro:[/red] --graph-expansion deve ser 'bidirectional' ou 'forward'.")
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        hybrid_kwargs = dict(query=query, top_k=top_k, hops=hops, graph_expansion=graph_expansion)
        if token_budget is not None:
            hybrid_kwargs["token_budget"] = token_budget

        with console.status("[bold]Buscando com expansão por grafo...[/bold]"):
            result = vg.hybrid(**hybrid_kwargs)

        # hits = direct_evidence do SDK (seeds da busca semântica). Se vazio,
        # usa graph_nodes como fallback (expansão via grafo com score>0).
        direct_hits = list(result.hits) if hasattr(result, "hits") else list(result)
        graph_hits = list(getattr(result, "graph_nodes", []) or [])
        hits = direct_hits if direct_hits else graph_hits

        if effective_output == "raw":
            # Safe serializer for stats dict
            raw_stats = {}
            stats_obj = getattr(result, "stats", None)
            if stats_obj is not None:
                if isinstance(stats_obj, dict):
                    raw_stats = stats_obj
                elif hasattr(stats_obj, "__dict__"):
                    raw_stats = {k: v for k, v in stats_obj.__dict__.items()
                                 if not k.startswith("_")}

            graph_nodes_raw = []
            for gn in getattr(result, "graph_nodes", []):
                graph_nodes_raw.append({
                    "text": getattr(gn, "text", ""),
                    "hop": getattr(gn, "hop", 0),
                    "source": getattr(gn, "source", ""),
                    "frequency": getattr(gn, "frequency", 0),
                    "node_id": getattr(gn, "node_id", ""),
                    "span_id": getattr(gn, "span_id", ""),
                    **get_evidence_links(gn),
                })

            data = {
                "query": query,
                "total": len(hits),
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result),
                "latency_ms": getattr(result, "latency_ms", None),
                "cached": getattr(result, "cached", None),
                "hits": [
                    {
                        "text": h.text,
                        "source": getattr(h, "source", ""),
                        "score": getattr(h, "score", 0),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        "is_graph_expanded": getattr(h, "is_graph_expanded", False),
                        "hop": getattr(h, "hop", 0),
                        **get_evidence_links(h),
                    }
                    for h in hits
                ],
                "graph_nodes": graph_nodes_raw,
                "stats": raw_stats,
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if effective_output == "llm":
            metadata = {
                "total": len(hits),
                "latency_ms": getattr(result, "latency_ms", None),
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            print(render_llm_output(hits, query, metadata))
            return

        if output == "json":
            data = [
                {
                    "source": getattr(h, "source", ""),
                    "score": getattr(h, "score", 0),
                    "text": h.text,
                    "graph": getattr(h, "is_graph_expanded", False),
                }
                for h in hits
            ]
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"Busca Híbrida ({len(hits)} resultados)")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Texto", overflow="fold")
            table.add_column("Score", justify="right", width=6)
            table.add_column("Grafo", width=5)
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                score = getattr(h, "score", 0)
                text = h.text
                graph = "+" if getattr(h, "is_graph_expanded", False) else ""
                table.add_row(
                    str(i), source, text, f"{score:.2f}" if score else "-", graph
                )
            console.print(table)
        else:
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                graph_tag = (
                    " [yellow][grafo][/yellow]"
                    if getattr(h, "is_graph_expanded", False)
                    else ""
                )
                console.print(f"\n[cyan][{i}][/cyan] [bold]{source}[/bold]{graph_tag}")
                console.print(f"  {h.text}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")

        # Estatisticas de expansao (--show-stats): seeds, graph nodes e
        # tokens do contexto LLM. Util para entender o quanto o grafo
        # contribuiu vs busca direta, sem precisar de --raw.
        if show_stats:
            stats_obj = getattr(result, "stats", None)
            seeds = None
            graph_nodes_count = None
            total_tokens = None
            truncated = None
            if stats_obj is not None:
                # stats pode ser dict (SDK antigo) ou objeto com atributos
                if isinstance(stats_obj, dict):
                    seeds = stats_obj.get("seeds") or stats_obj.get("seeds_count")
                    graph_nodes_count = stats_obj.get("graph_nodes") or stats_obj.get("nodes")
                    total_tokens = stats_obj.get("tokens") or stats_obj.get("total_tokens")
                    truncated = stats_obj.get("truncated")
                else:
                    seeds = getattr(stats_obj, "seeds", None) or getattr(stats_obj, "seeds_count", None)
                    graph_nodes_count = getattr(stats_obj, "graph_nodes", None) or getattr(stats_obj, "nodes", None)
                    total_tokens = getattr(stats_obj, "tokens", None) or getattr(stats_obj, "total_tokens", None)
                    truncated = getattr(stats_obj, "truncated", None)
            # Fallback: contar diretamente dos hits se stats nao veio
            if seeds is None:
                seeds = sum(1 for h in direct_hits)
            if graph_nodes_count is None:
                graph_nodes_count = sum(1 for h in graph_hits)

            console.print()
            stats_line = (
                f"[dim]Stats: seeds={seeds} | graph_nodes={graph_nodes_count}"
            )
            if total_tokens is not None:
                stats_line += f" | tokens={total_tokens}"
            if truncated is not None:
                stats_line += f" | truncated={'sim' if truncated else 'nao'}"
            stats_line += "[/dim]"
            console.print(stats_line)

        query_id = getattr(result, "query_id", None)
        if query_id:
            console.print(f"\n[dim]query_id: {query_id}[/dim]")
        print_request_id_footer(console, extract_request_id(result))
        print_credits_footer(console, result)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
