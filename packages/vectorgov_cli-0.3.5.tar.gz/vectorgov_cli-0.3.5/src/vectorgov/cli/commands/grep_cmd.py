"""Busca exata por texto nas normas (full-text search)."""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager
from ..utils.output import (
    extract_credits,
    extract_request_id,
    get_evidence_links,
    print_credits_footer,
    print_request_id_footer,
    render_evidence_lines_text,
    render_llm_output,
    resolve_output_format,
)

console = Console()
config_manager = ConfigManager()


def grep(
    query: str = typer.Argument(..., help="Texto exato para buscar (ex: 'dispensa de licitação')"),
    document_id: str = typer.Option(None, "--doc", "-d", help="Filtrar por documento (ex: LEI-14.133-2021)"),
    max_val: int = typer.Option(20, "--max", "-n", help="Máximo de resultados (1-50)"),
    context_lines: int = typer.Option(3, "--context-lines", "-C", help="Linhas de contexto (0-10)"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json, text, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca exata por texto no corpo das normas.

    Diferente de 'search' (semântico), grep encontra ocorrências literais do texto.
    Ideal para encontrar menções específicas a termos, siglas ou expressões exatas.

    Exemplo:
        vectorgov grep "dispensa de licitação"
        vectorgov grep "ETP" --doc LEI-14.133-2021
        vectorgov grep "pregão eletrônico" --output json
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if max_val < 1 or max_val > 50:
            console.print("[red]Erro:[/red] --max deve estar entre 1 e 50.")
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        with console.status("[bold]Buscando texto exato...[/bold]"):
            result = vg.grep(
                query=query,
                document_id=document_id or None,
                max_results=max_val,
                context_lines=context_lines,
            )

        # GrepResult has .matches (list of GrepMatch)
        hits = result.matches if hasattr(result, "matches") else (result if isinstance(result, list) else [])

        if effective_output == "raw":
            data = {
                "query": query,
                "document_id": document_id,
                "total": len(hits),
                "request_id": extract_request_id(result),
                "latency_ms": getattr(result, "latency_ms", None),
                "files_searched": getattr(result, "files_searched", None),
                "hits": [
                    {
                        "text": getattr(h, "text", str(h)),
                        "source": getattr(h, "source", ""),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        **get_evidence_links(h),
                    }
                    for h in hits
                ],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if effective_output == "llm":
            metadata = {
                "total": len(hits),
                "latency_ms": getattr(result, "latency_ms", None),
                "query_id": None,
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            print(render_llm_output(hits, query, metadata))
            return

        if not hits:
            console.print(f"[yellow]Nenhuma ocorrência de '{query}' encontrada.[/yellow]")
            raise typer.Exit(0)

        console.print(f"\n[bold]{len(hits)} ocorrência(s) encontrada(s)[/bold]\n")

        if output == "json":
            data = {
                "request_id": extract_request_id(result),
                "hits": [
                    {"source": getattr(h, "source", ""), "span_id": getattr(h, "span_id", ""),
                     "text": getattr(h, "text", str(h))}
                    for h in hits
                ],
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"grep: '{query}'")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Trecho", overflow="fold")
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                text = getattr(h, "text", str(h))
                table.add_row(str(i), source, text)
            console.print(table)
        else:
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                console.print(f"[cyan][{i}][/cyan] [bold]{source}[/bold]")
                console.print(f"  {getattr(h, 'text', str(h))}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")
                console.print()

        print_request_id_footer(console, extract_request_id(result))
        print_credits_footer(console, result)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
