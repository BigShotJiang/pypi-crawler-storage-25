"""Leitura direta do texto canônico de um documento ou dispositivo."""

import json
import typer
from rich.console import Console
from rich.panel import Panel
from ..utils.config import ConfigManager
from ..utils.output import extract_credits, extract_request_id, print_credits_footer, print_request_id_footer

console = Console()
config_manager = ConfigManager()


def read_canonical(
    document_id: str = typer.Argument(..., help="ID do documento (ex: LEI-14133-2021)"),
    span_id: str = typer.Option(None, "--span", "-s", help="Dispositivo específico (ex: ART-075)"),
    output: str = typer.Option("text", "--output", "-o", help="Formato: text, json"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Lê o texto canônico completo de um documento ou de um dispositivo.

    Diferente de `search` (vetorial), retorna o texto original da norma
    sem passar por embeddings. Útil para:
    - Ler um artigo inteiro de forma determinística
    - Verificar redação oficial de um dispositivo
    - Exportar uma lei completa para contexto de LLM

    Exemplos:
        vectorgov read LEI-14133-2021                    # Lei inteira
        vectorgov read LEI-14133-2021 --span ART-075     # Só Art. 75
        vectorgov read LEI-14133-2021 -s PAR-033-1       # Só § 1º do Art. 33
        vectorgov read LEI-14133-2021 -s ART-075 --raw   # JSON para piping
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        with console.status(f"[bold]Lendo {document_id}{f' / {span_id}' if span_id else ''}...[/bold]"):
            result = vg.read_canonical(document_id, span_id=span_id or None)

        text = getattr(result, "text", "")
        doc_id = getattr(result, "document_id", document_id)
        token_count = getattr(result, "token_count", 0)
        char_count = getattr(result, "char_count", len(text))
        returned_span = getattr(result, "span_id", None)
        breadcrumb = getattr(result, "breadcrumb", None)
        source = getattr(result, "source", "canonical")

        if raw:
            data = {
                "document_id": doc_id,
                "span_id": returned_span,
                "text": text,
                "breadcrumb": breadcrumb,
                "token_count": token_count,
                "char_count": char_count,
                "source": source,
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if not text:
            console.print(f"[yellow]Nenhum texto retornado para {doc_id}"
                          f"{f' / {span_id}' if span_id else ''}.[/yellow]")
            raise typer.Exit(0)

        if output == "json":
            data = {
                "document_id": doc_id,
                "span_id": returned_span,
                "text": text,
                "breadcrumb": breadcrumb,
                "token_count": token_count,
                "char_count": char_count,
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        else:
            title = doc_id
            if returned_span:
                title = f"{doc_id} — {returned_span}"
            if breadcrumb:
                title = f"{title}  |  {breadcrumb}"
            console.print(Panel(text, title=title, border_style="cyan"))
            console.print(
                f"[dim]{char_count} chars  •  {token_count} tokens  •  source={source}[/dim]"
            )
            print_request_id_footer(console, extract_request_id(result))
            print_credits_footer(console, result)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
