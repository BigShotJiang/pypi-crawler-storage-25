"""Busca inteligente com análise jurídica (MOC v4 Pipeline)."""

import json
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from ..utils.config import ConfigManager
from ..utils.output import (
    extract_credits,
    extract_request_id,
    get_evidence_links,
    print_credits_footer,
    print_request_id_footer,
    render_evidence_lines_text,
    render_llm_output,
    resolve_output_format,
)

console = Console()
config_manager = ConfigManager()


def smart_search(
    query: str = typer.Argument(..., help="Pergunta jurídica para análise inteligente"),
    use_cache: bool = typer.Option(False, "--cache", help="Usar cache semântico"),
    output: str = typer.Option("text", "--output", "-o", help="Formato: text, json, table, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca inteligente com análise de completude (Pensador -> Motor -> Juiz).

    Retorna resultados com nível de confiança (ALTO/MEDIO/BAIXO) e raciocínio jurídico.
    Mais lenta que 'search', porém mais precisa e com análise de qualidade.

    Exemplo:
        vectorgov smart-search "Quais os critérios de julgamento na Lei 14.133?"
        vectorgov smart-search "Quando o ETP pode ser dispensado?" --output json
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        with console.status("[bold]Analisando consulta (pode levar até 60s)...[/bold]"):
            result = vg.smart_search(query=query, use_cache=use_cache)

        if effective_output == "raw":
            data = {
                "query": query,
                "confianca": result.confianca,
                "raciocinio": result.raciocinio,
                "tentativas": result.tentativas,
                "total": result.total,
                "latency_ms": result.latency_ms,
                "cached": result.cached,
                "query_id": result.query_id,
                "request_id": extract_request_id(result),
                "hits": [
                    {
                        "text": h.text,
                        "source": getattr(h, "source", ""),
                        "score": getattr(h, "score", 0),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        **get_evidence_links(h),
                    }
                    for h in result.hits
                ],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        # Header with confidence
        conf_color = {"ALTO": "green", "MEDIO": "yellow", "BAIXO": "red"}.get(
            result.confianca, "white"
        )
        console.print(
            f"\n[bold]Confiança:[/bold] [{conf_color}]{result.confianca}[/{conf_color}]  "
            f"[dim]({result.tentativas} tentativa(s), {result.latency_ms:.0f}ms)[/dim]"
        )

        if result.raciocinio:
            console.print(
                Panel(result.raciocinio, title="Raciocínio Jurídico", border_style="blue")
            )

        if effective_output == "llm":
            hits = list(result.hits) if hasattr(result, "hits") else []
            metadata = {
                "total": len(hits),
                "latency_ms": getattr(result, "latency_ms", None),
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            print(render_llm_output(hits, query, metadata))
            return

        if output == "json":
            data = {
                "confianca": result.confianca,
                "raciocinio": result.raciocinio,
                "tentativas": result.tentativas,
                "total": result.total,
                "query_id": result.query_id,
                "request_id": extract_request_id(result),
                "hits": [
                    {
                        "text": h.text,
                        "source": getattr(h, "source", ""),
                        "score": getattr(h, "score", 0),
                        **get_evidence_links(h),
                    }
                    for h in result.hits
                ],
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"Resultados ({result.total})")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Texto", overflow="fold")
            table.add_column("Score", justify="right", width=6)
            for i, h in enumerate(result.hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                score = getattr(h, "score", 0)
                text = h.text
                table.add_row(
                    str(i), source, text, f"{score:.2f}" if score else "-"
                )
            console.print(table)
        else:
            for i, h in enumerate(result.hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                console.print(f"\n[cyan][{i}][/cyan] [bold]{source}[/bold]")
                console.print(f"  {h.text}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")

        if result.query_id:
            console.print(
                f"\n[dim]query_id: {result.query_id} "
                f"(use com 'vectorgov feedback send')[/dim]"
            )
        print_request_id_footer(console, extract_request_id(result))
        print_credits_footer(console, result)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
