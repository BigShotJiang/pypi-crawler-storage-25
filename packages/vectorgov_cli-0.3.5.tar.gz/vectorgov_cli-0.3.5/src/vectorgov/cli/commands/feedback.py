"""
Comando de feedback do CLI VectorGov.
"""

import typer
from rich.console import Console

from ..utils.config import ConfigManager
from ..utils.output import extract_request_id, print_request_id_footer

app = typer.Typer(no_args_is_help=True)
console = Console()
config_manager = ConfigManager()


@app.command("send")
def send_feedback(
    query_id: str = typer.Argument(..., help="ID da query (obtido após search ou ask)"),
    like: bool = typer.Option(None, "--like", "-l", help="Marcar como positivo"),
    dislike: bool = typer.Option(None, "--dislike", "-d", help="Marcar como negativo"),
):
    """
    Envia feedback sobre uma resposta (like/dislike).

    Exemplos:
        vectorgov feedback send abc123 --like
        vectorgov feedback send abc123 --dislike
    """
    # Valida opções
    if like is None and dislike is None:
        console.print("[red]Erro:[/red] Especifique --like ou --dislike")
        raise typer.Exit(1)

    if like and dislike:
        console.print("[red]Erro:[/red] Use apenas --like OU --dislike, não ambos")
        raise typer.Exit(1)

    is_like = like if like is not None else not dislike

    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    # Valida query_id localmente antes de chamar o backend.
    # O backend rejeita query_ids com menos de 8 caracteres (422), mas
    # vamos oferecer uma mensagem amigavel em vez de deixar o usuario
    # ver o raw do Pydantic ValidationError.
    if len(query_id) < 8:
        console.print(
            f"[red]Erro:[/red] query_id inválido — deve ter no mínimo 8 caracteres "
            f"(recebido: {len(query_id)})."
        )
        console.print(
            "[dim]Dica: o query_id vem no rodapé ou JSON de uma busca. "
            "Ex: [cyan]vectorgov search --raw 'ETP' | jq -r '.query_id'[/cyan][/dim]"
        )
        raise typer.Exit(1)

    # Envia feedback
    try:
        from vectorgov import VectorGov

        vg = VectorGov(api_key=api_key)
        result = vg.feedback(query_id, like=is_like)

        tipo = "+1 positivo" if is_like else "-1 negativo"
        console.print(f"[green]OK[/green] Feedback ({tipo}) enviado com sucesso!")
        # request_id da confirmação do backend (graceful se SDK não expor)
        print_request_id_footer(console, extract_request_id(result))

    except typer.Exit:
        raise
    except Exception as e:
        # Tenta extrair mensagem amigavel de ValidationError (Pydantic)
        # quando o erro vem como array de dicts do backend.
        import re
        msg = str(e)
        # Padrao: "[422] [{'type': 'string_too_short', 'msg': '...', ...}]"
        if "422" in msg and "string_too_short" in msg:
            console.print(
                "[red]Erro:[/red] query_id inválido ou muito curto. "
                "Use um query_id real de uma busca anterior."
            )
        elif "404" in msg:
            console.print(
                f"[red]Erro:[/red] query_id '{query_id[:12]}...' não encontrado. "
                "Pode ter expirado ou nunca ter existido."
            )
        elif "401" in msg or "403" in msg:
            console.print("[red]Erro:[/red] API key inválida ou sem permissão.")
        else:
            # Fallback: mostra erro original
            console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
