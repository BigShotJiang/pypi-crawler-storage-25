"""
Comando de busca do CLI VectorGov.
"""

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from ..utils.config import ConfigManager
from ..utils.output import OutputFormat, extract_request_id, format_search_results, hit_to_raw_dict, resolve_output_format

console = Console()
config_manager = ConfigManager()


def search(
    query: str = typer.Argument(..., help="Pergunta ou termo de busca"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Número de resultados (1-20)"),
    mode: str = typer.Option(
        "balanced",
        "--mode", "-m",
        help="Modo de busca: fast, balanced, precise"
    ),
    use_cache: bool = typer.Option(False, "--cache", help="Usar cache semântico"),
    tipo: Optional[str] = typer.Option(
        None, "--tipo", "-t",
        help="Filtra por tipo de documento (LEI, DECRETO, IN, PORTARIA, AC)"
    ),
    ano: Optional[int] = typer.Option(
        None, "--ano", "-a",
        help="Filtra por ano do documento (ex: 2021)"
    ),
    document_id: Optional[str] = typer.Option(
        None, "--doc", "-d",
        help="Filtra por document_id específico (ex: LEI-14133-2021)"
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.table,
        "--output", "-o",
        help="Formato de saída: table, json, text, llm"
    ),
    raw: bool = typer.Option(False, "--raw", help="Saída sem formatação (JSON bruto)"),
):
    """
    Busca documentos na base de legislação.

    Exemplos:
        vectorgov search "O que é ETP?"
        vectorgov search "pesquisa de preços" --top-k 10
        vectorgov search "licitação" --mode precise --output json
        vectorgov search "dispensa" --tipo LEI --ano 2021
        vectorgov search "art. 75" --doc LEI-14133-2021
    """
    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    # Valida parâmetros
    if top_k < 1 or top_k > 20:
        console.print("[red]Erro:[/red] top_k deve estar entre 1 e 20.")
        raise typer.Exit(1)

    if mode not in ["fast", "balanced", "precise"]:
        console.print("[red]Erro:[/red] mode deve ser: fast, balanced ou precise.")
        raise typer.Exit(1)

    if ano is not None and (ano < 1800 or ano > 2100):
        console.print("[red]Erro:[/red] --ano deve ser um ano válido (1800-2100).")
        raise typer.Exit(1)

    # Monta filters dict para o SDK (keys: tipo, ano, orgao — não tipo_documento)
    # IMPORTANTE: backend armazena tipo_documento UPPERCASE (LEI, DECRETO, IN)
    filters: Optional[dict] = None
    if tipo or ano:
        filters = {}
        if tipo:
            filters["tipo"] = tipo.upper()
        if ano:
            filters["ano"] = ano

    # Resolve formato efetivo (flag > env var > config > default)
    effective_output = resolve_output_format(output.value if isinstance(output, OutputFormat) else output, is_raw=raw)

    # Executa busca
    try:
        from vectorgov import VectorGov

        if effective_output != "raw":
            console.print(f"Buscando: [cyan]{query}[/cyan]", style="dim")

        vg = VectorGov(api_key=api_key)
        results = vg.search(
            query,
            top_k=top_k,
            mode=mode,
            use_cache=use_cache,
            filters=filters,
            document_id_filter=document_id,
        )

        # Formata saída
        if effective_output == "raw":
            # JSON bruto para pipes
            data = {
                "query": query,
                "total": results.total,
                "cached": results.cached,
                "latency_ms": results.latency_ms,
                "query_id": results.query_id,
                "request_id": extract_request_id(results),
                "hits": [hit_to_raw_dict(h) for h in results.hits],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
        else:
            # Map effective_output back to OutputFormat for format_search_results
            try:
                fmt = OutputFormat(effective_output)
            except ValueError:
                fmt = output
            format_search_results(console, results, fmt, query)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
