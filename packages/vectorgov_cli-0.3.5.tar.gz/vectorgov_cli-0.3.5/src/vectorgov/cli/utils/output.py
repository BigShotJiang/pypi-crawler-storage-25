"""
Utilitários de formatação de saída do CLI VectorGov.
"""

import json
import os
import sys
from enum import Enum
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel


BASE_URL = "https://vectorgov.io"


# ─── Formatação de document_id para exibição humana ─────────────────────────

_TIPO_LABEL = {
    "LEI": "Lei",
    "DECRETO": "Decreto",
    "IN": "IN",
    "PORTARIA": "Portaria",
    "AC": "Acórdão",
    "LC": "LC",
    "MP": "MP",
    "EC": "EC",
    "RES": "Resolução",
    "RESOLUCAO": "Resolução",
}


def format_document_label(document_id: Optional[str]) -> str:
    """Formata document_id para exibição humana.

    Exemplos:
        'LEI-14133-2021'     -> 'Lei 14.133/2021'
        'IN-65-2021'         -> 'IN 65/2021'
        'DECRETO-10947-2022' -> 'Decreto 10.947/2022'
        'PORTARIA-938-2022'  -> 'Portaria 938/2022'
        'AC-1852-2020-P'     -> 'Acórdão 1.852/2020-P'

    Fallback: retorna o document_id cru se não conseguir parsear.
    """
    if not document_id:
        return "-"
    parts = document_id.split("-")
    if len(parts) < 3:
        return document_id
    tipo = _TIPO_LABEL.get(parts[0].upper(), parts[0])
    num = parts[1]
    ano = parts[2]
    suffix = "-" + "-".join(parts[3:]) if len(parts) > 3 else ""
    if num.isdigit() and len(num) >= 4:
        num_fmt = f"{int(num):,}".replace(",", ".")
    else:
        num_fmt = num
    return f"{tipo} {num_fmt}/{ano}{suffix}"


def get_hit_document_id(hit: Any) -> Optional[str]:
    """Extrai document_id (ou source como fallback) de um hit."""
    if isinstance(hit, dict):
        return hit.get("document_id") or hit.get("source")
    return getattr(hit, "document_id", None) or getattr(hit, "source", None)


class OutputFormat(str, Enum):
    """Formatos de saída suportados."""
    table = "table"
    json = "json"
    text = "text"
    markdown = "markdown"
    llm = "llm"


# ─── Helpers de evidência ────────────────────────────────────────────────────

def absolute_url(relative_or_absolute: Optional[str]) -> Optional[str]:
    """Prefixa com https://vectorgov.io se vier relativo. None se vazio."""
    if not relative_or_absolute:
        return None
    if relative_or_absolute.startswith("http://") or relative_or_absolute.startswith("https://"):
        return relative_or_absolute
    if relative_or_absolute.startswith("/"):
        return f"{BASE_URL}{relative_or_absolute}"
    return f"{BASE_URL}/{relative_or_absolute}"


def get_evidence_links(hit: Any) -> Dict[str, Optional[str]]:
    """Extrai evidence_url e document_url de um hit do SDK.

    Retorna dict com ambos absolutos (com https://vectorgov.io prefixado),
    ou None se ausentes. Aceita hit objeto ou dict.
    """
    if isinstance(hit, dict):
        return {
            "evidence_url": absolute_url(hit.get("evidence_url")),
            "document_url": absolute_url(hit.get("document_url")),
        }
    return {
        "evidence_url": absolute_url(getattr(hit, "evidence_url", None)),
        "document_url": absolute_url(getattr(hit, "document_url", None)),
    }


def hit_to_raw_dict(hit: Any) -> Dict[str, Any]:
    """Serialização padronizada de um hit para JSON/raw output.

    Inclui evidence_url e document_url absolutos (null se ausentes).
    """
    links = get_evidence_links(hit)
    return {
        "text": getattr(hit, "text", ""),
        "article_number": getattr(hit, "article_number", None),
        "document_id": getattr(hit, "document_id", None) or getattr(hit, "source", None),
        "score": getattr(hit, "score", 0),
        "evidence_url": links["evidence_url"],
        "document_url": links["document_url"],
    }


def render_evidence_lines_text(hit: Any, indent: str = "    ") -> List[str]:
    """Linhas formatadas para text output. Lista vazia se nenhum link."""
    links = get_evidence_links(hit)
    lines: List[str] = []
    if links["evidence_url"]:
        lines.append(f"{indent}Ver trecho: {links['evidence_url']}")
    if links["document_url"]:
        lines.append(f"{indent}Baixar PDF: {links['document_url']}")
    return lines


def render_request_id_line(request_id: Optional[str], prefix: str = "") -> List[str]:
    """Retorna linha formatada 'Request ID: ...' para rodapé text/llm.

    Lista vazia se não houver request_id — simplifica composição com
    outras linhas de rodapé via extend().

    Use quando compondo output text programaticamente.
    """
    if not request_id:
        return []
    return [f"{prefix}Request ID: {request_id}"]


def print_request_id_footer(console: Console, request_id: Optional[str]) -> None:
    """Imprime rodapé formatado com Rich 'Request ID: ...' se disponível.

    Use no final dos handlers de output text dos comandos, para
    exibir o ID de tracking para o usuário copiar em caso de suporte.
    Dim style para não competir com o conteúdo principal.
    """
    if request_id:
        console.print(f"\n[dim]Request ID: {request_id}[/dim]")


def extract_request_id(result: Any, raw_resp: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """Extrai request_id do result do SDK com fallback para raw response.

    Graceful degradation: se a versão do SDK não expõe request_id,
    tenta pegar do _raw_response. Retorna None se ausente.
    """
    rid = getattr(result, "request_id", None)
    if rid:
        return rid
    if raw_resp and isinstance(raw_resp, dict):
        return raw_resp.get("request_id")
    # Tenta pegar do _raw_response do próprio result
    rr = getattr(result, "_raw_response", None)
    if rr and isinstance(rr, dict):
        return rr.get("request_id")
    return None


def extract_credits(result: Any) -> Optional[Dict[str, Any]]:
    """Extrai CreditsInfo (cost, balance, endpoint) do result do SDK.

    Requer vectorgov SDK >= 0.19.1 (expoe result.credits). Retorna None
    se o SDK nao populou (versao antiga ou endpoint sem custo).

    Returns:
        Dict com keys 'cost' (int), 'balance' (int), 'endpoint' (str)
        ou None se ausente.
    """
    credits = getattr(result, "credits", None)
    if credits is None:
        return None
    return {
        "cost": getattr(credits, "cost", 0),
        "balance": getattr(credits, "balance", 0),
        "endpoint": getattr(credits, "endpoint", ""),
    }


def format_credits_line(result: Any, prefix: str = "") -> Optional[str]:
    """Formata linha de creditos para o rodape text/llm.

    Retorna None se o SDK nao expos credits (nao renderiza nada).

    Exemplo de saida:
        'Creditos: 1 (saldo: 68)'
    """
    credits = extract_credits(result)
    if not credits:
        return None
    cost = credits.get("cost", 0)
    balance = credits.get("balance", 0)
    return f"{prefix}Créditos: {cost} (saldo: {balance})"


def print_credits_footer(console: Console, result: Any) -> None:
    """Imprime rodape formatado 'Creditos: X (saldo: Y)' se disponivel.

    Use no final dos handlers de output text dos comandos de busca,
    para exibir custo da chamada e saldo restante. Dim style para
    nao competir com o conteudo principal.

    Silencioso se SDK < 0.19.1 (result.credits e None).
    """
    line = format_credits_line(result)
    if line:
        console.print(f"[dim]{line}[/dim]")


def render_evidence_cell_table(hit: Any) -> str:
    """Célula curta para coluna de tabela. Usa Rich link markup clicável."""
    links = get_evidence_links(hit)
    ev = links["evidence_url"]
    if ev:
        return f"[link={ev}]ver trecho[/link]"
    return "-"


def render_evidence_markdown(hit: Any, indent: str = "") -> List[str]:
    """Seção Fontes em Markdown. Lista vazia se nenhum link."""
    links = get_evidence_links(hit)
    if not (links["evidence_url"] or links["document_url"]):
        return []
    lines = [f"{indent}**Fontes**:"]
    if links["evidence_url"]:
        lines.append(f"{indent}- [Ver trecho destacado]({links['evidence_url']})")
    if links["document_url"]:
        lines.append(f"{indent}- [Baixar PDF original]({links['document_url']})")
    return lines


# ─── Output LLM (texto puro) ─────────────────────────────────────────────────

def _hit_get(hit, key: str, default: Any = "") -> Any:
    """Le campo de um hit que pode ser dict OU objeto (Hit do SDK).

    `default` é Any para aceitar qualquer tipo (str, int, None) — score
    default = 0, text default = "", etc.
    """
    if hit is None:
        return default
    if isinstance(hit, dict):
        return hit.get(key, default)
    return getattr(hit, key, default)


def render_llm_output(hits: list, query: str, metadata: Optional[dict] = None) -> str:
    """Output otimizado para consumo por LLMs. Texto puro, sem formatacao.

    Sem truncamento — retorna o texto integral de cada hit. Se o usuario
    quer resposta menor, use --top-k N.
    """
    lines = []
    total = len(hits)
    for i, hit in enumerate(hits, 1):
        source = _hit_get(hit, "source") or _hit_get(hit, "document_id") or ""
        article = _hit_get(hit, "article_number") or ""
        score = _hit_get(hit, "score", 0) or 0
        text = _hit_get(hit, "text", "") or ""

        header = f"[{i}/{total}]"
        if source:
            header += f" {source}"
        if article and article not in source:
            header += f", Art. {article}"
        try:
            header += f" (score={float(score):.2f})"
        except (TypeError, ValueError):
            pass

        lines.append(header)
        if text:
            lines.append(text)

        links = get_evidence_links(hit)
        if links["evidence_url"]:
            lines.append(f"EVIDENCE: {links['evidence_url']}")
        if links["document_url"]:
            lines.append(f"PDF: {links['document_url']}")

        if i < total:
            lines.append("---")

    if metadata:
        # Curadoria (SPEC 1C): nota do especialista e jurisprudencia TCU
        nota = metadata.get("nota_especialista")
        jur = metadata.get("jurisprudencia_tcu")
        if nota:
            lines.append("---")
            lines.append("NOTA DO ESPECIALISTA:")
            lines.append(nota)
        if jur:
            lines.append("---")
            lines.append("JURISPRUDENCIA TCU:")
            lines.append(jur)
            if metadata.get("acordao_tcu_key"):
                lines.append(f"Acordao: {metadata['acordao_tcu_key']}")
            if metadata.get("acordao_tcu_link"):
                lines.append(f"Link: {metadata['acordao_tcu_link']}")

        parts = []
        if metadata.get("total") is not None:
            parts.append(f"Total: {metadata['total']} hits")
        if metadata.get("latency_ms") is not None:
            parts.append(f"Latencia: {metadata['latency_ms']/1000:.1f}s")
        credits_info = metadata.get("credits")
        if credits_info:
            cost = credits_info.get("cost", 0)
            balance = credits_info.get("balance", 0)
            parts.append(f"Creditos: {cost} (saldo: {balance})")
        if metadata.get("query_id"):
            parts.append(f"Query ID: {metadata['query_id']}")
        if metadata.get("request_id"):
            parts.append(f"Request ID: {metadata['request_id']}")
        if parts:
            lines.append("---")
            lines.append(" | ".join(parts))

    return "\n".join(lines)


# ─── Resolução de formato de output ─────────────────────────────────────────

def resolve_output_format(
    explicit: str = "table",
    is_raw: bool = False,
    command_default: str = "table",
) -> str:
    """Resolve formato de output com fallback em cascata.

    Precedência:
      1. is_raw=True                      -> "raw"
      2. flag --output != default do cmd  -> respeita flag
      3. env VECTORGOV_OUTPUT              -> respeita env
      4. config default_output             -> respeita config
      5. stdout não é TTY (pipe/LLM/CI)    -> "llm" (GNU-style)
      6. default do comando                -> fallback final

    A detecção de TTY (passo 5) faz o CLI ser LLM-friendly out of the box:
    quando um agente ou script executa `vectorgov search "..." | something`,
    recebe texto integral no formato llm em vez da tabela truncada.
    """
    valid = ("table", "json", "text", "markdown", "llm", "raw")

    if is_raw:
        return "raw"

    if explicit and explicit != command_default and explicit in valid:
        return explicit

    env_val = os.environ.get("VECTORGOV_OUTPUT", "").lower().strip()
    if env_val and env_val in valid:
        return env_val

    try:
        from ..utils.config import ConfigManager
        config_val = ConfigManager().get("default_output")
        if config_val and config_val.lower() in valid:
            return config_val.lower()
    except Exception:
        pass

    try:
        if not sys.stdout.isatty():
            return "llm"
    except (AttributeError, ValueError):
        pass

    return explicit or command_default


# ─── Formatador principal ────────────────────────────────────────────────────

def format_search_results(console: Console, results: Any, output_format: OutputFormat, query: str):
    """
    Formata e exibe resultados de busca.

    Args:
        console: Console Rich para output
        results: Objeto SearchResult da API
        output_format: Formato desejado
        query: Query original
    """
    request_id = extract_request_id(results)
    credits = extract_credits(results)

    if output_format == OutputFormat.json:
        data = {
            "query": query,
            "total": results.total,
            "cached": results.cached,
            "latency_ms": results.latency_ms,
            "query_id": results.query_id,
            "request_id": request_id,
            "credits": credits,
            "hits": [hit_to_raw_dict(h) for h in results.hits],
        }
        console.print_json(json.dumps(data, ensure_ascii=False))

    elif output_format == OutputFormat.table:
        # Cabeçalho
        console.print()
        console.print(f"[bold]Resultados para:[/bold] {query}")
        console.print(f"[dim]Total: {results.total} | Latência: {results.latency_ms:.0f}ms | Cache: {'Sim' if results.cached else 'Não'}[/dim]")
        console.print()

        # Tabela — sem truncamento de texto. Rich faz word-wrap via overflow="fold"
        # na coluna Texto. Se o resultado for muito alto visualmente, use --top-k N.
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("#", justify="right", style="dim", width=3)
        table.add_column("Norma", style="cyan", width=22)
        table.add_column("Artigo", style="green", width=8)
        table.add_column("Texto", overflow="fold")
        table.add_column("Score", justify="right", width=7)
        table.add_column("Evidência", width=14)

        for i, hit in enumerate(results.hits, 1):
            doc_id = get_hit_document_id(hit)
            norma = format_document_label(doc_id)
            article = getattr(hit, "article_number", "-") or "-"
            text = hit.text  # sem truncamento, sem replace \n — dado integral
            evidence_cell = render_evidence_cell_table(hit)
            table.add_row(
                str(i),
                norma,
                str(article),
                text,
                f"{hit.score:.3f}",
                evidence_cell,
            )

        console.print(table)

        # Footer: lista fontes únicas (substitui "PDF do primeiro resultado")
        unique_docs: List[str] = []
        seen: set = set()
        for h in results.hits:
            doc_id = get_hit_document_id(h)
            if doc_id and doc_id not in seen:
                seen.add(doc_id)
                unique_docs.append(format_document_label(doc_id))
        if unique_docs:
            console.print(
                f"\n[dim]Fontes ({len(unique_docs)}): {', '.join(unique_docs)}[/dim]"
            )
        console.print(f"[dim]Query ID: {results.query_id}[/dim]")
        if request_id:
            console.print(f"[dim]Request ID: {request_id}[/dim]")
        print_credits_footer(console, results)
        console.print("[dim]Use 'vectorgov feedback send <query_id> --like' para avaliar[/dim]")

    elif output_format == OutputFormat.markdown:
        console.print(f"## Resultados para: \"{query}\"\n")
        console.print(f"*Total: {results.total} | Latência: {results.latency_ms:.0f}ms*\n")
        for i, hit in enumerate(results.hits, 1):
            article = getattr(hit, "article_number", None)
            doc_id = getattr(hit, "document_id", None) or getattr(hit, "source", "")
            header = f"### {i}. Art. {article}" if article else f"### {i}."
            if doc_id:
                header += f" — {doc_id}"
            console.print(header)
            console.print()
            console.print(hit.text)
            console.print()
            for line in render_evidence_markdown(hit, indent=""):
                console.print(line)
            console.print()

    elif output_format == OutputFormat.llm or output_format == "llm":
        metadata = {
            "total": results.total,
            "latency_ms": results.latency_ms,
            "query_id": results.query_id,
            "request_id": request_id,
            "credits": credits,
        }
        print(render_llm_output(results.hits, query, metadata))

    else:  # text
        console.print()
        console.print(Panel(f"[bold]{query}[/bold]", title="Busca", border_style="blue"))

        for i, hit in enumerate(results.hits, 1):
            article = getattr(hit, "article_number", None)
            doc_id = get_hit_document_id(hit)
            norma = format_document_label(doc_id)
            if article and doc_id:
                header = f"[{i}] {norma}, Art. {article}"
            elif article:
                header = f"[{i}] Art. {article}"
            elif doc_id:
                header = f"[{i}] {norma}"
            else:
                header = f"[{i}]"

            console.print(f"\n[bold cyan]{header}[/bold cyan] (score: {hit.score:.3f})")
            console.print(hit.text)  # sem truncamento
            # Links de evidência
            for line in render_evidence_lines_text(hit):
                console.print(f"[dim]{line}[/dim]")

        console.print(f"\n[dim]Total: {results.total} | Latência: {results.latency_ms:.0f}ms[/dim]")
        console.print(f"[dim]Query ID: {results.query_id}[/dim]")
        if request_id:
            console.print(f"[dim]Request ID: {request_id}[/dim]")
        print_credits_footer(console, results)


def format_code_block(console: Console, code: str, language: str = "python"):
    """
    Formata e exibe um bloco de código.

    Args:
        console: Console Rich
        code: Código a exibir
        language: Linguagem para syntax highlighting
    """
    from rich.syntax import Syntax
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    console.print(syntax)
