"""iOS QA Agent — the brain.

Runs the observe → reason → act loop:
1. Screenshot + UI tree → Claude
2. Claude decides next action
3. Execute action on simulator
4. Repeat until path complete or failure
"""

import json
import time
import httpx
from config import ANTHROPIC_API_KEY, CLAUDE_MODEL, MAX_ITERATIONS
from simulator import (
    take_screenshot,
    get_ui_tree,
    get_ui_tree_summary,
    wait_for_stable,
    find_element_at,
    check_actionable,
    tap,
    swipe,
    type_text,
    press_button,
)


SYSTEM_PROMPT = """You are a QA agent testing an iOS mobile app running in a simulator.

You operate in a multi-turn conversation. Each message includes:
1. A screenshot of the CURRENT screen (as an image)
2. The accessibility tree (as JSON) showing all UI elements with their labels, identifiers, types, and tap coordinates (center_x, center_y)
3. Screen-change feedback — whether the screen changed after your last action
4. Visible text on screen — key labels and text extracted from the UI

You can see your own previous responses and previous screenshots in the conversation history.
Use this to:
- Compare before/after screenshots to verify your actions worked
- Avoid repeating actions that didn't change the screen
- Track your progress through the user path

Respond with ONLY a JSON object (no markdown, no backticks) in one of these formats:

TAP an element:
{"action": "tap", "x": 195.5, "y": 420.0, "reason": "Tapping the Sign Up button"}

TYPE text (into the currently focused field):
{"action": "type", "text": "john@example.com", "reason": "Entering email address"}

SWIPE:
{"action": "swipe", "x1": 200, "y1": 600, "x2": 200, "y2": 200, "reason": "Scrolling down to see more options"}

PRESS a hardware button:
{"action": "press", "button": "home", "reason": "Going to home screen"}

WAIT (if a screen is loading):
{"action": "wait", "seconds": 2, "reason": "Waiting for content to load"}

VERIFY text is on screen (like Playwright's expect().toHaveText()):
{"action": "verify", "text": "Welcome back", "reason": "Checking that login succeeded"}

PATH COMPLETE (all steps done successfully):
{"action": "done", "reason": "Successfully completed all steps: signed up, completed onboarding, navigated to settings"}

PATH FAILED (something went wrong, can't continue):
{"action": "fail", "reason": "Login button is not responding after 3 attempts"}

Rules:
- Always use the accessibility tree coordinates for tapping — they're more reliable than guessing from the screenshot.
- If an element has an identifier (testID), mention it in your reason.
- If you need to type, first tap the text field, then type in the next step.
- Be precise. One action per response.
- IMPORTANT: Compare the current screenshot to your previous screenshots. If the screen hasn't changed after your action, try a different approach (different coordinates, different element, scroll first, etc.)
- Use "verify" after important actions to confirm the expected result appeared on screen. If verify fails, adapt your strategy.
- Track your progress against the user path. Once all steps are done, return "done".
- CRITICAL: Respond with ONLY the JSON object. No explanation, no preamble, no text before or after the JSON. Just the raw JSON.
"""


def extract_screen_text(ui_elements: list[dict]) -> str:
    """Extract visible text from UI elements for better observation."""
    texts = []
    for el in ui_elements:
        label = el.get("label", "")
        value = el.get("value", "")
        if label:
            texts.append(label)
        if value and value != label:
            texts.append(value)
    # Deduplicate while preserving order
    seen = set()
    unique = []
    for t in texts:
        if t not in seen:
            seen.add(t)
            unique.append(t)
    return " | ".join(unique)


def build_user_message(
    screenshot_b64: str,
    ui_elements: list[dict],
    user_path: str,
    step: int,
    screen_changed: bool | None,
) -> list[dict]:
    """Build a single user turn with screenshot + context."""
    screen_text = extract_screen_text(ui_elements)

    # Screen change feedback (None = first step, no previous action)
    change_note = ""
    if screen_changed is None:
        change_note = "This is the initial screen."
    elif screen_changed:
        change_note = "✅ SCREEN CHANGED after your last action."
    else:
        change_note = "⚠️ SCREEN DID NOT CHANGE after your last action. Your action may not have worked — try a different approach."

    return [
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",
                "data": screenshot_b64,
            },
        },
        {
            "type": "text",
            "text": (
                f"[Step {step}] {change_note}\n\n"
                f"USER PATH TO COMPLETE:\n{user_path}\n\n"
                f"VISIBLE TEXT ON SCREEN:\n{screen_text}\n\n"
                f"ACCESSIBILITY TREE (actionable elements):\n"
                f"{json.dumps(ui_elements, indent=2)}\n\n"
                f"What is the next action?"
            ),
        },
    ]


def call_claude(conversation: list[dict]) -> tuple[dict, str]:
    """Send the full conversation to Claude and get the next action.

    Args:
        conversation: The full multi-turn messages list.

    Returns:
        (parsed_action, raw_response_text) — the action dict and raw text for history.
    """
    response = httpx.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "content-type": "application/json",
            "anthropic-version": "2023-06-01",
        },
        json={
            "model": CLAUDE_MODEL,
            "max_tokens": 1024,
            "system": SYSTEM_PROMPT,
            "messages": conversation,
        },
        timeout=30.0,
    )

    if response.status_code != 200:
        raise RuntimeError(f"Claude API error {response.status_code}: {response.text}")

    data = response.json()
    if not data.get("content") or not data["content"][0].get("text"):
        raise RuntimeError(f"Unexpected API response: {json.dumps(data, indent=2)[:500]}")
    raw_text = data["content"][0]["text"]
    print(f"   🤖 Raw response: {raw_text[:200]}")

    # Parse the JSON response — extract JSON even if Claude adds extra text
    text = raw_text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
    if text.endswith("```"):
        text = text.rsplit("```", 1)[0]
    text = text.strip()

    # Try direct parse first
    try:
        return json.loads(text), raw_text
    except json.JSONDecodeError:
        pass

    # Extract JSON object from mixed text
    import re
    match = re.search(r'\{[^{}]*"action"\s*:\s*"[^"]+?"[^{}]*\}', text)
    if match:
        return json.loads(match.group()), raw_text

    raise json.JSONDecodeError("No valid JSON action found in response", text, 0)


def execute_action(action: dict) -> str | None:
    """Execute a single action returned by Claude.

    For tap actions, runs Playwright-style actionability checks first:
    1. Wait for UI stability (animations to finish)
    2. Find element at target coordinates
    3. Verify element is visible and large enough to tap
    4. Use fresh coordinates from the re-queried UI tree

    Returns a status message for feedback actions (verify), or None.
    """
    action_type = action["action"]

    if action_type == "tap":
        target_x, target_y = action["x"], action["y"]

        # --- Playwright-style actionability pipeline ---
        # Step 1: Wait for UI to stabilize (like Playwright's "stable" check)
        ui_elements = wait_for_stable(max_wait=1.5, poll_interval=0.3)

        # Step 2: Re-query — find element at target coords (like Playwright re-querying DOM)
        element = find_element_at(ui_elements, target_x, target_y)
        if element:
            # Step 3: Actionability check
            actionable, reason = check_actionable(element)
            if not actionable:
                print(f"   ⚠️  Actionability: {reason}")
                # Still attempt the tap — Claude might know better
            else:
                # Use fresh coordinates from the re-queried element
                target_x = element["center_x"]
                target_y = element["center_y"]
                label = element.get("label") or element.get("identifier") or ""
                if label:
                    print(f"   🎯 Locked on: \"{label}\" at ({target_x}, {target_y})")
        else:
            print(f"   ⚠️  No element found near ({target_x}, {target_y}) — tapping anyway")

        tap(target_x, target_y)

    elif action_type == "type":
        type_text(action["text"])
    elif action_type == "swipe":
        swipe(action["x1"], action["y1"], action["x2"], action["y2"])
    elif action_type == "press":
        press_button(action["button"])
    elif action_type == "wait":
        time.sleep(action.get("seconds", 2))
    elif action_type == "verify":
        # Playwright-style assertion: check if text exists on screen
        target_text = action.get("text", "").lower()
        ui_elements = wait_for_stable(max_wait=2.0, poll_interval=0.3)
        screen_text = extract_screen_text(ui_elements).lower()
        found = target_text in screen_text
        status = f"✅ VERIFIED: \"{action.get('text')}\" found on screen" if found else f"❌ VERIFY FAILED: \"{action.get('text')}\" not found on screen"
        print(f"   {status}")
        return status
    elif action_type in ("done", "fail"):
        pass  # Handled in the loop
    else:
        print(f"⚠️  Unknown action: {action_type}")

    return None


def trim_conversation(conversation: list[dict], max_turns: int = 20) -> list[dict]:
    """Keep conversation from growing unbounded.

    Keeps the first turn (initial context) and the most recent turns.
    Replaces trimmed screenshots with a text placeholder to save tokens.
    """
    if len(conversation) <= max_turns:
        return conversation

    # Always keep the first user message (has the initial screenshot + path)
    kept = [conversation[0]]
    # Keep the most recent (max_turns - 1) messages
    kept.extend(conversation[-(max_turns - 1):])
    return kept


def run_agent(user_path: str) -> dict:
    """Run the full agent loop for a given user path.

    Returns:
        {"status": "pass"|"fail", "steps": int, "reason": str, "history": [...]}
    """
    action_history = []
    conversation = []  # Multi-turn messages for Claude
    stale_count = 0
    last_screenshot = None

    print(f"\n🧪 Starting QA agent")
    print(f"📋 User path: {user_path}\n")

    for iteration in range(1, MAX_ITERATIONS + 1):
        print(f"─── Step {iteration}/{MAX_ITERATIONS} ───")

        # 1. Observe
        try:
            screenshot_b64 = take_screenshot()
            ui_tree = get_ui_tree()
            ui_elements = get_ui_tree_summary(ui_tree)
        except RuntimeError as e:
            print(f"❌ Simulator error: {e}")
            return {
                "status": "fail",
                "steps": iteration,
                "reason": f"Simulator error: {e}",
                "history": action_history,
            }

        # Detect stale screen (nothing changed after action)
        if last_screenshot is None:
            screen_changed = None  # First step
        elif screenshot_b64 == last_screenshot:
            screen_changed = False
            stale_count += 1
            if stale_count >= 3:
                print("⚠️  Screen unchanged for 3 steps")
        else:
            screen_changed = True
            stale_count = 0
        last_screenshot = screenshot_b64

        print(f"   📸 Screenshot captured | {len(ui_elements)} UI elements found", end="")
        if screen_changed is False:
            print(" | ⚠️  screen unchanged")
        elif screen_changed is True:
            print(" | ✅ screen changed")
        else:
            print()

        # 2. Build new user turn and add to conversation
        user_msg = build_user_message(
            screenshot_b64, ui_elements, user_path, iteration, screen_changed,
        )
        conversation.append({"role": "user", "content": user_msg})

        # Trim conversation to avoid token limits
        conversation = trim_conversation(conversation)

        # 3. Think
        try:
            action, raw_response = call_claude(conversation)
        except (RuntimeError, json.JSONDecodeError) as e:
            print(f"❌ Claude error: {e}")
            return {
                "status": "fail",
                "steps": iteration,
                "reason": f"Claude error: {e}",
                "history": action_history,
            }

        # Add Claude's response to conversation history
        conversation.append({"role": "assistant", "content": raw_response})

        reason = action.get("reason", "")
        action_type = action["action"]
        print(f"   🧠 Decision: {action_type} — {reason}")

        # 4. Check for terminal states
        if action_type == "done":
            print(f"\n✅ PATH COMPLETE in {iteration} steps")
            print(f"   {reason}")
            return {
                "status": "pass",
                "steps": iteration,
                "reason": reason,
                "history": action_history,
            }

        if action_type == "fail":
            print(f"\n❌ PATH FAILED at step {iteration}")
            print(f"   {reason}")
            return {
                "status": "fail",
                "steps": iteration,
                "reason": reason,
                "history": action_history,
            }

        # 5. Act
        action_feedback = None
        try:
            action_feedback = execute_action(action)
        except RuntimeError as e:
            print(f"   ⚠️  Action error: {e}")
            action_feedback = f"Action error: {e}"

        # If verify returned feedback, inject it into conversation so Claude sees the result
        if action_feedback:
            conversation.append({
                "role": "user",
                "content": f"[System feedback] {action_feedback}",
            })

        # Record history
        details = ""
        if action_type == "tap":
            details = f"x={action['x']}, y={action['y']}"
        elif action_type == "type":
            details = f"text='{action['text']}'"
        elif action_type == "swipe":
            details = f"({action['x1']},{action['y1']}) → ({action['x2']},{action['y2']})"
        elif action_type == "verify":
            details = f"text='{action.get('text', '')}' → {'found' if action_feedback and '✅' in action_feedback else 'not found'}"

        action_history.append({
            "step": iteration,
            "action": action_type,
            "details": details,
            "reason": reason,
        })

    # Max iterations reached
    print(f"\n⏱️  MAX ITERATIONS ({MAX_ITERATIONS}) reached")
    return {
        "status": "fail",
        "steps": MAX_ITERATIONS,
        "reason": "Max iterations reached without completing path",
        "history": action_history,
    }
