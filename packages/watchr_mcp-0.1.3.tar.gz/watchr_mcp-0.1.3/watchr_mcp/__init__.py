"""Watchr MCP — iOS Simulator QA agent for Claude Code."""
