"""iOS QA Agent — entry point.

Usage:
    python main.py "sign up as a new user, complete onboarding, go to settings"
    python main.py --bundle com.affinitylabs.archives "open the app, navigate to quiz section, start a quiz"
"""

import argparse
import json
import sys
import time
from config import APP_BUNDLE_ID
from simulator import boot_simulator, launch_app, terminate_app
from agent import run_agent


def main():
    parser = argparse.ArgumentParser(
        description="iOS QA Agent — AI-powered mobile app testing",
    )
    parser.add_argument(
        "user_path",
        help="The user journey to test (e.g. 'sign up, complete onboarding, go to settings')",
    )
    parser.add_argument(
        "--bundle",
        default=APP_BUNDLE_ID,
        help=f"App bundle ID (default: {APP_BUNDLE_ID})",
    )
    parser.add_argument(
        "--fresh",
        action="store_true",
        help="Kill and relaunch the app before testing",
    )
    parser.add_argument(
        "--output",
        help="Save results to a JSON file",
    )
    args = parser.parse_args()

    # 1. Boot simulator
    print("📱 Checking simulator...")
    try:
        boot_simulator()
    except RuntimeError as e:
        print(f"❌ Failed to boot simulator: {e}")
        sys.exit(1)

    # 2. Launch app
    if args.fresh:
        print(f"🔄 Restarting app: {args.bundle}")
        terminate_app(args.bundle)
        time.sleep(1)

    print(f"🚀 Launching app: {args.bundle}")
    try:
        launch_app(args.bundle)
    except RuntimeError as e:
        print(f"❌ Failed to launch app: {e}")
        sys.exit(1)

    # 3. Run the agent
    start_time = time.time()
    result = run_agent(args.user_path)
    elapsed = time.time() - start_time

    # 4. Summary
    result["elapsed_seconds"] = round(elapsed, 1)
    result["bundle_id"] = args.bundle
    result["user_path"] = args.user_path

    print("\n" + "=" * 50)
    print(f"{'✅ PASS' if result['status'] == 'pass' else '❌ FAIL'}")
    print(f"Steps: {result['steps']} | Time: {result['elapsed_seconds']}s")
    print(f"Reason: {result['reason']}")
    print("=" * 50)

    # 5. Save results if requested
    if args.output:
        with open(args.output, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n📄 Results saved to {args.output}")

    sys.exit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
