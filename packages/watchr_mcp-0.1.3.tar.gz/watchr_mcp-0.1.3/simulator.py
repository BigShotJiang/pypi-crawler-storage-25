"""iOS Simulator control layer.

Wraps xcrun simctl and idb for:
- Screenshots
- Tap / swipe / text input
- Accessibility tree extraction
"""

import subprocess
import json
import base64
import time
from config import SIMULATOR_DEVICE_ID, SCREENSHOT_PATH


def run_cmd(cmd: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
    """Run a shell command and return the result."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Command failed: {' '.join(cmd)}\n"
                f"stderr: {result.stderr.strip()}"
            )
        return result
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"Command timed out: {' '.join(cmd)}")


# ── Screenshots ──────────────────────────────────────────────


def take_screenshot() -> str:
    """Capture the simulator screen and return as base64-encoded PNG."""
    run_cmd([
        "xcrun", "simctl", "io", SIMULATOR_DEVICE_ID,
        "screenshot", "--type=png", SCREENSHOT_PATH,
    ])
    with open(SCREENSHOT_PATH, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8")


# ── UI Tree ──────────────────────────────────────────────────


def get_ui_tree() -> dict:
    """Pull the full accessibility tree from the simulator via idb.

    Returns a nested dict of UI elements with:
    - AXLabel, AXValue, AXIdentifier (maps to testID)
    - frame: {x, y, width, height}
    - children: [...]
    """
    result = run_cmd(["idb", "ui", "describe-all", "--udid", SIMULATOR_DEVICE_ID])
    try:
        tree = json.loads(result.stdout)
    except json.JSONDecodeError:
        # idb sometimes outputs non-JSON — return raw text wrapped
        tree = {"raw": result.stdout.strip()}
    return tree


def get_ui_tree_summary(tree, depth: int = 0, max_depth: int = 10) -> list[dict]:
    """Flatten the UI tree into a list of actionable elements.

    Returns a list of dicts with:
    - label, identifier, value, type
    - center_x, center_y (tap targets)
    """
    # idb returns a flat list — handle both list and dict formats
    if isinstance(tree, list):
        elements = []
        for item in tree:
            if isinstance(item, dict):
                elements.extend(get_ui_tree_summary(item, depth, max_depth))
        return elements

    elements = []
    if depth > max_depth:
        return elements

    # Extract element info
    label = tree.get("AXLabel") or tree.get("label") or ""
    identifier = tree.get("AXIdentifier") or tree.get("identifier") or ""
    value = tree.get("AXValue") or tree.get("value") or ""
    elem_type = tree.get("type") or tree.get("AXType") or ""
    frame = tree.get("frame") or tree.get("AXFrame") or {}

    # Calculate center point for tapping
    if isinstance(frame, dict):
        x = frame.get("x", 0)
        y = frame.get("y", 0)
        w = frame.get("width", 0)
        h = frame.get("height", 0)
    else:
        x = y = w = h = 0
    center_x = x + w / 2
    center_y = y + h / 2

    # Only include elements that have some identifying info
    if label or identifier or value:
        elements.append({
            "label": label,
            "identifier": identifier,
            "value": value,
            "type": elem_type,
            "center_x": round(center_x, 1),
            "center_y": round(center_y, 1),
            "width": round(w, 1),
            "height": round(h, 1),
        })

    # Recurse into children
    children = tree.get("children") or tree.get("AXChildren") or []
    for child in children:
        if isinstance(child, dict):
            elements.extend(get_ui_tree_summary(child, depth + 1, max_depth))

    return elements


# ── Stability & Actionability ───────────────────────────────


def wait_for_stable(max_wait: float = 2.0, poll_interval: float = 0.3) -> list[dict]:
    """Wait until the UI tree stops changing, then return it.

    Like Playwright's stability check — don't act while the screen is animating.
    Polls the UI tree repeatedly; returns once two consecutive reads match.
    """
    prev = None
    latest = []
    elapsed = 0.0
    while elapsed < max_wait:
        tree = get_ui_tree()
        latest = get_ui_tree_summary(tree)
        if prev is not None and latest == prev:
            return latest
        prev = latest
        time.sleep(poll_interval)
        elapsed += poll_interval
    # Timed out waiting for stability — return what we have
    return latest


def find_element_at(ui_elements: list[dict], x: float, y: float, tolerance: float = 20.0) -> dict | None:
    """Find the UI element whose center is closest to (x, y) within tolerance.

    Like Playwright re-querying the DOM before acting — finds the element
    that's actually at those coordinates *right now*.
    """
    best = None
    best_dist = float("inf")
    for el in ui_elements:
        dx = el["center_x"] - x
        dy = el["center_y"] - y
        dist = (dx * dx + dy * dy) ** 0.5
        if dist < best_dist:
            best_dist = dist
            best = el
    if best and best_dist <= tolerance:
        return best
    return None


def check_actionable(element: dict) -> tuple[bool, str]:
    """Run Playwright-style actionability checks on a UI element.

    Checks:
    1. Has non-zero size (visible, not collapsed)
    2. Has a reasonable tap target (not tiny)

    Returns (is_actionable, reason).
    """
    w = element.get("width", 0)
    h = element.get("height", 0)

    if w == 0 or h == 0:
        return False, f"Element has zero size ({w}x{h}) — not visible"
    if w < 4 or h < 4:
        return False, f"Element too small to tap ({w}x{h})"

    return True, "Element is actionable"


# ── Interactions ─────────────────────────────────────────────


def tap(x: float, y: float) -> None:
    """Tap at the given coordinates."""
    run_cmd(["idb", "ui", "tap", str(int(x)), str(int(y)), "--udid", SIMULATOR_DEVICE_ID])
    time.sleep(0.5)  # Let the UI settle


def swipe(x1: float, y1: float, x2: float, y2: float, duration: float = 0.3) -> None:
    """Swipe from (x1,y1) to (x2,y2)."""
    run_cmd([
        "idb", "ui", "swipe",
        str(int(x1)), str(int(y1)),
        str(int(x2)), str(int(y2)),
        "--duration", str(duration),
        "--udid", SIMULATOR_DEVICE_ID,
    ])
    time.sleep(0.5)


def type_text(text: str) -> None:
    """Type text into the currently focused field."""
    run_cmd(["idb", "ui", "text", text, "--udid", SIMULATOR_DEVICE_ID])
    time.sleep(0.3)


def press_button(button: str) -> None:
    """Press a hardware button. Options: HOME, SIRI, etc."""
    button_map = {
        "home": "HOME",
        "siri": "SIRI",
    }
    mapped = button_map.get(button.lower(), button.upper())
    run_cmd(["idb", "ui", "button", mapped, "--udid", SIMULATOR_DEVICE_ID])
    time.sleep(0.5)


# ── App Lifecycle ────────────────────────────────────────────


def launch_app(bundle_id: str) -> None:
    """Launch an app on the simulator."""
    run_cmd(["xcrun", "simctl", "launch", SIMULATOR_DEVICE_ID, bundle_id])
    time.sleep(2)  # Wait for app to load


def terminate_app(bundle_id: str) -> None:
    """Terminate a running app."""
    try:
        run_cmd(["xcrun", "simctl", "terminate", SIMULATOR_DEVICE_ID, bundle_id])
    except RuntimeError:
        pass  # App might not be running


def boot_simulator() -> None:
    """Boot the simulator if not already booted."""
    result = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "booted"],
        capture_output=True, text=True,
    )
    if "Booted" not in result.stdout:
        # Boot the first available iPhone simulator
        list_result = subprocess.run(
            ["xcrun", "simctl", "list", "devices", "available", "-j"],
            capture_output=True, text=True,
        )
        devices = json.loads(list_result.stdout)
        for runtime, device_list in devices.get("devices", {}).items():
            if "iOS" in runtime:
                for device in device_list:
                    if "iPhone" in device.get("name", ""):
                        run_cmd(["xcrun", "simctl", "boot", device["udid"]])
                        print(f"Booted: {device['name']} ({device['udid']})")
                        time.sleep(5)
                        return
        raise RuntimeError("No available iPhone simulator found")
    else:
        print("Simulator already booted.")
