# CLAUDE.md

## Rules

- Never include `Co-Authored-By: Claude` in commit messages
- Do not add any Claude attribution to commits pushed to GitHub

## Project Overview

Watchr is an MCP server (`mcp_server.py`) that exposes iOS Simulator controls as tools for Claude Code. It wraps `xcrun simctl` (screenshots, app lifecycle) and `idb` (taps, swipes, text input, accessibility tree) to let Claude Code drive the simulator directly.

**Key files:**
- `mcp_server.py` — the MCP server (this is what Claude Code talks to)
- `simulator.py` — standalone simulator control layer (used by `agent.py` for CI/automation)
- `agent.py` — standalone QA agent (alternative to the MCP approach)

## MCP Development Iteration Loop

When an MCP tool errors out during use, follow this cycle:

1. **Read the error** — the tool result will contain the stderr/exception from `mcp_server.py`
2. **Fix the code** — edit `mcp_server.py` directly (the source is in this repo)
3. **Tell the user to restart the MCP server** — code changes are NOT hot-reloaded. The user must restart via `/mcp` menu or by restarting Claude Code
4. **Re-test** — run the same tool call again to verify the fix

**Do not** try to work around MCP bugs from the outside. Fix the server code.

## Resolved Issues

These were fixed in `mcp_server.py` and should not recur:

- **`idb` "booted" UDID** — `_get_device_id()` resolves "booted" to real UDID via simctl, cached per session
- **Screenshot too large** — `screenshot()` resizes to 900px height via `sips` by default. Pass `full_resolution=True` to get the original
- **UDID resolved on every call** — now cached in `_cached_udid`, invalidated only on boot/shutdown

## Speed: Prefer Combo Tools

The MCP server has three tiers of tools. **Always prefer the fastest tier:**

### Tier 1: Batch (fastest — 1 round trip for N actions)
- **`run_steps`** — pass a JSON array of actions, get back final screenshot + ui_tree. Use when you know what to do (fill a form, skip known screens)
- Example: `run_steps('[{"action":"tap_element","label":"Email"},{"action":"type","text":"a@b.com"},{"action":"tap_element","label":"Continue"}]')`

### Tier 2: Combo (fast — 1 round trip per action)
- **`perform`** — does action + wait + screenshot + ui_tree in one call. Use for explore/react loops
- **`observe`** — screenshot + ui_tree in one call. Use to see the current screen
- Example: `perform(action="tap_element", label="Settings")`

### Tier 3: Individual (slow — 1 round trip each)
- `tap`, `tap_element`, `type_text`, `swipe`, `screenshot`, `ui_tree`, `wait_for_stable`
- Only use these when you need fine-grained control

### Other tips
- Prefer `tap_element("Settings")` over `tap(x, y)` when the element has a label in the accessibility tree
- If icons don't appear in `ui_tree`, they lack accessibility labels — use `observe()` to see the screenshot and guess coordinates

## QA Testing Tools

The MCP server includes QA-specific tools for thorough testing:

### After every action, check for crashes:
- **`check_app_state(bundle_id)`** — verify app is running, read crash logs and console errors
- Call this after any action that might cause issues (navigation, form submission, deep links)

### Accessibility audit:
- **`audit_accessibility()`** — scan current screen for missing labels, small touch targets
- Run on every unique screen during a test pass

### Visual regression:
- **`save_baseline(name)`** — save a golden screenshot for a screen (e.g., "landing_page")
- **`compare_with_baseline(name)`** — compare current screen vs saved baseline
- Use during regression testing after code changes

### Chaos/monkey testing:
- **`monkey_test(bundle_id, duration)`** — random taps and swipes to find crashes
- Run at the end of a test session to stress-test the current screen

### Performance (built into `perform`):
- Every `perform` call now reports timing: action time, stabilization time, total
- Screens taking >3s are flagged as slow, >5s as very slow

## Simulator Tool Differences

| Tool | Backend | Notes |
|------|---------|-------|
| `screenshot` | `xcrun simctl io` | Auto-resized, simctl accepts "booted" |
| `launch_app` | `xcrun simctl launch` | simctl accepts "booted" |
| `terminate_app` | `xcrun simctl terminate` | simctl accepts "booted" |
| `boot_simulator` | `xcrun simctl boot` | Invalidates UDID cache |
| `ui_tree` | `idb ui describe-all` | Uses cached real UDID |
| `tap` | `idb ui tap` | Uses cached real UDID |
| `tap_element` | `idb ui tap` | Looks up coordinates from accessibility tree by label |
| `type_text` | `idb ui text` | Uses cached real UDID |
| `swipe` | `idb ui swipe` | Uses cached real UDID |
| `press_button` | `idb ui button` | Uses cached real UDID |
