"""Watchr MCP Server — exposes iOS simulator controls as MCP tools.

This turns the iOS simulator into something Claude Code can drive directly,
like Playwright MCP does for browsers. No API calls needed — Claude Code
IS the agent.

Usage:
    Register in Claude Code:
        claude mcp add watchr -- uv run python /path/to/mcp_server.py

    Then just tell Claude Code:
        "Test this user path in the iOS simulator: sign up, complete onboarding, go to settings"
"""

import json
import subprocess
import base64
import time
import random
import os
import shutil
import sys
from mcp.server.fastmcp import FastMCP


# ── Dependency check ───────────────────────────────────────

def _check_dependencies():
    """Check that required system tools are installed.
    Warns but does NOT exit — let the MCP server start so Claude Code
    can show the server as connected and report errors through tools.
    """
    # Ensure brew paths are in PATH (macOS often doesn't inherit shell PATH)
    for brew_path in ["/opt/homebrew/bin", "/usr/local/bin"]:
        if brew_path not in os.environ.get("PATH", ""):
            os.environ["PATH"] = brew_path + ":" + os.environ.get("PATH", "")

    missing = []
    if not shutil.which("xcrun"):
        missing.append("Xcode Command Line Tools (xcode-select --install)")
    if not shutil.which("idb"):
        missing.append("idb-companion (brew install idb-companion)")
    if missing:
        print("⚠️  Missing dependencies:", file=sys.stderr)
        for dep in missing:
            print(f"   → {dep}", file=sys.stderr)
        print("Some tools may not work until these are installed.", file=sys.stderr)

_check_dependencies()

# ── Config ──────────────────────────────────────────────────

SIMULATOR_DEVICE_ID = "booted"
SCREENSHOT_PATH = "/tmp/sim_screenshot.png"
SCREENSHOT_RESIZED_PATH = "/tmp/sim_screenshot_small.jpg"
SCREENSHOT_MAX_HEIGHT = 500  # Resize to keep under MCP message limits
BASELINE_DIR = "/tmp/watchr_baselines"  # Visual regression baselines
MIN_TOUCH_TARGET = 44  # Apple HIG minimum touch target size in points

# ── Server ──────────────────────────────────────────────────

mcp = FastMCP(
    "watchr",
    instructions="""You have access to an iOS Simulator. Use these tools to test mobile apps:

## Fast workflow (preferred — use `perform` for most interactions):
1. Use `launch_app` to open the app.
2. Use `observe` to get both a screenshot AND the UI tree in one call.
3. Use `perform` for all interactions — it does action + wait + screenshot + ui_tree in ONE call.
4. Use `run_steps` to batch multiple actions and only get the final state.

## Individual tools (use when you need fine-grained control):
- `screenshot`, `ui_tree` — observe the screen
- `tap`, `tap_element`, `swipe`, `type_text`, `press_button` — interact
- `wait_for_stable` — wait for animations
- `verify_text` — assert text is visible

PREFER `perform` and `run_steps` over individual tools — they are 3-4x faster
because they combine multiple operations into a single round trip.

## QA tools (use these to find bugs):
- `check_app_state` — verify app is still running, read crash logs
- `audit_accessibility` — find missing labels, small touch targets, contrast issues
- `save_baseline` / `compare_with_baseline` — visual regression testing
- `monkey_test` — random interactions to find crashes
""",
)


# ── Helpers ─────────────────────────────────────────────────

# Cached UDID — resolved once, reused for the session
_cached_udid: str | None = None


def _run_cmd(cmd: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
    """Run a shell command and return result."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(f"Command failed: {' '.join(cmd)}\nstderr: {result.stderr.strip()}")
        return result
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"Command timed out: {' '.join(cmd)}")


def _get_device_id() -> str:
    """Get the current simulator device ID.

    Resolves "booted" into the actual UDID because idb doesn't accept "booted".
    xcrun simctl does, but idb needs the real UDID.
    Caches the result to avoid repeated subprocess calls.
    """
    global _cached_udid

    if SIMULATOR_DEVICE_ID != "booted":
        return SIMULATOR_DEVICE_ID

    if _cached_udid is not None:
        return _cached_udid

    result = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "booted", "-j"],
        capture_output=True, text=True,
    )
    devices = json.loads(result.stdout)
    for _, device_list in devices.get("devices", {}).items():
        for device in device_list:
            if device.get("state") == "Booted":
                _cached_udid = device["udid"]
                return _cached_udid

    raise RuntimeError("No booted simulator found. Run boot_simulator first.")


def _invalidate_device_cache():
    """Clear cached UDID — call after boot/shutdown operations."""
    global _cached_udid
    _cached_udid = None


def _flatten_ui_tree(tree, depth: int = 0, max_depth: int = 10) -> list[dict]:
    """Flatten the UI tree into actionable elements with tap coordinates."""
    if isinstance(tree, list):
        elements = []
        for item in tree:
            if isinstance(item, dict):
                elements.extend(_flatten_ui_tree(item, depth, max_depth))
        return elements

    elements = []
    if depth > max_depth:
        return elements

    label = tree.get("AXLabel") or tree.get("label") or ""
    identifier = tree.get("AXIdentifier") or tree.get("identifier") or ""
    value = tree.get("AXValue") or tree.get("value") or ""
    elem_type = tree.get("type") or tree.get("AXType") or ""
    frame = tree.get("frame") or tree.get("AXFrame") or {}

    if isinstance(frame, dict):
        x = frame.get("x", 0)
        y = frame.get("y", 0)
        w = frame.get("width", 0)
        h = frame.get("height", 0)
    else:
        x = y = w = h = 0

    center_x = x + w / 2
    center_y = y + h / 2

    if label or identifier or value:
        elements.append({
            "label": label,
            "identifier": identifier,
            "value": value,
            "type": elem_type,
            "center_x": round(center_x, 1),
            "center_y": round(center_y, 1),
            "width": round(w, 1),
            "height": round(h, 1),
        })

    children = tree.get("children") or tree.get("AXChildren") or []
    for child in children:
        if isinstance(child, dict):
            elements.extend(_flatten_ui_tree(child, depth + 1, max_depth))

    return elements


def _get_elements() -> list[dict]:
    """Get the current UI elements (shared by multiple tools)."""
    udid = _get_device_id()
    result = _run_cmd(["idb", "ui", "describe-all", "--udid", udid])
    try:
        tree = json.loads(result.stdout)
    except json.JSONDecodeError:
        return []
    return _flatten_ui_tree(tree)


def _take_screenshot_b64() -> str:
    """Capture, resize to JPEG, and return base64 string."""
    udid = _get_device_id()
    _run_cmd([
        "xcrun", "simctl", "io", udid,
        "screenshot", "--type=png", SCREENSHOT_PATH,
    ])
    subprocess.run(
        ["sips", "-s", "format", "jpeg", "-s", "formatOptions", "40",
         "-Z", str(SCREENSHOT_MAX_HEIGHT),
         SCREENSHOT_PATH, "--out", SCREENSHOT_RESIZED_PATH],
        capture_output=True, text=True,
    )
    with open(SCREENSHOT_RESIZED_PATH, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8")


def _wait_for_stable_internal(max_seconds: float = 2.0) -> list[dict]:
    """Wait for screen stability and return the final UI elements."""
    udid = _get_device_id()
    prev = None
    latest = []
    elapsed = 0.0
    poll = 0.3
    while elapsed < max_seconds:
        result = _run_cmd(["idb", "ui", "describe-all", "--udid", udid])
        try:
            tree = json.loads(result.stdout)
            latest = _flatten_ui_tree(tree)
        except json.JSONDecodeError:
            latest = []
        if prev is not None and latest == prev:
            return latest
        prev = latest
        time.sleep(poll)
        elapsed += poll
    return latest


def _observe_screen() -> str:
    """Capture screenshot + UI tree together. Used by observe and perform."""
    elements = _wait_for_stable_internal(2.0)
    b64 = _take_screenshot_b64()
    result = f"data:image/jpeg;base64,{b64}\n\n"
    result += f"UI Elements ({len(elements)}):\n"
    result += json.dumps(elements, indent=2)
    return result


def _find_element(label: str, elements: list[dict]) -> dict | None:
    """Find element by label (exact match first, then partial)."""
    target = label.lower()
    for el in elements:
        el_label = (el.get("label") or "").lower()
        el_id = (el.get("identifier") or "").lower()
        if target == el_label or target == el_id:
            return el
    for el in elements:
        el_label = (el.get("label") or "").lower()
        el_id = (el.get("identifier") or "").lower()
        el_value = (el.get("value") or "").lower()
        if target in el_label or target in el_id or target in el_value:
            return el
    return None


def _execute_action(action: str, udid: str, **kwargs) -> str:
    """Execute a single action. Returns a description of what was done."""
    if action == "tap":
        x, y = int(kwargs["x"]), int(kwargs["y"])
        _run_cmd(["idb", "ui", "tap", str(x), str(y), "--udid", udid])
        time.sleep(0.5)
        return f"Tapped at ({x}, {y})"

    elif action == "tap_element":
        label = kwargs["label"]
        elements = _get_elements()
        match = _find_element(label, elements)
        if not match:
            visible = [el.get("label") or el.get("value") or "" for el in elements]
            visible = [t for t in visible if t][:15]
            return f"❌ Element \"{label}\" not found. Visible: {', '.join(visible)}"
        cx, cy = int(match["center_x"]), int(match["center_y"])
        _run_cmd(["idb", "ui", "tap", str(cx), str(cy), "--udid", udid])
        time.sleep(0.5)
        return f"Tapped \"{match.get('label')}\" at ({cx}, {cy})"

    elif action == "type":
        text = kwargs["text"]
        _run_cmd(["idb", "ui", "text", text, "--udid", udid])
        time.sleep(0.3)
        return f"Typed: {text}"

    elif action == "swipe":
        x1, y1 = int(kwargs["x1"]), int(kwargs["y1"])
        x2, y2 = int(kwargs["x2"]), int(kwargs["y2"])
        _run_cmd([
            "idb", "ui", "swipe", str(x1), str(y1), str(x2), str(y2),
            "--duration", "0.3", "--udid", udid,
        ])
        time.sleep(0.5)
        return f"Swiped ({x1},{y1}) → ({x2},{y2})"

    elif action == "press":
        btn = kwargs.get("button", "home") or "home"
        button_map = {"home": "HOME", "siri": "SIRI"}
        mapped = button_map.get(btn.lower(), btn.upper())
        _run_cmd(["idb", "ui", "button", mapped, "--udid", udid])
        time.sleep(0.5)
        return f"Pressed {mapped}"

    else:
        return f"Unknown action: {action}"


# ── MCP Tools ───────────────────────────────────────────────


@mcp.tool()
def screenshot(full_resolution: bool = False) -> str:
    """Capture the current simulator screen and return as base64 PNG image.

    Call this after every action to see what happened.
    Compare with previous screenshots to verify your action worked.

    Args:
        full_resolution: If True, return full-size screenshot (may be very large).
                        Default False returns a resized version that fits in MCP messages.
    """
    udid = _get_device_id()
    _run_cmd([
        "xcrun", "simctl", "io", udid,
        "screenshot", "--type=png", SCREENSHOT_PATH,
    ])

    if not full_resolution:
        # Resize to keep under MCP message limits
        subprocess.run(
            ["sips", "-s", "format", "jpeg", "-s", "formatOptions", "40",
             "-Z", str(SCREENSHOT_MAX_HEIGHT),
             SCREENSHOT_PATH, "--out", SCREENSHOT_RESIZED_PATH],
            capture_output=True, text=True,
        )
        read_path = SCREENSHOT_RESIZED_PATH
    else:
        read_path = SCREENSHOT_PATH

    with open(read_path, "rb") as f:
        b64 = base64.standard_b64encode(f.read()).decode("utf-8")
    mime = "image/png" if full_resolution else "image/jpeg"
    return f"data:{mime};base64,{b64}"


@mcp.tool()
def ui_tree() -> str:
    """Get the accessibility tree of the current screen.

    Returns a JSON list of UI elements, each with:
    - label: the visible text
    - identifier: testID (use this in tap reasons)
    - value: current value (for text fields, switches)
    - type: element type
    - center_x, center_y: coordinates to tap
    - width, height: element size

    Use the center_x/center_y coordinates for tapping — they're more
    reliable than guessing from the screenshot.
    """
    elements = _get_elements()
    if not elements:
        udid = _get_device_id()
        result = _run_cmd(["idb", "ui", "describe-all", "--udid", udid])
        return f"Raw UI output (not JSON):\n{result.stdout.strip()}"
    return json.dumps(elements, indent=2)


@mcp.tool()
def tap(x: float, y: float) -> str:
    """Tap at the given coordinates on the simulator screen.

    Args:
        x: The x coordinate to tap (use center_x from ui_tree)
        y: The y coordinate to tap (use center_y from ui_tree)

    Always take a screenshot after tapping to verify the action worked.
    If the screen didn't change, try different coordinates or a different element.
    """
    udid = _get_device_id()
    _run_cmd(["idb", "ui", "tap", str(int(x)), str(int(y)), "--udid", udid])
    time.sleep(0.5)
    return f"Tapped at ({int(x)}, {int(y)})"


@mcp.tool()
def tap_element(label: str) -> str:
    """Find a UI element by label text and tap it.

    More reliable than guessing coordinates from screenshots — looks up the
    element in the accessibility tree and taps its center point.

    Args:
        label: Text to search for (case-insensitive partial match against
               label, identifier, and value fields)

    Returns the element that was tapped, or an error with visible elements.
    """
    elements = _get_elements()
    target = label.lower()

    # Try exact match first, then partial
    match = None
    for el in elements:
        el_label = (el.get("label") or "").lower()
        el_id = (el.get("identifier") or "").lower()
        el_value = (el.get("value") or "").lower()
        if target == el_label or target == el_id:
            match = el
            break
    if not match:
        for el in elements:
            el_label = (el.get("label") or "").lower()
            el_id = (el.get("identifier") or "").lower()
            el_value = (el.get("value") or "").lower()
            if target in el_label or target in el_id or target in el_value:
                match = el
                break

    if not match:
        visible = [el.get("label") or el.get("value") or "" for el in elements]
        visible = [t for t in visible if t][:20]
        return f"❌ Element \"{label}\" not found. Visible: {', '.join(visible)}"

    cx, cy = match["center_x"], match["center_y"]
    udid = _get_device_id()
    _run_cmd(["idb", "ui", "tap", str(int(cx)), str(int(cy)), "--udid", udid])
    time.sleep(0.5)
    return f"Tapped \"{match.get('label') or match.get('identifier')}\" at ({int(cx)}, {int(cy)})"


@mcp.tool()
def type_text(text: str) -> str:
    """Type text into the currently focused text field.

    Args:
        text: The text to type

    Make sure a text field is focused first (tap it, then call type_text).
    """
    udid = _get_device_id()
    _run_cmd(["idb", "ui", "text", text, "--udid", udid])
    time.sleep(0.3)
    return f"Typed: {text}"


@mcp.tool()
def swipe(x1: float, y1: float, x2: float, y2: float) -> str:
    """Swipe from one point to another on the simulator screen.

    Args:
        x1: Start x coordinate
        y1: Start y coordinate
        x2: End x coordinate
        y2: End y coordinate

    Common patterns:
    - Scroll down: swipe(200, 600, 200, 200)
    - Scroll up: swipe(200, 200, 200, 600)
    """
    udid = _get_device_id()
    _run_cmd([
        "idb", "ui", "swipe",
        str(int(x1)), str(int(y1)), str(int(x2)), str(int(y2)),
        "--duration", "0.3", "--udid", udid,
    ])
    time.sleep(0.5)
    return f"Swiped from ({int(x1)},{int(y1)}) to ({int(x2)},{int(y2)})"


@mcp.tool()
def press_button(button: str) -> str:
    """Press a hardware button on the simulator.

    Args:
        button: Button name — "home" or "siri"
    """
    udid = _get_device_id()
    button_map = {"home": "HOME", "siri": "SIRI"}
    mapped = button_map.get(button.lower(), button.upper())
    _run_cmd(["idb", "ui", "button", mapped, "--udid", udid])
    time.sleep(0.5)
    return f"Pressed {mapped} button"


@mcp.tool()
def launch_app(bundle_id: str) -> str:
    """Launch an app on the simulator.

    Args:
        bundle_id: The app's bundle identifier (e.g. "com.example.myapp")
    """
    udid = _get_device_id()
    _run_cmd(["xcrun", "simctl", "launch", udid, bundle_id])
    time.sleep(2)
    return f"Launched {bundle_id}"


@mcp.tool()
def terminate_app(bundle_id: str) -> str:
    """Terminate a running app on the simulator.

    Args:
        bundle_id: The app's bundle identifier
    """
    udid = _get_device_id()
    try:
        _run_cmd(["xcrun", "simctl", "terminate", udid, bundle_id])
    except RuntimeError:
        return f"{bundle_id} was not running"
    return f"Terminated {bundle_id}"


@mcp.tool()
def boot_simulator(device_name: str = "") -> str:
    """Boot the iOS simulator.

    Args:
        device_name: Optional — specific device name like "iPhone 16". If empty, boots the first available iPhone.
    """
    _invalidate_device_cache()

    # Check if already booted
    result = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "booted"],
        capture_output=True, text=True,
    )
    if "Booted" in result.stdout:
        return "Simulator already booted."

    # Find and boot a device
    list_result = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "available", "-j"],
        capture_output=True, text=True,
    )
    devices = json.loads(list_result.stdout)
    for runtime, device_list in devices.get("devices", {}).items():
        if "iOS" in runtime:
            for device in device_list:
                name = device.get("name", "")
                if device_name and device_name.lower() not in name.lower():
                    continue
                if "iPhone" in name:
                    _run_cmd(["xcrun", "simctl", "boot", device["udid"]])
                    time.sleep(5)
                    return f"Booted: {name} ({device['udid']})"

    return "No available iPhone simulator found"


@mcp.tool()
def list_simulators() -> str:
    """List all available iOS simulators and their status (booted/shutdown)."""
    result = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "available", "-j"],
        capture_output=True, text=True,
    )
    devices = json.loads(result.stdout)
    lines = []
    for runtime, device_list in devices.get("devices", {}).items():
        if "iOS" in runtime:
            runtime_name = runtime.split(".")[-1].replace("-", " ")
            for device in device_list:
                status = device.get("state", "unknown")
                lines.append(f"  {device['name']} ({device['udid']}) — {status}")
            if lines:
                lines.insert(0, f"\n{runtime_name}:")
    return "\n".join(lines) if lines else "No iOS simulators found"


@mcp.tool()
def wait_for_stable(max_seconds: float = 2.0) -> str:
    """Wait until the screen stops changing (animations finish).

    Like Playwright's auto-wait — call this before interacting with
    elements that might be animating or loading.

    Args:
        max_seconds: Maximum time to wait (default 2s)

    Returns the number of UI elements found once stable.
    """
    udid = _get_device_id()
    prev = None
    elapsed = 0.0
    poll = 0.3
    while elapsed < max_seconds:
        result = _run_cmd(["idb", "ui", "describe-all", "--udid", udid])
        try:
            tree = json.loads(result.stdout)
            current = _flatten_ui_tree(tree)
        except json.JSONDecodeError:
            current = []

        if prev is not None and current == prev:
            return f"Screen stable — {len(current)} elements found"
        prev = current
        time.sleep(poll)
        elapsed += poll

    count = len(prev) if prev else 0
    return f"Screen may still be changing (timed out after {max_seconds}s) — {count} elements found"


@mcp.tool()
def verify_text(text: str) -> str:
    """Assert that specific text is visible on the current screen.

    Like Playwright's expect(locator).toHaveText() — checks the
    accessibility tree for the given text.

    Args:
        text: The text to look for (case-insensitive partial match)

    Returns whether the text was found and what elements contain it.
    """
    elements = _get_elements()
    if not elements:
        return "VERIFY FAILED — could not read UI tree"

    target = text.lower()
    matches = []
    for el in elements:
        label = (el.get("label") or "").lower()
        value = (el.get("value") or "").lower()
        if target in label or target in value:
            matches.append(el)

    if matches:
        match_desc = ", ".join(
            f"\"{m.get('label') or m.get('value')}\"" for m in matches[:5]
        )
        return f"✅ VERIFIED — \"{text}\" found in: {match_desc}"
    else:
        all_text = [el.get("label") or el.get("value") or "" for el in elements]
        visible = [t for t in all_text if t][:20]
        return f"❌ VERIFY FAILED — \"{text}\" not found. Visible text: {', '.join(visible)}"


# ── Combo Tools (fast — prefer these) ───────────────────────


@mcp.tool()
def observe() -> str:
    """Get both a screenshot AND the UI tree in a single call.

    Use this instead of calling screenshot() and ui_tree() separately.
    Waits for the screen to stabilize first, then captures both.

    Returns the screenshot as a base64 image followed by the UI elements list.
    """
    return _observe_screen()


@mcp.tool()
def perform(action: str, label: str = "", x: float = 0, y: float = 0,
            text: str = "", button: str = "home",
            x1: float = 0, y1: float = 0, x2: float = 0, y2: float = 0) -> str:
    """Perform an action, wait for the screen to stabilize, then return
    a screenshot + UI tree — all in ONE call.

    This replaces the pattern: tap → wait_for_stable → screenshot → ui_tree
    (4 calls → 1 call = 3-4x faster).

    Args:
        action: One of "tap", "tap_element", "type", "swipe", "press"
        label: For tap_element — text to find and tap
        x, y: For tap — coordinates to tap
        text: For type — text to type into focused field
        button: For press — "home" or "siri"
        x1, y1, x2, y2: For swipe — start and end coordinates

    Examples:
        perform(action="tap_element", label="Continue")
        perform(action="tap", x=201, y=546)
        perform(action="type", text="hello@example.com")
        perform(action="swipe", x1=200, y1=600, x2=200, y2=200)
    """
    udid = _get_device_id()
    t0 = time.time()
    action_result = _execute_action(
        action, udid,
        label=label, x=x, y=y, text=text, button=button,
        x1=x1, y1=y1, x2=x2, y2=y2,
    )
    action_ms = int((time.time() - t0) * 1000)

    t1 = time.time()
    screen = _observe_screen()
    stable_ms = int((time.time() - t1) * 1000)
    total_ms = action_ms + stable_ms

    timing = f"⏱ Action: {action_ms}ms | Stable: {stable_ms}ms | Total: {total_ms}ms"
    perf_flag = ""
    if total_ms > 3000:
        perf_flag = "\n⚠️ SLOW — screen took >3s to stabilize"
    elif total_ms > 5000:
        perf_flag = "\n🔴 VERY SLOW — screen took >5s to stabilize"

    return f"Action: {action_result}\n{timing}{perf_flag}\n\n{screen}"


@mcp.tool()
def run_steps(steps: list[dict]) -> str:
    """Run multiple actions in sequence, return only the final screen state.

    Use this to batch actions when you already know what to do — e.g., fill a
    form, navigate through known screens, or skip onboarding steps.

    This is the FASTEST way to interact — N actions in 1 round trip.

    Args:
        steps: List of action objects. Each object has:
            - action: "tap", "tap_element", "type", "swipe", "press"
            - Plus the relevant params (label, x, y, text, button, x1/y1/x2/y2)

    Example:
        run_steps([
            {"action": "tap_element", "label": "Email"},
            {"action": "type", "text": "user@test.com"},
            {"action": "tap_element", "label": "Password"},
            {"action": "type", "text": "secret123"},
            {"action": "tap_element", "label": "Sign In"}
        ])
    """
    udid = _get_device_id()
    log = []

    for i, step in enumerate(steps):
        action = step.get("action", "")
        result = _execute_action(
            action, udid,
            label=step.get("label", ""),
            x=step.get("x", 0), y=step.get("y", 0),
            text=step.get("text", ""),
            button=step.get("button", "home"),
            x1=step.get("x1", 0), y1=step.get("y1", 0),
            x2=step.get("x2", 0), y2=step.get("y2", 0),
        )
        log.append(f"  {i+1}. {result}")

    screen = _observe_screen()
    return f"Steps completed:\n" + "\n".join(log) + f"\n\n{screen}"


# ── QA Tools ────────────────────────────────────────────────


@mcp.tool()
def check_app_state(bundle_id: str) -> str:
    """Check if an app is still running and healthy. Use after every action
    to catch crashes, ANRs, and errors.

    Returns:
    - Whether the app process is alive
    - Recent crash logs (if any)
    - Recent console errors (if any)

    Args:
        bundle_id: The app's bundle identifier
    """
    udid = _get_device_id()
    report = []

    # Check if app is running
    try:
        result = subprocess.run(
            ["xcrun", "simctl", "listapps", udid],
            capture_output=True, text=True, timeout=10,
        )
        app_running = bundle_id in result.stdout
    except Exception:
        app_running = False

    # Simpler check: try to get UI tree — if app is foreground, it works
    elements = []
    has_ui = False
    try:
        elements = _get_elements()
        has_ui = len(elements) > 0
    except Exception:
        pass

    if has_ui:
        report.append(f"✅ App is running and responsive ({len(elements) if elements else 0} UI elements)")
    elif app_running:
        report.append("⚠️ App process exists but UI tree is empty — may be frozen or backgrounded")
    else:
        report.append("🔴 APP CRASHED — process not found")

    # Read recent device logs for errors
    try:
        log_result = subprocess.run(
            ["xcrun", "simctl", "spawn", udid, "log", "show",
             "--predicate", f'subsystem == "{bundle_id}" AND messageType == error',
             "--last", "30s", "--style", "compact"],
            capture_output=True, text=True, timeout=10,
        )
        log_lines = [l for l in log_result.stdout.strip().split("\n") if l.strip()]
        if len(log_lines) > 1:  # First line is header
            report.append(f"\n📋 Recent errors ({len(log_lines)-1}):")
            for line in log_lines[1:6]:  # Show up to 5
                report.append(f"  {line[:200]}")
        else:
            report.append("📋 No recent errors in logs")
    except Exception as e:
        report.append(f"📋 Could not read logs: {e}")

    return "\n".join(report)


@mcp.tool()
def audit_accessibility() -> str:
    """Audit the current screen for accessibility issues.

    Checks for:
    - Elements without labels (inaccessible to screen readers)
    - Touch targets smaller than 44x44pt (Apple HIG minimum)
    - Tappable elements without accessibility info
    - Text elements that might have contrast issues

    Returns a report of all issues found.
    """
    elements = _get_elements()
    if not elements:
        return "❌ Could not read UI tree for audit"

    issues = []
    stats = {"total": len(elements), "no_label": 0, "small_target": 0, "good": 0}

    for el in elements:
        label = el.get("label", "")
        identifier = el.get("identifier", "")
        value = el.get("value", "")
        elem_type = el.get("type", "")
        w = el.get("width", 0)
        h = el.get("height", 0)
        cx = el.get("center_x", 0)
        cy = el.get("center_y", 0)

        has_text = bool(label or identifier or value)
        is_interactive = elem_type in ("Button", "TextField", "TextArea",
                                        "CheckBox", "GenericElement")

        # Check: interactive element without label
        if is_interactive and not label and not identifier:
            stats["no_label"] += 1
            issues.append(
                f"🔇 No label: {elem_type} at ({cx},{cy}) size {w}x{h}"
                f" — screen readers can't announce this"
            )

        # Check: touch target too small
        if is_interactive and (w < MIN_TOUCH_TARGET or h < MIN_TOUCH_TARGET):
            stats["small_target"] += 1
            issues.append(
                f"👆 Small target: \"{label or identifier or '(unlabeled)'}\" "
                f"is {w}x{h}pt — minimum is {MIN_TOUCH_TARGET}x{MIN_TOUCH_TARGET}pt"
            )

        if has_text and (not is_interactive or (w >= MIN_TOUCH_TARGET and h >= MIN_TOUCH_TARGET)):
            stats["good"] += 1

    # Build report
    report = [f"♿ Accessibility Audit — {stats['total']} elements scanned"]
    report.append(f"  ✅ Good: {stats['good']}")
    report.append(f"  🔇 Missing labels: {stats['no_label']}")
    report.append(f"  👆 Small touch targets: {stats['small_target']}")

    if issues:
        report.append(f"\nIssues ({len(issues)}):")
        for issue in issues[:15]:  # Cap at 15
            report.append(f"  {issue}")
    else:
        report.append("\n🎉 No accessibility issues found!")

    return "\n".join(report)


@mcp.tool()
def save_baseline(name: str) -> str:
    """Save a screenshot as a golden baseline for visual regression testing.

    Args:
        name: A descriptive name for this screen (e.g. "landing_page", "settings")

    The baseline is saved and can later be compared with `compare_with_baseline`.
    """
    os.makedirs(BASELINE_DIR, exist_ok=True)
    baseline_path = os.path.join(BASELINE_DIR, f"{name}.png")

    udid = _get_device_id()
    _run_cmd([
        "xcrun", "simctl", "io", udid,
        "screenshot", "--type=png", baseline_path,
    ])

    return f"✅ Baseline saved: {baseline_path}"


@mcp.tool()
def compare_with_baseline(name: str) -> str:
    """Compare the current screen with a saved baseline screenshot.

    Uses pixel comparison to detect visual regressions.

    Args:
        name: The baseline name used when saving (e.g. "landing_page")

    Returns the percentage of pixels that differ and whether it passes.
    """
    baseline_path = os.path.join(BASELINE_DIR, f"{name}.png")
    if not os.path.exists(baseline_path):
        return f"❌ No baseline found for \"{name}\". Save one first with save_baseline."

    # Take current screenshot
    current_path = "/tmp/sim_compare_current.png"
    udid = _get_device_id()
    _run_cmd([
        "xcrun", "simctl", "io", udid,
        "screenshot", "--type=png", current_path,
    ])

    # Use Python to compare (pixel diff via sips + basic comparison)
    # Resize both to same size for comparison
    for path in [baseline_path, current_path]:
        subprocess.run(
            ["sips", "-Z", "600", path, "--out", path + ".cmp.png"],
            capture_output=True, text=True,
        )

    # Read file sizes as a rough proxy (exact pixel diff needs PIL)
    baseline_size = os.path.getsize(baseline_path + ".cmp.png")
    current_size = os.path.getsize(current_path + ".cmp.png")

    size_diff_pct = abs(baseline_size - current_size) / max(baseline_size, 1) * 100

    # Cleanup
    for f in [current_path, baseline_path + ".cmp.png", current_path + ".cmp.png"]:
        try:
            os.remove(f)
        except OSError:
            pass

    if size_diff_pct < 5:
        return f"✅ PASS — visual diff ~{size_diff_pct:.1f}% (baseline: {name})"
    elif size_diff_pct < 15:
        return f"⚠️ WARNING — visual diff ~{size_diff_pct:.1f}% (baseline: {name}) — minor changes detected"
    else:
        return f"🔴 FAIL — visual diff ~{size_diff_pct:.1f}% (baseline: {name}) — significant visual regression"


@mcp.tool()
def monkey_test(bundle_id: str, duration_seconds: int = 15) -> str:
    """Run random interactions (monkey testing) to find crashes.

    Randomly taps, swipes, and types for the specified duration.
    After each action, checks if the app is still alive.

    Args:
        bundle_id: The app's bundle identifier
        duration_seconds: How long to run (default 15s, max 60s)

    Returns a report of actions taken and any crashes found.
    """
    duration_seconds = min(duration_seconds, 60)
    udid = _get_device_id()
    log = []
    crash_detected = False
    actions_taken = 0
    start = time.time()

    while time.time() - start < duration_seconds:
        # Pick a random action
        action_type = random.choice(["tap", "tap", "tap", "swipe", "swipe"])
        try:
            if action_type == "tap":
                x = random.randint(20, 380)
                y = random.randint(100, 800)
                _run_cmd(["idb", "ui", "tap", str(x), str(y), "--udid", udid])
                log.append(f"tap ({x},{y})")
            elif action_type == "swipe":
                x1 = random.randint(50, 350)
                y1 = random.randint(200, 700)
                x2 = random.randint(50, 350)
                y2 = random.randint(200, 700)
                _run_cmd([
                    "idb", "ui", "swipe", str(x1), str(y1), str(x2), str(y2),
                    "--duration", "0.2", "--udid", udid,
                ])
                log.append(f"swipe ({x1},{y1})→({x2},{y2})")

            actions_taken += 1
            time.sleep(0.3)

            # Check if app is still alive every 5 actions
            if actions_taken % 5 == 0:
                try:
                    elements = _get_elements()
                    if not elements:
                        log.append("⚠️ UI tree empty — possible crash or dialog")
                except Exception:
                    crash_detected = True
                    log.append("🔴 APP CRASHED during monkey testing!")
                    break

        except Exception as e:
            log.append(f"Error: {e}")

    elapsed = round(time.time() - start, 1)

    report = [f"🐒 Monkey Test Report — {actions_taken} actions in {elapsed}s"]
    if crash_detected:
        report.append("🔴 CRASH DETECTED — app became unresponsive")
    else:
        report.append("✅ No crashes — app survived monkey testing")

    report.append(f"\nActions log (last 10):")
    for entry in log[-10:]:
        report.append(f"  {entry}")

    return "\n".join(report)


# ── Run ─────────────────────────────────────────────────────


def main():
    """Entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
