"""Configuration for the iOS Simulator QA Agent."""

# Your app's bundle ID (e.g. "com.affinitylabs.archives")
APP_BUNDLE_ID = "ai.affinitylabs.idc"

# Simulator device ID — use "booted" to target the currently running simulator
SIMULATOR_DEVICE_ID = "booted"

# Claude model
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# Max iterations before the agent gives up
MAX_ITERATIONS = 30

# Screenshot temp path
SCREENSHOT_PATH = "/tmp/sim_screenshot.png"

# Anthropic API key — reads from environment variable
import os
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
