While developing, install the package in editable mode from the project root:

    .venv/bin/pip install -e .

This makes pip create a direct link into src/ instead of copying files. Any changes you make to src/python_can_cansub/ are reflected immediately - no rebuild or reinstall needed.