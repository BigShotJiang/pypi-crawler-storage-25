# Repository Workflow Reminder

This project uses a **private repository for development** and a **public repository for cleaned releases**.

## Branches

### `master`

Private development master.

- Lives in the private repository.
- Contains the full commit history.
- Feature branches are reviewed and fast-forward merged here.
- This branch is **not pushed to the public repository**.

### `public-master`

Clean public-ready master.

- Lives in the private repository too.
- Contains squashed/clean commits only.
- This is the branch that gets pushed to the public repository's `master`.

## Normal Development

Work normally in the IDE using the private repository.

## Prepare Public Version

When a feature is ready for public release, squash it into `public-master`:

```bash
git checkout public-master
git merge --squash feature/my-feature
git commit -m "Add my feature"
```

Validate that `public-master` content and history is correct.

Push the cleaned branch to the private repo:

```bash
git push origin public-master
```

## Push to Public Repository

The public repository remote is not kept configured permanently.

Push only when intentionally publishing:

```bash
git push git@github.com:YOUR_USER/YOUR_PUBLIC_REPO.git public-master:master
```

This pushes:

```text
local/private public-master -> public repo master
```

## Rule of Thumb

- `master` = private full history
- `public-master` = clean squashed history
- public repo `master` = copy of `public-master`

Never push private `master` to the public repository.
