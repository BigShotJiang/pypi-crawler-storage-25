Build steps:

- Update version in pyproject.toml
- Ensure "build" is installed, "pip install build"
- Build with "python -m build"
- Install with e.g.: "pip install dist/python_can_cansub-2026.03.06-py3-none-any.whl"