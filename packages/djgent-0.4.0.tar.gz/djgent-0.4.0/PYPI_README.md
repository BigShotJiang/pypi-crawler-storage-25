# Djgent

Django AI Agent Framework for building AI agents with LangChain integration in
Django applications.

## Installation

```bash
pip install djgent
```

Or install with `uv`:

```bash
uv add djgent
```

## Basic Setup

Add `djgent` to your Django project:

```python
INSTALLED_APPS = [
    # ...
    "djgent",
]
```

Configure your LLM provider:

```python
DJGENT = {
    "DEFAULT_LLM": "openai:gpt-4o-mini",
    "API_KEYS": {
        "OPENAI": "your-openai-api-key",
    },
}
```

Run migrations when using database-backed memory or the built-in chat UI:

```bash
python manage.py migrate
```

## Default Chat View

Djgent includes a default chat UI you can mount in your project.

Add the chat app:

```python
INSTALLED_APPS = [
    # ...
    "djgent",
    "djgent.chat",
]
```

Configure the chat:

```python
DJGENT = {
    "DEFAULT_LLM": "openai:gpt-4o-mini",
    "API_KEYS": {
        "OPENAI": "your-openai-api-key",
    },
    "CHAT_UI": {
        "TITLE": "AI Assistant",
        "TOOLS": ["calculator", "datetime"],
        "AUTO_LOAD_TOOLS": True,
        "SYSTEM_PROMPT": "You are a helpful assistant.",
    },
}
```

Mount the default chat URLs:

```python
from django.urls import include, path

urlpatterns = [
    path("chat/", include("djgent.chat.urls")),
]
```

Then open `/chat/` in your browser.

To add the optional site-wide chat bubble, enable it in settings:

```python
DJGENT = {
    # ...
    "CHAT_UI": {
        "BUBBLE_ENABLED": True,
        "BUBBLE_TITLE": "Ask AI",
    },
}
```

And render it in your base template:

```django
{% load djgent_chat %}
{% djgent_chat_bubble %}
```

Create and run an agent:

```python
from djgent import Agent

agent = Agent.create(name="assistant")
response = agent.run("What is Djgent?")
print(response)
```

## Full Documentation

See the [full Djgent documentation on GitHub](https://github.com/borhanst/djgent#readme).
