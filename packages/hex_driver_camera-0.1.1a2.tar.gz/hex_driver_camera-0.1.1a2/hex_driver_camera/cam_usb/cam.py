#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-22
################################################################

import time
import platform
import cv2
import numpy as np
from collections import deque
from dataclasses import dataclass
from typing import Optional, Any, Callable

from hex_util_runtime import ns_now, deque_helper
from hex_util_msg.builder_image import hex_color_img_dtype
from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamUsbParams(HexCamBaseParams):
    cam_path: str = "/dev/video0"
    exposure: int = 100
    temperature: int = 4000


class HexCamUsbCallback(HexCamBase):

    def __init__(
        self,
        params: HexCamUsbParams = HexCamUsbParams(),
        callbacks: dict[str, Callable] = {},
    ) -> None:
        HexCamBase.__init__(self)
        self.__params = params
        self.__callbacks = {
            "color": callbacks.get("color", lambda x: None),
        }
        self.init_vars()
        self.init_camera()

    def init_vars(self) -> None:
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate
        self.__cam_path = self.__params.cam_path
        self.__exposure = self.__params.exposure
        self.__temperature = self.__params.temperature

        # buffer
        self.__msg_buffer = {
            "color": np.empty(1, dtype=hex_color_img_dtype(self.__h, self.__w)),
        }

    def init_camera(self) -> None:
        if platform.system() == "Linux":
            self.__cap = cv2.VideoCapture(self.__cam_path, cv2.CAP_V4L2)
        else:
            self.__cap = cv2.VideoCapture(self.__cam_path)
        if not self.__cap.isOpened():
            raise RuntimeError(f"Failed to open camera: {self.__cam_path}")

        self.__cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        self.__cap.set(cv2.CAP_PROP_FRAME_WIDTH, float(self.__w))
        self.__cap.set(cv2.CAP_PROP_FRAME_HEIGHT, float(self.__h))
        self.__cap.set(cv2.CAP_PROP_FPS, float(self.__fps))
        self.__cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)
        ae_open = 1.0 if platform.system() == "Windows" else 3.0
        ae_close = 0.0 if platform.system() == "Windows" else 1.0
        ae_value = 10000 * (2**self.__exposure) if platform.system(
        ) == "Windows" else float(self.__exposure)
        self.__cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, ae_open)
        if self.__exposure != 0:
            self.__cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, ae_close)
            self.__cap.set(cv2.CAP_PROP_EXPOSURE, ae_value)
        self.__cap.set(cv2.CAP_PROP_AUTO_WB, 1)
        if self.__temperature != 0:
            self.__cap.set(cv2.CAP_PROP_AUTO_WB, 0)
            self.__cap.set(cv2.CAP_PROP_WB_TEMPERATURE,
                           float(self.__temperature))

        fourcc_int = int(self.__cap.get(cv2.CAP_PROP_FOURCC))
        fourcc_str = "".join(
            [chr((fourcc_int >> 8 * i) & 0xFF) for i in range(4)])
        print(
            f"Camera info: {fourcc_str} {self.__cap.get(cv2.CAP_PROP_FRAME_WIDTH)}x{self.__cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}@{self.__cap.get(cv2.CAP_PROP_FPS)}"
        )

    def stop(self) -> None:
        if not HexCamBase.stop(self):
            return
        if self.__cap is not None:
            self.__cap.release()
            self.__cap = None

    def work_loop(self) -> None:
        while not self._stop_event.is_set():
            ret, frame = self.__cap.read()
            if not ret or frame is None:
                time.sleep(0.001)
                continue
            self.__msg_buffer["color"][0]["ts_ns"] = ns_now()
            self.__msg_buffer["color"][0]["data"][:] = frame
            self.__callbacks["color"](self.__msg_buffer["color"][0].copy())


class HexCamUsb(HexCamUsbCallback):

    def __init__(
            self,
            params: HexCamUsbParams = HexCamUsbParams(),
    ) -> None:
        self.__deque_dict = {
            "color": deque(maxlen=params.cam_buffer_size),
        }
        self.__callbacks = {
            "color": lambda x: self.__deque_dict["color"].append(x),
        }
        HexCamUsbCallback.__init__(self, params, self.__callbacks)

    def get_color_img(self, latest: bool = True) -> Optional[dict[str, Any]]:
        return deque_helper(self.__deque_dict["color"], latest=latest)
