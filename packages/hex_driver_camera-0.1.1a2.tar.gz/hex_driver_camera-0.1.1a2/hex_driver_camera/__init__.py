#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-22
################################################################

from .cam_dummy import HexCamDummy, HexCamDummyCallback, HexCamDummyParams
from .cam_usb import HexCamUsb, HexCamUsbCallback, HexCamUsbParams

__all__ = [
    # dummy camera
    "HexCamDummy",
    "HexCamDummyCallback",
    "HexCamDummyParams",

    # usb camera
    "HexCamUsb",
    "HexCamUsbCallback",
    "HexCamUsbParams",
]

try:
    import pyrealsense2 as _pyrealsense2  # noqa: F401
except ImportError:
    _pyrealsense2 = None

if _pyrealsense2 is not None:
    from .cam_realsense import (HexCamRealsense, HexCamRealsenseCallback,
                                HexCamRealsenseParams)

    __all__ += [
        # realsense camera (requires pyrealsense2)
        "HexCamRealsense",
        "HexCamRealsenseCallback",
        "HexCamRealsenseParams",
    ]

try:
    import berxel_py_wrapper as _berxel_py_wrapper  # noqa: F401
except ImportError:
    _berxel_py_wrapper = None

if _berxel_py_wrapper is not None:
    from .cam_berxel import (HexCamBerxel, HexCamBerxelCallback,
                             HexCamBerxelParams)

    __all__ += [
        "HexCamBerxel",
        "HexCamBerxelCallback",
        "HexCamBerxelParams",
    ]
