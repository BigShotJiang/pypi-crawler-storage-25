#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-22
################################################################

import numpy as np
from collections import deque
from dataclasses import dataclass
from typing import Optional, Any, Callable
from hex_util_runtime import HexRate, ns_now, deque_helper
from hex_util_msg.builder_image import hex_color_img_dtype

from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamDummyParams(HexCamBaseParams):
    pass


class HexCamDummyCallback(HexCamBase):

    def __init__(
        self,
        params: HexCamDummyParams = HexCamDummyParams(),
        callbacks: dict[str, Callable] = {},
    ) -> None:
        HexCamBase.__init__(self)
        self.__params = params
        self.__callbacks = {
            "color": callbacks.get("color", lambda x: None),
        }
        self.init_vars()
        self.init_camera()

    def init_vars(self) -> None:
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate

        # buffer
        self.__msg_buffer = {
            "color": np.empty(1, dtype=hex_color_img_dtype(self.__h, self.__w)),
        }

    def init_camera(self) -> None:
        pass

    def work_loop(self) -> None:
        rng = np.random.default_rng()
        rate = HexRate(self.__fps)
        while not self._stop_event.is_set():
            rate.sleep()
            self.__msg_buffer["color"][0]["data"][:] = rng.integers(
                0,
                256,
                (self.__h, self.__w, 3),
                dtype=np.uint8,
            )
            self.__msg_buffer["color"][0]["ts_ns"] = ns_now()
            self.__callbacks["color"](self.__msg_buffer["color"][0].copy())


class HexCamDummy(HexCamDummyCallback):

    def __init__(
            self,
            params: HexCamDummyParams = HexCamDummyParams(),
    ) -> None:
        self.__deque_dict = {
            "color": deque(maxlen=params.cam_buffer_size),
        }
        self.__callbacks = {
            "color": lambda x: self.__deque_dict["color"].append(x),
        }
        HexCamDummyCallback.__init__(self, params, self.__callbacks)

    def get_color_img(self, latest: bool = True) -> Optional[dict[str, Any]]:
        return deque_helper(self.__deque_dict["color"], latest=latest)
