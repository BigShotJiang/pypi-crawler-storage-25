#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

try:
    import pyrealsense2 as _pyrealsense2  # noqa: F401
except ImportError:
    _pyrealsense2 = None

if _pyrealsense2 is not None:
    from .cam import HexCamRealsense, HexCamRealsenseCallback, HexCamRealsenseParams

    __all__ = [
        "HexCamRealsense",
        "HexCamRealsenseCallback",
        "HexCamRealsenseParams",
    ]
else:
    __all__ = []
