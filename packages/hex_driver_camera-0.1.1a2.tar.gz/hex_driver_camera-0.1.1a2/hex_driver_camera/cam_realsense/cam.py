#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-22
################################################################

import numpy as np
import pyrealsense2 as rs
from collections import deque
from dataclasses import dataclass
from typing import Any, Optional, Callable

from hex_util_runtime import ns_now, deque_helper
from hex_util_msg.builder_image import hex_color_img_dtype, hex_depth_img_dtype
from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamRealsenseParams(HexCamBaseParams):
    serial_number: str = "243422073194"


class HexCamRealsenseCallback(HexCamBase):

    def __init__(
        self,
        params: HexCamRealsenseParams = HexCamRealsenseParams(),
        callbacks: dict[str, Callable] = {},
    ) -> None:
        HexCamBase.__init__(self)
        self.__params = params
        self.__callbacks = {
            "color": callbacks.get("color", lambda x: None),
            "depth": callbacks.get("depth", lambda x: None),
        }
        self.init_vars()
        self.init_camera()

    def get_intri(self) -> np.ndarray:
        return self.__intri.copy()

    def init_vars(self) -> None:
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate
        self.__serial_number = self.__params.serial_number
        self.__sens_ts = self.__params.sens_ts

        self.__pipeline: Any = None
        self.__align: Any = None
        self.__intri = np.zeros(4, dtype=np.float64)

        # buffer
        self.__msg_buffer = {
            "color": np.empty(1, dtype=hex_color_img_dtype(self.__h, self.__w)),
            "depth": np.empty(1, dtype=hex_depth_img_dtype(self.__h, self.__w)),
        }

    def init_camera(self) -> None:
        ctx = rs.context()
        serial_numbers = []
        for dev in ctx.query_devices():
            serial = dev.get_info(rs.camera_info.serial_number)
            name = dev.get_info(rs.camera_info.name)
            print(f"  - Device: {name}, Serial: {serial}")
            serial_numbers.append(serial)
        if self.__serial_number not in serial_numbers:
            raise RuntimeError(
                f"cannot find device with serial number: {self.__serial_number}"
            )

        self.__pipeline = rs.pipeline()
        config = rs.config()
        config.enable_device(self.__serial_number)
        config.enable_stream(
            rs.stream.color,
            self.__w,
            self.__h,
            rs.format.bgr8,
            int(self.__fps),
        )
        config.enable_stream(
            rs.stream.depth,
            self.__w,
            self.__h,
            rs.format.z16,
            int(self.__fps),
        )
        profile = self.__pipeline.start(config)
        color_profile = profile.get_stream(rs.stream.color)
        color_intrinsics = color_profile.as_video_stream_profile(
        ).get_intrinsics()
        self.__intri[0] = float(color_intrinsics.fx)
        self.__intri[1] = float(color_intrinsics.fy)
        self.__intri[2] = float(color_intrinsics.ppx)
        self.__intri[3] = float(color_intrinsics.ppy)
        self.__align = rs.align(rs.stream.color)
        self.__depth_scale = profile.get_device().first_depth_sensor(
        ).get_depth_scale() * 1000.0

    def stop(self) -> None:
        if not HexCamBase.stop(self):
            return
        if self.__pipeline is not None:
            try:
                self.__pipeline.stop()
            except RuntimeError:
                pass
            self.__pipeline = None
        self.__align = None

    def work_loop(self) -> None:
        aligned_frames = self.__align.process(
            self.__pipeline.wait_for_frames())
        bias_ns = np.int64(ns_now()) - np.int64(
            aligned_frames.get_frame_metadata(
                rs.frame_metadata_value.sensor_timestamp) * 1_000)

        while not self._stop_event.is_set():
            aligned_frames = self.__align.process(
                self.__pipeline.wait_for_frames())
            cur_ns = ns_now()
            if self.__sens_ts:
                sen_ts = bias_ns + np.int64(
                    aligned_frames.get_frame_metadata(
                        rs.frame_metadata_value.sensor_timestamp) * 1_000)
                if cur_ns < sen_ts:
                    sen_ts = cur_ns
                ts_ns = sen_ts
            else:
                ts_ns = cur_ns

            color_frame = aligned_frames.get_color_frame()
            if color_frame is not None:
                color = np.asanyarray(color_frame.get_data())
                self.__msg_buffer["color"][0]["ts_ns"] = ts_ns
                self.__msg_buffer["color"][0]["data"][:] = color
                self.__callbacks["color"](self.__msg_buffer["color"][0].copy())

            depth_frame = aligned_frames.get_depth_frame()
            if depth_frame is not None:
                depth = np.asanyarray(
                    depth_frame.get_data(),
                    dtype=np.float32,
                ) * self.__depth_scale
                self.__msg_buffer["depth"][0]["ts_ns"] = ts_ns
                self.__msg_buffer["depth"][0]["data"][:] = depth.astype(
                    np.uint16)
                self.__callbacks["depth"](self.__msg_buffer["depth"][0].copy())


class HexCamRealsense(HexCamRealsenseCallback):

    def __init__(
            self,
            params: HexCamRealsenseParams = HexCamRealsenseParams(),
    ) -> None:
        self.__deque_dict = {
            "color": deque(maxlen=params.cam_buffer_size),
            "depth": deque(maxlen=params.cam_buffer_size),
        }
        self.__callbacks = {
            "color": lambda x: self.__deque_dict["color"].append(x),
            "depth": lambda x: self.__deque_dict["depth"].append(x),
        }
        HexCamRealsenseCallback.__init__(self, params, self.__callbacks)

    def get_color_img(self, latest: bool = True) -> Optional[dict[str, Any]]:
        return deque_helper(self.__deque_dict["color"], latest=latest)

    def get_depth_img(self, latest: bool = True) -> Optional[dict[str, Any]]:
        return deque_helper(self.__deque_dict["depth"], latest=latest)
