#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-22
################################################################

import os
import threading
from dataclasses import dataclass
from abc import ABC, abstractmethod


@dataclass
class HexCamBaseParams:
    frame_rate: int = 30
    height: int = 480
    width: int = 640
    cam_buffer_size: int = 8
    sens_ts: bool = True


class HexCamBase(ABC):

    def __init__(self) -> None:
        os.environ["QT_QPA_FONTDIR"] = "/usr/share/fonts/truetype/dejavu/"
        self._stop_event = threading.Event()
        self._work_thread = threading.Thread(target=self.work_loop,
                                             daemon=True)

    def is_working(self) -> bool:
        return not self._stop_event.is_set()

    def start(self) -> None:
        if self._work_thread.is_alive():
            return
        self._stop_event.clear()
        self._work_thread.start()

    def stop(self) -> bool:
        if self._stop_event.is_set():
            return False
        self._stop_event.set()
        self._work_thread.join()
        return True

    @abstractmethod
    def init_vars(self):
        raise NotImplementedError(
            "`init_vars` should be implemented by the child class")

    @abstractmethod
    def init_camera(self):
        raise NotImplementedError(
            "`init_camera` should be implemented by the child class")

    @abstractmethod
    def work_loop(self):
        raise NotImplementedError(
            "`work_loop` should be implemented by the child class")
