"""Local-only encryption helpers."""

