"""Local HTTP proxy gateway."""

