"""Concrete AgentSecure implementations."""

