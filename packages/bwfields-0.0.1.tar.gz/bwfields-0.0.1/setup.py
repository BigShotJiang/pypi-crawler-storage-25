from setuptools import setup, find_packages

setup(
  name='bwfields',
  version='0.0.1',
  # packages=find_packages(),
  packages=['BWFields'],
  description = 'A collection of bubble identification and analysis algorithms',
  author = ['Jiang Yu'],
  author_email = 'yujiang@pmo.ac.cn',
  url = 'https://github.com/JiangYuTS/BWFileds',
#   download_url = '',
  keywords = ['astrophysics', 'BWFileds', 'bubble'],
  classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
  install_requires=[
      'numpy',
      'scipy',
      'matplotlib',
      'astropy',
      'scikit-learn',
      'scikit-image',
      'networkx',
      'pandas',
      'tqdm',
      'FacetClumps',
      'DPConCFil',
  ],
  python_requires='>=3.6',
)

