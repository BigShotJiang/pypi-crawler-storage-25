from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import traceback
import uuid
from pathlib import Path
from typing import Any, List

import uvicorn
from sqlmodel import Session, select

from agentcad_backend.config import BASE_DIR, get_settings
from agentcad_backend.db import engine, init_db, session_scope
from agentcad_backend.models import CADObject, CLIJob, utc_now
from agentcad_backend.routes import _next_session_version, _persist_generated_object
from agentcad_backend.services.cadquery_agent import CadQueryAgentService

UNTRACKED_COMMANDS = {"job", "jobs"}


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    return _run_with_job_tracking(args)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentcad-backend-cli",
        description="Generate and track AgentCAD STEP files from the command line.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    models_parser = subparsers.add_parser("models", help="Show configured LLM providers and models.")
    models_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    models_parser.set_defaults(func=_models_command)

    current_model_parser = subparsers.add_parser(
        "current-model", help="Show the currently active LLM provider and model."
    )
    current_model_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    current_model_parser.set_defaults(func=_current_model_command)

    set_model_parser = subparsers.add_parser(
        "set-model", help="Persistently set the active model (writes to .env)."
    )
    set_model_parser.add_argument("model", help="Model identifier to activate (e.g. gpt-4.1)")
    set_model_parser.add_argument("--provider", choices=("openai", "gemini"), help="Explicit provider for the model.")
    set_model_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    set_model_parser.set_defaults(func=_set_model_command)

    history_parser = subparsers.add_parser("history", help="Show generated STEP file versions.")
    history_parser.add_argument("--session", help="Only show versions for this session UUID.")
    history_parser.add_argument("--limit", type=int, default=20, help="Maximum rows to show.")
    history_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    history_parser.set_defaults(func=_history_command)

    jobs_parser = subparsers.add_parser("jobs", help="Show recent CLI jobs.")
    jobs_parser.add_argument("--limit", type=int, default=20, help="Maximum jobs to show.")
    jobs_parser.add_argument("--status", choices=("running", "succeeded", "failed"), help="Filter by status.")
    jobs_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    jobs_parser.set_defaults(func=_jobs_command)

    job_parser = subparsers.add_parser("job", help="Show one CLI job and its error/result details.")
    job_parser.add_argument("job_id", type=int, help="CLI job id.")
    job_parser.add_argument("--error", action="store_true", help="Print only the saved error and traceback.")
    job_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    job_parser.set_defaults(func=_job_command)

    generate_parser = subparsers.add_parser("generate", help="Generate a STEP file via the configured agent.")
    generate_parser.add_argument("prompt", nargs="+", help="Prompt describing the CAD object to generate.")
    generate_parser.add_argument(
        "--provider",
        choices=("openai", "gemini"),
        help="LLM provider to use for this run. Overrides LLM_PROVIDER.",
    )
    generate_parser.add_argument(
        "--model",
        help="Model to use for this run, for example gpt-4.1.",
    )
    generate_parser.add_argument(
        "--session",
        help="Existing session UUID to append a new version to. Omit to start a new session.",
    )
    generate_parser.add_argument(
        "--image",
        type=Path,
        help="Optional reference image to send to the agent and store with the run.",
    )
    generate_parser.add_argument(
        "--filename",
        help="Optional STEP filename. Defaults to an object UUID based filename.",
    )
    generate_parser.add_argument("--debug", action="store_true", help="Print provider, job, and fallback diagnostics.")
    generate_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    generate_parser.set_defaults(func=_generate_command)

    return parser


def _run_with_job_tracking(args: argparse.Namespace) -> int:
    command = str(args.command)
    if command in UNTRACKED_COMMANDS:
        return args.func(args)

    init_db()
    job = _create_job(command, _args_payload(args))
    args._job_id = job.id
    if getattr(args, "debug", False):
        print(f"[debug] job_id={job.id} command={command}", file=sys.stderr)
        print(f"[debug] args={json.dumps(_args_payload(args), default=str)}", file=sys.stderr)
    try:
        exit_code = int(args.func(args) or 0)
    except SystemExit as exc:
        exit_code = int(exc.code) if isinstance(exc.code, int) else 1
        if exit_code == 0:
            _succeed_job(job.id)
        else:
            failure = RuntimeError(str(exc) or f"Command exited with status {exit_code}")
            _fail_job(job.id, failure)
            print(f"Job {job.id} failed: {failure}", file=sys.stderr)
            print(f"Run `agentcad-backend-cli job {job.id} --error` to print the saved traceback.", file=sys.stderr)
            if getattr(args, "debug", False):
                traceback.print_exception(type(failure), failure, failure.__traceback__, file=sys.stderr)
        return exit_code
    except Exception as exc:
        _fail_job(job.id, exc)
        print(f"Job {job.id} failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        print(f"Run `agentcad-backend-cli job {job.id} --error` to print the saved traceback.", file=sys.stderr)
        if getattr(args, "debug", False):
            traceback.print_exception(type(exc), exc, exc.__traceback__, file=sys.stderr)
        return 1

    if exit_code == 0:
        _succeed_job(job.id)
    else:
        _fail_job(job.id, RuntimeError(f"Command exited with status {exit_code}"))
    return exit_code


def _models_command(args: argparse.Namespace) -> int:
    settings = get_settings()
    payload = {
        "openai_model": settings.openai_model,
        "provider": os.getenv("LLM_PROVIDER", "openai"),
        "openai_api_key": bool(settings.openai_api_key),
    }
    _record_job_result(args, payload)
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    print(f"Selected provider: {payload['provider']}")
    print(f"Selected model: {payload['openai_model']}")
    print(f"OpenAI API key configured: {payload['openai_api_key']}")
    return 0


def _current_model_command(args: argparse.Namespace) -> int:
    settings = get_settings()
    provider = os.getenv("LLM_PROVIDER", "openai")
    selected_model = settings.openai_model if provider == "openai" else os.getenv("GEMINI_MODEL")
    payload = {
        "provider": provider,
        "model": selected_model,
        "openai_model": settings.openai_model,
        "gemini_model": os.getenv("GEMINI_MODEL"),
    }
    _record_job_result(args, payload)
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    print(f"Active provider: {provider}")
    print(f"Active model: {selected_model or 'none'}")
    return 0


def _set_model_command(args: argparse.Namespace) -> int:
    model = args.model
    provider = args.provider or _infer_provider_for_model(model) or "openai"
    env_path = BASE_DIR / ".env"
    if provider == "openai":
        _update_env_var(env_path, "OPENAI_MODEL", model)
        _update_env_var(env_path, "LLM_PROVIDER", "openai")
    else:
        _update_env_var(env_path, "GEMINI_MODEL", model)
        _update_env_var(env_path, "LLM_PROVIDER", "gemini")

    try:
        if hasattr(get_settings, "cache_clear"):
            get_settings.cache_clear()
    except Exception:
        pass

    payload = {"provider": provider, "model": model, "env_file": str(env_path)}
    _record_job_result(args, payload)
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    print(f"Set provider={provider} model={model} in {env_path}")
    return 0


def _history_command(args: argparse.Namespace) -> int:
    init_db()
    with Session(engine) as session:
        statement = select(CADObject).order_by(CADObject.created_at.desc()).limit(args.limit)
        if args.session:
            statement = (
                select(CADObject)
                .where(CADObject.session_uuid == args.session)
                .order_by(CADObject.version.desc(), CADObject.created_at.desc())
                .limit(args.limit)
            )
        rows = session.exec(statement).all()

    payload = [
        {
            "id": cad_object.id,
            "session_uuid": cad_object.session_uuid,
            "object_uuid": cad_object.object_uuid,
            "version": cad_object.version,
            "prompt": cad_object.prompt,
            "model_used": json.loads(cad_object.preview_metadata).get("job_metadata", {}).get("model_used", "unknown"),
            "step_file_location": cad_object.step_file_path,
            "created_at": cad_object.created_at.isoformat(),
        }
        for cad_object in rows
    ]
    _record_job_result(args, {"objects": payload, "count": len(payload)})
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    if not payload:
        print("No generated STEP files found.")
        return 0

    for row in payload:
        print(
            f"#{row['id']} v{row['version']} {row['session_uuid']} {row['model_used']} {row['step_file_location']}"
        )
        print(f"  {row['prompt']}")
    return 0


def _jobs_command(args: argparse.Namespace) -> int:
    init_db()
    with Session(engine) as session:
        statement = select(CLIJob).order_by(CLIJob.created_at.desc()).limit(args.limit)
        if args.status:
            statement = (
                select(CLIJob)
                .where(CLIJob.status == args.status)
                .order_by(CLIJob.created_at.desc())
                .limit(args.limit)
            )
        jobs = session.exec(statement).all()

    payload = [_job_payload(job, include_details=False) for job in jobs]
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    if not payload:
        print("No CLI jobs found.")
        return 0

    for job in payload:
        target = job.get("output_path") or job.get("object_uuid") or ""
        print(f"#{job['id']} {job['status']} {job['command']} {job['created_at']} {target}")
        if job.get("error_message"):
            print(f"  {job['error_type']}: {job['error_message']}")
    return 0


def _job_command(args: argparse.Namespace) -> int:
    init_db()
    with Session(engine) as session:
        job = session.get(CLIJob, args.job_id)
        if job is None:
            raise SystemExit(f"Job not found: {args.job_id}")
        payload = _job_payload(job, include_details=True)

    if args.json:
        print(json.dumps(payload, indent=2))
        return 0

    if args.error:
        if not payload.get("error_message"):
            print(f"Job {args.job_id} has no saved error.")
            return 0
        print(f"{payload.get('error_type')}: {payload.get('error_message')}")
        if payload.get("traceback"):
            print()
            print(payload["traceback"])
        return 0

    print(f"Job {payload['id']} [{payload['status']}] {payload['command']}")
    print(f"Created: {payload['created_at']}")
    print(f"Updated: {payload['updated_at']}")
    if payload.get("cad_object_id"):
        print(f"Object: {payload['cad_object_id']} / {payload.get('object_uuid')}")
    if payload.get("session_uuid"):
        print(f"Session: {payload['session_uuid']}")
    if payload.get("output_path"):
        print(f"Output: {payload['output_path']}")
    if payload.get("error_message"):
        print(f"Error: {payload.get('error_type')}: {payload.get('error_message')}")
        print(f"Run `agentcad-backend-cli job {payload['id']} --error` for the traceback.")
    else:
        print("Result:")
        print(json.dumps(payload.get("result", {}), indent=2))
    return 0


def _generate_command(args: argparse.Namespace) -> int:
    init_db()
    settings = get_settings()
    _apply_model_overrides(settings, provider=args.provider, model=args.model)
    if args.debug:
        print(
            "[debug] llm_provider="
            f"{os.getenv('LLM_PROVIDER', 'openai')} openai_model={settings.openai_model}",
            file=sys.stderr,
        )
        print(
            "[debug] auth="
            f"openai:{bool(settings.openai_api_key)}",
            file=sys.stderr,
        )
        print(
            "[debug] storage="
            f"metadata:{settings.export_dir} ",
            file=sys.stderr,
        )

    prompt = " ".join(args.prompt).strip()
    image_bytes, image_path = _load_image(args.image, settings.upload_dir)
    agent_service = CadQueryAgentService()
    generated = agent_service.generate(
        prompt=prompt,
        image_bytes=image_bytes,
        image_mime=_guess_mime(args.image) if args.image else None,
    )

    with session_scope() as session:
        session_uuid = args.session or str(uuid.uuid4())
        version = _next_session_version(session, session_uuid)
        response = _persist_generated_object(
            session=session,
            prompt=prompt,
            generated=generated,
            image_path=image_path,
            session_uuid=session_uuid,
            version=version,
            chat_messages=[
                {"role": "user", "content": prompt, "image_path": image_path},
                {
                    "role": "assistant",
                    "content": "Generated the design from the command line.",
                    "image_path": None,
                },
            ],
        )

    model_used = response.metadata.model_used
    used_fallback = bool(response.preview.get("usedFallback") or response.preview.get("used_fallback", False))
    _record_job_result(args, {
        "id": response.id,
        "session_uuid": response.session_uuid,
        "object_uuid": response.object_uuid,
        "version": response.version,
        "prompt": response.prompt,
        "model_used": model_used,
        "used_fallback": used_fallback,
        "step_file_location": response.step_file_url,
        "created_at": response.created_at.isoformat(),
    })
    if args.debug:
        print(f"[debug] result={response}", file=sys.stderr)
    if args.json:
        print(json.dumps({
            "id": response.id,
            "session_uuid": response.session_uuid,
            "object_uuid": response.object_uuid,
            "version": response.version,
            "prompt": response.prompt,
            "model_used": model_used,
            "used_fallback": used_fallback,
            "step_file_location": response.step_file_url,
            "created_at": response.created_at.isoformat(),
        }, indent=2))
    else:
        print(f"Generated STEP: {response.step_file_url}")
        print(f"Session: {response.session_uuid}")
        print(f"Version: {response.version}")
        print(f"Object: {response.object_uuid}")
        print(f"Model: {model_used}")
        if used_fallback:
            print("Fallback: yes")
    return 0


def _render_video_command(args: argparse.Namespace) -> int:
    parser = argparse.ArgumentParser(description="Render a STEP object to MP4.")
    parser.add_argument("object", help="Saved numeric id or object UUID from history.")
    parser.add_argument("--width", type=int, default=960, help="Video width in pixels.")
    parser.add_argument("--height", type=int, default=720, help="Video height in pixels.")
    parser.add_argument("--fps", type=int, default=24, help="Frames per second.")
    parser.add_argument("--duration", type=float, default=4.0, help="Video duration in seconds.")
    parser.add_argument("--force", action="store_true", help="Regenerate even if a cached video exists.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    raise SystemExit("Use the separate backend server for render-video commands.")


def _get_cad_object(session: Session, identifier: str) -> CADObject | None:
    try:
        return session.get(CADObject, int(identifier))
    except ValueError:
        return session.exec(
            select(CADObject).where(CADObject.object_uuid == identifier)
        ).first()


def _create_job(command: str, args_payload: dict[str, Any]) -> CLIJob:
    with Session(engine) as session:
        job = CLIJob(
            command=command,
            status="running",
            args_json=json.dumps(args_payload, default=str),
            result_json="{}",
            updated_at=utc_now(),
        )
        session.add(job)
        session.commit()
        session.refresh(job)
        return job


def _record_job_result(args: argparse.Namespace, result: dict[str, Any]) -> None:
    job_id = getattr(args, "_job_id", None)
    if job_id is None:
        return
    with Session(engine) as session:
        job = session.get(CLIJob, job_id)
        if job is None:
            return
        job.result_json = json.dumps(result, default=str)
        job.cad_object_id = result.get("id")
        job.object_uuid = result.get("object_uuid")
        job.session_uuid = result.get("session_uuid")
        job.output_path = result.get("step_file_location")
        job.updated_at = utc_now()
        session.add(job)
        session.commit()


def _succeed_job(job_id: int | None) -> None:
    if job_id is None:
        return
    with Session(engine) as session:
        job = session.get(CLIJob, job_id)
        if job is None:
            return
        job.status = "succeeded"
        job.error_type = None
        job.error_message = None
        job.traceback = None
        job.updated_at = utc_now()
        session.add(job)
        session.commit()


def _fail_job(job_id: int | None, exc: BaseException) -> None:
    if job_id is None:
        return
    with Session(engine) as session:
        job = session.get(CLIJob, job_id)
        if job is None:
            return
        job.status = "failed"
        job.error_type = type(exc).__name__
        job.error_message = str(exc)
        job.traceback = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        job.updated_at = utc_now()
        session.add(job)
        session.commit()


def _args_payload(args: argparse.Namespace) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for key, value in vars(args).items():
        if key.startswith("_") or key == "func":
            continue
        if isinstance(value, Path):
            payload[key] = str(value)
        else:
            payload[key] = value
    return payload


def _job_payload(job: CLIJob, *, include_details: bool) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": job.id,
        "command": job.command,
        "status": job.status,
        "cad_object_id": job.cad_object_id,
        "object_uuid": job.object_uuid,
        "session_uuid": job.session_uuid,
        "output_path": job.output_path,
        "error_type": job.error_type,
        "error_message": job.error_message,
        "created_at": job.created_at.isoformat(),
        "updated_at": job.updated_at.isoformat(),
    }
    if include_details:
        payload["args"] = _loads_json(job.args_json)
        payload["result"] = _loads_json(job.result_json)
        payload["traceback"] = job.traceback
    return payload


def _loads_json(value: str | None) -> Any:
    if value is None:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _apply_model_overrides(settings, provider: str | None, model: str | None) -> None:
    if provider and provider.lower() != "openai":
        raise SystemExit(f"Only openai provider is supported by the current backend CLI.")
    if model:
        settings.openai_model = model


def _infer_provider_for_model(model: str | None) -> str | None:
    if not model:
        return None
    normalized = model.lower()
    if normalized.startswith(("gpt-", "o1", "o3", "o4")):
        return "openai"
    if normalized.startswith("gemini-"):
        return "gemini"
    return None


def _update_env_var(env_path: Path, key: str, value: str) -> None:
    lines = []
    if env_path.exists():
        lines = env_path.read_text().splitlines()
    found = False
    prefix = f"{key}="
    for i, line in enumerate(lines):
        if line.strip().startswith(prefix):
            lines[i] = f'{key}="{value}"'
            found = True
            break
    if not found:
        lines.append(f'{key}="{value}"')
    env_path.write_text("\n".join(lines) + "\n")


def _load_image(image_path: Path | None, upload_dir: Path) -> tuple[bytes | None, str | None]:
    if image_path is None:
        return None, None
    resolved = image_path.expanduser().resolve()
    if not resolved.exists() or not resolved.is_file():
        raise SystemExit(f"Image file not found: {image_path}")

    image_bytes = resolved.read_bytes()
    suffix = resolved.suffix or ".png"
    stored_name = f"{uuid.uuid4().hex}{suffix}"
    upload_dir.mkdir(parents=True, exist_ok=True)
    stored_path = upload_dir / stored_name
    shutil.copyfile(resolved, stored_path)
    return image_bytes, str(stored_path.relative_to(BASE_DIR))


def _guess_mime(image_path: Path | None) -> str | None:
    if image_path is None:
        return None
    suffix = image_path.suffix.lower()
    if suffix in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if suffix == ".webp":
        return "image/webp"
    return "image/png"


def server_main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="agentcad-backend-server",
        description="Run the AgentCAD backend FastAPI server.",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Server host address.")
    parser.add_argument("--port", type=int, default=8000, help="Server port number.")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development.")
    parser.add_argument("--log-level", default="info", help="Uvicorn log level.")
    parser.add_argument("--workers", type=int, default=1, help="Number of worker processes.")
    args = parser.parse_args(argv)

    uvicorn.run(
        "agentcad_backend.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level,
        workers=args.workers,
    )


def cli_main(argv: List[str] | None = None) -> None:
    raise SystemExit(main(argv))


if __name__ == "__main__":
    raise SystemExit(main())
