 All Submissions:

* [ ] Have you followed the guidelines in our Contributing document?
* [ ] Have you checked to ensure there aren't other open [Pull Requests](../../../pulls) for the same update/change?

<!-- You can erase any parts of this template not applicable to your Pull Request. -->

### New Feature Submissions:

1. [ ] Does your submission pass all ``pytest`` tests?
2. [ ] Have you lint your code locally before submission?
3. [ ] Does your code pass the ``mypy``, ``pyright``, ``tach``, ``slotscheck``, and ``ruff`` checks?

### Changes to Core Features:

* [ ] Have you added an explanation of what your changes do and why you'd like us to include them?
* [ ] Have you written new tests for your core changes, as applicable?
* [ ] Have you successfully run tests with your changes locally?
* [ ] Does your code pass all checks and tests with ``tox``?
