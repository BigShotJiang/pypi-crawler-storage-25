# Caribbean Breeze (https://codeberg.org/jdugan6240/caribbean-breeze)
from dataclasses import dataclass
from typing import final
from pygments.style import Style
from pygments.token import (
    Comment,
    Error,
    Generic,
    Keyword,
    Literal,
    Name,
    Number,
    Operator,
    Other,
    Punctuation,
    String,
    Text,
    Whitespace,
)


@final
@dataclass
class CaribbeanBreezePaletteDay:
    red = "#dd4444"
    orange = "#d99300"
    yellow = "#a79700"
    green = "#00af88"
    cyan = "#009090"
    blue = "#0060b4"
    magenta = "#d34fcf"
    white = "#dddddd"
    black = "#333333"
    grey = "#595959"
    grey2 = "#696969"
    grey3 = "#898989"
    grey4 = "#a9a9a9"
    grey5 = "#bbbbbb"
    grey6 = "#494949"
    fg = "#333333"
    bg = "#e8e0c7"
    bg_popup = "#e0d3ba"
    bg_green = "#00cc9929"
    bg_red = "#cc553333"



@final
@dataclass
class CaribbeanBreezePaletteNight:
    red = "#dd6666"
    orange = "#e79700"
    yellow = "#dcb900"
    green = "#00cc99"
    cyan = "#00baba"
    blue = "#0070d4"
    magenta = "#d179dc"
    white = "#dddddd"
    black = "#292929"
    grey = "#595959"
    grey2 = "#696969"
    grey3 = "#898989"
    grey4 = "#a9a9a9"
    grey5 = "#bbbbbb"
    grey6 = "#494949"
    fg = "#dddddd"
    bg = "#39342f"
    bg_popup = "#392919"
    bg_green = "#00cc9929"
    bg_red = "#cc553355"


class CaribbeanBreezeStyleDay(Style):
    c = CaribbeanBreezePaletteDay()

    name = "caribbean-breeze-day"
    background_color = c.bg
    line_number_color = c.grey2
    styles = {
        Comment: f"{c.grey2} italic",
        Generic: c.fg,
        Generic.Deleted: c.red,
        Generic.Emph: f"{c.fg} underline",
        Generic.Error: c.red,
        Generic.Heading: f"{c.red} bold",
        Generic.Inserted: f"{c.fg} bold",
        Generic.Output: c.grey3,
        Generic.Prompt: c.yellow,
        Generic.Strong: f"{c.fg} bold",
        Generic.Subheading: f"{c.orange} bold",
        Generic.Traceback: c.fg,
        Error: c.red,
        Keyword: c.red,
        Keyword.Declaration: c.magenta,
        Keyword.Namespace: f"{c.yellow} italic",
        Keyword.Reserved: c.red,
        Keyword.Type: c.orange,
        Keyword.Declaration: c.red,
        Literal: c.fg,
        Literal.Date: c.fg,
        Name: c.fg,
        Name.Attribute: f"{c.magenta} italic",
        Name.Builtin: f"{c.magenta} italic",
        Name.Builtin.Pseudo: f"{c.magenta} italic",
        Name.Class: c.orange,
        Name.Constant: c.fg,
        Name.Decorator: f"{c.cyan} bold",
        Name.Entity: c.orange,
        Name.Exception: c.orange,
        Name.Function: f"{c.cyan} bold",
        Name.Label: c.yellow,
        Name.Namespace: f"{c.yellow} bold",
        Name.Other: c.fg,
        Name.Tag: f"{c.yellow} italic",
        Name.Variable: c.fg,
        Name.Variable.Class: c.fg,
        Name.Variable.Global: c.fg,
        Name.Variable.Instance: c.fg,
        Number: c.magenta,
        Number.Bin: c.magenta,
        Number.Float: c.magenta,
        Number.Hex: c.magenta,
        Number.Integer: c.magenta,
        Number.Integer.Long: c.magenta,
        Number.Oct: c.magenta,
        Operator: f"{c.orange} bold",
        Operator.Word: f"{c.orange} bold",
        Other: c.fg,
        Punctuation: c.fg,
        String: c.green,
        String.Backtick: c.green,
        String.Char: c.green,
        String.Doc: c.green,
        String.Double: c.green,
        String.Escape: c.green,
        String.Heredoc: c.green,
        String.Interpol: c.green,
        String.Other: c.green,
        String.Regex: c.green,
        String.Single: c.green,
        String.Symbol: c.green,
        Text: c.fg,
        Whitespace: c.grey,
    }


class CaribbeanBreezeStyleNight(Style):
    c = CaribbeanBreezePaletteNight()

    name = "caribbean-breeze-night"
    background_color = c.bg
    line_number_color = c.grey2
    styles = {
        Comment: f"{c.grey2} italic",
        Generic: c.fg,
        Generic.Deleted: c.red,
        Generic.Emph: f"{c.fg} underline",
        Generic.Error: c.red,
        Generic.Heading: f"{c.red} bold",
        Generic.Inserted: f"{c.fg} bold",
        Generic.Output: c.grey3,
        Generic.Prompt: c.yellow,
        Generic.Strong: f"{c.fg} bold",
        Generic.Subheading: f"{c.orange} bold",
        Generic.Traceback: c.fg,
        Error: c.red,
        Keyword: c.red,
        Keyword.Declaration: c.magenta,
        Keyword.Namespace: f"{c.yellow} italic",
        Keyword.Reserved: c.red,
        Keyword.Type: c.orange,
        Keyword.Declaration: c.red,
        Literal: c.fg,
        Literal.Date: c.fg,
        Name: c.fg,
        Name.Attribute: f"{c.magenta} italic",
        Name.Builtin: f"{c.magenta} italic",
        Name.Builtin.Pseudo: f"{c.magenta} italic",
        Name.Class: c.orange,
        Name.Constant: c.fg,
        Name.Decorator: f"{c.cyan} bold",
        Name.Entity: c.orange,
        Name.Exception: c.orange,
        Name.Function: f"{c.cyan} bold",
        Name.Label: c.yellow,
        Name.Namespace: f"{c.yellow} bold",
        Name.Other: c.fg,
        Name.Tag: f"{c.yellow} italic",
        Name.Variable: c.fg,
        Name.Variable.Class: c.fg,
        Name.Variable.Global: c.fg,
        Name.Variable.Instance: c.fg,
        Number: c.magenta,
        Number.Bin: c.magenta,
        Number.Float: c.magenta,
        Number.Hex: c.magenta,
        Number.Integer: c.magenta,
        Number.Integer.Long: c.magenta,
        Number.Oct: c.magenta,
        Operator: f"{c.orange} bold",
        Operator.Word: f"{c.orange} bold",
        Other: c.fg,
        Punctuation: c.fg,
        String: c.green,
        String.Backtick: c.green,
        String.Char: c.green,
        String.Doc: c.green,
        String.Double: c.green,
        String.Escape: c.green,
        String.Heredoc: c.green,
        String.Interpol: c.green,
        String.Other: c.green,
        String.Regex: c.green,
        String.Single: c.green,
        String.Symbol: c.green,
        Text: c.fg,
        Whitespace: c.grey,
    }

