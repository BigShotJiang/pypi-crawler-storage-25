# Pygments Caribbean Breeze

This repository contains the Pygments style plugin for the [Caribbean Breeze](https://codeberg.org/jdugan6240/caribbean-breeze) theme.
Available as the `pygments-caribbean-breeze` package on PyPI.
The names of the styles are `caribbean-breeze-night` and `caribbean-breeze-day`, respectively.
