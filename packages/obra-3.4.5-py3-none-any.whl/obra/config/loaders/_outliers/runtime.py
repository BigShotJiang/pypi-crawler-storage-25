"""Runtime and local-environment config getters."""

from __future__ import annotations

import logging
import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults
from ._helpers import resolve_bool_config

logger = logging.getLogger(__name__)

__all__ = [
    "get_api_base_url",
    "get_benchmark_repo_root",
    "get_benchmark_workspace_directory",
    "get_cli_cleanup_runtime_log_config",
    "get_default_project_override",
    "get_heartbeat_initial_delay",
    "get_heartbeat_interval",
    "get_local_emulator_api_url",
    "get_projects_default_directory",
    "get_runtime_platform_config",
    "get_spike_first_config",
    "get_template_retention_settings",
    "is_local_mode",
]


def get_local_emulator_api_url() -> str:
    """Get local emulator API base URL from the current emulator project id."""
    project_id = os.environ.get(
        "OBRA_FIREBASE_EMULATOR_PROJECT_ID",
        _defaults.LOCAL_EMULATOR_PROJECT_ID,
    )
    return f"http://localhost:5001/{project_id.rstrip('/')}/us-central1"


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string
    """
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    config, _, _ = _core.load_layered_config()
    config_url = config.get("api_base_url")
    if isinstance(config_url, str):
        return config_url.rstrip("/")

    return _defaults.DEFAULT_API_BASE_URL


def is_local_mode() -> bool:
    """Check if local emulator mode is currently enabled.

    Returns:
        True if the API base URL is set to the local emulator URL
    """
    return get_api_base_url() == get_local_emulator_api_url()


def get_template_retention_settings() -> tuple[bool, bool]:
    """Get template edit retention settings.

    Resolution order:
    1. orchestration.template_retention.keep_on_success from config file
    2. orchestration.template_retention.keep_on_error from config file
    3. DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS/ERROR constants

    Returns:
        Tuple of (keep_on_success, keep_on_error)
    """
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    keep_on_success = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS
    keep_on_error = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_ERROR
    if isinstance(orch_config, dict):
        template_config = orch_config.get("template_retention", {})
        if isinstance(template_config, dict):
            if template_config.get("keep_on_success") is not None:
                keep_on_success = bool(template_config.get("keep_on_success"))
            if template_config.get("keep_on_error") is not None:
                keep_on_error = bool(template_config.get("keep_on_error"))

    return (keep_on_success, keep_on_error)


def get_heartbeat_interval() -> int:
    """Get heartbeat interval in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INTERVAL environment variable
    2. orchestration.progress.heartbeat_interval_s from config file
    3. Default 60 seconds

    Returns:
        Heartbeat interval in seconds
    """
    env_interval = os.environ.get("OBRA_HEARTBEAT_INTERVAL")
    if env_interval:
        try:
            value = int(env_interval)
            if value > 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INTERVAL must be > 0 (got %s)", env_interval)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            interval = progress_config.get("heartbeat_interval_s")
            if interval is not None:
                value = int(interval)
                if value > 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_interval_s must be > 0 (got %s)",
                    interval,
                )

    return 60


def get_heartbeat_initial_delay() -> int:
    """Get heartbeat initial delay in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INITIAL_DELAY environment variable
    2. orchestration.progress.heartbeat_initial_delay_s from config file
    3. Default 30 seconds

    Returns:
        Heartbeat initial delay in seconds
    """
    env_delay = os.environ.get("OBRA_HEARTBEAT_INITIAL_DELAY")
    if env_delay:
        try:
            value = int(env_delay)
            if value >= 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INITIAL_DELAY must be >= 0 (got %s)", env_delay)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            delay = progress_config.get("heartbeat_initial_delay_s")
            if delay is not None:
                value = int(delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_initial_delay_s must be >= 0 (got %s)",
                    delay,
                )

    return 30


def get_default_project_override() -> str | None:
    """Get local default project override from layered config."""
    config, _, _ = _core.load_layered_config()
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_project")
        return str(value) if value is not None else None
    return None


def get_benchmark_workspace_directory() -> Path:
    """Get the benchmark workspace root with env override support."""
    from pathlib import Path

    env_value = os.environ.get("OBRA_BENCHMARK_WORKSPACE_DIRECTORY")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("workspace_directory")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: benchmark.workspace_directory")


def get_benchmark_repo_root() -> Path:
    """Get the protected Obra repo root used by benchmark path guards."""
    from pathlib import Path

    env_value = os.environ.get("OBRA_BENCHMARK_REPO_ROOT")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("repo_root")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: benchmark.repo_root")


def get_projects_default_directory() -> Path:
    """Get the default directory for Obra-managed projects."""
    from pathlib import Path

    env_value = os.environ.get("OBRA_PROJECTS_DEFAULT_DIRECTORY")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_directory")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: projects.default_directory")


def get_cli_cleanup_runtime_log_config() -> dict[str, int]:
    """Get runtime log cleanup thresholds for the universal cleanup command."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    cli = config.get("cli", {})
    cleanup = cli.get("cleanup", {}) if isinstance(cli, dict) else {}

    max_size_raw = os.environ.get("OBRA_CLI_CLEANUP_RUNTIME_LOG_MAX_SIZE_BYTES") or (
        cleanup.get("runtime_log_max_size_bytes") if isinstance(cleanup, dict) else None
    )
    backup_count_raw = os.environ.get("OBRA_CLI_CLEANUP_RUNTIME_LOG_BACKUP_COUNT") or (
        cleanup.get("runtime_log_backup_count") if isinstance(cleanup, dict) else None
    )

    if max_size_raw is None:
        raise RuntimeError("Missing required config key: cli.cleanup.runtime_log_max_size_bytes")
    if backup_count_raw is None:
        raise RuntimeError("Missing required config key: cli.cleanup.runtime_log_backup_count")

    max_size = int(max_size_raw)
    backup_count = int(backup_count_raw)
    if max_size <= 0:
        raise RuntimeError("cli.cleanup.runtime_log_max_size_bytes must be > 0")
    if backup_count <= 0:
        raise RuntimeError("cli.cleanup.runtime_log_backup_count must be > 0")
    return {
        "runtime_log_max_size_bytes": max_size,
        "runtime_log_backup_count": backup_count,
    }


def get_runtime_platform_config() -> dict[str, int]:
    """Get runtime platform compatibility settings with env override support."""
    env_value = os.environ.get("OBRA_RUNTIME_PLATFORM_FD_SOFT_LIMIT_MINIMUM")
    if env_value is not None:
        minimum = int(env_value)
    else:
        config, _, _ = _core.load_layered_config(include_defaults=True)
        runtime = config.get("runtime", {})
        platform_config = runtime.get("platform", {}) if isinstance(runtime, dict) else {}
        if "fd_soft_limit_minimum" not in platform_config:
            raise RuntimeError(
                "Missing required config key: runtime.platform.fd_soft_limit_minimum"
            )
        minimum = int(platform_config["fd_soft_limit_minimum"])

    if minimum <= 0:
        raise RuntimeError("runtime.platform.fd_soft_limit_minimum must be > 0")
    return {"fd_soft_limit_minimum": minimum}


def get_spike_first_config() -> dict[str, Any]:
    """Get spike-first execution config with env-backed enabled override."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    orchestration = config.get("orchestration", {})
    if not isinstance(orchestration, dict):
        raise ConfigurationError("orchestration section not found in config")

    spike_first = orchestration.get("spike_first", {})
    if not isinstance(spike_first, dict):
        raise ConfigurationError("orchestration.spike_first must be a dictionary")

    max_spikes = spike_first.get("max_spikes", {})
    if not isinstance(max_spikes, dict):
        raise ConfigurationError("orchestration.spike_first.max_spikes must be a dictionary")

    enabled = resolve_bool_config(
        "OBRA_SPIKE_FIRST_ENABLED",
        "orchestration.spike_first.enabled",
        default=None,
        fail_fast=True,
        include_defaults=True,
        label="Spike-first setting",
    )

    executor_timeout = spike_first.get("executor_timeout_s")
    evaluator_timeout = spike_first.get("evaluator_timeout_s")
    if executor_timeout is None:
        raise ConfigurationError("orchestration.spike_first.executor_timeout_s is required")
    if evaluator_timeout is None:
        raise ConfigurationError("orchestration.spike_first.evaluator_timeout_s is required")

    normalized_max_spikes: dict[str, int] = {}
    for rigor_mode in ("light", "balanced", "thorough"):
        raw_value = max_spikes.get(rigor_mode)
        if raw_value is None:
            raise ConfigurationError(
                f"orchestration.spike_first.max_spikes.{rigor_mode} is required"
            )
        try:
            normalized_max_spikes[rigor_mode] = int(raw_value)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"orchestration.spike_first.max_spikes.{rigor_mode} must be an integer"
            ) from exc

    return {
        **spike_first,
        "enabled": enabled,
        "max_spikes": normalized_max_spikes,
        "executor_timeout_s": int(executor_timeout),
        "evaluator_timeout_s": int(evaluator_timeout),
    }
