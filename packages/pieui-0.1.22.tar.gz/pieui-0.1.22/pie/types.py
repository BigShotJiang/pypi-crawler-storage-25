import inspect
from fastapi import Response, Request, UploadFile
from dataclasses import dataclass, field
from typing import Any, Dict, TypedDict, Optional, Literal
from dataclasses_json import DataClassJsonMixin, dataclass_json
from starlette.datastructures import ImmutableMultiDict


@dataclass_json
@dataclass
class SocketIOEvent(DataClassJsonMixin):
    name: str
    data: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self):
        return f"<SocketIOEvent name={self.name} data={self.data}>"


def get_rich_signature(method):
    sig = inspect.signature(method)
    params = list(sig.parameters.values())

    if params and params[0].name == "self":
        params = params[1:]

    has_response = any(p.annotation is Response for p in params)
    if not has_response:
        params.insert(
            0,
            inspect.Parameter(
                "response",
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=Response,
            ),
        )

    has_request = any(p.annotation is Request for p in params)
    if not has_request:
        params.insert(
            0,
            inspect.Parameter(
                "request",
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=Request,
            ),
        )

    public_sig = inspect.Signature(
        parameters=params,
        return_annotation=sig.return_annotation,
    )
    return public_sig, has_request, has_response


def _is_upload_file_type(tp) -> bool:
    """Check if type is UploadFile or List[UploadFile]."""
    if tp is UploadFile:
        return True
    return getattr(tp, "__origin__", None) is list and getattr(tp, "__args__", ()) == (
        UploadFile,
    )


def form2dict(d: ImmutableMultiDict) -> Dict[str, Any]:
    res = {}
    for key in d.keys():
        val = d.getlist(key)
        if len(val) == 1:
            res[key] = val[0]
        else:
            res[key] = val
    return res


AggregationRuleType = Optional[Literal["by_underscore"]]


class FormParsingOptions(TypedDict, total=False):
    max_files: int
    max_fields: int
    max_part_size: int


class ParsedPieField:
    """Force parsing through card.parse() from child_loc, even if the default behavior would skip it."""

    def __init__(self, default=..., alias: str = None):
        self.default = default
        self.alias = alias


class RawPieField:
    """Skip card.parse() and pass the raw form value, even if the param name is in child_loc."""

    def __init__(self, default=None, alias: str = None):
        self.default = default
        self.alias = alias
