"""Initialize Pie in an existing project (mirror of `pieui init`)."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from jinja2 import Template

_PIE_CONFIG_DIR = ".pie"
_PIE_CONFIG_FILE = "config.json"
_MAX_HOMEDIR_SCAN_DEPTH = 2


def handle_init() -> Path:
    """Set up pages/components in cwd, ensure web.py, and link a frontend project."""
    project_dir = Path.cwd().resolve()
    print(f"[pie] Initializing pie in {project_dir}...")

    pages_dir = project_dir / "pages"
    components_dir = pages_dir / "components"
    web_py = project_dir / "web.py"
    main_py = pages_dir / "main.py"

    if not pages_dir.exists():
        pages_dir.mkdir(parents=True)
        print(f"[pie] Created: {pages_dir.resolve()}")
    else:
        print(f"[pie] Already exists: {pages_dir.resolve()}")

    if not components_dir.exists():
        components_dir.mkdir(parents=True)
        print(f"[pie] Created: {components_dir.resolve()}")
    else:
        print(f"[pie] Already exists: {components_dir.resolve()}")

    if not web_py.exists():
        web_py.write_text(_render_template("web.py.j2"), encoding="utf-8")
        print(f"[pie] Created: {web_py.resolve()}")
    else:
        print(f"[pie] Already exists: {web_py.resolve()}")

    if not main_py.exists():
        main_py.write_text(
            _render_template("pages/main.py.j2"), encoding="utf-8"
        )
        print(f"[pie] Created: {main_py.resolve()}")
    else:
        print(f"[pie] Already exists: {main_py.resolve()}")

    _ensure_frontend_link(project_dir)

    print("[pie] Initialization complete!")
    print("[pie] Next steps:")
    print("  1. Run `pie web web:app` to start the dev server")
    print("  2. Use `pie card add <type> <Name>` to scaffold components")
    return project_dir


def _ensure_frontend_link(project_dir: Path) -> None:
    config_path = project_dir / _PIE_CONFIG_DIR / _PIE_CONFIG_FILE
    existing = _read_config(config_path)
    if existing.get("frontendProjectDir") and existing.get("frontendComponentsDir"):
        print(f"[pie] Frontend project already linked in {_PIE_CONFIG_DIR}/{_PIE_CONFIG_FILE}:")
        print(f"[pie]   project:    {existing['frontendProjectDir']}")
        print(f"[pie]   components: {existing['frontendComponentsDir']}")
        return

    if not sys.stdin.isatty():
        print("[pie] Non-interactive shell — skipping frontend link prompt.")
        print(
            f"[pie] To configure, add `frontendProjectDir` and `frontendComponentsDir` to "
            f"{config_path}"
        )
        return

    home = Path.home()
    print(
        f"[pie] Searching {home} for frontend projects with `piecomponents/` "
        f"or `app/` directories..."
    )
    candidates = _find_frontend_candidates(home, _MAX_HOMEDIR_SCAN_DEPTH)

    frontend_project = existing.get("frontendProjectDir")
    frontend_components = existing.get("frontendComponentsDir")

    if not frontend_project:
        picked = _pick_candidate(candidates, home)
        if picked is not None:
            frontend_project = str(picked["project"])
            frontend_components = frontend_components or str(picked["components"])

    if not frontend_project:
        frontend_project = _prompt_absolute_dir(
            "Path to frontend project root", home
        )
    if frontend_project and not frontend_components:
        guess = Path(frontend_project) / "piecomponents"
        if guess.is_dir():
            frontend_components = str(guess)
        else:
            frontend_components = _prompt_absolute_dir(
                "Path to frontend piecomponents directory", home
            )

    if not frontend_project or not frontend_components:
        print("[pie] Skipped frontend link — no directory was provided.")
        return

    payload = {
        **existing,
        "frontendProjectDir": frontend_project,
        "frontendComponentsDir": frontend_components,
    }
    _write_config(config_path, payload)
    print(f"[pie] Saved frontend link to {config_path}")
    print(f"[pie]   project:    {frontend_project}")
    print(f"[pie]   components: {frontend_components}")


def _find_frontend_candidates(
    home: Path, max_depth: int
) -> list[dict[str, Path]]:
    found: list[dict[str, Path]] = []

    def visit(dir_path: Path, depth: int) -> None:
        if depth > max_depth:
            return
        try:
            entries = list(dir_path.iterdir())
        except (PermissionError, FileNotFoundError):
            return
        subdirs = [
            e for e in entries if e.is_dir() and not e.name.startswith(".")
        ]
        names = {e.name for e in subdirs}
        if "piecomponents" in names or ("app" in names and "package.json" in {e.name for e in entries}):
            components = dir_path / "piecomponents"
            if not components.is_dir():
                components = dir_path / "app"
            found.append({"project": dir_path, "components": components})
        for sub in subdirs:
            if sub.name in {"node_modules", ".git", ".venv", "__pycache__"}:
                continue
            visit(sub, depth + 1)

    visit(home, 0)
    return found


def _pick_candidate(
    candidates: list[dict[str, Path]], home: Path
) -> dict[str, Path] | None:
    if not candidates:
        print("[pie] No matching frontend projects found under home directory.")
        return None
    print("[pie] Found frontend candidates:")
    for i, c in enumerate(candidates, 1):
        print(f"  {i}. {c['project'].resolve()}")
    raw = input(
        f"[pie] Pick a candidate [1-{len(candidates)}] or press Enter to type manually: "
    ).strip()
    if not raw:
        return None
    try:
        idx = int(raw)
    except ValueError:
        print("[pie] Invalid selection — falling back to manual input.")
        return None
    if idx < 1 or idx > len(candidates):
        print("[pie] Out-of-range selection — falling back to manual input.")
        return None
    return candidates[idx - 1]


def _prompt_absolute_dir(label: str, home: Path) -> str | None:
    while True:
        raw = input(f"[pie] {label} (absolute or ~/...): ").strip()
        if not raw:
            return None
        if raw.startswith("~"):
            expanded = home / raw[1:].lstrip("/").lstrip(os.sep)
        else:
            expanded = Path(raw)
        absolute = expanded.expanduser().resolve()
        if not absolute.is_dir():
            print(f"[pie] Not a directory: {absolute}. Try again.")
            continue
        return str(absolute)


def _read_config(config_path: Path) -> dict[str, object]:
    if not config_path.exists():
        return {}
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_config(config_path: Path, payload: dict[str, object]) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )


def _render_template(template_name: str) -> str:
    template_path = _templates_dir() / template_name
    template_text = template_path.read_text(encoding="utf-8")
    return Template(template_text).render().rstrip() + "\n"


def _templates_dir() -> Path:
    return Path(__file__).resolve().parent / "templates"