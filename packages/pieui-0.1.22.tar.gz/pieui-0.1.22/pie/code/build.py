"""Build static JSON from a Web application."""

import importlib
import json
import os
import sys
from pathlib import Path


def handle_build(web_path: str) -> None:
    module_name, app_name = web_path.split(":")
    sys.path.insert(0, os.getcwd())
    module = importlib.import_module(module_name)
    web = getattr(module, app_name)

    result = {}
    for page_key, page in web.pages.items():
        if not hasattr(page, "fields") or page.fields is None:
            print(f"Warning: Page '{page_key}' has no fields, skipping")
            continue
        result[page_key] = page.fields.generate()

    output_path = Path("build.json").resolve()
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"Build complete: {output_path} ({len(result)} pages)")
