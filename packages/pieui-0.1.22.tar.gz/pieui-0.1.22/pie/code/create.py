import subprocess
from pathlib import Path

from jinja2 import Template


def handle_create(project_name: str) -> Path:
    project_dir = Path(project_name).resolve()
    if project_dir.exists():
        raise ValueError(f"Project already exists: {project_dir}")

    _run_command(["uv", "init", project_name, "--no-workspace"], cwd=Path.cwd())
    _run_command(["uv", "add", "pieui"], cwd=project_dir)
    _cleanup_uv_scaffold(project_dir)
    _create_project_structure(project_dir)
    process = _start_dev_server(project_dir)

    print(f"[pie] Created project: {project_name}")
    print(f"[pie] Path: {project_dir}")
    print("[pie] Server command: uv run uvicorn web:app --port 8008")
    print(f"[pie] Server PID: {process.pid}")
    return project_dir


def _create_project_structure(project_dir: Path) -> None:
    pages_dir = project_dir / "pages"
    components_dir = pages_dir / "components"
    components_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "web.py").write_text(_render_template("web.py.j2"), encoding="utf-8")
    (pages_dir / "main.py").write_text(
        _render_template("pages/main.py.j2"), encoding="utf-8"
    )


def _cleanup_uv_scaffold(project_dir: Path) -> None:
    for file_name in ("main.py", "hello.py"):
        scaffold_path = project_dir / file_name
        if scaffold_path.exists():
            scaffold_path.unlink()


def _render_template(template_name: str) -> str:
    template_path = _templates_dir() / template_name
    template_text = template_path.read_text(encoding="utf-8")
    return Template(template_text).render().rstrip() + "\n"


def _templates_dir() -> Path:
    return Path(__file__).resolve().parent / "templates"


def _run_command(command: list[str], *, cwd: Path) -> None:
    try:
        subprocess.run(command, cwd=cwd, check=True)
    except subprocess.CalledProcessError as error:
        raise ValueError(f"Command failed: {' '.join(command)}") from error


def _start_dev_server(project_dir: Path) -> subprocess.Popen:
    return subprocess.Popen(
        ["uv", "run", "uvicorn", "web:app", "--port", "8008"],
        cwd=project_dir,
        start_new_session=True,
    )
