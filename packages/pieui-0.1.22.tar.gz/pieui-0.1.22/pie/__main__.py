"""PieDemo CLI

Command-line interface for the PieDemo framework.
"""

import argparse
import sys
from typing import Optional

from .code import (
    handle_build,
    handle_card_add,
    handle_card_add_event,
    handle_card_list,
    handle_card_list_events,
    handle_card_pull,
    handle_card_remote_history,
    handle_card_remote_list,
    handle_card_remote_private,
    handle_card_remote_public,
    handle_card_remote_pull,
    handle_card_remote_push,
    handle_card_remote_remove,
    handle_card_view,
    handle_create,
    handle_init,
    handle_login,
    handle_page_add,
    handle_page_ajax_add,
    handle_page_ajax_remove,
    handle_page_view,
    handle_web,
    handle_web_verify,
)
from .code.services.storage import PieStorageError

CARD_TYPES = {"simple", "complex", "container", "complex-container"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pie",
        description="Pie - Framework for building interactive web applications",
    )

    subparsers = parser.add_subparsers(
        dest="command", help="Available commands", required=True
    )

    # piedemo web module:app [verify|build]
    web_parser = subparsers.add_parser("web", help="Run or lint a web application")
    web_parser.add_argument("web", help="Web in format module:attribute, e.g. some:app")
    web_subparsers = web_parser.add_subparsers(dest="web_command")
    web_subparsers.add_parser("verify", help="Verify the web application")
    web_subparsers.add_parser("build", help="Build static JSON from a Web application")

    card_parser = subparsers.add_parser("card", help="Manage card templates")
    card_subparsers = card_parser.add_subparsers(dest="card_command", required=True)
    card_add_parser = card_subparsers.add_parser(
        "add", help="Create a card file from a template"
    )
    card_add_parser.add_argument("card_type", choices=sorted(CARD_TYPES))
    card_add_parser.add_argument("card_name", metavar="NAME")
    card_add_parser.add_argument("--io", action="store_true", dest="use_io")
    card_add_parser.add_argument("--ajax", action="store_true", dest="use_ajax")
    card_subparsers.add_parser(
        "list", help="List card files in the components directory"
    )
    card_pull_parser = card_subparsers.add_parser(
        "pull",
        help="Download a card from current project, another project, or a public alias",
    )
    card_pull_parser.add_argument(
        "card_name",
        metavar="REF",
        help="Name, project/Name, or r/user/Name",
    )
    card_view_parser = card_subparsers.add_parser(
        "view",
        help="Print card name, props, ajax, IO, and events as plain text tables",
    )
    card_view_parser.add_argument("card_name", metavar="NAME")
    card_list_events_parser = card_subparsers.add_parser(
        "list-events",
        help="List get_supported_events() entries for a card (static parse)",
    )
    card_list_events_parser.add_argument("card_name", metavar="NAME")
    card_add_event_parser = card_subparsers.add_parser(
        "add-event",
        help="Add an IO event to a card (not implemented for Python sources)",
    )
    card_add_event_parser.add_argument("card_name", metavar="NAME")
    card_add_event_parser.add_argument("event_name", metavar="EVENT_NAME")

    card_remote_parser = card_subparsers.add_parser(
        "remote",
        help="PieUI storage API (see https://cdn-pieui.swarm.ing/api/openapi.json)",
    )
    card_remote_subparsers = card_remote_parser.add_subparsers(
        dest="card_remote_command",
        required=True,
    )
    card_remote_list_parser = card_remote_subparsers.add_parser(
        "list",
        help="List component names (GET /api/components/{user_id}/{project_slug})",
    )
    card_remote_list_parser.add_argument(
        "--user",
        dest="remote_user_id",
        metavar="USER_ID",
        default=None,
        help="Storage user id (default: PIE_USER_ID from env or .env in cwd)",
    )
    card_remote_list_parser.add_argument(
        "--project",
        dest="remote_project_slug",
        metavar="SLUG",
        default=None,
        help="Project slug (default: PIE_PROJECT or PIE_PROJECT_SLUG from env or .env)",
    )
    card_remote_push_parser = card_remote_subparsers.add_parser(
        "push",
        help="Upload a card file to PieUI storage for the configured user/project",
    )
    card_remote_push_parser.add_argument("card_name", metavar="NAME")
    card_remote_pull_parser = card_remote_subparsers.add_parser(
        "pull",
        help="Download a card into components_dir (same user/project as pie card remote push)",
    )
    card_remote_pull_parser.add_argument("card_name", metavar="NAME")
    card_remote_history_parser = card_remote_subparsers.add_parser(
        "history",
        help="Show component revision history with file diffs for the configured user/project",
    )
    card_remote_history_parser.add_argument("card_name", metavar="NAME")
    card_remote_history_parser.add_argument(
        "--page",
        type=int,
        default=1,
        help="History page number (default: 1)",
    )
    card_remote_history_parser.add_argument(
        "--per-page",
        dest="per_page",
        type=int,
        default=10,
        help="Entries per page (default: 10)",
    )
    card_remote_history_parser.add_argument(
        "--from",
        dest="from_revision",
        type=int,
        default=None,
        help="First revision in inclusive range filter",
    )
    card_remote_history_parser.add_argument(
        "--to",
        dest="to_revision",
        type=int,
        default=None,
        help="Last revision in inclusive range filter",
    )
    card_remote_public_parser = card_remote_subparsers.add_parser(
        "public",
        help="Publish a component under /api/public-components/{user_id}/{component_name}",
    )
    card_remote_public_parser.add_argument("card_name", metavar="NAME")
    card_remote_private_parser = card_remote_subparsers.add_parser(
        "private",
        help="Remove a component public alias and make it private again",
    )
    card_remote_private_parser.add_argument("card_name", metavar="NAME")
    card_remote_remove_parser = card_remote_subparsers.add_parser(
        "remove",
        help="Delete a component from PieUI storage for the configured user/project",
    )
    card_remote_remove_parser.add_argument("card_name", metavar="NAME")

    page_parser = subparsers.add_parser("page", help="Manage page templates")
    page_subparsers = page_parser.add_subparsers(dest="page_command", required=True)
    page_add_parser = page_subparsers.add_parser(
        "add", help="Create a page file from a template"
    )
    page_add_parser.add_argument("page_name", metavar="NAME")
    page_view_parser = page_subparsers.add_parser("view", help="Print page source file")
    page_view_parser.add_argument("page_name", metavar="NAME")
    page_ajax_parser = page_subparsers.add_parser(
        "ajax",
        help="Add or remove an AJAX handler in a page class",
    )
    page_ajax_parser.add_argument("page_name", metavar="PAGE")
    page_ajax_parser.add_argument("ajax_action", choices=["add", "remove"])
    page_ajax_parser.add_argument("handler_name", metavar="HANDLER")

    create_parser = subparsers.add_parser("create", help="Create a new Pie project")
    create_parser.add_argument("project_name", metavar="NAME")

    subparsers.add_parser(
        "init",
        help="Initialize Pie in an existing project (pages/, components/, web.py) and link a frontend project",
    )

    subparsers.add_parser(
        "login", help="Sign in to PieUI and save credentials under .pie/config.json"
    )

    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def run(
    command: str,
    web: Optional[str] = None,
    web_command: Optional[str] = None,
    card_command: Optional[str] = None,
    page_command: Optional[str] = None,
    card_type: Optional[str] = None,
    card_name: Optional[str] = None,
    card_remote_command: Optional[str] = None,
    remote_user_id: Optional[str] = None,
    remote_project_slug: Optional[str] = None,
    event_name: Optional[str] = None,
    page: int = 1,
    per_page: int = 10,
    from_revision: Optional[int] = None,
    to_revision: Optional[int] = None,
    page_name: Optional[str] = None,
    ajax_action: Optional[str] = None,
    handler_name: Optional[str] = None,
    project_name: Optional[str] = None,
    use_io: bool = False,
    use_ajax: bool = False,
) -> int:
    try:
        if command == "web":
            if web is None:
                raise ValueError("Web path is required")
            if web_command == "verify":
                handle_web_verify(web)
            elif web_command == "build":
                handle_build(web)
            else:
                handle_web(web)
            return 0

        if command == "page":
            if page_name is None:
                raise ValueError("Page name is required")
            if page_command == "add":
                handle_page_add(page_name)
            elif page_command == "view":
                handle_page_view(page_name)
            elif page_command == "ajax":
                if handler_name is None:
                    raise ValueError("Handler name is required")
                if ajax_action == "add":
                    handle_page_ajax_add(page_name, handler_name)
                elif ajax_action == "remove":
                    handle_page_ajax_remove(page_name, handler_name)
            return 0
        if command == "card":
            if card_command == "add":
                handle_card_add(
                    card_name=card_name,
                    card_type=card_type,
                    use_io=use_io,
                    use_ajax=use_ajax,
                )
            elif card_command == "list":
                handle_card_list()
            elif card_command == "view":
                if card_name is None:
                    raise ValueError("Card name is required")
                handle_card_view(card_name)
            elif card_command == "pull":
                if card_name is None:
                    raise ValueError("Card reference is required")
                handle_card_pull(card_name)
            elif card_command == "list-events":
                if card_name is None:
                    raise ValueError("Card name is required")
                handle_card_list_events(card_name)
            elif card_command == "add-event":
                if card_name is None or event_name is None:
                    raise ValueError("Card name and event name are required")
                handle_card_add_event(card_name, event_name)
            elif card_command == "remote":
                if card_remote_command == "list":
                    handle_card_remote_list(
                        user_id=remote_user_id,
                        project_slug=remote_project_slug,
                    )
                elif card_remote_command == "push":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_push(card_name)
                elif card_remote_command == "pull":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_pull(card_name)
                elif card_remote_command == "history":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_history(
                        card_name,
                        page=page,
                        per_page=per_page,
                        from_revision=from_revision,
                        to_revision=to_revision,
                    )
                elif card_remote_command == "public":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_public(card_name)
                elif card_remote_command == "private":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_private(card_name)
                elif card_remote_command == "remove":
                    if card_name is None:
                        raise ValueError("Card name is required")
                    handle_card_remote_remove(card_name)
            return 0
        if command == "create":
            if project_name is None:
                raise ValueError("Project name is required")
            handle_create(project_name)
            return 0
        if command == "init":
            handle_init()
            return 0
        if command == "login":
            handle_login()
            return 0
        return 0
    except (ValueError, PieStorageError) as error:
        print(f"[pie] Error: {error}", file=sys.stderr)
        return 1


def main(argv: list[str] | None = None, **kwargs: object) -> int:
    if kwargs:
        return run(**kwargs)
    return run(**vars(parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
