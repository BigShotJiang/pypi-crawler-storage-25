"""
Genetics-Viz: A web-based visualization tool for genetics cohort data.
"""

__version__ = "0.7.1"
