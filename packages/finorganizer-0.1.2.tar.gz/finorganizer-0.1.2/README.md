# finorganizer

Organise your music library by artist and album, ready for Jellyfin.

Scans folders for audio files, reads their embedded tags, and copies them into a clean `Artist/Album/Track` structure.

## Installation

```bash
pip install finorganizer
```

## Usage

```bash
finorganizer
```

1. Enter one or more source folders containing your audio files (blank line to finish)
2. Review the detected artists and albums
3. Enter the output directory
4. Confirm to copy

Files that already exist at the destination are skipped.

## Supported formats

MP3, FLAC, Opus, OGG, M4A, WAV

## Requirements

Files must have `artist`, `album`, and `title` tags — files missing any of these are ignored.
