"""parsimoney.currencies - Currency recognition and ISO resolution.

Symbols, ISO codes, and common names. The parser preserves what the human
wrote as the currency string. This module handles two concerns:

1. Recognition: is this token a currency indicator?
2. ISO resolution: what ISO 4217 code does this indicator map to?

Some indicators are unambiguous (EUR, euro sign, "yen"). Others are
ambiguous ("$" could be USD, CAD, AUD; "dollars" likewise; "pounds"
could be GBP, EGP, LBP). Ambiguous indicators resolve via application-
provided defaults or locale, never by guessing.
"""

import locale as _locale

# Unambiguous symbols: each maps to exactly one ISO code.
_UNAMBIGUOUS_SYMBOLS: dict[str, str] = {
    "\u20ac": "EUR",  # euro sign
    "\u00a5": "JPY",  # yen/yuan sign
    "\u20b9": "INR",  # Indian rupee sign
    "\u20a9": "KRW",  # Korean won sign
    "\u20bf": "BTC",  # bitcoin sign
    "\u0e3f": "THB",  # Thai baht sign
    "R$": "BRL",  # Brazilian real
}

# Ambiguous symbols: could map to multiple ISO codes depending on context.
_AMBIGUOUS_SYMBOLS: dict[str, list[str]] = {
    "$": ["USD", "CAD", "AUD", "NZD", "SGD", "HKD", "MXN"],
    "\u00a3": ["GBP", "EGP", "LBP"],  # pound sign
    "kr": ["SEK", "NOK", "DKK", "ISK"],
    "zl": ["PLN"],  # unambiguous in practice, but non-standard symbol
}

# All recognized symbols (for recognition, not resolution)
SYMBOLS: dict[str, str | None] = {}
for _sym, _iso in _UNAMBIGUOUS_SYMBOLS.items():
    SYMBOLS[_sym] = _iso
for _sym in _AMBIGUOUS_SYMBOLS:
    SYMBOLS[_sym] = None

# ISO 4217 codes: three-letter uppercase. These are always unambiguous
# because they ARE the canonical form.
ISO_CODES: set[str] = {
    "USD",
    "EUR",
    "GBP",
    "JPY",
    "CAD",
    "AUD",
    "NZD",
    "CHF",
    "CNY",
    "HKD",
    "SGD",
    "SEK",
    "NOK",
    "DKK",
    "ISK",
    "KRW",
    "INR",
    "BRL",
    "MXN",
    "ZAR",
    "RUB",
    "TRY",
    "PLN",
    "CZK",
    "HUF",
    "THB",
    "TWD",
    "ILS",
    "AED",
    "SAR",
    "PHP",
    "MYR",
    "IDR",
    "VND",
    "BTC",
    "ETH",
}

# Common names: lowercase word to ISO code (unambiguous) or None (ambiguous).
NAMES: dict[str, str | None] = {
    "dollar": None,
    "dollars": None,
    "euro": "EUR",
    "euros": "EUR",
    "pound": None,
    "pounds": None,
    "yen": "JPY",
    "yuan": "CNY",
    "franc": "CHF",
    "francs": "CHF",
    "rupee": None,
    "rupees": None,
    "krona": None,
    "kronor": None,
    "krone": None,
    "kroner": None,
    "won": "KRW",
    "baht": "THB",
    "real": "BRL",
    "reais": "BRL",
    "peso": None,
    "pesos": None,
    "lira": "TRY",
    "rand": "ZAR",
    "zloty": "PLN",
    "ringgit": "MYR",
    "rupiah": "IDR",
    "dong": "VND",
    "shekel": "ILS",
    "shekels": "ILS",
    "dirham": None,
    "dirhams": None,
    "riyal": None,
    "riyals": None,
    "cent": None,
    "cents": None,
    "penny": None,
    "pence": None,
}


def recognize_symbol(text: str) -> tuple[str, int] | None:
    """Try to match a currency symbol at the start of text.

    Returns (symbol_string, chars_consumed) or None.
    Multi-character symbols are tried first (longest match wins).
    """
    for symbol in sorted(SYMBOLS, key=len, reverse=True):
        if text.startswith(symbol):
            return symbol, len(symbol)
    return None


def recognize_currency_word(word: str) -> str | None:
    """Check if a word is a recognized currency name or ISO code.

    Returns the recognized string as-written, or None.
    """
    if word.upper() in ISO_CODES:
        return word
    if word.lower() in NAMES:
        return word
    return None


def resolve_iso(
    currency: str,
    defaults: dict[str, str] | None = None,
) -> str | None:
    """Resolve a currency string to an ISO 4217 code.

    Resolution order:
    1. Explicit defaults dict (application-provided)
    2. ISO code (it's already canonical)
    3. Unambiguous symbol or name from the table
    4. Locale default (for ambiguous indicators)
    5. None (ambiguous, no default available)
    """
    # 1. Explicit default for this exact string
    if defaults and currency in defaults:
        return defaults[currency]
    # Also check lowercase for names
    if defaults and currency.lower() in defaults:
        return defaults[currency.lower()]

    # 2. Already an ISO code
    if currency.upper() in ISO_CODES:
        return currency.upper()

    # 3. Unambiguous symbol
    if currency in _UNAMBIGUOUS_SYMBOLS:
        return _UNAMBIGUOUS_SYMBOLS[currency]

    # 3b. Unambiguous name
    lower = currency.lower()
    if lower in NAMES and NAMES[lower] is not None:
        return NAMES[lower]

    # 4. Ambiguous -- try locale default
    iso_from_locale = _locale_iso()
    if iso_from_locale is not None:
        # Check if the locale currency is one of the candidates
        if currency in _AMBIGUOUS_SYMBOLS:
            if iso_from_locale in _AMBIGUOUS_SYMBOLS[currency]:
                return iso_from_locale
        # Ambiguous names: "dollars" in a USD locale -> USD
        if lower in NAMES and NAMES[lower] is None:
            return iso_from_locale

    # 5. Can't resolve
    return None


def _locale_iso() -> str | None:
    """Get the ISO currency code from the current locale, if available."""
    try:
        conv = _locale.localeconv()
        code = conv.get("int_curr_symbol", "").strip()
        if code and code.upper() in ISO_CODES:
            return code.upper()
    except (ValueError, AttributeError):
        pass
    return None
