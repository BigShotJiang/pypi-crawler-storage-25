"""parsimoney - A strict money parser.

Parses human-written money values into structured (amount, currency) pairs.
Strict: the entire input must be accounted for. No silent data loss.
"""

from parsimoney.currencies import resolve_iso
from parsimoney.parser import parse_money
from parsimoney.types import Money

__all__ = ["parse_money", "Money", "resolve_iso"]
