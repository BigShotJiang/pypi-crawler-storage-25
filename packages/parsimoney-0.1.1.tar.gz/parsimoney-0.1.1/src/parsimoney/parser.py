"""parsimoney.parser - Strict money parser.

Parses human-written money values. Strict: the entire input must be
accounted for by a currency indicator and/or a numeric amount. No
silent data loss.
"""

import re

from parsimoney.currencies import recognize_currency_word, recognize_symbol, resolve_iso
from parsimoney.types import Money

# Matches numbers with optional thousands separators and decimals.
# Examples: 45, 1234.56, 1,234.56, 0.50, .99
# The \d+ branch must come before \d{1,3}(,\d{3})* to avoid partial matches
# on numbers without thousands separators (e.g. "1000" matching only "100").
_NUMBER_RE = re.compile(r"-?(?:\d+(?:,\d{3})*(?:\.\d+)?|\.\d+)")


def parse_money(
    text: str,
    defaults: dict[str, str] | None = None,
) -> Money:
    """Parse a money value from text.

    Recognizes:
        $45.00          symbol prefix
        45.00$          symbol suffix (rare but valid)
        USD 45.00       ISO code prefix
        45.00 USD       ISO code suffix
        45 dollars      currency name suffix
        1,234.56        number with thousands separators
        45.00           bare number (no currency)

    The optional defaults dict maps ambiguous currency strings to ISO codes
    (e.g. {"$": "CAD", "dollars": "CAD"}). For unambiguous indicators,
    ISO resolution happens automatically. For ambiguous ones without an
    explicit default, locale is checked as a fallback.

    Raises ValueError if the input cannot be fully parsed as a money value.
    """
    original = text
    text = text.strip()
    if not text:
        raise ValueError("empty money value")

    currency = ""
    currency_after = False
    amount_str = ""

    # Try symbol prefix: $45.00, EUR45.00
    sym = recognize_symbol(text)
    if sym is not None:
        currency, consumed = sym
        remainder = text[consumed:].lstrip()
        match = _NUMBER_RE.match(remainder)
        if match and match.end() == len(remainder):
            amount_str = match.group()
        elif not remainder:
            raise ValueError(f"currency symbol with no amount: {original!r}")
        else:
            raise ValueError(f"unexpected text after currency symbol: {original!r}")
    else:
        # Try number first, then look for suffix
        match = _NUMBER_RE.match(text)
        if match:
            amount_str = match.group()
            remainder = text[match.end() :].lstrip()

            if not remainder:
                # Bare number, no currency
                pass
            else:
                # Check for symbol suffix: 45$, 45EUR
                sym = recognize_symbol(remainder)
                if sym is not None:
                    symbol, consumed = sym
                    if consumed == len(remainder):
                        currency = symbol
                        currency_after = True
                    else:
                        raise ValueError(f"unexpected text after amount: {original!r}")
                else:
                    # Check for word suffix: 45 dollars, 45 USD
                    word = recognize_currency_word(remainder)
                    if word is not None:
                        currency = word
                        currency_after = True
                    else:
                        raise ValueError(f"unexpected text after amount: {original!r}")
        else:
            # Try word prefix: USD 45.00
            parts = text.split(None, 1)
            if len(parts) == 2:
                word = recognize_currency_word(parts[0])
                if word is not None:
                    currency = word
                    match = _NUMBER_RE.match(parts[1])
                    if match and match.end() == len(parts[1]):
                        amount_str = match.group()
                    else:
                        raise ValueError(
                            f"unexpected text after currency: {original!r}"
                        )
                else:
                    raise ValueError(f"could not parse money value: {original!r}")
            else:
                raise ValueError(f"could not parse money value: {original!r}")

    amount = float(amount_str.replace(",", ""))
    iso = resolve_iso(currency, defaults) if currency else None
    return Money(
        amount=amount, currency=currency, iso=iso, currency_after=currency_after
    )
