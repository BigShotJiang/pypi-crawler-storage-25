"""parsimoney.types - Result types for parsed money values."""

from dataclasses import dataclass


@dataclass
class Money:
    amount: float
    currency: str
    iso: str | None = None
    currency_after: bool = False

    def __str__(self) -> str:
        if self.amount == int(self.amount):
            amount_str = f"{int(self.amount)}"
        else:
            amount_str = f"{self.amount:.2f}"
        if not self.currency:
            return amount_str
        if self.currency_after:
            return f"{amount_str} {self.currency}"
        return f"{self.currency}{amount_str}"
