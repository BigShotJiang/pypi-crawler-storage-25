import{l as o,a as r}from"../chunks/Dkmbe-G6.mjs";export{o as load_css,r as start};
