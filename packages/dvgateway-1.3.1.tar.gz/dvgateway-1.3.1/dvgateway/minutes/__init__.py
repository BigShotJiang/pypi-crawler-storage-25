from dvgateway.minutes.manager import MinutesManager

__all__ = ["MinutesManager"]
