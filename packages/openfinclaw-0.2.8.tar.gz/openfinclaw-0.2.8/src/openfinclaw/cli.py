#!/usr/bin/env python3
"""OpenFinClaw CLI — Rich interactive terminal client.

Usage:
    openfinclaw-cli                                       # interactive REPL
    openfinclaw-cli "分析宁德时代"                          # single question, then exit
    openfinclaw-cli --url http://localhost:9008            # custom server
    openfinclaw-cli --thread <thread-id>                   # resume existing thread

Commands inside the CLI:
    /new          Create a new thread
    /threads      List all threads
    /history      Show message history
    /runs         Show run history
    /cancel       Cancel the active run
    /help         Show available commands
    /quit         Exit
"""

from __future__ import annotations

import argparse
import sys

import httpx

from .client import OpenFinClawClient
from .exceptions import ConflictError, OpenFinClawError, RateLimitError

DEFAULT_URL = "https://api.openfinclaw.ai/agent"
try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("openfinclaw")
except Exception:
    __version__ = "0.0.0-dev"

# Lazy-import Rich to keep SDK lightweight
_console = None


def _get_console():
    global _console
    if _console is None:
        from rich.console import Console

        _console = Console()
    return _console


# ── Styling constants ────────────────────────────────────────────────────────

STATUS_COLORS = {
    "idle": "green",
    "running": "yellow",
    "completed": "green",
    "error": "red",
    "pending": "dim",
    "cancelling": "yellow",
    "cancelled": "dim",
}

ROLE_STYLES = {
    "user": ("bold cyan", "User"),
    "assistant": ("bold green", "Assistant"),
}


# ── Helper functions ─────────────────────────────────────────────────────────


def _format_duration(ms: int | None) -> str:
    if ms is None:
        return "-"
    secs = ms / 1000
    if secs < 60:
        return f"{secs:.1f}s"
    return f"{secs / 60:.1f}m"


def _format_time(iso_str: str | None) -> str:
    if not iso_str:
        return "-"
    if "T" in iso_str:
        return iso_str.split("T")[1][:8]
    return iso_str[:19]


# ── Display functions ────────────────────────────────────────────────────────


def welcome_banner(health: dict, url: str, thread_id: str) -> None:
    from rich.panel import Panel

    console = _get_console()
    examples = [
        "[cyan]>[/] 300750 宁德时代深度分析",
        "[cyan]>[/] NVDA 英伟达 Q4 财报分析",
        "[cyan]>[/] 今天A股有哪些热门板块？",
        "[cyan]>[/] 用双均线策略回测沪深300",
        "[cyan]>[/] BTC 当前处于减半周期什么阶段？",
    ]
    content = (
        f"[dim]v{__version__}[/]\n\n"
        f"[bold]Thread:[/] {thread_id[:12]}...\n\n"
        "[bold]Try asking:[/]\n" + "\n".join(examples)
    )
    console.print(
        Panel(
            content,
            title="[bold green]OpenFinClaw AI[/]",
            subtitle="Type [bold]/help[/] for commands · [bold]/quit[/] to exit",
            border_style="green",
            padding=(1, 2),
        )
    )


def show_threads(client: OpenFinClawClient) -> None:
    from rich.table import Table
    from rich.text import Text

    console = _get_console()
    threads = client.list_threads()
    if not threads:
        console.print("  [dim]No threads found[/]")
        return

    table = Table(title="Threads", border_style="blue", show_lines=False)
    table.add_column("ID", style="cyan", max_width=12)
    table.add_column("Status", justify="center")
    table.add_column("Title", style="white")
    table.add_column("Turns", justify="right", style="dim")
    table.add_column("Created", style="dim", max_width=10)

    for t in threads[:15]:
        color = STATUS_COLORS.get(t.status, "white")
        table.add_row(
            t.id[:12],
            Text(t.status, style=color),
            t.title,
            str(t.total_turns),
            _format_time(t.created_at),
        )
    console.print(table)


def show_history(client: OpenFinClawClient, thread_id: str) -> None:
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.text import Text

    console = _get_console()
    msgs = client.list_messages(thread_id)
    if not msgs:
        console.print("  [dim]No messages in this thread[/]")
        return

    for m in msgs:
        style, label = ROLE_STYLES.get(m.role, ("white", m.role))
        if m.role == "assistant":
            panel_content = Markdown(m.content[:500])
        else:
            panel_content = Text(m.content[:500])
        console.print(
            Panel(
                panel_content,
                title=f"[{style}]{label}[/]",
                title_align="left",
                border_style=style.split()[-1],
                padding=(0, 1),
            )
        )


def show_runs(client: OpenFinClawClient, thread_id: str) -> None:
    from rich.table import Table
    from rich.text import Text

    console = _get_console()
    runs = client.list_runs(thread_id)
    if not runs:
        console.print("  [dim]No runs in this thread[/]")
        return

    table = Table(title="Runs", border_style="blue")
    table.add_column("ID", style="cyan", max_width=12)
    table.add_column("Status", justify="center")
    table.add_column("Duration", justify="right")
    table.add_column("Turns", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Time", style="dim", max_width=10)

    for r in runs:
        cost_str = f"${r.cost_usd:.4f}" if r.cost_usd > 0 else "-"
        color = STATUS_COLORS.get(r.status, "white")
        table.add_row(
            r.id[:12],
            Text(r.status, style=color),
            _format_duration(r.duration_ms),
            str(r.num_turns),
            cost_str,
            _format_time(r.created_at),
        )
    console.print(table)


def show_help() -> None:
    from rich.panel import Panel
    from rich.table import Table

    console = _get_console()
    table = Table(border_style="dim", show_header=False, padding=(0, 2))
    table.add_column("Command", style="bold cyan")
    table.add_column("Description")
    table.add_row("/new", "Create a new conversation thread")
    table.add_row("/threads", "List all threads")
    table.add_row("/history", "Show message history for current thread")
    table.add_row("/runs", "Show run history for current thread")
    table.add_row("/cancel", "Cancel any active run")
    table.add_row("/help", "Show this help message")
    table.add_row("/quit", "Exit the CLI")
    console.print(Panel(table, title="[bold]Commands[/]", border_style="blue"))


def send_message(client: OpenFinClawClient, thread_id: str, message: str) -> None:
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.text import Text

    console = _get_console()
    text_buffer = ""
    has_error = False
    error_msg = ""
    streaming_text = False
    completed_tools: list[str] = []
    handoffs: list[str] = []
    active_tool: str | None = None
    status = None

    try:
        # Phase 1: Rich Status spinner while waiting
        status = console.status("Thinking...", spinner="dots")
        status.start()

        for event in client.stream(thread_id, message):
            if event.type == "TEXT_DELTA":
                if not streaming_text:
                    streaming_text = True
                    if status:
                        status.stop()
                        status = None
                    # Print agent/tool header
                    for name in handoffs:
                        console.print(Rule(f"[bold blue]{name}[/]", style="blue"))
                    for name in completed_tools:
                        console.print(f"  [green]✓ {name}[/]")
                    if completed_tools or handoffs:
                        console.print()
                # Stream text directly
                print(event.text, end="", flush=True)
                text_buffer += event.text

            elif event.type == "TOOL_START":
                if active_tool:
                    completed_tools.append(active_tool)
                active_tool = event.tool_name or "unknown"
                if status:
                    status.update(f"Calling {active_tool}...")

            elif event.type == "TOOL_DONE":
                if active_tool:
                    completed_tools.append(active_tool)
                    active_tool = None
                if status:
                    status.update("Thinking...")

            elif event.type == "AGENT_HANDOFF":
                handoffs.append(event.agent_name or "unknown")
                if status:
                    status.update(f"→ {event.agent_name}...")

            elif event.type == "ERROR":
                has_error = True
                error_msg = event.error or "Unknown error"

            elif event.type == "RUN_FINISHED":
                if event.is_error:
                    has_error = True

        if status:
            status.stop()
            status = None

        # End of stream
        if text_buffer:
            print("\n")  # clean newline after streamed text

        if error_msg:
            console.print(
                Panel(
                    Text(error_msg, style="red"),
                    title="[bold red]Error[/]",
                    border_style="red",
                )
            )
        if has_error and not error_msg:
            console.print("[red]Run finished with errors[/]")

    except ConflictError:
        console.print(
            Panel(
                "Thread is already running. Use [bold]/cancel[/] or wait.",
                border_style="yellow",
                title="[yellow]Conflict[/]",
            )
        )
    except RateLimitError as e:
        console.print(Panel(str(e), border_style="red", title="[bold red]Rate Limit[/]"))
    except KeyboardInterrupt:
        console.print("\n  [yellow]Interrupted[/] [dim](server may still be processing)[/]")
    except httpx.RemoteProtocolError:
        console.print(
            Panel(
                "Server closed connection unexpectedly.\n"
                "The backend LLM service may be down. Please try again later.",
                border_style="red",
                title="[bold red]Connection Lost[/]",
            )
        )
    except httpx.ReadTimeout:
        console.print(
            Panel(
                "Request timed out (600s). The server may be overloaded.",
                border_style="yellow",
                title="[bold yellow]Timeout[/]",
            )
        )
    except Exception as e:
        console.print(
            Panel(
                str(e),
                border_style="red",
                title="[bold red]Unexpected Error[/]",
            )
        )
    finally:
        if status:
            status.stop()


def cancel_runs(client: OpenFinClawClient, thread_id: str) -> None:
    console = _get_console()
    runs = client.list_runs(thread_id)
    active = [r for r in runs if r.status == "running"]
    if not active:
        console.print("  [dim]No active runs[/]")
        return
    for r in active:
        ok = client.cancel_run(thread_id, r.id)
        if ok:
            console.print(f"  [green]Cancelled:[/] {r.id[:12]}...")
        else:
            console.print(f"  [red]Failed to cancel:[/] {r.id[:12]}...")


# ── Auto-update ──────────────────────────────────────────────────────────────


def _check_for_update() -> None:
    """Check PyPI for newer version and auto-upgrade if available."""
    import subprocess

    console = _get_console()
    try:
        resp = httpx.get(
            "https://pypi.org/pypi/openfinclaw/json",
            timeout=5,
        )
        if resp.status_code != 200:
            return
        latest = resp.json()["info"]["version"]
        if latest == __version__:
            return

        console.print(
            f"  [yellow]New version available:[/] {__version__} -> [bold green]{latest}[/]"
        )
        console.print("  [dim]Upgrading...[/]")

        # Try pip, then uv
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "openfinclaw[cli]"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print(f"  [green]Updated to {latest}.[/] Please restart the CLI.\n")
            sys.exit(0)

        # Fallback: uv
        result = subprocess.run(
            ["uv", "tool", "upgrade", "openfinclaw"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print(f"  [green]Updated to {latest}.[/] Please restart the CLI.\n")
            sys.exit(0)

        console.print(
            "  [yellow]Auto-update failed.[/] Run manually: "
            "pip install --upgrade openfinclaw[cli]\n"
        )
    except Exception:
        pass  # Network error — skip silently


# ── Main ─────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="openfinclaw-cli",
        description="OpenFinClaw — AI financial analysis agent",
        epilog='Example: openfinclaw-cli "分析宁德时代"',
    )
    parser.add_argument("question", nargs="?", default=None, help="Single question, then exit")
    parser.add_argument("--url", default=DEFAULT_URL, help="API base URL")
    parser.add_argument("--thread", default=None, help="Resume existing thread ID")
    parser.add_argument("--api-key", default="79a29a66b189ec09", help="API key")
    parser.add_argument("--no-update", action="store_true", help="Skip auto-update check")
    parser.add_argument("--version", action="version", version=f"openfinclaw-cli {__version__}")
    args = parser.parse_args()

    from rich.panel import Panel

    console = _get_console()

    # Auto-update check
    if not args.no_update:
        _check_for_update()

    # SDK expiry / auth check
    try:
        client = OpenFinClawClient(api_key=args.api_key, base_url=args.url)
    except OpenFinClawError as e:
        console.print(Panel(str(e), border_style="red", title="[bold red]Error[/]"))
        sys.exit(1)

    # Health check
    try:
        health = client.health()
    except Exception as e:
        console.print(
            Panel(
                f"Cannot connect to [bold]{args.url}[/]\n\n{e}",
                title="[bold red]Connection Failed[/]",
                border_style="red",
            )
        )
        sys.exit(1)

    # Thread
    if args.thread:
        thread_id = args.thread
    else:
        try:
            thread = client.create_thread()
        except Exception as e:
            console.print(Panel(str(e), border_style="red", title="[bold red]Error[/]"))
            sys.exit(1)
        thread_id = thread.id
        console.print(f"  [green]Thread created:[/] {thread_id[:12]}...")

    # Single question mode: ask and exit
    if args.question:
        console.print()
        send_message(client, thread_id, args.question)
        console.print()
        return

    # Interactive REPL
    console.print()
    welcome_banner(health, args.url, thread_id)
    console.print()

    while True:
        try:
            user_input = console.input("[bold cyan]You:[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Bye![/]")
            break

        if not user_input:
            continue

        cmd = user_input.lower()
        if cmd == "/quit" or cmd == "/exit" or cmd == "/q":
            console.print("[dim]Bye![/]")
            break
        elif cmd == "/new":
            thread = client.create_thread()
            thread_id = thread.id
            console.print(f"  [green]Thread created:[/] {thread_id[:12]}...")
            continue
        elif cmd == "/threads":
            show_threads(client)
            continue
        elif cmd == "/history":
            show_history(client, thread_id)
            continue
        elif cmd == "/runs":
            show_runs(client, thread_id)
            continue
        elif cmd == "/cancel":
            cancel_runs(client, thread_id)
            continue
        elif cmd == "/help":
            show_help()
            continue
        elif user_input.startswith("/"):
            console.print(f"  [red]Unknown command:[/] {user_input}. Type [bold]/help[/]")
            continue

        console.print()
        send_message(client, thread_id, user_input)
        console.print()


if __name__ == "__main__":
    main()
