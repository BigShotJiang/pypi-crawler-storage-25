"""Stack Machine"""

## Errors

class GoToError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class MathError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')
    
class CycleError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class AddressError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class IfError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class QuantityError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

## Lexer

class Lexer:
    def __init__(self, data='a'):
        self.data = data
    
    def form(self, text):
        result = []
        
        for line in text.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            parts = line.split()
            if len(parts) == 2:
                string_val = parts[0]
                try:
                    number_val = float(parts[1])
                    if number_val.is_integer():
                        number_val = int(number_val)
                except ValueError:
                    raise ValueError(f'Incorrect number: {parts[1]}')
                
                result.append(string_val)
                result.append(number_val)
        
        return result
    
    @property
    def start(self):
        result = []
        if len(self.data) % 2 != 0:
            raise QuantityError(f'There is an unfinished "Operation-Value" pair in the code')
        for i in range(0, len(self.data), 2):
            result.append([self.data[i], self.data[i+1]])
        return result

## Parser

class Parser:
    def __init__(self, data, len, num_cells=6):
        if num_cells < 1 or not(isinstance(num_cells, int)):
            raise QuantityError(f'The number of cells must be natural and greater than 1')
        self.data = data
        self.current_cell = 1
        self.pos = 1
        self.cells, self.output = [0 for i in range(num_cells)], 0
        self.cycles = [[] for i in range(len)]
        self.code_len = len
        self.address_to = -1
        self.num_cells = num_cells

    def to(self, address_to=-1):
        if address_to == -1:
            self.pos += 1
        else:
            self.pos = address_to
    
    @property
    def do(self):
        operation = self.data[self.pos-1][0]
        value = self.data[self.pos-1][1]
        if not isinstance(value, int):
            raise MathError(f'Cannot work with non-integer numbers.')
        if operation == 'change':
            if 1 <= value <= self.num_cells:
                self.current_cell = value
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')

        elif operation == 'add':
            if value >= 0:
                self.cells[self.current_cell-1] += value
            else:
                if value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] += self.cells[-1-value]

        elif operation == 'sub':
            if value >= 0:
                self.cells[self.current_cell-1] -= value
            else:
                if value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] -= self.cells[-1-value]
        
        elif operation == 'copy':
            if self.num_cells >= value >= 1:
                self.cells[value-1] = self.cells[self.current_cell-1]
            elif -self.num_cells <= value <= -1:
                self.cells[self.current_cell-1] = self.cells[-value-1]
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation == 'set':
            self.cells[self.current_cell-1] = value
        
        elif operation == 'output':
            if 1 <= value <= self.num_cells:
                self.output = self.cells[value-1]
            else:
                GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation == '[':
            if value < -2:
                raise CycleError(f'Cannot repeat the cycle {value} times')
            
            if value > 0:
                self.cycles[self.pos-1] = [value]
            elif value == 0:
                self.cycles[self.pos-1] = ['=']
            elif value == -1:
                self.cycles[self.pos-1] = ['>']
            elif value == -2:
                self.cycles[self.pos-1] = ['<']
        
        elif operation == ']':
            if value > self.code_len or value < 1:
                raise AddressError(f'Cannot go beyond the code boundary')
            type = self.cycles[value-1][0]
            if type == '=':
                if self.cells[self.current_cell-1] == 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            elif type == '>':
                if self.cells[self.current_cell-1] > 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            elif type == '<':
                if self.cells[self.current_cell-1] < 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            else:
                if type > 1:
                    self.address_to = value+1
                    self.cycles[value-1][0] -= 1
                else:
                    self.address_to = -1
        
        elif operation == 'if':
            if 1 <= value <= self.code_len:
                if self.cells[self.current_cell-1] <= 0:
                    self.address_to = value
                else:
                    self.address_to = -1
            elif -1 >= value >= -self.code_len:
                if self.cells[self.current_cell-1] >= 0:
                    self.address_to = -value
                else:
                    self.address_to = -1
            else:
                raise AddressError(f'Cannot go beyond the code boundary')

    @property    
    def start(self):
        while self.pos <= self.code_len:
            self.do
            self.to(self.address_to)
            self.address_to = -1
        return self.cells + [self.output]

def code(text, num_cells=6):
    lexer = Lexer(Lexer().form(text)).start
    print(Parser(lexer, len(lexer), num_cells).start)