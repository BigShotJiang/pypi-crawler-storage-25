"""Tests for msdatasets.download and msdatasets.client."""

import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from msdatasets.client import ensure_extracted, fetch_manifest
from msdatasets.download import (
    _import_torch_dataset,
    _NullContext,
    _parse_repo_spec,
    _RichBatchProgress,
    download_dataset,
    download_part,
    download_repo_dataset,
    load_dataset,
    load_repo_dataset,
)
from msdatasets.exceptions import DatasetNotFoundError, DownloadError
from msdatasets.models import (
    Dataset,
    DatasetPart,
    Manifest,
    RepoDatasetResponse,
    RepoImportJob,
    RepoImportStatus,
    RepoSource,
)

# Sample manifest dictionary for testing
SAMPLE_MANIFEST_DICT = {
    "dataset_id": "550e8400-e29b-41d4-a716-446655440000",
    "dataset_name": "Test Dataset",
    "total_parts": 2,
    "parts": [
        {
            "part_index": 0,
            "item_id": "aaa",
            "filename": "sample_01.mszx",
            "num_indices": 100,
            "extract_url": "/datasets/550e8400/parts/aaa",
            "download_url": "/transfer/files/aaa.mszx",
        },
        {
            "part_index": 1,
            "item_id": "bbb",
            "filename": "sample_02.mszx",
            "num_indices": 200,
            "extract_url": "/datasets/550e8400/parts/bbb",
            "download_url": "/transfer/files/bbb.mszx",
        },
    ],
}


def _make_part(**overrides):
    """Create a DatasetPart with sensible defaults."""
    defaults = {
        "part_index": 0,
        "item_id": "aaa",
        "filename": "test.mszx",
        "num_indices": 10,
        "extract_url": "/datasets/x/parts/aaa",
        "download_url": "/transfer/files/aaa.mszx",
    }
    defaults.update(overrides)
    return DatasetPart(**defaults)


class TestManifest:
    """Tests for the Manifest model."""

    def test_from_dict(self):
        m = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        assert m.dataset_id == "550e8400-e29b-41d4-a716-446655440000"
        assert m.dataset_name == "Test Dataset"
        assert m.total_parts == 2
        assert len(m.parts) == 2

    def test_from_dict_null_name(self):
        data = {**SAMPLE_MANIFEST_DICT, "dataset_name": None}
        m = Manifest.model_validate(data)
        assert m.dataset_name is None

    def test_parts_are_datasetpart(self):
        m = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        p = m.parts[0]
        assert isinstance(p, DatasetPart)
        assert p.part_index == 0
        assert p.item_id == "aaa"
        assert p.filename == "sample_01.mszx"
        assert p.num_indices == 100
        assert p.extract_url == "/datasets/550e8400/parts/aaa"
        assert p.download_url == "/transfer/files/aaa.mszx"


class TestDataset:
    """Tests for the Dataset model."""

    def test_len(self, tmp_path):
        ds = Dataset(
            dataset_id="x",
            dataset_name="X",
            cache_dir=tmp_path,
            files=[tmp_path / "a", tmp_path / "b"],
        )
        assert len(ds) == 2

    def test_indexing(self, tmp_path):
        f = tmp_path / "a"
        ds = Dataset(
            dataset_id="x",
            dataset_name=None,
            cache_dir=tmp_path,
            files=[f],
        )
        assert ds[0] == f

    def test_iteration(self, tmp_path):
        files = [tmp_path / "a", tmp_path / "b"]
        ds = Dataset(
            dataset_id="x",
            dataset_name=None,
            cache_dir=tmp_path,
            files=files,
        )
        assert list(ds) == files


class TestFetchManifest:
    """Tests for the fetch_manifest function."""

    @pytest.mark.asyncio
    async def test_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_MANIFEST_DICT

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        m = await fetch_manifest("550e8400", client=mock_client)
        assert m.dataset_id == "550e8400-e29b-41d4-a716-446655440000"
        assert len(m.parts) == 2

    @pytest.mark.asyncio
    async def test_404_raises_not_found(self):
        mock_response = MagicMock()
        mock_response.status_code = 404

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        with pytest.raises(DatasetNotFoundError, match="not found"):
            await fetch_manifest("bad-id", client=mock_client)

    @pytest.mark.asyncio
    async def test_500_raises_download_error(self):
        mock_response = MagicMock()
        mock_response.status_code = 500

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        with pytest.raises(DownloadError, match="500"):
            await fetch_manifest("some-id", client=mock_client)


class TestEnsureExtracted:
    """Tests for ensure_extracted."""

    @pytest.mark.asyncio
    @patch("msdatasets.client.get_api_url", return_value="https://api.example.com")
    async def test_204_already_cached(self, mock_api_url):
        mock_response = MagicMock()
        mock_response.status_code = 204

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        part = _make_part()
        await ensure_extracted(mock_client, part)  # Should return without error

        mock_client.get.assert_called_once_with(
            "https://api.example.com/datasets/x/parts/aaa"
        )

    @pytest.mark.asyncio
    @patch("msdatasets.client.stream_task", new_callable=AsyncMock)
    @patch("msdatasets.client.get_api_url", return_value="https://api.example.com")
    async def test_202_streams_task(self, mock_api_url, mock_stream):
        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.json.return_value = {
            "task_id": "task-123",
            "status_url": "/tasks/task-123",
        }

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        part = _make_part()
        await ensure_extracted(mock_client, part)

        mock_stream.assert_called_once_with(mock_client, "task-123")

    @pytest.mark.asyncio
    @patch("msdatasets.client.get_api_url", return_value="https://api.example.com")
    async def test_404_raises(self, mock_api_url):
        mock_response = MagicMock()
        mock_response.status_code = 404

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        part = _make_part()
        with pytest.raises(DownloadError, match="not found"):
            await ensure_extracted(mock_client, part)

    @pytest.mark.asyncio
    @patch("msdatasets.client.get_api_url", return_value="https://api.example.com")
    async def test_500_raises(self, mock_api_url):
        mock_response = MagicMock()
        mock_response.status_code = 500

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response

        part = _make_part()
        with pytest.raises(DownloadError, match="500"):
            await ensure_extracted(mock_client, part)


class TestDownloadPart:
    """Tests for the download_part function."""

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.ensure_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_file")
    def test_downloads_file(self, mock_dl_file, mock_ensure, mock_api_url, tmp_path):
        part = _make_part()
        expected = tmp_path / "test.mszx"
        mock_dl_file.return_value = expected

        result = download_part(part, tmp_path)

        assert result == expected
        mock_ensure.assert_called_once()
        mock_dl_file.assert_called_once_with(
            "https://api.example.com/transfer/files/aaa.mszx",
            expected,
            store_as="mszx",
            skip_existing=False,
            force=False,
        )

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.ensure_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_file")
    def test_passes_skip_existing(
        self, mock_dl_file, mock_ensure, mock_api_url, tmp_path
    ):
        part = _make_part()
        mock_dl_file.return_value = tmp_path / "test.mszx"

        download_part(part, tmp_path, skip_existing=True)

        mock_dl_file.assert_called_once_with(
            "https://api.example.com/transfer/files/aaa.mszx",
            tmp_path / "test.mszx",
            store_as="mszx",
            skip_existing=True,
            force=False,
        )

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.ensure_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_file")
    def test_passes_force(self, mock_dl_file, mock_ensure, mock_api_url, tmp_path):
        part = _make_part()
        mock_dl_file.return_value = tmp_path / "test.mszx"

        download_part(part, tmp_path, force=True)

        mock_dl_file.assert_called_once_with(
            "https://api.example.com/transfer/files/aaa.mszx",
            tmp_path / "test.mszx",
            store_as="mszx",
            skip_existing=False,
            force=True,
        )

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.ensure_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_file")
    def test_forwards_store_as(self, mock_dl_file, mock_ensure, mock_api_url, tmp_path):
        part = _make_part()
        mock_dl_file.return_value = tmp_path / "test.mzML"

        download_part(part, tmp_path, store_as="mzml")

        mock_dl_file.assert_called_once_with(
            "https://api.example.com/transfer/files/aaa.mszx",
            tmp_path / "test.mszx",
            store_as="mzml",
            skip_existing=False,
            force=False,
        )

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.ensure_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_file")
    def test_creates_dest_dir(self, mock_dl_file, mock_ensure, mock_api_url, tmp_path):
        part = _make_part()
        dest_dir = tmp_path / "nested" / "dir"
        mock_dl_file.return_value = dest_dir / "test.mszx"

        download_part(part, dest_dir)

        assert dest_dir.exists()


class TestDownloadDataset:
    """Tests for the download_dataset function."""

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_downloads_all_parts(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        mock_dir.return_value = ds_dir
        manifest = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_fetch.return_value = manifest

        mock_batch.return_value = [
            ds_dir / "sample_01.mszx",
            ds_dir / "sample_02.mszx",
        ]

        ds = download_dataset("550e8400", show_progress=False)

        assert len(ds) == 2
        assert ds.dataset_name == "Test Dataset"
        # Extraction should have been triggered
        mock_ensure.assert_called_once()
        # Downloads go through mstransfer
        mock_batch.assert_called_once()
        requests = mock_batch.call_args[0][0]
        assert len(requests) == 2
        assert requests[0].url == "https://api.example.com/transfer/files/aaa.mszx"
        assert requests[0].dest == ds_dir / "sample_01.mszx"
        assert requests[1].url == "https://api.example.com/transfer/files/bbb.mszx"
        assert requests[1].dest == ds_dir / "sample_02.mszx"

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_skips_existing_files(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        ds_dir.mkdir()
        mock_dir.return_value = ds_dir
        manifest = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_fetch.return_value = manifest

        # Pre-create one file
        (ds_dir / "sample_01.mszx").write_bytes(b"existing")

        mock_batch.return_value = [ds_dir / "sample_02.mszx"]

        ds = download_dataset("550e8400", show_progress=False)

        assert len(ds) == 2
        # Extraction should have been triggered for the missing part
        mock_ensure.assert_called_once()
        mock_batch.assert_called_once()
        requests = mock_batch.call_args[0][0]
        assert len(requests) == 1
        assert requests[0].dest == ds_dir / "sample_02.mszx"

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_force_redownloads(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        ds_dir.mkdir()
        mock_dir.return_value = ds_dir
        manifest = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_fetch.return_value = manifest

        (ds_dir / "sample_01.mszx").write_bytes(b"existing")

        mock_batch.return_value = [
            ds_dir / "sample_01.mszx",
            ds_dir / "sample_02.mszx",
        ]

        ds = download_dataset("550e8400", force_download=True, show_progress=False)

        assert len(ds) == 2
        # Both parts should be extracted and requested despite one existing
        mock_ensure.assert_called_once()
        requests = mock_batch.call_args[0][0]
        assert len(requests) == 2

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_all_cached_skips_download(
        self, mock_batch, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        ds_dir.mkdir()
        mock_dir.return_value = ds_dir
        manifest = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_fetch.return_value = manifest

        # Pre-create all files
        (ds_dir / "sample_01.mszx").write_bytes(b"existing")
        (ds_dir / "sample_02.mszx").write_bytes(b"existing")

        ds = download_dataset("550e8400", show_progress=False)

        assert len(ds) == 2
        mock_batch.assert_not_called()

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_saves_manifest_json(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        mock_dir.return_value = ds_dir
        manifest = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_fetch.return_value = manifest
        mock_batch.return_value = [
            ds_dir / "sample_01.mszx",
            ds_dir / "sample_02.mszx",
        ]

        download_dataset("550e8400", show_progress=False)

        manifest_file = ds_dir / "manifest.json"
        assert manifest_file.exists()
        import json

        saved = json.loads(manifest_file.read_text())
        assert saved["dataset_id"] == "550e8400-e29b-41d4-a716-446655440000"
        assert saved["total_parts"] == 2
        assert saved["parts"][0]["extract_url"] == "/datasets/550e8400/parts/aaa"
        assert saved["parts"][0]["download_url"] == "/transfer/files/aaa.mszx"


class TestDownloadStoreAs:
    """Tests for the store_as parameter on download_dataset."""

    @pytest.mark.parametrize(
        "store_as, ext",
        [("mszx", ".mszx"), ("msz", ".msz"), ("mzml", ".mzML")],
    )
    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_forwards_store_as_and_orders_by_target_name(
        self,
        mock_batch,
        mock_ensure,
        mock_fetch,
        mock_dir,
        mock_api_url,
        tmp_path,
        store_as,
        ext,
    ):
        ds_dir = tmp_path / "ds"
        mock_dir.return_value = ds_dir
        mock_fetch.return_value = Manifest.model_validate(SAMPLE_MANIFEST_DICT)

        # Emulate mstransfer's auto-extension rewrite.
        mock_batch.return_value = [
            ds_dir / f"sample_01{ext}",
            ds_dir / f"sample_02{ext}",
        ]

        ds = download_dataset("550e8400", store_as=store_as, show_progress=False)

        assert mock_batch.call_args.kwargs["store_as"] == store_as

        # DownloadRequest dests stay as .mszx — mstransfer handles the rewrite.
        requests = mock_batch.call_args[0][0]
        assert [r.dest.name for r in requests] == ["sample_01.mszx", "sample_02.mszx"]

        # Returned Dataset.files reflect the target extension, in manifest order.
        assert [f.name for f in ds.files] == [
            f"sample_01{ext}",
            f"sample_02{ext}",
        ]

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_mzml_cache_skips_download(
        self, mock_batch, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        ds_dir.mkdir()
        mock_dir.return_value = ds_dir
        mock_fetch.return_value = Manifest.model_validate(SAMPLE_MANIFEST_DICT)

        # Pre-create both parts at the .mzML extension; cache check should hit.
        (ds_dir / "sample_01.mzML").write_bytes(b"cached")
        (ds_dir / "sample_02.mzML").write_bytes(b"cached")

        ds = download_dataset("550e8400", store_as="mzml", show_progress=False)

        mock_batch.assert_not_called()
        assert [f.name for f in ds.files] == ["sample_01.mzML", "sample_02.mzML"]

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_mszx_on_disk_does_not_satisfy_mzml_request(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        ds_dir.mkdir()
        mock_dir.return_value = ds_dir
        mock_fetch.return_value = Manifest.model_validate(SAMPLE_MANIFEST_DICT)

        # A pre-existing .mszx must NOT count as cached when --store-as=mzml.
        (ds_dir / "sample_01.mszx").write_bytes(b"stale")
        (ds_dir / "sample_02.mszx").write_bytes(b"stale")

        mock_batch.return_value = [
            ds_dir / "sample_01.mzML",
            ds_dir / "sample_02.mzML",
        ]

        download_dataset("550e8400", store_as="mzml", show_progress=False)

        # Both parts re-downloaded because the cache key is per target format.
        requests = mock_batch.call_args[0][0]
        assert len(requests) == 2


class TestDownloadOutputDir:
    """Tests for the output_dir override on download_dataset."""

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_output_dir_bypasses_get_dataset_dir(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        target = tmp_path / "one-off"
        mock_fetch.return_value = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_batch.return_value = [
            target / "sample_01.mszx",
            target / "sample_02.mszx",
        ]

        ds = download_dataset("550e8400", output_dir=target, show_progress=False)

        # get_dataset_dir must not be consulted when output_dir is provided.
        mock_dir.assert_not_called()
        # Directory is created and used directly (no dataset_id subdir).
        assert target.exists()
        assert ds.cache_dir == target
        # DownloadRequest dests land inside target.
        requests = mock_batch.call_args[0][0]
        assert all(r.dest.parent == target for r in requests)
        # manifest.json is persisted inside the output dir too.
        assert (target / "manifest.json").exists()

    @patch("msdatasets.download.get_api_url", return_value="https://api.example.com")
    @patch("msdatasets.download.get_dataset_dir")
    @patch("msdatasets.download.fetch_manifest", new_callable=AsyncMock)
    @patch("msdatasets.download.ensure_all_extracted", new_callable=AsyncMock)
    @patch("msdatasets.download.download_batch")
    def test_none_uses_default_cache_dir(
        self, mock_batch, mock_ensure, mock_fetch, mock_dir, mock_api_url, tmp_path
    ):
        ds_dir = tmp_path / "ds"
        mock_dir.return_value = ds_dir
        mock_fetch.return_value = Manifest.model_validate(SAMPLE_MANIFEST_DICT)
        mock_batch.return_value = [
            ds_dir / "sample_01.mszx",
            ds_dir / "sample_02.mszx",
        ]

        ds = download_dataset("550e8400", show_progress=False)

        mock_dir.assert_called_once_with("550e8400")
        assert ds.cache_dir == ds_dir


class TestLoadDataset:
    """Tests for the load_dataset function (returns MSCompressDataset)."""

    @patch("msdatasets.download.download_dataset")
    def test_returns_mscompress_dataset(self, mock_download):
        mock_ds = MagicMock()
        mock_ds.cache_dir = "/tmp/ds"
        mock_download.return_value = mock_ds

        mock_msc_cls = MagicMock()
        sentinel = MagicMock()
        mock_msc_cls.return_value = sentinel

        fake_module = ModuleType("mscompress.datasets.torch")
        fake_module.MSCompressDataset = mock_msc_cls

        with patch.dict(sys.modules, {"mscompress.datasets.torch": fake_module}):
            result = load_dataset("abc-123", force_download=True, show_progress=False)

        mock_download.assert_called_once_with(
            "abc-123",
            force_download=True,
            show_progress=False,
            max_workers=4,
        )
        mock_msc_cls.assert_called_once_with("/tmp/ds", load_annotations=None)
        assert result is sentinel


class TestImportTorchDataset:
    """Tests for the lazy torch import helper."""

    def test_success_returns_class(self):
        fake_cls = MagicMock()
        fake_module = ModuleType("mscompress.datasets.torch")
        fake_module.MSCompressDataset = fake_cls
        with patch.dict(sys.modules, {"mscompress.datasets.torch": fake_module}):
            assert _import_torch_dataset() is fake_cls

    def test_missing_torch_raises_helpful_import_error(self):
        real_import = (
            __builtins__["__import__"]
            if isinstance(__builtins__, dict)
            else __builtins__.__import__
        )

        def fake_import(name, *args, **kwargs):
            if name == "mscompress.datasets.torch":
                raise ImportError("No module named 'torch'")
            return real_import(name, *args, **kwargs)

        # Drop any already-cached reference so the import actually runs.
        with patch.dict(sys.modules, {}, clear=False):
            sys.modules.pop("mscompress.datasets.torch", None)
            with patch("builtins.__import__", side_effect=fake_import):
                with pytest.raises(ImportError, match="torch"):
                    _import_torch_dataset()


class TestRichBatchProgress:
    """Tests for the mstransfer progress adapter."""

    def test_file_lifecycle(self):
        progress = MagicMock()
        progress.add_task.return_value = "task-id-1"
        adapter = _RichBatchProgress(progress)

        adapter.on_file_start("a.raw", 1000)
        progress.add_task.assert_called_once_with("a.raw", total=1000)

        adapter.on_file_progress("a.raw", 250)
        progress.update.assert_called_once_with("task-id-1", advance=250)

        # on_file_complete is a no-op but must not raise.
        adapter.on_file_complete("a.raw")

    def test_progress_update_for_unknown_file_is_noop(self):
        progress = MagicMock()
        adapter = _RichBatchProgress(progress)
        adapter.on_file_progress("unknown.raw", 100)
        progress.update.assert_not_called()

    def test_error_sets_red_description(self):
        progress = MagicMock()
        progress.add_task.return_value = "task-id-1"
        adapter = _RichBatchProgress(progress)

        adapter.on_file_start("a.raw", 500)
        adapter.on_file_error("a.raw", RuntimeError("network"))
        progress.update.assert_called_with(
            "task-id-1", description="[red]a.raw (error)"
        )

    def test_error_for_unknown_file_is_noop(self):
        progress = MagicMock()
        adapter = _RichBatchProgress(progress)
        adapter.on_file_error("nope.raw", RuntimeError("x"))
        progress.update.assert_not_called()


class TestNullContext:
    """Tests for the tiny Python 3.10 compat context manager."""

    def test_enter_returns_self(self):
        ctx = _NullContext()
        assert ctx.__enter__() is ctx

    def test_works_as_context_manager(self):
        with _NullContext() as ctx:
            assert isinstance(ctx, _NullContext)


def _repo_response(dataset_id="ds-xyz"):
    return RepoDatasetResponse(
        dataset_id=dataset_id,
        dataset_name="Repo Dataset",
        source=RepoSource.PRIDE,
        accession="PXD000001",
        total_files=1,
        jobs=[
            RepoImportJob(
                status=RepoImportStatus.COMPLETE,
                source=RepoSource.PRIDE,
                file_name="a.raw",
                job_id="j0",
                dataset_id=dataset_id,
            )
        ],
    )


class TestParseRepoSpec:
    """Tests for the repo-spec regex parser."""

    def test_pride_accession(self):
        assert _parse_repo_spec("pride/PXD075509") == (
            RepoSource.PRIDE,
            "PXD075509",
            None,
        )

    def test_massive_accession_with_files(self):
        assert _parse_repo_spec("massive/MSV000101460[a.raw, b.raw]") == (
            RepoSource.MASSIVE,
            "MSV000101460",
            ["a.raw", "b.raw"],
        )

    def test_uuid_returns_none(self):
        assert _parse_repo_spec("550e8400-e29b-41d4-a716-446655440000") is None

    def test_unknown_source_returns_none(self):
        assert _parse_repo_spec("unknown-source/ABC123") is None


class TestDownloadRepoDataset:
    """Tests for download_repo_dataset (repo import → Dataset, no torch)."""

    @patch("msdatasets.download.download_dataset")
    @patch("msdatasets.download.trigger_repo_import", new_callable=AsyncMock)
    def test_triggers_import_and_downloads(self, mock_trigger, mock_download, tmp_path):
        mock_trigger.return_value = _repo_response("ds-xyz")
        expected = Dataset(
            dataset_id="ds-xyz",
            dataset_name="Repo",
            cache_dir=tmp_path,
            files=[tmp_path / "a.raw"],
        )
        mock_download.return_value = expected

        result = download_repo_dataset(
            "pride",
            "PXD000001",
            filenames=["a.raw"],
            show_progress=False,
        )

        mock_trigger.assert_called_once()
        kwargs = mock_trigger.call_args.kwargs
        assert kwargs["filenames"] == ["a.raw"]
        # No on_status in the no-progress branch.
        assert "on_status" not in kwargs

        mock_download.assert_called_once_with(
            "ds-xyz",
            force_download=False,
            show_progress=False,
            max_workers=4,
            filenames=["a.raw"],
            store_as="mszx",
            output_dir=None,
        )
        assert result is expected

    @patch("msdatasets.download.download_dataset")
    @patch("msdatasets.download.trigger_repo_import", new_callable=AsyncMock)
    def test_forwards_store_as(self, mock_trigger, mock_download, tmp_path):
        mock_trigger.return_value = _repo_response("ds-xyz")
        mock_download.return_value = Dataset(
            dataset_id="ds-xyz",
            dataset_name=None,
            cache_dir=tmp_path,
            files=[],
        )

        download_repo_dataset(
            "pride",
            "PXD000001",
            show_progress=False,
            store_as="mzml",
        )

        assert mock_download.call_args.kwargs["store_as"] == "mzml"


class TestLoadRepoDataset:
    """Tests for load_repo_dataset (repo → MSCompressDataset pipeline)."""

    @patch("msdatasets.download._import_torch_dataset")
    @patch("msdatasets.download.download_dataset")
    @patch("msdatasets.download.trigger_repo_import", new_callable=AsyncMock)
    def test_with_progress_uses_spinner(
        self, mock_trigger, mock_download, mock_import, tmp_path
    ):
        mock_trigger.return_value = _repo_response("ds-xyz")
        mock_download.return_value = Dataset(
            dataset_id="ds-xyz",
            dataset_name="Repo Dataset",
            cache_dir=tmp_path,
            files=[tmp_path / "a.raw"],
        )
        mock_import.return_value = MagicMock(return_value="wrapped")

        result = load_repo_dataset(
            "pride",
            "PXD000001",
            filenames=["a.raw"],
            show_progress=True,
        )

        mock_trigger.assert_called_once()
        kwargs = mock_trigger.call_args.kwargs
        assert kwargs["filenames"] == ["a.raw"]
        assert kwargs["on_progress"] is not None

        # Exercise the on_progress callback across the lifecycle (covers
        # task creation, description updates, and the 100% pin).
        on_progress = kwargs["on_progress"]
        from msdatasets.models import RepoImportEvent

        on_progress(
            RepoImportEvent(
                status=RepoImportStatus.PENDING,
                job_id="job-0",
                file_name="a.raw",
            )
        )
        on_progress(
            RepoImportEvent(
                status=RepoImportStatus.DOWNLOADING,
                job_id="job-0",
                file_name="a.raw",
                bytes_downloaded=500,
                total_bytes=1000,
                speed_bps=100.0,
            )
        )
        on_progress(
            RepoImportEvent(
                status=RepoImportStatus.COMPLETE,
                job_id="job-0",
                file_name="a.raw",
            )
        )
        # Also a FAILED status to hit the fallback label path.
        on_progress(
            RepoImportEvent(
                status=RepoImportStatus.FAILED,
                job_id="job-0",
                file_name="a.raw",
            )
        )

        mock_download.assert_called_once_with(
            "ds-xyz",
            force_download=False,
            show_progress=True,
            max_workers=4,
            filenames=["a.raw"],
            store_as="mszx",
            output_dir=None,
        )
        assert result == "wrapped"

    @patch("msdatasets.download._import_torch_dataset")
    @patch("msdatasets.download.download_dataset")
    @patch("msdatasets.download.trigger_repo_import", new_callable=AsyncMock)
    def test_without_progress_skips_spinner(
        self, mock_trigger, mock_download, mock_import, tmp_path
    ):
        mock_trigger.return_value = _repo_response()
        mock_download.return_value = Dataset(
            dataset_id="ds-xyz",
            dataset_name=None,
            cache_dir=tmp_path,
            files=[],
        )
        mock_import.return_value = MagicMock(return_value="wrapped")

        load_repo_dataset(RepoSource.PRIDE, "PXD000001", show_progress=False)

        kwargs = mock_trigger.call_args.kwargs
        # No on_status callback in the no-progress branch.
        assert "on_status" not in kwargs


class TestLoadDatasetRouting:
    """Tests for the load_dataset regex-based dispatcher."""

    @patch("msdatasets.download.load_repo_dataset")
    def test_pride_accession_dispatches_to_repo(self, mock_repo):
        mock_repo.return_value = "wrapped"
        load_dataset("pride/PXD075509")
        mock_repo.assert_called_once()
        kwargs = mock_repo.call_args.kwargs
        args = mock_repo.call_args.args
        assert args[0] == RepoSource.PRIDE
        assert args[1] == "PXD075509"
        assert kwargs["filenames"] is None

    @patch("msdatasets.download.load_repo_dataset")
    def test_massive_accession_with_filenames(self, mock_repo):
        mock_repo.return_value = "wrapped"
        load_dataset("massive/MSV000078787[a.raw, b.mzML, c.raw]")
        args = mock_repo.call_args.args
        kwargs = mock_repo.call_args.kwargs
        assert args[0] == RepoSource.MASSIVE
        assert args[1] == "MSV000078787"
        assert kwargs["filenames"] == ["a.raw", "b.mzML", "c.raw"]

    @patch("msdatasets.download._import_torch_dataset")
    @patch("msdatasets.download.download_dataset")
    def test_uuid_falls_through_to_download_dataset(
        self, mock_download, mock_import, tmp_path
    ):
        mock_download.return_value = Dataset(
            dataset_id="uuid-1",
            dataset_name=None,
            cache_dir=tmp_path,
            files=[],
        )
        cls = MagicMock(return_value="wrapped")
        mock_import.return_value = cls
        result = load_dataset("550e8400-e29b-41d4-a716-446655440000")
        mock_download.assert_called_once()
        cls.assert_called_once_with(tmp_path, load_annotations=None)
        assert result == "wrapped"

    @patch("msdatasets.download._import_torch_dataset")
    @patch("msdatasets.download.download_dataset")
    def test_non_matching_specifier_falls_through(
        self, mock_download, mock_import, tmp_path
    ):
        # Looks like a repo spec but source is unsupported → falls through
        # as a plain dataset_id.
        mock_download.return_value = Dataset(
            dataset_id="foo",
            dataset_name=None,
            cache_dir=tmp_path,
            files=[],
        )
        mock_import.return_value = MagicMock(return_value="wrapped")
        load_dataset("unknown-source/ABC123")
        mock_download.assert_called_once()

    @patch("msdatasets.hf.load_hf_dataset")
    def test_hf_spec_dispatches_to_hf(self, mock_load_hf):
        mock_load_hf.return_value = "wrapped"
        result = load_dataset("hf/alice/bench[a.mszx,b.mszx]")
        mock_load_hf.assert_called_once_with(
            "alice/bench",
            filenames=["a.mszx", "b.mszx"],
            force_download=False,
            show_progress=True,
            load_annotations=None,
        )
        assert result == "wrapped"

    @patch("msdatasets.hf.load_hf_dataset")
    def test_hf_spec_forwards_load_annotations(self, mock_load_hf):
        mock_load_hf.return_value = "wrapped"
        sentinel = ["pseudo-AnnotationFormat"]
        load_dataset("hf/alice/bench", load_annotations=sentinel)
        assert mock_load_hf.call_args.kwargs["load_annotations"] is sentinel
