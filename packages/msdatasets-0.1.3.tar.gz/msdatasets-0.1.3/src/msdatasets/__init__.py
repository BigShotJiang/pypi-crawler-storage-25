"""A unified dataset framework for mass spectrometry."""

__version__ = "0.1.2"

from msdatasets.download import (
    download_dataset,
    download_repo_dataset,
    load_dataset,
    load_repo_dataset,
)
from msdatasets.exceptions import DatasetNotFoundError, DownloadError, ExtractionError
from msdatasets.hf import download_hf_dataset, load_hf_dataset
from msdatasets.models import Dataset, RepoSource

__all__ = [
    "Dataset",
    "DatasetNotFoundError",
    "DownloadError",
    "ExtractionError",
    "RepoSource",
    "download_dataset",
    "download_hf_dataset",
    "download_repo_dataset",
    "load_dataset",
    "load_hf_dataset",
    "load_repo_dataset",
    "__version__",
]
