"""Core download logic for fetching datasets from the server."""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from mscompress.datasets.torch import MSCompressDataset
    from mscompress.types import AnnotationFormat

import httpx
from mstransfer.client import download_batch, download_file
from mstransfer.client.downloader import DownloadRequest
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TaskID,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from msdatasets.client import (
    ensure_all_extracted,
    ensure_extracted,
    fetch_manifest,
    trigger_repo_import,
)
from msdatasets.config import get_api_url, get_dataset_dir
from msdatasets.models import (
    Dataset,
    DatasetPart,
    Manifest,
    RepoImportEvent,
    RepoImportStatus,
    RepoSource,
)

StoreFormat = Literal["mszx", "msz", "mzml"]

_STORE_FORMAT_EXT: dict[StoreFormat, str] = {
    "mszx": ".mszx",
    "msz": ".msz",
    "mzml": ".mzML",
}


def _target_filename(src_filename: str, store_as: StoreFormat) -> str:
    """Return the on-disk filename for *src_filename* after format conversion."""
    return str(Path(src_filename).with_suffix(_STORE_FORMAT_EXT[store_as]))


_STATUS_LABELS: dict[RepoImportStatus, str] = {
    RepoImportStatus.PENDING: "Pending",
    RepoImportStatus.DOWNLOADING: "Downloading",
    RepoImportStatus.CONVERTING: "Converting to MSZX",
    RepoImportStatus.INDEXING: "Indexing",
    RepoImportStatus.COMPLETE: "Complete",
}

log = logging.getLogger("msdatasets")

_REPO_PATTERN = re.compile(
    r"^(?P<source>pride|massive)/(?P<accession>[^\[\]/]+)(?:\[(?P<files>[^\]]+)\])?$"
)

_HF_PATTERN = re.compile(
    r"^hf/(?P<owner>[^/\[\]]+)/(?P<repo>[^/\[\]]+)(?:\[(?P<files>[^\]]+)\])?$"
)


def _parse_repo_spec(
    dataset_id: str,
) -> tuple[RepoSource, str, list[str] | None] | None:
    """Parse a ``{source}/{accession}[files]`` spec.

    Returns ``(source, accession, filenames)`` if *dataset_id* matches the
    repository pattern, otherwise ``None``.
    """
    match = _REPO_PATTERN.match(dataset_id)
    if not match:
        return None
    source = RepoSource(match.group("source"))
    accession = match.group("accession")
    files_group = match.group("files")
    filenames = [f.strip() for f in files_group.split(",")] if files_group else None
    return source, accession, filenames


def _parse_hf_spec(dataset_id: str) -> tuple[str, list[str] | None] | None:
    """Parse an ``hf/<owner>/<repo>[files]`` spec.

    Returns ``(repo_id, filenames)`` if *dataset_id* matches the HF pattern,
    otherwise ``None``.
    """
    match = _HF_PATTERN.match(dataset_id)
    if not match:
        return None
    repo_id = f"{match.group('owner')}/{match.group('repo')}"
    files_group = match.group("files")
    filenames = [f.strip() for f in files_group.split(",")] if files_group else None
    return repo_id, filenames


def _import_torch_dataset() -> type[MSCompressDataset]:
    """Import MSCompressDataset, raising a helpful error if torch is missing."""
    try:
        from mscompress.datasets.torch import MSCompressDataset
    except ImportError:
        raise ImportError(
            "Loading a dataset as a PyTorch Dataset requires the 'torch' extra. "
            "Install it with: pip install msdatasets[torch]"
        ) from None
    return MSCompressDataset


def download_part(
    part: DatasetPart,
    dest_dir: Path,
    *,
    store_as: StoreFormat = "mszx",
    skip_existing: bool = False,
    force: bool = False,
) -> Path:
    """Download a single dataset part to *dest_dir* via mstransfer.

    If the server needs to extract the file first (202 Accepted), polls
    the task endpoint until the file is ready, then downloads via the
    mstransfer endpoint.  When *store_as* is ``"msz"`` or ``"mzml"``,
    the downloaded ``.mszx`` is converted client-side by mstransfer.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    download_url = f"{get_api_url()}{part.download_url}"
    dest = dest_dir / part.filename
    log.debug("Downloading %s via %s", part.filename, download_url)

    async def _extract() -> None:
        timeout = httpx.Timeout(10.0, read=None)
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            await ensure_extracted(client, part)

    asyncio.run(_extract())

    result: Path = download_file(
        download_url,
        dest,
        store_as=store_as,
        skip_existing=skip_existing,
        force=force,
    )
    return result


class _RichImportProgress:
    """Adapts a rich `Progress` bar to the repo-import ``on_progress``
    callback protocol.

    Every event (not just DOWNLOADING ticks) flows through one entry
    point so tasks are created lazily, keyed consistently by
    ``event.job_id``, and their description tracks the current status.
    """

    def __init__(self, progress: Progress) -> None:
        self._progress = progress
        self._tasks: dict[str, TaskID] = {}

    @staticmethod
    def _describe(file_name: str, status: RepoImportStatus) -> str:
        label = _STATUS_LABELS.get(status, status.value)
        return f"{file_name}: {label}"

    def on_progress(self, event: RepoImportEvent) -> None:
        file_name = event.file_name or event.job_id
        description = self._describe(file_name, event.status)

        task_id = self._tasks.get(event.job_id)
        if task_id is None:
            task_id = self._progress.add_task(
                description,
                total=event.total_bytes,
                start=event.status == RepoImportStatus.DOWNLOADING,
            )
            self._tasks[event.job_id] = task_id

        task = self._progress.tasks[task_id]
        update_kwargs: dict[str, Any] = {"description": description}

        # Content-Length may only show up on later ticks (chunked → known
        # total); patch the total in when it appears.
        if event.total_bytes is not None and task.total != event.total_bytes:
            update_kwargs["total"] = event.total_bytes

        if event.status == RepoImportStatus.DOWNLOADING:
            if not task.started:
                self._progress.start_task(task_id)
            if event.bytes_downloaded is not None:
                update_kwargs["completed"] = event.bytes_downloaded
        elif event.status == RepoImportStatus.COMPLETE and task.total is not None:
            # Pin at 100% when we know the total.
            update_kwargs["completed"] = task.total

        self._progress.update(task_id, **update_kwargs)


class _RichBatchProgress:
    """Adapts a rich `Progress` bar to mstransfer's
    `BatchDownloadProgress` callback protocol."""

    def __init__(self, progress: Progress) -> None:
        self._progress = progress
        self._tasks: dict[str, TaskID] = {}

    def on_file_start(self, filename: str, total_bytes: int | None) -> None:
        self._tasks[filename] = self._progress.add_task(filename, total=total_bytes)

    def on_file_progress(self, filename: str, bytes_delta: int) -> None:
        if filename in self._tasks:
            self._progress.update(self._tasks[filename], advance=bytes_delta)

    def on_file_complete(self, filename: str) -> None:
        pass

    def on_file_error(self, filename: str, error: Exception) -> None:
        if filename in self._tasks:
            self._progress.update(
                self._tasks[filename],
                description=f"[red]{filename} (error)",
            )


def download_dataset(
    dataset_id: str,
    *,
    force_download: bool = False,
    show_progress: bool = True,
    max_workers: int = 4,
    filenames: list[str] | None = None,
    store_as: StoreFormat = "mszx",
    output_dir: Path | None = None,
) -> Dataset:
    """Download a dataset and return a `Dataset` pointing to local files.

    Parameters
    ----------
    dataset_id:
        Server-side dataset identifier (UUID).
    force_download:
        Re-download parts even if they already exist on disk.
    show_progress:
        Show a ``rich`` progress bar during download.
    max_workers:
        Maximum number of parallel downloads.
    filenames:
        Optional list of filenames to include. When provided, the server
        returns a manifest containing only matching parts.
    store_as:
        On-disk format for downloaded parts.  Defaults to ``"mszx"`` (the
        raw archive shipped by the server).  Set to ``"msz"`` to extract
        the inner MSZ, or ``"mzml"`` to decompress fully to mzML.
        Conversion is handled by mstransfer.
    output_dir:
        Optional destination directory.  When set, files are written
        directly here (no ``{dataset_id}`` subdir) and the cache root
        from `get_dataset_dir` is bypassed.  Useful for one-off
        downloads outside the shared cache.
    """
    log.info("Downloading dataset %s", dataset_id)
    dataset_dir = output_dir if output_dir is not None else get_dataset_dir(dataset_id)
    dataset_dir.mkdir(parents=True, exist_ok=True)
    log.debug("Dataset directory: %s", dataset_dir)

    async def _fetch_and_extract() -> tuple[Manifest, list[Path], list[DatasetPart]]:
        timeout = httpx.Timeout(10.0, read=None)
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            manifest_ = await fetch_manifest(
                dataset_id, filenames=filenames, client=client
            )

            # Persist manifest locally for offline inspection
            manifest_path = dataset_dir / "manifest.json"
            manifest_path.write_text(manifest_.model_dump_json(indent=2))

            cached: list[Path] = []
            to_download: list[DatasetPart] = []

            # Skip files that are already on disk, unless *force_download* is True.
            # Cache is keyed by the target on-disk filename, so switching
            # --store-as triggers a re-download rather than using a stale
            # artifact in a different format.
            for part in manifest_.parts:
                dest = dataset_dir / _target_filename(part.filename, store_as)
                if dest.exists() and not force_download:
                    log.debug("Cached, skipping: %s", dest.name)
                    cached.append(dest)
                else:
                    to_download.append(part)

            # For files that need to be downloaded,
            # ensure they are extracted and ready on the server.
            if to_download:
                log.info(
                    "Downloading %d/%d part(s)",
                    len(to_download),
                    manifest_.total_parts,
                )
                await ensure_all_extracted(client, to_download)
            else:
                log.info("All %d part(s) already cached", manifest_.total_parts)

            return manifest_, cached, to_download

    manifest, files, parts_to_download = asyncio.run(_fetch_and_extract())

    # Download all ready files via mstransfer.
    if parts_to_download:
        base_url = get_api_url()
        requests = [
            DownloadRequest(
                url=f"{base_url}{part.download_url}",
                dest=dataset_dir / part.filename,
            )
            for part in parts_to_download
        ]

        progress_bar: Progress | None = None
        batch_progress: _RichBatchProgress | None = None
        if show_progress:
            progress_bar = Progress(
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
            )
            batch_progress = _RichBatchProgress(progress_bar)

        ctx = progress_bar if progress_bar is not None else _NullContext()
        with ctx:
            downloaded = download_batch(
                requests,
                store_as=store_as,
                parallel=max_workers,
                progress=batch_progress,
            )
            files.extend(downloaded)

    # Ensure files are ordered by part_index.  `files` entries use the
    # target extension (set by mstransfer), so key the lookup by that name.
    file_map = {p.name: p for p in files}
    ordered_files = [
        file_map[target]
        for part in manifest.parts
        if (target := _target_filename(part.filename, store_as)) in file_map
    ]

    ds = Dataset(
        dataset_id=manifest.dataset_id,
        dataset_name=manifest.dataset_name,
        cache_dir=dataset_dir,
        files=ordered_files,
    )
    log.info("Dataset ready: %d file(s) in %s", len(ds), dataset_dir)
    return ds


def download_repo_dataset(
    source: RepoSource | str,
    accession: str,
    *,
    filenames: list[str] | None = None,
    force_download: bool = False,
    show_progress: bool = True,
    max_workers: int = 4,
    store_as: StoreFormat = "mszx",
    output_dir: Path | None = None,
) -> Dataset:
    """Trigger a repository import and download the resulting dataset.

    Posts to ``/repositories/{source}/projects/{accession}/dataset`` to create
    a dataset from a PRIDE or MassIVE project.  The endpoint is
    idempotent—calling it for an already-imported project returns the
    existing dataset and job statuses.

    Parameters
    ----------
    source:
        Repository source (``"pride"`` or ``"massive"``).
    accession:
        Project accession (e.g. ``PXD075509`` for PRIDE, ``MSV000078787`` for
        MassIVE).
    filenames:
        Optional list of specific filenames to import. When *None*, all
        files in the project are imported.
    force_download:
        Re-download parts even if they already exist on disk.
    show_progress:
        Show a ``rich`` progress bar during download.
    max_workers:
        Maximum number of parallel downloads.
    store_as:
        On-disk format for downloaded parts.  See `download_dataset`.
    output_dir:
        Optional destination directory.  See `download_dataset`.
    """
    source = RepoSource(source)
    console = Console(stderr=True)

    async def _import() -> str:
        timeout = httpx.Timeout(10.0, read=None)
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            if show_progress:
                progress = Progress(
                    TextColumn("[bold blue]{task.description}"),
                    BarColumn(),
                    DownloadColumn(),
                    TransferSpeedColumn(),
                    TimeRemainingColumn(),
                    console=console,
                    transient=False,
                )
                import_progress = _RichImportProgress(progress)
                with progress:
                    result = await trigger_repo_import(
                        source,
                        accession,
                        filenames=filenames,
                        client=client,
                        on_progress=import_progress.on_progress,
                    )
            else:
                result = await trigger_repo_import(
                    source, accession, filenames=filenames, client=client
                )
            return result.dataset_id

    dataset_id = asyncio.run(_import())

    return download_dataset(
        dataset_id,
        force_download=force_download,
        show_progress=show_progress,
        max_workers=max_workers,
        filenames=filenames,
        store_as=store_as,
        output_dir=output_dir,
    )


def load_repo_dataset(
    source: RepoSource | str,
    accession: str,
    *,
    filenames: list[str] | None = None,
    force_download: bool = False,
    show_progress: bool = True,
    max_workers: int = 4,
    load_annotations: list[AnnotationFormat] | None = None,
) -> MSCompressDataset:
    """Trigger a repository import and return an `MSCompressDataset` once ready.

    Convenience wrapper around `download_repo_dataset` that loads the
    downloaded files into an `mscompress.datasets.torch.MSCompressDataset`.
    Requires PyTorch to be installed.

    *load_annotations* is forwarded to ``MSCompressDataset``.  When set, the
    dataset's ``__getitem__`` returns ``(mz, intensity, annotations_dict)``
    instead of just ``(mz, intensity)``.
    """
    dataset_cls = _import_torch_dataset()
    ds = download_repo_dataset(
        source,
        accession,
        filenames=filenames,
        force_download=force_download,
        show_progress=show_progress,
        max_workers=max_workers,
    )
    return dataset_cls(ds.cache_dir, load_annotations=load_annotations)


def load_dataset(
    dataset_id: str,
    *,
    force_download: bool = False,
    show_progress: bool = True,
    max_workers: int = 4,
    load_annotations: list[AnnotationFormat] | None = None,
) -> MSCompressDataset:
    """Download a dataset and return an `MSCompressDataset`.

    Convenience wrapper around `download_dataset` that loads the
    downloaded files into an `mscompress.datasets.torch.MSCompressDataset`
    ready for iteration.  Requires PyTorch to be installed.

    If *dataset_id* matches the pattern ``{source}/<accession>`` (e.g.
    ``pride/PXD075509`` or ``massive/MSV000078787``), the repository import
    flow is used instead.  A specific filename subset may be specified in
    square brackets: ``pride/PXD000001[file1.raw,file2.mzML]``.

    If *dataset_id* matches ``hf/<owner>/<repo>`` (e.g.
    ``hf/myorg/proteomics-bench``), files are pulled directly from the
    HuggingFace dataset repo.  Requires the ``hf`` extra.

    Parameters
    ----------
    dataset_id:
        Server-side dataset identifier, or a repository specifier like
        ``pride/PXD075509``, ``massive/MSV000078787``, or
        ``hf/<owner>/<repo>[file1.mszx,file2.mszx]``.
    force_download:
        Re-download parts even if they already exist on disk.
    show_progress:
        Show a ``rich`` progress bar during download.
    max_workers:
        Maximum number of parallel downloads.
    load_annotations:
        Annotation formats to load alongside spectra (forwarded to
        ``mscompress.datasets.torch.MSCompressDataset``).  When set, the
        returned dataset's ``__getitem__`` yields
        ``(mz, intensity, annotations_dict)`` instead of ``(mz, intensity)``.
    """
    hf_spec = _parse_hf_spec(dataset_id)
    if hf_spec is not None:
        from msdatasets.hf import load_hf_dataset

        repo_id, filenames = hf_spec
        return load_hf_dataset(
            repo_id,
            filenames=filenames,
            force_download=force_download,
            show_progress=show_progress,
            load_annotations=load_annotations,
        )

    repo_spec = _parse_repo_spec(dataset_id)
    if repo_spec is not None:
        source, accession, filenames = repo_spec
        return load_repo_dataset(
            source,
            accession,
            filenames=filenames,
            force_download=force_download,
            show_progress=show_progress,
            max_workers=max_workers,
            load_annotations=load_annotations,
        )

    dataset_cls = _import_torch_dataset()

    ds = download_dataset(
        dataset_id,
        force_download=force_download,
        show_progress=show_progress,
        max_workers=max_workers,
    )
    return dataset_cls(ds.cache_dir, load_annotations=load_annotations)


class _NullContext:
    """Minimal context manager for Python 3.10 compatibility."""

    def __enter__(self) -> _NullContext:
        return self

    def __exit__(self, *exc: object) -> None:
        pass
