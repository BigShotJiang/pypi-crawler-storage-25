import httpx
import pytest

from cognethics import AsyncClient


@pytest.fixture
def anyio_backend():
    return "asyncio"


def test_async_client_constructs_cleanly():
    c = AsyncClient(
        api_key="mcp_testkey",
        base_url="https://example.com",
        org="my-org",
    )
    assert c.api_key == "mcp_testkey"
    assert c.base_url == "https://example.com"
    assert c.org == "my-org"


@pytest.mark.anyio
async def test_async_client_is_async_context_manager():
    async with AsyncClient(
        api_key="mcp_testkey",
        base_url="https://example.com",
        org="my-org",
    ) as c:
        assert isinstance(c, AsyncClient)


@pytest.mark.anyio
async def test_async_call_sends_bearer_and_returns_data(respx_mock):
    respx_mock.post("/api/mcp/tools/test_tool/").mock(
        return_value=httpx.Response(
            200,
            json={"success": True, "data": {"foo": "bar"}, "meta": {}},
        )
    )
    async with AsyncClient(
        api_key="mcp_testkey",
        base_url="http://localhost:8000",
        org="my-org",
    ) as c:
        out = await c.call("test_tool", foo="bar")

    assert out["data"] == {"foo": "bar"}
    sent = respx_mock.calls.last.request
    assert sent.headers["Authorization"] == "Bearer mcp_testkey"
    assert sent.headers["X-Organization-Context"] == "my-org"
