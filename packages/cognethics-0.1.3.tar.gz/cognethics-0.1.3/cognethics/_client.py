"""Cognethics SDK HTTP client transport."""
from __future__ import annotations

import inspect
import logging
import re
import time
from types import ModuleType
from typing import Any, Callable, Iterator, Optional

import httpx

from cognethics._exceptions import (
    AuthenticationError,
    Error,
    RateLimit,
    ServerError,
    raise_for_response,
)

logger = logging.getLogger("cognethics")

DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 3
DEFAULT_RETRY_BASE = 0.5
RETRYABLE_STATUS = {429, 502, 503, 504}

_CAMEL_TO_SNAKE_RE = re.compile(r"(?<!^)(?=[A-Z])")


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case (e.g. 'WorkOrderClient' -> 'work_order')."""
    if name.endswith("Client"):
        name = name[:-6]
    return _CAMEL_TO_SNAKE_RE.sub("_", name).lower()


class _Registry:
    """Lightweight namespace built dynamically from generated module tree."""
    def __init__(self, _label: str) -> None:
        self._label = _label

    def __repr__(self) -> str:
        attrs = sorted(k for k in vars(self) if not k.startswith("_"))
        preview = attrs[:5]
        more = "..." if len(attrs) > 5 else ""
        return f"<{self._label} attrs={preview}{more}>"


class _EmptyRegistry(_Registry):
    def __getattr__(self, item: str) -> Any:
        if item.startswith("_"):
            raise AttributeError(item)
        raise Error(
            f"No handlers generated for mega-tool '{self._label}'. "
            "Run `python manage.py prism_codegen` to (re)generate."
        )


def _build_app_registry(client: "Client", mt_module: ModuleType) -> _Registry:
    """Walk mt_module's submodules (apps) and build a Registry tree."""
    mt_name = mt_module.__name__.rsplit(".", 1)[-1]
    app_registry = _Registry(f"{mt_name}.AppRegistry")
    app_names = getattr(mt_module, "__all__", None) or [
        name for name in dir(mt_module)
        if not name.startswith("_") and isinstance(getattr(mt_module, name), ModuleType)
    ]
    for app_name in app_names:
        app_module = getattr(mt_module, app_name, None)
        if not isinstance(app_module, ModuleType):
            continue
        entity_registry = _Registry(f"{mt_name}.{app_name}.EntityRegistry")
        bound_any = False
        for cls_name, cls in inspect.getmembers(app_module, inspect.isclass):
            if cls.__module__ != app_module.__name__:
                continue
            if not cls_name.endswith("Client"):
                continue
            entity_attr = _camel_to_snake(cls_name)
            try:
                instance = cls(client)
            except Exception:
                continue
            setattr(entity_registry, entity_attr, instance)
            bound_any = True
        if not bound_any:
            # No per-entity classes — bind methods at app level (e.g. report_query)
            entity_registry = _build_app_level_registry(client, app_module, mt_name, app_name)
        setattr(app_registry, app_name, entity_registry)
    return app_registry


def _build_app_level_registry(client: "Client", app_module: ModuleType, mt_name: str, app_name: str) -> Any:
    """For mega-tools without per-entity nesting (e.g. report_query), expose ops directly under app."""
    registry = _Registry(f"{mt_name}.{app_name}")
    for member_name, member in inspect.getmembers(app_module):
        if callable(member) and not member_name.startswith("_") and not inspect.isclass(member):
            setattr(registry, member_name, member)
    return registry


class Client:
    """Cognethics platform client.

    Args:
        api_key: API key — `ck_...` (preferred, works for both dev API and MCP)
            or legacy `mcp_...` (MCP-only).
        base_url: e.g. `https://gtm.cognethics.com` or `http://localhost:8000`.
        org: Organization UUID (sent as `X-Organization-Context` header).
        timeout: Per-request timeout in seconds (default 30).
        max_retries: Max retries on 429/5xx (default 3).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://gtm.cognethics.com",
        org: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_RETRIES,
        _http: Optional[httpx.Client] = None,
    ):
        if not api_key:
            raise AuthenticationError("api_key is required")
        if not (api_key.startswith("mcp_") or api_key.startswith("ck_")):
            logger.warning(
                "api_key does not start with 'mcp_' or 'ck_' - auth will likely fail"
            )
        self.api_key = api_key
        self.key_prefix = "ck_" if api_key.startswith("ck_") else "mcp_"
        self.base_url = base_url.rstrip("/")
        self.org = org
        self.timeout = timeout
        self.max_retries = max_retries
        self._http = _http or httpx.Client(timeout=timeout)
        self._generated_bound = False
        self._dev: Optional[Any] = None

    def _headers(self, org_override: Optional[str] = None) -> dict:
        h = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "cognethics-python/0.1.2",
        }
        org = org_override or self.org
        if org:
            h["X-Organization-Context"] = str(org)
        return h

    def call(self, tool_name: str, *, _org: Optional[str] = None, **params) -> dict:
        """Call any MCP tool by name.

        Args:
            tool_name: e.g. `prism_entity_crud`, `prism_introspect`, or any legacy tool name.
            _org: per-call org override (UUID).
            **params: tool-specific parameters.

        Returns:
            The PrismResponse dict (success=True branch). On errors, raises an Error subclass.
        """
        url = f"{self.base_url}/api/mcp/tools/{tool_name}/"
        body = {k: v for k, v in params.items() if v is not None}
        attempt = 0
        while True:
            try:
                resp = self._http.post(url, json=body, headers=self._headers(_org))
            except httpx.RequestError as e:
                if attempt >= self.max_retries:
                    raise Error(f"Network error: {e}") from e
                self._sleep_backoff(attempt)
                attempt += 1
                continue

            if resp.status_code == 401:
                raise AuthenticationError("API key invalid or expired", code="UNAUTHORIZED")
            if resp.status_code == 404:
                try:
                    body = resp.json()
                except Exception:
                    body = {}
                if body.get("error") in ("tool_not_found", "TOOL_NOT_FOUND") or "tool_not_found" in resp.text:
                    raise Error(f"Tool not found: {tool_name}", code="TOOL_NOT_FOUND")
            if resp.status_code in RETRYABLE_STATUS and attempt < self.max_retries:
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "0") or 0)
                    logger.warning(
                        f"429 rate limited, retry_after={retry_after}, "
                        f"attempt {attempt + 1}/{self.max_retries}"
                    )
                    time.sleep(max(retry_after, self._backoff_seconds(attempt)))
                else:
                    self._sleep_backoff(attempt)
                attempt += 1
                continue
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", "0") or 0)
                raise RateLimit(
                    "Rate limit exceeded", code="RATE_LIMIT", retry_after=retry_after
                )
            if resp.status_code >= 500:
                raise ServerError(
                    f"Server error {resp.status_code}: {resp.text[:200]}",
                    code="SERVER_ERROR",
                )

            try:
                payload = resp.json()
            except Exception as e:
                raise Error(f"Invalid JSON response: {e}") from e

            raise_for_response(payload, resp.status_code)
            return payload

    def paginate(
        self,
        method: Callable,
        *,
        page_size: int = 100,
        max_pages: int = 1000,
        **params,
    ) -> Iterator[dict]:
        """Iterate all rows across pages until has_next=False.

        Args:
            method: A bound list method (e.g. `client.entity_crud.spare_parts.work_order.list`).
            page_size: Page size for each request.
            max_pages: Safety cap (default 1000).
            **params: Forwarded to the method.

        Yields:
            Individual rows from each page's `data`.
        """
        page = 1
        for _ in range(max_pages):
            resp = method(page=page, page_size=page_size, **params)
            data = resp.get("data") or []
            if isinstance(data, list):
                yield from data
            else:
                yield data
            pagination = resp.get("pagination") or {}
            if not pagination.get("has_next"):
                break
            page += 1

    def _backoff_seconds(self, attempt: int) -> float:
        return DEFAULT_RETRY_BASE * (2 ** attempt)

    def _sleep_backoff(self, attempt: int) -> None:
        time.sleep(self._backoff_seconds(attempt))

    # === Lazy-loaded generated tree ===
    @property
    def entity_crud(self):
        self._bind_generated()
        return self._entity_crud

    @property
    def workflow_action(self):
        self._bind_generated()
        return self._workflow_action

    @property
    def report_query(self):
        self._bind_generated()
        return self._report_query

    @property
    def agent_command(self):
        self._bind_generated()
        return self._agent_command

    @property
    def integration_call(self):
        self._bind_generated()
        return self._integration_call

    @property
    def smart_action(self):
        self._bind_generated()
        return self._smart_action

    @property
    def document_op(self):
        self._bind_generated()
        return self._document_op

    @property
    def notification_send(self):
        self._bind_generated()
        return self._notification_send

    @property
    def config_manage(self):
        self._bind_generated()
        return self._config_manage

    @property
    def dev(self):
        """Developer Sandbox API namespace (`/api/v1/dev/`, `ck_`-keyed)."""
        if self._dev is None:
            from cognethics.dev import DevClient
            self._dev = DevClient(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=self.timeout,
                _http=self._http,
            )
        return self._dev

    def _bind_generated(self) -> None:
        if self._generated_bound:
            return
        try:
            from cognethics import generated as _gen
            mega_tools = (
                "entity_crud", "workflow_action", "report_query", "agent_command",
                "integration_call", "smart_action", "document_op", "notification_send",
                "config_manage",
            )
            for mt in mega_tools:
                try:
                    mt_module = __import__(f"cognethics.generated.{mt}", fromlist=["*"])
                except ImportError:
                    setattr(self, f"_{mt}", _EmptyRegistry(mt))
                    continue
                setattr(self, f"_{mt}", _build_app_registry(self, mt_module))
        except ImportError as e:
            raise Error(
                f"Generated SDK tree not found: {e}. "
                "Run `python manage.py prism_codegen` to generate."
            ) from e
        self._generated_bound = True

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
