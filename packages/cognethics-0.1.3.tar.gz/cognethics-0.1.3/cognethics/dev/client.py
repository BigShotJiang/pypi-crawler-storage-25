"""DevClient — thin wrapper around `/api/v1/dev/{ping,me,echo}/`.

Auth: `Authorization: Bearer ck_<token>`. Errors: tolerates both DRF
`{"detail": "..."}` and Prism `{"success": false, "error": {...}}` envelopes.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from cognethics._exceptions import (
    AuthenticationError,
    Error,
    NotFound,
    PermissionDenied,
    RateLimit,
    ServerError,
    ValidationError,
    raise_for_response,
)

logger = logging.getLogger("cognethics.dev")


class DevApiError(Error):
    """Raised for 4xx/5xx responses from `/api/v1/dev/` not covered by a more specific subclass."""


def _extract_message(payload: Any, status_code: int) -> str:
    if isinstance(payload, dict):
        if "detail" in payload:
            return str(payload["detail"])
        err = payload.get("error")
        if isinstance(err, dict) and err.get("message"):
            return str(err["message"])
    return f"HTTP {status_code}"


def _raise_for_dev_response(resp: httpx.Response) -> dict:
    """Parse a dev-API response, raising the right exception on error."""
    try:
        payload = resp.json()
    except Exception:
        payload = {}

    status = resp.status_code

    if status < 400:
        if isinstance(payload, dict) and payload.get("success") is False:
            raise_for_response(payload, status)
        return payload if isinstance(payload, dict) else {"data": payload}

    if isinstance(payload, dict) and payload.get("success") is False and payload.get("error"):
        raise_for_response(payload, status)

    msg = _extract_message(payload, status)
    if status == 401:
        raise AuthenticationError(msg, code="UNAUTHORIZED")
    if status == 403:
        raise PermissionDenied(msg, code="PERMISSION_DENIED")
    if status == 404:
        raise NotFound(msg, code="NOT_FOUND")
    if status == 422 or status == 400:
        raise ValidationError(msg, code="VALIDATION_ERROR")
    if status == 429:
        retry_after = int(resp.headers.get("Retry-After", "0") or 0)
        raise RateLimit(msg, code="RATE_LIMIT", retry_after=retry_after)
    if status >= 500:
        raise ServerError(msg, code="SERVER_ERROR")
    raise DevApiError(msg, code=f"HTTP_{status}")


class DevClient:
    """Client for the Cognethics Developer Sandbox API (`/api/v1/dev/`).

    Args:
        api_key: API key starting with `ck_`. Required for `me()` / `echo()`;
            `ping()` is unauthenticated and works without one.
        base_url: Tenant base URL, e.g. `https://gtm.cognethics.com`.
        timeout: Per-request timeout in seconds.
        _http: Injected httpx.Client (for tests).
    """

    DEFAULT_TIMEOUT = 30.0

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://gtm.cognethics.com",
        timeout: float = DEFAULT_TIMEOUT,
        _http: Optional[httpx.Client] = None,
    ):
        if api_key is not None and not api_key.startswith("ck_"):
            logger.warning("api_key does not start with 'ck_' - dev API auth will likely fail")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._http = _http or httpx.Client(timeout=timeout)

    def _headers(self, *, auth: bool) -> dict:
        h = {
            "Accept": "application/json",
            "User-Agent": "cognethics-python-dev/0.1.2",
        }
        if auth:
            if not self.api_key:
                raise AuthenticationError("api_key is required for this endpoint")
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _get(self, path: str, *, auth: bool = True, params: Optional[dict] = None) -> dict:
        url = f"{self.base_url}{path}"
        try:
            resp = self._http.get(url, headers=self._headers(auth=auth), params=params)
        except httpx.RequestError as e:
            raise Error(f"Network error: {e}") from e
        return _raise_for_dev_response(resp)

    def ping(self) -> dict:
        """Liveness probe. No auth required.

        Returns:
            ``{"service": "cognethics-dev-api", "version": "v1", "status": "ok"}``
        """
        return self._get("/api/v1/dev/ping/", auth=False)

    def me(self) -> dict:
        """Verify the current `ck_` key and return its identity context.

        Returns:
            ``{"authenticated": true, "key": {...}, "user": {...}, "tenant": {...}}``
        """
        return self._get("/api/v1/dev/me/")

    def echo(self, payload: Optional[Any] = None, **query: Any) -> dict:
        """Echo back query parameters (debug helper).

        Args:
            payload: Single positional value sent as ``?payload=...`` for
                quick string echoing, e.g. ``client.dev.echo("hello")``.
            **query: Additional named query parameters.

        Returns:
            ``{"query": {...}, "note": "...", "tenant_subdomain": "..."}``
        """
        params: dict[str, Any] = {}
        if payload is not None:
            params["payload"] = payload
        params.update({k: v for k, v in query.items() if v is not None})
        return self._get("/api/v1/dev/echo/", params=params or None)

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
