"""Tests for the `cognethics.dev` namespace (`/api/v1/dev/` surface)."""
from __future__ import annotations

import httpx
import pytest
import respx

from cognethics import (
    AuthenticationError,
    Client,
    DevApiError,
    DevClient,
    NotFound,
    PermissionDenied,
)


BASE_URL = "http://localhost:8000"


@pytest.fixture
def respx_mock():
    with respx.mock(base_url=BASE_URL) as r:
        yield r


@pytest.fixture
def dev():
    return DevClient(api_key="ck_testkey", base_url=BASE_URL)


# --- ping -------------------------------------------------------------------


def test_ping_no_auth_required(respx_mock):
    route = respx_mock.get("/api/v1/dev/ping/").mock(
        return_value=httpx.Response(
            200, json={"service": "cognethics-dev-api", "version": "v1", "status": "ok"}
        )
    )
    out = DevClient(base_url=BASE_URL).ping()
    assert route.called
    assert out == {"service": "cognethics-dev-api", "version": "v1", "status": "ok"}
    assert "Authorization" not in route.calls.last.request.headers


def test_ping_does_not_send_bearer_when_key_present(respx_mock, dev):
    route = respx_mock.get("/api/v1/dev/ping/").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    dev.ping()
    assert "Authorization" not in route.calls.last.request.headers


# --- me ---------------------------------------------------------------------


def test_me_sends_bearer_header(respx_mock, dev):
    payload = {
        "authenticated": True,
        "key": {"prefix": "ck_a1b2c3d4", "name": "Sandbox key", "scopes": []},
        "user": {"id": "u-1", "email": "user@example.com"},
        "tenant": {"id": "t-1", "name": "GTM", "subdomain": "gtm"},
    }
    route = respx_mock.get("/api/v1/dev/me/").mock(
        return_value=httpx.Response(200, json=payload)
    )
    out = dev.me()
    assert out == payload
    assert route.calls.last.request.headers["Authorization"] == "Bearer ck_testkey"


def test_me_401_drf_envelope_raises_authentication_error(respx_mock, dev):
    respx_mock.get("/api/v1/dev/me/").mock(
        return_value=httpx.Response(401, json={"detail": "Invalid API key"})
    )
    with pytest.raises(AuthenticationError) as exc:
        dev.me()
    assert "Invalid API key" in str(exc.value)


def test_me_403_drf_envelope_raises_permission_denied(respx_mock, dev):
    respx_mock.get("/api/v1/dev/me/").mock(
        return_value=httpx.Response(
            403, json={"detail": "Authentication credentials were not provided."}
        )
    )
    with pytest.raises(PermissionDenied) as exc:
        dev.me()
    assert "credentials" in str(exc.value)


def test_me_without_api_key_raises_locally():
    # Should NOT make a network request — fail fast before sending an unauth'd `me` call.
    with pytest.raises(AuthenticationError):
        DevClient(base_url=BASE_URL).me()


# --- echo -------------------------------------------------------------------


def test_echo_sends_payload_as_query_param(respx_mock, dev):
    route = respx_mock.get("/api/v1/dev/echo/").mock(
        return_value=httpx.Response(
            200,
            json={
                "query": {"payload": ["hello"]},
                "note": "authenticated via DeveloperApiKey",
                "tenant_subdomain": "gtm",
            },
        )
    )
    out = dev.echo("hello")
    assert out["tenant_subdomain"] == "gtm"
    assert "payload=hello" in str(route.calls.last.request.url)


def test_echo_with_named_kwargs(respx_mock, dev):
    route = respx_mock.get("/api/v1/dev/echo/").mock(
        return_value=httpx.Response(200, json={"query": {"foo": ["1"]}})
    )
    dev.echo(foo="1")
    url = str(route.calls.last.request.url)
    assert "foo=1" in url


def test_echo_404_drf_envelope_raises_not_found(respx_mock, dev):
    respx_mock.get("/api/v1/dev/echo/").mock(
        return_value=httpx.Response(404, json={"detail": "Not found."})
    )
    with pytest.raises(NotFound):
        dev.echo("x")


def test_echo_unknown_4xx_raises_dev_api_error(respx_mock, dev):
    respx_mock.get("/api/v1/dev/echo/").mock(
        return_value=httpx.Response(418, json={"detail": "I'm a teapot"})
    )
    with pytest.raises(DevApiError) as exc:
        dev.echo("x")
    assert exc.value.code == "HTTP_418"


# --- top-level Client.dev accessor + prefix detection ----------------------


def test_top_level_client_dev_accessor_routes_to_dev(respx_mock):
    c = Client(api_key="ck_abc", base_url=BASE_URL)
    assert c.key_prefix == "ck_"
    route = respx_mock.get("/api/v1/dev/ping/").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    out = c.dev.ping()
    assert route.called
    assert out["status"] == "ok"


def test_top_level_client_dev_accessor_is_lazy_singleton():
    c = Client(api_key="ck_abc", base_url=BASE_URL)
    first = c.dev
    second = c.dev
    assert first is second
    assert isinstance(first, DevClient)


def test_client_accepts_legacy_mcp_prefix():
    c = Client(api_key="mcp_legacy", base_url=BASE_URL)
    assert c.key_prefix == "mcp_"
    # `.dev` is still accessible — `ck_`-only keys are recommended but not enforced.
    assert isinstance(c.dev, DevClient)


def test_client_rejects_empty_api_key():
    with pytest.raises(AuthenticationError):
        Client(api_key="", base_url=BASE_URL)
