"""Hardening tests for the cognethics SDK — auth-error envelopes, malformed
responses, retry behavior, ck_/mcp_ prefix routing, and AsyncClient cancellation.

These complement `test_dev.py` (DevClient surface) and the project-level
`tests/test_client.py` (sync MCP transport) by stressing edge cases that
caused regressions during ck_ reshaping work.
"""
from __future__ import annotations

import asyncio
import json
import logging

import httpx
import pytest
import respx

from cognethics import (
    AsyncClient,
    AuthenticationError,
    Client,
    DevApiError,
    DevClient,
    Error,
    PermissionDenied,
    RateLimit,
)


BASE_URL = "http://localhost:8000"
TOOL_URL = "/api/mcp/tools/prism_introspect/"


@pytest.fixture
def respx_mock():
    with respx.mock(base_url=BASE_URL) as r:
        yield r


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    """Skip retry backoff sleeps so retry tests run instantly."""
    import cognethics._client as _client_mod

    monkeypatch.setattr(_client_mod.time, "sleep", lambda *_a, **_k: None)

    async def _no_async_sleep(*_a, **_k):
        return None

    monkeypatch.setattr(asyncio, "sleep", _no_async_sleep)


# --- Auth-error envelopes (401/403) on MCP transport -----------------------


def test_mcp_401_with_drf_detail_envelope_raises_authentication_error(respx_mock):
    """MCP transport tolerates DRF-style 401 envelope `{"detail": "..."}`."""
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(401, json={"detail": "Token expired."})
    )
    c = Client(api_key="ck_abc", base_url=BASE_URL, max_retries=0)
    with pytest.raises(AuthenticationError) as exc:
        c.call("prism_introspect")
    assert exc.value.code == "UNAUTHORIZED"


def test_dev_403_with_prism_envelope_raises_permission_denied(respx_mock):
    """DevClient tolerates Prism-style 403 envelope when DRF detail is absent."""
    respx_mock.get("/api/v1/dev/me/").mock(
        return_value=httpx.Response(
            403,
            json={
                "success": False,
                "error": {
                    "code": "PERMISSION_DENIED",
                    "message": "Key lacks `dev` scope",
                    "details": {},
                },
                "meta": {"request_id": "req-xyz"},
            },
        )
    )
    dev = DevClient(api_key="ck_test", base_url=BASE_URL)
    with pytest.raises(PermissionDenied) as exc:
        dev.me()
    assert "Key lacks" in str(exc.value)
    assert exc.value.request_id == "req-xyz"


# --- Malformed response handling -------------------------------------------


def test_mcp_non_json_2xx_response_raises_error(respx_mock):
    """A 200 with non-JSON body must raise Error rather than crashing."""
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(
            200,
            text="<html>not json</html>",
            headers={"Content-Type": "text/html"},
        )
    )
    c = Client(api_key="ck_abc", base_url=BASE_URL, max_retries=0)
    with pytest.raises(Error) as exc:
        c.call("prism_introspect")
    assert "Invalid JSON response" in str(exc.value)


def test_dev_echo_unknown_4xx_with_no_envelope_falls_back_to_http_status(respx_mock):
    """Generic 4xx with no `detail` / no `error.message` should still raise DevApiError
    with a sensible code based on the HTTP status."""
    respx_mock.get("/api/v1/dev/echo/").mock(
        return_value=httpx.Response(418, text="just a teapot, no json"),
    )
    dev = DevClient(api_key="ck_test", base_url=BASE_URL)
    with pytest.raises(DevApiError) as exc:
        dev.echo("x")
    assert exc.value.code == "HTTP_418"
    assert "418" in str(exc.value)


# --- Retry on 429 + 503 ----------------------------------------------------


def test_mcp_retry_on_429_honors_retry_after_then_succeeds(respx_mock):
    """429 with Retry-After: 1 must retry, then succeed."""
    respx_mock.post(TOOL_URL).mock(
        side_effect=[
            httpx.Response(429, headers={"Retry-After": "1"}, json={"error": "rate"}),
            httpx.Response(
                200, json={"success": True, "data": {"ok": True}, "meta": {}}
            ),
        ]
    )
    c = Client(api_key="ck_abc", base_url=BASE_URL, max_retries=3)
    out = c.call("prism_introspect")
    assert out["data"] == {"ok": True}


def test_mcp_retry_exhausted_on_429_raises_rate_limit_with_retry_after(respx_mock):
    """After exhausting retries on 429, raise RateLimit carrying the Retry-After value."""
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(
            429, headers={"Retry-After": "7"}, json={"error": "rate"}
        )
    )
    c = Client(api_key="ck_abc", base_url=BASE_URL, max_retries=2)
    with pytest.raises(RateLimit) as exc:
        c.call("prism_introspect")
    assert exc.value.retry_after == 7


def test_mcp_retry_on_503_then_succeeds(respx_mock):
    """503 must retry on the same call, then succeed cleanly."""
    respx_mock.post(TOOL_URL).mock(
        side_effect=[
            httpx.Response(503, json={"error": "down"}),
            httpx.Response(503, json={"error": "down"}),
            httpx.Response(
                200, json={"success": True, "data": {"hello": "world"}, "meta": {}}
            ),
        ]
    )
    c = Client(api_key="ck_abc", base_url=BASE_URL, max_retries=3)
    out = c.call("prism_introspect")
    assert out["data"] == {"hello": "world"}


# --- ck_ vs mcp_ prefix routing assertions ---------------------------------


def test_client_ck_key_sets_key_prefix_attribute():
    """ck_ key → client.key_prefix == 'ck_' (used by routing/UA decisions)."""
    c = Client(api_key="ck_abc123", base_url=BASE_URL)
    assert c.key_prefix == "ck_"


def test_client_mcp_key_sets_key_prefix_attribute():
    """Legacy mcp_ key → client.key_prefix == 'mcp_'; backwards compat preserved."""
    c = Client(api_key="mcp_legacy", base_url=BASE_URL)
    assert c.key_prefix == "mcp_"


def test_async_client_accepts_ck_prefix_without_warning(caplog):
    """AsyncClient must accept ck_ keys without spitting a 'will likely fail' warning."""
    with caplog.at_level(logging.WARNING, logger="cognethics"):
        c = AsyncClient(api_key="ck_modern", base_url=BASE_URL)
    assert c.key_prefix == "ck_"
    assert not any(
        "will likely fail" in rec.message for rec in caplog.records
    ), "AsyncClient warned on a valid ck_ key"


def test_async_client_unknown_prefix_logs_warning(caplog):
    """An unknown prefix must still log the same warning the sync Client does."""
    with caplog.at_level(logging.WARNING, logger="cognethics"):
        AsyncClient(api_key="bogus_prefix", base_url=BASE_URL)
    assert any(
        "ck_" in rec.message and "mcp_" in rec.message and "will likely fail" in rec.message
        for rec in caplog.records
    )


# --- AsyncClient cancellation ----------------------------------------------


@pytest.mark.asyncio
async def test_async_client_call_can_be_cancelled():
    """A pending AsyncClient.call() must propagate CancelledError cleanly when its
    task is cancelled, leaving the underlying httpx client closeable."""

    async def hang(_request: httpx.Request) -> httpx.Response:
        # Block long enough for the outer cancel to fire before we'd return.
        await asyncio.sleep(60)
        return httpx.Response(200, json={"success": True, "data": {}, "meta": {}})

    transport = httpx.MockTransport(hang)
    http = httpx.AsyncClient(transport=transport)

    # Restore real asyncio.sleep just inside this test (autouse fixture neutered it).
    # Without this, the hang() above would return immediately and we'd never cancel.
    real_sleep = asyncio.sleep
    import time as _time

    async def _real_sleep(*a, **kw):
        # Yield control once; that's enough for the cancel to land.
        return await real_sleep(*a, **kw)

    # We can't easily un-patch the autouse fixture, so we use a sentinel: cancel
    # the task immediately and assert CancelledError surfaces. The MockTransport
    # awaits asyncio.sleep, which the autouse fixture turned into a no-op — so
    # the request "completes" immediately. To force the cancel to win, we cancel
    # before the task is even scheduled past its first await.
    async with AsyncClient(
        api_key="ck_test", base_url=BASE_URL, _http=http, max_retries=0
    ) as c:
        task = asyncio.create_task(c.call("prism_introspect"))
        # Give the event loop one tick so the task starts.
        await asyncio.sleep(0)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
