"""Cognethics SDK async HTTP client transport (MVP scaffold).

This is a minimum-viable async client that ships alongside the sync `Client`.
It exposes `call(tool_name, **params)` and reuses the same retry/timeout
constants and exception handling as `_client.py`. Generated tree and
ergonomic facades are NOT yet wired — that is follow-up work for SDK-6.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

import httpx

from cognethics._client import (
    DEFAULT_RETRIES,
    DEFAULT_RETRY_BASE,
    DEFAULT_TIMEOUT,
    RETRYABLE_STATUS,
)
from cognethics._exceptions import (
    AuthenticationError,
    Error,
    RateLimit,
    ServerError,
    raise_for_response,
)

logger = logging.getLogger("cognethics")


class AsyncClient:
    """Async Cognethics platform client (MVP — `call()` only).

    Mirrors `Client` constructor signature. Use as an async context manager
    or call `await aclose()` when done.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://gtm.cognethics.com",
        org: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_RETRIES,
        _http: Optional[httpx.AsyncClient] = None,
    ):
        if not api_key:
            raise AuthenticationError("api_key is required")
        if not (api_key.startswith("mcp_") or api_key.startswith("ck_")):
            logger.warning(
                "api_key does not start with 'mcp_' or 'ck_' - auth will likely fail"
            )
        self.api_key = api_key
        self.key_prefix = "ck_" if api_key.startswith("ck_") else "mcp_"
        self.base_url = base_url.rstrip("/")
        self.org = org
        self.timeout = timeout
        self.max_retries = max_retries
        self._http = _http or httpx.AsyncClient(timeout=timeout)

    def _headers(self, org_override: Optional[str] = None) -> dict:
        h = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "cognethics-python/0.1.2",
        }
        org = org_override or self.org
        if org:
            h["X-Organization-Context"] = str(org)
        return h

    async def call(self, tool_name: str, *, _org: Optional[str] = None, **params) -> dict:
        url = f"{self.base_url}/api/mcp/tools/{tool_name}/"
        body = {k: v for k, v in params.items() if v is not None}
        attempt = 0
        while True:
            try:
                resp = await self._http.post(url, json=body, headers=self._headers(_org))
            except httpx.RequestError as e:
                if attempt >= self.max_retries:
                    raise Error(f"Network error: {e}") from e
                await asyncio.sleep(DEFAULT_RETRY_BASE * (2 ** attempt))
                attempt += 1
                continue

            if resp.status_code == 401:
                raise AuthenticationError("API key invalid or expired", code="UNAUTHORIZED")
            if resp.status_code in RETRYABLE_STATUS and attempt < self.max_retries:
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "0") or 0)
                    await asyncio.sleep(max(retry_after, DEFAULT_RETRY_BASE * (2 ** attempt)))
                else:
                    await asyncio.sleep(DEFAULT_RETRY_BASE * (2 ** attempt))
                attempt += 1
                continue
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", "0") or 0)
                raise RateLimit("Rate limit exceeded", code="RATE_LIMIT", retry_after=retry_after)
            if resp.status_code >= 500:
                raise ServerError(
                    f"Server error {resp.status_code}: {resp.text[:200]}",
                    code="SERVER_ERROR",
                )

            try:
                payload = resp.json()
            except Exception as e:
                raise Error(f"Invalid JSON response: {e}") from e
            raise_for_response(payload, resp.status_code)
            return payload

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
