#!/usr/bin/env python3
"""Bump pyproject.toml version + cognethics/__init__.py __version__ in lock-step.

Reads the current `version = "X.Y.Z"` from pyproject.toml, bumps the requested
component, and writes the new version into BOTH files. Prints the new version
to stdout (no trailing newline noise) so the caller can capture it.

Usage:
    python bump_version.py --level patch
    python bump_version.py --level minor
    python bump_version.py --level major
    python bump_version.py --set 0.2.0      # explicit override
    python bump_version.py --dry-run        # default: defaults to --level patch
    python bump_version.py --level minor --dry-run  # compute, don't write

`--dry-run` skips file writes and prints the proposed new version. If neither
`--level` nor `--set` is supplied alongside `--dry-run`, defaults to `patch`.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYPROJECT = ROOT / "pyproject.toml"
INIT_PY   = ROOT / "cognethics" / "__init__.py"

PYPROJECT_RE = re.compile(r'^version\s*=\s*"([^"]+)"', re.MULTILINE)
INIT_RE      = re.compile(r'^__version__\s*=\s*"([^"]+)"', re.MULTILINE)


def _read_current() -> str:
    text = PYPROJECT.read_text()
    m = PYPROJECT_RE.search(text)
    if not m:
        raise SystemExit("Could not find version in pyproject.toml")
    return m.group(1)


def _bump(version: str, level: str) -> str:
    parts = version.split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise SystemExit(f"Non-semver version: {version}")
    major, minor, patch = (int(x) for x in parts)
    if level == "patch":
        patch += 1
    elif level == "minor":
        minor += 1
        patch = 0
    elif level == "major":
        major += 1
        minor = 0
        patch = 0
    else:
        raise SystemExit(f"Unknown level: {level}")
    return f"{major}.{minor}.{patch}"


def _write_new(new_version: str) -> None:
    pp_text = PYPROJECT.read_text()
    pp_new = PYPROJECT_RE.sub(f'version = "{new_version}"', pp_text, count=1)
    if pp_new == pp_text:
        raise SystemExit("Failed to substitute version in pyproject.toml")
    PYPROJECT.write_text(pp_new)

    init_text = INIT_PY.read_text()
    if not INIT_RE.search(init_text):
        raise SystemExit("Could not find __version__ in cognethics/__init__.py")
    init_new = INIT_RE.sub(f'__version__ = "{new_version}"', init_text, count=1)
    INIT_PY.write_text(init_new)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--level", choices=["patch", "minor", "major"])
    ap.add_argument("--set", dest="explicit", help="Set version explicitly (overrides --level)")
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Compute the new version and print it; do NOT write to files.",
    )
    args = ap.parse_args()

    current = _read_current()
    if args.explicit:
        new = args.explicit
    elif args.level:
        new = _bump(current, args.level)
    elif args.dry_run:
        # Convenience: dry-runs default to patch so CI can probe without args.
        new = _bump(current, "patch")
    else:
        raise SystemExit("Provide --level or --set")

    if args.dry_run:
        print(f"{current} -> {new} (dry-run, no files written)", end="")
    else:
        _write_new(new)
        print(new, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
