#!/usr/bin/env python3
"""Classify a regen diff as patch / minor / major / none.

Heuristic rules (priority order — first match wins):
  - none:  trees are byte-identical (codegen idempotency check).
  - major: a method present in the old facade allow-list disappeared,
           OR a class disappeared whose name appears in
           `cognethics/ergonomic.py`'s ERGONOMIC_FACADES references.
  - minor: any method or class added or removed,
           OR a method's parameter signature changed.
  - patch: only method bodies changed (same set of methods + same signatures),
           e.g. axis kwarg literals updated, docstring rewordings.

Usage:
    python classify_bump.py --old /tmp/generated_old --new clients/python/cognethics/generated
Prints one of: none|patch|minor|major  (no trailing newline noise).
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from pathlib import Path


def _walk_py(root: Path) -> dict[str, str]:
    """Return {relative_path: file_text} for all .py files in tree."""
    out: dict[str, str] = {}
    if not root.exists():
        return out
    for p in sorted(root.rglob("*.py")):
        if "__pycache__" in p.parts:
            continue
        rel = p.relative_to(root).as_posix()
        out[rel] = p.read_text()
    return out


def _surface(text: str) -> dict[str, tuple[str, ...]]:
    """Extract {ClassName.method_name: (param_names_in_order,)}.

    Used to compare API surface between old and new trees. Only looks at
    top-level classes and their direct methods — matches the codegen shape.
    """
    surface: dict[str, tuple[str, ...]] = {}
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return surface
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for item in node.body:
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            params = tuple(a.arg for a in item.args.args if a.arg != "self")
            params = params + tuple(a.arg for a in item.args.kwonlyargs)
            surface[f"{node.name}.{item.name}"] = params
    return surface


def _facade_methods(repo_root: Path) -> set[str]:
    """Public ergonomic facade method names referenced from cognethics/ergonomic.py.

    Anything called as `self._client.<mega>.<...>.<method_name>(` inside
    ergonomic.py is treated as load-bearing public API. Removing one of these
    is a MAJOR break.
    """
    ergo = repo_root / "clients/python/cognethics/ergonomic.py"
    if not ergo.exists():
        return set()
    text = ergo.read_text()
    return set(re.findall(r"\.([a-zA-Z_]\w*)\(", text))


def classify(old_root: Path, new_root: Path, repo_root: Path) -> str:
    old = _walk_py(old_root)
    new = _walk_py(new_root)

    if old == new:
        return "none"

    old_surface: dict[str, tuple[str, ...]] = {}
    new_surface: dict[str, tuple[str, ...]] = {}
    for path, text in old.items():
        for k, v in _surface(text).items():
            old_surface[f"{path}::{k}"] = v
    for path, text in new.items():
        for k, v in _surface(text).items():
            new_surface[f"{path}::{k}"] = v

    removed = set(old_surface) - set(new_surface)
    added = set(new_surface) - set(old_surface)
    sig_changed = {
        k for k in (set(old_surface) & set(new_surface))
        if old_surface[k] != new_surface[k]
    }

    facade = _facade_methods(repo_root)
    for r in removed:
        method_name = r.rsplit(".", 1)[-1]
        if method_name in facade:
            return "major"

    if removed or added or sig_changed:
        return "minor"

    return "patch"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", required=True, type=Path)
    ap.add_argument("--new", required=True, type=Path)
    ap.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[3],
        help="Repo root (used to find ergonomic.py); default = grandparent of this script.",
    )
    args = ap.parse_args()
    print(classify(args.old, args.new, args.repo_root), end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
