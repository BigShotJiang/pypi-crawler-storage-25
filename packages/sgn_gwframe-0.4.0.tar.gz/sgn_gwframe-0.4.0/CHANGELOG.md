# Changelog

## [Unreleased]

## [0.4.0] - 2026-04-13

### Added

- Masked array support: gaps are now preserved as masked data in frame
  files instead of being skipped, and sources propagate invalid-data
  masks from upstream frame files
- `GWFrameSink`: new `channel_type`, `on_mask_loss`, and `frame_spec` options
- `CacheEntry.from_gwf()`, `CacheEntry.from_T050017()` classmethods
- `CacheEntry.segmentlistdict` property

### Changed

- Require `gwframe >= 0.3`, `sgn >= 0.7`, `sgn-ts >= 0.7`
- `GWFrameSink`: use `FrameWriter.open()`/`close()` API

## [0.3.0] - 2026-03-17

### Added

- Support `file://` URLs in LAL cache file entries
- `GWFrameSink`: add `output_dir` parameter for specifying output directory
- Accept `Path` objects for all path parameters
- Allow source/sink elements to be imported from the top level of the package

### Changed

- Require `gwframe >= 0.2`
- `GWFrameSink`: rename `path` parameter to `file_pattern` for clarity;
  it now accepts only a filename pattern (no directory separators)

### Fixed

- Raise `ValueError` with a descriptive message when no frame data covers the
  requested time range, instead of an opaque `IndexError` on empty cache

## [0.2.0] - 2026-03-11

### Changed

- Rename `FrameSource` to `GWFrameSource`
- Rename `FrameWatchSource` to `GWFrameWatchSource`
- Rename `FrameSink` to `GWFrameSink`

## [0.1.0] - 2026-02-24

- Initial release, overhauled frame elements from sgn-ligo.

[unreleased]: https://git.ligo.org/greg/sgn-gwframe/-/compare/0.4.0...main
[0.4.0]: https://git.ligo.org/greg/sgn-gwframe/-/tags/0.4.0
[0.3.0]: https://git.ligo.org/greg/sgn-gwframe/-/tags/0.3.0
[0.2.0]: https://git.ligo.org/greg/sgn-gwframe/-/tags/0.2.0
[0.1.0]: https://git.ligo.org/greg/sgn-gwframe/-/tags/0.1.0
