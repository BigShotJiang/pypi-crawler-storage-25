try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.0.0"


from sgn_gwframe.sinks import GWFrameSink
from sgn_gwframe.sources import GWFrameSource, GWFrameWatchSource
