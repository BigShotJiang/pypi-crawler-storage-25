"""Utility functions for gravitational wave frame I/O."""

# Copyright (C) 2009-2013  Kipp Cannon, Chad Hanna, Drew Keppel
# Copyright (C) 2024 Becca Ewing, Yun-Jing Huang

from __future__ import annotations

import itertools
import os
from dataclasses import dataclass
from os import PathLike, fspath
from typing import TYPE_CHECKING
from urllib.parse import urlparse, urlunparse

import gwframe
import igwn_segments as segments
import numpy as np
from sgnts.base import Offset, SeriesBuffer

if TYPE_CHECKING:
    from gwframe import TimeSeries


def from_T050017(url):  # noqa: N802
    """
    Parse a path or URL in the style of T050017-00.
    """
    filename, _ = os.path.splitext(os.path.basename(url))
    obs, desc, start, dur = filename.split("-")
    return obs, desc, int(start), int(dur)


def timeseries_to_buffers(
    series: TimeSeries,
    start: float,
    sample_rate: int,
) -> list[SeriesBuffer]:
    """Convert a gwframe TimeSeries to a list of SeriesBuffers.

    If the TimeSeries has a mask (invalid data regions), it is split into
    contiguous valid/gap runs, each returned as a separate SeriesBuffer.
    Unmasked data produces a single buffer.
    """
    masked_data = series.to_masked()

    if isinstance(masked_data, np.ma.MaskedArray) and np.ma.is_masked(masked_data):
        buffers = []
        offset = Offset.fromsec(start)
        masked_runs = [(s, True) for s in np.ma.clump_masked(masked_data)]
        unmasked_runs = [(s, False) for s in np.ma.clump_unmasked(masked_data)]
        for slc, is_gap in sorted(itertools.chain(masked_runs, unmasked_runs)):
            n = int(slc.stop - slc.start)
            buf = SeriesBuffer(
                offset=offset,
                sample_rate=sample_rate,
                data=None if is_gap else masked_data.data[slc],
                shape=(n,),
            )
            buffers.append(buf)
            offset = buf.end_offset
        return buffers

    return [
        SeriesBuffer(
            offset=Offset.fromsec(start),
            sample_rate=sample_rate,
            data=masked_data,
        )
    ]


@dataclass
class CacheEntry:
    """Simple cache entry parser for LAL cache files.

    Cache file format: observatory description gps_start duration url
    Example: L L1_GWOSC_16KHZ_R1 1240215487 32 file://localhost/path/to/file.gwf

    The url field follows the LAL cache specification and may be either a bare
    file path or a file:// URL.  Other URL schemes are not supported.
    """

    observatory: str
    description: str
    gps_start: float
    duration: float
    path: str
    scheme: str = ""
    host: str = ""

    @classmethod
    def from_line(cls, line: str) -> CacheEntry:
        """Parse a cache file line into a CacheEntry."""
        parts = line.strip().split()
        if len(parts) != 5:
            msg = f"Invalid cache line format: {line}"
            raise ValueError(msg)
        scheme, host, path = cls._parse_url(parts[4])
        return cls(
            observatory=parts[0],
            description=parts[1],
            gps_start=float(parts[2]),
            duration=float(parts[3]),
            path=path,
            scheme=scheme,
            host=host,
        )

    @staticmethod
    def _parse_url(url: str) -> tuple[str, str, str]:
        """Parse a cache entry URL into scheme, host, and path components.

        Supports bare file paths and file:// URLs per the LAL cache spec.
        Other URL schemes (e.g. gsiftp://) are not supported.
        """
        parsed = urlparse(url)
        if parsed.scheme not in ("", "file"):
            msg = f"Unsupported URL scheme '{parsed.scheme}' in cache entry: {url}"
            raise ValueError(msg)
        return parsed.scheme, parsed.netloc, parsed.path or url

    @classmethod
    def from_gwf(
        cls,
        gwf_path: str | PathLike[str],
        channels: list[str] | None = None,
        description: str = "FRAME",
    ) -> CacheEntry:
        """Create a CacheEntry from a gwf file by reading its metadata."""
        gwf_path = fspath(gwf_path)
        # Read the file to get metadata
        frame_data = gwframe.read(gwf_path, channels=channels, allow_invalid=True)

        # Get metadata from first channel
        first_channel_data = next(iter(frame_data.values()))
        gps_start = first_channel_data.start
        duration = first_channel_data.duration

        # Extract observatory from channel name (e.g., "H1" from "H1:GDS-CALIB_STRAIN")
        first_channel_name = next(iter(frame_data.keys()))
        observatory = first_channel_name.split(":")[0]

        return cls(
            observatory=observatory,
            description=description,
            gps_start=gps_start,
            duration=duration,
            path=gwf_path,
        )

    @classmethod
    def from_T050017(cls, url: str):  # noqa: N802
        """Parse a path or URL into a CacheEntry in the style of T050017-00."""
        obs, desc, start, dur = from_T050017(url)
        return cls(
            observatory=obs,
            description=desc,
            gps_start=int(start),
            duration=int(dur),
            path=url,
        )

    def T050017_filename(self):  # noqa N802
        """Generate a T050017 filename from this entry"""
        return (
            f"{self.observatory}-{self.description}-"
            f"{int(self.gps_start)}-{int(self.duration)}.gwf"
        )

    @property
    def url(self) -> str:
        """Reconstruct the URL from scheme, host, and path components."""
        return urlunparse((self.scheme, self.host, self.path, "", "", ""))

    def __str__(self) -> str:
        """Format as a LAL cache file line."""
        gps_start = (
            int(self.gps_start)
            if self.gps_start == int(self.gps_start)
            else self.gps_start
        )
        duration = (
            int(self.duration) if self.duration == int(self.duration) else self.duration
        )
        return (
            f"{self.observatory} {self.description} {gps_start} {duration} {self.url}"
        )

    @property
    def segment(self) -> segments.segment:
        """Return the time segment for this cache entry."""
        return segments.segment(self.gps_start, self.gps_start + self.duration)

    @property
    def segmentlistdict(self) -> segments.segmentlistdict:
        """Return a segmentlistdict for this cache entry."""
        s = segments.segmentlistdict()
        s[self.observatory] = segments.segmentlist([self.segment])
        return s
