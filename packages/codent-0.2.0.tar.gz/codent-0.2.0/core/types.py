# core/types.py
"""
Shared data contracts for Cont.

RULES:
  - Contract-only: dataclasses + enums, NO business logic.
  - No imports from core/ modules (prevents circular deps).
  - Only stdlib imports allowed.
  - New types must be added here, not inline in cont.py.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ── Routing ───────────────────────────────────────────────

class RouteDecision(str, Enum):
    """How a task is dispatched."""
    FASTPATH = "fastpath"
    RECIPE = "recipe"
    LLM = "llm"
    BROWSER_AGENT = "browser_agent"


@dataclass
class TaskRoute:
    """Result of route_task(): what lane handles this input."""
    decision: RouteDecision
    recipe_id: Optional[str] = None
    recipe: Optional[Dict[str, Any]] = None
    intent: Optional[str] = None        # fastpath intent (e.g. "git_status")
    url: Optional[str] = None           # extracted URL (for browser_agent)
    confidence: float = 0.0


# ── Tool Execution ────────────────────────────────────────

@dataclass
class ToolResult:
    """Single tool call record."""
    tool_name: str
    args: Dict[str, Any]
    result: str
    success: bool
    timestamp: float = 0.0


# ── Episode Recording ─────────────────────────────────────

@dataclass
class EpisodeRecord:
    """One task execution episode (what happened + outcome)."""
    task_input: str
    task_type: str = "llm"              # llm | fastpath | recipe
    method: Optional[str] = None        # e.g. "recipe:mevzuat_arama_v1"
    tools_used: int = 0
    tool_names: List[str] = field(default_factory=list)
    duration_ms: int = 0
    success: int = -1                   # 1=ok, 0=fail, -1=unknown
    auto_eval: Optional[Dict] = None
    response_preview: Optional[str] = None
    error: Optional[str] = None
    recipe_id: Optional[str] = None
    fastpath_intent: Optional[str] = None


# ── Auto-Evaluation ───────────────────────────────────────

@dataclass
class AutoEvalResult:
    """Deterministic task evaluation result."""
    success: Optional[bool]             # True / False / None (uncertain)
    confidence: float                   # 0.0 – 1.0
    reasons: List[str] = field(default_factory=list)
    score: int = 50                     # 0 – 100
