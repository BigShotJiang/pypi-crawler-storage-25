# core/router.py
"""
Pure routing decision for tasks — determines WHERE to dispatch.

route_task() returns a TaskRoute (decision + metadata) without executing.
Execution stays in cont.py (or future core/runtime.py).

Dependencies are injected via init_router() — no direct cont.py imports.
"""

import re
from typing import Callable, Dict, Optional

from core.types import RouteDecision, TaskRoute


# ── URL Detection ────────────────────────────────────────────

_URL_RE = re.compile(
    r'https?://[\w\-.]+\.\w{2,}[^\s]*|[\w\-.]+\.(gov|com|org|net)\.\w{2,}[^\s]*'
)


def extract_url(text: str) -> Optional[str]:
    """Extract first URL from text. Returns None if no URL found."""
    m = _URL_RE.search(text)
    if m:
        url = m.group()
        if not url.startswith('http'):
            url = 'https://' + url
        return url
    return None


def extract_goal(text: str) -> str:
    """Extract task goal by removing URLs from text."""
    goal = _URL_RE.sub('', text).strip()
    if not goal or len(goal) < 3:
        goal = "sayfayı aç ve içeriği özetle"
    return goal


# ── Raw Input Extraction ─────────────────────────────────────

def extract_raw_input(task: str) -> str:
    """Extract raw user input from possibly-wrapped task string.

    Strips conversation history wrappers and system hints, returning
    just the user's actual request text.
    """
    raw = task

    # XML-wrapped: <current_request>actual input</current_request>
    if "<current_request>" in raw:
        m = re.search(
            r'<current_request>\s*(.*?)\s*</current_request>',
            raw, re.DOTALL,
        )
        if m:
            return m.group(1)

    # System hint prefix or conversation history wrapper
    if raw.startswith("[SİSTEM İPUCU:") or raw.startswith("<conversation_history>"):
        clean = re.sub(r'\[SİSTEM İPUCU:.*?\]', '', raw, flags=re.DOTALL).strip()
        clean = re.sub(r'<[^>]+>.*?</[^>]+>', '', clean, flags=re.DOTALL)
        clean = re.sub(r'<[^>]+>', '', clean).strip()
        if clean:
            return clean

    return raw


# ── Module-level DI state ────────────────────────────────────

_fastpath_enabled: bool = True
_learning_enabled: bool = True
_escalation_enabled: bool = False
_check_safety_fn: Optional[Callable] = None
_system_executor_factory: Optional[Callable] = None
_match_recipe_fn: Optional[Callable] = None
_recipe_needs_browser_fn: Optional[Callable] = None
_should_escalate_fn: Optional[Callable] = None
_memory_search_fn: Optional[Callable] = None
_init_recipe_db_fn: Optional[Callable] = None
_seed_recipes_fn: Optional[Callable] = None
_cleanup_junk_fn: Optional[Callable] = None
_debug_fn: Callable = lambda msg: None


def init_router(
    *,
    fastpath_enabled: bool = True,
    learning_enabled: bool = True,
    escalation_enabled: bool = False,
    check_safety_fn: Callable = None,
    system_executor_factory: Callable = None,
    match_recipe_fn: Callable = None,
    recipe_needs_browser_fn: Callable = None,
    should_escalate_fn: Callable = None,
    memory_search_fn: Callable = None,
    init_recipe_db_fn: Callable = None,
    seed_recipes_fn: Callable = None,
    cleanup_junk_fn: Callable = None,
    debug_fn: Callable = None,
):
    """Initialize router with runtime dependencies from cont.py."""
    global _fastpath_enabled, _learning_enabled, _escalation_enabled
    global _check_safety_fn, _system_executor_factory
    global _match_recipe_fn, _recipe_needs_browser_fn
    global _should_escalate_fn, _memory_search_fn
    global _init_recipe_db_fn, _seed_recipes_fn, _cleanup_junk_fn
    global _debug_fn

    _fastpath_enabled = fastpath_enabled
    _learning_enabled = learning_enabled
    _escalation_enabled = escalation_enabled
    _check_safety_fn = check_safety_fn
    _system_executor_factory = system_executor_factory
    _match_recipe_fn = match_recipe_fn
    _recipe_needs_browser_fn = recipe_needs_browser_fn
    _should_escalate_fn = should_escalate_fn
    _memory_search_fn = memory_search_fn
    _init_recipe_db_fn = init_recipe_db_fn
    _seed_recipes_fn = seed_recipes_fn
    _cleanup_junk_fn = cleanup_junk_fn
    if debug_fn:
        _debug_fn = debug_fn


# ── Main routing function ────────────────────────────────────

def route_task(raw_input: str) -> TaskRoute:
    """Determine how to dispatch a task. Pure decision — no execution.

    Routing pipeline (in priority order):
      1. Safety check → reject if unsafe
      2. Fastpath → SystemExecutor.try_execute()
      3. Recipe match → SystemExecutor.try_execute_recipe()
      4. Browser agent → URL detected + recipe allows
      5. Escalation → Claude Code (if enabled)
      6. LLM with tools (default)

    Returns TaskRoute with decision + metadata.
    """

    # Stage 0: Safety check
    if _check_safety_fn:
        safe, reason = _check_safety_fn(raw_input)
        if not safe:
            return TaskRoute(
                decision=RouteDecision.LLM,
                intent=f"blocked:{reason}",
                confidence=1.0,
            )

    # Stage 1: Fastpath (Lane A)
    if _fastpath_enabled and _system_executor_factory:
        try:
            se = _system_executor_factory()
            result = se.try_execute(raw_input)
            if result and result.get("handled"):
                return TaskRoute(
                    decision=RouteDecision.FASTPATH,
                    intent=result.get("intent"),
                    confidence=min(result.get("intent_score", 0) / 10.0, 1.0),
                )
        except Exception:
            pass

    # Stage 2: Recipe matching (Lane A2)
    matched_recipe = None
    recipe_result = None
    if _learning_enabled and _match_recipe_fn:
        try:
            conn = _init_recipe_db_fn() if _init_recipe_db_fn else None
            if conn and _seed_recipes_fn:
                _seed_recipes_fn(conn)
            if conn and _cleanup_junk_fn:
                _cleanup_junk_fn(conn, max_age_hours=24)
            matched_recipe = _match_recipe_fn(raw_input, conn)
            if matched_recipe:
                # Try system execution
                if _system_executor_factory:
                    se = _system_executor_factory(
                        memory_fn=_memory_search_fn,
                    )
                    recipe_result = se.try_execute_recipe(
                        raw_input, matched_recipe,
                    )
                    if recipe_result and recipe_result.get("handled"):
                        return TaskRoute(
                            decision=RouteDecision.RECIPE,
                            recipe_id=matched_recipe.get("id"),
                            recipe=matched_recipe,
                            confidence=min(
                                matched_recipe.get("_score", 0) / 10.0, 1.0
                            ),
                        )
        except Exception:
            pass

    # Stage 3: Browser agent (URL detection)
    url = extract_url(raw_input)
    if url:
        # Check if recipe allows browser
        recipe_system_handled = (
            recipe_result and recipe_result.get("handled")
        )
        recipe_allows_browser = True
        if matched_recipe:
            if _recipe_needs_browser_fn:
                recipe_allows_browser = (
                    _recipe_needs_browser_fn(matched_recipe)
                    and not recipe_system_handled
                )
            else:
                recipe_allows_browser = False

        if recipe_allows_browser:
            return TaskRoute(
                decision=RouteDecision.BROWSER_AGENT,
                url=url,
                recipe=matched_recipe,
                recipe_id=(
                    matched_recipe.get("id") if matched_recipe else None
                ),
                confidence=0.9,
            )

    # Stage 4: Escalation (if enabled, not handled here — just signal)
    # Escalation stays in cont.py because it needs interactive approval.
    # Router signals LLM, and cont.py checks escalation before LLM loop.

    # Stage 5: Default — LLM with tools
    return TaskRoute(
        decision=RouteDecision.LLM,
        recipe=matched_recipe,
        recipe_id=(
            matched_recipe.get("id") if matched_recipe else None
        ),
        confidence=0.5,
    )
