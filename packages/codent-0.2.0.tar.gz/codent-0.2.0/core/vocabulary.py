# core/vocabulary.py
"""
Bilingual vocabulary system for local LLMs.

Local 7B-20B models often fail on Turkish commands. This module loads a
human-editable vocabulary.json and injects relevant entries into the
system prompt so the model can understand Turkish→English mappings.
"""

import json
from pathlib import Path
from datetime import datetime


VOCAB_PATH = Path.home() / ".config" / "cont" / "vocabulary.json"


def load_vocabulary() -> dict:
    """Load vocabulary from JSON file. Returns empty dict on failure."""
    try:
        if VOCAB_PATH.exists():
            return json.loads(VOCAB_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def get_relevant_vocab(task: str) -> str:
    """
    Return a compact prompt string (~100 tokens) with only matching
    Turkish words from the vocabulary.
    """
    vocab = load_vocabulary()
    if not vocab:
        return ""

    task_lower = task.lower()
    parts = []

    # Match commands
    commands = vocab.get("commands", {})
    matched_cmds = []
    for word, info in commands.items():
        if word in task_lower:
            en = info.get("en", "?")
            intent = info.get("intent", "")
            matched_cmds.append(f"{word}={en}({intent})")

    if matched_cmds:
        parts.append("TR→EN: " + ", ".join(matched_cmds))

    # Match context words
    context_words = vocab.get("context_words", {})
    matched_ctx = []
    for word, info in context_words.items():
        if word in task_lower:
            en = info.get("en", "?")
            matched_ctx.append(f"{word}={en}")

    if matched_ctx:
        parts.append("Context: " + ", ".join(matched_ctx))

    # Match sentence patterns
    patterns = vocab.get("patterns", {})
    matched_patterns = []
    for tr_pattern, en_pattern in patterns.items():
        # Check if any key words from the pattern appear in the task
        pattern_words = [w for w in tr_pattern.lower().split() if len(w) > 2]
        if any(w in task_lower for w in pattern_words):
            matched_patterns.append(f'"{tr_pattern}" → "{en_pattern}"')

    if matched_patterns:
        parts.append("Patterns: " + "; ".join(matched_patterns[:3]))

    if not parts:
        return ""

    return "VOCABULARY:\n" + "\n".join(parts)


def add_word(word: str, translation: str, intent: str = "read",
             example: str = "") -> bool:
    """Add a new word to vocabulary.json. Returns True on success."""
    try:
        vocab = load_vocabulary()
        if not vocab:
            vocab = {"commands": {}, "context_words": {}, "patterns": {},
                     "learned_at": datetime.now().isoformat()}

        commands = vocab.setdefault("commands", {})
        entry = {"en": translation, "intent": intent}
        if example:
            entry["example"] = example
        commands[word] = entry
        vocab["learned_at"] = datetime.now().isoformat()

        VOCAB_PATH.parent.mkdir(parents=True, exist_ok=True)
        VOCAB_PATH.write_text(json.dumps(vocab, ensure_ascii=False, indent=2),
                              encoding="utf-8")
        return True
    except Exception:
        return False


def get_vocabulary_stats() -> dict:
    """Get vocabulary statistics for CLI reporting."""
    vocab = load_vocabulary()
    if not vocab:
        return {"commands": 0, "context_words": 0, "patterns": 0, "total": 0}

    commands = len(vocab.get("commands", {}))
    context_words = len(vocab.get("context_words", {}))
    patterns = len(vocab.get("patterns", {}))
    return {
        "commands": commands,
        "context_words": context_words,
        "patterns": patterns,
        "total": commands + context_words + patterns,
        "learned_at": vocab.get("learned_at", "unknown"),
    }
