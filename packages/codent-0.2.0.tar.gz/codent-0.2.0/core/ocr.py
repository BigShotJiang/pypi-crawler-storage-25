# core/ocr.py
"""
OCR engine for Cont — dual-engine: EasyOCR (fast) + Surya (powerful).

Engines:
  - easyocr: Fast, lightweight. Good for simple text extraction.
  - surya:   Transformer-based. Superior accuracy, layout detection,
             reading order. Slower first run (model download ~1.4GB).

Usage as library:
    from core.ocr import ocr_image
    result = ocr_image("/path/to/image.jpg")                    # auto-select
    result = ocr_image("/path/to/image.jpg", engine="surya")    # force surya
    result = ocr_image("/path/to/image.jpg", engine="easyocr")  # force easyocr

    from core.ocr import ocr_layout
    layout = ocr_layout("/path/to/page.jpg")  # page layout analysis

Usage as CLI:
    python -m core.ocr photo.jpg                        # auto engine
    python -m core.ocr photo.jpg --engine surya         # force surya
    python -m core.ocr scan.png --layout                # layout analysis
    python -m core.ocr receipt.jpg --json --engine both  # compare engines
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

VALID_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}


def _resolve_win_path(p: str) -> str:
    """Convert Windows path to WSL path if needed."""
    if len(p) >= 3 and p[1] == ':' and p[2] in ('\\', '/'):
        try:
            import subprocess
            proc = subprocess.run(
                ["wslpath", "-u", p],
                capture_output=True, text=True, timeout=5
            )
            if proc.returncode == 0 and proc.stdout.strip():
                return proc.stdout.strip()
        except Exception:
            pass
    return p


# ─────────────────────────────────────────────────────────
# GPU check
# ─────────────────────────────────────────────────────────

def _gpu_available() -> bool:
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False


# ─────────────────────────────────────────────────────────
# Engine availability
# ─────────────────────────────────────────────────────────

def _has_easyocr() -> bool:
    try:
        import easyocr  # noqa: F401
        return True
    except ImportError:
        return False


def _has_surya() -> bool:
    try:
        from surya.detection import DetectionPredictor  # noqa: F401
        from surya.recognition import RecognitionPredictor  # noqa: F401
        return True
    except ImportError:
        return False


def available_engines() -> list[str]:
    engines = []
    if _has_easyocr():
        engines.append("easyocr")
    if _has_surya():
        engines.append("surya")
    return engines


def _pick_engine() -> str:
    """Auto-select best available engine. Surya preferred."""
    if _has_surya():
        return "surya"
    if _has_easyocr():
        return "easyocr"
    raise RuntimeError("OCR motoru bulunamadı. 'pip install easyocr' veya 'pip install surya-ocr' çalıştırın.")


# ─────────────────────────────────────────────────────────
# EasyOCR backend
# ─────────────────────────────────────────────────────────

_easyocr_reader = None
_easyocr_langs = None


def _get_easyocr_reader(languages: list[str]):
    global _easyocr_reader, _easyocr_langs
    if _easyocr_reader is not None and _easyocr_langs == languages:
        return _easyocr_reader
    import easyocr
    _easyocr_reader = easyocr.Reader(languages, gpu=_gpu_available(), verbose=False)
    _easyocr_langs = languages
    return _easyocr_reader


def _ocr_easyocr(path: Path, languages: list[str], detail: str,
                 confidence_threshold: float) -> dict:
    reader = _get_easyocr_reader(languages)
    raw = reader.readtext(str(path))

    blocks = []
    text_lines = []
    for bbox, text, conf in raw:
        if conf < confidence_threshold:
            continue
        block = {"text": text, "confidence": round(conf, 4)}
        if detail in ("standard", "full"):
            block["bbox"] = {
                "top_left": [int(bbox[0][0]), int(bbox[0][1])],
                "top_right": [int(bbox[1][0]), int(bbox[1][1])],
                "bottom_right": [int(bbox[2][0]), int(bbox[2][1])],
                "bottom_left": [int(bbox[3][0]), int(bbox[3][1])],
            }
        if detail == "full":
            block["bbox_raw"] = [[int(p[0]), int(p[1])] for p in bbox]
        blocks.append(block)
        text_lines.append(text)

    return blocks, text_lines, len(raw)


# ─────────────────────────────────────────────────────────
# Surya backend (lazy singleton)
# ─────────────────────────────────────────────────────────

_surya_det = None
_surya_rec = None
_surya_foundation = None
_surya_layout = None


def _get_surya_predictors():
    """Lazy-load Surya detection + recognition predictors."""
    global _surya_det, _surya_rec, _surya_foundation
    if _surya_det is not None and _surya_rec is not None:
        return _surya_det, _surya_rec

    from surya.detection import DetectionPredictor
    from surya.recognition import RecognitionPredictor
    from surya.foundation import FoundationPredictor

    _surya_det = DetectionPredictor()
    _surya_foundation = FoundationPredictor()
    _surya_rec = RecognitionPredictor(_surya_foundation)
    return _surya_det, _surya_rec


def _get_surya_layout():
    """Lazy-load Surya layout predictor (needs foundation model)."""
    global _surya_layout, _surya_foundation
    if _surya_layout is not None:
        return _surya_layout

    from surya.layout import LayoutPredictor
    from surya.foundation import FoundationPredictor

    if _surya_foundation is None:
        _surya_foundation = FoundationPredictor()
    _surya_layout = LayoutPredictor(_surya_foundation)
    return _surya_layout


def _ocr_surya(path: Path, languages: list[str], detail: str,
               confidence_threshold: float) -> dict:
    from PIL import Image

    det, rec = _get_surya_predictors()
    img = Image.open(str(path)).convert("RGB")

    # Surya 0.17+: languages passed via task_names (optional),
    # or auto-detected. det_predictor as kwarg.
    preds = rec([img], det_predictor=det)
    page = preds[0]

    blocks = []
    text_lines = []
    total = len(page.text_lines)

    for line in page.text_lines:
        conf = line.confidence
        if conf < confidence_threshold:
            continue

        block = {"text": line.text, "confidence": round(conf, 4)}

        if detail in ("standard", "full"):
            bb = line.bbox  # [x1, y1, x2, y2]
            block["bbox"] = {
                "top_left": [int(bb[0]), int(bb[1])],
                "top_right": [int(bb[2]), int(bb[1])],
                "bottom_right": [int(bb[2]), int(bb[3])],
                "bottom_left": [int(bb[0]), int(bb[3])],
            }

        if detail == "full":
            block["polygon"] = [[int(p[0]), int(p[1])] for p in line.polygon]

        blocks.append(block)
        text_lines.append(line.text)

    return blocks, text_lines, total


# ─────────────────────────────────────────────────────────
# Layout analysis (Surya only)
# ─────────────────────────────────────────────────────────

def ocr_layout(image_path: str) -> dict:
    """
    Analyze page layout: detect text regions, tables, figures, headers, etc.

    Returns:
        dict with layout regions, each having:
          - label: region type (Text, Table, Figure, Title, Header, Footer, etc.)
          - bbox: bounding box [x1, y1, x2, y2]
          - confidence: detection confidence
    """
    if not _has_surya():
        return {"status": "error", "error": "Surya yüklü değil. 'pip install surya-ocr'"}

    path = Path(image_path).expanduser().resolve()
    if not path.exists():
        return {"status": "error", "error": f"Dosya bulunamadı: {image_path}"}

    from PIL import Image

    t0 = time.time()
    layout_pred = _get_surya_layout()
    img = Image.open(str(path)).convert("RGB")

    preds = layout_pred([img])
    page = preds[0]
    duration_ms = int((time.time() - t0) * 1000)

    regions = []
    for block in page.bboxes:
        regions.append({
            "label": block.label,
            "bbox": [int(b) for b in block.bbox],
            "confidence": round(block.confidence, 4) if hasattr(block, 'confidence') else None,
            "position": block.position if hasattr(block, 'position') else None,
        })

    return {
        "status": "ok",
        "regions": regions,
        "region_count": len(regions),
        "image_size": {"width": img.width, "height": img.height},
        "meta": {
            "file": str(path),
            "duration_ms": duration_ms,
            "engine": "surya_layout",
        }
    }


# ─────────────────────────────────────────────────────────
# Main OCR function
# ─────────────────────────────────────────────────────────

def ocr_image(
    image_path: str,
    languages: list[str] = None,
    detail: str = "standard",
    confidence_threshold: float = 0.1,
    engine: str = "auto",
) -> dict:
    """
    Extract text from an image file.

    Args:
        image_path: Path to image file (JPEG, PNG, BMP, TIFF, WebP)
        languages: OCR languages, default ["tr", "en"]
        detail: "simple" (text only), "standard" (text+confidence+bbox),
                "full" (everything including polygons)
        confidence_threshold: Minimum confidence (0.0-1.0)
        engine: "auto" (best available), "surya", "easyocr", "both" (compare)

    Returns:
        dict with: status, text, blocks, meta
    """
    image_path = _resolve_win_path(str(image_path).strip().strip('"').strip("'"))
    path = Path(image_path).expanduser().resolve()

    if not path.exists():
        return {"status": "error", "error": f"Dosya bulunamadı: {image_path}"}
    if not path.is_file():
        return {"status": "error", "error": f"Dosya değil: {image_path}"}
    if path.suffix.lower() not in VALID_EXTS:
        return {"status": "error",
                "error": f"Desteklenmeyen format: {path.suffix}. Desteklenen: {', '.join(VALID_EXTS)}"}

    if languages is None:
        languages = ["tr", "en"]

    # Resolve engine
    if engine == "auto":
        engine = _pick_engine()
    elif engine == "both":
        return _ocr_compare(path, languages, detail, confidence_threshold)

    if engine == "surya" and not _has_surya():
        return {"status": "error", "error": "Surya yüklü değil. 'pip install surya-ocr'"}
    if engine == "easyocr" and not _has_easyocr():
        return {"status": "error", "error": "EasyOCR yüklü değil. 'pip install easyocr'"}

    t0 = time.time()

    try:
        if engine == "surya":
            blocks, text_lines, total_raw = _ocr_surya(path, languages, detail, confidence_threshold)
        else:
            blocks, text_lines, total_raw = _ocr_easyocr(path, languages, detail, confidence_threshold)
    except Exception as e:
        return {"status": "error", "error": f"OCR hatası ({engine}): {e}"}

    duration_ms = int((time.time() - t0) * 1000)

    meta = {
        "file": str(path),
        "file_size_bytes": path.stat().st_size,
        "languages": languages,
        "engine": engine,
        "gpu": _gpu_available(),
        "duration_ms": duration_ms,
        "total_blocks": total_raw,
        "filtered_blocks": len(blocks),
        "confidence_threshold": confidence_threshold,
    }

    return {
        "status": "ok",
        "text": "\n".join(text_lines),
        "blocks": blocks,
        "meta": meta,
    }


def _ocr_compare(path: Path, languages: list[str], detail: str,
                 confidence_threshold: float) -> dict:
    """Run both engines and return side-by-side comparison."""
    results = {}

    for eng in ["easyocr", "surya"]:
        has_fn = _has_easyocr if eng == "easyocr" else _has_surya
        if not has_fn():
            results[eng] = {"status": "unavailable"}
            continue

        t0 = time.time()
        try:
            ocr_fn = _ocr_easyocr if eng == "easyocr" else _ocr_surya
            blocks, text_lines, total_raw = ocr_fn(path, languages, detail, confidence_threshold)
            dt = int((time.time() - t0) * 1000)
            results[eng] = {
                "text": "\n".join(text_lines),
                "blocks": blocks,
                "duration_ms": dt,
                "total_blocks": total_raw,
                "filtered_blocks": len(blocks),
            }
        except Exception as e:
            results[eng] = {"status": "error", "error": str(e)}

    return {
        "status": "ok",
        "mode": "comparison",
        "engines": results,
        "meta": {
            "file": str(path),
            "file_size_bytes": path.stat().st_size,
            "languages": languages,
            "gpu": _gpu_available(),
        }
    }


def ocr_image_simple(image_path: str, languages: list[str] = None,
                     engine: str = "auto") -> str:
    """Simple wrapper: returns just extracted text or error string."""
    result = ocr_image(image_path, languages=languages, detail="simple", engine=engine)
    if result["status"] == "error":
        return f"Error: {result['error']}"
    return result["text"]


# ─────────────────────────────────────────────────────────
# Cont tool interface
# ─────────────────────────────────────────────────────────

def ocr_tool(path: str, languages: str = "tr,en", detail: str = "standard",
             engine: str = "auto", layout: str = "false") -> str:
    """
    Cont tool entry point. Called by the tool dispatcher.

    Args:
        path: Image file path (relative to repo root or absolute)
        languages: Comma-separated language codes (default "tr,en")
        detail: "simple", "standard", or "full"
        engine: "auto", "surya", "easyocr", or "both"
        layout: "true" to get page layout analysis instead of OCR

    Returns:
        JSON string with OCR results
    """
    lang_list = [l.strip() for l in languages.split(",") if l.strip()]
    if not lang_list:
        lang_list = ["tr", "en"]

    if layout.lower() == "true":
        result = ocr_layout(path)
    else:
        result = ocr_image(path, languages=lang_list, detail=detail, engine=engine)

    return json.dumps(result, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────

def _cli_main():
    import argparse

    parser = argparse.ArgumentParser(
        description="OCR tool — extract text from images (EasyOCR + Surya)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m core.ocr photo.jpg                    # auto-select engine\n"
            "  python -m core.ocr photo.jpg --engine surya      # use Surya\n"
            "  python -m core.ocr scan.png --engine both        # compare engines\n"
            "  python -m core.ocr page.jpg --layout             # page layout analysis\n"
            "  python -m core.ocr receipt.jpg --json             # JSON output\n"
        )
    )
    parser.add_argument("image", help="Path to image file")
    parser.add_argument("--lang", default="tr,en",
                        help="Languages (comma-separated). Default: tr,en")
    parser.add_argument("--detail", choices=["simple", "standard", "full"],
                        default="standard", help="Detail level (default: standard)")
    parser.add_argument("--engine", choices=["auto", "easyocr", "surya", "both"],
                        default="auto", help="OCR engine (default: auto)")
    parser.add_argument("--layout", action="store_true",
                        help="Page layout analysis (Surya only)")
    parser.add_argument("--json", action="store_true",
                        help="Output raw JSON instead of formatted text")
    parser.add_argument("--threshold", type=float, default=0.1,
                        help="Minimum confidence threshold (0.0-1.0)")

    args = parser.parse_args()
    lang_list = [l.strip() for l in args.lang.split(",")]

    # Layout mode
    if args.layout:
        result = ocr_layout(args.image)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            _print_layout(result)
        return

    result = ocr_image(
        args.image,
        languages=lang_list,
        detail=args.detail,
        confidence_threshold=args.threshold,
        engine=args.engine,
    )

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif result.get("mode") == "comparison":
        _print_comparison(result)
    else:
        _print_ocr(result, args.detail)


def _print_ocr(result: dict, detail: str = "standard"):
    if result["status"] == "error":
        print(f"HATA: {result['error']}", file=sys.stderr)
        sys.exit(1)

    meta = result["meta"]
    engine_tag = meta.get("engine", "?").upper()
    print(f"📄 {meta['file']}")
    print(f"   Motor: {engine_tag}  |  GPU: {'✓' if meta['gpu'] else '✗'}  |  "
          f"{meta['duration_ms']}ms  |  {meta['filtered_blocks']} blok")
    print(f"   Diller: {', '.join(meta['languages'])}")
    print("─" * 60)

    if detail == "simple":
        print(result["text"])
    else:
        for block in result["blocks"]:
            conf = block["confidence"]
            if conf >= 0.8:
                marker = "🟢"
            elif conf >= 0.5:
                marker = "🟡"
            else:
                marker = "🔴"
            print(f"  {marker} [{conf:.0%}] {block['text']}")

    print("─" * 60)
    print(f"Toplam metin:\n{result['text']}")


def _print_comparison(result: dict):
    print(f"📄 {result['meta']['file']}")
    print(f"   GPU: {'✓' if result['meta']['gpu'] else '✗'}")
    print("═" * 60)

    for eng_name, eng_data in result["engines"].items():
        print(f"\n{'─' * 25} {eng_name.upper()} {'─' * 25}")
        if eng_data.get("status") in ("unavailable", "error"):
            print(f"  ⚠ {eng_data.get('error', 'Motor yüklü değil')}")
            continue

        print(f"  Süre: {eng_data['duration_ms']}ms  |  {eng_data['filtered_blocks']} blok")
        for block in eng_data["blocks"]:
            conf = block["confidence"]
            if conf >= 0.8:
                marker = "🟢"
            elif conf >= 0.5:
                marker = "🟡"
            else:
                marker = "🔴"
            print(f"    {marker} [{conf:.0%}] {block['text']}")

    print("═" * 60)


def _print_layout(result: dict):
    if result["status"] == "error":
        print(f"HATA: {result['error']}", file=sys.stderr)
        sys.exit(1)

    meta = result["meta"]
    size = result["image_size"]
    print(f"📐 {meta['file']}")
    print(f"   Boyut: {size['width']}x{size['height']}  |  {meta['duration_ms']}ms")
    print(f"   {result['region_count']} bölge tespit edildi")
    print("─" * 60)

    # Color-code by type
    type_colors = {
        "Text": "📝", "Title": "🏷️", "Table": "📊",
        "Figure": "🖼️", "Header": "📌", "Footer": "📎",
        "List": "📋", "Caption": "💬",
    }

    for region in result["regions"]:
        icon = type_colors.get(region["label"], "◻️")
        bbox = region["bbox"]
        conf = region.get("confidence")
        conf_str = f" [{conf:.0%}]" if conf is not None else ""
        print(f"  {icon} {region['label']}{conf_str}  @({bbox[0]},{bbox[1]})-({bbox[2]},{bbox[3]})")

    print("─" * 60)


if __name__ == "__main__":
    _cli_main()
