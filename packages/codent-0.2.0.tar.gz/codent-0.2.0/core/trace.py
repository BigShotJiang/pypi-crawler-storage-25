# core/trace.py
"""
Real-time trace output for LLM + tool call boundaries.

Levels:
  OFF     — zero overhead, no formatting, no hashing, no joins
  COMPACT — 2-4 technical lines per LLM turn (provider/model/latency/hash)
  STORY   — human-readable narrative blocks, Rich colored, grouped turns
  FULL    — COMPACT + last-k message context + response body previews

Output: stderr only (never stdout). Optional JSONL via --trace-file.

STORY mode suppresses COMPACT/FULL technical lines. It shows:
  - Grouped turn blocks with INPUT / INTENT / OUTPUT sections
  - Narrative tool beats (not raw TOOL→/TOOL← lines)
  - Memory inject visibility
"""

import atexit
import hashlib
import json
import re
import sys
import time
from datetime import datetime
from enum import IntEnum
from typing import Optional, TextIO


class TraceLevel(IntEnum):
    OFF = 0       # falsy → zero-cost guard
    COMPACT = 1
    STORY = 2
    FULL = 3


# ── Module-level singleton ──────────────────────────────────────

_level: TraceLevel = TraceLevel.OFF
_file: Optional[TextIO] = None
_max_lines: int = 4
_max_chars: int = 800
_last_k: int = 3
_run_id: str = ""
_turn_counter: int = 0

# Rich stderr console (lazy init, fallback to plain text)
_console = None  # type: ignore
_rich_available = False


def _init_rich():
    """Try to init Rich Console for stderr. Fallback to plain print."""
    global _console, _rich_available
    try:
        from rich.console import Console
        _console = Console(
            stderr=True, force_terminal=True,
            color_system="trueround" if False else "auto",
            width=120,
        )
        _rich_available = True
    except ImportError:
        _rich_available = False
        _console = None


def init_trace(
    level: TraceLevel = TraceLevel.OFF,
    trace_file: Optional[str] = None,
    max_lines: int = 4,
    max_chars: int = 800,
    last_k: int = 3,
    run_id: str = "",
):
    """Initialize trace system. Called once from main()."""
    global _level, _file, _max_lines, _max_chars, _last_k, _run_id, _turn_counter
    _level = level
    _max_lines = max_lines
    _max_chars = max_chars
    _last_k = last_k
    _run_id = run_id or datetime.now().strftime("%H%M%S")
    _turn_counter = 0
    if trace_file:
        _file = open(trace_file, "a", encoding="utf-8")
    if level != TraceLevel.OFF:
        _init_rich()


def _cleanup():
    global _file
    if _file:
        try:
            _file.close()
        except Exception:
            pass
        _file = None


atexit.register(_cleanup)


def is_off() -> bool:
    """Call-site guard: True when tracing is disabled."""
    return _level == TraceLevel.OFF


def get_level() -> TraceLevel:
    """Current trace level."""
    return _level


# ── Internal helpers ─────────────────────────────────────────────

def _emit(line: str):
    """Print plain text line to stderr. Used by COMPACT/FULL."""
    print(line, file=sys.stderr, flush=True)


def _rich(markup: str):
    """Print Rich-markup line to stderr. Falls back to plain if Rich unavailable."""
    if _rich_available and _console:
        _console.print(markup, highlight=False)
    else:
        # Strip Rich markup for plain fallback
        plain = re.sub(r"\[/?[a-z_ #0-9]+\]", "", markup)
        print(plain, file=sys.stderr, flush=True)


def _emit_jsonl(event: dict):
    """Write one JSONL event to trace file (if open)."""
    if _file is None:
        return
    event.setdefault("ts", datetime.now().isoformat())
    event.setdefault("run_id", _run_id)
    try:
        _file.write(json.dumps(event, ensure_ascii=False) + "\n")
        _file.flush()
    except Exception:
        pass


def _preview(text: str, max_chars: int = 160) -> str:
    """Truncate + collapse newlines for compact display."""
    if not text:
        return ""
    t = text.replace("\n", " ").replace("\r", "").replace("\t", " ")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > max_chars:
        return t[:max_chars] + "..."
    return t


_SECRET_RE = re.compile(
    r"((?:key|token|secret|password|cookie|authorization)\s*[=:]\s*)\S+",
    re.IGNORECASE,
)


def _sanitize(text: str) -> str:
    """Mask API keys, tokens, cookies, passwords."""
    return _SECRET_RE.sub(r"\1***", text)


def _detect_provider(base_url: str) -> str:
    """Infer provider from base_url."""
    if not base_url:
        return "unknown"
    u = base_url.lower()
    if "lmstudio" in u or ":1234" in u:
        return "lmstudio"
    if "api.openai.com" in u:
        return "openai"
    if "anthropic" in u:
        return "anthropic"
    if "localhost" in u or "127.0.0.1" in u:
        return "local"
    return "custom"


def _args_hash(args: dict) -> str:
    """Deterministic 8-char hash for tool args."""
    return hashlib.md5(
        json.dumps(args, ensure_ascii=False, sort_keys=True).encode()
    ).hexdigest()[:8]


def _roles_sig(messages: list) -> str:
    """Compact role signature: 's,u,a,t,...' (last 10)."""
    role_map = {"system": "s", "user": "u", "assistant": "a", "tool": "t"}
    roles = [role_map.get(m.get("role", "?"), "?") for m in messages[-10:]]
    return ",".join(roles)


def _cap(line: str, max_chars: int = 200) -> str:
    """Hard cap a line to max_chars, add '...' if truncated."""
    if len(line) > max_chars:
        return line[: max_chars - 3] + "..."
    return line


def _human_args(tool_name: str, args: dict) -> str:
    """Format tool args as human-readable short string."""
    if "path" in args:
        return str(args["path"])
    if "query" in args:
        return f'"{args["query"]}"'
    if "command" in args:
        return str(args["command"])[:80]
    if "url" in args:
        return str(args["url"])[:80]
    if "content" in args and "path" not in args:
        return _preview(str(args["content"]), 60)
    # Fallback: key=val pairs
    parts = []
    for k, v in list(args.items())[:3]:
        parts.append(f"{k}={_preview(str(v), 40)}")
    return ", ".join(parts) if parts else "()"


_ROLE_COLORS = {
    "system": "dim italic",
    "user": "bold cyan",
    "assistant": "bold green",
    "tool": "yellow",
}
_ROLE_TAGS = {"system": "S", "user": "U", "assistant": "A", "tool": "T"}


# ── Public hooks ─────────────────────────────────────────────────

def trace_llm_request(
    *,
    model: str,
    messages: list,
    tools_enabled: bool,
    tool_choice: Optional[str],
    base_url: str = "",
    iteration: int = 0,
):
    """Hook: BEFORE LLM API call. Caller must guard with is_off()."""
    if _level == TraceLevel.OFF:
        return

    global _turn_counter
    _turn_counter += 1

    provider = _detect_provider(base_url)
    msg_count = len(messages)
    roles = _roles_sig(messages)
    total_chars = sum(len(m.get("content", "") or "") for m in messages)
    est_tok = total_chars // 4
    tools_str = "on" if tools_enabled else "off"
    tc = tool_choice or "auto"

    if _level == TraceLevel.STORY:
        # ── STORY: grouped turn header + input section ──
        _rich("")
        _rich(f"[bold white on #333333] 🎬 TURN #{_turn_counter} [/bold white on #333333]"
              f"  [dim]{provider}[/dim] [bold]{model}[/bold]"
              f"  [dim]tools={tools_str}  ~{est_tok} tok[/dim]")

        # Section A: INPUT (to LLM) — last K messages
        _rich("[bold #6699cc]  🧠 INPUT (to LLM)[/bold #6699cc]")
        tail = messages[-_last_k:]
        for m in tail:
            role = m.get("role", "?")
            tag = _ROLE_TAGS.get(role, "?")
            color = _ROLE_COLORS.get(role, "dim")
            raw_content = m.get("content", "") or ""

            # Special: tool results show tool name
            if role == "tool":
                tool_id = m.get("tool_call_id", "")
                short = _sanitize(_preview(raw_content, 120))
                _rich(f"    [{color}]\\[T][/{color}] [dim]{short}[/dim]")
            else:
                short = _sanitize(_preview(raw_content, 140))
                _rich(f"    [{color}]\\[{tag}][/{color}] {short}")

    elif _level == TraceLevel.COMPACT or _level == TraceLevel.FULL:
        # ── COMPACT/FULL: technical one-liner ──
        _emit(
            f"LLM→ provider={provider} model={model} msgs={msg_count} "
            f"roles={roles} tools={tools_str} tool_choice={tc} est_tok_in={est_tok}"
        )
        if _level >= TraceLevel.FULL:
            _emit(f"  base_url={_sanitize(base_url)}")
            for m in messages[-_last_k:]:
                r = _ROLE_TAGS.get(m.get("role", "?"), "?")
                content = _sanitize(_preview(m.get("content", "") or "", 200))
                _emit(f"  [{r}] {content}")

    _emit_jsonl({
        "event": "llm_request",
        "provider": provider,
        "model": model,
        "msg_count": msg_count,
        "roles_sig": roles,
        "tools_enabled": tools_enabled,
        "tool_choice": tool_choice,
        "est_tok_in": est_tok,
    })


def trace_llm_response(
    *,
    content: str,
    tool_calls_count: int,
    finish_reason: str,
    latency_ms: int,
    tool_names: Optional[list] = None,
):
    """Hook: AFTER LLM API call returns. Caller must guard with is_off()."""
    if _level == TraceLevel.OFF:
        return

    out_chars = len(content or "")

    if _level == TraceLevel.STORY:
        # ── STORY: OUTPUT section ──
        _rich(f"[bold #66cc99]  🎭 OUTPUT (from LLM)[/bold #66cc99]"
              f"  [dim]{latency_ms}ms  {out_chars} chars[/dim]")

        if tool_calls_count:
            names = ", ".join(tool_names[:4]) if tool_names else f"{tool_calls_count} tool(s)"
            _rich(f"    [yellow]→ Tool calls: {names}[/yellow]")

        if content and content.strip():
            lines = content.strip().split("\n")
            for ln in lines[:_max_lines]:
                short = _sanitize(ln[:200])
                _rich(f"    [dim]{short}[/dim]")

    elif _level == TraceLevel.COMPACT or _level == TraceLevel.FULL:
        # ── COMPACT/FULL: technical one-liner ──
        line = f"LLM← stop={finish_reason} out_chars={out_chars} latency={latency_ms}ms"
        if tool_calls_count:
            line += f" tool_calls={tool_calls_count}"
        _emit(line)

        if _level >= TraceLevel.FULL and content:
            for ln in (content or "").split("\n")[:_max_lines]:
                _emit(f"  | {_sanitize(ln[:200])}")

    _emit_jsonl({
        "event": "llm_response",
        "finish_reason": finish_reason,
        "out_chars": out_chars,
        "latency_ms": latency_ms,
        "tool_calls_count": tool_calls_count,
    })


def trace_tool_call(
    *,
    tool_name: str,
    args: dict,
    call_id: str = "",
):
    """Hook: BEFORE tool execution. Caller must guard with is_off()."""
    if _level == TraceLevel.OFF:
        return

    h = _args_hash(args)

    if _level == TraceLevel.STORY:
        # ── STORY: narrative tool beat ──
        human = _sanitize(_human_args(tool_name, args))
        _rich(f"  [bold yellow]⚙️  {tool_name}[/bold yellow] [dim]{human}[/dim]")
    else:
        # ── COMPACT/FULL: technical ──
        prev = _sanitize(_preview(json.dumps(args, ensure_ascii=False), 160))
        _emit(f"TOOL→ {tool_name} args_hash={h} args_preview=\"{prev}\"")

    _emit_jsonl({
        "event": "tool_call",
        "tool_name": tool_name,
        "args_hash": h,
        "preview": _sanitize(_preview(json.dumps(args, ensure_ascii=False), 160))[:160],
        "call_id": call_id,
    })


def trace_tool_result(
    *,
    tool_name: str,
    result_chars: int,
    result_preview: str,
    error: Optional[str],
    latency_ms: int,
    call_id: str = "",
):
    """Hook: AFTER tool execution. Caller must guard with is_off()."""
    if _level == TraceLevel.OFF:
        return

    preview = _sanitize(_preview(result_preview, 120))

    if _level == TraceLevel.STORY:
        # ── STORY: narrative result ──
        if error:
            err_short = _sanitize(_preview(str(error), 80))
            _rich(f"    [bold red]❌ ERROR[/bold red] [dim]{err_short}  ({latency_ms}ms)[/dim]")
        else:
            _rich(f"    [green]✅ ok[/green] [dim]{result_chars} chars  {latency_ms}ms[/dim]"
                  f"  [dim italic]{preview[:80]}[/dim italic]")
    else:
        # ── COMPACT/FULL: technical ──
        status = "err" if error else "ok"
        line = f"TOOL← {status} {tool_name} chars={result_chars} latency={latency_ms}ms"
        if error:
            line += f" error={_preview(str(error), 60)}"
        else:
            line += f" preview=\"{preview}\""
        _emit(line)

        if _level >= TraceLevel.FULL and result_preview:
            for ln in result_preview.split("\n")[:_max_lines]:
                _emit(f"  | {_sanitize(ln[:200])}")

    _emit_jsonl({
        "event": "tool_result",
        "tool_name": tool_name,
        "chars": result_chars,
        "latency_ms": latency_ms,
        "ok": error is None,
        "preview": preview[:120],
        "call_id": call_id,
    })


# ── STORY-only hooks (suppressed in COMPACT/FULL) ───────────────

def trace_story_intent(
    *,
    content: str,
    tool_names: list,
    tool_args_previews: list,
):
    """STORY: after LLM response with tool_calls — show intent + next chain."""
    if _level < TraceLevel.STORY:
        return
    if not tool_names:
        return

    # Extract intent: first meaningful line from LLM content
    intent = ""
    if content:
        for ln in content.split("\n"):
            stripped = ln.strip()
            if stripped and len(stripped) > 5:
                intent = _sanitize(_preview(stripped, 120))
                break

    if _level == TraceLevel.STORY:
        # Build human chain
        chain_parts = []
        for i, name in enumerate(tool_names[:3]):
            arg_prev = ""
            if i < len(tool_args_previews):
                arg_prev = _sanitize(_preview(tool_args_previews[i], 50))
            chain_parts.append(f"[yellow]{name}[/yellow] [dim]{arg_prev}[/dim]" if arg_prev else f"[yellow]{name}[/yellow]")

        next_chain = " → ".join(chain_parts)
        _rich(f"[bold #6699cc]  🧭 INTENT[/bold #6699cc]")
        if intent:
            _rich(f"    [italic]{intent}[/italic]")
        _rich(f"    Next: {next_chain}")
    else:
        # FULL: compact one-liner (kept for backward compat)
        if not intent:
            intent = "(implicit)"
        names = "→".join(tool_names[:3])
        _emit(_cap(f"STORY: intent={intent} | next={names}"))

    _emit_jsonl({
        "event": "story",
        "phase": "intent",
        "intent": (intent or "(implicit)")[:200],
        "tools": tool_names[:3],
    })


def trace_story_observed(
    *,
    tool_name: str,
    result_preview: str,
    success: bool,
    next_action: str = "continue",
):
    """STORY: after tool result — what was observed. Suppressed in COMPACT."""
    if _level < TraceLevel.STORY:
        return

    obs = _sanitize(_preview(result_preview, 120))

    if _level == TraceLevel.STORY:
        # Narrative observed — already shown inline via trace_tool_result STORY path
        # Only emit to JSONL; terminal output handled by trace_tool_result
        pass
    else:
        # FULL: one-liner
        status = "✓" if success else "✗"
        _emit(_cap(f"STORY: {status} {tool_name} → {obs} | next={next_action}"))

    _emit_jsonl({
        "event": "story",
        "phase": "observed",
        "tool_name": tool_name,
        "success": success,
        "preview": obs[:120],
        "next_action": next_action,
    })


# ── Memory trace hooks ──────────────────────────────────────────

def trace_memory_recall(
    *,
    source: str,
    entity_count: int,
    result_count: int,
    top_snippets: Optional[list] = None,
):
    """Hook: after Phase-0 or runtime memory recall completes."""
    if _level == TraceLevel.OFF:
        return

    if _level == TraceLevel.STORY:
        if result_count == 0:
            _rich(f"  [dim]🧠 MEMORY ({source}): no results[/dim]")
        else:
            _rich(f"  [bold #cc99ff]🧠 MEMORY ({source})[/bold #cc99ff]"
                  f"  [dim]{entity_count} entities → {result_count} results[/dim]")
            for snip in (top_snippets or [])[:2]:
                level = snip.get("level", "?")
                content = _sanitize(_preview(snip.get("content", ""), 120))
                color = "green" if level == "HIGH" else "dim"
                _rich(f"    [{color}]\\[{level}][/{color}] {content}")
    else:
        _emit(f"MEMORY {source}: {entity_count} entities → {result_count} results")
        for snip in (top_snippets or [])[:2]:
            level = snip.get("level", "?")
            content = _sanitize(_preview(snip.get("content", ""), 100))
            _emit(f"  [{level}] {content}")

    _emit_jsonl({
        "event": "memory_recall",
        "source": source,
        "entity_count": entity_count,
        "result_count": result_count,
    })


def trace_memory_search(*, query: str, limit: int):
    """Hook: when memory_hybrid_search is invoked."""
    if _level == TraceLevel.OFF:
        return

    short_q = _sanitize(_preview(query, 80))
    if _level == TraceLevel.STORY:
        _rich(f"  [dim]🔍 memory search: \"{short_q}\" (limit={limit})[/dim]")
    else:
        _emit(f"MEMORY search: \"{short_q}\" limit={limit}")

    _emit_jsonl({"event": "memory_search", "query": short_q, "limit": limit})


def trace_memory_write(*, kind: str, key: str):
    """Hook: when a memory record is written."""
    if _level == TraceLevel.OFF:
        return

    short_key = _sanitize(_preview(key, 60))
    if _level == TraceLevel.STORY:
        _rich(f"  [dim]💾 memory write: {kind} → {short_key}[/dim]")
    else:
        _emit(f"MEMORY write: kind={kind} key={short_key}")

    _emit_jsonl({"event": "memory_write", "kind": kind, "key": short_key})
