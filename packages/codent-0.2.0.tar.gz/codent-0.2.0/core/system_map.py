"""
Cont System Map — Filesystem indexer and search.
Builds and maintains a persistent index of the user's filesystem.
Searches are instant (<10ms) via SQLite instead of slow find/grep.
"""

import os
import sqlite3
import time
import json
import subprocess
import threading
from pathlib import Path
from datetime import datetime, timedelta

# Roots to scan
SCAN_ROOTS = [
    os.path.expanduser("~/projects"),
    os.path.expanduser("~/Documents"),
    os.path.expanduser("~/Desktop"),
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~"),  # home (shallow)
]

# Directories to skip
SKIP_DIRS = {
    '.git', '.venv', 'venv', 'node_modules', '__pycache__',
    '.pytest_cache', '.mypy_cache', '.cache', '.local',
    '.npm', '.cargo', '.rustup', 'site-packages',
    '.config/chromium', '.config/google-chrome',
    'snap', '.snap',
}

# Extensions to skip (binary/media)
SKIP_EXTENSIONS = {
    '.pyc', '.pyo', '.so', '.o', '.a', '.dylib',
    '.whl', '.egg', '.tar', '.gz', '.zip', '.7z',
    '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico',
    '.mp3', '.mp4', '.avi', '.mkv', '.mov',
    '.bin', '.dat', '.db', '.sqlite',
}

DB_PATH = os.path.expanduser("~/.config/cont/system_map.db")


def get_db():
    """Get or create the system map database."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("""
        CREATE TABLE IF NOT EXISTS fs_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            name_lower TEXT NOT NULL,
            extension TEXT,
            entry_type TEXT NOT NULL,
            size INTEGER DEFAULT 0,
            modified_at TEXT,
            parent_dir TEXT,
            depth INTEGER,
            project TEXT,
            indexed_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            root_path TEXT NOT NULL,
            entries_found INTEGER,
            duration_ms INTEGER,
            scanned_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS project_info (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            languages TEXT,
            file_count INTEGER,
            last_modified TEXT,
            indexed_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_name_lower ON fs_entries(name_lower)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_extension ON fs_entries(extension)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_parent ON fs_entries(parent_dir)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_project ON fs_entries(project)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_type ON fs_entries(entry_type)")
    db.commit()
    return db


def detect_project(path: str) -> str:
    """Detect which project a path belongs to."""
    home = os.path.expanduser("~")
    rel = os.path.relpath(path, home)
    rel_parts = rel.split(os.sep)

    if len(rel_parts) >= 2 and rel_parts[0] == "projects":
        return rel_parts[1]
    return rel_parts[0] if rel_parts else ""


def scan_directory(root: str, max_depth: int = 6, db=None):
    """Scan a directory tree and index all entries."""
    if db is None:
        db = get_db()

    root = os.path.expanduser(root)
    if not os.path.isdir(root):
        return 0

    start = time.time()
    count = 0
    batch = []

    skip_args = " ".join(f'-not -path "*/{d}/*"' for d in SKIP_DIRS)
    cmd = f'find "{root}" -maxdepth {max_depth} {skip_args} 2>/dev/null'

    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=30
        )
        paths = result.stdout.strip().split('\n') if result.stdout.strip() else []
    except subprocess.TimeoutExpired:
        paths = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            depth = dirpath.replace(root, '').count(os.sep)
            if depth >= max_depth:
                dirnames.clear()
                continue
            for name in dirnames + filenames:
                paths.append(os.path.join(dirpath, name))

    for full_path in paths:
        if not full_path or full_path == root:
            continue

        name = os.path.basename(full_path)
        if not name:
            continue

        ext = os.path.splitext(name)[1].lower() if '.' in name else ''
        if ext in SKIP_EXTENSIONS:
            continue

        entry_type = 'dir' if os.path.isdir(full_path) else 'file'

        try:
            stat = os.stat(full_path)
            size = stat.st_size if entry_type == 'file' else 0
            modified = datetime.fromtimestamp(stat.st_mtime).isoformat()
        except (OSError, PermissionError):
            size = 0
            modified = None

        parent = os.path.dirname(full_path)
        depth = full_path.replace(root, '').count(os.sep)
        project = detect_project(full_path)

        batch.append((
            full_path, name, name.lower(), ext, entry_type,
            size, modified, parent, depth, project
        ))
        count += 1

        if len(batch) >= 1000:
            _insert_batch(db, batch)
            batch = []

    if batch:
        _insert_batch(db, batch)

    duration_ms = int((time.time() - start) * 1000)
    db.execute(
        "INSERT INTO scan_history (root_path, entries_found, duration_ms) VALUES (?, ?, ?)",
        (root, count, duration_ms)
    )
    db.commit()

    return count


def _insert_batch(db, batch):
    """Batch insert/update entries."""
    db.executemany("""
        INSERT OR REPLACE INTO fs_entries
        (path, name, name_lower, extension, entry_type, size, modified_at,
         parent_dir, depth, project, indexed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    """, batch)


def scan_all(verbose=False):
    """Full system scan."""
    db = get_db()
    total = 0

    for root in SCAN_ROOTS:
        if not os.path.isdir(root):
            continue
        max_depth = 2 if root == os.path.expanduser("~") else 6

        if verbose:
            print(f"  Scanning: {root} (max_depth={max_depth})")

        count = scan_directory(root, max_depth=max_depth, db=db)
        total += count

        if verbose:
            print(f"    -> {count} entries")

    _index_projects(db, verbose)

    if verbose:
        print(f"  Total: {total} entries indexed")

    return total


def _index_projects(db, verbose=False):
    """Detect and catalog projects in ~/projects/."""
    projects_dir = os.path.expanduser("~/projects")
    if not os.path.isdir(projects_dir):
        return

    lang_map = {
        '.py': 'Python', '.js': 'JavaScript', '.ts': 'TypeScript',
        '.json': 'JSON', '.md': 'Markdown', '.yaml': 'YAML',
        '.yml': 'YAML', '.html': 'HTML', '.css': 'CSS',
        '.sh': 'Shell', '.sql': 'SQL', '.rs': 'Rust',
        '.go': 'Go', '.java': 'Java', '.rb': 'Ruby',
    }

    for name in os.listdir(projects_dir):
        project_path = os.path.join(projects_dir, name)
        if not os.path.isdir(project_path):
            continue

        file_count = db.execute(
            "SELECT COUNT(*) FROM fs_entries WHERE project = ? AND entry_type = 'file'",
            (name,)
        ).fetchone()[0]

        languages = []
        ext_counts = db.execute("""
            SELECT extension, COUNT(*) as cnt FROM fs_entries
            WHERE project = ? AND entry_type = 'file' AND extension != ''
            GROUP BY extension ORDER BY cnt DESC LIMIT 5
        """, (name,)).fetchall()

        for row in ext_counts:
            lang = lang_map.get(row[0], row[0])
            if lang:
                languages.append(lang)

        description = ""
        readme_path = os.path.join(project_path, "README.md")
        if os.path.isfile(readme_path):
            try:
                with open(readme_path, 'r', errors='ignore') as f:
                    first_lines = f.read(500)
                    for line in first_lines.split('\n'):
                        line = line.strip()
                        if line and not line.startswith('#') and len(line) > 10:
                            description = line[:200]
                            break
            except Exception:
                pass

        last_mod = db.execute(
            "SELECT MAX(modified_at) FROM fs_entries WHERE project = ?",
            (name,)
        ).fetchone()[0]

        db.execute("""
            INSERT OR REPLACE INTO project_info
            (path, name, description, languages, file_count, last_modified)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            project_path, name, description,
            json.dumps(languages), file_count, last_mod
        ))

    db.commit()


# ──────────────────────────────────────────
# SEARCH FUNCTIONS
# ──────────────────────────────────────────

def _query_variants(query: str) -> list:
    """Generate fuzzy name variants for search.
    'kosgebot' -> ['%kosgebot%', '%kosgeb%bot%'] etc."""
    import re
    q = query.lower()
    variants = [f"%{q}%"]

    # Split on common word boundaries and rejoin with %
    parts = re.split(r'[-_.\s]', q)
    if len(parts) > 1:
        variants.append("%" + "%".join(parts) + "%")

    # Also try splitting long words at likely boundaries (3+ chars each side)
    if len(parts) == 1 and len(q) >= 6:
        # Try splitting at each position (min 3 chars per part)
        for i in range(3, len(q) - 2):
            variants.append(f"%{q[:i]}%{q[i:]}%")

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for v in variants:
        if v not in seen:
            seen.add(v)
            unique.append(v)
    return unique


def find_in_map(query: str, entry_type: str = None,
                extension: str = None, project: str = None,
                limit: int = 20) -> list:
    """Search the filesystem index. Instant results with fuzzy matching."""
    db = get_db()

    # Build name match with variants (fuzzy)
    variants = _query_variants(query)
    name_conditions = ["name_lower LIKE ?"] * len(variants)
    name_clause = "(" + " OR ".join(name_conditions) + ")"
    params = list(variants)

    # Additional filters
    extra = []
    if entry_type:
        extra.append("entry_type = ?")
        params.append(entry_type)

    if extension:
        if not extension.startswith('.'):
            extension = f'.{extension}'
        extra.append("extension = ?")
        params.append(extension)

    if project:
        # Search both project field AND full path (subfolders like kosgeb-bot)
        extra.append("(project LIKE ? OR path LIKE ?)")
        params.extend([f"%{project}%", f"%{project}%"])

    where = name_clause
    if extra:
        where += " AND " + " AND ".join(extra)

    rows = db.execute(f"""
        SELECT path, name, entry_type, size, modified_at, project
        FROM fs_entries
        WHERE {where}
        ORDER BY
            CASE WHEN name_lower = ? THEN 0 ELSE 1 END,
            modified_at DESC
        LIMIT ?
    """, params + [query.lower(), limit]).fetchall()

    return [dict(r) for r in rows]


def find_by_extension(ext: str, project: str = None, limit: int = 50) -> list:
    """Find all files with a given extension."""
    db = get_db()

    if not ext.startswith('.'):
        ext = f'.{ext}'

    if project:
        rows = db.execute("""
            SELECT path, name, size, modified_at, project
            FROM fs_entries
            WHERE extension = ? AND (project LIKE ? OR path LIKE ?) AND entry_type = 'file'
            ORDER BY modified_at DESC LIMIT ?
        """, (ext, f"%{project}%", f"%{project}%", limit)).fetchall()
    else:
        rows = db.execute("""
            SELECT path, name, size, modified_at, project
            FROM fs_entries
            WHERE extension = ? AND entry_type = 'file'
            ORDER BY modified_at DESC LIMIT ?
        """, (ext, limit)).fetchall()

    return [dict(r) for r in rows]


def get_project_info(name: str = None) -> list:
    """Get info about projects."""
    db = get_db()

    if name:
        rows = db.execute("""
            SELECT * FROM project_info
            WHERE name LIKE ? OR path LIKE ?
            ORDER BY last_modified DESC
        """, (f"%{name}%", f"%{name}%")).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM project_info ORDER BY last_modified DESC"
        ).fetchall()

    return [dict(r) for r in rows]


def get_directory_tree(path: str, max_depth: int = 3) -> list:
    """Get directory tree from index."""
    db = get_db()

    rows = db.execute("""
        SELECT path, name, entry_type, size
        FROM fs_entries
        WHERE path LIKE ? AND depth <= ?
        ORDER BY path
    """, (f"{path}%", max_depth)).fetchall()

    return [dict(r) for r in rows]


def get_stats() -> dict:
    """Get index statistics."""
    db = get_db()

    total = db.execute("SELECT COUNT(*) FROM fs_entries").fetchone()[0]
    files = db.execute(
        "SELECT COUNT(*) FROM fs_entries WHERE entry_type='file'"
    ).fetchone()[0]
    dirs = db.execute(
        "SELECT COUNT(*) FROM fs_entries WHERE entry_type='dir'"
    ).fetchone()[0]
    projects = db.execute("SELECT COUNT(*) FROM project_info").fetchone()[0]
    last_scan = db.execute(
        "SELECT MAX(scanned_at) FROM scan_history"
    ).fetchone()[0]

    return {
        "total_entries": total,
        "files": files,
        "directories": dirs,
        "projects": projects,
        "last_scan": last_scan,
    }


def needs_update() -> bool:
    """Check if index needs updating (older than 1 hour)."""
    db = get_db()
    last = db.execute(
        "SELECT MAX(scanned_at) FROM scan_history"
    ).fetchone()[0]

    if not last:
        return True

    last_dt = datetime.fromisoformat(last)
    return datetime.now() - last_dt > timedelta(hours=1)


def auto_update_if_needed(verbose=False):
    """Update index if stale. Called on Cont startup."""
    if needs_update():
        if verbose:
            import sys
            print("System map updating...", file=sys.stderr, flush=True)
        scan_all(verbose=verbose)
    return get_stats()


# ──────────────────────────────────────────
# FILE WATCHER
# ──────────────────────────────────────────

class FileWatcher:
    """inotifywait-based filesystem watcher. Falls back to polling."""

    def __init__(self, watch_roots=None):
        self.watch_roots = watch_roots or SCAN_ROOTS
        self.running = False
        self._thread = None
        self._process = None

    def start(self):
        """Start watching in background thread."""
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop watching."""
        self.running = False
        if self._process:
            self._process.terminate()

    def _watch_loop(self):
        """Main watch loop using inotifywait."""
        paths = [p for p in self.watch_roots if os.path.isdir(p)]
        if not paths:
            return

        excludes = "|".join(SKIP_DIRS)

        cmd = [
            "inotifywait",
            "-m", "-r",
            "--format", "%w%f|%e",
            "--exclude", f"({excludes})",
            "-e", "create",
            "-e", "delete",
            "-e", "move",
            "-e", "modify",
        ] + paths

        try:
            self._process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )

            db = get_db()
            batch = []
            last_flush = time.time()

            for line in self._process.stdout:
                if not self.running:
                    break

                line = line.strip()
                if not line or "|" not in line:
                    continue

                path, events = line.rsplit("|", 1)

                ext = os.path.splitext(path)[1].lower()
                if ext in SKIP_EXTENSIONS:
                    continue

                if "DELETE" in events or "MOVED_FROM" in events:
                    batch.append(("DELETE", path))
                elif "CREATE" in events or "MOVED_TO" in events or "MODIFY" in events:
                    batch.append(("UPSERT", path))

                if len(batch) >= 50 or (time.time() - last_flush) > 2:
                    self._flush_batch(db, batch)
                    batch = []
                    last_flush = time.time()

            if batch:
                self._flush_batch(db, batch)

        except FileNotFoundError:
            self._poll_loop()
        except Exception:
            pass

    def _flush_batch(self, db, batch):
        """Apply batch of changes to DB."""
        for action, path in batch:
            try:
                if action == "DELETE":
                    db.execute("DELETE FROM fs_entries WHERE path = ?", (path,))
                elif action == "UPSERT":
                    if os.path.exists(path):
                        name = os.path.basename(path)
                        entry_type = 'dir' if os.path.isdir(path) else 'file'
                        ext = os.path.splitext(name)[1].lower() if '.' in name else ''
                        try:
                            stat = os.stat(path)
                            size = stat.st_size if entry_type == 'file' else 0
                            modified = datetime.fromtimestamp(stat.st_mtime).isoformat()
                        except OSError:
                            size = 0
                            modified = None

                        parent = os.path.dirname(path)
                        project = detect_project(path)

                        db.execute("""
                            INSERT OR REPLACE INTO fs_entries
                            (path, name, name_lower, extension, entry_type,
                             size, modified_at, parent_dir, depth, project, indexed_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
                        """, (
                            path, name, name.lower(), ext, entry_type,
                            size, modified, parent, 0, project
                        ))
            except Exception:
                continue

        try:
            db.commit()
        except Exception:
            pass

    def _poll_loop(self):
        """Fallback: poll for changes every 5 minutes."""
        while self.running:
            time.sleep(300)
            try:
                scan_all(verbose=False)
            except Exception:
                pass


# Global watcher
_watcher = None


def ensure_watcher_running():
    """Ensure the file watcher is running."""
    global _watcher
    if _watcher is None or not _watcher.running:
        _watcher = FileWatcher()
        _watcher.start()


def ensure_index_exists():
    """
    Called on Cont startup. Initial scan if empty, then start watcher.
    """
    db = get_db()
    count = db.execute("SELECT COUNT(*) FROM fs_entries").fetchone()[0]

    if count == 0:
        import sys
        print("System map: initial scan...", file=sys.stderr, flush=True)
        scan_all(verbose=False)
        stats = get_stats()
        print(f"System map ready: {stats['files']} files, "
              f"{stats['projects']} projects", file=sys.stderr, flush=True)

    ensure_watcher_running()
