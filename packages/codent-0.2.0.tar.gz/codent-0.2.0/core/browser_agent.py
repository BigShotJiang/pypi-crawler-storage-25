# core/browser_agent.py
"""
Autonomous browser navigation agent.

When Cont needs to interact with an unknown website, this agent:
1. Opens the page
2. Observes the DOM structure (inputs, buttons, links, tables)
3. Asks GPT-4o-mini for the next action
4. Executes the action via Playwright
5. Checks if the goal was achieved
6. Repeats until success or max steps

Successful navigation paths are saved as site-specific recipes
for future deterministic use.
"""

import json
import time
import re
import os
from typing import Optional, Dict, List
from pathlib import Path


# ============================================
# DOM OBSERVER — Structured page analysis
# ============================================

def observe_page(browser) -> Dict:
    """
    Analyze current page structure.
    Returns structured info about what's on the page.
    """
    result = browser.evaluate('''
    (function() {
        var obs = {};

        // Page basics
        obs.url = window.location.href;
        obs.title = document.title;

        // Inputs
        obs.inputs = Array.from(document.querySelectorAll(
            "input:not([type=hidden]), textarea, select"
        )).map(function(el) {
            return {
                tag: el.tagName,
                type: el.type || "",
                id: el.id || "",
                name: el.name || "",
                placeholder: el.placeholder || "",
                value: el.value || "",
                selector: el.id ? "#" + el.id :
                    (el.name ? "[name='" + el.name + "']" : "")
            };
        }).slice(0, 10);

        // Buttons
        obs.buttons = Array.from(document.querySelectorAll(
            "button, input[type=submit], [role=button]"
        )).filter(function(el) {
            return el.offsetHeight > 0;
        }).map(function(el) {
            return {
                text: el.textContent.trim().substring(0, 60),
                type: el.type || "",
                id: el.id || "",
                cls: el.className.substring(0, 60),
                selector: el.id ? "#" + el.id :
                    (el.textContent.trim() ?
                        "button" : "button." + el.className.split(" ")[0])
            };
        }).slice(0, 15);

        // Links
        obs.links = Array.from(document.querySelectorAll("a"))
        .filter(function(a) {
            return a.offsetHeight > 0 && a.textContent.trim().length > 2;
        }).map(function(a) {
            return {
                text: a.textContent.trim().substring(0, 60),
                href: a.href
            };
        }).slice(0, 20);

        // Tables/grids
        obs.tables = Array.from(document.querySelectorAll(
            "table, [role=grid], .dx-datagrid"
        )).map(function(t) {
            var rows = t.querySelectorAll("tr");
            var headers = Array.from(
                rows[0] ? rows[0].querySelectorAll("th, td") : []
            ).map(function(h) {
                return h.textContent.trim().substring(0, 30);
            });
            return {
                rows: rows.length,
                headers: headers,
                hasData: rows.length > 1
            };
        }).slice(0, 3);

        // Popups/modals
        obs.modals = Array.from(document.querySelectorAll(
            ".modal, [role=dialog], .dx-popup, .dx-overlay-content"
        )).filter(function(el) {
            return el.offsetHeight > 0;
        }).map(function(el) {
            return {
                cls: el.className.substring(0, 60),
                text: el.textContent.trim().substring(0, 300),
                hasContent: el.textContent.trim().length > 50
            };
        });

        // Page text summary (first 500 chars)
        obs.textPreview = document.body.innerText.substring(0, 500);

        return obs;
    })()
    ''')

    return result.get("result", {}) if result.get("success") else {}


# ============================================
# ACTION EXECUTOR — Run browser actions
# ============================================

def execute_action(browser, action: Dict) -> Dict:
    """
    Execute a single browser action.

    Action types:
    - type: {selector, text} — type into input
    - click: {selector} — click element
    - submit_search: {selector, text} — SPA-safe search submit
    - extract_text: {selector} — get text content
    - extract_popup: {} — get popup/modal content
    - click_table_button: {row_contains, button_selector} — click button in table row
    - wait: {ms} — wait milliseconds
    - screenshot: {path} — take screenshot
    """
    action_type = action.get("action", "")

    try:
        if action_type == "type":
            result = browser.type_text(action["selector"], action["text"])
            ok = result.get("success", False) if isinstance(result, dict) else True
            return {"success": ok, "action": action_type}

        elif action_type == "click":
            browser.click(action["selector"])
            page = browser._run(browser._ensure_page())
            browser._run(page.wait_for_timeout(2000))
            return {"success": True, "action": action_type}

        elif action_type == "submit_search":
            # SPA-safe: set value via JS + trigger events
            selector = action["selector"]
            # Escape text for JS injection
            text = action["text"].replace("\\", "\\\\").replace('"', '\\"')

            browser.evaluate(f'''
                var input = document.querySelector("{selector}");
                if (input) {{
                    var setter = Object.getOwnPropertyDescriptor(
                        window.HTMLInputElement.prototype, "value").set;
                    setter.call(input, "{text}");
                    input.dispatchEvent(new Event("input", {{ bubbles: true }}));
                    input.dispatchEvent(new Event("change", {{ bubbles: true }}));
                    input.dispatchEvent(new KeyboardEvent("keypress", {{
                        key: "Enter", code: "Enter", keyCode: 13,
                        which: 13, bubbles: true
                    }}));
                }}
            ''')
            page = browser._run(browser._ensure_page())
            browser._run(page.wait_for_timeout(3000))
            return {"success": True, "action": action_type}

        elif action_type == "extract_text":
            selector = action.get("selector")
            result = browser.get_text(selector)
            text = result.get("text", "") if isinstance(result, dict) else str(result)
            return {"success": bool(text), "action": action_type,
                    "text": text[:5000]}

        elif action_type == "extract_popup":
            result = browser.evaluate('''
                var popup = document.querySelector(
                    ".dx-overlay-content.dx-state-focused, " +
                    ".modal.show .modal-body, " +
                    "[role=dialog]:not([aria-hidden=true])"
                );
                popup ? popup.textContent.trim() : "";
            ''')
            text = result.get("result", "")
            return {"success": bool(text), "action": action_type,
                    "text": text[:10000]}

        elif action_type == "click_table_button":
            row_text = action.get("row_contains", "").replace("\\", "\\\\").replace('"', '\\"')
            button_selector = action.get("button_selector", "button")

            browser.evaluate(f'''
                var rows = document.querySelectorAll("tr");
                for (var r of rows) {{
                    if (r.textContent.includes("{row_text}")) {{
                        var btn = r.querySelector("{button_selector}") ||
                                  r.querySelector("button") ||
                                  r.querySelector(".dx-button");
                        if (btn) {{ btn.click(); break; }}
                    }}
                }}
            ''')
            page = browser._run(browser._ensure_page())
            browser._run(page.wait_for_timeout(3000))
            return {"success": True, "action": action_type}

        elif action_type == "wait":
            ms = min(action.get("ms", 2000), 10000)
            page = browser._run(browser._ensure_page())
            browser._run(page.wait_for_timeout(ms))
            return {"success": True, "action": action_type}

        elif action_type == "screenshot":
            path = action.get("path", "/tmp/browser_screenshot.png")
            browser.screenshot(path)
            return {"success": True, "action": action_type, "path": path}

        else:
            return {"success": False, "error": f"Unknown action: {action_type}"}

    except Exception as e:
        error_msg = f"{type(e).__name__}: {str(e)[:200]}"
        return {"success": False, "error": error_msg, "action": action_type}


# ============================================
# PLANNER — Asks GPT-4o-mini for next action
# ============================================

PLANNER_SYSTEM = """\
Sen bir web tarayıcı pilotusun. Kullanıcının hedefine ulaşmak için
tarayıcıda ne yapılması gerektiğini planlıyorsun.

Sana sayfanın yapısı (inputs, buttons, links, tables, modals) verilecek.
Sen bir SONRAKİ EYLEM döndüreceksin.

EYLEM TİPLERİ:
1. {"action": "submit_search", "selector": "#inputId", "text": "aranacak"}
   — SPA-safe arama (React/Angular/Vue siteleri için)

2. {"action": "click", "selector": "CSS_SELECTOR"}
   — Bir elemente tıkla

3. {"action": "click_table_button", "row_contains": "satir metni", "button_selector": "#buton"}
   — Tablodaki belirli satırdaki butona tıkla

4. {"action": "extract_text", "selector": "CSS_SELECTOR"}
   — Bir elementin metnini çek

5. {"action": "extract_popup"}
   — Açık popup/modal içeriğini çek

6. {"action": "wait", "ms": 3000}
   — Bekle (sayfa yüklenmesi için)

7. {"action": "done", "status": "success", "summary": "ne bulundu"}
   — Hedef tamamlandı

8. {"action": "done", "status": "failed", "reason": "neden başarısız"}
   — Hedefe ulaşılamadı

KURALLAR:
- Sayfada arama inputu varsa ve henüz aranmadıysa, ÖNCE ara
- SPA sitelerde (Angular, React, Vue) submit_search kullan (normal type+click çalışmaz)
- Tablo varsa ve veri gösteriyorsa, ilgili satırdaki butona tıkla
- Popup/modal açıldıysa extract_popup ile içeriği çek
- SADECE JSON döndür, başka hiçbir şey yazma
- Her seferinde TEK bir eylem döndür
"""


def plan_next_action(observation: Dict, goal: str, history: List[Dict],
                     api_key: str) -> Optional[Dict]:
    """Ask GPT-4o-mini for the next browser action."""
    import httpx

    prompt = f"""HEDEF: {goal}

SAYFA DURUMU:
URL: {observation.get('url', '?')}
Başlık: {observation.get('title', '?')}

INPUTLAR:
{json.dumps(observation.get('inputs', []), ensure_ascii=False, indent=2)}

BUTONLAR:
{json.dumps(observation.get('buttons', []), ensure_ascii=False, indent=2)}

TABLOLAR:
{json.dumps(observation.get('tables', []), ensure_ascii=False, indent=2)}

MODALLER/POPUPLAR:
{json.dumps(observation.get('modals', []), ensure_ascii=False, indent=2)}

LİNKLER (ilk 10):
{json.dumps(observation.get('links', [])[:10], ensure_ascii=False, indent=2)}

SAYFA ÖNİZLEME:
{observation.get('textPreview', '')[:300]}

ÖNCEKİ ADIMLAR ({len(history)} adım):
{json.dumps([{"action": h.get("action", "?"), "success": h.get("success"), **( {"warning": h["_warning"]} if "_warning" in h else {} )} for h in history[-5:]], ensure_ascii=False)}

Sonraki eylem ne olmalı? SADECE JSON döndür."""

    try:
        response = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "gpt-4o-mini",
                "messages": [
                    {"role": "system", "content": PLANNER_SYSTEM},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": 500,
                "temperature": 0.1,
            },
            timeout=30,
        )

        data = response.json()
        text = data["choices"][0]["message"]["content"]

        # Strip markdown fences
        text = text.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        match = re.search(r'\{[^{}]+\}', text)
        if match:
            return json.loads(match.group())

        return json.loads(text)

    except Exception as e:
        print(f"  ⚠️ Planner hatası: {type(e).__name__}: {str(e)[:100]}")
        return None


# ============================================
# BROWSER AGENT — Main orchestrator
# ============================================

class BrowserAgent:
    """
    Autonomous browser navigation agent.
    Uses observe-plan-act-verify loop.
    """

    def __init__(self, api_key=None, max_steps=10):
        self.api_key = api_key
        self.max_steps = max_steps
        self.history = []

    def run(self, url: str, goal: str, save_recipe=True) -> Dict:
        """
        Navigate to URL and achieve goal.

        Returns: {
            "success": bool,
            "content": str (extracted content),
            "steps": list (action history),
            "recipe_saved": bool,
        }
        """
        from core.browser import Browser
        from core.teacher import get_api_key

        api_key = self.api_key or get_api_key()
        if not api_key:
            return {"success": False, "error": "API key gerekli (teacher/planner için)"}

        browser = Browser.get_instance()
        self.history = []
        content = ""

        try:
            # Step 0: Open URL
            print(f"  🌐 Açılıyor: {url}")
            open_result = browser.open(url)
            if not open_result.get("success"):
                return {"success": False, "error": open_result.get("error", "Sayfa açılamadı")}

            page = browser._run(browser._ensure_page())
            browser._run(page.wait_for_timeout(2000))

            _recent_action_sigs: list[tuple] = []  # Loop detector

            for step in range(self.max_steps):
                # 1. OBSERVE
                obs = observe_page(browser)
                if not obs:
                    print(f"  ⚠️ Sayfa okunamadı")
                    break

                # 2. PLAN
                print(f"  🤖 Adım {step + 1}: Planlama...")
                action = plan_next_action(obs, goal, self.history, api_key)

                if not action:
                    print(f"  ⚠️ Plan alınamadı")
                    break

                action_type = action.get("action", "?")

                # Loop detector: same action signature 3x → early exit
                _action_sig = (action_type, action.get("selector", action.get("text", "")).strip())
                _recent_action_sigs.append(_action_sig)
                if len(_recent_action_sigs) >= 3:
                    _last_3 = _recent_action_sigs[-3:]
                    if _last_3[0] == _last_3[1] == _last_3[2]:
                        print(f"  🔄 Loop algılandı: {_action_sig} x3 — durduruluyor")
                        return {
                            "success": False,
                            "error": "Aynı işlem tekrarlandı, sayfa bu yöntemle gezilemiyor.",
                            "content": content,
                            "steps": self.history,
                            "recipe_saved": False,
                        }

                # Cycle-2 detector: alternating A→B→A→B→A→B pattern
                if len(_recent_action_sigs) >= 6:
                    _last_6 = _recent_action_sigs[-6:]
                    if all(_last_6[i] == _last_6[i + 2] for i in range(4)):
                        print(f"  🔄 Döngü algılandı: {_last_6[-2:]!r} x3 — durduruluyor")
                        return {
                            "success": False,
                            "error": "Alternatif işlem döngüsü tespit edildi, durduruluyor.",
                            "content": content,
                            "steps": self.history,
                            "recipe_saved": False,
                        }

                # Cycle-3 detector: A→B→C→A→B→C→A→B→C pattern
                if len(_recent_action_sigs) >= 9:
                    _last_9 = _recent_action_sigs[-9:]
                    if all(_last_9[i] == _last_9[i + 3] for i in range(6)):
                        print(f"  🔄 3-döngü algılandı: {_last_9[-3:]!r} x3 — durduruluyor")
                        return {
                            "success": False,
                            "error": "3-adımlık döngü tespit edildi, durduruluyor.",
                            "content": content,
                            "steps": self.history,
                            "recipe_saved": False,
                        }

                # Check if done
                if action_type == "done":
                    status = action.get("status", "unknown")
                    summary = action.get("summary", action.get("reason", ""))
                    icon = "✅" if status == "success" else "❌"
                    print(f"  {icon} Tamamlandı: {summary}")

                    if status == "success" and save_recipe:
                        self._save_as_recipe(url, goal)

                    return {
                        "success": status == "success",
                        "content": content,
                        "summary": summary,
                        "steps": self.history,
                        "recipe_saved": status == "success" and save_recipe,
                    }

                # 3. ACT
                detail = {k: v for k, v in action.items() if k != "action"}
                print(f"  ▶ {action_type}: {json.dumps(detail, ensure_ascii=False)[:80]}")
                result = execute_action(browser, action)

                # 4. VERIFY
                result["action"] = action_type
                self.history.append({**action, **result})

                # Change detection: did the page actually change?
                if action_type in ("click", "submit_search") and result.get("success"):
                    _post_obs = observe_page(browser)
                    if _post_obs and obs:
                        _url_same = _post_obs.get("url") == obs.get("url")
                        _title_same = _post_obs.get("title") == obs.get("title")
                        if _url_same and _title_same:
                            self.history[-1]["_warning"] = (
                                "Sayfa değişmedi — farklı selector veya strateji dene"
                            )
                            print(f"  ⚠️ Sayfa değişmedi")

                if result.get("text"):
                    content = result["text"]
                    print(f"  📄 İçerik alındı: {len(content)} karakter")

                if not result.get("success"):
                    print(f"  ⚠️ Başarısız: {result.get('error', '?')[:80]}")

            # Max steps reached
            print(f"  ⚠️ Maksimum adıma ulaşıldı ({self.max_steps})")
            return {
                "success": bool(content),
                "content": content,
                "steps": self.history,
                "recipe_saved": False,
            }

        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)[:200]}"
            return {"success": False, "error": error_msg, "steps": self.history}

        finally:
            browser.close()

    def _save_as_recipe(self, url, goal):
        """Save successful navigation as a site-specific recipe."""
        try:
            from core.recipes import add_recipe, init_recipe_db
            from urllib.parse import urlparse

            domain = urlparse(url).netloc.replace("www.", "")
            safe_domain = re.sub(r'[^a-zA-Z0-9]', '_', domain)
            recipe_id = f"site_{safe_domain}_v1"

            # Convert history to recipe steps
            steps = []
            for h in self.history:
                act = h.get("action", "")
                if act == "done":
                    continue
                step = {
                    "action": f"browser_{act}",
                    "args": {k: v for k, v in h.items()
                             if k not in ("action", "success", "error", "text")},
                    "expect": "Başarılı" if h.get("success") else "?",
                }
                steps.append(step)

            # Extract keywords from goal
            words = goal.lower().split()
            keywords = {}
            for w in words:
                if len(w) > 3:
                    keywords[w] = 2
            keywords[domain] = 3

            recipe = {
                "id": recipe_id,
                "pattern_keywords": keywords,
                "threshold": 4.0,
                "description": f"{domain} sitesinden bilgi çekme: {goal[:50]}",
                "variables": ["search_term"],
                "steps": steps,
                "student_contract": [
                    "Bu siteye browser_open ile git",
                    "submit_search ile SPA-safe arama yap",
                    "Sonuçlardan ilk uygun olanı seç",
                ],
                "estimated_tools": len(steps),
                "source": "browser_agent",
            }

            conn = init_recipe_db()
            add_recipe(recipe, conn)
            print(f"  📦 Site recipe kaydedildi: {recipe_id}")

        except Exception as e:
            print(f"  ⚠️ Recipe kaydedilemedi: {type(e).__name__}: {str(e)[:100]}")


# ============================================
# TOOL WRAPPER — For Cont's tool system
# ============================================

def browser_agent_run(url: str, goal: str) -> dict:
    """
    Run the browser agent to navigate a website and achieve a goal.

    Args:
        url: Starting URL
        goal: What to find/do on the site

    Returns: dict with 'success' (bool), 'text' (human-readable), 'content' (raw)
    """
    agent = BrowserAgent(max_steps=10)
    result = agent.run(url, goal)

    if result.get("success"):
        content = result.get("content", "")
        summary = result.get("summary", "")

        text = f"Başarılı: {summary}\n\n"
        if content:
            text += f"İçerik ({len(content)} karakter):\n{content[:5000]}"

        if result.get("recipe_saved"):
            text += "\n\nBu site için navigasyon recipe kaydedildi."

        return {"success": True, "text": text, "content": content[:5000]}
    else:
        error = result.get("error", result.get("summary", "Bilinmeyen hata"))
        return {"success": False, "text": f"Başarısız: {error}"}
