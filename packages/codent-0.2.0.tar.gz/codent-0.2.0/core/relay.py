# core/relay.py
"""
Browser ↔ Claude Code relay server.

Workflow:
1. User talks to Browser Claude, gets a Claude Code prompt
2. User pastes prompt into relay (web UI)
3. Relay sends to Claude Code automatically
4. Result appears in relay (user copies back to browser)

Usage:
  cont --relay             # Start relay server on localhost:8765
  cont --relay --port 9000 # Custom port
"""

import json
import os
import shutil
import subprocess
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent


class RelayState:
    """Shared state for the relay."""

    def __init__(self):
        self.jobs = []  # List of {id, prompt, status, output, ts}
        self.lock = threading.Lock()

    def add_job(self, prompt: str) -> dict:
        job = {
            "id": len(self.jobs) + 1,
            "prompt": prompt,
            "status": "queued",  # queued|running|done|failed
            "output": "",
            "started_at": None,
            "finished_at": None,
            "created_at": time.time(),
        }
        with self.lock:
            self.jobs.append(job)
        return job

    def get_job(self, job_id: int) -> dict:
        with self.lock:
            for j in self.jobs:
                if j["id"] == job_id:
                    return j.copy()
        return None

    def get_recent(self, n: int = 20) -> list:
        with self.lock:
            return [j.copy() for j in self.jobs[-n:]]


def _find_claude_cli() -> str:
    """Find claude CLI binary path."""
    path = shutil.which("claude")
    if path:
        return path
    npm_path = Path.home() / ".npm-global" / "bin" / "claude"
    if npm_path.exists():
        return str(npm_path)
    return "claude"


def execute_claude_code(prompt: str, job: dict):
    """Run Claude Code in background thread."""
    job["status"] = "running"
    job["started_at"] = time.time()

    try:
        claude_path = _find_claude_cli()
        cmd = [
            claude_path, "-p", prompt,
            "--output-format", "text",
            "--max-turns", "30",
            "--allowedTools", "Read,Write,Edit,Bash",
        ]

        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        process = subprocess.Popen(
            cmd,
            cwd=str(REPO_ROOT),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )

        output_lines = []
        while True:
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
            if line:
                output_lines.append(line)
                with threading.Lock():
                    job["output"] = "".join(output_lines)

        process.wait(timeout=300)
        job["status"] = "done"
        job["output"] = "".join(output_lines)

    except subprocess.TimeoutExpired:
        process.kill()
        job["status"] = "failed"
        job["output"] += "\n\nTIMEOUT (5 min)"
    except FileNotFoundError:
        job["status"] = "failed"
        job["output"] = "Claude CLI not found. Install: npm install -g @anthropic-ai/claude-code"
    except Exception as e:
        job["status"] = "failed"
        job["output"] += f"\n\nError: {e}"
    finally:
        job["finished_at"] = time.time()


RELAY_HTML = r"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cont Relay</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: -apple-system, system-ui, sans-serif;
    background: #0d1117; color: #e6edf3;
    padding: 20px; max-width: 1200px; margin: 0 auto;
  }
  h1 { color: #58a6ff; margin-bottom: 8px; font-size: 1.4em; }
  .subtitle { color: #8b949e; margin-bottom: 20px; font-size: 0.9em; }

  .panel {
    display: grid; grid-template-columns: 1fr 1fr; gap: 16px;
    margin-bottom: 16px;
  }
  @media (max-width: 768px) { .panel { grid-template-columns: 1fr; } }

  .box {
    background: #161b22; border: 1px solid #30363d;
    border-radius: 8px; padding: 16px;
  }
  .box h3 { color: #58a6ff; margin-bottom: 8px; font-size: 1em; }

  textarea {
    width: 100%; min-height: 200px;
    background: #0d1117; color: #e6edf3;
    border: 1px solid #30363d; border-radius: 6px;
    padding: 12px; font-family: 'Fira Code', monospace;
    font-size: 13px; resize: vertical;
  }
  textarea:focus { border-color: #58a6ff; outline: none; }

  .btn {
    padding: 8px 20px; border: none; border-radius: 6px;
    cursor: pointer; font-weight: 600; font-size: 14px;
    margin-top: 8px; margin-right: 8px;
  }
  .btn-primary { background: #238636; color: white; }
  .btn-primary:hover { background: #2ea043; }
  .btn-secondary { background: #30363d; color: #e6edf3; }
  .btn-secondary:hover { background: #484f58; }

  .output {
    background: #0d1117; border: 1px solid #30363d;
    border-radius: 6px; padding: 12px;
    font-family: 'Fira Code', monospace; font-size: 13px;
    white-space: pre-wrap; word-break: break-word;
    min-height: 200px; max-height: 500px;
    overflow-y: auto;
  }

  .status {
    display: inline-block; padding: 2px 10px;
    border-radius: 12px; font-size: 12px; font-weight: 600;
  }
  .status-queued { background: #1f2937; color: #9ca3af; }
  .status-running { background: #064e3b; color: #34d399; }
  .status-done { background: #14532d; color: #4ade80; }
  .status-failed { background: #7f1d1d; color: #fca5a5; }

  .job-info { color: #8b949e; font-size: 0.85em; margin-top: 8px; }

  .history { margin-top: 16px; }
  .history-item {
    background: #161b22; border: 1px solid #30363d;
    border-radius: 6px; padding: 12px; margin-bottom: 8px;
    cursor: pointer;
  }
  .history-item:hover { border-color: #58a6ff; }
  .history-prompt {
    color: #8b949e; font-size: 0.85em;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }

  .spinner {
    display: inline-block; width: 16px; height: 16px;
    border: 2px solid #30363d; border-top: 2px solid #58a6ff;
    border-radius: 50%; animation: spin 1s linear infinite;
    vertical-align: middle; margin-right: 6px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .quick-actions { margin-top: 12px; }
  .quick-btn {
    padding: 4px 12px; background: #21262d; border: 1px solid #30363d;
    border-radius: 4px; color: #8b949e; cursor: pointer;
    font-size: 12px; margin-right: 4px; margin-bottom: 4px;
  }
  .quick-btn:hover { color: #e6edf3; border-color: #58a6ff; }
</style>
</head>
<body>

<h1>Cont Relay</h1>
<p class="subtitle">Browser Claude &rarr; Claude Code</p>

<div class="panel">
  <div class="box">
    <h3>Prompt (Browser Claude'dan yapistir)</h3>
    <textarea id="prompt" placeholder="Claude Code promptunu buraya yapistir..."></textarea>
    <div>
      <button class="btn btn-primary" onclick="submit()">Calistir</button>
      <button class="btn btn-secondary" onclick="clearPrompt()">Temizle</button>
    </div>
    <div class="quick-actions">
      <button class="quick-btn" onclick="quickAction('test')">Test calistir</button>
      <button class="quick-btn" onclick="quickAction('status')">Git status</button>
    </div>
  </div>

  <div class="box">
    <h3>
      Sonuc
      <span id="status"></span>
      <button class="btn btn-secondary" style="float:right;margin:0;padding:4px 12px;font-size:12px"
              onclick="copyOutput()">Kopyala</button>
    </h3>
    <div id="output" class="output">Henuz bir is calistirilmadi.</div>
    <div id="job-info" class="job-info"></div>
  </div>
</div>

<div class="box history">
  <h3>Gecmis</h3>
  <div id="history"></div>
</div>

<script>
let pollInterval = null;
let currentJobId = null;

async function submit() {
  const prompt = document.getElementById('prompt').value.trim();
  if (!prompt) return;

  const res = await fetch('/api/submit', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({prompt})
  });
  const data = await res.json();
  currentJobId = data.id;

  document.getElementById('status').innerHTML =
    '<span class="status status-running"><span class="spinner"></span>Calisiyor</span>';
  document.getElementById('output').textContent = 'Baslatiliyor...';

  startPolling();
}

async function quickAction(action) {
  const prompts = {
    test: 'Run: python3 -c "import cont; print(\'OK\')" && python3 -m pytest tests/ -q',
    status: 'Run: git status && git log --oneline -5',
  };
  document.getElementById('prompt').value = prompts[action] || action;
  submit();
}

function startPolling() {
  if (pollInterval) clearInterval(pollInterval);
  pollInterval = setInterval(pollJob, 1000);
}

async function pollJob() {
  if (!currentJobId) return;

  const res = await fetch('/api/job/' + currentJobId);
  const job = await res.json();

  document.getElementById('output').textContent = job.output || '...';
  const el = document.getElementById('output');
  el.scrollTop = el.scrollHeight;

  const elapsed = job.started_at ?
    Math.round((job.finished_at || Date.now()/1000) - job.started_at) : 0;

  if (job.status === 'running') {
    document.getElementById('status').innerHTML =
      '<span class="status status-running"><span class="spinner"></span>' + elapsed + 's</span>';
  } else if (job.status === 'done') {
    clearInterval(pollInterval);
    document.getElementById('status').innerHTML =
      '<span class="status status-done">Tamamlandi (' + elapsed + 's)</span>';
    document.getElementById('job-info').textContent =
      'Output: ' + job.output.length + ' karakter';
    loadHistory();
  } else if (job.status === 'failed') {
    clearInterval(pollInterval);
    document.getElementById('status').innerHTML =
      '<span class="status status-failed">Basarisiz (' + elapsed + 's)</span>';
    loadHistory();
  }
}

async function loadHistory() {
  const res = await fetch('/api/history');
  const jobs = await res.json();

  const el = document.getElementById('history');
  el.innerHTML = jobs.reverse().map(function(j) {
    return '<div class="history-item" onclick="loadJob(' + j.id + ')">' +
      '<span class="status status-' + j.status + '">' + j.status + '</span> ' +
      '<span class="history-prompt">' + j.prompt.substring(0, 80) + '...</span>' +
      '</div>';
  }).join('');
}

async function loadJob(id) {
  currentJobId = id;
  const res = await fetch('/api/job/' + id);
  const job = await res.json();
  document.getElementById('prompt').value = job.prompt;
  document.getElementById('output').textContent = job.output;
  const elapsed = job.started_at && job.finished_at ?
    Math.round(job.finished_at - job.started_at) : 0;
  document.getElementById('status').innerHTML =
    '<span class="status status-' + job.status + '">' + job.status + ' (' + elapsed + 's)</span>';
}

function copyOutput() {
  const text = document.getElementById('output').textContent;
  navigator.clipboard.writeText(text).then(function() {
    var btn = document.querySelector('[onclick="copyOutput()"]');
    btn.textContent = 'Kopyalandi!';
    setTimeout(function() { btn.textContent = 'Kopyala'; }, 2000);
  });
}

function clearPrompt() {
  document.getElementById('prompt').value = '';
}

loadHistory();
</script>
</body>
</html>"""


class RelayHandler(BaseHTTPRequestHandler):
    """HTTP handler for the relay server."""

    def log_message(self, format, *args):
        pass  # Suppress default logging

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def _send_html(self, html):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode())

    def do_GET(self):
        if self.path == "/":
            self._send_html(RELAY_HTML)

        elif self.path.startswith("/api/job/"):
            try:
                job_id = int(self.path.split("/")[-1])
                job = state.get_job(job_id)
                if job:
                    self._send_json(job)
                else:
                    self._send_json({"error": "not found"}, 404)
            except ValueError:
                self._send_json({"error": "invalid id"}, 400)

        elif self.path == "/api/history":
            self._send_json(state.get_recent(20))

        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        if self.path == "/api/submit":
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
            prompt = body.get("prompt", "").strip()

            if not prompt:
                self._send_json({"error": "empty prompt"}, 400)
                return

            job = state.add_job(prompt)

            t = threading.Thread(
                target=execute_claude_code,
                args=(prompt, job),
                daemon=True,
            )
            t.start()

            self._send_json({"id": job["id"], "status": "queued"})
        else:
            self._send_json({"error": "not found"}, 404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


state = RelayState()


def start_relay(port: int = 8765):
    """Start the relay server."""
    print(f"Cont Relay started: http://localhost:{port}")
    print(f"  Paste prompt from Browser Claude -> run -> copy result back")
    print(f"  Ctrl+C to stop")

    server = HTTPServer(("127.0.0.1", port), RelayHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nRelay stopped.")
        server.server_close()
