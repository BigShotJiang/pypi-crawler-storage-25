# core/recipes.py
"""
Parametric recipe system.

A recipe is a proven sequence of steps for a task pattern.
When matched, it guides the LLM instead of letting it explore freely.

Storage: SQLite table in cont's memory DB
Matching: Keyword scoring (same approach as system_executor)
Execution: Steps injected into system prompt as instructions
"""

import json
import os
import re
import sqlite3
import time
from typing import Callable, Dict, List, Optional


# ============================================
# RECIPE SCHEMA
# ============================================

RECIPE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS recipes (
    id TEXT PRIMARY KEY,
    pattern_keywords TEXT NOT NULL,
    threshold REAL DEFAULT 4.0,
    description TEXT,
    variables TEXT,
    steps TEXT NOT NULL,
    student_contract TEXT,
    estimated_tools INTEGER DEFAULT 3,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    last_success REAL,
    last_failure REAL,
    created_at REAL,
    source TEXT DEFAULT 'manual',
    status TEXT DEFAULT 'active',
    success_criteria TEXT
)
"""


def init_recipe_db(db_path=None):
    """Initialize recipe table in existing memory DB or standalone."""
    if db_path is None:
        db_path = os.path.expanduser("~/.config/cont/memory.db")

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(RECIPE_TABLE_SQL)
    # Migration: add success_criteria column for existing DBs
    try:
        conn.execute("ALTER TABLE recipes ADD COLUMN success_criteria TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists
    conn.commit()
    return conn


# ============================================
# TURKISH NORMALIZATION
# ============================================

_TR_MAP = str.maketrans(
    "çğıöşüÇĞİÖŞÜ",
    "cgiosuCGIOSU",
)


def _normalize(word: str) -> str:
    """Strip Turkish diacritics + trailing punctuation."""
    return word.translate(_TR_MAP).strip(".,!?:;\"'()[]{}/*")


# ============================================
# ENTITY EXTRACTION (for intent-consistency guard)
# ============================================

# Uppercase acronyms (2+ chars): BDDK, SEGEM, KOSGEB, etc.
_ENTITY_RE = re.compile(r'\b[A-ZÇĞİÖŞÜ]{2,}\b')

# Known org/domain names that appear lowercase in Turkish text
_KNOWN_ENTITIES = {
    'bddk', 'segem', 'kosgeb', 'tubitak', 'tübitak',
    'spk', 'tcmb', 'kvkk', 'epdk', 'icta', 'btk',
    'kobigel', 'teknogirişim', 'teknoloji', 'dijital',
}

# Generic words that look like entities but aren't (common in step text)
_ENTITY_STOPWORDS = {
    'JSON', 'HTML', 'URL', 'API', 'PDF', 'CSV', 'SQL', 'OK',
    'GET', 'POST', 'HTTP', 'HTTPS', 'SSL', 'TLS',
}


def _extract_entities(text: str) -> set:
    """Extract entity-like tokens from text.

    Returns lowercase set of acronyms and known org names.
    Ignores variable placeholders like {search_term}.
    """
    entities = set()

    # Uppercase acronyms
    for m in _ENTITY_RE.finditer(text):
        tok = m.group()
        if tok not in _ENTITY_STOPWORDS and not tok.startswith('{'):
            entities.add(tok.lower())

    # Known entities in lowercase text
    lower_words = set(re.findall(r'\b\w+\b', text.lower()))
    entities |= lower_words & _KNOWN_ENTITIES

    return entities


def _entity_conflict(user_entities: set, recipe_entities: set) -> bool:
    """True if user mentions entity X but recipe is hardcoded for entity Y.

    Only triggers when BOTH sides have entities and they don't overlap.
    """
    if not user_entities or not recipe_entities:
        return False  # No conflict if either side has no entities

    # If there's any overlap, they're talking about the same thing
    if user_entities & recipe_entities:
        return False

    return True  # User says X, recipe says Y → conflict


# ============================================
# RECIPE MATCHING
# ============================================

def match_recipe(user_input: str, conn=None) -> Optional[Dict]:
    """
    Find the best matching active recipe for user input.
    Uses keyword scoring (same as system_executor intents).
    Includes entity-consistency guard: rejects recipes whose hardcoded
    entities conflict with the user's intent.
    Returns recipe dict or None.
    """
    if conn is None:
        try:
            conn = init_recipe_db()
        except Exception:
            return None

    cursor = conn.execute(
        "SELECT * FROM recipes WHERE status = 'active'"
    )
    columns = [d[0] for d in cursor.description]

    raw_words = user_input.lower().split()
    words = [_normalize(w) for w in raw_words]
    user_entities = _extract_entities(user_input)
    best_recipe = None
    best_score = 0

    for row in cursor:
        recipe = dict(zip(columns, row))
        keywords = json.loads(recipe["pattern_keywords"])
        threshold = recipe["threshold"]

        score = 0
        for word in words:
            if not word:
                continue
            # Exact match
            if word in keywords:
                score += keywords[word]
            else:
                # Substring/stem match (Turkish suffix handling)
                for kw, kw_score in keywords.items():
                    if len(kw) >= 3 and (
                        word.startswith(kw) or kw.startswith(word)
                        or kw in word or word in kw
                    ):
                        score += kw_score * 0.7
                        break

        if score >= threshold and score > best_score:
            # Entity-consistency guard: check for entity conflict
            steps_raw = recipe["steps"]  # still JSON string here
            recipe_text = steps_raw + " " + recipe.get("description", "")
            recipe_entities = _extract_entities(recipe_text)

            if _entity_conflict(user_entities, recipe_entities):
                # User says "BDDK" but recipe is about "SEGEM" → skip
                continue

            best_score = score
            recipe["_score"] = score
            recipe["steps"] = json.loads(steps_raw)
            recipe["variables"] = json.loads(
                recipe.get("variables") or "[]"
            )
            recipe["student_contract"] = json.loads(
                recipe.get("student_contract") or "[]"
            )
            recipe["success_criteria"] = json.loads(
                recipe["success_criteria"]
            ) if recipe.get("success_criteria") else None
            best_recipe = recipe

    return best_recipe


# ============================================
# RECIPE PROMPT INJECTION
# ============================================

def recipe_to_prompt(recipe: Dict, user_input: str,
                     context: Dict = None) -> str:
    """
    Convert a matched recipe into LLM prompt instructions.
    The LLM follows these steps instead of exploring freely.
    """
    parts = []

    parts.append(f"[RECIPE: {recipe['id']}]")
    sc = recipe.get('success_count', 0)
    fc = recipe.get('failure_count', 0)
    if sc > 0:
        parts.append("Bu gorev tipi daha once basariyla cozuldu.")
    elif fc > 0:
        parts.append(f"Bu recipe henuz basarili olmadi ({fc} basarisiz deneme). Adimlar rehber niteliklidir, gerekirse adapte et.")
    else:
        parts.append("Bu gorev tipi icin onerilen adimlar:")
    parts.append(f"Aciklama: {recipe.get('description', '')}")
    parts.append(f"Tahmini tool sayisi: {recipe.get('estimated_tools', 3)}")
    parts.append("")

    # Steps
    parts.append("ADIMLAR (sirayla takip et):")
    for i, step in enumerate(recipe["steps"], 1):
        action = step.get("action", "?")
        args = step.get("args", {})
        expect = step.get("expect", "")
        on_fail = step.get("on_fail", "")

        # Resolve variables in args
        if context:
            args_str = json.dumps(args, ensure_ascii=False)
            for key, val in context.items():
                args_str = args_str.replace(f"{{{key}}}", str(val))
            args = json.loads(args_str)

        parts.append(
            f"  {i}. {action}({json.dumps(args, ensure_ascii=False)})"
        )
        if expect:
            parts.append(f"     Beklenen: {expect}")
        if on_fail:
            parts.append(f"     Hata durumu: {on_fail}")

    parts.append("")

    # Student contract
    if recipe.get("student_contract"):
        parts.append("KURALLAR (kesinlikle uy):")
        for rule in recipe["student_contract"]:
            parts.append(f"  ! {rule}")

    parts.append("")
    parts.append(
        f"Basari sayisi: {recipe.get('success_count', 0)} | "
        f"Basarisizlik: {recipe.get('failure_count', 0)}"
    )

    return "\n".join(parts)


# ============================================
# RECIPE LIFECYCLE
# ============================================

def record_success(recipe_id: str, conn=None):
    """Record a successful recipe execution."""
    if conn is None:
        conn = init_recipe_db()
    conn.execute(
        "UPDATE recipes SET success_count = success_count + 1, "
        "last_success = ? WHERE id = ?",
        (time.time(), recipe_id),
    )
    conn.commit()


def record_failure(recipe_id: str, conn=None):
    """Record a failed recipe execution. Expire after 3 failures."""
    if conn is None:
        conn = init_recipe_db()
    conn.execute(
        "UPDATE recipes SET failure_count = failure_count + 1, "
        "last_failure = ? WHERE id = ?",
        (time.time(), recipe_id),
    )
    # Auto-expire after 3 consecutive failures
    conn.execute(
        "UPDATE recipes SET status = 'expired' "
        "WHERE id = ? AND failure_count >= 3",
        (recipe_id,),
    )
    conn.commit()


def archive_stale(days=30, conn=None):
    """Archive recipes not used in N days."""
    if conn is None:
        conn = init_recipe_db()
    cutoff = time.time() - (days * 86400)
    conn.execute(
        "UPDATE recipes SET status = 'archived' "
        "WHERE status = 'active' AND last_success < ? "
        "AND last_success IS NOT NULL",
        (cutoff,),
    )
    conn.commit()


def cleanup_junk_recipes(conn=None, max_age_hours=24):
    """Expire 0-success recipes older than max_age_hours. Called on startup."""
    if conn is None:
        conn = init_recipe_db()
    cutoff = time.time() - (max_age_hours * 3600)
    cursor = conn.execute(
        "SELECT id FROM recipes WHERE status = 'active' "
        "AND success_count = 0 AND created_at < ?", (cutoff,)
    )
    expired = []
    for row in cursor.fetchall():
        conn.execute(
            "UPDATE recipes SET status = 'expired' WHERE id = ?", (row[0],)
        )
        expired.append(row[0])
    if expired:
        conn.commit()
    return expired


# ============================================
# SEED RECIPES — Common patterns
# ============================================

SEED_RECIPES = [
    {
        "id": "dosya_oku_ozetle_v1",
        "pattern_keywords": {
            "oku": 3, "read": 3, "ozetle": 3, "summarize": 3,
            "dosya": 2, "file": 2, "icerik": 2, "content": 2,
        },
        "threshold": 5,
        "description": "Bir dosyayi oku ve icerigini ozetle",
        "variables": ["file_path"],
        "success_criteria": {
            "response_contains_any": ["import", "def ", "class ", "dosya"],
            "min_response_words": 20,
            "max_tools": 3,
        },
        "steps": [
            {
                "action": "recall",
                "args": {"query": "{file_hint}"},
                "expect": "Dosya yolu hafizadan bulunur",
                "on_fail": "system_search ile ara",
            },
            {
                "action": "read_file",
                "args": {"path": "{resolved_path}"},
                "expect": "Dosya icerigi doner",
                "on_fail": "Dosya bulunamadi hatasi ver",
            },
            {
                "action": "respond",
                "args": {"task": "Icerigi Turkce ozetle"},
                "expect": "Kullaniciya ozet sunulur",
            },
        ],
        "student_contract": [
            "Dosya yolu HAFIZA'da verilmisse ARAMA yapma",
            "read_file basariliysa 'erisemiyorum' DEME",
            "Dosyayi SADECE 1 kez oku, tekrar cagirma",
        ],
        "estimated_tools": 2,
        "source": "manual",
    },
    {
        "id": "proje_analiz_v1",
        "pattern_keywords": {
            "proje": 3, "project": 3, "analiz": 3, "analyze": 3,
            "yapi": 2, "structure": 2, "incele": 2, "examine": 2,
            "klasor": 1, "folder": 1,
        },
        "threshold": 5,
        "description": "Bir projenin yapisini analiz et",
        "variables": ["project_path"],
        "success_criteria": {
            "response_contains_any": ["README", "proje", "yapı", "modül"],
            "min_response_words": 30,
            "max_tools": 5,
        },
        "steps": [
            {
                "action": "recall",
                "args": {"query": "{project_hint}"},
                "expect": "Proje yolu hafizadan bulunur",
                "on_fail": "CWD'yi kullan",
            },
            {
                "action": "list_dir",
                "args": {"path": "{resolved_path}"},
                "expect": "Proje dosya/klasor listesi",
            },
            {
                "action": "read_file",
                "args": {
                    "path": "{resolved_path}/README.md",
                },
                "expect": "README icerigi",
                "on_fail": "README yoksa package.json veya setup.py dene",
            },
            {
                "action": "respond",
                "args": {"task": "Proje yapisini ve amacini ozetle"},
            },
        ],
        "student_contract": [
            "list_dir'i sadece 1 kez cagir",
            "Alt klasorlere DALMA, sadece root seviyeyi goster",
            "README varsa oku, yoksa tahmin et",
        ],
        "estimated_tools": 3,
        "source": "manual",
    },
    {
        "id": "web_arama_v1",
        "pattern_keywords": {
            "ara": 3, "search": 3, "bul": 2, "find": 2,
            "web": 3, "internet": 3, "google": 3,
            "nedir": 2, "hakkinda": 2, "about": 2,
        },
        "threshold": 5,
        "description": "Web'de bilgi ara ve ozetle",
        "variables": ["query"],
        "steps": [
            {
                "action": "web_search",
                "args": {"query": "{search_query}"},
                "expect": "Arama sonuclari listesi",
            },
            {
                "action": "web_fetch",
                "args": {"url": "{best_result_url}"},
                "expect": "Sayfa icerigi",
                "on_fail": "Ikinci sonucu dene",
            },
            {
                "action": "respond",
                "args": {"task": "Bilgiyi Turkce ozetle"},
            },
        ],
        "student_contract": [
            "web_search'u SADECE 1 kez cagir",
            "Ayni URL'yi 2 kez fetch ETME",
            "Sonuc yoksa 'bulunamadi' de, donguye girme",
        ],
        "estimated_tools": 2,
        "source": "manual",
    },
    {
        "id": "kod_duzenle_v1",
        "pattern_keywords": {
            "duzenle": 3, "edit": 3, "degistir": 3, "change": 3,
            "ekle": 2, "add": 2, "sil": 2, "remove": 2, "delete": 2,
            "kod": 2, "code": 2, "dosya": 1, "satir": 2, "line": 2,
        },
        "threshold": 5,
        "description": "Bir dosyada kod degisikligi yap",
        "variables": ["file_path", "change_description"],
        "steps": [
            {
                "action": "recall",
                "args": {"query": "{file_hint}"},
                "expect": "Dosya yolu",
                "on_fail": "system_search ile ara",
            },
            {
                "action": "read_file",
                "args": {
                    "path": "{resolved_path}",
                    "lines": "relevant section",
                },
                "expect": "Mevcut kod icerigi",
            },
            {
                "action": "edit_file",
                "args": {
                    "path": "{resolved_path}",
                    "changes": "{edit_spec}",
                },
                "expect": "Dosya guncellendi mesaji",
            },
            {
                "action": "read_file",
                "args": {
                    "path": "{resolved_path}",
                    "lines": "changed section",
                },
                "expect": "Dogrulama: degisiklik uygulandi",
            },
        ],
        "student_contract": [
            "Dosyayi duzenlemeden ONCE mutlaka oku",
            "edit_file SONRASI dogrulama oku yap",
            "Ayni dosyayi 3'ten fazla okuma",
        ],
        "estimated_tools": 4,
        "source": "manual",
    },
]


def seed_recipes(conn=None):
    """Insert seed recipes if they don't exist."""
    if conn is None:
        conn = init_recipe_db()

    for recipe in SEED_RECIPES:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO recipes "
                "(id, pattern_keywords, threshold, description, "
                "variables, steps, student_contract, estimated_tools, "
                "created_at, source, status, success_criteria) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    recipe["id"],
                    json.dumps(recipe["pattern_keywords"], ensure_ascii=False),
                    recipe["threshold"],
                    recipe["description"],
                    json.dumps(recipe.get("variables", []), ensure_ascii=False),
                    json.dumps(recipe["steps"], ensure_ascii=False),
                    json.dumps(
                        recipe.get("student_contract", []), ensure_ascii=False
                    ),
                    recipe.get("estimated_tools", 3),
                    time.time(),
                    recipe.get("source", "manual"),
                    "active",
                    json.dumps(recipe.get("success_criteria"), ensure_ascii=False)
                    if recipe.get("success_criteria") else None,
                ),
            )
        except Exception:
            pass

    conn.commit()


# ============================================
# ADD / LIST / DELETE recipes
# ============================================

def add_recipe(recipe: Dict, conn=None):
    """Add a new recipe (from teacher API or manual)."""
    if conn is None:
        conn = init_recipe_db()

    recipe.setdefault("created_at", time.time())
    recipe.setdefault("source", "manual")
    recipe.setdefault("status", "active")
    recipe.setdefault("threshold", 4.0)
    recipe.setdefault("estimated_tools", 3)

    conn.execute(
        "INSERT OR REPLACE INTO recipes "
        "(id, pattern_keywords, threshold, description, "
        "variables, steps, student_contract, estimated_tools, "
        "created_at, source, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            recipe["id"],
            json.dumps(recipe["pattern_keywords"], ensure_ascii=False),
            recipe["threshold"],
            recipe.get("description", ""),
            json.dumps(recipe.get("variables", []), ensure_ascii=False),
            json.dumps(recipe["steps"], ensure_ascii=False),
            json.dumps(
                recipe.get("student_contract", []), ensure_ascii=False
            ),
            recipe["estimated_tools"],
            recipe["created_at"],
            recipe["source"],
            recipe["status"],
        ),
    )
    conn.commit()


def list_recipes(conn=None, status="active"):
    """List all recipes with given status."""
    if conn is None:
        conn = init_recipe_db()
    cursor = conn.execute(
        "SELECT id, description, success_count, failure_count, "
        "source, status FROM recipes WHERE status = ?",
        (status,),
    )
    return [
        dict(zip([d[0] for d in cursor.description], row))
        for row in cursor
    ]


# ============================================
# BACKWARD COMPAT — old API used by cont.py
# ============================================

def load_recipes() -> list:
    """Backward compat: load recipes from SQLite (was JSON files)."""
    try:
        conn = init_recipe_db()
        seed_recipes(conn)
        return list_recipes(conn)
    except Exception:
        return []


def format_recipe_for_prompt(recipe: dict) -> str:
    """Backward compat: format recipe for prompt injection."""
    if not recipe:
        return ""
    return recipe_to_prompt(recipe, "")


def record_recipe_outcome(name: str, success: bool,
                          db_connect=None, memory_init=None) -> bool:
    """Backward compat: track recipe outcome via old API."""
    try:
        if success:
            record_success(name)
        else:
            record_failure(name)
        return True
    except Exception:
        return False


def get_recipe_stats(db_connect=None, memory_init=None) -> list:
    """Backward compat: get stats from new recipes table."""
    try:
        conn = init_recipe_db()
        cursor = conn.execute(
            "SELECT id, success_count, "
            "success_count + failure_count as total, "
            "CASE WHEN (success_count + failure_count) > 0 "
            "  THEN ROUND(CAST(success_count AS FLOAT) "
            "       / (success_count + failure_count) * 100) "
            "  ELSE 0 END as rate "
            "FROM recipes WHERE success_count + failure_count > 0 "
            "ORDER BY total DESC"
        )
        return [
            {
                "name": r[0],
                "successes": r[1],
                "total": r[2],
                "rate": f"{r[3]:.0f}%",
            }
            for r in cursor.fetchall()
        ]
    except Exception:
        return []


def save_recipe(name: str, triggers: list, steps: list,
                forbidden_tools: list = None,
                exclude_triggers: list = None) -> bool:
    """Backward compat: save via old API, converts to new format."""
    try:
        # Build keyword dict from old trigger strings
        keywords = {}
        for t in triggers:
            for word in t.lower().split():
                if len(word) >= 2:
                    keywords[word] = keywords.get(word, 0) + 3
        if exclude_triggers:
            for t in exclude_triggers:
                for word in t.lower().split():
                    if len(word) >= 2:
                        keywords[word] = keywords.get(word, 0) - 5

        # Convert old step format to new
        new_steps = []
        for s in steps:
            new_steps.append({
                "action": s.get("tool", s.get("action", "?")),
                "args": s.get("args", {}),
                "expect": s.get("purpose", s.get("expect", "")),
            })

        add_recipe({
            "id": name,
            "pattern_keywords": keywords,
            "threshold": 4.0,
            "description": name.replace("_", " "),
            "variables": [],
            "steps": new_steps,
            "student_contract": (
                [f"FORBIDDEN: {', '.join(forbidden_tools)}"]
                if forbidden_tools else []
            ),
            "estimated_tools": len(new_steps),
        })
        return True
    except Exception:
        return False


# ============================================
# RECIPE BROWSER DECISION
# ============================================

_BROWSER_ACTIONS = frozenset({
    "browser_agent", "browser_open", "web_fetch", "web_search",
})


def recipe_needs_browser(recipe: Optional[Dict]) -> bool:
    """Return True if recipe has steps that require browser/web tools.

    Used by the routing layer: if a matched recipe needs browser actions
    but SystemExecutor couldn't handle it, browser_agent should still run.
    """
    if not recipe:
        return False
    steps = recipe.get("steps", [])
    if isinstance(steps, str):
        try:
            steps = json.loads(steps)
        except (json.JSONDecodeError, TypeError):
            return False
    if not isinstance(steps, list):
        return False
    return any(
        isinstance(s, dict) and s.get("action") in _BROWSER_ACTIONS
        for s in steps
    )
