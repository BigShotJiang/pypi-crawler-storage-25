# core/scratchpad.py
"""Scratchpad — deterministic context offloading for long tasks.

Tool results are captured to a temp file. When context exceeds threshold,
messages are rebuilt from scratchpad instead of being truncated (which
loses earlier findings).

No LLM summarization — all extraction is deterministic.
"""

import json
import os
import re
from datetime import datetime
from typing import TYPE_CHECKING

SCRATCHPAD_DIR = "/tmp/cont_scratchpad"

# Context threshold (chars). 9k tokens ≈ 22k chars at ~2.5 chars/token.
# Rebuild when we hit ~78% capacity.
CONTEXT_REBUILD_CHARS = 17000

_URL_RE = re.compile(r'https?://[\w./%\-?&=#+]+')


def _sanitize_role_alternation(messages: list[dict]) -> list[dict]:
    """Merge consecutive same-role messages to prevent Jinja template crash.

    Local copy to avoid circular import from runtime.py.
    """
    if not messages:
        return messages
    result = []
    for msg in messages:
        if result and result[-1]["role"] == msg["role"]:
            result[-1] = dict(result[-1])
            result[-1]["content"] = (result[-1].get("content") or "") + "\n\n" + (msg.get("content") or "")
        else:
            result.append(msg)
    return result


def init_scratchpad(task_id: str) -> str:
    """Create scratchpad file at task start. Returns file path."""
    os.makedirs(SCRATCHPAD_DIR, exist_ok=True)
    path = os.path.join(SCRATCHPAD_DIR, f"{task_id}.md")
    with open(path, "w") as f:
        f.write(f"# Görev Notları\nBaşlangıç: {datetime.now().isoformat()}\n\n")
    return path


def append_scratchpad(path: str, step: int, tool_name: str,
                      tool_args: dict, tool_result: str):
    """Extract key info from tool result and append to scratchpad."""
    key_info = extract_key_info(tool_name, tool_args, tool_result)
    if not key_info:
        return
    try:
        with open(path, "a") as f:
            f.write(f"## Adım {step}: {tool_name}\n{key_info}\n\n")
    except OSError:
        pass


def extract_key_info(tool_name: str, tool_args: dict,
                     tool_result: str) -> str:
    """Extract the most important info from a tool result. Deterministic."""

    if tool_name == "web_search":
        try:
            data = json.loads(tool_result)
            results = data.get("results", [])[:3]
            lines = []
            for r in results:
                title = r.get("title", "")
                url = r.get("url", "")
                snippet = r.get("snippet", "")[:150]
                lines.append(f"- [{title}]({url})")
                if snippet:
                    lines.append(f"  {snippet}")
            return "\n".join(lines) if lines else tool_result[:300]
        except (json.JSONDecodeError, TypeError):
            return tool_result[:300]

    if tool_name == "web_fetch":
        try:
            data = json.loads(tool_result)
            url = data.get("final_url", data.get("url", ""))
            status = data.get("status_code", "?")
            text = data.get("text", "")[:500]
            return f"URL: {url} (HTTP {status})\n{text}"
        except (json.JSONDecodeError, TypeError):
            return tool_result[:500]

    if tool_name == "browser_agent":
        return tool_result[:200]

    if tool_name in ("browser_open", "browser_links"):
        return tool_result[:500]

    if tool_name == "browser_text":
        return tool_result[:500] if tool_result else ""

    if tool_name in ("read_file", "list_dir", "search_files"):
        return tool_result[:300]

    return tool_result[:200] if tool_result else ""


def read_scratchpad(path: str, max_chars: int = 3000) -> str:
    """Read scratchpad content, keeping last entries if too long."""
    if not os.path.exists(path):
        return ""
    try:
        with open(path) as f:
            content = f.read()
    except OSError:
        return ""

    if len(content) <= max_chars:
        return content

    # Keep last N steps
    parts = content.split("## Adım")
    if len(parts) <= 2:
        return content[-max_chars:]
    # Header + last 5 steps
    header = parts[0]
    kept = parts[-5:]
    return header + "## Adım".join(kept)


def maybe_rebuild_context(messages: list, scratchpad_path: str,
                          original_task: str,
                          estimate_chars: int | None = None) -> list:
    """Rebuild context from scratchpad if messages are too long.

    Returns original messages if under threshold, rebuilt messages otherwise.
    """
    if estimate_chars is None:
        estimate_chars = sum(len(m.get("content") or "") for m in messages)

    if estimate_chars < CONTEXT_REBUILD_CHARS:
        return messages

    scratchpad_content = read_scratchpad(scratchpad_path)
    if not scratchpad_content or scratchpad_content.count("## Adım") < 1:
        return messages  # Nothing captured yet

    # Rebuild: system prompt + scratchpad summary + task continuation
    rebuilt = [
        messages[0],  # system prompt preserved
        {"role": "user", "content": original_task},
        {
            "role": "assistant",
            "content": "Önceki adımlarda bilgi topladım, devam ediyorum.",
        },
        {
            "role": "user",
            "content": (
                f"[GÖREVİN DEVAMI — önceki adımların özeti]\n"
                f"{scratchpad_content}\n\n"
                f"Bu bilgilerle görevi tamamla: {original_task}"
            ),
        },
    ]

    # v6.2: Sanitize role alternation after rebuild to prevent Jinja crash
    rebuilt = _sanitize_role_alternation(rebuilt)

    return rebuilt


def cleanup_scratchpad(path: str):
    """Remove scratchpad file after task completes."""
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
