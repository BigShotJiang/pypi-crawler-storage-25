# core/events.py
"""
Simple pub/sub event system for Cont.

Allows any part of Cont to emit events and any other part to listen.
No external dependencies — just a dict of lists.

Event types:
- file.created, file.modified, file.deleted
- task.completed, task.failed
- build.failed, test.failed
- schedule.daily, schedule.weekly
- system.disk_warning, system.gpu_hot
- inbox.new_file
"""

import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable, Any


# Automation log file
_LOG_FILE = Path.home() / ".config" / "cont" / "automation_log.jsonl"


def _log_event(event_type: str, data: dict, handler_name: str = "",
               result: str = ""):
    """Append one line to the automation log."""
    try:
        _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": datetime.now().isoformat(),
            "event": event_type,
            "handler": handler_name,
            "result": result[:500] if result else "",
            "data_keys": list(data.keys()) if data else [],
        }
        with open(_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


class EventBus:
    """
    Simple pub/sub event bus.

    Usage:
        bus = EventBus()
        bus.subscribe("task.completed", my_handler)
        bus.emit("task.completed", {"task": "...", "success": True})

    Handlers receive (event_type: str, data: dict).
    """

    def __init__(self):
        self._handlers: dict[str, list[tuple[str, Callable]]] = {}
        self._lock = threading.Lock()

    def subscribe(self, event_type: str, handler: Callable,
                  name: str = "") -> None:
        """
        Register a handler for an event type.

        Args:
            event_type: Event name (e.g., "file.modified")
            handler: Callable(event_type: str, data: dict)
            name: Optional handler name for logging
        """
        handler_name = name or getattr(handler, "__name__", str(handler))
        with self._lock:
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append((handler_name, handler))

    def unsubscribe(self, event_type: str, handler: Callable) -> None:
        """Remove a handler from an event type."""
        with self._lock:
            if event_type in self._handlers:
                self._handlers[event_type] = [
                    (n, h) for n, h in self._handlers[event_type]
                    if h is not handler
                ]

    def emit(self, event_type: str, data: dict = None) -> list:
        """
        Emit an event synchronously. All handlers run in sequence.
        Returns list of (handler_name, result_or_error) tuples.
        """
        data = data or {}
        results = []

        with self._lock:
            handlers = list(self._handlers.get(event_type, []))
            # Also trigger wildcard handlers
            handlers += list(self._handlers.get("*", []))

        for handler_name, handler in handlers:
            try:
                result = handler(event_type, data)
                result_str = str(result)[:200] if result else "ok"
                _log_event(event_type, data, handler_name, result_str)
                results.append((handler_name, result))
            except Exception as e:
                error_str = f"error: {e}"
                _log_event(event_type, data, handler_name, error_str)
                results.append((handler_name, e))

        return results

    def emit_async(self, event_type: str, data: dict = None) -> None:
        """
        Emit an event asynchronously. Handlers run in a background thread.
        Fire-and-forget — errors are logged but not raised.
        """
        data = data or {}
        thread = threading.Thread(
            target=self.emit,
            args=(event_type, data),
            daemon=True,
        )
        thread.start()

    def list_handlers(self) -> dict:
        """Return a summary of registered handlers per event type."""
        with self._lock:
            return {
                event_type: [name for name, _ in handlers]
                for event_type, handlers in self._handlers.items()
            }

    def clear(self) -> None:
        """Remove all handlers."""
        with self._lock:
            self._handlers.clear()


# Global event bus instance
event_bus = EventBus()
