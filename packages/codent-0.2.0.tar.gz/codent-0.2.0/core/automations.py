# core/automations.py
"""
Automation rule engine for Cont.

Loads YAML rules from ~/.config/cont/automations/ and executes
actions when events match triggers. Actions can be shell commands,
recipes, or memory recalls.

No external dependencies beyond PyYAML (already available).
"""

import fnmatch
import json
import os
import subprocess
import time
from datetime import datetime, date
from pathlib import Path
from typing import Optional

try:
    import yaml
    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

try:
    from core.events import event_bus, _log_event
except ImportError:
    event_bus = None
    _log_event = lambda *a, **k: None

try:
    from core.scheduler import Scheduler
except ImportError:
    Scheduler = None


AUTOMATIONS_DIR = Path.home() / ".config" / "cont" / "automations"
_LOG_FILE = Path.home() / ".config" / "cont" / "automation_log.jsonl"

# Safety: max execution time per shell action (seconds)
_SHELL_TIMEOUT = 30

# Safety: blocked patterns (same philosophy as cont.py block_dangerous)
_BLOCKED_PATTERNS = [
    "rm -rf /", "mkfs", "dd if=", ":(){", "chmod -R 777 /",
    "curl|sh", "wget|sh", "sudo", "su -",
]


def _is_safe_command(cmd: str) -> bool:
    """Check if a shell command is safe to run in automation context."""
    cmd_lower = cmd.lower()
    for pattern in _BLOCKED_PATTERNS:
        if pattern in cmd_lower:
            return False
    return True


def _expand_variables(text: str, context: dict) -> str:
    """
    Expand {variable} placeholders in a string using context dict.
    Uses simple string.format_map() with a safe fallback for missing keys.
    """
    class SafeDict(dict):
        def __missing__(self, key):
            return "{" + key + "}"

    try:
        return text.format_map(SafeDict(context))
    except Exception:
        return text


def _build_context(event_data: dict = None) -> dict:
    """Build the variable context available to automation actions."""
    today = date.today()
    now = datetime.now()

    ctx = {
        "date": today.isoformat(),
        "year": str(today.year),
        "month": f"{today.month:02d}",
        "day": f"{today.day:02d}",
        "week_number": today.strftime("%V"),
        "weekday": today.strftime("%A").lower(),
        "timestamp": now.isoformat(),
        "home": str(Path.home()),
        "user": os.environ.get("USER", os.environ.get("USERNAME", "user")),
    }

    # Try to get repo_root from cont
    try:
        from cont import REPO_ROOT
        ctx["repo_root"] = str(REPO_ROOT)
    except Exception:
        ctx["repo_root"] = str(Path.cwd())

    # Merge event data
    if event_data:
        ctx.update(event_data)

        # Derive file-specific variables
        if "path" in event_data or "file_path" in event_data:
            fpath = event_data.get("file_path", event_data.get("path", ""))
            if fpath:
                p = Path(fpath)
                ctx["file_path"] = str(p)
                ctx["file_name"] = p.name
                ctx["file_stem"] = p.stem
                ctx["file_ext"] = p.suffix
                ctx["file_dir"] = str(p.parent)

    return ctx


def load_automations() -> list:
    """Load all automation YAML files from the automations directory."""
    automations = []
    if not _YAML_AVAILABLE or not AUTOMATIONS_DIR.exists():
        return automations

    for f in sorted(AUTOMATIONS_DIR.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8"))
            if data and isinstance(data, dict):
                data["_file"] = str(f)
                automations.append(data)
        except Exception:
            continue

    # Also try .yml extension
    for f in sorted(AUTOMATIONS_DIR.glob("*.yml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8"))
            if data and isinstance(data, dict):
                data["_file"] = str(f)
                automations.append(data)
        except Exception:
            continue

    return automations


def match_automation(event_type: str, event_data: dict,
                     automations: list = None) -> list:
    """
    Find automations whose trigger matches the given event.

    Returns list of matching automation dicts.
    """
    if automations is None:
        automations = load_automations()

    matched = []
    for auto in automations:
        if not auto.get("enabled", True):
            continue

        trigger = auto.get("trigger", {})
        trigger_event = trigger.get("event", "")

        # Event type must match
        if trigger_event != event_type:
            continue

        # Check conditions
        conditions = trigger.get("conditions", {})
        if conditions and not _check_conditions(conditions, event_data):
            continue

        matched.append(auto)

    return matched


def _check_conditions(conditions: dict, event_data: dict) -> bool:
    """Check if event data satisfies trigger conditions."""
    # path_pattern: glob match on file path
    path_pattern = conditions.get("path_pattern")
    if path_pattern:
        file_path = event_data.get("file_path", event_data.get("path", ""))
        if not file_path or not fnmatch.fnmatch(file_path, path_pattern):
            return False

    # exclude_pattern: list of patterns that should NOT match
    exclude_patterns = conditions.get("exclude_pattern", [])
    if exclude_patterns:
        file_path = event_data.get("file_path", event_data.get("path", ""))
        if isinstance(exclude_patterns, str):
            exclude_patterns = [exclude_patterns]
        for ep in exclude_patterns:
            if file_path and fnmatch.fnmatch(file_path, ep):
                return False

    return True


class AutomationRunner:
    """Executes automation actions."""

    def __init__(self):
        self._scheduler = Scheduler() if Scheduler else None

    def execute(self, automation: dict, event_data: dict = None) -> str:
        """
        Execute all actions in an automation.

        Returns a summary string of what was done.
        """
        name = automation.get("name", "unnamed")
        actions = automation.get("actions", [])
        context = _build_context(event_data)

        results = []
        for action in actions:
            result = self._execute_action(action, context, name)
            if result:
                results.append(result)

                # Handle on_fail
                on_fail = action.get("on_fail", "ignore")
                if result.startswith("ERROR:") and on_fail == "stop":
                    break

        summary = f"[{name}] " + " | ".join(results) if results else ""
        return summary

    def _execute_action(self, action: dict, context: dict,
                        automation_name: str) -> str:
        """Execute a single action. Returns result string."""
        # Shell command action
        if "shell" in action:
            return self._run_shell_action(action, context, automation_name)

        # Match-based action (conditional on extension etc.)
        if "match" in action:
            return self._run_match_action(action, context, automation_name)

        # Recall action (memory search)
        if "recall" in action:
            return self._run_recall_action(action, context, automation_name)

        return ""

    def _run_shell_action(self, action: dict, context: dict,
                          automation_name: str) -> str:
        """Execute a shell command action."""
        cmd_template = action["shell"]
        label = action.get("label", cmd_template[:40])
        cmd = _expand_variables(cmd_template, context)

        # Safety check
        if not _is_safe_command(cmd):
            msg = f"ERROR: blocked unsafe command: {cmd[:60]}"
            _log_event("automation.blocked", {"cmd": cmd}, automation_name, msg)
            return msg

        try:
            # Get cwd from context
            cwd = context.get("repo_root", str(Path.cwd()))

            result = subprocess.run(
                cmd, shell=True, cwd=cwd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                timeout=_SHELL_TIMEOUT,
            )
            output = result.stdout.strip()[:500]
            status = "ok" if result.returncode == 0 else "fail"
            _log_event("automation.shell", {"cmd": cmd, "rc": result.returncode},
                       automation_name, f"{status}: {output[:100]}")

            if result.returncode != 0:
                return f"ERROR: [{label}] exit {result.returncode}: {output[:200]}"
            return f"[{label}] {output[:200]}" if output else f"[{label}] done"

        except subprocess.TimeoutExpired:
            msg = f"ERROR: [{label}] timeout ({_SHELL_TIMEOUT}s)"
            _log_event("automation.timeout", {"cmd": cmd}, automation_name, msg)
            return msg
        except Exception as e:
            msg = f"ERROR: [{label}] {e}"
            _log_event("automation.error", {"cmd": cmd}, automation_name, msg)
            return msg

    def _run_match_action(self, action: dict, context: dict,
                          automation_name: str) -> str:
        """Execute a match-conditional action."""
        match_cond = action["match"]
        ext = match_cond.get("extension", "")

        # Check if file extension matches
        file_ext = context.get("file_ext", "")
        if ext and file_ext != ext:
            return ""  # No match, skip silently

        # If matched, execute the inner action (shell or recipe)
        if "shell" in action:
            return self._run_shell_action(action, context, automation_name)
        if "recipe" in action:
            recipe_name = action["recipe"]
            return f"[recipe:{recipe_name}] would execute (not yet connected)"

        return ""

    def _run_recall_action(self, action: dict, context: dict,
                           automation_name: str) -> str:
        """Execute a memory recall action."""
        recall_config = action["recall"]
        query = recall_config.get("query", "")
        label = recall_config.get("label", action.get("label", "recall"))
        query = _expand_variables(query, context)

        try:
            from cont import memory_recall
            results = memory_recall(query, limit=5)
            if results:
                items = [r["content"][:80] for r in results[:3]]
                return f"[{label}] {'; '.join(items)}"
            return f"[{label}] no results"
        except Exception as e:
            return f"[{label}] recall failed: {e}"

    def get_pending_scheduled(self) -> list:
        """
        Get automations that should run now based on schedule triggers.

        Checks daily/weekly triggers against scheduler state.
        Returns list of (automation, period) tuples.
        """
        if not self._scheduler:
            return []

        automations = load_automations()
        pending = []

        for auto in automations:
            if not auto.get("enabled", True):
                continue

            trigger = auto.get("trigger", {})
            event = trigger.get("event", "")
            name = auto.get("name", "unnamed")

            if event == "schedule.daily":
                if self._scheduler.check_daily(name):
                    pending.append((auto, "daily"))

            elif event == "schedule.weekly":
                day = trigger.get("day", "")
                if self._scheduler.check_weekly(name, day):
                    pending.append((auto, "weekly"))

        return pending

    def run_pending(self) -> list:
        """
        Run all pending scheduled automations.

        Returns list of (name, summary) tuples.
        """
        results = []
        for auto, period in self.get_pending_scheduled():
            name = auto.get("name", "unnamed")
            summary = self.execute(auto)
            if self._scheduler:
                self._scheduler.mark_done(name, period)
            results.append((name, summary))
        return results


def register_event_handlers() -> None:
    """
    Register automation event handlers with the global EventBus.

    This connects file/task events to automation matching and execution.
    """
    if not event_bus:
        return

    runner = AutomationRunner()

    def _automation_handler(event_type: str, data: dict):
        """Generic handler that finds and runs matching automations."""
        matched = match_automation(event_type, data)
        results = []
        for auto in matched:
            summary = runner.execute(auto, data)
            if summary:
                results.append(summary)
        return results

    # Register for all event-triggered automation types
    for event_type in [
        "file.created", "file.modified", "file.deleted",
        "task.completed", "task.failed",
        "build.failed", "test.failed",
        "inbox.new_file",
    ]:
        event_bus.subscribe(event_type, _automation_handler,
                            name=f"automations:{event_type}")
