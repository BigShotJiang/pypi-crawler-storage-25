# core/intent_detection.py
"""User intent detection (read vs write) and write protection."""

import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.utils import debug as _debug


# Read-only intent patterns (user wants to SEE, not MODIFY)
READ_INTENT_PATTERNS = [
    r"\b(bul|ara|göster|listele|oku|getir|nerede|hangisi)\b",  # Turkish
    r"\b(find|search|show|list|read|get|where|which|display|look|check)\b",  # English
    r"\b(what|what's|whats|how|does|is there|are there|can you find)\b",
    r"^\s*(ls|cat|grep|find|locate|show me|tell me|what)\b",
]

# Write intent patterns (user explicitly wants to MODIFY)
WRITE_INTENT_PATTERNS = [
    r"\b(yaz|oluştur|değiştir|düzelt|ekle|sil|güncelle|düzenle)\b",  # Turkish
    r"\b(write|create|modify|change|fix|add|delete|remove|update|edit|patch|replace)\b",  # English
    r"\b(make|set|put|insert|append|overwrite|save)\b",
    r"\b(refactor|rename|move|convert)\b",
    r"\b(delete|remove|sil|kaldır|temizle)\s+(all|tüm|hepsi)?",  # "delete all X"
    r"\b(clean|purge|wipe|clear)\b",
]

# Destructive tools that require intent verification
DESTRUCTIVE_TOOLS = {
    "write_file": "write/create file",
    "apply_patch": "modify file content",
    "run_shell": "execute command",  # Some shell commands are destructive
    "forget": "delete memory",
}

# Shell commands that are destructive
DESTRUCTIVE_SHELL_PATTERNS = [
    r"\brm\s+",
    r"\brm\s+-rf?\s+",
    r"\brmdir\b",
    r"\bunlink\b",
    r"\bmv\s+",
    r"\bcp\s+.*>",  # cp with overwrite
    r">",  # redirect (overwrites)
    r"\bsed\s+-i",
    r"\bchmod\b",
    r"\bchown\b",
    r"\bgit\s+(push|reset|checkout|clean)",
    r"\bpip\s+install",
    r"\bnpm\s+install",
]

SAFE_READ_COMMANDS = [
    "find", "ls", "cat", "head", "tail", "grep", "rg", "wc", "file",
    "stat", "du", "df", "which", "whereis", "type", "echo", "pwd",
    "tree", "less", "more", "diff", "sort", "uniq", "cut", "tr",
    "python -c", "python3 -c", "py_compile",
]


def detect_user_intent(task: str) -> str:
    """
    Detect if user wants to READ or WRITE.
    Returns: 'read', 'write', or 'ambiguous'
    """
    task_lower = task.lower()

    read_score = 0
    write_score = 0

    for pattern in READ_INTENT_PATTERNS:
        if re.search(pattern, task_lower):
            read_score += 1

    for pattern in WRITE_INTENT_PATTERNS:
        if re.search(pattern, task_lower):
            write_score += 1

    # === MIXED INTENT DETECTION ===
    # "find and delete", "bul ve sil" → treat as WRITE (delete is destructive)
    mixed_patterns = [
        r"(find|bul|ara).*(delete|remove|sil|kaldır)",
        r"(search|ara).*(delete|remove|sil)",
        r"(list|listele).*(delete|remove|sil)",
    ]
    for pattern in mixed_patterns:
        if re.search(pattern, task_lower):
            _debug(f"Mixed intent detected: {pattern}")
            return "write"  # Destructive action takes precedence
    # === END MIXED INTENT ===

    if write_score > read_score:
        return "write"
    elif read_score > write_score:
        return "read"
    else:
        return "ambiguous"


def is_shell_destructive(cmd: str) -> bool:
    """Check if a shell command is destructive."""
    cmd_stripped = cmd.strip().lower()
    # Safe read-only commands are never destructive
    for safe in SAFE_READ_COMMANDS:
        if cmd_stripped.startswith(safe):
            return False
    for pattern in DESTRUCTIVE_SHELL_PATTERNS:
        if re.search(pattern, cmd_stripped):
            return True
    return False


class WriteProtection:
    """Manages write protection and confirmations."""

    def __init__(self, backup_dir: Path = None):
        self.user_intent = "ambiguous"
        self.original_task = ""
        self.write_confirmed = False
        self.dry_run = False
        self.pending_writes = []  # Track pending write operations
        self.backup_dir = backup_dir

    def set_task(self, task: str):
        """Set the current task and detect intent."""
        self.original_task = task
        self.user_intent = detect_user_intent(task)
        self.write_confirmed = (self.user_intent == "write")
        self.pending_writes = []
        _debug(f"User intent: {self.user_intent} for task: {task[:50]}")

    def should_block_write(self, tool_name: str, args: dict) -> tuple:
        """
        Check if a write operation should be blocked.
        Returns: (should_block: bool, reason: str, details: dict)
        """
        # If not a destructive tool, allow
        if tool_name not in DESTRUCTIVE_TOOLS:
            return False, "", {}

        # If user intent was clearly write, allow
        if self.write_confirmed:
            return False, "", {}

        # If dry-run mode, block all writes
        if self.dry_run:
            return True, "dry_run", {"tool": tool_name, "args": args}

        # Special handling for run_shell
        if tool_name == "run_shell":
            cmd = args.get("cmd", "")
            if not is_shell_destructive(cmd):
                return False, "", {}  # Non-destructive shell command, allow
            details = {"cmd": cmd}
        else:
            details = {"path": args.get("path", "unknown")}

        # User intent was read or ambiguous, block write
        if self.user_intent in ("read", "ambiguous"):
            return True, "intent_mismatch", {
                "tool": tool_name,
                "action": DESTRUCTIVE_TOOLS[tool_name],
                "user_intent": self.user_intent,
                "original_task": self.original_task,
                **details
            }

        return False, "", {}

    def create_backup(self, path: str) -> Optional[str]:
        """Create a backup of a file before modifying it."""
        try:
            source = Path(path)
            if not source.exists() or not source.is_file():
                return None
            if self.backup_dir is None:
                return None

            self.backup_dir.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{source.name}.{timestamp}.bak"
            backup_path = self.backup_dir / backup_name

            shutil.copy2(source, backup_path)
            _debug(f"Backup created: {backup_path}")

            return str(backup_path)
        except Exception as e:
            _debug(f"Backup failed: {e}")
            return None

    def request_confirmation(self, tool_name: str, args: dict) -> str:
        """Generate a bilingual confirmation request message."""
        action = DESTRUCTIVE_TOOLS.get(tool_name, tool_name)

        if tool_name == "run_shell":
            target = args.get("cmd", "command")
        else:
            target = args.get("path", "target")

        return f"""
⚠️  WRITE PROTECTION / YAZMA KORUMASI

You asked / Siz istediniz: "{self.original_task}"
Detected as / Algılanan: READ (sadece oku/göster)

But I'm about to / Ama yapmak üzereydim: {action}
Target / Hedef: {target}

This seems like a mismatch. / Bu uyumsuz görünüyor.

Please confirm / Lütfen onaylayın:
- "yes" / "evet" → Proceed with modification / Değişikliği yap
- "no" / "hayır" → Cancel and just show info / İptal et, sadece göster
"""
