# core/utils.py
"""Shared utility functions used by multiple core modules."""

import os
import sys
from pathlib import Path


# ── Config constants (derived from environment, no cont.py dependency) ──
REPO_ROOT = Path(os.environ.get("CONT_REPO_ROOT", os.getcwd())).resolve()
CONT_DIR = Path(__file__).parent.parent.resolve()  # cont project root
LOG_LEVEL = os.environ.get("CONT_LOG_LEVEL", "").lower()
LOG_DIR = CONT_DIR / "logs" / "cont_runs"


def clean_surrogates(text: str) -> str:
    """Remove surrogate characters that break UTF-8 encoding.

    WSL2 can produce surrogate characters when reading Windows file paths.
    These cause 'surrogates not allowed' errors when sent to the LLM API.
    """
    if not isinstance(text, str):
        return text
    try:
        return text.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
    except Exception:
        return text.encode('utf-8', errors='replace').decode('utf-8')


def _clean_messages(messages: list) -> list:
    """Clean all string values in a messages list of surrogate characters."""
    cleaned = []
    for msg in messages:
        cmsg = {}
        for k, v in msg.items():
            if isinstance(v, str):
                cmsg[k] = clean_surrogates(v)
            elif isinstance(v, list):
                cmsg[k] = v
            else:
                cmsg[k] = v
        cleaned.append(cmsg)
    return cleaned


def slugify(s: str, max_len: int = 48) -> str:
    """Convert string to slug: lowercase, replace non-alnum with dash, collapse dashes."""
    import re
    slug = re.sub(r'[^a-z0-9]+', '-', s.lower())
    slug = re.sub(r'-+', '-', slug).strip('-')
    return slug[:max_len] if slug else "unknown-error"


def debug(msg: str):
    """Print debug message if CONT_LOG_LEVEL=debug.

    Uses stderr to avoid interfering with Rich console output.
    When imported by core modules that don't have access to Rich console,
    this prints to stderr. cont.py overrides this with its own _debug()
    that uses Rich console.
    """
    if LOG_LEVEL == "debug":
        print(f"[DEBUG] {msg}", file=sys.stderr)


# ── Canonical JSON fixup for tool_call arguments ──
# Single source of truth.  Both adapter (cont.py, Layer 1) and runtime
# (core/runtime.py, Layer 2) call this.  Only FORMAT fixes — never
# invents missing keys or fills in values.

import json
import re

_JSON_FIXUPS: list[tuple[str, callable]] = []  # populated below


def _fixup_trailing_comma(raw: str) -> str:
    return re.sub(r',\s*([}\]])', r'\1', raw)


def _fixup_single_quotes(raw: str) -> str:
    return raw.replace("'", '"')


def _fixup_control_chars(raw: str) -> str:
    return raw.replace('\n', '\\n').replace('\t', '\\t')


def _fixup_python_literals(raw: str) -> str:
    """True/False/None → true/false/null (Python → JSON)."""
    return raw.replace('True', 'true').replace('False', 'false').replace('None', 'null')


_JSON_FIXUPS = [
    ("trailing_comma",   _fixup_trailing_comma),
    ("single_quotes",    _fixup_single_quotes),
    ("control_chars",    _fixup_control_chars),
    ("python_literals",  _fixup_python_literals),
]


def fixup_json(raw: str) -> tuple[str, str | None]:
    """Try to fix malformed JSON from local LLMs.

    Returns (fixed_string, method_name) on success,
            (raw_string,   None)        if all fixups fail.

    Rules:
    - Only format corrections (commas, quotes, escapes, literals).
    - Never adds missing keys or invents values.
    - Deterministic and idempotent.
    """
    # Fast path: already valid
    try:
        json.loads(raw)
        return raw, None  # no fixup needed
    except (json.JSONDecodeError, ValueError):
        pass

    for name, fn in _JSON_FIXUPS:
        try:
            candidate = fn(raw)
            json.loads(candidate)
            return candidate, name
        except (json.JSONDecodeError, ValueError):
            continue

    return raw, None  # all failed
