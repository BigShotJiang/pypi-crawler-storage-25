# core/memory_eviction.py
"""
Memory eviction — keeps memory clean and relevant.

Rules:
1. Negative feedback memories: delete after 7 days
2. Duplicate content: keep newest, delete rest
3. Low-importance + old: delete after 30 days
4. Cap total memories at 500
"""

import re
import sqlite3
import time
from datetime import datetime, timedelta
from typing import Optional

from core.utils import debug as _debug


NOISE_PATTERNS = [
    r"memnun de\u011fil",
    r"ba\u015far\u0131s\u0131z",
    r"basarisiz",
    r"hata",
    r"failed",
    r"k\u00f6t\u00fc",
    r"/k\u00f6t\u00fc",
    r"timeout",
    r"eri\u015femiyorum",
    r"erisemiyorum",
    r"yap(a)?m\u0131yorum",
    r"bulunamad\u0131",
    r"bulunamadi",
]

_COMPILED_NOISE = [re.compile(p, re.IGNORECASE) for p in NOISE_PATTERNS]

# Max memories to keep
MAX_MEMORIES = 500


def _parse_ts(ts_str: str) -> Optional[float]:
    """Parse ISO timestamp to epoch float."""
    if not ts_str:
        return None
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        return dt.timestamp()
    except Exception:
        return None


def run_eviction(conn: sqlite3.Connection, dry_run: bool = False) -> int:
    """Run all eviction rules. Returns count of affected rows."""
    total = 0

    cutoff_7d = (datetime.now() - timedelta(days=7)).isoformat()
    cutoff_30d = (datetime.now() - timedelta(days=30)).isoformat()

    # Rule 1: Delete negative/failure memories older than 7 days
    cursor = conn.execute(
        "SELECT id, content FROM semantic_memory "
        "WHERE created_at < ?",
        (cutoff_7d,),
    )

    to_delete = []
    for row in cursor:
        mid, content = row
        if not content:
            continue
        content_lower = content.lower()
        if any(p.search(content_lower) for p in _COMPILED_NOISE):
            to_delete.append(mid)

    if to_delete and not dry_run:
        placeholders = ",".join("?" * len(to_delete))
        conn.execute(
            f"DELETE FROM semantic_memory WHERE id IN ({placeholders})",
            to_delete,
        )
        total += len(to_delete)
        _debug(f"Eviction: {len(to_delete)} negative memories deleted (>7d)")

    # Rule 2: Deduplicate — same content, keep newest
    cursor = conn.execute(
        "SELECT content, COUNT(*) as cnt, "
        "GROUP_CONCAT(id) as ids, MAX(created_at) as newest "
        "FROM semantic_memory GROUP BY content HAVING cnt > 1"
    )

    dedup_delete = []
    for row in cursor:
        content, cnt, ids_str, newest_ts = row
        ids = [int(x) for x in ids_str.split(",")]
        # Find the newest ID
        newest_row = conn.execute(
            "SELECT id FROM semantic_memory "
            "WHERE content = ? ORDER BY created_at DESC LIMIT 1",
            (content,),
        ).fetchone()
        keep_id = newest_row[0] if newest_row else ids[-1]
        dedup_delete.extend(mid for mid in ids if mid != keep_id)

    if dedup_delete and not dry_run:
        placeholders = ",".join("?" * len(dedup_delete))
        conn.execute(
            f"DELETE FROM semantic_memory WHERE id IN ({placeholders})",
            dedup_delete,
        )
        total += len(dedup_delete)
        _debug(f"Eviction: {len(dedup_delete)} duplicate memories merged")

    # Rule 3: Low importance + old = delete
    if not dry_run:
        cursor = conn.execute(
            "DELETE FROM semantic_memory "
            "WHERE created_at < ? AND importance < 0.3",
            (cutoff_30d,),
        )
        if cursor.rowcount:
            total += cursor.rowcount
            _debug(
                f"Eviction: {cursor.rowcount} low-importance "
                f"memories deleted (>30d)"
            )

    # Rule 4: Cap total memories
    count_row = conn.execute(
        "SELECT COUNT(*) FROM semantic_memory"
    ).fetchone()
    count = count_row[0] if count_row else 0

    if count > MAX_MEMORIES and not dry_run:
        excess = count - MAX_MEMORIES
        conn.execute(
            "DELETE FROM semantic_memory WHERE id IN ("
            "  SELECT id FROM semantic_memory "
            "  ORDER BY importance ASC, created_at ASC "
            "  LIMIT ?"
            ")",
            (excess,),
        )
        total += excess
        _debug(f"Eviction: {excess} overflow memories deleted (cap: {MAX_MEMORIES})")

    if not dry_run:
        conn.commit()

    return total


def evict_on_startup(db_connect_fn) -> int:
    """Run eviction at startup. Silent if nothing to do."""
    try:
        conn = db_connect_fn()
        total = run_eviction(conn)
        conn.close()
        if total > 0:
            _debug(f"Startup eviction: {total} records cleaned")
        return total
    except Exception as e:
        _debug(f"Startup eviction failed: {e}")
        return 0
