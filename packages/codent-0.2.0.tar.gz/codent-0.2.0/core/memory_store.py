# core/memory_store.py
"""
Memory store: SQLite-backed memory for solutions, attempts, semantic memory,
embeddings, error mapping, autofix, daily summaries, and feedback.
"""

import json
import sys
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Any, Optional

from core.utils import clean_surrogates, debug as _debug

try:
    from core.trace import is_off as _trace_off, trace_memory_search
except ImportError:
    _trace_off = lambda: True
    trace_memory_search = lambda **kw: None

# Embedding support (optional)
try:
    import logging as _logging
    _logging.getLogger("sentence_transformers").setLevel(_logging.ERROR)
    _logging.getLogger("transformers").setLevel(_logging.ERROR)
    from sentence_transformers import SentenceTransformer
    import numpy as np
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False
    SentenceTransformer = None
    np = None


# =====================
# Memory Store (SQLite)
# =====================
def _cont_state_dir() -> Path:
    """Return ~/.cont/ directory path."""
    return Path.home() / ".cont"

def _memory_db_path() -> Path:
    """Return path to ~/.cont/memory.sqlite."""
    return _cont_state_dir() / "memory.sqlite"

def _db_connect() -> sqlite3.Connection:
    """Connect to memory database, ensuring dir exists and setting pragmas."""
    state_dir = _cont_state_dir()
    state_dir.mkdir(parents=True, exist_ok=True)
    db_path = _memory_db_path()
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn

def memory_init_db():
    """Initialize memory database tables (idempotent)."""
    conn = _db_connect()
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS env_snapshot (
                env_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                repo_root TEXT,
                facts_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS solution (
                solution_id INTEGER PRIMARY KEY AUTOINCREMENT,
                problem_signature TEXT NOT NULL,
                title TEXT NOT NULL,
                steps_json TEXT NOT NULL,
                tags_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                disabled INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS attempt (
                attempt_id INTEGER PRIMARY KEY AUTOINCREMENT,
                solution_id INTEGER NULL,
                env_id TEXT NULL,
                inputs_hash TEXT NULL,
                result TEXT NOT NULL,
                error_signature TEXT NULL,
                stdout_tail TEXT NULL,
                stderr_tail TEXT NULL,
                duration_ms INTEGER NULL,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_attempt_env_created
                ON attempt(env_id, created_at);

            CREATE INDEX IF NOT EXISTS idx_solution_problem_disabled
                ON solution(problem_signature, disabled);

            CREATE TABLE IF NOT EXISTS error_map (
                error_sig TEXT PRIMARY KEY,
                problem_signature TEXT NOT NULL,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL,
                hits INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS autofix_allow (
                problem_signature TEXT PRIMARY KEY,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
        """)

        # Semantic memory table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS semantic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                memory_type TEXT DEFAULT 'fact',
                source TEXT DEFAULT 'agent',
                importance REAL DEFAULT 0.5,
                tags TEXT DEFAULT '[]',
                created_at TEXT NOT NULL,
                last_accessed TEXT,
                access_count INTEGER DEFAULT 0,
                embedding TEXT DEFAULT NULL
            )
        """)

        # FTS5 for semantic search
        conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS semantic_memory_fts
            USING fts5(content, memory_type, tags, content=semantic_memory, content_rowid=id)
        """)

        # Triggers to keep FTS in sync
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS semantic_memory_ai AFTER INSERT ON semantic_memory BEGIN
                INSERT INTO semantic_memory_fts(rowid, content, memory_type, tags)
                VALUES (new.id, new.content, new.memory_type, new.tags);
            END
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS semantic_memory_ad AFTER DELETE ON semantic_memory BEGIN
                INSERT INTO semantic_memory_fts(semantic_memory_fts, rowid, content, memory_type, tags)
                VALUES('delete', old.id, old.content, old.memory_type, old.tags);
            END
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS semantic_memory_au AFTER UPDATE ON semantic_memory BEGIN
                INSERT INTO semantic_memory_fts(semantic_memory_fts, rowid, content, memory_type, tags)
                VALUES('delete', old.id, old.content, old.memory_type, old.tags);
                INSERT INTO semantic_memory_fts(rowid, content, memory_type, tags)
                VALUES (new.id, new.content, new.memory_type, new.tags);
            END
        """)

        # Daily summaries table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary (
                date TEXT PRIMARY KEY,
                summary TEXT NOT NULL,
                task_count INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
        """)

        # Self-improvement: task outcome tracking
        conn.execute("""
            CREATE TABLE IF NOT EXISTS task_outcome (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_text TEXT NOT NULL,
                task_type TEXT,
                success INTEGER NOT NULL,
                failure_reason TEXT,
                reflection TEXT,
                tool_calls_count INTEGER,
                duration_ms INTEGER,
                model_used TEXT,
                prompt_tokens_approx INTEGER,
                created_at TEXT NOT NULL
            )
        """)

        # Feedback system: user + self-assessment feedback
        conn.execute("""
            CREATE TABLE IF NOT EXISTS task_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_outcome_id INTEGER NOT NULL,
                source TEXT NOT NULL,
                rating INTEGER,
                note TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (task_outcome_id) REFERENCES task_outcome(id)
            )
        """)

        # Self-improvement: learned prompt patches
        conn.execute("""
            CREATE TABLE IF NOT EXISTS prompt_patch (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                patch_text TEXT NOT NULL,
                trigger_pattern TEXT,
                success_delta REAL,
                active INTEGER DEFAULT 1,
                created_at TEXT NOT NULL
            )
        """)

        # Index for fast task_outcome lookups
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_task_outcome_type_created
            ON task_outcome(task_type, created_at)
        """)

        # Learning system: recipe stats table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS recipe_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipe_name TEXT NOT NULL,
                success INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        # Learning system: file-based patch stats table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS patch_file_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patch_id TEXT NOT NULL,
                success INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        # Automation system: run log table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS automation_run (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                automation_name TEXT NOT NULL,
                trigger_event TEXT,
                actions_count INTEGER DEFAULT 0,
                success INTEGER NOT NULL,
                summary TEXT,
                duration_ms INTEGER,
                created_at TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_automation_run_name
            ON automation_run(automation_name, created_at)
        """)

        # Self-improvement loop: fix log table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS self_improve_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                issue_type TEXT NOT NULL,
                task_text TEXT,
                fix_type TEXT,
                success INTEGER NOT NULL,
                details_json TEXT
            )
        """)

        # Migration: add embedding column if not exists
        try:
            conn.execute("ALTER TABLE semantic_memory ADD COLUMN embedding TEXT DEFAULT NULL")
        except Exception:
            pass  # Column already exists

        conn.commit()
    finally:
        conn.close()

def memory_stats() -> dict:
    """Get memory database statistics."""
    db_path = _memory_db_path()
    exists = db_path.exists()

    result = {
        "db_path": str(db_path),
        "exists": exists,
        "tables": {"env_snapshot": 0, "solution": 0, "attempt": 0},
        "last_attempt_at": None
    }

    if not exists:
        return result

    # Ensure tables exist
    memory_init_db()

    conn = _db_connect()
    try:
        # Count rows in each table
        for table in ["env_snapshot", "solution", "attempt"]:
            cur = conn.execute(f"SELECT COUNT(*) FROM {table}")
            result["tables"][table] = cur.fetchone()[0]

        # Get last attempt timestamp
        cur = conn.execute(
            "SELECT created_at FROM attempt ORDER BY created_at DESC LIMIT 1"
        )
        row = cur.fetchone()
        if row:
            result["last_attempt_at"] = row[0]
    finally:
        conn.close()

    return result

def _stable_json(obj: Any) -> str:
    """Produce stable JSON for hashing (sorted keys, compact)."""
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))

def compute_env_id(snapshot: dict) -> str:
    """Compute a stable env_id hash from snapshot subset."""
    subset = {
        "repo_root": snapshot.get("repo_root"),
        "host": snapshot.get("host"),
        "os_release": snapshot.get("os_release", {}),
        "python_version": snapshot.get("python", {}).get("version"),
        "python_executable": snapshot.get("python", {}).get("executable"),
        "conda_available": snapshot.get("conda", {}).get("available"),
        "conda_active_env": snapshot.get("conda", {}).get("active_env"),
        "gpu_gpus": snapshot.get("gpu", {}).get("gpus"),
        "openai_base_url": snapshot.get("env_vars", {}).get("OPENAI_BASE_URL"),
        "cont_repo_root": snapshot.get("env_vars", {}).get("CONT_REPO_ROOT"),
    }
    stable = _stable_json(subset)
    return hashlib.sha256(stable.encode()).hexdigest()[:16]

def memory_upsert_env_snapshot(snapshot: dict) -> str:
    """Upsert env snapshot into DB, return env_id."""
    memory_init_db()
    env_id = compute_env_id(snapshot)
    facts_json = _stable_json(snapshot)
    repo_root = snapshot.get("repo_root")
    created_at = datetime.now().isoformat()

    conn = _db_connect()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO env_snapshot (env_id, created_at, repo_root, facts_json)
               VALUES (?, ?, ?, ?)""",
            (env_id, created_at, repo_root, facts_json)
        )
        conn.commit()
    finally:
        conn.close()

    return env_id

def _truncate(s: str, n: int = 2000) -> str:
    """Truncate string to last n characters."""
    if len(s) <= n:
        return s
    return s[-n:]

def _error_signature_from_output(output: str) -> Optional[str]:
    """Extract error signature from command output."""
    if not output or not output.strip():
        return None

    lines = output.strip().splitlines()

    # Check for "API Error:" line
    for line in lines:
        if "API Error:" in line:
            return line.strip()[:200]

    # Check for Traceback - take last non-empty line
    if "Traceback" in output:
        for line in reversed(lines):
            if line.strip():
                return line.strip()[:200]

    # Fallback: first 120 chars, collapsed whitespace
    collapsed = " ".join(output.split())
    return collapsed[:120] if collapsed else None

def memory_log_attempt(env_id: str, cmd: str, exit_code: int, output: str, duration_ms: int, solution_id: int = None) -> None:
    """Log a shell command attempt to the database."""
    memory_init_db()

    result = "ok" if exit_code == 0 else "fail"
    stdout_tail = _truncate(output, 2000) if output else None
    error_signature = _error_signature_from_output(output) if exit_code != 0 else None
    inputs_hash = hashlib.sha256(cmd.encode()).hexdigest()[:16]
    created_at = datetime.now().isoformat()

    conn = _db_connect()
    try:
        conn.execute(
            """INSERT INTO attempt
               (solution_id, env_id, inputs_hash, result, error_signature, stdout_tail, stderr_tail, duration_ms, created_at)
               VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)""",
            (solution_id, env_id, inputs_hash, result, error_signature, stdout_tail, duration_ms, created_at)
        )
        conn.commit()
    finally:
        conn.close()

def memory_add_solution(problem_signature: str, title: str, steps: list, tags: list = None) -> int:
    """Add a solution to the database. Returns solution_id."""
    memory_init_db()
    steps_json = _stable_json(steps)
    tags_json = _stable_json(tags or [])
    created_at = datetime.now().isoformat()

    conn = _db_connect()
    try:
        cur = conn.execute(
            """INSERT INTO solution (problem_signature, title, steps_json, tags_json, created_at, disabled)
               VALUES (?, ?, ?, ?, ?, 0)""",
            (problem_signature, title, steps_json, tags_json, created_at)
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def _parse_iso_timestamp(ts: str) -> datetime:
    """Parse ISO timestamp, handling trailing Z."""
    if ts.endswith("Z"):
        ts = ts[:-1] + "+00:00"
    return datetime.fromisoformat(ts)

def memory_solution_stats(problem_signature: str, env_id: str = None) -> dict:
    """Compute stats for all non-disabled solutions with this signature."""
    memory_init_db()
    conn = _db_connect()
    try:
        # Get all solutions for this signature
        cur = conn.execute(
            """SELECT solution_id, created_at FROM solution
               WHERE problem_signature = ? AND disabled = 0""",
            (problem_signature,)
        )
        solutions = cur.fetchall()

        stats = {}
        for sol_id, sol_created_at in solutions:
            # Get attempt stats for this solution
            cur = conn.execute(
                """SELECT COUNT(*) as total,
                          SUM(CASE WHEN result='ok' THEN 1 ELSE 0 END) as ok_count,
                          MAX(created_at) as last_run_at
                   FROM attempt WHERE solution_id = ?""",
                (sol_id,)
            )
            row = cur.fetchone()
            total = row[0] or 0
            ok_count = row[1] or 0
            fail_count = total - ok_count
            last_run_at = row[2]

            # Get last result
            last_result = None
            if last_run_at:
                cur = conn.execute(
                    """SELECT result FROM attempt
                       WHERE solution_id = ? ORDER BY created_at DESC LIMIT 1""",
                    (sol_id,)
                )
                lr = cur.fetchone()
                if lr:
                    last_result = lr[0]

            sol_stats = {
                "solution_id": sol_id,
                "created_at": sol_created_at,
                "attempts_total": total,
                "attempts_ok": ok_count,
                "attempts_fail": fail_count,
                "success_rate": ok_count / total if total > 0 else None,
                "last_run_at": last_run_at,
                "last_result": last_result
            }

            # Add env-specific stats if env_id provided
            if env_id:
                cur = conn.execute(
                    """SELECT COUNT(*) as total,
                              SUM(CASE WHEN result='ok' THEN 1 ELSE 0 END) as ok_count
                       FROM attempt WHERE solution_id = ? AND env_id = ?""",
                    (sol_id, env_id)
                )
                env_row = cur.fetchone()
                env_total = env_row[0] or 0
                env_ok = env_row[1] or 0
                sol_stats["env_attempts_total"] = env_total
                sol_stats["env_attempts_ok"] = env_ok
                sol_stats["env_success_rate"] = env_ok / env_total if env_total > 0 else None

                # Get last result for this env
                cur = conn.execute(
                    """SELECT result FROM attempt
                       WHERE solution_id = ? AND env_id = ?
                       ORDER BY created_at DESC LIMIT 1""",
                    (sol_id, env_id)
                )
                env_lr = cur.fetchone()
                sol_stats["env_last_result"] = env_lr[0] if env_lr else None

            stats[sol_id] = sol_stats
        return stats
    finally:
        conn.close()

def memory_get_best_solution(problem_signature: str, env_id: str = None) -> Optional[dict]:
    """Get the best solution for a problem signature using scoring."""
    memory_init_db()

    conn = _db_connect()
    try:
        # Get all non-disabled solutions
        cur = conn.execute(
            """SELECT solution_id, problem_signature, title, steps_json, tags_json, created_at
               FROM solution
               WHERE problem_signature = ? AND disabled = 0""",
            (problem_signature,)
        )
        solutions = cur.fetchall()

        if not solutions:
            return None

        # Get stats for scoring (with env_id if provided)
        stats = memory_solution_stats(problem_signature, env_id=env_id)
        now = datetime.now()

        best_solution = None
        best_score = -1

        for row in solutions:
            sol_id = row[0]
            sol_created_at = row[5]
            sol_stats = stats.get(sol_id, {})

            # Compute global score
            score = 0.0
            attempts_total = sol_stats.get("attempts_total", 0)
            success_rate = sol_stats.get("success_rate")
            last_result = sol_stats.get("last_result")
            last_run_at = sol_stats.get("last_run_at")

            if attempts_total > 0 and success_rate is not None:
                score += 2.0 * success_rate
            else:
                # New solution with no attempts - modest score
                score += 0.2

            if last_result == "ok":
                score += 0.5

            # Recency bonuses
            if last_run_at:
                try:
                    last_run_dt = _parse_iso_timestamp(last_run_at)
                    if (now - last_run_dt).days <= 7:
                        score += 0.3
                except Exception:
                    pass

            try:
                created_dt = _parse_iso_timestamp(sol_created_at)
                if (now - created_dt).days <= 30:
                    score += 0.1
            except Exception:
                pass

            # Environment-specific scoring bonus
            if env_id:
                env_attempts_total = sol_stats.get("env_attempts_total", 0)
                env_success_rate = sol_stats.get("env_success_rate")
                env_last_result = sol_stats.get("env_last_result")

                if env_attempts_total > 0 and env_success_rate is not None:
                    score += 0.8 * env_success_rate

                if env_last_result == "ok":
                    score += 0.2

            # Choose best by score, tie-breaker: newest created_at
            if score > best_score or (score == best_score and best_solution and sol_created_at > best_solution[5]):
                best_score = score
                best_solution = row

        if not best_solution:
            return None

        return {
            "solution_id": best_solution[0],
            "problem_signature": best_solution[1],
            "title": best_solution[2],
            "steps": json.loads(best_solution[3]),
            "tags": json.loads(best_solution[4]),
            "created_at": best_solution[5]
        }
    finally:
        conn.close()

def memory_check_recent_failure(solution_id: int, env_id: str, hours: int = 24) -> Optional[dict]:
    """Check if this solution failed recently in this env. Returns attempt info or None."""
    memory_init_db()
    conn = _db_connect()
    try:
        cur = conn.execute(
            """SELECT result, created_at FROM attempt
               WHERE solution_id = ? AND env_id = ?
               ORDER BY created_at DESC LIMIT 1""",
            (solution_id, env_id)
        )
        row = cur.fetchone()
        if not row:
            return None

        result, created_at = row
        if result != "fail":
            return None

        # Check if within time window
        try:
            attempt_dt = _parse_iso_timestamp(created_at)
            now = datetime.now()
            if (now - attempt_dt).total_seconds() < hours * 3600:
                return {"result": result, "created_at": created_at}
        except Exception:
            pass

        return None
    finally:
        conn.close()

# =====================
# Error Mapping (error_sig -> problem_signature)
# =====================
def memory_map_error(error_sig: str, problem_signature: str, title: str) -> None:
    """Map an error signature to a problem signature."""
    memory_init_db()
    created_at = datetime.now().isoformat()
    conn = _db_connect()
    try:
        # INSERT OR REPLACE resets hits to 0 on new insert
        conn.execute(
            """INSERT OR REPLACE INTO error_map (error_sig, problem_signature, title, created_at, hits)
               VALUES (?, ?, ?, ?, COALESCE((SELECT hits FROM error_map WHERE error_sig = ?), 0))""",
            (error_sig, problem_signature, title, created_at, error_sig)
        )
        conn.commit()
    finally:
        conn.close()

def memory_unmap_error(error_sig: str) -> None:
    """Remove an error signature mapping."""
    memory_init_db()
    conn = _db_connect()
    try:
        conn.execute("DELETE FROM error_map WHERE error_sig = ?", (error_sig,))
        conn.commit()
    finally:
        conn.close()

def memory_get_error_mappings(limit: int = 50) -> list:
    """Get error mappings, most recent first."""
    memory_init_db()
    conn = _db_connect()
    try:
        cur = conn.execute(
            """SELECT error_sig, problem_signature, title, hits, created_at
               FROM error_map ORDER BY created_at DESC LIMIT ?""",
            (limit,)
        )
        return [
            {"error_sig": r[0], "problem_signature": r[1], "title": r[2], "hits": r[3], "created_at": r[4]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()

def memory_lookup_error(error_sig: str) -> Optional[dict]:
    """Look up error signature in error_map. Returns mapping or None."""
    memory_init_db()
    conn = _db_connect()
    try:
        cur = conn.execute(
            "SELECT error_sig, problem_signature, title, hits FROM error_map WHERE error_sig = ?",
            (error_sig,)
        )
        row = cur.fetchone()
        if not row:
            return None
        return {"error_sig": row[0], "problem_signature": row[1], "title": row[2], "hits": row[3]}
    finally:
        conn.close()

def memory_increment_error_hits(error_sig: str) -> None:
    """Increment hits counter for an error mapping."""
    conn = _db_connect()
    try:
        conn.execute("UPDATE error_map SET hits = hits + 1 WHERE error_sig = ?", (error_sig,))
        conn.commit()
    finally:
        conn.close()

# =====================
# Autofix Allowlist
# =====================
def memory_enable_autofix(problem_signature: str) -> None:
    """Enable autofix for a problem signature."""
    memory_init_db()
    created_at = datetime.now().isoformat()
    conn = _db_connect()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO autofix_allow (problem_signature, enabled, created_at)
               VALUES (?, 1, ?)""",
            (problem_signature, created_at)
        )
        conn.commit()
    finally:
        conn.close()

def memory_disable_autofix(problem_signature: str) -> None:
    """Disable autofix for a problem signature."""
    memory_init_db()
    created_at = datetime.now().isoformat()
    conn = _db_connect()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO autofix_allow (problem_signature, enabled, created_at)
               VALUES (?, 0, ?)""",
            (problem_signature, created_at)
        )
        conn.commit()
    finally:
        conn.close()

def memory_is_autofix_enabled(problem_signature: str) -> bool:
    """Check if autofix is enabled for a problem signature. Default: disabled."""
    memory_init_db()
    conn = _db_connect()
    try:
        cur = conn.execute(
            "SELECT enabled FROM autofix_allow WHERE problem_signature = ?",
            (problem_signature,)
        )
        row = cur.fetchone()
        if not row:
            return False  # Default: disabled if not in table
        return row[0] == 1
    finally:
        conn.close()

def memory_get_autofix_list() -> list:
    """Get all autofix allowlist entries."""
    memory_init_db()
    conn = _db_connect()
    try:
        cur = conn.execute(
            "SELECT problem_signature, enabled, created_at FROM autofix_allow ORDER BY created_at DESC"
        )
        return [
            {"problem_signature": r[0], "enabled": bool(r[1]), "created_at": r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()

def memory_get_last_failed_attempt(env_id: str = None) -> Optional[dict]:
    """Get the last failed attempt with error_signature, optionally filtered by env_id."""
    memory_init_db()
    conn = _db_connect()
    try:
        if env_id:
            cur = conn.execute(
                """SELECT attempt_id, env_id, error_signature, stdout_tail, created_at
                   FROM attempt WHERE result = 'fail' AND env_id = ? AND error_signature IS NOT NULL
                   ORDER BY created_at DESC LIMIT 1""",
                (env_id,)
            )
        else:
            cur = conn.execute(
                """SELECT attempt_id, env_id, error_signature, stdout_tail, created_at
                   FROM attempt WHERE result = 'fail' AND error_signature IS NOT NULL
                   ORDER BY created_at DESC LIMIT 1"""
            )
        row = cur.fetchone()
        if not row:
            return None
        return {
            "attempt_id": row[0],
            "env_id": row[1],
            "error_signature": row[2],
            "stdout_tail": row[3],
            "created_at": row[4]
        }
    finally:
        conn.close()

def memory_recent_attempts(limit: int = 20, only_fail: bool = False, env_only: bool = False) -> list:
    """Get recent attempts, optionally filtered by failure or current env."""
    memory_init_db()
    conn = _db_connect()
    try:
        # Build query
        conditions = []
        params = []

        if only_fail:
            conditions.append("result = 'fail'")

        if env_only:
            snapshot = collect_env_snapshot()
            current_env_id = compute_env_id(snapshot)
            conditions.append("env_id = ?")
            params.append(current_env_id)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""SELECT attempt_id, created_at, env_id, solution_id, result,
                           error_signature, inputs_hash, duration_ms, stdout_tail
                    FROM attempt {where_clause}
                    ORDER BY created_at DESC LIMIT ?"""
        params.append(limit)

        cur = conn.execute(query, params)
        rows = cur.fetchall()
        results = []
        for row in rows:
            stdout_tail = row[8]
            if stdout_tail and len(stdout_tail) > 300:
                stdout_tail = stdout_tail[:300]
            results.append({
                "attempt_id": row[0],
                "created_at": row[1],
                "env_id": row[2],
                "solution_id": row[3],
                "result": row[4],
                "error_signature": row[5],
                "inputs_hash": row[6],
                "duration_ms": row[7],
                "stdout_tail": stdout_tail
            })
        return results
    finally:
        conn.close()

def memory_prune(days: int = 90, keep_min: int = 500) -> dict:
    """Prune old attempts, keeping at least keep_min newest. Also clean orphan env_snapshots."""
    memory_init_db()
    conn = _db_connect()
    try:
        from datetime import datetime, timedelta
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        # Count total attempts
        cur = conn.execute("SELECT COUNT(*) FROM attempt")
        total = cur.fetchone()[0]

        # Calculate how many we can delete
        deletable = max(0, total - keep_min)
        if deletable == 0:
            return {"ok": True, "deleted_attempts": 0, "deleted_env_snapshots": 0, "kept_attempts": total}

        # Find IDs of attempts older than cutoff, but respect keep_min
        # First get all attempt IDs ordered by created_at DESC
        cur = conn.execute(
            """SELECT attempt_id FROM attempt
               WHERE created_at < ?
               ORDER BY created_at ASC""",
            (cutoff,)
        )
        old_ids = [row[0] for row in cur.fetchall()]

        # Only delete up to 'deletable' count
        to_delete = old_ids[:deletable]

        deleted_attempts = 0
        if to_delete:
            placeholders = ",".join("?" * len(to_delete))
            conn.execute(f"DELETE FROM attempt WHERE attempt_id IN ({placeholders})", to_delete)
            deleted_attempts = conn.total_changes

        # Clean orphan env_snapshots (not referenced by any attempt)
        cur = conn.execute(
            """DELETE FROM env_snapshot
               WHERE env_id NOT IN (SELECT DISTINCT env_id FROM attempt WHERE env_id IS NOT NULL)"""
        )
        deleted_envs = conn.total_changes - deleted_attempts

        conn.commit()

        # Count remaining
        cur = conn.execute("SELECT COUNT(*) FROM attempt")
        kept = cur.fetchone()[0]

        return {"ok": True, "deleted_attempts": deleted_attempts, "deleted_env_snapshots": max(0, deleted_envs), "kept_attempts": kept}
    finally:
        conn.close()

def memory_export(path: str, include_attempts: bool = False) -> dict:
    """Export memory to JSON file."""
    memory_init_db()
    conn = _db_connect()
    try:
        from datetime import datetime

        # Export solutions
        cur = conn.execute(
            """SELECT solution_id, problem_signature, title, steps_json, tags_json, disabled, created_at
               FROM solution"""
        )
        solutions = []
        for row in cur.fetchall():
            solutions.append({
                "solution_id": row[0],
                "problem_signature": row[1],
                "title": row[2],
                "steps": json.loads(row[3]) if row[3] else [],
                "tags": json.loads(row[4]) if row[4] else [],
                "disabled": row[5],
                "created_at": row[6]
            })

        # Export error_map
        cur = conn.execute(
            """SELECT error_sig, problem_signature, title, hits, created_at
               FROM error_map"""
        )
        error_map = []
        for row in cur.fetchall():
            error_map.append({
                "error_sig": row[0],
                "problem_signature": row[1],
                "title": row[2],
                "hits": row[3],
                "created_at": row[4]
            })

        # Export autofix_allow
        cur = conn.execute(
            """SELECT problem_signature, enabled, created_at
               FROM autofix_allow"""
        )
        autofix_allow = []
        for row in cur.fetchall():
            autofix_allow.append({
                "problem_signature": row[0],
                "enabled": row[1],
                "created_at": row[2]
            })

        export_data = {
            "version": 1,
            "exported_at": datetime.now().isoformat(),
            "solutions": solutions,
            "error_map": error_map,
            "autofix_allow": autofix_allow
        }

        # Optionally include attempts
        if include_attempts:
            cur = conn.execute(
                """SELECT attempt_id, env_id, inputs_hash, result,
                          error_signature, duration_ms, solution_id, stdout_tail, stderr_tail, created_at
                   FROM attempt"""
            )
            attempts = []
            for row in cur.fetchall():
                attempts.append({
                    "attempt_id": row[0],
                    "env_id": row[1],
                    "inputs_hash": row[2],
                    "result": row[3],
                    "error_signature": row[4],
                    "duration_ms": row[5],
                    "solution_id": row[6],
                    "stdout_tail": row[7],
                    "stderr_tail": row[8],
                    "created_at": row[9]
                })
            export_data["attempts"] = attempts

        # Write file
        with open(path, "w") as f:
            json.dump(export_data, f, indent=2)

        return {
            "ok": True,
            "path": path,
            "solutions": len(solutions),
            "error_map": len(error_map),
            "autofix_allow": len(autofix_allow),
            "attempts": len(export_data.get("attempts", []))
        }
    finally:
        conn.close()

def memory_import(path: str, merge: bool = True) -> dict:
    """Import memory from JSON file. If merge=True, skip duplicate solutions."""
    memory_init_db()

    # Read file
    with open(path, "r") as f:
        data = json.load(f)

    if data.get("version") != 1:
        return {"ok": False, "error": f"Unsupported version: {data.get('version')}"}

    conn = _db_connect()
    try:
        stats = {"solutions_added": 0, "solutions_skipped": 0,
                 "error_map_added": 0, "autofix_allow_added": 0}

        # Import solutions
        for sol in data.get("solutions", []):
            steps_json = json.dumps(sol.get("steps", []))
            tags_json = json.dumps(sol.get("tags", []))

            # Check for duplicate if merge=True
            if merge:
                cur = conn.execute(
                    """SELECT solution_id FROM solution
                       WHERE problem_signature = ? AND steps_json = ?""",
                    (sol["problem_signature"], steps_json)
                )
                if cur.fetchone():
                    stats["solutions_skipped"] += 1
                    continue

            # Insert as new row (don't preserve original solution_id)
            conn.execute(
                """INSERT INTO solution (problem_signature, title, steps_json, tags_json, disabled, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (sol["problem_signature"], sol["title"], steps_json, tags_json,
                 sol.get("disabled", 0), sol.get("created_at"))
            )
            stats["solutions_added"] += 1

        # Import error_map (upsert by error_sig, keep higher hits)
        for em in data.get("error_map", []):
            cur = conn.execute("SELECT hits FROM error_map WHERE error_sig = ?", (em["error_sig"],))
            existing = cur.fetchone()
            if existing:
                # Keep max hits
                if em.get("hits", 0) > existing[0]:
                    conn.execute(
                        """UPDATE error_map SET problem_signature = ?, title = ?, hits = ?
                           WHERE error_sig = ?""",
                        (em["problem_signature"], em["title"], em["hits"], em["error_sig"])
                    )
            else:
                conn.execute(
                    """INSERT INTO error_map (error_sig, problem_signature, title, hits, created_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (em["error_sig"], em["problem_signature"], em["title"],
                     em.get("hits", 0), em.get("created_at"))
                )
                stats["error_map_added"] += 1

        # Import autofix_allow (upsert by problem_signature)
        for aa in data.get("autofix_allow", []):
            cur = conn.execute("SELECT 1 FROM autofix_allow WHERE problem_signature = ?",
                               (aa["problem_signature"],))
            if not cur.fetchone():
                conn.execute(
                    """INSERT INTO autofix_allow (problem_signature, enabled, created_at)
                       VALUES (?, ?, ?)""",
                    (aa["problem_signature"], aa.get("enabled", 1), aa.get("created_at"))
                )
                stats["autofix_allow_added"] += 1

        conn.commit()
        return {"ok": True, **stats}
    finally:
        conn.close()

# =====================
# Embedding Manager
# =====================

class EmbeddingManager:
    """Manages local embeddings for semantic search."""

    _instance = None
    _model = None  # Class-level: persists across session
    _model_name = "sentence-transformers/all-MiniLM-L6-v2"  # Small, fast, good

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._dimension = 384  # MiniLM output dimension

    def is_available(self) -> bool:
        return EMBEDDINGS_AVAILABLE

    def _load_model(self):
        """Lazy load the embedding model. Class-level singleton."""
        if EmbeddingManager._model is None and EMBEDDINGS_AVAILABLE:
            try:
                _debug(f"Loading embedding model: {self._model_name}")
                import io as _io
                import logging as _lg
                import warnings as _warnings
                # Suppress all noisy output: loggers + stdout + stderr
                for name in (
                    "sentence_transformers", "transformers",
                    "transformers.modeling_utils", "huggingface_hub",
                    "tqdm",
                ):
                    _lg.getLogger(name).setLevel(_lg.ERROR)
                _old_stdout = sys.stdout
                _old_stderr = sys.stderr
                sys.stdout = _io.StringIO()
                sys.stderr = _io.StringIO()
                try:
                    with _warnings.catch_warnings():
                        _warnings.simplefilter("ignore")
                        EmbeddingManager._model = SentenceTransformer(
                            self._model_name
                        )
                finally:
                    sys.stdout = _old_stdout
                    sys.stderr = _old_stderr
                _debug("Embedding model loaded")
            except Exception as e:
                _debug(f"Failed to load embedding model: {e}")
                EmbeddingManager._model = None
        return EmbeddingManager._model

    def encode(self, texts: list) -> Optional[list]:
        """Encode texts to embeddings. Returns list of lists (not numpy)."""
        model = self._load_model()
        if model is None:
            return None

        try:
            if isinstance(texts, str):
                texts = [texts]
            texts = [clean_surrogates(t) for t in texts]
            embeddings = model.encode(texts, normalize_embeddings=True)
            # Convert to list for JSON storage
            return [emb.tolist() for emb in embeddings]
        except Exception as e:
            _debug(f"Encoding failed: {e}")
            return None

    def cosine_similarity(self, emb1: list, emb2: list) -> float:
        """Compute cosine similarity between two embeddings."""
        if not EMBEDDINGS_AVAILABLE or emb1 is None or emb2 is None:
            return 0.0
        try:
            a = np.array(emb1)
            b = np.array(emb2)
            return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))
        except Exception:
            return 0.0


# Global instance
_embedding_manager = None

def get_embedding_manager() -> EmbeddingManager:
    global _embedding_manager
    if _embedding_manager is None:
        _embedding_manager = EmbeddingManager()
    return _embedding_manager

# =====================
# Semantic Memory Functions
# =====================

def memory_remember(
    content: str,
    memory_type: str = "fact",
    source: str = "agent",
    importance: float = 0.5,
    tags: list = None
) -> int:
    """
    Store a piece of information in semantic memory.

    memory_type: 'fact', 'preference', 'context', 'skill', 'daily'
    source: 'user', 'agent', 'system'
    importance: 0.0 to 1.0 (higher = more important, less likely to be pruned)

    Returns: memory_id
    """
    memory_init_db()

    # === DUPLICATE CHECK START ===
    conn = _db_connect()
    try:
        # Check for exact duplicate
        cur = conn.execute(
            "SELECT id, importance FROM semantic_memory WHERE content = ?",
            (content,)
        )
        existing = cur.fetchone()
        if existing:
            existing_id, existing_importance = existing
            # Update importance if new one is higher
            if importance > existing_importance:
                conn.execute(
                    "UPDATE semantic_memory SET importance = ? WHERE id = ?",
                    (importance, existing_id)
                )
                conn.commit()
            _debug(f"Duplicate memory, returning existing id={existing_id}")
            return existing_id

        # Check for similar content (same start, likely duplicate)
        content_prefix = content[:50] if len(content) > 50 else content
        cur = conn.execute(
            "SELECT id FROM semantic_memory WHERE content LIKE ? AND memory_type = ?",
            (content_prefix + "%", memory_type)
        )
        similar = cur.fetchone()
        if similar:
            _debug(f"Similar memory exists, returning id={similar[0]}")
            return similar[0]
    finally:
        conn.close()
    # === DUPLICATE CHECK END ===

    # Generate embedding if available
    embedding_json = None
    emb_manager = get_embedding_manager()
    if emb_manager.is_available():
        embeddings = emb_manager.encode([content])
        if embeddings:
            embedding_json = json.dumps(embeddings[0])

    created_at = datetime.now().isoformat()
    tags_json = json.dumps(tags or [])

    conn = _db_connect()
    try:
        cur = conn.execute(
            """INSERT INTO semantic_memory
               (content, memory_type, source, importance, tags, created_at, access_count, embedding)
               VALUES (?, ?, ?, ?, ?, ?, 0, ?)""",
            (content, memory_type, source, importance, tags_json, created_at, embedding_json)
        )
        conn.commit()
        memory_id = cur.lastrowid
        _debug(f"Remembered: [{memory_type}] {content[:50]}... (id={memory_id})")
        return memory_id
    finally:
        conn.close()


def memory_recall(
    query: str,
    limit: int = 10,
    memory_type: str = None,
    min_importance: float = 0.0
) -> list:
    """
    Search semantic memory using FTS5.

    Returns list of matching memories with relevance ranking.
    """
    memory_init_db()

    conn = _db_connect()
    try:
        # Escape special characters for FTS5
        safe_query = query.replace('"', '""')

        sql = """
            SELECT m.id, m.content, m.memory_type, m.source, m.importance,
                   m.tags, m.created_at, m.access_count,
                   bm25(semantic_memory_fts) as rank
            FROM semantic_memory m
            JOIN semantic_memory_fts fts ON m.id = fts.rowid
            WHERE semantic_memory_fts MATCH ?
        """
        params = [f'"{safe_query}" OR {safe_query}']

        if memory_type:
            sql += " AND m.memory_type = ?"
            params.append(memory_type)

        if min_importance > 0:
            sql += " AND m.importance >= ?"
            params.append(min_importance)

        sql += " ORDER BY rank LIMIT ?"
        params.append(limit)

        cur = conn.execute(sql, params)
        rows = cur.fetchall()

        results = []
        now = datetime.now().isoformat()
        for row in rows:
            memory_id = row[0]
            results.append({
                "id": memory_id,
                "content": row[1],
                "memory_type": row[2],
                "source": row[3],
                "importance": row[4],
                "tags": json.loads(row[5]) if row[5] else [],
                "created_at": row[6],
                "access_count": row[7],
                "relevance": -row[8]  # BM25 returns negative scores
            })

            # Update access stats
            conn.execute(
                "UPDATE semantic_memory SET last_accessed = ?, access_count = access_count + 1 WHERE id = ?",
                (now, memory_id)
            )

        conn.commit()
        return results
    except Exception as e:
        _debug(f"Recall failed: {e}")
        # Fallback to LIKE search if FTS fails
        try:
            cur = conn.execute(
                """SELECT id, content, memory_type, source, importance, tags, created_at, access_count
                   FROM semantic_memory
                   WHERE content LIKE ?
                   ORDER BY importance DESC, created_at DESC
                   LIMIT ?""",
                (f"%{query}%", limit)
            )
            return [{
                "id": r[0], "content": r[1], "memory_type": r[2], "source": r[3],
                "importance": r[4], "tags": json.loads(r[5]) if r[5] else [],
                "created_at": r[6], "access_count": r[7], "relevance": 0.5
            } for r in cur.fetchall()]
        except Exception:
            return []
    finally:
        conn.close()


def memory_hybrid_search(
    query: str,
    limit: int = 10,
    memory_type: str = None,
    vector_weight: float = 0.7,
    bm25_weight: float = 0.3
) -> list:
    """
    Hybrid search combining vector similarity and BM25.

    Falls back to BM25-only if embeddings not available.
    """
    if not _trace_off():
        trace_memory_search(query=query, limit=limit)
    memory_init_db()
    emb_manager = get_embedding_manager()

    # Get BM25 results first
    bm25_results = memory_recall(query, limit=limit*2, memory_type=memory_type)

    # If no embeddings, return BM25 results
    if not emb_manager.is_available():
        _debug("Embeddings not available, using BM25 only")
        return bm25_results[:limit]

    # Encode query
    query_embeddings = emb_manager.encode([query])
    if not query_embeddings:
        return bm25_results[:limit]

    query_emb = query_embeddings[0]

    # Get all memories with embeddings for vector search
    conn = _db_connect()
    try:
        sql = """
            SELECT id, content, memory_type, source, importance,
                   tags, created_at, access_count, embedding
            FROM semantic_memory
            WHERE embedding IS NOT NULL
        """
        params = []

        if memory_type:
            sql += " AND memory_type = ?"
            params.append(memory_type)

        cur = conn.execute(sql, params)
        rows = cur.fetchall()
    finally:
        conn.close()

    # Calculate vector scores
    vector_scores = {}
    for row in rows:
        memory_id = row[0]
        embedding_json = row[8]
        if embedding_json:
            try:
                embedding = json.loads(embedding_json)
                similarity = emb_manager.cosine_similarity(query_emb, embedding)
                vector_scores[memory_id] = similarity
            except Exception:
                pass

    # Create BM25 score map (normalize to 0-1)
    bm25_scores = {}
    if bm25_results:
        max_relevance = max(r.get("relevance", 0) for r in bm25_results) or 1
        for r in bm25_results:
            bm25_scores[r["id"]] = r.get("relevance", 0) / max_relevance

    # Combine scores
    all_ids = set(vector_scores.keys()) | set(bm25_scores.keys())
    combined = []

    for memory_id in all_ids:
        v_score = vector_scores.get(memory_id, 0)
        b_score = bm25_scores.get(memory_id, 0)
        hybrid_score = (vector_weight * v_score) + (bm25_weight * b_score)

        # Find the memory data
        memory_data = next((r for r in bm25_results if r["id"] == memory_id), None)
        if memory_data:
            memory_data["vector_score"] = v_score
            memory_data["bm25_score"] = b_score
            memory_data["hybrid_score"] = hybrid_score
            combined.append(memory_data)
        elif memory_id in vector_scores:
            # Memory found by vector but not BM25, fetch from DB
            conn = _db_connect()
            try:
                cur = conn.execute(
                    """SELECT id, content, memory_type, source, importance, tags, created_at, access_count
                       FROM semantic_memory WHERE id = ?""",
                    (memory_id,)
                )
                r = cur.fetchone()
                if r:
                    combined.append({
                        "id": r[0], "content": r[1], "memory_type": r[2],
                        "source": r[3], "importance": r[4],
                        "tags": json.loads(r[5]) if r[5] else [],
                        "created_at": r[6], "access_count": r[7],
                        "vector_score": v_score, "bm25_score": 0,
                        "hybrid_score": hybrid_score
                    })
            finally:
                conn.close()

    # Sort by hybrid score
    combined.sort(key=lambda x: x.get("hybrid_score", 0), reverse=True)

    return combined[:limit]


def memory_forget(memory_id: int = None, query: str = None) -> dict:
    """
    Remove memory by ID or by content match.

    Returns: {"deleted": count}
    """
    memory_init_db()

    conn = _db_connect()
    try:
        if memory_id:
            conn.execute("DELETE FROM semantic_memory WHERE id = ?", (memory_id,))
            deleted = conn.total_changes
        elif query:
            conn.execute("DELETE FROM semantic_memory WHERE content LIKE ?", (f"%{query}%",))
            deleted = conn.total_changes
        else:
            return {"deleted": 0, "error": "Provide memory_id or query"}

        conn.commit()
        return {"deleted": deleted}
    finally:
        conn.close()


def memory_get_context(limit: int = 5) -> list:
    """
    Get recent and important memories for context injection.
    Prioritizes by: importance * recency * access_frequency
    """
    memory_init_db()

    conn = _db_connect()
    try:
        cur = conn.execute("""
            SELECT id, content, memory_type, source, importance, created_at
            FROM semantic_memory
            WHERE memory_type IN ('fact', 'preference', 'context')
            ORDER BY
                importance *
                CASE
                    WHEN julianday('now') - julianday(created_at) < 1 THEN 2.0
                    WHEN julianday('now') - julianday(created_at) < 7 THEN 1.5
                    ELSE 1.0
                END *
                (1 + 0.1 * access_count) DESC
            LIMIT ?
        """, (limit,))

        return [{
            "id": r[0], "content": r[1], "memory_type": r[2],
            "source": r[3], "importance": r[4], "created_at": r[5]
        } for r in cur.fetchall()]
    finally:
        conn.close()


def memory_update_daily_summary(summary: str, task_count: int = 1) -> None:
    """
    Update today's daily summary. Appends if exists.
    """
    memory_init_db()

    today = datetime.now().strftime("%Y-%m-%d")
    now = datetime.now().isoformat()

    conn = _db_connect()
    try:
        cur = conn.execute("SELECT summary, task_count FROM daily_summary WHERE date = ?", (today,))
        row = cur.fetchone()

        if row:
            existing_summary = row[0]
            existing_count = row[1]
            new_summary = existing_summary + "\n- " + summary
            conn.execute(
                "UPDATE daily_summary SET summary = ?, task_count = ?, updated_at = ? WHERE date = ?",
                (new_summary, existing_count + task_count, now, today)
            )
        else:
            conn.execute(
                "INSERT INTO daily_summary (date, summary, task_count, created_at) VALUES (?, ?, ?, ?)",
                (today, "- " + summary, task_count, now)
            )

        conn.commit()
    finally:
        conn.close()


def memory_get_daily_summary(date: str = None) -> Optional[dict]:
    """Get daily summary for a date (default: today)."""
    memory_init_db()

    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    conn = _db_connect()
    try:
        cur = conn.execute(
            "SELECT date, summary, task_count, created_at FROM daily_summary WHERE date = ?",
            (date,)
        )
        row = cur.fetchone()
        if row:
            return {
                "date": row[0],
                "summary": row[1],
                "task_count": row[2],
                "created_at": row[3]
            }
        return None
    finally:
        conn.close()


def memory_list_all(limit: int = 50, memory_type: str = None) -> list:
    """List all semantic memories."""
    memory_init_db()

    conn = _db_connect()
    try:
        if memory_type:
            cur = conn.execute(
                """SELECT id, content, memory_type, source, importance, created_at
                   FROM semantic_memory WHERE memory_type = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (memory_type, limit)
            )
        else:
            cur = conn.execute(
                """SELECT id, content, memory_type, source, importance, created_at
                   FROM semantic_memory
                   ORDER BY created_at DESC LIMIT ?""",
                (limit,)
            )

        return [{
            "id": r[0], "content": r[1], "memory_type": r[2],
            "source": r[3], "importance": r[4], "created_at": r[5]
        } for r in cur.fetchall()]
    finally:
        conn.close()


def memory_semantic_stats() -> dict:
    """Get semantic memory statistics."""
    memory_init_db()

    conn = _db_connect()
    try:
        stats = {}

        cur = conn.execute("SELECT COUNT(*) FROM semantic_memory")
        stats["total_memories"] = cur.fetchone()[0]

        cur = conn.execute(
            "SELECT memory_type, COUNT(*) FROM semantic_memory GROUP BY memory_type"
        )
        stats["by_type"] = {r[0]: r[1] for r in cur.fetchall()}

        cur = conn.execute(
            "SELECT source, COUNT(*) FROM semantic_memory GROUP BY source"
        )
        stats["by_source"] = {r[0]: r[1] for r in cur.fetchall()}

        cur = conn.execute("SELECT COUNT(*) FROM daily_summary")
        stats["daily_summaries"] = cur.fetchone()[0]

        # Embedding stats
        cur = conn.execute(
            "SELECT COUNT(*) FROM semantic_memory WHERE embedding IS NOT NULL"
        )
        stats["with_embeddings"] = cur.fetchone()[0]

        # Embedding availability
        emb_manager = get_embedding_manager()
        stats["embeddings_available"] = emb_manager.is_available()

        return stats
    finally:
        conn.close()


def log_automation_run(name: str, trigger_event: str, actions_count: int,
                       success: int, summary: str, duration_ms: int):
    """Log an automation run to the database."""
    from datetime import datetime
    init_db()
    conn = _db_connect()
    try:
        conn.execute("""
            INSERT INTO automation_run
            (automation_name, trigger_event, actions_count, success, summary, duration_ms, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (name, trigger_event, actions_count, success,
              summary[:500], duration_ms, datetime.now().isoformat()))
        conn.commit()
    finally:
        conn.close()

