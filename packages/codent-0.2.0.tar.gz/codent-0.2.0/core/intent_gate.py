# core/intent_gate.py
"""Phase-(-1) Intent Gate — intercept teach/read/command before fastpath & LLM.

Score-based detection prevents chicken-egg problems:
  - "hatırla: X = Y" → WRITE intent → memory_remember() directly
  - "hafızanı yokla" → READ intent → memory_hybrid_search() directly
  - "/kötü" → COMMAND intent → safety net (slash router should catch)
  - everything else → PASS → normal pipeline
"""

import re
from dataclasses import dataclass
from typing import Callable, Optional


@dataclass
class IntentResult:
    intent: str          # "write" | "read" | "command" | "pass"
    payload: str         # cleaned text (markers stripped)
    score: int           # detection confidence score
    matched_trigger: str # which trigger fired


# ── Score tables ──

_WRITE_TRIGGERS = [
    # (+3) strong write signals
    (r"hafızana\s+yaz", 3),
    (r"^hatırla\s*:", 3),
    (r"bunu\s+öğren", 3),
    (r"not\s+et", 3),
    (r"kural\s+olarak", 3),
    (r"bundan\s+sonra", 3),
    # (+2) moderate write signals
    (r"dediğimde", 2),
    (r"kastediyorum", 2),
    (r"demektir", 2),
    (r".+=.+", 2),  # X = Y pattern
]

_WRITE_PENALTIES = [
    # (-3) question forms — asking about, not teaching
    (r"^(ne|nasıl|nerede|nereye|kim|hangi)\b", -3),
    (r"hatırlıyor\s+musun", -3),
    (r"biliyor\s+musun", -3),
    # (-1) ends with ?
    (r"\?\s*$", -1),
]

_READ_TRIGGERS = [
    # (+3) strong read signals
    (r"hafızanı\s+yokla", 3),
    (r"hafızanda\s+var\s+mı", 3),
    (r"hatırlıyor\s+musun", 3),
    # (+2) moderate read signals
    (r"daha\s+önce.*demiştik", 2),
    (r"daha\s+önce.*söylemiştim", 2),
]

_COMMAND_PREFIXES = ("/iyi", "/kötü", "/not ", "/s ", "/s\n")

_WRITE_THRESHOLD = 3
_READ_THRESHOLD = 3


def detect_intent(user_input: str) -> IntentResult:
    """Score-based intent detection.

    Returns IntentResult with intent = WRITE/READ/COMMAND/PASS.
    """
    if not user_input or not user_input.strip():
        return IntentResult("pass", user_input or "", 0, "")

    text = user_input.strip()
    text_lower = text.lower()

    # 1. COMMAND: exact prefix match
    for prefix in _COMMAND_PREFIXES:
        if text_lower.startswith(prefix) or text_lower == prefix.strip():
            return IntentResult("command", text, 10, prefix.strip())

    # 2. WRITE: score-based
    w_score = 0
    w_trigger = ""
    for pattern, score in _WRITE_TRIGGERS:
        if re.search(pattern, text_lower):
            w_score += score
            if not w_trigger:
                w_trigger = pattern
    for pattern, penalty in _WRITE_PENALTIES:
        if re.search(pattern, text_lower):
            w_score += penalty  # penalty is negative

    if w_score >= _WRITE_THRESHOLD:
        # Strip write markers from payload
        payload = text
        payload = re.sub(r"^hatırla\s*:\s*", "", payload, flags=re.IGNORECASE)
        payload = re.sub(r"^hafızana\s+yaz\s*:\s*", "", payload, flags=re.IGNORECASE)
        payload = re.sub(r"^bunu\s+öğren\s*:\s*", "", payload, flags=re.IGNORECASE)
        payload = re.sub(r"^not\s+et\s*:\s*", "", payload, flags=re.IGNORECASE)
        return IntentResult("write", payload.strip(), w_score, w_trigger)

    # 3. READ: score-based
    r_score = 0
    r_trigger = ""
    for pattern, score in _READ_TRIGGERS:
        if re.search(pattern, text_lower):
            r_score += score
            if not r_trigger:
                r_trigger = pattern
    # Apply same question penalty? No — questions ARE read intent.

    if r_score >= _READ_THRESHOLD:
        # Strip read markers from payload
        payload = text
        payload = re.sub(r"^hafızanı\s+yokla\s*:\s*", "", payload, flags=re.IGNORECASE)
        payload = re.sub(r"hafızanda\s+var\s+mı\s*", "", payload, flags=re.IGNORECASE)
        payload = re.sub(r"hatırlıyor\s+musun\s*", "", payload, flags=re.IGNORECASE)
        return IntentResult("read", payload.strip(), r_score, r_trigger)

    # 4. PASS: default
    return IntentResult("pass", text, 0, "")


# ── Handlers ──

# Simple regex: X = Y, X: Y, X → Y
_SIMPLE_KV_RE = re.compile(r"^(.+?)\s*[=:→]\s*(.+)$")

# NL regex: "X dediğimde Y kastediyorum" / "X demektir Y"
_NL_KV_RE = re.compile(
    r"^(.+?)\s+(?:dediğimde|kastediyorum|demektir|şu\s+demek)\s+(.+?)(?:\s+kastediyorum)?$",
    re.IGNORECASE,
)

_FORMAT_SUGGESTION = (
    "Hafızaya yazmak için şu formatlardan birini kullan:\n"
    "  • hatırla: anahtar = değer\n"
    "  • hatırla: anahtar: değer\n"
    "  • X dediğimde Y kastediyorum"
)


def handle_write_intent(
    payload: str,
    memory_write_fn: Callable,
    console_print_fn: Callable,
) -> Optional[str]:
    """Parse teach payload and write to memory.

    3-layer parse:
      1. Simple regex: X = Y, X: Y, X → Y
      2. NL regex: X dediğimde Y kastediyorum
      3. Fail: format suggestion

    Returns response string or None.
    """
    if not payload or not payload.strip():
        console_print_fn(f"[yellow]  {_FORMAT_SUGGESTION}[/yellow]")
        return _FORMAT_SUGGESTION

    text = payload.strip()

    # Layer 1: simple key=value
    m = _SIMPLE_KV_RE.match(text)
    if m:
        alias = m.group(1).strip()
        value = m.group(2).strip()
        return _do_write(alias, value, memory_write_fn, console_print_fn)

    # Layer 2: NL pattern
    m = _NL_KV_RE.match(text)
    if m:
        alias = m.group(1).strip()
        value = m.group(2).strip()
        return _do_write(alias, value, memory_write_fn, console_print_fn)

    # Layer 3: fail — format suggestion
    console_print_fn(f"[yellow]  {_FORMAT_SUGGESTION}[/yellow]")
    return _FORMAT_SUGGESTION


def _do_write(
    alias: str, value: str,
    memory_write_fn: Callable, console_print_fn: Callable,
) -> str:
    """Actually write to memory and confirm."""
    content = f"{alias} = {value}"
    try:
        memory_write_fn(
            content=content,
            memory_type="fact",
            source="user_teach",
            importance=1.0,
        )
        msg = f"Hafızaya yazıldı: {alias} = {value}"
        console_print_fn(f"[green]  ✓ {msg}[/green]")
        return msg
    except Exception as e:
        err_msg = f"Hafızaya yazma hatası: {e}"
        console_print_fn(f"[red]  ✗ {err_msg}[/red]")
        return err_msg


def handle_read_intent(
    payload: str,
    memory_search_fn: Callable,
    console_print_fn: Callable,
) -> Optional[str]:
    """Search memory and display results.

    Returns response string or None.
    """
    query = payload.strip() if payload else ""
    if not query:
        console_print_fn("[yellow]  Ne arayacağımı belirt.[/yellow]")
        return "Ne arayacağımı belirt."

    try:
        results = memory_search_fn(query=query, limit=5)
    except Exception as e:
        err_msg = f"Hafıza araması hatası: {e}"
        console_print_fn(f"[red]  {err_msg}[/red]")
        return err_msg

    if not results:
        msg = f"Hafızamda '{query}' ile ilgili bir şey bulamadım. 'hatırla: anahtar = değer' ile öğretebilirsin."
        console_print_fn(f"[yellow]  {msg}[/yellow]")
        return msg

    lines = [f"Hafızamda '{query}' ile ilgili {len(results)} sonuç:"]
    for mem in results:
        content = mem.get("content", "")[:120]
        importance = mem.get("importance", 0)
        source = mem.get("source", "")
        label = "[HIGH]" if importance >= 0.8 or source == "user_teach" else "[LOW]"
        lines.append(f"  {label} {content}")

    result_text = "\n".join(lines)
    console_print_fn(f"[cyan]{result_text}[/cyan]")
    return result_text
