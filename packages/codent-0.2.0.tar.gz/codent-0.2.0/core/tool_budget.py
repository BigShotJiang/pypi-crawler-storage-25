# core/tool_budget.py
"""Phase-based tool budget with duplicate blocking, bulk read mode, and free quotas."""

import json
import os


# =====================================================================
# Free Tool Quotas — these calls DON'T consume the phase budget
# =====================================================================

# Always free up to N calls per task (never counts toward budget)
FREE_TOOL_QUOTAS = {
    "where_am_i":          1,   # 1 call free
    "capabilities_report": 1,   # 1 call free
    "recall":              3,   # 3 calls free (multiple keyword searches)
    "list_memories":       1,   # 1 call free
    "system_search":       2,   # 2 calls free
}

# First call free, subsequent calls cost budget
FIRST_CALL_FREE = {
    "list_dir":   1,   # First directory listing free
    "find_path":  1,   # First path search free
}


class BulkReadMode:
    """
    Auto-activates when 10+ files are found in search results.
    read_file calls bypass the phase budget (up to MAX_BULK_READS).
    """

    MAX_BULK_READS = 30

    def __init__(self):
        self.active = False
        self.files_to_read = []
        self.files_read = []
        self.read_count = 0

    def activate(self, file_list: list) -> str:
        """Activate bulk read mode."""
        self.active = True
        self.files_to_read = file_list[:self.MAX_BULK_READS]
        self.read_count = 0
        return (
            f"[SYSTEM: Toplu okuma modu aktif. "
            f"{len(self.files_to_read)} dosya okunacak. "
            f"read_file çağrıları aşama bütçesinden düşülmez.]"
        )

    def is_free_read(self, tool_name: str, path: str) -> bool:
        """Check if this read_file is budget-free."""
        if not self.active or tool_name != "read_file":
            return False
        if self.read_count >= self.MAX_BULK_READS:
            self.active = False
            return False
        self.read_count += 1
        self.files_read.append(path)
        return True

    def deactivate(self):
        """Deactivate bulk read mode."""
        self.active = False


class DynamicToolBudget:
    """
    Phase-based tool budget. Each phase gets BUDGET_PER_PHASE calls.
    When a phase is exhausted, a new phase auto-starts (up to MAX_PHASES).
    Duplicate tool+args calls are blocked without consuming budget.
    """

    DEFAULT_BUDGET_PER_PHASE = 12
    MAX_PHASES = 4
    MAX_TOTAL_CALLS = 60

    # Legacy compat (still works for simple checks)
    FREE_TOOLS = set(FREE_TOOL_QUOTAS.keys())

    def __init__(self, budget_per_phase: int = None, cwd: str = None):
        self.BUDGET_PER_PHASE = budget_per_phase or self.DEFAULT_BUDGET_PER_PHASE
        self.current_phase = 1
        self.phase_calls = 0
        self.total_calls = 0
        self.blocked_calls = 0
        self._seen_calls = {}  # {call_key: count} per phase
        self._bulk_reader = BulkReadMode()
        self._free_counts = {}  # tool_name -> call count (for quota tracking)
        self._cwd = cwd or os.getcwd()

    def _is_free_call(self, tool_name: str) -> bool:
        """Check if this call is free under quota rules.

        FREE_TOOL_QUOTAS: always free up to N calls.
        FIRST_CALL_FREE: only the first call is free.
        Returns True if the call should NOT consume budget.
        """
        count = self._free_counts.get(tool_name, 0)
        self._free_counts[tool_name] = count + 1

        # Check unlimited-free quota tools
        if tool_name in FREE_TOOL_QUOTAS:
            return count < FREE_TOOL_QUOTAS[tool_name]

        # Check first-call-free tools
        if tool_name in FIRST_CALL_FREE:
            return count < FIRST_CALL_FREE[tool_name]

        return False

    def can_call(self, tool_name: str, tool_args: dict) -> tuple:
        """Check if a tool call is allowed. Returns (allowed, message)."""
        # Free quota check (replaces old FREE_TOOLS set)
        if self._is_free_call(tool_name):
            return True, ""

        # Bulk read bypass
        if self._bulk_reader.is_free_read(tool_name, tool_args.get("path", "")):
            self.total_calls += 1
            return True, ""

        # Absolute cap
        if self.total_calls >= self.MAX_TOTAL_CALLS:
            return False, (
                f"[SYSTEM: Mutlak tool limiti ({self.MAX_TOTAL_CALLS}) "
                f"aşıldı. CEVABINI VER.]"
            )

        # Duplicate blocking (doesn't consume budget)
        call_key = self._make_key(tool_name, tool_args)
        if call_key in self._seen_calls:
            count = self._seen_calls[call_key]
            self.blocked_calls += 1
            self._seen_calls[call_key] = count + 1
            if count >= 2:
                return False, (
                    f"Blocked: {tool_name} same args x{count+1}. "
                    f"FARKLI parametreler kullan veya system_search dene."
                )
            return False, f"Blocked: {tool_name} same args x{count+1}"

        # Phase exhausted? Start new phase if possible
        if self.phase_calls >= self.BUDGET_PER_PHASE:
            if self.current_phase >= self.MAX_PHASES:
                return False, (
                    f"[SYSTEM: Tool bütçesi tükendi "
                    f"(Aşama {self.current_phase}/{self.MAX_PHASES}, "
                    f"toplam {self.total_calls} çağrı). "
                    f"Elindeki bilgilerle CEVABINI VER.]"
                )
            self._start_new_phase()

        # Warnings
        remaining = self.BUDGET_PER_PHASE - self.phase_calls
        message = ""
        if remaining == 2:
            message = (
                f"[SYSTEM: Bu aşamada {remaining} tool hakkın kaldı. "
                f"Aşama {self.current_phase}/{self.MAX_PHASES}. "
                f"Sonuç üretirsen yeni aşama açılır.]"
            )
        elif remaining == 1:
            message = (
                f"[SYSTEM: Bu aşamada SON tool hakkın. "
                f"Bir sonraki çağrıdan sonra ya cevap ver, "
                f"ya da yeni aşama başlat.]"
            )

        # Record the call
        self._seen_calls[call_key] = 1
        self.phase_calls += 1
        self.total_calls += 1

        return True, message

    def _start_new_phase(self):
        """Start a new phase."""
        self.current_phase += 1
        self.phase_calls = 0
        # _seen_calls NOT reset — duplicates tracked globally across all phases

    # Argument names that contain file/directory paths
    _PATH_ARGS = frozenset({"path", "file", "filepath", "filename", "directory", "dir", "folder"})

    def _make_key(self, tool_name, tool_args):
        """Create unique key for a tool call with path normalization.

        Relative paths are resolved against cwd so that
        list_dir("logs/") and list_dir("/home/.../logs") produce the same key.
        """
        normalized = {}
        for key, value in tool_args.items():
            if key in self._PATH_ARGS and isinstance(value, str) and value:
                p = value
                if not os.path.isabs(p):
                    p = os.path.join(self._cwd, p)
                p = os.path.normpath(p)
                normalized[key] = p
            else:
                normalized[key] = value
        args_str = json.dumps(normalized, sort_keys=True)
        return f"{tool_name}:{args_str}"

    def get_display(self) -> str:
        """For tool call display: '3/12 A1'."""
        return f"{self.phase_calls}/{self.BUDGET_PER_PHASE} A{self.current_phase}"

    def get_budget_for_prompt(self) -> str:
        """Budget info for system prompt."""
        free_tools_str = ", ".join(sorted(FREE_TOOL_QUOTAS.keys()))
        first_free_str = ", ".join(sorted(FIRST_CALL_FREE.keys()))
        return (
            f"Tool budget: {self.BUDGET_PER_PHASE - self.phase_calls}"
            f"/{self.BUDGET_PER_PHASE} remaining in phase "
            f"{self.current_phase}/{self.MAX_PHASES}. "
            f"Total {self.MAX_TOTAL_CALLS - self.total_calls} remaining. "
            f"Each phase gives {self.BUDGET_PER_PHASE} calls. "
            f"Same tool+args cannot be repeated. "
            f"Free tools (quota): {free_tools_str}. "
            f"First call free: {first_free_str}."
        )

    def force_new_phase(self) -> bool:
        """Force start a new phase (called at checkpoints)."""
        if self.current_phase >= self.MAX_PHASES:
            return False
        self.current_phase += 1
        self.phase_calls = 0
        # _seen_calls NOT reset — duplicates tracked globally across all phases
        return True

    def activate_bulk_read(self, file_list: list) -> str:
        """Activate bulk read mode for a list of files."""
        return self._bulk_reader.activate(file_list)
