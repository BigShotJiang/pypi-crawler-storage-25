# core/prefetch.py
"""Phase-0 Prelude: warmup + auto-recall + resolver (CWD only).

Runs BEFORE the LLM loop. 3 threads in parallel with a hard timeout.
Results are injected into the system prompt so the model starts pre-informed.

Prefetch (keyword-triggered tool pre-execution) disabled — <1% hit rate.
PrefetchCache class kept for future explicit-hint use.
"""

import json
import os
import re
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Optional

from core.utils import debug as _debug

try:
    from core.trace import is_off as _trace_off, trace_memory_recall
except ImportError:
    _trace_off = lambda: True
    trace_memory_recall = lambda **kw: None


# =====================================================================
# Prefetch Cache — shared across Phase-0 and dispatcher
# =====================================================================
class PrefetchCache:
    """Task-scope cache. Dispatcher checks here before real tool execution."""

    def __init__(self, ttl: float = 30.0):
        self._cache: dict[str, Any] = {}
        self._created_at = time.time()
        self._ttl = ttl
        self.hits = 0
        self.misses = 0

    def put(self, tool_name: str, args: dict, result: Any) -> None:
        key = self._make_key(tool_name, args)
        self._cache[key] = result

    def get(self, tool_name: str, args: dict) -> Any:
        if time.time() - self._created_at > self._ttl:
            return None
        key = self._make_key(tool_name, args)
        val = self._cache.get(key)
        if val is not None:
            self.hits += 1
        else:
            self.misses += 1
        return val

    def has(self, tool_name: str, args: dict) -> bool:
        return self.get(tool_name, args) is not None

    @staticmethod
    def _make_key(tool_name: str, args: dict) -> str:
        return f"{tool_name}:{json.dumps(args, sort_keys=True)}"

    def summary(self) -> str:
        items = len(self._cache)
        return f"PrefetchCache: {items} items, {self.hits} hits, {self.misses} misses"


# =====================================================================
# Resolver — delegate to system_executor.Resolver (dynamic, no hardcode)
# =====================================================================
try:
    from core.system_executor import Resolver
except ImportError:
    # Minimal fallback if system_executor isn't available
    class Resolver:  # type: ignore[no-redef]
        @staticmethod
        def user_dir(folder: str) -> Optional[str]:
            p = os.path.expanduser(f"~/{folder.capitalize()}")
            return p if os.path.isdir(p) else None

        @classmethod
        def downloads_dir(cls) -> Optional[str]:
            return cls.user_dir("downloads")

        @staticmethod
        def repo_root() -> str:
            try:
                r = subprocess.run(
                    ["git", "rev-parse", "--show-toplevel"],
                    capture_output=True, text=True, timeout=2,
                )
                if r.returncode == 0:
                    return r.stdout.strip()
            except Exception:
                pass
            return os.getcwd()

        @staticmethod
        def git_status() -> Optional[dict]:
            try:
                branch = subprocess.run(
                    ["git", "branch", "--show-current"],
                    capture_output=True, text=True, timeout=2,
                ).stdout.strip()
                status = subprocess.run(
                    ["git", "status", "--short"],
                    capture_output=True, text=True, timeout=2,
                ).stdout.strip()
                return {
                    "branch": branch,
                    "dirty": bool(status),
                    "files_changed": len(status.splitlines()),
                }
            except Exception:
                return None

        @staticmethod
        def wsl_user_dirs() -> dict:
            return {}

        @staticmethod
        def git_info() -> Optional[dict]:
            return None

        @staticmethod
        def cwd_info() -> dict:
            return {"cwd": os.getcwd()}

        @classmethod
        def is_wsl(cls) -> bool:
            return os.path.isdir("/mnt/c/Windows")


# =====================================================================
# Entity Extraction (for auto-recall keywords)
# =====================================================================
_STOP_WORDS = {
    "bir", "bu", "su", "ve", "ile", "icin", "de", "da",
    "den", "dan", "ne", "nasil", "nerede", "nereye",
    "son", "en", "bul", "ac", "oku", "listele", "goster",
    "yap", "et", "olan", "ki", "mi", "mu",
    "the", "a", "an", "in", "on", "at", "to", "for",
    # v4: question particles / discourse markers
    "mi", "mı", "mu", "mü", "ya", "ama", "için",
    "gibi", "kadar", "sonra", "önce",
    "çünkü", "zira", "hem", "peki", "acaba",
    "böyle", "şöyle", "hangisi", "hangi",
    "var", "yok", "ben", "sen", "lütfen", "tamam",
}

# Container words — grammatical wrappers, not meaningful entities
_CONTAINER_STOPWORDS = {
    "klasörünü", "klasörü", "klasöründe", "klasöründeki", "klasörüne",
    "dosyasını", "dosyası", "dosyayı", "dosyasında", "dosyasındaki",
    "sitesini", "sitesi", "sitesinde", "sitesindeki", "sitesine",
    "sayfasını", "sayfası", "sayfasında", "sayfasındaki",
    "linkini", "linki", "urlsini",
    "dizinini", "dizini", "dizininde", "dizinindeki",
    "yolunu", "yolu", "yolundaki",
    "içindeki", "altındaki", "üzerindeki",
    "konumunu", "konumundaki",
    "projesini", "projesinde", "projesindeki", "projesine", "projesi",
}

# Turkish suffixes to strip for keyword matching (longest first)
_TR_SUFFIXES = (
    # 5-char locative
    "ndeki", "ndaki",
    # 4-char plural/accusative/locative/ablative
    "ları", "leri", "ını", "ini", "unu", "ünü",
    "nden", "ndan", "deki", "daki",
    # 3-char locative
    "nde", "nda",
    # 2-char accusative/possessive
    "nı", "ni", "nu", "nü",
    "ım", "im", "um", "üm",
    # 1-char accusative
    "ı", "i", "u", "ü",
)

_DIR_KEYWORDS = {
    "indirilenler": "indirilenler", "masaustu": "masaüstü",
    "masaüstü": "masaüstü", "belgeler": "belgeler",
    "downloads": "indirilenler", "desktop": "masaüstü",
    "documents": "belgeler",
}


def _strip_tr_suffix(word: str) -> str:
    """Strip common Turkish possessive/accusative suffixes."""
    for suffix in _TR_SUFFIXES:
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[:-len(suffix)]
    return word


# Compound suffixes — multi-morpheme chains that single-pass stripping can't handle
_COMPOUND_SUFFIXES = (
    # plural + possessive + ablative (lerimden/larımdan)
    "lerimden", "larımdan",
    # possessive + locative (ümdeki/ımdaki etc.)
    "ümdeki", "ımdaki", "umdaki", "imdeki",
    # 3rd person + locative (sindeki/sındaki etc.)
    "sindeki", "sındaki", "sundaki", "sündeki",
    # 3rd person + ablative (sinden/sından)
    "sinden", "sından", "sunden", "sünden",
    # plural + 3rd person + ablative
    "lerinden", "larından",
    # possessive + ablative (imden/ımdan)
    "imden", "ımdan", "umdan", "ümden",
)


def _strip_tr_suffixes_chain(word: str, max_passes: int = 3) -> str:
    """Iteratively strip Turkish suffix chains (e.g. klasörümdeki → klasör).

    First tries compound suffixes (multi-morpheme), then falls back to
    iterative single-suffix stripping.
    """
    # Try compound suffixes first (longest match wins)
    for cs in _COMPOUND_SUFFIXES:
        if word.endswith(cs) and len(word) - len(cs) >= 3:
            return word[:-len(cs)]

    # Fall back to iterative single-suffix stripping
    for _ in range(max_passes):
        stripped = _strip_tr_suffix(word)
        if stripped == word:
            break
        word = stripped
    return word


def extract_entities(text: str) -> list[tuple[str, str]]:
    """Extract typed entities from user input for memory recall.

    Uses regex split on whitespace + punctuation to prevent word merging.
    Each token is processed independently — NO concatenation/merging.
    Entity values are used ONLY for memory search keys, never
    concatenated back into the user input sent to LLM.
    """
    entities: list[tuple[str, str]] = []
    # v6.2: Regex split to properly handle punctuation boundaries
    words = re.split(r'[\s.,;:!?()\"\[\]{}]+', text)
    words = [w for w in words if w]  # drop empty strings

    for word in words:
        w = word.lower().strip(".,!?:;\"'()[]")
        raw = word.strip(".,!?:;\"'()[]")

        if w in _STOP_WORDS or w in _CONTAINER_STOPWORDS:
            continue
        # Allow 2-char words only if ALL UPPERCASE (acronyms: AI, DB, ML)
        if len(w) < 2 or (len(w) == 2 and not raw.isupper()):
            continue

        # Path-like entities (highest priority)
        if "/" in word or "\\" in word:
            entities.append(("path", word))
            continue

        # File extensions
        if re.match(r"\.\w{1,5}$", word):
            entities.append(("ext", word))
            continue

        # Known directory names (try raw, single-strip, and chain-strip)
        stem = _strip_tr_suffix(w)
        chain_stem = _strip_tr_suffixes_chain(w)
        if w in _DIR_KEYWORDS:
            entities.append(("dir", w))
            continue
        if stem in _DIR_KEYWORDS:
            entities.append(("dir", _DIR_KEYWORDS[stem]))
            continue
        if chain_stem != stem and chain_stem in _DIR_KEYWORDS:
            entities.append(("dir", _DIR_KEYWORDS[chain_stem]))
            continue

        # Uppercase acronyms (any length ≤ 5) → name type
        if raw.isupper() and 2 <= len(w) <= 5:
            entities.append(("name", w))
            continue

        # Repo/project names (alphanumeric with dashes)
        if re.match(r"^[a-zA-Z][\w-]+$", word) and len(word) > 3:
            entities.append(("name", w))
            continue

        # Generic keyword
        entities.append(("keyword", w))

    return entities


def _tr_lower(text: str) -> str:
    """Turkish-aware lowercase: İ (U+0130) → i.

    Standard Python lower() maps İ to i̇ (i + combining dot above U+0307),
    which breaks substring matching. This function normalizes İ → i first.
    """
    return text.replace('\u0130', 'i').lower()


def _sanitize_entity_value(evalue: str, user_input: str) -> str | None:
    """Drop entity values that don't appear verbatim in user input.

    Prevents corrupted tokens (e.g. "ebugün" from "bugün") from
    reaching memory search. Uses Turkish-aware lowercase for İ/i matching.
    """
    if _tr_lower(evalue) in _tr_lower(user_input):
        return evalue
    return None


# =====================================================================
# Auto-Recall (threshold + HIGH/LOW labeling)
# =====================================================================
def auto_recall(
    user_input: str,
    memory_fn: Callable,
    threshold_low: float = 0.4,
    threshold_high: float = 0.7,
) -> list[dict]:
    """
    Extract entities from input, query memory for each, score and label.

    Returns list of {"content": str, "level": "HIGH"|"LOW", "score": float}
    """
    entities = extract_entities(user_input)
    results: list[dict] = []
    seen: set[str] = set()
    type_counts: dict[str, int] = {}

    for etype, evalue in entities[:4]:  # Max 4 entities
        # Guard A: drop corrupted entity values not in user input
        evalue = _sanitize_entity_value(evalue, user_input)
        if evalue is None:
            continue
        try:
            memories = memory_fn(evalue, limit=3)
        except Exception:
            continue

        for m in memories or []:
            content = m.get("content", "") if isinstance(m, dict) else str(m)
            score = m.get("hybrid_score") or m.get("importance", 0.5)
            if isinstance(score, str):
                try:
                    score = float(score)
                except ValueError:
                    score = 0.5

            if score < threshold_low:
                continue

            content_key = content[:100]
            if content_key in seen:
                continue
            seen.add(content_key)

            type_counts[etype] = type_counts.get(etype, 0) + 1
            if type_counts[etype] > 2:
                continue

            level = "HIGH" if score >= threshold_high else "LOW"
            entry = {"content": content, "level": level, "score": score}
            # Preserve original memory fields for downstream gates
            if isinstance(m, dict):
                for k in ("source", "importance", "memory_type", "type"):
                    if k in m:
                        entry[k] = m[k]
            results.append(entry)

    return results


def format_memories_labeled(memories: list[dict]) -> str:
    """Format memories with HIGH/LOW labels for prompt injection."""
    if not memories:
        return ""

    parts = ["[HAFIZA]"]
    for m in memories:
        level = m["level"]
        content = m["content"]
        parts.append(f"[{level}] {content}")

    parts.append("")
    parts.append("NOT: HIGH = guvenilir bilgi, kullan.")
    parts.append("     LOW = ipucu, dogrula.")

    return "\n".join(parts)


# =====================================================================
# Keyword-triggered prefetch rules
# =====================================================================
KEYWORD_PREFETCH = [
    (r"log|kayit|gunluk", "list_dir", lambda: {"path": "logs/"}),
    (r"indir|download|indirilenler", "list_dir",
     lambda: {"path": Resolver.user_dir("downloads") or "."}),
    (r"git|push|commit|branch", "run_shell",
     lambda: {"command": "git status --short"}),
    (r"dosya|file|klasor|folder", "list_dir", lambda: {"path": "."}),
    (r"test|pytest", "run_shell",
     lambda: {"command": "pytest tests/ -q --no-header 2>&1 | tail -5"}),
    (r"hata|error|bug", "list_dir", lambda: {"path": "logs/"}),
]


# =====================================================================
# Phase-0 Prelude Orchestrator
# =====================================================================
class Phase0Result:
    """Collected results from Phase-0 prelude."""

    def __init__(self):
        self.warmup_ok: bool = False
        self.warmup_ms: float = 0
        self.prefetch_cache: PrefetchCache = PrefetchCache()
        self.memories: list[dict] = []
        self.resolver_info: dict = {}
        self.elapsed_ms: float = 0

    def build_prompt_section(self) -> str:
        """Build the prompt section from Phase-0 results."""
        parts: list[str] = []

        # System info from resolver (CWD only)
        if self.resolver_info and "cwd" in self.resolver_info:
            parts.append("[SISTEM BILGISI]")
            parts.append(f"CWD: {self.resolver_info['cwd']}")
            parts.append("")

        # Memory recall results
        if self.memories:
            parts.append(format_memories_labeled(self.memories))
            parts.append("")

        return "\n".join(parts)

    def build_prefetch_messages(self) -> list[dict]:
        """Disabled — fake tool injection removed (model-confusing, high context cost)."""
        return []


def run_phase0(
    user_input: str,
    *,
    llm_complete_fn: Optional[Callable] = None,
    model: str = "",
    memory_search_fn: Optional[Callable] = None,
    tool_fns: Optional[dict[str, Callable]] = None,
    timeout: float = 2.0,
) -> Phase0Result:
    """
    Run Phase-0 Prelude: 3 parallel threads (warmup + recall + resolver).

    Args:
        user_input: Raw user input text
        llm_complete_fn: Function to call LLM (for warmup)
        model: Model name for warmup
        memory_search_fn: memory_hybrid_search function
        tool_fns: Dict of tool functions (unused, kept for API compat)
        timeout: Max seconds to wait for all threads
    """
    result = Phase0Result()
    start = time.time()
    tool_fns = tool_fns or {}

    def _warmup():
        """Thread 1: LLM warmup — max_tokens=1 ping, no tools."""
        if not llm_complete_fn:
            return
        try:
            t0 = time.time()
            llm_complete_fn(
                model=model,
                messages=[{"role": "user", "content": "ok"}],
                tools=None,
                tool_choice="none",
            )
            result.warmup_ok = True
            result.warmup_ms = (time.time() - t0) * 1000
            _debug(f"Phase-0 warmup: {result.warmup_ms:.0f}ms")
        except Exception as e:
            _debug(f"Phase-0 warmup failed: {e}")

    def _auto_recall():
        """Thread 2: Entity-aware memory recall."""
        if not memory_search_fn:
            return
        try:
            result.memories = auto_recall(
                user_input,
                memory_fn=memory_search_fn,
            )
            _debug(f"Phase-0 recall: {len(result.memories)} memories")
            if not _trace_off() and result.memories:
                trace_memory_recall(
                    source="phase0",
                    entity_count=len(extract_entities(user_input)[:4]),
                    result_count=len(result.memories),
                    top_snippets=result.memories[:2],
                )
        except Exception as e:
            _debug(f"Phase-0 recall failed: {e}")

    # Thread 3 (_prefetch) disabled — <1% cache hit rate across 717 runs.
    # PrefetchCache class + runtime cache_hit path kept for future explicit use.

    def _resolve():
        """Thread 4: CWD resolution only."""
        try:
            result.resolver_info = {"cwd": os.getcwd()}
            _debug(f"Phase-0 resolver: cwd={result.resolver_info['cwd']}")
        except Exception as e:
            _debug(f"Phase-0 resolver failed: {e}")

    # Run 3 threads in parallel with timeout (prefetch disabled)
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="phase0") as pool:
        futures = [
            pool.submit(_warmup),
            pool.submit(_auto_recall),
            pool.submit(_resolve),
        ]

        for f in as_completed(futures, timeout=timeout):
            try:
                f.result()
            except Exception as e:
                _debug(f"Phase-0 thread error: {e}")

    result.elapsed_ms = (time.time() - start) * 1000
    _debug(
        f"Phase-0 complete: {result.elapsed_ms:.0f}ms, "
        f"warmup={'ok' if result.warmup_ok else 'skip'}, "
        f"memories={len(result.memories)}"
    )
    return result
