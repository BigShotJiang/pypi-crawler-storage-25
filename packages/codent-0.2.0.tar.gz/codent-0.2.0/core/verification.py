# core/verification.py
"""
Verification system to detect and prevent hallucinations.
"""

import re
import json
from typing import Optional
from dataclasses import dataclass, field

@dataclass
class ToolResult:
    """Record of a tool call and its result."""
    tool_name: str
    args: dict
    result: str
    success: bool
    timestamp: float = 0.0

@dataclass
class Claim:
    """A claim extracted from model response."""
    text: str
    claim_type: str  # file_exists, file_contains, command_output, etc.
    referenced_path: Optional[str] = None
    referenced_content: Optional[str] = None

@dataclass
class VerificationResult:
    """Result of verifying a claim."""
    claim: Claim
    is_valid: bool
    reason: str
    evidence: Optional[str] = None

class ToolResultTracker:
    """Tracks all tool calls and results for verification."""

    def __init__(self):
        self.results: list[ToolResult] = []
        self.files_read: dict[str, str] = {}      # path -> content
        self.files_written: dict[str, str] = {}   # path -> content
        self.dirs_listed: dict[str, list] = {}    # path -> entries
        self.commands_run: list[dict] = []        # {cmd, exit_code, output}

    def record(self, tool_name: str, args: dict, result: str, success: bool):
        """Record a tool call result."""
        import time
        self.results.append(ToolResult(
            tool_name=tool_name,
            args=args,
            result=result,
            success=success,
            timestamp=time.time()
        ))

        # Index by type for quick lookup
        if tool_name == "read_file" and success:
            path = args.get("path", "")
            self.files_read[path] = result

        elif tool_name == "write_file" and success:
            path = args.get("path", "")
            content = args.get("content", "")
            self.files_written[path] = content

        elif tool_name == "list_dir" and success:
            path = args.get("path", ".")
            # Parse list_dir output
            try:
                entries = [line.strip() for line in result.split('\n') if line.strip()]
                self.dirs_listed[path] = entries
            except Exception:
                self.dirs_listed[path] = []

        elif tool_name == "run_shell":
            cmd = args.get("cmd", "")
            # Parse exit code from result
            exit_code = -1
            if "[exit code:" in result:
                match = re.search(r'\[exit code: (\d+)\]', result)
                if match:
                    exit_code = int(match.group(1))
            self.commands_run.append({
                "cmd": cmd,
                "exit_code": exit_code,
                "output": result
            })

    def was_file_read(self, path: str) -> bool:
        """Check if a file was read this session."""
        # Normalize path
        path = path.lstrip("./")
        return path in self.files_read or f"./{path}" in self.files_read

    def was_file_written(self, path: str) -> bool:
        """Check if a file was written this session."""
        path = path.lstrip("./")
        return path in self.files_written or f"./{path}" in self.files_written

    def was_dir_listed(self, path: str) -> bool:
        """Check if a directory was listed this session."""
        path = path.rstrip("/") or "."
        return path in self.dirs_listed

    def get_file_content(self, path: str) -> Optional[str]:
        """Get content of a file that was read."""
        path = path.lstrip("./")
        return self.files_read.get(path) or self.files_read.get(f"./{path}")

    def file_contains(self, path: str, text: str) -> bool:
        """Check if a read file contains specific text."""
        content = self.get_file_content(path)
        if content is None:
            return False
        return text in content

    def dir_contains(self, path: str, entry: str) -> bool:
        """Check if a listed directory contains an entry."""
        path = path.rstrip("/") or "."
        entries = self.dirs_listed.get(path, [])
        return entry in entries or any(entry in e for e in entries)


# Patterns that indicate unverified claims
HALLUCINATION_PATTERNS = [
    (r"\b(I assume|assuming|I would assume)\b", "assumption_language"),
    (r"\b(typically|usually|normally|generally)\b", "generalizing_language"),
    (r"\b(probably|likely|most likely|should have)\b", "uncertain_language"),
    (r"\b(standard practice|common practice|best practice suggests)\b", "appeal_to_convention"),
    (r"the file (probably|likely|should) (contain|have|include)", "file_speculation"),
    (r"there (should|would|might) be a", "existence_speculation"),
]

# Patterns that indicate claims about files/content
CLAIM_PATTERNS = [
    (r"(?:file|found|contains?|shows?|has)\s+['\"]?([^'\"]+\.[\w]+)['\"]?\s+(?:contains?|shows?|has)\s+['\"]([^'\"]+)['\"]", "file_contains"),
    (r"(?:created?|wrote|written|modified)\s+(?:file\s+)?['\"]?([^'\"]+\.[\w]+)['\"]?", "file_created"),
    (r"(?:directory|folder)\s+['\"]?([^'\"]+)['\"]?\s+contains?\s+['\"]?([^'\"]+)['\"]?", "dir_contains"),
    (r"\[exit code:\s*(\d+)\]", "command_exit_code"),
]


def _strip_code_and_quotes(text: str) -> str:
    """Remove code blocks and quoted strings to avoid false positives."""
    # Remove fenced code blocks (```...```)
    text = re.sub(r'```[\s\S]*?```', ' ', text)
    # Remove inline code (`...`)
    text = re.sub(r'`[^`]+`', ' ', text)
    # Remove double-quoted strings
    text = re.sub(r'"[^"]{3,}"', ' ', text)
    # Remove single-quoted strings
    text = re.sub(r"'[^']{3,}'", ' ', text)
    return text


def detect_hallucination_language(text: str) -> list[tuple[str, str]]:
    """
    Detect language patterns that suggest hallucination.
    Returns list of (matched_text, pattern_type).
    Skips matches inside code blocks or quoted strings.
    """
    cleaned = _strip_code_and_quotes(text)
    findings = []
    for pattern, pattern_type in HALLUCINATION_PATTERNS:
        matches = re.finditer(pattern, cleaned, re.IGNORECASE)
        for match in matches:
            findings.append((match.group(0), pattern_type))
    return findings


def extract_claims(response: str) -> list[Claim]:
    """
    Extract verifiable claims from model response.
    """
    claims = []

    # Look for file content claims
    file_claims = re.finditer(
        r"(?:file\s+)?['\"`]([^'\"`]+)['\"`]\s+(?:contains?|shows?|has|includes?)\s+['\"`]([^'\"`]+)['\"`]",
        response, re.IGNORECASE
    )
    for match in file_claims:
        claims.append(Claim(
            text=match.group(0),
            claim_type="file_contains",
            referenced_path=match.group(1),
            referenced_content=match.group(2)
        ))

    # Look for file creation/modification claims
    write_claims = re.finditer(
        r"(?:created?|wrote|written|modified|updated)\s+(?:the\s+)?(?:file\s+)?['\"`]([^'\"`]+)['\"`]",
        response, re.IGNORECASE
    )
    for match in write_claims:
        claims.append(Claim(
            text=match.group(0),
            claim_type="file_written",
            referenced_path=match.group(1)
        ))

    # Look for directory content claims
    dir_claims = re.finditer(
        r"(?:directory|folder)\s+['\"`]([^'\"`]+)['\"`]\s+(?:contains?|has|includes?)\s+['\"`]([^'\"`]+)['\"`]",
        response, re.IGNORECASE
    )
    for match in dir_claims:
        claims.append(Claim(
            text=match.group(0),
            claim_type="dir_contains",
            referenced_path=match.group(1),
            referenced_content=match.group(2)
        ))

    # Look for "file exists" claims
    exists_claims = re.finditer(
        r"(?:there is|found|exists?)\s+(?:a\s+)?(?:file\s+)?['\"`]([^'\"`]+\.[\w]+)['\"`]",
        response, re.IGNORECASE
    )
    for match in exists_claims:
        claims.append(Claim(
            text=match.group(0),
            claim_type="file_exists",
            referenced_path=match.group(1)
        ))

    return claims


def verify_claims(claims: list[Claim], tracker: ToolResultTracker) -> list[VerificationResult]:
    """
    Verify each claim against recorded tool results.
    """
    results = []

    for claim in claims:
        if claim.claim_type == "file_contains":
            if not tracker.was_file_read(claim.referenced_path):
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"File '{claim.referenced_path}' was never read this session"
                ))
            elif not tracker.file_contains(claim.referenced_path, claim.referenced_content):
                actual_content = tracker.get_file_content(claim.referenced_path)
                snippet = actual_content[:200] + "..." if actual_content and len(actual_content) > 200 else actual_content
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"Content '{claim.referenced_content}' not found in file",
                    evidence=f"Actual content: {snippet}"
                ))
            else:
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=True,
                    reason="Verified: content found in file"
                ))

        elif claim.claim_type == "file_written":
            if not tracker.was_file_written(claim.referenced_path):
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"File '{claim.referenced_path}' was never written this session"
                ))
            else:
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=True,
                    reason="Verified: file was written"
                ))

        elif claim.claim_type == "file_exists":
            # Check if we listed a directory containing this file
            path = claim.referenced_path
            parent = "/".join(path.split("/")[:-1]) or "."
            filename = path.split("/")[-1]

            if tracker.was_dir_listed(parent) and tracker.dir_contains(parent, filename):
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=True,
                    reason="Verified: file seen in directory listing"
                ))
            elif tracker.was_file_read(path):
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=True,
                    reason="Verified: file was successfully read"
                ))
            else:
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"File existence not verified - not seen in any list_dir or read_file"
                ))

        elif claim.claim_type == "dir_contains":
            if not tracker.was_dir_listed(claim.referenced_path):
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"Directory '{claim.referenced_path}' was never listed"
                ))
            elif not tracker.dir_contains(claim.referenced_path, claim.referenced_content):
                actual = tracker.dirs_listed.get(claim.referenced_path, [])
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=False,
                    reason=f"Entry '{claim.referenced_content}' not found in directory",
                    evidence=f"Actual contents: {actual[:10]}"
                ))
            else:
                results.append(VerificationResult(
                    claim=claim,
                    is_valid=True,
                    reason="Verified: entry found in directory"
                ))

    return results


def generate_correction_prompt(
    original_response: str,
    verification_results: list[VerificationResult],
    hallucination_warnings: list[tuple[str, str]]
) -> Optional[str]:
    """
    Generate a correction prompt if verification failed.
    Returns None if no correction needed.
    """
    issues = []

    # Check for invalid claims
    invalid_claims = [r for r in verification_results if not r.is_valid]
    if invalid_claims:
        issues.append("UNVERIFIED CLAIMS DETECTED:")
        for r in invalid_claims:
            issues.append(f"  - Claim: \"{r.claim.text}\"")
            issues.append(f"    Problem: {r.reason}")
            if r.evidence:
                issues.append(f"    Evidence: {r.evidence}")

    # Check for hallucination language
    if hallucination_warnings:
        issues.append("\nPROBLEMATIC LANGUAGE DETECTED:")
        for text, pattern_type in hallucination_warnings[:5]:  # Limit to 5
            issues.append(f"  - \"{text}\" ({pattern_type})")

    if not issues:
        return None

    return f"""Your response contains verification issues:

{chr(10).join(issues)}

Please revise your response:
1. Remove or correct unverified claims
2. Replace uncertain language with verified facts
3. If you cannot verify something, say "I did not verify this" or omit it
4. Cite tool results for every factual claim

Provide your corrected response:"""


class ResponseVerifier:
    """Main class for verifying model responses."""

    def __init__(self, strict_mode: bool = True):
        self.strict_mode = strict_mode
        self.tracker = ToolResultTracker()

    def record_tool_call(self, tool_name: str, args: dict, result: str, success: bool):
        """Record a tool call for later verification."""
        self.tracker.record(tool_name, args, result, success)

    def verify_response(self, response: str) -> tuple[bool, Optional[str]]:
        """
        Verify a model response.
        Returns (is_valid, correction_prompt_or_none)
        """
        # Check for hallucination language
        warnings = detect_hallucination_language(response)

        # Extract and verify claims
        claims = extract_claims(response)
        verification_results = verify_claims(claims, self.tracker)

        has_invalid_claims = any(not r.is_valid for r in verification_results)

        # In strict mode, require 2+ hallucination warnings to trigger
        # (single "likely" or "typically" is not enough on its own)
        if self.strict_mode:
            has_issues = has_invalid_claims or len(warnings) >= 2
        else:
            # In relaxed mode, only invalid claims trigger correction
            has_issues = has_invalid_claims

        if has_issues:
            correction = generate_correction_prompt(response, verification_results, warnings)
            return False, correction

        return True, None

    def reset(self):
        """Reset tracker for new task."""
        self.tracker = ToolResultTracker()
