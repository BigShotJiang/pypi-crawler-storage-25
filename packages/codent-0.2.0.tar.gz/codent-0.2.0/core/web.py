# core/web.py
"""
Web fetch, web search, and repo fetch implementations.
Includes SSRF prevention, HTML-to-text conversion, and caching.
"""

import os
import re
import io
import json
import socket
import hashlib
import shutil
import tarfile
import ipaddress
import subprocess
import requests
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse, parse_qs, unquote
from html.parser import HTMLParser


# ── Config ──
_CONT_DIR = Path(__file__).parent.parent.resolve()
_REPO_ROOT = Path(os.environ.get("CONT__REPO_ROOT", os.getcwd())).resolve()

WEB_MAX_BYTES = int(os.environ.get("CONT_WEB_MAX_BYTES", "1000000"))  # 1MB
WEB_TIMEOUT = int(os.environ.get("CONT_WEB_TIMEOUT", "15"))  # seconds
WEB_CACHE_ENABLED = os.environ.get("CONT_WEB_CACHE", "1") == "1"
WEB_CACHE_DIR = _CONT_DIR / "logs" / "web_cache"
WEB_MAX_REDIRECTS = 3
WEB_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

REPO_MAX_MB = int(os.environ.get("CONT_REPO_MAX_MB", "50"))  # 50MB default
EXTERNAL_DIR = _REPO_ROOT / "external"
ALLOWED_REPO_HOSTS = {"github.com", "gitlab.com", "bitbucket.org", "raw.githubusercontent.com"}

# =====================
# Safety - Web Fetch (SSRF Prevention)
# =====================
# Blocked hostnames
BLOCKED_HOSTNAMES = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1",
    "metadata.google.internal", "169.254.169.254",
}

# Private/reserved IP ranges
PRIVATE_IP_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),       # Loopback
    ipaddress.ip_network("10.0.0.0/8"),        # Private A
    ipaddress.ip_network("172.16.0.0/12"),     # Private B
    ipaddress.ip_network("192.168.0.0/16"),    # Private C
    ipaddress.ip_network("169.254.0.0/16"),    # Link-local
    ipaddress.ip_network("224.0.0.0/4"),       # Multicast
    ipaddress.ip_network("240.0.0.0/4"),       # Reserved
    ipaddress.ip_network("0.0.0.0/8"),         # Current network
    ipaddress.ip_network("100.64.0.0/10"),     # Shared address space (CGNAT)
    ipaddress.ip_network("192.0.0.0/24"),      # IETF Protocol Assignments
    ipaddress.ip_network("192.0.2.0/24"),      # TEST-NET-1
    ipaddress.ip_network("198.51.100.0/24"),   # TEST-NET-2
    ipaddress.ip_network("203.0.113.0/24"),    # TEST-NET-3
    ipaddress.ip_network("::1/128"),           # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),          # IPv6 unique local
    ipaddress.ip_network("fe80::/10"),         # IPv6 link-local
    ipaddress.ip_network("ff00::/8"),          # IPv6 multicast
]

def is_private_ip(ip_str: str) -> bool:
    """Check if an IP address is private/reserved/blocked."""
    try:
        ip = ipaddress.ip_address(ip_str)
        for network in PRIVATE_IP_NETWORKS:
            if ip in network:
                return True
        return False
    except ValueError:
        return True  # Invalid IP = blocked

def validate_url_scheme(url: str) -> None:
    """Validate URL scheme is http or https."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Invalid URL scheme: {parsed.scheme}. Only http/https allowed.")

def validate_hostname(hostname: str) -> None:
    """Check if hostname is blocked."""
    hostname_lower = hostname.lower()
    if hostname_lower in BLOCKED_HOSTNAMES:
        raise ValueError(f"Blocked hostname: {hostname}")
    # Check for IP address in hostname
    try:
        ip = ipaddress.ip_address(hostname)
        # Successfully parsed as IP - check if private
        if is_private_ip(str(ip)):
            raise ValueError(f"Blocked private/reserved IP: {hostname}")
    except ValueError as e:
        # Re-raise if it's our own "Blocked" error
        if "Blocked" in str(e):
            raise
        # Otherwise it's not a valid IP, which is fine (it's a hostname)

def resolve_and_validate_hostname(hostname: str) -> list:
    """
    Resolve hostname to IPs and validate none are private/reserved.
    Returns list of validated IPs.
    """
    validate_hostname(hostname)

    try:
        # Resolve hostname to IP addresses
        addr_info = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        ips = list(set(info[4][0] for info in addr_info))

        if not ips:
            raise ValueError(f"Could not resolve hostname: {hostname}")

        for ip in ips:
            if is_private_ip(ip):
                raise ValueError(f"Hostname {hostname} resolves to blocked IP: {ip}")

        return ips
    except socket.gaierror as e:
        raise ValueError(f"DNS resolution failed for {hostname}: {e}")

def validate_url_for_fetch(url: str) -> str:
    """
    Comprehensive URL validation for SSRF prevention.
    Returns the validated URL.
    """
    validate_url_scheme(url)
    parsed = urlparse(url)

    if not parsed.netloc:
        raise ValueError("Invalid URL: missing hostname")

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Invalid URL: could not extract hostname")

    # Resolve and validate all IPs
    resolve_and_validate_hostname(hostname)

    return url

# =====================
# HTML to Text Conversion
# =====================
class HTMLTextExtractor(HTMLParser):
    """Simple HTML to text converter that strips scripts/styles."""

    def __init__(self):
        super().__init__()
        self.result = []
        self.skip_data = False
        self.skip_tags = {"script", "style", "noscript", "head", "meta", "link"}

    def handle_starttag(self, tag, attrs):
        if tag.lower() in self.skip_tags:
            self.skip_data = True
        elif tag.lower() in ("br", "p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
            self.result.append("\n")

    def handle_endtag(self, tag):
        if tag.lower() in self.skip_tags:
            self.skip_data = False
        elif tag.lower() in ("p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
            self.result.append("\n")

    def handle_data(self, data):
        if not self.skip_data:
            self.result.append(data)

    def get_text(self) -> str:
        text = "".join(self.result)
        # Clean up whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)
        return text.strip()

def html_to_text(html: str) -> str:
    """Convert HTML to plain text, stripping scripts/styles."""
    try:
        parser = HTMLTextExtractor()
        parser.feed(html)
        return parser.get_text()
    except Exception:
        # Fallback: strip all tags with regex
        text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

# =====================
# Web Fetch Caching
# =====================
def get_cache_key(url: str) -> str:
    """Generate cache key from URL."""
    return hashlib.sha256(url.encode()).hexdigest()

def get_cached_response(url: str) -> Optional[dict]:
    """Try to get cached response for URL."""
    if not WEB_CACHE_ENABLED:
        return None

    cache_key = get_cache_key(url)
    meta_file = WEB_CACHE_DIR / f"{cache_key}.meta.json"
    body_file = WEB_CACHE_DIR / f"{cache_key}.body.txt"

    if meta_file.exists() and body_file.exists():
        try:
            meta = json.loads(meta_file.read_text())
            text = body_file.read_text(errors="replace")
            meta["text"] = text
            meta["cache_hit"] = True
            return meta
        except Exception:
            return None
    return None

def save_to_cache(url: str, result: dict) -> None:
    """Save response to cache."""
    if not WEB_CACHE_ENABLED:
        return

    try:
        WEB_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_key = get_cache_key(url)
        meta_file = WEB_CACHE_DIR / f"{cache_key}.meta.json"
        body_file = WEB_CACHE_DIR / f"{cache_key}.body.txt"

        # Save metadata (without text)
        meta = {k: v for k, v in result.items() if k != "text"}
        meta_file.write_text(json.dumps(meta, indent=2))

        # Save body text
        body_file.write_text(result.get("text", ""))
    except Exception:
        pass  # Cache write failure is not critical

# =====================
# Web Fetch Implementation
# =====================
ALLOWED_CONTENT_TYPES = {
    "text/html", "text/plain", "text/xml", "text/css", "text/javascript",
    "application/json", "application/xml", "application/xhtml+xml",
    "application/javascript", "application/x-javascript",
}

def web_fetch(
    url: str,
    max_bytes: Optional[int] = None,
    timeout_sec: Optional[int] = None,
    headers: Optional[dict] = None
) -> dict:
    """
    Fetch web content with SSRF protection, size limits, and caching.
    """
    # Check cache first
    cached = get_cached_response(url)
    if cached:
        return cached

    # Apply defaults
    max_bytes = max_bytes or WEB_MAX_BYTES
    timeout_sec = timeout_sec or WEB_TIMEOUT

    # Validate URL
    validate_url_for_fetch(url)

    # Build headers - only allow safe headers
    request_headers = {"User-Agent": WEB_USER_AGENT}
    if headers:
        allowed_header_keys = {"accept", "user-agent"}
        for key, value in headers.items():
            if key.lower() in allowed_header_keys:
                request_headers[key] = value
            else:
                raise ValueError(f"Header not allowed: {key}. Only Accept and User-Agent permitted.")

    # Track redirects manually for validation
    current_url = url
    redirect_count = 0

    session = requests.Session()
    # Redirects handled manually below via allow_redirects=False

    while True:
        # Validate current URL before each request
        validate_url_for_fetch(current_url)

        try:
            response = session.get(
                current_url,
                headers=request_headers,
                timeout=timeout_sec,
                allow_redirects=False,
                stream=True
            )
        except requests.exceptions.Timeout:
            raise ValueError(f"Request timed out after {timeout_sec}s")
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Request failed: {e}")

        # Handle redirects manually
        if response.is_redirect:
            redirect_count += 1
            if redirect_count > WEB_MAX_REDIRECTS:
                raise ValueError(f"Too many redirects (max {WEB_MAX_REDIRECTS})")

            redirect_url = response.headers.get("Location")
            if not redirect_url:
                raise ValueError("Redirect without Location header")

            # Handle relative URLs
            if not redirect_url.startswith(("http://", "https://")):
                from urllib.parse import urljoin
                redirect_url = urljoin(current_url, redirect_url)

            current_url = redirect_url
            continue

        break

    # Check content type
    content_type = response.headers.get("Content-Type", "").split(";")[0].strip().lower()

    is_allowed = False
    for allowed in ALLOWED_CONTENT_TYPES:
        if content_type.startswith(allowed) or allowed.startswith(content_type):
            is_allowed = True
            break

    if not is_allowed and content_type:
        raise ValueError(f"Content type not allowed: {content_type}. Only text/* and application/json permitted.")

    # Stream download with size limit
    chunks = []
    total_bytes = 0
    truncated = False

    for chunk in response.iter_content(chunk_size=8192):
        if total_bytes + len(chunk) > max_bytes:
            # Take only what fits
            remaining = max_bytes - total_bytes
            chunks.append(chunk[:remaining])
            total_bytes = max_bytes
            truncated = True
            break
        chunks.append(chunk)
        total_bytes += len(chunk)

    response.close()

    # Decode content
    raw_content = b"".join(chunks)

    # Try to detect encoding
    encoding = response.encoding or "utf-8"
    try:
        text = raw_content.decode(encoding, errors="replace")
    except Exception:
        text = raw_content.decode("utf-8", errors="replace")

    # Process based on content type
    if "html" in content_type or "xhtml" in content_type:
        text = html_to_text(text)
    elif "json" in content_type:
        try:
            parsed = json.loads(text)
            text = json.dumps(parsed, indent=2)
            if len(text) > max_bytes:
                text = text[:max_bytes]
                truncated = True
        except json.JSONDecodeError:
            pass  # Keep as-is

    # Calculate hash
    content_hash = hashlib.sha256(raw_content).hexdigest()

    result = {
        "url": url,
        "final_url": current_url,
        "status_code": response.status_code,
        "content_type": content_type,
        "bytes": total_bytes,
        "sha256": content_hash,
        "text": text,
        "truncated": truncated,
        "cache_hit": False
    }

    # Save to cache
    save_to_cache(url, result)

    return result

# =====================
# Web Search Implementation
# =====================
def web_search(
    query: str,
    max_results: int = 5,
    language: str = "en",
    recency_days: Optional[int] = None
) -> dict:
    """
    Search the web using DuckDuckGo HTML endpoint.
    Returns ranked results with title, snippet, and URL.
    """
    if not query or not query.strip():
        raise ValueError("Search query cannot be empty")

    query = query.strip()
    max_results = min(max(1, max_results), 10)  # Clamp to 1-10

    # Auto-detect Turkish if language not explicitly set
    if language == "en":
        _turkish_chars = set("çğıöşüÇĞİÖŞÜ")
        if any(c in _turkish_chars for c in query):
            language = "tr-TR"

    # Build DuckDuckGo HTML search URL
    params = {"q": query}
    if language and language != "en":
        params["kl"] = language
    if recency_days:
        # DuckDuckGo time filter: d=day, w=week, m=month
        if recency_days <= 1:
            params["df"] = "d"
        elif recency_days <= 7:
            params["df"] = "w"
        elif recency_days <= 30:
            params["df"] = "m"

    search_url = "https://html.duckduckgo.com/html/"

    try:
        response = requests.post(
            search_url,
            data=params,
            headers={"User-Agent": WEB_USER_AGENT},
            timeout=WEB_TIMEOUT
        )
        response.raise_for_status()
    except requests.exceptions.Timeout:
        raise ValueError(f"Search timed out after {WEB_TIMEOUT}s")
    except requests.exceptions.RequestException as e:
        raise ValueError(f"Search request failed: {e}")

    # Parse results from HTML
    results = []
    html = response.text

    # Simple regex-based extraction (avoids BeautifulSoup dependency)
    # DuckDuckGo HTML format: <a class="result__a" href="...">Title</a>
    # and <a class="result__snippet">Snippet</a>
    result_pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([^<]+)</a>.*?'
        r'<a[^>]+class="result__snippet"[^>]*>([^<]*(?:<[^>]+>[^<]*)*)</a>',
        re.DOTALL | re.IGNORECASE
    )

    # Alternative pattern for different HTML structure
    alt_pattern = re.compile(
        r'<h2[^>]*class="result__title"[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>([^<]+)</a>.*?'
        r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
        re.DOTALL | re.IGNORECASE
    )

    matches = result_pattern.findall(html)
    if not matches:
        matches = alt_pattern.findall(html)

    for i, match in enumerate(matches[:max_results], 1):
        url, title, snippet = match

        # Clean up URL (DuckDuckGo wraps URLs in redirects)
        if "uddg=" in url:
            # Extract actual URL from DuckDuckGo redirect
            parsed_qs = parse_qs(urlparse(url).query)
            if "uddg" in parsed_qs:
                url = unquote(parsed_qs["uddg"][0])

        # Clean snippet (remove HTML tags)
        snippet = re.sub(r'<[^>]+>', '', snippet)
        snippet = re.sub(r'\s+', ' ', snippet).strip()

        # Validate URL is not private
        try:
            parsed_url = urlparse(url)
            if parsed_url.hostname:
                validate_hostname(parsed_url.hostname)
        except ValueError:
            continue  # Skip results pointing to private IPs

        results.append({
            "rank": i,
            "title": title.strip(),
            "snippet": snippet[:500],  # Limit snippet length
            "url": url
        })

    # Handle no results case with helpful suggestions
    if not results:
        # Debug: dump raw HTML when 0 results (for diagnosis)
        from core.utils import debug as _debug
        _debug(f"web_search 0 results for '{query}' (language={language})")
        _debug(f"  HTML length: {len(html)}, first 300: {html[:300]}")

        suggestions = []
        words = query.split()
        if len(words) > 2:
            suggestions.append(" ".join(words[:2]))
            suggestions.append(" ".join(words[-2:]))
        else:
            suggestions.append(query + " tutorial")
            suggestions.append(query + " documentation")

        return {
            "query": query,
            "results": [],
            "count": 0,
            "no_results": True,
            "backend_status": "ok",
            "suggestion": (
                f"No results found. Alternative queries to try: {suggestions[:2]}. "
                "IMPORTANT: Do NOT invent/guess URLs. Use web_fetch only with URLs "
                "from search results or user input."
            )
        }

    return {
        "query": query,
        "results": results,
        "count": len(results),
        "no_results": False
    }

# =====================
# Repo Fetch Implementation
# =====================
def validate_repo_source(source: str) -> tuple:
    """
    Validate repo source URL is from allowlisted hosts.
    Returns (hostname, parsed_url).
    """
    validate_url_scheme(source)
    parsed = urlparse(source)

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Invalid repo URL: missing hostname")

    hostname_lower = hostname.lower()
    if hostname_lower not in ALLOWED_REPO_HOSTS:
        raise ValueError(
            f"Repo source not allowed: {hostname}. "
            f"Allowed: {', '.join(sorted(ALLOWED_REPO_HOSTS))}"
        )

    # Validate not pointing to private IP
    resolve_and_validate_hostname(hostname)

    return hostname_lower, parsed

def repo_fetch(
    source: str,
    dest: str,
    ref: Optional[str] = None,
    force: bool = False
) -> dict:
    """
    Download external code from allowlisted hosts.
    Uses git clone --depth 1 or HTTPS tarball download.
    """
    # Validate source
    hostname, parsed = validate_repo_source(source)

    # Validate and resolve dest path
    if not dest:
        raise ValueError("Destination path required")

    # Ensure dest is relative and under external/
    dest_clean = dest.strip().lstrip("/").lstrip("\\")
    if dest_clean.startswith("..") or dest_clean.startswith("external/.."):
        raise ValueError("Destination cannot escape external/ directory")

    # Force dest under external/
    if not dest_clean.startswith("external/"):
        dest_clean = f"external/{dest_clean}"

    dest_path = (_REPO_ROOT / dest_clean).resolve()

    # Security check: must be under EXTERNAL_DIR
    if not str(dest_path).startswith(str(EXTERNAL_DIR)):
        raise ValueError(f"Destination must be under external/: {dest_clean}")

    # Check if dest exists
    if dest_path.exists() and not force:
        raise ValueError(f"Destination already exists: {dest_clean}. Use force=true to overwrite.")

    # Create external/ directory
    EXTERNAL_DIR.mkdir(parents=True, exist_ok=True)

    # Remove existing if force=true
    if dest_path.exists() and force:
        shutil.rmtree(dest_path)

    # Try git clone first
    git_url = source
    if hostname == "github.com" and not source.endswith(".git"):
        # Normalize GitHub URL
        git_url = source.rstrip("/")
        if not git_url.endswith(".git"):
            git_url += ".git"

    result_info = {
        "source": source,
        "dest": dest_clean,
        "verify_path": dest_clean,  # Path to verify with list_dir
        "ref": ref,
        "method": None,
        "files": 0,
        "bytes": 0,
        "sha256": None,
        "success": False,
        "exists": False,
        "action_required": "VERIFY: Run list_dir on verify_path to confirm contents before describing."
    }

    try:
        # Build git clone command
        cmd = ["git", "clone", "--depth", "1"]
        if ref:
            cmd.extend(["--branch", ref])
        cmd.extend([git_url, str(dest_path)])

        # Run git clone with size limit check via environment
        env = os.environ.copy()
        env["GIT_TERMINAL_PROMPT"] = "0"  # Disable prompts

        proc = subprocess.run(
            cmd,
            cwd=_REPO_ROOT,
            capture_output=True,
            text=True,
            timeout=120,
            env=env
        )

        if proc.returncode == 0:
            result_info["method"] = "git_clone"

            # Get commit SHA
            try:
                sha_proc = subprocess.run(
                    ["git", "rev-parse", "HEAD"],
                    cwd=dest_path,
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if sha_proc.returncode == 0:
                    result_info["sha256"] = sha_proc.stdout.strip()
            except Exception:
                pass

            # Remove .git directory (no hooks, no submodules)
            git_dir = dest_path / ".git"
            if git_dir.exists():
                shutil.rmtree(git_dir)

            # Count files and size
            total_bytes = 0
            file_count = 0
            for f in dest_path.rglob("*"):
                if f.is_file():
                    file_count += 1
                    total_bytes += f.stat().st_size

            result_info["files"] = file_count
            result_info["bytes"] = total_bytes

            # Check size limit
            max_bytes = REPO_MAX_MB * 1024 * 1024
            if total_bytes > max_bytes:
                shutil.rmtree(dest_path)
                raise ValueError(f"Repository too large: {total_bytes / 1024 / 1024:.1f}MB > {REPO_MAX_MB}MB limit")

            result_info["success"] = True
            result_info["exists"] = True
            result_info["action_required"] = "MANDATORY: Run list_dir on verify_path to confirm contents. Do NOT describe files you have not seen."
            return result_info
        else:
            # Git clone failed, try tarball for GitHub
            if hostname == "github.com":
                raise ValueError("Git clone failed, trying tarball...")
            else:
                raise ValueError(f"Git clone failed: {proc.stderr}")

    except subprocess.TimeoutExpired:
        raise ValueError("Git clone timed out after 120s")
    except ValueError as e:
        if "trying tarball" not in str(e):
            raise

    # Fallback: tarball download for GitHub
    if hostname == "github.com":
        # Parse repo path: github.com/owner/repo
        path_parts = parsed.path.strip("/").split("/")
        if len(path_parts) < 2:
            raise ValueError("Invalid GitHub URL format")

        owner, repo = path_parts[0], path_parts[1].replace(".git", "")
        branch = ref or "main"

        tarball_url = f"https://github.com/{owner}/{repo}/archive/refs/heads/{branch}.tar.gz"

        try:
            response = requests.get(
                tarball_url,
                headers={"User-Agent": WEB_USER_AGENT},
                timeout=60,
                stream=True
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            # Try 'master' branch if 'main' fails
            if branch == "main":
                tarball_url = f"https://github.com/{owner}/{repo}/archive/refs/heads/master.tar.gz"
                try:
                    response = requests.get(
                        tarball_url,
                        headers={"User-Agent": WEB_USER_AGENT},
                        timeout=60,
                        stream=True
                    )
                    response.raise_for_status()
                    branch = "master"
                except requests.exceptions.RequestException as e2:
                    raise ValueError(f"Failed to download tarball: {e2}")
            else:
                raise ValueError(f"Failed to download tarball: {e}")

        # Download with size limit
        max_bytes = REPO_MAX_MB * 1024 * 1024
        chunks = []
        total_downloaded = 0

        for chunk in response.iter_content(chunk_size=8192):
            total_downloaded += len(chunk)
            if total_downloaded > max_bytes:
                raise ValueError(f"Download exceeds {REPO_MAX_MB}MB limit")
            chunks.append(chunk)

        tarball_data = b"".join(chunks)
        result_info["sha256"] = hashlib.sha256(tarball_data).hexdigest()

        # Extract tarball
        dest_path.mkdir(parents=True, exist_ok=True)

        with tarfile.open(fileobj=io.BytesIO(tarball_data), mode="r:gz") as tar:
            # Security: check for path traversal
            for member in tar.getmembers():
                if member.name.startswith("/") or ".." in member.name:
                    raise ValueError(f"Dangerous path in tarball: {member.name}")

            # Extract, stripping top-level directory
            members = tar.getmembers()
            if members:
                # GitHub archives have a top-level dir like "repo-branch/"
                top_dir = members[0].name.split("/")[0]

                for member in members[1:]:  # Skip top directory itself
                    # Strip top directory from path
                    if member.name.startswith(top_dir + "/"):
                        member.name = member.name[len(top_dir) + 1:]
                        if member.name:  # Skip empty names
                            tar.extract(member, dest_path)

        # Count files and size
        total_bytes = 0
        file_count = 0
        for f in dest_path.rglob("*"):
            if f.is_file():
                file_count += 1
                total_bytes += f.stat().st_size

        result_info["method"] = "tarball"
        result_info["files"] = file_count
        result_info["bytes"] = total_bytes
        result_info["ref"] = branch
        result_info["success"] = True
        result_info["exists"] = True
        result_info["action_required"] = "MANDATORY: Run list_dir on verify_path to confirm contents. Do NOT describe files you have not seen."

        return result_info

    raise ValueError(f"Could not fetch repository from {hostname}")

