# core/browser.py
"""
Playwright browser automation for Cont.

Gives Cont a real browser it can control:
- Navigate to URLs
- Click elements
- Type text
- Extract page content
- Take screenshots
- Fill forms

Usage as a tool:
  browser_open(url) — open a page
  browser_click(selector) — click element
  browser_type(selector, text) — type into input
  browser_text(selector?) — extract text from page/element
  browser_screenshot(path?) — take screenshot
  browser_close() — close browser
"""

import os
import asyncio
import json
import time
from typing import Optional, Dict, List
from pathlib import Path
from urllib.parse import urlparse


# Security: allowed URL schemes
_ALLOWED_SCHEMES = {"http", "https"}


def _validate_url(url):
    """Validate URL for security. Returns (ok, error)."""
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Geçersiz URL"

    if parsed.scheme not in _ALLOWED_SCHEMES:
        return False, f"Sadece http/https desteklenir, '{parsed.scheme}' değil"

    if parsed.hostname in ("localhost", "127.0.0.1", "::1"):
        return False, "localhost erişimi engellendi"

    return True, None


class Browser:
    """Persistent browser session for Cont."""

    _instance = None
    _browser = None
    _page = None
    _context = None
    _pw = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _ensure_loop(self):
        """Get or create event loop."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_closed():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop

    def _run(self, coro):
        """Run async code from sync context."""
        loop = self._ensure_loop()
        return loop.run_until_complete(coro)

    async def _ensure_browser(self):
        """Launch browser if not running."""
        if self._browser is None or not self._browser.is_connected():
            from playwright.async_api import async_playwright
            self._pw = await async_playwright().start()
            self._browser = await self._pw.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage']
            )
            self._context = await self._browser.new_context(
                viewport={'width': 1280, 'height': 720},
                user_agent=(
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36'
                ),
                ignore_https_errors=True,
            )
            self._page = await self._context.new_page()

    async def _ensure_page(self):
        await self._ensure_browser()
        if self._page is None or self._page.is_closed():
            self._page = await self._context.new_page()
        return self._page

    # === PUBLIC API (sync wrappers) ===

    # Known local gateway signatures — if page title/content matches,
    # it means DNS resolved to local router instead of target site.
    _GATEWAY_SIGNATURES = [
        "zxhn", "zte ", "router", "modem", "gateway",
        "hoşgeldiniz", "oturum aç", "login page",
        "tp-link", "huawei", "netgear", "asus rt-",
    ]

    def _looks_like_gateway(self, title, text):
        """Check if page looks like a local router/gateway page."""
        combined = f"{title} {text[:500]}".lower()
        return any(sig in combined for sig in self._GATEWAY_SIGNATURES)

    def open(self, url, wait_until="domcontentloaded", timeout=15000):
        """Navigate to URL. Returns page title and text preview."""
        ok, err = _validate_url(url)
        if not ok:
            return {"success": False, "error": err}

        async def _do():
            page = await self._ensure_page()
            try:
                await page.goto(
                    url, wait_until=wait_until, timeout=timeout
                )
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

            title = await page.title()
            text = await page.inner_text('body')
            text = text[:2000] if text else ""

            return {
                "success": True,
                "url": page.url,
                "title": title,
                "text_preview": text,
            }

        result = self._run(_do())

        # Retry without www if we hit a local gateway
        if (result.get("success") and
                self._looks_like_gateway(result.get("title", ""), result.get("text_preview", ""))):
            parsed = urlparse(url)
            if parsed.hostname and parsed.hostname.startswith("www."):
                no_www = url.replace(f"://{parsed.hostname}", f"://{parsed.hostname[4:]}", 1)
                print(f"  ⚠️ Gateway algılandı, www olmadan deneniyor: {no_www}")
                result = self.open(no_www, wait_until=wait_until, timeout=timeout)

        return result

    def click(self, selector, timeout=5000):
        """Click an element."""
        async def _do():
            page = await self._ensure_page()
            try:
                await page.click(selector, timeout=timeout)
                await page.wait_for_timeout(500)
                return {"success": True, "clicked": selector}
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

        return self._run(_do())

    def type_text(self, selector, text, timeout=5000):
        """Type text into an input field."""
        async def _do():
            page = await self._ensure_page()
            try:
                await page.fill(selector, text, timeout=timeout)
                return {"success": True, "typed": text[:50]}
            except Exception as e:
                # Fallback: click then type
                try:
                    await page.click(selector, timeout=timeout)
                    await page.keyboard.type(text, delay=50)
                    return {"success": True, "typed": text[:50]}
                except Exception as e2:
                    return {"success": False, "error": str(e2)[:200]}

        return self._run(_do())

    def get_text(self, selector=None, timeout=5000):
        """Extract text from page or specific element."""
        async def _do():
            page = await self._ensure_page()
            try:
                if selector:
                    el = await page.wait_for_selector(
                        selector, timeout=timeout
                    )
                    text = await el.inner_text() if el else ""
                else:
                    text = await page.inner_text('body')

                return {
                    "success": True,
                    "text": text[:5000],
                    "length": len(text),
                }
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

        return self._run(_do())

    def screenshot(self, path=None, full_page=False):
        """Take a screenshot."""
        async def _do():
            page = await self._ensure_page()
            if path is None:
                p = os.path.expanduser("~/.config/cont/screenshot.png")
            else:
                p = path

            os.makedirs(os.path.dirname(p), exist_ok=True)

            try:
                await page.screenshot(path=p, full_page=full_page)
                return {
                    "success": True,
                    "path": p,
                    "url": page.url,
                }
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

        return self._run(_do())

    def evaluate(self, js_code):
        """Run JavaScript on the page."""
        async def _do():
            page = await self._ensure_page()
            try:
                result = await page.evaluate(js_code)
                return {"success": True, "result": result}
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

        return self._run(_do())

    def get_links(self, selector="a"):
        """Get all links on the page."""
        async def _do():
            page = await self._ensure_page()
            links = await page.evaluate(f"""
                Array.from(document.querySelectorAll('{selector}'))
                .map(a => ({{
                    text: a.textContent.trim().substring(0, 100),
                    href: a.href
                }}))
                .filter(l => l.href && l.text)
            """)
            return {
                "success": True,
                "links": links[:50],
                "count": len(links),
            }

        return self._run(_do())

    def fill_form(self, fields):
        """Fill multiple form fields. fields = {selector: value}."""
        async def _do():
            page = await self._ensure_page()
            results = []
            for selector, value in fields.items():
                try:
                    await page.fill(selector, value, timeout=3000)
                    results.append({"selector": selector, "success": True})
                except Exception:
                    results.append(
                        {"selector": selector, "success": False}
                    )
            return {
                "success": all(r["success"] for r in results),
                "fields": results,
            }

        return self._run(_do())

    def wait_for(self, selector, timeout=10000):
        """Wait for an element to appear."""
        async def _do():
            page = await self._ensure_page()
            try:
                el = await page.wait_for_selector(
                    selector, timeout=timeout
                )
                text = await el.inner_text() if el else ""
                return {"success": True, "text": text[:500]}
            except Exception as e:
                return {"success": False, "error": str(e)[:200]}

        return self._run(_do())

    def close(self):
        """Close browser."""
        async def _do():
            if self._browser:
                await self._browser.close()
                self._browser = None
                self._page = None
                self._context = None
            if self._pw:
                await self._pw.stop()
                self._pw = None

        try:
            self._run(_do())
        except Exception:
            pass
        Browser._instance = None
        Browser._browser = None
        Browser._page = None
        Browser._context = None
        Browser._pw = None
        return {"success": True}


# === TOOL WRAPPERS (for Cont's tool system) ===

def browser_open(url: str, **kwargs) -> str:
    """Open a URL in the browser."""
    result = Browser.get_instance().open(url, **kwargs)
    if result["success"]:
        return (
            f"Sayfa açıldı: {result['title']}\n"
            f"URL: {result['url']}\n"
            f"İçerik:\n{result['text_preview']}"
        )
    return f"Hata: {result['error']}"


def browser_click(selector: str) -> str:
    """Click an element on the page."""
    result = Browser.get_instance().click(selector)
    if result["success"]:
        return f"Tıklandı: {selector}"
    return f"Hata: {result['error']}"


def browser_type(selector: str, text: str) -> str:
    """Type text into an input field."""
    result = Browser.get_instance().type_text(selector, text)
    if result["success"]:
        return f"Yazıldı: {result['typed']}"
    return f"Hata: {result['error']}"


def browser_text(selector: str = None) -> str:
    """Get text from page or element."""
    result = Browser.get_instance().get_text(selector)
    if result["success"]:
        return result["text"]
    return f"Hata: {result['error']}"


def browser_screenshot(path: str = None) -> str:
    """Take a screenshot."""
    result = Browser.get_instance().screenshot(path)
    if result["success"]:
        return f"Screenshot kaydedildi: {result['path']}"
    return f"Hata: {result['error']}"


def browser_links() -> str:
    """Get all links on the page."""
    result = Browser.get_instance().get_links()
    if result["success"]:
        lines = [
            f"  {l['text']}: {l['href']}"
            for l in result["links"][:20]
        ]
        return f"Linkler ({result['count']}):\n" + "\n".join(lines)
    return f"Hata: {result['error']}"


def browser_close() -> str:
    """Close the browser."""
    Browser.get_instance().close()
    return "Browser kapatıldı."
