# core/file_context.py
"""File context injection — pre-read files mentioned in user input."""

import re
from pathlib import Path

from core.utils import debug as _debug


_FILE_CONTEXT_MAX_BYTES = 500_000  # 500KB per file max

_FILE_CONTEXT_PATTERNS = [
    # Relative paths: tools/foo.txt, ./foo.txt, data/bar.json
    r'(?:^|\s)(\./[\w./-]+)',
    r'(?:^|\s)(tools/[\w./-]+)',
    r'(?:^|\s)(data/[\w./-]+)',
    r'(?:^|\s)(tests/[\w./-]+)',
    r'(?:^|\s)(logs/[\w./-]+)',
    r'(?:^|\s)(external/[\w./-]+)',
    # Generic relative path pattern (word/word.ext or word/word/word.ext)
    r'(?:^|\s)((?:[a-zA-Z_][\w-]*/)+[\w.-]+\.[\w]+)',
    # Absolute paths (must exist and be under REPO_ROOT for safety)
    r'(?:^|\s)(/[\w./-]+\.[\w]+)',
]


def read_text_file(path: str, repo_root: Path = None) -> dict:
    """
    Read a text file with full error handling.
    Returns: {"ok": bool, "content": str|None, "error": str|None, "bytes": int, "encoding": str, "path": str}
    """
    result = {"ok": False, "content": None, "error": None, "bytes": 0, "encoding": "utf-8", "path": path}

    try:
        # Resolve path — try multiple locations
        if path.startswith("/"):
            p = Path(path).resolve()
            # Security: block system directories but allow ~/projects/ etc.
            forbidden = ["/etc", "/usr", "/bin", "/sbin", "/boot", "/root"]
            for f in forbidden:
                if str(p).startswith(f):
                    result["error"] = f"Access denied: {path}"
                    result["hint"] = "System directories are not accessible"
                    return result
        else:
            base = repo_root or Path.cwd()
            p = (base / path).resolve()

        result["path"] = str(p)

        if not p.exists():
            # Try alternative paths before failing
            candidates = [
                Path(path).expanduser(),
                Path.home() / path,
                Path.home() / "projects" / path,
            ]
            found = None
            for c in candidates:
                try:
                    c = c.resolve()
                    if c.exists() and c.is_file():
                        found = c
                        break
                except Exception:
                    continue
            if found is None:
                result["error"] = f"File not found: {path}"
                result["hint"] = "Check the file path and ensure it exists"
                return result
            p = found
            result["path"] = str(p)

        if not p.is_file():
            result["error"] = f"Not a file: {path}"
            result["hint"] = "Path points to a directory, not a file"
            return result

        # Check size
        size = p.stat().st_size
        result["bytes"] = size

        if size > _FILE_CONTEXT_MAX_BYTES:
            result["error"] = f"File too large: {size} bytes (max: {_FILE_CONTEXT_MAX_BYTES})"
            result["hint"] = "Consider using a smaller file or reading specific sections"
            return result

        # Read content
        try:
            content = p.read_text(encoding="utf-8")
            result["encoding"] = "utf-8"
        except UnicodeDecodeError:
            # Try latin-1 as fallback
            try:
                content = p.read_text(encoding="latin-1")
                result["encoding"] = "latin-1"
            except Exception as e:
                result["error"] = f"Encoding error: {e}"
                result["hint"] = "File may be binary or use unsupported encoding"
                return result

        result["ok"] = True
        result["content"] = content
        return result

    except PermissionError:
        result["error"] = f"Permission denied: {path}"
        result["hint"] = "Check file permissions"
        return result
    except Exception as e:
        result["error"] = f"Read error: {e}"
        return result


def extract_file_paths(text: str) -> list:
    """
    Extract potential file paths from user input text.
    Returns list of unique path strings found.
    """
    paths = set()
    for pattern in _FILE_CONTEXT_PATTERNS:
        for match in re.finditer(pattern, text):
            path = match.group(1).strip()
            # Skip common false positives
            if path in (".", "..", "/", "./", "../"):
                continue
            # Skip URLs
            if "://" in path or path.startswith("http"):
                continue
            # Skip if looks like a command flag
            if path.startswith("-"):
                continue
            paths.add(path)
    return sorted(paths)


def resolve_file_context(task: str, repo_root: Path = None) -> tuple:
    """
    Detect file paths in task, read them, and build augmented context.
    Returns: (augmented_task: str, skipped_paths: list[str], loaded_count: int)

    Best-effort: reads what it can, silently skips what it can't.
    Never blocks the task — the model can use read_file tool for failures.
    """
    paths = extract_file_paths(task)
    if not paths:
        return task, [], 0

    file_contexts = []
    skipped = []
    total_chars = 0
    MAX_CONTEXT_CHARS = 3000  # ~1000 tokens (Turkish), leaves room for system prompt + response

    for path in paths:
        if total_chars >= MAX_CONTEXT_CHARS:
            skipped.append(path)
            _debug(f"File context skipped (budget full): {path}")
            continue
        result = read_text_file(path, repo_root=repo_root)
        if result["ok"]:
            content = result["content"]
            remaining = MAX_CONTEXT_CHARS - total_chars
            if len(content) > remaining:
                content = content[:remaining] + "\n... (bağlam bütçesi nedeniyle kırpıldı)"
            file_contexts.append({
                "path": path,
                "resolved": result["path"],
                "content": content,
                "bytes": result["bytes"],
                "encoding": result["encoding"]
            })
            total_chars += len(content)
            _debug(f"File context loaded: {path} ({result['bytes']} bytes, context: {total_chars}/{MAX_CONTEXT_CHARS})")
        else:
            # Skip silently — let the model handle it with read_file tool
            skipped.append(path)
            _debug(f"File context skipped: {path} - {result['error']}")

    # Build augmented task with whatever files we could read
    if file_contexts:
        context_blocks = []
        for fc in file_contexts:
            block = f"""FILE_CONTEXT_BEGIN path={fc['path']} bytes={fc['bytes']} encoding={fc['encoding']}
{fc['content']}
FILE_CONTEXT_END"""
            context_blocks.append(block)

        augmented = "\n\n".join(context_blocks) + "\n\n---\n\n" + task
        return augmented, skipped, len(file_contexts)

    return task, skipped, 0
