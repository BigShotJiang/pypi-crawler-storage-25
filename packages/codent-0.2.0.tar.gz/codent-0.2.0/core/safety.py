# core/safety.py
"""
Tiered security system for Cont.

4-tier permission model:
  TIER_0 (always allowed): read-only tools
  TIER_1 (safe zones): write tools inside repo root
  TIER_2 (require approval): destructive shell, web, memory delete
  TIER_3 (always blocked): dangerous patterns (rm -rf /, sudo, etc.)

Session memory: once user approves a TIER_2 tool, it stays approved.
RepeatGuard: blocks repeated destructive calls (3x in 60s).
Audit log: SQLite table for all security events.
"""

import hashlib
import json
import re
import shutil
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Optional


# ── Tier enum ──

class SecurityTier(IntEnum):
    ALWAYS_ALLOWED = 0
    SAFE_ZONES = 1
    REQUIRE_APPROVAL = 2
    ALWAYS_BLOCKED = 3


# ── Tool classification sets ──
# Duplicated from cont.py to avoid circular imports.

TIER_0_ALWAYS_ALLOWED = {
    "read_file", "list_dir", "search_files", "find_path", "system_search",
    "where_am_i", "recall", "list_memories", "capabilities_report",
    "list_automations", "navigate",
    # Web search is read-only
    "web_search",
    # Browser read-only tools
    "browser_text", "browser_links", "browser_close",
}

TIER_1_SAFE_ZONES = {
    "write_file", "apply_patch", "open_file", "open_in_explorer",
    "open_in_browser", "create_recipe", "learn_word", "remember",
    "run_automation", "toggle_automation", "emit_event",
    "suggest_improvement", "report_failure",
    # Web fetch has built-in SSRF protection
    "web_fetch",
    # Browser interactive tools (have built-in URL validation)
    "browser_open", "browser_click", "browser_type", "browser_screenshot",
    "browser_agent",
    # OCR — reads image files, no side effects
    "ocr",
}

TIER_2_REQUIRE_APPROVAL = {
    "forget", "repo_fetch",
}

# run_shell is classified dynamically based on the command content.

# ── Shell command patterns (duplicated from cont.py) ──

DANGEROUS_PATTERNS = [
    "rm -rf /", "rm -rf ~", "rm -rf $HOME",
    "rm -r /", "rm -r ~", "rm -r $HOME",
    "rm --recursive", "find / -delete", "find . -delete",
    "mkfs", "dd if=", "shutdown", "reboot", "poweroff",
    "sudo ", ":(){", "fork bomb", "chmod -R 777 /",
    "> /dev/sd", "mv /* /dev/null",
    "wget|sh", "curl|sh", "wget|bash", "curl|bash",
    "shred ", "wipefs",
]

SAFE_READ_COMMANDS = [
    "ls", "cat", "head", "tail", "grep", "rg", "wc", "file",
    "stat", "du", "df", "which", "whereis", "type", "echo", "pwd",
    "tree", "diff", "sort", "uniq", "cut", "tr",
    "py_compile",
    # NOTE: "find" moved to dynamic check (_classify_shell_command) — find -exec bypass
    # NOTE: "less"/"more" removed — interactive shell escape via !command
]

# python -c body inspection: dangerous stdlib modules that can destroy data
_PYTHON_C_DANGEROUS = {
    "subprocess", "shutil", "os.system", "os.remove", "os.rmdir",
    "os.unlink", "__import__", "eval(", "exec(",
    # v4: file/network/ffi access
    "open(", "ctypes", "socket", "requests", "urllib",
    "pathlib", "glob",
}

# Piped execution: curl/wget output piped to shell interpreter (with optional path prefix)
_PIPE_DANGEROUS_RX = re.compile(
    r"(curl|wget)\b.*\|\s*"
    r"(?:/?(?:usr/)?(?:local/)?(?:s?bin/)?)?"
    r"(bash|sh|zsh|python[23]?|perl|ruby)\b",
    re.IGNORECASE,
)

# Command substitution: $(...) or `...` — arbitrary execution vector
_CMD_SUBST_RX = re.compile(r"\$\(|`[^`]+`")

# Environment variable prefix: VAR=val command — can bypass startswith checks
_ENV_PREFIX_RX = re.compile(r"^(?:\w+=\S+\s+)+")

DESTRUCTIVE_SHELL_PATTERNS = [
    r"\brm\s+",
    r"\brm\s+-rf?\s+",
    r"\brmdir\b",
    r"\bunlink\b",
    r"\bmv\s+",
    r"\bmkdir\b",
    r"\bcp\s+",
    r">",
    r"\bsed\s+-i",
    r"\bchmod\b",
    r"\bchown\b",
    r"\bgit\s+(push|reset|checkout|clean)",
    r"\bpip\s+install",
    r"\bnpm\s+install",
]


# ── Classification ──

def _classify_shell_command(cmd: str) -> SecurityTier:
    """Classify a shell command into a security tier."""
    cmd_lower = cmd.strip().lower()

    # TIER_3: dangerous patterns (literal substring match)
    for pattern in DANGEROUS_PATTERNS:
        if pattern.lower() in cmd_lower:
            return SecurityTier.ALWAYS_BLOCKED

    # TIER_3: piped execution (curl/wget | bash/sh/python) — with full path support
    if _PIPE_DANGEROUS_RX.search(cmd_lower):
        return SecurityTier.ALWAYS_BLOCKED

    # TIER_2: command substitution $(...) or `...` — needs user approval
    if _CMD_SUBST_RX.search(cmd_lower):
        return SecurityTier.REQUIRE_APPROVAL

    # Strip env variable prefixes (VAR=val) before further checks
    cmd_for_check = _ENV_PREFIX_RX.sub("", cmd_lower).strip()

    # python -c: inspect body for dangerous modules before allowing
    if cmd_for_check.startswith(("python -c", "python3 -c")):
        if any(d in cmd_lower for d in _PYTHON_C_DANGEROUS):
            return SecurityTier.ALWAYS_BLOCKED
        return SecurityTier.ALWAYS_ALLOWED

    # find: safe only without -exec/-delete/-ok
    if cmd_for_check.startswith("find"):
        if re.search(r"-exec\b|-delete\b|-ok\b", cmd_lower):
            return SecurityTier.ALWAYS_BLOCKED
        return SecurityTier.ALWAYS_ALLOWED

    # less/more: interactive shell escape risk — require approval
    if cmd_for_check.startswith(("less ", "more ")):
        return SecurityTier.REQUIRE_APPROVAL

    # TIER_0: safe read commands
    for safe in SAFE_READ_COMMANDS:
        if cmd_for_check.startswith(safe):
            return SecurityTier.ALWAYS_ALLOWED

    # TIER_2: destructive shell patterns
    for pattern in DESTRUCTIVE_SHELL_PATTERNS:
        if re.search(pattern, cmd_lower):
            return SecurityTier.REQUIRE_APPROVAL

    # Non-destructive, non-read shell → TIER_1 (safe zone)
    return SecurityTier.SAFE_ZONES


def classify_tool(tool_name: str, args: dict) -> SecurityTier:
    """Classify a tool call into a security tier."""
    if tool_name in TIER_0_ALWAYS_ALLOWED:
        return SecurityTier.ALWAYS_ALLOWED

    if tool_name == "run_shell":
        return _classify_shell_command(args.get("cmd", ""))

    if tool_name in TIER_1_SAFE_ZONES:
        return SecurityTier.SAFE_ZONES

    if tool_name in TIER_2_REQUIRE_APPROVAL:
        return SecurityTier.REQUIRE_APPROVAL

    # Unknown tools default to TIER_2
    return SecurityTier.REQUIRE_APPROVAL


# ── Permission result ──

@dataclass
class PermissionResult:
    allowed: bool
    tier: SecurityTier
    reason: str      # "allowed", "safe_zone", "session_approved", "needs_approval", "blocked", "repeat_blocked"
    details: dict = field(default_factory=dict)


# ── Session permissions ──

class SessionPermissions:
    """Tracks per-session tool approvals so user isn't asked repeatedly."""

    def __init__(self):
        self.approved_tools: set = set()
        self.approved_commands: set = set()

    def approve_tool(self, tool_name: str):
        self.approved_tools.add(tool_name)

    def approve_command(self, cmd_prefix: str):
        self.approved_commands.add(cmd_prefix)

    def is_approved(self, tool_name: str, args: dict) -> bool:
        if tool_name in self.approved_tools:
            return True
        if tool_name == "run_shell":
            cmd = args.get("cmd", "").strip()
            for prefix in self.approved_commands:
                if cmd.startswith(prefix):
                    return True
        return False


# ── Repeat guard ──

class RepeatGuard:
    """Detects repeated destructive tool calls (same tool + same args)."""

    def __init__(self, max_repeats: int = 3, window_seconds: int = 60):
        self.max_repeats = max_repeats
        self.window = window_seconds
        self.history: list = []  # (tool, args_hash, timestamp)

    def check(self, tool_name: str, args: dict) -> bool:
        """Returns True if this call should be BLOCKED as a repeat."""
        now = time.time()
        args_hash = hashlib.md5(
            json.dumps(args, sort_keys=True, default=str).encode()
        ).hexdigest()

        # Prune old entries
        self.history = [
            (t, h, ts) for t, h, ts in self.history
            if now - ts < self.window
        ]

        count = sum(
            1 for t, h, _ in self.history
            if t == tool_name and h == args_hash
        )

        self.history.append((tool_name, args_hash, now))
        return count >= self.max_repeats

    def reset(self):
        self.history.clear()


# ── Backup ──

def backup_before_write(path: str, backup_dir: Path) -> Optional[str]:
    """
    Create a backup of a file before modifying it.
    Also writes a .meta sidecar with original path for --undo.
    Returns backup path or None.
    """
    try:
        source = Path(path)
        if not source.exists() or not source.is_file():
            return None

        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{source.name}.{timestamp}.bak"
        backup_path = backup_dir / backup_name

        shutil.copy2(source, backup_path)

        # Write .meta sidecar for --undo
        meta_path = backup_path.with_suffix(".bak.meta")
        meta_path.write_text(json.dumps({
            "original": str(source.resolve()),
            "backup": str(backup_path),
            "timestamp": timestamp,
        }))

        return str(backup_path)
    except Exception:
        return None


# ── Audit log ──

def init_audit_table(db_path: Path):
    """Create audit_log table if it doesn't exist."""
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                event_type TEXT NOT NULL,
                tool_name TEXT NOT NULL,
                args_json TEXT,
                tier INTEGER NOT NULL,
                result TEXT NOT NULL,
                details_json TEXT,
                session_id TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_log_ts
            ON audit_log(timestamp)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_log_tool
            ON audit_log(tool_name, event_type)
        """)
        conn.commit()
        conn.close()
    except Exception:
        pass  # Audit init must never crash the agent


def _audit_log(db_path: Path, event_type: str, tool_name: str,
               args: dict, tier: int, result: str,
               details: dict = None, session_id: str = None):
    """Write an audit log entry."""
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute(
            "INSERT INTO audit_log "
            "(event_type, tool_name, args_json, tier, result, details_json, session_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (event_type, tool_name,
             json.dumps(args, default=str)[:2000],
             tier, result,
             json.dumps(details or {}, default=str)[:2000],
             session_id)
        )
        conn.commit()
        conn.close()
    except Exception:
        pass  # Audit must never crash the agent


def query_audit_log(db_path: Path, limit: int = 50) -> list:
    """Query recent audit log entries."""
    try:
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute(
            "SELECT timestamp, event_type, tool_name, args_json, tier, result, details_json "
            "FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [
            {"timestamp": r[0], "event_type": r[1], "tool_name": r[2],
             "args": r[3], "tier": r[4], "result": r[5], "details": r[6]}
            for r in rows
        ]
    except Exception:
        return []


# ── Security Manager ──

class SecurityManager:
    """
    Main security coordinator.

    Wraps all tool calls through a 4-tier permission check.
    Manages session approvals, repeat detection, backups, and audit logging.
    """

    def __init__(self, repo_root: Path, db_path: Path,
                 backup_dir: Path, enabled: bool = True):
        self.repo_root = repo_root.resolve()
        self.db_path = db_path
        self.backup_dir = backup_dir
        self.session = SessionPermissions()
        self.repeat_guard = RepeatGuard()
        self.enabled = enabled
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        init_audit_table(db_path)

    def check(self, tool_name: str, args: dict) -> PermissionResult:
        """
        Check if a tool call is allowed.

        Returns PermissionResult with allowed=True/False and reason.
        """
        if not self.enabled:
            return PermissionResult(True, SecurityTier.ALWAYS_ALLOWED, "disabled")

        tier = classify_tool(tool_name, args)

        # RepeatGuard (TIER_1+ only)
        if tier >= SecurityTier.SAFE_ZONES and self.repeat_guard.check(tool_name, args):
            self._audit("repeat_blocked", tool_name, args, tier, "blocked")
            return PermissionResult(
                False, tier, "repeat_blocked",
                {"message": "Same destructive call repeated too many times"}
            )

        # TIER_0: always allowed
        if tier == SecurityTier.ALWAYS_ALLOWED:
            return PermissionResult(True, tier, "allowed")

        # TIER_1: allowed if inside repo root
        if tier == SecurityTier.SAFE_ZONES:
            if self._is_in_safe_zone(tool_name, args):
                return PermissionResult(True, tier, "safe_zone")
            # Outside repo → escalate to TIER_2
            tier = SecurityTier.REQUIRE_APPROVAL

        # TIER_2: check session approval
        if tier == SecurityTier.REQUIRE_APPROVAL:
            if self.session.is_approved(tool_name, args):
                return PermissionResult(True, tier, "session_approved")
            return PermissionResult(
                False, tier, "needs_approval",
                {"tool": tool_name, "args": args}
            )

        # TIER_3: always blocked
        if tier == SecurityTier.ALWAYS_BLOCKED:
            self._audit("tier3_blocked", tool_name, args, tier, "blocked")
            return PermissionResult(
                False, tier, "blocked",
                {"message": "Command matches dangerous pattern"}
            )

        return PermissionResult(False, tier, "unknown")

    def approve(self, tool_name: str, args: dict, remember_session: bool = True):
        """User approved a TIER_2 action."""
        if remember_session:
            self.session.approve_tool(tool_name)
            if tool_name == "run_shell":
                cmd = args.get("cmd", "").strip()
                prefix = cmd.split()[0] if cmd else ""
                if prefix:
                    self.session.approve_command(prefix)
        self._audit("approved", tool_name, args,
                     SecurityTier.REQUIRE_APPROVAL, "user_approved")

    def do_backup(self, path: str) -> Optional[str]:
        """Create a backup and log it."""
        result = backup_before_write(path, self.backup_dir)
        if result:
            self._audit("backup", "backup", {"path": path}, 0, "created",
                        {"backup_path": result})
        return result

    def _is_in_safe_zone(self, tool_name: str, args: dict) -> bool:
        """Check if the target path is inside the repo root."""
        target = args.get("path", "")
        if not target:
            return True  # No path → no file risk
        try:
            resolved = Path(target).expanduser().resolve()
            return str(resolved).startswith(str(self.repo_root))
        except Exception:
            return False

    def _audit(self, event_type, tool_name, args, tier, result, details=None):
        """Write to audit log (never crashes)."""
        _audit_log(self.db_path, event_type, tool_name, args, int(tier),
                   result, details, self.session_id)
