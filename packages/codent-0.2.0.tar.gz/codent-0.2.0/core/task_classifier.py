# core/task_classifier.py
"""Task type classification for adaptive prompting and success tracking."""

import re

TASK_TYPES = {
    "file_read": ["bul", "göster", "oku", "find", "show", "read", "list", "listele",
                   "cat", "bak", "aç", "içeriğini", "nedir", "dosya"],
    "file_write": ["yaz", "oluştur", "düzelt", "create", "write", "fix", "ekle",
                    "add", "modify", "değiştir", "güncelle", "update", "patch"],
    "search": ["ara", "search", "grep", "find in", "tara", "içinde bul",
               "where is", "nerede", "hangi dosya"],
    "explain": ["açıkla", "explain", "what", "how", "why", "ne", "nasıl",
                "neden", "describe", "tanımla", "anlat"],
    "shell": ["çalıştır", "run", "execute", "komutu", "komut", "terminal",
              "shell", "bash", "pip", "npm", "git"],
    "web": ["fetch", "search web", "internet", "url", "http", "download",
            "indir", "web", "site", "browser", "browse", "sayfay", "sayfas",
            "mevzuat", "gov.tr"],
    "memory": ["hatırla", "remember", "recall", "unut", "forget", "hafıza",
               "memory", "anımsa"],
}

# Weighted keywords that strongly signal a type
STRONG_SIGNALS = {
    "file_read": ["read_file", "cat ", "head ", "tail ", "göster", "oku"],
    "file_write": ["write_file", "apply_patch", "yaz", "oluştur", "create"],
    "search": ["grep", "search_files", "ara", "rg "],
    "shell": ["run_shell", "çalıştır", "execute"],
}


def classify_task(task: str) -> str:
    """
    Return task type based on keyword matching.
    Returns the best-matching type or 'general' if no strong match.
    """
    if not task:
        return "general"

    task_lower = task.lower()

    # Check strong signals first (2x weight)
    scores = {}
    for task_type, keywords in STRONG_SIGNALS.items():
        for kw in keywords:
            if kw in task_lower:
                scores[task_type] = scores.get(task_type, 0) + 2

    # Check regular keywords
    for task_type, keywords in TASK_TYPES.items():
        for kw in keywords:
            if kw in task_lower:
                scores[task_type] = scores.get(task_type, 0) + 1

    if not scores:
        return "general"

    return max(scores, key=scores.get)


def is_turkish(task: str) -> bool:
    """Check if task contains Turkish characters or common Turkish words."""
    turkish_chars = set("çğıöşüÇĞİÖŞÜ")
    if any(c in turkish_chars for c in task):
        return True

    turkish_words = [
        "bir", "bu", "ve", "için", "ile", "olan", "var", "yok",
        "mı", "mi", "mu", "mü", "ne", "nasıl", "neden", "nerede",
        "dosya", "klasör", "proje", "kod", "hata", "çalış",
        "bul", "ara", "yaz", "oku", "aç", "kapat", "sil",
        "bana", "benim", "şu", "bu", "onu", "onun",
    ]
    task_lower = task.lower()
    return any(f" {w} " in f" {task_lower} " for w in turkish_words)


def get_task_intent(task: str) -> str:
    """
    Determine high-level intent: 'read', 'write', or 'mixed'.
    Used by write protection and prompt adaptation.
    """
    task_type = classify_task(task)

    read_types = {"file_read", "search", "explain"}
    write_types = {"file_write"}

    if task_type in read_types:
        return "read"
    elif task_type in write_types:
        return "write"
    else:
        return "mixed"
