# core/memory_gate.py
"""Memory-First Action Gate — bypass LLM when memory has actionable facts.

Phase-0 memory results are checked for HIGH-confidence actionable facts
(paths, URLs). If found and user input has an action verb (aç, git),
the gate fires and executes the tool directly — zero LLM calls.

NO hardcoded mappings. Only mechanism. All knowledge from cont's memory.
"""

import re

# Minimum verb set — language grammar, not knowledge
_OPEN_VERBS = {"aç", "açın", "açalım", "açsana", "göster", "gösterin"}
_NAV_VERBS = {"git", "gidin", "gidelim", "gir"}
_BROWSE_VERBS = {"bak", "bakın", "bakalım", "baksana"}
_READ_VERBS = {"oku", "okuyun", "okuyalım"}
_DOWNLOAD_VERBS = {"indir", "indirin", "indirelim"}

# Task verbs — if present alongside nav verbs, gate should NOT fire (multi-step command)
_TASK_VERBS = {
    "bul", "ara", "getir", "listele", "indir", "oku",
    "çek", "tara", "öğren", "yap", "karşılaştır", "analiz",
    "kaydet", "kontrol", "incele", "topla",
}

_STOP_WORDS = {
    # Basic particles/conjunctions
    "bir", "bu", "şu", "ve", "ile", "için", "de", "da",
    "den", "dan", "ne", "nasıl", "nerede", "nereye",
    "mi", "mı", "mu", "mü", "ya", "ki",
    # Container words (grammatical wrappers)
    "klasörünü", "klasörü", "dosyasını", "dosyayı",
    "sitesini", "sitesi", "sayfasını",
    # Pronouns
    "ben", "sen", "benim", "senin", "onun", "bizim", "sizin",
    "onu", "bunu", "şunu", "bana", "sana", "ona",
    # Conjunctions/adverbs
    "var", "yok", "olan", "olarak",
    "her", "tüm", "hep", "daha", "çok",
    "ama", "fakat", "ancak", "ise",
    "gibi", "kadar", "sonra", "önce",
    # Response words
    "lütfen", "tamam", "evet", "hayır",
    # v4: discourse markers
    "çünkü", "zira", "hem", "peki", "acaba",
    "böyle", "şöyle", "hangisi", "hangi",
}

_PATH_RE = re.compile(r"(/[\w/._ -]{3,}|[A-Z]:\\[\w\\._-]{3,})")
_URL_RE = re.compile(r"https?://[\w._/-]+")
_KV_RE = re.compile(r"^(.+?)\s*[=:]\s*(.+)$")  # "key = value" or "key: value"


def try_memory_gate(user_input: str, memories: list[dict]) -> dict | None:
    """Check if Phase-0 memories contain an actionable HIGH fact.

    Returns: {"action": "open_path"|"open_url", "target": str, ...} or None
    """
    if not user_input or not memories:
        return None

    high_mems = [m for m in memories if _is_high(m)]
    if not high_mems:
        return None

    action = _detect_action(user_input)
    if action is None:
        return None

    # Multi-step guard: if input has both nav verb AND task verb, skip gate
    # e.g. "kosgeb sitesine git SSS bul" → gate should NOT fire
    _input_stems = set()
    for w in user_input.lower().split():
        _input_stems.add(w)
        for s in ("mak", "mek", "malı", "meli"):
            if w.endswith(s) and len(w) > len(s) + 1:
                _input_stems.add(w[:-len(s)])
    if _input_stems & _TASK_VERBS:
        return None

    content_words = _extract_content_words(user_input)
    if not content_words:
        return None

    for mem in high_mems:
        content = mem.get("content", "")

        # Overlap check: at least 1 meaningful word must match
        if not _has_meaningful_overlap(content_words, content):
            continue

        # URL match first (URLs contain path-like patterns, check URL before path)
        url_match = _URL_RE.search(content)
        if url_match and action in ("open", "navigate", "browse", "read", "download"):
            return {
                "action": "open_url",
                "target": url_match.group(0).strip(),
                "source_memory": content[:100],
                "gate": "memory_first",
            }

        # Path match — for open/browse/read/download actions
        path_match = _PATH_RE.search(content)
        if path_match and action in ("open", "browse", "read", "download"):
            return {
                "action": "open_path",
                "target": path_match.group(0).strip(),
                "source_memory": content[:100],
                "gate": "memory_first",
            }

    return None


def _has_meaningful_overlap(content_words: set[str], memory_content: str) -> bool:
    """Check overlap between user content words and memory.

    Supports both plain text and key=value / key: value format.
    Returns True only if at least 1 meaningful (non-stopword) word matches.
    """
    content_lower = memory_content.lower()

    # Direct overlap: user words in memory content
    if any(w in content_lower for w in content_words):
        return True

    # Key-value format: check overlap with key part only
    kv_match = _KV_RE.match(memory_content.strip())
    if kv_match:
        key_part = kv_match.group(1).lower().strip()
        key_words = {
            w.strip(".,!?:;\"'()[]")
            for w in key_part.split()
            if len(w.strip(".,!?:;\"'()[]")) >= 3
        }
        if key_words & content_words:
            return True

    return False


def _is_high(mem: dict) -> bool:
    """HIGH = level=HIGH or (importance >= 0.8 and type=fact) or source=user_teach."""
    if mem.get("level") == "HIGH":
        return True
    # memory_store returns "memory_type", accept both keys
    mtype = mem.get("type") or mem.get("memory_type")
    if mem.get("importance", 0) >= 0.8 and mtype == "fact":
        return True
    if mem.get("source") == "user_teach":
        return True
    return False


def _detect_action(user_input: str) -> str | None:
    """Detect Turkish action verb. Returns 'open'|'navigate'|'browse'|'read'|'download'|None."""
    words = set(user_input.lower().split())
    stems = set()
    for w in words:
        stems.add(w)
        # Handle common Turkish suffixes (infinitive, necessity, accusative)
        for s in ("mak", "mek", "malı", "meli",
                   "ını", "ini", "unu", "ünü",
                   "yı", "yi", "yu", "yü",
                   "ı", "i", "u", "ü"):
            if w.endswith(s) and len(w) > len(s) + 1:
                stems.add(w[:-len(s)])
    if stems & _OPEN_VERBS:
        return "open"
    if stems & _NAV_VERBS:
        return "navigate"
    if stems & _BROWSE_VERBS:
        return "browse"
    if stems & _READ_VERBS:
        return "read"
    if stems & _DOWNLOAD_VERBS:
        return "download"
    return None


def _extract_content_words(text: str) -> set[str]:
    """Extract meaningful words from text (remove stop words)."""
    words = set()
    for w in text.lower().split():
        w = w.strip(".,!?:;\"'()[]")
        if len(w) >= 3 and w not in _STOP_WORDS:
            words.add(w)
    return words
