# core/run_logger.py
"""JSONL run logger for task execution traces.

Enhanced with decision tracing for debugging model behavior.
Each log entry has a type that tells you what happened:

  llm_request    — Full prompt sent to model (system + messages)
  llm_response   — Model's response (text + tool_calls)
  tool_call      — Tool invoked with arguments
  tool_result    — Tool returned a result
  decision       — Why a particular path was taken (recipe match, budget, etc.)
  task_reminder  — Task reminder injected after N tool calls
  verification   — Verification result (passed/failed/cancelled)
  phase          — Phase transition (budget phase change)
  warning        — Non-fatal issue (www redirect, limit hit, etc.)
  final          — Final answer + success status + stats
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from core.utils import clean_surrogates


def _sanitize_filename(text: str, max_len: int = 50) -> str:
    """Convert to ASCII-safe filename for log files."""
    tr_map = str.maketrans('çğıöşüÇĞİÖŞÜâîûêôÂÎÛÊÔ', 'cgiosuCGIOSUaiueoAIUEO')
    text = text.translate(tr_map)
    text = text.encode('ascii', 'ignore').decode('ascii')
    text = re.sub(r'[^a-zA-Z0-9_]', '_', text)
    text = re.sub(r'_+', '_', text).strip('_')
    return text[:max_len]


class RunLogger:
    def __init__(self, task_slug: str, log_dir: Path):
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = _sanitize_filename(task_slug)
        self.logfile = log_dir / f"{ts}_{slug}.jsonl"
        self.events = []
        self._tool_count = 0
        self._start_time = datetime.now()

    def log(self, event_type: str, data: Any):
        event = {"type": event_type, "ts": datetime.now().isoformat(), "data": data}
        self.events.append(event)
        with open(self.logfile, "a", encoding="utf-8") as f:
            f.write(clean_surrogates(json.dumps(event, ensure_ascii=False)) + "\n")

    def log_llm_request(self, messages: list):
        # Log only the last 2 messages to save space (full prompt is in first event)
        if len(self.events) == 0:
            self.log("llm_request", {"messages": messages})
        else:
            # Subsequent requests: only log new messages (tail)
            self.log("llm_request", {
                "messages": messages,
                "message_count": len(messages),
                "tool_calls_so_far": self._tool_count,
            })

    def log_llm_response(self, response_content: Any, tool_calls: Any):
        self.log("llm_response", {"content": response_content, "tool_calls": tool_calls})

    def log_tool_call(self, name: str, args: dict):
        self._tool_count += 1
        self.log("tool_call", {
            "name": name,
            "args": args,
            "call_number": self._tool_count,
        })

    def log_tool_result(self, name: str, result: Any, error: Optional[str] = None):
        # Truncate large results for readability
        result_str = str(result) if result else ""
        if len(result_str) > 2000:
            result_str = result_str[:2000] + f"... [truncated, total {len(str(result))} chars]"
        self.log("tool_result", {"name": name, "result": result_str, "error": error})

    def log_decision(self, decision: str, reason: str, details: dict = None):
        """Log WHY a decision was made — recipe match, budget change, etc."""
        self.log("decision", {
            "decision": decision,
            "reason": reason,
            **(details or {}),
        })

    def log_event(self, event_name: str, data: Any = None):
        """Log a named event (memory_gate_fired, memory_gate_skipped, etc.)."""
        self.log(event_name, data or {})

    def log_warning(self, message: str, details: dict = None):
        """Log a non-fatal issue."""
        self.log("warning", {"message": message, **(details or {})})

    def log_final(self, answer: str, success: bool = True, **extra):
        elapsed = (datetime.now() - self._start_time).total_seconds()
        data = {
            "answer": answer,
            "success": success,
            "tool_calls_total": self._tool_count,
            "elapsed_seconds": round(elapsed, 1),
            "event_count": len(self.events),
        }
        data.update(extra)
        self.log("final", data)
