"""
core/app.py - CLI flag handlers extracted from cont.py main()

Contains handle_exit_flags(args) which processes all CLI flags that
end with sys.exit(0).  Returns True if any flag was handled.
"""

import os
import sys
import json
import shutil
import subprocess
import time
from pathlib import Path

# Direct imports from core modules (no circular deps)
from core.utils import CONT_DIR, REPO_ROOT, LOG_DIR, slugify
from core.identity import (
    CONT_SOUL_FILE, _ensure_config_dir, get_cont_home, set_cont_home,
    get_soul, _get_default_soul, get_current_state,
)
from core.memory_store import (
    _db_connect, _memory_db_path, memory_init_db, memory_stats,
    memory_get_autofix_list, memory_enable_autofix, memory_disable_autofix,
    memory_get_last_failed_attempt, memory_map_error, memory_unmap_error,
    memory_get_error_mappings, memory_recent_attempts, memory_prune,
    memory_export, memory_import, memory_solution_stats, memory_add_solution,
    memory_get_best_solution, memory_check_recent_failure, compute_env_id,
    memory_upsert_env_snapshot,
)
from core.env_snapshot import collect_env_snapshot, save_env_snapshot
from core.tools import is_step_safe, _run_shell_capture, run_shell
from core.sticky_config import _get_sticky_model, _get_auto_mode
from core.model_routing import MODEL_TIERS
from core.episodic import run_triage

# Conditional imports (matching cont.py try/except pattern)
try:
    from core.self_improve import SelfImprover
    _SELF_IMPROVE_AVAILABLE = True
except ImportError:
    _SELF_IMPROVE_AVAILABLE = False

try:
    from core.recipes import list_recipes, get_recipe_stats
    from core.prompt_patches import load_file_patches, get_patch_stats
    from core.vocabulary import get_vocabulary_stats, load_vocabulary
    _LEARNING_AVAILABLE = True
except ImportError:
    _LEARNING_AVAILABLE = False

try:
    from core.automations import load_automations, AutomationRunner
    _AUTOMATION_AVAILABLE = True
except ImportError:
    _AUTOMATION_AVAILABLE = False

try:
    from core.escalation import get_escalation
    _ESCALATION_AVAILABLE = True
except ImportError:
    _ESCALATION_AVAILABLE = False

try:
    from core.safety import query_audit_log
    _SAFETY_AVAILABLE = True
except ImportError:
    _SAFETY_AVAILABLE = False

# ---------------------------------------------------------------------------
# Module-level state (set by init_app)
# ---------------------------------------------------------------------------
_console = None
_debug_fn = None
_base_url = None
_self_improve_enabled = False
_learning_enabled = False
_automation_enabled = False
_escalation_enabled = False
_model_override_getter = None
_resolve_model_fn = None
_determine_endpoint_fn = None
_list_available_models_fn = None
_run_task_fn = None

_cont_dir = CONT_DIR
_repo_root = REPO_ROOT


def init_app(*, console, debug_fn, base_url,
             self_improve_enabled=False, learning_enabled=False,
             automation_enabled=False, escalation_enabled=False,
             model_override_getter=None,
             resolve_model_fn=None, determine_endpoint_fn=None,
             list_available_models_fn=None, run_task_fn=None):
    """Inject cont.py-specific dependencies.  Call once before handle_exit_flags."""
    global _console, _debug_fn, _base_url
    global _self_improve_enabled, _learning_enabled
    global _automation_enabled, _escalation_enabled
    global _model_override_getter
    global _resolve_model_fn, _determine_endpoint_fn
    global _list_available_models_fn, _run_task_fn

    _console = console
    _debug_fn = debug_fn
    _base_url = base_url
    _self_improve_enabled = self_improve_enabled
    _learning_enabled = learning_enabled
    _automation_enabled = automation_enabled
    _escalation_enabled = escalation_enabled
    _model_override_getter = model_override_getter
    _resolve_model_fn = resolve_model_fn
    _determine_endpoint_fn = determine_endpoint_fn
    _list_available_models_fn = list_available_models_fn
    _run_task_fn = run_task_fn


def handle_exit_flags(args) -> bool:
    """Handle ALL CLI flags that end with sys.exit(0).

    Returns True if a flag was handled (and sys.exit was called — so this
    never actually returns True; it either exits or returns False).
    """

    # Handle --set-home
    if args.set_home:
        path = Path(args.set_home).expanduser().resolve()
        if path.exists():
            set_cont_home(path)
        else:
            _console.print(f"[red]Error: Path does not exist: {path}[/red]")
            sys.exit(1)
        if not args.task:
            sys.exit(0)

    # Handle --show-home
    if args.show_home:
        home = get_cont_home()
        _console.print(f"[green]Cont home:[/green] {home}")
        sys.exit(0)

    # Handle --show-soul
    if args.show_soul:
        soul = get_soul()
        _console.print("[bold]SOUL.md:[/bold]")
        _console.print(soul)
        sys.exit(0)

    # Handle --show-state
    if args.show_state:
        state = get_current_state()
        if state:
            _console.print("[bold]Current State:[/bold]")
            _console.print(json.dumps(state, indent=2, default=str))
        else:
            _console.print("[yellow]No state file found. Watcher may not be running.[/yellow]")
        sys.exit(0)

    # Handle --edit-soul
    if args.edit_soul:
        _ensure_config_dir()
        if not CONT_SOUL_FILE.exists():
            CONT_SOUL_FILE.write_text(_get_default_soul())

        # Try to open in editor
        editor = os.environ.get("EDITOR", "nano")
        try:
            subprocess.run([editor, str(CONT_SOUL_FILE)])
        except Exception:
            _console.print(f"[yellow]Could not open editor. Edit manually:[/yellow]")
            _console.print(f"  {CONT_SOUL_FILE}")
        sys.exit(0)

    # Handle --watcher
    if args.watcher:
        watcher_script = Path(__file__).parent.parent / "cont_watcher.py"

        if not watcher_script.exists():
            _console.print(f"[red]Watcher script not found: {watcher_script}[/red]")
            sys.exit(1)

        if args.watcher == "start":
            _console.print("[cyan]Starting context watcher...[/cyan]")
            subprocess.Popen(
                [sys.executable, str(watcher_script), "start"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            time.sleep(1)
            # Check if started
            pid_file = Path.home() / ".config" / "cont" / "watcher" / "cont_watcher.pid"
            if pid_file.exists():
                pid = pid_file.read_text().strip()
                _console.print(f"[green]Watcher started (PID: {pid})[/green]")
            else:
                _console.print("[yellow]Watcher may have failed to start. Check logs.[/yellow]")

        elif args.watcher == "stop":
            subprocess.run([sys.executable, str(watcher_script), "stop"])

        elif args.watcher == "status":
            subprocess.run([sys.executable, str(watcher_script), "status"])

        sys.exit(0)

    # Handle --self-report
    if args.self_report:
        memory_init_db()
        if _self_improve_enabled:
            improver = SelfImprover(_db_connect, memory_init_db)
            report = improver.get_self_report()
            _console.print("[bold]Self-Improvement Report[/bold]")
            _console.print(f"Period: {report.get('period', 'N/A')}")
            _console.print(f"Total tasks: {report.get('total_tasks', 0)}")
            _console.print(f"Overall success rate: {report.get('overall_success_rate', 'N/A')}")

            by_type = report.get("by_type", [])
            if by_type:
                _console.print("\n[bold]By Task Type:[/bold]")
                for t in by_type:
                    _console.print(f"  {t['type']:15s} {t['rate']:>5s} ({t['successes']}/{t['total']})")

            top_failures = report.get("top_failures", [])
            if top_failures:
                _console.print("\n[bold]Top Failures:[/bold]")
                for f in top_failures:
                    _console.print(f"  [{f['count']}x] {f['reason'][:60]}")

            patches = report.get("active_patches", [])
            if patches:
                _console.print(f"\n[bold]Active Patches:[/bold] {len(patches)}")
                for p in patches:
                    _console.print(f"  [{p['type']}] {p['patch'][:60]}")
        else:
            _console.print("[yellow]Self-improvement modules not available.[/yellow]")
        sys.exit(0)

    # Handle --self-improve
    if args.self_improve:
        memory_init_db()
        if _self_improve_enabled:
            improver = SelfImprover(_db_connect, memory_init_db)
            suggestions = improver.suggest_improvements()
            if suggestions:
                _console.print(f"[bold]Found {len(suggestions)} improvement suggestion(s):[/bold]")
                for i, s in enumerate(suggestions, 1):
                    _console.print(f"\n  {i}. [{s['task_type']}] Pattern: {s['pattern']} ({s['count']}x)")
                    _console.print(f"     Patch: {s['suggested_patch'][:80]}")
                _console.print("\n[cyan]Run --self-apply to apply these patches.[/cyan]")
            else:
                _console.print("[green]No improvement suggestions (not enough failure data or patches already applied).[/green]")
        else:
            _console.print("[yellow]Self-improvement modules not available.[/yellow]")
        sys.exit(0)

    # Handle --self-apply
    if args.self_apply:
        memory_init_db()
        if _self_improve_enabled:
            improver = SelfImprover(_db_connect, memory_init_db)
            suggestions = improver.suggest_improvements()
            applied = 0
            for s in suggestions:
                created = improver.auto_create_patch(s["pattern"], s["task_type"])
                if created:
                    applied += 1
                    _console.print(f"[green]Applied patch for [{s['task_type']}]: {s['suggested_patch'][:60]}[/green]")
            if applied:
                _console.print(f"\n[bold green]{applied} patch(es) applied.[/bold green]")
            else:
                _console.print("[yellow]No new patches to apply.[/yellow]")
        else:
            _console.print("[yellow]Self-improvement modules not available.[/yellow]")
        sys.exit(0)

    # Handle --self-reset
    if args.self_reset:
        memory_init_db()
        if _self_improve_enabled:
            improver = SelfImprover(_db_connect, memory_init_db)
            if improver.reset_learning():
                _console.print("[green]Self-improvement data reset. Fresh start.[/green]")
            else:
                _console.print("[red]Failed to reset self-improvement data.[/red]")
        else:
            _console.print("[yellow]Self-improvement modules not available.[/yellow]")
        sys.exit(0)

    # Handle --self-improve-status
    if args.self_improve_status:
        memory_init_db()
        try:
            conn = _db_connect()
            rows = conn.execute("""
                SELECT issue_type, COUNT(*) as cnt,
                       SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) as successes
                FROM self_improve_log
                GROUP BY issue_type
                ORDER BY cnt DESC
            """).fetchall()
            conn.close()

            if rows:
                total = sum(r[1] for r in rows)
                total_success = sum(r[2] for r in rows)
                _console.print(f"[bold]Self-Improvement Loop Stats:[/bold]")
                _console.print(f"  Total attempts: {total}")
                _console.print(f"  Successful: {total_success}")
                _console.print(f"  Success rate: {total_success/total:.0%}" if total > 0 else "  N/A")
                _console.print(f"\n[bold]By Issue Type:[/bold]")
                for r in rows:
                    rate = f"{r[2]/r[1]:.0%}" if r[1] > 0 else "N/A"
                    _console.print(f"  {r[0]:20s} {rate:>5s} ({r[2]}/{r[1]})")
            else:
                _console.print("[yellow]No self-improvement loop history yet.[/yellow]")
        except Exception as e:
            _console.print(f"[red]Error: {e}[/red]")
        sys.exit(0)

    # Handle --triage
    if args.triage is not None:
        report = run_triage(n=args.triage, log_dir=str(_repo_root / "logs" / "cont_runs"), verbose=True)
        _console.print(report)
        sys.exit(0)

    # Handle --self-improve-log
    if args.self_improve_log:
        memory_init_db()
        try:
            conn = _db_connect()
            rows = conn.execute("""
                SELECT timestamp, issue_type, task_text, fix_type, success, details_json
                FROM self_improve_log
                ORDER BY timestamp DESC
                LIMIT 50
            """).fetchall()
            conn.close()

            if rows:
                _console.print(f"[bold]Self-Improvement Log (last {len(rows)} entries):[/bold]")
                for r in rows:
                    status = "[green]\u2705[/green]" if r[4] else "[red]\u274c[/red]"
                    ts = r[0][:16] if r[0] else "?"
                    task_short = (r[2] or "")[:50]
                    _console.print(f"  {status} {ts} [{r[1]}] {r[3] or '-'}: {task_short}")
            else:
                _console.print("[yellow]No self-improvement loop log entries yet.[/yellow]")
        except Exception as e:
            _console.print(f"[red]Error: {e}[/red]")
        sys.exit(0)

    # Handle --show-recipes
    if args.show_recipes:
        if _learning_enabled:
            recipes = list_recipes()
            if recipes:
                _console.print(f"[bold]Recipes ({len(recipes)}):[/bold]")
                for r in recipes:
                    rid = r.get("id", "?")
                    desc = r.get("description", "")
                    ok = r.get("success_count", 0)
                    fail = r.get("failure_count", 0)
                    src = r.get("source", "?")
                    _console.print(f"  {rid}: {desc} (ok:{ok} fail:{fail}) [{src}]")

                # Show stats
                stats = get_recipe_stats()
                if stats:
                    _console.print("\n[bold]Recipe Stats:[/bold]")
                    for s in stats:
                        _console.print(f"  {s['name']:20s} {s['rate']:>5s} ({s['successes']}/{s['total']})")
            else:
                _console.print("[yellow]No recipes found.[/yellow]")
        else:
            _console.print("[yellow]Learning system not available.[/yellow]")
        sys.exit(0)

    # Handle --show-patches
    if args.show_patches:
        if _learning_enabled:
            patches = load_file_patches()
            if patches:
                _console.print(f"[bold]File-Based Patches ({len(patches)}):[/bold]")
                for p in patches:
                    pid = p.get("id", "?")
                    active = "active" if p.get("active", True) else "inactive"
                    priority = p.get("priority", 0)
                    text = p.get("patch_text", "")[:80]
                    triggers = ", ".join(p.get("trigger_patterns", [])[:5])
                    _console.print(f"  [{pid}] priority={priority} [{active}]")
                    _console.print(f"    Triggers: {triggers}")
                    _console.print(f"    Rule: {text}")

                # Show stats if available
                memory_init_db()
                stats = get_patch_stats(_db_connect, memory_init_db)
                if stats:
                    _console.print("\n[bold]Patch Stats:[/bold]")
                    for s in stats:
                        _console.print(f"  {s['id']:20s} {s['rate']:>5s} ({s['successes']}/{s['total']})")
            else:
                _console.print("[yellow]No file-based patches found.[/yellow]")
        else:
            _console.print("[yellow]Learning system not available.[/yellow]")
        sys.exit(0)

    # Handle --show-vocabulary
    if args.show_vocabulary:
        if _learning_enabled:
            stats = get_vocabulary_stats()
            if stats.get("total", 0) > 0:
                _console.print("[bold]Vocabulary Stats:[/bold]")
                _console.print(f"  Commands:      {stats['commands']}")
                _console.print(f"  Context words: {stats['context_words']}")
                _console.print(f"  Patterns:      {stats['patterns']}")
                _console.print(f"  Total entries: {stats['total']}")
                _console.print(f"  Last updated:  {stats.get('learned_at', 'unknown')}")

                # Show some sample commands
                vocab = load_vocabulary()
                commands = vocab.get("commands", {})
                if commands:
                    _console.print("\n[bold]Sample Commands (TR→EN):[/bold]")
                    for word, info in list(commands.items())[:15]:
                        en = info.get("en", "?")
                        intent = info.get("intent", "")
                        example = info.get("example", "")
                        line = f"  {word:15s} → {en:15s} [{intent}]"
                        if example:
                            line += f"  ({example})"
                        _console.print(line)
                    if len(commands) > 15:
                        _console.print(f"  ... and {len(commands) - 15} more")
            else:
                _console.print("[yellow]No vocabulary found.[/yellow]")
        else:
            _console.print("[yellow]Learning system not available.[/yellow]")
        sys.exit(0)

    # Handle --automations
    if args.automations:
        if _automation_enabled:
            autos = load_automations()
            if autos:
                _console.print("[bold]Automations:[/bold]")
                for a in autos:
                    name = a.get("name", "?")
                    desc = a.get("description", "")
                    enabled = "\u2713 enabled" if a.get("enabled", True) else "\u2717 disabled"
                    trigger = a.get("trigger", {}).get("event", "?")
                    actions = len(a.get("actions", []))
                    _console.print(f"\n  [{enabled}] {name}")
                    _console.print(f"    {desc}")
                    _console.print(f"    Trigger: {trigger} | Actions: {actions}")
            else:
                _console.print("[yellow]No automations found.[/yellow]")
        else:
            _console.print("[yellow]Automation system not available.[/yellow]")
        sys.exit(0)

    # Handle --run-automation
    if args.run_automation:
        if _automation_enabled:
            autos = load_automations()
            target = next((a for a in autos if a.get("name") == args.run_automation), None)
            if target:
                _console.print(f"[cyan]Running automation: {args.run_automation}[/cyan]")
                runner = AutomationRunner()
                summary = runner.execute(target)
                if summary:
                    for part in summary.split(" | "):
                        _console.print(f"  {part}")
                else:
                    _console.print("  (no output)")
            else:
                available = [a.get("name", "?") for a in autos]
                _console.print(f"[red]Automation '{args.run_automation}' not found.[/red]")
                _console.print(f"Available: {', '.join(available)}")
        else:
            _console.print("[yellow]Automation system not available.[/yellow]")
        sys.exit(0)

    # Handle --briefing
    if args.briefing:
        if _automation_enabled:
            autos = load_automations()
            briefing = next((a for a in autos if a.get("name") == "morning_briefing"), None)
            if briefing:
                _console.print("[bold cyan]Morning Briefing[/bold cyan]")
                runner = AutomationRunner()
                summary = runner.execute(briefing)
                if summary:
                    for part in summary.split(" | "):
                        _console.print(f"  {part}")
                else:
                    _console.print("  (no output)")
            else:
                _console.print("[yellow]No morning_briefing automation found.[/yellow]")
        else:
            _console.print("[yellow]Automation system not available.[/yellow]")
        sys.exit(0)

    # Handle --claude-stats
    if args.claude_stats:
        if _escalation_enabled:
            esc = get_escalation()
            _console.print(esc.get_stats())
        else:
            _console.print("[yellow]Escalation system not available.[/yellow]")
        sys.exit(0)

    # Handle --list-models
    if args.list_models:
        _console.print(f"[dim]LM Studio URL: {_base_url}[/dim]")
        models = _list_available_models_fn()
        if models:
            _console.print(f"\n[bold]Available models ({len(models)}):[/bold]")
            for m in models:
                _console.print(f"  - {m}")
        else:
            _console.print("[yellow]No models loaded in LM Studio.[/yellow]")
        sys.exit(0)

    # Handle --model-info
    if args.model_info:
        sticky = _get_sticky_model()
        auto_on = _get_auto_mode()
        available = _list_available_models_fn()
        _console.print(f"[bold]Model Configuration[/bold]")
        _console.print(f"  Sticky model:  {sticky or '(none)'}")
        _console.print(f"  Auto routing:  {'ON' if auto_on else 'OFF'}")
        _console.print(f"  LM Studio URL: {_base_url}")
        _console.print(f"  Available:     {len(available)} model(s)")
        if available:
            for m in available:
                marker = " *" if m == sticky else ""
                _console.print(f"    - {m}{marker}")
        _console.print(f"\n[bold]Tier Assignments[/bold]")
        for tier_name, tier_models in MODEL_TIERS.items():
            matched = []
            for tm in tier_models:
                for av in available:
                    if tm.lower() in av.lower() or av.lower() in tm.lower():
                        matched.append(av)
                        break
            status = f"[green]{', '.join(matched)}[/green]" if matched else "[dim]no match[/dim]"
            _console.print(f"  {tier_name:10s} \u2192 {status}")
        sys.exit(0)

    # Handle --map-stats
    if args.map_stats:
        try:
            from core.system_map import get_stats, ensure_index_exists
            ensure_index_exists()
            stats = get_stats()
            print(f"System Map:")
            print(f"  Files:       {stats['files']}")
            print(f"  Directories: {stats['directories']}")
            print(f"  Projects:    {stats['projects']}")
            print(f"  Last scan:   {stats['last_scan']}")
        except Exception as e:
            print(f"Error: {e}")
        sys.exit(0)

    # Handle --map-projects
    if args.map_projects:
        try:
            from core.system_map import get_project_info, ensure_index_exists
            ensure_index_exists()
            projects = get_project_info()
            if projects:
                for p in projects:
                    langs = json.loads(p.get('languages', '[]'))
                    desc = p.get('description', '')[:60]
                    print(f"  {p['name']:20s} {p.get('file_count', 0):5d} files  "
                          f"{', '.join(langs[:3]):30s} {p['path']}")
                    if desc:
                        print(f"  {'':20s} {desc}")
            else:
                print("No projects found. Run cont to trigger initial scan.")
        except Exception as e:
            print(f"Error: {e}")
        sys.exit(0)

    # Handle --audit (security audit log)
    if args.audit:
        try:
            entries = query_audit_log(_memory_db_path(), limit=50)
            if not entries:
                _console.print("[dim]No audit log entries found.[/dim]")
            else:
                _console.print(f"[bold]Recent Security Events ({len(entries)} entries):[/bold]\n")
                for e in entries:
                    color = "red" if "block" in e["result"] else "green" if e["result"] == "user_approved" else "cyan"
                    _console.print(
                        f"[{color}]{e['timestamp']}  {e['event_type']:18s}  "
                        f"{e['tool_name']:15s}  {e['result']}[/{color}]"
                    )
        except Exception as ex:
            _console.print(f"[red]Error: {ex}[/red]")
        sys.exit(0)

    # Handle --backups (list file backups)
    if args.backups:
        backup_dir = _cont_dir / "backups"
        if not backup_dir.exists():
            _console.print("[dim]No backups found.[/dim]")
            sys.exit(0)
        metas = sorted(backup_dir.glob("*.meta"), reverse=True)[:20]
        if not metas:
            _console.print("[dim]No backup metadata found.[/dim]")
            sys.exit(0)
        _console.print(f"[bold]Recent Backups ({len(metas)} shown):[/bold]\n")
        for meta in metas:
            try:
                info = json.loads(meta.read_text())
                bak = Path(info["backup"])
                exists_str = "[green]exists[/green]" if bak.exists() else "[red]missing[/red]"
                _console.print(f"  {info['timestamp']}  {info['original']}  -> {bak.name}  {exists_str}")
            except Exception:
                pass
        sys.exit(0)

    # Handle --undo (restore from backup)
    if args.undo:
        backup_dir = _cont_dir / "backups"
        target = args.undo
        if not backup_dir.exists():
            _console.print("[red]No backups directory found.[/red]")
            sys.exit(1)
        meta_files = list(backup_dir.glob("*.meta"))
        match = None
        for meta in sorted(meta_files, reverse=True):
            try:
                info = json.loads(meta.read_text())
                if target in info.get("backup", "") or target in info.get("original", ""):
                    match = info
                    break
            except Exception:
                pass
        if not match:
            _console.print(f"[red]No backup found matching '{target}'[/red]")
            _console.print("[dim]Use --backups to see available backups.[/dim]")
            sys.exit(1)
        _console.print(f"[bold]Restore:[/bold] {match['backup']}")
        _console.print(f"[bold]To:[/bold] {match['original']}")
        _console.print("[yellow]Proceed? (y/n)[/yellow] ", end="")
        try:
            resp = input().strip().lower()
            if resp in ("y", "yes", "evet"):
                shutil.copy2(match["backup"], match["original"])
                _console.print("[green]Restored successfully.[/green]")
            else:
                _console.print("[dim]Cancelled.[/dim]")
        except (EOFError, KeyboardInterrupt):
            _console.print("\n[dim]Cancelled.[/dim]")
        sys.exit(0)

    # Handle --memory-show-autofix
    if args.memory_show_autofix:
        entries = memory_get_autofix_list()
        print(json.dumps(entries, indent=2))
        sys.exit(0)

    # Handle --memory-enable-autofix
    if args.memory_enable_autofix:
        memory_enable_autofix(args.memory_enable_autofix)
        print(json.dumps({"ok": True, "problem_signature": args.memory_enable_autofix, "enabled": True}))
        sys.exit(0)

    # Handle --memory-disable-autofix
    if args.memory_disable_autofix:
        memory_disable_autofix(args.memory_disable_autofix)
        print(json.dumps({"ok": True, "problem_signature": args.memory_disable_autofix, "enabled": False}))
        sys.exit(0)

    # Handle --memory-suggest-map
    if args.memory_suggest_map:
        snapshot = collect_env_snapshot()
        env_id = compute_env_id(snapshot)
        # Try env-specific first, then global
        fail = memory_get_last_failed_attempt(env_id)
        if not fail:
            fail = memory_get_last_failed_attempt(None)
        if not fail or not fail.get("error_signature"):
            print(json.dumps({"found": False}))
            sys.exit(0)
        error_sig = fail["error_signature"]
        suggested_sig = slugify(error_sig)
        suggested_title = f"Auto-fix for: {error_sig[:60]}"
        print(json.dumps({
            "found": True,
            "error_sig": error_sig,
            "suggested_problem_signature": suggested_sig,
            "suggested_title": suggested_title,
            "hint": f"Use --memory-map-error '{error_sig}|||{suggested_sig}|||{suggested_title}' and --memory-enable-autofix '{suggested_sig}' if desired"
        }, indent=2))
        sys.exit(0)

    # Handle --memory-map-last-fail
    if args.memory_map_last_fail is not None:
        snapshot = collect_env_snapshot()
        env_id = compute_env_id(snapshot)
        fail = memory_get_last_failed_attempt(env_id)
        if not fail:
            fail = memory_get_last_failed_attempt(None)
        if not fail or not fail.get("error_signature"):
            print(json.dumps({"ok": False, "error": "No failed attempt with error_signature found"}))
            sys.exit(1)
        error_sig = fail["error_signature"]

        if args.memory_map_last_fail:
            parts = args.memory_map_last_fail.split("|||")
            problem_sig = parts[0].strip() if len(parts) > 0 else ""
            title = parts[1].strip() if len(parts) > 1 else ""
        else:
            problem_sig = ""
            title = ""

        if not problem_sig:
            problem_sig = slugify(error_sig)
        if not title:
            title = f"Auto-fix for: {error_sig[:60]}"

        memory_map_error(error_sig, problem_sig, title)
        print(json.dumps({"ok": True, "error_sig": error_sig, "problem_signature": problem_sig, "title": title}))
        sys.exit(0)

    # Handle --memory-show-error-map
    if args.memory_show_error_map:
        mappings = memory_get_error_mappings(limit=50)
        print(json.dumps(mappings, indent=2))
        sys.exit(0)

    # Handle --memory-recent
    if args.memory_recent is not None:
        snapshot = collect_env_snapshot()
        current_env_id = compute_env_id(snapshot)
        attempts = memory_recent_attempts(limit=args.memory_recent, only_fail=False, env_only=False)
        print(json.dumps({"ok": True, "current_env_id": current_env_id, "attempts": attempts}, indent=2))
        sys.exit(0)

    # Handle --memory-recent-fail
    if args.memory_recent_fail is not None:
        snapshot = collect_env_snapshot()
        current_env_id = compute_env_id(snapshot)
        attempts = memory_recent_attempts(limit=args.memory_recent_fail, only_fail=True, env_only=False)
        print(json.dumps({"ok": True, "current_env_id": current_env_id, "attempts": attempts}, indent=2))
        sys.exit(0)

    # Handle --memory-recent-env
    if args.memory_recent_env is not None:
        snapshot = collect_env_snapshot()
        current_env_id = compute_env_id(snapshot)
        attempts = memory_recent_attempts(limit=args.memory_recent_env, only_fail=False, env_only=True)
        print(json.dumps({"ok": True, "current_env_id": current_env_id, "attempts": attempts}, indent=2))
        sys.exit(0)

    # Handle --memory-prune
    if args.memory_prune is not None:
        keep_min = int(os.environ.get("CONT_MEMORY_KEEP_MIN", "500"))
        result = memory_prune(days=args.memory_prune, keep_min=keep_min)
        print(json.dumps(result, indent=2))
        sys.exit(0)

    # Handle --memory-export
    if args.memory_export:
        result = memory_export(args.memory_export, include_attempts=False)
        print(json.dumps(result, indent=2))
        sys.exit(0)

    # Handle --memory-export-all
    if args.memory_export_all:
        result = memory_export(args.memory_export_all, include_attempts=True)
        print(json.dumps(result, indent=2))
        sys.exit(0)

    # Handle --memory-import
    if args.memory_import:
        result = memory_import(args.memory_import, merge=True)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result.get("ok") else 1)

    # Handle --memory-map-error
    if args.memory_map_error:
        spec = args.memory_map_error
        parts = spec.split("|||")
        if len(parts) < 3:
            print(json.dumps({"ok": False, "error": "Invalid format. Use: <error_sig>|||<problem_signature>|||<title>"}))
            sys.exit(1)
        error_sig = parts[0].strip()
        problem_sig = parts[1].strip()
        title = parts[2].strip()
        if not error_sig or not problem_sig:
            print(json.dumps({"ok": False, "error": "error_sig and problem_signature required"}))
            sys.exit(1)
        memory_map_error(error_sig, problem_sig, title)
        print(json.dumps({"ok": True}))
        sys.exit(0)

    # Handle --memory-unmap-error
    if args.memory_unmap_error:
        memory_unmap_error(args.memory_unmap_error)
        print(json.dumps({"ok": True}))
        sys.exit(0)

    # Handle --memory-solution-stats
    if args.memory_solution_stats:
        # Compute current env_id for env-aware stats
        snapshot = collect_env_snapshot()
        current_env_id = compute_env_id(snapshot)
        stats = memory_solution_stats(args.memory_solution_stats, env_id=current_env_id)
        print(json.dumps({
            "signature": args.memory_solution_stats,
            "current_env_id": current_env_id,
            "solutions": stats
        }, indent=2))
        sys.exit(0)

    # Handle --memory-add
    if args.memory_add:
        spec = args.memory_add
        parts = spec.split("|||")
        if len(parts) < 3:
            print(json.dumps({"ok": False, "error": "Invalid format. Use: <signature>|||<title>|||<step1>;;<step2>"}))
            sys.exit(1)
        signature = parts[0].strip()
        title = parts[1].strip()
        steps_raw = parts[2] if len(parts) > 2 else ""
        steps = [s.strip() for s in steps_raw.split(";;") if s.strip()]
        if not signature or not title:
            print(json.dumps({"ok": False, "error": "Signature and title required"}))
            sys.exit(1)
        solution_id = memory_add_solution(signature, title, steps)
        print(json.dumps({"ok": True, "solution_id": solution_id}))
        sys.exit(0)

    # Handle --memory-find
    if args.memory_find:
        # Compute current env_id for env-aware scoring
        snapshot = collect_env_snapshot()
        current_env_id = compute_env_id(snapshot)
        sol = memory_get_best_solution(args.memory_find, env_id=current_env_id)
        if sol:
            print(json.dumps({"found": True, "current_env_id": current_env_id, **sol}, indent=2))
        else:
            print(json.dumps({"found": False, "current_env_id": current_env_id}))
        sys.exit(0)

    # Handle --memory-apply
    if args.memory_apply:
        # Compute current env_id for env-aware solution scoring
        snapshot = collect_env_snapshot()
        env_id = memory_upsert_env_snapshot(snapshot)

        sol = memory_get_best_solution(args.memory_apply, env_id=env_id)
        if not sol:
            print(json.dumps({"ok": False, "error": "not_found"}))
            sys.exit(1)

        # Anti-loop: check for recent failure in same env
        recent_fail = memory_check_recent_failure(sol["solution_id"], env_id, hours=24)
        if recent_fail:
            print(json.dumps({
                "ok": False,
                "error": "recent_failure_skip",
                "solution_id": sol["solution_id"],
                "last_attempt_at": recent_fail["created_at"]
            }))
            sys.exit(2)

        # Safety check each step before running (unless --memory-apply-unsafe)
        if not args.memory_apply_unsafe:
            for step in sol["steps"]:
                is_safe, reason = is_step_safe(step)
                if not is_safe:
                    print(json.dumps({
                        "ok": False,
                        "error": "unsafe_step",
                        "reason": reason,
                        "step": step
                    }))
                    sys.exit(3)

        results = []
        for step in sol["steps"]:
            try:
                exit_code, output, duration_ms = _run_shell_capture(step, solution_id=sol["solution_id"])
                results.append({"step": step, "exit_code": exit_code, "duration_ms": duration_ms})
            except Exception as e:
                results.append({"step": step, "exit_code": -1, "duration_ms": None, "error": str(e)})
        print(json.dumps({
            "ok": True,
            "solution_id": sol["solution_id"],
            "title": sol["title"],
            "results": results
        }, indent=2))
        sys.exit(0)

    # Handle --memory-selftest
    if args.memory_selftest:
        print("Running selftest: run_shell('echo hello')", file=sys.stderr)
        out = run_shell("echo hello")
        print(f"Output: {out.strip()}", file=sys.stderr)
        print("Memory stats:", file=sys.stderr)
        stats = memory_stats()
        print(json.dumps(stats, indent=2))
        sys.exit(0)

    # Handle --memory-stats
    if args.memory_stats:
        memory_init_db()
        stats = memory_stats()
        print(json.dumps(stats, indent=2))
        sys.exit(0)

    # Handle --doctor (environment + model diagnostics)
    if args.doctor:
        snapshot = collect_env_snapshot()

        # Add LLM/model diagnostics
        models = _list_available_models_fn()
        resolved_model = None
        endpoint_mode = None
        try:
            resolved_model = _resolve_model_fn()
            endpoint_mode = _determine_endpoint_fn(resolved_model)
        except SystemExit:
            pass  # No models loaded

        snapshot["llm"] = {
            "base_url": _base_url,
            "available_models": models,
            "resolved_model": resolved_model,
            "endpoint_mode": endpoint_mode,
            "model_override": _model_override_getter(),
            "env_cont_model": os.environ.get("CONT_MODEL"),
            "env_openai_model": os.environ.get("OPENAI_MODEL"),
        }

        # Save to file
        filepath = save_env_snapshot(snapshot)
        # Print to stdout
        print(json.dumps(snapshot, indent=2))
        # Print save location to stderr so it doesn't pollute JSON output
        print(f"Saved to: {filepath}", file=sys.stderr)
        sys.exit(0)

    # Handle --print-openai-base-url
    if args.print_openai_base_url:
        print(_base_url)
        sys.exit(0)

    # Handle --relay
    if args.relay:
        from core.relay import start_relay
        start_relay(port=args.relay_port)
        sys.exit(0)

    # Handle --bridge
    if args.bridge:
        from core.bridge_server import start_bridge
        start_bridge(port=args.bridge_port)
        sys.exit(0)

    # Handle --setup-openai
    if args.setup_openai:
        key = args.setup_openai.strip()
        if not key.startswith("sk-"):
            _console.print("[red]Invalid key format. OpenAI keys start with 'sk-'[/red]")
            sys.exit(1)
        key_dir = Path.home() / ".config" / "cont"
        key_dir.mkdir(parents=True, exist_ok=True)
        key_file = key_dir / "openai_key"
        key_file.write_text(key)
        key_file.chmod(0o600)
        _console.print(f"[green]OpenAI key saved to {key_file}[/green]")
        # Quick test
        try:
            from openai import OpenAI
            import httpx
            test_client = OpenAI(api_key=key, timeout=httpx.Timeout(15.0, connect=5.0))
            resp = test_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Say OK"}],
                max_tokens=5
            )
            _console.print(f"[green]Test OK: {resp.choices[0].message.content}[/green]")
        except Exception as e:
            _console.print(f"[yellow]Key saved but test failed: {e}[/yellow]")
        sys.exit(0)

    # Handle --voice-test
    if args.voice_test:
        from core.voice import voice_diagnostic
        voice_diagnostic(duration=5)
        sys.exit(0)

    # No exit flag matched
    return False
