# core/scheduler.py
"""
Lightweight scheduler for Cont.

No cron dependency. Tracks which automations have run today/this week
via a single JSON state file. Called at Cont startup to determine
which scheduled automations should execute.
"""

import json
from datetime import datetime, date
from pathlib import Path


STATE_FILE = Path.home() / ".config" / "cont" / "scheduler_state.json"


def _load_state() -> dict:
    """Load scheduler state from JSON file."""
    try:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save_state(state: dict) -> None:
    """Save scheduler state to JSON file."""
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


class Scheduler:
    """
    Check if scheduled automations should run.

    State tracks last run dates:
        {
            "morning_briefing": {"last_daily": "2025-02-13"},
            "weekly_report": {"last_weekly": "2025-W07"},
            "disk_cleanup": {"last_daily": "2025-02-12"}
        }
    """

    def __init__(self):
        self._state = _load_state()

    def check_daily(self, automation_name: str) -> bool:
        """Returns True if this automation hasn't run today."""
        today_str = date.today().isoformat()
        entry = self._state.get(automation_name, {})
        return entry.get("last_daily") != today_str

    def check_weekly(self, automation_name: str, day: str = "") -> bool:
        """
        Returns True if this automation hasn't run this week,
        and today is the right day (if specified).

        Args:
            automation_name: Name of the automation
            day: Day of week (e.g., "monday", "friday"). Empty = any day.
        """
        today = date.today()
        week_str = today.strftime("%Y-W%V")

        # Check if already run this week
        entry = self._state.get(automation_name, {})
        if entry.get("last_weekly") == week_str:
            return False

        # Check day-of-week constraint
        if day:
            day_lower = day.lower()
            today_day = today.strftime("%A").lower()
            if day_lower != today_day:
                return False

        return True

    def mark_done(self, automation_name: str, period: str = "daily") -> None:
        """
        Mark automation as done for current period.

        Args:
            automation_name: Name of the automation
            period: "daily" or "weekly"
        """
        today = date.today()
        if automation_name not in self._state:
            self._state[automation_name] = {}

        if period == "daily":
            self._state[automation_name]["last_daily"] = today.isoformat()
        elif period == "weekly":
            self._state[automation_name]["last_weekly"] = today.strftime("%Y-W%V")

        self._state[automation_name]["last_run_at"] = datetime.now().isoformat()
        _save_state(self._state)

    def get_status(self) -> dict:
        """Get full scheduler state for CLI display."""
        return dict(self._state)

    def reset(self, automation_name: str = "") -> None:
        """Reset state for one automation or all."""
        if automation_name:
            self._state.pop(automation_name, None)
        else:
            self._state.clear()
        _save_state(self._state)
