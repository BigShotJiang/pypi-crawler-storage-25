# core/sticky_config.py
"""Persistent model/config storage (~/.config/cont/config.json)."""

import json
from pathlib import Path
from typing import Optional

from core.utils import debug as _debug

_CONT_CONFIG_DIR = Path.home() / ".config" / "cont"
_CONT_CONFIG_FILE = _CONT_CONFIG_DIR / "config.json"


def _load_sticky_config() -> dict:
    """Load persistent config (sticky model, etc.)."""
    try:
        if _CONT_CONFIG_FILE.exists():
            return json.loads(_CONT_CONFIG_FILE.read_text())
    except Exception as e:
        _debug(f"Failed to load config: {e}")
    return {}


def _save_sticky_config(config: dict) -> None:
    """Save persistent config."""
    try:
        _CONT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _CONT_CONFIG_FILE.write_text(json.dumps(config, indent=2))
        _debug(f"Saved config to {_CONT_CONFIG_FILE}")
    except Exception as e:
        _debug(f"Failed to save config: {e}")


def _get_sticky_model() -> Optional[str]:
    """Get persisted model ID if any."""
    config = _load_sticky_config()
    return config.get("last_model_id")


def _set_sticky_model(model_id: str, endpoint_mode: str = None, base_url: str = None) -> None:
    """Persist model ID for future runs."""
    config = _load_sticky_config()
    config["last_model_id"] = model_id
    if endpoint_mode:
        config["last_endpoint_mode"] = endpoint_mode
    if base_url:
        config["last_base_url"] = base_url
    _save_sticky_config(config)


def _get_auto_mode() -> bool:
    """Check if auto model selection is enabled."""
    config = _load_sticky_config()
    return config.get("auto_model", False)


def _set_auto_mode(enabled: bool) -> None:
    """Enable or disable auto model selection."""
    config = _load_sticky_config()
    config["auto_model"] = enabled
    _save_sticky_config(config)


def _forget_sticky_model() -> None:
    """Remove persisted model ID."""
    config = _load_sticky_config()
    if "last_model_id" in config:
        del config["last_model_id"]
    if "last_endpoint_mode" in config:
        del config["last_endpoint_mode"]
    if "last_base_url" in config:
        del config["last_base_url"]
    _save_sticky_config(config)
