# core/lmstudio.py
"""LM Studio model management — probe, load, unload models."""

from typing import Optional

import requests

from core.utils import debug as _debug


_LMSTUDIO_UNLOAD_SUPPORTED: Optional[bool] = None


def _probe_lmstudio_unload(base_url: str) -> bool:
    """
    Probe if LM Studio supports model unload/load endpoints.
    Returns True if supported, False otherwise.
    Caches result.
    """
    global _LMSTUDIO_UNLOAD_SUPPORTED

    if _LMSTUDIO_UNLOAD_SUPPORTED is not None:
        return _LMSTUDIO_UNLOAD_SUPPORTED

    try:
        url = base_url.rstrip("/") + "/lmstudio/models"
        _debug(f"Probing LM Studio unload support: {url}")
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            _LMSTUDIO_UNLOAD_SUPPORTED = True
            _debug("LM Studio model management supported")
            return True
    except Exception as e:
        _debug(f"LM Studio probe error: {e}")

    _LMSTUDIO_UNLOAD_SUPPORTED = False
    _debug("LM Studio model management not supported")
    return False


def _lmstudio_unload_model(base_url: str, model_id: str) -> bool:
    """
    Attempt to unload a model from LM Studio.
    Returns True on success, False otherwise.
    """
    if not _probe_lmstudio_unload(base_url):
        _debug("LM Studio unload not supported; switching model may keep previous loaded")
        return False

    try:
        url = base_url.rstrip("/") + "/lmstudio/unload"
        _debug(f"Unloading model: {model_id}")
        resp = requests.post(url, json={"model": model_id}, timeout=30)
        if resp.status_code == 200:
            _debug(f"Model {model_id} unloaded successfully")
            return True
        else:
            _debug(f"Unload failed: HTTP {resp.status_code}")
            return False
    except Exception as e:
        _debug(f"Unload error: {e}")
        return False


def _lmstudio_load_model(base_url: str, model_id: str) -> bool:
    """
    Attempt to load a model in LM Studio.
    Returns True on success, False otherwise.
    """
    if not _probe_lmstudio_unload(base_url):
        return False

    try:
        url = base_url.rstrip("/") + "/lmstudio/load"
        _debug(f"Loading model: {model_id}")
        resp = requests.post(url, json={"model": model_id}, timeout=60)
        if resp.status_code == 200:
            _debug(f"Model {model_id} loaded successfully")
            return True
        else:
            _debug(f"Load failed: HTTP {resp.status_code}")
            return False
    except Exception as e:
        _debug(f"Load error: {e}")
        return False
