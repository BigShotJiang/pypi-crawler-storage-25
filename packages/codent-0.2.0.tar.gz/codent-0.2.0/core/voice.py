# core/voice.py
"""
Voice input for Cont.

Architecture:
  Windows mic -> temp WAV file -> faster-whisper STT -> text command

WSL2 has no direct microphone access. Recording uses PowerShell on the
Windows side. Transcription runs on WSL with GPU via faster-whisper.

Usage:
  cont --voice         # Continuous voice mode with wake word
  cont --listen-once   # Single voice command
"""

import os
import subprocess
import sys
import time
from pathlib import Path

# Lazy-loaded whisper model
_whisper_model = None

# Shared temp dir accessible from both WSL and Windows
_WIN_TEMP = "/mnt/c/Users/Sertan/AppData/Local/Temp"


def _ensure_cuda_libs():
    """Ensure CUDA libraries are discoverable for ctranslate2.

    Must be called BEFORE importing faster_whisper / ctranslate2,
    because the dynamic linker reads LD_LIBRARY_PATH at dlopen time.
    As a fallback, also preload libs via ctypes.
    """
    import ctypes
    import ctypes.util

    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    lib_dirs = []

    # Find nvidia libs installed by pip (nvidia-cublas-cu12 etc.)
    for site in sys.path:
        nvidia_dir = os.path.join(site, "nvidia")
        if os.path.isdir(nvidia_dir):
            for sub in os.listdir(nvidia_dir):
                lib_dir = os.path.join(nvidia_dir, sub, "lib")
                if os.path.isdir(lib_dir) and lib_dir not in ld_path:
                    lib_dirs.append(lib_dir)

    # Also check ollama's bundled CUDA 12
    ollama_cuda = "/usr/local/lib/ollama/cuda_v12"
    if os.path.isdir(ollama_cuda) and ollama_cuda not in ld_path:
        lib_dirs.append(ollama_cuda)

    if lib_dirs:
        os.environ["LD_LIBRARY_PATH"] = ":".join(lib_dirs) + ":" + ld_path

    # Preload critical libs via ctypes so ctranslate2 can find them
    for lib_dir in lib_dirs:
        for lib_name in ("libcublas.so.12", "libcublasLt.so.12",
                         "libcudnn.so.9", "libcudnn.so.8"):
            lib_path = os.path.join(lib_dir, lib_name)
            if os.path.exists(lib_path):
                try:
                    ctypes.cdll.LoadLibrary(lib_path)
                except OSError:
                    pass


def _get_whisper_model(model_size: str = "base"):
    """Lazy-load faster-whisper model. Uses GPU if available."""
    global _whisper_model
    if _whisper_model is not None:
        return _whisper_model

    _ensure_cuda_libs()

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        print("faster-whisper not installed:", file=sys.stderr)
        print("  pip install faster-whisper", file=sys.stderr)
        return None

    # Try GPU first, fall back to CPU
    for device, compute in [("cuda", "float16"), ("cpu", "int8")]:
        try:
            print(f"Loading Whisper '{model_size}' ({device})...",
                  file=sys.stderr)
            _whisper_model = WhisperModel(
                model_size, device=device, compute_type=compute
            )
            print(f"Whisper ready ({device})", file=sys.stderr)
            return _whisper_model
        except Exception as e:
            if device == "cuda":
                print(f"GPU failed ({e}), trying CPU...", file=sys.stderr)
                continue
            print(f"Whisper load failed: {e}", file=sys.stderr)
            return None


def _wsl_to_win_path(wsl_path: str) -> str:
    """Convert /mnt/c/... to C:\\..."""
    return wsl_path.replace("/mnt/c", "C:").replace("/", "\\")


def _make_wav_path() -> str:
    """Create a temp WAV path accessible from both WSL and Windows."""
    return f"{_WIN_TEMP}/cont_voice_{int(time.time() * 1000)}.wav"


# ===================================================================
# RECORDING — multiple strategies, first one that works wins
# ===================================================================

def _record_powershell_dotnet(wav_path: str, duration: int,
                              sample_rate: int) -> bool:
    """
    Record audio via PowerShell using .NET waveIn API.

    Records at 44100 Hz (native mic rate) then resamples to target
    sample_rate via ffmpeg, because many Windows mics produce silence
    at non-native rates like 16000 Hz.
    """
    # Record at 44100 Hz (native), resample later
    record_rate = 44100
    win_path = _wsl_to_win_path(wav_path)

    ps_script = f"""
$ErrorActionPreference = "Stop"
$outFile = "{win_path}"
$duration = {duration}
$sampleRate = {record_rate}

# Use Add-Type with inline C# that uses waveIn API
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

public class SimpleRecorder {{
    const int WAVE_MAPPER = -1;
    const int CALLBACK_NULL = 0;
    const int WHDR_DONE = 1;

    [StructLayout(LayoutKind.Sequential)]
    struct WAVEFORMATEX {{
        public ushort wFormatTag;
        public ushort nChannels;
        public uint nSamplesPerSec;
        public uint nAvgBytesPerSec;
        public ushort nBlockAlign;
        public ushort wBitsPerSample;
        public ushort cbSize;
    }}

    [StructLayout(LayoutKind.Sequential)]
    struct WAVEHDR {{
        public IntPtr lpData;
        public uint dwBufferLength;
        public uint dwBytesRecorded;
        public IntPtr dwUser;
        public uint dwFlags;
        public uint dwLoops;
        public IntPtr lpNext;
        public IntPtr reserved;
    }}

    [DllImport("winmm.dll")]
    static extern int waveInOpen(out IntPtr hWaveIn, int uDeviceID,
        ref WAVEFORMATEX lpFormat, IntPtr dwCallback, IntPtr dwInstance, int dwFlags);
    [DllImport("winmm.dll")]
    static extern int waveInPrepareHeader(IntPtr hWaveIn, ref WAVEHDR lpWaveHdr, int uSize);
    [DllImport("winmm.dll")]
    static extern int waveInAddBuffer(IntPtr hWaveIn, ref WAVEHDR lpWaveHdr, int uSize);
    [DllImport("winmm.dll")]
    static extern int waveInStart(IntPtr hWaveIn);
    [DllImport("winmm.dll")]
    static extern int waveInStop(IntPtr hWaveIn);
    [DllImport("winmm.dll")]
    static extern int waveInUnprepareHeader(IntPtr hWaveIn, ref WAVEHDR lpWaveHdr, int uSize);
    [DllImport("winmm.dll")]
    static extern int waveInClose(IntPtr hWaveIn);

    public static void Record(string filePath, int durationMs, int sampleRate) {{
        WAVEFORMATEX fmt = new WAVEFORMATEX();
        fmt.wFormatTag = 1; // PCM
        fmt.nChannels = 1;
        fmt.nSamplesPerSec = (uint)sampleRate;
        fmt.wBitsPerSample = 16;
        fmt.nBlockAlign = (ushort)(fmt.nChannels * fmt.wBitsPerSample / 8);
        fmt.nAvgBytesPerSec = fmt.nSamplesPerSec * fmt.nBlockAlign;
        fmt.cbSize = 0;

        IntPtr hWaveIn;
        int result = waveInOpen(out hWaveIn, WAVE_MAPPER, ref fmt, IntPtr.Zero, IntPtr.Zero, CALLBACK_NULL);
        if (result != 0) throw new Exception("waveInOpen failed: " + result);

        int bufSize = (int)(fmt.nAvgBytesPerSec * durationMs / 1000);
        IntPtr buffer = Marshal.AllocHGlobal(bufSize);

        WAVEHDR hdr = new WAVEHDR();
        hdr.lpData = buffer;
        hdr.dwBufferLength = (uint)bufSize;

        waveInPrepareHeader(hWaveIn, ref hdr, Marshal.SizeOf(typeof(WAVEHDR)));
        waveInAddBuffer(hWaveIn, ref hdr, Marshal.SizeOf(typeof(WAVEHDR)));
        waveInStart(hWaveIn);

        Thread.Sleep(durationMs + 200);

        waveInStop(hWaveIn);
        waveInUnprepareHeader(hWaveIn, ref hdr, Marshal.SizeOf(typeof(WAVEHDR)));
        waveInClose(hWaveIn);

        // Write WAV file
        using (var fs = new FileStream(filePath, FileMode.Create))
        using (var bw = new BinaryWriter(fs)) {{
            int dataSize = (int)hdr.dwBytesRecorded;
            bw.Write(new char[] {{ 'R', 'I', 'F', 'F' }});
            bw.Write(36 + dataSize);
            bw.Write(new char[] {{ 'W', 'A', 'V', 'E' }});
            bw.Write(new char[] {{ 'f', 'm', 't', ' ' }});
            bw.Write(16);
            bw.Write((short)1);
            bw.Write((short)fmt.nChannels);
            bw.Write((int)fmt.nSamplesPerSec);
            bw.Write((int)fmt.nAvgBytesPerSec);
            bw.Write((short)fmt.nBlockAlign);
            bw.Write((short)fmt.wBitsPerSample);
            bw.Write(new char[] {{ 'd', 'a', 't', 'a' }});
            bw.Write(dataSize);
            byte[] data = new byte[dataSize];
            Marshal.Copy(buffer, data, 0, dataSize);
            bw.Write(data);
        }}

        Marshal.FreeHGlobal(buffer);
    }}
}}
'@ -ReferencedAssemblies System.IO

[SimpleRecorder]::Record($outFile, $duration * 1000, $sampleRate)
Write-Host "RECORD_OK"
"""

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", ps_script],
            capture_output=True, text=True,
            timeout=duration + 15,
        )
        if "RECORD_OK" not in result.stdout:
            if result.stderr:
                print(f"  PS error: {result.stderr[:200]}", file=sys.stderr)
            return False
        if not os.path.exists(wav_path) or os.path.getsize(wav_path) < 100:
            return False

        # Resample from 44100 Hz to target sample_rate if needed
        if record_rate != sample_rate:
            resampled = wav_path + ".tmp.wav"
            try:
                subprocess.run(
                    ["ffmpeg", "-y", "-i", wav_path,
                     "-ar", str(sample_rate), "-ac", "1", resampled],
                    capture_output=True, timeout=10,
                )
                if os.path.exists(resampled) and os.path.getsize(resampled) > 100:
                    os.replace(resampled, wav_path)
                else:
                    # ffmpeg failed — keep original, Whisper handles various rates
                    try:
                        os.remove(resampled)
                    except OSError:
                        pass
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass  # Keep original file

        return True
    except subprocess.TimeoutExpired:
        print("  Recording timed out", file=sys.stderr)
        return False
    except FileNotFoundError:
        return False


def _record_win_ffmpeg(wav_path: str, duration: int,
                       sample_rate: int) -> bool:
    """Record via Windows ffmpeg (if installed via winget/choco)."""
    win_path = _wsl_to_win_path(wav_path)

    # Try common Windows ffmpeg locations
    ffmpeg_paths = [
        "ffmpeg",  # In PATH
        r"C:\ProgramData\chocolatey\bin\ffmpeg.exe",
        r"C:\tools\ffmpeg\bin\ffmpeg.exe",
    ]

    for ffmpeg in ffmpeg_paths:
        try:
            ps_cmd = (
                f'& "{ffmpeg}" -f dshow -i audio="Microphone" '
                f'-t {duration} -ar {sample_rate} -ac 1 '
                f'-y "{win_path}" 2>&1 | Out-Null; '
                f'if (Test-Path "{win_path}") {{ Write-Host "RECORD_OK" }}'
            )
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True,
                timeout=duration + 10,
            )
            if "RECORD_OK" in result.stdout:
                return os.path.exists(wav_path) and os.path.getsize(wav_path) > 100
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return False


def _record_wsl_ffmpeg(wav_path: str, duration: int,
                       sample_rate: int) -> bool:
    """Record via WSL ffmpeg with ALSA or PulseAudio."""
    for audio_sys in [("pulse", "default"), ("alsa", "default")]:
        try:
            result = subprocess.run(
                ["ffmpeg", "-f", audio_sys[0], "-i", audio_sys[1],
                 "-t", str(duration), "-ar", str(sample_rate),
                 "-ac", "1", "-y", wav_path],
                capture_output=True, text=True,
                timeout=duration + 5,
            )
            if os.path.exists(wav_path) and os.path.getsize(wav_path) > 100:
                return True
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return False


def record_audio(duration: int = 5, sample_rate: int = 16000) -> str:
    """
    Record audio from microphone. Tries multiple strategies:
    1. PowerShell .NET waveIn (always available on Windows)
    2. Windows ffmpeg via dshow
    3. WSL ffmpeg via ALSA/PulseAudio

    Returns path to WAV file, or None on failure.
    """
    wav_path = _make_wav_path()

    strategies = [
        ("PowerShell waveIn", _record_powershell_dotnet),
        ("Windows ffmpeg", _record_win_ffmpeg),
        ("WSL ffmpeg", _record_wsl_ffmpeg),
    ]

    for name, func in strategies:
        try:
            if func(wav_path, duration, sample_rate):
                return wav_path
        except Exception as e:
            print(f"  {name} failed: {e}", file=sys.stderr)
            continue

    print("Audio recording failed. No working method found.", file=sys.stderr)
    print("  Options:", file=sys.stderr)
    print("  - Install ffmpeg on Windows: winget install ffmpeg", file=sys.stderr)
    print("  - Set up PulseAudio for WSL2", file=sys.stderr)
    return None


# ===================================================================
# TRANSCRIPTION
# ===================================================================

def transcribe(audio_path: str, language: str = "tr") -> str:
    """Transcribe audio file to text using faster-whisper."""
    model = _get_whisper_model()
    if model is None:
        return ""

    if not audio_path or not os.path.exists(audio_path):
        return ""

    try:
        segments, info = model.transcribe(
            audio_path,
            language=language,
            beam_size=5,
            vad_filter=True,
            initial_prompt="Cont, kont. Alev, alev.",
        )
        text = " ".join(seg.text.strip() for seg in segments)
        return text.strip()
    except Exception as e:
        print(f"Transcription error: {e}", file=sys.stderr)
        return ""
    finally:
        try:
            os.remove(audio_path)
        except OSError:
            pass


# ===================================================================
# WAKE WORD
# ===================================================================

_WAKE_WORDS = {
    "cont", "kont", "count", "conto", "cant",
    "kompe", "konpe", "conte", "kornun", "come", "konc", "kond",
    "alev",
}


def _strip_punct(word: str) -> str:
    """Strip trailing punctuation from a word."""
    return word.rstrip(".,!?;:'\"")


def detect_wake_word(text: str) -> bool:
    """Check if text starts with a wake word."""
    words = text.lower().split()
    return bool(words) and _strip_punct(words[0]) in _WAKE_WORDS


def extract_command(text: str) -> str:
    """Remove wake word from text to get the actual command."""
    words = text.split()
    if not words:
        return ""
    if _strip_punct(words[0].lower()) in _WAKE_WORDS:
        return " ".join(words[1:]).strip()
    return text.strip()


# ===================================================================
# VOICE LOOP
# ===================================================================

class VoiceLoop:
    """
    Continuous voice listening loop.

    Listens for wake word "cont", then captures command,
    sends to Cont for execution.
    """

    def __init__(self, task_handler,
                 wake_duration: int = 3,
                 command_duration: int = 6,
                 language: str = "tr",
                 continuous: bool = True,
                 whisper_model: str = "base"):
        self.task_handler = task_handler
        self.wake_duration = wake_duration
        self.command_duration = command_duration
        self.language = language
        self.continuous = continuous
        self.whisper_model = whisper_model
        self.running = False

    def start(self):
        """Start the voice loop."""
        model = _get_whisper_model(self.whisper_model)
        if model is None:
            return

        # Test recording once
        print("Testing microphone...", file=sys.stderr)
        test_wav = record_audio(duration=1)
        if test_wav is None:
            print("Microphone not accessible. Voice mode unavailable.",
                  file=sys.stderr)
            return
        # Clean up test file
        try:
            os.remove(test_wav)
        except OSError:
            pass

        self.running = True
        print("Voice mode active. Say 'Cont' or 'Alev' followed by your command.")
        print("  Ctrl+C to stop\n")

        if self.continuous:
            self._continuous_loop()
        else:
            self._single_listen()

    def stop(self):
        self.running = False
        print("\nVoice mode stopped.")

    def _continuous_loop(self):
        """Listen continuously for wake word + command."""
        while self.running:
            try:
                sys.stderr.write("\r  Listening... (say 'Cont')  ")
                sys.stderr.flush()

                audio = record_audio(duration=self.wake_duration)
                if not audio:
                    time.sleep(1)
                    continue

                text = transcribe(audio, self.language)
                if not text:
                    continue

                if detect_wake_word(text):
                    command = extract_command(text)

                    if not command:
                        # Wake word only - listen for the command
                        sys.stderr.write("\r" + " " * 40 + "\r")
                        print("  Listening for command...")
                        audio2 = record_audio(duration=self.command_duration)
                        if audio2:
                            command = transcribe(audio2, self.language)

                    if command:
                        sys.stderr.write("\r" + " " * 40 + "\r")
                        print(f"  Command: {command}")
                        try:
                            result = self.task_handler(command)
                            if result:
                                # Truncate long results for voice feedback
                                short = result[:300]
                                print(f"  Result: {short}")
                        except Exception as e:
                            print(f"  Error: {e}", file=sys.stderr)
                    else:
                        print("  Could not understand, try again")

            except KeyboardInterrupt:
                self.stop()
                break
            except Exception as e:
                print(f"  Voice error: {e}", file=sys.stderr)
                time.sleep(1)

    def _single_listen(self):
        """Listen for a single command (no wake word needed)."""
        print("  Listening...")
        audio = record_audio(duration=self.command_duration)
        if audio:
            text = transcribe(audio, self.language)
            if text:
                command = extract_command(text) if detect_wake_word(text) else text
                print(f"  Command: {command}")
                if self.task_handler:
                    self.task_handler(command)
            else:
                print("  Could not understand audio")
        else:
            print("  Recording failed")


# ===================================================================
# DIAGNOSTIC
# ===================================================================

def voice_diagnostic(duration: int = 5, language: str = "tr"):
    """
    Test each step of the voice pipeline and report results.
    Run with: cont --voice-test
    """
    import struct
    import wave

    print("Voice diagnostic starting...\n")

    # Step 1: Record
    print("1. RECORDING")
    print(f"   Recording {duration} seconds. Speak into microphone!")
    print("   3... 2... 1... Go!")
    time.sleep(1)

    audio_path = record_audio(duration=duration)
    if not audio_path:
        print("   FAIL: No recording method worked")
        print("\n   Options:")
        print("   - Install ffmpeg on Windows: winget install ffmpeg")
        print("   - Set up PulseAudio for WSL2")
        return

    file_size = os.path.getsize(audio_path)
    print(f"   OK: {audio_path}")
    print(f"   File size: {file_size:,} bytes")

    if file_size < 5000:
        print("   WARNING: File very small - mic may be silent")

    # Step 2: Audio level analysis
    print("\n2. AUDIO LEVEL")
    try:
        with wave.open(audio_path, "rb") as wf:
            frames = wf.readframes(wf.getnframes())
            if len(frames) >= 2:
                samples = struct.unpack(f"<{len(frames) // 2}h", frames)
                max_amp = max(abs(s) for s in samples)
                avg_amp = sum(abs(s) for s in samples) / len(samples)

                print(f"   Max amplitude: {max_amp} / 32767")
                print(f"   Avg amplitude: {avg_amp:.0f} / 32767")

                if max_amp < 500:
                    print("   PROBLEM: Audio too quiet - mic off or too far")
                elif max_amp < 3000:
                    print("   WARNING: Low volume - move closer to mic")
                else:
                    print("   OK: Audio level sufficient")
            else:
                print("   PROBLEM: No audio samples in file")
    except Exception as e:
        print(f"   Could not analyze: {e}")

    # Step 3: Transcribe
    print("\n3. TRANSCRIPTION")
    model = _get_whisper_model()
    if not model:
        print("   FAIL: Whisper model could not be loaded")
        _cleanup(audio_path)
        return

    try:
        segments, info = model.transcribe(
            audio_path, language=language, beam_size=5, vad_filter=True,
            initial_prompt="Cont, kont. Alev, alev.",
        )
        segments_list = list(segments)
    except Exception as e:
        print(f"   FAIL: {e}")
        _cleanup(audio_path)
        return

    print(f"   Language: {info.language} (confidence: {info.language_probability:.1%})")
    print(f"   Duration: {info.duration:.1f}s")
    print(f"   Segments: {len(segments_list)}")

    if not segments_list:
        print("   WARNING: No segments - Whisper detected no speech")
        print("   Possible causes: mic too quiet, background noise, VAD filtered")

        # Retry without VAD
        print("\n   Retrying with VAD filter OFF...")
        try:
            segments2, info2 = model.transcribe(
                audio_path, language=language, beam_size=5, vad_filter=False,
            )
            segments_list2 = list(segments2)
            if segments_list2:
                full_text = " ".join(s.text.strip() for s in segments_list2)
                print(f"   Result without VAD: '{full_text}'")
                segments_list = segments_list2
            else:
                print("   Still no result without VAD")
        except Exception:
            pass

    if segments_list:
        full_text = " ".join(s.text.strip() for s in segments_list)
        print(f"   Full text: '{full_text}'")
        for seg in segments_list:
            print(f"   [{seg.start:.1f}s-{seg.end:.1f}s] '{seg.text.strip()}'")
    else:
        full_text = ""

    # Step 4: Wake word
    print("\n4. WAKE WORD")
    if not full_text:
        print("   SKIP: No text to check")
    else:
        print(f"   Text: '{full_text}'")
        detected = detect_wake_word(full_text)
        print(f"   Wake word detected: {'YES' if detected else 'NO'}")

        if not detected:
            first_word = full_text.split()[0].lower() if full_text.split() else "(empty)"
            print(f"   First word: '{first_word}'")
            print(f"   Expected: {', '.join(sorted(_WAKE_WORDS))}")
            print(f"   Tip: Add '{first_word}' to _WAKE_WORDS if it's a misrecognition")

        if detected:
            command = extract_command(full_text)
            print(f"   Extracted command: '{command}'")

    # Summary
    print(f"\n{'=' * 50}")
    print("SUMMARY:")
    if file_size < 5000:
        print("  PROBLEM: Mic issue - recording too small")
    elif not full_text:
        print("  PROBLEM: Whisper issue - no speech detected")
    elif not detect_wake_word(full_text):
        first = full_text.split()[0] if full_text.split() else "?"
        print(f"  PARTIAL: Speech works but wake word not recognized")
        print(f"  First word '{first}' not in wake word list")
    else:
        print("  ALL OK: Recording, transcription, and wake word working")

    _cleanup(audio_path)


def _cleanup(path: str):
    """Remove temp file silently."""
    try:
        os.remove(path)
    except OSError:
        pass
