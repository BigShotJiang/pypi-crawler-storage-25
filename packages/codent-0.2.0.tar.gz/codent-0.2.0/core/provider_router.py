# core/provider_router.py
"""Detect available LLM provider at startup (LM Studio primary, Ollama fallback)."""

import logging
from functools import lru_cache
from typing import Optional

import httpx
from openai import OpenAI

logger = logging.getLogger(__name__)

LM_STUDIO_BASE = "http://localhost:1234/v1"
OLLAMA_BASE = "http://localhost:11434/v1"
OLLAMA_PREFERRED_MODEL = "devstral"
HEALTH_TIMEOUT = 2.0


class ProviderUnavailableError(RuntimeError):
    """Raised when no LLM provider is available."""
    pass


def _check_provider(base_url: str, api_key: str = "none") -> Optional[list[str]]:
    """
    Check if a provider is alive at base_url.
    Returns list of model names if reachable, else None.
    """
    try:
        url = base_url.rstrip("/") + "/models"
        resp = httpx.get(url, timeout=HEALTH_TIMEOUT)
        if resp.status_code != 200:
            return None
        data = resp.json()
        models = [m["id"] for m in data.get("data", [])]
        return models if models else None
    except Exception:
        return None


def _pick_ollama_model(models: list[str]) -> str:
    """Pick devstral if available, otherwise first model."""
    for m in models:
        if OLLAMA_PREFERRED_MODEL in m:
            return m
    return models[0]


@lru_cache(maxsize=1)
def get_provider(
    *,
    lmstudio_base: Optional[str] = None,
    ollama_base: Optional[str] = None,
    api_key: str = "lmstudio",
    timeout: float = 120.0,
) -> tuple[OpenAI, str, str]:
    """
    Detect available provider once, cache result.

    Returns (client, model_name, provider_name).
    Raises ProviderUnavailableError if none available.
    """
    lm_url = lmstudio_base or LM_STUDIO_BASE
    ol_url = ollama_base or OLLAMA_BASE

    # 1. Try LM Studio
    models = _check_provider(lm_url)
    if models:
        model = models[0]
        client = OpenAI(
            base_url=lm_url,
            api_key=api_key,
            timeout=httpx.Timeout(timeout, connect=10.0),
        )
        logger.info("Provider: lmstudio | Model: %s", model)
        return client, model, "lmstudio"

    logger.warning("LM Studio unavailable, falling back to Ollama")

    # 2. Try Ollama
    models = _check_provider(ol_url)
    if models:
        model = _pick_ollama_model(models)
        client = OpenAI(
            base_url=ol_url,
            api_key="ollama",
            timeout=httpx.Timeout(timeout, connect=10.0),
        )
        logger.info("Provider: ollama | Model: %s", model)
        return client, model, "ollama"

    logger.error("No LLM provider available")
    raise ProviderUnavailableError(
        "No LLM provider available.\n"
        f"Tried: {lm_url}, {ol_url}\n"
        "Hint: Start LM Studio (port 1234) or Ollama (port 11434)."
    )
