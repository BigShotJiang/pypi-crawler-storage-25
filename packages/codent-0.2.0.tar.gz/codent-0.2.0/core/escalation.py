# core/escalation.py
"""
Claude Code CLI integration.
Delegates complex tasks to claude CLI subprocess.
No API key needed — uses existing Claude Code subscription.
"""

import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from datetime import datetime


# Complexity triggers (rule-based, no LLM)
# STRICT: Only escalate for explicit self-fix commands.
# Normal tasks (analiz, düzelt, incele, etc.) are handled locally.
COMPLEXITY_TRIGGERS = {
    "self_fix": [
        r"kendini.*(düzelt|tamir|fix|iyileştir|iyilestir)",
        r"self.?fix|fix.yourself",
    ],
    "repeated_failure": [],  # checked via failure_count >= 3
}


class ClaudeCodeEscalation:
    """Claude Code CLI integration."""

    def __init__(self):
        self.config_dir = Path.home() / ".config" / "cont"
        self.cost_log = self.config_dir / "claude_cli_log.jsonl"
        self.require_approval = True
        self._claude_path: Optional[str] = None
        self._available: Optional[bool] = None

        # Session tracking
        self.session_calls = 0
        self.session_start = time.time()

        # Rate limiting
        self.max_calls_per_hour = 20
        self._call_times: list = []

    @property
    def is_available(self) -> bool:
        """Is claude CLI installed and accessible?"""
        if self._available is not None:
            return self._available

        self._claude_path = shutil.which("claude")
        self._available = self._claude_path is not None

        if not self._available:
            # Check npm global path
            npm_path = Path.home() / ".npm-global" / "bin" / "claude"
            if npm_path.exists():
                self._claude_path = str(npm_path)
                self._available = True

        return self._available

    # Follow-up words that should never trigger escalation
    _FOLLOWUP_WORDS = {
        'evet', 'hayır', 'tamam', 'devam', 'analiz', 'özetle',
        'tekrar', 'göster', 'aç', 'oku', 'yap', 'et', 'yaz',
        'yes', 'no', 'ok', 'sure', 'do', 'it', 'them', 'show',
        'onları', 'bunu', 'şunu', 'bunları', 'onu', 'hepsini',
    }

    def should_escalate(self, task: str, local_failed: bool = False,
                        failure_count: int = 0) -> Tuple[bool, str]:
        """
        Should we send this task to Claude Code?
        STRICT: Only for explicit self-fix or repeated failures.
        Normal tasks (analiz, düzelt, incele, etc.) are handled locally.
        """
        if not self.is_available:
            return False, "Claude CLI not found"

        # Extract current task only (strip conversation history context)
        current_task = task
        if "<conversation_history>" in task:
            if "<current_request>" in task:
                start = task.index("<current_request>") + len("<current_request>")
                end = task.index("</current_request>") if "</current_request>" in task else len(task)
                current_task = task[start:end].strip()
            else:
                parts = task.split("</conversation_history>")
                if len(parts) > 1:
                    current_task = parts[-1].strip()

        task_lower = current_task.lower().strip()

        # Self-fix commands — explicit user request to escalate
        for category, patterns in COMPLEXITY_TRIGGERS.items():
            for pattern in patterns:
                if re.search(pattern, task_lower, re.IGNORECASE):
                    return True, f"Self-fix: {category}"

        # 3+ repeated failures on same task type
        if local_failed and failure_count >= 3:
            return True, f"Local model failed {failure_count} times"

        # Everything else → handle locally
        return False, ""

    def request_approval(self, task: str, reason: str) -> bool:
        """Ask user for approval."""
        print(f"\n{'─'*50}")
        print(f"SEND TO CLAUDE CODE?")
        print(f"{'─'*50}")
        print(f"Task: {task[:150]}{'...' if len(task) > 150 else ''}")
        print(f"Reason: {reason}")
        print(f"Session call: #{self.session_calls + 1}")
        print(f"{'─'*50}")

        try:
            response = input("Send? (y/n): ").strip().lower()
            return response in ('y', 'yes', 'e', 'evet', '')
        except (EOFError, KeyboardInterrupt):
            return False

    def _run_with_spinner(self, cmd, cwd, env, timeout=120):
        """Run subprocess with visual spinner showing elapsed time."""
        process = subprocess.Popen(
            cmd, cwd=cwd, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        stop = threading.Event()
        start = time.time()

        def spin():
            chars = itertools.cycle(['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'])
            while not stop.is_set():
                elapsed = int(time.time() - start)
                sys.stderr.write(f"\r  {next(chars)} Claude Code çalışıyor... ({elapsed}s) ")
                sys.stderr.flush()
                stop.wait(0.1)
            sys.stderr.write("\r" + " " * 50 + "\r")
            sys.stderr.flush()

        t = threading.Thread(target=spin, daemon=True)
        t.start()
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            stop.set()
            t.join(timeout=1)
            return process.returncode, stdout.strip(), stderr.strip()
        except subprocess.TimeoutExpired:
            process.kill()
            stop.set()
            t.join(timeout=1)
            return -1, "", "timeout"

    def call_claude(self, task: str, context: str = "",
                    working_dir: str = None,
                    mode: str = "general",
                    max_turns: int = 15) -> Dict[str, Any]:
        """
        Call Claude Code CLI.

        Modes:
        - general: Think + do (default permissions)
        - plan: Plan only, don't execute (read-only)
        - analyze: Analyze, don't touch files (read-only)
        - edit: Edit files (read+write)
        """
        if not self.is_available:
            return {"success": False, "error": "Claude CLI not found"}

        # Rate limiting
        self._cleanup_old_calls()
        if len(self._call_times) >= self.max_calls_per_hour:
            return {"success": False, "error": f"Rate limit: max {self.max_calls_per_hour}/hour"}

        # Self-fix tasks get special treatment: force edit mode + more turns
        is_self_fix = bool(re.search(
            r'kendini.*(düzelt|tamir|fix)|self.?fix|fix.yourself', task.lower()
        ))
        if is_self_fix:
            mode = "edit"
            max_turns = 30

        # Build prompt (rewrites self-fix tasks to be specific)
        prompt = self._build_prompt(task, context, mode)

        # Build CLI command
        cmd = [self._claude_path, "-p", prompt, "--output-format", "text"]

        # Max turns — edit mode needs more room to read/analyze/write
        effective_turns = max_turns
        if mode == "edit" and max_turns == 15:  # default wasn't overridden
            effective_turns = 20
        cmd.extend(["--max-turns", str(effective_turns)])

        # Mode-based permissions
        if mode in ("analyze", "plan"):
            cmd.extend(["--allowedTools", "Read,Bash(read-only)"])
        elif mode == "edit":
            cmd.extend(["--allowedTools", "Read,Write,Edit,Bash"])
        # general → default permissions

        # Working directory — ALWAYS prefer project root over model's navigated dir
        if working_dir:
            cwd = working_dir
        else:
            # Try CONT_REPO_ROOT env, then fall back to script's directory
            cwd = os.environ.get("CONT_REPO_ROOT") or str(Path(__file__).resolve().parent.parent)

        # Build env: inherit but unset CLAUDECODE to avoid nested session error
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        # Execute with spinner feedback
        print(f"[ESCALATION] Running: {' '.join(cmd)}", file=sys.stderr)
        print(f"[ESCALATION] cwd: {cwd}", file=sys.stderr)
        start_time = time.time()
        try:
            returncode, output, error = self._run_with_spinner(cmd, cwd, env, timeout=120)

            duration = time.time() - start_time
            self._call_times.append(time.time())
            self.session_calls += 1

            # Debug logging
            print(f"[ESCALATION] returncode: {returncode}, output_len: {len(output)}", file=sys.stderr)
            if returncode != 0:
                print(f"[ESCALATION] stderr: {error[:500]}", file=sys.stderr)
            if not output and returncode == 0:
                print(f"[ESCALATION] Warning: returncode=0 but empty output", file=sys.stderr)

            # Handle timeout
            if returncode == -1:
                return {"success": False, "error": "timeout", "silent_fallback": True}

            # Log
            self._log_call(task, mode, duration, len(output), returncode)

            if returncode == 0 and output:
                return {
                    "success": True,
                    "output": output,
                    "duration_sec": round(duration, 1),
                    "mode": mode,
                }
            else:
                return {
                    "success": False,
                    "error": error or "Claude Code returned empty response",
                    "output": output,
                    "duration_sec": round(duration, 1),
                }

        except FileNotFoundError:
            self._available = False
            return {"success": False, "error": "Claude CLI not found"}
        except Exception as e:
            return {"success": False, "error": f"Error: {e}"}

    def _get_self_fix_context(self) -> str:
        """Gather recent errors and logs for self-fix tasks."""
        context_parts = []

        # Recent failures from DB
        try:
            import sqlite3
            db_path = Path.home() / ".cont" / "memory.sqlite"
            if db_path.exists():
                db = sqlite3.connect(str(db_path))
                cur = db.cursor()
                cur.execute(
                    "SELECT task_text, failure_reason, created_at "
                    "FROM task_outcome "
                    "WHERE success = 0 "
                    "ORDER BY created_at DESC LIMIT 3"
                )
                rows = cur.fetchall()
                if rows:
                    context_parts.append("Son basarisiz gorevler:")
                    for r in rows:
                        context_parts.append(f"  [{r[2]}] {r[0][:100]}: {r[1] or 'bilinmiyor'}")
                db.close()
        except Exception:
            pass

        # Recent log file
        try:
            log_dir = Path.cwd() / "logs" / "cont_runs"
            if log_dir.exists():
                logs = sorted(log_dir.glob("*.jsonl"),
                              key=lambda f: f.stat().st_mtime, reverse=True)
                if logs:
                    lines = logs[0].read_text(encoding="utf-8").splitlines()[-5:]
                    context_parts.append(f"\nSon log ({logs[0].name}):")
                    for line in lines:
                        context_parts.append(f"  {line[:200]}")
        except Exception:
            pass

        return "\n".join(context_parts) if context_parts else ""

    def _build_prompt(self, task: str, context: str, mode: str) -> str:
        """Build prompt based on mode."""
        parts = []

        # Self-fix: rewrite vague task to be specific
        is_self_fix = bool(re.search(
            r'kendini.*(düzelt|tamir|fix)|self.?fix|fix.yourself', task.lower()
        ))
        if is_self_fix:
            fix_context = self._get_self_fix_context()
            if fix_context:
                task = (
                    "Bu projedeki son hataları düzelt. "
                    "Her hatayı tek tek incele, kök nedeni bul, düzelt ve test et.\n\n"
                    f"{fix_context}"
                )
            else:
                task = (
                    "Bu projeyi incele: cont.py ve core/ altındaki dosyalar. "
                    "py_compile ile kontrol et, hata varsa düzelt. "
                    "Linting yap, bariz sorunları bul ve düzelt."
                )

        if mode == "plan":
            parts.append("ONLY PLAN, do NOT modify any files.")
            parts.append("List step-by-step what needs to be done.")
            parts.append("For each step, specify which file changes and how.")
        elif mode == "analyze":
            parts.append("ONLY ANALYZE, do NOT modify any files.")
            parts.append("Report findings in a clear, structured way.")
        elif mode == "edit":
            parts.append("Make the necessary file edits.")
            parts.append("After each change, verify with py_compile if it's Python.")

        parts.append(f"\nTask: {task}")

        if context:
            parts.append(f"\nContext:\n{context}")

        return "\n".join(parts)

    def _cleanup_old_calls(self):
        cutoff = time.time() - 3600
        self._call_times = [t for t in self._call_times if t > cutoff]

    def _log_call(self, task: str, mode: str, duration: float,
                  output_len: int, returncode: int):
        try:
            self.cost_log.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "timestamp": datetime.now().isoformat(),
                "task": task[:200],
                "mode": mode,
                "duration_sec": round(duration, 1),
                "output_length": output_len,
                "returncode": returncode,
            }
            with open(self.cost_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def get_stats(self) -> str:
        """CLI usage statistics."""
        if not self.cost_log.exists():
            return "No Claude Code calls recorded yet."

        calls = []
        for line in self.cost_log.read_text(encoding="utf-8").splitlines():
            try:
                calls.append(json.loads(line))
            except Exception:
                continue

        if not calls:
            return "Log is empty."

        total = len(calls)
        success = sum(1 for c in calls if c.get("returncode") == 0)
        avg_duration = sum(c.get("duration_sec", 0) for c in calls) / total

        modes: Dict[str, int] = {}
        for c in calls:
            m = c.get("mode", "unknown")
            modes[m] = modes.get(m, 0) + 1

        lines = [
            f"Total Claude Code calls: {total}",
            f"Successful: {success}/{total}",
            f"Average duration: {avg_duration:.1f}s",
            "By mode:",
        ]
        for m, count in sorted(modes.items()):
            lines.append(f"  {m}: {count}")

        return "\n".join(lines)


# Singleton
_escalation: Optional[ClaudeCodeEscalation] = None


def get_escalation() -> ClaudeCodeEscalation:
    global _escalation
    if _escalation is None:
        _escalation = ClaudeCodeEscalation()
    return _escalation
