# core/teacher.py
"""
ChatGPT Teacher for recipe generation.

When Cont encounters an unknown task pattern, it asks a strong
external model (GPT-4o-mini) to create a recipe that the small
local model can follow.

The teacher:
1. Knows the student is a 30B model with limited capabilities
2. Produces parametric recipes with student contracts
3. Recipes are validated on first execution
4. Successful recipes are saved permanently

Usage:
  recipe = teacher.learn_recipe(task_input, context, api_key)

Config:
  API key stored in ~/.config/cont/openai_key
  Or env: OPENAI_API_KEY
"""

import json
import os
import re
import time
from typing import Optional, Dict
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "cont"

# Rate limiting: prevent excessive teacher calls
_teacher_last_call: float = 0.0
_teacher_session_count: int = 0
TEACHER_COOLDOWN_SEC = 300   # 5 min between auto-learn calls
TEACHER_SESSION_MAX = 3      # Max 3 teacher calls per session


TEACHER_SYSTEM_PROMPT = """\
Sen bir "recipe üretici"sin. Küçük bir dil modeli için görev reçeteleri yazıyorsun.

ÖĞRENCİ MODELİN PROFİLİ:
- 30B parametre, 8K context window
- Tool calling yapabiliyor ama sık yanlış kullanıyor
- Aynı tool'u gereksiz yere tekrar çağırma eğilimi var
- Tool sonuçlarını bazen yok sayıp hallucinate ediyor
- Türkçe anlıyor ama İngilizce talimatları daha iyi takip ediyor
- "Erişemiyorum/yapamıyorum" deme eğilimi var
- Sistem prefetch ile bazı bilgileri önceden alır (CWD, hafıza, dizin listesi)

ÖĞRENCİNİN KULLANABİLECEĞİ TOOL'LAR:
- read_file(path) — dosya oku
- edit_file(path, old_str, new_str) — dosya düzenle
- list_dir(path) — dizin listele
- run_shell(cmd) — shell komutu çalıştır (güvenlik kısıtlı)
- system_search(query) — dosya sistemi indeksinde ara
- web_search(query) — web'de ara
- web_fetch(url) — URL'den içerik çek
- browser_open(url) — tarayıcıda sayfa aç (JS destekli siteler için)
- browser_click(selector) — tarayıcıda elemente tıkla
- browser_type(selector, text) — tarayıcıda input'a yaz
- browser_text(selector?) — sayfadan metin çek
- browser_agent(url, goal) — otonom tarayıcı navigasyonu (çok adımlı web görevleri için)
- recall(query) — hafızadan bilgi ara
- remember(content) — hafızaya kaydet
- find_path(query) — akıllı yol bulucu
- where_am_i() — mevcut konum

ÖNEMLİ: Web görevleri için browser_agent EN ETKİLİ araçtır. web_fetch basit sayfalar
için, browser_agent JS-ağırlıklı ve çok adımlı siteler için kullanılmalı.

RECIPE FORMATI (strict JSON):
{
  "id": "benzersiz_isim_v1",
  "pattern_keywords": {
    "anahtar_kelime": puan,
    "keyword": puan
  },
  "threshold": 4.0,
  "description": "tek cümle açıklama",
  "variables": ["param1", "param2"],
  "steps": [
    {
      "action": "tool_adı",
      "args": {"arg": "{değişken}"},
      "expect": "beklenen sonuç",
      "on_fail": "hata durumunda ne yap"
    }
  ],
  "student_contract": [
    "ASLA ... yapma",
    "EĞER ... ise ... yap"
  ],
  "estimated_tools": 3,
  "success_criteria": {
    "response_contains_any": ["beklenen", "kelimeler"],
    "min_response_words": 20,
    "max_tools": 5
  }
}

KRİTİK KURALLAR:
- SADECE JSON üret, başka hiçbir şey yazma
- Adımlar AÇIK ve KESİN olsun
- Her adımda beklenen sonucu belirt
- student_contract ile öğrencinin bilinen hatalarını ÖNCEDEN engelle
- pattern_keywords Türkçe + İngilizce karışık olsun
- estimated_tools gerçekçi olsun (genelde 2-4)
- success_criteria mutlaka ekle
- id benzersiz ve açıklayıcı olsun (snake_case_v1)"""


def get_api_key():
    """Get OpenAI API key from config or environment.

    Priority: CONT_OPENAI_KEY env → config file → OPENAI_API_KEY env.
    OPENAI_API_KEY is checked last because it's often set to 'lmstudio'
    for the local LLM and would incorrectly override the real key.
    """
    # 1. Dedicated env var (always the real OpenAI key)
    key = os.environ.get("CONT_OPENAI_KEY")
    if key:
        return key

    # 2. Config file (saved via --setup-openai)
    key_file = CONFIG_DIR / "openai_key"
    if key_file.exists():
        stored = key_file.read_text().strip()
        if stored:
            return stored

    # 3. Fallback: OPENAI_API_KEY (skip if it's a local LLM placeholder)
    key = os.environ.get("OPENAI_API_KEY", "")
    if key and key.startswith("sk-"):
        return key

    return None


def set_api_key(key):
    """Save OpenAI API key to config."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    key_path = CONFIG_DIR / "openai_key"
    key_path.write_text(key.strip())
    os.chmod(key_path, 0o600)


def _call_openai(prompt, api_key, model="gpt-4o-mini", max_tokens=1500):
    """Call OpenAI API. Returns response text."""
    import httpx

    response = httpx.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": model,
            "messages": [
                {"role": "system", "content": TEACHER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": max_tokens,
            "temperature": 0.3,
        },
        timeout=30,
    )

    if response.status_code != 200:
        raise Exception(
            f"OpenAI API error {response.status_code}: "
            f"{response.text[:200]}"
        )

    data = response.json()
    return data["choices"][0]["message"]["content"]


def _parse_recipe_json(text):
    """Extract and parse JSON from API response."""
    text = text.strip()

    # Remove markdown code fences
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines).strip()

    # Try to find JSON object
    match = re.search(r'\{[\s\S]+\}', text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    # Last resort: direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _build_context_prompt(task_input, context=None, failed_episode=None):
    """Build the user prompt for the teacher."""
    parts = [f"GÖREV: {task_input}"]

    if context:
        if context.get("cwd"):
            parts.append(f"CWD: {context['cwd']}")
        if context.get("repo_root"):
            parts.append(f"Repo root: {context['repo_root']}")
        if context.get("prefetch_summary"):
            parts.append(f"Prefetch: {context['prefetch_summary']}")
        if context.get("memory_summary"):
            parts.append(f"Hafıza: {context['memory_summary']}")
        if context.get("matched_recipe_id"):
            parts.append(f"Eşleşen recipe: {context['matched_recipe_id']}")
            _kw = context.get("matched_recipe_keywords")
            if _kw:
                parts.append(f"  Keywords: {_kw}")
        if context.get("run_id"):
            parts.append(f"Run ID: {context['run_id']}")

    if failed_episode:
        parts.append(f"\nÖNCEKİ BAŞARISIZ DENEME:")
        parts.append(
            f"  Tool sayısı: {failed_episode.get('tools_used', '?')}"
        )
        parts.append(
            f"  Tool'lar: {failed_episode.get('tool_names', '?')}"
        )
        parts.append(
            f"  Hata: {failed_episode.get('error', 'bilinmiyor')}"
        )
        parts.append(
            f"  Yanıt: {failed_episode.get('response_preview', '')[:100]}"
        )

    parts.append("\nBu görev için bir recipe üret.")

    return "\n".join(parts)


def learn_recipe(task_input, context=None, failed_episode=None,
                 api_key=None, model="gpt-4o-mini"):
    """
    Ask the teacher to generate a recipe for an unknown task.

    Returns: parsed recipe dict or None
    """
    global _teacher_last_call, _teacher_session_count

    if api_key is None:
        api_key = get_api_key()

    if not api_key:
        return None

    prompt = _build_context_prompt(task_input, context, failed_episode)

    # Track rate limiting
    _teacher_last_call = time.time()
    _teacher_session_count += 1

    try:
        print("  🎓 Teacher'a soruluyor...")
        response_text = _call_openai(prompt, api_key, model=model)

        recipe = _parse_recipe_json(response_text)
        if not recipe:
            print("  ⚠️ Teacher yanıtı parse edilemedi")
            return None

        # Validate required fields
        required = ["id", "pattern_keywords", "steps"]
        for field in required:
            if field not in recipe:
                print(f"  ⚠️ Recipe'de '{field}' alanı eksik")
                return None

        # Ensure defaults
        recipe.setdefault("threshold", 4.0)
        recipe.setdefault("description", task_input[:50])
        recipe.setdefault("variables", [])
        recipe.setdefault("student_contract", [])
        recipe.setdefault("estimated_tools", 3)
        recipe.setdefault("success_criteria", {})
        recipe["source"] = "teacher"
        recipe["created_at"] = time.time()

        print(f"  ✅ Recipe öğrenildi: {recipe['id']}")
        return recipe

    except ImportError:
        print("  ⚠️ httpx gerekli: pip install httpx")
        return None
    except Exception as e:
        print(f"  ⚠️ Teacher hatası: {str(e)[:100]}")
        return None


def learn_and_save(task_input, recipe_conn, context=None,
                   failed_episode=None, api_key=None):
    """
    Learn a recipe and save it to the database.
    Returns the recipe or None.
    """
    from core.recipes import add_recipe

    recipe = learn_recipe(task_input, context, failed_episode, api_key)

    if recipe:
        try:
            add_recipe(recipe, recipe_conn)
            print(f"  📦 Recipe kaydedildi: {recipe['id']}")
            return recipe
        except Exception as e:
            print(f"  ⚠️ Recipe kaydedilemedi: {e}")

    return None


def should_learn(task_input, episode=None, recipe_match=None,
                 *, browser_agent_success=False, explicit_teach=False):
    """
    STRICT GATE: Only learn from verified success.

    YES: browser_agent returned verified content (success=True)
    YES: user explicitly used /teach (explicit_teach=True)

    NO: everything else. Failed tasks produce junk recipes.
    """
    global _teacher_last_call, _teacher_session_count

    if not get_api_key():
        return False

    # Rate limit: cooldown
    if time.time() - _teacher_last_call < TEACHER_COOLDOWN_SEC:
        return False

    # Rate limit: per-session cap
    if _teacher_session_count >= TEACHER_SESSION_MAX:
        return False

    # Skip very short/simple inputs
    if len(task_input.split()) < 3:
        return False

    # Skip commands
    if task_input.startswith("/"):
        return False

    # If recipe matched and is working, no need
    if recipe_match and recipe_match.get("success_count", 0) > 0:
        return False

    # Explicit /teach command — always allow
    if explicit_teach:
        return True

    # Verified browser_agent success — content was actually extracted
    if browser_agent_success:
        return True

    # STRICT: block everything else
    # Failed tasks, fastpath errors, greeting responses — NEVER learn
    return False
