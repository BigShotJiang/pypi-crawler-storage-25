# core/auto_eval.py
"""
Automatic task evaluation.

Checks task output against simple rules to determine success.
No LLM needed — purely deterministic.
"""

import re
from typing import Dict, Optional


def evaluate_task(task_input: str, response: str,
                  tools_used: int = 0, tool_names: list = None,
                  task_type: str = "llm",
                  recipe_id: str = None,
                  recipe_criteria: dict = None) -> Dict:
    """
    Evaluate if a task succeeded based on heuristics.

    Returns: {
        "success": True/False/None (uncertain),
        "confidence": 0.0-1.0,
        "reasons": ["reason1", "reason2"],
        "score": 0-100,
    }
    """
    reasons = []
    score = 50  # Start neutral

    if not response:
        return {"success": False, "confidence": 0.9,
                "reasons": ["Boş yanıt"], "score": 0}

    response_lower = response.lower()
    input_words = len(task_input.split())
    response_words = len(response.split())

    # === NEGATIVE signals ===

    # 1. Greeting instead of answer
    greeting_patterns = [
        r'^(merhaba|selam|hello|hi)\b',
        r'size nasıl yardımcı olabilirim',
        r'how can i (help|assist)',
        r'nasıl yardımcı olabilirim',
    ]
    for p in greeting_patterns:
        if re.search(p, response_lower):
            score -= 30
            reasons.append("Cevap yerine selamlama")

    # 2. Denial / inability
    denial_patterns = [
        r'erişemiyorum', r'yapamıyorum', r'okuyamıyorum',
        r'bulamıyorum', r'cannot access', r'unable to',
        r'i don.t have access', r'iznim yok',
    ]
    for p in denial_patterns:
        if re.search(p, response_lower):
            score -= 25
            reasons.append(f"Erişememe ifadesi: {p}")

    # 3. Raw JSON/tool dump in response
    if response.strip().startswith('[{"') or response.strip().startswith('{"'):
        if len(response) > 100:
            score -= 20
            reasons.append("Ham JSON dump")

    # 4. Too short for complex task
    if input_words > 5 and response_words < 10:
        score -= 15
        reasons.append("Çok kısa yanıt")

    # 5. Capabilities dump instead of answer
    if "tool budget" in response_lower or "capabilities" in response_lower:
        if "available tools" in response_lower:
            score -= 30
            reasons.append("Yetenek listesi döktü, görevi yapmadı")

    # 6. Excessive tool usage
    if tools_used > 8:
        score -= 10
        reasons.append(f"Çok fazla tool: {tools_used}")

    # 6.5 Hallucinated law numbers (specific number without any tool usage)
    if tools_used == 0:
        _fake_law = re.search(r'(?:Kanun(?:u)?|No)\s*[:.]?\s*\d{4,5}', response)
        if _fake_law:
            score -= 10
            reasons.append("Tool kullanmadan kanun numarası — hallucination olabilir")

    # === POSITIVE signals ===

    # 7. Fastpath = reliable
    if task_type == "fastpath":
        score += 20
        reasons.append("Fastpath ile çözüldü")

    # 8. Recipe executed = structured
    if task_type == "recipe":
        score += 15
        reasons.append("Recipe ile çözüldü")

    # 9. Contains structured content (tables, lists, code)
    if '|' in response and '---' in response:
        score += 10
        reasons.append("Tablo formatında yanıt")
    if '```' in response:
        score += 5
        reasons.append("Kod bloğu içeriyor")

    # 10. File content was shown (for read tasks)
    if 'dosya' in task_input.lower() or 'oku' in task_input.lower():
        if any(kw in response_lower for kw in ['import', 'def ', 'class ', 'function']):
            score += 15
            reasons.append("Dosya içeriği gösterildi")

    # 11. Path mentioned (for find/list tasks)
    if any(kw in task_input.lower() for kw in ['bul', 'listele', 'göster', 'nerede']):
        if re.search(r'/[\w/.-]+', response):
            score += 10
            reasons.append("Dosya yolu gösterildi")

    # 12. Efficient tool usage
    if 0 < tools_used <= 3:
        score += 10
        reasons.append(f"Verimli tool kullanımı: {tools_used}")

    # 13. Reasonable response length
    if 20 < response_words < 500:
        score += 5
        reasons.append("Uygun uzunlukta yanıt")

    # === RECIPE CRITERIA ===
    if recipe_criteria:
        if "response_contains_any" in recipe_criteria:
            found = any(kw in response_lower
                        for kw in recipe_criteria["response_contains_any"])
            if found:
                score += 15
                reasons.append("Recipe kriteri karşılandı")
            else:
                score -= 15
                reasons.append("Recipe kriteri karşılanmadı")

        if "min_response_words" in recipe_criteria:
            if response_words >= recipe_criteria["min_response_words"]:
                score += 5
            else:
                score -= 10
                reasons.append(
                    f"Yanıt çok kısa (min: {recipe_criteria['min_response_words']})"
                )

        if "max_tools" in recipe_criteria:
            if tools_used <= recipe_criteria["max_tools"]:
                score += 5
            else:
                score -= 10
                reasons.append(
                    f"Çok fazla tool (max: {recipe_criteria['max_tools']})"
                )

    # Clamp score
    score = max(0, min(100, score))

    # Determine success
    if score >= 60:
        success = True
    elif score <= 30:
        success = False
    else:
        success = None  # Uncertain

    confidence = abs(score - 50) / 50  # 0-1 based on distance from neutral

    return {
        "success": success,
        "confidence": round(confidence, 2),
        "reasons": reasons,
        "score": score,
    }
