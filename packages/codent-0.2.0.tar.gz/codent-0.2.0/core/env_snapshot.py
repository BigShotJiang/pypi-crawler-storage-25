# core/env_snapshot.py
"""Environment Snapshot collection for --doctor diagnostics."""

import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from core.utils import CONT_DIR

ENV_SNAPSHOT_DIR = CONT_DIR / "logs" / "env_snapshots"

_REPO_ROOT = Path(os.environ.get("CONT_REPO_ROOT", os.getcwd())).resolve()


def _probe_cmd(cmd_list: list, timeout: float = 3.0) -> tuple[bool, str]:
    """Run a command with short timeout. Returns (ok, stdout_str)."""
    try:
        result = subprocess.run(
            cmd_list,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return (result.returncode == 0, result.stdout)
    except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
        return (False, "")

def _parse_os_release() -> dict:
    """Parse /etc/os-release into a dict."""
    result = {}
    try:
        p = Path("/etc/os-release")
        if p.exists():
            for line in p.read_text().splitlines():
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    key, _, val = line.partition("=")
                    # Remove quotes
                    val = val.strip('"').strip("'")
                    result[key] = val
    except Exception:
        pass
    return result

def _get_conda_info() -> dict:
    """Get conda environment info."""
    result = {"available": False, "active_env": None, "envs": None}

    # Check if conda is available
    if not shutil.which("conda"):
        return result

    result["available"] = True
    result["active_env"] = os.environ.get("CONDA_DEFAULT_ENV")

    # Try to get list of envs
    ok, out = _probe_cmd(["conda", "info", "-e"], timeout=3.0)
    if ok:
        envs = []
        for line in out.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                parts = line.split()
                if parts:
                    envs.append(parts[0])
        result["envs"] = envs

    return result

def _get_gpu_info() -> dict:
    """Get GPU info via nvidia-smi."""
    result = {"nvidia_smi": False, "gpus": None}

    if not shutil.which("nvidia-smi"):
        return result

    result["nvidia_smi"] = True
    ok, out = _probe_cmd(["nvidia-smi", "-L"], timeout=3.0)
    if ok:
        gpus = [line.strip() for line in out.splitlines() if line.strip()]
        result["gpus"] = gpus

    return result

def _get_ports_info() -> dict:
    """Check listening ports using ss or netstat."""
    result = {"listening_4010": False, "listening_1234": False, "raw": None}

    raw_output = None

    # Try ss first, then netstat
    if shutil.which("ss"):
        ok, out = _probe_cmd(["ss", "-lntp"], timeout=3.0)
        if ok:
            raw_output = out
    elif shutil.which("netstat"):
        ok, out = _probe_cmd(["netstat", "-lntp"], timeout=3.0)
        if ok:
            raw_output = out

    if raw_output:
        # Check for ports in output
        result["listening_4010"] = ":4010" in raw_output or ":4010 " in raw_output
        result["listening_1234"] = ":1234" in raw_output or ":1234 " in raw_output

        # Truncate raw output - last 40 lines, max 4000 chars
        lines = raw_output.splitlines()
        tail = "\n".join(lines[-40:])
        if len(tail) > 4000:
            tail = tail[:4000] + "\n... (truncated)"
        result["raw"] = tail

    return result

def collect_env_snapshot() -> dict:
    """Collect full environment snapshot for --doctor."""
    import getpass
    import platform

    snapshot = {
        "timestamp": datetime.now().isoformat(),
        "repo_root": str(_REPO_ROOT),
        "cwd": os.getcwd(),
        "user": getpass.getuser(),
        "host": platform.node(),
        "os_release": _parse_os_release(),
        "uname": None,
        "python": {
            "executable": sys.executable,
            "version": sys.version.split()[0]
        },
        "conda": _get_conda_info(),
        "gpu": _get_gpu_info(),
        "ports": _get_ports_info(),
        "env_vars": {
            "CONT_REPO_ROOT": os.environ.get("CONT_REPO_ROOT", ""),
            "OPENAI_BASE_URL": os.environ.get("OPENAI_BASE_URL", ""),
            "OPENAI_API_KEY_set": bool(os.environ.get("OPENAI_API_KEY")),
            "CONT_TOOL_BUDGET": os.environ.get("CONT_TOOL_BUDGET", ""),
            "CONT_MODEL": os.environ.get("CONT_MODEL", ""),
            "CONT_TIMEOUT": os.environ.get("CONT_TIMEOUT", ""),
            "CONT_MAX_STEPS": os.environ.get("CONT_MAX_STEPS", ""),
            "CONT_LOG_LEVEL": os.environ.get("CONT_LOG_LEVEL", ""),
        }
    }

    # Get uname
    ok, out = _probe_cmd(["uname", "-a"], timeout=2.0)
    if ok:
        snapshot["uname"] = out.strip()

    return snapshot

def save_env_snapshot(snapshot: dict) -> Path:
    """Save snapshot to logs/env_snapshots/ directory."""
    ENV_SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = ENV_SNAPSHOT_DIR / f"{ts}_env.json"
    with open(filepath, "w") as f:
        json.dump(snapshot, f, indent=2)
    return filepath
