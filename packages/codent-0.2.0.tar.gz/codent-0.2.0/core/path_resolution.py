# core/path_resolution.py
"""Smart path resolution for WSL — normalize, resolve, fuzzy-find paths."""

import os
import re
from pathlib import Path

from core.utils import debug as _debug


def _is_wsl_environment() -> bool:
    """Check if running in WSL."""
    try:
        with open("/proc/version", "r") as f:
            return "microsoft" in f.read().lower()
    except Exception:
        return False

IS_WSL = _is_wsl_environment()


def normalize_path(path: str) -> str:
    """
    Normalize any path format to Linux-native path.

    Handles:
    - ~ (tilde expansion)
    - \\\\wsl.localhost\\Ubuntu\\... (WSL network path)
    - \\\\wsl$\\Ubuntu\\... (older WSL network path)
    - C:\\Users\\... (Windows path)
    - /mnt/c/Users/... (already correct)
    - Backslashes -> forward slashes
    """
    if not path:
        return "."

    original = path

    # Step 1: Handle tilde
    if path.startswith("~"):
        path = os.path.expanduser(path)

    # Step 2: Handle WSL network paths (\\wsl.localhost\Ubuntu\... or \\wsl$\Ubuntu\...)
    wsl_patterns = [
        r"^\\\\wsl\.localhost\\Ubuntu\\?",
        r"^\\\\wsl\.localhost\\[^\\]+\\?",  # Any distro
        r"^\\\\wsl\$\\Ubuntu\\?",
        r"^\\\\wsl\$\\[^\\]+\\?",  # Any distro
        r"^//wsl\.localhost/Ubuntu/?",
        r"^//wsl\.localhost/[^/]+/?",
        r"^//wsl\$/Ubuntu/?",
        r"^//wsl\$/[^/]+/?",
    ]

    for pattern in wsl_patterns:
        match = re.match(pattern, path, re.IGNORECASE)
        if match:
            # Remove the WSL prefix, keep the rest
            path = path[match.end():]
            # Ensure it starts with /
            if not path.startswith("/"):
                path = "/" + path
            break

    # Step 3: Convert backslashes to forward slashes
    path = path.replace("\\", "/")

    # Step 4: Handle Windows drive letters (C:/Users/... -> /mnt/c/Users/...)
    drive_match = re.match(r"^([A-Za-z]):/", path)
    if drive_match:
        drive_letter = drive_match.group(1).lower()
        path = f"/mnt/{drive_letter}/" + path[3:]

    # Step 5: Clean up double slashes
    while "//" in path:
        path = path.replace("//", "/")

    # Step 6: Remove trailing slash (except for root)
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    _debug(f"Path normalized: {original} -> {path}")

    return path


def resolve_path(path: str, base: str = None) -> Path:
    """
    Resolve path to absolute Path object.

    1. Normalize the path format
    2. Make absolute (relative to base or cwd)
    3. Return Path object
    """
    # Normalize first
    path = normalize_path(path)

    # Convert to Path
    p = Path(path)

    # Make absolute if relative
    if not p.is_absolute():
        if base:
            p = Path(base) / p
        else:
            p = Path.cwd() / p

    return p


def path_exists_fuzzy(path: str) -> tuple:
    """
    Try to find a path using multiple strategies.

    Returns: (resolved_path: str or None, tried_paths: list)
    """
    tried = []

    # Strategy 1: Direct normalized path
    normalized = normalize_path(path)
    tried.append(normalized)
    if Path(normalized).exists():
        return normalized, tried

    # Strategy 2: From home directory
    if not path.startswith("/") and not path.startswith("~"):
        home_path = str(Path.home() / path)
        tried.append(home_path)
        if Path(home_path).exists():
            return home_path, tried

    # Strategy 3: From cont home (lazy import to avoid circular deps)
    try:
        from core.identity import get_cont_home
        cont_home = get_cont_home()
        cont_relative = str(cont_home / path)
        tried.append(cont_relative)
        if Path(cont_relative).exists():
            return cont_relative, tried
    except Exception:
        pass

    # Strategy 4: Common project locations
    common_bases = [
        Path.home() / "projects",
        Path.home(),
        Path("/mnt/c/Users") / os.environ.get("USER", "user"),
    ]

    # Extract potential relative part
    relative_part = path
    for prefix in ["/home/", "~/", "projects/", "/mnt/c/Users/"]:
        if prefix in path:
            idx = path.find(prefix) + len(prefix)
            remaining = path[idx:]
            if "/" in remaining:
                relative_part = remaining.split("/", 1)[-1] if prefix == "/home/" else remaining

    for base in common_bases:
        if base.exists():
            test_path = base / relative_part
            tried.append(str(test_path))
            if test_path.exists():
                return str(test_path), tried

    return None, tried
