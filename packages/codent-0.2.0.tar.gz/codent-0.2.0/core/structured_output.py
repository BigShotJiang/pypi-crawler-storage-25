# core/structured_output.py
"""
Parse and validate structured output from model responses.
"""

import re
from dataclasses import dataclass
from typing import Optional

@dataclass
class StructuredResponse:
    """Parsed structured response."""
    verified_facts: list[str]
    actions_taken: list[str]
    unverified_info: list[str]
    answer: str
    raw: str
    is_valid_format: bool
    format_errors: list[str]


def parse_structured_response(response: str) -> StructuredResponse:
    """
    Parse a response that should follow the structured format.
    """
    errors = []

    # Initialize sections
    verified_facts = []
    actions_taken = []
    unverified_info = []
    answer = ""

    # Try to find sections
    sections = {
        "verified_facts": r"##\s*Verified Facts\s*\n(.*?)(?=##|\Z)",
        "actions_taken": r"##\s*Actions Taken\s*\n(.*?)(?=##|\Z)",
        "unverified": r"##\s*Unverified.*?\n(.*?)(?=##|\Z)",
        "answer": r"##\s*Answer\s*\n(.*?)(?=##|\Z)",
    }

    for section_name, pattern in sections.items():
        match = re.search(pattern, response, re.DOTALL | re.IGNORECASE)
        if match:
            content = match.group(1).strip()
            lines = [l.strip() for l in content.split('\n') if l.strip()]

            if section_name == "verified_facts":
                verified_facts = [l.lstrip('- ') for l in lines if l.startswith('-')]
            elif section_name == "actions_taken":
                actions_taken = [l.lstrip('- ') for l in lines if l.startswith('-')]
            elif section_name == "unverified":
                unverified_info = [l.lstrip('- ') for l in lines if l.startswith('-')]
            elif section_name == "answer":
                answer = content

    # Check if format is valid
    is_valid = True

    if not verified_facts and not actions_taken:
        # If no tool usage, this might be acceptable
        if "[" in response and "(" in response:  # Looks like it has tool references
            errors.append("Missing '## Verified Facts' section")
            is_valid = False

    if not answer:
        # Try to find answer in unstructured response
        answer = response
        if "##" in response:
            errors.append("Missing '## Answer' section")
            # Don't mark invalid, just warn

    return StructuredResponse(
        verified_facts=verified_facts,
        actions_taken=actions_taken,
        unverified_info=unverified_info,
        answer=answer,
        raw=response,
        is_valid_format=is_valid,
        format_errors=errors
    )


def validate_tool_citations(response: str) -> list[str]:
    """
    Check that factual claims have tool citations.
    Returns list of uncited claims.
    """
    uncited = []

    # Sentences that look like factual claims
    claim_patterns = [
        r"(?:file|directory)\s+['\"]?[\w./]+['\"]?\s+(?:contains?|has|exists?|shows?)",
        r"(?:created?|wrote|modified)\s+(?:the\s+)?file",
        r"the\s+(?:code|content|output)\s+(?:shows?|contains?|has)",
        r"(?:found|discovered)\s+(?:a\s+)?(?:file|function|class|error)",
    ]

    for pattern in claim_patterns:
        for match in re.finditer(pattern, response, re.IGNORECASE):
            # Get the sentence containing this claim
            start = max(0, match.start() - 100)
            end = min(len(response), match.end() + 100)
            context = response[start:end]

            # Check if there's a tool citation nearby
            if not re.search(r'\[(?:read_file|list_dir|write_file|run_shell|search_files)\(', context):
                # Get just the sentence
                sentence_match = re.search(r'[^.!?]*' + re.escape(match.group(0)) + r'[^.!?]*[.!?]?', response)
                if sentence_match:
                    uncited.append(sentence_match.group(0).strip())

    return uncited
