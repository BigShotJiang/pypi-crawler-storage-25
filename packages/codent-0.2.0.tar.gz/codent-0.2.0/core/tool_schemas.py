# core/tool_schemas.py
"""Tool JSON schemas for OpenAI-compatible function calling."""

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "List contents of a directory. Use recursive=true to see all files in subdirectories (tree view).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path from repo root. Default is '.' (root).",
                        "default": "."
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "If true, list all files recursively up to max_depth levels deep.",
                        "default": False
                    },
                    "max_depth": {
                        "type": "integer",
                        "description": "Maximum depth for recursive listing. Default 2, max 5.",
                        "default": 2
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path to the file from repo root."
                    }
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a file, creating parent directories if needed. Use apply_patch for partial edits.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path to the file from repo root."
                    },
                    "content": {
                        "type": "string",
                        "description": "Full content to write to the file."
                    }
                },
                "required": ["path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "apply_patch",
            "description": "Apply a minimal edit to a file by replacing lines in a range. Safer than rewriting whole file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path to the file from repo root."
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "1-based line number where replacement starts (inclusive)."
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "1-based line number where replacement ends (inclusive). Use same as start_line for single-line edit."
                    },
                    "replacement": {
                        "type": "string",
                        "description": "New content to replace the specified line range. Can be multiple lines."
                    }
                },
                "required": ["path", "start_line", "end_line", "replacement"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_shell",
            "description": "Run a shell command in the repo root. Returns stdout/stderr (max 15000 chars). Dangerous commands are blocked.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cmd": {
                        "type": "string",
                        "description": "Shell command to execute."
                    }
                },
                "required": ["cmd"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_files",
            "description": "Search for a pattern in files using grep. Returns matching lines with file:line format.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regex pattern to search for."
                    },
                    "path": {
                        "type": "string",
                        "description": "Relative path to search in (file or directory). Default is '.' (entire repo).",
                        "default": "."
                    },
                    "file_pattern": {
                        "type": "string",
                        "description": "Glob pattern to filter files, e.g., '*.py'. Default searches all files.",
                        "default": "*"
                    }
                },
                "required": ["pattern"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "web_fetch",
            "description": "Fetch content from a URL (http/https only). Use for documentation lookups or external references. Returns cleaned text. SSRF-protected: local/private IPs blocked.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "The URL to fetch (must be http:// or https://)"
                    },
                    "max_bytes": {
                        "type": "integer",
                        "description": "Maximum bytes to download. Default 1MB.",
                        "default": 1000000
                    },
                    "timeout_sec": {
                        "type": "integer",
                        "description": "Request timeout in seconds. Default 15.",
                        "default": 15
                    }
                },
                "required": ["url"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Search the web and return ranked results (titles, snippets, URLs). Use to discover sources before fetching specific pages.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query string"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (1-10). Default 5.",
                        "default": 5
                    },
                    "language": {
                        "type": "string",
                        "description": "Language code (e.g., 'en', 'de'). Default 'en'.",
                        "default": "en"
                    },
                    "recency_days": {
                        "type": "integer",
                        "description": "Filter results to last N days (1=day, 7=week, 30=month)"
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "repo_fetch",
            "description": "Download external code from allowlisted hosts (GitHub, GitLab, Bitbucket). Saves to external/ directory. Max 50MB. No execution of downloaded code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "source": {
                        "type": "string",
                        "description": "Repository URL (e.g., https://github.com/user/repo)"
                    },
                    "dest": {
                        "type": "string",
                        "description": "Destination path under external/ (e.g., 'mylib' -> external/mylib)"
                    },
                    "ref": {
                        "type": "string",
                        "description": "Branch, tag, or commit to fetch. Default: main/master."
                    },
                    "force": {
                        "type": "boolean",
                        "description": "Overwrite if destination exists. Default false.",
                        "default": False
                    }
                },
                "required": ["source", "dest"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "capabilities_report",
            "description": "Report what this agent can and cannot do. Returns capability flags and limits. Call this first if asked about abilities.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "open_in_explorer",
            "description": "Open a file or folder in Windows Explorer. If given a file, Explorer opens with that file selected. If given a folder, Explorer opens that folder. Only works in WSL.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path to file or folder from repo root."
                    }
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "open_in_browser",
            "description": "Open a URL in the default Windows browser. Use this after web_search to open a result, or when user asks to open documentation/websites.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "URL to open (http:// or https://)"
                    }
                },
                "required": ["url"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "open_file",
            "description": "Open a file with its default Windows application. E.g., .pdf opens in PDF reader, .docx in Word, .py in VS Code. Only works in WSL.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path to the file from repo root."
                    }
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": "Store information in long-term memory. Use this to remember facts about the user, their preferences, important context, or anything that should persist across sessions. The agent should proactively use this when learning something important.",
            "parameters": {
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "What to remember (e.g., 'User prefers Python over JavaScript', 'Project uses FastAPI')"
                    },
                    "memory_type": {
                        "type": "string",
                        "enum": ["fact", "preference", "context", "skill"],
                        "description": "Type of memory. fact=about user/project, preference=user likes/dislikes, context=situational, skill=learned capability",
                        "default": "fact"
                    },
                    "importance": {
                        "type": "number",
                        "description": "How important is this? 0.0-1.0. Higher = remembered longer. Use 0.8+ for critical info.",
                        "default": 0.5
                    }
                },
                "required": ["content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "recall",
            "description": "Search long-term memory for relevant information. Use this before making assumptions about user preferences, project details, or past conversations.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "What to search for (e.g., 'user preferences', 'Python', 'project setup')"
                    },
                    "memory_type": {
                        "type": "string",
                        "enum": ["fact", "preference", "context", "skill"],
                        "description": "Filter by memory type (optional)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum results to return",
                        "default": 5
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "forget",
            "description": "Remove something from memory. Use when user asks to forget something or when information is outdated.",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {
                        "type": "integer",
                        "description": "Specific memory ID to forget (from recall results)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Forget all memories matching this text"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_memories",
            "description": "List all stored memories. Use to show user what you remember about them.",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_type": {
                        "type": "string",
                        "enum": ["fact", "preference", "context", "skill"],
                        "description": "Filter by type (optional)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum to show",
                        "default": 20
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "where_am_i",
            "description": "Report Cont's location, home directory, and identity status. Use this when confused about location or to verify self-awareness.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "find_path",
            "description": "Smart path finder. Use when a path doesn't work or user gives partial/ambiguous path info. Tries multiple resolution strategies including WSL path conversion, home directory, and common project locations.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Path to find (any format: Windows, WSL, Linux, relative)"
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "system_search",
            "description": "Search the filesystem index for files and folders. MUCH faster than list_dir or search_files. Use this FIRST when looking for any file, folder, or project. Searches ~/projects/, ~/Documents/, ~/Desktop/ and more.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "File or folder name (or partial name) to search for"
                    },
                    "type": {
                        "type": "string",
                        "enum": ["file", "dir", "any"],
                        "description": "Search only files, only directories, or both. Default: any."
                    },
                    "extension": {
                        "type": "string",
                        "description": "Filter by file extension, e.g. .json, .py, .md"
                    },
                    "project": {
                        "type": "string",
                        "description": "Filter by project name, e.g. kosgebot, cont, RAG_main"
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "navigate",
            "description": "Change working directory. Use when user says 'go to', 'navigate to', 'cd to', 'open folder'. Affects subsequent operations in this session.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory to navigate to (any format)"
                    }
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_recipe",
            "description": "Create a new task recipe for future use. Use this when you successfully complete a task and want to remember the approach for similar tasks.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Recipe name (e.g., 'file_read', 'code_fix')"
                    },
                    "triggers": {
                        "type": "string",
                        "description": "JSON array of trigger words (e.g., '[\"find\", \"bul\", \"show\"]')"
                    },
                    "steps": {
                        "type": "string",
                        "description": "JSON array of step objects with 'tool' and 'purpose' keys"
                    },
                    "forbidden_tools": {
                        "type": "string",
                        "description": "JSON array of tools NOT to use (optional, default '[]')",
                        "default": "[]"
                    }
                },
                "required": ["name", "triggers", "steps"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "learn_word",
            "description": "Add a new word to the vocabulary. Use when you encounter a Turkish/English word mapping that should be remembered.",
            "parameters": {
                "type": "object",
                "properties": {
                    "word": {
                        "type": "string",
                        "description": "The word to learn (e.g., Turkish command)"
                    },
                    "translation": {
                        "type": "string",
                        "description": "English translation"
                    },
                    "intent": {
                        "type": "string",
                        "description": "Intent: 'read', 'write', or 'execute'",
                        "default": "read"
                    },
                    "example": {
                        "type": "string",
                        "description": "Usage example (optional)"
                    }
                },
                "required": ["word", "translation"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "report_failure",
            "description": "Report why you failed a task. Use when you realize you made a mistake or couldn't complete a task.",
            "parameters": {
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "description": "What went wrong"
                    },
                    "lesson": {
                        "type": "string",
                        "description": "What to do differently next time"
                    },
                    "suggested_patch": {
                        "type": "string",
                        "description": "Optional rule to add as a prompt patch"
                    }
                },
                "required": ["reason"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "suggest_improvement",
            "description": "Suggest an improvement to your own behavior. Stored for human review.",
            "parameters": {
                "type": "object",
                "properties": {
                    "area": {
                        "type": "string",
                        "description": "Area: 'prompt', 'recipe', 'vocabulary', or 'tool'"
                    },
                    "suggestion": {
                        "type": "string",
                        "description": "What to improve"
                    },
                    "priority": {
                        "type": "string",
                        "description": "Priority: 'low', 'medium', or 'high'",
                        "default": "medium"
                    }
                },
                "required": ["area", "suggestion"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_automations",
            "description": "List all automation rules and their status (enabled/disabled, trigger type, action count).",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_automation",
            "description": "Manually trigger a named automation. Use list_automations first to see available names.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the automation to run (e.g., 'morning_briefing', 'disk_cleanup')"
                    }
                },
                "required": ["name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "toggle_automation",
            "description": "Enable or disable an automation by name.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the automation to toggle"
                    },
                    "enabled": {
                        "type": "string",
                        "description": "'true' to enable, 'false' to disable",
                        "default": "true"
                    }
                },
                "required": ["name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "emit_event",
            "description": "Emit an event to trigger matching automations. Event types: file.created, file.modified, task.completed, task.failed, inbox.new_file, etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "event_type": {
                        "type": "string",
                        "description": "Event type (e.g., 'file.modified', 'task.completed')"
                    },
                    "data": {
                        "type": "string",
                        "description": "JSON object with event data (e.g., '{\"file_path\": \"main.py\"}')",
                        "default": "{}"
                    }
                },
                "required": ["event_type"]
            }
        }
    },
    # ask_claude schema removed — model was auto-calling it.
    # Use /claude, /claude-edit, /claude-analyze slash commands instead.
    {
        "type": "function",
        "function": {
            "name": "ocr",
            "description": "Extract text from an image using OCR (Optical Character Recognition). Dual engine: Surya (powerful, layout-aware) and EasyOCR (fast). Supports JPEG, PNG, BMP, TIFF, WebP. GPU-accelerated. Returns detected text blocks with confidence scores and bounding boxes. Use this to read text from screenshots, photos, scanned documents, receipts, tables, etc. Set layout=true to analyze page structure (text regions, tables, figures).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to image file (relative or absolute)"
                    },
                    "languages": {
                        "type": "string",
                        "description": "Comma-separated language codes. Default 'tr,en'. Available: tr, en, de, fr, ar, zh, ja, ko, etc.",
                        "default": "tr,en"
                    },
                    "detail": {
                        "type": "string",
                        "enum": ["simple", "standard", "full"],
                        "description": "Detail level. simple=text only, standard=text+confidence+bbox, full=everything+polygons. Default 'standard'.",
                        "default": "standard"
                    },
                    "engine": {
                        "type": "string",
                        "enum": ["auto", "surya", "easyocr", "both"],
                        "description": "OCR engine. auto=best available (prefers Surya), both=compare engines side by side. Default 'auto'.",
                        "default": "auto"
                    },
                    "layout": {
                        "type": "string",
                        "enum": ["true", "false"],
                        "description": "If 'true', return page layout analysis (text regions, tables, figures) instead of OCR text. Surya only.",
                        "default": "false"
                    }
                },
                "required": ["path"]
            }
        }
    },
]

# Browser tool schemas (appended if playwright available)
BROWSER_TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "browser_open",
            "description": "Open a URL in a headless browser. Returns page title and text preview. Only http/https allowed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "URL to navigate to (http/https only)"
                    }
                },
                "required": ["url"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_click",
            "description": "Click an element on the current page using a CSS selector.",
            "parameters": {
                "type": "object",
                "properties": {
                    "selector": {
                        "type": "string",
                        "description": "CSS selector for the element to click"
                    }
                },
                "required": ["selector"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_type",
            "description": "Type text into an input field identified by CSS selector.",
            "parameters": {
                "type": "object",
                "properties": {
                    "selector": {
                        "type": "string",
                        "description": "CSS selector for the input field"
                    },
                    "text": {
                        "type": "string",
                        "description": "Text to type into the field"
                    }
                },
                "required": ["selector", "text"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_text",
            "description": "Extract text content from the page or a specific element.",
            "parameters": {
                "type": "object",
                "properties": {
                    "selector": {
                        "type": "string",
                        "description": "CSS selector to extract text from. Omit for full page text.",
                        "default": ""
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_screenshot",
            "description": "Take a screenshot of the current page.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "File path to save the screenshot. Default: ~/.config/cont/screenshot.png",
                        "default": ""
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_links",
            "description": "Get all links on the current page (text + href).",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_close",
            "description": "Close the headless browser session.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_agent",
            "description": "Autonomous browser pilot. Navigates to a website and achieves a goal by analyzing the page, filling forms, clicking buttons, and extracting information. Uses GPT-4o-mini for planning. Saves successful navigation paths as recipes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "Starting URL to navigate to (http/https only)"
                    },
                    "goal": {
                        "type": "string",
                        "description": "What to find or do on the site (e.g. 'kosgeb kanununu bul', 'destek programlarını listele')"
                    }
                },
                "required": ["url", "goal"]
            }
        }
    }
]

