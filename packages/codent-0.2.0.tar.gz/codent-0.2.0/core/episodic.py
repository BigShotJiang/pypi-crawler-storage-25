# core/episodic.py
"""
Episodic memory for task history + triage analysis.

Records WHAT happened, HOW it was done, and WHETHER it worked.
Unlike semantic memory (facts), episodic memory is temporal:
"what did we do and what was the result?"

Storage: SQLite table in cont's memory DB
Triage: JSONL log file analysis for failure pattern detection
"""

import sqlite3
import time
import json
import os
from collections import Counter, defaultdict
from pathlib import Path

EPISODIC_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_input TEXT NOT NULL,
    task_type TEXT,
    method TEXT,
    tools_used INTEGER DEFAULT 0,
    tool_names TEXT,
    duration_ms INTEGER,
    success INTEGER DEFAULT -1,
    auto_eval TEXT,
    user_feedback TEXT,
    response_preview TEXT,
    error TEXT,
    recipe_id TEXT,
    fastpath_intent TEXT,
    created_at REAL NOT NULL
)
"""


def init_episodic_db(db_path=None):
    """Initialize episodic table."""
    if db_path is None:
        db_path = os.path.expanduser("~/.config/cont/memory.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(EPISODIC_TABLE_SQL)
    conn.commit()
    return conn


def record_episode(conn, task_input, task_type="llm", method=None,
                   tools_used=0, tool_names=None, duration_ms=0,
                   success=-1, auto_eval=None, response_preview=None,
                   error=None, recipe_id=None, fastpath_intent=None):
    """Record a task episode."""
    conn.execute(
        "INSERT INTO episodes "
        "(task_input, task_type, method, tools_used, tool_names, "
        "duration_ms, success, auto_eval, response_preview, error, "
        "recipe_id, fastpath_intent, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            task_input[:500],
            task_type,
            method,
            tools_used,
            json.dumps(tool_names or [], ensure_ascii=False),
            duration_ms,
            success,
            json.dumps(auto_eval, ensure_ascii=False) if auto_eval else None,
            response_preview[:200] if response_preview else None,
            error[:500] if error else None,
            recipe_id,
            fastpath_intent,
            time.time(),
        )
    )
    conn.commit()
    return conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def update_feedback(conn, episode_id, feedback):
    """Update episode with user feedback."""
    success = 1 if feedback == "iyi" else (0 if feedback in ("kotu", "kötü") else -1)
    conn.execute(
        "UPDATE episodes SET user_feedback = ?, success = ? WHERE id = ?",
        (feedback, success, episode_id)
    )
    conn.commit()


def get_similar_episodes(conn, task_input, limit=3):
    """
    Find similar past episodes for a task.
    Simple keyword matching — not semantic, but fast.
    """
    words = task_input.lower().split()
    keywords = [w for w in words if len(w) > 3][:3]

    if not keywords:
        return []

    # Build LIKE clauses
    conditions = " OR ".join(
        "LOWER(task_input) LIKE ?" for _ in keywords
    )
    params = [f"%{kw}%" for kw in keywords]

    cursor = conn.execute(
        f"SELECT * FROM episodes WHERE ({conditions}) "
        f"ORDER BY created_at DESC LIMIT ?",
        params + [limit]
    )

    columns = [d[0] for d in cursor.description]
    return [dict(zip(columns, row)) for row in cursor]


def get_task_stats(conn, days=7):
    """Get task statistics for last N days."""
    cutoff = time.time() - (days * 86400)

    total = conn.execute(
        "SELECT COUNT(*) FROM episodes WHERE created_at > ?",
        (cutoff,)
    ).fetchone()[0]

    success = conn.execute(
        "SELECT COUNT(*) FROM episodes WHERE created_at > ? AND success = 1",
        (cutoff,)
    ).fetchone()[0]

    failed = conn.execute(
        "SELECT COUNT(*) FROM episodes WHERE created_at > ? AND success = 0",
        (cutoff,)
    ).fetchone()[0]

    by_type = {}
    cursor = conn.execute(
        "SELECT task_type, COUNT(*) FROM episodes "
        "WHERE created_at > ? GROUP BY task_type",
        (cutoff,)
    )
    for row in cursor:
        by_type[row[0]] = row[1]

    avg_tools = conn.execute(
        "SELECT AVG(tools_used) FROM episodes WHERE created_at > ?",
        (cutoff,)
    ).fetchone()[0] or 0

    return {
        "total": total,
        "success": success,
        "failed": failed,
        "unknown": total - success - failed,
        "success_rate": f"{(success/total*100):.0f}%" if total else "N/A",
        "by_type": by_type,
        "avg_tools": round(avg_tools, 1),
    }


def cleanup_old_episodes(conn, keep_days=90, keep_max=1000):
    """Remove old episodes, keep recent and successful ones."""
    cutoff = time.time() - (keep_days * 86400)

    count = conn.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]
    if count <= keep_max:
        return 0

    # Delete oldest, but keep successful ones longer
    result = conn.execute(
        "DELETE FROM episodes WHERE created_at < ? AND success != 1",
        (cutoff,)
    )
    deleted = result.rowcount
    conn.commit()
    return deleted


# =====================================================================
# Triage — Failure Pattern Analysis from JSONL Run Logs
# =====================================================================

_ROOT_CAUSES = {
    "wasteful_tools": {
        "cause": "Model gereksiz tool call yapıyor (decomposer yanlış bölüyor veya model plan yapmadan arama yapıyor)",
        "fix": "System prompt'ta verimlilik kuralını güçlendir; decomposer'ı basit görevlerde atla",
        "file": "cont.py (system prompt + decomposer gate)",
    },
    "blocked_calls": {
        "cause": "Model aynı tool'u aynı args ile tekrar çağırıyor, budget_blocked alıyor",
        "fix": "Anti-loop guard'ı güçlendir; blocked sonrası 'DUR ve cevap ver' kuralı ekle",
        "file": "cont.py (anti-loop prompt + tool dispatch)",
    },
    "tool_loop": {
        "cause": "Tek tool'a takılıyor (genelde web_search veya list_dir), farklı yaklaşım denemiyor",
        "fix": "Tool-specific limit düşür; 2. tekrarda 'farklı tool kullan' uyarısı ekle",
        "file": "cont.py (tool budget + per-tool limits)",
    },
    "incomplete": {
        "cause": "Tool call sonrası model final cevap üretmeden session bitiyor",
        "fix": "Budget tükendiğinde forced final response ekle (tools=None ile son call)",
        "file": "cont.py (run_task loop exit)",
    },
    "task_failed": {
        "cause": "Görev tamamlandı ama başarısız (yanlış cevap, doğrulama geçemedi, vb.)",
        "fix": "Spesifik hata türüne göre — verification, hallucination, veya context kaybı olabilir",
        "file": "core/auto_eval.py + core/verification.py",
    },
    "tool_error": {
        "cause": "Tool çağrısı hata döndü (API hatası, dosya bulunamadı, permission, vb.)",
        "fix": "Hata türüne göre — genelde tool input validation eksik",
        "file": "cont.py (tool dispatch error handling)",
    },
}

# These error codes are NOT real errors — skip in triage
_TRIAGE_SKIP_ERRORS = frozenset({
    "prefetch_cache_hit", "repetition_blocked", "cache_hit",
})


def run_triage(n: int = 50, log_dir: str = None, verbose: bool = False) -> str:
    """Scan last N runs, report top 5 failure patterns with root cause.

    Args:
        n: Number of recent log files to scan.
        log_dir: Path to JSONL log directory. If None, uses default.
        verbose: Include full log file paths in output.
    """
    if log_dir is None:
        log_dir = os.path.join(os.getcwd(), "logs", "cont_runs")

    log_path = Path(log_dir)
    if not log_path.exists():
        return f"Log klasörü bulunamadı: {log_dir}"

    log_files = sorted(log_path.glob("*.jsonl"),
                       key=lambda f: f.stat().st_mtime, reverse=True)[:n]

    if not log_files:
        return "Henüz run logu yok."

    # --- Parse each log ---
    issues = []  # list of (category, detail, task_name, log_file, run_id, tool_trace)
    stats = {"total": 0, "success": 0, "fail": 0}

    for lf in log_files:
        fname = lf.stem
        task_name = fname[16:].replace("_", " ").strip() if len(fname) > 16 else fname
        stats["total"] += 1

        tool_calls = []
        blocked_count = 0
        errors = []
        has_final = False
        final_success = None

        try:
            for line in lf.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                etype = entry.get("type", "")
                data = entry.get("data", {})

                if etype == "tool_call":
                    tool_calls.append(data.get("name", "?"))
                elif etype == "tool_result":
                    _err = data.get("error", "")
                    if _err == "budget_blocked":
                        blocked_count += 1
                    elif _err == "tool_limit_reached":
                        blocked_count += 1
                    elif _err in _TRIAGE_SKIP_ERRORS:
                        pass  # Not real errors — budget enforcement / cache hits
                    elif _err:
                        errors.append(_err[:100])
                elif etype == "final":
                    has_final = True
                    final_success = data.get("success", False)
        except Exception:
            continue

        if final_success:
            stats["success"] += 1
        else:
            stats["fail"] += 1

        # --- Detect issues ---
        tc = len(tool_calls)
        tool_counts = Counter(tool_calls)

        # Run ID from filename (YYYYMMDD_HHMMSS)
        run_id = fname[:15] if len(fname) >= 15 else fname

        # Tool trace summary: "web_search(3) → list_dir(2) → read_file(1)"
        trace_parts = [f"{t}({c})" for t, c in tool_counts.most_common(4)]
        tool_trace = " → ".join(trace_parts) if trace_parts else "(no tools)"

        def _issue(cat, detail):
            issues.append((cat, detail, task_name, str(lf), run_id, tool_trace))

        # 1. Wasteful: 8+ tool calls
        if tc >= 8:
            _issue("wasteful_tools", f"{tc} tool calls")

        # 2. Blocked/duplicate calls
        if blocked_count >= 2:
            _issue("blocked_calls", f"{blocked_count} blocked out of {tc}")

        # 3. Tool loop (same tool 4+ times)
        for tname, cnt in tool_counts.items():
            if cnt >= 4 and tname not in ("system_search",):
                _issue("tool_loop", f"{tname} x{cnt}")
                break

        # 4. No final answer
        if not has_final and tc > 0:
            _issue("incomplete", f"no final answer after {tc} tool calls")

        # 5. Final but failed
        if has_final and not final_success:
            _issue("task_failed", f"failed ({tc} tools)")

        # 6. Errors
        for err in errors[:1]:  # max 1 per log
            if "budget_blocked" not in err and "tool_limit" not in err:
                _issue("tool_error", err[:80])

    # --- Aggregate: top 5 failure patterns ---
    pattern_count = Counter()
    pattern_examples = defaultdict(list)

    for cat, detail, task, lf, rid, trace in issues:
        pattern_count[cat] += 1
        if len(pattern_examples[cat]) < 3:
            pattern_examples[cat].append((task, detail, lf, rid, trace))

    # --- Format output ---
    lines = []
    success_rate = (stats["success"] / stats["total"] * 100) if stats["total"] > 0 else 0
    lines.append(f"TRIAGE RAPORU — Son {stats['total']} run")
    lines.append(f"{'─' * 50}")
    lines.append(f"Başarılı: {stats['success']}/{stats['total']} ({success_rate:.0f}%)")
    lines.append(f"Toplam sorun: {len(issues)}")
    lines.append("")

    top5 = pattern_count.most_common(5)
    if not top5:
        lines.append("Sorun tespit edilmedi.")
        return "\n".join(lines)

    for rank, (cat, count) in enumerate(top5, 1):
        info = _ROOT_CAUSES.get(cat, {})
        lines.append(f"{'━' * 50}")
        lines.append(f"#{rank}  {cat} — {count} occurrence{'s' if count > 1 else ''}")
        lines.append(f"{'━' * 50}")
        lines.append(f"  Kök neden : {info.get('cause', '?')}")
        lines.append(f"  Önerilen fix: {info.get('fix', '?')}")
        lines.append(f"  Dosya/konum: {info.get('file', '?')}")
        lines.append(f"  Örnekler:")
        for task, detail, lf_path, rid, trace in pattern_examples[cat]:
            lines.append(f"    • [{rid}] {task[:50]} — {detail}")
            lines.append(f"      Trace: {trace}")
            if verbose:
                lines.append(f"      Log: {lf_path}")
        lines.append("")

    return "\n".join(lines)
