# core/system_executor.py
"""
System Fastpath — 2-lane highway.

Lane A (Fastpath): System resolves + executes → LLM formats (tools=[])
Lane B (Agent):    System can't handle → normal LLM + tools flow

This module handles Lane A only.
"""

import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


# Words that indicate a negative/noisy memory — filter from recall
_RECALL_NOISE = [
    "başarısız", "basarisiz", "memnun değil", "hata", "failed",
    "kötü", "/kötü", "timeout", "error", "denied",
]


# ============================================
# RESOLVER — Deterministic, no LLM, no find
# ============================================

class Resolver:
    """Deterministic path/env resolution. O(1) only."""

    _wsl_user: Optional[str] = None

    @classmethod
    def wsl_username(cls) -> str:
        """Get Windows username dynamically. Cached after first call."""
        if cls._wsl_user is not None:
            return cls._wsl_user

        user: Optional[str] = None

        # Method 1: env var (explicit override)
        user = os.environ.get("WINDOWS_USER")

        # Method 2: cmd.exe /c echo %USERNAME%
        if not user:
            try:
                r = subprocess.run(
                    ["cmd.exe", "/c", "echo", "%USERNAME%"],
                    capture_output=True, text=True, timeout=3,
                )
                candidate = r.stdout.strip().strip("%")
                if candidate and candidate != "USERNAME":
                    user = candidate
            except Exception:
                pass

        # Method 3: scan /mnt/c/Users for single non-system dir
        if not user:
            try:
                users_dir = "/mnt/c/Users"
                if os.path.isdir(users_dir):
                    skip = {
                        "Public", "Default", "Default User",
                        "All Users", "desktop.ini",
                    }
                    dirs = [
                        d for d in os.listdir(users_dir)
                        if d not in skip and os.path.isdir(f"{users_dir}/{d}")
                    ]
                    if len(dirs) == 1:
                        user = dirs[0]
                    elif dirs:
                        # Pick the one with a Desktop folder
                        for d in dirs:
                            if os.path.isdir(f"{users_dir}/{d}/Desktop"):
                                user = d
                                break
            except Exception:
                pass

        cls._wsl_user = user or "Unknown"
        return cls._wsl_user

    @classmethod
    def is_wsl(cls) -> bool:
        return os.path.isdir("/mnt/c/Windows")

    @classmethod
    def user_dir(cls, folder: str) -> Optional[str]:
        """
        Resolve a user folder like 'downloads', 'desktop', 'documents'.
        Returns path or None. O(1) — just checks known locations.
        """
        folder_map = {
            "downloads": "Downloads",
            "desktop": "Desktop",
            "documents": "Documents",
            "pictures": "Pictures",
            "videos": "Videos",
            "music": "Music",
        }

        win_folder = folder_map.get(folder.lower())
        if not win_folder:
            return None

        candidates: list[str] = []

        if cls.is_wsl():
            user = cls.wsl_username()
            if user and user != "Unknown":
                candidates.append(f"/mnt/c/Users/{user}/{win_folder}")

        candidates.append(os.path.expanduser(f"~/{win_folder}"))
        candidates.append(os.path.expanduser(f"~/{folder.lower()}"))

        for c in candidates:
            if os.path.isdir(c):
                return c

        return None

    @classmethod
    def repo_root(cls) -> str:
        try:
            r = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                return r.stdout.strip()
        except Exception:
            pass
        return os.getcwd()

    @classmethod
    def git_info(cls) -> Optional[dict]:
        """Quick git status. O(1)."""
        try:
            branch = subprocess.run(
                ["git", "branch", "--show-current"],
                capture_output=True, text=True, timeout=3,
            ).stdout.strip()

            status = subprocess.run(
                ["git", "status", "--short"],
                capture_output=True, text=True, timeout=3,
            ).stdout.strip()

            log = subprocess.run(
                ["git", "log", "--oneline", "-5"],
                capture_output=True, text=True, timeout=3,
            ).stdout.strip()

            return {
                "branch": branch,
                "dirty": bool(status),
                "changes": status,
                "recent_commits": log,
                "files_changed": len(status.splitlines()) if status else 0,
            }
        except Exception:
            return None

    @classmethod
    def cwd_info(cls) -> dict:
        return {
            "cwd": os.getcwd(),
            "repo_root": cls.repo_root(),
            "is_wsl": cls.is_wsl(),
        }


# ============================================
# INTENT SCORER — Keyword-based, not regex
# ============================================

# Turkish stopwords — common verbs/particles that cause false matches
# e.g. "git" (go) vs git VCS, "bul" (find) inflating scores
_TR_STOPWORDS = {
    'git', 'gel', 'yap', 'al', 'ver', 'aç', 'ac', 'koy', 'bul',
    'de', 'da', 'bir', 'bu', 'şu', 'su', 'ne', 'ile', 'için', 'icin',
    'ben', 'sen', 'biz', 'siz', 'var', 'yok', 'olan',
    'gibi', 'kadar', 'sonra', 'önce', 'once', 'daha', 'çok', 'cok',
    'şimdi', 'simdi', 'zaman', 'her', 'tüm', 'tum', 'hep', 'hiç', 'hic',
    'iste', 'işte', 'haydi', 'hadi', 'tamam', 'evet', 'değil', 'degil',
    'lütfen', 'lutfen', 'tekrar', 'dene',
}

# If ANY of these appear, the user wants a browser/web action → skip filesystem intents
_BROWSER_INTENT_KEYWORDS = {
    'site', 'sitesi', 'sitesine', 'sitesinden', 'sayfası', 'sayfasi',
    'web', 'http', 'https', 'www',
    'mevzuat', 'kanun', 'yönetmelik', 'yonetmelik',
    'browser', 'sayfa', 'sayfaya', 'sayfadan',
}

# "indir" alone is ambiguous — only browser when combined with browser context
_BROWSER_COMBO_KEYWORDS = {'indir', 'indirmek', 'indirin'}
_BROWSER_COMBO_CONTEXT = {'kanun', 'yasa', 'belge', 'doküman', 'dokuman'}

# Turkish + English keyword → intent mapping with score weights
INTENT_KEYWORDS: Dict[str, dict] = {
    "list_downloads": {
        "keywords": {
            "indirilenler": 3, "indirilen": 3, "indirme": 2,
            "download": 3, "downloads": 3,
            "son": 1, "listele": 2, "göster": 2, "goster": 2, "bul": 1,
            "dosya": 1, "file": 1,
        },
        "threshold": 4,
        "handler": "handle_dir_list",
        "dir_key": "downloads",
    },
    "list_desktop": {
        "keywords": {
            "masaüstü": 3, "masaustu": 3, "desktop": 3,
            "listele": 2, "göster": 2, "goster": 2, "bul": 1,
            "dosya": 1, "file": 1,
        },
        "threshold": 4,
        "handler": "handle_dir_list",
        "dir_key": "desktop",
    },
    "list_documents": {
        "keywords": {
            "belgeler": 3, "documents": 3, "doküman": 2, "dokuman": 2,
            "listele": 2, "göster": 2, "goster": 2,
            "dosya": 1,
        },
        "threshold": 4,
        "handler": "handle_dir_list",
        "dir_key": "documents",
    },
    "list_logs": {
        "keywords": {
            "log": 3, "kayıt": 2, "kayit": 2, "günlük": 2, "gunluk": 2,
            "listele": 2, "göster": 2, "goster": 2, "son": 1, "oku": 1,
        },
        "threshold": 4,
        "handler": "handle_logs",
    },
    "where_am_i": {
        "keywords": {
            "neredeyim": 5, "nerde": 4, "nerdeyim": 4,
            "neredesin": 5, "nerdesin": 4, "neredesiniz": 4,
            "nerdeyiz": 4, "konum": 3,
            "where": 3, "pwd": 5, "cwd": 5,
        },
        "threshold": 4,
        "handler": "handle_where",
    },
    "git_status": {
        "keywords": {
            "git": 3, "status": 5, "durum": 5, "durumu": 5, "durumunu": 5,
            "branch": 5, "commit": 5, "dal": 4,
            "değişiklik": 5, "degisiklik": 5,
            "göster": 1, "goster": 1, "listele": 1,
        },
        "threshold": 5,
        "handler": "handle_git",
    },
    "list_cwd": {
        "keywords": {
            "dosya": 2, "klasör": 2, "klasor": 2, "dizin": 2, "folder": 2,
            "listele": 3, "göster": 2, "goster": 2, "neler": 2, "ne": 1,
            "var": 1, "burada": 2, "şurada": 2, "surada": 2, "mevcut": 2,
        },
        "threshold": 5,
        "handler": "handle_cwd_list",
    },
}


def detect_intent(user_input: str) -> Optional[Dict]:
    """
    Score user input against known intents via keyword matching.
    Returns best matching intent dict (with 'name' and 'score') or None.

    Guards prevent false matches:
    - URLs in input → browser intent, skip filesystem
    - Browser keywords → skip filesystem
    - Turkish stopwords removed before scoring
    """
    words = user_input.lower().split()
    word_set = set(words)

    # GUARD 1: URL in input → definitely browser intent
    if any('http' in w or '.gov' in w or '.com' in w or '.org' in w
           for w in words):
        return None

    # GUARD 2: Direct browser keywords → skip filesystem intents
    if word_set & _BROWSER_INTENT_KEYWORDS:
        return None

    # GUARD 3: "indir" + browser context = browser intent
    if word_set & _BROWSER_COMBO_KEYWORDS:
        if word_set & (_BROWSER_INTENT_KEYWORDS | _BROWSER_COMBO_CONTEXT):
            return None

    # GUARD 4: Remove stopwords before keyword scoring
    scoring_words = [w for w in words if w not in _TR_STOPWORDS]
    if not scoring_words:
        return None  # All stopwords = no clear intent

    best_intent: Optional[Dict] = None
    best_score = 0

    for intent_name, config in INTENT_KEYWORDS.items():
        score = 0
        matched_words: list[str] = []
        for word in scoring_words:
            # Exact match
            if word in config["keywords"]:
                score += config["keywords"][word]
                matched_words.append(word)
            else:
                # Partial/stem match (handles Turkish suffixes like -deki, -ları)
                for kw, kw_score in config["keywords"].items():
                    if len(kw) >= 3 and (word.startswith(kw) or kw.startswith(word) or kw in word or word in kw):
                        score += int(kw_score * 0.7)
                        matched_words.append(f"{word}~{kw}")
                        break

        if score >= config["threshold"] and score > best_score:
            best_score = score
            best_intent = {
                **config,
                "name": intent_name,
                "score": score,
                "matched": matched_words,
            }

    # v6.3: Word count guard — long inputs with marginal match scores are
    # likely complex tasks that should go to LLM, not fastpath.
    # Require score >= 1.5x threshold for inputs with >4 words.
    if best_intent and len(words) > 4:
        _threshold = best_intent.get("threshold", 1)
        if _threshold > 0 and best_score / _threshold < 1.5:
            return None

    return best_intent


# ============================================
# SYSTEM EXECUTOR
# ============================================

class SystemExecutor:
    """
    Tries to handle query at system level (Lane A).
    Returns structured result for LLM to format, or None → Lane B.
    """

    def __init__(self, memory_fn: Optional[Callable] = None):
        self.memory_fn = memory_fn

    def try_execute(self, user_input: str) -> Optional[Dict]:
        """
        Attempt fastpath execution.

        Returns:
            {
                "handled": True,
                "intent": "list_downloads",
                "intent_score": 7,
                "data": { ... structured result ... },
                "format_prompt": "..." (for LLM formatter)
            }
            or None if not handled.
        """
        # Intent gate safety net: skip fastpath for write/read/command intents
        from core.intent_gate import detect_intent as _gate_detect
        _gate = _gate_detect(user_input)
        if _gate.intent in ("write", "read", "command"):
            return None

        intent = detect_intent(user_input)
        if not intent:
            return None

        handler_name = intent.get("handler")
        handler = getattr(self, handler_name, None)
        if not handler:
            return None

        try:
            result = handler(user_input, intent)
            if result:
                result["intent"] = intent["name"]
                result["intent_score"] = intent["score"]
            return result
        except Exception:
            return None

    # -- Utility -------------------------------------------------------

    @staticmethod
    def _extract_count(text: str, default: int = 10) -> int:
        """Extract a number from user text (e.g. 'son 10 dosya')."""
        m = re.search(r"(\d+)", text)
        if m:
            return min(int(m.group(1)), 50)
        return default

    @staticmethod
    def _shell(cmd: str, timeout: int = 5) -> Optional[str]:
        """Run a quick shell command. Returns stdout or None."""
        try:
            r = subprocess.run(
                cmd, shell=True, capture_output=True,
                text=True, timeout=timeout,
            )
            return r.stdout.strip() if r.returncode == 0 else None
        except Exception:
            return None

    # -- Handlers — each returns structured data -----------------------

    # Negative guard for list_downloads — block if user means a website
    _DIR_LIST_BLOCKERS = {
        'site', 'sitesi', 'sitesine', 'sitesinden',
        'kanun', 'mevzuat', 'yönetmelik', 'yonetmelik',
        'ara', 'arama', 'browser', 'sayfa',
        # Open/navigate/show verbs — user wants to OPEN/SHOW, not LIST
        'aç', 'açın', 'açalım', 'açsana', 'açmak',
        'git', 'gidin', 'gidelim', 'gir', 'gitmek',
        'göster', 'gösterin', 'göstermek',
        # Browse/read/download verbs — not a list intent
        'bak', 'bakmak',
        'oku', 'okumak',
        'indir', 'indirmek',
    }

    def handle_dir_list(self, user_input: str, intent: dict) -> Optional[Dict]:
        """List files in a known user directory."""
        if set(user_input.lower().split()) & self._DIR_LIST_BLOCKERS:
            return None
        dir_key = intent.get("dir_key", "downloads")
        path = Resolver.user_dir(dir_key)
        if not path:
            return None

        count = self._extract_count(user_input)
        raw = self._shell(f'ls -lt "{path}" | tail -n +2 | head -{count}')
        if not raw:
            return None

        # Parse ls output into structured data
        files: list[dict] = []
        for line in raw.strip().splitlines():
            parts = line.split(None, 8)
            if len(parts) >= 9:
                files.append({
                    "permissions": parts[0],
                    "size": parts[4],
                    "date": f"{parts[5]} {parts[6]} {parts[7]}",
                    "name": parts[8],
                })
            elif parts:
                files.append({"name": parts[-1]})

        data = {
            "path": path,
            "count": count,
            "total_found": len(files),
            "files": files,
        }

        return {
            "handled": True,
            "data": data,
            "format_prompt": self._build_format_prompt(
                user_input, "dir_list", data
            ),
        }

    def handle_logs(self, user_input: str, intent: dict) -> Optional[Dict]:
        """List recent log files."""
        log_dirs = [
            os.path.join(os.getcwd(), "logs", "cont_runs"),
            os.path.expanduser("~/projects/cont/logs/cont_runs"),
        ]
        for log_dir in log_dirs:
            if os.path.isdir(log_dir):
                count = self._extract_count(user_input, 5)
                raw = self._shell(
                    f'ls -lt "{log_dir}" | tail -n +2 | head -{count}'
                )
                if raw:
                    data = {"path": log_dir, "count": count, "raw": raw}
                    return {
                        "handled": True,
                        "data": data,
                        "format_prompt": self._build_format_prompt(
                            user_input, "log_list", data
                        ),
                    }
        return None

    def handle_where(self, user_input: str, intent: dict) -> Optional[Dict]:
        """Handle location query."""
        data = Resolver.cwd_info()
        git = Resolver.git_info()
        if git:
            data["git"] = git

        return {
            "handled": True,
            "data": data,
            "format_prompt": self._build_format_prompt(
                user_input, "location", data
            ),
        }

    def handle_git(self, user_input: str, intent: dict) -> Optional[Dict]:
        """Handle git status query."""
        git = Resolver.git_info()
        if not git:
            return None

        data = {"repo": Resolver.repo_root(), **git}
        return {
            "handled": True,
            "data": data,
            "format_prompt": self._build_format_prompt(
                user_input, "git_status", data
            ),
        }

    def handle_cwd_list(self, user_input: str, intent: dict) -> Optional[Dict]:
        """List files in current directory."""
        count = self._extract_count(user_input, 20)
        raw = self._shell(f'ls -lt | tail -n +2 | head -{count}')
        if not raw:
            return None

        data = {"path": os.getcwd(), "count": count, "raw": raw}
        return {
            "handled": True,
            "data": data,
            "format_prompt": self._build_format_prompt(
                user_input, "dir_list", data
            ),
        }

    # -- Recipe execution ------------------------------------------------

    def try_execute_recipe(self, user_input: str, recipe: dict) -> Optional[Dict]:
        """
        Execute a recipe's steps at system level.
        Returns structured results for LLM to format, or None if
        recipe requires LLM judgment (creative/complex tasks).
        """
        steps = recipe.get("steps", [])
        if not steps:
            return None

        # Recipes whose primary job is "respond" need LLM thinking
        concrete_actions = [
            s for s in steps if s.get("action") not in ("respond",)
        ]
        if not concrete_actions:
            return None

        results: list[dict] = []
        context: Dict[str, str] = {
            "cwd": os.getcwd(),
            "repo_root": Resolver.repo_root(),
            "user_input": user_input,
            "file_hint": self._extract_file_hint(user_input),
            "search_query": self._extract_search_query(user_input),
        }

        for step in steps:
            action = step.get("action", "")
            args = step.get("args", {})
            resolved_args = self._resolve_vars(args, context)

            if action == "recall":
                query = resolved_args.get(
                    "query", context.get("file_hint", "")
                )
                if self.memory_fn and query:
                    try:
                        memories = self.memory_fn(query, limit=3)
                        # Filter out noisy/negative memories
                        memories = [
                            m for m in (memories or [])
                            if not any(
                                nw in str(m).lower()
                                for nw in _RECALL_NOISE
                            )
                        ]
                        for m in memories:
                            content = (
                                m.get("content", "")
                                if isinstance(m, dict) else str(m)
                            )
                            path_match = re.search(
                                r'(/[\w/._-]+)', content
                            )
                            if path_match:
                                context["resolved_path"] = (
                                    path_match.group(1)
                                )
                        if memories:
                            results.append({
                                "step": "recall",
                                "result": str(memories[:2]),
                            })
                    except Exception:
                        pass

            elif action == "read_file":
                path = resolved_args.get("path", "")
                if not path or "{" in path:
                    path = self._find_file(context)
                if path and os.path.isfile(path):
                    try:
                        with open(path, "r", errors="replace") as f:
                            content = f.read()
                        if len(content) > 5000:
                            content = (
                                content[:2000]
                                + f"\n\n... [{len(content)} karakter, "
                                  f"kisaltildi] ...\n\n"
                                + content[-1000:]
                            )
                        context["file_content"] = content
                        context["file_path"] = path
                        context["resolved_path"] = path
                        results.append({
                            "step": "read_file",
                            "path": path,
                            "size": os.path.getsize(path),
                            "lines": content.count("\n"),
                            "content_preview": content,
                        })
                    except Exception as e:
                        results.append({
                            "step": "read_file", "error": str(e),
                        })

            elif action == "list_dir":
                path = resolved_args.get(
                    "path",
                    context.get("resolved_path", "."),
                )
                if "{" in path:
                    path = "."
                if os.path.isdir(path):
                    raw = self._shell(f'ls -la "{path}" | head -30')
                    if raw:
                        results.append({
                            "step": "list_dir",
                            "path": path,
                            "result": raw,
                        })

            elif action == "respond":
                # Final format step — LLM handles this
                pass

            # Skip web_search, web_fetch, edit_file — need network or
            # write access, better left to LLM flow

        # Return if we got meaningful results
        has_content = any(
            r.get("content_preview") or r.get("result")
            for r in results
        )
        if results and has_content:
            return {
                "handled": True,
                "recipe_id": recipe["id"],
                "data": {
                    "results": results,
                    "file_path": context.get("file_path"),
                },
                "format_prompt": self._build_recipe_format_prompt(
                    user_input, recipe, results, context
                ),
            }

        return None

    # -- Recipe helpers ---------------------------------------------------

    @staticmethod
    def _extract_file_hint(text: str) -> str:
        """Extract filename from user input."""
        # After colon: "özetle: cont.py"
        if ":" in text:
            after = text.split(":", 1)[1].strip()
            if after:
                candidate = after.split()[0].strip("\"'")
                if candidate:
                    return candidate

        # Common file patterns (name.ext)
        match = re.search(r'([\w./-]+\.\w{1,10})', text)
        if match:
            return match.group(1)

        return ""

    @staticmethod
    def _extract_search_query(text: str) -> str:
        """Extract search query, stripping action words."""
        remove = {
            "ara", "bul", "search", "find", "web", "internet",
            "nedir", "hakkinda", "ozetle", "oku", "goster",
            "bu", "ve", "ile", "de", "da", "bir",
        }
        words = text.lower().split()
        query_words = [
            w for w in words if w not in remove and len(w) > 2
        ]
        return " ".join(query_words[:5])

    @staticmethod
    def _resolve_vars(args: dict, context: dict) -> dict:
        """Resolve {variable} placeholders in args."""
        resolved = {}
        for key, val in args.items():
            if isinstance(val, str):
                for ctx_key, ctx_val in context.items():
                    if isinstance(ctx_val, str):
                        val = val.replace(f"{{{ctx_key}}}", ctx_val)
                resolved[key] = val
            else:
                resolved[key] = val
        return resolved

    def _find_file(self, context: dict) -> str:
        """Resolve a file from hint, CWD, or repo root."""
        hint = context.get("file_hint", "")
        if not hint:
            return ""

        repo = context.get("repo_root", os.getcwd())

        # Direct path
        if os.path.isfile(hint):
            return os.path.abspath(hint)

        # Relative to repo root
        candidate = os.path.join(repo, hint)
        if os.path.isfile(candidate):
            return candidate

        # Shallow find (max depth 3)
        found = self._shell(
            f'find "{repo}" -name "{hint}" -maxdepth 3 '
            f'-type f 2>/dev/null | head -1'
        )
        if found and os.path.isfile(found):
            return found

        return ""

    @staticmethod
    def _build_recipe_format_prompt(
        user_input: str, recipe: dict,
        results: list, context: dict,
    ) -> str:
        """Build formatting prompt for recipe results."""
        parts = [
            f'Kullanici: "{user_input}"',
            "",
            f'Sistem bu gorevi "{recipe.get("description", "")}" '
            f"recetesiyle cozdu.",
            "TOOL CAGIRMA. Sadece sonuclari guzelce formatla.",
            "",
        ]

        has_file_content = any(
            r["step"] == "read_file" and r.get("content_preview")
            for r in results
        )

        for r in results:
            if r["step"] == "read_file" and r.get("content_preview"):
                parts.append(f'Dosya: {r.get("path", "?")}')
                parts.append(
                    f'Boyut: {r.get("size", "?")} bytes, '
                    f'{r.get("lines", "?")} satir'
                )
                parts.append("")
                parts.append("Icerik:")
                parts.append("```")
                parts.append(r["content_preview"])
                parts.append("```")
                parts.append("")
                parts.append(
                    "Bu dosyanin OZETINI yaz. Ne yaptigini, yapisini, "
                    "onemli bilesenlerini acikla."
                )

            elif r["step"] == "list_dir":
                parts.append(f'Dizin: {r.get("path", "?")}')
                parts.append("```")
                parts.append(r.get("result", ""))
                parts.append("```")

            elif r["step"] == "recall" and r.get("result"):
                # Skip recall noise when we already have file content
                if not has_file_content:
                    parts.append(f"Hafiza sonucu: {r['result']}")

        parts.append("")
        parts.append("Kurallar:")
        parts.append("- Tool cagrisi YAPMA")
        parts.append("- Veriyi okunaklı sekilde sun")
        parts.append("- Kisa ve net ol")

        return "\n".join(parts)

    # -- Formatter prompt builder --------------------------------------

    @staticmethod
    def _build_format_prompt(user_input: str, kind: str, data: dict) -> str:
        """Build structured prompt for LLM formatter (tools=[])."""
        return (
            f'Kullanıcı: "{user_input}"\n\n'
            f"Sistem bu sorguyu zaten çözdü. "
            f"TOOL ÇAĞIRMA. Sadece sonucu güzelce formatla.\n\n"
            f"Veri tipi: {kind}\n"
            f"Veri:\n```json\n"
            f"{json.dumps(data, ensure_ascii=False, indent=2)}\n```\n\n"
            f"Kurallar:\n"
            f"- Tool çağrısı YAPMA\n"
            f"- Veriyi okunaklı şekilde sun\n"
            f"- Dosya listesiyse tablo veya liste formatı kullan\n"
            f"- Tarih ve boyut bilgisi varsa göster\n"
            f"- Kısa ve net ol"
        )
