# core/model_routing.py
"""Adaptive model routing — select fast/balanced/powerful model per task."""

import re
from typing import Optional

from core.utils import debug as _debug


MODEL_TIERS = {
    "fast": [
        "nemotron-3-nano-30b",
        "qwen2.5-7b-instruct",
        "qwen2.5-7b-instruct-1m",
    ],
    "balanced": [
        "nemotron-3-nano-30b",
        "qwen2.5-7b-instruct-1m",
    ],
    "powerful": [
        "qwen3-coder-30b-a3b",
        "qwen3-coder-30b",
    ],
}

# Patterns for simple tasks -> fast model
SIMPLE_TASK_PATTERNS = [
    r"^(list|ls|show|display)\s+(files?|dir|folder|directory)",
    r"^(read|cat|print|show)\s+(file|the file)",
    r"^what('s| is| are) in\s+",
    r"^(create|write|make|touch)\s+(a\s+)?(simple\s+)?(file|empty)",
    r"^(delete|remove|rm)\s+",
    r"^(copy|cp|move|mv)\s+",
    r"^(find|locate|where)\s+(is\s+)?(the\s+)?[\w.]+$",
    r"^open\s+(the\s+)?[\w./]+",
    r"^run\s+(the\s+)?(test|script)",
    # Turkish simple patterns
    r"^(listele|göster|oku|aç|sil|kopyala|taşı)\s+",
    r"^(dosya|klasör|dizin)\s+(listele|göster|oku)",
    r"^merhaba",
    r"^selam",
]

# Patterns for complex tasks -> powerful model
COMPLEX_TASK_PATTERNS = [
    r"(debug|fix|solve|diagnose)\s+(the\s+)?(bug|error|issue|problem)",
    r"(explain|why|how does|what causes)",
    r"(analyze|review|audit)\s+(the\s+)?(code|file|project)",
    r"(refactor|rewrite|improve|optimize)\s+",
    r"(compare|diff|difference|versus)",
    r"(design|architect|plan|implement)\s+(a\s+)?",
    r"(step[- ]by[- ]step|reasoning|think through)",
    r"(complex|complicated|difficult|hard)\s+",
    r"(multiple|several|many)\s+(files?|changes?)",
    r"(security|vulnerability|performance)\s+(issue|check|audit)",
    # Turkish complex patterns
    r"(düzelt|tamir et|onar)\s+",
    r"(incele|analiz et|gözden geçir)\s+",
    r"(refactor|yeniden yaz|iyileştir)\s+",
    r"(test yaz|test ekle|birim test)",
    r"(açıkla|neden|nasıl çalışıyor)",
    r"(kod yaz|fonksiyon yaz|class yaz|implement)",
    r"(algorithm|algoritma|optimize|performans)",
    r"(güvenlik|zafiyet|vulnerability)",
    r"kendini.*(düzelt|iyileştir|tamir)",
]


def detect_task_complexity(task: str) -> str:
    """
    Analyze task and return complexity tier: 'fast', 'balanced', or 'powerful'.
    """
    task_lower = task.lower().strip()

    # Check for simple patterns
    for pattern in SIMPLE_TASK_PATTERNS:
        if re.search(pattern, task_lower):
            return "fast"

    # Check for complex patterns
    for pattern in COMPLEX_TASK_PATTERNS:
        if re.search(pattern, task_lower):
            return "powerful"

    # Check task length as heuristic
    word_count = len(task_lower.split())
    if word_count <= 5:
        return "fast"
    elif word_count >= 30:
        return "powerful"

    return "balanced"


def select_model_for_tier(tier: str, available_models: list) -> Optional[str]:
    """
    Select best available model for the given tier.
    Falls back to next tier if no models available.
    """
    tier_order = ["fast", "balanced", "powerful"]
    tier_idx = tier_order.index(tier) if tier in tier_order else 1

    # Try current tier and fall forward
    for i in range(tier_idx, len(tier_order)):
        current_tier = tier_order[i]
        for model in MODEL_TIERS.get(current_tier, []):
            # Check if model is available (case-insensitive partial match)
            for avail in available_models:
                if model.lower() in avail.lower() or avail.lower() in model.lower():
                    return avail

    # Fall back: try any tier
    for t in tier_order:
        for model in MODEL_TIERS.get(t, []):
            for avail in available_models:
                if model.lower() in avail.lower() or avail.lower() in model.lower():
                    return avail

    # Last resort: return first available
    return available_models[0] if available_models else None


def auto_select_model(task: str, list_models_fn=None) -> Optional[str]:
    """
    Automatically select the best model for a task.
    Returns model name or None if auto-select not possible.

    list_models_fn: callable returning list[str] of available models.
                    If None, tries to import from cont.
    """
    try:
        if list_models_fn is None:
            from cont import list_available_models
            list_models_fn = list_available_models
        available = list_models_fn()
        if not available:
            return None

        tier = detect_task_complexity(task)
        model = select_model_for_tier(tier, available)

        if model:
            _debug(f"Auto-select: tier={tier}, model={model}")

        return model
    except Exception as e:
        _debug(f"Auto-select failed: {e}")
        return None
