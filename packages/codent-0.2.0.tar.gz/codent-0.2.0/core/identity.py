# core/identity.py
"""Identity & Home Management — config dirs, SOUL.md, startup context."""

import json
from pathlib import Path
from datetime import datetime


# ── Config paths ──
CONT_CONFIG_DIR = Path.home() / ".config" / "cont"
CONT_HOME_FILE = CONT_CONFIG_DIR / "HOME"
CONT_SOUL_FILE = CONT_CONFIG_DIR / "SOUL.md"
CONT_STATE_FILE = CONT_CONFIG_DIR / "context" / "current_state.json"


def _ensure_config_dir():
    """Ensure config directories exist."""
    CONT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    (CONT_CONFIG_DIR / "context").mkdir(exist_ok=True)
    (CONT_CONFIG_DIR / "memory").mkdir(exist_ok=True)
    (CONT_CONFIG_DIR / "watcher").mkdir(exist_ok=True)
    (CONT_CONFIG_DIR / "recipes").mkdir(exist_ok=True)
    (CONT_CONFIG_DIR / "patches").mkdir(exist_ok=True)

    # Create default watched_paths.txt if not exists
    watched_paths_file = CONT_CONFIG_DIR / "context" / "watched_paths.txt"
    if not watched_paths_file.exists():
        default_paths = f"""# Paths to watch for file changes
# One path per line, comments start with #

{Path.home() / "projects"}
"""
        watched_paths_file.write_text(default_paths)

    # Ensure starter learning data exists
    _ensure_learning_data()


def _ensure_learning_data():
    """Create starter recipes, vocabulary, and patches on first run."""
    recipes_dir = CONT_CONFIG_DIR / "recipes"
    patches_dir = CONT_CONFIG_DIR / "patches"
    vocab_file = CONT_CONFIG_DIR / "vocabulary.json"

    # --- Starter Recipes ---
    _starter_recipes = {
        "file_find": {
            "name": "file_find",
            "triggers": ["bul", "find", "göster", "show", "nerede", "where", "list", "oku", "read"],
            "exclude_triggers": ["ve düzelt", "and fix", "ve değiştir", "and change"],
            "steps": [
                {"tool": "list_dir", "purpose": "find the target directory/file"},
                {"tool": "read_file", "purpose": "read content"},
                {"action": "respond", "purpose": "report findings"}
            ],
            "forbidden_tools": ["write_file", "apply_patch", "run_shell"],
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "code_fix": {
            "name": "code_fix",
            "triggers": ["düzelt", "fix", "hata", "bug", "error", "patch"],
            "exclude_triggers": [],
            "steps": [
                {"tool": "read_file", "purpose": "read current code"},
                {"tool": "search_files", "purpose": "find related issues"},
                {"tool": "apply_patch", "purpose": "apply minimal fix"},
                {"tool": "run_shell", "purpose": "verify fix compiles"}
            ],
            "forbidden_tools": [],
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "search_code": {
            "name": "search_code",
            "triggers": ["ara", "search", "grep", "bul...içinde"],
            "exclude_triggers": ["ve düzelt", "and fix"],
            "steps": [
                {"tool": "search_files", "purpose": "search for pattern"},
                {"tool": "read_file", "purpose": "read matching files for context"},
                {"action": "respond", "purpose": "report search results"}
            ],
            "forbidden_tools": ["write_file", "apply_patch"],
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "explain_code": {
            "name": "explain_code",
            "triggers": ["açıkla", "explain", "ne yapıyor", "what does", "how does", "nasıl"],
            "exclude_triggers": [],
            "steps": [
                {"tool": "read_file", "purpose": "read the code"},
                {"action": "respond", "purpose": "explain the code clearly"}
            ],
            "forbidden_tools": ["write_file", "apply_patch", "run_shell"],
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "run_command": {
            "name": "run_command",
            "triggers": ["çalıştır", "run", "execute", "test et", "derle", "compile"],
            "exclude_triggers": [],
            "steps": [
                {"tool": "run_shell", "purpose": "execute the command"},
                {"action": "respond", "purpose": "report output"}
            ],
            "forbidden_tools": [],
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
    }

    for name, recipe in _starter_recipes.items():
        recipe_file = recipes_dir / f"{name}.json"
        if not recipe_file.exists():
            try:
                recipe_file.write_text(
                    json.dumps(recipe, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    # --- Starter Vocabulary ---
    if not vocab_file.exists():
        vocab = {
            "commands": {
                "bul": {"en": "find", "intent": "read", "example": "bul config dosyasını → find config file"},
                "göster": {"en": "show", "intent": "read", "example": "göster hataları → show errors"},
                "düzelt": {"en": "fix", "intent": "write", "example": "düzelt hatayı → fix the bug"},
                "sil": {"en": "delete", "intent": "write", "example": "sil log dosyalarını → delete log files"},
                "ara": {"en": "search", "intent": "read", "example": "ara TODO → search for TODO"},
                "oluştur": {"en": "create", "intent": "write", "example": "oluştur test.py → create test.py"},
                "çalıştır": {"en": "run", "intent": "execute", "example": "çalıştır testleri → run tests"},
                "aç": {"en": "open", "intent": "read", "example": "aç tarayıcıda → open in browser"},
                "kapat": {"en": "close", "intent": "execute"},
                "karşılaştır": {"en": "compare", "intent": "read"},
                "birleştir": {"en": "merge", "intent": "write"},
                "yedekle": {"en": "backup", "intent": "write"},
                "geri al": {"en": "undo/revert", "intent": "write"},
                "kontrol et": {"en": "check/verify", "intent": "read"},
                "derle": {"en": "compile/build", "intent": "execute"},
                "test et": {"en": "test", "intent": "execute"},
                "güncelle": {"en": "update", "intent": "write"},
                "yaz": {"en": "write", "intent": "write", "example": "yaz dosyaya → write to file"},
                "oku": {"en": "read", "intent": "read", "example": "oku dosyayı → read the file"},
                "ekle": {"en": "add", "intent": "write"},
                "kaldır": {"en": "remove", "intent": "write"},
                "taşı": {"en": "move", "intent": "write"},
                "kopyala": {"en": "copy", "intent": "write"},
                "değiştir": {"en": "change/modify", "intent": "write"},
                "incele": {"en": "inspect/review", "intent": "read"},
                "listele": {"en": "list", "intent": "read"},
                "yükle": {"en": "install/load", "intent": "execute"},
                "indir": {"en": "download", "intent": "execute"},
                "kaydet": {"en": "save", "intent": "write"},
                "geri yükle": {"en": "restore", "intent": "write"},
                "temizle": {"en": "clean", "intent": "write"},
                "yapılandır": {"en": "configure", "intent": "write"},
            },
            "context_words": {
                "dosya": {"en": "file"},
                "klasör": {"en": "folder/directory"},
                "hata": {"en": "error/bug"},
                "satır": {"en": "line"},
                "fonksiyon": {"en": "function"},
                "değişken": {"en": "variable"},
                "sınıf": {"en": "class"},
                "modül": {"en": "module"},
                "paket": {"en": "package"},
                "bağımlılık": {"en": "dependency"},
                "test": {"en": "test"},
                "sonuç": {"en": "result"},
                "çıktı": {"en": "output"},
                "girdi": {"en": "input"},
                "proje": {"en": "project"},
                "dizin": {"en": "directory/index"},
            },
            "patterns": {
                "X dosyasını bul": "find file X",
                "X klasöründe ara": "search in directory X",
                "X ile Y'yi karşılaştır": "compare X with Y",
                "son değişiklikleri göster": "show recent changes",
                "hataları düzelt": "fix the errors",
                "testleri çalıştır": "run tests",
                "X fonksiyonunu açıkla": "explain function X",
                "X dosyasını oku": "read file X",
                "X dosyasına yaz": "write to file X",
                "tüm Y dosyalarını bul": "find all Y files",
            },
            "learned_at": "2025-01-01T00:00:00"
        }
        try:
            vocab_file.write_text(
                json.dumps(vocab, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    # --- Starter Patches ---
    _starter_patches = {
        "read_only_guard": {
            "id": "read_only_guard",
            "trigger_patterns": ["bul", "find", "göster", "show", "ara", "search", "nerede", "where", "list", "oku", "read"],
            "exclude_patterns": ["ve düzelt", "and fix", "ve değiştir", "and change", "ve yaz", "and write"],
            "patch_text": "STRICT: This is a READ-ONLY task. Do NOT use write_file, apply_patch, or destructive run_shell. Only use list_dir, read_file, search_files.",
            "task_types": ["file_read", "search"],
            "priority": 10,
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "turkish_boost": {
            "id": "turkish_boost",
            "trigger_patterns": ["ı", "ğ", "ü", "ş", "ö", "ç", "İ", "Ğ", "Ü", "Ş", "Ö", "Ç"],
            "exclude_patterns": [],
            "patch_text": "User writes in Turkish. Key commands: bul=find, göster=show, düzelt=fix, sil=delete, ara=search, yaz=write, oku=read, çalıştır=run. Match intent from these words FIRST.",
            "task_types": ["all"],
            "priority": 5,
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "short_answer": {
            "id": "short_answer",
            "trigger_patterns": ["nedir", "what is", "kaç", "how many", "hangisi", "which"],
            "exclude_patterns": ["açıkla", "explain", "detaylı", "detailed"],
            "patch_text": "Give a SHORT answer. Max 3 sentences unless user asks for detail.",
            "task_types": ["general", "question"],
            "priority": 3,
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
        "no_repeat_tools": {
            "id": "no_repeat_tools",
            "trigger_patterns": ["bul", "find", "ara", "search", "göster", "show", "oku", "read", "düzelt", "fix"],
            "exclude_patterns": [],
            "patch_text": "NEVER call the same tool with the same arguments twice. If a tool returns empty/error, do NOT retry — report the result and move on.",
            "task_types": ["all"],
            "priority": 15,
            "active": True,
            "created_at": "2025-01-01T00:00:00"
        },
    }

    for patch_id, patch in _starter_patches.items():
        patch_file = patches_dir / f"{patch_id}.json"
        if not patch_file.exists():
            try:
                patch_file.write_text(
                    json.dumps(patch, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    # --- Starter Automations (YAML) ---
    automations_dir = CONT_CONFIG_DIR / "automations"
    automations_dir.mkdir(exist_ok=True)

    _starter_automations = {
        "morning_briefing": {
            "name": "morning_briefing",
            "description": "Show status when Cont starts for the first time today",
            "trigger": {"event": "schedule.daily", "time": "first_launch"},
            "actions": [
                {"shell": "git -C {repo_root} log --oneline --since='yesterday' 2>/dev/null | head -10",
                 "label": "Yesterday's commits"},
                {"shell": "df -h / | tail -1",
                 "label": "Disk usage"},
                {"shell": "find {repo_root} -name '*.py' -newer {repo_root}/.git/index -not -path '*/.venv/*' -not -path '*/__pycache__/*' 2>/dev/null | head -10",
                 "label": "Uncommitted Python changes"},
                {"shell": "find {repo_root}/logs -name '*.jsonl' 2>/dev/null | wc -l",
                 "label": "Log file count"},
            ],
            "enabled": True,
        },
        "disk_cleanup": {
            "name": "disk_cleanup",
            "description": "Clean up temp files and old logs daily",
            "trigger": {"event": "schedule.daily"},
            "actions": [
                {"shell": "find /tmp -user $USER -mtime +7 -delete 2>/dev/null; echo 'tmp cleaned'",
                 "label": "Clean old /tmp files"},
                {"shell": "find {repo_root}/logs -name '*.jsonl' -mtime +30 -delete 2>/dev/null; echo 'old logs cleaned'",
                 "label": "Clean old log files"},
                {"shell": "find {repo_root} -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null; echo 'pycache cleaned'",
                 "label": "Clean __pycache__"},
                {"shell": "find {repo_root} -name '*.pyc' -delete 2>/dev/null; echo 'pyc cleaned'",
                 "label": "Clean .pyc files"},
            ],
            "enabled": True,
        },
        "test_on_change": {
            "name": "test_on_change",
            "description": "Run syntax check and tests when Python files change",
            "trigger": {
                "event": "file.modified",
                "conditions": {
                    "path_pattern": "*.py",
                    "exclude_pattern": ["test_*", "__pycache__/*", ".venv/*"],
                },
            },
            "actions": [
                {"shell": "python3 -m py_compile {file_path}",
                 "label": "Syntax check", "on_fail": "report"},
                {"shell": "python3 -m pytest tests/ -x --tb=short -q 2>/dev/null || echo 'No tests or tests failed'",
                 "label": "Run tests", "on_fail": "report"},
            ],
            "enabled": False,
        },
    }

    try:
        import yaml as _yaml
        for auto_name, auto_data in _starter_automations.items():
            auto_file = automations_dir / f"{auto_name}.yaml"
            if not auto_file.exists():
                try:
                    auto_file.write_text(
                        _yaml.dump(auto_data, default_flow_style=False,
                                   allow_unicode=True, sort_keys=False),
                        encoding="utf-8")
                except Exception:
                    pass
    except ImportError:
        # No PyYAML — write as JSON fallback
        for auto_name, auto_data in _starter_automations.items():
            auto_file = automations_dir / f"{auto_name}.yaml"
            if not auto_file.exists():
                try:
                    auto_file.write_text(
                        json.dumps(auto_data, ensure_ascii=False, indent=2),
                        encoding="utf-8")
                except Exception:
                    pass


def get_cont_home() -> Path:
    """Get Cont's stable home directory."""
    _ensure_config_dir()

    if CONT_HOME_FILE.exists():
        home = CONT_HOME_FILE.read_text().strip()
        if home and Path(home).exists():
            return Path(home)

    # Fallback: try to find cont directory
    candidates = [
        Path.home() / "projects" / "cont",
        Path.home() / "cont",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "cont.py").exists():
            set_cont_home(candidate)
            return candidate

    return Path.cwd()

def set_cont_home(path: Path) -> None:
    """Set Cont's home directory."""
    _ensure_config_dir()
    CONT_HOME_FILE.write_text(str(path.resolve()))
    print(f"Cont home set to: {path.resolve()}")

def get_soul() -> str:
    """Read SOUL.md content."""
    _ensure_config_dir()

    if CONT_SOUL_FILE.exists():
        return CONT_SOUL_FILE.read_text()

    # Create default SOUL.md
    default_soul = _get_default_soul()
    CONT_SOUL_FILE.write_text(default_soul)
    return default_soul

def _get_default_soul() -> str:
    """Generate default SOUL.md content."""
    return '''# SOUL.md - Cont Identity Document

## Who I Am
I am Cont, a local AI coding assistant running on this machine.
I am the offline alternative to Claude Code - privacy-focused, no internet required for core functions.
My source code lives in my home directory.

## My Home
My home directory is defined in ~/.config/cont/HOME
This is my reference point regardless of where I'm invoked from.
I should always know where my home is and be able to navigate back to it.

## My Owner
- Name: (Set via memory - use 'remember' to tell me)
- Preferences: (Learned over time)

## Behavior Rules
1. I verify before I claim - no hallucinations
2. I ask when uncertain instead of guessing
3. I check intent before writing - "find" means read, not modify
4. I remember important information for future sessions
5. I know my home directory regardless of current working directory
6. I create backups before modifying files

## What I Can Do
- Read and write files (within allowed paths)
- Execute safe shell commands
- Search files and code
- Remember and recall information
- Fetch web content (read-only)
- Open files in Explorer/Browser (WSL)
- Manage my own memory

## What I Cannot Do
- Execute sudo/root commands
- Send data to internet without explicit request
- Modify system files
- Write when user intent was read-only
- Make claims without verification

## Current Context
On startup, I read:
1. This SOUL.md for my identity
2. ~/.config/cont/context/current_state.json for live context
3. My memory database for relevant facts

## Communication Style
- Clear and concise
- Technical when needed
- Honest about limitations
- Proactive about remembering useful info
'''

def get_current_state() -> dict:
    """Read current state from context file."""
    if CONT_STATE_FILE.exists():
        try:
            state = json.loads(CONT_STATE_FILE.read_text())

            # Check if state is fresh (less than 30 seconds old)
            timestamp = state.get("timestamp", "")
            if timestamp:
                try:
                    state_time = datetime.fromisoformat(timestamp)
                    age = (datetime.now() - state_time).total_seconds()
                    state["_age_seconds"] = age
                    state["_fresh"] = age < 30
                except Exception:
                    state["_fresh"] = False

            return state
        except Exception:
            pass
    return {"_fresh": False}

def get_startup_context() -> str:
    """Build startup context string for system prompt."""
    context_parts = []

    # 1. Location awareness
    cont_home = get_cont_home()
    cwd = Path.cwd()

    context_parts.append(f"""
## Current Location
- My home: {cont_home}
- Current working directory: {cwd}
- In my home: {cwd.resolve() == cont_home.resolve()}
""")

    # 2. Current state (if watcher is running)
    state = get_current_state()
    if state:
        context_parts.append("## Live System State")

        if "recent_files" in state:
            recent = state["recent_files"][:5]
            if recent:
                context_parts.append("Recent file changes:")
                for f in recent:
                    context_parts.append(f"  - {f.get('action', '?')}: {f.get('path', '?')} ({f.get('time', '?')})")

        if "recent_commands" in state:
            recent = state["recent_commands"][:5]
            if recent:
                context_parts.append("Recent commands:")
                for c in recent:
                    context_parts.append(f"  - {c.get('cmd', '?')} ({c.get('time', '?')})")

        if "git_status" in state:
            git = state["git_status"]
            context_parts.append(f"Git: branch={git.get('branch', '?')}, uncommitted={git.get('uncommitted_changes', 0)}")

    # 3. Key memories (lazy import to avoid circular deps)
    try:
        from core.memory_store import memory_get_context
        key_memories = memory_get_context(limit=5)
        if key_memories:
            context_parts.append("\n## Key Memories")
            for mem in key_memories:
                context_parts.append(f"- [{mem['memory_type']}] {mem['content']}")
    except Exception:
        pass

    # 4. Learning system stats (lazy imports)
    try:
        from core.vocabulary import get_vocabulary_stats
        from core.recipes import load_recipes
        from core.prompt_patches import load_file_patches
        learning_parts = []
        # Vocabulary
        vstats = get_vocabulary_stats()
        if vstats.get("total", 0) > 0:
            learning_parts.append(f"Vocabulary: {vstats['commands']} commands, {vstats['context_words']} context words")
        # Recipes
        recipes = load_recipes()
        if recipes:
            learning_parts.append(f"Recipes: {len(recipes)} loaded")
        # File patches
        patches = load_file_patches()
        if patches:
            active = sum(1 for p in patches if p.get("active", True))
            learning_parts.append(f"Patches: {active} active")

        if learning_parts:
            context_parts.append("\n## Learning System")
            for lp in learning_parts:
                context_parts.append(f"- {lp}")
    except Exception:
        pass

    # 5. Automation system stats (lazy import)
    try:
        from core.automations import load_automations
        autos = load_automations()
        if autos:
            enabled = sum(1 for a in autos if a.get("enabled", True))
            context_parts.append(f"\n## Automations")
            context_parts.append(f"- {enabled}/{len(autos)} automations enabled")
            enabled_names = [a["name"] for a in autos if a.get("enabled", True)]
            if enabled_names:
                context_parts.append(f"- Active: {', '.join(enabled_names[:5])}")
    except Exception:
        pass

    return "\n".join(context_parts)
