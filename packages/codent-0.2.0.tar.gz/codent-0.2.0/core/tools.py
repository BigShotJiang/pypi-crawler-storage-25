# core/tools.py
"""
Tool implementations for Cont agent.

Filesystem, shell, search, navigation, and tool normalization.
All tool functions return JSON strings or plain text.

Dependencies injected via init_tools() — must be called before use.
"""

import json
import os
import re
import shlex
import subprocess
import time
from pathlib import Path

from core.path_resolution import normalize_path, path_exists_fuzzy

# Memory functions (optional — auto-retry disabled if unavailable)
try:
    from core.memory_store import (
        memory_upsert_env_snapshot, memory_log_attempt,
        memory_lookup_error, memory_is_autofix_enabled,
        memory_get_best_solution, memory_check_recent_failure,
        memory_increment_error_hits, _error_signature_from_output,
    )
    from core.env_snapshot import collect_env_snapshot
    _MEMORY_AVAILABLE = True
except ImportError:
    _MEMORY_AVAILABLE = False


# =====================================================================
# Module-level runtime state — set by init_tools()
# =====================================================================

_repo_root: Path = Path.cwd()
_debug_fn = lambda msg: None
_console = None
_allow_shell: bool = True
_get_cwd = lambda: Path.cwd()
_set_cwd = lambda p: None
_is_wsl_fn = lambda: False
_wsl_to_win_path_fn = lambda p: p
_current_log_path_fn = lambda: None  # returns current log path or None


def init_tools(*, repo_root, debug_fn, console, allow_shell,
               get_cwd, set_cwd, is_wsl_fn, wsl_to_win_path_fn,
               current_log_path_fn=None):
    """Initialize tool module with runtime dependencies from cont.py."""
    global _repo_root, _debug_fn, _console, _allow_shell
    global _get_cwd, _set_cwd, _is_wsl_fn, _wsl_to_win_path_fn
    global _current_log_path_fn
    _repo_root = repo_root
    _debug_fn = debug_fn
    _console = console
    _allow_shell = allow_shell
    _get_cwd = get_cwd
    _set_cwd = set_cwd
    _is_wsl_fn = is_wsl_fn
    _wsl_to_win_path_fn = wsl_to_win_path_fn
    if current_log_path_fn:
        _current_log_path_fn = current_log_path_fn


# =====================================================================
# Safety helpers
# =====================================================================

DANGEROUS_PATTERNS = [
    "rm -rf /", "rm -rf ~", "rm -rf $HOME",
    "mkfs", "dd if=", "shutdown", "reboot", "poweroff",
    "sudo ", ":(){", "fork bomb", "chmod -R 777 /",
    "> /dev/sd", "wget|sh", "curl|sh", "wget|bash", "curl|bash",
]


def block_dangerous(cmd: str):
    """Block dangerous shell commands."""
    cmd_lower = cmd.lower()
    for pattern in DANGEROUS_PATTERNS:
        if pattern.lower() in cmd_lower:
            raise ValueError(f"Dangerous command blocked: contains '{pattern}'")


_UNSAFE_STEP_PATTERNS = [
    (r"\brm\b.*\s+-rf\b", "rm -rf detected"),
    (r"\brm\s+-rf\b", "rm -rf detected"),
    (r"\bmkfs\b", "mkfs (filesystem format) detected"),
    (r"\bdd\b\s+if=", "dd command detected"),
    (r"\bshutdown\b", "shutdown command detected"),
    (r"\breboot\b", "reboot command detected"),
    (r":\(\)\s*\{", "fork bomb pattern detected"),
    (r"\bchmod\b\s+777\s+/", "chmod 777 on root detected"),
    (r"\bchown\b.*\s+/\s*$", "chown on root detected"),
    (r"\bchown\b.*\s+/[a-z]", "chown on system directory detected"),
]


def is_step_safe(cmd: str) -> tuple:
    """Check if a step command is safe to run. Returns (is_safe, reason)."""
    cmd_lower = cmd.lower()
    for pattern, reason in _UNSAFE_STEP_PATTERNS:
        if re.search(pattern, cmd_lower, re.IGNORECASE):
            return (False, reason)
    return (True, None)


def _shell_timeout(cmd: str) -> int:
    """Return timeout in seconds based on command type."""
    cmd_lower = cmd.lower().strip()
    if cmd_lower.startswith("find /") or cmd_lower.startswith("find \\"):
        return 15
    if any(c in cmd_lower for c in ("curl ", "wget ", "pip install", "npm install")):
        return 60
    return 30


def safe_path(p: str) -> Path:
    """
    Resolve path safely, respecting current working directory.

    - Absolute paths: Use as-is (if allowed)
    - Relative paths: Resolve from current CWD (set by navigate)
    - ~: Expand to home directory
    """
    p = normalize_path(p)
    path = Path(p).expanduser()

    if not path.is_absolute():
        cwd = _get_cwd()
        path = (cwd / path).resolve()
    else:
        path = path.resolve()

    # Security check - don't allow escaping to system directories
    forbidden = ["/etc", "/usr", "/bin", "/sbin", "/boot", "/root"]
    for f in forbidden:
        if str(path).startswith(f):
            raise ValueError(f"Access denied: {path}")

    return path


# =====================================================================
# Tool normalization constants
# =====================================================================

# Argument aliases — normalize before calling tool function
_ARG_ALIASES = {
    'run_shell': {'command': 'cmd', 'script': 'cmd'},
    'browser_open': {'link': 'url', 'address': 'url', 'site': 'url'},
    'read_file': {'filename': 'path', 'file': 'path', 'filepath': 'path'},
    'web_search': {'search_query': 'query', 'q': 'query'},
    'web_fetch': {'link': 'url', 'address': 'url'},
}

# Tool name aliases
_TOOL_NAME_ALIASES = {
    'open_browser': 'browser_open',
    'browse': 'browser_open',
    'browser': 'browser_open',
    'click': 'browser_click',
    'screenshot': 'browser_screenshot',
    'search': 'web_search',
    'fetch': 'web_fetch',
    'shell': 'run_shell',
    'bash': 'run_shell',
    'navigate': 'browser_open',
    'read_image': 'ocr',
    'ocr_image': 'ocr',
    'text_from_image': 'ocr',
}

# Per-tool hard caps (enforced in tool loop)
PER_TOOL_CAPS = {
    'web_search': 2,
    'web_fetch': 2,
    'browser_open': 2,
    'run_shell': 3,
    'list_dir': 2,
    'system_search': 2,
    'read_file': 3,
    'find_path': 2,
    'recall': 2,
    'remember': 2,
    'ocr': 2,
}

# Alternative tools to suggest when blocked
_TOOL_ALTERNATIVES = {
    'web_search': 'web_fetch, browser_open, browser_agent',
    'web_fetch': 'browser_open, browser_agent',
    'browser_open': 'browser_agent, web_fetch',
    'system_search': 'find_path, list_dir',
    'list_dir': 'find_path, system_search',
    'run_shell': 'system_search, list_dir, read_file',
    'read_file': 'system_search, find_path',
    'find_path': 'system_search, list_dir',
    'recall': 'system_search, list_memories',
}

_SEARCH_EXCLUDE_DIRS = {
    '.venv', 'venv', 'node_modules', '.git',
    '__pycache__', '.pytest_cache', '.mypy_cache',
    '.tox', '.eggs', '*.egg-info',
}


# =====================================================================
# Tool functions
# =====================================================================

def normalize_tool_call(tool_name: str, args: dict) -> tuple:
    """Normalize tool name and arguments before dispatch."""
    tool_name = _TOOL_NAME_ALIASES.get(tool_name, tool_name)

    if tool_name in _ARG_ALIASES:
        aliases = _ARG_ALIASES[tool_name]
        normalized = {}
        for key, value in args.items():
            normalized[aliases.get(key, key)] = value
        args = normalized

    return tool_name, args


def open_file(path: str) -> str:
    """Open file with its default Windows application (WSL only)."""
    if not _is_wsl_fn():
        return "Error: This tool only works in WSL environment"

    path = normalize_path(path)
    target = safe_path(path)
    if not target.exists():
        return f"Error: File does not exist: {path}"

    if not target.is_file():
        return f"Error: Not a file: {path}. Use open_in_explorer for folders."

    win_path = _wsl_to_win_path_fn(str(target))

    try:
        subprocess.Popen(["cmd.exe", "/c", "start", "", win_path],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return f"Opened with default app: {win_path}"
    except Exception as e:
        return f"Error opening file: {e}"


def list_dir(path: str = ".", recursive: bool = False, max_depth: int = 2) -> str:
    """List directory contents. If recursive, show tree up to max_depth."""
    path = normalize_path(path)

    try:
        if path == "." or path == "":
            full_path = _get_cwd()
        else:
            full_path = safe_path(path)
    except Exception as e:
        return f"Error: {e}"

    if not full_path.exists():
        dirname = Path(path).name
        if dirname:
            try:
                cmd = (
                    f'find {shlex.quote(str(Path.home() / "projects"))} '
                    f'-maxdepth 3 -type d -iname {shlex.quote(dirname)} '
                    f'-not -path "*/.venv/*" -not -path "*/.git/*" '
                    f'2>/dev/null | head -5'
                )
                proc = subprocess.run(cmd, shell=True, capture_output=True,
                                      text=True, timeout=5)
                if proc.stdout.strip():
                    found = proc.stdout.strip().split('\n')[0]
                    full_path = Path(found)
                    if _console:
                        _console.print(f"[dim]list_dir: {path} → {found}[/dim]")
                else:
                    return json.dumps({
                        "error": f"Dizin bulunamadı: {path}",
                        "hint": "~/projects/ altında da bulunamadı. Tam yol verin."
                    })
            except Exception:
                pass
        if not full_path.exists():
            return f"Error: Directory not found: {path}"

    if not full_path.is_dir():
        return f"Error: Not a directory: {path}"

    if recursive:
        try:
            depth = min(max_depth, 5)
            cmd = (
                f'find {shlex.quote(str(full_path))} -maxdepth {depth} '
                f'-not -path "*/.venv/*" -not -path "*/.git/*" '
                f'-not -path "*/node_modules/*" -not -path "*/__pycache__/*" '
                f'2>/dev/null | head -200'
            )
            proc = subprocess.run(cmd, shell=True, capture_output=True,
                                  text=True, timeout=10)
            if proc.stdout.strip():
                lines = proc.stdout.strip().split('\n')
                entries = []
                for line in lines:
                    rel = line.replace(str(full_path), ".", 1)
                    if rel == ".":
                        continue
                    entries.append(rel)
                return json.dumps({
                    "path": str(full_path),
                    "recursive": True,
                    "max_depth": depth,
                    "contents": entries
                })
        except Exception as e:
            _debug_fn(f"Recursive list_dir failed: {e}")

    try:
        entries = sorted(os.listdir(full_path))

        # Encoding safety
        safe_entries = []
        for entry in entries:
            try:
                entry.encode('utf-8')
                safe_entries.append(entry)
            except (UnicodeEncodeError, UnicodeDecodeError):
                safe_entry = entry.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
                safe_entries.append(safe_entry)
        entries = safe_entries

        result = []
        for entry in entries:
            entry_path = full_path / entry
            if entry_path.is_dir():
                result.append(f"{entry}/")
            else:
                result.append(entry)

        return json.dumps({"path": str(full_path), "contents": result})
    except Exception as e:
        return f"Error listing directory: {e}"


def read_file(path: str) -> str:
    """Read file with encoding safety."""
    path = normalize_path(path)

    # Don't read our own running log file
    _log_path = _current_log_path_fn()
    if _log_path:
        try:
            is_current = (
                os.path.abspath(path) == os.path.abspath(_log_path)
                or os.path.basename(path) == os.path.basename(_log_path)
            )
            if is_current:
                return json.dumps({
                    "error": "Bu dosya şu anda yazılıyor, okunamaz.",
                    "hint": "Önceki log dosyalarını okuyabilirsin."
                })
        except Exception:
            pass

    try:
        full_path = safe_path(path)
    except Exception as e:
        return f"Error: {e}"

    if not full_path.exists():
        candidates = [
            _repo_root / path,
            Path(path).expanduser(),
            Path.home() / path,
            Path(os.path.join(os.getcwd(), path)),
        ]
        if not path.startswith("/"):
            candidates.append(Path.home() / "projects" / path)
        found = None
        for c in candidates:
            try:
                c = c.resolve()
                if c.exists() and c.is_file():
                    found = c
                    break
            except Exception:
                continue
        if found is None:
            return f"Error: File not found: {path}"
        full_path = found

    if not full_path.is_file():
        return f"Error: Not a file: {path}"

    try:
        content = full_path.read_text(encoding='utf-8', errors='replace')
        return content
    except UnicodeDecodeError:
        try:
            content = full_path.read_text(encoding='latin-1')
            return content
        except Exception as e:
            return f"Error reading file: {e}"
    except Exception as e:
        return f"Error reading file: {e}"


def write_file(path: str, content: str) -> dict:
    """Write content to file."""
    path = normalize_path(path)
    p = safe_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return {"status": "ok", "path": str(p.relative_to(_repo_root)), "bytes": len(content)}


def apply_patch(path: str, start_line: int, end_line: int, replacement: str) -> dict:
    """Apply a line-range patch to a file."""
    path = normalize_path(path)
    p = safe_path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")

    lines = p.read_text(errors="replace").splitlines(keepends=True)
    total_lines = len(lines)

    if start_line < 1 or end_line < 1:
        raise ValueError("Line numbers must be >= 1")
    if start_line > end_line:
        raise ValueError(f"start_line ({start_line}) > end_line ({end_line})")
    if start_line > total_lines + 1:
        raise ValueError(f"start_line ({start_line}) beyond file length ({total_lines})")

    start_idx = start_line - 1
    end_idx = min(end_line, total_lines)

    repl_lines = replacement.splitlines(keepends=True)
    if repl_lines and not repl_lines[-1].endswith('\n'):
        repl_lines[-1] += '\n'

    new_lines = lines[:start_idx] + repl_lines + lines[end_idx:]
    p.write_text("".join(new_lines))

    return {
        "status": "ok",
        "path": str(p.relative_to(_repo_root)),
        "lines_removed": end_idx - start_idx,
        "lines_added": len(repl_lines),
        "new_total_lines": len(new_lines)
    }


def run_shell(cmd: str) -> str:
    """Run shell command safely, with auto-retry on mapped errors."""
    if not _allow_shell:
        raise PermissionError("Shell commands are disabled")
    block_dangerous(cmd)

    t0 = time.time()
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=_repo_root,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding='utf-8',
        errors='replace',
        timeout=_shell_timeout(cmd),
    )
    duration_ms = int((time.time() - t0) * 1000)

    output = result.stdout
    auto_fix_note = ""

    # Log attempt to memory DB (swallow errors)
    env_id = None
    if _MEMORY_AVAILABLE:
        try:
            snapshot = collect_env_snapshot()
            env_id = memory_upsert_env_snapshot(snapshot)
            memory_log_attempt(env_id, cmd, result.returncode, output, duration_ms)
        except Exception as e:
            _debug_fn(f"Memory logging failed: {e}")

    # Auto-retry logic: only if command failed
    if result.returncode != 0 and env_id and _MEMORY_AVAILABLE:
        try:
            error_sig = _error_signature_from_output(output)
            if error_sig:
                mapping = memory_lookup_error(error_sig)
                if mapping:
                    problem_sig = mapping["problem_signature"]
                    if not memory_is_autofix_enabled(problem_sig):
                        auto_fix_note = f"\n[memory] mapping found but autofix disabled: {problem_sig}"
                    else:
                        sol = memory_get_best_solution(problem_sig, env_id=env_id)
                        if sol:
                            # Safety check
                            unsafe_step = None
                            unsafe_reason = None
                            for step in sol["steps"]:
                                safe, reason = is_step_safe(step)
                                if not safe:
                                    unsafe_step = step
                                    unsafe_reason = reason
                                    break

                            if unsafe_step:
                                auto_fix_note = f"\n[memory] auto-fix blocked (unsafe step): {unsafe_reason}"
                            else:
                                recent_fail = memory_check_recent_failure(sol["solution_id"], env_id, hours=24)
                                if not recent_fail:
                                    fix_ok = True
                                    for step in sol["steps"]:
                                        step_exit, step_out, step_dur = _run_shell_capture(step, solution_id=sol["solution_id"])
                                        if step_exit != 0:
                                            fix_ok = False
                                            break

                                    memory_increment_error_hits(error_sig)

                                    if fix_ok:
                                        retry_exit, retry_out, retry_dur = _run_shell_capture(cmd, solution_id=None)
                                        retry_status = "ok" if retry_exit == 0 else "fail"
                                        auto_fix_note = f"\n[memory] auto-fix applied: {problem_sig} (solution_id={sol['solution_id']}) -> retry {retry_status}"
                                        output = retry_out
                                        result = type('obj', (object,), {'returncode': retry_exit, 'stdout': retry_out})()
                                    else:
                                        auto_fix_note = f"\n[memory] auto-fix attempted: {problem_sig} (solution_id={sol['solution_id']}) -> fix steps failed"
        except Exception as e:
            _debug_fn(f"Auto-retry failed: {e}")

    if len(output) > 15000:
        output = output[:15000] + "\n... (truncated)"
    return f"[exit code: {result.returncode}]\n{output}{auto_fix_note}"


def _run_shell_capture(cmd: str, solution_id: int = None) -> tuple:
    """Run shell command and return (exit_code, output, duration_ms)."""
    if not _allow_shell:
        raise PermissionError("Shell commands are disabled")
    block_dangerous(cmd)

    t0 = time.time()
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=_repo_root,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=_shell_timeout(cmd),
    )
    duration_ms = int((time.time() - t0) * 1000)
    output = result.stdout

    if _MEMORY_AVAILABLE:
        try:
            snapshot = collect_env_snapshot()
            env_id = memory_upsert_env_snapshot(snapshot)
            memory_log_attempt(env_id, cmd, result.returncode, output, duration_ms, solution_id=solution_id)
        except Exception as e:
            _debug_fn(f"Memory logging failed: {e}")

    return (result.returncode, output, duration_ms)


def search_files(pattern: str, path: str = ".", file_pattern: str = "*") -> str:
    """Search for pattern in files using grep with encoding safety."""
    path = normalize_path(path)
    p = safe_path(path)

    def _grep_search(search_path: Path, fp: str = file_pattern) -> str:
        cmd = ["grep", "-rn", "--include", fp]
        for d in _SEARCH_EXCLUDE_DIRS:
            cmd.extend(["--exclude-dir", d])
        cmd.extend([pattern, str(search_path)])
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=30,
            cwd=str(search_path)
        )
        return result.stdout

    try:
        output = _grep_search(p)

        if not output and (path == "." or str(p) == str(_get_cwd())):
            projects_dir = Path.home() / "projects"
            if projects_dir.exists():
                output = _grep_search(projects_dir)
                if not output and file_pattern == "*":
                    safe_pattern = shlex.quote(pattern)
                    cmd = (
                        f'grep -rl {safe_pattern} {shlex.quote(str(projects_dir))} '
                        f'--include="*.py" --include="*.json" --include="*.md" '
                        f'--include="*.yaml" --include="*.yml" --include="*.txt" '
                        f'--exclude-dir=.venv --exclude-dir=.git '
                        f'--exclude-dir=node_modules --exclude-dir=__pycache__ '
                        f'2>/dev/null | head -20'
                    )
                    proc = subprocess.run(cmd, shell=True, capture_output=True,
                                          text=True, timeout=15)
                    if proc.stdout.strip():
                        output = f"# File matches from {projects_dir}:\n" + proc.stdout.strip()

                if output and not output.startswith("#"):
                    output = f"# Results from {projects_dir}:\n" + output

        if not output:
            return "No matches found."
        if len(output) > 10000:
            output = output[:10000] + "\n... (truncated)"
        return output
    except subprocess.TimeoutExpired:
        return "Search timed out."


def find_path(query: str) -> str:
    """Smart path finder - tries multiple strategies to locate a path."""
    # Try system map first (instant)
    try:
        from core.system_map import find_in_map
        map_results = find_in_map(query, limit=10)
        if map_results:
            best = map_results[0]
            return json.dumps({
                "status": "found",
                "resolved_path": best["path"],
                "exists": True,
                "is_dir": best.get("entry_type") == "dir",
                "is_file": best.get("entry_type") == "file",
                "source": "system_map",
                "all_matches": [r["path"] for r in map_results[:10]],
            })
    except Exception:
        pass

    resolved, tried = path_exists_fuzzy(query)

    if resolved:
        return json.dumps({
            "status": "found",
            "resolved_path": resolved,
            "exists": True,
            "is_dir": Path(resolved).is_dir(),
            "is_file": Path(resolved).is_file(),
        })

    # Broad search using find command
    search_locations = [
        str(_get_cwd()),
        str(Path.home() / "projects"),
        str(Path.home()),
    ]
    results = []
    for loc in search_locations:
        if not Path(loc).exists():
            continue
        try:
            safe_query = shlex.quote(f"*{query}*")
            safe_loc = shlex.quote(loc)
            cmd = (
                f'find {safe_loc} -maxdepth 4 -iname {safe_query}'
                f' -not -path "*/.venv/*" -not -path "*/.git/*"'
                f' -not -path "*/node_modules/*" -not -path "*/__pycache__/*"'
                f' 2>/dev/null | head -20'
            )
            proc = subprocess.run(cmd, shell=True, capture_output=True,
                                  text=True, timeout=10)
            if proc.stdout.strip():
                results.extend(proc.stdout.strip().split('\n'))
        except Exception:
            continue
        if results:
            break

    if results:
        return json.dumps({
            "status": "found",
            "resolved_path": results[0],
            "exists": True,
            "is_dir": Path(results[0]).is_dir(),
            "is_file": Path(results[0]).is_file(),
            "all_matches": results[:10],
        })

    return json.dumps({
        "status": "not_found",
        "query": query,
        "tried_paths": tried,
        "suggestion": "Try providing absolute path or check if the path exists",
    })


def navigate(path: str) -> str:
    """Change Cont's working directory."""
    path = normalize_path(path)

    try:
        target = Path(path).expanduser().resolve()

        if not target.exists():
            resolved, tried = path_exists_fuzzy(path)
            if resolved:
                target = Path(resolved)
            else:
                return json.dumps({
                    "status": "error",
                    "message": f"Directory not found: {path}",
                    "tried": tried
                })

        if not target.is_dir():
            return json.dumps({
                "status": "error",
                "message": f"Not a directory: {path}"
            })

        old_cwd = _get_cwd()
        _set_cwd(target)

        contents = []
        try:
            entries = sorted(os.listdir(target))[:20]
            for e in entries:
                try:
                    e.encode('utf-8')
                    contents.append(e)
                except (UnicodeEncodeError, UnicodeDecodeError):
                    contents.append(e.encode('utf-8', errors='replace').decode('utf-8'))
        except Exception:
            pass

        return json.dumps({
            "status": "success",
            "previous": str(old_cwd),
            "current": str(target),
            "contents_preview": contents
        })
    except Exception as e:
        return json.dumps({
            "status": "error",
            "message": str(e)
        })


def system_search(query: str, type: str = None, extension: str = None,
                  project: str = None) -> str:
    """Search the filesystem index for files and folders."""
    try:
        from core.system_map import find_in_map, find_by_extension

        entry_type = type if type and type != "any" else None

        if query.startswith("*.") or (query.startswith(".") and len(query) <= 6):
            ext = query.lstrip("*")
            results = find_by_extension(ext, project=project)
        else:
            results = find_in_map(
                query, entry_type=entry_type,
                extension=extension, project=project
            )

        if not results:
            return json.dumps({
                "status": "not_found",
                "query": query,
                "hint": "Harita güncel olmayabilir. find_path veya search_files dene."
            })

        formatted = []
        for r in results:
            entry = {
                "path": r["path"],
                "name": r.get("name", ""),
                "type": r.get("entry_type", ""),
                "project": r.get("project", ""),
            }
            if r.get("size") and r["size"] > 0:
                entry["size"] = r["size"]
            formatted.append(entry)

        return json.dumps({
            "status": "found",
            "count": len(formatted),
            "results": formatted
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})
