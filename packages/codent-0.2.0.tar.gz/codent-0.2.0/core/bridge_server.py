# core/bridge_server.py
"""
WebSocket server for Chrome extension bridge.

Allows Cont to send messages to Claude.ai via Chrome extension
and receive responses back.

Usage:
    from core.bridge_server import BridgeServer

    bridge = BridgeServer()
    bridge.start()

    # Send a message to Claude.ai and wait for response
    response = bridge.send_and_wait("How should I fix the recall bug?")
    print(response)
"""

import asyncio
import json
import sys
import threading
import time
from typing import Optional, Callable

try:
    import websockets
    import websockets.server
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


class BridgeServer:
    """WebSocket bridge between Cont and Chrome extension on Claude.ai."""

    def __init__(self, port: int = 8766, on_response: Optional[Callable] = None):
        self.port = port
        self.on_response = on_response
        self.client = None  # Connected Chrome extension websocket
        self.loop = None
        self.thread = None
        self.running = False
        self._pending = {}  # msg_id -> {event, response, partial}
        self._msg_id = 0
        self._connected_event = threading.Event()

    def start(self):
        """Start WebSocket server in background thread."""
        if not HAS_WEBSOCKETS:
            raise ImportError(
                "websockets required: pip install websockets"
            )

        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        print(f"Bridge server started: ws://localhost:{self.port}")
        print(f"  Waiting for Chrome extension connection...")

    def stop(self):
        """Stop the server."""
        self.running = False
        if self.loop:
            self.loop.call_soon_threadsafe(self.loop.stop)

    def is_connected(self) -> bool:
        """Check if Chrome extension is connected."""
        return self.client is not None

    def wait_for_connection(self, timeout: float = 30) -> bool:
        """Wait for Chrome extension to connect."""
        return self._connected_event.wait(timeout=timeout)

    def send_message(self, text: str) -> int:
        """Send a message to Claude.ai (non-blocking). Returns msg_id."""
        self._msg_id += 1
        msg_id = self._msg_id

        self._pending[msg_id] = {
            "event": threading.Event(),
            "response": None,
            "partial": "",
        }

        self._ws_send({
            "type": "send_message",
            "text": text,
            "id": msg_id,
        })

        return msg_id

    def send_and_wait(self, text: str, timeout: float = 300) -> Optional[str]:
        """
        Send message to Claude.ai and wait for complete response.
        Main API for Cont integration.
        """
        if not self.is_connected():
            print("Chrome extension not connected.", file=sys.stderr)
            print("  1. Open claude.ai in Chrome", file=sys.stderr)
            print("  2. Load Cont Bridge extension", file=sys.stderr)
            return None

        msg_id = self.send_message(text)
        pending = self._pending.get(msg_id)
        if not pending:
            return None

        success = pending["event"].wait(timeout=timeout)

        response = pending.get("response")
        del self._pending[msg_id]

        if not success:
            print(f"Timeout ({timeout}s) waiting for Claude response",
                  file=sys.stderr)
            return pending.get("partial") or None

        return response

    def _ws_send(self, data: dict):
        """Send data to connected Chrome extension."""
        if self.client and self.loop:
            asyncio.run_coroutine_threadsafe(
                self.client.send(json.dumps(data)),
                self.loop,
            )

    def _run(self):
        """Run the event loop in background thread."""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._serve())

    async def _serve(self):
        """Start WebSocket server."""
        try:
            async with websockets.serve(
                self._handler, "localhost", self.port,
                reuse_address=True,
            ):
                while self.running:
                    await asyncio.sleep(0.1)
        except OSError as e:
            if e.errno == 98:  # Address already in use
                print(f"\n  Error: Port {self.port} already in use.", file=sys.stderr)
                print(f"  Fix: kill the old process with: lsof -ti :{self.port} | xargs kill -9", file=sys.stderr)
            else:
                raise

    async def _handler(self, websocket):
        """Handle WebSocket connection from Chrome extension."""
        self.client = websocket
        self._connected_event.set()
        print("Chrome extension connected")

        try:
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                    self._handle_message(msg)
                except json.JSONDecodeError:
                    pass
        except Exception:
            pass
        finally:
            self.client = None
            self._connected_event.clear()
            print("Chrome extension disconnected")

    def _handle_message(self, msg: dict):
        """Handle incoming message from Chrome extension."""
        msg_type = msg.get("type")
        msg_id = msg.get("id")

        if msg_type == "hello":
            print(f"  Claude.ai page: {msg.get('url', '?')}")

        elif msg_type == "send_ack":
            if msg.get("success"):
                print("  Message sent, waiting for response...")
            else:
                print(f"  Send failed: {msg.get('error')}", file=sys.stderr)
                if msg_id in self._pending:
                    self._pending[msg_id]["event"].set()

        elif msg_type == "response_streaming":
            if msg_id in self._pending:
                self._pending[msg_id]["partial"] = msg.get("text", "")
            text = msg.get("text", "")
            lines = text.count("\n")
            sys.stderr.write(
                f"\r  Streaming... ({lines} lines)  "
            )
            sys.stderr.flush()

        elif msg_type == "response_complete":
            sys.stderr.write("\r" + " " * 40 + "\r")
            sys.stderr.flush()
            print("  Response complete")
            text = msg.get("text", "")

            # Resolve the oldest pending request
            for pid, pending in self._pending.items():
                if not pending["event"].is_set():
                    pending["response"] = text
                    pending["event"].set()
                    break

            if self.on_response:
                self.on_response(text)

        elif msg_type == "pong":
            pass


def _kill_stale_port(port: int):
    """Kill any process holding the given port."""
    import subprocess as _sp
    try:
        result = _sp.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True, text=True, timeout=5,
        )
        pids = result.stdout.strip().split()
        for pid in pids:
            if pid.isdigit() and int(pid) != os.getpid():
                print(f"  Killing stale process on port {port} (PID {pid})")
                os.kill(int(pid), 9)
        if pids:
            import time
            time.sleep(0.5)
    except (FileNotFoundError, _sp.TimeoutExpired, OSError):
        pass


def start_bridge(port: int = 8766):
    """Start bridge server interactively."""
    _kill_stale_port(port)
    bridge = BridgeServer(port=port)
    bridge.start()

    print("\nUsage:")
    print("  Type a message to send to Claude.ai")
    print("  Ctrl+C to stop\n")

    try:
        while True:
            try:
                msg = input("Cont > ").strip()
            except EOFError:
                break
            if not msg:
                continue
            if msg in ("q", "quit", "exit"):
                break
            response = bridge.send_and_wait(msg)
            if response:
                print(f"\nClaude.ai:\n{response[:2000]}\n")
            else:
                print("No response received.\n")
    except KeyboardInterrupt:
        pass
    finally:
        bridge.stop()
        print("\nBridge stopped.")
