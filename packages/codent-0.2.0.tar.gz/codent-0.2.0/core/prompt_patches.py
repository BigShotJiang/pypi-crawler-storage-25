# core/prompt_patches.py
"""
File-based prompt patch system for local LLMs.

Small, focused rules learned from failures. These get loaded from JSON
files in ~/.config/cont/patches/ and injected into the system prompt
dynamically based on trigger pattern matching.
"""

import json
from pathlib import Path
from datetime import datetime


PATCHES_DIR = Path.home() / ".config" / "cont" / "patches"


def load_file_patches() -> list:
    """Load all patch JSON files from the patches directory."""
    patches = []
    if not PATCHES_DIR.exists():
        return patches

    for f in PATCHES_DIR.glob("*.json"):
        try:
            patch = json.loads(f.read_text(encoding="utf-8"))
            patch["_file"] = str(f)
            patches.append(patch)
        except Exception:
            continue
    return patches


def match_patches(task: str) -> list:
    """
    Match trigger_patterns against task text, exclude exclude_patterns,
    sort by priority (desc), limit to top 3.
    """
    patches = load_file_patches()
    if not patches:
        return []

    task_lower = task.lower()
    matched = []

    for patch in patches:
        if not patch.get("active", True):
            continue

        # Check exclude patterns first
        exclude = patch.get("exclude_patterns", [])
        if any(ex.lower() in task_lower for ex in exclude):
            continue

        # Check trigger patterns
        triggers = patch.get("trigger_patterns", [])
        if any(t.lower() in task_lower for t in triggers):
            matched.append(patch)

    # Sort by priority (higher first), limit to top 3
    matched.sort(key=lambda p: p.get("priority", 0), reverse=True)
    return matched[:3]


def format_patches_for_prompt(patches: list) -> str:
    """Format matched patches as a compact string for injection (~150 tokens)."""
    if not patches:
        return ""

    lines = ["FILE PATCHES:"]
    for patch in patches:
        patch_text = patch.get("patch_text", "")
        patch_id = patch.get("id", "?")
        lines.append(f"[{patch_id}] {patch_text}")

    return "\n".join(lines)


def record_patch_outcome(patch_id: str, success: bool, db_connect=None,
                         memory_init=None) -> bool:
    """Track success/fail for a file-based patch in the patch_file_stats table."""
    try:
        if memory_init:
            memory_init()
        if db_connect:
            conn = db_connect()
            try:
                conn.execute("""
                    INSERT INTO patch_file_stats (patch_id, success, created_at)
                    VALUES (?, ?, ?)
                """, (patch_id, 1 if success else 0, datetime.now().isoformat()))
                conn.commit()
                return True
            finally:
                conn.close()
    except Exception:
        pass
    return False


def get_patch_stats(db_connect=None, memory_init=None) -> list:
    """Get file-based patch stats for CLI reporting."""
    try:
        if memory_init:
            memory_init()
        if db_connect:
            conn = db_connect()
            try:
                cur = conn.execute("""
                    SELECT patch_id,
                           SUM(success) as successes,
                           COUNT(*) as total,
                           ROUND(CAST(SUM(success) AS FLOAT) / COUNT(*) * 100) as rate
                    FROM patch_file_stats
                    GROUP BY patch_id
                    ORDER BY total DESC
                """)
                return [{"id": r[0], "successes": r[1], "total": r[2],
                         "rate": f"{r[3]:.0f}%"} for r in cur.fetchall()]
            finally:
                conn.close()
    except Exception:
        pass
    return []


def save_patch(patch_id: str, trigger_patterns: list, patch_text: str,
               priority: int = 5, exclude_patterns: list = None,
               task_types: list = None) -> bool:
    """Save a new patch JSON file."""
    try:
        PATCHES_DIR.mkdir(parents=True, exist_ok=True)
        patch = {
            "id": patch_id,
            "trigger_patterns": trigger_patterns,
            "exclude_patterns": exclude_patterns or [],
            "patch_text": patch_text,
            "task_types": task_types or ["all"],
            "priority": priority,
            "active": True,
            "created_at": datetime.now().isoformat(),
        }
        filepath = PATCHES_DIR / f"{patch_id}.json"
        filepath.write_text(json.dumps(patch, ensure_ascii=False, indent=2),
                            encoding="utf-8")
        return True
    except Exception:
        return False
