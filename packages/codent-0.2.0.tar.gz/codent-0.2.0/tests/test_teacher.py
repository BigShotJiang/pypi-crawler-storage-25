"""
Tests for core/teacher.py — ChatGPT teacher for recipe generation.
Run: pytest tests/test_teacher.py -v
"""
import os

import pytest


class TestParseRecipeJson:
    """JSON extraction from various API response formats."""

    def test_clean_json(self):
        from core.teacher import _parse_recipe_json

        text = '{"id": "test_v1", "pattern_keywords": {"test": 3}, "steps": []}'
        result = _parse_recipe_json(text)
        assert result["id"] == "test_v1"

    def test_markdown_wrapped(self):
        from core.teacher import _parse_recipe_json

        text = '```json\n{"id": "test_v2", "pattern_keywords": {"x": 1}, "steps": []}\n```'
        result = _parse_recipe_json(text)
        assert result["id"] == "test_v2"

    def test_with_preamble(self):
        from core.teacher import _parse_recipe_json

        text = 'Here is the recipe:\n{"id": "test_v3", "pattern_keywords": {}, "steps": []}'
        result = _parse_recipe_json(text)
        assert result["id"] == "test_v3"

    def test_invalid_returns_none(self):
        from core.teacher import _parse_recipe_json

        assert _parse_recipe_json("not json at all") is None

    def test_empty_string(self):
        from core.teacher import _parse_recipe_json

        assert _parse_recipe_json("") is None

    def test_markdown_no_lang(self):
        from core.teacher import _parse_recipe_json

        text = '```\n{"id": "test_v4", "pattern_keywords": {}, "steps": []}\n```'
        result = _parse_recipe_json(text)
        assert result["id"] == "test_v4"


class TestShouldLearn:
    """Decision logic for when to invoke the teacher."""

    @pytest.fixture(autouse=True)
    def _manage_env(self):
        """Set/restore OPENAI_API_KEY for tests."""
        old = os.environ.get("OPENAI_API_KEY")
        yield
        if old is not None:
            os.environ["OPENAI_API_KEY"] = old
        else:
            os.environ.pop("OPENAI_API_KEY", None)

    def test_no_key_returns_false(self):
        from core.teacher import should_learn
        from unittest.mock import patch

        with patch("core.teacher.get_api_key", return_value=None):
            result = should_learn("do something complex")
        assert result is False

    def test_failed_task_blocked(self):
        """Failed tasks should NOT trigger learning — they produce junk recipes."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "karmaşık bir görev yap",
            episode={"success": 0, "tools_used": 10},
            recipe_match=None,
        )
        assert result is False

    def test_short_input(self):
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn("merhaba")
        assert result is False

    def test_good_recipe_skipped(self):
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "dosya oku ve özetle",
            recipe_match={"success_count": 5},
        )
        assert result is False

    def test_too_many_tools_blocked(self):
        """Excessive tool usage alone should NOT trigger learning."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "karmaşık bir görev yap",
            episode={"success": 1, "tools_used": 8},
            recipe_match=None,
        )
        assert result is False

    def test_command_skipped(self):
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn("/stats göster bana")
        assert result is False

    def test_no_recipe_no_episode_blocked(self):
        """No recipe + no episode should NOT trigger learning — no evidence of success."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "bir şey yap lütfen",
            episode=None,
            recipe_match=None,
        )
        assert result is False

    def test_browser_agent_success_triggers(self):
        """Verified browser_agent success SHOULD trigger learning."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "mevzuat sitesinden kanun bul",
            browser_agent_success=True,
        )
        assert result is True

    def test_explicit_teach_triggers(self):
        """Explicit /teach command SHOULD trigger learning."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "dosya okuma görevi",
            explicit_teach=True,
        )
        assert result is True

    def test_browser_agent_failure_blocked(self):
        """browser_agent_success=False should NOT trigger."""
        from core.teacher import should_learn

        os.environ["OPENAI_API_KEY"] = "test-key"
        result = should_learn(
            "mevzuat sitesinden kanun bul",
            browser_agent_success=False,
            episode={"success": 0, "tools_used": 5},
        )
        assert result is False


class TestBuildContextPrompt:
    """Context prompt construction for the teacher."""

    def test_basic_prompt(self):
        from core.teacher import _build_context_prompt

        prompt = _build_context_prompt("test görevi")
        assert "test görevi" in prompt
        assert "recipe üret" in prompt

    def test_with_context(self):
        from core.teacher import _build_context_prompt

        prompt = _build_context_prompt(
            "test görevi",
            context={"cwd": "/home/test", "repo_root": "/home/test/project"},
        )
        assert "/home/test" in prompt
        assert "Repo root" in prompt

    def test_with_failed_episode(self):
        from core.teacher import _build_context_prompt

        prompt = _build_context_prompt(
            "test görevi",
            failed_episode={
                "tools_used": 8,
                "tool_names": ["list_dir", "run_shell"],
            },
        )
        assert "BAŞARISIZ" in prompt
        assert "8" in prompt

    def test_full_context(self):
        from core.teacher import _build_context_prompt

        prompt = _build_context_prompt(
            "dosyayı analiz et",
            context={
                "cwd": "/home/user",
                "repo_root": "/home/user/repo",
                "prefetch_summary": "3 dosya bulundu",
                "memory_summary": "cont.py hatırlandı",
            },
            failed_episode={
                "tools_used": 5,
                "tool_names": ["read_file"],
                "error": "timeout",
                "response_preview": "Merhaba...",
            },
        )
        assert "dosyayı analiz et" in prompt
        assert "3 dosya bulundu" in prompt
        assert "cont.py hatırlandı" in prompt
        assert "timeout" in prompt


class TestApiKeyManagement:
    """API key storage and retrieval."""

    def test_get_from_env(self):
        from core.teacher import get_api_key
        from unittest.mock import patch
        import core.teacher as _mod

        # CONT_OPENAI_KEY has highest priority
        # Mock CONFIG_DIR to avoid reading real config file
        with patch.object(_mod, "CONFIG_DIR", _mod.Path("/nonexistent")):
            os.environ["CONT_OPENAI_KEY"] = "sk-test-env-key"
            try:
                key = get_api_key()
                assert key == "sk-test-env-key"
            finally:
                del os.environ["CONT_OPENAI_KEY"]

    def test_get_missing(self):
        from core.teacher import get_api_key

        old = os.environ.pop("OPENAI_API_KEY", None)
        # Don't test file-based — just env
        key = get_api_key()
        # May or may not return None (depends on config file existence)
        if old:
            os.environ["OPENAI_API_KEY"] = old

    def test_set_and_get(self, tmp_path):
        from core.teacher import set_api_key, get_api_key, CONFIG_DIR
        import core.teacher as _mod

        # Temporarily redirect CONFIG_DIR
        orig_dir = _mod.CONFIG_DIR
        _mod.CONFIG_DIR = tmp_path

        set_api_key("sk-test-saved-key")

        # Verify file was created
        key_file = tmp_path / "openai_key"
        assert key_file.exists()
        assert key_file.read_text().strip() == "sk-test-saved-key"

        _mod.CONFIG_DIR = orig_dir


class TestLearnRecipe:
    """Recipe learning (mocked API)."""

    def test_learn_no_key(self):
        from core.teacher import learn_recipe
        from unittest.mock import patch

        with patch("core.teacher.get_api_key", return_value=None):
            result = learn_recipe("test görev", api_key=None)
        assert result is None

    def test_learn_validates_fields(self):
        from core.teacher import learn_recipe
        from unittest.mock import patch

        # Mock _call_openai to return incomplete recipe
        with patch("core.teacher._call_openai") as mock_api:
            mock_api.return_value = '{"id": "test", "steps": []}'
            result = learn_recipe(
                "test görev", api_key="sk-fake"
            )
            # Missing pattern_keywords
            assert result is None

    def test_learn_parses_valid_recipe(self):
        from core.teacher import learn_recipe
        from unittest.mock import patch

        recipe_json = json.dumps({
            "id": "learned_v1",
            "pattern_keywords": {"test": 3, "görev": 2},
            "steps": [
                {"action": "read_file", "args": {"path": "."}, "expect": "ok"}
            ],
            "student_contract": ["ASLA tekrarlama"],
        })

        with patch("core.teacher._call_openai") as mock_api:
            mock_api.return_value = recipe_json
            result = learn_recipe("test görev yap", api_key="sk-fake")

        assert result is not None
        assert result["id"] == "learned_v1"
        assert result["source"] == "teacher"
        assert result["threshold"] == 4.0
        assert len(result["steps"]) == 1


class TestLearnAndSave:
    """Full learn + save pipeline (mocked API)."""

    def test_learn_and_save_to_db(self, tmp_path):
        from core.teacher import learn_and_save
        from core.recipes import init_recipe_db, list_recipes
        from unittest.mock import patch

        db = str(tmp_path / "test.db")
        conn = init_recipe_db(db)

        recipe_json = json.dumps({
            "id": "saved_recipe_v1",
            "pattern_keywords": {"kaydet": 3},
            "steps": [{"action": "respond", "args": {}, "expect": "ok"}],
        })

        with patch("core.teacher._call_openai") as mock_api:
            mock_api.return_value = recipe_json
            result = learn_and_save(
                "kaydet ve işle", conn, api_key="sk-fake"
            )

        assert result is not None
        assert result["id"] == "saved_recipe_v1"

        # Verify in DB
        all_recipes = list_recipes(conn)
        ids = {r["id"] for r in all_recipes}
        assert "saved_recipe_v1" in ids


# Need json import for TestLearnRecipe
import json
