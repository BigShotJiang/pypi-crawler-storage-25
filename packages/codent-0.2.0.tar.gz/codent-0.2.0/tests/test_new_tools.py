#!/usr/bin/env python3
"""
Unit tests for web_search, repo_fetch, and capabilities_report tools.
These tests verify security controls and validation logic.
"""

import sys
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.web import (
    web_search,
    repo_fetch,
    validate_repo_source,
    ALLOWED_REPO_HOSTS,
)
from cont import (
    capabilities_report,
    CAPABILITIES,
    CAPABILITY_DESCRIPTIONS,
    TOOLS,
    tool_call_signature,
)


class TestWebSearch:
    """Test web_search tool validation."""

    def test_empty_query_rejected(self):
        """web_search rejects empty query."""
        with pytest.raises(ValueError, match="cannot be empty"):
            web_search("")

    def test_whitespace_query_rejected(self):
        """web_search rejects whitespace-only query."""
        with pytest.raises(ValueError, match="cannot be empty"):
            web_search("   ")

    def test_max_results_clamped(self):
        """max_results is clamped to 1-10 range."""
        # This tests the internal clamping logic
        # We can't easily test the actual search without network
        # but we can verify the parameter handling
        pass  # Tested implicitly when search is mocked

    @patch('core.web.requests.post')
    def test_returns_structured_results(self, mock_post):
        """web_search returns structured results."""
        # Mock DuckDuckGo response HTML
        mock_response = MagicMock()
        mock_response.text = '''
        <html>
        <a class="result__a" href="https://example.com/page1">Test Title 1</a>
        <a class="result__snippet">This is the first snippet</a>
        <a class="result__a" href="https://example.com/page2">Test Title 2</a>
        <a class="result__snippet">This is the second snippet</a>
        </html>
        '''
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = web_search("test query", max_results=5)

        assert "query" in result
        assert result["query"] == "test query"
        assert "results" in result
        assert "count" in result
        assert isinstance(result["results"], list)

    @patch('core.web.requests.post')
    def test_filters_private_ip_results(self, mock_post):
        """web_search filters out results pointing to private IPs."""
        mock_response = MagicMock()
        mock_response.text = '''
        <html>
        <a class="result__a" href="http://192.168.1.1/admin">Private Admin</a>
        <a class="result__snippet">Private network page</a>
        <a class="result__a" href="https://example.com/safe">Safe Page</a>
        <a class="result__snippet">Public page content</a>
        </html>
        '''
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = web_search("test")

        # Private IP result should be filtered out
        urls = [r["url"] for r in result["results"]]
        assert "http://192.168.1.1/admin" not in urls

    @patch('core.web.requests.post')
    def test_returns_no_results_structure_when_empty(self, mock_post):
        """web_search returns structured no_results with suggestions when empty."""
        mock_response = MagicMock()
        mock_response.text = '<html><body>No results found</body></html>'
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = web_search("obscure query that returns nothing")

        assert result["no_results"] is True
        assert result["count"] == 0
        assert "suggestion" in result
        assert "backend_status" in result
        assert len(result["results"]) == 0

    @patch('core.web.requests.post')
    def test_no_results_includes_alternative_suggestions(self, mock_post):
        """web_search provides alternative query suggestions when no results."""
        mock_response = MagicMock()
        mock_response.text = '<html></html>'
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = web_search("some multi word query here")

        assert result["no_results"] is True
        assert "Alternative queries" in result["suggestion"] or "web_fetch" in result["suggestion"]


class TestRepoFetch:
    """Test repo_fetch tool validation."""

    def test_blocks_non_allowlisted_domains(self):
        """repo_fetch blocks domains not in allowlist."""
        with pytest.raises(ValueError, match="not allowed"):
            validate_repo_source("https://evil.com/malware/repo")

    def test_blocks_private_domain(self):
        """repo_fetch blocks private IP domains (via allowlist check)."""
        with pytest.raises(ValueError, match="not allowed"):
            validate_repo_source("https://192.168.1.1/repo")

    def test_allows_github(self):
        """repo_fetch allows github.com."""
        hostname, parsed = validate_repo_source("https://github.com/user/repo")
        assert hostname == "github.com"

    def test_allows_gitlab(self):
        """repo_fetch allows gitlab.com."""
        hostname, parsed = validate_repo_source("https://gitlab.com/user/repo")
        assert hostname == "gitlab.com"

    def test_allows_bitbucket(self):
        """repo_fetch allows bitbucket.org."""
        hostname, parsed = validate_repo_source("https://bitbucket.org/user/repo")
        assert hostname == "bitbucket.org"

    def test_refuses_writing_outside_external(self):
        """repo_fetch refuses paths that escape external/."""
        with pytest.raises(ValueError, match="escape"):
            repo_fetch("https://github.com/user/repo", "../../../etc/passwd")

    def test_absolute_path_sanitized(self):
        """repo_fetch sanitizes absolute paths to be under external/."""
        # Absolute paths have leading / stripped and are forced under external/
        # This is secure - /etc/passwd becomes external/etc/passwd
        # The test verifies the path doesn't escape, not that it's rejected
        # (Network errors from actual fetch are expected)
        try:
            repo_fetch("https://github.com/psf/requests", "/some/path")
        except ValueError as e:
            # Should fail at network level, not path validation
            assert "escape" not in str(e).lower()
        except Exception:
            pass  # Network errors are expected

    def test_dest_forced_under_external(self):
        """Destination is forced under external/ directory."""
        # This would try to create under REPO_ROOT which might not be writable in tests
        # Just verify validation passes for a clean relative path
        try:
            # Will fail at actual clone/download, but validates path handling
            repo_fetch("https://github.com/psf/requests", "mylib")
        except ValueError as e:
            # Should fail at network level, not path validation
            assert "escape" not in str(e).lower()
            assert "external" not in str(e).lower() or "exists" in str(e).lower()
        except Exception:
            pass  # Network errors are expected

    def test_blocks_file_scheme(self):
        """repo_fetch blocks file:// URLs."""
        with pytest.raises(ValueError, match="scheme"):
            validate_repo_source("file:///etc/passwd")


class TestCapabilitiesReport:
    """Test capabilities_report tool."""

    def test_returns_expected_structure(self):
        """capabilities_report returns expected structure."""
        result = capabilities_report()

        assert "capabilities" in result
        assert "descriptions" in result
        assert "limits" in result

    def test_has_required_capabilities(self):
        """capabilities_report includes all required flags."""
        result = capabilities_report()
        caps = result["capabilities"]

        assert "local_code_edit" in caps
        assert "web_fetch" in caps
        assert "web_search" in caps
        assert "repo_fetch" in caps
        assert "package_install" in caps
        assert "sudo" in caps

    def test_blocked_capabilities_are_false(self):
        """Blocked capabilities are marked as False."""
        result = capabilities_report()
        caps = result["capabilities"]

        assert caps["package_install"] is False
        assert caps["sudo"] is False
        assert caps["binary_execution"] is False
        assert caps["network_write"] is False

    def test_enabled_capabilities_are_true(self):
        """Enabled capabilities are marked as True."""
        result = capabilities_report()
        caps = result["capabilities"]

        assert caps["local_code_edit"] is True
        assert caps["web_fetch"] is True
        assert caps["web_search"] is True
        assert caps["repo_fetch"] is True

    def test_includes_limits(self):
        """capabilities_report includes operational limits."""
        result = capabilities_report()
        limits = result["limits"]

        assert "tool_budget" in limits
        assert "max_iterations" in limits
        assert "web_max_bytes" in limits
        assert "repo_max_mb" in limits
        assert "allowed_repo_hosts" in limits

    def test_allowed_repo_hosts_correct(self):
        """Allowed repo hosts list is correct."""
        result = capabilities_report()
        hosts = result["limits"]["allowed_repo_hosts"]

        assert "github.com" in hosts
        assert "gitlab.com" in hosts
        assert "bitbucket.org" in hosts


class TestAllowedRepoHosts:
    """Test the ALLOWED_REPO_HOSTS constant."""

    def test_github_in_list(self):
        assert "github.com" in ALLOWED_REPO_HOSTS

    def test_gitlab_in_list(self):
        assert "gitlab.com" in ALLOWED_REPO_HOSTS

    def test_bitbucket_in_list(self):
        assert "bitbucket.org" in ALLOWED_REPO_HOSTS

    def test_raw_github_in_list(self):
        assert "raw.githubusercontent.com" in ALLOWED_REPO_HOSTS

    def test_no_arbitrary_hosts(self):
        """Ensure common dangerous hosts are not in list."""
        assert "localhost" not in ALLOWED_REPO_HOSTS
        assert "127.0.0.1" not in ALLOWED_REPO_HOSTS
        assert "evil.com" not in ALLOWED_REPO_HOSTS


class TestToolRegistry:
    """Test that tool registry is complete and valid."""

    def test_all_tools_are_registered(self):
        """All expected tools are in TOOLS registry."""
        expected_tools = [
            "list_dir", "read_file", "write_file", "apply_patch",
            "run_shell", "search_files", "web_fetch", "web_search",
            "repo_fetch", "capabilities_report"
        ]
        for tool in expected_tools:
            assert tool in TOOLS, f"Missing tool: {tool}"

    def test_no_unknown_tools_like_commentary(self):
        """Mangled tool names like 'web_searchcommentary' are not registered."""
        assert "web_searchcommentary" not in TOOLS
        assert "list_dircommentary" not in TOOLS
        assert "read_fileextra" not in TOOLS

    def test_unknown_tool_not_callable(self):
        """Calling an unknown tool name should raise KeyError."""
        assert "unknown_tool_xyz" not in TOOLS
        with pytest.raises(KeyError):
            TOOLS["unknown_tool_xyz"]


class TestToolCallSignature:
    """Test tool call signature generation for repetition detection."""

    def test_same_call_same_signature(self):
        """Same tool + args produces same signature."""
        sig1 = tool_call_signature("web_search", {"query": "test"})
        sig2 = tool_call_signature("web_search", {"query": "test"})
        assert sig1 == sig2

    def test_different_args_different_signature(self):
        """Different args produce different signature."""
        sig1 = tool_call_signature("web_search", {"query": "test1"})
        sig2 = tool_call_signature("web_search", {"query": "test2"})
        assert sig1 != sig2

    def test_different_tool_different_signature(self):
        """Different tools produce different signature."""
        sig1 = tool_call_signature("web_search", {"query": "test"})
        sig2 = tool_call_signature("web_fetch", {"url": "test"})
        assert sig1 != sig2


class TestRepoFetchVerificationFields:
    """Test that repo_fetch returns fields required for verification."""

    @patch('core.web.subprocess.run')
    def test_repo_fetch_includes_verify_path(self, mock_run):
        """repo_fetch result includes verify_path for list_dir verification."""
        # Mock git clone success
        mock_proc = MagicMock()
        mock_proc.returncode = 0
        mock_proc.stdout = ""
        mock_run.return_value = mock_proc

        # This will fail because dest doesn't exist, but we can check structure
        try:
            result = repo_fetch("https://github.com/user/repo", "test_lib")
        except Exception:
            pass  # Expected to fail without real git

        # The function should include these fields in result_info
        # We can't fully test without mocking more, but structure is validated

    def test_result_info_has_action_required_field(self):
        """Result info structure should have action_required field."""
        # This tests the structure is correct by checking the function's internal dict
        # The actual test would need to mock git/network calls
        pass


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
