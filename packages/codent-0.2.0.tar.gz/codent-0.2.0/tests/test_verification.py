# tests/test_verification.py
"""Tests for the verification system."""

import pytest
from core.verification import (
    ToolResultTracker,
    ResponseVerifier,
    detect_hallucination_language,
    extract_claims,
    verify_claims,
)


class TestToolResultTracker:
    def test_record_read_file(self):
        tracker = ToolResultTracker()
        tracker.record("read_file", {"path": "test.py"}, "print('hello')", True)

        assert tracker.was_file_read("test.py")
        assert tracker.get_file_content("test.py") == "print('hello')"
        assert tracker.file_contains("test.py", "hello")
        assert not tracker.file_contains("test.py", "goodbye")

    def test_record_list_dir(self):
        tracker = ToolResultTracker()
        tracker.record("list_dir", {"path": "src"}, "main.py\nutils.py\nconfig.py", True)

        assert tracker.was_dir_listed("src")
        assert tracker.dir_contains("src", "main.py")
        assert not tracker.dir_contains("src", "test.py")

    def test_record_write_file(self):
        tracker = ToolResultTracker()
        tracker.record("write_file", {"path": "new.py", "content": "# new file"}, "ok", True)

        assert tracker.was_file_written("new.py")
        assert not tracker.was_file_written("other.py")


class TestHallucinationDetection:
    def test_detect_assumption_language(self):
        text = "I assume the file contains a main function."
        warnings = detect_hallucination_language(text)

        assert len(warnings) > 0
        assert any("assumption" in w[1] for w in warnings)

    def test_detect_uncertain_language(self):
        text = "The file probably has an error handler."
        warnings = detect_hallucination_language(text)

        assert len(warnings) > 0
        assert any("uncertain" in w[1] for w in warnings)

    def test_clean_response(self):
        text = "According to read_file output, line 5 shows: def main():"
        warnings = detect_hallucination_language(text)

        assert len(warnings) == 0

    def test_ignores_code_blocks(self):
        text = 'I found this in the code:\n```\nif likely_match:\n    return True\n```'
        warnings = detect_hallucination_language(text)
        assert not any("uncertain" in w[1] for w in warnings)

    def test_ignores_quoted_text(self):
        text = 'The function is called "most likely checker" in the codebase.'
        warnings = detect_hallucination_language(text)
        assert not any("uncertain" in w[1] for w in warnings)

    def test_single_warning_no_correction(self):
        """Single 'likely' outside quotes should NOT trigger correction in strict mode."""
        verifier = ResponseVerifier(strict_mode=True)
        response = "This is likely the cause of the error."
        is_valid, correction = verifier.verify_response(response)
        # Single warning → no correction (threshold = 2)
        assert is_valid

    def test_multiple_warnings_trigger_correction(self):
        """Multiple hallucination patterns should trigger correction."""
        verifier = ResponseVerifier(strict_mode=True)
        response = "I assume the file probably has an error handler."
        is_valid, correction = verifier.verify_response(response)
        # "I assume" + "probably" → 2 warnings → correction
        assert not is_valid


class TestClaimExtraction:
    def test_extract_file_contains_claim(self):
        response = "The file 'app.py' contains 'def main()'"
        claims = extract_claims(response)

        assert len(claims) > 0
        assert any(c.claim_type == "file_contains" for c in claims)

    def test_extract_file_created_claim(self):
        response = "I created the file 'new_module.py'"
        claims = extract_claims(response)

        assert len(claims) > 0
        assert any(c.claim_type == "file_written" for c in claims)


class TestClaimVerification:
    def test_verify_file_content_claim_valid(self):
        tracker = ToolResultTracker()
        tracker.record("read_file", {"path": "test.py"}, "def main():\n    pass", True)

        from core.verification import Claim
        claims = [Claim(
            text="file contains def main",
            claim_type="file_contains",
            referenced_path="test.py",
            referenced_content="def main"
        )]

        results = verify_claims(claims, tracker)
        assert len(results) == 1
        assert results[0].is_valid

    def test_verify_file_content_claim_invalid(self):
        tracker = ToolResultTracker()
        tracker.record("read_file", {"path": "test.py"}, "def other():\n    pass", True)

        from core.verification import Claim
        claims = [Claim(
            text="file contains def main",
            claim_type="file_contains",
            referenced_path="test.py",
            referenced_content="def main"
        )]

        results = verify_claims(claims, tracker)
        assert len(results) == 1
        assert not results[0].is_valid

    def test_verify_unread_file_claim(self):
        tracker = ToolResultTracker()
        # No files read

        from core.verification import Claim
        claims = [Claim(
            text="file contains something",
            claim_type="file_contains",
            referenced_path="never_read.py",
            referenced_content="something"
        )]

        results = verify_claims(claims, tracker)
        assert len(results) == 1
        assert not results[0].is_valid
        assert "never read" in results[0].reason.lower()


class TestResponseVerifier:
    def test_full_verification_flow(self):
        verifier = ResponseVerifier(strict_mode=True)

        # Simulate tool calls
        verifier.record_tool_call("list_dir", {"path": "."}, "src\ntests\nREADME.md", True)
        verifier.record_tool_call("read_file", {"path": "README.md"}, "# My Project\nThis is a test.", True)

        # Valid response
        response = """
        ## Verified Facts
        - [list_dir('.')] Found directories: src, tests, and README.md
        - [read_file('README.md')] Content shows: "# My Project"

        ## Answer
        The project has a README with title "My Project".
        """

        is_valid, correction = verifier.verify_response(response)
        # Should be mostly valid (structured format helps)
        assert correction is None or is_valid

    def test_invalid_claim_detected(self):
        verifier = ResponseVerifier(strict_mode=True)

        # Only list_dir called, not read_file
        verifier.record_tool_call("list_dir", {"path": "."}, "src\ntests", True)

        # Response claims file content without reading
        response = "The file 'config.py' contains 'DEBUG = True'"

        is_valid, correction = verifier.verify_response(response)
        # Should detect the unverified claim
        assert not is_valid or correction is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
