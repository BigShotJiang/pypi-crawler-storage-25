"""
Tests for bugs discovered during development.
Each test documents a real bug and verifies the fix.
Run: pytest tests/test_known_bugs.py -v
"""
import pytest
import sys
import os
import re
import json
from pathlib import Path
from unittest.mock import MagicMock

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestDecomposer:
    """Decomposer should only split genuinely compound tasks."""

    def setup_method(self):
        from core.decomposer import decompose_compound_task
        self.decompose = decompose_compound_task

    def test_simple_commands_not_decomposed(self):
        """Bug: 'list dir' was decomposed into 3 phases."""
        simple = [
            "list dir", "ls", "merhaba", "hello",
            "cont loglarını aç", "help", "devam",
        ]
        for cmd in simple:
            result = self.decompose(cmd)
            assert result == [], f"'{cmd}' should NOT be decomposed, got {result}"

    def test_turkish_common_words_not_locations(self):
        """Bug: 'su anda icindeki' treated 'anda' as directory."""
        bad_cases = [
            "su anda icindeki klasoru listele",
            "butun klasor yapisini agac gibi listele",
            "burada bulunan jsonlarin adlarini yazdir",
            "guzel simdi bunlari ozetle",
            "patron mevuzusu bitti",
        ]
        for cmd in bad_cases:
            result = self.decompose(cmd)
            assert result == [], f"'{cmd}' should NOT be decomposed, got {result}"

    def test_compound_tasks_decomposed(self):
        """These genuinely need decomposition."""
        compound = [
            "kosgeb-bot altındaki jsonları özetle",
            "RAG_main içindeki py dosyalarını listele",
        ]
        for cmd in compound:
            result = self.decompose(cmd)
            assert len(result) >= 2, f"'{cmd}' SHOULD be decomposed, got {result}"

    def test_short_input_never_decomposed(self):
        """Bug: even 2-word inputs were decomposed."""
        for cmd in ["list dir", "ls", "hi", "ok", "devam et"]:
            assert self.decompose(cmd) == [], f"'{cmd}' should NOT be decomposed"

    def test_empty_input(self):
        """Edge case: empty string should not crash."""
        assert self.decompose("") == []
        assert self.decompose("   ") == []


class TestSecurity:
    """Security tiers should block dangerous commands."""

    def setup_method(self):
        from core.safety import SecurityManager
        import tempfile
        self.tmpdir = tempfile.mkdtemp()
        db_path = Path(self.tmpdir) / "test.db"
        self.sm = SecurityManager(
            repo_root=Path(self.tmpdir),
            db_path=db_path,
            backup_dir=Path(self.tmpdir) / "backups",
            enabled=True,
        )

    def test_tier3_blocked(self):
        """rm -rf must be blocked."""
        result = self.sm.check("run_shell", {"cmd": "rm -rf /"})
        assert not result.allowed

    def test_tier0_allowed(self):
        """Safe read commands should pass."""
        result = self.sm.check("list_dir", {"path": "."})
        assert result.allowed

    def test_safe_read_file(self):
        """read_file should always be allowed (TIER_0)."""
        result = self.sm.check("read_file", {"path": "/some/file.txt"})
        assert result.allowed

    def test_sudo_blocked(self):
        """sudo commands must be blocked."""
        result = self.sm.check("run_shell", {"cmd": "sudo rm -rf /etc"})
        assert not result.allowed


class TestPostprocess:
    """_postprocess_response should catch false denials."""

    def test_denial_patterns_exist(self):
        """Denial regex list must be populated."""
        import cont
        assert hasattr(cont, 'DENIAL_PATTERNS')
        assert len(cont.DENIAL_PATTERNS) > 5

    def test_denial_detected_in_text(self):
        """Model denial patterns should match known phrases."""
        import cont
        denial_re = [re.compile(p, re.IGNORECASE) for p in cont.DENIAL_PATTERNS]

        denial_texts = [
            "Log dosyalarına erişemiyorum. İzinler gerekli.",
            "I can't read files on the filesystem.",
            "I don't have access to the file system.",
            "Dosya okuma yetkim yok.",
        ]
        for text in denial_texts:
            matched = any(p.search(text) for p in denial_re)
            assert matched, f"Denial not detected: '{text}'"

    def test_no_denial_in_normal_text(self):
        """Normal answers should not trigger denial detection."""
        import cont
        denial_re = [re.compile(p, re.IGNORECASE) for p in cont.DENIAL_PATTERNS]

        normal_texts = [
            "Iste dosya listesi: file1.py, file2.py",
            "Here are the search results.",
            "The function returns a list of items.",
            "Dosya basariyla okundu.",
        ]
        for text in normal_texts:
            matched = any(p.search(text) for p in denial_re)
            assert not matched, f"False denial detected: '{text}'"


class TestContextOverflow:
    """Context truncation should prevent overflow."""

    def test_truncation_exists(self):
        """_truncate_for_context function must exist."""
        import cont
        assert hasattr(cont, '_truncate_for_context'), \
            "Truncation function missing!"

    def test_short_messages_unchanged(self):
        """Messages under limit should not be modified."""
        import cont
        messages = [
            {"role": "system", "content": "You are an assistant."},
            {"role": "user", "content": "Hello world"},
        ]
        result = cont._truncate_for_context(messages, max_chars=20000)
        assert len(result) == 2
        assert result[0]["content"] == "You are an assistant."
        assert result[1]["content"] == "Hello world"

    def test_long_messages_truncated(self):
        """Messages exceeding limit should be cut."""
        import cont
        messages = [
            {"role": "system", "content": "S" * 10000},
            {"role": "user", "content": "U" * 15000},
        ]
        result = cont._truncate_for_context(messages, max_chars=12000)
        total = sum(len(m.get("content", "") or "") for m in result)
        assert total < 25000, f"Total {total} should be truncated"


class TestFeedbackCommands:
    """/iyi, /kotu, /not, /s should not be sent to LLM."""

    def test_feedback_patterns_recognized(self):
        """All feedback commands must start with /."""
        feedback_commands = ["/iyi", "/kotu", '/not "mesaj"', "/s"]
        for cmd in feedback_commands:
            assert cmd.startswith("/"), f"{cmd} should start with /"

    def test_handle_feedback_returns_true(self):
        """_handle_feedback_command should consume feedback input."""
        import cont
        # With a valid last_task_id, /iyi should be consumed
        # (even if saving fails, it should return True)
        result = cont._handle_feedback_command("/iyi", last_task_id=None)
        assert result is True  # Consumed even without task_id

    def test_non_feedback_returns_false(self):
        """Normal input should not be consumed."""
        import cont
        result = cont._handle_feedback_command("hello world", last_task_id=None)
        assert result is False

    def test_session_reset_not_feedback(self):
        """/s should NOT be consumed by feedback handler."""
        import cont
        result = cont._handle_feedback_command("/s", last_task_id=None)
        assert result is False


class TestBatchContinuation:
    """'devam' command should continue reading files."""

    def test_devam_detected_as_continuation(self):
        """Bug: 'devam' was treated as new task."""
        import cont
        assert cont._is_continuation("devam")
        assert cont._is_continuation("devam et")
        assert cont._is_continuation("continue")
        assert cont._is_continuation("next")

    def test_normal_input_not_continuation(self):
        """Regular tasks should not trigger continuation."""
        import cont
        assert not cont._is_continuation("list dir")
        assert not cont._is_continuation("hello")
        assert not cont._is_continuation("fix the bug")


class TestFilenamesSanitized:
    """Log filenames should be ASCII-safe."""

    def test_turkish_chars_replaced(self):
        """Bug: Turkish chars in filenames broke read_file."""
        import cont
        result = cont._sanitize_filename("dosyaları göster şimdi")
        # Should be ASCII-only
        assert result.isascii(), f"Not ASCII-safe: {result}"
        assert " " not in result
        # Should contain recognizable transliterated content
        assert "dosyalar" in result.lower()

    def test_special_chars_removed(self):
        """Slashes, dots, quotes should be removed/replaced."""
        import cont
        result = cont._sanitize_filename('test/file "name".log')
        assert result.isascii()
        assert "/" not in result
        assert '"' not in result

    def test_length_limit(self):
        """Filenames should be capped at max_len."""
        import cont
        long_input = "a" * 200
        result = cont._sanitize_filename(long_input, max_len=50)
        assert len(result) <= 50

    def test_empty_input(self):
        """Empty string should not crash."""
        import cont
        result = cont._sanitize_filename("")
        assert isinstance(result, str)


class TestWriteProtection:
    """Intent detection should correctly classify read vs write."""

    def test_read_intent_detected(self):
        """Read-only commands should be detected."""
        import cont
        assert cont.detect_user_intent("dosyalari bul") == "read"
        assert cont.detect_user_intent("find the config file") == "read"
        assert cont.detect_user_intent("show me the logs") == "read"

    def test_write_intent_detected(self):
        """Write commands should be detected."""
        import cont
        assert cont.detect_user_intent("fix the bug in main.py") == "write"
        assert cont.detect_user_intent("delete all log files") == "write"
        assert cont.detect_user_intent("create a new test file") == "write"

    def test_shell_destructive_detection(self):
        """Destructive shell commands should be flagged."""
        import cont
        assert cont.is_shell_destructive("rm -rf /tmp/test")
        assert cont.is_shell_destructive("rm file.txt")
        assert not cont.is_shell_destructive("ls -la")
        assert not cont.is_shell_destructive("cat file.txt")
        assert not cont.is_shell_destructive("grep pattern file")


class TestToolBudget:
    """Tool budget should prevent wasteful tool spirals."""

    def test_budget_class_exists(self):
        """ToolBudget class must exist."""
        import cont
        assert hasattr(cont, 'DynamicToolBudget')

    def test_duplicate_blocking(self):
        """Same tool+args called twice should be blocked."""
        import cont
        budget = cont.DynamicToolBudget()
        allowed1, msg1 = budget.can_call("read_file", {"path": "/tmp/a.txt"})
        assert allowed1
        allowed2, msg2 = budget.can_call("read_file", {"path": "/tmp/a.txt"})
        assert not allowed2
        assert "same args" in msg2

    def test_different_args_allowed(self):
        """Same tool with different args should be allowed."""
        import cont
        budget = cont.DynamicToolBudget()
        allowed1, _ = budget.can_call("list_dir", {"path": "/tmp"})
        assert allowed1
        allowed2, _ = budget.can_call("list_dir", {"path": "/home"})
        assert allowed2

    def test_free_tools_quota(self):
        """Free tools are allowed up to their quota (recall: 3 free calls)."""
        import cont
        from core.tool_budget import FREE_TOOL_QUOTAS
        budget = cont.DynamicToolBudget()
        quota = FREE_TOOL_QUOTAS["recall"]
        for i in range(quota):
            allowed, _ = budget.can_call("recall", {"query": f"q{i}"})
            assert allowed

    def test_max_total_calls_enforced(self):
        """Should hard-stop after MAX_TOTAL_CALLS."""
        import cont
        budget = cont.DynamicToolBudget(budget_per_phase=100)
        budget.MAX_TOTAL_CALLS = 5
        for i in range(5):
            allowed, _ = budget.can_call("read_file", {"path": f"/file{i}"})
            assert allowed
        allowed, msg = budget.can_call("read_file", {"path": "/file99"})
        assert not allowed


class TestSurrogateClean:
    """Surrogate characters should be cleaned from all LLM paths."""

    def test_clean_surrogates_normal(self):
        """Normal text should pass through unchanged."""
        from core.utils import clean_surrogates
        assert clean_surrogates("hello world") == "hello world"
        assert clean_surrogates("Turkce karakter: ozetim") == "Turkce karakter: ozetim"

    def test_clean_surrogates_non_string(self):
        """Non-string input should return unchanged."""
        from core.utils import clean_surrogates
        assert clean_surrogates(42) == 42
        assert clean_surrogates(None) is None

    def test_clean_messages(self):
        """Message list cleaning should handle all string values."""
        from core.utils import _clean_messages
        msgs = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "world"},
        ]
        result = _clean_messages(msgs)
        assert len(result) == 2
        assert result[0]["content"] == "hello"


class TestPathNormalization:
    """WSL path normalization should handle all formats."""

    def test_windows_path_converted(self):
        """C:\\Users\\... should become /mnt/c/Users/..."""
        import cont
        result = cont.normalize_path("C:\\Users\\test\\file.txt")
        assert result == "/mnt/c/Users/test/file.txt"

    def test_tilde_expanded(self):
        """~ should expand to home directory."""
        import cont
        result = cont.normalize_path("~/projects")
        assert result.startswith("/home/") or result.startswith("/root/")

    def test_empty_returns_dot(self):
        """Empty path should return '.'."""
        import cont
        assert cont.normalize_path("") == "."

    def test_linux_path_unchanged(self):
        """Normal Linux paths should pass through."""
        import cont
        result = cont.normalize_path("/home/user/file.txt")
        assert result == "/home/user/file.txt"


class TestSystemExecutor:
    """Tests for core/system_executor.py — system fastpath."""

    def test_detect_intent_downloads(self):
        """'indirilenler' queries match list_downloads intent."""
        from core.system_executor import detect_intent
        intent = detect_intent("indirilenler klasöründeki son 10 dosyayı listele")
        assert intent is not None
        assert intent["name"] == "list_downloads"

    def test_detect_intent_no_match(self):
        """Unrelated queries return None."""
        from core.system_executor import detect_intent
        assert detect_intent("bu kodu refactor et") is None

    def test_detect_intent_git(self):
        """Git status queries match git_status intent."""
        from core.system_executor import detect_intent
        intent = detect_intent("git durumunu göster")
        assert intent is not None
        assert intent["name"] == "git_status"

    def test_detect_intent_desktop(self):
        """Desktop queries match list_desktop intent."""
        from core.system_executor import detect_intent
        intent = detect_intent("masaüstündeki dosyaları göster")
        assert intent is not None
        assert intent["name"] == "list_desktop"

    def test_detect_intent_where(self):
        """Location queries match where_am_i intent."""
        from core.system_executor import detect_intent
        intent = detect_intent("neredeyim")
        assert intent is not None
        assert intent["name"] == "where_am_i"

    def test_resolver_no_hardcode(self):
        """Resolver must not contain hardcoded usernames."""
        import inspect
        from core.system_executor import Resolver
        source = inspect.getsource(Resolver)
        assert "Sertan" not in source
        assert "sertan" not in source

    def test_extract_count(self):
        """_extract_count parses numbers from text."""
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        assert se._extract_count("son 10 dosya") == 10
        assert se._extract_count("son 5 dosya") == 5
        assert se._extract_count("dosyaları listele") == 10  # default

    def test_extract_count_clamp(self):
        """_extract_count clamps to max 50."""
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        assert se._extract_count("son 999 dosya") == 50

    # === FIX 2: Browser intent guards ===

    def test_browser_guard_url(self):
        """URLs should block all fastpath intents."""
        from core.system_executor import detect_intent
        assert detect_intent("https://example.com sayfasını aç") is None
        assert detect_intent("mevzuat.adalet.gov.tr sitesinde ara") is None

    def test_browser_guard_keywords(self):
        """Browser intent keywords should block fastpath."""
        from core.system_executor import detect_intent
        browser_queries = [
            "siteye git",
            "mevzuat sitesinden kanun indir",
            "bddk kanunu bul",
            "web sitesine git ve ara",
            "sayfaya git ve oku",
        ]
        for q in browser_queries:
            assert detect_intent(q) is None, f'"{q}" should NOT match fastpath'

    def test_browser_guard_preserves_valid(self):
        """Legitimate fastpath queries should still work."""
        from core.system_executor import detect_intent
        r = detect_intent("indirilen dosyaları göster")
        assert r is not None and r["name"] == "list_downloads"

        r = detect_intent("neredeyim")
        assert r is not None and r["name"] == "where_am_i"

    def test_stopword_git_not_broken(self):
        """Git VCS commands still work despite 'git' being a stopword."""
        from core.system_executor import detect_intent
        for q in ["git status", "git branch", "git commit", "git durumunu göster"]:
            r = detect_intent(q)
            assert r is not None and r["name"] == "git_status", f'"{q}" should match git_status'

    def test_stopword_only_input(self):
        """All-stopword inputs should return None."""
        from core.system_executor import detect_intent
        assert detect_intent("haydi yap") is None
        assert detect_intent("şimdi tekrar dene") is None
        assert detect_intent("tamam evet") is None


class TestTriage:
    """Triage command — failure pattern analysis."""

    def test_triage_returns_string(self):
        """run_triage() should return a string report."""
        from cont import run_triage
        report = run_triage(n=5)
        assert isinstance(report, str)
        assert "TRIAGE RAPORU" in report

    def test_triage_no_crash_empty(self):
        """run_triage() handles 0 logs gracefully."""
        from cont import run_triage
        # n=0 edge case
        report = run_triage(n=0)
        assert isinstance(report, str)

    def test_self_improve_apply_fix_is_noop(self):
        """_apply_fix must never call Claude Code — always returns False."""
        from core.self_improve import SelfImproveLoop
        loop = SelfImproveLoop(lambda: None, lambda: None, "/tmp")
        fix = {"prompt": "test prompt", "file": "test.py", "type": "test"}
        result = loop._apply_fix(fix)
        assert result is False


class TestRecipeEntityGuard:
    """Recipe matcher entity-consistency guard."""

    def test_extract_entities_acronyms(self):
        """Uppercase acronyms should be detected."""
        from core.recipes import _extract_entities
        e = _extract_entities("BDDK kanunu bul")
        assert "bddk" in e

    def test_extract_entities_known(self):
        """Known org names detected even in lowercase."""
        from core.recipes import _extract_entities
        e = _extract_entities("segem hakkında bilgi")
        assert "segem" in e

    def test_extract_entities_skip_stopwords(self):
        """Generic acronyms (JSON, URL, etc.) should be ignored."""
        from core.recipes import _extract_entities
        e = _extract_entities("JSON dosyası URL ile")
        assert "json" not in e
        assert "url" not in e

    def test_entity_conflict_detected(self):
        """User says BDDK, recipe says SEGEM → conflict."""
        from core.recipes import _entity_conflict
        assert _entity_conflict({"bddk"}, {"segem"}) is True

    def test_entity_no_conflict_overlap(self):
        """Same entity on both sides → no conflict."""
        from core.recipes import _entity_conflict
        assert _entity_conflict({"bddk"}, {"bddk", "mevzuat"}) is False

    def test_entity_no_conflict_empty(self):
        """Empty entity sets → no conflict."""
        from core.recipes import _entity_conflict
        assert _entity_conflict(set(), {"segem"}) is False
        assert _entity_conflict({"bddk"}, set()) is False
        assert _entity_conflict(set(), set()) is False

    def test_entity_conflict_blocks_match(self):
        """Recipe with wrong entity should not match."""
        import sqlite3, json
        from core.recipes import match_recipe

        # Create in-memory DB with a SEGEM recipe
        conn = sqlite3.connect(":memory:")
        conn.execute("""
            CREATE TABLE recipes (
                id TEXT PRIMARY KEY,
                pattern_keywords TEXT NOT NULL,
                threshold REAL DEFAULT 4.0,
                description TEXT,
                variables TEXT,
                steps TEXT NOT NULL,
                student_contract TEXT,
                estimated_tools INTEGER DEFAULT 3,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                last_success REAL,
                last_failure REAL,
                created_at REAL,
                source TEXT DEFAULT 'manual',
                status TEXT DEFAULT 'active',
                success_criteria TEXT
            )
        """)
        conn.execute("""
            INSERT INTO recipes (id, pattern_keywords, steps, description, status)
            VALUES (?, ?, ?, ?, 'active')
        """, (
            "mevzuat_arama_segem_v1",
            json.dumps({"mevzuat": 5, "kanun": 4, "ara": 3, "segem": 5}),
            json.dumps([{"action": "browser_agent",
                        "args": {"url": "https://mevzuat.adalet.gov.tr",
                                "goal": "SEGEM kanunu ara"}}]),
            "SEGEM ile ilgili mevzuat araması",
        ))
        conn.commit()

        # "bddk kanunu ara" should NOT match this SEGEM recipe
        result = match_recipe("bddk kanunu ara", conn=conn)
        assert result is None, f"Should not match SEGEM recipe for BDDK query, got: {result}"

    def test_entity_match_same_entity(self):
        """Recipe with matching entity should still work."""
        import sqlite3, json
        from core.recipes import match_recipe

        conn = sqlite3.connect(":memory:")
        conn.execute("""
            CREATE TABLE recipes (
                id TEXT PRIMARY KEY,
                pattern_keywords TEXT NOT NULL,
                threshold REAL DEFAULT 4.0,
                description TEXT,
                variables TEXT,
                steps TEXT NOT NULL,
                student_contract TEXT,
                estimated_tools INTEGER DEFAULT 3,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                last_success REAL,
                last_failure REAL,
                created_at REAL,
                source TEXT DEFAULT 'manual',
                status TEXT DEFAULT 'active',
                success_criteria TEXT
            )
        """)
        conn.execute("""
            INSERT INTO recipes (id, pattern_keywords, steps, description, status)
            VALUES (?, ?, ?, ?, 'active')
        """, (
            "mevzuat_arama_bddk_v1",
            json.dumps({"mevzuat": 5, "kanun": 4, "ara": 3, "bddk": 5}),
            json.dumps([{"action": "browser_agent",
                        "args": {"url": "https://mevzuat.adalet.gov.tr",
                                "goal": "BDDK kanunu ara"}}]),
            "BDDK ile ilgili mevzuat araması",
        ))
        conn.commit()

        # "bddk kanunu ara" SHOULD match this BDDK recipe
        result = match_recipe("bddk kanunu ara", conn=conn)
        assert result is not None, "Should match BDDK recipe for BDDK query"
        assert result["id"] == "mevzuat_arama_bddk_v1"


class TestDecomposerGate:
    """P0.5 FIX 1: _should_decompose() gate prevents unnecessary decomposition."""

    def test_short_input_skipped(self):
        """Short inputs (<12 words, no URL+multi-action) should skip decomposer."""
        from cont import _should_decompose
        assert _should_decompose("dosyayı oku") is False
        assert _should_decompose("list dir") is False
        assert _should_decompose("merhaba") is False
        assert _should_decompose("git status göster") is False

    def test_complex_input_passes(self):
        """Long multi-step inputs should pass through to decomposer."""
        from cont import _should_decompose
        long = "kosgeb sitesine git oradan destek programlarını bul sonra hepsini özetle ve kaydet"
        assert _should_decompose(long) is True

    def test_url_with_action(self):
        """URL + multi-action in short input should pass."""
        from cont import _should_decompose
        assert _should_decompose("https://example.com sayfasını ara ve özetle") is True

    def test_retry_skipped(self):
        """Retry flag should always skip decomposer."""
        from cont import _should_decompose
        assert _should_decompose("kosgeb destek programlarını ara ve listele", is_retry=True) is False

    def test_correction_skipped(self):
        """Correction phrases should skip decomposer."""
        from cont import _should_decompose
        assert _should_decompose("hayır değil onu demek istedim başka şey ara") is False

    def test_question_skipped(self):
        """Pure questions should skip decomposer."""
        from cont import _should_decompose
        assert _should_decompose("bu dosya nedir") is False
        assert _should_decompose("kosgeb nedir") is False
        assert _should_decompose("bu ne?") is False

    def test_short_url_without_multi_action_skipped(self):
        """URL alone without multi-action still skipped."""
        from cont import _should_decompose
        assert _should_decompose("https://example.com aç") is False

    def test_empty_input(self):
        """Empty input should not crash."""
        from cont import _should_decompose
        assert _should_decompose("") is False
        assert _should_decompose("   ") is False


class TestNormalizeToolCall:
    """P0.5 FIX 3: normalize_tool_call() name/arg normalization."""

    def test_name_alias(self):
        """Tool name aliases should resolve to canonical names."""
        from cont import normalize_tool_call
        name, args = normalize_tool_call("open_browser", {"url": "http://x.com"})
        assert name == "browser_open"

        name, _ = normalize_tool_call("bash", {"cmd": "ls"})
        assert name == "run_shell"

        name, _ = normalize_tool_call("search", {"query": "test"})
        assert name == "web_search"

        name, _ = normalize_tool_call("fetch", {"url": "http://x.com"})
        assert name == "web_fetch"

        name, _ = normalize_tool_call("navigate", {"url": "http://x.com"})
        assert name == "browser_open"

    def test_unknown_name_unchanged(self):
        """Unknown tool names should pass through unchanged."""
        from cont import normalize_tool_call
        name, _ = normalize_tool_call("read_file", {"path": "/tmp/a.txt"})
        assert name == "read_file"

    def test_arg_alias(self):
        """Argument aliases should normalize to canonical keys."""
        from cont import normalize_tool_call
        _, args = normalize_tool_call("run_shell", {"command": "ls -la"})
        assert "cmd" in args
        assert args["cmd"] == "ls -la"

        _, args = normalize_tool_call("browser_open", {"link": "http://x.com"})
        assert "url" in args
        assert args["url"] == "http://x.com"

        _, args = normalize_tool_call("read_file", {"filename": "/tmp/a.txt"})
        assert "path" in args

        _, args = normalize_tool_call("web_search", {"search_query": "test"})
        assert "query" in args

    def test_canonical_args_unchanged(self):
        """Already-canonical args should pass through."""
        from cont import normalize_tool_call
        _, args = normalize_tool_call("run_shell", {"cmd": "ls"})
        assert args == {"cmd": "ls"}

    def test_combined_name_and_arg(self):
        """Both name and arg should normalize together."""
        from cont import normalize_tool_call
        name, args = normalize_tool_call("bash", {"command": "git status"})
        assert name == "run_shell"
        assert args == {"cmd": "git status"}


class TestPathNormBudget:
    """Budget duplicate detection should normalize relative/absolute paths."""

    def test_relative_vs_absolute_same_key(self):
        """list_dir('logs/') and list_dir('/abs/path/logs') should produce same key."""
        import os
        from core.tool_budget import DynamicToolBudget
        cwd = os.getcwd()
        budget = DynamicToolBudget(cwd=cwd)
        key_rel = budget._make_key("list_dir", {"path": "logs/cont_runs/"})
        key_abs = budget._make_key("list_dir", {"path": os.path.join(cwd, "logs", "cont_runs")})
        assert key_rel == key_abs, f"Keys differ: {key_rel} vs {key_abs}"

    def test_different_paths_different_keys(self):
        """Different directories should produce different keys."""
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(cwd="/home/user/project")
        key_a = budget._make_key("read_file", {"path": "/tmp/a.txt"})
        key_b = budget._make_key("read_file", {"path": "/tmp/b.txt"})
        assert key_a != key_b

    def test_trailing_slash_normalized(self):
        """Trailing slashes should not affect key."""
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(cwd="/home/user")
        key_a = budget._make_key("list_dir", {"path": "/tmp/logs/"})
        key_b = budget._make_key("list_dir", {"path": "/tmp/logs"})
        assert key_a == key_b

    def test_non_path_args_unchanged(self):
        """Non-path arguments should not be normalized."""
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(cwd="/home/user")
        key = budget._make_key("web_search", {"query": "test query"})
        assert "test query" in key

    def test_duplicate_blocked_with_path_variants(self):
        """list_dir with different path format should be blocked as duplicate."""
        import os
        from core.tool_budget import DynamicToolBudget
        cwd = os.getcwd()
        budget = DynamicToolBudget(cwd=cwd)
        # First call is free (FIRST_CALL_FREE), burn it with a different path
        budget.can_call("list_dir", {"path": "/tmp/burn_free_quota"})
        # Now second call: relative path — uses budget, records key
        ok1, _ = budget.can_call("list_dir", {"path": "logs"})
        assert ok1
        # Third call: same dir as absolute path — should be blocked as duplicate
        ok2, msg2 = budget.can_call("list_dir", {"path": os.path.join(cwd, "logs")})
        assert not ok2, f"Should be blocked as duplicate, got: {msg2}"
        assert "same args" in msg2


class TestShellTimeout:
    """Adaptive shell timeout based on command type."""

    def test_find_root_short_timeout(self):
        """find / should get short timeout."""
        from cont import _shell_timeout
        assert _shell_timeout("find / -type d -name 'kito'") == 15
        assert _shell_timeout("find /usr -name '*.py'") == 15

    def test_default_timeout(self):
        """Normal commands should get default timeout."""
        from cont import _shell_timeout
        assert _shell_timeout("ls -la") == 30
        assert _shell_timeout("git status") == 30

    def test_network_timeout(self):
        """Network commands should get longer timeout."""
        from cont import _shell_timeout
        assert _shell_timeout("curl https://example.com") == 60
        assert _shell_timeout("wget https://example.com/file.tar.gz") == 60
        assert _shell_timeout("pip install requests") == 60

    def test_find_relative_normal_timeout(self):
        """find . (relative) should get default timeout, not 15s."""
        from cont import _shell_timeout
        assert _shell_timeout("find . -name '*.py'") == 30


class TestRecipeBrowserGate:
    """Recipe with browser steps should allow browser_agent fallback."""

    def test_recipe_needs_browser_true(self):
        """Recipe with browser_agent step should return True."""
        from core.recipes import recipe_needs_browser
        recipe = {
            "id": "test_v1",
            "steps": [
                {"action": "browser_agent", "args": {"url": "https://example.com", "goal": "search"}},
            ],
        }
        assert recipe_needs_browser(recipe) is True

    def test_recipe_needs_browser_false(self):
        """Recipe with only read_file steps should return False."""
        from core.recipes import recipe_needs_browser
        recipe = {
            "id": "test_v2",
            "steps": [
                {"action": "read_file", "args": {"path": "/tmp/a.txt"}},
                {"action": "recall", "args": {"query": "test"}},
            ],
        }
        assert recipe_needs_browser(recipe) is False

    def test_recipe_needs_browser_none(self):
        """None recipe should return False."""
        from core.recipes import recipe_needs_browser
        assert recipe_needs_browser(None) is False

    def test_recipe_needs_browser_json_steps(self):
        """Steps stored as JSON string should be parsed."""
        import json
        from core.recipes import recipe_needs_browser
        recipe = {
            "id": "test_v3",
            "steps": json.dumps([
                {"action": "web_search", "args": {"query": "test"}},
            ]),
        }
        assert recipe_needs_browser(recipe) is True

    def test_recipe_needs_browser_web_fetch(self):
        """web_fetch step should count as browser action."""
        from core.recipes import recipe_needs_browser
        recipe = {"id": "test_v4", "steps": [{"action": "web_fetch", "args": {"url": "x"}}]}
        assert recipe_needs_browser(recipe) is True


class TestRememberGuard:
    """remember() should reject facts with correction language."""

    def test_correction_rejected(self):
        """'X değil Y' content should be rejected when memory_type=fact."""
        import json
        from cont import remember
        result = json.loads(remember("Kito değil ITO demek", memory_type="fact"))
        assert result["status"] == "rejected"

    def test_yanlis_rejected(self):
        """'yanlış' content should be rejected."""
        import json
        from cont import remember
        result = json.loads(remember("Bu bilgi yanlış düzeltiyorum", memory_type="fact"))
        assert result["status"] == "rejected"

    def test_normal_fact_allowed(self):
        """Normal facts without correction language should pass."""
        import json
        from cont import remember
        result = json.loads(remember("ITO = İstanbul Ticaret Odası", memory_type="fact"))
        assert result["status"] in ("remembered", "error")  # error OK if no DB

    def test_non_fact_type_allowed(self):
        """Correction language in non-fact types should be allowed."""
        import json
        from cont import remember
        result = json.loads(remember("Bu değil şu olmalı", memory_type="reflection"))
        assert result["status"] != "rejected"

    def test_aslinda_rejected(self):
        """'aslında' correction should be rejected for facts."""
        import json
        from cont import remember
        result = json.loads(remember("Aslında doğrusu ITO", memory_type="fact"))
        assert result["status"] == "rejected"

    def test_hatali_rejected(self):
        """'hatalı' correction should be rejected for facts."""
        import json
        from cont import remember
        result = json.loads(remember("Önceki bilgi hatalı düzeltme", memory_type="fact"))
        assert result["status"] == "rejected"

    def test_degil_suffix_not_false_positive(self):
        """'değildir' (Turkish suffix) should NOT trigger guard — not a correction."""
        import json
        from cont import remember
        # 'değildir' has suffix 'dir' attached, so \bdeğil\b doesn't match.
        # "tamamlanmış değildir" = "is not completed" — legitimate statement.
        result = json.loads(remember("Bu proje tamamlanmış değildir", memory_type="fact"))
        assert result["status"] != "rejected"

    def test_standalone_degil_rejected(self):
        """Standalone 'değil' should trigger guard — this is a correction."""
        import json
        from cont import remember
        result = json.loads(remember("Ankara değil İstanbul", memory_type="fact"))
        assert result["status"] == "rejected"


class TestPerToolCaps:
    """P0.5 FIX 2: Per-tool hard caps prevent looping."""

    def test_caps_defined(self):
        """PER_TOOL_CAPS should be defined with expected tools."""
        from cont import PER_TOOL_CAPS
        assert PER_TOOL_CAPS["web_search"] == 2
        assert PER_TOOL_CAPS["browser_open"] == 2
        assert PER_TOOL_CAPS["run_shell"] == 3

    def test_tool_limits_uses_caps(self):
        """TOOL_LIMITS in task loop should reflect PER_TOOL_CAPS."""
        from cont import PER_TOOL_CAPS
        # PER_TOOL_CAPS is the source of truth
        assert "web_search" in PER_TOOL_CAPS
        assert "web_fetch" in PER_TOOL_CAPS
        assert "list_dir" in PER_TOOL_CAPS

    def test_alternatives_defined(self):
        """_TOOL_ALTERNATIVES should provide suggestions for blocked tools."""
        from cont import _TOOL_ALTERNATIVES
        assert "web_search" in _TOOL_ALTERNATIVES
        assert "browser_agent" in _TOOL_ALTERNATIVES["web_search"]
        assert "web_fetch" in _TOOL_ALTERNATIVES
        assert "run_shell" in _TOOL_ALTERNATIVES


# ======================================================================
# core/types.py — Shared Contracts
# ======================================================================

class TestSharedTypes:
    """core/types.py contract types are valid and usable."""

    def test_route_decision_values(self):
        """RouteDecision enum has all 4 lanes."""
        from core.types import RouteDecision
        assert RouteDecision.FASTPATH.value == "fastpath"
        assert RouteDecision.RECIPE.value == "recipe"
        assert RouteDecision.LLM.value == "llm"
        assert RouteDecision.BROWSER_AGENT.value == "browser_agent"

    def test_task_route_defaults(self):
        """TaskRoute has sensible defaults."""
        from core.types import TaskRoute, RouteDecision
        route = TaskRoute(decision=RouteDecision.LLM)
        assert route.recipe_id is None
        assert route.recipe is None
        assert route.intent is None
        assert route.url is None
        assert route.confidence == 0.0

    def test_task_route_with_recipe(self):
        """TaskRoute with recipe metadata."""
        from core.types import TaskRoute, RouteDecision
        route = TaskRoute(
            decision=RouteDecision.RECIPE,
            recipe_id="mevzuat_arama_v1",
            confidence=0.85,
        )
        assert route.decision == RouteDecision.RECIPE
        assert route.recipe_id == "mevzuat_arama_v1"
        assert route.confidence == 0.85

    def test_tool_result_fields(self):
        """ToolResult holds tool call data."""
        from core.types import ToolResult
        tr = ToolResult(tool_name="read_file", args={"path": "/tmp/a"}, result="ok", success=True)
        assert tr.tool_name == "read_file"
        assert tr.success is True
        assert tr.timestamp == 0.0

    def test_episode_record_defaults(self):
        """EpisodeRecord defaults match episodic.py expectations."""
        from core.types import EpisodeRecord
        ep = EpisodeRecord(task_input="dosyayı oku")
        assert ep.task_type == "llm"
        assert ep.tools_used == 0
        assert ep.tool_names == []
        assert ep.success == -1
        assert ep.recipe_id is None

    def test_auto_eval_result(self):
        """AutoEvalResult can represent uncertain evaluation."""
        from core.types import AutoEvalResult
        ae = AutoEvalResult(success=None, confidence=0.3, score=45)
        assert ae.success is None
        assert ae.confidence == 0.3
        assert ae.reasons == []
        assert ae.score == 45

    def test_no_core_imports_in_types(self):
        """core/types.py must not import from other core modules."""
        import inspect
        import core.types
        source = inspect.getsource(core.types)
        core_imports = re.findall(r'^(?:from|import)\s+core\.', source, re.MULTILINE)
        assert core_imports == [], f"core/types.py imports core modules: {core_imports}"


# ======================================================================
# Teacher Context Enhancement
# ======================================================================

class TestTeacherContext:
    """Teacher prompts include recipe_id and run_id when available."""

    def test_context_includes_recipe_id(self):
        """_build_context_prompt includes matched_recipe_id."""
        from core.teacher import _build_context_prompt
        ctx = {"cwd": "/tmp", "matched_recipe_id": "mevzuat_v1"}
        prompt = _build_context_prompt("kanun bul", context=ctx)
        assert "mevzuat_v1" in prompt

    def test_context_includes_run_id(self):
        """_build_context_prompt includes run_id."""
        from core.teacher import _build_context_prompt
        ctx = {"cwd": "/tmp", "run_id": "20260217_231834"}
        prompt = _build_context_prompt("dosya ara", context=ctx)
        assert "20260217_231834" in prompt

    def test_context_includes_keywords(self):
        """_build_context_prompt includes recipe keywords."""
        from core.teacher import _build_context_prompt
        ctx = {
            "cwd": "/tmp",
            "matched_recipe_id": "web_v1",
            "matched_recipe_keywords": "ara, web, search",
        }
        prompt = _build_context_prompt("web ara", context=ctx)
        assert "ara, web, search" in prompt

    def test_context_without_extras(self):
        """Prompt works fine without recipe/run context."""
        from core.teacher import _build_context_prompt
        ctx = {"cwd": "/tmp"}
        prompt = _build_context_prompt("basit görev", context=ctx)
        assert "GÖREV: basit görev" in prompt
        assert "recipe" not in prompt.lower() or "recipe üret" in prompt.lower()


# ======================================================================
# core/episodic.py — Triage Extraction
# ======================================================================

class TestTriageExtraction:
    """run_triage() lives in core/episodic.py and works standalone."""

    def test_import_run_triage(self):
        """run_triage is importable from core.episodic."""
        from core.episodic import run_triage
        assert callable(run_triage)

    def test_root_causes_complete(self):
        """_ROOT_CAUSES has all 6 issue categories."""
        from core.episodic import _ROOT_CAUSES
        expected = {"wasteful_tools", "blocked_calls", "tool_loop",
                    "incomplete", "task_failed", "tool_error"}
        assert set(_ROOT_CAUSES.keys()) == expected

    def test_root_causes_have_fields(self):
        """Each root cause has cause, fix, file."""
        from core.episodic import _ROOT_CAUSES
        for cat, info in _ROOT_CAUSES.items():
            assert "cause" in info, f"{cat} missing 'cause'"
            assert "fix" in info, f"{cat} missing 'fix'"
            assert "file" in info, f"{cat} missing 'file'"

    def test_triage_skip_errors(self):
        """_TRIAGE_SKIP_ERRORS contains expected non-error codes."""
        from core.episodic import _TRIAGE_SKIP_ERRORS
        assert "prefetch_cache_hit" in _TRIAGE_SKIP_ERRORS
        assert "repetition_blocked" in _TRIAGE_SKIP_ERRORS
        assert "cache_hit" in _TRIAGE_SKIP_ERRORS

    def test_triage_missing_dir(self):
        """run_triage returns error message for missing log dir."""
        from core.episodic import run_triage
        result = run_triage(log_dir="/nonexistent/path/logs")
        assert "bulunamadı" in result

    def test_triage_empty_dir(self, tmp_path):
        """run_triage returns 'no logs' for empty directory."""
        from core.episodic import run_triage
        result = run_triage(log_dir=str(tmp_path))
        assert "Henüz run logu yok" in result

    def test_triage_parses_log(self, tmp_path):
        """run_triage parses a JSONL log and produces a report."""
        import json
        log_file = tmp_path / "20260218_120000_test_task.jsonl"
        entries = [
            {"type": "tool_call", "data": {"name": "web_search"}},
            {"type": "tool_call", "data": {"name": "web_search"}},
            {"type": "tool_call", "data": {"name": "web_search"}},
            {"type": "tool_call", "data": {"name": "web_search"}},
            {"type": "final", "data": {"success": False}},
        ]
        log_file.write_text("\n".join(json.dumps(e) for e in entries))
        from core.episodic import run_triage
        result = run_triage(n=5, log_dir=str(tmp_path))
        assert "TRIAGE RAPORU" in result
        assert "tool_loop" in result  # web_search x4

    def test_triage_success_run(self, tmp_path):
        """Successful run with few tools does not trigger issues."""
        import json
        log_file = tmp_path / "20260218_130000_good_task.jsonl"
        entries = [
            {"type": "tool_call", "data": {"name": "read_file"}},
            {"type": "final", "data": {"success": True}},
        ]
        log_file.write_text("\n".join(json.dumps(e) for e in entries))
        from core.episodic import run_triage
        result = run_triage(n=5, log_dir=str(tmp_path))
        assert "Başarılı: 1/1" in result
        assert "Sorun tespit edilmedi" in result

    def test_no_run_triage_in_cont(self):
        """run_triage is NOT defined in cont.py anymore."""
        import inspect
        import cont
        source = inspect.getsource(cont)
        # Should NOT have "def run_triage" (it's imported, not defined)
        assert "def run_triage(" not in source

    def test_cont_imports_run_triage(self):
        """cont.py imports run_triage from core.episodic."""
        with open("cont.py", "r") as f:
            source = f.read()
        assert "run_triage" in source
        assert "from core.episodic import" in source


# ======================================================================
# core/tools.py — Tool Implementation Extraction
# ======================================================================

class TestToolsExtraction:
    """Tool functions live in core/tools.py and work correctly."""

    def test_import_tool_functions(self):
        """All 9 tool functions + normalize_tool_call are importable."""
        from core.tools import (
            open_file, list_dir, read_file, write_file, apply_patch,
            run_shell, search_files, find_path, navigate, system_search,
            normalize_tool_call,
        )
        assert callable(list_dir)
        assert callable(normalize_tool_call)

    def test_per_tool_caps(self):
        """PER_TOOL_CAPS has expected tools."""
        from core.tools import PER_TOOL_CAPS
        assert "web_search" in PER_TOOL_CAPS
        assert "run_shell" in PER_TOOL_CAPS
        assert PER_TOOL_CAPS["web_search"] == 2

    def test_tool_alternatives(self):
        """_TOOL_ALTERNATIVES has suggestions for each capped tool."""
        from core.tools import _TOOL_ALTERNATIVES
        assert "web_search" in _TOOL_ALTERNATIVES
        assert "list_dir" in _TOOL_ALTERNATIVES
        assert "run_shell" in _TOOL_ALTERNATIVES

    def test_normalize_tool_call_name(self):
        """Tool name aliases resolve correctly."""
        from core.tools import normalize_tool_call
        name, args = normalize_tool_call("shell", {"command": "ls"})
        assert name == "run_shell"
        assert args["cmd"] == "ls"  # 'command' → 'cmd' alias

    def test_normalize_tool_call_passthrough(self):
        """Unknown tool names pass through unchanged."""
        from core.tools import normalize_tool_call
        name, args = normalize_tool_call("list_dir", {"path": "."})
        assert name == "list_dir"
        assert args["path"] == "."

    def test_safe_path_relative(self, tmp_path):
        """safe_path resolves relative paths via get_cwd."""
        from core.tools import safe_path, init_tools
        import core.tools as tools_mod
        old_get = tools_mod._get_cwd
        tools_mod._get_cwd = lambda: tmp_path
        try:
            result = safe_path("subdir")
            assert str(result) == str((tmp_path / "subdir").resolve())
        finally:
            tools_mod._get_cwd = old_get

    def test_safe_path_forbidden(self):
        """safe_path blocks system directories."""
        from core.tools import safe_path
        import pytest
        with pytest.raises(ValueError, match="Access denied"):
            safe_path("/etc/passwd")

    def test_block_dangerous(self):
        """block_dangerous catches rm -rf /."""
        from core.tools import block_dangerous
        import pytest
        with pytest.raises(ValueError, match="Dangerous"):
            block_dangerous("rm -rf /")

    def test_shell_timeout_find(self):
        """_shell_timeout returns 15s for find /."""
        from core.tools import _shell_timeout
        assert _shell_timeout("find / -name foo") == 15

    def test_shell_timeout_default(self):
        """_shell_timeout returns 30s for normal commands."""
        from core.tools import _shell_timeout
        assert _shell_timeout("ls -la") == 30

    def test_shell_timeout_network(self):
        """_shell_timeout returns 60s for curl."""
        from core.tools import _shell_timeout
        assert _shell_timeout("curl https://example.com") == 60

    def test_is_step_safe_ok(self):
        """Safe commands pass is_step_safe."""
        from core.tools import is_step_safe
        safe, reason = is_step_safe("ls -la")
        assert safe is True
        assert reason is None

    def test_is_step_safe_blocked(self):
        """Dangerous commands fail is_step_safe."""
        from core.tools import is_step_safe
        safe, reason = is_step_safe("rm -rf /")
        assert safe is False
        assert "rm -rf" in reason

    def test_no_tool_defs_in_cont(self):
        """Tool functions are NOT defined in cont.py anymore."""
        import inspect
        import cont
        source = inspect.getsource(cont)
        for fn in ("def list_dir(", "def read_file(", "def run_shell(",
                    "def apply_patch(", "def search_files(", "def find_path(",
                    "def navigate(", "def system_search(", "def safe_path(",
                    "def normalize_tool_call("):
            assert fn not in source, f"{fn} still in cont.py"

    def test_cont_imports_tools(self):
        """cont.py imports from core.tools."""
        with open("cont.py", "r") as f:
            source = f.read()
        assert "from core.tools import" in source
        assert "init_tools" in source


# ======================================================================
# core/cli.py — CLI Parser Extraction
# ======================================================================

class TestCLIExtraction:
    """CLI parser lives in core/cli.py and works correctly."""

    def test_import_build_parser(self):
        """build_parser is importable from core.cli."""
        from core.cli import build_parser
        assert callable(build_parser)

    def test_parser_has_task(self):
        """Parser has positional 'task' argument."""
        from core.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["hello", "world"])
        assert args.task == ["hello", "world"]

    def test_parser_has_model(self):
        """Parser has --model flag."""
        from core.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--model", "test-model", "task"])
        assert args.model == "test-model"

    def test_parser_has_debug(self):
        """Parser has --debug flag."""
        from core.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--debug"])
        assert args.debug is True

    def test_parser_has_triage(self):
        """Parser has --triage flag with optional N."""
        from core.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--triage"])
        assert args.triage == 50  # default const
        args2 = parser.parse_args(["--triage", "20"])
        assert args2.triage == 20

    def test_parser_has_memory_flags(self):
        """Parser has memory-related flags."""
        from core.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--memory-stats"])
        assert args.memory_stats is True

    def test_no_parser_in_cont_main(self):
        """cont.py main() uses build_parser(), not inline parser."""
        with open("cont.py", "r") as f:
            source = f.read()
        assert "build_parser()" in source
        # Should NOT have the inline epilog string
        assert "CONT_TOOL_BUDGET=8 cont" not in source

    def test_cont_imports_build_parser(self):
        """cont.py imports build_parser from core.cli."""
        with open("cont.py", "r") as f:
            source = f.read()
        assert "from core.cli import build_parser" in source


# ============================================
# Tool Discipline / Backpressure Tests
# ============================================

class TestPerToolCapsStrict:
    """PER_TOOL_CAPS must include all high-frequency tools."""

    def test_caps_include_required_tools(self):
        from core.tools import PER_TOOL_CAPS
        required = ['web_search', 'web_fetch', 'browser_open', 'run_shell',
                     'list_dir', 'system_search', 'read_file', 'find_path']
        for tool in required:
            assert tool in PER_TOOL_CAPS, f"{tool} missing from PER_TOOL_CAPS"

    def test_caps_are_low(self):
        """No tool should have cap > 3."""
        from core.tools import PER_TOOL_CAPS
        for tool, cap in PER_TOOL_CAPS.items():
            assert cap <= 3, f"{tool} cap={cap} too high (max 3)"

    def test_alternatives_exist_for_capped_tools(self):
        """Every capped tool should have an alternative suggestion."""
        from core.tools import PER_TOOL_CAPS, _TOOL_ALTERNATIVES
        for tool in PER_TOOL_CAPS:
            if tool not in ('remember', 'recall'):
                assert tool in _TOOL_ALTERNATIVES, f"{tool} has cap but no alternative"


class TestToolBlockedMsgAlternatives:
    """tool_blocked_msg must include alternatives when provided."""

    def test_with_alternatives(self):
        from core.formatters import tool_blocked_msg
        msg = tool_blocked_msg("web_search", "web_fetch, browser_agent")
        assert "web_fetch, browser_agent" in msg
        assert "Alternatifler" in msg

    def test_without_alternatives(self):
        from core.formatters import tool_blocked_msg
        msg = tool_blocked_msg("web_search", "")
        assert "Alternatifler" not in msg

    def test_empty_string_alternatives(self):
        from core.formatters import tool_blocked_msg
        msg = tool_blocked_msg("recall")
        assert "Alternatifler" not in msg


class TestConsecutiveToolBrake:
    """Consecutive tool brake must exist in runtime.py source."""

    def test_brake_message_exists_in_source(self):
        with open("core/runtime.py", "r") as f:
            source = f.read()
        assert "consecutive_tools += 1" in source
        assert "consecutive_tools >= 3" in source
        assert "ardışık tool çağrısı" in source

    def test_consecutive_tools_reset_on_text(self):
        with open("core/runtime.py", "r") as f:
            source = f.read()
        # After "if content and content.strip():" there should be consecutive_tools = 0
        idx_content = source.index("if content and content.strip():")
        next_100 = source[idx_content:idx_content + 200]
        assert "consecutive_tools = 0" in next_100

    def test_total_blocked_threshold_is_2(self):
        with open("core/runtime.py", "r") as f:
            source = f.read()
        assert "total_blocked >= 2" in source
        # Old threshold should NOT exist
        assert "total_blocked >= 4" not in source

    def test_brake_uses_deferred_flag(self):
        """Brake must set _force_llm_turn_msg flag, not append directly."""
        with open("core/runtime.py", "r") as f:
            source = f.read()
        # Brake sets the flag instead of appending
        idx = source.index("ardışık tool çağrısı")
        region = source[idx:idx + 400]
        assert "_force_llm_turn_msg = _brake_msg" in region, \
            "Brake must set _force_llm_turn_msg flag"
        # Old direct append should not exist
        assert '"role": "user", "content": _brake_msg' not in source
        assert '"role": "system", "content": _brake_msg' not in source

    def test_deferred_injection_at_loop_top(self):
        """_force_llm_turn_msg must be injected as system at top of iteration."""
        with open("core/runtime.py", "r") as f:
            source = f.read()
        # Must have the deferred injection block
        assert 'if _force_llm_turn_msg:' in source
        idx = source.index('if _force_llm_turn_msg:')
        region = source[idx:idx + 200]
        assert '"role": "system", "content": _force_llm_turn_msg' in region, \
            "Deferred brake must inject as system role"
        assert '_force_llm_turn_msg = ""' in region, \
            "Flag must be cleared after injection"

    def test_no_user_injections_in_tool_loop(self):
        """System injections between tool results must use system role."""
        with open("core/runtime.py", "r") as f:
            source = f.read()
        # These specific messages should NOT be user role (they sit between tool results)
        forbidden = [
            '"role": "user", "content": security_blocked_msg',
            '"role": "user", "content": budget_msg',
            '"role": "user", "content": _reminder',
            '"role": "user", "content": read_blocked_msg',
            '"role": "user", "content": tool_blocked_msg',
            '"role": "user", "content": tool_limit_system_inject_msg',
            '"role": "user", "content": checkpoint_msg',
            '"role": "user", "content": stop_msg',
        ]
        for pattern in forbidden:
            assert pattern not in source, \
                f"Found forbidden user-role injection: {pattern}"

    def test_brake_triggers_second_llm_request(self):
        """After 3 consecutive tool-only turns, brake fires and LLM is called again.

        Uses a fake LLM that returns tool_calls for 3 consecutive iterations,
        then text content on the 4th call. Verifies:
        - At least 4 llm_complete_fn calls (3 tool + 1 final after brake)
        - Brake message injected as system role before the 4th call
        - No role alternation violations in the message list
        """
        from types import SimpleNamespace
        from unittest.mock import MagicMock, patch
        from pathlib import Path
        import core.runtime as rt

        # --- Fake LLM ---
        llm_call_count = 0
        captured_messages = []

        def fake_llm(model, messages, tools=None, tool_choice=None):
            nonlocal llm_call_count
            llm_call_count += 1
            captured_messages.append(list(messages))  # snapshot

            if llm_call_count <= 3:
                tc = SimpleNamespace(
                    id=f"call_{llm_call_count}",
                    function=SimpleNamespace(
                        name="system_search",
                        arguments='{"query": "test"}'
                    )
                )
                return {"content": None, "tool_calls": [tc]}
            else:
                return {"content": "Özet: 3 arama yaptım, sonuç bulunamadı.", "tool_calls": None}

        # --- Fake tool ---
        def fake_system_search(**kwargs):
            return '{"status": "not_found", "query": "test"}'

        # --- Fake write protection ---
        fake_wp = MagicMock()
        fake_wp.set_task = MagicMock()
        fake_wp.check = MagicMock(return_value=(True, None))

        # --- Fake logger ---
        log_events = []
        fake_logger = MagicMock()
        fake_logger.events = log_events
        fake_logger.log = lambda etype, data: log_events.append({"type": etype, "data": data})
        fake_logger.log_llm_request = lambda msgs: log_events.append({"type": "llm_request"})
        fake_logger.log_llm_response = lambda c, tc: log_events.append({"type": "llm_response"})
        fake_logger.log_tool_call = lambda n, a: log_events.append({"type": "tool_call", "name": n})
        fake_logger.log_tool_result = lambda n, r, e=None: log_events.append({"type": "tool_result", "name": n})
        fake_logger.log_final = lambda c, success=True, **kw: log_events.append({"type": "final"})
        fake_logger.log_warning = lambda msg, data=None: log_events.append({"type": "warning", "msg": msg})

        # --- Build minimal _ctx ---
        ctx = rt.ensure_runtime_ctx(
            console=MagicMock(),
            debug_fn=lambda msg: None,
            model="test-model",
            llm_complete_fn=fake_llm,
            endpoint_mode="chat",
            tool_schemas=[{"type": "function", "function": {"name": "system_search", "parameters": {}}}],
            tools={"system_search": fake_system_search},
            tool_budget=12,
            max_iterations=10,
            repo_root=Path("/tmp"),
            # Disable all optional features
            learning_enabled=False,
            fastpath_enabled=False,
            escalation_enabled=False,
            verification_enabled=False,
            self_improve_enabled=False,
            phase0_enabled=False,
            automation_enabled=False,
            safety_enabled=False,
            teacher_enabled=False,
            episodic_enabled=False,
            browser_available=False,
            # Required callbacks (stubs)
            check_input_safety_fn=lambda task: (True, None),
            get_write_protection_fn=lambda: fake_wp,
            memory_get_context_fn=None,
            memory_hybrid_search_fn=None,
            memory_remember_fn=None,
            memory_update_daily_summary_fn=None,
            memory_init_db_fn=None,
            db_connect_fn=None,
            build_system_prompt_fn=None,
            truncate_for_context_fn=lambda msgs, max_chars=20000: msgs,
            load_openai_cloud_key_fn=None,
            context_limit=8192,
            max_tokens=2048,
            # Recipe/decomposer stubs
            match_recipe_fn=lambda task, **kw: None,
            match_patches_fn=lambda task: [],
            init_recipe_db_fn=None,
            seed_recipes_fn=None,
            cleanup_junk_recipes_fn=None,
            recipe_to_prompt_fn=None,
            recipe_record_success_fn=None,
            record_recipe_outcome_fn=None,
            record_patch_outcome_fn=None,
            decompose_fn=lambda t: [t],
            decompose_compound_fn=lambda t: [],
            format_decomposed_fn=lambda t: t[0] if t else "",
            # Other
            event_bus=None,
            get_escalation_fn=None,
            run_phase0_fn=None,
            system_executor_cls=None,
            evaluate_task_fn=None,
            should_learn_fn=None,
            learn_and_save_fn=None,
            self_improver_cls=None,
            classify_task_fn=None,
            build_adaptive_prompt_fn=None,
            estimate_tokens_fn=None,
            browser_agent_cls=None,
            get_teacher_api_key_fn=None,
            get_security_manager_fn=lambda: None,
            request_tier2_approval_fn=lambda **kw: False,
            save_batch_state_fn=None,
            clear_batch_state_fn=None,
            remember_tool_fn=lambda content, **kw: None,
            run_shell_fn=None,
            resolver_repo_root_fn=lambda: "/tmp",
            response_verifier_cls=None,
            user_input=None,
            in_decomposed=False,
            skip_escalation=False,
            dry_run=False,
            clean_messages_fn=lambda msgs: msgs,
            llm_complete_openai_fn=None,
            determine_endpoint_mode_fn=None,
        )

        # --- Run ---
        answer, success = rt.run_task("test search", logger=fake_logger)

        # --- Assert ---
        # At least 4 LLM calls: 3 tool turns + 1 after brake
        assert llm_call_count >= 4, \
            f"Expected >=4 LLM calls, got {llm_call_count}"

        # Brake message must appear in messages sent to 4th LLM call
        # (v6_doit: mid-conversation system messages are converted to user role
        # by _sanitize_role_alternation, so check both system and user roles)
        fourth_call_msgs = captured_messages[3]
        all_msgs = [m for m in fourth_call_msgs if m["role"] in ("system", "user")]
        brake_found = any("ardışık tool çağrısı" in m.get("content", "") for m in all_msgs)
        assert brake_found, \
            "Brake message not found in 4th LLM call messages"

        # Logger must have llm_request events
        llm_request_events = [e for e in log_events if e["type"] == "llm_request"]
        assert len(llm_request_events) >= 2, \
            f"Expected >=2 llm_request events, got {len(llm_request_events)}"

        # No consecutive same-role violations (except system which is allowed anywhere)
        for call_msgs in captured_messages:
            prev_role = None
            for msg in call_msgs:
                role = msg["role"]
                if role == "system":
                    continue  # system allowed anywhere
                if role == prev_role and role == "user":
                    # Check this isn't a false positive from budget/finalize msgs
                    assert False, \
                        f"Consecutive user messages found in LLM call"
                if role != "tool":
                    prev_role = role


class TestNotCommandPrefix:
    """Bug: 'çok /not "mesaj"' was not recognized as feedback command.
    The /not was only detected at start of input (startswith), but users
    often prefix with words like 'çok', 'kötü', etc.
    Fixed: detect /not anywhere in input, use prefix for rating.
    """

    def test_embedded_not_detected(self):
        """'çok /not "mesaj"' should be consumed as feedback."""
        import cont
        result = cont._handle_feedback_command('çok /not "mesaj"', last_task_id=1)
        assert result is True

    def test_negative_prefix_rating(self):
        """'kötü /not "berbat"' should get rating=1 (negative prefix + note)."""
        from core.runtime import handle_feedback_command
        from unittest.mock import patch
        with patch('core.runtime.save_feedback') as mock_save:
            with patch('core.runtime.learn_from_chain'):
                handle_feedback_command('kötü /not "berbat"', last_task_id=1)
                mock_save.assert_called_once()
                # rating arg (index 2) should be 1 (negative)
                assert mock_save.call_args[0][2] == 1

    def test_plain_not_still_works(self):
        """'/not "iyi"' (original format) should still work."""
        import cont
        result = cont._handle_feedback_command('/not "iyi"', last_task_id=1)
        assert result is True

    def test_non_feedback_not_consumed(self):
        """'hello world' should NOT be consumed."""
        import cont
        result = cont._handle_feedback_command('hello world', last_task_id=None)
        assert result is False

    def test_embedded_iyi_detected(self):
        """'harika /iyi' should be consumed as feedback."""
        import cont
        result = cont._handle_feedback_command('harika /iyi', last_task_id=1)
        assert result is True

    def test_embedded_kotu_detected(self):
        """'berbat /kötü' should be consumed as feedback."""
        import cont
        result = cont._handle_feedback_command('berbat /kötü', last_task_id=1)
        assert result is True


class TestWebSearchTurkish:
    """web_search: Turkish auto-detect + browser User-Agent."""

    def test_user_agent_is_browser(self):
        """WEB_USER_AGENT must look like a real browser, not a bot."""
        from core.web import WEB_USER_AGENT
        assert "Mozilla" in WEB_USER_AGENT
        assert "cont-web-fetch" not in WEB_USER_AGENT

    def test_turkish_autodetect_triggered(self):
        """Query with Turkish chars should auto-set language to tr-TR."""
        from unittest.mock import patch, MagicMock
        import core.web

        # Patch requests.post to capture the params sent
        mock_response = MagicMock()
        mock_response.text = "<html></html>"
        mock_response.raise_for_status = MagicMock()

        with patch.object(core.web.requests, 'post', return_value=mock_response) as mock_post:
            core.web.web_search("İstanbul Ticaret Odası")
            call_kwargs = mock_post.call_args
            params = call_kwargs[1].get('data') or call_kwargs[0][1] if len(call_kwargs[0]) > 1 else call_kwargs[1]['data']
            assert params.get("kl") == "tr-TR", f"Expected kl=tr-TR, got {params}"

    def test_english_query_no_autodetect(self):
        """Query without Turkish chars should stay language=en."""
        from unittest.mock import patch, MagicMock
        import core.web

        mock_response = MagicMock()
        mock_response.text = "<html></html>"
        mock_response.raise_for_status = MagicMock()

        with patch.object(core.web.requests, 'post', return_value=mock_response) as mock_post:
            core.web.web_search("Istanbul Trade Chamber")
            call_kwargs = mock_post.call_args
            params = call_kwargs[1].get('data') or call_kwargs[0][1] if len(call_kwargs[0]) > 1 else call_kwargs[1]['data']
            assert "kl" not in params, f"kl should not be set for English query, got {params}"

    def test_explicit_language_not_overridden(self):
        """Explicit language='de' should not be overridden by autodetect."""
        from unittest.mock import patch, MagicMock
        import core.web

        mock_response = MagicMock()
        mock_response.text = "<html></html>"
        mock_response.raise_for_status = MagicMock()

        with patch.object(core.web.requests, 'post', return_value=mock_response) as mock_post:
            core.web.web_search("İstanbul Handel", language="de")
            call_kwargs = mock_post.call_args
            params = call_kwargs[1].get('data') or call_kwargs[0][1] if len(call_kwargs[0]) > 1 else call_kwargs[1]['data']
            assert params.get("kl") == "de", f"Expected kl=de, got {params}"

    def test_zero_results_suggestion_no_hallucinate(self):
        """0-result response should warn against URL hallucination."""
        from unittest.mock import patch, MagicMock
        import core.web

        mock_response = MagicMock()
        mock_response.text = "<html><body>No results</body></html>"
        mock_response.raise_for_status = MagicMock()

        with patch.object(core.web.requests, 'post', return_value=mock_response):
            result = core.web.web_search("nonexistent query xyz")
            assert result["no_results"] is True
            assert "Do NOT invent" in result["suggestion"]


class TestEncodingRecovery:
    """handle_feedback_command: Turkish encoding corruption recovery."""

    def test_kotu_with_replacement_char(self):
        """'/k\\ufffdtü' (corrupted /kötü) should be recognized as feedback."""
        from core.runtime import handle_feedback_command
        from unittest.mock import patch
        with patch('core.runtime.save_feedback'):
            with patch('core.runtime.learn_from_chain'):
                result = handle_feedback_command('/k\ufffdtü', last_task_id=1)
                assert result is True

    def test_iyi_with_replacement_char(self):
        """'/i\\ufffdyi' (corrupted /iyi) should be recognized as feedback."""
        from core.runtime import handle_feedback_command
        from unittest.mock import patch
        with patch('core.runtime.save_feedback'):
            with patch('core.runtime.learn_from_chain'):
                result = handle_feedback_command('/i\ufffdyi', last_task_id=1)
                assert result is True

    def test_clean_input_unchanged(self):
        """Clean input without U+FFFD should work as before."""
        from core.runtime import handle_feedback_command
        from unittest.mock import patch
        with patch('core.runtime.save_feedback'):
            with patch('core.runtime.learn_from_chain'):
                result = handle_feedback_command('/kötü', last_task_id=1)
                assert result is True

    def test_non_feedback_with_replacement_char(self):
        """Non-feedback input with U+FFFD should not be consumed."""
        from core.runtime import handle_feedback_command
        result = handle_feedback_command('hello \ufffd world', last_task_id=1)
        assert result is False


# === Connection / Reliability sweep ===

class TestCanonicalFixupJson:
    """core.utils.fixup_json — single source of truth for JSON repair."""

    def test_valid_json_no_fixup(self):
        from core.utils import fixup_json
        raw = '{"path": "/tmp"}'
        fixed, method = fixup_json(raw)
        assert fixed == raw
        assert method is None

    def test_trailing_comma(self):
        from core.utils import fixup_json
        fixed, method = fixup_json('{"path": "/tmp",}')
        assert json.loads(fixed) == {"path": "/tmp"}
        assert method == "trailing_comma"

    def test_single_quotes(self):
        from core.utils import fixup_json
        fixed, method = fixup_json("{'query': 'hello'}")
        assert json.loads(fixed) == {"query": "hello"}
        assert method == "single_quotes"

    def test_control_chars(self):
        from core.utils import fixup_json
        fixed, method = fixup_json('{"cmd": "echo\nhello"}')
        assert method == "control_chars"
        assert json.loads(fixed) == {"cmd": "echo\nhello"}

    def test_python_literals(self):
        from core.utils import fixup_json
        fixed, method = fixup_json('{"flag": True, "val": None}')
        assert json.loads(fixed) == {"flag": True, "val": None}
        assert method == "python_literals"

    def test_nested_trailing_commas(self):
        from core.utils import fixup_json
        fixed, method = fixup_json('{"a": [1, 2,], "b": "x",}')
        assert json.loads(fixed) == {"a": [1, 2], "b": "x"}
        assert method == "trailing_comma"

    def test_garbage_returns_raw(self):
        from core.utils import fixup_json
        fixed, method = fixup_json("not json at all")
        assert fixed == "not json at all"
        assert method is None

    def test_idempotent(self):
        """Applying fixup twice should give the same result."""
        from core.utils import fixup_json
        raw = '{"a": 1,}'
        fixed1, _ = fixup_json(raw)
        fixed2, method2 = fixup_json(fixed1)
        assert fixed1 == fixed2
        assert method2 is None  # second pass: already valid


class TestToolJsonRecovery:
    """Layer 2: _recover_tool_json returns (dict, method) or (None, None)."""

    def test_recoverable_returns_dict_and_method(self):
        from core.runtime import _recover_tool_json
        result, method = _recover_tool_json('{"path": "/tmp",}', "list_dir")
        assert result == {"path": "/tmp"}
        assert method == "trailing_comma"

    def test_total_garbage_returns_none_none(self):
        from core.runtime import _recover_tool_json
        result, method = _recover_tool_json("not json at all", "test")
        assert result is None
        assert method is None

    def test_valid_json_returns_none_none(self):
        """Valid JSON shouldn't reach Layer 2, but if it does: no recovery needed."""
        from core.runtime import _recover_tool_json
        # fixup_json returns (raw, None) for valid JSON — method is None
        # so _recover_tool_json returns (None, None) — no recovery branch
        result, method = _recover_tool_json('{"path": "."}', "list_dir")
        assert result is None
        assert method is None


class TestAdapterSanitize:
    """_sanitize_tool_arguments in cont.py — adapter-level JSON fixup."""

    def test_valid_json_passthrough(self):
        from cont import _sanitize_tool_arguments
        raw = '{"path": "/tmp"}'
        assert _sanitize_tool_arguments(raw) == raw  # untouched

    def test_trailing_comma_fixed(self):
        from cont import _sanitize_tool_arguments
        import json
        raw = '{"path": "/tmp",}'
        result = _sanitize_tool_arguments(raw)
        assert json.loads(result) == {"path": "/tmp"}

    def test_single_quotes_fixed(self):
        from cont import _sanitize_tool_arguments
        import json
        raw = "{'query': 'test'}"
        result = _sanitize_tool_arguments(raw)
        assert json.loads(result) == {"query": "test"}

    def test_garbage_returns_raw(self):
        from cont import _sanitize_tool_arguments
        raw = "not json"
        assert _sanitize_tool_arguments(raw) == raw  # unchanged


class TestActionableLlmError:
    """_actionable_llm_error should return user-friendly messages."""

    def test_connection_refused(self):
        from core.runtime import _actionable_llm_error
        msg = _actionable_llm_error("Connection refused to localhost:1234")
        assert "bağlantı" in msg.lower() or "Bağlantı" in msg

    def test_timeout(self):
        from core.runtime import _actionable_llm_error
        msg = _actionable_llm_error("Request timed out after 30s")
        assert "zaman" in msg.lower() or "Zaman" in msg

    def test_jinja_role_error(self):
        from core.runtime import _actionable_llm_error
        msg = _actionable_llm_error(
            "Error code: 400 - roles must alternate user and assistant"
        )
        assert "şablon" in msg.lower() or "model" in msg.lower()

    def test_rate_limit(self):
        from core.runtime import _actionable_llm_error
        msg = _actionable_llm_error("429 Too Many Requests")
        assert "rate" in msg.lower() or "Rate" in msg

    def test_unknown_error_truncated(self):
        from core.runtime import _actionable_llm_error
        long_err = "x" * 500
        msg = _actionable_llm_error(long_err)
        assert len(msg) < 300
        assert "..." in msg


class TestClassifyLlmError:
    """_classify_llm_error returns (error_class, http_status, action_hint)."""

    def test_connection(self):
        from core.runtime import _classify_llm_error
        cls, st, hint = _classify_llm_error("Connection refused")
        assert cls == "connection"
        assert hint == "check_endpoint_alive"

    def test_role_alternation_extracts_400(self):
        from core.runtime import _classify_llm_error
        cls, st, hint = _classify_llm_error("Error code: 400 - roles must alternate")
        assert cls == "role_alternation"
        assert st == "400"
        assert hint == "check_roles_alternation"

    def test_rate_limit(self):
        from core.runtime import _classify_llm_error
        cls, st, _ = _classify_llm_error("429 Too Many Requests")
        assert cls == "rate_limit"
        assert st == "429"

    def test_unknown(self):
        from core.runtime import _classify_llm_error
        cls, st, hint = _classify_llm_error("something weird happened")
        assert cls == "unknown"
        assert hint == "check_logs"


class TestMessageRolesSig:
    """_message_roles_sig produces compact role signature."""

    def test_basic(self):
        from core.runtime import _message_roles_sig
        msgs = [{"role": "system"}, {"role": "user"}, {"role": "assistant"}]
        assert _message_roles_sig(msgs) == "s,u,a"

    def test_with_tool(self):
        from core.runtime import _message_roles_sig
        msgs = [
            {"role": "system"}, {"role": "user"}, {"role": "assistant"},
            {"role": "tool"}, {"role": "assistant"},
        ]
        assert _message_roles_sig(msgs) == "s,u,a,t,a"

    def test_truncates_to_10(self):
        from core.runtime import _message_roles_sig
        msgs = [{"role": "user"}] * 15
        sig = _message_roles_sig(msgs)
        assert sig.count(",") == 9  # 10 items → 9 commas


class TestLogFinalExtras:
    """RunLogger.log_final accepts **extra for loop health metrics."""

    def test_extra_fields_in_final(self):
        import tempfile
        from pathlib import Path
        from core.run_logger import RunLogger

        with tempfile.TemporaryDirectory() as tmp:
            lg = RunLogger("test", Path(tmp))
            lg.log_final("ok", success=True,
                llm_calls_count=3,
                tool_args_recovered_count=1,
                tool_args_invalid_count=0,
            )
            # Read last event
            import json
            with open(lg.logfile) as f:
                events = [json.loads(line) for line in f]
            final = events[-1]
            assert final["type"] == "final"
            assert final["data"]["llm_calls_count"] == 3
            assert final["data"]["tool_args_recovered_count"] == 1
            assert final["data"]["tool_args_invalid_count"] == 0


# ═══════════════════════════════════════════════════════════════
# Trace mode (core/trace.py)
# ═══════════════════════════════════════════════════════════════

class TestTraceLevel:
    """TraceLevel enum ordering and properties."""

    def test_ordering(self):
        from core.trace import TraceLevel
        assert TraceLevel.OFF < TraceLevel.COMPACT < TraceLevel.STORY < TraceLevel.FULL

    def test_off_is_falsy(self):
        from core.trace import TraceLevel
        assert not TraceLevel.OFF

    def test_values(self):
        from core.trace import TraceLevel
        assert TraceLevel.OFF == 0
        assert TraceLevel.COMPACT == 1
        assert TraceLevel.STORY == 2
        assert TraceLevel.FULL == 3


class TestTraceInit:
    """init_trace / is_off / get_level."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        self._old_file = trace._file

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level
        if trace._file and trace._file is not self._old_file:
            trace._file.close()
        trace._file = self._old_file

    def test_init_sets_level(self):
        from core import trace
        trace.init_trace(level=trace.TraceLevel.COMPACT)
        assert trace._level == trace.TraceLevel.COMPACT
        assert not trace.is_off()
        assert trace.get_level() == trace.TraceLevel.COMPACT

    def test_default_is_off(self):
        from core import trace
        trace.init_trace()
        assert trace.is_off()
        assert trace.get_level() == trace.TraceLevel.OFF


class TestTraceOff:
    """OFF mode produces zero output and zero string work."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        trace.init_trace(level=trace.TraceLevel.OFF)

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level

    def test_no_stderr_output(self, capsys):
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=False, tool_choice=None,
        )
        trace.trace_llm_response(
            content="hello", tool_calls_count=0, finish_reason="stop", latency_ms=100,
        )
        trace.trace_tool_call(tool_name="run_shell", args={"cmd": "ls"})
        trace.trace_tool_result(
            tool_name="run_shell", result_chars=10, result_preview="...",
            error=None, latency_ms=5,
        )
        captured = capsys.readouterr()
        assert captured.err == ""
        assert captured.out == ""

    def test_no_file_output(self, tmp_path):
        from core import trace
        tf = str(tmp_path / "trace.jsonl")
        trace.init_trace(level=trace.TraceLevel.OFF, trace_file=tf)
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=False, tool_choice=None,
        )
        with open(tf) as f:
            assert f.read() == ""
        if trace._file:
            trace._file.close()
            trace._file = None

    def test_estimate_not_called(self):
        """OFF guard at call site prevents token estimation."""
        from core.trace import is_off
        # This simulates the runtime call-site guard pattern
        called = []
        def fake_estimate(text):
            called.append(True)
            return len(text) // 4
        if not is_off():
            fake_estimate("hello world")
        assert called == []  # never called in OFF mode

    def test_story_no_output(self, capsys):
        from core import trace
        trace.trace_story_intent(
            content="I will list files", tool_names=["run_shell"],
            tool_args_previews=["ls -la"],
        )
        trace.trace_story_observed(
            tool_name="run_shell", result_preview="total 12", success=True,
        )
        captured = capsys.readouterr()
        assert captured.err == ""


class TestTraceCompact:
    """COMPACT mode: meta lines only, no body."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        trace.init_trace(level=trace.TraceLevel.COMPACT)

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level

    def test_llm_request(self, capsys):
        from core import trace
        trace.trace_llm_request(
            model="qwen2.5-coder", messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "List files"},
            ],
            tools_enabled=True, tool_choice="auto",
            base_url="http://172.20.1.1:1234/v1",
        )
        err = capsys.readouterr().err
        assert "LLM→" in err
        assert "provider=lmstudio" in err
        assert "model=qwen2.5-coder" in err
        assert "tools=on" in err
        assert "est_tok_in=" in err
        assert "roles=" in err
        # COMPACT: no base_url, no message context
        assert "base_url=" not in err
        assert "[S]" not in err

    def test_llm_response(self, capsys):
        from core import trace
        trace.trace_llm_response(
            content="Hello world", tool_calls_count=0,
            finish_reason="stop", latency_ms=450,
        )
        err = capsys.readouterr().err
        assert "LLM←" in err
        assert "latency=450ms" in err
        assert "stop" in err
        # No body preview in COMPACT
        assert "| Hello" not in err

    def test_tool_call(self, capsys):
        from core import trace
        trace.trace_tool_call(
            tool_name="run_shell", args={"cmd": "ls -la /mnt/c/Users"},
            call_id="call_123",
        )
        err = capsys.readouterr().err
        assert "TOOL→" in err
        assert "run_shell" in err
        assert "args_hash=" in err

    def test_tool_result(self, capsys):
        from core import trace
        trace.trace_tool_result(
            tool_name="run_shell", result_chars=180,
            result_preview="total 12\ndrwxr-xr-x ...",
            error=None, latency_ms=45, call_id="call_123",
        )
        err = capsys.readouterr().err
        assert "TOOL←" in err
        assert "ok" in err
        assert "latency=45ms" in err
        assert "chars=180" in err

    def test_tool_result_error(self, capsys):
        from core import trace
        trace.trace_tool_result(
            tool_name="web_fetch", result_chars=0,
            result_preview="", error="ConnectionError: refused",
            latency_ms=2000,
        )
        err = capsys.readouterr().err
        assert "err" in err
        assert "ConnectionError" in err

    def test_story_not_emitted(self, capsys):
        """COMPACT < STORY, so story hooks should produce no output."""
        from core import trace
        trace.trace_story_intent(
            content="I will list files", tool_names=["run_shell"],
            tool_args_previews=["ls -la"],
        )
        captured = capsys.readouterr()
        assert "STORY" not in captured.err


class TestTraceStory:
    """STORY mode: grouped blocks, Rich-styled, suppresses COMPACT lines."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        self._old_rich = trace._rich_available
        self._old_console = trace._console
        trace.init_trace(level=trace.TraceLevel.STORY)
        # Force plain text fallback so capsys can capture stderr
        trace._rich_available = False
        trace._console = None

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level
        trace._rich_available = self._old_rich
        trace._console = self._old_console

    def test_turn_header(self, capsys):
        """STORY LLM request shows TURN header + model."""
        from core import trace
        trace.trace_llm_request(
            model="qwen2.5-coder", messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "List files"},
            ],
            tools_enabled=True, tool_choice="auto",
            base_url="http://172.20.1.1:1234/v1",
        )
        err = capsys.readouterr().err
        assert "TURN #1" in err
        assert "qwen2.5-coder" in err

    def test_input_section(self, capsys):
        """STORY LLM request shows INPUT section with role tags."""
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[
                {"role": "system", "content": "System prompt"},
                {"role": "user", "content": "Hello there"},
            ],
            tools_enabled=False, tool_choice=None,
        )
        err = capsys.readouterr().err
        assert "INPUT" in err
        assert "[S]" in err
        assert "[U]" in err

    def test_output_section(self, capsys):
        """STORY LLM response shows OUTPUT section with latency."""
        from core import trace
        trace.trace_llm_response(
            content="Hello world", tool_calls_count=0,
            finish_reason="stop", latency_ms=450,
        )
        err = capsys.readouterr().err
        assert "OUTPUT" in err
        assert "450ms" in err

    def test_output_tool_calls(self, capsys):
        """STORY LLM response with tool calls shows tool names."""
        from core import trace
        trace.trace_llm_response(
            content="", tool_calls_count=2,
            finish_reason="tool_calls", latency_ms=800,
            tool_names=["run_shell", "read_file"],
        )
        err = capsys.readouterr().err
        assert "run_shell" in err
        assert "read_file" in err

    def test_intent_section(self, capsys):
        """STORY intent shows INTENT label + tool chain."""
        from core import trace
        trace.trace_story_intent(
            content="I'll check the directory structure first.\nThen read the main file.",
            tool_names=["run_shell", "read_file"],
            tool_args_previews=['{"cmd": "ls -la"}', '{"path": "main.py"}'],
        )
        err = capsys.readouterr().err
        assert "INTENT" in err
        assert "run_shell" in err
        assert "read_file" in err

    def test_tool_call_narrative(self, capsys):
        """STORY tool call shows gear emoji + tool name."""
        from core import trace
        trace.trace_tool_call(
            tool_name="run_shell",
            args={"command": "ls -la /mnt/c/Users"},
            call_id="call_42",
        )
        err = capsys.readouterr().err
        assert "run_shell" in err
        # No COMPACT-style "TOOL→" prefix
        assert "TOOL→" not in err

    def test_tool_result_ok(self, capsys):
        """STORY tool result ok shows green check."""
        from core import trace
        trace.trace_tool_result(
            tool_name="run_shell", result_chars=180,
            result_preview="total 12 drwxr-xr-x ...",
            error=None, latency_ms=45, call_id="call_42",
        )
        err = capsys.readouterr().err
        assert "ok" in err
        assert "45ms" in err
        # No COMPACT-style "TOOL←" prefix
        assert "TOOL←" not in err

    def test_tool_result_error(self, capsys):
        """STORY tool result error shows red cross."""
        from core import trace
        trace.trace_tool_result(
            tool_name="web_fetch", result_chars=0,
            result_preview="", error="ConnectionError: refused",
            latency_ms=2000,
        )
        err = capsys.readouterr().err
        assert "ERROR" in err
        assert "ConnectionError" in err

    def test_observed_no_terminal(self, capsys):
        """STORY observed produces no terminal output (JSONL only)."""
        from core import trace
        trace.trace_story_observed(
            tool_name="run_shell",
            result_preview="total 12 drwxr-xr-x ...",
            success=True,
        )
        err = capsys.readouterr().err
        assert err.strip() == ""

    def test_suppresses_compact_lines(self, capsys):
        """STORY mode never emits LLM→/LLM←/TOOL→/TOOL← lines."""
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=True, tool_choice="auto",
        )
        trace.trace_llm_response(
            content="ok", tool_calls_count=0,
            finish_reason="stop", latency_ms=100,
        )
        trace.trace_tool_call(tool_name="read_file", args={"path": "x.py"})
        trace.trace_tool_result(
            tool_name="read_file", result_chars=50,
            result_preview="content...", error=None, latency_ms=5,
        )
        err = capsys.readouterr().err
        assert "LLM→" not in err
        assert "LLM←" not in err
        assert "TOOL→" not in err
        assert "TOOL←" not in err

    def test_memory_recall(self, capsys):
        """STORY memory recall shows memory section."""
        from core import trace
        trace.trace_memory_recall(
            source="phase0",
            entity_count=3,
            result_count=2,
            top_snippets=[
                {"level": "HIGH", "content": "Git repo at /home/user/project"},
                {"level": "LOW", "content": "Last used pytest"},
            ],
        )
        err = capsys.readouterr().err
        assert "MEMORY" in err
        assert "phase0" in err
        assert "HIGH" in err

    def test_no_secrets_in_story(self, capsys):
        """STORY sanitizes secrets from all outputs."""
        from core import trace
        trace.trace_tool_call(
            tool_name="web_fetch",
            args={"url": "http://host?token=abc123secret"},
        )
        err = capsys.readouterr().err
        assert "abc123secret" not in err


class TestTraceFull:
    """FULL mode: message context + response previews."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        trace.init_trace(level=trace.TraceLevel.FULL, max_lines=2, last_k=3)

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level

    def test_shows_base_url(self, capsys):
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=False, tool_choice=None,
            base_url="http://172.20.1.1:1234/v1",
        )
        err = capsys.readouterr().err
        assert "base_url=" in err

    def test_shows_message_context(self, capsys):
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "List files"},
                {"role": "assistant", "content": "Sure, listing files."},
            ],
            tools_enabled=False, tool_choice=None,
        )
        err = capsys.readouterr().err
        assert "[S] You are helpful." in err
        assert "[U] List files" in err

    def test_respects_last_k(self, capsys):
        from core import trace
        msgs = [{"role": "user", "content": f"msg-{i}"} for i in range(10)]
        trace.trace_llm_request(
            model="test", messages=msgs,
            tools_enabled=False, tool_choice=None,
        )
        err = capsys.readouterr().err
        # last_k=3, so only last 3 messages shown
        assert "msg-7" in err
        assert "msg-8" in err
        assert "msg-9" in err
        assert "msg-0" not in err

    def test_response_preview_lines(self, capsys):
        from core import trace
        trace.trace_llm_response(
            content="Line 1\nLine 2\nLine 3\nLine 4",
            tool_calls_count=0, finish_reason="stop", latency_ms=100,
        )
        err = capsys.readouterr().err
        assert "| Line 1" in err
        assert "| Line 2" in err
        assert "Line 3" not in err  # max_lines=2

    def test_tool_result_preview_lines(self, capsys):
        from core import trace
        trace.trace_tool_result(
            tool_name="read_file", result_chars=500,
            result_preview="# main.py\nimport os\nimport sys\nprint('hello')",
            error=None, latency_ms=10,
        )
        err = capsys.readouterr().err
        assert "| # main.py" in err
        assert "| import os" in err
        # FULL detail lines capped at max_lines=2
        pipe_lines = [l for l in err.split("\n") if l.strip().startswith("|")]
        assert len(pipe_lines) == 2

    def test_message_preview_capped_200(self, capsys):
        from core import trace
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "A" * 500}],
            tools_enabled=False, tool_choice=None,
        )
        err = capsys.readouterr().err
        for line in err.strip().split("\n"):
            if line.strip().startswith("[U]"):
                assert len(line) < 220  # 200 + prefix overhead


class TestTraceHelpers:
    """Helper functions: _preview, _sanitize, _detect_provider, _args_hash."""

    def test_preview_truncation(self):
        from core.trace import _preview
        assert _preview("hello", 10) == "hello"
        long_result = _preview("a" * 200, 50)
        assert len(long_result) == 53  # 50 + "..."
        assert long_result.endswith("...")

    def test_preview_newline_collapse(self):
        from core.trace import _preview
        assert _preview("line1\nline2\nline3", 100) == "line1 line2 line3"

    def test_preview_empty(self):
        from core.trace import _preview
        assert _preview("") == ""
        assert _preview(None) == ""

    def test_sanitize_masks_key(self):
        from core.trace import _sanitize
        result = _sanitize("api key=sk-abc123 extra")
        assert "sk-abc123" not in result
        assert "key=***" in result

    def test_sanitize_masks_token(self):
        from core.trace import _sanitize
        result = _sanitize("token: mytoken123")
        assert "mytoken123" not in result
        assert "token: ***" in result

    def test_sanitize_masks_password(self):
        from core.trace import _sanitize
        result = _sanitize("password=hunter2")
        assert "hunter2" not in result

    def test_sanitize_preserves_normal(self):
        from core.trace import _sanitize
        text = "hello world model=qwen"
        assert _sanitize(text) == text

    def test_detect_provider_lmstudio(self):
        from core.trace import _detect_provider
        assert _detect_provider("http://172.20.1.1:1234/v1") == "lmstudio"

    def test_detect_provider_openai(self):
        from core.trace import _detect_provider
        assert _detect_provider("https://api.openai.com/v1") == "openai"

    def test_detect_provider_anthropic(self):
        from core.trace import _detect_provider
        assert _detect_provider("https://api.anthropic.com/v1") == "anthropic"

    def test_detect_provider_local(self):
        from core.trace import _detect_provider
        assert _detect_provider("http://localhost:8080/v1") == "local"

    def test_detect_provider_custom(self):
        from core.trace import _detect_provider
        assert _detect_provider("https://myserver.com/v1") == "custom"

    def test_args_hash_deterministic(self):
        from core.trace import _args_hash
        args = {"cmd": "ls -la", "path": "/tmp"}
        assert _args_hash(args) == _args_hash(args)

    def test_args_hash_differs_for_different_args(self):
        from core.trace import _args_hash
        h1 = _args_hash({"cmd": "ls"})
        h2 = _args_hash({"cmd": "pwd"})
        assert h1 != h2

    def test_args_hash_order_independent(self):
        from core.trace import _args_hash
        h1 = _args_hash({"a": 1, "b": 2})
        h2 = _args_hash({"b": 2, "a": 1})
        assert h1 == h2

    def test_roles_sig(self):
        from core.trace import _roles_sig
        msgs = [{"role": "system"}, {"role": "user"}, {"role": "assistant"},
                {"role": "tool"}, {"role": "user"}]
        assert _roles_sig(msgs) == "s,u,a,t,u"

    def test_roles_sig_truncates_to_10(self):
        from core.trace import _roles_sig
        msgs = [{"role": "user"}] * 15
        sig = _roles_sig(msgs)
        assert sig.count(",") == 9  # 10 items → 9 commas

    def test_human_args_path(self):
        from core.trace import _human_args
        assert _human_args("read_file", {"path": "/home/user/main.py"}) == "/home/user/main.py"

    def test_human_args_query(self):
        from core.trace import _human_args
        assert _human_args("search_files", {"query": "def main"}) == '"def main"'

    def test_human_args_command(self):
        from core.trace import _human_args
        result = _human_args("run_shell", {"command": "ls -la /mnt/c/Users"})
        assert "ls -la" in result

    def test_human_args_fallback(self):
        from core.trace import _human_args
        result = _human_args("custom_tool", {"x": "val1", "y": "val2"})
        assert "x=" in result
        assert "y=" in result

    def test_human_args_empty(self):
        from core.trace import _human_args
        assert _human_args("noop", {}) == "()"


class TestTraceMemoryHooks:
    """Memory trace hooks: recall, search, write."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        self._old_rich = trace._rich_available
        self._old_console = trace._console
        trace.init_trace(level=trace.TraceLevel.COMPACT)

    def teardown_method(self):
        from core import trace
        trace._level = self._old_level
        trace._rich_available = self._old_rich
        trace._console = self._old_console

    def test_recall_compact(self, capsys):
        from core import trace
        trace.trace_memory_recall(
            source="phase0", entity_count=3, result_count=2,
            top_snippets=[{"level": "HIGH", "content": "Project at /home/user"}],
        )
        err = capsys.readouterr().err
        assert "MEMORY phase0" in err
        assert "3 entities" in err
        assert "2 results" in err
        assert "[HIGH]" in err

    def test_search_compact(self, capsys):
        from core import trace
        trace.trace_memory_search(query="main.py", limit=5)
        err = capsys.readouterr().err
        assert "MEMORY search" in err
        assert "main.py" in err

    def test_write_compact(self, capsys):
        from core import trace
        trace.trace_memory_write(kind="solution", key="fix_imports")
        err = capsys.readouterr().err
        assert "MEMORY write" in err
        assert "solution" in err

    def test_off_no_output(self, capsys):
        from core import trace
        trace._level = trace.TraceLevel.OFF
        trace.trace_memory_recall(source="x", entity_count=1, result_count=1)
        trace.trace_memory_search(query="x", limit=1)
        trace.trace_memory_write(kind="x", key="y")
        assert capsys.readouterr().err == ""

    def test_recall_jsonl(self, tmp_path):
        from core import trace
        tf = str(tmp_path / "mem.jsonl")
        trace.init_trace(level=trace.TraceLevel.COMPACT, trace_file=tf)
        trace.trace_memory_recall(source="runtime", entity_count=2, result_count=1)
        if trace._file:
            trace._file.close()
            trace._file = None
        with open(tf) as f:
            ev = json.loads(f.readline())
        assert ev["event"] == "memory_recall"
        assert ev["source"] == "runtime"


class TestTraceFile:
    """--trace-file JSONL output."""

    def setup_method(self):
        from core import trace
        self._old_level = trace._level
        self._old_file = trace._file

    def teardown_method(self):
        from core import trace
        if trace._file and trace._file is not self._old_file:
            trace._file.close()
        trace._file = self._old_file
        trace._level = self._old_level

    def test_jsonl_written(self, tmp_path):
        from core import trace
        tf = str(tmp_path / "trace.jsonl")
        trace.init_trace(level=trace.TraceLevel.COMPACT, trace_file=tf)
        trace.trace_llm_request(
            model="test", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=False, tool_choice=None,
        )
        trace.trace_tool_call(tool_name="run_shell", args={"cmd": "ls"})
        if trace._file:
            trace._file.close()
            trace._file = None
        with open(tf) as f:
            lines = [json.loads(l) for l in f if l.strip()]
        assert len(lines) == 2
        assert lines[0]["event"] == "llm_request"
        assert lines[1]["event"] == "tool_call"

    def test_jsonl_has_required_fields(self, tmp_path):
        from core import trace
        tf = str(tmp_path / "trace.jsonl")
        trace.init_trace(level=trace.TraceLevel.COMPACT, trace_file=tf, run_id="test123")
        trace.trace_llm_request(
            model="qwen", messages=[{"role": "user", "content": "hi"}],
            tools_enabled=True, tool_choice="auto",
            base_url="http://localhost:1234/v1",
        )
        if trace._file:
            trace._file.close()
            trace._file = None
        with open(tf) as f:
            ev = json.loads(f.readline())
        assert ev["ts"]  # ISO timestamp
        assert ev["run_id"] == "test123"
        assert ev["provider"] == "lmstudio"
        assert ev["model"] == "qwen"
        assert ev["msg_count"] == 1
        assert ev["roles_sig"] == "u"
        assert ev["tools_enabled"] is True

    def test_story_jsonl(self, tmp_path):
        from core import trace
        tf = str(tmp_path / "trace.jsonl")
        trace.init_trace(level=trace.TraceLevel.STORY, trace_file=tf)
        trace.trace_story_intent(
            content="Listing files", tool_names=["run_shell"],
            tool_args_previews=["ls"],
        )
        trace.trace_story_observed(
            tool_name="run_shell", result_preview="total 12", success=True,
        )
        if trace._file:
            trace._file.close()
            trace._file = None
        with open(tf) as f:
            events = [json.loads(l) for l in f if l.strip()]
        assert events[0]["event"] == "story"
        assert events[0]["phase"] == "intent"
        assert events[1]["event"] == "story"
        assert events[1]["phase"] == "observed"


# ═══════════════════════════════════════════════════════════════
# Bug Fixes: aç intent routing, permanent block, hallucination
# ═══════════════════════════════════════════════════════════════


class TestAcIntentRouting:
    """BUG 1: 'aç' intent should route to open_in_explorer/open_file, not list_dir."""

    def test_system_prompt_has_ac_routing(self):
        """System prompt includes 'aç' → open_in_explorer routing rule."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "open_in_explorer" in prompt
        assert "open_file" in prompt
        # The critical rule: "aç" with folder = open_in_explorer
        assert "aç" in prompt
        assert "NEVER list_dir" in prompt or "NEVER read_file" in prompt

    def test_ac_routing_distinguishes_listele(self):
        """System prompt distinguishes 'listele' (list_dir) from 'aç' (open)."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "listele" in prompt
        assert "list_dir" in prompt


class TestPermanentBlock:
    """BUG 2: Blocked tool+args must be permanently blocked — no retry."""

    def test_permanent_block_set_exists(self):
        """Runtime uses _permanently_blocked set (verified via source inspection)."""
        import inspect
        from core.runtime import run_task
        source = inspect.getsource(run_task)
        assert "_permanently_blocked" in source
        assert "KALICI ENGEL" in source or "PERM-BLOCKED" in source

    def test_permanent_block_prevents_retry(self):
        """Simulated: once a tool+args sig is in permanently_blocked, it's instant-rejected."""
        import hashlib
        # Simulate the runtime logic
        _permanently_blocked = set()
        fn_name = "list_dir"
        args = {"path": "/home/user/projects"}
        sig = f"{fn_name}:{hashlib.md5(json.dumps(args, sort_keys=True).encode()).hexdigest()[:12]}"

        # First block adds to set
        _permanently_blocked.add(sig)

        # Second call hits permanent block
        assert sig in _permanently_blocked

        # Different args should NOT be blocked
        args2 = {"path": "/tmp"}
        sig2 = f"{fn_name}:{hashlib.md5(json.dumps(args2, sort_keys=True).encode()).hexdigest()[:12]}"
        assert sig2 not in _permanently_blocked

    def test_permanent_block_added_on_budget_block(self):
        """Source confirms _permanently_blocked.add(_fp_sig) in budget block path."""
        import inspect
        from core.runtime import run_task
        source = inspect.getsource(run_task)
        assert "_permanently_blocked.add(_fp_sig)" in source


class TestAcHallucination:
    """BUG 3: Hallucination check — 'açtım' without open tool → warning."""

    def test_actim_without_open_tool_warns(self):
        """If user says 'aç', model says 'açtım', but no open tool → warning."""
        from core.runtime import check_hallucination
        answer = "Klasörü açtım, içerisindeki dosyalar aşağıda."
        result = check_hallucination(
            answer, blocked_reads=[], files_read=None,
            tools_used=["list_dir"], raw_input="aç bu klasörü",
        )
        assert "UYARI" in result
        assert "open_in_explorer" in result or "open_file" in result

    def test_actim_with_open_tool_no_warning(self):
        """If open_in_explorer was actually called, no hallucination warning."""
        from core.runtime import check_hallucination
        answer = "Klasörü açtım."
        result = check_hallucination(
            answer, blocked_reads=[], files_read=None,
            tools_used=["open_in_explorer"], raw_input="aç bu klasörü",
        )
        assert "UYARI" not in result

    def test_no_ac_intent_no_warning(self):
        """If user didn't ask to 'aç', no hallucination check triggered."""
        from core.runtime import check_hallucination
        answer = "Dosyaları listeledim."
        result = check_hallucination(
            answer, blocked_reads=[], files_read=None,
            tools_used=["list_dir"], raw_input="listele",
        )
        assert "UYARI" not in result

    def test_ac_intent_no_claim_no_warning(self):
        """If user says 'aç' but model doesn't claim it opened, no warning."""
        from core.runtime import check_hallucination
        answer = "Bu klasörü açamadım, hata oluştu."
        result = check_hallucination(
            answer, blocked_reads=[], files_read=None,
            tools_used=["list_dir"], raw_input="aç bu klasörü",
        )
        assert "UYARI" not in result

    def test_open_file_also_counts(self):
        """open_file tool call also prevents hallucination warning."""
        from core.runtime import check_hallucination
        answer = "Dosyayı açtım."
        result = check_hallucination(
            answer, blocked_reads=[], files_read=None,
            tools_used=["open_file"], raw_input="dosyayı aç",
        )
        assert "UYARI" not in result


# ═══════════════════════════════════════════════════════════════
# Bug Fixes: capability map, language guard, false success
# ═══════════════════════════════════════════════════════════════


class TestCapabilityMap:
    """BUG 4: System prompt must include capability map."""

    def test_yetenek_haritasi_in_prompt(self):
        """System prompt contains YETENEK HARİTASI section."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "YETENEK HARİTASI" in prompt

    def test_browser_agent_mentioned(self):
        """Capability map mentions browser_agent for scraping."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "browser_agent" in prompt
        assert "browser_open" in prompt

    def test_yapamam_deme_rule(self):
        """Prompt tells model to never say 'yapamam'."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "Yapamam" in prompt or "yapamam" in prompt

    def test_eksi_sozluk_example(self):
        """Prompt includes Ekşi Sözlük as reachable example."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "Ekşi" in prompt or "eksi" in prompt.lower()


class TestLanguageGuard:
    """BUG 5: Turkish input must get Turkish response."""

    def test_language_rule_in_prompt(self):
        """System prompt has LANGUAGE rule at the top."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "LANGUAGE:" in prompt
        assert "Türkçe" in prompt

    def test_language_rule_before_tools(self):
        """LANGUAGE rule appears before Available tools."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        lang_pos = prompt.index("LANGUAGE:")
        tools_pos = prompt.index("Available tools:")
        assert lang_pos < tools_pos

    def test_language_bidirectional(self):
        """Rule covers both TR→TR and EN→EN."""
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/test", 12)
        assert "English input" in prompt or "İngilizce" in prompt


class TestFalseSuccess:
    """BUG 6: Action intent + zero tools = false success."""

    def test_action_verb_zero_tools_is_false(self):
        """'aç bu klasörü' with 0 tool calls → false success."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="aç bu klasörü",
            answer="Klasörü açtım.",
            tool_calls_count=0,
            tools_used=[],
        )
        assert is_false
        assert reason == "no_action_taken"

    def test_action_verb_with_tools_is_real(self):
        """'aç bu klasörü' with tool calls → real success."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="aç bu klasörü",
            answer="Klasörü açtım.",
            tool_calls_count=1,
            tools_used=["open_in_explorer"],
        )
        assert not is_false

    def test_no_action_verb_is_real(self):
        """Greeting without action verb → real success."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="merhaba",
            answer="Merhaba!",
            tool_calls_count=0,
            tools_used=[],
        )
        assert not is_false

    def test_cek_verb_detected(self):
        """'çek' (fetch/pull) is an action verb."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="mevzuattan kanunu çek",
            answer="İşte kanun metni...",
            tool_calls_count=0,
            tools_used=[],
        )
        assert is_false

    def test_bul_verb_detected(self):
        """'bul' (find) is an action verb."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="dosyayı bul",
            answer="Dosya burada.",
            tool_calls_count=0,
            tools_used=[],
        )
        assert is_false

    def test_empty_input_no_crash(self):
        """Empty input → not false success, no crash."""
        from core.runtime import detect_false_success
        is_false, reason = detect_false_success(
            raw_input="", answer="ok", tool_calls_count=0, tools_used=[],
        )
        assert not is_false


# ── FIX 2: Fenced tool_request parser ─────────────────────────────────
class TestFencedToolRequest:
    """extract_fenced_tool_requests parses tool_request fenced blocks."""

    def test_single_tool_request(self):
        from core.runtime import extract_fenced_tool_requests
        text = '```tool_request\n{"name":"list_dir","arguments":{"path":"."}}\n```'
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 1
        assert calls[0]["name"] == "list_dir"
        assert calls[0]["args"] == {"path": "."}

    def test_multiple_tool_requests(self):
        from core.runtime import extract_fenced_tool_requests
        text = (
            '```tool_request\n{"name":"list_dir","arguments":{"path":"."}}\n```\n'
            'Some text in between.\n'
            '```tool_request\n{"name":"read_file","arguments":{"path":"a.py"}}\n```'
        )
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 2
        assert calls[0]["name"] == "list_dir"
        assert calls[1]["name"] == "read_file"

    def test_invalid_json_no_crash(self):
        from core.runtime import extract_fenced_tool_requests
        text = '```tool_request\n{broken json}\n```'
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 0

    def test_missing_name_field_skipped(self):
        from core.runtime import extract_fenced_tool_requests
        text = '```tool_request\n{"tool":"list_dir","args":{"path":"."}}\n```'
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 0

    def test_no_tool_request_in_text(self):
        from core.runtime import extract_fenced_tool_requests
        text = "Just some normal model output without any tool requests."
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 0

    def test_empty_text(self):
        from core.runtime import extract_fenced_tool_requests
        assert extract_fenced_tool_requests("") == []
        assert extract_fenced_tool_requests(None) == []

    def test_args_key_fallback(self):
        """'args' key works as fallback for 'arguments'."""
        from core.runtime import extract_fenced_tool_requests
        text = '```tool_request\n{"name":"web_search","args":{"query":"test"}}\n```'
        calls = extract_fenced_tool_requests(text)
        assert len(calls) == 1
        assert calls[0]["args"] == {"query": "test"}


# ── FIX 12: Tool error recovery patterns ──────────────────────────────
class TestToolErrorRecovery:
    """check_tool_error_recovery matches known error patterns."""

    def test_content_type_not_allowed(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("Content type not allowed: application/pdf")
        assert recovery is not None
        assert recovery["block"] is True
        assert "browser" in recovery["msg"].lower()

    def test_too_many_redirects(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("Too many redirects for url https://example.com")
        assert recovery is not None
        assert recovery["block"] is True

    def test_timeout_expired(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("TimeoutExpired: find /mnt/c/Users")
        assert recovery is not None
        assert recovery["block"] is True
        assert "mnt/c" in recovery["msg"]

    def test_blocked_ip(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("Request failed: blocked IP detected")
        assert recovery is not None
        assert recovery["block"] is True

    def test_connection_refused_no_block(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("Connection refused by server")
        assert recovery is not None
        assert recovery["block"] is False  # Don't permanently block

    def test_unknown_error_returns_none(self):
        from core.runtime import check_tool_error_recovery
        recovery = check_tool_error_recovery("TypeError: some random error")
        assert recovery is None

    def test_recovery_dict_has_required_keys(self):
        from core.runtime import TOOL_ERROR_RECOVERY
        for pattern, recovery in TOOL_ERROR_RECOVERY.items():
            assert "msg" in recovery, f"Missing 'msg' for pattern '{pattern}'"
            assert "block" in recovery, f"Missing 'block' for pattern '{pattern}'"
            assert isinstance(recovery["block"], bool)
