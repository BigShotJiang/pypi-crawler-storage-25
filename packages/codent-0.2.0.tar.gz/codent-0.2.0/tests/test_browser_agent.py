"""
Tests for core/browser_agent.py — Autonomous browser navigation agent.
Run: pytest tests/test_browser_agent.py -v
"""
import pytest


class TestObservePage:
    """observe_page returns structured DOM data."""

    def test_returns_structured_data(self):
        from core.browser_agent import observe_page
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        obs = observe_page(b)

        assert "url" in obs
        assert "title" in obs
        assert "inputs" in obs
        assert "buttons" in obs
        assert "links" in obs
        assert "tables" in obs
        assert "textPreview" in obs

        b.close()

    def test_captures_links(self):
        from core.browser_agent import observe_page
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        obs = observe_page(b)

        # example.com has a link
        assert len(obs.get("links", [])) >= 1
        assert any("iana" in l.get("href", "") for l in obs["links"])

        b.close()


class TestExecuteAction:
    """execute_action handles various action types."""

    def test_wait(self):
        from core.browser_agent import execute_action
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        result = execute_action(b, {"action": "wait", "ms": 100})
        assert result["success"] is True
        b.close()

    def test_extract_text(self):
        from core.browser_agent import execute_action
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        result = execute_action(b, {"action": "extract_text", "selector": "h1"})
        assert result["success"] is True
        assert "Example" in result.get("text", "")
        b.close()

    def test_unknown_action(self):
        from core.browser_agent import execute_action
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        result = execute_action(b, {"action": "nonexistent"})
        assert result["success"] is False
        assert "Unknown" in result.get("error", "")
        b.close()

    def test_screenshot(self):
        import tempfile
        from core.browser_agent import execute_action
        from core.browser import Browser

        b = Browser.get_instance()
        b.open("https://example.com")
        path = tempfile.mktemp(suffix=".png")
        result = execute_action(b, {"action": "screenshot", "path": path})
        assert result["success"] is True
        b.close()


class TestBrowserAgent:
    """BrowserAgent class."""

    def test_no_api_key(self):
        from core.browser_agent import BrowserAgent
        from unittest.mock import patch

        agent = BrowserAgent(api_key=None)
        with patch("core.teacher.get_api_key", return_value=None):
            result = agent.run("https://example.com", "test")
            assert isinstance(result, dict)
            assert result["success"] is False
            assert "API key" in result.get("error", "")

    def test_bad_url(self):
        from core.browser_agent import BrowserAgent

        agent = BrowserAgent(api_key="sk-fake")
        result = agent.run("file:///etc/passwd", "read secrets")
        assert result["success"] is False


class TestToolRegistration:
    """browser_agent registered in cont."""

    def test_in_tools(self):
        from cont import TOOLS

        assert "browser_agent" in TOOLS

    def test_in_schemas(self):
        from cont import TOOL_SCHEMAS

        names = {s["function"]["name"] for s in TOOL_SCHEMAS}
        assert "browser_agent" in names

    def test_security_tier(self):
        from core.safety import classify_tool, SecurityTier

        assert classify_tool("browser_agent", {}) == SecurityTier.SAFE_ZONES
