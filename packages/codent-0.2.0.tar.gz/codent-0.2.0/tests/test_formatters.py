"""
Tests for core/formatters.py — prompt strings and formatting helpers.
Run: pytest tests/test_formatters.py -v
"""
import sys
import os
import re

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestGreetingDetection:
    """is_greeting_response detects model greetings."""

    def test_turkish_greeting(self):
        from core.formatters import is_greeting_response
        assert is_greeting_response("Merhaba! Size nasıl yardımcı olabilirim?")

    def test_selam_greeting(self):
        from core.formatters import is_greeting_response
        assert is_greeting_response("Selam, hoş geldiniz!")

    def test_english_greeting(self):
        from core.formatters import is_greeting_response
        assert is_greeting_response("Hello! How can I help you today?")

    def test_not_greeting_content(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("KOSGEB yönetmeliği şu şekildedir...")

    def test_not_greeting_file_content(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("İşte indirilen dosyalar:")

    def test_empty_string(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("")

    def test_none_like(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("   ")


class TestFormatPrompts:
    """Format system prompts contain anti-greeting rules."""

    def test_format_prompt_has_anti_greeting(self):
        from core.formatters import build_format_system_prompt
        prompt = build_format_system_prompt()
        assert "Selamlama" in prompt or "selamlama" in prompt
        assert "formatla" in prompt.lower()

    def test_format_prompt_no_tools(self):
        from core.formatters import build_format_system_prompt
        prompt = build_format_system_prompt()
        assert "Tool" in prompt  # "Tool çağrısı yapma"

    def test_browser_format_prompt(self):
        from core.formatters import build_browser_format_system_prompt
        prompt = build_browser_format_system_prompt()
        assert "Browser" in prompt or "browser" in prompt
        assert "Selamlama" in prompt

    def test_browser_rescue_prompt(self):
        from core.formatters import build_browser_rescue_system_prompt
        prompt = build_browser_rescue_system_prompt()
        assert "browser" in prompt.lower()
        assert "Selamlama" in prompt

    def test_summarize_prompt(self):
        from core.formatters import build_summarize_system_prompt
        prompt = build_summarize_system_prompt()
        assert "özetle" in prompt.lower() or "özet" in prompt.lower()

    def test_summarize_user_prompt(self):
        from core.formatters import build_summarize_user_prompt
        prompt = build_summarize_user_prompt(5, "dosyaları listele", "file1.py\nfile2.py")
        assert "5" in prompt
        assert "dosyaları listele" in prompt
        assert "file1.py" in prompt


class TestBrowserUserPrompt:
    """build_browser_user_prompt formats task + content."""

    def test_contains_task_and_content(self):
        from core.formatters import build_browser_user_prompt
        prompt = build_browser_user_prompt("bddk kanunu bul", "BDDK YÖNETMELİĞİ içerik...")
        assert "bddk kanunu bul" in prompt
        assert "BDDK YÖNETMELİĞİ" in prompt


class TestToolMessages:
    """Tool loop control messages are well-formed."""

    def test_tool_blocked_message(self):
        from core.formatters import tool_blocked_msg
        msg = tool_blocked_msg("web_search")
        assert "web_search" in msg
        assert "BLOCKED" in msg

    def test_tool_blocked_path_hint_list_dir(self):
        from core.formatters import tool_blocked_path_hint
        hint = tool_blocked_path_hint("list_dir")
        assert "find_path" in hint or "system_search" in hint

    def test_tool_blocked_path_hint_unknown(self):
        from core.formatters import tool_blocked_path_hint
        assert tool_blocked_path_hint("web_search") == ""

    def test_budget_exhausted(self):
        from core.formatters import budget_exhausted_msg, FINALIZE_MARKER
        msg = budget_exhausted_msg("9/12 A1", 9)
        assert "9" in msg
        assert FINALIZE_MARKER in msg

    def test_budget_nearly_exhausted(self):
        from core.formatters import budget_nearly_exhausted_msg
        msg = budget_nearly_exhausted_msg("11/12 A1")
        assert "1 tool" in msg

    def test_tool_limit_reached(self):
        from core.formatters import tool_limit_reached_msg
        msg = tool_limit_reached_msg("web_search", 3, "web_fetch, browser_open")
        assert "web_search" in msg
        assert "3" in msg
        assert "ZORUNLU" in msg

    def test_tool_limit_system_inject(self):
        from core.formatters import tool_limit_system_inject_msg
        msg = tool_limit_system_inject_msg("list_dir", "find_path")
        assert "list_dir" in msg
        assert "find_path" in msg

    def test_phase_checkpoint(self):
        from core.formatters import phase_checkpoint_msg
        msg = phase_checkpoint_msg(12, 2, 4, "  - some results")
        assert "12" in msg
        assert "2/4" in msg or ("2" in msg and "4" in msg)
        assert "some results" in msg

    def test_all_phases_exhausted(self):
        from core.formatters import all_phases_exhausted_msg
        msg = all_phases_exhausted_msg(48)
        assert "48" in msg

    def test_too_many_blocks(self):
        from core.formatters import too_many_blocks_msg
        msg = too_many_blocks_msg(5)
        assert "5" in msg

    def test_task_reminder(self):
        from core.formatters import task_reminder_msg
        msg = task_reminder_msg("dosyayı bul ve oku")
        assert "dosyayı bul" in msg

    def test_task_reminder_truncation(self):
        from core.formatters import task_reminder_msg
        long_input = "a" * 500
        msg = task_reminder_msg(long_input)
        assert len(long_input) > 200
        assert "a" * 200 in msg
        assert "a" * 201 not in msg

    def test_empty_response(self):
        from core.formatters import empty_response_msg
        msg = empty_response_msg()
        assert "empty response" in msg.lower()

    def test_security_blocked(self):
        from core.formatters import security_blocked_msg
        msg = security_blocked_msg("web_fetch")
        assert "web_fetch" in msg
        assert "güvenlik" in msg or "engellendi" in msg

    def test_unknown_tool(self):
        from core.formatters import unknown_tool_msg
        msg = unknown_tool_msg("fake_tool", ["read_file", "list_dir"])
        assert "fake_tool" in msg
        assert "list_dir" in msg
        assert "read_file" in msg


class TestSystemPrompt:
    """Bare system prompt template is valid."""

    def test_bare_prompt_renders(self):
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/home/test/repo", 12)
        assert "/home/test/repo" in prompt
        assert "12" in prompt

    def test_bare_prompt_has_tools(self):
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp", 10)
        assert "list_dir" in prompt
        assert "read_file" in prompt
        assert "browser_agent" in prompt

    def test_bare_prompt_has_rules(self):
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp", 10)
        assert "EVIDENCE REQUIRED" in prompt
        assert "WRITE PROTECTION" in prompt


class TestLeakMarkers:
    """LEAK_MARKERS are used by _sanitize_response."""

    def test_markers_exist(self):
        from core.formatters import LEAK_MARKERS
        assert len(LEAK_MARKERS) > 10
        assert "You are cont —" in LEAK_MARKERS
        assert "Available tools:" in LEAK_MARKERS

    def test_finalize_marker_in_leak(self):
        from core.formatters import LEAK_MARKERS, FINALIZE_MARKER
        assert FINALIZE_MARKER in LEAK_MARKERS


class TestNoBusinessLogic:
    """formatters.py must not import from core/ modules."""

    def test_no_core_imports(self):
        import inspect
        import core.formatters
        source = inspect.getsource(core.formatters)
        core_imports = re.findall(r'^(?:from|import)\s+core\.', source, re.MULTILINE)
        assert core_imports == [], f"core/formatters.py imports core modules: {core_imports}"
