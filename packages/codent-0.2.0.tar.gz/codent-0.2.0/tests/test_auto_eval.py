"""
Tests for core/auto_eval.py — automatic task evaluation.
Run: pytest tests/test_auto_eval.py -v
"""
import pytest


class TestEvalGreeting:
    """Greeting responses should be detected as failures."""

    def test_greeting_response(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "dosya listele",
            "Merhaba! Size nasıl yardımcı olabilirim?",
        )
        assert result["success"] is False
        assert result["score"] < 40

    def test_selam_response(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "proje analiz et",
            "Selam! Ben bir yapay zeka asistanıyım.",
        )
        assert result["score"] < 50


class TestEvalFastpath:
    """Fastpath responses get a boost."""

    def test_good_fastpath(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "indirilenler listele",
            "| Tarih | Dosya |\n|---|---|\n| Feb 17 | test.pdf |",
            task_type="fastpath",
            tools_used=0,
        )
        assert result["success"] is True
        assert result["score"] >= 60

    def test_recipe_boost(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "dosya oku",
            "Bu dosya Python modülüdür. import os kullanır.",
            task_type="recipe",
            tools_used=1,
        )
        assert result["success"] is True


class TestEvalDenial:
    """Denial/inability responses should be penalized."""

    def test_denial_erisemiyorum(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "dosya oku",
            "Bu dosyaya erişemiyorum.",
        )
        assert result["success"] is False

    def test_denial_yapamiyorum(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "kod düzenle",
            "Yapamıyorum, bu dosyayı bulamıyorum.",
        )
        assert result["success"] is False


class TestEvalJsonDump:
    """Raw JSON dumps should be penalized."""

    def test_json_dump(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "görev yap",
            '[{"id":"call_123","function":{"name":"read_file"},'
            '"type":"function","arguments":"{}"}, '
            '{"id":"call_456","function":{"name":"list_dir"},'
            '"type":"function","arguments":"{\\"path\\": \\"/home\\"}"}]',
        )
        assert result["score"] < 50


class TestEvalPositive:
    """Positive signals should boost the score."""

    def test_code_content(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "dosya oku test.py",
            "Bu dosya test modülüdür:\n```python\nimport pytest\ndef test_foo():\n    assert True\n```",
            tools_used=1,
        )
        assert result["success"] is True

    def test_table_format(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "proje analiz et",
            "| Dosya | Boyut |\n|---|---|\n| main.py | 2KB |\n| test.py | 1KB |",
            tools_used=2,
        )
        assert result["success"] is True

    def test_path_in_response(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task(
            "dosyayı bul",
            "Dosya şurada bulundu: /home/user/project/main.py",
            tools_used=1,
        )
        assert result["success"] is True


class TestEvalEmpty:
    """Empty responses should always fail."""

    def test_empty_response(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task("herhangi bir görev", "")
        assert result["success"] is False
        assert result["score"] == 0

    def test_none_like_empty(self):
        from core.auto_eval import evaluate_task

        result = evaluate_task("görev", "")
        assert result["confidence"] == 0.9


class TestEvalRecipeCriteria:
    """Recipe success_criteria integration."""

    def test_criteria_met(self):
        from core.auto_eval import evaluate_task

        criteria = {
            "response_contains_any": ["import", "def ", "class "],
            "min_response_words": 10,
            "max_tools": 3,
        }
        result = evaluate_task(
            "dosya oku",
            "Bu modül şunları içerir: import os, import sys. "
            "Toplam 3 fonksiyon tanımlanmış.",
            tools_used=1,
            recipe_criteria=criteria,
        )
        assert result["score"] >= 60
        assert any("kriteri karşılandı" in r for r in result["reasons"])

    def test_criteria_not_met(self):
        from core.auto_eval import evaluate_task

        criteria = {
            "response_contains_any": ["import", "def ", "class "],
            "min_response_words": 50,
        }
        result = evaluate_task(
            "dosya oku",
            "Merhaba dünya!",
            recipe_criteria=criteria,
        )
        assert any("karşılanmadı" in r for r in result["reasons"])

    def test_criteria_max_tools(self):
        from core.auto_eval import evaluate_task

        criteria = {"max_tools": 2}
        result = evaluate_task(
            "görev yap",
            "Sonuç başarılı bir şekilde tamamlandı. "
            "Tüm dosyalar kontrol edildi ve düzenlendi.",
            tools_used=5,
            recipe_criteria=criteria,
        )
        assert any("max" in r.lower() for r in result["reasons"])


class TestEvalScoreBounds:
    """Score should always be in [0, 100]."""

    def test_score_not_negative(self):
        from core.auto_eval import evaluate_task

        # Stack many negatives
        result = evaluate_task(
            "çok uzun bir görev açıklaması burada yazıyor detaylı",
            "Merhaba! Erişemiyorum. Yapamıyorum. Bulamıyorum.",
        )
        assert result["score"] >= 0

    def test_score_not_over_100(self):
        from core.auto_eval import evaluate_task

        # Stack many positives
        result = evaluate_task(
            "dosya oku ve bul",
            "| Dosya | Boyut |\n|---|---|\n"
            "```python\nimport os\ndef test():\n    pass\n```\n"
            "Dosya yolu: /home/user/test.py bulundu.",
            task_type="fastpath",
            tools_used=1,
        )
        assert result["score"] <= 100
