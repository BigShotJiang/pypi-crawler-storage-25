# tests/test_commands_and_teach.py
"""Tests for Intent Gate v2, Teach Handler, Stopword Guard, and OS Browser rewrite.

4 test classes, ~23 tests. No LLM calls, no tool calls.
"""

import sys
import os
import pytest
from unittest.mock import MagicMock, patch, call

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.intent_gate import detect_intent, handle_write_intent, handle_read_intent
from core.runtime import _is_stopword_only_query, _sanitize_tool_args


# ============================================================
# 1. TestIntentGate — unit tests, 0 tool, 0 LLM
# ============================================================

class TestIntentGate:
    """detect_intent() score-based WRITE/READ/COMMAND/PASS."""

    def test_write_with_colon(self):
        """'hatırla: X = Y' → intent=write"""
        result = detect_intent("hatırla: X = Y")
        assert result.intent == "write"
        assert "X = Y" in result.payload

    def test_write_with_assignment(self):
        """'hafızana yaz: indirilenler = /mnt/c/...' → write"""
        result = detect_intent("hafızana yaz: indirilenler = /mnt/c/Users/Downloads")
        assert result.intent == "write"
        assert "indirilenler" in result.payload

    def test_context_not_write(self):
        """'hatırla şöyle konuşmuştuk' — no assignment, should NOT be write.
        Score: 'hatırla' prefix needs colon to get +3. Without colon, no strong trigger."""
        result = detect_intent("ne hatırlıyorsun bu konuda")
        assert result.intent != "write"

    def test_read_intent(self):
        """'hafızanı yokla' → intent=read"""
        result = detect_intent("hafızanı yokla")
        assert result.intent == "read"

    def test_read_hatirliyormusun(self):
        """'hatırlıyor musun X' → intent=read"""
        result = detect_intent("hatırlıyor musun indirilenler klasörünü")
        assert result.intent == "read"

    def test_command_kotu(self):
        """/kötü → intent=command"""
        result = detect_intent("/kötü")
        assert result.intent == "command"

    def test_command_not(self):
        """/not mesaj → intent=command"""
        result = detect_intent("/not bu bir not")
        assert result.intent == "command"

    def test_pass_through(self):
        """'indirilenler klasörünü aç' → intent=pass (no teach markers)"""
        result = detect_intent("indirilenler klasörünü aç")
        assert result.intent == "pass"

    def test_empty_input(self):
        """Empty → pass"""
        result = detect_intent("")
        assert result.intent == "pass"

    def test_question_blocks_write(self):
        """'ne demek indirilenler?' — question penalty should block write"""
        result = detect_intent("ne demek indirilenler?")
        assert result.intent != "write"


# ============================================================
# 2. TestTeachHandler — flow tests
# ============================================================

class TestTeachHandler:
    """handle_write_intent() and handle_read_intent() flow tests."""

    def test_teach_simple_assignment(self):
        """'indirilenler = /path' → memory_remember called with importance=1.0, source='user_teach'"""
        mock_write = MagicMock()
        mock_print = MagicMock()

        result = handle_write_intent(
            "indirilenler = /mnt/c/Users/Downloads",
            memory_write_fn=mock_write,
            console_print_fn=mock_print,
        )

        assert result is not None
        assert "indirilenler" in result
        mock_write.assert_called_once()
        call_kwargs = mock_write.call_args
        assert call_kwargs[1]["source"] == "user_teach"
        assert call_kwargs[1]["importance"] == 1.0
        assert call_kwargs[1]["memory_type"] == "fact"

    def test_teach_natural_language(self):
        """'indirilenler dediğimde /path kastediyorum' → parsed correctly"""
        mock_write = MagicMock()
        mock_print = MagicMock()

        result = handle_write_intent(
            "indirilenler dediğimde /mnt/c/Users/Downloads kastediyorum",
            memory_write_fn=mock_write,
            console_print_fn=mock_print,
        )

        assert result is not None
        mock_write.assert_called_once()
        content = mock_write.call_args[1]["content"]
        assert "indirilenler" in content
        assert "/mnt/c/Users/Downloads" in content

    def test_teach_no_fastpath_hijack(self):
        """'hatırla: indirilenler = ...' → fastpath returns None (intent gate blocks)"""
        from core.intent_gate import detect_intent
        intent = detect_intent("hatırla: indirilenler = /mnt/c/Users/Downloads")
        assert intent.intent == "write"
        # SystemExecutor.try_execute should return None for write intents
        # (tested via the gate check in system_executor.py)

    def test_teach_format_suggestion(self):
        """Unparseable text → no memory write, format suggestion returned"""
        mock_write = MagicMock()
        mock_print = MagicMock()

        result = handle_write_intent(
            "bu bir şey ama parse edilemez",
            memory_write_fn=mock_write,
            console_print_fn=mock_print,
        )

        assert result is not None
        assert "format" in result.lower() or "hatırla" in result.lower()
        mock_write.assert_not_called()

    def test_teach_empty_payload(self):
        """Empty payload → format suggestion"""
        mock_write = MagicMock()
        mock_print = MagicMock()

        result = handle_write_intent(
            "",
            memory_write_fn=mock_write,
            console_print_fn=mock_print,
        )

        assert result is not None
        mock_write.assert_not_called()

    def test_read_with_results(self):
        """Mock memory search with results → results displayed"""
        mock_search = MagicMock(return_value=[
            {"content": "indirilenler = /mnt/c/Users/Downloads", "importance": 1.0, "source": "user_teach"},
        ])
        mock_print = MagicMock()

        result = handle_read_intent(
            "indirilenler",
            memory_search_fn=mock_search,
            console_print_fn=mock_print,
        )

        assert result is not None
        assert "indirilenler" in result
        assert "[HIGH]" in result
        mock_search.assert_called_once()

    def test_read_empty(self):
        """No memory results → suggestion displayed"""
        mock_search = MagicMock(return_value=[])
        mock_print = MagicMock()

        result = handle_read_intent(
            "bilinmeyen_anahtar",
            memory_search_fn=mock_search,
            console_print_fn=mock_print,
        )

        assert result is not None
        assert "bulamadım" in result or "öğretebilirsin" in result


# ============================================================
# 3. TestStopwordGuard — unit tests
# ============================================================

class TestStopwordGuard:
    """_is_stopword_only_query() and _sanitize_tool_args() stopword blocking."""

    def test_single_stopword_blocked(self):
        """query='ve' → blocked"""
        assert _is_stopword_only_query("ve") is True

    def test_multi_stopword_blocked(self):
        """query='ve de' → blocked"""
        assert _is_stopword_only_query("ve de") is True

    def test_meaningful_query_passes(self):
        """query='bddk kanunu' → passes"""
        assert _is_stopword_only_query("bddk kanunu") is False

    def test_short_char_blocked(self):
        """query='a' → blocked (len<=1)"""
        assert _is_stopword_only_query("a") is True

    def test_sanitize_stopword_skip(self):
        """_sanitize_tool_args blocks stopword-only query"""
        args = {"query": "ve"}
        cooldown = set()
        _, should_skip, reason = _sanitize_tool_args(
            args, "bul ve listele", "web_search", cooldown
        )
        assert should_skip is True
        assert "stopword" in reason.lower() or "anlamsız" in reason.lower()


# ============================================================
# 4. TestOsBrowserRewrite — unit tests
# ============================================================

class TestOsBrowserRewrite:
    """browser_open → open_in_browser rewrite logic tests.

    Tests the rewrite logic directly since the actual rewrite is inline in run_task.
    We test the decision logic pattern here.
    """

    @staticmethod
    def _should_rewrite(fn_name: str, raw_input: str) -> str:
        """Simulate the rewrite logic from runtime.py."""
        if fn_name == "browser_open" and raw_input:
            _input_lower = raw_input.lower()
            _open_verbs = {"aç", "açın", "git", "gidin", "göster"}
            _headless_verbs = {"ara", "bul", "analiz", "tara", "scrape", "tıkla"}
            _input_words = set(_input_lower.split())
            _has_open = bool(_input_words & _open_verbs)
            _has_headless = bool(_input_words & _headless_verbs)
            if _has_open and not _has_headless:
                return "open_in_browser"
        return fn_name

    def test_ac_rewrite(self):
        """fn='browser_open' + 'sitesini aç' → 'open_in_browser'"""
        result = self._should_rewrite("browser_open", "google sitesini aç")
        assert result == "open_in_browser"

    def test_ara_no_rewrite(self):
        """fn='browser_open' + 'sitesinde ara' → NOT rewritten"""
        result = self._should_rewrite("browser_open", "google sitesinde ara")
        assert result == "browser_open"

    def test_both_verbs_no_rewrite(self):
        """fn='browser_open' + 'sitesini aç ve ara' → NOT rewritten (headless verb present)"""
        result = self._should_rewrite("browser_open", "sitesini aç ve ara")
        assert result == "browser_open"

    def test_other_tool_no_rewrite(self):
        """fn='list_dir' → no rewrite regardless of input"""
        result = self._should_rewrite("list_dir", "sitesini aç")
        assert result == "list_dir"

    def test_git_rewrite(self):
        """fn='browser_open' + 'git' verb → rewrite (git = go)"""
        result = self._should_rewrite("browser_open", "google.com'a git")
        assert result == "open_in_browser"


# ============================================================
# 5. TestMemoryGateHighSource — _is_high() user_teach
# ============================================================

class TestMemoryGateHighSource:
    """_is_high() recognizes source='user_teach'."""

    def test_user_teach_is_high(self):
        from core.memory_gate import _is_high
        mem = {"source": "user_teach", "importance": 1.0, "type": "fact"}
        assert _is_high(mem) is True

    def test_user_teach_even_low_importance(self):
        from core.memory_gate import _is_high
        mem = {"source": "user_teach", "importance": 0.3, "type": "fact"}
        assert _is_high(mem) is True

    def test_regular_low_not_high(self):
        from core.memory_gate import _is_high
        mem = {"source": "agent", "importance": 0.3, "type": "fact"}
        assert _is_high(mem) is False


# ============================================================
# 6. TestRunLoggerEvent — log_event method exists
# ============================================================

class TestRunLoggerEvent:
    """RunLogger.log_event() must exist for memory_gate structured logging."""

    def test_log_event_exists(self):
        import tempfile
        from pathlib import Path
        from core.run_logger import RunLogger
        logger = RunLogger("test", Path(tempfile.mkdtemp()))
        logger.log_event("memory_gate_fired", {"action": "open_url", "target": "https://x.com"})
        assert len(logger.events) == 1
        assert logger.events[0]["type"] == "memory_gate_fired"

    def test_log_event_skipped(self):
        import tempfile
        from pathlib import Path
        from core.run_logger import RunLogger
        logger = RunLogger("test", Path(tempfile.mkdtemp()))
        logger.log_event("memory_gate_skipped", {
            "high_count": 0, "action": "open", "content_words": ["mevzuat"],
        })
        assert logger.events[0]["type"] == "memory_gate_skipped"
