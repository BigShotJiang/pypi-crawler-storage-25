"""
Tests for core/memory_eviction.py — memory eviction rules.
Run: pytest tests/test_eviction.py -v
"""
import sqlite3
import tempfile
import os
from datetime import datetime, timedelta

import pytest


def _make_db():
    """Create an in-memory DB with semantic_memory table."""
    conn = sqlite3.connect(":memory:")
    conn.execute("""
        CREATE TABLE semantic_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT,
            memory_type TEXT DEFAULT 'general',
            tags TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            created_at TEXT,
            updated_at TEXT,
            embedding BLOB
        )
    """)
    conn.commit()
    return conn


def _insert(conn, content, created_at=None, importance=0.5):
    """Insert a memory row."""
    if created_at is None:
        created_at = datetime.now().isoformat()
    conn.execute(
        "INSERT INTO semantic_memory (content, importance, created_at) VALUES (?, ?, ?)",
        (content, importance, created_at),
    )
    conn.commit()


class TestEvictionNegativeMemories:
    """Rule 1: Negative/failure memories older than 7 days should be deleted."""

    def test_deletes_old_negative(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(days=10)).isoformat()
        _insert(conn, "başarısız oldu, hata verdi", created_at=old_ts)
        _insert(conn, "bu dosya bulunamadı", created_at=old_ts)
        _insert(conn, "normal bir hafıza", created_at=old_ts)

        evicted = run_eviction(conn)

        # 2 negative deleted + 1 normal (low importance >30d? no, only 10d)
        # Normal one is not negative, not old enough for rule 3
        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 1  # only the normal one stays
        assert evicted >= 2

    def test_keeps_recent_negative(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        recent_ts = (datetime.now() - timedelta(days=2)).isoformat()
        _insert(conn, "hata verdi ama yeni", created_at=recent_ts)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 1  # recent negative stays
        assert evicted == 0

    def test_turkish_noise_patterns(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(days=10)).isoformat()
        _insert(conn, "memnun değil kullanıcı", created_at=old_ts)
        _insert(conn, "timeout bekleniyor", created_at=old_ts)
        _insert(conn, "erişemiyorum dosyaya", created_at=old_ts)
        _insert(conn, "yapamıyorum bunu", created_at=old_ts)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 0
        assert evicted == 4


class TestEvictionDedup:
    """Rule 2: Duplicate content — keep newest, delete rest."""

    def test_dedup_keeps_newest(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(hours=5)).isoformat()
        new_ts = datetime.now().isoformat()
        _insert(conn, "aynı içerik", created_at=old_ts)
        _insert(conn, "aynı içerik", created_at=new_ts)
        _insert(conn, "aynı içerik", created_at=old_ts)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 1
        # The newest one should survive
        row = conn.execute("SELECT created_at FROM semantic_memory").fetchone()
        assert row[0] == new_ts
        assert evicted == 2

    def test_no_dedup_for_unique_content(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        ts = datetime.now().isoformat()
        _insert(conn, "birinci içerik", created_at=ts)
        _insert(conn, "ikinci içerik", created_at=ts)
        _insert(conn, "üçüncü içerik", created_at=ts)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 3
        assert evicted == 0


class TestEvictionLowImportance:
    """Rule 3: Low importance + old (>30 days) = delete."""

    def test_deletes_old_low_importance(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(days=35)).isoformat()
        _insert(conn, "eski düşük önemli", created_at=old_ts, importance=0.1)
        _insert(conn, "eski yüksek önemli", created_at=old_ts, importance=0.8)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 1  # high importance stays

    def test_keeps_recent_low_importance(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        recent_ts = (datetime.now() - timedelta(days=5)).isoformat()
        _insert(conn, "yeni düşük önemli", created_at=recent_ts, importance=0.1)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 1  # recent stays even with low importance


class TestEvictionCap:
    """Rule 4: Cap total memories at MAX_MEMORIES."""

    def test_cap_excess_deleted(self):
        from core.memory_eviction import run_eviction, MAX_MEMORIES

        conn = _make_db()
        ts = datetime.now().isoformat()
        # Insert MAX_MEMORIES + 5 records
        for i in range(MAX_MEMORIES + 5):
            _insert(conn, f"memory_{i}", created_at=ts, importance=i / (MAX_MEMORIES + 5))

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == MAX_MEMORIES
        assert evicted >= 5

    def test_no_cap_under_limit(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        ts = datetime.now().isoformat()
        for i in range(10):
            _insert(conn, f"memory_{i}", created_at=ts)

        evicted = run_eviction(conn)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 10
        assert evicted == 0


class TestEvictOnStartup:
    """evict_on_startup wrapper should handle errors gracefully."""

    def test_startup_eviction_runs(self):
        from core.memory_eviction import evict_on_startup

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(days=10)).isoformat()
        conn.execute(
            "INSERT INTO semantic_memory (content, importance, created_at) VALUES (?, ?, ?)",
            ("hata oluştu", 0.5, old_ts),
        )
        conn.commit()

        # evict_on_startup takes a callable that returns a connection
        evicted = evict_on_startup(lambda: conn)
        assert evicted >= 1

    def test_startup_eviction_handles_error(self):
        from core.memory_eviction import evict_on_startup

        def bad_connect():
            raise RuntimeError("DB unavailable")

        evicted = evict_on_startup(bad_connect)
        assert evicted == 0  # graceful failure


class TestDryRun:
    """dry_run=True should not delete anything."""

    def test_dry_run_no_delete(self):
        from core.memory_eviction import run_eviction

        conn = _make_db()
        old_ts = (datetime.now() - timedelta(days=10)).isoformat()
        _insert(conn, "başarısız deneme", created_at=old_ts)
        _insert(conn, "başarısız deneme", created_at=old_ts)  # dup + negative

        evicted = run_eviction(conn, dry_run=True)

        remaining = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
        assert remaining == 2  # nothing deleted
        assert evicted == 0
