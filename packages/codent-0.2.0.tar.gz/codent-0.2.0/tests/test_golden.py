"""
Golden regression tests — deterministic safety net for refactoring.

RULES:
  - Only import from core/ modules, NEVER from cont.py.
  - Each test must be deterministic (no LLM, no network, no disk state).
  - If ANY golden test fails after a refactoring step, REVERT that step.

Run: pytest tests/test_golden.py -v
"""

import os
import sys
import json
import sqlite3
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


# ═══════════════════════════════════════════════════════════════
# 1. Types — Contracts survive refactoring
# ═══════════════════════════════════════════════════════════════

class TestTypesContracts:
    """core/types.py dataclasses and enums are stable."""

    def test_route_decision_enum_values(self):
        from core.types import RouteDecision
        assert RouteDecision.FASTPATH.value == "fastpath"
        assert RouteDecision.RECIPE.value == "recipe"
        assert RouteDecision.LLM.value == "llm"
        assert RouteDecision.BROWSER_AGENT.value == "browser_agent"

    def test_route_decision_count(self):
        from core.types import RouteDecision
        assert len(RouteDecision) >= 4

    def test_task_route_defaults(self):
        from core.types import TaskRoute, RouteDecision
        route = TaskRoute(decision=RouteDecision.LLM)
        assert route.recipe_id is None
        assert route.recipe is None
        assert route.intent is None
        assert route.url is None
        assert route.confidence == 0.0

    def test_task_route_with_recipe(self):
        from core.types import TaskRoute, RouteDecision
        route = TaskRoute(
            decision=RouteDecision.RECIPE,
            recipe_id="test_recipe_v1",
            recipe={"steps": []},
            confidence=0.9,
        )
        assert route.decision == RouteDecision.RECIPE
        assert route.recipe_id == "test_recipe_v1"

    def test_task_route_with_browser(self):
        from core.types import TaskRoute, RouteDecision
        route = TaskRoute(
            decision=RouteDecision.BROWSER_AGENT,
            url="https://example.com",
        )
        assert route.url == "https://example.com"

    def test_tool_result_fields(self):
        from core.types import ToolResult
        tr = ToolResult(tool_name="read_file", args={"path": "/tmp/a.txt"},
                        result="content", success=True)
        assert tr.tool_name == "read_file"
        assert tr.success is True
        assert tr.timestamp == 0.0

    def test_episode_record_defaults(self):
        from core.types import EpisodeRecord
        ep = EpisodeRecord(task_input="hello")
        assert ep.task_type == "llm"
        assert ep.success == -1  # -1 = unknown, NOT None
        assert ep.tools_used == 0
        assert ep.tool_names == []
        assert ep.auto_eval is None

    def test_auto_eval_result(self):
        from core.types import AutoEvalResult
        ae = AutoEvalResult(success=True, confidence=0.95,
                            reasons=["tool ok"], score=80)
        assert ae.success is True
        assert ae.score == 80

    def test_auto_eval_result_defaults(self):
        from core.types import AutoEvalResult
        ae = AutoEvalResult(success=None, confidence=0.5)
        assert ae.reasons == []
        assert ae.score == 50


# ═══════════════════════════════════════════════════════════════
# 2. Formatters — Message templates are stable
# ═══════════════════════════════════════════════════════════════

class TestFormattersGolden:
    """core/formatters.py output strings are deterministic."""

    def test_tool_blocked_msg_contains_tool_name(self):
        from core.formatters import tool_blocked_msg
        msg = tool_blocked_msg("web_search")
        assert "web_search" in msg
        assert "BLOCKED" in msg

    def test_budget_exhausted_msg_has_finalize(self):
        from core.formatters import budget_exhausted_msg, FINALIZE_MARKER
        msg = budget_exhausted_msg("9/12 A1", 9)
        assert FINALIZE_MARKER in msg
        assert "9" in msg

    def test_greeting_detection_turkish(self):
        from core.formatters import is_greeting_response
        assert is_greeting_response("Merhaba! Size nasıl yardımcı olabilirim?")

    def test_greeting_detection_negative(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("KOSGEB yönetmeliği...")

    def test_greeting_detection_empty(self):
        from core.formatters import is_greeting_response
        assert not is_greeting_response("")
        assert not is_greeting_response("   ")

    def test_finalize_marker_constant(self):
        from core.formatters import FINALIZE_MARKER
        assert FINALIZE_MARKER == "FINALIZE NOW"

    def test_leak_markers_non_empty(self):
        from core.formatters import LEAK_MARKERS
        assert len(LEAK_MARKERS) > 10

    def test_leak_markers_contains_finalize(self):
        from core.formatters import LEAK_MARKERS, FINALIZE_MARKER
        assert FINALIZE_MARKER in LEAK_MARKERS

    def test_bare_system_prompt_renders(self):
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp/repo", 12)
        assert "/tmp/repo" in prompt
        assert "12" in prompt
        assert "list_dir" in prompt
        assert "read_file" in prompt

    def test_bare_system_prompt_has_rules(self):
        from core.formatters import build_bare_system_prompt
        prompt = build_bare_system_prompt("/tmp", 10)
        assert "EVIDENCE REQUIRED" in prompt
        assert "WRITE PROTECTION" in prompt

    def test_tool_limit_reached_msg(self):
        from core.formatters import tool_limit_reached_msg
        msg = tool_limit_reached_msg("web_search", 3, "web_fetch, browser_open")
        assert "web_search" in msg
        assert "3" in msg
        assert "ZORUNLU" in msg

    def test_budget_nearly_exhausted_msg(self):
        from core.formatters import budget_nearly_exhausted_msg
        msg = budget_nearly_exhausted_msg("11/12 A1")
        assert "1 tool" in msg

    def test_empty_response_msg(self):
        from core.formatters import empty_response_msg
        msg = empty_response_msg()
        assert "empty response" in msg.lower()

    def test_task_reminder_msg_truncation(self):
        from core.formatters import task_reminder_msg
        long_input = "a" * 500
        msg = task_reminder_msg(long_input)
        assert "a" * 200 in msg
        assert "a" * 201 not in msg


# ═══════════════════════════════════════════════════════════════
# 3. Tool Budget — Duplicate blocking and phase logic
# ═══════════════════════════════════════════════════════════════

class TestToolBudgetGolden:
    """core/tool_budget.py budget enforcement is deterministic."""

    def test_first_call_allowed(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=12)
        allowed, _ = budget.can_call("read_file", {"path": "/tmp/a.txt"})
        assert allowed

    def test_duplicate_blocked(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=12)
        budget.can_call("read_file", {"path": "/tmp/a.txt"})
        allowed, msg = budget.can_call("read_file", {"path": "/tmp/a.txt"})
        assert not allowed
        assert "Blocked" in msg

    def test_different_args_not_blocked(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=12)
        budget.can_call("read_file", {"path": "/tmp/a.txt"})
        allowed, _ = budget.can_call("read_file", {"path": "/tmp/b.txt"})
        assert allowed

    def test_phase_exhaustion_starts_new(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=2)
        budget.can_call("read_file", {"path": "/tmp/1.txt"})
        budget.can_call("read_file", {"path": "/tmp/2.txt"})
        # Phase 1 exhausted, phase 2 should auto-start
        allowed, _ = budget.can_call("read_file", {"path": "/tmp/3.txt"})
        assert allowed
        assert budget.current_phase == 2

    def test_max_phases_blocks(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=1)
        # Exhaust all 4 phases (1 call each)
        for i in range(4):
            budget.can_call("read_file", {"path": f"/tmp/{i}.txt"})
        # Phase 5 should be denied
        allowed, msg = budget.can_call("read_file", {"path": "/tmp/99.txt"})
        assert not allowed
        assert "tükendi" in msg

    def test_free_tool_quota(self):
        from core.tool_budget import DynamicToolBudget, FREE_TOOL_QUOTAS
        budget = DynamicToolBudget(budget_per_phase=1)
        # recall has 3 free calls
        for i in range(FREE_TOOL_QUOTAS["recall"]):
            allowed, _ = budget.can_call("recall", {"query": f"test{i}"})
            assert allowed
        # Budget should still be at phase_calls=0 (free calls don't consume budget)
        assert budget.phase_calls == 0

    def test_path_normalization_relative_vs_absolute(self):
        from core.tool_budget import DynamicToolBudget
        cwd = "/home/user/project"
        budget = DynamicToolBudget(budget_per_phase=12, cwd=cwd)
        # Use read_file (not in FIRST_CALL_FREE) to test path normalization
        budget.can_call("read_file", {"path": "src/main.py"})
        # Same path via absolute — should be blocked as duplicate
        allowed, msg = budget.can_call("read_file", {"path": "/home/user/project/src/main.py"})
        assert not allowed, "Relative and absolute paths to same dir should be deduplicated"

    def test_display_format(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=12)
        assert budget.get_display() == "0/12 A1"
        budget.can_call("read_file", {"path": "/tmp/1.txt"})
        assert budget.get_display() == "1/12 A1"

    def test_absolute_cap(self):
        from core.tool_budget import DynamicToolBudget
        budget = DynamicToolBudget(budget_per_phase=100)
        budget.total_calls = 60  # At absolute cap
        allowed, msg = budget.can_call("read_file", {"path": "/tmp/x.txt"})
        assert not allowed
        assert "Mutlak" in msg


# ═══════════════════════════════════════════════════════════════
# 4. Tools — Normalization and safety helpers
# ═══════════════════════════════════════════════════════════════

class TestToolsGolden:
    """core/tools.py normalization and safety are deterministic."""

    def test_normalize_alias_to_canonical(self):
        from core.tools import normalize_tool_call
        name, args = normalize_tool_call("shell", {"command": "ls"})
        assert name == "run_shell"

    def test_normalize_browser_alias(self):
        from core.tools import normalize_tool_call
        name, _ = normalize_tool_call("browse", {})
        assert name == "browser_open"

    def test_normalize_passthrough(self):
        from core.tools import normalize_tool_call
        name, args = normalize_tool_call("read_file", {"path": "/tmp/a.txt"})
        assert name == "read_file"
        assert args["path"] == "/tmp/a.txt"

    def test_per_tool_caps_structure(self):
        from core.tools import PER_TOOL_CAPS
        assert isinstance(PER_TOOL_CAPS, dict)
        assert "web_search" in PER_TOOL_CAPS
        assert "list_dir" in PER_TOOL_CAPS
        assert all(isinstance(v, int) for v in PER_TOOL_CAPS.values())

    def test_shell_timeout_find_root(self):
        from core.tools import _shell_timeout
        assert _shell_timeout("find / -name foo") <= 15

    def test_shell_timeout_normal(self):
        from core.tools import _shell_timeout
        assert _shell_timeout("ls -la") <= 30

    def test_shell_timeout_network(self):
        from core.tools import _shell_timeout
        timeout = _shell_timeout("curl https://example.com")
        assert timeout >= 30

    def test_dangerous_patterns_non_empty(self):
        from core.tools import DANGEROUS_PATTERNS
        assert len(DANGEROUS_PATTERNS) > 0

    def test_block_dangerous_rm_rf(self):
        import pytest
        from core.tools import block_dangerous
        with pytest.raises(ValueError, match="Dangerous"):
            block_dangerous("rm -rf /")

    def test_block_dangerous_safe_cmd(self):
        from core.tools import block_dangerous
        # Safe commands return None (no exception)
        assert block_dangerous("ls -la") is None

    def test_is_step_safe_blocks_rm(self):
        from core.tools import is_step_safe
        safe, reason = is_step_safe("rm -rf /tmp/*")
        assert safe is False
        assert reason is not None

    def test_is_step_safe_allows_read(self):
        from core.tools import is_step_safe
        safe, reason = is_step_safe("cat /tmp/test.txt")
        assert safe is True
        assert reason is None

    def test_search_exclude_dirs(self):
        from core.tools import _SEARCH_EXCLUDE_DIRS
        assert ".git" in _SEARCH_EXCLUDE_DIRS
        assert "node_modules" in _SEARCH_EXCLUDE_DIRS


# ═══════════════════════════════════════════════════════════════
# 5. Episodic Memory — CRUD and triage
# ═══════════════════════════════════════════════════════════════

class TestEpisodicGolden:
    """core/episodic.py episode storage is deterministic."""

    def _make_db(self):
        """Create in-memory episode DB."""
        from core.episodic import init_episodic_db
        conn = sqlite3.connect(":memory:")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_input TEXT NOT NULL,
                task_type TEXT,
                method TEXT,
                tools_used INTEGER DEFAULT 0,
                tool_names TEXT,
                duration_ms INTEGER,
                success INTEGER DEFAULT -1,
                auto_eval TEXT,
                user_feedback TEXT,
                response_preview TEXT,
                error TEXT,
                recipe_id TEXT,
                fastpath_intent TEXT,
                created_at REAL NOT NULL
            )
        """)
        return conn

    def test_record_episode_returns_id(self):
        from core.episodic import record_episode
        conn = self._make_db()
        eid = record_episode(conn, "test task")
        assert isinstance(eid, int)
        assert eid >= 1

    def test_record_episode_stores_data(self):
        from core.episodic import record_episode
        conn = self._make_db()
        record_episode(conn, "hello world", task_type="fastpath",
                       tools_used=3, success=1)
        row = conn.execute(
            "SELECT task_input, task_type, tools_used, success FROM episodes WHERE id=1"
        ).fetchone()
        assert row == ("hello world", "fastpath", 3, 1)

    def test_update_feedback_positive(self):
        from core.episodic import record_episode, update_feedback
        conn = self._make_db()
        eid = record_episode(conn, "test")
        update_feedback(conn, eid, "iyi")
        row = conn.execute(
            "SELECT success, user_feedback FROM episodes WHERE id=?", (eid,)
        ).fetchone()
        assert row == (1, "iyi")

    def test_update_feedback_negative(self):
        from core.episodic import record_episode, update_feedback
        conn = self._make_db()
        eid = record_episode(conn, "test")
        update_feedback(conn, eid, "kotu")
        row = conn.execute(
            "SELECT success FROM episodes WHERE id=?", (eid,)
        ).fetchone()
        assert row[0] == 0

    def test_get_similar_episodes(self):
        from core.episodic import record_episode, get_similar_episodes
        conn = self._make_db()
        record_episode(conn, "KOSGEB yönetmelik arama")
        record_episode(conn, "dosya listele")
        results = get_similar_episodes(conn, "yönetmelik bul")
        assert len(results) >= 1
        assert "yönetmelik" in results[0]["task_input"].lower()

    def test_root_causes_keys(self):
        from core.episodic import _ROOT_CAUSES
        expected = {"wasteful_tools", "blocked_calls", "tool_loop",
                    "incomplete", "task_failed", "tool_error"}
        assert set(_ROOT_CAUSES.keys()) == expected

    def test_root_cause_structure(self):
        from core.episodic import _ROOT_CAUSES
        for key, info in _ROOT_CAUSES.items():
            assert "cause" in info, f"Missing 'cause' in {key}"
            assert "fix" in info, f"Missing 'fix' in {key}"
            assert "file" in info, f"Missing 'file' in {key}"

    def test_triage_skip_errors(self):
        from core.episodic import _TRIAGE_SKIP_ERRORS
        assert "budget_blocked" not in _TRIAGE_SKIP_ERRORS
        assert "prefetch_cache_hit" in _TRIAGE_SKIP_ERRORS

    def test_triage_missing_dir(self):
        from core.episodic import run_triage
        result = run_triage(n=10, log_dir="/nonexistent/dir")
        assert "bulunamadı" in result

    def test_triage_empty_dir(self):
        from core.episodic import run_triage
        with tempfile.TemporaryDirectory() as td:
            result = run_triage(n=10, log_dir=td)
            assert "log" in result.lower()

    def test_triage_parses_log(self):
        from core.episodic import run_triage
        with tempfile.TemporaryDirectory() as td:
            # Create a minimal log file
            log_file = Path(td) / "20260218_010000_test_task.jsonl"
            lines = [
                json.dumps({"type": "tool_call", "data": {"name": "read_file"}}),
                json.dumps({"type": "tool_result", "data": {"error": ""}}),
                json.dumps({"type": "final", "data": {"success": True}}),
            ]
            log_file.write_text("\n".join(lines))
            result = run_triage(n=10, log_dir=td)
            assert "TRIAGE" in result
            assert "1" in result  # 1 run scanned


# ═══════════════════════════════════════════════════════════════
# 6. System Executor — Pure command routing
# ═══════════════════════════════════════════════════════════════

class TestSystemExecutorGolden:
    """core/system_executor.py command dispatch is deterministic."""

    def test_executor_instantiation(self):
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        assert se.memory_fn is None

    def test_executor_with_memory_fn(self):
        from core.system_executor import SystemExecutor
        se = SystemExecutor(memory_fn=lambda q: [])
        assert se.memory_fn is not None

    def test_try_execute_empty_returns_none(self):
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        result = se.try_execute("")
        assert result is None

    def test_try_execute_whitespace_returns_none(self):
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        result = se.try_execute("   ")
        assert result is None

    def test_try_execute_hello_returns_none(self):
        """Non-command input returns None (falls through to LLM)."""
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        result = se.try_execute("KOSGEB destekleri nelerdir?")
        assert result is None

    def test_try_execute_recipe_none_on_no_recipe(self):
        from core.system_executor import SystemExecutor
        se = SystemExecutor()
        result = se.try_execute_recipe("test", {})
        assert result is None


# ═══════════════════════════════════════════════════════════════
# 7. CLI Parser — Argument structure is stable
# ═══════════════════════════════════════════════════════════════

class TestCLIParserGolden:
    """core/cli.py parser flags are stable."""

    def test_parser_builds(self):
        from core.cli import build_parser
        parser = build_parser()
        assert parser is not None

    def test_task_positional(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["hello", "world"])
        assert ns.task == ["hello", "world"]

    def test_model_flag(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--model", "qwen2.5"])
        assert ns.model == "qwen2.5"

    def test_debug_flag(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--debug"])
        assert ns.debug is True

    def test_triage_flag_default(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--triage"])
        assert ns.triage == 50

    def test_triage_flag_custom(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--triage", "100"])
        assert ns.triage == 100

    def test_memory_flags(self):
        from core.cli import build_parser
        parser = build_parser()
        # Ensure memory CLI flags parse
        ns = parser.parse_args(["--memory-stats"])
        assert ns.memory_stats is True

    def test_doctor_flag(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--doctor"])
        assert ns.doctor is True

    def test_list_models_flag(self):
        from core.cli import build_parser
        parser = build_parser()
        ns = parser.parse_args(["--list-models"])
        assert ns.list_models is True


# ═══════════════════════════════════════════════════════════════
# 8. Integration — Cross-module consistency
# ═══════════════════════════════════════════════════════════════

class TestCrossModuleGolden:
    """Cross-module contracts are consistent."""

    def test_episode_record_matches_db_schema(self):
        """EpisodeRecord fields match what record_episode() stores."""
        from core.types import EpisodeRecord
        from core.episodic import EPISODIC_TABLE_SQL
        ep = EpisodeRecord(task_input="test")
        # These DB columns must exist for all EpisodeRecord fields
        for field_name in ['task_input', 'task_type', 'method', 'tools_used',
                           'tool_names', 'duration_ms', 'success', 'auto_eval',
                           'response_preview', 'error', 'recipe_id',
                           'fastpath_intent']:
            assert field_name in EPISODIC_TABLE_SQL, \
                f"EpisodeRecord.{field_name} missing from EPISODIC_TABLE_SQL"

    def test_route_decision_values_are_strings(self):
        """RouteDecision values are plain strings (for JSON serialization)."""
        from core.types import RouteDecision
        for rd in RouteDecision:
            assert isinstance(rd.value, str)
            assert rd.value == rd.value.lower()

    def test_tool_budget_and_tools_caps_agree(self):
        """PER_TOOL_CAPS tools are valid tool names."""
        from core.tools import PER_TOOL_CAPS, _TOOL_NAME_ALIASES
        # All capped tools should NOT be aliases — they should be canonical names
        for tool_name in PER_TOOL_CAPS:
            assert tool_name not in _TOOL_NAME_ALIASES, \
                f"PER_TOOL_CAPS key '{tool_name}' is an alias, not canonical"

    def test_formatters_no_core_imports(self):
        """formatters.py must not import business logic modules."""
        import re
        import inspect
        import core.formatters
        source = inspect.getsource(core.formatters)
        core_imports = re.findall(r'^(?:from|import)\s+core\.', source, re.MULTILINE)
        assert core_imports == [], f"core/formatters.py imports core modules: {core_imports}"

    def test_types_no_core_imports(self):
        """types.py must not import from core/ modules."""
        import re
        import inspect
        import core.types
        source = inspect.getsource(core.types)
        core_imports = re.findall(r'^(?:from|import)\s+core\.', source, re.MULTILINE)
        assert core_imports == [], f"core/types.py imports core modules: {core_imports}"


# ═══════════════════════════════════════════════════════════════
# 9. Router — Pure routing decisions
# ═══════════════════════════════════════════════════════════════

class TestRouterGolden:
    """core/router.py route decisions are deterministic."""

    def test_extract_url_http(self):
        from core.router import extract_url
        assert extract_url("https://example.com sayfasını aç") == "https://example.com"

    def test_extract_url_domain_only(self):
        from core.router import extract_url
        url = extract_url("mevzuat.gov.tr sitesini aç")
        assert url is not None
        assert "mevzuat.gov.tr" in url

    def test_extract_url_none(self):
        from core.router import extract_url
        assert extract_url("KOSGEB destekleri nedir?") is None

    def test_extract_goal(self):
        from core.router import extract_goal
        goal = extract_goal("https://example.com sayfasını özetle")
        assert "example.com" not in goal
        assert "özetle" in goal

    def test_extract_goal_url_only(self):
        from core.router import extract_goal
        goal = extract_goal("https://example.com")
        assert len(goal) >= 3  # Falls back to default goal

    def test_extract_raw_input_plain(self):
        from core.router import extract_raw_input
        assert extract_raw_input("hello world") == "hello world"

    def test_extract_raw_input_xml_wrapped(self):
        from core.router import extract_raw_input
        wrapped = "context... <current_request> actual task </current_request>"
        assert extract_raw_input(wrapped) == "actual task"

    def test_extract_raw_input_system_hint(self):
        from core.router import extract_raw_input
        wrapped = "[SİSTEM İPUCU: something] actual question"
        result = extract_raw_input(wrapped)
        assert "actual question" in result

    def test_route_default_llm(self):
        """Without DI, route_task returns LLM."""
        from core.router import route_task, init_router
        from core.types import RouteDecision
        # Reset to bare state (no DI)
        init_router(
            fastpath_enabled=False,
            learning_enabled=False,
            escalation_enabled=False,
        )
        route = route_task("KOSGEB destekleri nedir?")
        assert route.decision == RouteDecision.LLM
        assert route.confidence == 0.5

    def test_route_fastpath(self):
        """Fastpath detected when SystemExecutor returns handled."""
        from core.router import route_task, init_router
        from core.types import RouteDecision

        class MockSE:
            def __init__(self, **kw):
                pass
            def try_execute(self, inp):
                return {"handled": True, "intent": "list_downloads", "intent_score": 7}

        init_router(
            fastpath_enabled=True,
            learning_enabled=False,
            system_executor_factory=lambda **kw: MockSE(),
        )
        route = route_task("indirilenler klasörünü listele")
        assert route.decision == RouteDecision.FASTPATH
        assert route.intent == "list_downloads"

    def test_route_browser_agent(self):
        """URL in input triggers BROWSER_AGENT."""
        from core.router import route_task, init_router
        from core.types import RouteDecision

        init_router(
            fastpath_enabled=False,
            learning_enabled=False,
        )
        route = route_task("https://mevzuat.gov.tr sayfasını aç")
        assert route.decision == RouteDecision.BROWSER_AGENT
        assert route.url is not None
        assert "mevzuat.gov.tr" in route.url

    def test_route_recipe_match(self):
        """Recipe match when match_recipe returns a recipe."""
        from core.router import route_task, init_router
        from core.types import RouteDecision

        class MockSE:
            def __init__(self, **kw):
                pass
            def try_execute(self, inp):
                return None
            def try_execute_recipe(self, inp, recipe):
                return {"handled": True, "recipe_id": "test_v1"}

        mock_recipe = {"id": "test_v1", "_score": 8, "steps": []}
        init_router(
            fastpath_enabled=True,
            learning_enabled=True,
            system_executor_factory=lambda **kw: MockSE(**kw),
            match_recipe_fn=lambda inp, conn: mock_recipe,
            init_recipe_db_fn=lambda: None,
            seed_recipes_fn=lambda conn: None,
            cleanup_junk_fn=lambda conn, **kw: None,
        )
        route = route_task("test task for recipe")
        assert route.decision == RouteDecision.RECIPE
        assert route.recipe_id == "test_v1"

    def test_route_url_regex_shared(self):
        """Router uses same URL regex pattern as cont.py used."""
        from core.router import _URL_RE
        # Must match http/https URLs
        assert _URL_RE.search("https://example.com")
        assert _URL_RE.search("http://foo.bar.baz/path")
        # Must match bare gov/com/org/net domains
        assert _URL_RE.search("mevzuat.gov.tr")
        assert _URL_RE.search("google.com.tr")
        # Must NOT match random text
        assert _URL_RE.search("hello world") is None

    def test_route_no_cont_imports(self):
        """router.py must not import from cont module."""
        import re, inspect
        import core.router
        source = inspect.getsource(core.router)
        cont_imports = re.findall(r'^(?:from|import)\s+cont\b', source, re.MULTILINE)
        assert cont_imports == [], f"core/router.py imports cont: {cont_imports}"


# ═══════════════════════════════════════════════════════════════
# 10. Runtime Helpers — Extracted from cont.py
# ═══════════════════════════════════════════════════════════════

class TestRuntimeGolden:
    """core/runtime.py helpers are deterministic."""

    def test_should_decompose_short_input(self):
        from core.runtime import should_decompose
        assert should_decompose("merhaba") is False

    def test_should_decompose_retry(self):
        from core.runtime import should_decompose
        assert should_decompose("dosyaları bul ve özetle", is_retry=True) is False

    def test_should_decompose_correction(self):
        from core.runtime import should_decompose
        assert should_decompose("değil kito demek istedim ito") is False

    def test_should_decompose_question(self):
        from core.runtime import should_decompose
        assert should_decompose("KOSGEB nedir") is False

    def test_should_decompose_long_multi_step(self):
        from core.runtime import should_decompose
        assert should_decompose(
            "önce indirilenler klasöründeki dosyaları listele sonra her birini oku ve özetini çıkar"
        ) is True

    def test_is_retry_input(self):
        from core.runtime import is_retry_input
        assert is_retry_input("tekrar dene") is True
        assert is_retry_input("evet") is True
        assert is_retry_input("KOSGEB nedir?") is False

    def test_check_hallucination_clean(self):
        from core.runtime import check_hallucination
        result = check_hallucination("Normal answer", [], [])
        assert result == "Normal answer"

    def test_check_hallucination_blocked_file(self):
        from core.runtime import check_hallucination
        answer = "```json\n{\"name\": \"test\"}\n```\nconfig.json içeriği..."
        result = check_hallucination(answer, ["/tmp/config.json"])
        assert "UYARI" in result

    def test_denial_patterns_non_empty(self):
        from core.runtime import DENIAL_PATTERNS
        assert len(DENIAL_PATTERNS) > 5

    def test_postprocess_no_denial(self):
        from core.runtime import postprocess_response
        result = postprocess_response("Normal answer", [])
        assert result == "Normal answer"

    def test_self_assess_empty_answer(self):
        from core.runtime import self_assess
        score, notes = self_assess("task", "", 0, 1000, 1)
        assert score == 1
        assert any("kısa" in n or "boş" in n for n in notes)

    def test_self_assess_good_answer(self):
        from core.runtime import self_assess
        answer = "İşte detaylı yanıt: " + "x" * 600
        score, notes = self_assess("task", answer, 2, 3000, 1)
        assert score >= 3

    def test_extract_dir_from_results_empty(self):
        from core.runtime import extract_dir_from_results
        assert extract_dir_from_results([]) == ""

    def test_sanitize_response_in_formatters(self):
        """sanitize_response is now in core/formatters."""
        from core.formatters import sanitize_response
        assert sanitize_response("normal text") == "normal text"
        assert sanitize_response("") == ""

    def test_build_conversation_context_empty(self):
        from core.runtime import build_conversation_context
        result = build_conversation_context([], "hello")
        assert result == "hello"

    def test_build_conversation_context_with_history(self):
        from core.runtime import build_conversation_context
        history = [
            {"user": "önceki soru", "assistant": "önceki cevap"},
        ]
        result = build_conversation_context(history, "yeni soru")
        assert "<conversation_history>" in result
        assert "önceki soru" in result
        assert "<current_request>" in result
        assert "yeni soru" in result

    def test_handle_feedback_not_feedback(self):
        from core.runtime import handle_feedback_command
        result = handle_feedback_command("KOSGEB nedir?", 1)
        assert result is False

    def test_handle_feedback_iyi(self):
        from core.runtime import handle_feedback_command
        messages = []
        result = handle_feedback_command(
            "/iyi", 1,
            console_print_fn=lambda msg: messages.append(msg),
        )
        assert result is True
        assert any("Teşekkürler" in m for m in messages)

    def test_handle_feedback_no_task(self):
        from core.runtime import handle_feedback_command
        messages = []
        result = handle_feedback_command(
            "/iyi", None,
            console_print_fn=lambda msg: messages.append(msg),
        )
        assert result is True  # Consumed but no task to rate

    def test_runtime_no_cont_imports(self):
        """runtime.py must not import from cont module."""
        import re, inspect
        import core.runtime
        source = inspect.getsource(core.runtime)
        cont_imports = re.findall(r'^(?:from|import)\s+cont\b', source, re.MULTILINE)
        assert cont_imports == [], f"core/runtime.py imports cont: {cont_imports}"
