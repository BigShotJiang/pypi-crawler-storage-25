"""
Tests for core/recipes.py — parametric recipe system.
Run: pytest tests/test_recipes.py -v
"""
import os
import tempfile

import pytest


@pytest.fixture
def recipe_conn():
    """Create a temporary recipe DB for testing."""
    from core.recipes import init_recipe_db, seed_recipes

    db = os.path.join(tempfile.mkdtemp(), "test.db")
    conn = init_recipe_db(db)
    seed_recipes(conn)
    return conn


class TestRecipeSeed:
    """Seed recipes should populate the DB."""

    def test_seed_creates_recipes(self, recipe_conn):
        from core.recipes import list_recipes

        recipes = list_recipes(recipe_conn)
        assert len(recipes) >= 4

    def test_seed_has_expected_ids(self, recipe_conn):
        from core.recipes import list_recipes

        recipes = list_recipes(recipe_conn)
        ids = {r["id"] for r in recipes}
        assert "dosya_oku_ozetle_v1" in ids
        assert "proje_analiz_v1" in ids
        assert "web_arama_v1" in ids
        assert "kod_duzenle_v1" in ids

    def test_seed_idempotent(self, recipe_conn):
        from core.recipes import seed_recipes, list_recipes

        # Seed again — should not duplicate
        seed_recipes(recipe_conn)
        seed_recipes(recipe_conn)
        recipes = list_recipes(recipe_conn)
        assert len(recipes) == 4


class TestRecipeMatch:
    """Keyword scoring should match the right recipe."""

    def test_match_dosya_oku(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("bu dosyayi oku ve ozetle", recipe_conn)
        assert r is not None
        assert r["id"] == "dosya_oku_ozetle_v1"

    def test_match_proje_analiz(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("projeyi analiz et", recipe_conn)
        assert r is not None
        assert r["id"] == "proje_analiz_v1"

    def test_match_web_search(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("web'de python hakkinda ara", recipe_conn)
        assert r is not None
        assert r["id"] == "web_arama_v1"

    def test_no_match(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("merhaba nasilsin", recipe_conn)
        assert r is None

    def test_match_returns_score(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        assert r is not None
        assert "_score" in r
        assert r["_score"] >= 5

    def test_match_returns_parsed_steps(self, recipe_conn):
        from core.recipes import match_recipe

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        assert r is not None
        assert isinstance(r["steps"], list)
        assert len(r["steps"]) >= 2
        assert isinstance(r["student_contract"], list)


class TestRecipeLifecycle:
    """Success/failure tracking and auto-expiry."""

    def test_record_success(self, recipe_conn):
        from core.recipes import record_success, list_recipes

        record_success("dosya_oku_ozetle_v1", recipe_conn)
        record_success("dosya_oku_ozetle_v1", recipe_conn)
        recipes = list_recipes(recipe_conn)
        found = [r for r in recipes if r["id"] == "dosya_oku_ozetle_v1"][0]
        assert found["success_count"] == 2

    def test_record_failure(self, recipe_conn):
        from core.recipes import record_failure, list_recipes

        record_failure("proje_analiz_v1", recipe_conn)
        recipes = list_recipes(recipe_conn)
        found = [r for r in recipes if r["id"] == "proje_analiz_v1"][0]
        assert found["failure_count"] == 1

    def test_auto_expire_after_3_failures(self, recipe_conn):
        from core.recipes import record_failure, list_recipes

        record_failure("web_arama_v1", recipe_conn)
        record_failure("web_arama_v1", recipe_conn)
        record_failure("web_arama_v1", recipe_conn)

        # Should no longer be in active list
        active = list_recipes(recipe_conn, status="active")
        active_ids = {r["id"] for r in active}
        assert "web_arama_v1" not in active_ids

        # Should be in expired list
        expired = list_recipes(recipe_conn, status="expired")
        expired_ids = {r["id"] for r in expired}
        assert "web_arama_v1" in expired_ids


class TestRecipePrompt:
    """Prompt injection formatting."""

    def test_recipe_to_prompt(self, recipe_conn):
        from core.recipes import match_recipe, recipe_to_prompt

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        prompt = recipe_to_prompt(r, "dosyayi oku ve ozetle")
        assert "[RECIPE: dosya_oku_ozetle_v1]" in prompt
        assert "ADIMLAR" in prompt
        assert "KURALLAR" in prompt

    def test_variable_resolution(self, recipe_conn):
        from core.recipes import match_recipe, recipe_to_prompt

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        context = {"resolved_path": "/tmp/test.py"}
        prompt = recipe_to_prompt(r, "dosyayi oku", context)
        assert "/tmp/test.py" in prompt

    def test_student_contract_in_prompt(self, recipe_conn):
        from core.recipes import match_recipe, recipe_to_prompt

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        prompt = recipe_to_prompt(r, "dosyayi oku")
        assert "erisemiyorum" in prompt  # from student contract


class TestRecipeExecution:
    """SystemExecutor should execute recipe steps at system level."""

    def test_extract_file_hint_colon(self):
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        assert se._extract_file_hint("dosyayi oku: cont.py") == "cont.py"
        assert se._extract_file_hint("ozetle: README.md") == "README.md"

    def test_extract_file_hint_extension(self):
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        assert se._extract_file_hint("cont.py dosyasini oku") == "cont.py"
        assert se._extract_file_hint("setup.cfg icerigi") == "setup.cfg"

    def test_extract_file_hint_empty(self):
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        assert se._extract_file_hint("merhaba nasilsin") == ""

    def test_resolve_vars(self):
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        args = {"path": "{repo_root}/test.py", "query": "{file_hint}"}
        ctx = {"repo_root": "/home/user/project", "file_hint": "test.py"}
        resolved = se._resolve_vars(args, ctx)
        assert resolved["path"] == "/home/user/project/test.py"
        assert resolved["query"] == "test.py"

    def test_execute_read_recipe(self, recipe_conn, tmp_path):
        from core.recipes import match_recipe
        from core.system_executor import SystemExecutor

        # Create a temp file to read
        test_file = tmp_path / "hello.py"
        test_file.write_text("print('hello world')\n# test file\n")

        se = SystemExecutor()
        recipe = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        assert recipe is not None

        # Provide the file hint via the input text
        result = se.try_execute_recipe(
            f"dosyayi oku ve ozetle: {test_file}", recipe
        )
        assert result is not None
        assert result["handled"] is True
        assert result["recipe_id"] == "dosya_oku_ozetle_v1"
        assert "format_prompt" in result
        assert "hello world" in result["format_prompt"]

    def test_execute_recipe_no_file_returns_none(self, recipe_conn):
        from core.recipes import match_recipe
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        recipe = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        # No valid file hint → should return None
        result = se.try_execute_recipe(
            "dosyayi oku ve ozetle", recipe
        )
        assert result is None

    def test_execute_list_dir_recipe(self, recipe_conn, tmp_path):
        from core.recipes import match_recipe
        from core.system_executor import SystemExecutor

        # Create some files in tmp dir
        (tmp_path / "a.py").write_text("x")
        (tmp_path / "b.txt").write_text("y")

        se = SystemExecutor()
        recipe = match_recipe("projeyi analiz et", recipe_conn)
        assert recipe is not None

        # Override resolved_path via recall mock
        result = se.try_execute_recipe(
            f"projeyi analiz et: {tmp_path}", recipe
        )
        # May or may not succeed depending on file resolution,
        # but should not crash
        assert result is None or result.get("handled")

    def test_respond_only_recipe_returns_none(self):
        from core.system_executor import SystemExecutor

        se = SystemExecutor()
        # Recipe with only "respond" steps can't be system-executed
        recipe = {
            "id": "test_respond",
            "steps": [{"action": "respond", "args": {}}],
        }
        result = se.try_execute_recipe("hello", recipe)
        assert result is None


class TestBackwardCompat:
    """Old API functions should still work."""

    def test_load_recipes(self):
        from core.recipes import load_recipes

        recipes = load_recipes()
        assert isinstance(recipes, list)
        assert len(recipes) >= 4

    def test_format_recipe_for_prompt(self, recipe_conn):
        from core.recipes import match_recipe, format_recipe_for_prompt

        r = match_recipe("dosyayi oku ve ozetle", recipe_conn)
        prompt = format_recipe_for_prompt(r)
        assert "RECIPE" in prompt

    def test_record_recipe_outcome(self):
        from core.recipes import record_recipe_outcome

        # Should not crash even with None db_connect
        result = record_recipe_outcome("dosya_oku_ozetle_v1", True)
        assert result is True

    def test_get_recipe_stats(self):
        from core.recipes import get_recipe_stats

        stats = get_recipe_stats()
        assert isinstance(stats, list)

    def test_save_recipe(self):
        from core.recipes import save_recipe, list_recipes, init_recipe_db

        ok = save_recipe(
            "test_recipe_compat",
            triggers=["test trigger", "deneme"],
            steps=[{"tool": "read_file", "args": {"path": "."}, "purpose": "test"}],
        )
        assert ok is True

        # Verify it was saved
        conn = init_recipe_db()
        recipes = list_recipes(conn)
        ids = {r["id"] for r in recipes}
        assert "test_recipe_compat" in ids
