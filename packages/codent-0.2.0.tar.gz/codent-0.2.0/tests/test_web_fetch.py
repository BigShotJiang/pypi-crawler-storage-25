#!/usr/bin/env python3
"""
Unit tests for web_fetch SSRF protection and URL validation.
These tests verify security controls without requiring network access.
"""

import sys
import pytest
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.web import (
    is_private_ip,
    validate_url_scheme,
    validate_hostname,
    validate_url_for_fetch,
    html_to_text,
    get_cache_key,
    BLOCKED_HOSTNAMES,
)


class TestPrivateIPDetection:
    """Test private/reserved IP detection."""

    def test_loopback_ipv4(self):
        assert is_private_ip("127.0.0.1") is True
        assert is_private_ip("127.0.0.2") is True
        assert is_private_ip("127.255.255.255") is True

    def test_private_class_a(self):
        assert is_private_ip("10.0.0.1") is True
        assert is_private_ip("10.255.255.255") is True

    def test_private_class_b(self):
        assert is_private_ip("172.16.0.1") is True
        assert is_private_ip("172.31.255.255") is True
        # 172.32.x.x is NOT private
        assert is_private_ip("172.32.0.1") is False

    def test_private_class_c(self):
        assert is_private_ip("192.168.0.1") is True
        assert is_private_ip("192.168.255.255") is True

    def test_link_local(self):
        assert is_private_ip("169.254.0.1") is True
        assert is_private_ip("169.254.169.254") is True  # AWS metadata

    def test_public_ips(self):
        assert is_private_ip("8.8.8.8") is False
        assert is_private_ip("1.1.1.1") is False
        assert is_private_ip("93.184.216.34") is False  # example.com

    def test_ipv6_loopback(self):
        assert is_private_ip("::1") is True

    def test_invalid_ip(self):
        # Invalid IPs should be treated as blocked
        assert is_private_ip("not-an-ip") is True
        assert is_private_ip("") is True


class TestURLSchemeValidation:
    """Test URL scheme validation."""

    def test_http_allowed(self):
        validate_url_scheme("http://example.com")  # Should not raise

    def test_https_allowed(self):
        validate_url_scheme("https://example.com")  # Should not raise

    def test_file_blocked(self):
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            validate_url_scheme("file:///etc/passwd")

    def test_ftp_blocked(self):
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            validate_url_scheme("ftp://example.com")

    def test_data_blocked(self):
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            validate_url_scheme("data:text/html,<script>alert(1)</script>")

    def test_javascript_blocked(self):
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            validate_url_scheme("javascript:alert(1)")


class TestHostnameValidation:
    """Test hostname blocking."""

    def test_localhost_blocked(self):
        with pytest.raises(ValueError, match="Blocked hostname"):
            validate_hostname("localhost")

    def test_localhost_case_insensitive(self):
        with pytest.raises(ValueError, match="Blocked hostname"):
            validate_hostname("LOCALHOST")
        with pytest.raises(ValueError, match="Blocked hostname"):
            validate_hostname("LocalHost")

    def test_loopback_ip_blocked(self):
        with pytest.raises(ValueError, match="Blocked"):
            validate_hostname("127.0.0.1")

    def test_zero_ip_blocked(self):
        with pytest.raises(ValueError, match="Blocked hostname"):
            validate_hostname("0.0.0.0")

    def test_private_ip_in_hostname_blocked(self):
        with pytest.raises(ValueError, match="Blocked"):
            validate_hostname("192.168.1.1")
        with pytest.raises(ValueError, match="Blocked"):
            validate_hostname("10.0.0.1")

    def test_public_hostname_allowed(self):
        validate_hostname("example.com")  # Should not raise
        validate_hostname("google.com")   # Should not raise


class TestFullURLValidation:
    """Test complete URL validation for SSRF."""

    def test_localhost_url_blocked(self):
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://localhost/admin")

    def test_localhost_with_port_blocked(self):
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://localhost:8080/api")

    def test_private_ip_url_blocked(self):
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://192.168.1.1/")
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://10.0.0.1/")
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://172.16.0.1/")

    def test_file_url_blocked(self):
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            validate_url_for_fetch("file:///etc/passwd")

    def test_aws_metadata_blocked(self):
        with pytest.raises(ValueError):
            validate_url_for_fetch("http://169.254.169.254/latest/meta-data/")

    def test_missing_hostname_blocked(self):
        with pytest.raises(ValueError, match="missing hostname"):
            validate_url_for_fetch("http:///path")

    def test_public_url_format_valid(self):
        # Note: This only validates format, not DNS resolution
        # The actual DNS check may fail if network is unavailable
        try:
            validate_url_for_fetch("https://example.com/page")
        except ValueError as e:
            # DNS resolution failure is acceptable in test environment
            assert "DNS" in str(e) or "resolve" in str(e).lower()


class TestHTMLToText:
    """Test HTML to text conversion."""

    def test_basic_html(self):
        html = "<html><body><p>Hello World</p></body></html>"
        text = html_to_text(html)
        assert "Hello World" in text

    def test_script_stripped(self):
        html = "<html><script>alert('xss')</script><p>Safe content</p></html>"
        text = html_to_text(html)
        assert "alert" not in text
        assert "Safe content" in text

    def test_style_stripped(self):
        html = "<html><style>body{color:red}</style><p>Content</p></html>"
        text = html_to_text(html)
        assert "color:red" not in text
        assert "Content" in text

    def test_preserves_text(self):
        html = "<div><h1>Title</h1><p>Paragraph 1</p><p>Paragraph 2</p></div>"
        text = html_to_text(html)
        assert "Title" in text
        assert "Paragraph 1" in text
        assert "Paragraph 2" in text


class TestCacheKey:
    """Test cache key generation."""

    def test_same_url_same_key(self):
        key1 = get_cache_key("https://example.com/page")
        key2 = get_cache_key("https://example.com/page")
        assert key1 == key2

    def test_different_url_different_key(self):
        key1 = get_cache_key("https://example.com/page1")
        key2 = get_cache_key("https://example.com/page2")
        assert key1 != key2

    def test_key_is_sha256_hex(self):
        key = get_cache_key("https://example.com")
        assert len(key) == 64  # SHA256 hex length
        assert all(c in "0123456789abcdef" for c in key)


class TestBlockedHostnamesList:
    """Test that blocked hostnames list is correct."""

    def test_localhost_in_list(self):
        assert "localhost" in BLOCKED_HOSTNAMES

    def test_loopback_in_list(self):
        assert "127.0.0.1" in BLOCKED_HOSTNAMES

    def test_metadata_endpoints_blocked(self):
        # Cloud metadata endpoints
        assert "169.254.169.254" in BLOCKED_HOSTNAMES
        assert "metadata.google.internal" in BLOCKED_HOSTNAMES


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
