"""
Tests for core/episodic.py — episodic memory system.
Run: pytest tests/test_episodic.py -v
"""
import os
import tempfile

import pytest


@pytest.fixture
def episodic_conn():
    """Create a temporary episodic DB for testing."""
    from core.episodic import init_episodic_db

    db = os.path.join(tempfile.mkdtemp(), "test.db")
    return init_episodic_db(db)


class TestRecordAndQuery:
    """Episode recording and similarity search."""

    def test_record_episode(self, episodic_conn):
        from core.episodic import record_episode

        eid = record_episode(
            episodic_conn, "dosya oku cont.py",
            task_type="recipe",
            method="recipe:dosya_oku_ozetle_v1",
            tools_used=0,
            success=1,
            response_preview="cont.py özeti...",
        )
        assert eid > 0

    def test_query_similar(self, episodic_conn):
        from core.episodic import record_episode, get_similar_episodes

        record_episode(
            episodic_conn, "dosya oku cont.py",
            task_type="recipe",
            method="recipe:dosya_oku_ozetle_v1",
            tools_used=0,
            success=1,
            response_preview="cont.py özeti...",
        )

        similar = get_similar_episodes(episodic_conn, "cont.py dosyasını özetle")
        assert len(similar) == 1
        assert similar[0]["task_type"] == "recipe"

    def test_query_no_match(self, episodic_conn):
        from core.episodic import record_episode, get_similar_episodes

        record_episode(
            episodic_conn, "dosya oku cont.py",
            task_type="recipe",
            success=1,
        )

        # Short words filtered out, no keyword overlap
        similar = get_similar_episodes(episodic_conn, "xy ab")
        assert len(similar) == 0

    def test_multiple_episodes(self, episodic_conn):
        from core.episodic import record_episode, get_similar_episodes

        record_episode(episodic_conn, "dosya oku test.py", success=1)
        record_episode(episodic_conn, "dosya oku main.py", success=0)
        record_episode(episodic_conn, "web arama python", success=1)

        similar = get_similar_episodes(episodic_conn, "dosya okuma işlemi")
        assert len(similar) == 2  # Both "dosya" matches


class TestTaskStats:
    """Task statistics computation."""

    def test_stats_basic(self, episodic_conn):
        from core.episodic import record_episode, get_task_stats

        record_episode(episodic_conn, "task1", success=1, task_type="fastpath")
        record_episode(episodic_conn, "task2", success=1, task_type="recipe")
        record_episode(episodic_conn, "task3", success=0, task_type="llm")

        stats = get_task_stats(episodic_conn)
        assert stats["total"] == 3
        assert stats["success"] == 2
        assert stats["failed"] == 1
        assert stats["unknown"] == 0
        assert stats["success_rate"] == "67%"

    def test_stats_empty(self, episodic_conn):
        from core.episodic import get_task_stats

        stats = get_task_stats(episodic_conn)
        assert stats["total"] == 0
        assert stats["success_rate"] == "N/A"

    def test_stats_by_type(self, episodic_conn):
        from core.episodic import record_episode, get_task_stats

        record_episode(episodic_conn, "t1", task_type="fastpath", success=1)
        record_episode(episodic_conn, "t2", task_type="fastpath", success=1)
        record_episode(episodic_conn, "t3", task_type="llm", success=0)

        stats = get_task_stats(episodic_conn)
        assert stats["by_type"]["fastpath"] == 2
        assert stats["by_type"]["llm"] == 1


class TestUpdateFeedback:
    """User feedback update on episodes."""

    def test_feedback_iyi(self, episodic_conn):
        from core.episodic import record_episode, update_feedback

        eid = record_episode(episodic_conn, "task", success=-1)
        update_feedback(episodic_conn, eid, "iyi")

        row = episodic_conn.execute(
            "SELECT success, user_feedback FROM episodes WHERE id = ?",
            (eid,),
        ).fetchone()
        assert row[0] == 1
        assert row[1] == "iyi"

    def test_feedback_kotu(self, episodic_conn):
        from core.episodic import record_episode, update_feedback

        eid = record_episode(episodic_conn, "task", success=-1)
        update_feedback(episodic_conn, eid, "kötü")

        row = episodic_conn.execute(
            "SELECT success, user_feedback FROM episodes WHERE id = ?",
            (eid,),
        ).fetchone()
        assert row[0] == 0
        assert row[1] == "kötü"


class TestCleanup:
    """Old episode cleanup."""

    def test_cleanup_under_limit(self, episodic_conn):
        from core.episodic import record_episode, cleanup_old_episodes

        for i in range(5):
            record_episode(episodic_conn, f"task_{i}", success=1)

        deleted = cleanup_old_episodes(episodic_conn, keep_max=1000)
        assert deleted == 0  # Under limit, nothing deleted

    def test_cleanup_respects_max(self, episodic_conn):
        from core.episodic import record_episode, cleanup_old_episodes
        import time as _time

        # Insert old episodes (fake old timestamp)
        old_ts = _time.time() - (100 * 86400)
        for i in range(15):
            episodic_conn.execute(
                "INSERT INTO episodes (task_input, success, created_at) "
                "VALUES (?, ?, ?)",
                (f"old_task_{i}", 0, old_ts),
            )
        episodic_conn.commit()

        deleted = cleanup_old_episodes(episodic_conn, keep_days=90, keep_max=5)
        assert deleted > 0
