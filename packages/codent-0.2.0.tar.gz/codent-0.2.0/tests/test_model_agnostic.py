#!/usr/bin/env python3
"""
Unit tests for model-agnostic LLM layer.
Tests dynamic model selection, endpoint fallback, and message flattening.
"""

import sys
import os
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from cont import (
    resolve_model,
    _flatten_messages_to_prompt,
    _probe_chat_endpoint,
    _determine_endpoint_mode,
)
from core.model import list_available_models


@pytest.fixture(autouse=True)
def _reset_model_cache():
    """Reset model cache before each test to prevent cross-test pollution."""
    import core.model as model_mod
    orig_cache = model_mod._AVAILABLE_MODELS_CACHE
    model_mod._AVAILABLE_MODELS_CACHE = None
    yield
    model_mod._AVAILABLE_MODELS_CACHE = orig_cache


class TestListAvailableModels:
    """Test model listing from /v1/models endpoint."""

    @patch('core.model.requests.get')
    def test_returns_model_ids(self, mock_get):
        """list_available_models returns model IDs from API."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"id": "qwen2.5-coder"},
                {"id": "gemma-7b"},
                {"id": "mistral-7b"}
            ]
        }
        mock_get.return_value = mock_response

        models = list_available_models()

        assert len(models) == 3
        assert "qwen2.5-coder" in models
        assert "gemma-7b" in models
        assert "mistral-7b" in models

    @patch('core.model.requests.get')
    def test_returns_empty_on_error(self, mock_get):
        """list_available_models returns empty list on HTTP error."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_get.return_value = mock_response

        models = list_available_models()

        assert models == []

    @patch('core.model.requests.get')
    def test_returns_empty_on_exception(self, mock_get):
        """list_available_models returns empty list on exception."""
        mock_get.side_effect = Exception("Connection refused")

        models = list_available_models()

        assert models == []

    @patch('core.model.requests.get')
    def test_handles_empty_response(self, mock_get):
        """list_available_models handles empty model list."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": []}
        mock_get.return_value = mock_response

        models = list_available_models()

        assert models == []


class TestResolveModel:
    """Test dynamic model resolution."""

    @patch('cont._MODEL_OVERRIDE', "cli-model")
    def test_cli_override_has_priority(self):
        """CLI --model flag takes priority."""
        import cont
        cont._MODEL_OVERRIDE = "cli-model"

        # Clear env vars
        with patch.dict(os.environ, {}, clear=True):
            model = resolve_model(strict=False)

        assert model == "cli-model"
        cont._MODEL_OVERRIDE = None

    @patch('cont._MODEL_OVERRIDE', None)
    @patch.dict(os.environ, {"CONT_MODEL": "env-model"})
    def test_cont_model_env_used(self):
        """CONT_MODEL env var is used when no CLI override."""
        model = resolve_model(strict=False)
        assert model == "env-model"

    @patch('cont._MODEL_OVERRIDE', None)
    @patch.dict(os.environ, {"OPENAI_MODEL": "openai-model"}, clear=True)
    def test_openai_model_env_fallback(self):
        """OPENAI_MODEL env var is fallback when CONT_MODEL not set."""
        # Ensure CONT_MODEL is not set
        os.environ.pop("CONT_MODEL", None)
        model = resolve_model(strict=False)
        assert model == "openai-model"

    @patch('cont._MODEL_OVERRIDE', None)
    @patch('core.model.list_available_models')
    @patch.dict(os.environ, {}, clear=True)
    def test_auto_detect_first_model(self, mock_list):
        """Auto-detects first model from /v1/models."""
        # Clear both env vars
        os.environ.pop("CONT_MODEL", None)
        os.environ.pop("OPENAI_MODEL", None)
        mock_list.return_value = ["auto-detected-model", "second-model"]

        model = resolve_model()

        assert model == "auto-detected-model"


class TestFlattenMessages:
    """Test message flattening for completions endpoint."""

    def test_flattens_simple_conversation(self):
        """Flattens messages with role labels."""
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hello!"}
        ]

        prompt = _flatten_messages_to_prompt(messages)

        assert "SYSTEM:" in prompt
        assert "You are helpful." in prompt
        assert "USER:" in prompt
        assert "Hello!" in prompt
        assert "ASSISTANT:" in prompt
        assert prompt.endswith("ASSISTANT:\n")

    def test_preserves_message_order(self):
        """Message order is preserved in flattened prompt."""
        messages = [
            {"role": "system", "content": "First"},
            {"role": "user", "content": "Second"},
            {"role": "assistant", "content": "Third"},
            {"role": "user", "content": "Fourth"}
        ]

        prompt = _flatten_messages_to_prompt(messages)

        # Check order
        assert prompt.index("First") < prompt.index("Second")
        assert prompt.index("Second") < prompt.index("Third")
        assert prompt.index("Third") < prompt.index("Fourth")

    def test_handles_empty_content(self):
        """Handles messages with empty content."""
        messages = [
            {"role": "user", "content": ""},
            {"role": "assistant", "content": "Response"}
        ]

        prompt = _flatten_messages_to_prompt(messages)

        assert "Response" in prompt


class TestProbeChatEndpoint:
    """Test chat endpoint probing."""

    @patch('core.model.requests.post')
    def test_returns_true_on_success(self, mock_post):
        """Returns True when chat endpoint responds with 200."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        result = _probe_chat_endpoint("test-model")

        assert result is True

    @patch('core.model.requests.post')
    def test_returns_false_on_400(self, mock_post):
        """Returns False when chat endpoint responds with 400."""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_post.return_value = mock_response

        result = _probe_chat_endpoint("test-model")

        assert result is False

    @patch('core.model.requests.post')
    def test_returns_false_on_404(self, mock_post):
        """Returns False when chat endpoint responds with 404."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_post.return_value = mock_response

        result = _probe_chat_endpoint("test-model")

        assert result is False

    @patch('core.model.requests.post')
    def test_returns_true_on_exception(self, mock_post):
        """Returns True on exception (assumes chat works, will fail properly later)."""
        mock_post.side_effect = Exception("Connection error")

        result = _probe_chat_endpoint("test-model")

        assert result is True


class TestDetermineEndpointMode:
    """Test endpoint mode determination."""

    @patch('core.model._ENDPOINT_MODE', None)
    @patch('core.model.probe_chat_endpoint')
    def test_uses_chat_when_probe_succeeds(self, mock_probe):
        """Uses chat endpoint when probe succeeds."""
        import core.model as cm
        cm._ENDPOINT_MODE = None
        mock_probe.return_value = True

        mode = _determine_endpoint_mode("test-model")

        assert mode == "chat"
        cm._ENDPOINT_MODE = None

    @patch('core.model._ENDPOINT_MODE', None)
    @patch('core.model.probe_chat_endpoint')
    def test_falls_back_to_completions(self, mock_probe):
        """Falls back to completions when chat probe fails."""
        import core.model as cm
        cm._ENDPOINT_MODE = None
        mock_probe.return_value = False

        mode = _determine_endpoint_mode("test-model")

        assert mode == "completions"
        cm._ENDPOINT_MODE = None

    @patch('core.model._ENDPOINT_MODE', "chat")
    def test_caches_endpoint_mode(self):
        """Returns cached endpoint mode without re-probing."""
        import core.model as cm
        cm._ENDPOINT_MODE = "chat"

        mode = _determine_endpoint_mode("test-model")

        assert mode == "chat"
        cm._ENDPOINT_MODE = None


class TestModelAgnosticIntegration:
    """Integration tests for model-agnostic layer."""

    @patch('core.model._set_sticky_model')
    def test_cli_flag_overrides_all(self, mock_save):
        """Verify CLI flag has highest priority."""
        import cont
        original = cont._MODEL_OVERRIDE

        cont._MODEL_OVERRIDE = "cli-priority-model"

        with patch.dict(os.environ, {"CONT_MODEL": "env-model", "OPENAI_MODEL": "openai-model"}):
            model = resolve_model(strict=False)

        assert model == "cli-priority-model"
        cont._MODEL_OVERRIDE = original

    @patch('core.model._get_sticky_model', return_value=None)
    @patch('core.model.list_available_models', return_value=[])
    def test_no_models_error_message(self, mock_list, mock_sticky):
        """Verify clear error when no models available."""
        import cont
        cont._MODEL_OVERRIDE = None

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("CONT_MODEL", None)
            os.environ.pop("OPENAI_MODEL", None)

            with pytest.raises(SystemExit) as exc_info:
                resolve_model()

        assert exc_info.value.code == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
