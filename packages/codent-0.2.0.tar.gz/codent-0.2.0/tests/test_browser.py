"""
Tests for core/browser.py — Playwright browser automation.
Run: pytest tests/test_browser.py -v
"""
import pytest


class TestUrlValidation:
    """URL security validation."""

    def test_http_allowed(self):
        from core.browser import _validate_url

        ok, err = _validate_url("http://example.com")
        assert ok is True
        assert err is None

    def test_https_allowed(self):
        from core.browser import _validate_url

        ok, err = _validate_url("https://example.com/page")
        assert ok is True
        assert err is None

    def test_file_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("file:///etc/passwd")
        assert ok is False
        assert "http" in err

    def test_javascript_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("javascript:alert(1)")
        assert ok is False

    def test_localhost_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("http://localhost:8080")
        assert ok is False
        assert "localhost" in err

    def test_127_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("http://127.0.0.1/admin")
        assert ok is False

    def test_ipv6_localhost_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("http://[::1]/admin")
        assert ok is False

    def test_invalid_url(self):
        from core.browser import _validate_url

        ok, err = _validate_url("")
        assert ok is False

    def test_ftp_blocked(self):
        from core.browser import _validate_url

        ok, err = _validate_url("ftp://files.example.com")
        assert ok is False


class TestBrowserSingleton:
    """Browser instance management."""

    def test_singleton(self):
        from core.browser import Browser

        a = Browser.get_instance()
        b = Browser.get_instance()
        assert a is b

    def test_open_bad_url(self):
        from core.browser import browser_open

        result = browser_open("file:///etc/passwd")
        assert "Hata" in result or "http" in result.lower()

    def test_open_localhost_blocked(self):
        from core.browser import browser_open

        result = browser_open("http://localhost:3000")
        assert "localhost" in result


class TestToolWrappers:
    """Tool wrapper return format."""

    def test_browser_open_returns_string(self):
        from core.browser import browser_open

        result = browser_open("ftp://bad.url")
        assert isinstance(result, str)

    def test_browser_close_returns_string(self):
        from core.browser import browser_close

        result = browser_close()
        assert isinstance(result, str)
        assert "kapat" in result.lower()


class TestSecurityTiers:
    """Browser and web tools have correct security tiers."""

    def test_browser_read_tools_tier0(self):
        from core.safety import classify_tool, SecurityTier

        for tool in ("browser_text", "browser_links", "browser_close"):
            assert classify_tool(tool, {}) == SecurityTier.ALWAYS_ALLOWED, f"{tool} should be TIER_0"

    def test_browser_interactive_tools_tier1(self):
        from core.safety import classify_tool, SecurityTier

        for tool in ("browser_open", "browser_click", "browser_type", "browser_screenshot"):
            assert classify_tool(tool, {}) == SecurityTier.SAFE_ZONES, f"{tool} should be TIER_1"

    def test_web_search_tier0(self):
        from core.safety import classify_tool, SecurityTier

        assert classify_tool("web_search", {}) == SecurityTier.ALWAYS_ALLOWED

    def test_web_fetch_tier1(self):
        from core.safety import classify_tool, SecurityTier

        assert classify_tool("web_fetch", {}) == SecurityTier.SAFE_ZONES


class TestToolBudget:
    """Tool budget doesn't block first web_search."""

    def test_web_search_first_call_allowed(self):
        from core.tool_budget import DynamicToolBudget

        budget = DynamicToolBudget(budget_per_phase=12)
        allowed, msg = budget.can_call("web_search", {"query": "test"})
        assert allowed is True

    def test_web_search_three_calls_allowed(self):
        from core.tool_budget import DynamicToolBudget

        budget = DynamicToolBudget(budget_per_phase=12)
        for i in range(3):
            allowed, _ = budget.can_call("web_search", {"query": f"test_{i}"})
            assert allowed is True, f"web_search call {i+1} should be allowed"


class TestRegistration:
    """Browser tools are registered in cont."""

    def test_tools_in_dispatcher(self):
        from cont import TOOLS

        assert "browser_open" in TOOLS
        assert "browser_click" in TOOLS
        assert "browser_close" in TOOLS

    def test_schemas_present(self):
        from cont import TOOL_SCHEMAS

        schema_names = {
            s["function"]["name"]
            for s in TOOL_SCHEMAS
        }
        assert "browser_open" in schema_names
        assert "browser_click" in schema_names
        assert "browser_type" in schema_names
        assert "browser_text" in schema_names
        assert "browser_screenshot" in schema_names
        assert "browser_links" in schema_names
        assert "browser_close" in schema_names

    def test_capability_flag(self):
        from cont import CAPABILITIES

        assert CAPABILITIES["browser_automation"] is True
