#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Regression tests for canonical_health_check.py

Tests:
- Valid JSON output
- Atomic write function
- Safe autofix behavior
- Patch plan generation
"""

import json
import sys
import subprocess
import tempfile
from pathlib import Path

TOOL_PATH = Path(__file__).parent.parent / "tools" / "canonical_health_check.py"


def create_test_files(tmpdir: Path) -> None:
    """Create test canonical JSON files."""
    # Valid canonical file
    valid_file = tmpdir / "valid.json"
    valid_data = [
        {
            "id": "test.rules.m1_p1",
            "text": "This is a valid test record with enough text to pass the minimum length check.",
            "type": "rule",
            "title": "Test Rule",
            "program": "test"
        },
        {
            "id": "test.rules.m1_p2",
            "text": "Another valid record with sufficient content to satisfy the validator requirements.",
            "type": "rule",
            "title": "Test Rule 2",
            "program": "test"
        }
    ]
    with open(valid_file, "w", encoding="utf-8") as f:
        json.dump(valid_data, f, ensure_ascii=False, indent=2)

    # File with issues
    issues_file = tmpdir / "with_issues.json"
    issues_data = [
        {
            "id": "test.rules.m2_p1",
            "text": "Short",  # Too short
            "type": "rule"
        },
        {
            "id": "test.rules.m2_p2",
            # Missing 'text' field
            "type": "rule"
        },
        {
            "id": "test.rules.m2_p3",
            "text": "Valid text with enough characters to pass the minimum length requirement.",
            # Missing 'type' field
        },
        {
            "id": "  test.rules.m2_p4  ",  # Whitespace in ID
            "text": "   ",  # Whitespace-only text
            "type": "rule"
        },
        {
            "id": "test.rules.m2_p5",
            "text": "Text with\r\nWindows\rline endings that need normalization.",
            "type": "rule"
        }
    ]
    with open(issues_file, "w", encoding="utf-8") as f:
        json.dump(issues_data, f, ensure_ascii=False, indent=2)


def test_report_is_valid_json():
    """Test that the health report is always valid JSON."""
    errors = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        create_test_files(tmpdir)

        report_path = tmpdir / "health_report.json"

        result = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir), "--output", str(report_path)],
            capture_output=True,
            text=True
        )

        if not report_path.exists():
            errors.append(f"Report file not created: {report_path}")
            return errors

        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report = json.load(f)
        except json.JSONDecodeError as e:
            errors.append(f"Invalid JSON: {e}")
            return errors

        required_keys = {"timestamp", "path", "summary", "files", "issues"}
        missing_keys = required_keys - set(report.keys())
        if missing_keys:
            errors.append(f"Missing required keys: {missing_keys}")

        # Check for new keys
        if "duplicates" not in report:
            errors.append("Missing 'duplicates' key in report")
        if "broken_links" not in report:
            errors.append("Missing 'broken_links' key in report")

        # Verify with json.tool
        tool_result = subprocess.run(
            [sys.executable, "-m", "json.tool", str(report_path)],
            capture_output=True,
            text=True
        )
        if tool_result.returncode != 0:
            errors.append(f"json.tool validation failed: {tool_result.stderr}")

    return errors


def test_atomic_write_function():
    """Test the atomic write function directly."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import write_json_atomic

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        test_file = tmpdir / "test_atomic.json"

        test_data = {
            "key": "value",
            "unicode": "Türkçe karakterler: çğıöşü",
            "nested": {"a": 1}
        }

        try:
            write_json_atomic(test_file, test_data)
        except Exception as e:
            errors.append(f"write_json_atomic raised exception: {e}")
            return errors

        if not test_file.exists():
            errors.append("Atomic write did not create file")
            return errors

        try:
            with open(test_file, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if loaded != test_data:
                errors.append(f"Data mismatch")
        except json.JSONDecodeError as e:
            errors.append(f"Atomic write produced invalid JSON: {e}")

        with open(test_file, "rb") as f:
            content = f.read()
            if not content.endswith(b"\n"):
                errors.append("File does not end with newline")

    return errors


def test_autofix_type_inference():
    """Test that autofix infers type from record_id."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import infer_type_from_id, autofix_record

    # Test type inference
    test_cases = [
        ("test.rules.m1_p1", "rule"),
        ("test.definitions.term1", "definition"),
        ("test.terms.glossary_a", "term"),
        ("m5_p2_ba", "rule"),
        ("unknown_pattern", "unknown"),
    ]

    for record_id, expected_type in test_cases:
        result = infer_type_from_id(record_id)
        if result != expected_type:
            errors.append(f"infer_type_from_id('{record_id}'): expected '{expected_type}', got '{result}'")

    # Test autofix adds type
    record = {"id": "test.rules.m1_p1", "text": "Some valid text here."}
    fixed, fixes = autofix_record(record)

    if "type" not in fixed:
        errors.append("autofix did not add 'type' field")
    elif fixed["type"] != "rule":
        errors.append(f"autofix set wrong type: {fixed['type']}")

    return errors


def test_autofix_empty_text():
    """Test that autofix sets placeholder for empty text."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import autofix_record, MISSING_TEXT_PLACEHOLDER

    # Test empty text
    record = {"id": "test.m1", "text": "", "type": "rule"}
    fixed, fixes = autofix_record(record)

    if fixed["text"] != MISSING_TEXT_PLACEHOLDER:
        errors.append(f"Empty text not replaced with placeholder: {fixed['text']}")

    # Test whitespace-only text
    record2 = {"id": "test.m2", "text": "   \n\t  ", "type": "rule"}
    fixed2, fixes2 = autofix_record(record2)

    if fixed2["text"] != MISSING_TEXT_PLACEHOLDER:
        errors.append(f"Whitespace text not replaced: {fixed2['text']}")

    # Test missing text
    record3 = {"id": "test.m3", "type": "rule"}
    fixed3, fixes3 = autofix_record(record3)

    if fixed3.get("text") != MISSING_TEXT_PLACEHOLDER:
        errors.append(f"Missing text not set to placeholder")

    return errors


def test_autofix_line_endings():
    """Test that autofix normalizes line endings."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import autofix_record

    record = {
        "id": "test.m1",
        "text": "Line1\r\nLine2\rLine3\nLine4",
        "type": "rule"
    }
    fixed, fixes = autofix_record(record)

    expected = "Line1\nLine2\nLine3\nLine4"
    if fixed["text"] != expected:
        errors.append(f"Line endings not normalized: {repr(fixed['text'])}")

    return errors


def test_patch_plan_generation():
    """Test that patch plans are generated correctly."""
    errors = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        patches_dir = tmpdir / "patches"

        # Create file with issues
        test_file = tmpdir / "needs_fixes.json"
        test_data = [
            {"id": "m1_p1", "text": "Valid enough text for testing purposes here."},  # missing type
            {"id": "m2_p1", "type": "rule"},  # missing text
        ]
        with open(test_file, "w", encoding="utf-8") as f:
            json.dump(test_data, f)

        # Run with --write-patches
        result = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--write-patches", str(patches_dir),
             "--output", str(tmpdir / "report.json")],
            capture_output=True,
            text=True
        )

        # Check patch file exists
        patch_file = patches_dir / "needs_fixes.patch_plan.json"
        if not patch_file.exists():
            errors.append(f"Patch file not created: {patch_file}")
            return errors

        # Load and validate patch plan
        try:
            with open(patch_file, "r", encoding="utf-8") as f:
                plan = json.load(f)
        except json.JSONDecodeError as e:
            errors.append(f"Patch plan is invalid JSON: {e}")
            return errors

        # Check structure
        if "proposed_fixes" not in plan:
            errors.append("Patch plan missing 'proposed_fixes'")
        if "summary" not in plan:
            errors.append("Patch plan missing 'summary'")

        # Should have 2 fixes (missing type + missing text)
        if len(plan.get("proposed_fixes", [])) < 2:
            errors.append(f"Expected at least 2 fixes, got {len(plan.get('proposed_fixes', []))}")

    return errors


def test_duplicate_suggestions():
    """Test duplicate ID detection and suggestions."""
    errors = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create files with duplicate IDs
        file1 = tmpdir / "file1_full.json"
        file2 = tmpdir / "file2_canonical.json"

        data1 = [{"id": "dup_id", "text": "Text in full file.", "type": "rule"}]
        data2 = [{"id": "dup_id", "text": "Text in canonical file.", "type": "rule"}]

        with open(file1, "w") as f:
            json.dump(data1, f)
        with open(file2, "w") as f:
            json.dump(data2, f)

        report_path = tmpdir / "report.json"
        result = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--output", str(report_path)],
            capture_output=True,
            text=True
        )

        with open(report_path) as f:
            report = json.load(f)

        if "duplicates" not in report or not report["duplicates"]:
            errors.append("No duplicates detected")
            return errors

        dup_info = report["duplicates"].get("dup_id", {})
        if not dup_info:
            errors.append("dup_id not in duplicates report")
        elif "suggested_keeper" not in dup_info:
            errors.append("No suggested_keeper in duplicate info")
        elif "_canonical" not in dup_info["suggested_keeper"]:
            errors.append(f"Should prefer canonical file, got: {dup_info['suggested_keeper']}")

    return errors


def test_report_file_exclusion():
    """Test that health_report.json and patch_plan files are excluded by default."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import is_report_file, find_json_files

    # Test is_report_file function
    should_exclude = [
        "health_report.json",
        "health_report_2024.json",
        "health_report_v2.json",
        "segem.patch_plan.json",
        "data_patch_plan.json",
        "foo_patch_plan.json",
    ]
    should_include = [
        "segem.json",
        "canonical.json",
        "my_report.json",  # doesn't start with health_report
        "health.json",     # doesn't match pattern
    ]

    for name in should_exclude:
        if not is_report_file(name):
            errors.append(f"is_report_file should exclude '{name}'")

    for name in should_include:
        if is_report_file(name):
            errors.append(f"is_report_file should NOT exclude '{name}'")

    # Test actual file exclusion in find_json_files
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create a valid data file
        valid_file = tmpdir / "data.json"
        with open(valid_file, "w") as f:
            json.dump([{"id": "test", "text": "test", "type": "rule"}], f)

        # Create report files that should be excluded
        report_file = tmpdir / "health_report.json"
        with open(report_file, "w") as f:
            json.dump({"invalid": "structure"}, f)  # Would fail validation

        patch_file = tmpdir / "data.patch_plan.json"
        with open(patch_file, "w") as f:
            json.dump({"also": "invalid"}, f)

        # Test default exclusion
        files = find_json_files(tmpdir, include_reports=False)
        file_names = [f.name for f in files]

        if "health_report.json" in file_names:
            errors.append("health_report.json was not excluded by default")
        if "data.patch_plan.json" in file_names:
            errors.append("data.patch_plan.json was not excluded by default")
        if "data.json" not in file_names:
            errors.append("data.json should be included")

        # Test with include_reports=True
        files_all = find_json_files(tmpdir, include_reports=True)
        file_names_all = [f.name for f in files_all]

        if "health_report.json" not in file_names_all:
            errors.append("health_report.json should be included with --include-reports")
        if "data.patch_plan.json" not in file_names_all:
            errors.append("data.patch_plan.json should be included with --include-reports")

    return errors


def test_exclusion_prevents_errors():
    """Test that excluded files don't cause validation errors."""
    errors = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create valid data file
        valid_file = tmpdir / "valid.json"
        with open(valid_file, "w") as f:
            json.dump([{
                "id": "test.m1",
                "text": "Valid text with enough length to pass validation checks.",
                "type": "rule"
            }], f)

        # Create health_report.json with structure that would fail validation
        # (missing required fields like 'id', 'text', 'type')
        report_file = tmpdir / "health_report.json"
        with open(report_file, "w") as f:
            json.dump({
                "timestamp": "2024-01-01",
                "summary": {"errors": 0}
            }, f)

        # Run health check - should NOT report errors from health_report.json
        result = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--output", str(tmpdir / "new_report.json")],
            capture_output=True,
            text=True
        )

        with open(tmpdir / "new_report.json") as f:
            report = json.load(f)

        # Should have 0 errors (valid.json is valid, health_report.json is excluded)
        if report["summary"]["errors"] != 0:
            errors.append(f"Expected 0 errors, got {report['summary']['errors']}")
            errors.append(f"Issues: {report.get('issues', {})}")

        # Should only scan 1 file (valid.json)
        if report["summary"]["files_scanned"] != 1:
            errors.append(f"Expected 1 file scanned, got {report['summary']['files_scanned']}")

    return errors


def test_min_text_len_flag():
    """Test --min-text-len flag changes short text threshold."""
    errors = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create file with text of 30 chars
        test_file = tmpdir / "test.json"
        with open(test_file, "w") as f:
            json.dump([{
                "id": "test.m1",
                "text": "This is exactly 30 characters.",  # 30 chars
                "type": "rule"
            }], f)

        # With default threshold (50), should get short_text warning
        result1 = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--output", str(tmpdir / "report1.json")],
            capture_output=True,
            text=True
        )
        with open(tmpdir / "report1.json") as f:
            report1 = json.load(f)

        if report1["summary"]["warnings"] != 1:
            errors.append(f"Default threshold: expected 1 warning, got {report1['summary']['warnings']}")

        # With --min-text-len 25, should get short_text warning (30 > 25)
        result2 = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--min-text-len", "25",
             "--output", str(tmpdir / "report2.json")],
            capture_output=True,
            text=True
        )
        with open(tmpdir / "report2.json") as f:
            report2 = json.load(f)

        if report2["summary"]["warnings"] != 0:
            errors.append(f"With --min-text-len 25: expected 0 warnings, got {report2['summary']['warnings']}")

        # With --min-text-len 35, should get short_text warning (30 < 35)
        result3 = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--min-text-len", "35",
             "--output", str(tmpdir / "report3.json")],
            capture_output=True,
            text=True
        )
        with open(tmpdir / "report3.json") as f:
            report3 = json.load(f)

        if report3["summary"]["warnings"] != 1:
            errors.append(f"With --min-text-len 35: expected 1 warning, got {report3['summary']['warnings']}")

    return errors


def test_ignore_placeholder_short():
    """Test --ignore-placeholder-short and --no-ignore-placeholder-short flags."""
    errors = []

    sys.path.insert(0, str(TOOL_PATH.parent))
    from canonical_health_check import MISSING_TEXT_PLACEHOLDER

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create file with placeholder text
        test_file = tmpdir / "test.json"
        with open(test_file, "w") as f:
            json.dump([{
                "id": "test.m1",
                "text": MISSING_TEXT_PLACEHOLDER,
                "type": "rule"
            }], f)

        # Default behavior: placeholder should NOT produce short_text warning
        result1 = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--output", str(tmpdir / "report1.json")],
            capture_output=True,
            text=True
        )
        with open(tmpdir / "report1.json") as f:
            report1 = json.load(f)

        if report1["summary"]["warnings"] != 0:
            errors.append(f"Default (ignore placeholder): expected 0 warnings, got {report1['summary']['warnings']}")
            if "short_text" in report1.get("issues", {}):
                errors.append(f"  short_text issues: {report1['issues']['short_text']}")

        # With --no-ignore-placeholder-short: should produce short_text warning
        result2 = subprocess.run(
            [sys.executable, str(TOOL_PATH), "--path", str(tmpdir),
             "--no-ignore-placeholder-short",
             "--output", str(tmpdir / "report2.json")],
            capture_output=True,
            text=True
        )
        with open(tmpdir / "report2.json") as f:
            report2 = json.load(f)

        if report2["summary"]["warnings"] != 1:
            errors.append(f"With --no-ignore-placeholder-short: expected 1 warning, got {report2['summary']['warnings']}")

    return errors


def main():
    """Run all tests."""
    tests = [
        ("Report is valid JSON", test_report_is_valid_json),
        ("Atomic write function", test_atomic_write_function),
        ("Autofix type inference", test_autofix_type_inference),
        ("Autofix empty text", test_autofix_empty_text),
        ("Autofix line endings", test_autofix_line_endings),
        ("Patch plan generation", test_patch_plan_generation),
        ("Duplicate suggestions", test_duplicate_suggestions),
        ("Report file exclusion", test_report_file_exclusion),
        ("Exclusion prevents errors", test_exclusion_prevents_errors),
        ("Min text length flag", test_min_text_len_flag),
        ("Ignore placeholder short", test_ignore_placeholder_short),
    ]

    all_passed = True

    for name, test_func in tests:
        print(f"Test: {name}")
        try:
            errors = test_func()
            if errors:
                all_passed = False
                print("  FAIL:")
                for e in errors:
                    print(f"    - {e}")
            else:
                print("  PASS")
        except Exception as e:
            all_passed = False
            print(f"  EXCEPTION: {e}")

    print()
    if all_passed:
        print("ALL TESTS PASSED")
        sys.exit(0)
    else:
        print("SOME TESTS FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
