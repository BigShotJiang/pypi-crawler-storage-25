# -*- coding: utf-8 -*-

import json
from pathlib import Path
import subprocess
import sys


def run(cmd: str) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def test_parse_and_validate_segem_first_section(tmp_path: Path):
    # Paths relative to repo root (assumes pytest is run from repo root)
    inp = Path("data/inbox/SEGEM_first_section.txt")
    assert inp.exists(), "Missing input file: data/inbox/SEGEM_first_section.txt"

    out = tmp_path / "segem_out.json"

    cmd = f"{sys.executable} tools/corpus_parser.py --in {inp} --out {out} --section-id s1"
    r = run(cmd)
    assert r.returncode == 0, f"parser failed:\nSTDOUT:\n{r.stdout}\nSTDERR:\n{r.stderr}"

    # Basic shape checks
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["id"] == "root"
    assert isinstance(data["children"], list)
    assert len(data["children"]) >= 1  # should at least have section wrapper

    # Validate canonical
    vcmd = f"{sys.executable} tools/validate_canonical.py --in {out} --strict-levels"
    vr = run(vcmd)
    assert vr.returncode == 0, f"validator failed:\nSTDOUT:\n{vr.stdout}\nSTDERR:\n{vr.stderr}"
