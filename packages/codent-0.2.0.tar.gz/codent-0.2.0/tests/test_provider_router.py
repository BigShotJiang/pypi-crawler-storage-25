# tests/test_provider_router.py
"""Tests for core.provider_router — no real network calls."""

import unittest
from unittest.mock import patch, MagicMock

from core.provider_router import (
    get_provider,
    _check_provider,
    _pick_ollama_model,
    ProviderUnavailableError,
)


def _make_models_response(model_ids: list[str]):
    """Create a mock httpx response with model list."""
    mock = MagicMock()
    mock.status_code = 200
    mock.json.return_value = {"data": [{"id": m} for m in model_ids]}
    return mock


def _make_error_response():
    mock = MagicMock()
    mock.status_code = 500
    return mock


class TestCheckProvider(unittest.TestCase):
    @patch("core.provider_router.httpx.get")
    def test_alive_returns_models(self, mock_get):
        mock_get.return_value = _make_models_response(["qwen2.5", "llama3"])
        result = _check_provider("http://localhost:1234/v1")
        self.assertEqual(result, ["qwen2.5", "llama3"])

    @patch("core.provider_router.httpx.get")
    def test_dead_returns_none(self, mock_get):
        mock_get.side_effect = ConnectionError("refused")
        result = _check_provider("http://localhost:1234/v1")
        self.assertIsNone(result)

    @patch("core.provider_router.httpx.get")
    def test_500_returns_none(self, mock_get):
        mock_get.return_value = _make_error_response()
        result = _check_provider("http://localhost:1234/v1")
        self.assertIsNone(result)

    @patch("core.provider_router.httpx.get")
    def test_empty_models_returns_none(self, mock_get):
        mock_get.return_value = _make_models_response([])
        result = _check_provider("http://localhost:1234/v1")
        self.assertIsNone(result)


class TestPickOllamaModel(unittest.TestCase):
    def test_devstral_preferred(self):
        self.assertEqual(
            _pick_ollama_model(["llama3", "devstral:latest", "qwen2.5"]),
            "devstral:latest",
        )

    def test_fallback_to_first(self):
        self.assertEqual(
            _pick_ollama_model(["llama3", "qwen2.5"]),
            "llama3",
        )


class TestGetProvider(unittest.TestCase):
    def setUp(self):
        # Clear lru_cache between tests
        get_provider.cache_clear()

    @patch("core.provider_router._check_provider")
    def test_lmstudio_available(self, mock_check):
        mock_check.side_effect = lambda url: (
            ["qwen2.5-coder"] if "1234" in url else None
        )
        client, model, provider = get_provider()
        self.assertEqual(provider, "lmstudio")
        self.assertEqual(model, "qwen2.5-coder")

    @patch("core.provider_router._check_provider")
    def test_ollama_fallback(self, mock_check):
        mock_check.side_effect = lambda url: (
            None if "1234" in url else ["devstral:latest", "llama3"]
        )
        client, model, provider = get_provider()
        self.assertEqual(provider, "ollama")
        self.assertEqual(model, "devstral:latest")

    @patch("core.provider_router._check_provider")
    def test_both_down_raises(self, mock_check):
        mock_check.return_value = None
        with self.assertRaises(ProviderUnavailableError):
            get_provider()

    @patch("core.provider_router._check_provider")
    def test_ollama_no_devstral(self, mock_check):
        mock_check.side_effect = lambda url: (
            None if "1234" in url else ["llama3", "mistral"]
        )
        client, model, provider = get_provider()
        self.assertEqual(provider, "ollama")
        self.assertEqual(model, "llama3")


if __name__ == "__main__":
    unittest.main()
