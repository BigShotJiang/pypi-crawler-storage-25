#!/usr/bin/env python3
"""
Cont Context Watcher - Background daemon for system awareness.

Usage:
    python cont_watcher.py start
    python cont_watcher.py stop
    python cont_watcher.py status
"""

import os
import sys
import json
import time
import signal
import subprocess
import threading
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
import atexit

# Try to import inotify (Linux file watching)
try:
    from inotify_simple import INotify, flags as inotify_flags
    INOTIFY_AVAILABLE = True
except ImportError:
    INOTIFY_AVAILABLE = False

# Configuration
CONT_CONFIG_DIR = Path.home() / ".config" / "cont"
WATCHER_DIR = CONT_CONFIG_DIR / "watcher"
CONTEXT_DIR = CONT_CONFIG_DIR / "context"
PID_FILE = WATCHER_DIR / "cont_watcher.pid"
LOG_FILE = WATCHER_DIR / "cont_watcher.log"
STATE_FILE = CONTEXT_DIR / "current_state.json"
WATCHED_PATHS_FILE = CONTEXT_DIR / "watched_paths.txt"

# Update interval in seconds
UPDATE_INTERVAL = 5

# Maximum items to keep in history
MAX_RECENT_FILES = 50
MAX_RECENT_COMMANDS = 50


def log(msg: str):
    """Log message to file and optionally stdout."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}\n"

    try:
        WATCHER_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a") as f:
            f.write(line)
    except Exception:
        pass

    # Also print if running in foreground
    if not is_daemon():
        print(line.strip())


def is_daemon() -> bool:
    """Check if running as daemon."""
    return os.getppid() == 1


def get_watched_paths() -> List[Path]:
    """Get list of paths to watch."""
    paths = []

    # Default paths
    default_paths = [
        Path.home() / "projects",
        Path.home(),
    ]

    # Read custom paths
    if WATCHED_PATHS_FILE.exists():
        try:
            for line in WATCHED_PATHS_FILE.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    p = Path(line).expanduser()
                    if p.exists():
                        paths.append(p)
        except Exception:
            pass

    # Add defaults if no custom paths
    if not paths:
        paths = [p for p in default_paths if p.exists()]

    return paths


def get_recent_bash_history(limit: int = 20) -> List[Dict]:
    """Read recent commands from bash history."""
    history_file = Path.home() / ".bash_history"
    commands = []

    if not history_file.exists():
        return commands

    try:
        lines = history_file.read_text(errors='ignore').splitlines()
        recent = lines[-limit:] if len(lines) > limit else lines

        for cmd in reversed(recent):
            cmd = cmd.strip()
            if cmd and not cmd.startswith("#"):
                commands.append({
                    "cmd": cmd[:200],  # Truncate long commands
                    "time": "recent",  # Bash history doesn't have timestamps by default
                })
    except Exception:
        pass

    return commands


def get_git_status(path: Path) -> Optional[Dict]:
    """Get git status for a directory."""
    try:
        # Check if it's a git repo
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode != 0:
            return None

        # Get branch
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5
        )
        branch = result.stdout.strip() if result.returncode == 0 else "unknown"

        # Get status
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5
        )
        uncommitted = len(result.stdout.strip().splitlines()) if result.returncode == 0 else 0

        return {
            "path": str(path),
            "branch": branch,
            "uncommitted_changes": uncommitted,
        }
    except Exception:
        return None


def get_environment() -> Dict:
    """Get relevant environment variables."""
    env = {}

    keys = [
        "VIRTUAL_ENV",
        "CONDA_DEFAULT_ENV",
        "CONDA_PREFIX",
        "PYTHONPATH",
        "PATH",
    ]

    for key in keys:
        val = os.environ.get(key)
        if val:
            env[key] = val[:500]  # Truncate long values

    # Active python
    try:
        result = subprocess.run(
            ["which", "python"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            env["active_python"] = result.stdout.strip()
    except Exception:
        pass

    return env


def get_system_stats() -> Dict:
    """Get system statistics."""
    stats = {}

    # Load average
    try:
        with open("/proc/loadavg") as f:
            parts = f.read().split()
            stats["load_avg"] = [float(parts[0]), float(parts[1]), float(parts[2])]
    except Exception:
        pass

    # Memory
    try:
        with open("/proc/meminfo") as f:
            meminfo = {}
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    key = parts[0].rstrip(":")
                    val = int(parts[1])
                    meminfo[key] = val

            total = meminfo.get("MemTotal", 0) / 1024 / 1024  # GB
            available = meminfo.get("MemAvailable", 0) / 1024 / 1024  # GB
            stats["memory_total_gb"] = round(total, 1)
            stats["memory_free_gb"] = round(available, 1)
    except Exception:
        pass

    # GPU memory (nvidia-smi)
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(",")
            if len(parts) >= 2:
                stats["gpu_memory_used_mb"] = int(parts[0].strip())
                stats["gpu_memory_total_mb"] = int(parts[1].strip())
    except Exception:
        pass

    return stats


def get_running_services() -> List[Dict]:
    """Get list of relevant running services."""
    services = []

    # Look for specific processes
    targets = ["lm-studio", "lmstudio", "ollama", "code", "python", "node"]

    try:
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines()[1:]:  # Skip header
                parts = line.split()
                if len(parts) >= 11:
                    cmd = " ".join(parts[10:])
                    for target in targets:
                        if target in cmd.lower():
                            services.append({
                                "name": target,
                                "pid": int(parts[1]),
                                "cmd": cmd[:100],
                            })
                            break
    except Exception:
        pass

    # Dedupe by name
    seen = set()
    unique = []
    for s in services:
        if s["name"] not in seen:
            seen.add(s["name"])
            unique.append(s)

    return unique[:10]


class FileWatcher:
    """Watch files for changes using inotify."""

    def __init__(self, paths: List[Path], callback):
        self.paths = paths
        self.callback = callback
        self.inotify = None
        self.watch_descriptors = {}
        self.running = False
        self.thread = None

    def start(self):
        """Start watching."""
        if not INOTIFY_AVAILABLE:
            log("inotify not available, file watching disabled")
            return

        try:
            self.inotify = INotify()
            watch_flags = (
                inotify_flags.CREATE |
                inotify_flags.DELETE |
                inotify_flags.MODIFY |
                inotify_flags.MOVED_FROM |
                inotify_flags.MOVED_TO
            )

            for path in self.paths:
                try:
                    wd = self.inotify.add_watch(str(path), watch_flags)
                    self.watch_descriptors[wd] = path
                    log(f"Watching: {path}")
                except Exception as e:
                    log(f"Failed to watch {path}: {e}")

            self.running = True
            self.thread = threading.Thread(target=self._watch_loop, daemon=True)
            self.thread.start()
        except Exception as e:
            log(f"Failed to start file watcher: {e}")

    def stop(self):
        """Stop watching."""
        self.running = False
        if self.inotify:
            try:
                self.inotify.close()
            except Exception:
                pass

    def _watch_loop(self):
        """Main watch loop."""
        while self.running:
            try:
                events = self.inotify.read(timeout=1000)
                for event in events:
                    path = self.watch_descriptors.get(event.wd, Path("."))
                    name = event.name

                    # Determine action
                    if event.mask & inotify_flags.CREATE:
                        action = "created"
                    elif event.mask & inotify_flags.DELETE:
                        action = "deleted"
                    elif event.mask & inotify_flags.MODIFY:
                        action = "modified"
                    elif event.mask & (inotify_flags.MOVED_FROM | inotify_flags.MOVED_TO):
                        action = "moved"
                    else:
                        action = "changed"

                    # Ignore hidden/temp files
                    if name.startswith(".") or name.endswith((".swp", ".tmp", "~")):
                        continue

                    self.callback(str(path / name), action)
            except Exception as e:
                if self.running:
                    log(f"Watch error: {e}")
                time.sleep(1)


class ContextWatcher:
    """Main watcher class that aggregates all watchers."""

    def __init__(self):
        self.state = {
            "recent_files": [],
            "recent_commands": [],
        }
        self.running = False
        self.file_watcher = None
        self._start_time = time.time()

    def start(self):
        """Start the watcher."""
        log("Starting Context Watcher...")

        # Ensure directories exist
        WATCHER_DIR.mkdir(parents=True, exist_ok=True)
        CONTEXT_DIR.mkdir(parents=True, exist_ok=True)

        # Write PID
        PID_FILE.write_text(str(os.getpid()))
        atexit.register(self._cleanup)

        # Handle signals
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)

        # Start file watcher
        paths = get_watched_paths()
        self.file_watcher = FileWatcher(paths, self.on_file_change)
        self.file_watcher.start()

        self.running = True
        log("Context Watcher started")

        # Main loop
        while self.running:
            try:
                self._update_state()
                self._write_state()
            except Exception as e:
                log(f"Update error: {e}")

            time.sleep(UPDATE_INTERVAL)

    def stop(self):
        """Stop the watcher."""
        log("Stopping Context Watcher...")
        self.running = False
        if self.file_watcher:
            self.file_watcher.stop()
        self._cleanup()

    def on_file_change(self, path: str, action: str):
        """Called when a file changes."""
        self.state["recent_files"].insert(0, {
            "path": path,
            "action": action,
            "time": datetime.now().strftime("%H:%M:%S"),
            "timestamp": datetime.now().isoformat(),
        })
        # Keep limited history
        self.state["recent_files"] = self.state["recent_files"][:MAX_RECENT_FILES]

    def _update_state(self):
        """Update the full state."""
        now = datetime.now()

        # Get cont home
        cont_home = ""
        home_file = CONT_CONFIG_DIR / "HOME"
        if home_file.exists():
            cont_home = home_file.read_text().strip()

        self.state["timestamp"] = now.isoformat()
        self.state["uptime_seconds"] = int(time.time() - self._start_time)

        # Location
        cwd = os.getcwd()
        self.state["location"] = {
            "cwd": cwd,
            "cont_home": cont_home,
            "in_cont_home": cont_home and cwd.startswith(cont_home),
        }

        # Commands (from bash history)
        self.state["recent_commands"] = get_recent_bash_history(MAX_RECENT_COMMANDS)

        # Git status (for cont home if available)
        if cont_home and Path(cont_home).exists():
            git_status = get_git_status(Path(cont_home))
            if git_status:
                self.state["git_status"] = git_status

        # Environment
        self.state["environment"] = get_environment()

        # Running services
        self.state["running_services"] = get_running_services()

        # System stats
        self.state["system"] = get_system_stats()

    def _write_state(self):
        """Write state to file."""
        try:
            STATE_FILE.write_text(json.dumps(self.state, indent=2, default=str))
        except Exception as e:
            log(f"Failed to write state: {e}")

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        log(f"Received signal {signum}")
        self.stop()
        sys.exit(0)

    def _cleanup(self):
        """Cleanup on exit."""
        try:
            if PID_FILE.exists():
                PID_FILE.unlink()
        except Exception:
            pass
        log("Context Watcher stopped")


def daemonize():
    """Fork into background daemon."""
    # First fork
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as e:
        sys.stderr.write(f"Fork #1 failed: {e}\n")
        sys.exit(1)

    # Decouple from parent
    os.chdir("/")
    os.setsid()
    os.umask(0)

    # Second fork
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as e:
        sys.stderr.write(f"Fork #2 failed: {e}\n")
        sys.exit(1)

    # Redirect standard file descriptors
    sys.stdout.flush()
    sys.stderr.flush()

    with open("/dev/null", "r") as devnull:
        os.dup2(devnull.fileno(), sys.stdin.fileno())

    # Redirect stdout/stderr to log
    WATCHER_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as log_file:
        os.dup2(log_file.fileno(), sys.stdout.fileno())
        os.dup2(log_file.fileno(), sys.stderr.fileno())


def get_pid() -> Optional[int]:
    """Get running watcher PID."""
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            # Check if process is running
            os.kill(pid, 0)
            return pid
        except (ValueError, ProcessLookupError, PermissionError):
            # Process not running, clean up stale PID file
            try:
                PID_FILE.unlink()
            except Exception:
                pass
    return None


def cmd_start(foreground: bool = False):
    """Start the watcher."""
    pid = get_pid()
    if pid:
        print(f"Watcher already running (PID: {pid})")
        return

    if not foreground:
        print("Starting watcher in background...")
        daemonize()
    else:
        print("Starting watcher in foreground (Ctrl+C to stop)...")

    watcher = ContextWatcher()
    watcher.start()


def cmd_stop():
    """Stop the watcher."""
    pid = get_pid()
    if not pid:
        print("Watcher is not running")
        return

    print(f"Stopping watcher (PID: {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        print("Watcher stopped")
    except ProcessLookupError:
        print("Process not found")
        try:
            PID_FILE.unlink()
        except Exception:
            pass


def cmd_status():
    """Show watcher status."""
    pid = get_pid()

    if pid:
        print(f"Watcher is running (PID: {pid})")
    else:
        print("Watcher is not running")

    # Show state file info
    if STATE_FILE.exists():
        try:
            state = json.loads(STATE_FILE.read_text())
            ts = state.get("timestamp", "unknown")
            print(f"\nLast update: {ts}")
            print(f"Recent files: {len(state.get('recent_files', []))}")
            print(f"Recent commands: {len(state.get('recent_commands', []))}")
        except Exception:
            pass
    else:
        print("\nNo state file found")

    # Show log tail
    if LOG_FILE.exists():
        print(f"\nRecent log ({LOG_FILE}):")
        try:
            lines = LOG_FILE.read_text().splitlines()[-5:]
            for line in lines:
                print(f"  {line}")
        except Exception:
            pass


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python cont_watcher.py <start|stop|status|foreground>")
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "start":
        cmd_start(foreground=False)
    elif cmd == "foreground":
        cmd_start(foreground=True)
    elif cmd == "stop":
        cmd_stop()
    elif cmd == "status":
        cmd_status()
    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python cont_watcher.py <start|stop|status|foreground>")
        sys.exit(1)


if __name__ == "__main__":
    main()
