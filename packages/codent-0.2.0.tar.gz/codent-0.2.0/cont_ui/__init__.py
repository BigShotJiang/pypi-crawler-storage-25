"""Cont Web UI - browser-based interface for Cont AI agent."""
