"""
Cont Web UI Backend.

Bridges the browser to Cont's core functionality via WebSocket.

Install: pip install fastapi uvicorn websockets --break-system-packages
Run: python -m cont_ui.server
Or: cont --ui
"""

import asyncio
import json
import sys
import threading
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
import uvicorn

# Add parent dir to path so we can import cont
_PARENT = str(Path(__file__).resolve().parent.parent)
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

app = FastAPI(title="Cont UI")

# Active WebSocket connections
active_connections: list[WebSocket] = []

# Per-connection escalation queues
_escalation_queues: dict[int, asyncio.Queue] = {}


# ── Frontend ──

@app.get("/")
async def serve_frontend():
    """Serve the single-file frontend."""
    html_path = Path(__file__).parent / "frontend.html"
    return HTMLResponse(html_path.read_text(encoding="utf-8"))


@app.get("/manifest.json")
async def serve_manifest():
    """PWA manifest for standalone mode."""
    manifest = {
        "name": "Cont",
        "short_name": "Cont",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#1a1714",
        "theme_color": "#e8a849",
        "icons": [
            {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
            {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
        ]
    }
    return JSONResponse(manifest)


@app.get("/icon-{size}.png")
async def serve_icon(size: int):
    """Generate a golden C icon on dark background."""
    import base64, io
    try:
        from PIL import Image, ImageDraw, ImageFont
        img = Image.new("RGB", (size, size), "#1a1714")
        draw = ImageDraw.Draw(img)
        # Draw golden circle background
        margin = size // 8
        draw.ellipse(
            [margin, margin, size - margin, size - margin],
            fill="#e8a849"
        )
        # Draw C letter
        font_size = int(size * 0.5)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), "C", font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        draw.text(((size - tw) / 2, (size - th) / 2 - bbox[1]), "C", fill="#1a1714", font=font)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return Response(content=buf.getvalue(), media_type="image/png")
    except ImportError:
        # Fallback: return a tiny 1x1 PNG if Pillow not available
        # (browsers handle missing icons gracefully)
        return Response(
            content=base64.b64decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
            ),
            media_type="image/png"
        )


# ── Status API ──

# Cache resolved model name so we don't spam "Using sticky model" on every poll
_cached_model_name: str = ""


@app.get("/api/status")
async def get_status():
    """Return current Cont status for sidebar."""
    global _cached_model_name
    try:
        from cont import _db_connect, MODEL, REPO_ROOT, resolve_model
        from core.recipes import load_recipes
        from core.vocabulary import load_vocabulary
        from core.prompt_patches import load_file_patches
        from core.escalation import get_escalation

        model_name = MODEL or _cached_model_name
        if not model_name:
            try:
                model_name = resolve_model()
                _cached_model_name = model_name
            except Exception:
                # Fallback to sticky model from config
                try:
                    from cont import _get_sticky_model
                    model_name = _get_sticky_model() or "unknown"
                except Exception:
                    model_name = "unknown"

        # Memory count
        memory_count = 0
        try:
            db = _db_connect()
            cur = db.cursor()
            cur.execute("SELECT COUNT(*) FROM semantic_memory")
            memory_count = cur.fetchone()[0]
            db.close()
        except Exception:
            pass

        # Today's tasks
        today_tasks = 0
        success_rate = 0
        try:
            db = _db_connect()
            cur = db.cursor()
            cur.execute(
                "SELECT COUNT(*), AVG(CASE WHEN success=1 THEN 100.0 ELSE 0 END) "
                "FROM task_outcome WHERE date(created_at)=date('now')"
            )
            row = cur.fetchone()
            today_tasks = row[0] or 0
            success_rate = int(row[1] or 0)
            db.close()
        except Exception:
            pass

        recipes = load_recipes()
        vocab = load_vocabulary()
        patches = load_file_patches()

        claude_available = False
        try:
            esc = get_escalation()
            claude_available = esc.is_available
        except Exception:
            pass

        # Today's feedback counts
        feedback_good = feedback_mid = feedback_bad = 0
        try:
            db2 = _db_connect()
            fb_rows = db2.execute("""
                SELECT rating, COUNT(*) FROM task_feedback
                WHERE source = 'user' AND date(created_at) = date('now')
                GROUP BY rating
            """).fetchall()
            for r in fb_rows:
                if r[0] == 3: feedback_good = r[1]
                elif r[0] == 2: feedback_mid = r[1]
                elif r[0] == 1: feedback_bad = r[1]
            db2.close()
        except Exception:
            pass

        # System map stats
        map_stats = {}
        try:
            from core.system_map import get_stats as map_get_stats
            map_stats = map_get_stats()
        except Exception:
            pass

        return {
            "model": model_name,
            "claude_available": claude_available,
            "memory_count": memory_count,
            "recipe_count": len(recipes),
            "vocabulary_count": len(vocab.get("commands", {})),
            "patch_count": len(patches),
            "success_rate": success_rate,
            "today_tasks": today_tasks,
            "feedback_good": feedback_good,
            "feedback_mid": feedback_mid,
            "feedback_bad": feedback_bad,
            "map": map_stats,
        }
    except Exception as e:
        return {"error": str(e)}


# ── Recipes API ──

@app.get("/api/recipes")
async def get_recipes():
    """List all recipes."""
    try:
        from core.recipes import load_recipes
        recipes = load_recipes()
        return {"recipes": [
            {"name": r.get("name", "?"), "description": r.get("description", ""),
             "trigger": r.get("trigger", "")}
            for r in recipes
        ]}
    except Exception as e:
        return {"error": str(e)}


# ── Memory API ──

@app.get("/api/memory")
async def search_memory(q: str = Query("", description="Search query")):
    """Search semantic memory."""
    try:
        from cont import memory_recall
        if not q.strip():
            return {"memories": []}
        results = memory_recall(q, limit=20)
        return {"memories": [
            {"id": r.get("id"), "content": r.get("content", ""),
             "type": r.get("memory_type", ""), "source": r.get("source", ""),
             "created_at": r.get("created_at", "")}
            for r in results
        ]}
    except Exception as e:
        return {"error": str(e)}


# ── History API ──

@app.get("/api/history")
async def get_history(limit: int = Query(50, ge=1, le=200)):
    """Recent task outcomes."""
    try:
        from cont import _db_connect
        db = _db_connect()
        cur = db.cursor()
        cur.execute(
            "SELECT id, task_text, task_type, success, failure_reason, "
            "tool_calls_count, duration_ms, model_used, created_at "
            "FROM task_outcome ORDER BY created_at DESC LIMIT ?",
            (limit,)
        )
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, row)) for row in cur.fetchall()]
        db.close()
        return {"history": rows}
    except Exception as e:
        return {"error": str(e)}


# ── Feedback API ──

@app.post("/api/feedback")
async def post_feedback(request: Request):
    """Submit user feedback for a task."""
    try:
        data = await request.json()
        task_id = data.get("task_id")
        rating = data.get("rating")
        note = data.get("note")

        if not task_id:
            return {"ok": False, "error": "task_id required"}

        from cont import _db_connect, memory_init_db
        memory_init_db()
        db = _db_connect()
        db.execute("""
            INSERT INTO task_feedback (task_outcome_id, source, rating, note)
            VALUES (?, 'user', ?, ?)
        """, (task_id, rating, note))
        db.commit()

        # Trigger learning for bad feedback
        if rating and rating <= 1:
            try:
                from cont import _process_feedback_for_learning
                _process_feedback_for_learning(task_id)
            except Exception:
                pass

        db.close()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.get("/api/feedback/stats")
async def feedback_stats():
    """Feedback statistics for last 7 days."""
    try:
        from cont import _db_connect
        db = _db_connect()

        # Daily averages
        daily = db.execute("""
            SELECT date(created_at) as day, source,
                   AVG(rating) as avg_rating, COUNT(*) as count
            FROM task_feedback
            WHERE created_at > datetime('now', '-7 days')
            GROUP BY day, source ORDER BY day
        """).fetchall()

        # Top issues
        issues = db.execute("""
            SELECT note, COUNT(*) as cnt
            FROM task_feedback
            WHERE note IS NOT NULL AND created_at > datetime('now', '-7 days')
            GROUP BY note ORDER BY cnt DESC LIMIT 10
        """).fetchall()

        # Today's counts by rating
        today = db.execute("""
            SELECT rating, COUNT(*) as cnt
            FROM task_feedback
            WHERE source = 'user' AND date(created_at) = date('now')
            GROUP BY rating
        """).fetchall()

        db.close()

        today_counts = {str(r[0]): r[1] for r in today}
        return {
            "daily": [{"day": r[0], "source": r[1], "avg": round(r[2], 1) if r[2] else 0, "count": r[3]} for r in daily],
            "issues": [{"note": r[0], "count": r[1]} for r in issues],
            "today": {
                "good": today_counts.get("3", 0),
                "mid": today_counts.get("2", 0),
                "bad": today_counts.get("1", 0),
            }
        }
    except Exception as e:
        return {"error": str(e)}


# ── WebSocket Chat ──

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Main chat WebSocket."""
    await websocket.accept()
    ws_id = id(websocket)
    active_connections.append(websocket)
    _escalation_queues[ws_id] = asyncio.Queue()

    try:
        while True:
            data = await websocket.receive_json()

            if data.get("type") == "message":
                task_text = data.get("text", "").strip()
                if task_text:
                    asyncio.create_task(
                        process_task(websocket, task_text)
                    )

            elif data.get("type") == "escalation_response":
                approved = data.get("approved", False)
                queue = _escalation_queues.get(ws_id)
                if queue:
                    await queue.put(approved)

    except WebSocketDisconnect:
        if websocket in active_connections:
            active_connections.remove(websocket)
        _escalation_queues.pop(ws_id, None)


async def process_task(ws: WebSocket, task: str):
    """
    Process a user task and send events via WebSocket.
    Bridges async WebSocket to synchronous run_task() via thread + queue.
    """
    loop = asyncio.get_event_loop()
    events: asyncio.Queue = asyncio.Queue()
    ws_id = id(ws)
    esc_queue = _escalation_queues.get(ws_id)

    def event_callback(event: dict):
        """Called from run_task thread, puts events on async queue."""
        loop.call_soon_threadsafe(events.put_nowait, event)

        # If this is an escalation, wait for user response
        if event.get("type") == "escalation" and esc_queue:
            try:
                approved = asyncio.run_coroutine_threadsafe(
                    esc_queue.get(), loop
                ).result(timeout=120)
                # Store on the event callback so run_task can read it
                event_callback._escalation_result = approved
            except Exception:
                event_callback._escalation_result = False

    event_callback._escalation_result = None

    def task_runner():
        """Runs in a thread."""
        try:
            from cont import run_task
            run_task(task, event_callback=event_callback)
        except Exception as e:
            loop.call_soon_threadsafe(
                events.put_nowait,
                {"type": "error", "text": str(e)}
            )
        finally:
            loop.call_soon_threadsafe(
                events.put_nowait,
                {"type": "done"}
            )

    # Start task in thread
    thread = threading.Thread(target=task_runner, daemon=True)
    thread.start()

    # Forward events to WebSocket
    done = False
    while not done:
        try:
            event = await asyncio.wait_for(events.get(), timeout=300)
            try:
                await ws.send_json(event)
            except Exception:
                break
            if event.get("type") in ("done",):
                done = True
        except asyncio.TimeoutError:
            # Task took too long
            try:
                await ws.send_json({"type": "error", "text": "Zaman aşımı (5 dakika)"})
                await ws.send_json({"type": "done"})
            except Exception:
                pass
            break


# ── Entry point ──

def _kill_port(port: int):
    """Kill any process using the given port."""
    try:
        import subprocess as _sp
        result = _sp.run(['lsof', '-ti', f':{port}'],
                         capture_output=True, text=True)
        if result.stdout.strip():
            for pid in result.stdout.strip().split('\n'):
                pid = pid.strip()
                if pid:
                    _sp.run(['kill', '-9', pid], capture_output=True)
            import time
            time.sleep(0.5)
            print(f"   Killed existing process on port {port}")
    except Exception:
        pass


def main(port: int = 8550):
    """Start the Cont UI server."""
    _kill_port(port)
    print(f"Cont UI starting at http://localhost:{port}")
    print("   Press Ctrl+C to stop\n")
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    main()
