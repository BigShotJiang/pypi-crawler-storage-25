# kneo-serv (name placeholder)

This 0.0.0 release reserves the `kneo-serv` name on PyPI for the **Kneo
Agent Platform** service / control-plane package.

This package does **not** install a working service. It is intentionally
empty pending the first real release.

The real `kneo-serv` ships starting at **0.2.0**. Until then, see the
[GitHub repository](https://github.com/kneo-agent/kneo-serv) for source
and release artifacts.
