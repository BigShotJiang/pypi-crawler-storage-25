"""kneo-serv 0.0.0 — name placeholder.

This release reserves the `kneo-serv` name on PyPI. The real Kneo Agent
Platform service / control-plane package ships starting at 0.2.0. See
https://github.com/kneo-agent/kneo-serv for source and release artifacts.
"""

__version__ = "0.0.0"
