"""FastMCP stdio server: tools call the KomAInu API over HTTP only."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from komainu_mcp import client

mcp = FastMCP("KomAInu")


@mcp.tool(
    description="List all requirement IDs that have been analyzed, with their last analysis date.",
)
async def list_all_requirements() -> str:
    return await client.get_list_all_requirements()


@mcp.tool(
    description=(
        "Get the description and generated test cases for a specific requirement. "
        "Args: req_name — the requirement ID (e.g. 'REQ-001')."
    ),
)
async def get_requirement_details(req_name: str) -> str:
    return await client.get_requirement_details(req_name)


@mcp.tool(
    description=(
        "Get the coverage analysis for a requirement — which test cases are present "
        "in the codebase. Args: req_name — the requirement ID (e.g. 'REQ-001')."
    ),
)
async def get_requirement_coverage(req_name: str) -> str:
    return await client.get_requirement_coverage(req_name)


@mcp.tool(
    description=(
        "Get a high-level summary of test coverage across all analyzed requirements."
    ),
)
async def get_coverage_summary() -> str:
    return await client.get_coverage_summary()


def run() -> None:
    mcp.run(transport="stdio")
