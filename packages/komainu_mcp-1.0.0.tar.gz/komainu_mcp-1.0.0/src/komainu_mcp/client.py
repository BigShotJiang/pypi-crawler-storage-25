"""HTTP client for KomAInu `/tools` endpoints (backend is the only DB layer)."""

from __future__ import annotations

import os
from urllib.parse import quote

import httpx


def _base_url() -> str:
    raw = os.environ.get("KOMAINU_API_BASE_URL", "").strip()
    if not raw:
        msg = (
            "KOMAINU_API_BASE_URL is not set. Set it to your KomAInu API base URL "
            "(e.g. https://your-service.up.railway.app)."
        )
        raise RuntimeError(msg)
    return raw.rstrip("/")


def _headers() -> dict[str, str]:
    key = os.environ.get("KOMAINU_TOOLS_API_KEY", "").strip()
    if key:
        return {"Authorization": f"Bearer {key}"}
    return {}


async def get_list_all_requirements() -> str:
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.get(
            f"{_base_url()}/tools/list-all-requirements",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.text


async def get_requirement_details(req_name: str) -> str:
    enc = quote(req_name, safe="")
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.get(
            f"{_base_url()}/tools/requirements/{enc}/details",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.text


async def get_requirement_coverage(req_name: str) -> str:
    enc = quote(req_name, safe="")
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.get(
            f"{_base_url()}/tools/requirements/{enc}/coverage",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.text


async def get_coverage_summary() -> str:
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.get(
            f"{_base_url()}/tools/coverage-summary",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.text
