"""Entry point for `python -m komainu_mcp`."""

from __future__ import annotations

from komainu_mcp.server import run


def main() -> None:
    """Run the KomAInu MCP server (stdio)."""
    run()


if __name__ == "__main__":
    main()
