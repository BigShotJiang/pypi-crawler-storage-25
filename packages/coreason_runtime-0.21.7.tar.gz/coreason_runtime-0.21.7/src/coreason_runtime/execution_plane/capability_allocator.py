# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import TYPE_CHECKING, Any

try:
    from coreason_manifest.utils.algebra import compute_merkle_directory_cid
except ImportError:
    # Fallback for environments where coreason-manifest is not yet updated.
    # This is a verbatim copy of the canonical implementation from coreason-manifest.
    import hashlib

    def compute_merkle_directory_cid(file_contents: dict[str, bytes]) -> str:  # type: ignore[misc]
        """Merkle-style SHA-256 CID (local fallback)."""
        file_hashes: list[str] = []
        for filename in sorted(file_contents.keys()):
            file_hash = hashlib.sha256(file_contents[filename]).hexdigest()
            file_hashes.append(f"{filename}:{file_hash}")
        merkle_input = "\n".join(file_hashes).encode("utf-8")
        return f"sha256:{hashlib.sha256(merkle_input).hexdigest()}"


from coreason_runtime.utils.exceptions import IntegrityViolationError

if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest


def verify_bundle_integrity(bundle_files: dict[str, bytes], expected_hash: str | None) -> bool:
    """Zero-trust Merkle verification: recompute the CID and compare to the registry.

    Delegates the Merkle hash to ``compute_merkle_directory_cid()`` from the
    shared kernel (``coreason-manifest``) — the single canonical implementation
    used across the entire CoReason ecosystem.

    If the expected_hash is None or empty (e.g. DRAFT capabilities that have not
    yet been compiled), verification is skipped and the function returns True.

    Args:
        bundle_files: Mapping of canonical filenames to their raw bytes.
            Expected keys: ``__init__.py``, ``manifest.yaml``, ``schema.py``, ``server.py``.
            For ``manifest.yaml``, pass the bytes with ``cryptographic_hash``
            set to null (matching the compilation-side zeroing).
        expected_hash: The sha256-prefixed hex digest from the compiled registry.

    Returns:
        True if verification passes.

    Raises:
        IntegrityViolationError: If the computed hash does not match the expected hash.
    """
    if not expected_hash:
        return True  # DRAFT capabilities skip verification

    actual = compute_merkle_directory_cid(bundle_files)

    if actual != expected_hash:
        raise IntegrityViolationError(
            f"Bundle CID mismatch. Expected {expected_hash}, got {actual}. Possible supply-chain attack or stale cache."
        )
    return True


def dynamic_capability_injection(
    action_space: CognitiveActionSpaceManifest, mounted_capability: dict[str, Any]
) -> CognitiveActionSpaceManifest:
    """
    Dynamically appends a discovered capability to the agent's CognitiveActionSpaceManifest at runtime.
    Do not require a restart of the node.
    """
    from coreason_manifest import MCPCapabilityWhitelistPolicy, MCPServerManifest, StdioTransportProfile

    capability_name = mounted_capability.get("name", "dynamic_tool")

    action_space.capabilities[capability_name] = MCPServerManifest.model_construct(
        server_cid="dynamic_mcp_pool",
        binary_hash=str(mounted_capability.get("binary_hash", "")),
        transport=StdioTransportProfile.model_construct(command="extism", args=[]),
        capability_whitelist=MCPCapabilityWhitelistPolicy.model_construct(),
        attestation_receipt=None,  # type: ignore[arg-type]
    )

    return action_space
