import json
import os
import re
from pathlib import Path

from coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp import NemoClawBridgeClient
from coreason_runtime.utils.logger import logger

# Canonical URN regex — synchronized with ActionSpaceURNState in
# coreason_manifest.spec.ontology.  Used to validate fabricated URNs.
_ACTIONSPACE_URN_PATTERN = re.compile(
    r"^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
)


class IntentFabricator:
    """
    Handles the Intent-Based Dynamic Solver URN Fabrication.
    Uses the Kinetic FSM compiler to extract epistemic intents and physically
    scaffold them into the ecosystem using the Universal Asset Forge (MCP).
    """

    def __init__(
        self,
        meta_dir: str | None = None,
        model_name: str | None = None,
    ) -> None:
        # Determine the coreason-meta-engineering directory
        if meta_dir:
            self.meta_dir = Path(meta_dir).resolve()
        elif "COREASON_META_DIR" in os.environ:
            self.meta_dir = Path(os.environ["COREASON_META_DIR"]).resolve()
        else:
            # Fallback assuming it's an adjacent repository
            self.meta_dir = (Path.cwd().parent / "coreason-meta-engineering").resolve()
            if not self.meta_dir.exists():
                logger.warning(
                    f"Fallback meta-dir not found at {self.meta_dir}. "
                    "Ensure you are running this from adjacent to coreason-meta-engineering, "
                    "or set COREASON_META_DIR / pass --meta-dir."
                )

        # Fallback model to Qwen if nothing is set in the environment or passed
        self.model_name = model_name or os.getenv("OUTLINES_MODEL", "Qwen/Qwen2.5-32B-Instruct-AWQ")
        self.client = None  # Removed OutlinesKineticClient

    async def setup_mcp_manager(self) -> NemoClawBridgeClient:
        """Sets up the MCP Manager targeting the Universal Asset Forge."""
        # Note: In Proxy-First architecture, the Agentic Forge must be
        # registered with the NemoClaw proxy. We no longer manage
        # local transport manifests here.
        return NemoClawBridgeClient()

    async def fabricate(self, human_intent: str) -> None:
        """Executes the 3-phase Intent-Based Fabrication process."""
        logger.info("=== PHASE 1: GENERATE INTENT VIA LLM + FSM ===")
        logger.info(f"[Human Intent]: {human_intent}")

        original_cwd = os.getcwd()
        try:
            # Change to the meta engineering directory so the MCP server works natively
            os.chdir(str(self.meta_dir))
            manager = await self.setup_mcp_manager()

            # 1. Fetch exact geometric schema from MCP server
            mcp_tools_resp = await manager.get_client("agentic_forge").request("tools/list", {})
            forge_schema_dict = None
            for t in mcp_tools_resp.get("tools", []):
                if t.get("name") == "scaffold_logic_actuator":
                    forge_schema_dict = t.get("inputSchema")
                    break

            if not forge_schema_dict:
                raise ValueError("Could not find 'scaffold_logic_actuator' on the MCP server.")

            logger.info("Executing Physical DFA Logit Masking using dynamic MCP Schema...")

            if self.client:
                raw_json, _, _ = await self.client.generate(
                    "Universal Asset Forge prompt", forge_schema_dict, constrained_decoding=True
                )
            else:
                raw_json = '{"actuator_name": "dummy", "action_space_id": "urn:coreason:actionspace:solver:dummy:v1", "target_file_path": "dummy.py", "return_type": "float", "geometric_schema": {}, "required_imports": []}'

            payload_dict = json.loads(raw_json)
            logger.info("Generated Epistemic Intent Payload:\n" + json.dumps(payload_dict, indent=2))

            logger.info("\n=== PHASE 2: FABRICATING URN VIA MCP ===")

            # Validate/normalize URN to match ActionSpaceURNState regex.
            # If the LLM generated an incomplete URN, attempt to fixup;
            # otherwise accept any valid multi-authority actionspace URN.
            action_id = payload_dict["action_space_id"]
            if not _ACTIONSPACE_URN_PATTERN.match(action_id):
                # Attempt fixup: prepend authority + actionspace + infer category
                if not action_id.startswith("urn:"):
                    action_id = f"urn:coreason:actionspace:solver:{action_id}:v1"
                payload_dict["action_space_id"] = action_id

            # Sanitize actuator name to be a valid python identifier
            actuator_name = payload_dict["actuator_name"].removesuffix(".py")
            actuator_name = re.sub(r"[^a-zA-Z0-9_]", "", actuator_name.lower().replace(" ", "_"))
            payload_dict["actuator_name"] = actuator_name

            # Ensure filename is safe and ends with .py
            filename = os.path.basename(payload_dict["target_file_path"])
            if not filename.endswith(".py") or filename.startswith("*"):
                filename = f"{actuator_name}.py"

            # Always resolve back relative to the coreason-runtime workspace, regardless of LLM hallucination
            target_path = os.path.abspath(
                os.path.join(
                    original_cwd,
                    "src/coreason_runtime/execution_plane/actuators",
                    filename,
                )
            )
            payload_dict["target_file_path"] = target_path

            logger.info(f"Triggering 'scaffold_logic_actuator' over MCP to generate: {target_path}")

            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            with open(target_path, "w") as f:
                f.write("# LLM Intent-based Actuator\n")

            result = await manager.call_tool(
                server_cid="agentic_forge",
                name="scaffold_logic_actuator",
                arguments=payload_dict,
            )

            logger.info("\n=== URN FABRICATION COMPLETE ===")
            logger.info(f"MCP Server Response: {result}")

            with open(target_path) as f:
                scaffolded_code = f.read()

            logger.info("\n=== PHASE 3: LOGIC REFINEMENT (INJECTING CODE) ===")

            (
                f"You are injecting physical logic into a newly fabricated tool.\n"
                f"Human Intent: {human_intent}\n"
                f"Tool Name: {payload_dict['actuator_name']}\n"
                f"Parameters: {payload_dict['geometric_schema']}\n"
                "Write ONLY the internal Python logic for this. DO NOT include the `def` signature. "
                "Assume the parameters are already available in the local scope. Just return the Python code string."
            )
            logger.info("Executing Physical DFA Logit Masking for Logic Refinement (Native Dict)...")

            if self.client:
                raw_logic_json, _, _ = await self.client.generate(
                    "Logic Refinement prompt", {}, constrained_decoding=True
                )
            else:
                raw_logic_json = '{"python_code": "pass"}'

            logic_payload = json.loads(raw_logic_json)
            injected_logic = logic_payload["python_code"].replace("\\n", "\n")
            indented_logic = "\n".join([f"    {line}" for line in injected_logic.strip().split("\n")])

            logger.info("\nInjecting logic into the scaffold...")
            final_code = scaffolded_code.replace("    pass\n", f"{indented_logic}\n")

            with open(target_path, "w") as f:
                f.write(final_code)

            logger.info("\n=== FULLY HYDRATED KINETIC ACTUATOR ===")
            logger.info(f"\n{final_code}")

        except Exception as e:
            logger.error(f"Fabrication failed: {e}")
            raise
        finally:
            os.chdir(original_cwd)
