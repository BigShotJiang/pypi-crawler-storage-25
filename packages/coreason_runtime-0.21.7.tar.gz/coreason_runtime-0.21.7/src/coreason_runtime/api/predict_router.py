# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import os
import uuid
from typing import Any, cast

from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse

# Load .env so CLOUD_ORACLE_* vars are available whether the server is
# started via `coreason serve` (which doesn't call load_dotenv) or directly.
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass  # python-dotenv is optional; env vars may be set externally

import instructor
from coreason_manifest import CognitiveAgentNodeProfile
from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam

from coreason_runtime.api.schema import TopologySynthesisRequest
from coreason_runtime.execution_plane.discovery_indexer import DiscoveryIndexer
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_COMPUTE_BUDGET

predict_router = APIRouter(prefix="/api/v1/predict", tags=["Topology Synthesis"])


def _build_synthesis_prompt(topology_dict: dict[str, Any] | None, user_prompt: str, discovery_context: str = "") -> str:
    """Build the LLM prompt for agent synthesis, topology-aware."""
    topology_dict = topology_dict or {}
    topology_section = topology_dict.get("topology", {})
    existing_nodes = topology_section.get("nodes", {})
    topology_type = topology_section.get("type", "unknown")
    existing_summary = (
        "\n".join(f"  - {nid}: {props.get('description', '(no description)')}" for nid, props in existing_nodes.items())
        if existing_nodes
        else "  (No existing agents. This is a blank canvas.)"
    )

    # Instructor natively handles Pydantic schema injection via function calling,
    # so we do not need to manually append a JSON schema string to the prompt.
    user_prompt = user_prompt.strip() if isinstance(user_prompt, str) else ""
    user_hint = f"\nUser intent: {user_prompt}" if user_prompt else ""

    if user_prompt:
        rule_3 = (
            "The 'description' field MUST contain the exact, full instruction set provided "
            "in the User intent, preserving all formatting and rules without summarizing them."
        )
    else:
        rule_3 = (
            "The 'description' field MUST provide a detailed, autonomous instruction "
            "for the NEXT logical step in the sequence based on the existing agents."
        )

    topology_context = (
        f"You are currently building within a '{topology_type}' topology domain.\n"
        f"Ensure the new agent strictly adheres to the physical constraints of this domain."
    )

    return (
        f"You are a CoReason topology architect. "
        f"Given the existing swarm topology below, predict the single best NEXT agent node to add.{user_hint}\n"
        f"IMPORTANT DIAGNOSTICS: {discovery_context}\n\n"
        f"{topology_context}\n"
        f"Existing nodes:\n{existing_summary}\n\n"
        f"Rules:\n"
        f"1. node_cid MUST match the DID pattern: ^did:[a-z0-9]+:[a-zA-Z0-9.\\-_:]+$\n"
        f"2. type MUST be 'agent'.\n"
        f"3. {rule_3}\n"
        f"4. The node_cid must be unique and not duplicate any existing node.\n"
        f"5. The new agent MUST be contextually appropriate for the '{topology_type}' topology domain.\n"
        f"6. ANTI-CRUD: Do NOT use legacy terms like 'Create', 'Update', 'Delete', 'Manager' in node names. Use causal terms (e.g., 'Synthesizer', 'Transmuter', 'Validator').\n"
        f"7. When generating the 'description' field, you MUST explicitly instruct the agent "
        f"that its final JSON response must be a stringified JSON block "
        f"wrapped inside a required root 'output' key."
    )


def _load_dspy_optimized_messages(
    topology_dict: dict[str, Any] | None, user_prompt: str, discovery_context: str = ""
) -> list[ChatCompletionMessageParam]:
    """Loads the compiled DSPy JSON artifact to construct an optimized multi-turn message array.
    Falls back to the legacy _build_synthesis_prompt string if the artifact doesn't exist.
    """
    import json
    import os

    topology_dict = topology_dict or {}
    topology_section = topology_dict.get("topology", {})
    existing_nodes = topology_section.get("nodes", {})
    topology_type = topology_section.get("type", "unknown")
    existing_summary = (
        "\n".join(f"  - {nid}: {props.get('description', '(no description)')}" for nid, props in existing_nodes.items())
        if existing_nodes
        else "  (No existing agents. This is a blank canvas.)"
    )

    artifact_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "resources", "optimized_synthesis_prompt.json"
    )

    if not os.path.exists(artifact_path):
        prompt = _build_synthesis_prompt(topology_dict, user_prompt, discovery_context)
        return [{"role": "user", "content": prompt}]

    try:
        with open(artifact_path, encoding="utf-8") as f:
            dspy_prog = json.load(f)

        prog_data = dspy_prog.get("prog", dspy_prog)

        # DSPy formatting mapping
        instructions = prog_data.get("signature_instructions", "")
        if not instructions:
            instructions = "You are a CoReason topology architect. Predict the single best NEXT agent node to add to the existing swarm topology based on the user intent and domain type."

        messages: list[Any] = [{"role": "system", "content": instructions}]

        demos = prog_data.get("demos", [])
        for demo in demos:
            demo_user = (
                f"Domain Type: {demo.get('domain_type', '')}\n"
                f"Existing Nodes Summary: {demo.get('existing_nodes_summary', '')}\n"
                f"User Intent: {demo.get('user_intent', '')}\n"
                f"Discovery Context: {demo.get('discovery_context', '')}\n"
            )
            messages.append({"role": "user", "content": demo_user})

            demo_agent = demo.get("next_agent", {})
            demo_assistant = json.dumps(demo_agent) if isinstance(demo_agent, dict) else str(demo_agent)
            messages.append({"role": "assistant", "content": demo_assistant})

        current_request = (
            f"Domain Type: {topology_type}\n"
            f"Existing Nodes Summary: {existing_summary}\n"
            f"User Intent: {user_prompt}\n"
            f"Discovery Context: {discovery_context}\n"
        )
        messages.append({"role": "user", "content": current_request})
        return cast("list[ChatCompletionMessageParam]", messages)
    except Exception as e:
        logger.warning(f"Failed to load DSPy optimized prompt, falling back to manual: {e}")
        prompt = _build_synthesis_prompt(topology_dict, user_prompt, discovery_context)
        return cast("list[ChatCompletionMessageParam]", [{"role": "user", "content": prompt}])


async def _synthesize_expansion(request: TopologySynthesisRequest) -> PlainTextResponse:
    """Synthesize the next agent node for a given topology.

    Accepts the current manifest as raw text (JSON or YAML), uses the Cloud
    Oracle to predict the optimal next agent, merges it into the topology,
    and returns the updated document in the same format (JSON or YAML).
    """
    if isinstance(request.topology, str):
        raw = request.topology.strip()
    elif isinstance(request.topology, dict):
        raw = json.dumps(request.topology)
    else:
        raw = "{}"
    is_json = raw.startswith("{")

    # Parse current topology
    try:
        if is_json:
            topology_dict = json.loads(raw)
        else:
            import yaml

            topology_dict = yaml.safe_load(raw)
    except Exception as exc:
        logger.error(f"Failed to extract metric vector metadata: {exc}")
        raise HTTPException(status_code=422, detail=f"Failed to parse topology: {exc}") from exc

    discovery_context = ""
    is_deficit = False
    discovery_results = []
    if request.user_prompt:
        try:
            indexer = DiscoveryIndexer()
            indexer.sync_local_wasm()
            # Remote MCP discovery is now handled out-of-process by NemoClaw proxy

            discovery_results = indexer.search_capabilities(request.user_prompt, limit=1)
            is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 1.65

            prompt_lower = request.user_prompt.lower() if request.user_prompt else ""
            intent_builds_tool = (
                ("build" in prompt_lower and "tool" in prompt_lower)
                or "create tool" in prompt_lower
                or "make tool" in prompt_lower
            )

            if is_deficit and intent_builds_tool:
                discovery_context = "Semantic deficit! We MUST synthesize a 'system' node mapped explicitly to 'macro_forge' to build/compile missing capabilities."
            elif not is_deficit and discovery_results:
                top_tool = discovery_results[0].get("name", "unknown_tool")
                discovery_context = f"Found MCP/Native capabilities: '{top_tool}'. Output MUST confidently hook into this existing tool pipeline."
            else:
                discovery_context = "No specific isomorphic tools matched. Proceed with standard autonomous reasoning."
        except Exception as e:
            logger.warning(f"Semantic discovery failed during expansion pipeline: {e}")

    try:
        # Initialize OpenTelemetry TracerProvider so instructor's built-in
        # auto-instrumentation emits LLM call spans (model, tokens, latency).
        from coreason_runtime.utils.tracing import get_tracer

        _tracer = get_tracer("coreason-runtime.predict")

        messages = _load_dspy_optimized_messages(topology_dict, request.user_prompt or "", discovery_context)

        client = instructor.from_openai(AsyncOpenAI())
        model_name = os.getenv("COREASON_DEFAULT_MODEL", "gpt-4o")

        # Call the LLM with instructor to enforce the FSM / Schema validation natively
        # instructor handles the retry and validation logic natively
        profile = await client.chat.completions.create(
            model=model_name,
            response_model=CognitiveAgentNodeProfile,
            messages=messages,
            max_retries=3,
        )

        node_payload = profile.model_dump(mode="json")
        usage: dict[str, int] = {}

        # The node_cid serves as the dict key in the topology
        node_cid = node_payload.pop("node_cid", None)
        if not node_cid or not str(node_cid).startswith("did:"):
            node_cid = f"did:coreason:synthesized-agent-{uuid.uuid4().hex[:8]}"

    except Exception as e:
        logger.exception(f"Topology synthesis LLM call failed: {e}")
        raise HTTPException(
            status_code=503,
            detail=f"Synthesis engine failure: LLM inference did not return a valid response. {e}",
        ) from e

    if topology_dict is None:
        topology_dict = {}

    if "topology" not in topology_dict:
        topology_dict["topology"] = {}
    if "nodes" not in topology_dict["topology"]:
        topology_dict["topology"]["nodes"] = {}

    topology_dict["topology"]["nodes"][node_cid] = node_payload

    logger.info(f"Synthesis complete — new node '{node_cid}' added ({'prompt' if usage else 'no'} usage tracked). ")

    # Re-serialise in the original format
    if is_json:
        return PlainTextResponse(content=json.dumps(topology_dict, indent=2))
    import yaml

    return PlainTextResponse(content=yaml.dump(topology_dict, default_flow_style=False, allow_unicode=True))


async def _synthesize_scratch(request: TopologySynthesisRequest) -> dict[str, Any]:
    """Synthesize a complete topology manifest from a raw user prompt, then dispatch.

    Uses a two-phase FSM-constrained approach:
    1. Phase 1: LLM selects the optimal topology type (dag, swarm, council,
       evolutionary, smpc, evaluator_optimizer, digital_twin, macro_adversarial,
       macro_federation, macro_forge, macro_elicitation) based on the user's intent.
    2. Phase 2: Generates the full manifest against the resolved Pydantic schema.
    3. Wraps the manifest in an ExecutionEnvelopeState.
    4. Dispatches the appropriate Temporal workflow.

    Returns:
        A dict with workflow_id, manifest_type, and node_count.
    """

    # Step 0: Semantic Interrogation & Zero-Day Forge Fallback
    is_deficit = False
    discovery_results = []

    if "forge" not in (request.topological_manifold_bias or "") and "elicitation" not in (
        request.topological_manifold_bias or ""
    ):
        try:
            indexer = DiscoveryIndexer()
            indexer.sync_local_wasm()

            # Hook the remote MCP server capabilities into the local Discovery namespace
            from coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp import NemoClawBridgeClient

            mcp_client = NemoClawBridgeClient()
            await indexer.sync_remote_mcp(mcp_client)

            discovery_results = indexer.search_capabilities(request.user_prompt or "", limit=1)
            is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 1.25

            if is_deficit:
                logger.warning(
                    "[ZERO-DAY FORGE] Semantic Discovery deficit! No isomorphic tools found for intent. "
                    "Triggering macro_forge..."
                )

                forge_manifest: dict[str, Any] = {}
                _usage: dict[str, int] = {}  # Removed TensorRouter usage

                import typing
                import uuid

                from coreason_manifest import (
                    ExecutionEnvelopeState,
                    JsonPrimitiveState,
                    StateVectorProfile,
                    TraceContextState,
                )
                from temporalio.client import Client

                from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY
                from coreason_runtime.orchestration.worker import TASK_QUEUE

                forge_payload = forge_manifest

                # Securely extract inner topology regardless of LLM wrapper hallucinations
                inner_topology = forge_payload.get("topology", forge_payload)

                u = str(uuid.uuid4())
                forge_trace_id = u[:14] + "7" + u[15:]

                forge_envelope = ExecutionEnvelopeState[dict[str, Any]](
                    trace_context=TraceContextState(trace_cid=forge_trace_id, span_cid=forge_trace_id, causal_clock=0),
                    state_vector=StateVectorProfile(
                        immutable_matrix=typing.cast(
                            "dict[str, JsonPrimitiveState]",
                            {
                                "tenant_cid": getattr(request, "tenant_cid", "default-tenant"),
                                "session_cid": forge_trace_id,
                                "instruction": getattr(request, "user_prompt", None),
                            },
                        ),
                        mutable_matrix=typing.cast(
                            "dict[str, JsonPrimitiveState]",
                            {
                                "accumulated_tokens": 0,
                                "accumulated_cost": 0.0,
                                "iterations": 0,
                                "compute_budget": COREASON_COMPUTE_BUDGET,
                            },
                        ),
                        is_delta=False,
                    ),
                    payload=inner_topology,
                )

                temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
                temporal_client = await Client.connect(temporal_host)
                workflow_func = _WORKFLOW_REGISTRY.get("macro_forge")

                logger.info("Dispatching Forge Workflow to Temporal to explicitly build missing capability...")
                forge_result = await temporal_client.execute_workflow(
                    typing.cast("Any", workflow_func),
                    forge_envelope.model_dump(mode="json"),
                    id=f"forge-{forge_trace_id}",
                    task_queue=TASK_QUEUE,
                )
                logger.info(f"Forge executed successfully: {forge_result}. Resyncing WASM memory...")
                indexer.sync_local_wasm()

                logger.info("Re-evaluating Semantic Discovery against newly forged tools...")
                discovery_results = indexer.search_capabilities(request.user_prompt or "", limit=1)
                is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 0.35

        except Exception as e:
            logger.exception(f"Semantic Discovery / Forge Fallback failed: {e}. Bypassing to blind DAG execution.")

    actual_tool_cid = None
    is_macro_forge = request.topological_manifold_bias == "macro_forge" or (
        request.epistemic_boundary_state and "macro_forge" in request.epistemic_boundary_state.lower()
    )
    if not is_macro_forge and discovery_results and discovery_results[0].get("distance", 2.0) <= 0.35:
        tool_match = discovery_results[0]
        actual_tool_cid = tool_match.get("capability_id") or tool_match.get("name") or str(tool_match)
        logger.info(
            f"Local Isomorphic Tool matched (Distance: {tool_match.get('distance')})! injecting '{actual_tool_cid}' directly into LLM Latent Context."
        )
        forced_ctx = (request.epistemic_boundary_state or "") + (
            f"\n\nCRITICAL ARCHITECTURAL DIRECTIVE:\n"
            f"You MUST ensure at least one agent utilizes the following discovered capability:\n"
            f'action_space_cid: "{actual_tool_cid}"\n'
            f"Description: {tool_match.get('description')}\n"
            f"Integrate this tool into the most appropriate topology for the user's task."
        )
        request.epistemic_boundary_state = forced_ctx

    # Step 1: Synthesize manifest
    import uuid

    manifest_instance: dict[str, Any] = {}

    u = str(uuid.uuid4())
    trace_id = u[:14] + "7" + u[15:]

    logger.warning(f"Manifest failed schema validation! Skipping Temporal dispatch for trace {trace_id}.")
    return manifest_instance


@predict_router.post("/synthesize")
@predict_router.post("/topology")
async def synthesize_topology(request: TopologySynthesisRequest) -> Any:
    """Synthesize a complete manifesto from scratch OR expand the next agent.
    If 'topology' is present, performs expansion. If missing, performs scratch generation.
    """
    if request.topology:
        return await _synthesize_expansion(request)
    scratch_res = await _synthesize_scratch(request)

    import json

    from fastapi import Response

    return Response(content=json.dumps(scratch_res, indent=4), media_type="application/json")
