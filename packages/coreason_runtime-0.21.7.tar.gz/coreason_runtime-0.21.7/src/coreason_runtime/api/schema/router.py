# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import functools
from pathlib import Path
from typing import TYPE_CHECKING, Any

from coreason_manifest import (
    DAGTopologyManifest,
    EpistemicEscalationContract,
    EpistemicQuarantineSnapshot,
    OracleExecutionReceipt,
    SwarmTopologyManifest,
    WorkflowManifest,
)
from fastapi import APIRouter, HTTPException

from coreason_runtime.utils.settings import COREASON_PLUGINS_DIR

if TYPE_CHECKING:
    from pydantic import BaseModel

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware


class JSONDepthLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Any) -> Any:
        if request.method in ("POST", "PUT", "PATCH") and "application/json" in request.headers.get("content-type", ""):
            body = await request.body()
            try:
                import io

                import ijson  # type: ignore[import-untyped]

                parser = ijson.parse(io.BytesIO(body))
                depth = 0
                for _prefix, event, _value in parser:
                    if event in ("start_map", "start_array"):
                        depth += 1
                        if depth > 10:
                            return JSONResponse(
                                status_code=400,
                                content={
                                    "detail": "JSON Payload rejected: nesting depth exceeds maximum allowed of 10."
                                },
                            )
                    elif event in ("end_map", "end_array"):
                        depth -= 1
            except ImportError:
                # Fallback zero-allocation byte scanner guillotine
                depth = 0
                in_str = False
                esc = False
                for byte in body:
                    if esc:
                        esc = False
                    elif byte == 92:  # '\\'
                        esc = True
                    elif byte == 34:  # '"'
                        in_str = not in_str
                    elif not in_str:
                        if byte == 123 or byte == 91:  # '{' or '['
                            depth += 1
                            if depth > 10:
                                return JSONResponse(
                                    status_code=400,
                                    content={
                                        "detail": "JSON Payload rejected: nesting depth exceeds maximum allowed of 10."
                                    },
                                )
                        elif byte == 125 or byte == 93:  # '}' or ']'
                            depth -= 1
            except Exception as e:
                return JSONResponse(status_code=400, content={"detail": f"Malformed JSON Payload: {e}"})

        return await call_next(request)


router = APIRouter(prefix="/api/v1/schema", tags=["Schema Projection"])


# SOTA 2026: Deterministic Memoization. Compile Rust ASTs exactly once per daemon lifecycle.
@functools.lru_cache(maxsize=16)
def _generate_cached_schema(model_name: str) -> dict[str, Any]:
    models: dict[str, type[BaseModel]] = {
        "dag": DAGTopologyManifest,
        "swarm": SwarmTopologyManifest,
        "workflow": WorkflowManifest,
        "receipt": OracleExecutionReceipt,
        "epistemicquarantinesnapshot": EpistemicQuarantineSnapshot,
        "epistemicescalationcontract": EpistemicEscalationContract,
    }
    if model_name not in models:
        msg = f"Unknown topology or schema model: {model_name}"
        raise ValueError(msg)

    # Generates a Draft 2020-12 / OpenAPI compliant schema with $ref resolution
    return models[model_name].model_json_schema(mode="validation")


@router.get("/topology/{topology_type}")
async def get_topology_schema(topology_type: str) -> dict[str, Any]:
    """Returns the deeply nested JSON schema for a specific swarm topology."""
    try:
        return _generate_cached_schema(topology_type.lower())
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e


@router.get("/receipt")
async def get_receipt_schema() -> dict[str, Any]:
    """Returns the schema for an OracleExecutionReceipt."""
    return _generate_cached_schema("receipt")


@router.get("/capabilities")
async def get_capabilities_schema() -> dict[str, Any]:
    """Dynamically introspects the host runtime to list executable WASM tools."""
    plugins_dir = Path(COREASON_PLUGINS_DIR)
    available_tools = []

    if plugins_dir.exists() and plugins_dir.is_dir():
        available_tools = [f.stem for f in plugins_dir.glob("*.wasm")]

    if not available_tools:
        available_tools = ["no_tools_available"]

    # Construct a valid JSON Schema enum dynamically
    return {
        "title": "ExecutableCapabilities",
        "description": "Dynamically discovered executable WASM tools on the host daemon.",
        "type": "string",
        "enum": available_tools,
    }
