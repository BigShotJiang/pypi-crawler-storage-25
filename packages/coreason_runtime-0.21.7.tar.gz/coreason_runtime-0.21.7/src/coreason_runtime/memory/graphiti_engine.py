# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: Graphiti-backed state engine replacing the LanceDB MedallionStateEngine.

This module wraps Zep's Graphiti temporal knowledge graph framework to provide
bi-temporal episodic memory, automatic entity extraction, and hierarchical
community detection — replacing the custom Bronze/Silver/Gold Medallion layers.

CAUSAL AFFORDANCE: Provides the physical connection and lifecycle management
for the Graphiti graph database backend (Neo4j or FalkorDB).

EPISTEMIC BOUNDS: Connection parameters are strictly bounded by environment
variables. The engine is stateless beyond the database driver connection pool.

MCP ROUTING TRIGGERS: Graphiti, Temporal Knowledge Graph, Neo4j Driver,
Graph Database Connection, Epistemic Memory Engine
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.patches import patch_graphiti_queries

if TYPE_CHECKING:
    from graphiti_core import Graphiti


class GraphitiStateEngine:
    """Graphiti-backed state engine providing temporal knowledge graph connectivity.

    AGENT INSTRUCTION: This engine replaces MedallionStateEngine by delegating
    all storage operations to Graphiti's native temporal graph backend. It
    maintains a single Graphiti client instance with configurable LLM and
    embedding providers.

    CAUSAL AFFORDANCE: Exposes the initialized Graphiti client for downstream
    managers (GraphitiEpistemicLedgerManager, GraphitiLatentMemoryManager).

    EPISTEMIC BOUNDS: Connection is bounded by Neo4j URI, auth credentials,
    and optional LLM/embedding client overrides.

    MCP ROUTING TRIGGERS: Graphiti Engine, Neo4j Connection, Graph Driver,
    Temporal State Engine
    """

    def __init__(
        self,
        neo4j_uri: str,
        neo4j_user: str | None = None,
        neo4j_password: str | None = None,
        llm_client: Any | None = None,
        embedder: Any | None = None,
        cross_encoder: Any | None = None,
    ) -> None:
        self.neo4j_uri = neo4j_uri
        self.neo4j_user = neo4j_user
        self.neo4j_password = neo4j_password
        self._llm_client = llm_client
        self._embedder = embedder
        self._cross_encoder = cross_encoder
        self._graphiti: Graphiti | None = None

    @property
    def graphiti(self) -> Graphiti:
        """Lazy-initialize and return the Graphiti client."""
        if self._graphiti is None:
            patch_graphiti_queries()
            from graphiti_core import Graphiti

            kwargs: dict[str, Any] = {
                "uri": self.neo4j_uri,
                "user": self.neo4j_user,
                "password": self.neo4j_password,
            }
            if self._llm_client is not None:
                kwargs["llm_client"] = self._llm_client
            if self._embedder is not None:
                kwargs["embedder"] = self._embedder
            if self._cross_encoder is not None:
                kwargs["cross_encoder"] = self._cross_encoder

            self._graphiti = Graphiti(**kwargs)
            logger.info(f"Graphiti State Engine initialized. Backend: {self.neo4j_uri}")

        return self._graphiti

    async def bootstrap(self) -> None:
        """Build indices and constraints in the graph database."""
        await self.graphiti.build_indices_and_constraints()

        # Build vector indices for Neo4j (Graphiti doesn't do this automatically for standard Neo4j)
        # We use dimensions=1536 as default for OpenAI/standard embeddings.
        try:
            session = self.graphiti.driver.session()
            async with session:
                # Entity name_embedding index
                await session.run(
                    "CREATE VECTOR INDEX entity_name_embeddings IF NOT EXISTS "
                    "FOR (n:Entity) ON (n.name_embedding) "
                    "OPTIONS {indexConfig: {`vector.dimensions`: 1536, `vector.similarity_function`: 'cosine'}}"
                )
                # Community name_embedding index
                await session.run(
                    "CREATE VECTOR INDEX community_name_embeddings IF NOT EXISTS "
                    "FOR (n:Community) ON (n.name_embedding) "
                    "OPTIONS {indexConfig: {`vector.dimensions`: 1536, `vector.similarity_function`: 'cosine'}}"
                )
                # RELATES_TO fact_embedding index
                await session.run(
                    "CREATE VECTOR INDEX relates_to_fact_embeddings IF NOT EXISTS "
                    "FOR ()-[r:RELATES_TO]-() ON (r.fact_embedding) "
                    "OPTIONS {indexConfig: {`vector.dimensions`: 1536, `vector.similarity_function`: 'cosine'}}"
                )

                # Use Graphiti's native utility for range and fulltext indices
                from graphiti_core.utils.maintenance.graph_data_operations import build_indices_and_constraints

                await build_indices_and_constraints(self.graphiti.driver)
        except Exception as e:
            logger.warning(f"Failed to create vector indices: {e}")

        # Eliminate UnknownPropertyKeyWarning by pre-defining properties
        # This is a substrate-hardening step for Neo4j.
        try:
            # We use a dummy transaction to ensure property keys are registered
            session = self.graphiti.driver.session()
            async with session:
                await session.run(
                    "CREATE (n:Episodic {uuid: 'bootstrap-dummy'}) SET n.entity_edges = [] DETACH DELETE n"
                )
        except Exception as e:
            logger.warning(f"Failed to pre-register entity_edges property key: {e}")

        logger.info("Graphiti indices and constraints bootstrapped.")

    async def close(self) -> None:
        """Close the Graphiti driver connection."""
        if self._graphiti is not None:
            await self._graphiti.close()  # type: ignore[no-untyped-call]
            self._graphiti = None
            logger.info("Graphiti State Engine connection closed.")
