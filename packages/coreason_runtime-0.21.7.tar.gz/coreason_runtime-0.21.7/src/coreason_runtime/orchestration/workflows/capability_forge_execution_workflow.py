# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy


import contextlib

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CapabilityForgeExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents the Zero-to-One capability generation loop."""

    def __init__(self) -> None:
        """Initialize CapabilityForgeExecutionWorkflow."""
        super().__init__()
        self._human_approval_attestation: str | None = None

    @workflow.signal(name="approve_forge")
    def approve_forge(self, attestation: str) -> None:
        """Signal handler to receive human approval attestation string."""
        self._human_approval_attestation = attestation

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Capability Forge workflow.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing the CapabilityForgeTopologyManifest (or its unrolled base).

        Returns:
            A dictionary containing the final execution status and results.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting CapabilityForgeExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import CapabilityForgeTopologyManifest

            forge_macro = CapabilityForgeTopologyManifest.model_validate_json(json.dumps(manifest_payload))

            # Anti-Hallucination patch: Ensure macro CIDs are structurally unique to prevent DAG cycles
            updates: dict[str, Any] = {}
            if forge_macro.generator_node_cid == forge_macro.formal_verifier_cid:
                updates["generator_node_cid"] = f"{forge_macro.generator_node_cid}_gen_{workflow.uuid4().hex[:4]}"
                updates["formal_verifier_cid"] = f"{forge_macro.formal_verifier_cid}_ver_{workflow.uuid4().hex[:4]}"

            curr_gen = updates.get("generator_node_cid", forge_macro.generator_node_cid)
            curr_ver = updates.get("formal_verifier_cid", forge_macro.formal_verifier_cid)

            if forge_macro.fuzzing_engine_cid in [curr_gen, curr_ver]:
                updates["fuzzing_engine_cid"] = f"{forge_macro.fuzzing_engine_cid}_fuzz_{workflow.uuid4().hex[:4]}"

            if updates:
                new_nodes = dict(forge_macro.nodes)
                for old_key, new_key in updates.items():
                    if old_key == "nodes":
                        continue
                    old_val = getattr(forge_macro, old_key)
                    if isinstance(old_val, str) and isinstance(new_key, str):
                        orig_node = forge_macro.nodes.get(old_val)
                        if orig_node:
                            new_nodes[new_key] = orig_node
                updates["nodes"] = new_nodes
                forge_macro = forge_macro.model_copy(update=updates)

            manifest = forge_macro.compile_to_base_topology()

            # Rehydrate the LLM-generated node intelligence that was wiped by the base compiler
            for n_id in manifest.nodes:
                if n_id in forge_macro.nodes:
                    manifest.nodes[n_id] = forge_macro.nodes[n_id]

        governance = manifest_payload.get("governance")

        generator_node = None
        verifier_node = None
        agent_node = None

        for node_cid, node_profile in manifest.nodes.items():
            if "generator" in node_cid or getattr(node_profile, "type", "") == "generator":
                generator_node = node_profile
                gen_id = node_cid
            elif "verifier" in node_cid or getattr(node_profile, "type", "") == "formal_verifier":
                verifier_node = node_profile
                ver_id = node_cid
            elif "agent" in node_cid or getattr(node_profile, "topology_class", "") == "agent":
                agent_node = node_profile

        if not generator_node:
            gen_id = next(iter(manifest.nodes.keys()))
            generator_node = manifest.nodes.get(gen_id)

        success = False

        workflow.logger.info("Forge Generation Strategy: Bipartite Proposer-Verifier")
        await workflow.sleep(timedelta(seconds=0.1))

        self.enforce_governance_limits(governance, workflow_start_time)

        with workflow.unsafe.sandbox_unrestricted():
            gen_payload = manifest_payload.get(
                "generator", generator_node.model_dump(mode="json") if generator_node else {}
            )
            if getattr(forge_macro, "target_epistemic_deficit", None):
                gen_payload["target_deficit"] = forge_macro.target_epistemic_deficit.model_dump(mode="json")
            if agent_node and hasattr(agent_node, "description"):
                gen_payload["target_agent_desc"] = agent_node.description

        gen_segregated_payload = {
            "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
            "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
            "node_profile": gen_payload,
        }

        gen_result = await workflow.execute_activity(
            "ExecuteNemoclawSwarmIoActivity",
            args=[{"name": "deploy_cognitive_swarm", "arguments": {"payload": gen_segregated_payload}}],
            schedule_to_close_timeout=timedelta(minutes=5),
            retry_policy=RetryPolicy(maximum_attempts=5),
        )
        usage = gen_result.get("usage", {})
        self._accumulated_tokens += usage.get("total_tokens", 0)
        self._accumulated_cost += gen_result.get("cost", 0.0)
        await self.record_thermodynamic_burn("gen", usage, gen_result.get("cost", 0.0))

        results.append({"node": gen_id, "type": "generation", "result": gen_result})

        self.enforce_governance_limits(governance, workflow_start_time)

        ver_result = {}
        if verifier_node:
            with workflow.unsafe.sandbox_unrestricted():
                ver_payload = manifest_payload.get("verifier", verifier_node.model_dump(mode="json"))
                ver_payload["artifact"] = gen_result

            ver_segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": ver_payload,
            }

            ver_result = await workflow.execute_activity(
                "ExecuteNemoclawSwarmIoActivity",
                args=[
                    {
                        "name": "deploy_cognitive_swarm",
                        "arguments": {
                            "workflow_id": workflow.info().workflow_id,
                            "payload": ver_segregated_payload,
                            "schema_to_request": "VerificationYield",
                        },
                    }
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            )
            ver_usage = ver_result.get("usage", {})
            self._accumulated_tokens += ver_usage.get("total_tokens", 0)
            self._accumulated_cost += ver_result.get("cost", 0.0)
            await self.record_thermodynamic_burn("verifier", ver_usage, ver_result.get("cost", 0.0))

            results.append({"node": ver_id, "type": "verification", "result": ver_result})

            if "outputs" in ver_result:
                ver_success = ver_result.get("outputs", {}).get("success", False)
            else:
                ver_success = ver_result.get("success", False)
        else:
            ver_success = True

        mcp_result = {}
        if ver_success:
            workflow.logger.info("Verification succeeded! Proxying target to Universal Asset Forge via MCP.")

            target_schema = gen_result.get("output", "{}")
            with workflow.unsafe.sandbox_unrestricted():
                import json

                try:
                    schema_dict = json.loads(target_schema) if isinstance(target_schema, str) else target_schema
                    if not isinstance(schema_dict, dict):
                        schema_dict = {"raw": target_schema}
                except Exception:
                    schema_dict = {"raw": target_schema}

                # Prevent double-serialization: ensure nested fields that must be dicts are not strings
                for nested_key in ("geometric_schema",):
                    if nested_key in schema_dict and isinstance(schema_dict[nested_key], str):
                        with contextlib.suppress(json.JSONDecodeError, TypeError):
                            schema_dict[nested_key] = json.loads(schema_dict[nested_key])

                schema_type = schema_dict.get("scaffold_type", "scaffold_logic_actuator")
                scaffold_tools = ["scaffold_manifest_state", "scaffold_logic_actuator", "scaffold_epistemic_node"]
                target_tool = schema_type if schema_type in scaffold_tools else "scaffold_logic_actuator"

                if "scaffold_type" in schema_dict:
                    del schema_dict["scaffold_type"]

                mcp_arguments = schema_dict

            mcp_result = await workflow.execute_activity(
                "ExecuteMCPToolIOActivity",
                args=[
                    f"coreason-meta-engineering:{target_tool}",
                    {"params": {"arguments": mcp_arguments}},
                    None,
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            )

            results.append({"node": "meta-engineering-mcp", "type": "forge_proxy", "result": mcp_result})
            if "receipt" in mcp_result:
                success = mcp_result.get("receipt", {}).get("success", False)
            else:
                success = mcp_result.get("success", False)

        # Phase 2: Auto-promote to URN Authority if injection succeeded
        if success and mcp_result:
            workflow.logger.info("Promoting forged artifact to URN Authority...")
            with workflow.unsafe.sandbox_unrestricted():
                import os

                urn_id = mcp_arguments.get("action_space_id", "")
                source_file = mcp_arguments.get("target_file_path", "")
                urn_authority_dir = os.environ.get(
                    "COREASON_URN_AUTHORITY_DIR",
                    "/home/user/Demo/coreason-urn-authority",
                )

            promote_result = await workflow.execute_activity(
                "ExecuteMCPToolIOActivity",
                args=[
                    "coreason-meta-engineering:promote_to_urn_authority",
                    {
                        "params": {
                            "arguments": {
                                "source_file_path": source_file,
                                "target_urn": urn_id,
                                "urn_authority_dir": urn_authority_dir,
                            }
                        }
                    },
                    None,
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
            )
            results.append({"node": "urn-promotion", "type": "promotion", "result": promote_result})

            # Check promotion success
            if "receipt" in promote_result:
                promote_success = promote_result.get("receipt", {}).get("success", False)
            else:
                promote_success = promote_result.get("success", False)

            if not promote_success:
                workflow.logger.warning("URN Authority promotion failed. Tool remains in sandbox only.")
            else:
                workflow.logger.info("Tool successfully promoted to URN Authority.")

        # Build a structurally valid receipt for crystallization
        # OracleExecutionReceipt requires: request_cid, execution_hash
        # and forbids extra keys like 'receipt', 'system_state'
        base_result = ver_result if verifier_node else gen_result

        with workflow.unsafe.sandbox_unrestricted():
            import hashlib
            import json

            fallback_hash = hashlib.sha256(
                json.dumps(base_result, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()

        final_receipt = {
            "request_cid": base_result.get("request_cid", fallback_hash[:128]),
            "inputs": base_result.get("inputs", {}),
            "outputs": {
                "forge_success": success,
                "mcp_result": mcp_result if success else None,
                "verification": base_result.get("outputs", {}),
            },
        }

        intent_hash = final_receipt["request_cid"]
        if not intent_hash or intent_hash == "UNKNOWN_HASH":
            intent_hash = fallback_hash

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, final_receipt, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed CapabilityForgeExecutionWorkflow")
        return {"status": "success" if success else "failed", "results": results}
