# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
from datetime import timedelta
from typing import Any

from temporalio import workflow
from temporalio.common import RetryPolicy

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import DiscourseTreeManifest, ExecutionEnvelopeState


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class DiscourseTreeExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that traverses a DiscourseTreeManifest context mapping text into structured hierarchies."""

    def __init__(self) -> None:
        """AGENT INSTRUCTION: Traverse semantics topologically to eliminate flat rhetoric mappings."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Discourse Tree hierarchical execution loop.

        AGENT INSTRUCTION: Process documents recursively using discourse geometries.
        Maintain causal dependencies across extraction tasks.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState containing the layout geometry.

        Returns:
            A dictionary containing the parsed extraction results.
        """
        from collections import deque

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Initializing Discourse Tree Graph Traversal.")

        with workflow.unsafe.sandbox_unrestricted():
            safe_payload = dict(manifest_payload)
            safe_payload.pop("governance", None)
            safe_payload.pop("allowed_semantic_classifications", None)
            safe_payload.pop("allowed_information_classifications", None)

            manifest = DiscourseTreeManifest.model_validate_json(json.dumps(safe_payload))

            manifest = DiscourseTreeManifest.model_validate_json(json.dumps(safe_payload))

        governance = manifest_payload.get("governance")
        workflow_start_time = workflow.now()

        root_node_cid = manifest.root_node_cid
        discourse_nodes = manifest.discourse_nodes

        # Breadth-first sorting queues mapping child geometry
        children_map: dict[str, list[str]] = {n: [] for n in discourse_nodes}
        for n_id, n_state in discourse_nodes.items():
            if n_state.parent_node_cid is not None and n_state.parent_node_cid in children_map:
                children_map[n_state.parent_node_cid].append(n_id)

        queue = deque([root_node_cid])
        extracted_facts: dict[str, Any] = {}

        while queue:
            node_cid = queue.popleft()
            node_state = discourse_nodes[node_cid]

            self.enforce_governance_limits(governance, workflow_start_time)

            # Map inherited subsuming block extraction contexts downwards
            upstream_deps = {}
            if node_state.parent_node_cid and node_state.parent_node_cid in extracted_facts:
                upstream_deps[node_state.parent_node_cid] = extracted_facts[node_state.parent_node_cid]

            propositions_outputs = {}
            for prop_cid in node_state.contained_propositions:
                with workflow.unsafe.sandbox_unrestricted():
                    prop_payload = manifest_payload.get("payload", {}).get("nodes", {}).get(prop_cid, {})
                    if not prop_payload:
                        prop_payload = {"cid": prop_cid}

                import copy

                enriched_roc = copy.deepcopy(self._current_state_envelope.state_vector.immutable_matrix or {})
                enriched_roc["upstream_dependencies"] = upstream_deps

                segregated_payload = {
                    "node_profile": prop_payload,
                    "immutable_matrix": enriched_roc,
                    "mutable_matrix": getattr(self._current_state_envelope.state_vector, "mutable_matrix", {}),
                }

                action_space = (
                    segregated_payload.get("node_profile", {}).get("action_space_cid")
                    if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                    else None
                )
                schema_req = "AutonomousAgentResponse" if action_space else "AgentResponse"

                result = await workflow.execute_activity(
                    "ExecuteNodeActivity",
                    args=[workflow.info().workflow_id, segregated_payload, schema_req],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=3),
                )

                if isinstance(result, dict):
                    usage = result.get("usage", {})
                    self._accumulated_tokens += usage.get("total_tokens", 0) if isinstance(usage, dict) else 0
                    self._accumulated_cost += float(result.get("cost", 0.0))
                    await self.record_thermodynamic_burn(
                        "result", usage if isinstance(usage, dict) else {}, float(result.get("cost", 0.0))
                    )
                    self.reconcile_state(
                        {
                            "accumulated_tokens": self._accumulated_tokens,
                            "accumulated_cost": self._accumulated_cost,
                        }
                    )

                propositions_outputs[prop_cid] = result

            extracted_facts[node_cid] = {
                "discourse_type": node_state.discourse_type,
                "extracted_propositions": propositions_outputs,
            }

            for child_cid in children_map[node_cid]:
                queue.append(child_cid)

        workflow.logger.info("Successfully traversed Document Geometry constraints.")
        return {"status": "success", "results": extracted_facts}
