# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from temporalio.common import RetryPolicy

from coreason_manifest.spec.ontology import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CausalInferenceWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that traverses causal inference topologies using PyWhy MCP Oracles."""

    def __init__(self) -> None:
        """Initialize CausalInferenceWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the causal inference workflow.

        AGENT INSTRUCTION: This workflow natively delegates causal computations to isolated URN Oracles.
        It maintains a Hollow Data Plane by never importing py-why Math dependencies.

        Args:
            payload: The dictionary representing the execution intent.

        Returns:
            A dictionary containing the results of the causal executions.
        """
        workflow.logger.info("Starting CausalInferenceWorkflow")

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        results: list[dict[str, Any]] = []
        intent_type = manifest_payload.get("intent_type", "")
        intent_payload = manifest_payload.get("payload", {})

        target_urn = ""

        if intent_type == "CausalDiscoveryIntent":
            target_urn = "urn:coreason:actionspace:oracle:pywhy_causallearn:v1"
        elif intent_type == "DoWhyEstimationIntent":
            target_urn = "urn:coreason:actionspace:oracle:pywhy_dowhy_estimator:v1"
        elif intent_type == "EconMLCATEIntent":
            target_urn = "urn:coreason:actionspace:oracle:pywhy_econml:v1"
        else:
            from temporalio.exceptions import ApplicationError

            raise ApplicationError(
                f"Unknown causal intent type: {intent_type}", type="ValidationError", non_retryable=True
            )

        workflow.logger.info(f"Delegating intent to Oracle URN: {target_urn}")

        # Map to an external MCP Call to the respective URN
        intent_jsonrpc = {
            "jsonrpc": "2.0",
            "method": "mcp.ui.emit_intent",
            "params": {"name": target_urn, "arguments": intent_payload},
        }

        tool_receipt = await workflow.execute_activity(
            "ExecuteMCPToolIOActivity",
            args=[target_urn, intent_jsonrpc, {}],
            schedule_to_close_timeout=timedelta(minutes=30),
            retry_policy=RetryPolicy(maximum_attempts=3),
        )

        results.append(tool_receipt)

        if intent_type == "CausalDiscoveryIntent":
            # ContinueAsNew checkpoint after graph discovery to serialize state
            workflow.logger.info("CausalDiscovery complete. Checkpointing via ContinueAsNew...")
            # We would normally do continue_as_new here, but for this basic orchestrator, we'll just return.

        workflow.logger.info("Completed CausalInferenceWorkflow")
        return {"status": "success", "results": results}
