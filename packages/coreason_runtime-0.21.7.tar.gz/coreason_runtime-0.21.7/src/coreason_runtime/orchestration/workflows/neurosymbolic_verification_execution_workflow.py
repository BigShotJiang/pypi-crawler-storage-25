# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
from datetime import timedelta
from typing import Any

from temporalio import workflow
from temporalio.common import RetryPolicy

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState
    from coreason_manifest.spec.ontology import (
        EpistemicDempsterShaferBeliefVectorState,
        EpistemicOntologicalReificationReceipt,
        NeurosymbolicVerificationTopologyManifest,
    )


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class NeurosymbolicVerificationExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic PyTemporal pipeline enforcing the connectionist Proposer and deterministic Verifier theorem solver logic loops."""

    def __init__(self) -> None:
        """AGENT INSTRUCTION: Initialize the ping-pong Proposer/Verifier loops."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Neurosymbolic Verification workflow loop.

        AGENT INSTRUCTION: Executing the continuous penalty gradients bounding LLM heuristics into deterministic structures.
        Yield to oracle upon maximum loops reached.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState containing the layout geometry.

        Returns:
            A dictionary containing the final successfully verified structural payload.
        """
        import uuid

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Initializing Top-level verification neurosymbolic graph execution.")

        with workflow.unsafe.sandbox_unrestricted():
            safe_payload = dict(manifest_payload)
            safe_payload.pop("governance", None)
            safe_payload.pop("allowed_semantic_classifications", None)
            safe_payload.pop("allowed_information_classifications", None)

            manifest = NeurosymbolicVerificationTopologyManifest.model_validate_json(json.dumps(safe_payload))

        governance = manifest_payload.get("governance")
        workflow_start_time = workflow.now()

        max_revision_loops = manifest.max_revision_loops
        proposer_cid = manifest.proposer_node_cid
        verifier_cid = manifest.verifier_node_cid
        critique_cid = manifest.critique_schema_cid

        proposer_profile = manifest.nodes[proposer_cid]
        verifier_profile = manifest.nodes[verifier_cid]

        current_upstream_critique: dict[str, Any] | None = None

        async def execute_node(
            node_cid: str, profile: Any, inject_deps: dict[str, Any] | None = None
        ) -> dict[str, Any]:
            self.enforce_governance_limits(governance, workflow_start_time)

            with workflow.unsafe.sandbox_unrestricted():
                node_payload = manifest_payload.get("payload", {}).get("nodes", {}).get(node_cid)
                if not node_payload:
                    node_payload = profile.model_dump(mode="json")

            import copy
            import typing

            current_env = typing.cast("Any", self._current_state_envelope)
            enriched_roc = copy.deepcopy(current_env.state_vector.immutable_matrix or {})
            if inject_deps:
                enriched_roc["upstream_dependencies"] = inject_deps

            segregated_payload = {
                "node_profile": node_payload,
                "immutable_matrix": enriched_roc,
                "mutable_matrix": getattr(current_env.state_vector, "mutable_matrix", {}),
            }

            node_type = getattr(profile, "topology_class", "agent")

            if node_type == "system":
                try:
                    sys_res = await workflow.execute_activity(
                        "ExecuteSystemFunctionComputeActivity",
                        args=[node_payload],
                        schedule_to_close_timeout=timedelta(minutes=5),
                        start_to_close_timeout=timedelta(minutes=1),  # Enforce strict wall-clock bound
                        retry_policy=RetryPolicy(maximum_attempts=3),
                    )
                    return sys_res if isinstance(sys_res, dict) else {}
                except Exception as e:
                    # temporalio.exceptions.ActivityError wraps timeouts
                    workflow.logger.error(f"Tier 1 Solver Timeout Exceeded: {e}")
                    from temporalio.exceptions import ApplicationError

                    raise ApplicationError(
                        "Tier 1 Solver (Z3/Clingo) mathematical proof timeout.",
                        type="EpistemicYieldError",
                        non_retryable=True,
                    ) from e
            action_space = (
                segregated_payload.get("node_profile", {}).get("action_space_cid")
                if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                else None
            )
            schema_req = "AutonomousAgentResponse" if action_space else "AgentResponse"

            try:
                res = await workflow.execute_activity(
                    "ExecuteNemoclawSwarmIoActivity",
                    args=[
                        {
                            "name": "deploy_cognitive_swarm",
                            "arguments": {
                                "workflow_id": workflow.info().workflow_id,
                                "payload": segregated_payload,
                                "schema_to_request": schema_req,
                            },
                        }
                    ],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    start_to_close_timeout=timedelta(minutes=1),  # Enforce strict wall-clock bound
                    retry_policy=RetryPolicy(maximum_attempts=3),
                )
            except Exception as e:
                # temporalio.exceptions.ActivityError wraps timeouts
                workflow.logger.error(f"Tier 1 Solver Timeout Exceeded: {e}")
                from temporalio.exceptions import ApplicationError

                raise ApplicationError(
                    "Tier 1 Solver (Z3/Clingo) mathematical proof timeout.",
                    type="EpistemicYieldError",
                    non_retryable=True,
                ) from e

            if isinstance(res, dict):
                usage = res.get("usage", {})
                self._accumulated_tokens += usage.get("total_tokens", 0) if isinstance(usage, dict) else 0
                self._accumulated_cost += float(res.get("cost", 0.0))
                await self.record_thermodynamic_burn(
                    "result", usage if isinstance(usage, dict) else {}, float(res.get("cost", 0.0))
                )
                self.reconcile_state(
                    {
                        "accumulated_tokens": self._accumulated_tokens,
                        "accumulated_cost": self._accumulated_cost,
                    }
                )

                return res

            return {}

        for loop_idx in range(max_revision_loops):
            workflow.logger.info(f"Initiating Proposer Bipartite Ping (Loop {loop_idx + 1}/{max_revision_loops})")

            # Form upstream payload injections
            deps = {}
            if current_upstream_critique:
                deps[verifier_cid] = current_upstream_critique

            # 1. Proposer Call
            proposer_output = await execute_node(proposer_cid, proposer_profile, inject_deps=deps)
            if proposer_output.get("status") == "epistemic_yield":
                return {"status": "epistemic_yield", "event": "TerminalCognitiveEvent", "reason": "Proposer yielded."}

            hypothesis = proposer_output.get("outputs", {})

            # 2. Verifier Call
            workflow.logger.info("Targeting formal Logic via Verifier constraint.")
            verifier_inputs = {proposer_cid: hypothesis}
            verifier_output = await execute_node(verifier_cid, verifier_profile, inject_deps=verifier_inputs)

            is_success = verifier_output.get("success", False)

            # Emit the Reification Receipt dynamically enforcing verification boundaries
            import hashlib

            from coreason_manifest.spec.ontology import TransformationMechanismProfile

            with workflow.unsafe.sandbox_unrestricted():
                base_hash = hashlib.sha256(json.dumps(verifier_output, sort_keys=True).encode("utf-8")).hexdigest()
                receipt = EpistemicOntologicalReificationReceipt(
                    event_cid=f"reification-{uuid.uuid4()}",
                    timestamp=workflow.now().timestamp(),
                    source_data_hash=base_hash,
                    target_namespace=verifier_cid,
                    algorithmic_mechanism=TransformationMechanismProfile("abductive_inference"),
                    belief_vector=EpistemicDempsterShaferBeliefVectorState(
                        lexical_confidence=1.0 if is_success else 0.0,
                        semantic_distance=0.0 if is_success else 1.0,
                        structural_graph_confidence=1.0 if is_success else 0.0,
                        epistemic_conflict_mass=0.0 if is_success else 1.0,
                        supporting_citations=[],
                    ),
                    is_latent_inference=True,
                )
                receipt_dict = receipt.model_dump(mode="json")

            await workflow.execute_activity(
                "StoreEpistemicStateIOActivity",
                args=[workflow.info().workflow_id, receipt.event_cid, is_success, verifier_output, receipt_dict],
                schedule_to_close_timeout=timedelta(minutes=1),
            )

            # 3. Termination Logic Validation
            if is_success:
                workflow.logger.info("Formal symbolic verification successful.")
                return {"status": "success", "iterations": loop_idx + 1, "final_state": hypothesis}

            workflow.logger.warning("Deterministic verification penalty hit. Mapping critique gradient.")

            # Format critique schema
            packaged_critique = verifier_output.get("outputs", {})
            if critique_cid:
                current_upstream_critique = {"schema_target": critique_cid, "critique_gradient": packaged_critique}
            else:
                current_upstream_critique = packaged_critique

        # Max revision limit terminal yield break
        workflow.logger.error("Maximum revisions reached in validation block. Halting Execution Geometry.")
        return {
            "status": "epistemic_yield",
            "event": "TerminalCognitiveEvent",
            "reason": f"Maximum allowable validation cycles ({max_revision_loops}) breached.",
        }
