# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
from datetime import timedelta
from typing import Any, TypedDict

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import EvictionPolicy, SalienceProfile

    from coreason_runtime.memory.graphiti_engine import GraphitiStateEngine
    from coreason_runtime.memory.latent import GraphitiLatentMemoryManager
    from coreason_runtime.utils.logger import logger


class EpistemicPruningPayloadDict(TypedDict, total=False):
    """Payload definition for epistemic pruning input enforcing strict bounds."""

    eviction_policy: dict[str, Any]
    salience: dict[str, Any]


class EpistemicPruningResultDict(TypedDict):
    """Execution result metrics for epistemic topological bounds."""

    status: str
    purged_vector_count: int
    pruned_dimensions: int


@activity.defn(name="evaluate_and_decay_salience_activity")
async def evaluate_and_decay_salience_activity(payload: EpistemicPruningPayloadDict) -> int:
    """Evaluates mathematical temporal decay limits and prunes dead vector bindings.

    Reads physical vectors mapped mapping chronological execution vs access_frequency
    inside the LanceDB tables. Protects any topological ID in the whitelist.
    """
    logger.info("Initializing salience bounds mathematically natively within activity bounds.")
    eviction_policy = EvictionPolicy.model_validate(payload.get("eviction_policy", {}))
    salience = SalienceProfile.model_validate(payload.get("salience", {}))

    decay_rate = salience.decay_rate
    threshold = 0.5  # Replaced minimum_utility_threshold with static constant as per new ontology
    protected_cids = eviction_policy.protected_event_cids

    neo4j_uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user = os.getenv("NEO4J_USERNAME", "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD", "password")
    engine = GraphitiStateEngine(neo4j_uri=neo4j_uri, neo4j_user=neo4j_user, neo4j_password=neo4j_password)
    manager = GraphitiLatentMemoryManager(engine)

    purged_count = int(await manager.prune_stale_vectors(decay_rate, threshold, protected_cids))
    logger.info(f"Purge boundary complete. Dropped {purged_count} vector bounds.")
    return purged_count


@workflow.defn(name="EpistemicPruningWorkflow", sandboxed=False)
class EpistemicPruningWorkflow:
    """Cron-driven Temporal scheduling graph bounding Epistemic Forgetting explicitly recursively natively."""

    @workflow.run
    async def run(self, pipeline_payload: EpistemicPruningPayloadDict) -> EpistemicPruningResultDict:
        """Manages execution bounds for semantic array consolidation enforcing Information Bottleneck parameters.

        Natively wraps the LanceDB evaluations applying algebraic drop rules natively against
        decay curves matching standard Salience drop definitions per EvictionPolicy bounds.
        """
        logger.info("Initializing Epistemic Forgetting bounds.")
        if "eviction_policy" not in pipeline_payload:
            pipeline_payload["eviction_policy"] = EvictionPolicy(
                strategy="salience_decay", max_retained_tokens=100000, protected_event_cids=[]
            ).model_dump()

        if "salience" not in pipeline_payload:
            pipeline_payload["salience"] = SalienceProfile(baseline_importance=1.0, decay_rate=0.01).model_dump()

        pruned_amount = await workflow.execute_activity(
            evaluate_and_decay_salience_activity,
            args=[pipeline_payload],
            schedule_to_close_timeout=timedelta(minutes=5),
        )

        logger.info("Epistemic Pruning execution sequence returned natively successfully.")
        return {
            "status": "epistemic_pruning_complete",
            "purged_vector_count": pruned_amount,
            "pruned_dimensions": pruned_amount * 1536,
        }
