# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import math
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field
from temporalio import activity


class ThermodynamicBounds(BaseModel):
    min_entropy_threshold: float = Field(default=0.5)


if TYPE_CHECKING:
    from collections.abc import Sequence


@activity.defn(name="EvaluateThermodynamicExhaustionActivity")
async def evaluate_thermodynamic_exhaustion_activity(
    epistemic_history: Sequence[str],
    bounds_payload: dict[str, Any],  # noqa: ARG001
) -> float:
    """Calculate the Shannon entropy of epistemic state transitions to restrict infinite hallucinatory loops natively.

    Args:
        epistemic_history: An explicitly ordered structural sequence of states mapping execution memory natively.
        bounds_payload: The dictionary representation of a ThermodynamicBounds object defining thermodynamic limits securely.

    Returns:
        The calculated mathematical Shannon entropy.

    Raises:
        ManifestConformanceError: Explicitly validating Free Energy Exhausted if bounds are severely breached.
    """

    if not epistemic_history:
        return 0.0

    counts: dict[str, int] = {}
    for state in epistemic_history:
        counts[state] = counts.get(state, 0) + 1

    total = len(epistemic_history)
    entropy = 0.0
    for count in counts.values():
        p = count / total
        if p > 0:
            entropy -= p * math.log2(p)

    return entropy
