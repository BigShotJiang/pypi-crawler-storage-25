# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os

import httpx


class Fido2Verifier:
    """AGENT INSTRUCTION: Validates physical WetwareAttestationContract FIDO2 signatures via NemoClaw delegation."""

    def __init__(self, rp_id: str, rp_name: str) -> None:
        self.rp_id = rp_id
        self.rp_name = rp_name
        self.url = os.getenv("NEMOCLAW_URL", "http://localhost:8080")

    def verify_hardware_signature(
        self, cryptographic_payload: str, did_subject: str, expected_challenge: str, stored_public_key: bytes
    ) -> bool:
        """Verify the WebAuthn signature bound directly against the human's DID mapping via NemoClaw."""
        payload = {
            "rp_id": self.rp_id,
            "rp_name": self.rp_name,
            "cryptographic_payload": cryptographic_payload,
            "did_subject": did_subject,
            "expected_challenge": expected_challenge,
            "stored_public_key": stored_public_key.hex(),
        }
        try:
            with httpx.Client(timeout=5.0) as client:
                response = client.post(f"{self.url}/v1/verify/biometric", json=payload)
                if response.status_code != 200:
                    return False
                return bool(response.json().get("valid", False))
        except httpx.RequestError as err:
            raise ValueError("NemoClaw bridge unreachable for biometric verification") from err
