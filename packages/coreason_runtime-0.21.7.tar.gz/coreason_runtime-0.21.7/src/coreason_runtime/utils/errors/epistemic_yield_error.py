class EpistemicYieldError(Exception):
    """Raised when the active inference loop requires resolving priors."""
