import asyncio
import concurrent.futures

from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow
from tests.orchestration.workflows.test_dag_execution_workflow import (
    _build,
    stub_emit_span,
    stub_execute_oracle,
    stub_execute_tensor_json,
    stub_fetch_memoized_hit,
    stub_mcp_tool,
    stub_record_token_burn,
    stub_store_epistemic,
    stub_system_function,
)


async def test():
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        async with Worker(
            env.client,
            task_queue="dag-depth-1",
            workflows=[DAGExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_store_epistemic,
                stub_execute_tensor_json,
                stub_fetch_memoized_hit,
                stub_mcp_tool,
                stub_system_function,
                stub_record_token_burn,
                stub_execute_oracle,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            manifest_depth = {
                "max_depth": 0,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test agent 1",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test agent 2",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [
                    ("did:agent:nodeaaa", "did:agent:nodebbb"),
                ],
            }

            try:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_depth), id="t-depth-1", task_queue="dag-depth-1"
                )
                print("NO EXCEPTION THROWN!")
            except Exception as e:
                cause = getattr(e, "cause", e)
                print(f"EXCEPTION CAUSE: {cause}")
                print(f"TYPE: {type(cause)}")

        executor.shutdown(wait=False)


if __name__ == "__main__":
    asyncio.run(test())
