import asyncio
import concurrent.futures

from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow
from tests.orchestration.workflows.test_dag_execution_workflow import _build, stub_emit_span


async def test():
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        async with Worker(
            env.client,
            task_queue="dag-cycles-2",
            workflows=[DAGExecutionWorkflow],
            activities=[stub_emit_span],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            manifest_cycles = {
                "max_depth": 5,
                "allow_cycles": True,
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test agent 1",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test agent 2",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [
                    ("did:agent:nodeaaa", "did:agent:nodebbb"),
                    ("did:agent:nodebbb", "did:agent:nodeaaa"),
                ],
            }

            import coreason_manifest

            orig_val_json = coreason_manifest.DAGTopologyManifest.model_validate_json

            def _fake_val_json(json_data, *args, **kwargs):
                m = orig_val_json(json_data, *args, **kwargs)
                object.__setattr__(m, "allow_cycles", False)
                return m

            coreason_manifest.DAGTopologyManifest.model_validate_json = _fake_val_json

            try:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_cycles), id="t-cycles-2", task_queue="dag-cycles-2"
                )
                print("NO EXCEPTION THROWN!")
            except Exception as e:
                cause = getattr(e, "cause", e)
                cause_str = str(cause)
                print(f"EXCEPTION CAUSE: {cause_str}")
                print(f"TYPE: {type(cause)}")
            finally:
                coreason_manifest.DAGTopologyManifest.model_validate_json = orig_val_json

        executor.shutdown(wait=False)


if __name__ == "__main__":
    asyncio.run(test())
