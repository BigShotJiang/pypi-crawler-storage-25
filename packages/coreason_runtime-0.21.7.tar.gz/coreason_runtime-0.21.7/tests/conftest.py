# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime
# isort: skip_file
from typing import Any

import pytest
import respx
from httpx import Response
from testcontainers.neo4j import Neo4jContainer  # type: ignore[import-untyped]


@pytest.fixture(scope="session")
def neo4j_container() -> Any:
    """AGENT INSTRUCTION: Provisions a session-scoped Neo4j substrate for integration testing.

    Physical execution engine for Graphiti-backed memory subsystems.
    """
    try:
        with Neo4jContainer("neo4j:5.18") as neo4j:
            # neo4j.with_env("NEO4J_AUTH", "none") # If we want no auth
            yield neo4j
    except Exception as e:
        pytest.skip(f"Docker is not available or Neo4j failed to start: {e}")


@pytest.fixture(autouse=True)
def mock_nemoclaw_bridge() -> Any:
    """AGENT INSTRUCTION: Implicitly projects a default-allow security plane across all test trajectories.

    This fixture ensures that any tests hitting the NemoClaw bridge (localhost:8080)
    receive a successful 'valid: true' response by default, preventing ConnectionRefused
    errors in legacy tests that haven't been updated to use respx explicitly.

    It also prevents network leaks to HuggingFace during LanceDB discovery.
    """
    with respx.mock(assert_all_called=False) as respx_mock:
        # Default allow for all verification endpoints
        respx_mock.post(url__regex=r"http://localhost:8080/v1/verify/.*").mock(
            return_value=Response(200, json={"valid": True})
        )

        # AGENT INSTRUCTION: Aggressively trap HuggingFace metadata requests.
        # This acts as a secondary defense if the source-level mock is bypassed.
        respx_mock.head(url__regex=r"https://huggingface.co/.*").mock(return_value=Response(200))
        respx_mock.get(url__regex=r"https://huggingface.co/.*").mock(return_value=Response(200, content=b""))
        yield respx_mock
