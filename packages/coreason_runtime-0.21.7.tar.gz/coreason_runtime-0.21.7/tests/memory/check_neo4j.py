import time

from testcontainers.neo4j import Neo4jContainer  # type: ignore[import-untyped]

try:
    print("Starting Neo4j container...")
    with Neo4jContainer("neo4j:5.12") as neo4j:
        print(f"Neo4j started at {neo4j.get_connection_url()}")
        time.sleep(2)
    print("Stopped successfully.")
except Exception as e:
    print(f"Error: {e}")
