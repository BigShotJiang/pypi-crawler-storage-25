# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import os
from pathlib import Path
from typing import Any

import polars as pl
from coreason_manifest import ObservationEvent
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import process_medallion_pipeline


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow], deadline=None)
@given(
    receipts=st.lists(
        st.builds(
            ObservationEvent,
            event_cid=st.uuids().map(lambda u: f"obs-{u}"),
            timestamp=st.floats(min_value=1700000000.0, max_value=1800000000.0),
            payload=st.dictionaries(keys=st.text(min_size=1), values=st.text(), max_size=5),
            triggering_invocation_cid=st.uuids().map(lambda u: f"inv-{u}"),
        ),
        min_size=10,
        max_size=100,
    ),
    jitter_offsets=st.lists(st.integers(min_value=-1000, max_value=1000), min_size=10, max_size=100),
)
def test_medallion_deduplication(
    receipts: list[ObservationEvent], jitter_offsets: list[int], tmp_path: Path, monkeypatch: Any
) -> None:
    # Setup iteration-specific directory using a random UUID to avoid state contamination
    iter_id = "018e69ac-5591-7f0b-9c76-556bede63287"
    iter_dir = tmp_path / iter_id

    # Setup bronze directory with receipts, add some exact duplicates
    base_dir = iter_dir / "data"
    bronze_dir = base_dir / "bronze" / "telemetry" / "raw_events"
    silver_dir = base_dir / "silver"
    gold_dir = base_dir / "gold"

    os.makedirs(bronze_dir, exist_ok=True)
    os.makedirs(silver_dir, exist_ok=True)
    os.makedirs(gold_dir, exist_ok=True)

    # process_medallion_pipeline unique is on ["node_id", "event_type", "timestamp"]
    # and drops nulls on ["workflow_id"]

    # Save base receipts
    unique_receipts = {}

    records = []

    import datetime

    base_time = datetime.datetime(2026, 1, 1, tzinfo=datetime.UTC)

    for i, receipt in enumerate(receipts):
        # Pydantic strictly validates the models, so these are valid structurally.
        # Now we serialize and duplicate them to simulate SSE stream duplication
        dump = receipt.model_dump(mode="json")
        unique_receipts[dump["event_cid"]] = dump

        # Jitter the timestamp slightly to simulate network drift or out-of-order SSE
        offset = jitter_offsets[i] if i < len(jitter_offsets) else 0
        jitter = datetime.timedelta(milliseconds=offset)
        jittered_time = (base_time + jitter).isoformat()

        # We need to add the fields that process_medallion_pipeline expects:
        # node_id, event_type, timestamp, workflow_id
        records.append(
            {
                "node_cid": dump["event_cid"],
                "event_type": "execution_node_receipt",
                "timestamp": jittered_time,
                "workflow_id": "wf-1",
                "payload": json.dumps(dump),
            }
        )

        # Add duplicate
        records.append(
            {
                "node_cid": dump["event_cid"],
                "event_type": "execution_node_receipt",
                "timestamp": jittered_time,
                "workflow_id": "wf-1",
                "payload": json.dumps(dump),
            }
        )

    # create a polars dataframe and write to parquet in the bronze dir
    df = pl.DataFrame(records)
    df.write_parquet(bronze_dir / "events.parquet")

    # Safely monkeypatch the current working directory so the standard Path logic resolves correctly
    monkeypatch.chdir(iter_dir)

    # Process pipeline
    result = process_medallion_pipeline()

    # Verify expectations
    assert result["status"] == "success"

    if os.path.exists(silver_dir / "events.parquet"):
        df_silver = pl.read_parquet(silver_dir / "events.parquet")

        # Invariant: Must perfectly deduplicate on node_id
        if "node_id" in df_silver.columns:
            assert len(df_silver) == len(df_silver["node_id"].unique())

    if os.path.exists(gold_dir / "metrics.parquet"):
        df_gold = pl.read_parquet(gold_dir / "metrics.parquet")
        # Invariant: accurately counts the Gold layer metrics
        # There's 1 workflow_id: "wf-1", so there should be 1 row
        assert len(df_gold) == 1
        assert df_gold["workflow_id"][0] == "wf-1"
        assert df_gold["total_events"][0] == len(unique_receipts)
        assert df_gold["unique_nodes_activated"][0] == len(unique_receipts)
