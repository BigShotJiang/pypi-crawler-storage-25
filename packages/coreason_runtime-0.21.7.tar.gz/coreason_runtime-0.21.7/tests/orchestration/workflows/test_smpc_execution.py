# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    ExecutionEnvelopeState,
    ObservationEvent,
    OracleExecutionReceipt,
    SMPCTopologyManifest,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.smpc_execution_workflow import SMPCExecutionWorkflow


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def execute_tensor_inference_mock(*args: Any) -> dict[str, Any]:
    receipt = OracleExecutionReceipt(
        execution_hash="a" * 64,
        solver_urn="urn:coreason:solver:stub_smpc_member",
        tokens_burned=10,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="mock-request",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    payload["intent_hash"] = "a" * 64
    return payload


@activity.defn(name="StoreEpistemicStateIOActivity")
async def store_epistemic_mock(*args: Any) -> None:
    pass


@pytest.mark.asyncio
async def test_smpc_segregated_workers() -> None:
    manifest = SMPCTopologyManifest(
        participant_node_cids=["did:coreason:agent-partyA", "did:coreason:agent-partyB"],
        smpc_protocol="secret_sharing",
        joint_function_uri="smpc://test-uri",
        nodes={
            "did:coreason:agent-partyA": CognitiveAgentNodeProfile(description="Party A", topology_class="agent"),
            "did:coreason:agent-partyB": CognitiveAgentNodeProfile(description="Party B", topology_class="agent"),
        },
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H0000000000000000000000A", span_cid="01H0000000000000000000000B"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        # Create segregated workers for the distinctly isolated network nodes
        worker_a = Worker(
            env.client,
            task_queue="did:coreason:agent-partyA",
            activities=[stub_emit_span, execute_tensor_inference_mock, store_epistemic_mock],
        )
        worker_b = Worker(
            env.client,
            task_queue="did:coreason:agent-partyB",
            activities=[stub_emit_span, execute_tensor_inference_mock],
        )

        # Core Orchestrator Worker running the topology
        worker_orchestrator = Worker(
            env.client,
            task_queue="orchestrator-queue",
            workflows=[SMPCExecutionWorkflow],
            activities=[stub_emit_span, store_epistemic_mock],  # To handle Epistemic IO
            workflow_runner=UnsandboxedWorkflowRunner(),
        )

        # Run all workers concurrently
        async with worker_a, worker_b, worker_orchestrator:
            result = await env.client.execute_workflow(
                SMPCExecutionWorkflow.run,
                payload,
                id="smpc-test-workflow",
                task_queue="orchestrator-queue",
            )

            assert result["status"] == "success"
            assert result["participants"] == 2
            assert result["smpc_protocol"] == "secret_sharing"

            # 2 shares + 1 aggregator step = 3 results
            assert len(result["results"]) == 3
            types = [r.get("type") for r in result["results"]]
            assert types.count("share") == 2
            assert types.count("aggregation") == 1


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def execute_tensor_inference_mock_no_hash(*args: Any) -> dict[str, Any]:
    receipt = OracleExecutionReceipt(
        execution_hash="b" * 64,
        solver_urn="urn:coreason:solver:stub_smpc_member",
        tokens_burned=10,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="mock-request",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    # deliberately omit intent_hash
    if "intent_hash" in payload:
        del payload["intent_hash"]
    return payload


@pytest.mark.asyncio
async def test_smpc_missing_intent_hash_and_action_space() -> None:
    manifest = SMPCTopologyManifest(
        participant_node_cids=["did:coreason:agent-partyC", "did:coreason:agent-partyD"],
        smpc_protocol="garbled_circuits",
        joint_function_uri="smpc://test-uri-2",
        nodes={
            "did:coreason:agent-partyC": CognitiveAgentNodeProfile(
                description="Party C", topology_class="agent", action_space_cid="did:coreason:action-space-123"
            ),
            "did:coreason:agent-partyD": CognitiveAgentNodeProfile(
                description="Party D",
                topology_class="agent",
            ),
        },
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H0000000000000000000000A", span_cid="01H0000000000000000000000B"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        worker_c = Worker(
            env.client,
            task_queue="did:coreason:agent-partyC",
            activities=[stub_emit_span, execute_tensor_inference_mock_no_hash, store_epistemic_mock],
        )
        worker_d = Worker(
            env.client,
            task_queue="did:coreason:agent-partyD",
            activities=[stub_emit_span, execute_tensor_inference_mock_no_hash],
        )

        worker_orchestrator = Worker(
            env.client,
            task_queue="orchestrator-queue-2",
            workflows=[SMPCExecutionWorkflow],
            activities=[stub_emit_span, store_epistemic_mock],
            workflow_runner=UnsandboxedWorkflowRunner(),
        )

        async with worker_c, worker_d, worker_orchestrator:
            result = await env.client.execute_workflow(
                SMPCExecutionWorkflow.run,
                payload,
                id="smpc-test-workflow-2",
                task_queue="orchestrator-queue-2",
            )

            assert result["status"] == "success"
            assert result["participants"] == 2
