import concurrent.futures
from typing import Any

import httpx
import pytest
import respx
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.swarm_execution_workflow import SwarmExecutionWorkflow


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


def _build_swarm_envelope(manifest_payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "state_vector": {
            "immutable_matrix": {"matrix_hash": "testhash", "agent_traces": []},
            "mutable_matrix": {"compute_budget": 1000000},
        },
        "payload": manifest_payload,
        "trace_context": {"trace_cid": "0123456789ABCDEFGHJKMNPQRS", "span_cid": "0123456789ABCDEFGHJKMNPQRS"},
    }


@pytest.fixture
def mock_swarm_manifest() -> dict[str, Any]:
    return {
        "spawning_threshold": 2,
        "nodes": {"did:coreason:worker": {"topology_class": "agent", "description": "test agent"}},
    }


@pytest.mark.asyncio
@respx.mock
async def test_swarm_execution_workflow_delegates_to_nemoclaw(mock_swarm_manifest: dict[str, Any]) -> None:
    respx.post("https://nemoclaw:8443/v1/mcp/urn:coreason:oracle:nemoclaw/tools/call").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "success",
                "iterations": 1,
                "results": [{"status": "success", "intent_hash": "NEMOCLAW_REAL"}],
            },
        )
    )
    activities = KineticActivities("memory")
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="swarm-test-queue",
            workflows=[SwarmExecutionWorkflow],
            activities=[
                stub_emit_span,
                activities.execute_nemoclaw_swarm_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_swarm_envelope(mock_swarm_manifest)
            result = await env.client.execute_workflow(
                SwarmExecutionWorkflow.run, payload, id="swarm-test", task_queue="swarm-test-queue"
            )

            assert result["status"] == "success"
            assert result.get("iterations", 1) == 1
            assert result["results"][0]["intent_hash"] == "NEMOCLAW_REAL"


@pytest.mark.asyncio
@respx.mock
async def test_swarm_execution_workflow_delegates_to_nemoclaw_empty(mock_swarm_manifest: dict[str, Any]) -> None:
    respx.post("https://nemoclaw:8443/v1/mcp/urn:coreason:oracle:nemoclaw/tools/call").mock(
        return_value=httpx.Response(200, json={"status": "success", "iterations": 1, "results": []})
    )
    activities = KineticActivities("memory")
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="swarm-test-queue-empty",
            workflows=[SwarmExecutionWorkflow],
            activities=[
                stub_emit_span,
                activities.execute_nemoclaw_swarm_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_swarm_envelope(mock_swarm_manifest)
            result = await env.client.execute_workflow(
                SwarmExecutionWorkflow.run, payload, id="swarm-test-empty", task_queue="swarm-test-queue-empty"
            )

            assert result["status"] == "success"
            assert result.get("iterations", 1) == 1
            assert result.get("results", []) == []
