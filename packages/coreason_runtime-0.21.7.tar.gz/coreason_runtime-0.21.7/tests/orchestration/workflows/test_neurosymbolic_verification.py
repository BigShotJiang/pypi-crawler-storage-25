# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    CognitiveSystemNodeProfile,
    ExecutionEnvelopeState,
    NeurosymbolicVerificationTopologyManifest,
    ObservationEvent,
    OracleExecutionReceipt,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.neurosymbolic_verification_execution_workflow import (
    NeurosymbolicVerificationExecutionWorkflow,
)

# Custom mock activity just to simulate the solver taking too long


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def execute_tensor_inference_mock(*args: Any) -> dict[str, Any]:
    receipt = OracleExecutionReceipt(
        execution_hash="a" * 64,
        solver_urn="urn:coreason:solver:stub_neuro_member",
        tokens_burned=10,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="mock-request",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    return payload


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def execute_system_function_mock(*args: Any) -> dict[str, Any]:
    raise TimeoutError("Solver timeout simulated.")


@activity.defn(name="StoreEpistemicStateIOActivity")
async def store_epistemic_mock(*args: Any) -> None:
    pass


@activity.defn(name="RecordTokenBurnIOActivity")
async def record_token_burn_mock(*args: Any) -> None:
    pass


@pytest.mark.asyncio
async def test_solver_timeout_throws_epistemic_yield() -> None:
    manifest = NeurosymbolicVerificationTopologyManifest(
        proposer_node_cid="did:coreason:agent-111",
        verifier_node_cid="did:coreason:system-222",
        critique_schema_cid="did:coreason:schema-333",
        max_revision_loops=3,
        nodes={
            "did:coreason:agent-111": CognitiveAgentNodeProfile(description="Proposer", topology_class="agent"),
            "did:coreason:system-222": CognitiveSystemNodeProfile(description="Verifier", topology_class="system"),
        },
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H00000000000000000000000", span_cid="01H00000000000000000000001"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neurosymbolic-test-queue",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                execute_tensor_inference_mock,
                execute_system_function_mock,
                store_epistemic_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            # The workflow expects EpistemicYieldError, which is a Python Exception.
            # Due to the time-skipping environment, the sleep(65) is instant, but the timeout gets triggered.
            with pytest.raises(Exception) as exc_info:
                await env.client.execute_workflow(
                    NeurosymbolicVerificationExecutionWorkflow.run,
                    payload,
                    id="neurosymbolic-test-workflow",
                    task_queue="neurosymbolic-test-queue",
                )

            # The exception that comes back from execute_workflow is WorkflowExecutionFailedError
            # which wraps an ApplicationError containing the EpistemicYieldError details
            err = exc_info.value
            cause = getattr(err, "cause", None)
            assert cause is not None
            assert "EpistemicYieldError" in getattr(cause, "type", "") or "EpistemicYieldError" in str(cause)
            assert "timeout" in str(cause).lower()


# ── Additional Stubs for Proposer(agent) + Verifier(system) Path ──────

_call_counter: int = 0


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def stub_proposer_agent(*args: Any) -> dict[str, Any]:
    """Proposer (agent node) returns a hypothesis output."""
    receipt = OracleExecutionReceipt(
        execution_hash="b" * 64,
        solver_urn="urn:coreason:solver:stub_proposer",
        tokens_burned=10,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="req-proposer",
            timestamp=123.0,
            payload={"result": True, "hypothesis": "verified_output"},
        ).model_dump(mode="json")
    ]
    return payload


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def stub_verifier_success(*args: Any) -> dict[str, Any]:
    """Verifier (system node) returns success=True."""
    receipt = OracleExecutionReceipt(
        execution_hash="d" * 64,
        solver_urn="urn:coreason:solver:stub_verifier",
        tokens_burned=10,
    )
    result = receipt.model_dump(mode="json")
    result["evidence"] = [
        ObservationEvent(
            event_cid="req-verifier",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    result["success"] = True
    return result


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def stub_verifier_fail(*args: Any) -> dict[str, Any]:
    """Verifier (system node) always returns success=False."""
    receipt = OracleExecutionReceipt(
        execution_hash="e" * 64,
        solver_urn="urn:coreason:solver:stub_verifier_fail",
        tokens_burned=10,
    )
    result = receipt.model_dump(mode="json")
    result["evidence"] = [
        ObservationEvent(
            event_cid="req-verifier-fail",
            timestamp=123.0,
            payload={"result": False},
        ).model_dump(mode="json")
    ]
    result["success"] = False
    return result


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def stub_proposer_yields(*args: Any) -> dict[str, Any]:
    """Proposer yields immediately."""
    return {"status": "epistemic_yield", "outputs": {}}


def _build_neuro_agent_envelope(max_loops: int = 3) -> dict[str, Any]:
    """Build envelope where proposer is agent and verifier is system."""
    manifest = NeurosymbolicVerificationTopologyManifest(
        proposer_node_cid="did:coreason:proposer",
        verifier_node_cid="did:coreason:verifier",
        critique_schema_cid="did:coreason:critique",
        max_revision_loops=max_loops,
        nodes={
            "did:coreason:proposer": CognitiveAgentNodeProfile(description="Proposer", topology_class="agent"),
            "did:coreason:verifier": CognitiveSystemNodeProfile(description="Verifier", topology_class="system"),
        },
    )
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H00000000000000000000000", span_cid="01H00000000000000000000001"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )
    return envelope.model_dump(mode="json")


@pytest.mark.asyncio
async def test_verification_succeeds_first_loop() -> None:
    """Proposer(agent)→Verifier(system) succeeds on first iteration."""
    payload = _build_neuro_agent_envelope(max_loops=3)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neuro-success-queue",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_proposer_agent,
                stub_verifier_success,
                store_epistemic_mock,
                record_token_burn_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                NeurosymbolicVerificationExecutionWorkflow.run,
                payload,
                id="neuro-success-test",
                task_queue="neuro-success-queue",
            )

    assert result["status"] == "success"
    assert result["iterations"] == 1


@pytest.mark.asyncio
async def test_max_revision_loops_exhausted() -> None:
    """Max revision loops exhausted returns epistemic_yield."""
    payload = _build_neuro_agent_envelope(max_loops=2)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neuro-exhaust-queue",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_proposer_agent,
                stub_verifier_fail,
                store_epistemic_mock,
                record_token_burn_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                NeurosymbolicVerificationExecutionWorkflow.run,
                payload,
                id="neuro-exhaust-test",
                task_queue="neuro-exhaust-queue",
            )

    assert result["status"] == "epistemic_yield"
    assert "Maximum" in result["reason"]


@pytest.mark.asyncio
async def test_proposer_yields_immediately() -> None:
    """Proposer returning epistemic_yield halts the loop."""
    payload = _build_neuro_agent_envelope(max_loops=3)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neuro-yield-queue",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_proposer_yields,
                stub_verifier_success,
                store_epistemic_mock,
                record_token_burn_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                NeurosymbolicVerificationExecutionWorkflow.run,
                payload,
                id="neuro-yield-test",
                task_queue="neuro-yield-queue",
            )

    assert result["status"] == "epistemic_yield"
    assert "Proposer yielded" in result["reason"]


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def execute_tensor_inference_timeout_mock(*args: Any) -> dict[str, Any]:
    raise TimeoutError("Inference timeout simulated.")


@pytest.mark.asyncio
async def test_inference_timeout_throws_epistemic_yield() -> None:
    manifest = NeurosymbolicVerificationTopologyManifest(
        proposer_node_cid="did:coreason:agent-111",
        verifier_node_cid="did:coreason:system-222",
        # no critique_schema_cid
        max_revision_loops=3,
        nodes={
            "did:coreason:agent-111": CognitiveAgentNodeProfile(description="Proposer", topology_class="agent"),
            "did:coreason:system-222": CognitiveSystemNodeProfile(description="Verifier", topology_class="system"),
        },
    )
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H00000000000000000000000", span_cid="01H00000000000000000000001"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )
    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neurosymbolic-test-queue-2",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                execute_tensor_inference_timeout_mock,
                execute_system_function_mock,
                store_epistemic_mock,
                record_token_burn_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with pytest.raises(Exception) as exc_info:
                await env.client.execute_workflow(
                    NeurosymbolicVerificationExecutionWorkflow.run,
                    payload,
                    id="neurosymbolic-test-workflow-2",
                    task_queue="neurosymbolic-test-queue-2",
                )

            err = exc_info.value
            cause = getattr(err, "cause", None)
            assert cause is not None
            assert "EpistemicYieldError" in getattr(cause, "type", "") or "EpistemicYieldError" in str(cause)
            assert "timeout" in str(cause).lower()


@pytest.mark.asyncio
async def test_max_revision_loops_exhausted_no_critique_cid() -> None:
    """Max revision loops exhausted without critique schema returns epistemic_yield and hits the dict branch."""
    manifest = NeurosymbolicVerificationTopologyManifest(
        proposer_node_cid="did:coreason:proposer",
        verifier_node_cid="did:coreason:verifier",
        # critique_schema_cid is None here
        max_revision_loops=1,
        nodes={
            "did:coreason:proposer": CognitiveAgentNodeProfile(description="Proposer", topology_class="agent"),
            "did:coreason:verifier": CognitiveSystemNodeProfile(description="Verifier", topology_class="system"),
        },
    )
    # Manually change the node to be a dictionary to test `if isinstance(profile, dict):`
    dumped = manifest.model_dump(mode="json")
    dumped["nodes"]["did:coreason:verifier"] = {"topology_class": "system", "description": "Verifier"}

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H00000000000000000000000", span_cid="01H00000000000000000000001"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=dumped,
    )

    # We must patch the workflow so that when it runs model_validate_json it uses dict instead of model?
    # Actually Pydantic will convert dicts back to CognitiveSystemNodeProfile, so `isinstance(profile, dict)` will never trigger
    # from the envelope. We can just test the else branch for critique_schema_cid by omitting it.

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="neuro-exhaust-queue-2",
            workflows=[NeurosymbolicVerificationExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_proposer_agent,
                stub_verifier_fail,
                store_epistemic_mock,
                record_token_burn_mock,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                NeurosymbolicVerificationExecutionWorkflow.run,
                payload,
                id="neuro-exhaust-test-2",
                task_queue="neuro-exhaust-queue-2",
            )

    assert result["status"] == "epistemic_yield"
    assert "Maximum" in result["reason"]
