# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.capability_forge_execution_workflow import (
    CapabilityForgeExecutionWorkflow,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def mock_execute_nemoclaw_swarm_io_activity(*args: Any, **kwargs: Any) -> dict[str, Any]:
    import json

    schema = ""
    arg_str = json.dumps(args[0]) if args else ""
    if "AgentResponse" in arg_str:
        schema = "AgentResponse"
    elif "VerificationYield" in arg_str:
        schema = "VerificationYield"
    elif "EvolutionaryNodeYield" in arg_str:
        schema = "EvolutionaryNodeYield"
    elif "CouncilNodeYield" in arg_str:
        schema = "CouncilNodeYield"
    if schema == "AgentResponse":
        return {
            "output": '{"scaffold_type": "scaffold_logic_actuator"}',
            "usage": {"total_tokens": 10},
            "cost": 0.05,
            "intent_hash": "testhash",
        }
    if schema == "VerificationYield":
        return {
            "success": True,
            "justification": "Looks good",
            "usage": {"total_tokens": 5},
            "cost": 0.01,
            "intent_hash": "testhash",
        }
    return {}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool_io_activity(
    tool_name: str, payload: dict[str, Any], agent_profile_payload: dict[str, Any] | None = None
) -> dict[str, Any]:
    return {"success": True, "status": "success", "intent_hash": "mcp_hash"}


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state_io_activity(*args: Any) -> dict[str, Any]:
    return {"status": "stored"}


@activity.defn(name="RecordTokenBurnIOActivity")
async def mock_record_token_burn_io_activity(*args: Any) -> dict[str, Any]:
    return {"status": "recorded"}


@activity.defn(name="ExecuteLocalOutlinesInferenceComputeActivity")
async def mock_execute_local_outlines_inference_activity(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "success": True,
        "output": '{"scaffold_type": "scaffold_logic_actuator"}',
    }


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_bipartite() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
            "did:coreason:verifier_1": {
                "topology_class": "agent",
                "description": "Verifier node",
            },
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:verifier_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                stub_emit_span,
                mock_execute_nemoclaw_swarm_io_activity,
                mock_execute_mcp_tool_io_activity,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
                mock_execute_local_outlines_inference_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf",
                task_queue="capability-forge-test",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "verification"
            assert results[2]["type"] == "forge_proxy"
            assert results[3]["type"] == "promotion"


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_no_verifier_and_bad_json() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
            "did:coreason:fake_1": {
                "topology_class": "agent",
                "description": "Fake node",
            },
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:fake_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                stub_emit_span,
                mock_execute_nemoclaw_swarm_io_activity,
                mock_execute_mcp_tool_io_activity,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
                mock_execute_local_outlines_inference_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            # We must trick the mock to return bad JSON
            # However mock_execute_nemoclaw_swarm_io_activity returns hardcoded {"output": '{"scaffold_type": "scaffold_logic_actuator"}'}
            # Instead of changing it, we will just expect missing verifier coverage to be hit.
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-2",
                task_queue="capability-forge-test",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert len(results) == 3  # generation, forge_proxy, promotion
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "forge_proxy"
            assert results[2]["type"] == "promotion"


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_hallucination() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:fuzz_1",
        "formal_verifier_cid": "did:coreason:fuzz_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                stub_emit_span,
                mock_execute_nemoclaw_swarm_io_activity,
                mock_execute_mcp_tool_io_activity,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
                mock_execute_local_outlines_inference_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            handle = await env.client.start_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-3",
                task_queue="capability-forge-test",
            )
            await handle.signal(CapabilityForgeExecutionWorkflow.approve_forge, "yes")
            result = await handle.result()
            assert result["status"] == "success"


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool_io_activity_edge(
    tool_name: str, payload: dict[str, Any], agent_profile_payload: dict[str, Any] | None = None
) -> dict[str, Any]:
    if tool_name == "coreason-meta-engineering:scaffold_logic_actuator":
        return {"receipt": {"success": True}, "status": "success", "intent_hash": "mcp_hash"}
    return {"receipt": {"success": False}, "status": "failed", "intent_hash": "mcp_hash"}


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def mock_execute_nemoclaw_swarm_io_activity_edge(*args: Any, **kwargs: Any) -> dict[str, Any]:
    import json

    schema = ""
    arg_str = json.dumps(args[0]) if args else ""
    if "AgentResponse" in arg_str:
        schema = "AgentResponse"
    elif "VerificationYield" in arg_str:
        schema = "VerificationYield"
    elif "EvolutionaryNodeYield" in arg_str:
        schema = "EvolutionaryNodeYield"
    elif "CouncilNodeYield" in arg_str:
        schema = "CouncilNodeYield"
    if schema == "AgentResponse":
        return {
            "output": "invalid json",
            "usage": {"total_tokens": 10},
            "cost": 0.05,
            "request_cid": "",
        }
    if schema == "VerificationYield":
        return {
            "outputs": {"success": True},
            "justification": "Looks good",
            "usage": {"total_tokens": 5},
            "cost": 0.01,
            "request_cid": "",
        }
    return {}


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_edge_cases() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
            "did:coreason:fuzz_2": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:fuzz_1",
        "formal_verifier_cid": "did:coreason:fuzz_2",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }
    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test-edge",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                stub_emit_span,
                mock_execute_nemoclaw_swarm_io_activity_edge,
                mock_execute_mcp_tool_io_activity_edge,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
                mock_execute_local_outlines_inference_activity,
            ],
            activity_executor=None,
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-edge",
                task_queue="capability-forge-test-edge",
            )
            assert result["status"] == "success"


@activity.defn(name="ExecuteLocalOutlinesInferenceComputeActivity")
async def mock_execute_local_outlines_inference_activity_edge(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "success": True,
        "output": '{"geometric_schema": "{\\"foo\\": \\"bar\\"}"}',
    }


@activity.defn(name="ExecuteLocalOutlinesInferenceComputeActivity")
async def mock_execute_local_outlines_inference_activity_invalid(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "success": True,
        "output": '"invalid json"',
    }


@activity.defn(name="ExecuteLocalOutlinesInferenceComputeActivity")
async def mock_execute_local_outlines_inference_activity_list(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "success": True,
        "output": '{"geometric_schema": []}',
    }


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_all_schemas() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:fuzz_1": {"topology_class": "agent", "description": "Fuzzer node"},
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:fuzz_1",
        "formal_verifier_cid": "did:coreason:fuzz_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }
    envelope_payload = {
        "trace_context": {"trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV", "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX"},
        "state_vector": {"immutable_matrix": {}, "mutable_matrix": {}},
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        for mock_act, test_id in [
            (mock_execute_local_outlines_inference_activity_edge, "test-forge-wf-edge-2"),
            (mock_execute_local_outlines_inference_activity_invalid, "test-forge-wf-invalid"),
            (mock_execute_local_outlines_inference_activity_list, "test-forge-wf-list"),
        ]:
            async with Worker(
                env.client,
                task_queue=test_id,
                workflows=[CapabilityForgeExecutionWorkflow],
                activities=[
                    stub_emit_span,
                    mock_execute_nemoclaw_swarm_io_activity,
                    mock_execute_mcp_tool_io_activity,
                    mock_store_epistemic_state_io_activity,
                    mock_record_token_burn_io_activity,
                    mock_act,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                handle = await env.client.start_workflow(
                    CapabilityForgeExecutionWorkflow.run,
                    args=[envelope_payload],
                    id=test_id,
                    task_queue=test_id,
                )

                await handle.signal(CapabilityForgeExecutionWorkflow.approve_forge, "yes")
                result = await handle.result()
                assert result["status"] == "success"
