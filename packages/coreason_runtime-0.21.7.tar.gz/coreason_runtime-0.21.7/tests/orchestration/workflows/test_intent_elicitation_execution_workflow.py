# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for IntentElicitationExecutionWorkflow.

Tests: low-entropy convergence (below threshold break), full iteration,
and scanner node fallback path.

All tests use Temporal time-skipping environments with physical stub activities — zero unittest.mock.
"""

from typing import Any

import pytest
from coreason_manifest import (
    ExecutionEnvelopeState,
    IntentElicitationTopologyManifest,
)
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    ObservationEvent,
    OracleExecutionReceipt,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.intent_elicitation_execution_workflow import (
    IntentElicitationExecutionWorkflow,
)

# ── Physical Stub Activities ──────────────────────────────────────────


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def stub_tensor_inference(*args: Any) -> dict[str, Any]:
    """Return a low-entropy result that breaks the loop on first round."""
    receipt = OracleExecutionReceipt(
        execution_hash="b" * 64,
        solver_urn="urn:coreason:solver:stub_intent_member",
        tokens_burned=15,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="stub-intent-req",
            timestamp=123.0,
            payload={"result": True, "entropy": 0.1},
        ).model_dump(mode="json")
    ]
    payload["intent_hash"] = "b" * 64
    payload["usage"] = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    payload["cost"] = 0.01
    payload["success"] = True
    return payload


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any) -> None:
    """Physical no-op stub."""


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_burn(*args: Any) -> None:
    """Physical no-op stub."""


ALL_STUBS = [stub_tensor_inference, stub_store_epistemic, stub_record_burn]

# ── Envelope Factory ──────────────────────────────────────────────────


def _build_intent_envelope(
    max_clarification_loops: int = 3,
) -> dict[str, Any]:
    """Build an ExecutionEnvelopeState for intent elicitation."""
    scanner_cid = "did:coreason:scanner-0"
    transmuter_cid = "did:coreason:transmuter-0"
    oracle_cid = "did:coreason:oracle-0"

    nodes: dict[str, CognitiveAgentNodeProfile] = {
        scanner_cid: CognitiveAgentNodeProfile(
            description="VLM Scanner Node",
            topology_class="agent",
        ),
        transmuter_cid: CognitiveAgentNodeProfile(
            description="Transmuter Node",
            topology_class="agent",
        ),
        oracle_cid: CognitiveAgentNodeProfile(
            description="Human Oracle Node",
            topology_class="agent",
        ),
    }

    manifest = IntentElicitationTopologyManifest(
        nodes=nodes,  # type: ignore[arg-type]
        max_clarification_loops=max_clarification_loops,
        scanner_node_cid=scanner_cid,
        transmuter_node_cid=transmuter_cid,
        human_oracle_cid=oracle_cid,
        raw_human_artifact_cid="artifact-001",
    )

    manifest_payload = manifest.model_dump(mode="json")
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest_payload,
    )
    return envelope.model_dump(mode="json")


# ── Tests ─────────────────────────────────────────────────────────────


class TestIntentElicitationExecutionWorkflow:
    """Physical Temporal tests for intent elicitation workflow."""

    @pytest.mark.asyncio
    async def test_low_entropy_converges_immediately(self) -> None:
        """Entropy below threshold causes immediate convergence on first round."""
        payload = _build_intent_envelope(max_clarification_loops=3)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-q1",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=[stub_emit_span, *ALL_STUBS],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-low-entropy",
                    task_queue="intent-q1",
                )

        assert result["status"] == "success"
        assert result["rounds"] == 0  # converged on first round
        assert result["intent"] is not None

    @pytest.mark.asyncio
    async def test_single_loop_iteration(self) -> None:
        """Single clarification loop produces correct structure."""
        payload = _build_intent_envelope(max_clarification_loops=1)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-q2",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=[stub_emit_span, *ALL_STUBS],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-single-loop",
                    task_queue="intent-q2",
                )

        assert result["status"] == "success"


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def stub_tensor_inference_high_entropy(*args: Any) -> dict[str, Any]:
    """Return a high-entropy result missing an intent hash to cover branch fallback logic."""
    receipt = OracleExecutionReceipt(
        execution_hash="b" * 64,
        solver_urn="urn:coreason:solver:stub_intent_member",
        tokens_burned=15,
    )
    payload = receipt.model_dump(mode="json")
    payload["evidence"] = [
        ObservationEvent(
            event_cid="stub-intent-req",
            timestamp=123.0,
            payload={"result": True, "entropy": 0.8},
        ).model_dump(mode="json")
    ]
    payload["outputs"] = {"result": True, "entropy": 0.8}
    payload["usage"] = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    payload["cost"] = 0.01
    payload["success"] = True
    # intent_hash explicitly omitted!
    return payload


HIGH_ENTROPY_STUBS = [stub_tensor_inference_high_entropy, stub_store_epistemic, stub_record_burn]


class TestIntentElicitationHighEntropy:
    """Evaluate structural fallback blocks natively via high-entropy stubs."""

    @pytest.mark.asyncio
    async def test_high_entropy_resolved_by_override(self) -> None:
        """Covers entropy wait_condition, receive_oracle_override signal, and intent_hash calculation fallback."""
        payload = _build_intent_envelope(max_clarification_loops=3)
        # Modify the payload to force `node_profile is None` organically!
        payload_data = payload["payload"]["payload"] if "payload" in payload.get("payload", {}) else payload["payload"]
        if isinstance(payload_data, str):
            import json

            payload_data = json.loads(payload_data)
            payload_data["scanner_node_cid"] = "did:coreason:missing-node"
            payload["payload"] = json.dumps(payload_data)
        elif isinstance(payload_data, dict):
            payload["payload"]["scanner_node_cid"] = "did:coreason:missing-node"

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-high",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=[stub_emit_span, *HIGH_ENTROPY_STUBS],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                import asyncio

                handle = await env.client.start_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-high-entropy",
                    task_queue="intent-high",
                )

                await asyncio.sleep(0.1)
                await handle.signal("receive_oracle_override", {"success": True, "override": "absolute_truth"})

                res = await handle.result()

        assert res["status"] == "success"
        assert res["intent"]["override"] == "absolute_truth"

    @pytest.mark.asyncio
    async def test_high_entropy_resolved_by_resolution(self) -> None:
        """Covers inject_oracle_resolution signal breaking inner loops organically."""
        payload = _build_intent_envelope(max_clarification_loops=1)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-high-res",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=[stub_emit_span, *HIGH_ENTROPY_STUBS],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                import asyncio

                handle = await env.client.start_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-high-resolution",
                    task_queue="intent-high-res",
                )

                await asyncio.sleep(0.1)
                await handle.signal("inject_oracle_resolution", {"status": "cleared"})

                res = await handle.result()

        assert res["status"] == "success"
        # Since override was not used and resolution allowed progress, it proceeds to increment round and loop again!
        assert res["rounds"] == 1
