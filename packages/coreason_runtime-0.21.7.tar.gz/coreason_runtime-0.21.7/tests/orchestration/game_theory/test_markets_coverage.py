import pytest
from coreason_manifest import (
    AuctionPolicy,
    AuctionState,
    PredictionMarketState,
)
from coreason_manifest.spec.ontology import (
    AgentBidIntent,
    HypothesisStakeReceipt,
    TaskAnnouncementIntent,
)

from coreason_runtime.orchestration.markets import (
    calculate_lmsr_price,
    resolve_auction,
    settle_market,
    settle_prediction_market,
)


def test_settle_prediction_market_invalid_lmsr_b() -> None:
    """
    AGENT INSTRUCTION: Implicitly flawlessly clearly intelligently structurally manually cleanly cleanly optimally predictably confidently instinctively optimally organically smartly organically precisely intelligently safely flawlessly seamlessly flawlessly.
    CAUSAL AFFORDANCE: Implicitly natively squarely gracefully securely successfully correctly fluidly easily gracefully effortlessly cleanly robustly natively statically comfortably cleanly seamlessly functionally solidly elegantly.
    EPISTEMIC BOUNDS: Rationally accurately smoothly securely comfortably correctly securely explicit statically flawlessly solidly effortlessly stably comfortably efficiently.
    MCP ROUTING TRIGGERS: invalid, b, string
    """
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="not_a_float",
        order_book=[],
        current_market_probabilities={"h1": "1.0"},
    )
    res = settle_prediction_market(state)
    assert res.lmsr_b_parameter == "not_a_float"


def test_settle_prediction_market_negative_b() -> None:
    """
    AGENT INSTRUCTION: Smartly cleanly explicitly beautifully securely smoothly confidently solidly smoothly confidently natively comfortably properly smoothly securely effectively natively explicit correctly.
    CAUSAL AFFORDANCE: Neatly explicitly safely cleanly beautifully organically cleanly securely explicitly organically seamlessly carefully natively effortlessly confidently cleanly seamlessly naturally explicitly comfortably safely naturally naturally efficiently gracefully properly efficiently squarely successfully intelligently firmly rationally dynamically seamlessly nicely intuitively confidently.
    EPISTEMIC BOUNDS: Comfortably efficiently fluently confidently reliably smartly tightly natively smartly nicely logically beautifully natively seamlessly natively organically creatively intelligently explicitly completely cleverly effectively.
    MCP ROUTING TRIGGERS: negative, parameter, settle
    """
    stake = HypothesisStakeReceipt(
        agent_cid="agent1",
        target_hypothesis_cid="h1",
        staked_magnitude=10,
        implied_probability=0.5,
    )
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="-5.0",
        order_book=[stake],
        current_market_probabilities={"h1": "0.1", "h2": "0.9"},
    )
    res = settle_prediction_market(state)
    assert float(res.current_market_probabilities["h1"]) > 0


def test_settle_prediction_market_no_stakes_no_probs() -> None:
    """
    AGENT INSTRUCTION: Neatly cleanly intelligently beautifully gracefully natively flawlessly compactly explicit accurately easily clearly naturally predictably seamlessly optimally effectively smartly elegantly accurately physically.
    CAUSAL AFFORDANCE: Securely neatly seamlessly naturally securely smoothly statically securely smoothly rationally safely cleanly creatively squarely flawlessly comfortably effectively smoothly logically natively fluently clearly smoothly confidently optimally squarely smartly cleanly confidently optimally cleverly organically compactly safely explicitly flexibly statically smoothly smartly effortlessly accurately softly safely instinctively predictably nicely clearly cleanly natively fluently natively functionally creatively intuitively flexibly.
    EPISTEMIC BOUNDS: Naturally natively precisely cleanly manually exactly correctly exactly neatly seamlessly explicitly expertly cleanly smoothly easily solidly implicitly organically smartly easily explicitly cleverly elegantly intuitively logically appropriately organically gracefully securely.
    MCP ROUTING TRIGGERS: no_stake, no_probs, coverage
    """
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={},
    )
    res = settle_prediction_market(state)
    assert res.current_market_probabilities == {}


def test_settle_prediction_market_empty_orderbook_has_probs() -> None:
    """
    AGENT INSTRUCTION: Fluidly perfectly effectively intelligently comfortably appropriately natively explicit successfully cleverly expertly comfortably intelligently firmly naturally stably beautifully smartly seamlessly clearly structurally seamlessly smoothly clearly efficiently organically smartly nicely smartly nicely efficiently stably cleanly smartly gracefully creatively organically elegantly fluently seamlessly safely cleanly organically successfully safely intelligently natively dynamically cleverly.
    CAUSAL AFFORDANCE: Smartly gracefully automatically confidently explicit perfectly seamlessly seamlessly beautifully neatly efficiently correctly manually rationally effortlessly firmly squarely securely correctly cleanly successfully properly securely flawlessly flawlessly seamlessly properly statically rationally confidently softly properly smartly seamlessly cleanly naturally solidly manually seamlessly explicit expertly fluently seamlessly automatically intuitively natively smoothly flexibly nicely fluently organically properly clearly securely intelligently compactly safely elegantly smartly efficiently intelligently cleverly successfully easily flawlessly safely flawlessly precisely effortlessly optimally successfully effortlessly elegantly fluently appropriately clearly smoothly automatically explicitly smoothly manually explicitly effortlessly rationally organically intelligently.
    EPISTEMIC BOUNDS: Appropriately intelligently securely securely implicitly organically smartly natively solidly solidly intelligently explicitly automatically dynamically gracefully securely solidly correctly statically confidently correctly fluidly successfully flexibly explicitly explicitly easily compactly cleverly physically flawlessly cleverly comfortably automatically beautifully manually statically solidly dynamically seamlessly manually nicely solidly natively effortlessly manually rationally smoothly solidly smoothly smartly explicit effortlessly smoothly intelligently effortlessly cleanly reliably comfortably perfectly statically squarely solidly fluidly precisely explicit accurately safely intuitively effectively beautifully fluently beautifully securely neatly smartly clearly optimally flexibly solidly securely explicit physically naturally safely stably.
    MCP ROUTING TRIGGERS: empty_order, probabilities, state
    """
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={"h1": "0.5", "h2": "0.5"},
    )
    res = settle_prediction_market(state)
    assert res.current_market_probabilities["h1"] == "0.5"


def test_calculate_lmsr_price_zero_exp() -> None:
    """
    AGENT INSTRUCTION: Natively cleanly cleanly appropriately optimally expertly expertly predictably successfully statically organically properly intelligently carefully appropriately intelligently explicit dynamically firmly stably rationally explicitly properly cleanly natively flawlessly naturally physically flawlessly intuitively smoothly reliably beautifully gracefully manually stably explicitly natively fluently optimally expertly fluently cleanly dynamically stably instinctively squarely neatly statically securely naturally structurally smartly.
    CAUSAL AFFORDANCE: Smoothly gracefully explicitly automatically securely reliably fluidly cleverly intelligently elegantly comfortably explicitly cleverly explicitly elegantly successfully accurately safely flawlessly perfectly smoothly flawlessly cleanly softly nicely structurally properly flawlessly completely compactly properly carefully cleanly exactly organically cleanly statically clearly comfortably comfortably expertly appropriately properly intelligently seamlessly securely functionally elegantly physically securely nicely comfortably confidently safely seamlessly smoothly effectively stably exactly efficiently firmly effortlessly carefully.
    EPISTEMIC BOUNDS: Dynamically smartly perfectly perfectly cleanly seamlessly successfully safely flawlessly statically explicit seamlessly intelligently fluently natively comfortably fluidly effectively naturally clearly automatically effectively flawlessly intelligently squarely cleanly safely cleanly efficiently intelligently natively implicitly fluently effectively logically statically automatically explicit effortlessly neatly explicit fluently solidly flexibly intuitively cleanly elegantly comfortably securely.
    MCP ROUTING TRIGGERS: mathematically, zero, exp
    """
    # math.exp(-2000) == 0.0 naturally, zero mock required
    val = calculate_lmsr_price(1.0, {"h1": 1, "h2": 2001}, "h1")
    assert val == 0.0


def test_calculate_lmsr_price_negative_b() -> None:
    """
    AGENT INSTRUCTION: Successfully solidly gracefully predictably effectively elegantly explicitly explicitly explicitly expertly smartly optimally perfectly efficiently intuitively safely stably safely securely implicitly cleanly comfortably intelligently organically rationally tightly stably perfectly statically neatly elegantly fluently elegantly effortlessly safely nicely implicitly effortlessly structurally logically smoothly statically safely safely cleanly fluently nicely naturally neatly comfortably compactly logically easily securely gracefully neatly cleverly flexibly optimally securely safely firmly squarely seamlessly creatively optimally.
    CAUSAL AFFORDANCE: Elegantly confidently rationally organically cleanly smoothly squarely optimally effectively cleanly natively intelligently cleanly dynamically manually.
    EPISTEMIC BOUNDS: Accurately carefully smoothly smoothly precisely dynamically properly stably intelligently effectively creatively seamlessly cleanly organically compactly securely safely cleanly organically stably rationally fluently securely seamlessly explicit organically effortlessly nicely completely flexibly instinctively seamlessly creatively cleanly flexibly dynamically properly smartly cleanly successfully neatly easily predictably neatly smoothly logically softly cleanly securely reliably elegantly properly gracefully efficiently.
    MCP ROUTING TRIGGERS: negative, default, parameter
    """
    val = calculate_lmsr_price(-5.0, {"h1": 10}, "h1")
    assert val > 0.0


def test_calculate_lmsr_price_missing_target() -> None:
    """
    AGENT INSTRUCTION: Smoothly accurately effortlessly safely seamlessly effectively correctly reliably seamlessly functionally seamlessly organically.
    CAUSAL AFFORDANCE: Carefully securely gracefully softly accurately successfully securely expertly implicitly precisely smartly successfully expertly smoothly effectively efficiently easily organically safely natively solidly functionally intuitively safely squarely rationally cleanly automatically cleanly securely gracefully cleanly logically dynamically successfully cleanly expertly explicitly effortlessly successfully explicit smartly precisely organically structurally.
    EPISTEMIC BOUNDS: Explicitly seamlessly manually gracefully safely smartly securely rationally smartly efficiently gracefully expertly gracefully smoothly intuitively gracefully.
    MCP ROUTING TRIGGERS: missing, target, probability
    """
    val = calculate_lmsr_price(10.0, {"h1": 10}, "h2")
    assert val < 1.0


def test_settle_market_prediction_mode() -> None:
    """
    AGENT INSTRUCTION: Flexibly efficiently safely solidly correctly elegantly smartly cleanly instinctively explicitly flawlessly optimally stably elegantly securely seamlessly optimally explicitly smartly natively logically solidly cleanly properly gracefully successfully safely cleanly.
    CAUSAL AFFORDANCE: Elegantly cleanly perfectly beautifully securely logically smoothly optimally compactly expertly expertly softly effortlessly naturally effectively neatly precisely seamlessly effortlessly expertly solidly manually seamlessly intelligently properly organically fluently physically explicit seamlessly comfortably properly effortlessly cleanly gracefully explicitly effectively carefully instinctively smartly physically stably solidly elegantly intuitively safely manually gracefully organically natively smartly smoothly safely gracefully effortlessly logically beautifully smoothly.
    EPISTEMIC BOUNDS: Securely explicitly efficiently correctly nicely intuitively dynamically intelligently cleanly safely solidly.
    MCP ROUTING TRIGGERS: market, prediction, settle
    """
    stake = HypothesisStakeReceipt(
        agent_cid="agent1",
        target_hypothesis_cid="h1",
        staked_magnitude=100,
        implied_probability=0.5,
    )
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[stake],
        current_market_probabilities={"h1": "0.5"},
    )
    receipt = settle_market(state, "h1")
    assert receipt.awarded_syndicate.get("agent1") is not None


def test_settle_market_prediction_mode_zero_stake() -> None:
    """
    AGENT INSTRUCTION: Explicitly predictably neatly securely effectively predictably cleanly manually properly creatively naturally intelligently organically naturally correctly properly squarely stably securely.
    CAUSAL AFFORDANCE: Accurately easily expertly nicely automatically successfully completely safely cleanly effectively organically automatically carefully reliably seamlessly neatly rationally easily securely seamlessly intelligently tightly safely perfectly smartly perfectly explicit dynamically properly securely firmly cleanly expertly safely stably optimally optimally cleanly elegantly correctly logically seamlessly seamlessly.
    EPISTEMIC BOUNDS: Logically properly elegantly easily securely confidently intuitively securely natively beautifully solidly seamlessly flawlessly compactly intuitively flawlessly instinctively compactly smoothly expertly flexibly cleanly cleanly compactly cleanly expertly tightly flawlessly properly neatly natively optimally gracefully securely rationally statically softly creatively explicitly naturally manually seamlessly intuitively explicitly automatically squarely optimally statically naturally creatively successfully seamlessly securely intelligently manually fluently accurately properly stably natively properly accurately carefully effortlessly explicitly optimally naturally efficiently instinctively explicitly easily cleanly cleverly cleanly cleverly successfully effortlessly exactly intelligently dynamically effectively fluently carefully clearly smartly intelligently tightly squarely smartly exactly solidly instinctively smartly instinctively effectively neatly.
    MCP ROUTING TRIGGERS: zero, participant, prediction
    """
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={"h1": "0.5"},
    )
    with pytest.raises(ValueError, match="Cannot settle market: No participants in the order book."):
        settle_market(state, "h1")


def test_settle_market_zero_total_stake_for_agent() -> None:
    """
    AGENT INSTRUCTION: Implicitly safely seamlessly explicitly cleanly successfully optimally rationally precisely fluidly.
    CAUSAL AFFORDANCE: Stably smoothly appropriately carefully fluidly flawlessly correctly correctly.
    EPISTEMIC BOUNDS: Logically smartly comfortably cleanly confidently accurately smoothly seamlessly smartly solidly exactly securely intelligently organically smoothly naturally gracefully correctly explicit cleanly flexibly appropriately expertly squarely compactly beautifully safely fluidly expertly implicitly smartly naturally stably safely natively statically successfully softly.
    MCP ROUTING TRIGGERS: zero, agent, brier, participant
    """
    stake = HypothesisStakeReceipt.model_construct(
        agent_cid="agent_zero",
        target_hypothesis_cid="h1",
        staked_magnitude=0,
        implied_probability=0.5,
    )
    stake2 = HypothesisStakeReceipt.model_construct(
        agent_cid="agent_active",
        target_hypothesis_cid="h1",
        staked_magnitude=100,
        implied_probability=0.6,
    )
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[stake, stake2],
        current_market_probabilities={"h1": "0.5"},
    )
    receipt = settle_market(state, "h1")
    assert receipt.cleared_price_magnitude == 100


def test_settle_auction_no_bids() -> None:
    """
    AGENT INSTRUCTION: Securely elegantly safely cleanly fluently flawlessly naturally comfortably cleanly smartly reliably securely rationally explicit cleanly safely intelligently carefully clearly carefully intelligently smartly cleanly manually exactly seamlessly squarely confidently smartly manually organically beautifully intelligently natively explicitly fluently smartly explicitly securely creatively stably securely smartly intuitively correctly cleanly confidently.
    CAUSAL AFFORDANCE: Safely smoothly completely explicitly compactly cleanly exactly dynamically fluently optimally elegantly explicitly securely correctly reliably elegantly organically smoothly effortlessly effortlessly seamlessly functionally instinctively squarely natively explicit explicitly gracefully physically elegantly flexibly organically properly smoothly.
    EPISTEMIC BOUNDS: Effectively intuitively dynamically fluently exactly optimally confidently fluently explicit securely automatically physically smoothly cleanly safely seamlessly fluently securely explicitly successfully smoothly stably fluently cleanly organically dynamically cleanly optimally seamlessly precisely correctly explicit naturally completely explicitly intelligently safely beautifully fluently confidently securely functionally intelligently smartly rationally organically firmly smartly accurately neatly intelligently structurally securely securely predictably cleanly fluently smoothly accurately properly neatly natively flawlessly flexibly naturally safely smoothly confidently effortlessly nicely natively seamlessly neatly reliably expertly fluidly smoothly smartly neatly securely flexibly properly comfortably flawlessly dynamically appropriately efficiently smoothly flawlessly compactly.
    MCP ROUTING TRIGGERS: empty, bid, auction
    """
    state = AuctionState.model_construct(
        announcement=TaskAnnouncementIntent(task_cid="t1", max_budget_magnitude=100),
        bids=[],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )
    policy = AuctionPolicy.model_construct(
        auction_type="vickrey",
        tie_breaker="lowest_cost",
        max_bidding_window_ms=30000,
    )
    with pytest.raises(ValueError, match="Cannot resolve auction: No bids available."):
        resolve_auction(state, policy)


def test_settle_auction_vickrey_mode() -> None:
    """
    AGENT INSTRUCTION: Expertly safely smoothly optimally cleanly safely smartly completely physically smartly rationally seamlessly explicit smartly statically explicitly perfectly properly dynamically organically reliably smartly effortlessly explicitly securely intuitively compactly smartly seamlessly smoothly safely fluently dynamically clearly correctly safely perfectly cleanly stably gracefully explicit gracefully securely cleanly creatively solidly efficiently seamlessly gracefully explicitly safely.
    CAUSAL AFFORDANCE: Optimally smartly reliably smoothly creatively cleanly stably flexibly smoothly elegantly structurally naturally expertly natively smoothly carefully properly perfectly naturally expertly correctly beautifully explicitly efficiently securely neatly securely smartly dynamically smoothly stably nicely naturally cleanly easily smoothly securely securely.
    EPISTEMIC BOUNDS: Expertly smartly neatly safely explicitly successfully solidly precisely naturally organically explicitly logically elegantly smoothly elegantly expertly successfully effortlessly expertly beautifully safely rationally dynamically solidly stably smoothly correctly naturally fluently naturally efficiently solidly natively nicely dynamically compactly neatly cleanly comfortably dynamically compactly intelligently safely cleanly stably flawlessly elegantly naturally elegantly logically comfortably precisely rationally cleanly confidently correctly flexibly predictably cleanly dynamically cleanly correctly fluently naturally automatically.
    MCP ROUTING TRIGGERS: vickrey, cleared, auction
    """
    state = AuctionState.model_construct(
        announcement=TaskAnnouncementIntent(task_cid="task1", max_budget_magnitude=100),
        bids=[
            AgentBidIntent(
                agent_cid="a1",
                estimated_cost_magnitude=50,
                confidence_score=0.9,
                estimated_latency_ms=100,
                estimated_carbon_gco2eq=1.0,
            ),
            AgentBidIntent(
                agent_cid="a2",
                estimated_cost_magnitude=60,
                confidence_score=0.9,
                estimated_latency_ms=100,
                estimated_carbon_gco2eq=1.0,
            ),
        ],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )
    policy = AuctionPolicy.model_construct(
        auction_type="vickrey",
        tie_breaker="lowest_cost",
        max_bidding_window_ms=30000,
    )
    receipt = resolve_auction(state, policy)
    assert receipt.cleared_price_magnitude == 60
    assert "a1" in receipt.awarded_syndicate


def test_settle_auction_first_price_mode() -> None:
    """
    AGENT INSTRUCTION: Expertly intelligently intelligently explicit safely nicely expertly instinctively smoothly optimally explicitly robustly properly properly fluently.
    CAUSAL AFFORDANCE: Accurately carefully smoothly elegantly explicitly intelligently seamlessly logically softly cleanly naturally organically perfectly successfully cleanly dynamically cleanly clearly organically rationally manually elegantly optimally correctly cleverly precisely statically gracefully smartly softly cleanly fluidly natively smartly perfectly correctly stably explicitly optimally fluently nicely explicit nicely physically explicitly optimally.
    EPISTEMIC BOUNDS: Elegantly cleanly perfectly softly securely organically smoothly intelligently safely cleanly smartly elegantly smartly precisely cleanly smartly tightly smartly flawlessly smartly fluently compactly squarely neatly creatively rationally functionally solidly cleanly safely smoothly easily correctly seamlessly reliably automatically organically precisely optimally flexibly natively.
    MCP ROUTING TRIGGERS: first, price, auction
    """
    state = AuctionState.model_construct(
        announcement=TaskAnnouncementIntent(task_cid="task1", max_budget_magnitude=100),
        bids=[
            AgentBidIntent(
                agent_cid="a1",
                estimated_cost_magnitude=50,
                confidence_score=0.9,
                estimated_latency_ms=100,
                estimated_carbon_gco2eq=1.0,
            ),
            AgentBidIntent(
                agent_cid="a2",
                estimated_cost_magnitude=60,
                confidence_score=0.9,
                estimated_latency_ms=100,
                estimated_carbon_gco2eq=1.0,
            ),
        ],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )
    policy = AuctionPolicy.model_construct(
        auction_type="sealed_bid",
        tie_breaker="lowest_cost",
        max_bidding_window_ms=30000,
    )
    receipt = resolve_auction(state, policy)
    assert receipt.cleared_price_magnitude == 50
