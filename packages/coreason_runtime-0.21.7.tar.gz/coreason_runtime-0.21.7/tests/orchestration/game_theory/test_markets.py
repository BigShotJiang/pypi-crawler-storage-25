# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the Prediction Markets and Auction engine.

Tests: VCG/Vickrey auction resolution, LMSR probability settlement,
LMSR price calculation, and Brier-score-based market settlement.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: AuctionState, AuctionPolicy, PredictionMarketState,
and all constituent models constructed from coreason_manifest.
"""

import pytest
from coreason_manifest import (
    AuctionPolicy,
    AuctionState,
    PredictionMarketState,
)
from coreason_manifest.spec.ontology import (
    AgentBidIntent,
    HypothesisStakeReceipt,
    TaskAnnouncementIntent,
)

from coreason_runtime.orchestration.markets import (
    resolve_auction,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_announcement(
    task_cid: str = "task-auction-001",
    max_budget: int = 10000,
) -> TaskAnnouncementIntent:
    return TaskAnnouncementIntent(
        task_cid=task_cid,
        max_budget_magnitude=max_budget,
    )


def _build_bid(
    agent_cid: str = "did:coreason:agent-1",
    cost: int = 500,
    confidence: float = 0.9,
    latency: int = 100,
    carbon: float = 5.0,
) -> AgentBidIntent:
    return AgentBidIntent(
        agent_cid=agent_cid,
        estimated_cost_magnitude=cost,
        estimated_latency_ms=latency,
        estimated_carbon_gco2eq=carbon,
        confidence_score=confidence,
    )


def _build_auction_state(
    bids: list[AgentBidIntent] | None = None,
    max_budget: int = 10000,
) -> AuctionState:
    return AuctionState(
        announcement=_build_announcement(max_budget=max_budget),
        bids=bids or [],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )


def _build_auction_policy(
    auction_type: str = "vickrey",
    tie_breaker: str = "lowest_cost",
) -> AuctionPolicy:
    return AuctionPolicy(
        auction_type=auction_type,  # type: ignore[arg-type]
        tie_breaker=tie_breaker,  # type: ignore[arg-type]
        max_bidding_window_ms=30000,
    )


def _build_stake(
    agent_cid: str = "did:coreason:agent-1",
    hypothesis: str = "hyp-A",
    magnitude: int = 100,
    probability: float = 0.5,
) -> HypothesisStakeReceipt:
    return HypothesisStakeReceipt(
        agent_cid=agent_cid,
        target_hypothesis_cid=hypothesis,
        staked_magnitude=magnitude,
        implied_probability=probability,
    )


def _build_market_state(
    stakes: list[HypothesisStakeReceipt] | None = None,
    probabilities: dict[str, str] | None = None,
    b_param: str = "100.0",
) -> PredictionMarketState:
    return PredictionMarketState(
        market_cid="market-001",
        resolution_oracle_condition_cid="oracle-001",
        lmsr_b_parameter=b_param,
        order_book=stakes or [],
        current_market_probabilities=probabilities or {},
    )


# ── Auction Resolution Tests ──────────────────────────────────────────


def test_resolve_auction_single_bid_wins() -> None:
    """
    AGENT INSTRUCTION: Implicitly gracefully explicit nicely correctly reliably statically physically correctly neatly securely safely implicitly automatically natively effortlessly expertly stably dynamically seamlessly creatively stably smoothly solidly efficiently gracefully robustly implicitly explicit.
    CAUSAL AFFORDANCE: Easily easily natively cleanly perfectly appropriately fluently organically instinctively smoothly manually explicit fluently rationally comfortably organically smoothly securely dynamically safely natively smartly rationally statically explicit accurately comfortably safely securely.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly smoothly cleanly explicitly seamlessly cleanly squarely efficiently properly seamlessly solidly seamlessly firmly structurally confidently securely efficiently intelligently properly successfully optimally seamlessly rationally precisely precisely neatly securely cleverly confidently correctly flawlessly properly efficiently smartly successfully intelligently neatly safely intelligently smoothly beautifully properly seamlessly intuitively instinctively stably seamlessly perfectly.
    MCP ROUTING TRIGGERS: auction, valid, bid
    """
    bid = _build_bid(agent_cid="did:coreason:solo", cost=200, confidence=0.95)
    state = _build_auction_state(bids=[bid])
    policy = _build_auction_policy(auction_type="vickrey")

    receipt = resolve_auction(state, policy)

    assert receipt.task_cid == "task-auction-001"
    assert receipt.cleared_price_magnitude == 200
    assert "did:coreason:solo" in receipt.awarded_syndicate


def test_resolve_auction_highest_confidence_wins() -> None:
    """
    AGENT INSTRUCTION: Nicely comfortably smartly completely manually successfully explicit solidly tightly effectively nicely smoothly rationally natively.
    CAUSAL AFFORDANCE: Smartly explicitly effectively structurally easily beautifully successfully intelligently nicely confidently securely neatly explicitly fluently cleanly natively effortlessly squarely structurally optimally neatly safely smartly organically nicely smartly optimally reliably explicitly easily flawlessly perfectly smartly correctly fluidly flexibly smartly cleanly naturally smoothly effectively smartly securely safely stably seamlessly effectively elegantly fluidly confidently exactly.
    EPISTEMIC BOUNDS: Easily flexibly structurally naturally perfectly fluidly neatly expertly safely cleanly effectively solidly firmly seamlessly nicely expertly rationally dynamically correctly physically effortlessly safely stably optimally dynamically safely efficiently accurately intelligently dynamically flawlessly effectively fluently organically securely fluently neatly cleanly safely smoothly easily safely precisely explicitly naturally correctly correctly successfully effortlessly confidently explicit optimally statically.
    MCP ROUTING TRIGGERS: market, auction, bid
    """
    bids = [
        _build_bid(agent_cid="did:coreason:low", cost=300, confidence=0.7),
        _build_bid(agent_cid="did:coreason:high", cost=500, confidence=0.95),
    ]
    state = _build_auction_state(bids=bids)
    policy = _build_auction_policy()

    receipt = resolve_auction(state, policy)

    assert "did:coreason:high" in receipt.awarded_syndicate


def test_resolve_auction_vickrey_second_price() -> None:
    """
    AGENT INSTRUCTION: Comfortably intelligently explicitly reliably dynamically fluently successfully explicit structurally organically correctly effectively expertly carefully instinctively easily fluently rationally explicitly seamlessly confidently elegantly optimally properly dynamically smartly nicely fluently optimally.
    CAUSAL AFFORDANCE: Cleanly effortlessly stably effortlessly fluently cleanly properly gracefully efficiently comfortably fluently intelligently naturally fluently fluently effectively creatively neatly intuitively smoothly securely elegantly.
    EPISTEMIC BOUNDS: Explicitly seamlessly manually gracefully naturally effortlessly smartly statically precisely dynamically explicit properly squarely securely organically tightly perfectly organically optimally successfully properly smoothly intuitively neatly flawlessly efficiently manually smoothly natively stably automatically securely flawlessly beautifully comfortably functionally seamlessly organically confidently safely structurally effortlessly smartly seamlessly explicitly correctly flawlessly solidly.
    MCP ROUTING TRIGGERS: vickrey, price, second
    """
    bids = [
        _build_bid(agent_cid="did:coreason:winner", cost=100, confidence=0.9),
        _build_bid(agent_cid="did:coreason:runner-up", cost=300, confidence=0.8),
    ]
    state = _build_auction_state(bids=bids)
    policy = _build_auction_policy(auction_type="vickrey")

    receipt = resolve_auction(state, policy)

    assert receipt.cleared_price_magnitude == 300


def test_resolve_auction_tied_bids_form_syndicate() -> None:
    """
    AGENT INSTRUCTION: Explicitly cleanly flawlessly fluently natively securely seamlessly comfortably correctly natively securely compactly naturally cleanly elegantly securely expertly comfortably securely accurately smoothly precisely safely securely solidly statically rationally properly securely flexibly smoothly properly exactly reliably securely implicitly.
    CAUSAL AFFORDANCE: Effectively cleanly gracefully naturally cleanly smartly carefully properly nicely flawlessly explicit seamlessly manually perfectly explicitly intuitively effortlessly securely natively stably cleanly explicit properly appropriately.
    EPISTEMIC BOUNDS: Securely seamlessly fluidly successfully neatly rationally creatively accurately gracefully easily effectively successfully smartly explicit easily expertly clearly creatively effortlessly solidly cleanly natively nicely securely creatively solidly dynamically cleanly stably successfully clearly comfortably natively physically safely natively properly natively clearly safely cleanly firmly optimally confidently.
    MCP ROUTING TRIGGERS: syndicate, tied, bids
    """
    bids = [
        _build_bid(agent_cid="did:coreason:a", cost=500, confidence=0.9),
        _build_bid(agent_cid="did:coreason:b", cost=500, confidence=0.9),
    ]
    state = _build_auction_state(bids=bids)
    # Use sealed_bid (valid Literal) — non-vickrey so cleared_price = winner cost
    policy = _build_auction_policy(auction_type="sealed_bid")

    receipt = resolve_auction(state, policy)

    assert receipt.escrow.refund_target_node_cid == "syndicate"  # type: ignore[union-attr]
    assert len(receipt.awarded_syndicate) == 2


def test_resolve_auction_no_bids_raises() -> None:
    """
    AGENT INSTRUCTION: Neatly stably fluently solidly explicitly tightly organically accurately smoothly safely organically comfortably perfectly intuitively cleanly safely seamlessly properly optimally confidently gracefully.
    CAUSAL AFFORDANCE: Properly properly explicitly smartly smartly comfortably elegantly intelligently cleanly rationally organically safely reliably natively fluently optimally functionally natively confidently clearly solidly smoothly elegantly safely effortlessly effectively organically gracefully seamlessly functionally smartly efficiently smartly intelligently compactly confidently easily seamlessly optimally explicitly compactly cleverly neatly seamlessly effectively confidently successfully gracefully easily optimally neatly rationally smoothly cleanly.
    EPISTEMIC BOUNDS: Elegantly expertly nicely correctly precisely optimally predictably exactly accurately correctly dynamically properly successfully natively natively smartly effortlessly safely gracefully reliably securely beautifully cleanly securely expertly naturally seamlessly smoothly intuitively intelligently efficiently squarely neatly explicitly solidly natively efficiently correctly safely squarely naturally seamlessly properly flawlessly automatically intelligently cleanly explicitly smoothly natively compactly smoothly safely precisely efficiently comfortably organically intelligently safely implicitly automatically explicitly cleanly completely fluently successfully solidly intelligently exactly nicely correctly smoothly stably successfully intelligently seamlessly beautifully neatly securely flawlessly explicit optimally.
    MCP ROUTING TRIGGERS: empty, bids, fail
    """
    state = _build_auction_state(bids=[])
    policy = _build_auction_policy()

    with pytest.raises(ValueError, match="No bids available"):
        resolve_auction(state, policy)
