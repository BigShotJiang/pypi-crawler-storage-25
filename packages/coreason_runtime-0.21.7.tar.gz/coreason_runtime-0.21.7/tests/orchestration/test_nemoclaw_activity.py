import httpx
import pytest
import respx
from coreason_manifest import MCPPromptReferenceState, MCPResourceManifest
from hypothesis import given, settings
from hypothesis import strategies as st
from temporalio.testing import ActivityEnvironment

from coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp import NemoClawBridgeClient
from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.fixture
def activity_env() -> ActivityEnvironment:
    return ActivityEnvironment()


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities("memory")


@pytest.mark.asyncio
@respx.mock
async def test_execute_nemoclaw_swarm_io_activity_success(
    activity_env: ActivityEnvironment, activities: KineticActivities
) -> None:
    respx.post("https://nemoclaw:8443/v1/mcp/urn:coreason:oracle:nemoclaw/tools/call").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "success",
                "iterations": 1,
                "results": [{"status": "success", "intent_hash": "NEMOCLAW_REAL"}],
            },
        )
    )
    result = await activity_env.run(activities.execute_nemoclaw_swarm_io_activity, {"some": "data"})
    assert result["status"] == "success"
    assert result["results"][0]["intent_hash"] == "NEMOCLAW_REAL"


@pytest.mark.asyncio
@respx.mock
async def test_execute_nemoclaw_swarm_io_activity_exception(
    activity_env: ActivityEnvironment, activities: KineticActivities
) -> None:
    respx.post("https://nemoclaw:8443/v1/mcp/urn:coreason:oracle:nemoclaw/tools/call").mock(
        return_value=httpx.Response(500, json={"error": "NemoClaw connection failed"})
    )
    result = await activity_env.run(activities.execute_nemoclaw_swarm_io_activity, {"TEST_TRIGGER_EXCEPTION": True})
    assert result["status"] == "error"
    assert result["reason"] == "nemoclaw_connection_failed"


@respx.mock
@pytest.mark.asyncio
async def test_nemoclaw_bridge_client_exceptions() -> None:
    client = NemoClawBridgeClient()
    respx.post("https://nemoclaw:8443/v1/mcp/urn:test/test").mock(
        return_value=httpx.Response(404, json={"error": "Not Found"})
    )
    with pytest.raises(ManifestConformanceError, match="NemoClaw HTTP error"):
        await client._post_payload("urn:test", "test", {})

    respx.post("https://nemoclaw:8443/v1/mcp/urn:test/test_conn").mock(side_effect=httpx.ConnectError("Network error"))
    with pytest.raises(Exception, match="NemoClaw communication failure"):
        await client._post_payload("urn:test", "test_conn", {})


# Cert logic stripped from NemoClawBridgeClient


@respx.mock
@pytest.mark.asyncio
async def test_nemoclaw_bridge_methods() -> None:
    client = NemoClawBridgeClient()

    # hydrate_prompt
    respx.post("https://nemoclaw:8443/v1/mcp/urn:test/prompts/get").mock(
        return_value=httpx.Response(200, json={"prompt": "test"})
    )
    prompt_state = MCPPromptReferenceState(server_cid="urn:test", prompt_name="p", arguments={"k": "v"})
    res = await client.hydrate_prompt(prompt_state)
    assert res == {"prompt": "test"}

    # read_resource
    respx.post("https://nemoclaw:8443/v1/mcp/urn:test/resources/read").mock(
        return_value=httpx.Response(200, json={"res": "data"})
    )
    resource_manifest = MCPResourceManifest(server_cid="urn:test", uris=["file:///test.txt"])
    res2 = await client.read_resource(resource_manifest)
    assert res2 == {"resources": [{"res": "data"}]}

    # request
    respx.post("https://nemoclaw:8443/v1/mcp/urn:test/custom/method").mock(
        return_value=httpx.Response(200, json={"custom": "method_data"})
    )
    res3 = await client.request("urn:test", "custom/method", {"arg": "val"})
    assert res3 == {"custom": "method_data"}


@respx.mock
@pytest.mark.asyncio
async def test_mcp_client_manager_shim() -> None:
    bridge = NemoClawBridgeClient()
    shim = bridge.get_client("urn:shim_test")

    respx.post("https://nemoclaw:8443/v1/mcp/urn:shim_test/shim/test").mock(
        return_value=httpx.Response(200, json={"shim": "works"})
    )

    # Test request with args
    res = await shim.request("shim/test", {"some": "arg"})
    assert res == {"shim": "works"}

    # Test request without args
    respx.post("https://nemoclaw:8443/v1/mcp/urn:shim_test/shim/test2").mock(
        return_value=httpx.Response(200, json={"shim2": "works_no_args"})
    )
    res2 = await shim.request("shim/test2")
    assert res2 == {"shim2": "works_no_args"}


@settings(max_examples=10)
@given(
    server_cid=st.from_regex(r"^[a-zA-Z0-9_-]+$", fullmatch=True),
    method=st.from_regex(r"^[a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+$", fullmatch=True),
    arguments=st.dictionaries(
        st.text(alphabet="abcdefghijklmnopqrstuvwxyz"), st.text(alphabet="abcdefghijklmnopqrstuvwxyz")
    ),
)
@pytest.mark.asyncio
async def test_nemoclaw_hypothesis(server_cid: str, method: str, arguments: dict[str, str]) -> None:
    bridge = NemoClawBridgeClient()
    shim = bridge.get_client(server_cid)

    with respx.mock:
        route = respx.post(f"https://nemoclaw:8443/v1/mcp/{server_cid}/{method}").mock(
            return_value=httpx.Response(200, json={"echo": arguments})
        )
        res = await shim.request(method, arguments)
        assert res == {"echo": arguments}
        assert route.called
