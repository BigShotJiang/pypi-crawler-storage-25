# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.mark.asyncio
async def test_store_epistemic_state_attestation() -> None:
    activities = KineticActivities(memory_path="memory://test")

    class FakeLedger:
        async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
            pass

    class FakeLatent:
        async def upsert_projection(self, *_args: Any, **_kwargs: Any) -> None:
            pass

    cast("Any", activities).ledger = FakeLedger()
    cast("Any", activities).latent = FakeLatent()
    cast("Any", activities)._generate_dense_vector = AsyncMock(return_value=[0.1])

    payload = {
        "topology_class": "verdict",
        "event_cid": "event_123",
        "timestamp": 123456789.0,
        "intervention_request_cid": "req_123",
        "target_node_cid": "did:example:123",
        "approved": True,
        "feedback": "good",
        "attestation": {
            "mechanism": "urn:coreason:human",
            "did_subject": "did:example:123",
            "cryptographic_payload": "sig_123",
            "dag_node_nonce": "req_123",
            "liveness_challenge_hash": "0" * 64,
        },
    }

    result = await activities.store_epistemic_state_io_activity("w1", "UNKNOWN_HASH", True, payload)
    assert result["status"] == "gold_crystallized"


@pytest.mark.asyncio
async def test_store_epistemic_state_data_no_inputs() -> None:
    activities = KineticActivities(memory_path="memory://test")

    class FakeLedger:
        async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
            pass

    cast("Any", activities).ledger = FakeLedger()

    payload = {
        "data": {"result": "success"},
        "parent_request_cid": "p1",
        "root_request_cid": "r1",
        "parent_hashes": ["0" * 64],
        "node_hash": "0" * 64,
    }

    result = await activities.store_epistemic_state_io_activity("w1", "h1", True, payload)
    assert result["status"] == "gold_crystallized"


@pytest.mark.asyncio
async def test_record_token_burn_error() -> None:
    activities = KineticActivities(memory_path="memory://test")

    class FakeLedger:
        async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
            raise ValueError("Test error")

    cast("Any", activities).ledger = FakeLedger()

    result = await activities.record_token_burn_io_activity(
        "w1",
        {
            "event_cid": "e1",
            "timestamp": 1234.0,
            "topology_class": "token_burn",
            "tool_invocation_cid": "tic1",
            "input_tokens": 10,
            "output_tokens": 20,
            "burn_magnitude": 0,
        },
    )
    assert result["status"] == "burn_capture_failed"
    assert "Test error" in result["error"]


@pytest.mark.asyncio
async def test_retrieve_latent_projection_compute_activity() -> None:
    pytest.skip("Requires physical Graphiti substrate")
    activities = KineticActivities(memory_path="memory://test")

    class FakeSearch:
        def __init__(self, cond: str = "") -> None:
            self.cond = cond

        def metric(self, name: str) -> Any:
            _ = name
            return self

        def where(self, cond: str) -> Any:
            self.cond = cond
            return self

        def limit(self, num: int) -> Any:
            _ = num
            return self

        def to_arrow(self) -> Any:
            return self

        def to_pylist(self) -> list[dict[str, Any]]:
            if "intent_hash" in self.cond:
                return [{"receipt_payload": '{"parent_hashes": ["hash1"]}'}]
            return [
                {"intent_hash": "hash1", "receipt_payload": '{"parent_hashes": ["hash2"]}', "_distance": 0.0},
                {"intent_hash": "hash2", "receipt_payload": '{"parent_hashes": []}', "_distance": 0.0},
            ]

    class FakeTable:
        def search(self, *args: Any, **kwargs: Any) -> FakeSearch:
            _, _ = args, kwargs
            return FakeSearch()

    class FakeLedger:
        def open_table(self, name: str) -> Any:
            _ = name
            return FakeTable()

        def list_tables(self) -> Any:
            return MagicMock(tables=["latent_space", "gold_crystallized"])

    cast("Any", activities).db = FakeLedger()
    cast("Any", activities).gold_table_name = "gold_crystallized"

    import base64
    import struct

    b64_vec = base64.b64encode(struct.pack("2f", 1.0, 1.0)).decode("utf-8")

    payload = {
        "topology_class": "latent_projection",
        "synthetic_target_vector": {
            "dimensionality": 2,
            "vector_base64": b64_vec,
            "foundation_matrix_name": "test_matrix",
        },
        "top_k_candidates": 2,
        "min_isometry_score": 0.9,
        "topological_bounds": {"max_hop_depth": 2, "allowed_causal_relationships": ["causes"]},
        "context_expansion": {"expansion_paradigm": "sliding_window", "max_token_budget": 1000},  # nosec B105
    }

    result = await activities.retrieve_latent_projection_compute_activity(payload)
    assert len(result) > 0


@pytest.mark.asyncio
async def test_execute_exogenous_shock() -> None:
    activities = KineticActivities(memory_path="memory://test")
    payload = {
        "event_cid": "e1",
        "timestamp": 123.0,
        "topology_class": "exogenous_event",
        "shock_cid": "s1",
        "target_node_hash": "0" * 64,
        "bayesian_surprise_score": 0.9,
        "synthetic_payload": {},
        "escrow": {"locked_magnitude": 100},
    }
    result = await activities.execute_exogenous_shock_compute_activity(payload)
    assert result["status"] == "success"


@pytest.mark.asyncio
async def test_execute_formal_verification() -> None:
    import sys
    from unittest.mock import MagicMock, patch

    from coreason_runtime.orchestration.activities import execute_formal_verification_compute_activity

    # Mock z3
    mock_z3 = MagicMock()
    mock_z3.sat = "sat"
    mock_solver = MagicMock()
    mock_solver.check.return_value = "sat"
    mock_z3.Solver.return_value = mock_solver

    with patch.dict(sys.modules, {"z3": mock_z3}):
        payload = {
            "handoff_cid": "0" * 128,
            "solver_protocol": "z3",
            "formal_grammar_payload": "(declare-const x Int) (assert (> x 0))",
            "timeout_ms": 1000,
        }
        result = await execute_formal_verification_compute_activity(payload)
        assert result["status"] == "success"

    # Mock lean4
    mock_lean = MagicMock()
    mock_server = MagicMock()
    mock_server.sync_eval.return_value = MagicMock(error=False)
    mock_lean.server.LeanServer.return_value = mock_server

    with patch.dict(sys.modules, {"lean_client": mock_lean, "lean_client.server": mock_lean.server}):
        payload = {
            "handoff_cid": "0" * 128,
            "solver_protocol": "lean4",
            "formal_grammar_payload": "theorem foo : True := trivial",
            "timeout_ms": 1000,
        }
        result = await execute_formal_verification_compute_activity(payload)
        assert result["status"] == "success"

    # Mock sympy by bypassing Pydantic
    mock_sympy = MagicMock()
    mock_sympy.sympify.return_value = "expr"
    with patch.dict(sys.modules, {"sympy": mock_sympy}):
        with patch("coreason_manifest.spec.ontology.NeuroSymbolicHandoffContract.model_validate") as mock_validate:
            mock_validate.return_value = MagicMock(
                handoff_cid="0" * 128,
                solver_protocol="sympy",
                formal_grammar_payload="x + 1",
                timeout_ms=1000,
            )
            payload = {
                "handoff_cid": "0" * 128,
                "solver_protocol": "sympy",
                "formal_grammar_payload": "x + 1",
                "timeout_ms": 1000,
            }
            result = await execute_formal_verification_compute_activity(payload)
            assert result["status"] == "success"


@pytest.mark.asyncio
async def test_execute_fhe_solver() -> None:
    import base64
    import sys
    from unittest.mock import MagicMock, patch

    from coreason_runtime.orchestration.activities import execute_fhe_solver_compute_activity

    mock_ts = MagicMock()
    mock_ts.SCHEME_TYPE.CKKS = "CKKS"
    mock_context = MagicMock()
    mock_ts.context.return_value = mock_context
    mock_vec1 = MagicMock()
    mock_vec2 = MagicMock()
    mock_vec1.dot.return_value = MagicMock(serialize=lambda: b"result")
    mock_ts.ckks_vector_from.side_effect = [mock_vec1, mock_vec2]

    with patch.dict(sys.modules, {"tenseal": mock_ts}):
        payload = {
            "public_key_cid": "did:example:123",
            "fhe_scheme": "ckks",
            "ciphertext_blob": base64.b64encode(b"test1").decode(),
            "operation": "dot_product",
            "crypto_parameters": {"enc_v2_b64": base64.b64encode(b"test2").decode()},
        }
        result = await execute_fhe_solver_compute_activity(payload)
        assert result.get("fhe_scheme") == "ckks"


@pytest.mark.asyncio
async def test_execute_silver_transformation() -> None:
    from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

    payload = {"data": [{"id": 1, "value": "test"}], "natural_keys": ["id"]}
    # It might fail with InvalidSchemaYieldError because of mock or missing, but it will cover the lines
    result = await execute_silver_transformation_compute_activity(payload)
    assert "status" in result


@pytest.mark.asyncio
async def test_execute_market_settlement() -> None:
    from coreason_runtime.orchestration.activities import execute_market_settlement_io_activity

    payload = {
        "market_cid": "m1_12345678",
        "lmsr_b_parameter": "100.0",
        "resolution_oracle_condition_cid": "cond1",
        "current_market_probabilities": {"h1_12345678": 0.8, "h2_12345678": 0.2},
        "order_book": [
            {
                "agent_cid": "did:example:123",
                "target_hypothesis_cid": "h1_12345678",
                "implied_probability": 0.8,
                "staked_magnitude": 10,
            },
            {
                "agent_cid": "did:example:456",
                "target_hypothesis_cid": "h2_12345678",
                "implied_probability": 0.2,
                "staked_magnitude": 10,
            },
        ],
    }
    result = await execute_market_settlement_io_activity(payload, "h1_12345678")
    assert result.get("settlement_status") == "cleared"


@pytest.mark.asyncio
async def test_execute_shapley_attribution() -> None:
    from coreason_runtime.orchestration.activities import execute_shapley_attribution_compute_activity

    result = await execute_shapley_attribution_compute_activity("100.0", ["did:example:1", "did:example:2"])
    assert len(result) == 2


@pytest.mark.asyncio
async def test_execute_verify_wetware_attestation() -> None:
    from unittest.mock import patch

    from coreason_runtime.orchestration.activities import execute_verify_wetware_attestation_activity

    payload = {"cryptographic_payload": "payload", "did_subject": "did:key:test123", "liveness_challenge_hash": "hash"}
    with patch("coreason_runtime.orchestration.activities.Fido2Verifier") as mock_fido:
        mock_fido.return_value.verify_hardware_signature.return_value = True
        result = await execute_verify_wetware_attestation_activity(payload)
        assert result["verification_status"] == "verified"


@pytest.mark.asyncio
async def test_execute_gaze_tracking() -> None:
    from unittest.mock import patch

    from coreason_runtime.orchestration.activities import execute_gaze_tracking_io_activity

    payload = {
        "origin": [0.0, 0.0, 0.0],
        "direction_unit_vector": [1.0, 0.0, 0.0],
        "hardware_signature": "signature",
        "active_bounding_boxes": [],
    }
    with patch("coreason_runtime.orchestration.activities.intersect_ray_with_nodes") as mock_intersect:
        mock_intersect.return_value = ["node1"]
        with patch("coreason_runtime.orchestration.activities.validate_normalized_vector"):
            result = await execute_gaze_tracking_io_activity(payload)
            assert result["trusted_hardware"] is True
