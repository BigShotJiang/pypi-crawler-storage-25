from unittest.mock import MagicMock

import pytest

from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_silver_transformation_compute_activity,
    execute_spatial_kinematic_compute_activity,
)


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities(memory_path="/tmp/mem")


@pytest.mark.asyncio
async def test_medallion_etl(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1315-1321
    mock_pl = MagicMock(return_value={"status": "etl_done"})
    monkeypatch.setattr(
        "coreason_runtime.epistemic_memory.epistemic_vectorization_policy.process_medallion_pipeline", mock_pl
    )

    res = await activities.execute_medallion_etl_compute_activity()
    assert res["status"] == "etl_done"


@pytest.mark.asyncio
async def test_spatial_kinematic() -> None:
    # 1711-1719
    res = await execute_spatial_kinematic_compute_activity({})
    assert res["success"] is False
    assert "forbidden" in res["error"]


@pytest.mark.asyncio
async def test_silver_transformation(monkeypatch: pytest.MonkeyPatch) -> None:
    # 1722-1758

    # Missing args
    res_miss = await execute_silver_transformation_compute_activity({})
    assert res_miss["status"] == "failed"

    # Success case
    payload = {"data": [{"entity_uuid": "e_1"}], "natural_keys": ["entity_uuid"]}

    # Mock Polars and EpistemicPolicy
    mock_df = MagicMock()
    monkeypatch.setattr("polars.DataFrame", MagicMock(return_value=mock_df))

    mock_lf = MagicMock()
    mock_lf.collect.return_value.height = 1
    mock_lf.collect.return_value.__getitem__.return_value.head.return_value.to_list.return_value = ["e_1"]
    mock_lf.collect.return_value.columns = ["entity_uuid"]

    mock_policy = MagicMock()
    mock_policy.transform.return_value = mock_lf
    monkeypatch.setattr(
        "coreason_runtime.epistemic_memory.epistemic_vectorization_policy.EpistemicVectorizationPolicy", mock_policy
    )

    res = await execute_silver_transformation_compute_activity(payload)
    assert res["status"] == "success"
    assert res["transformed_rows"] == 1

    # InvalidSchemaYieldError case
    from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import InvalidSchemaYieldError

    mock_policy.transform.side_effect = InvalidSchemaYieldError("schema err")
    res_err1 = await execute_silver_transformation_compute_activity(payload)
    assert res_err1["status"] == "rejected"
    assert "schema err" in res_err1["reason"]

    # General Exception case
    mock_policy.transform.side_effect = Exception("boom")
    res_err2 = await execute_silver_transformation_compute_activity(payload)
    assert res_err2["status"] == "failed"
    assert "boom" in res_err2["error"]
