import sys
from unittest.mock import MagicMock

import pytest

from coreason_runtime.orchestration.activities import KineticActivities, execute_formal_verification_compute_activity


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities(memory_path="/tmp/mem")


@pytest.mark.asyncio
async def test_neurosymbolic_lean4(monkeypatch: pytest.MonkeyPatch) -> None:
    # Without lean_client
    res_err = await execute_formal_verification_compute_activity(
        {"handoff_cid": "h1", "formal_grammar_payload": "theorem x", "solver_protocol": "lean4", "timeout_ms": 1000}
    )
    assert res_err["proof_valid"] is False

    # With mock lean_client
    mock_lean = MagicMock()
    mock_srv = MagicMock()
    mock_srv.sync_eval.return_value = MagicMock(error=False)
    mock_lean.server.LeanServer.return_value = mock_srv
    monkeypatch.setitem(sys.modules, "lean_client", mock_lean)

    res = await execute_formal_verification_compute_activity(
        {"handoff_cid": "h1", "formal_grammar_payload": "theorem x", "solver_protocol": "lean4", "timeout_ms": 1000}
    )
    assert res["proof_valid"] is True

    # Throwing lean error
    mock_srv.sync_eval.side_effect = Exception("lean broke")
    res2 = await execute_formal_verification_compute_activity(
        {"handoff_cid": "h1", "formal_grammar_payload": "theorem x", "solver_protocol": "lean4", "timeout_ms": 1000}
    )
    assert res2["proof_valid"] is False


@pytest.mark.asyncio
async def test_neurosymbolic_sympy(monkeypatch: pytest.MonkeyPatch) -> None:
    # With sympy success
    mock_sympy = MagicMock()
    mock_sympy.sympify.return_value = "expr_evaluated"
    monkeypatch.setitem(sys.modules, "sympy", mock_sympy)

    contract_mock = MagicMock()
    contract_mock.solver_protocol = "sympy"
    contract_mock.formal_grammar_payload = "x+1"
    contract_mock.handoff_cid = "h1"
    contract_mock.timeout_ms = 1000

    neuro_mock = MagicMock()
    neuro_mock.model_validate.return_value = contract_mock
    monkeypatch.setattr("coreason_manifest.spec.ontology.NeuroSymbolicHandoffContract", neuro_mock)

    res = await execute_formal_verification_compute_activity({"handoff_cid": "h1"})
    assert res["proof_valid"] is True

    # Sympy fails
    mock_sympy.sympify.side_effect = Exception("sympy fail")
    res2 = await execute_formal_verification_compute_activity({"handoff_cid": "h1"})
    assert res2["proof_valid"] is False


@pytest.mark.asyncio
async def test_neurosymbolic_unmapped(monkeypatch: pytest.MonkeyPatch) -> None:
    contract_mock = MagicMock()
    contract_mock.solver_protocol = "unknown_solver"
    contract_mock.handoff_cid = "h1"
    contract_mock.timeout_ms = 1000
    neuro_mock = MagicMock()
    neuro_mock.model_validate.return_value = contract_mock
    monkeypatch.setattr("coreason_manifest.spec.ontology.NeuroSymbolicHandoffContract", neuro_mock)

    res = await execute_formal_verification_compute_activity({"handoff_cid": "h1"})
    assert res["proof_valid"] is False
    assert "Verification Unavailable" in res["status"]
