"""Real tests for standalone activities in activities.py — no mocks.

Tests the module-level activity functions that don't require a Temporal worker.
"""

from typing import Any

import pytest


# ---------------------------------------------------------------------------
# execute_silver_transformation_compute_activity
# ---------------------------------------------------------------------------
class TestSilverTransformation:
    """Real Polars-based Silver ETL transformation."""

    @pytest.mark.asyncio
    async def test_success_path(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        payload = {
            "data": [
                {"first_name": "Alice", "last_name": "Smith", "age": 30},
                {"first_name": "Bob", "last_name": "Jones", "age": 25},
            ],
            "natural_keys": ["first_name", "last_name"],
        }
        result = await execute_silver_transformation_compute_activity(payload)
        assert result["status"] == "success"
        assert result["transformed_rows"] == 2
        assert "entity_uuid" in result["columns_mapped"]

    @pytest.mark.asyncio
    async def test_missing_data(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        result = await execute_silver_transformation_compute_activity({"data": [], "natural_keys": ["x"]})
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_missing_natural_keys(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        result = await execute_silver_transformation_compute_activity({"data": [{"a": 1}], "natural_keys": []})
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_invalid_keys_rejected(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        payload = {
            "data": [{"a": 1}],
            "natural_keys": ["nonexistent_column"],
        }
        result = await execute_silver_transformation_compute_activity(payload)
        assert result["status"] == "rejected"


# ---------------------------------------------------------------------------
# execute_spatial_kinematic_compute_activity
# ---------------------------------------------------------------------------
class TestSpatialKinematic:
    @pytest.mark.asyncio
    async def test_always_forbidden(self) -> None:
        from coreason_runtime.orchestration.activities import execute_spatial_kinematic_compute_activity

        result = await execute_spatial_kinematic_compute_activity({"intent": "click"})
        assert result["success"] is False
        assert "forbidden" in result["error"]


# ---------------------------------------------------------------------------
# execute_market_settlement_io_activity
# ---------------------------------------------------------------------------
class TestMarketSettlement:
    @pytest.mark.asyncio
    async def test_settlement_computes_brier(self) -> None:
        from coreason_manifest.spec.ontology import HypothesisStakeReceipt

        from coreason_runtime.orchestration.activities import execute_market_settlement_io_activity

        auction = {
            "market_cid": "mkt_001_test",
            "resolution_oracle_condition_cid": "oracle_001",
            "lmsr_b_parameter": "100.0",
            "current_market_probabilities": {"hyp_001_win": "0.6", "hyp_002_lose": "0.4"},
            "order_book": [
                HypothesisStakeReceipt(
                    agent_cid="did:key:agent_alpha",
                    target_hypothesis_cid="hyp_001_win",
                    implied_probability=0.9,
                    staked_magnitude=100,
                ).model_dump(),
                HypothesisStakeReceipt(
                    agent_cid="did:key:agent_bravo",
                    target_hypothesis_cid="hyp_002_lose",
                    implied_probability=0.7,
                    staked_magnitude=50,
                ).model_dump(),
            ],
        }
        result = await execute_market_settlement_io_activity(auction, "hyp_001_win")

        assert result.get("settlement_status") == "cleared"
        assert "brier_scores" in result
        assert result["winning_hypothesis_cid"] == "hyp_001_win"

    @pytest.mark.asyncio
    async def test_settlement_with_zero_payouts(self) -> None:
        """All agents bet wrong → zero weights → equal fallback distribution."""
        from coreason_manifest.spec.ontology import HypothesisStakeReceipt

        from coreason_runtime.orchestration.activities import execute_market_settlement_io_activity

        auction = {
            "market_cid": "mkt_002_test",
            "resolution_oracle_condition_cid": "oracle_002",
            "lmsr_b_parameter": "50.0",
            "current_market_probabilities": {"hyp_wrong_one": "0.5", "hyp_correct_ans": "0.5"},
            "order_book": [
                HypothesisStakeReceipt(
                    agent_cid="did:key:agent_x_test",
                    target_hypothesis_cid="hyp_wrong_one",
                    implied_probability=1.0,
                    staked_magnitude=100,
                ).model_dump(),
            ],
        }
        result = await execute_market_settlement_io_activity(auction, "hyp_correct_ans")
        assert result.get("settlement_status") == "cleared"


# ---------------------------------------------------------------------------
# execute_shapley_attribution_compute_activity
# ---------------------------------------------------------------------------
class TestShapleyAttribution:
    @pytest.mark.asyncio
    async def test_exact_shapley_small_coalition(self) -> None:
        from coreason_runtime.orchestration.activities import execute_shapley_attribution_compute_activity

        receipts = await execute_shapley_attribution_compute_activity(
            "100.0", ["did:key:agent_aaa", "did:key:agent_bbb", "did:key:agent_ccc"]
        )
        assert len(receipts) == 3
        for r in receipts:
            assert "causal_attribution_score" in r

    @pytest.mark.asyncio
    async def test_shapley_single_agent(self) -> None:
        from coreason_runtime.orchestration.activities import execute_shapley_attribution_compute_activity

        receipts = await execute_shapley_attribution_compute_activity("50.0", ["did:key:solo_agent"])
        assert len(receipts) == 1
        assert abs(receipts[0]["causal_attribution_score"] - 1.0) < 0.01

    @pytest.mark.asyncio
    async def test_shapley_empty_coalition(self) -> None:
        from coreason_runtime.orchestration.activities import execute_shapley_attribution_compute_activity

        receipts = await execute_shapley_attribution_compute_activity("10.0", [])
        assert receipts == []

    @pytest.mark.asyncio
    async def test_shapley_with_characteristic_values(self) -> None:
        from coreason_runtime.orchestration.activities import execute_shapley_attribution_compute_activity

        char_vals = {"did:key:agent_aaa": 30.0, "did:key:agent_aaa,did:key:agent_bbb": 80.0, "did:key:agent_bbb": 40.0}
        receipts = await execute_shapley_attribution_compute_activity(
            "100.0", ["did:key:agent_aaa", "did:key:agent_bbb"], char_vals
        )
        assert len(receipts) == 2


# ---------------------------------------------------------------------------
# execute_collective_intelligence_activity
# ---------------------------------------------------------------------------
class TestCollectiveIntelligence:
    @pytest.mark.asyncio
    async def test_multi_agent_synergy(self) -> None:
        from coreason_runtime.orchestration.activities import execute_collective_intelligence_activity

        result = await execute_collective_intelligence_activity(100.0, 3)
        assert result["synergy_index"] == 1.15

    @pytest.mark.asyncio
    async def test_single_agent_no_synergy(self) -> None:
        from coreason_runtime.orchestration.activities import execute_collective_intelligence_activity

        result = await execute_collective_intelligence_activity(100.0, 1)
        assert result["synergy_index"] == 1.0


# ---------------------------------------------------------------------------
# execute_verify_wetware_attestation_activity
# ---------------------------------------------------------------------------
class TestWetwareAttestation:
    @pytest.mark.asyncio
    async def test_invalid_signature_raises(self, mock_nemoclaw_bridge: Any) -> None:
        from coreason_runtime.orchestration.activities import execute_verify_wetware_attestation_activity

        contract = {
            "cryptographic_payload": "invalid_payload_abc",
            "did_subject": "did:key:z6MkTest",
            "liveness_challenge_hash": "challenge_hash_123",
        }
        from httpx import Response

        mock_nemoclaw_bridge.clear()
        mock_nemoclaw_bridge.post("http://localhost:8080/v1/verify/biometric").mock(
            return_value=Response(200, json={"valid": False})
        )

        with pytest.raises(ValueError, match="Invalid wetware attestation"):
            await execute_verify_wetware_attestation_activity(contract)


# ---------------------------------------------------------------------------
# execute_gaze_tracking_io_activity
# ---------------------------------------------------------------------------
class TestGazeTracking:
    @pytest.mark.asyncio
    async def test_invalid_direction_vector_size(self) -> None:
        from coreason_runtime.orchestration.activities import execute_gaze_tracking_io_activity

        payload = {
            "origin": [0.0, 0.0, 0.0],
            "direction_unit_vector": [1.0, 0.0],  # Wrong size
        }
        with pytest.raises(ValueError, match="Invalid direction"):
            await execute_gaze_tracking_io_activity(payload)

    @pytest.mark.asyncio
    async def test_valid_normalized_vector_with_no_bboxes(self) -> None:
        """This tests the full gaze-tracking path — if OQS library is unavailable,
        Signature validation delegated to Sigstore."""
        from coreason_runtime.orchestration.activities import execute_gaze_tracking_io_activity

        payload = {
            "origin": [0.0, 0.0, 0.0],
            "direction_unit_vector": [0.0, 0.0, 1.0],
            "hardware_signature": {
                "pq_algorithm": "Ed25519",
                "public_key_id": "gaze_key",
            },
            "active_bounding_boxes": [],
        }
        try:
            result = await execute_gaze_tracking_io_activity(payload)
            assert result["trusted_hardware"] is True
            assert result["intersected_node_cids"] == []
        except RuntimeError, ValueError:
            # OQS native library not available in this environment — acceptable
            pytest.skip("OQS native library not available")


# ---------------------------------------------------------------------------
# execute_formal_verification_compute_activity (z3-less path)
# ---------------------------------------------------------------------------
class TestFormalVerification:
    @pytest.mark.asyncio
    async def test_z3_import_unavailable(self) -> None:
        """When z3 is not installed, we get Verification Unavailable."""
        from coreason_runtime.orchestration.activities import execute_formal_verification_compute_activity

        payload = {
            "handoff_cid": "h" * 128,
            "solver_protocol": "z3",
            "formal_grammar_payload": "(assert (= 1 1))",
            "timeout_ms": 1000,
        }
        result = await execute_formal_verification_compute_activity(payload)
        # z3 might or might not be installed - either way we get a result
        assert "status" in result
        assert "proof_valid" in result

    @pytest.mark.asyncio
    async def test_unsupported_solver(self) -> None:
        """Unknown solver protocol → Verification Unavailable."""
        from coreason_runtime.orchestration.activities import execute_formal_verification_compute_activity

        payload = {
            "handoff_cid": "x" * 128,
            "solver_protocol": "lean4",
            "formal_grammar_payload": "some lean code",
            "timeout_ms": 500,
        }
        result = await execute_formal_verification_compute_activity(payload)
        assert result["proof_valid"] is False


# ---------------------------------------------------------------------------
# execute_fhe_solver_compute_activity
# ---------------------------------------------------------------------------
class TestFHESolver:
    @pytest.mark.asyncio
    async def test_without_tenseal(self) -> None:
        """TenSEAL not installed → should fail gracefully."""
        from coreason_runtime.orchestration.activities import execute_fhe_solver_compute_activity

        payload = {
            "public_key_cid": "pk_test",
            "fhe_scheme": "CKKS",
            "ciphertext_blob": "dGVzdA==",
        }
        result = await execute_fhe_solver_compute_activity(payload)
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_missing_ciphertext(self) -> None:
        """No ciphertext_blob → fails with missing data error."""
        from coreason_runtime.orchestration.activities import execute_fhe_solver_compute_activity

        payload = {
            "public_key_cid": "pk_test2",
            "fhe_scheme": "CKKS",
            "ciphertext_blob": "",
        }
        result = await execute_fhe_solver_compute_activity(payload)
        assert result["status"] == "failed"


# ---------------------------------------------------------------------------
# resolve_schema_class
# ---------------------------------------------------------------------------
class TestResolveSchemaClass:
    def test_resolves_known_manifest_class(self) -> None:
        from coreason_runtime.orchestration.activities import resolve_schema_class

        cls = resolve_schema_class("OracleExecutionReceipt")
        from coreason_manifest import OracleExecutionReceipt

        assert cls is OracleExecutionReceipt

    def test_resolves_agent_response_fallback(self) -> None:
        from coreason_runtime.orchestration.activities import resolve_schema_class

        cls = resolve_schema_class("AgentResponse")
        assert cls.__name__ == "AgentResponse"

    def test_resolves_verification_yield_fallback(self) -> None:
        from coreason_runtime.orchestration.activities import resolve_schema_class

        cls = resolve_schema_class("VerificationYield")
        assert cls.__name__ == "VerificationYield"

    def test_resolves_dynamic_from_domain_extensions(self) -> None:
        from coreason_runtime.orchestration.activities import resolve_schema_class

        ext = {"CustomModel": {"field1": "string desc", "is_valid": "boolean flag"}}
        cls = resolve_schema_class("CustomModel", ext)
        assert cls.__name__ == "CustomModel"

    def test_raises_for_unknown(self) -> None:
        from coreason_runtime.orchestration.activities import resolve_schema_class

        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("TotallyFakeSchema123")


# ---------------------------------------------------------------------------
# KineticActivities — instance method tests
# ---------------------------------------------------------------------------
class TestKineticActivitiesEmitResumed:
    """Test the simple no-op activities on KineticActivities."""

    @pytest.mark.asyncio
    async def test_emit_resumed_event(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.emit_resumed_event_io_activity()
        assert result == {"status": "resumed"}

    @pytest.mark.asyncio
    async def test_emit_span_valid(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)

        # OpenTelemetry-native span payload (replaces legacy ExecutionSpanReceipt)
        span_payload = {
            "trace_cid": "trace_test_001",
            "span_cid": "span_test_001",
            "name": "test_span",
            "kind": "internal",
            "start_time_unix_nano": 1000000000,
            "end_time_unix_nano": 2000000000,
            "status": "ok",
            "events": [
                {"name": "checkpoint", "attributes": {"step": "1"}},
            ],
        }
        result = await ka.emit_span_io_activity(span_payload)
        assert result == {"status": "span_emitted"}

    @pytest.mark.asyncio
    async def test_request_oracle_intervention(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.request_oracle_intervention_io_activity("wf_test", "node_001", {"context": "data"})
        assert result["status"] == "oracle_requested"
        assert result["node_cid"] == "node_001"

    @pytest.mark.asyncio
    async def test_broadcast_state_echo(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.broadcast_state_echo_io_activity("wf_test", {"key": "val"})
        assert result["status"] == "echoed"


# ---------------------------------------------------------------------------
# EpistemicVectorizationPolicy — real Polars tests
# ---------------------------------------------------------------------------
class TestEpistemicVectorizationPolicy:
    def test_transform_produces_entity_uuid(self) -> None:
        import polars as pl

        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import (
            EpistemicVectorizationPolicy,
        )

        df = pl.DataFrame({"name": ["Alice", "Bob"], "dept": ["Eng", "Sales"]})
        result = EpistemicVectorizationPolicy.transform(df, ["name", "dept"]).collect()
        assert "entity_uuid" in result.columns
        assert result.height == 2

    def test_transform_missing_key_raises(self) -> None:
        import polars as pl

        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import (
            EpistemicVectorizationPolicy,
            InvalidSchemaYieldError,
        )

        df = pl.DataFrame({"x": [1]})
        with pytest.raises(InvalidSchemaYieldError, match="missing required"):
            EpistemicVectorizationPolicy.transform(df, ["nonexistent"])

    @pytest.mark.asyncio
    async def test_transform_async(self) -> None:
        import polars as pl

        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import (
            EpistemicVectorizationPolicy,
        )

        df = pl.DataFrame({"id": ["1", "2"], "val": ["a", "b"]})
        result = await EpistemicVectorizationPolicy.transform_async(df, ["id", "val"])
        collected = result.collect()
        assert "entity_uuid" in collected.columns

    def test_deterministic_output(self) -> None:
        """Same input → same UUIDs."""
        import polars as pl

        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import (
            EpistemicVectorizationPolicy,
        )

        df = pl.DataFrame({"k": ["hello", "world"]})
        r1 = EpistemicVectorizationPolicy.transform(df, ["k"]).collect()
        r2 = EpistemicVectorizationPolicy.transform(df, ["k"]).collect()
        assert r1["entity_uuid"].to_list() == r2["entity_uuid"].to_list()

    def test_lazy_frame_input(self) -> None:
        import polars as pl

        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import (
            EpistemicVectorizationPolicy,
        )

        lf = pl.DataFrame({"k": ["a"]}).lazy()
        result = EpistemicVectorizationPolicy.transform(lf, ["k"]).collect()
        assert "entity_uuid" in result.columns


# ---------------------------------------------------------------------------
# KineticActivities — execute_system_function_compute_activity tests
# ---------------------------------------------------------------------------
class _FakeMCPManager:
    """Lightweight fake MCP manager for testing."""

    async def call_tool(self, _server: str, tool: str, _args: dict[str, Any]) -> dict[str, Any]:
        return {"success": True, "output": f"executed:{tool}"}


class _FailingMCPManager:
    """MCP manager that always raises."""

    async def call_tool(self, _server: str, _tool: str, _args: dict[str, Any]) -> dict[str, Any]:
        raise ConnectionError("MCP server unavailable")


class TestSystemFunctionActivity:
    @pytest.mark.asyncio
    async def test_non_wasm_execution_forbidden(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.execute_system_function_compute_activity({"domain_extensions": {"execution_type": "native"}})
        assert result["success"] is False
        assert "Security Violation" in result["data"]

    @pytest.mark.asyncio
    async def test_wasm_execution_missing_tool(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.execute_system_function_compute_activity(
            {"domain_extensions": {"execution_type": "wasm", "wasm_tool": ""}}
        )
        assert result["success"] is False
        assert "Structural integrity error" in result["data"]

    @pytest.mark.asyncio
    async def test_wasm_execution_success(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.execute_system_function_compute_activity(
            {"domain_extensions": {"execution_type": "wasm", "wasm_tool": "test_solver"}}
        )
        assert result["success"] is True
        assert "executed:test_solver" in result["data"]

    @pytest.mark.asyncio
    async def test_wasm_execution_mcp_failure(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FailingMCPManager()  # type: ignore[assignment]

        result = await ka.execute_system_function_compute_activity(
            {"domain_extensions": {"execution_type": "wasm", "wasm_tool": "failing_tool"}}
        )
        assert result["success"] is False
        assert "Sandbox execution trapped" in result["data"]

    @pytest.mark.asyncio
    async def test_default_execution_type_is_dummy(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.execute_system_function_compute_activity({})
        assert result["success"] is False


# ---------------------------------------------------------------------------
# KineticActivities — NemoClaw swarm activity
# ---------------------------------------------------------------------------
class TestNemoClawSwarmActivity:
    @pytest.mark.asyncio
    async def test_nemoclaw_success(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.execute_nemoclaw_swarm_io_activity(
            {"server_cid": "nemoclaw", "name": "deploy", "arguments": {}}
        )
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_nemoclaw_failure(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FailingMCPManager()  # type: ignore[assignment]

        result = await ka.execute_nemoclaw_swarm_io_activity({})
        assert result["status"] == "error"


# ---------------------------------------------------------------------------
# KineticActivities — hydrate MCP prompt
# ---------------------------------------------------------------------------
class TestHydrateMCPPrompt:
    @pytest.mark.asyncio
    async def test_invalid_payload(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        ka.mcp_manager = _FakeMCPManager()  # type: ignore[assignment]

        result = await ka.hydrate_mcp_prompt_io_activity({"invalid": "data"})
        assert result["status"] == "error"
        assert "mcp_hydration_failed" in result["reason"]


# ---------------------------------------------------------------------------
# KineticActivities — record_token_burn
# ---------------------------------------------------------------------------
class TestRecordTokenBurn:
    @pytest.mark.asyncio
    async def test_records_token_burn_validation_error(self) -> None:
        """Invalid payload → burn_capture_failed (validation catches it)."""
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.record_token_burn_io_activity("wf_test", {"prompt_tokens": 100, "completion_tokens": 200})
        assert result["status"] == "burn_capture_failed"


# ---------------------------------------------------------------------------
# KineticActivities — announce_task
# ---------------------------------------------------------------------------
class TestAnnounceTask:
    @pytest.mark.asyncio
    async def test_announce_task_validation_error(self) -> None:
        """Invalid payload → validation error."""
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        with pytest.raises((ValueError, TypeError, KeyError)):
            await ka.announce_task_io_activity({"invalid": "data"})


# ---------------------------------------------------------------------------
# KineticActivities — execute_medallion_etl
# ---------------------------------------------------------------------------
class TestMedallionETL:
    @pytest.mark.asyncio
    async def test_medallion_etl_basic(self) -> None:
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.execute_medallion_etl_compute_activity()
        # Should delegate to the silver transformation
        assert "status" in result
