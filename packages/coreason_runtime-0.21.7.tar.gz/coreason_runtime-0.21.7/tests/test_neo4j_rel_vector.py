from typing import Any

import pytest
from neo4j import AsyncGraphDatabase


@pytest.mark.asyncio
async def test_neo4j_rel_vector(neo4j_container: Any) -> None:
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))

    async with driver.session() as session:
        await session.run("CREATE (a:Node {uuid: 'a'})-[:RELATES_TO {uuid: 'r'}]->(b:Node {uuid: 'b'})")

        # Test db.create.setVectorProperty on relationship
        print("\nTesting db.create.setVectorProperty on relationship...")
        try:
            await session.run(
                "MATCH ()-[r:RELATES_TO {uuid: 'r'}]->() "
                "CALL db.create.setVectorProperty(r, 'vec', $vec) YIELD node RETURN node",
                vec=[0.1, 0.2, 0.3],
            )
            print("[SUCCESS] db.create.setVectorProperty works on relationship")
        except Exception as e:
            print(f"[FAILURE] db.create.setVectorProperty failed on relationship: {e}")

    await driver.close()
