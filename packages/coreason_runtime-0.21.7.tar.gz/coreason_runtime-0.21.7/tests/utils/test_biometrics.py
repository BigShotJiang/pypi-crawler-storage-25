# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64

import httpx
import pytest
import respx
from httpx import Response

from coreason_runtime.utils.biometrics import Fido2Verifier


def test_fido2_verifier_valid(mock_nemoclaw_bridge: respx.MockRouter) -> None:
    """AGENT INSTRUCTION: Mathematically prevent malicious actors gracefully asserting valid hardware signatures mapping exactly cleanly gracefully natively confidently firmly gracefully conforming."""
    mock_nemoclaw_bridge.clear()
    mock_nemoclaw_bridge.post("http://localhost:8080/v1/verify/biometric").mock(
        return_value=Response(200, json={"valid": True})
    )

    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"

    # Craft a mocked valid base64url payload natively perfectly checked structurally
    raw_payload = b"VALID_PAYLOAD_" + challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    assert verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key") is True


def test_fido2_verifier_invalid_signature(mock_nemoclaw_bridge: respx.MockRouter) -> None:
    """AGENT INSTRUCTION: Assert the failure state forcefully rejects maliciously spoofed wetware signatures cleanly gracefully mapping reliably neatly."""
    # Simulating a rejection from NemoClaw
    mock_nemoclaw_bridge.clear()
    mock_nemoclaw_bridge.post("http://localhost:8080/v1/verify/biometric").mock(
        return_value=Response(401, text="Invalid signature")
    )

    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"
    raw_payload = b"INVALID_HARDWARE_SIGNATURE_" + challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    assert verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key") is False


def test_fido2_verifier_unreachable(mock_nemoclaw_bridge: respx.MockRouter) -> None:
    """Test behavior when NemoClaw is unreachable."""
    mock_nemoclaw_bridge.clear()
    mock_nemoclaw_bridge.post("http://localhost:8080/v1/verify/biometric").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )

    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    with pytest.raises(ValueError, match="NemoClaw bridge unreachable|Internal Bridge Error"):
        verifier.verify_hardware_signature("any", "did:test", "challenge", b"key")
