# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Targeted tests to close residual coverage gaps in utils/logger.py."""

import logging
import pathlib
from typing import Any, cast
from unittest.mock import patch

import loguru

from coreason_runtime.utils.logger import (
    InterceptHandler,
    LoggerConfig,
    otel_telemetry_sink,
    set_global_log_level,
    temporal_context_patcher,
)


# ---------------------------------------------------------------------------
# L59-60: InterceptHandler.emit — ValueError branch when levelname is unknown
# ---------------------------------------------------------------------------
def test_intercept_handler_emit_unknown_level() -> None:
    """Covers the `except ValueError: level = record.levelno` branch (lines 59-60)."""
    handler = InterceptHandler()
    record = logging.LogRecord(
        name="test",
        level=logging.DEBUG,
        pathname=__file__,
        lineno=1,
        msg="test message",
        args=(),
        exc_info=None,
    )
    # Use a non-standard level name that loguru will not recognise, triggering ValueError
    record.levelname = "NONEXISTENT_LEVEL_XYZ"
    # Should not raise — the handler catches ValueError and falls back to levelno
    handler.emit(record)


# ---------------------------------------------------------------------------
# L136-137: otel_telemetry_sink — json.JSONDecodeError branch
# ---------------------------------------------------------------------------
def test_otel_telemetry_sink_invalid_json() -> None:
    """Covers the `except json.JSONDecodeError: pass` branch (lines 136-137)."""

    class MockMessage(str):
        record: loguru.Record

    # Non-JSON string — will trigger JSONDecodeError inside the sink
    mock_msg = MockMessage("this is not json at all")
    record = cast("loguru.Record", {"extra": {}})
    mock_msg.record = record
    msg = cast("loguru.Message", mock_msg)

    # Should not raise — just silently swallows the decode error
    otel_telemetry_sink(msg)


# ---------------------------------------------------------------------------
# L167-169: temporal_context_patcher — RuntimeError branch
# ---------------------------------------------------------------------------
@patch("temporalio.activity.in_activity", side_effect=RuntimeError("not in runtime"))
def test_temporal_context_patcher_runtime_error(mock_in_activity: Any) -> None:
    """Covers the `except RuntimeError` branch (lines 167-169)."""
    record_dict: dict[str, Any] = {"message": "hello", "extra": {}}
    record = cast("Any", record_dict)
    temporal_context_patcher(record)
    # The error message is stored in extra under temporal_context_error
    assert "temporal_context_error" in record_dict["extra"]
    assert "not in runtime" in record_dict["extra"]["temporal_context_error"]


# ---------------------------------------------------------------------------
# L191: set_global_log_level — mkdir when parent directory does not exist
# ---------------------------------------------------------------------------
def test_set_global_log_level_creates_parent_dir(tmp_path: pathlib.Path) -> None:
    """Covers `log_file.parent.mkdir(parents=True, exist_ok=True)` (line 191)."""
    deep_log = tmp_path / "deep" / "nested" / "app.log"
    assert not deep_log.parent.exists()

    with patch(
        "coreason_runtime.utils.logger.logger_config",
        LoggerConfig(
            LOG_LEVEL="INFO",
            LOG_FILE_PATH=str(deep_log),
            ENABLE_CONSOLE_LOGS=False,
            ENABLE_OTEL_SINK=False,
        ),
    ):
        set_global_log_level("INFO")

    assert deep_log.parent.exists()


# ---------------------------------------------------------------------------
# L206-207: set_global_log_level — ENABLE_OTEL_SINK=True branch
# ---------------------------------------------------------------------------
def test_set_global_log_level_otel_sink_enabled(tmp_path: pathlib.Path) -> None:
    """Covers the `if logger_config.ENABLE_OTEL_SINK:` branch (lines 206-207)."""
    log_file = tmp_path / "otel_test.log"

    with patch(
        "coreason_runtime.utils.logger.logger_config",
        LoggerConfig(
            LOG_LEVEL="INFO",
            LOG_FILE_PATH=str(log_file),
            ENABLE_CONSOLE_LOGS=False,
            ENABLE_OTEL_SINK=True,
        ),
    ):
        # Should not raise — registers otel_telemetry_sink as a third loguru sink
        set_global_log_level("INFO")
