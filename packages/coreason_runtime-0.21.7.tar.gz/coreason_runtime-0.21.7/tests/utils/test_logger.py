# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import os
import pathlib
import time
from typing import Any, cast
from unittest.mock import MagicMock, patch

import loguru
from pydantic import BaseModel


class LogEvent(BaseModel):
    timestamp: float
    level: str
    message: str
    context_profile: dict[str, Any]
    event_cid: str = "mock-cid"


from loguru import logger

from coreason_runtime.utils.logger import (
    LoggerConfig,
    log_event,
    otel_telemetry_sink,
    set_global_log_level,
    temporal_context_patcher,
)


def test_logger_config_loads_defaults() -> None:
    config = LoggerConfig()
    assert config.LOG_LEVEL == "INFO"
    assert config.LOG_FILE_PATH == "logs/app.log"
    assert config.ENABLE_CONSOLE_LOGS is True
    assert config.ENABLE_OTEL_SINK is False


def test_logger_config_respects_env_vars() -> None:
    with patch.dict(
        os.environ,
        {
            "COREASON_LOG_LEVEL": "DEBUG",
            "COREASON_LOG_FILE_PATH": "test_logs/app.log",
            "COREASON_ENABLE_CONSOLE_LOGS": "false",
            "COREASON_ENABLE_OTEL_SINK": "true",
        },
    ):
        config = LoggerConfig()
        assert config.LOG_LEVEL == "DEBUG"
        assert config.LOG_FILE_PATH == "test_logs/app.log"
        assert config.ENABLE_CONSOLE_LOGS is False
        assert config.ENABLE_OTEL_SINK is True


def test_set_global_log_level_modifies_handlers(tmp_path: pathlib.Path) -> None:
    # Test changing the global log level using set_global_log_level
    with patch(
        "coreason_runtime.utils.logger.logger_config",
        LoggerConfig(
            LOG_LEVEL="DEBUG",
            LOG_FILE_PATH=str(tmp_path / "app.log"),
            ENABLE_CONSOLE_LOGS=False,
            ENABLE_OTEL_SINK=False,
        ),
    ):
        set_global_log_level("DEBUG")

        # Verify the file exists (loguru might not create it until a log is emitted)
        logger.debug("Test debug message")

        # loguru uses a background thread (enqueue=True) to write to file
        import time

        time.sleep(0.1)

        log_file = tmp_path / "app.log"
        assert log_file.exists()

        # Read the content
        content = log_file.read_text(encoding="utf-8")
        assert "Test debug message" in content


def test_temporal_context_patcher_outside_context() -> None:
    # Should not throw an exception when called outside a temporal context
    record_dict: dict[str, Any] = {"message": "test", "extra": {}}
    record = cast("Any", record_dict)
    temporal_context_patcher(record)
    assert record_dict["extra"] == {}


@patch("temporalio.activity.in_activity", return_value=True)
@patch("temporalio.activity.info")
def test_temporal_context_patcher_in_activity(mock_info: MagicMock, mock_in_activity: MagicMock) -> None:
    class MockActivityInfo:
        workflow_id = "wf-123"
        workflow_run_id = "run-456"
        activity_type = "MyActivity"

    mock_info.return_value = MockActivityInfo()
    record_dict: dict[str, Any] = {"message": "test", "extra": {}}
    record = cast("Any", record_dict)
    temporal_context_patcher(record)

    assert record_dict["extra"]["workflow_id"] == "wf-123"
    assert record_dict["extra"]["run_id"] == "run-456"
    assert record_dict["extra"]["activity_type"] == "MyActivity"


@patch("temporalio.activity.in_activity", return_value=False)
@patch("temporalio.workflow.in_workflow", return_value=True)
@patch("temporalio.workflow.info")
def test_temporal_context_patcher_in_workflow(
    mock_info: MagicMock,
    mock_in_workflow: MagicMock,
    mock_in_activity: MagicMock,
) -> None:
    class MockWorkflowInfo:
        workflow_id = "wf-789"
        run_id = "run-012"
        workflow_type = "MyWorkflow"

    mock_info.return_value = MockWorkflowInfo()
    record_dict: dict[str, Any] = {"message": "test", "extra": {}}
    record = cast("Any", record_dict)
    temporal_context_patcher(record)

    assert record_dict["extra"]["workflow_id"] == "wf-789"
    assert record_dict["extra"]["run_id"] == "run-012"
    assert record_dict["extra"]["workflow_type"] == "MyWorkflow"


def test_log_event_binds_data(tmp_path: pathlib.Path) -> None:
    import time

    # Use a dummy log event to verify log binding
    event = LogEvent(
        timestamp=time.time_ns() / 1e9,
        level="INFO",
        message="NodeStartedEvent",
        context_profile={"node_cid": "node-1", "epistemic_node_name": "TestAgent"},
    )

    with patch(
        "coreason_runtime.utils.logger.logger_config",
        LoggerConfig(
            LOG_LEVEL="INFO",
            LOG_FILE_PATH=str(tmp_path / "telemetry.log"),
            ENABLE_CONSOLE_LOGS=False,
            ENABLE_OTEL_SINK=False,
        ),
    ):
        set_global_log_level("INFO")
        log_event(event)  # type: ignore[arg-type]

        time.sleep(0.1)

        log_file = tmp_path / "telemetry.log"
        assert log_file.exists()
        content = log_file.read_text(encoding="utf-8")

        # Verify the logged output is a JSON string containing the bound fields
        lines = [line for line in content.strip().split("\n") if line]
        assert len(lines) > 0
        parsed = json.loads(lines[-1])
        # Pydantic dicts bound to logger get placed in the record["extra"] dictionary
        # Let's inspect the top level structure for safety.
        record_extra = parsed.get("record", {}).get("extra", parsed.get("extra", {}))
        # LogEvent context_profile values are nested within context_profile inside the bound output
        assert record_extra.get("context_profile", {}).get("node_cid") == "node-1"
        assert record_extra.get("context_profile", {}).get("epistemic_node_name") == "TestAgent"

        # Determine where message is stored based on loguru JSON serialize output structure
        message = parsed.get("record", {}).get("message", parsed.get("text", ""))
        assert "NodeStartedEvent" in message


def test_log_event_updates_prometheus_metrics() -> None:
    # Test token increment
    token_event = LogEvent(
        timestamp=time.time_ns() / 1e9,
        level="INFO",
        message="TokenStreamChunk",
        context_profile={"event_type": "TokenStreamChunk", "epistemic_node_name": "agent-x"},
    )
    with patch("coreason_runtime.utils.logger.TOKEN_GENERATION_COUNTER") as mock_counter:
        log_event(token_event)  # type: ignore[arg-type]
        mock_counter.labels.assert_called_once_with(epistemic_node_name="agent-x")
        mock_counter.labels.return_value.inc.assert_called_once_with(1)

    # Test tool duration observe
    tool_event = LogEvent(
        timestamp=time.time_ns() / 1e9,
        level="INFO",
        message="ToolExecutionUpdate",
        context_profile={
            "event_type": "ToolExecutionUpdate",
            "status": "finished",
            "actuator_name": "calculator",
            "duration_ms": 1500,
        },
    )
    with patch("coreason_runtime.utils.logger.ACTUATOR_EXECUTION_DURATION_HISTOGRAM") as mock_histogram:
        log_event(tool_event)  # type: ignore[arg-type]
        mock_histogram.labels.assert_called_once_with(actuator_name="calculator", status="finished")
        mock_histogram.labels.return_value.observe.assert_called_once_with(1.5)


def test_otel_telemetry_sink_forwards_message() -> None:
    # Create a mock loguru Message object (a string with a record attribute)
    class MockMessage(str):
        record: loguru.Record

    msg_str = json.dumps({"record": {"message": "Test OTel Message"}})
    mock_msg = MockMessage(msg_str)

    # mock loguru.Message attributes by casting
    record = cast("loguru.Record", {"extra": {}, "level": "INFO", "message": "Test OTel Message"})
    mock_msg.record = record

    msg = cast("loguru.Message", mock_msg)

    # The new implementation calls get_tracer and starts an OTel span
    with patch("coreason_runtime.utils.tracing.get_tracer") as mock_get_tracer:
        mock_tracer = MagicMock()
        mock_span = MagicMock()
        mock_tracer.start_as_current_span.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_tracer.start_as_current_span.return_value.__exit__ = MagicMock(return_value=False)
        mock_get_tracer.return_value = mock_tracer

        otel_telemetry_sink(msg)

        mock_get_tracer.assert_called_once_with("coreason-runtime.logger")
        mock_tracer.start_as_current_span.assert_called_once_with("log_event")


def test_otel_telemetry_sink_prevents_recursion() -> None:
    class MockMessage(str):
        record: loguru.Record

    msg_str = json.dumps({"record": {"message": "Forwarding log to OTel Sink: some data"}})
    mock_msg = MockMessage(msg_str)

    # mock loguru.Message attributes by casting
    record = cast("loguru.Record", {"extra": {"internal_telemetry": True}})
    mock_msg.record = record

    msg = cast("loguru.Message", mock_msg)

    with patch("coreason_runtime.utils.logger.logger.bind") as mock_bind:
        otel_telemetry_sink(msg)
        mock_bind.assert_not_called()
