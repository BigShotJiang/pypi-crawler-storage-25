# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from coreason_runtime.execution_plane.fabricator import IntentFabricator


@pytest.mark.asyncio
async def test_fabricator_urn_fixup() -> None:
    """Coverage for lines 135-142: _ACTIONSPACE_URN_PATTERN regex fixup logic in fabricator.py."""
    import os

    # Do not pass meta_dir so we cover the fallback (lines 40-46)
    os.environ.pop("COREASON_META_DIR", None)
    with patch("coreason_runtime.execution_plane.fabricator.Path.exists", return_value=False):
        fabricator = IntentFabricator(model_name="MockModel")

    # Mock the LLM client to return an incomplete URN payload
    class MockClient:
        async def generate(
            self,
            prompt: str,
            schema_dict: dict[str, Any],  # noqa: ARG002
            constrained_decoding: bool,  # noqa: ARG002
        ) -> tuple[str, int, None]:
            if "Universal Asset Forge" in prompt:
                # Phase 1 response with missing "urn:..."
                payload = {
                    "actuator_name": "my_tool",
                    "action_space_id": "missing_prefix_tool",
                    "target_file_path": "my_tool.py",
                    "return_type": "float",
                    "geometric_schema": {},
                    "required_imports": [],
                }
            else:
                # Phase 3 logic refinement response
                payload = {"python_code": "return 1.0"}

            return json.dumps(payload), 0, None

    fabricator.client = MockClient()  # type: ignore[assignment]

    class MockMCPClient:
        async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # noqa: ARG002
            return {"tools": [{"name": "scaffold_logic_actuator", "inputSchema": {"type": "object"}}]}

    class MockMCPManager:
        def get_client(self, server_cid: str) -> Any:  # noqa: ARG002
            return MockMCPClient()

        async def call_tool(self, server_cid: str, name: str, arguments: dict[str, Any]) -> str:  # noqa: ARG002
            # We'll assert the arguments here
            assert arguments["action_space_id"] == "urn:coreason:actionspace:solver:missing_prefix_tool:v1"
            return "Success"

    mock_manager = MockMCPManager()

    with patch("coreason_runtime.execution_plane.fabricator.NemoClawBridgeClient", return_value=mock_manager):
        with patch("os.makedirs"), patch("builtins.open", MagicMock()), patch("os.chdir"):
            await fabricator.fabricate("make a tool")


@pytest.mark.asyncio
async def test_fabricator_meta_dir_initialization() -> None:
    """Coverage for lines 39 and 41: explicit meta_dir and env var."""
    import os

    # Test line 39: passing meta_dir explicitly
    with patch("coreason_runtime.execution_plane.fabricator.Path.exists", return_value=True):
        fab1 = IntentFabricator(model_name="MockModel", meta_dir="/tmp/fake_meta_dir")
        assert str(fab1.meta_dir).endswith("fake_meta_dir")

    # Test line 41: using COREASON_META_DIR
    os.environ["COREASON_META_DIR"] = "/tmp/env_meta_dir"
    with patch("coreason_runtime.execution_plane.fabricator.Path.exists", return_value=True):
        fab2 = IntentFabricator(model_name="MockModel")
        assert str(fab2.meta_dir).endswith("env_meta_dir")

    os.environ.pop("COREASON_META_DIR", None)


@pytest.mark.asyncio
async def test_fabricator_tool_not_found() -> None:
    """Coverage for line 106: ValueError when scaffold_logic_actuator is missing."""

    fabricator = IntentFabricator(model_name="MockModel")

    class MockClientEmpty:
        async def generate(self, *args: Any, **kwargs: Any) -> tuple[str, int, None]:  # noqa: ARG002
            return '{"actuator_name": "my_tool", "action_space_id": "missing_prefix_tool"}', 0, None

    fabricator.client = MockClientEmpty()  # type: ignore[assignment]

    class MockMCPClientEmpty:
        async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # noqa: ARG002
            return {"tools": [{"name": "some_other_tool", "inputSchema": {"type": "object"}}]}

    class MockMCPManagerEmpty:
        def get_client(self, server_cid: str) -> Any:  # noqa: ARG002
            return MockMCPClientEmpty()

    with patch("coreason_runtime.execution_plane.fabricator.NemoClawBridgeClient", return_value=MockMCPManagerEmpty()):
        with patch("os.chdir"):
            with pytest.raises(ValueError, match="Could not find 'scaffold_logic_actuator'"):
                await fabricator.fabricate("make a tool")


@pytest.mark.asyncio
async def test_fabricator_fallback_filename_and_exception() -> None:
    """Coverage for line 152 (fallback filename) and lines 224-226 (Exception block)."""

    fabricator = IntentFabricator(model_name="MockModel")

    # 1. Provide an actuator name and bad target_file_path to force line 152
    class MockClientFallback:
        async def generate(
            self,
            prompt: str,  # noqa: ARG002
            schema_dict: dict[str, Any],  # noqa: ARG002
            constrained_decoding: bool,  # noqa: ARG002
        ) -> tuple[str, int, None]:
            # This triggers line 152: filename = f"{actuator_name}.py"
            payload = {
                "actuator_name": "fallback_tool",
                "action_space_id": "urn:coreason:actionspace:solver:test:v1",
                "target_file_path": "bad_file.txt",  # Not .py
            }
            return json.dumps(payload), 0, None

    fabricator.client = MockClientFallback()  # type: ignore[assignment]

    class MockMCPClientEx:
        async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # noqa: ARG002
            return {"tools": [{"name": "scaffold_logic_actuator", "inputSchema": {"type": "object"}}]}

    class MockMCPManagerEx:
        def get_client(self, server_cid: str) -> Any:  # noqa: ARG002
            return MockMCPClientEx()

        async def call_tool(self, server_cid: str, name: str, arguments: dict[str, Any]) -> str:  # noqa: ARG002
            # Throw exception to cover lines 224-226
            raise RuntimeError("Mock failure")

    with patch("coreason_runtime.execution_plane.fabricator.NemoClawBridgeClient", return_value=MockMCPManagerEx()):
        with patch("os.makedirs"), patch("builtins.open", MagicMock()), patch("os.chdir"):
            with pytest.raises(RuntimeError, match="Mock failure"):
                await fabricator.fabricate("make a tool")


@pytest.mark.asyncio
async def test_fabricator_no_client() -> None:
    """Coverage for lines 114 and 186: no client."""
    fabricator = IntentFabricator(model_name="MockModel")

    class MockMCPClientEx:
        async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # noqa: ARG002
            return {"tools": [{"name": "scaffold_logic_actuator", "inputSchema": {"type": "object"}}]}

    class MockMCPManagerEx:
        def get_client(self, server_cid: str) -> Any:  # noqa: ARG002
            return MockMCPClientEx()

        async def call_tool(self, server_cid: str, name: str, arguments: dict[str, Any]) -> str:  # noqa: ARG002
            return "Success"

    with patch("coreason_runtime.execution_plane.fabricator.NemoClawBridgeClient", return_value=MockMCPManagerEx()):
        with patch("os.makedirs"), patch("builtins.open", MagicMock()), patch("os.chdir"):
            await fabricator.fabricate("make a tool")
