from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

# Attempt to import the FastAPI app and predict_router
from coreason_runtime.api.predict_router import _build_synthesis_prompt, predict_router

app = FastAPI()
app.include_router(predict_router)


from collections.abc import AsyncGenerator


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


def test_build_synthesis_prompt() -> None:
    prompt = _build_synthesis_prompt(None, "user prompt", "discovery context")
    assert "user prompt" in prompt
    assert "discovery context" in prompt

    topology = {"topology": {"type": "swarm", "nodes": {"did:node:1": {"description": "node 1"}}}}
    prompt2 = _build_synthesis_prompt(topology, "", "")
    assert "swarm" in prompt2
    assert "did:node:1" in prompt2


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
async def test_synthesize_topology_expansion_json_fail(mock_indexer: MagicMock, client: AsyncClient) -> None:
    # This will fail at json.loads("") -> 503
    payload = {"topology": '{"test": 1}', "user_prompt": "test"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 503
    assert "Synthesis engine failure" in resp.text


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
async def test_synthesize_topology_expansion_yaml(mock_indexer: MagicMock, client: AsyncClient) -> None:
    # Testing YAML parsing logic
    payload = {"topology": "test: 1\n", "user_prompt": "test"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_synthesize_topology_expansion_bad_topology(client: AsyncClient) -> None:
    # Testing json parsing failure early -> 422
    payload = {"topology": "{bad json", "user_prompt": "test"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 422
    assert "Failed to parse topology" in resp.text


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
async def test_synthesize_topology_expansion_success(mock_indexer: MagicMock, client: AsyncClient) -> None:
    from coreason_manifest import CognitiveAgentNodeProfile

    fake_profile = CognitiveAgentNodeProfile.model_construct(description="test node")

    fake_completions = MagicMock()
    fake_completions.create = AsyncMock(return_value=fake_profile)
    fake_chat = MagicMock()
    fake_chat.completions = fake_completions
    fake_client = MagicMock()
    fake_client.chat = fake_chat

    with (
        patch("coreason_runtime.api.predict_router.instructor") as mock_instructor,
        patch("coreason_runtime.api.predict_router.AsyncOpenAI"),
    ):
        mock_instructor.from_openai.return_value = fake_client
        payload = {"topology": {"topology": {"type": "swarm", "nodes": {}}}, "user_prompt": "test"}
        resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 200
    body = resp.text
    assert "did:coreason:synthesized-agent-" in body


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
@patch("coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp.NemoClawBridgeClient")
async def test_synthesize_scratch_empty(mock_mcp: MagicMock, mock_indexer: MagicMock, client: AsyncClient) -> None:
    mock_indexer_instance = MagicMock()
    mock_indexer_instance.search_capabilities.return_value = [{"distance": 0.1}]
    mock_indexer.return_value = mock_indexer_instance
    payload = {"user_prompt": "test scratch"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    # It should succeed and return {} because is_valid = False
    assert resp.status_code == 200
    assert resp.json() == {}


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
@patch("coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp.NemoClawBridgeClient")
async def test_synthesize_scratch_discovery(mock_mcp: MagicMock, mock_indexer: MagicMock, client: AsyncClient) -> None:
    mock_indexer_instance = MagicMock()
    mock_indexer_instance.search_capabilities.return_value = [
        {"distance": 0.1, "capability_id": "test_id", "description": "desc"}
    ]
    mock_indexer_instance.sync_remote_mcp = AsyncMock()
    mock_indexer.return_value = mock_indexer_instance

    mock_mcp_instance = MagicMock()
    mock_mcp_instance.discover_servers = AsyncMock(return_value=["test_cid"])
    mock_mcp.return_value = mock_mcp_instance

    payload = {"user_prompt": "build tool", "topological_manifold_bias": ""}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 200


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
@patch("coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp.NemoClawBridgeClient")
@patch("temporalio.client.Client.connect", new_callable=AsyncMock)
async def test_synthesize_scratch_macro_forge(
    mock_connect: AsyncMock, mock_mcp: MagicMock, mock_indexer: MagicMock, client: AsyncClient
) -> None:
    mock_indexer_instance = MagicMock()
    mock_indexer_instance.sync_remote_mcp = AsyncMock()
    mock_indexer_instance.search_capabilities.return_value = []  # deficit
    mock_indexer.return_value = mock_indexer_instance

    mock_temporal_client = MagicMock()
    mock_temporal_client.execute_workflow = AsyncMock()
    mock_connect.return_value = mock_temporal_client

    payload = {"user_prompt": "build tool", "topological_manifold_bias": "macro_forge"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 200


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
@patch("coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp.NemoClawBridgeClient")
@patch("temporalio.client.Client.connect", new_callable=AsyncMock)
async def test_synthesize_scratch_zero_day_forge(
    mock_connect: AsyncMock, mock_manager: MagicMock, mock_indexer: MagicMock, client: AsyncClient
) -> None:
    mock_indexer_instance = MagicMock()
    mock_indexer_instance.sync_remote_mcp = AsyncMock()
    # Ensure distance > 1.25 to trigger is_deficit = True
    mock_indexer_instance.search_capabilities.return_value = [{"distance": 2.0}]
    mock_indexer.return_value = mock_indexer_instance

    mock_temporal_client = MagicMock()
    mock_temporal_client.execute_workflow = AsyncMock(return_value="forge_result")
    mock_connect.return_value = mock_temporal_client

    payload = {"user_prompt": "build custom tool", "topological_manifold_bias": "dag"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 200
    mock_temporal_client.execute_workflow.assert_awaited_once()


# ---------------------------------------------------------------------------
# Additional coverage: _build_synthesis_prompt variations
# ---------------------------------------------------------------------------
class TestBuildSynthesisPromptEdgeCases:
    def test_empty_topology_dict(self) -> None:
        prompt = _build_synthesis_prompt({}, "test prompt")
        assert "blank canvas" in prompt.lower()

    def test_nodes_without_description(self) -> None:
        topology = {
            "topology": {
                "type": "council",
                "nodes": {"did:key:a": {}},
            }
        }
        prompt = _build_synthesis_prompt(topology, "")
        assert "no description" in prompt.lower()

    def test_user_prompt_is_whitespace(self) -> None:
        prompt = _build_synthesis_prompt(None, "   ")
        # Empty after strip -> no user_hint
        assert "topology architect" in prompt.lower()


# ---------------------------------------------------------------------------
# Additional endpoint coverage: dict topology input
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
async def test_dict_topology_input(mock_indexer: MagicMock, client: None) -> None:
    """Dict topology is JSON-serialized internally."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        payload = {"topology": {"topology": {"type": "dag", "nodes": {}}}}
        resp = await c.post("/api/v1/predict/synthesize", json=payload)
        assert resp.status_code == 503


@pytest.mark.asyncio
@patch("coreason_runtime.api.predict_router.DiscoveryIndexer")
@patch("coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp.NemoClawBridgeClient")
async def test_none_topology_scratch_path(mock_mcp: MagicMock, mock_indexer: MagicMock) -> None:
    """None topology falls back to scratch synthesis."""
    mock_indexer_instance = MagicMock()
    mock_indexer_instance.sync_remote_mcp = AsyncMock()
    mock_indexer_instance.search_capabilities.return_value = [{"distance": 0.1}]
    mock_indexer.return_value = mock_indexer_instance
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        payload = {"user_prompt": "test synthesis"}
        resp = await c.post("/api/v1/predict/synthesize", json=payload)
        assert resp.status_code == 200
