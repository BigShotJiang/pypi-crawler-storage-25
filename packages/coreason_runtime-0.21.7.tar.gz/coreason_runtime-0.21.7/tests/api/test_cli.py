"""Real tests for CLI module — testing Typer commands with real runners."""

from typer.testing import CliRunner

from coreason_runtime.cli import app, create_app

runner = CliRunner()


class TestCLIDryRun:
    """Test CLI commands in dry-run mode (no side effects)."""

    def test_start_node_dry_run(self) -> None:
        result = runner.invoke(app, ["start", "node", "--dry-run"])
        assert result.exit_code == 0

    def test_start_api_dry_run(self) -> None:
        result = runner.invoke(app, ["start", "api", "--dry-run"])
        assert result.exit_code == 0

    def test_execute_dry_run(self, tmp_path) -> None:  # type: ignore[no-untyped-def]
        # Create a minimal valid manifest file
        manifest = tmp_path / "test_manifest.json"
        manifest.write_text('{"topology": {"type": "dag", "nodes": {}}}')
        result = runner.invoke(app, ["execute", str(manifest), "--dry-run"])
        assert result.exit_code == 0

    def test_execute_missing_file(self) -> None:
        result = runner.invoke(app, ["execute", "/nonexistent/manifest.json"])
        assert result.exit_code != 0


class TestCreateApp:
    """Test the FastAPI factory function."""

    def test_create_app_returns_fastapi(self) -> None:
        from fastapi import FastAPI

        api_app = create_app()
        assert isinstance(api_app, FastAPI)

    def test_create_app_has_routes(self) -> None:
        api_app = create_app()
        route_paths = [r.path for r in api_app.routes]
        assert any("/api/v1/state" in p for p in route_paths)
        assert any("/api/v1/schema" in p for p in route_paths)
