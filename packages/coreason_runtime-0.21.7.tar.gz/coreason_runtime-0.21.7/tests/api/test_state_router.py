from unittest.mock import AsyncMock, MagicMock, patch  # noqa: TID251

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from temporalio.client import WorkflowExecutionStatus

from coreason_runtime.api.state_router import state_router

app = FastAPI()
app.include_router(state_router)


from collections.abc import AsyncGenerator


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.AnyTopologyManifestAdapter.validate_python")
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_sync_state_success(mock_connect: AsyncMock, mock_validate: MagicMock, client: AsyncClient) -> None:
    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    mock_handle = MagicMock()
    mock_client.get_workflow_handle.return_value = mock_handle

    mock_desc = MagicMock()
    mock_desc.status = WorkflowExecutionStatus.RUNNING
    mock_handle.describe = AsyncMock(return_value=mock_desc)
    mock_handle.signal = AsyncMock()

    payload = {"type": "swarm", "nodes": {}}
    resp = await client.post("/api/v1/state/sync/wf-123", json=payload)
    print(resp.text)
    assert resp.status_code == 200
    assert resp.json() == {"status": "signal_accepted"}
    mock_handle.signal.assert_called_once_with("apply_state_delta", payload)


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.AnyTopologyManifestAdapter.validate_python")
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_sync_state_not_running(mock_connect: AsyncMock, mock_validate: MagicMock, client: AsyncClient) -> None:
    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    mock_handle = MagicMock()
    mock_client.get_workflow_handle.return_value = mock_handle

    mock_desc = MagicMock()
    mock_desc.status = WorkflowExecutionStatus.COMPLETED
    mock_handle.describe = AsyncMock(return_value=mock_desc)

    payload = {"type": "swarm", "nodes": {}}
    resp = await client.post("/api/v1/state/sync/wf-123", json=payload)

    assert resp.status_code == 410
    assert "already finished" in resp.text


@pytest.mark.asyncio
async def test_sync_state_payload_too_large(client: AsyncClient) -> None:
    # 256KB +
    large_payload = {"type": "swarm", "nodes": {"large": "a" * (256 * 1024 + 10)}}
    resp = await client.post("/api/v1/state/sync/wf-123", json=large_payload)

    assert resp.status_code == 413
    assert "Payload Too Large" in resp.text


@pytest.mark.asyncio
async def test_sync_state_validation_error(client: AsyncClient) -> None:
    # No patching of validate_python, let it fail
    payload = {"invalid": "payload"}
    resp = await client.post("/api/v1/state/sync/wf-123", json=payload)

    assert resp.status_code == 422
    assert "Invalid state delta payload" in resp.text


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.AnyTopologyManifestAdapter.validate_python")
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_sync_state_server_error(mock_connect: AsyncMock, mock_validate: MagicMock, client: AsyncClient) -> None:
    mock_connect.side_effect = Exception("Temporal error")
    payload = {"type": "swarm"}
    resp = await client.post("/api/v1/state/sync/wf-123", json=payload)

    assert resp.status_code == 500
    assert "Temporal error" in resp.text


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_read_state_success(mock_connect: AsyncMock, client: AsyncClient) -> None:
    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    mock_handle = MagicMock()
    mock_client.get_workflow_handle.return_value = mock_handle
    mock_handle.query = AsyncMock(return_value={"status": "all_good"})

    resp = await client.get("/api/v1/state/sync/wf-123")
    assert resp.status_code == 200
    assert resp.json() == {"workflow_id": "wf-123", "state": {"status": "all_good"}}


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_read_state_not_found(mock_connect: AsyncMock, client: AsyncClient) -> None:
    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    mock_handle = MagicMock()
    mock_client.get_workflow_handle.return_value = mock_handle
    mock_handle.query = AsyncMock(side_effect=Exception("Not found"))

    resp = await client.get("/api/v1/state/sync/wf-123")
    assert resp.status_code == 404
    assert "not found" in resp.text


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.KineticExecutionManifold")
@patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock)
async def test_execute_manifest_success(
    mock_connect: AsyncMock, mock_engine_cls: MagicMock, client: AsyncClient
) -> None:
    mock_engine_instance = AsyncMock()
    mock_engine_cls.return_value = mock_engine_instance
    mock_engine_instance.execute_from_dict.return_value = {"completed": True}

    payload = {
        "manifest": {"topology": {"t1": {"nodes": {"n1": {"type": "agent", "runtime_context": "should_be_deleted"}}}}},
        "query": "hello",
    }

    resp = await client.post("/api/v1/state/execute", json=payload)
    assert resp.status_code == 200
    assert resp.json() == {"status": "success", "result": {"completed": True}}

    # Verify that the input dictionary was mutated properly for legacy retrofitting
    args, _kwargs = mock_engine_instance.execute_from_dict.call_args
    passed_manifest = args[0]
    node = passed_manifest["topology"]["t1"]["nodes"]["n1"]
    assert "runtime_context" not in node
    assert node.get("topology_class") == "agent"


@pytest.mark.asyncio
@patch("coreason_runtime.api.state_router.KineticExecutionManifold")
async def test_execute_manifest_error(mock_engine_cls: MagicMock, client: AsyncClient) -> None:
    # Force Client.connect to fail to trigger the Exception block
    with patch("coreason_runtime.api.state_router.Client.connect", new_callable=AsyncMock) as mock_connect:
        mock_connect.side_effect = Exception("Engine failure")
        payload: dict[str, dict[str, str]] = {"manifest": {}}
        resp = await client.post("/api/v1/state/execute", json=payload)
        assert resp.status_code == 500
        assert "Engine failure" in resp.text


@pytest.mark.asyncio
async def test_sync_state_no_content_length() -> None:
    # Use direct function call to bypass FastAPI/httpx content-length population
    from fastapi import Request

    from coreason_runtime.api.state_router import sync_state

    mock_request = MagicMock(spec=Request)
    # Return None for content-length
    mock_request.headers.get.return_value = None

    large_payload = {"type": "swarm", "nodes": {"large": "a" * (256 * 1024 + 10)}}

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as excinfo:
        await sync_state("wf-123", large_payload, mock_request)

    assert excinfo.value.status_code == 413
    assert "Payload Too Large" in excinfo.value.detail
