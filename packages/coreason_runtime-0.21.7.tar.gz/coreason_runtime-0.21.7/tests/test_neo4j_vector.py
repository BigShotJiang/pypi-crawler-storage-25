from typing import Any

import pytest
from neo4j import AsyncGraphDatabase


@pytest.mark.asyncio
async def test_neo4j_vector_capabilities(neo4j_container: Any) -> None:
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))

    async with driver.session() as session:
        # 1. Test normal SET for vector
        await session.run("CREATE (n:TestNode {uuid: 'v1'})")
        await session.run("MATCH (n:TestNode {uuid: 'v1'}) SET n.vec = $vec", vec=[0.1, 0.2, 0.3])
        result = await session.run("MATCH (n:TestNode {uuid: 'v1'}) RETURN n.vec as vec")
        record = await result.single()
        assert record is not None
        assert record["vec"] == [0.1, 0.2, 0.3]
        print("\n[SUCCESS] Normal SET works for vectors")

        # 2. Test vector index creation (Neo4j 5.x syntax)
        await session.run(
            "CREATE VECTOR INDEX test_index IF NOT EXISTS FOR (n:TestNode) ON (n.vec) "
            "OPTIONS {indexConfig: {`vector.dimensions`: 3, `vector.similarity_function`: 'cosine'}}"
        )
        print("[SUCCESS] Vector index creation works")

        # 3. Check if db.create.setNodeVectorProperty exists
        try:
            await session.run(
                "MATCH (n:TestNode {uuid: 'v1'}) CALL db.create.setNodeVectorProperty(n, 'vec2', $vec)",
                vec=[0.4, 0.5, 0.6],
            )
            print("[SUCCESS] db.create.setNodeVectorProperty exists")
        except Exception as e:
            print(f"[EXPECTED FAILURE] db.create.setNodeVectorProperty missing: {e}")

    await driver.close()
