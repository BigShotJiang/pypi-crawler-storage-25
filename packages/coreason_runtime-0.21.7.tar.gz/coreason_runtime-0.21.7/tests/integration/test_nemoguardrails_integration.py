# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import httpx
import pytest

from coreason_runtime.execution_plane.nemoclaw_bridge.master_mcp import NemoClawBridgeClient

try:
    from nemoguardrails.server import api  # type: ignore[import-not-found]

    HAS_GUARDRAILS = True
except ImportError:
    HAS_GUARDRAILS = False


@pytest.mark.skipif(not HAS_GUARDRAILS, reason="nemoguardrails not installed in this environment")
@pytest.mark.asyncio
async def test_nemoguardrails_real_integration(monkeypatch: Any) -> None:
    """AGENT INSTRUCTION: Mathematically prove the kinetic bridge can sustain real HTTP violations from the genuine NeMo Guardrails ASGI app."""

    # We patch the NEMOCLAW_URL to localhost where ASGITransport will answer
    monkeypatch.setenv("NEMOCLAW_URL", "http://localhost:8080")

    # Patch httpx.AsyncClient to use the real ASGI app
    real_app = api.app
    transport = httpx.ASGITransport(app=real_app)

    # Let's subclass or patch httpx.AsyncClient in NemoClawBridgeClient just for this test to inject the transport
    original_client_init = httpx.AsyncClient.__init__

    def patched_init(self: httpx.AsyncClient, *args: Any, **kwargs: Any) -> None:
        kwargs["transport"] = transport
        original_client_init(self, *args, **kwargs)

    monkeypatch.setattr(httpx.AsyncClient, "__init__", patched_init)

    bridge = NemoClawBridgeClient()

    # If we hit an invalid endpoint or invalid config, the real guardrails server will return 404 or 422
    # e.g. /v1/mcp/{server_cid}/tools/call will hit 404 on the guardrails server,
    # or if we hit the actual chat completions endpoint, it will return 422 if config_id is invalid.

    # Use pytest.raises to check for HTTPStatusError
    with pytest.raises(httpx.HTTPStatusError) as excinfo:
        # A payload that would be a violation or a bad request to the real server
        # Nemo Guardrails /v1/chat/completions
        await bridge._post_payload(
            "test-server",
            "../../chat/completions",
            {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Hello"}],
                "guardrails": {"config_id": "invalid_config"},
            },
        )

    assert excinfo.value.response.status_code in [404, 422]
