from typing import Any

import pytest
from neo4j import AsyncGraphDatabase


@pytest.mark.asyncio
async def test_neo4j_version(neo4j_container: Any) -> None:
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))

    async with driver.session() as session:
        result = await session.run(
            "CALL dbms.components() YIELD name, versions, edition RETURN name, versions, edition"
        )
        record = await result.single()
        assert record is not None
        print(f"\n[INFO] Neo4j Name: {record['name']}")
        print(f"[INFO] Neo4j Versions: {record['versions']}")
        print(f"[INFO] Neo4j Edition: {record['edition']}")

        # Also check indices
        try:
            result = await session.run("SHOW INDEXES")
            records = await result.data()
            print(f"[INFO] Indexes: {records}")
        except Exception as e:
            print(f"[ERROR] Could not show indexes: {e}")

    await driver.close()
