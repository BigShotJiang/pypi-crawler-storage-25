import asyncio
import concurrent.futures

from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow
from tests.orchestration.workflows.test_dag_execution_workflow import (
    _build,
    stub_emit_span,
    stub_execute_oracle,
    stub_execute_tensor_json,
    stub_fetch_memoized_hit,
    stub_mcp_tool,
    stub_record_token_burn,
    stub_store_epistemic,
    stub_system_function,
)


async def main():
    print("Starting env...")
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        print("Starting worker...")
        async with Worker(
            env.client,
            task_queue="dag-cycles-1",
            workflows=[DAGExecutionWorkflow],
            activities=[
                stub_emit_span,
                stub_store_epistemic,
                stub_execute_tensor_json,
                stub_fetch_memoized_hit,
                stub_mcp_tool,
                stub_system_function,
                stub_record_token_burn,
                stub_execute_oracle,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            print("Worker started. Building manifest...")
            manifest_cycles = {
                "max_depth": 5,
                "max_fan_out": 10,
                "allow_cycles": True,
                "backpressure": {"max_queue_depth": 2},
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test agent 1",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test agent 2",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [
                    ("did:agent:nodeaaa", "did:agent:nodebbb"),
                    ("did:agent:nodebbb", "did:agent:nodeaaa"),
                ],
            }

            import coreason_manifest

            orig_val = coreason_manifest.DAGTopologyManifest.model_validate

            def _fake_val(obj, *args, **kwargs):
                print("Inside _fake_val!")
                m = orig_val(obj, *args, **kwargs)
                object.__setattr__(m, "max_fan_out", 0)
                return m

            coreason_manifest.DAGTopologyManifest.model_validate = _fake_val

            print("Executing workflow...")
            try:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_cycles), id="t-cycles-1", task_queue="dag-cycles-1"
                )
                print("Workflow finished successfully!")
            except Exception as e:
                print(f"Workflow failed as expected: {e}")
                cause = getattr(e, "cause", None)
                print(f"Cause: {cause}")
            finally:
                coreason_manifest.DAGTopologyManifest.model_validate = orig_val

        executor.shutdown(wait=False)
        print("Done!")


if __name__ == "__main__":
    asyncio.run(main())
