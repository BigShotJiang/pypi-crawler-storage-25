"""
Thermoclaw — Thermodynamic Diagnostics for Neural Network Training
===================================================================

See what your optimizer is actually doing. Thermoclaw wraps any PyTorch
optimizer and exposes real-time thermodynamic quantities: entropy production,
internal vs external entropy flow, equilibrium detection, and actionable
per-layer diagnostics.

Quick start::

    from thermoclaw import Observer, diagnose

    observer = Observer(model, optimizer)
    for batch in loader:
        loss = criterion(model(batch))
        loss.backward()
        optimizer.step()
        snap = observer.step(loss=loss.item())
        optimizer.zero_grad()

    report = diagnose(observer)
    print(report)                      # "layer 18: weight decay → σ_i
                                       #  exceeds σ_e by 4.2×. Reduce wd."

    observer.plot_dashboard()          # 8-panel thermodynamic figure
"""

__version__ = "0.1.4"

from thermoclaw.observer import Observer
from thermoclaw.entropy_split import EntropySplit
from thermoclaw.collapse_detector import CollapseDetector
from thermoclaw.diagnose import diagnose, DiagnosticReport
from thermoclaw.scheduler import ThermoScheduler
from thermoclaw.layer_utils import detect_layer_type, make_param_groups

# EPTO optimizer variants
from thermoclaw.optimizers import (
    EPTOTransformer,
    EPTOv5,
    TCIController,
    auto as epto_auto,
)

__all__ = [
    # Diagnostics
    "Observer",
    "EntropySplit",
    "CollapseDetector",
    "diagnose",
    "DiagnosticReport",
    "ThermoScheduler",
    "detect_layer_type",
    "make_param_groups",
    # Optimizers
    "EPTOTransformer",
    "EPTOv5",
    "TCIController",
    "epto_auto",
]
