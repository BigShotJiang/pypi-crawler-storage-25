"""Request and response schemas for ``/api/settings`` endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class SandboxSettingsBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    denied_patterns: list[str] = Field(default_factory=list)


class TitleGenerationSettingsBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enabled: bool
    model: str = ""
    wait_timeout_seconds: float = 3.0


class MultimodalSectionBody(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str = ""


class MultimodalSettingsBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    image: MultimodalSectionBody = Field(default_factory=MultimodalSectionBody)
    video: MultimodalSectionBody = Field(default_factory=MultimodalSectionBody)


# ── Providers (Settings → Providers tab) ────────────────────────────────────


class ProviderInfo(BaseModel):
    """One catalog row enriched with the user's current configuration state."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    description: str
    kind: str  # "api_key" | "oauth" | "local" | "cloud_creds"
    credentials: list[dict[str, object]] = Field(default_factory=list)
    env_var: str = ""
    env_vars: list[str] = Field(default_factory=list)
    # Only set for providers without a live model-listing endpoint
    # (currently just vertexai). Other providers return an empty list
    # here and the UI must call the `/models` endpoint to populate.
    fallback_models: list[str] = Field(default_factory=list)
    oauth_command: str = ""
    docs_url: str = ""
    # State the UI uses to decide whether to render "Connected" or a CTA.
    is_configured: bool = False


class ProvidersListBody(BaseModel):
    """``GET /api/settings/providers`` response."""

    model_config = ConfigDict(extra="forbid")

    providers: list[ProviderInfo]
    has_any_configured: bool


class ProviderModelsResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: str
    # Just agent-usable text-chat model IDs. We deliberately don't ship per-model capability
    # flags here: the prefix-based resolver is too coarse for a
    # per-model UI badge ("text-embedding-3-small" would show vision
    # because `openai:` is vision-true), and a curated registry would be
    # stale by the time the user upgraded the app. If capability ever
    # needs to surface on this endpoint, build it from a runtime-fetched
    # registry — see ``documents/techdebts/model-capabilities-registry.md``.
    models: list[str] = Field(default_factory=list)
    # ``provider`` = list returned by the live provider API.
    # ``fallback`` = curated list from the catalog (provider has no
    # listing endpoint, or live discovery failed). Only providers with
    # ``fallback_models`` set in the catalog ever return this.
    source: Literal["provider", "fallback"]


class ProviderTestRequest(BaseModel):
    """``POST /api/settings/providers/{id}/test`` request body."""

    model_config = ConfigDict(extra="forbid")

    # ``api_key`` lets the UI verify a key *before* persisting it. Empty
    # string means "use the already-saved key" — useful for re-testing
    # an existing config.
    api_key: str = ""
    model: str
    # Multi-field providers (vertexai) pass their extras here.
    extra: dict[str, str] = Field(default_factory=dict)


class ProviderModelsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    api_key: str = ""
    extra: dict[str, str] = Field(default_factory=dict)


class ProviderTestResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ok: bool
    latency_ms: int | None = None
    error: str | None = None


class ProviderSaveRequest(BaseModel):
    """``PUT /api/settings/providers/{id}`` request body."""

    model_config = ConfigDict(extra="forbid")

    api_key: str = ""
    extra: dict[str, str] = Field(default_factory=dict)


class ProviderSaveResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    saved: bool
    # Convenience: whether this save call resulted in the first
    # configured provider (frontend uses this to decide whether to
    # trigger the seed installer afterward).
    is_first_provider: bool = False


class SeedInstallRequest(BaseModel):
    """``POST /api/settings/seed`` request body."""

    model_config = ConfigDict(extra="forbid")

    # ``provider:model`` string that substitutes for ``__PROVIDER_MODEL__``
    # in every seeded agent .md.
    provider_model: str = Field(min_length=1)


class SeedInstallResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agents_written: list[str] = Field(default_factory=list)
    skills_written: list[str] = Field(default_factory=list)
    configs_written: list[str] = Field(default_factory=list)
    source: str  # "local", "tag:v0.x.y", or "branch:main"
