import inspect
from typing import Callable, Optional, Tuple, Union, Mapping

from autolog._logger import get_logger
from autolog._wrapper import wrap


def _resolve_level(module_name: str, level_spec: Union[str, Mapping[str, str]], default: str = "INFO") -> str:
    """Resolve the log level for a module. Accepts str or {package_prefix: level}."""
    if isinstance(level_spec, str):
        return level_spec
    if isinstance(level_spec, Mapping):
        for k in sorted(level_spec.keys(), key=len, reverse=True):
            if k == "default":
                continue
            if module_name == k or module_name.startswith(k + "."):
                return str(level_spec[k])
        return str(level_spec.get("default", default))
    return default


def _make_wrapper(
    func: Callable,
    *,
    service: Optional[str] = None,
    level: Union[str, Mapping[str, str]] = "INFO",
    log_file: Optional[str] = None,
    trunc: int = 100,
    format: str = "compact",
    sample: float = 1.0,
    force: bool = False,
) -> Callable:
    module = getattr(func, "__module__", "unknown") or "unknown"
    qualname = getattr(func, "__qualname__", func.__name__)
    func_location = f"{module}.{qualname}"

    resolved_level = _resolve_level(module, level)

    logger = get_logger(
        name=module,
        level=resolved_level,
        log_file=log_file,
        service=service or module,
        trunc=trunc,
        format=format,
    )
    return wrap(
        func,
        logger=logger,
        func_location=func_location,
        service=service or module.split(".")[0],
        trunc=trunc,
        sample=sample,
        force=force,
    )


def log_function(
    func=None,
    *,
    service=None,
    level="INFO",
    log_file=None,
    trunc=100,
    format="compact",
    sample: float = 1.0,
):
    """Decorator. Can be used bare (@log_function) or with options (@log_function(...))."""
    if func is not None and callable(func):
        return _make_wrapper(
            func, service=service, level=level, log_file=log_file,
            trunc=trunc, format=format, sample=sample,
        )

    def decorator(f):
        return _make_wrapper(
            f, service=service, level=level, log_file=log_file,
            trunc=trunc, format=format, sample=sample,
        )

    return decorator


def log_class(cls=None, *, skip: Tuple[str, ...] = (), sample: float = 1.0):
    if cls is None:
        def decorator(c):
            return _apply_log_class(c, skip=skip, sample=sample)
        return decorator
    return _apply_log_class(cls, skip=skip, sample=sample)


def _apply_log_class(cls, *, skip: Tuple[str, ...] = (), sample: float = 1.0):
    for name, raw in list(cls.__dict__.items()):
        if name in skip:
            continue
        if name.startswith("_") and name not in ("__init__", "__call__"):
            continue

        if isinstance(raw, staticmethod):
            inner = raw.__func__
            if inspect.isfunction(inner):
                setattr(cls, name, staticmethod(_make_wrapper(inner, sample=sample)))
        elif isinstance(raw, classmethod):
            inner = raw.__func__
            if inspect.isfunction(inner):
                setattr(cls, name, classmethod(_make_wrapper(inner, sample=sample)))
        elif isinstance(raw, property):
            fget = _make_wrapper(raw.fget, sample=sample) if raw.fget else None
            fset = _make_wrapper(raw.fset, sample=sample) if raw.fset else None
            fdel = _make_wrapper(raw.fdel, sample=sample) if raw.fdel else None
            setattr(cls, name, property(fget, fset, fdel, raw.__doc__))
        elif inspect.isfunction(raw):
            setattr(cls, name, _make_wrapper(raw, sample=sample))
    return cls


def log(target=None, *, sample: float = 1.0, **kwargs):
    """Unified decorator: detects function vs class automatically.

    @log
    def foo(): ...

    @log
    class Bar: ...

    @log(sample=0.1)
    def hot_path(): ...
    """
    def _apply(obj):
        if inspect.isclass(obj):
            return _apply_log_class(obj, sample=sample)
        return _make_wrapper(obj, sample=sample, **kwargs)

    if target is None:
        return _apply
    if callable(target) or inspect.isclass(target):
        return _apply(target)
    return _apply
