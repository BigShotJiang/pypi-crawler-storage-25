import functools
import inspect
import logging as _logging
import os
import random
import time
import traceback
from typing import Callable


def no_log(func: Callable) -> Callable:
    """Mark a function so autolog will skip wrapping it (use with auto-patcher)."""
    setattr(func, "_autolog_skip", True)
    return func

from autolog._context import get_bound_fields, get_trace_id
from autolog._formatter import (
    _is_sensitive,
    _to_json,
    _redact_sensitive,
    _MISSING,
)


def _scrub_args(func: Callable, args: tuple, kwargs: dict) -> tuple:
    try:
        varnames = func.__code__.co_varnames[: func.__code__.co_argcount]
    except AttributeError:
        return args, kwargs

    scrubbed_args = []
    for i, val in enumerate(args):
        if i < len(varnames) and _is_sensitive(varnames[i]):
            scrubbed_args.append("[REDACTED]")
        else:
            scrubbed_args.append(_redact_sensitive(val))

    scrubbed_kwargs = {}
    for k, v in kwargs.items():
        if _is_sensitive(k):
            scrubbed_kwargs[k] = "[REDACTED]"
        else:
            scrubbed_kwargs[k] = _redact_sensitive(v)

    return tuple(scrubbed_args), scrubbed_kwargs


def _format_inputs(func: Callable, scrubbed_args: tuple, scrubbed_kwargs: dict, trunc: int):
    try:
        varnames = func.__code__.co_varnames[: func.__code__.co_argcount]
    except AttributeError:
        varnames = []

    combined = {}
    for i, val in enumerate(scrubbed_args):
        name = varnames[i] if i < len(varnames) else f"arg{i}"
        combined[name] = val

    combined.update(scrubbed_kwargs)

    if not combined:
        return None

    return _to_json(combined, trunc)


def _make_record(logger, level, func_location, trace_id, inputs_repr,
                 result=_MISSING, error=None, duration=None, tb=None, bound=None,
                 service=None):
    record = logger.makeRecord(
        logger.name, level, "(autolog)", 0, func_location, (), None
    )
    record.func_location = func_location
    record.trace_id = trace_id
    record.func_inputs = inputs_repr
    if service is not None:
        record.func_service = service
    if result is not _MISSING:
        record.func_result = result
    if error is not None:
        record.func_error = error
    if duration is not None:
        record.func_duration = duration
    if tb is not None:
        record.func_traceback = tb
    if bound:
        record.func_bound = bound
    return record


def _emit_success(logger, func_location, trace_id, inputs_repr, result, duration, trunc, service):
    record = _make_record(
        logger, _logging.INFO, func_location, trace_id, inputs_repr,
        result=_to_json(_redact_sensitive(result), trunc),
        duration=duration,
        bound=get_bound_fields(),
        service=service,
    )
    logger.handle(record)


def _emit_error(logger, func_location, trace_id, inputs_repr, exc, duration, service):
    tb_str = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    record = _make_record(
        logger, _logging.ERROR, func_location, trace_id, inputs_repr,
        error=repr(exc),
        duration=duration,
        tb=tb_str,
        bound=get_bound_fields(),
        service=service,
    )
    logger.handle(record)


def _should_log(sample: float) -> bool:
    """Decide if this call should be sampled in. 1.0 = always, 0.0 = never."""
    if sample >= 1.0:
        return True
    if sample <= 0.0:
        return False
    return random.random() < sample


def wrap(
    func: Callable,
    *,
    logger,
    func_location: str,
    service: str = None,
    trunc: int = 100,
    sample: float = 1.0,
    force: bool = False,
) -> Callable:
    if getattr(func, "_autolog_wrapped", False):
        if force:
            # Peel back to the original so new config takes effect
            while getattr(func, "_autolog_wrapped", False):
                func = getattr(func, "__wrapped__", func)
        else:
            return func
    if getattr(func, "_autolog_skip", False):
        return func
    if os.environ.get("AUTOLOG_DISABLE"):
        return func

    is_async_gen = inspect.isasyncgenfunction(func)
    is_coroutine = inspect.iscoroutinefunction(func)
    is_generator = inspect.isgeneratorfunction(func)

    if is_async_gen:
        @functools.wraps(func)
        async def async_gen_wrapper(*args, **kwargs):
            if not logger.isEnabledFor(_logging.INFO) or not _should_log(sample):
                async for item in func(*args, **kwargs):
                    yield item
                return

            scrubbed_args, scrubbed_kwargs = _scrub_args(func, args, kwargs)
            inputs_repr = _format_inputs(func, scrubbed_args, scrubbed_kwargs, trunc)
            trace_id = get_trace_id()
            start = time.perf_counter()
            count = 0
            try:
                async for item in func(*args, **kwargs):
                    count += 1
                    yield item
                duration = time.perf_counter() - start
                _emit_success(
                    logger, func_location, trace_id, inputs_repr,
                    f"<async generator: {count} items>", duration, trunc, service,
                )
            except Exception as exc:
                duration = time.perf_counter() - start
                _emit_error(logger, func_location, trace_id, inputs_repr, exc, duration, service)
                raise

        async_gen_wrapper._autolog_wrapped = True
        return async_gen_wrapper

    if is_coroutine:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            if not logger.isEnabledFor(_logging.INFO) or not _should_log(sample):
                return await func(*args, **kwargs)

            scrubbed_args, scrubbed_kwargs = _scrub_args(func, args, kwargs)
            inputs_repr = _format_inputs(func, scrubbed_args, scrubbed_kwargs, trunc)
            trace_id = get_trace_id()
            start = time.perf_counter()

            try:
                result = await func(*args, **kwargs)
                duration = time.perf_counter() - start
                _emit_success(logger, func_location, trace_id, inputs_repr, result, duration, trunc, service)
                return result
            except Exception as exc:
                duration = time.perf_counter() - start
                _emit_error(logger, func_location, trace_id, inputs_repr, exc, duration, service)
                raise

        async_wrapper._autolog_wrapped = True
        return async_wrapper

    if is_generator:
        @functools.wraps(func)
        def gen_wrapper(*args, **kwargs):
            if not logger.isEnabledFor(_logging.INFO) or not _should_log(sample):
                yield from func(*args, **kwargs)
                return

            scrubbed_args, scrubbed_kwargs = _scrub_args(func, args, kwargs)
            inputs_repr = _format_inputs(func, scrubbed_args, scrubbed_kwargs, trunc)
            trace_id = get_trace_id()
            start = time.perf_counter()
            count = 0
            try:
                for item in func(*args, **kwargs):
                    count += 1
                    yield item
                duration = time.perf_counter() - start
                _emit_success(
                    logger, func_location, trace_id, inputs_repr,
                    f"<generator: {count} items>", duration, trunc, service,
                )
            except Exception as exc:
                duration = time.perf_counter() - start
                _emit_error(logger, func_location, trace_id, inputs_repr, exc, duration, service)
                raise

        gen_wrapper._autolog_wrapped = True
        return gen_wrapper

    @functools.wraps(func)
    def sync_wrapper(*args, **kwargs):
        if not logger.isEnabledFor(_logging.INFO) or not _should_log(sample):
            return func(*args, **kwargs)

        scrubbed_args, scrubbed_kwargs = _scrub_args(func, args, kwargs)
        inputs_repr = _format_inputs(func, scrubbed_args, scrubbed_kwargs, trunc)
        trace_id = get_trace_id()
        start = time.perf_counter()

        try:
            result = func(*args, **kwargs)
            duration = time.perf_counter() - start
            _emit_success(logger, func_location, trace_id, inputs_repr, result, duration, trunc, service)
            return result
        except Exception as exc:
            duration = time.perf_counter() - start
            _emit_error(logger, func_location, trace_id, inputs_repr, exc, duration, service)
            raise

    sync_wrapper._autolog_wrapped = True
    return sync_wrapper
