import logging
import os
import sys
import threading
from logging.handlers import RotatingFileHandler

from autolog._formatter import make_formatter

_loggers: dict = {}
_loggers_lock = threading.Lock()
_underlying_configs: dict = {}

_DEFAULT_LEVEL = "INFO"
_DEFAULT_TRUNC = 100
_DEFAULT_FILE_MAX_BYTES = 10 * 1024 * 1024
_DEFAULT_FILE_BACKUPS = 5


def _ensure_utf8_stdout():
    """Reconfigure sys.stdout to UTF-8 in place (Py3.7+) so non-ASCII chars work."""
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, AttributeError, OSError):
            pass


def get_logger(
    name: str = "autolog",
    *,
    level: str = "INFO",
    log_file: str = None,
    service: str = None,
    trunc: int = 100,
    format: str = "compact",
) -> logging.Logger:
    env_level = os.environ.get("AUTOLOG_LEVEL", level)
    env_file = os.environ.get("AUTOLOG_FILE", log_file)
    env_service = os.environ.get("AUTOLOG_SERVICE", service or name)
    env_format = os.environ.get("AUTOLOG_FORMAT", format).lower()
    if env_format not in ("pretty", "compact", "json"):
        env_format = "compact"

    cache_key = (name, env_level, env_file, env_service, trunc, env_format)
    cached = _loggers.get(cache_key)
    if cached is not None:
        return cached

    with _loggers_lock:
        cached = _loggers.get(cache_key)
        if cached is not None:
            return cached
        return _build_and_cache_logger(cache_key, name, env_level, env_file, trunc, env_format)


def _build_and_cache_logger(cache_key, name, env_level, env_file, trunc, env_format):
    base = f"autolog.{name}"
    config = (env_level.upper(), env_file, trunc, env_format)

    existing_config = _underlying_configs.get(base)
    if existing_config is None or existing_config == config:
        logger_name = base
    else:
        config_hash = abs(hash(config)) % 100000
        logger_name = f"{base}.{config_hash}"

    _underlying_configs[logger_name] = config

    logger = logging.getLogger(logger_name)
    logger.setLevel(getattr(logging, env_level.upper(), logging.INFO))
    logger.propagate = False

    for h in list(logger.handlers):
        if getattr(h, "_autolog_handler", False):
            logger.removeHandler(h)

    no_color = bool(os.environ.get("NO_COLOR"))
    force_color = bool(os.environ.get("FORCE_COLOR"))
    is_tty = getattr(sys.stdout, "isatty", lambda: False)()
    use_color = (
        env_format in ("pretty", "compact")
        and not no_color
        and (force_color or is_tty)
    )
    _ensure_utf8_stdout()
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(
        make_formatter(env_format, use_color=use_color, trunc=trunc)
    )
    console_handler._autolog_handler = True
    logger.addHandler(console_handler)

    if env_file:
        try:
            max_bytes = int(os.environ.get("AUTOLOG_FILE_MAX_BYTES", _DEFAULT_FILE_MAX_BYTES))
            backups = int(os.environ.get("AUTOLOG_FILE_BACKUPS", _DEFAULT_FILE_BACKUPS))
            file_handler = RotatingFileHandler(
                env_file,
                maxBytes=max_bytes,
                backupCount=backups,
                encoding="utf-8",
            )
            file_handler.setFormatter(
                make_formatter(env_format, use_color=False, trunc=trunc)
            )
            file_handler._autolog_handler = True
            logger.addHandler(file_handler)
        except OSError as exc:
            logging.warning(
                f"[autolog] Cannot open log file {env_file!r}: {exc}. "
                "Continuing with console only."
            )

    _loggers[cache_key] = logger
    return logger
