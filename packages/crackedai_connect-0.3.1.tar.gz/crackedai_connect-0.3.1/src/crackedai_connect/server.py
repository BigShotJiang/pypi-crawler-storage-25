import base64
import secrets

from flask import Flask, jsonify, request
from flask_cors import CORS

from crackedai_connect import __version__
from crackedai_connect.contract import DEFAULT_TIMEOUT_MS, validate_execute_request
from crackedai_connect.detect import detect_environment
from crackedai_connect.executor import execute
from crackedai_connect.tensor_cache import TensorCache


# Per-process auth token. Generated fresh at startup and exposed on /health
# so the (CORS-allowlisted) website can fetch it. /execute requires it as the
# `X-CrackedAI-Token` header.
#
# Why this exists: CORS is browser-enforced. A non-browser client (e.g. an
# installed desktop app abusing Electron's WebView, a malicious local script)
# can ignore CORS and POST arbitrary code to the runtime. The token raises
# the bar — an attacker now has to read /health (which is itself CORS-locked)
# AND replay it in their request.
def _new_auth_token():
    return secrets.token_urlsafe(32)


def create_app(auth_token=None):
    app = Flask(__name__)
    app.config["CRACKEDAI_AUTH_TOKEN"] = auth_token or _new_auth_token()
    app.config["TENSOR_CACHE"] = TensorCache()

    CORS(
        app,
        origins=["https://crackedaicode.com", "http://localhost:4000"],
        expose_headers=["X-CrackedAI-Token"],
    )

    # Cache detection at startup
    env_info = detect_environment()

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify(
            {
                "status": "ok",
                "version": __version__,
                "auth_token": app.config["CRACKEDAI_AUTH_TOKEN"],
                **env_info,
            }
        )

    @app.route("/execute", methods=["POST"])
    def execute_code():
        provided = request.headers.get("X-CrackedAI-Token")
        expected = app.config["CRACKEDAI_AUTH_TOKEN"]
        if not provided or not secrets.compare_digest(provided, expected):
            return jsonify({"error": "missing or invalid X-CrackedAI-Token header"}), 401

        data = request.get_json(silent=True)
        err = validate_execute_request(data)
        if err:
            return jsonify({"error": err}), 400

        # Resolve `data_ref` references in test-case tensors using the cache,
        # and register any new full-data tensors so future requests can refer
        # to them by hash. Tracks which refs the client now knows are cached.
        cache = app.config["TENSOR_CACHE"]
        cached_refs = set()
        try:
            test_cases = _process_tensor_refs(data["test_cases"], cache, cached_refs)
        except KeyError as missing:
            # Client referenced a hash we don't have. Tell them which ones,
            # so they can resend with full data.
            return (
                jsonify({
                    "error": "tensor data_ref not in cache (cache evicted or runtime restarted)",
                    "missing_refs": [missing.args[0]],
                }),
                422,
            )

        result = execute(
            code=data["code"],
            framework=data["framework"],
            function_name=data["function_name"],
            test_cases=test_cases,
            timeout_ms=data.get("timeout_ms", DEFAULT_TIMEOUT_MS),
            reference_code=data.get("reference_code"),
            benchmark=data.get("benchmark", False),
        )

        if cached_refs:
            result["cached_refs"] = sorted(cached_refs)
        return jsonify(result)

    return app


def _process_tensor_refs(obj, cache, registered):
    """Recursively walk a JSON-decoded structure. For each tensor dict:

    - If it has `data_ref`, look up the bytes and inject them back as `data`.
      Raise KeyError(ref) on miss.
    - If it has `data`, hash the bytes, register them with the cache, and
      attach `data_ref` so the response can advertise the hash.
    """
    if isinstance(obj, dict):
        if "shape" in obj and ("data" in obj or "data_ref" in obj):
            return _process_tensor_dict(obj, cache, registered)
        return {k: _process_tensor_refs(v, cache, registered) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_process_tensor_refs(x, cache, registered) for x in obj]
    return obj


def _process_tensor_dict(obj, cache, registered):
    if "data_ref" in obj and "data" not in obj:
        ref = obj["data_ref"]
        cached = cache.get(ref)
        if cached is None:
            raise KeyError(ref)
        return {**obj, "data": base64.b64encode(cached).decode("ascii")}

    if "data" in obj:
        try:
            raw = base64.b64decode(obj["data"])
        except Exception:
            return obj  # let the harness surface the bad-payload error
        h = cache.put(raw)
        registered.add(h)
        return {**obj, "data_ref": h}

    return obj
