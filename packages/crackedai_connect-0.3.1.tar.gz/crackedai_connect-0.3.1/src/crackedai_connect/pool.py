"""Long-lived worker pool for executing user code.

Why this exists
---------------
A naive implementation spawns a fresh Python subprocess per `/execute`,
re-paying the `import torch` (~0.5–2s) or `import jax` (~1–4s) cost every
time. For Submit-with-benchmark this multiplies by 8 — easily 10–30s of
overhead unrelated to the user's code.

The pool keeps a small set of warm workers alive. On POSIX with `fork`,
every task inherits already-imported `torch`/`jax` modules from the worker
parent. On macOS with `spawn` (the default since Python 3.8) we don't get
fork-warmup, but `maxtasksperchild` lets us amortize the cost across N tasks
per worker before recycling.

Trade-offs
----------
- `maxtasksperchild=8`: bounds state leak between requests (numpy random
  seed, JIT caches). Most ML practice problems are pure functions, so leak
  is rarely observable; 8 is a balance between warmup amortization and
  paranoia. Set `CRACKEDAI_MAX_TASKS_PER_CHILD=1` to opt out.
- On timeout we terminate the whole pool. Subsequent requests spin up a
  fresh one. This is intentional: a single-user, localhost tool can afford
  to lose in-flight work to keep the pool clean.
- The pool is created lazily so importing this module is cheap — the cost
  is paid on the first /execute.
"""

import multiprocessing as mp
import os
import platform
import time

# Recycle the entire pool periodically to bound memory growth from JIT caches
# / fragmentation. 30 minutes is long enough that interactive use rarely sees
# a recycle, short enough that an idle runtime doesn't grow forever.
POOL_MAX_AGE_SEC = 30 * 60

_DEFAULT_PROCESSES = 2
_DEFAULT_MAX_TASKS_PER_CHILD = 8

_pool = None
_pool_started_at = 0.0


def _worker_init():
    """Run in each worker on startup. Pre-imports the heavy modules so per-task
    fork() (POSIX) inherits them. On spawn-context macOS this happens once per
    worker — still amortizes across `maxtasksperchild` requests.

    Per-task RNG reset so consecutive submits to the same worker get a clean
    starting state — without this, the second-onwards user submits inherit
    numpy/torch random state from the previous one. (We seed at init too; the
    per-task reset belongs in the parent's apply_async caller, but starting
    deterministic here at least makes worker-level state predictable.)
    """
    import numpy  # noqa: F401

    try:
        import torch  # noqa: F401
    except ImportError:
        pass

    try:
        import jax  # noqa: F401
    except ImportError:
        pass


def _pool_context():
    """Pick a multiprocessing start method.

    Linux: `fork`. Per-task children inherit already-imported `torch`/`jax`
    at zero cost. JAX-on-Linux's CPU XLA runtime is fork-safe in practice;
    JAX-on-CUDA is also generally OK because the parent hasn't touched the
    GPU yet (workers do that themselves).

    macOS + Windows: `spawn`. macOS could theoretically use fork, but JAX
    explicitly warns "JAX is multithreaded, so this will likely lead to a
    deadlock" when you fork after importing it. The warning fires on every
    pytorch-only run too because we eagerly preimport jax in the worker
    init. Spawn pays the import cost per worker (still amortised by
    `maxtasksperchild`) but avoids the deadlock class entirely. Set
    `CRACKEDAI_USE_FORK=1` to opt back into fork if you know your usage
    is jax-free.
    """
    if os.environ.get("CRACKEDAI_USE_FORK") == "1":
        return mp.get_context("fork")

    if platform.system() == "Linux":
        return mp.get_context("fork")

    return mp.get_context("spawn")


def _config():
    return {
        "processes": int(os.environ.get("CRACKEDAI_POOL_SIZE", _DEFAULT_PROCESSES)),
        "maxtasksperchild": int(
            os.environ.get("CRACKEDAI_MAX_TASKS_PER_CHILD", _DEFAULT_MAX_TASKS_PER_CHILD)
        ),
    }


def get_pool():
    """Return the current pool, recycling if it's older than POOL_MAX_AGE_SEC."""
    global _pool, _pool_started_at

    if _pool is not None and (time.time() - _pool_started_at) > POOL_MAX_AGE_SEC:
        shutdown_pool()

    if _pool is None:
        cfg = _config()
        ctx = _pool_context()
        _pool = ctx.Pool(
            processes=cfg["processes"],
            maxtasksperchild=cfg["maxtasksperchild"],
            initializer=_worker_init,
        )
        _pool_started_at = time.time()
    return _pool


def shutdown_pool():
    """Terminate the pool. Used after a hung worker, on exit, and for tests."""
    global _pool
    if _pool is not None:
        try:
            _pool.terminate()
            _pool.join()
        finally:
            _pool = None
