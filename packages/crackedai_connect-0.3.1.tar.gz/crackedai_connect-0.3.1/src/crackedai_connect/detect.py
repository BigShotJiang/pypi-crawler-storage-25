import platform
import sys


def detect_environment():
    """Detect hardware, installed frameworks, and Python version."""
    return {
        "hardware": _detect_hardware(),
        "frameworks": _detect_frameworks(),
        "python": platform.python_version(),
    }


def _detect_hardware():
    device = "cpu"
    device_name = platform.processor() or platform.machine()

    try:
        import torch
        if torch.cuda.is_available():
            device = "cuda"
            device_name = torch.cuda.get_device_name(0)
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            device = "mps"
            device_name = f"Apple {platform.machine()}"
    except ImportError:
        pass

    return {
        "platform": platform.system(),
        "processor": platform.processor() or platform.machine(),
        "device": device,
        "device_name": device_name,
    }


def _detect_frameworks():
    frameworks = {}

    try:
        import numpy
        frameworks["numpy"] = {"version": numpy.__version__, "available": True}
    except ImportError:
        frameworks["numpy"] = {"available": False}

    try:
        import torch
        device = "cpu"
        if torch.cuda.is_available():
            device = "cuda"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            device = "mps"
        frameworks["pytorch"] = {"version": torch.__version__, "available": True, "device": device}
    except ImportError:
        frameworks["pytorch"] = {"available": False}

    try:
        import jax
        frameworks["jax"] = {"version": jax.__version__, "available": True, "backend": jax.default_backend()}
    except ImportError:
        frameworks["jax"] = {"available": False}

    return frameworks
