from crackedai_connect.cli import main
main()
