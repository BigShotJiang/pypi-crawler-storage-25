from crackedai_connect import __version__

PORT = 52341


def main():
    print()
    print(f"  CrackedAI Runtime v{__version__}")

    # Auto-install torch/jax if missing
    from crackedai_connect.setup import ensure_frameworks

    ensure_frameworks()

    # Now detect what's available (imports happen after install)
    from crackedai_connect.detect import detect_environment

    env = detect_environment()

    print(f"  Detected: {env['hardware']['device_name']} | {env['hardware']['platform']}")

    for name, info in env["frameworks"].items():
        if info["available"]:
            detail = ""
            if "device" in info:
                detail = f" ({info['device'].upper()} accelerated)"
            elif "backend" in info:
                detail = f" ({info['backend']})"
            print(f"    {name} {info['version']} \u2713{detail}")
        else:
            print(f"    {name} \u2717 (not installed)")

    print()
    print(f"  Listening on http://127.0.0.1:{PORT}")
    print("  Open crackedaicode.com to start solving problems.")
    print("  Press Ctrl+C to stop.")
    print()

    from crackedai_connect.server import create_app

    app = create_app()
    app.run(host="127.0.0.1", port=PORT, debug=False)


if __name__ == "__main__":
    main()
