"""Auto-detect hardware and install the right PyTorch + JAX versions."""

import platform
import shutil
import subprocess
import sys

# Marker file to skip reinstall on subsequent runs
_SETUP_MARKER = None


def ensure_frameworks():
    """Detect hardware and install/reinstall the correct torch + jax versions.

    Always reinstalls on first run to ensure hardware-matched versions.
    Writes a marker file after successful setup so subsequent runs skip this.
    """
    import pathlib

    marker = pathlib.Path.home() / ".crackedai" / "setup_done"

    if marker.exists():
        # Already set up once — verify frameworks are importable
        if _is_installed("torch") and _is_installed("jax"):
            return
        # Marker exists but frameworks missing (user uninstalled?) — reinstall
        marker.unlink()

    print("\n  Setting up ML frameworks for your hardware...")

    cuda_version = _detect_cuda_version()
    apple_silicon = _is_apple_silicon()

    if cuda_version:
        major, _ = _parse_cuda_version(cuda_version)
        print(f"  Found NVIDIA GPU (CUDA {cuda_version})")
        _install_torch_cuda(cuda_version)
        _install_jax_cuda(str(major))
    elif apple_silicon:
        print("  Found Apple Silicon (MPS)")
        _install_torch_default()
        _install_jax_default()
    else:
        print("  No GPU detected, installing CPU versions")
        _install_torch_cpu()
        _install_jax_default()

    # Verify installation worked
    if _is_installed("torch") and _is_installed("jax"):
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text("ok")
        print("  Setup complete!")
    else:
        print("  Warning: some frameworks failed to install.")
        print("  You can install them manually and re-run crackedai-connect.")

    print()


def _is_installed(package):
    """Check if a Python package is importable."""
    try:
        __import__(package)
        return True
    except ImportError:
        return False


def _detect_cuda_version():
    """Detect CUDA version from nvidia-smi."""
    nvidia_smi = shutil.which("nvidia-smi")
    if not nvidia_smi:
        return None

    try:
        result = subprocess.run(
            [nvidia_smi],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None

        # Parse "CUDA Version: 12.4" from nvidia-smi output
        for line in result.stdout.split("\n"):
            if "CUDA Version" in line:
                parts = line.split("CUDA Version:")
                if len(parts) > 1:
                    return parts[1].strip().split()[0]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return None


def _parse_cuda_version(cuda_version):
    """Parse CUDA version string into (major, minor) tuple."""
    parts = cuda_version.split(".")
    major = int(parts[0])
    minor = int(parts[1]) if len(parts) > 1 else 0
    return major, minor


def _torch_cuda_tag(cuda_version):
    """Map CUDA version to PyTorch wheel index tag.

    PyTorch publishes wheels for specific CUDA versions:
    cu118 (11.8), cu121 (12.1), cu124 (12.4), cu126 (12.6)
    We pick the highest tag that doesn't exceed the installed CUDA version.
    """
    major, minor = _parse_cuda_version(cuda_version)

    if major >= 13:
        return "cu126"  # latest available, forward-compatible
    elif major == 12:
        if minor >= 6:
            return "cu126"
        elif minor >= 4:
            return "cu124"
        else:
            return "cu121"
    elif major == 11:
        return "cu118"
    else:
        return "cu121"  # fallback


def _is_apple_silicon():
    """Check if running on Apple Silicon."""
    return platform.system() == "Darwin" and platform.machine() == "arm64"


def _pip_install(args, label):
    """Run pip install with progress."""
    print(f"  Installing {label}...", end=" ", flush=True)
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet"] + args
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if result.returncode == 0:
        print("done")
    else:
        print("failed")
        print(f"    Error: {result.stderr.strip()[:200]}")


def _install_torch_cuda(cuda_version):
    """Install PyTorch with CUDA support."""
    tag = _torch_cuda_tag(cuda_version)
    index = f"https://download.pytorch.org/whl/{tag}"
    _pip_install(
        ["torch", "--extra-index-url", index],
        f"PyTorch (CUDA {cuda_version}, {tag})",
    )


def _install_torch_default():
    """Install PyTorch (standard — includes MPS on Apple Silicon)."""
    _pip_install(["torch"], "PyTorch (MPS)")


def _install_torch_cpu():
    """Install PyTorch CPU-only (smaller download)."""
    _pip_install(
        ["torch", "--extra-index-url", "https://download.pytorch.org/whl/cpu"],
        "PyTorch (CPU)",
    )


def _install_jax_cuda(cuda_major):
    """Install JAX with CUDA support."""
    # cuda13 is the latest, fall back to cuda12 for older drivers
    extra = f"cuda{cuda_major}"
    _pip_install([f"jax[{extra}]"], f"JAX (CUDA {cuda_major})")


def _install_jax_default():
    """Install JAX (auto-detects backend)."""
    _pip_install(["jax"], "JAX")
