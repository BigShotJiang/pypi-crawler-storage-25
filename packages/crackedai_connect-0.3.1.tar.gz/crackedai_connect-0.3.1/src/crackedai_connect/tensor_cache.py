"""In-memory LRU for tensor binaries, keyed by content hash.

Why this exists
---------------
For a given problem, the website re-sends the same test-case tensors on every
Submit. With base64 binary payloads (P14), each tensor is `~4 × num_elements`
bytes — small for toy problems, megabytes for the bigger ones.

This cache lets the website send a tensor *once* (full `data`), then reference
it by `data_ref` (the sha256) on subsequent requests. The runtime substitutes
the cached bytes back in before passing test cases to the worker pool.

The cache lives in the parent (Flask) process. Workers in the pool never see
it — the substitution happens in `server.py` before `execute()` is called.

Lifetime
--------
- Bound by `MAX_ENTRIES` (default 1000), evicted LRU.
- Cleared when the runtime restarts (in-memory only). The auth token
  rotates on restart too, so the website can use token equality as a signal
  that its cached refs are still valid.
"""

import hashlib
import threading
from collections import OrderedDict

MAX_ENTRIES = 1000


class TensorCache:
    def __init__(self, max_entries=MAX_ENTRIES):
        self.max = max_entries
        self.lock = threading.Lock()
        self.cache = OrderedDict()

    def put(self, data):
        """Insert `data` (bytes). Returns the sha256 hex digest."""
        h = hashlib.sha256(data).hexdigest()
        with self.lock:
            if h in self.cache:
                self.cache.move_to_end(h)
            else:
                self.cache[h] = data
                if len(self.cache) > self.max:
                    self.cache.popitem(last=False)
        return h

    def get(self, h):
        """Look up bytes by hex digest. Returns None on miss."""
        with self.lock:
            if h in self.cache:
                self.cache.move_to_end(h)
                return self.cache[h]
            return None

    def clear(self):
        with self.lock:
            self.cache.clear()
