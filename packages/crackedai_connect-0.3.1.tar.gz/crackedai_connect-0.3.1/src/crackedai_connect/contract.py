"""Wire-protocol contract for crackedai-connect.

This module is the single source of truth for the HTTP request/response shapes
the runtime accepts. The website (cracked-ai-code) must produce requests that
satisfy `validate_execute_request`. If you change the shape here, also update:

  - cracked-ai-code/crackedaicode/lib/crackedaicode_web/live/problem_solve_live.ex
  - cracked-ai-code/crackedaicode/assets/js/local_runtime.js (if it ever inspects fields)
  - docs/CONTRACT.md (the human-readable mirror of this file)
"""

VALID_FRAMEWORKS = ("pytorch", "jax")
DEFAULT_TIMEOUT_MS = 30_000


def validate_execute_request(data):
    """Validate an /execute request body. Returns None if valid, else an error string."""
    if not isinstance(data, dict):
        return "request body must be a JSON object"

    required = {"code", "framework", "function_name", "test_cases"}
    missing = required - set(data.keys())
    if missing:
        return f"missing fields: {', '.join(sorted(missing))}"

    if not isinstance(data["code"], str):
        return "code must be a string"
    if data["framework"] not in VALID_FRAMEWORKS:
        return f"framework must be one of: {', '.join(VALID_FRAMEWORKS)}"
    if not isinstance(data["function_name"], str) or not data["function_name"]:
        return "function_name must be a non-empty string"
    if not isinstance(data["test_cases"], list):
        return "test_cases must be a list"

    for i, tc in enumerate(data["test_cases"]):
        err = _validate_test_case(tc, i)
        if err:
            return err

    if "timeout_ms" in data:
        ms = data["timeout_ms"]
        if not isinstance(ms, int) or ms <= 0 or ms > 600_000:
            return "timeout_ms must be a positive integer up to 600000"

    if "reference_code" in data and data["reference_code"] is not None:
        if not isinstance(data["reference_code"], str):
            return "reference_code must be a string or null"

    if "benchmark" in data and not isinstance(data["benchmark"], bool):
        return "benchmark must be a boolean"

    return None


def _validate_test_case(tc, i):
    if not isinstance(tc, dict):
        return f"test_cases[{i}] must be an object"
    for f in ("id", "inputs", "expected"):
        if f not in tc:
            return f"test_cases[{i}] missing field: {f}"
    if not isinstance(tc["id"], str) or not tc["id"]:
        return f"test_cases[{i}].id must be a non-empty string"
    if not isinstance(tc["inputs"], dict):
        return f"test_cases[{i}].inputs must be an object"
    if "tolerance" in tc and not isinstance(tc["tolerance"], (int, float)):
        return f"test_cases[{i}].tolerance must be a number"
    return None
