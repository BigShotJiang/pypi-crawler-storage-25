"""Orchestrates code execution against a long-lived worker pool.

Every `/execute` request goes through `execute()`, which submits the user's
code to the worker pool (see pool.py) and returns the harness's result dict.

If `benchmark=True` and the run passes, `_benchmark()` does 1 warmup +
`runs` timed invocations and attaches median timings. When `reference_code`
is also present, it benchmarks both and computes a ratio. The website
typically sends `benchmark=True` *without* `reference_code` and computes
the ratio server-side from a precomputed per-problem reference time, so
that the official solution never crosses the wire.
"""

import multiprocessing as mp
import statistics
import time

from crackedai_connect.harness import run_tests_with_code
from crackedai_connect.pool import get_pool, shutdown_pool


def _run_with_timeout(code, framework, function_name, test_cases, timeout_ms):
    """Submit one run to the pool. On timeout, terminate the pool so a hung
    worker doesn't block subsequent requests, then return an error dict."""
    timeout_sec = timeout_ms / 1000

    pool = get_pool()
    async_result = pool.apply_async(
        run_tests_with_code, (code, framework, function_name, test_cases)
    )

    try:
        return async_result.get(timeout=timeout_sec)
    except mp.TimeoutError:
        # Hung worker. Tear down the entire pool — it's cheap to rebuild and
        # avoids queueing future requests behind the stuck task.
        shutdown_pool()
        return {
            "status": "error",
            "test_results": [],
            "stdout": "",
            "stderr": f"Timed out after {timeout_ms}ms",
            "runtime_us": timeout_ms * 1000,
        }
    except (Exception, SystemExit) as e:
        # Worker died (sys.exit, segfault, OS kill, unpicklable args, etc.).
        # The pool spawns a replacement on the next request automatically.
        return {
            "status": "error",
            "test_results": [],
            "stdout": "",
            "stderr": f"Worker pool error: {type(e).__name__}: {e}",
            "runtime_us": 0,
        }


def execute(code, framework, function_name, test_cases, timeout_ms=30000, reference_code=None, benchmark=False):
    """Execute user code against test cases, optionally benchmarking on a pass."""
    parsed = _run_with_timeout(code, framework, function_name, test_cases, timeout_ms)

    if benchmark and parsed.get("status") == "passed":
        user_median = _benchmark(code, framework, function_name, test_cases, timeout_ms)
        if user_median is not None:
            parsed["benchmark"] = {"user_median_ms": round(user_median, 2)}
            if reference_code:
                ref_median = _benchmark(reference_code, framework, function_name, test_cases, timeout_ms)
                if ref_median is not None and ref_median > 0:
                    parsed["benchmark"]["reference_median_ms"] = round(ref_median, 2)
                    parsed["benchmark"]["ratio"] = round(user_median / ref_median, 3)

    return parsed


def _benchmark(code, framework, function_name, test_cases, timeout_ms, runs=3):
    """1 warmup + `runs` timed runs. Returns median in ms, or None on any failure.

    Timing uses `perf_counter` around the harness invocation. With the worker
    pool, this excludes Python interpreter startup and framework-import time
    (warmup absorbs the first-fork JIT cost). Both user and reference code pay
    the same per-call overhead, so the ratio is meaningful.
    """
    runtimes = []

    for i in range(1 + runs):
        t_start = time.perf_counter()
        parsed = _run_with_timeout(code, framework, function_name, test_cases, timeout_ms)
        elapsed_ms = (time.perf_counter() - t_start) * 1000

        if parsed.get("status") != "passed":
            return None

        if i > 0:  # skip warmup
            runtimes.append(elapsed_ms)

    return statistics.median(runtimes) if runtimes else None
