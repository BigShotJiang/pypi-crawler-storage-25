"""Test harness. Two ways to run:

  1) As a script (legacy / fallback):
       python run_tests.py <framework> <function_name> <test_cases_json>
     Reads `solution.py` from the cwd and prints JSON results to stdout.

  2) As an imported function:
       from crackedai_connect.harness import run_tests_with_code
       run_tests_with_code(code_str, framework, function_name, test_cases)
     Used by the worker pool to avoid per-request Python startup + framework
     import cost (see executor.py + pool.py).
"""
import base64
import json
import sys
import time
import traceback


# Tensor wire format
# ------------------
# A tensor on the wire is a JSON object with `shape` plus either:
#   - `data`: base64-encoded little-endian binary buffer (preferred, ~3x smaller)
#   - `values`: nested or flat JSON array (legacy, still accepted)
# An optional `dtype` field defaults to "float32". Scalars (int/float/bool)
# pass through unchanged. Anything else is round-tripped as-is and compared
# with `==`.

def _tensor_to_numpy(d):
    """Decode a wire-format tensor dict into a numpy array."""
    import numpy as np
    dtype = np.dtype(d.get("dtype", "float32"))
    if "data" in d:
        return np.frombuffer(base64.b64decode(d["data"]), dtype=dtype).reshape(d["shape"])
    return np.array(d["values"], dtype=dtype).reshape(d["shape"])


def _numpy_to_tensor(arr):
    """Encode a numpy array as the wire-format tensor dict (binary form)."""
    contiguous = arr.copy() if not arr.flags["C_CONTIGUOUS"] else arr
    return {
        "shape": list(arr.shape),
        "dtype": str(arr.dtype),
        "data": base64.b64encode(contiguous.tobytes()).decode("ascii"),
    }


def deserialize_value(value, framework):
    """Convert wire-format JSON value to a framework tensor.

    Recurses into dicts/lists so inputs like `gradients=[t1, t2, t3]` or
    `expert_weights=[w1, w2]` get their nested tensor dicts decoded too.
    Without this, the user code receives a list of dicts and crashes the
    moment it tries to call a tensor op on them.
    """
    if isinstance(value, dict) and "shape" in value and ("data" in value or "values" in value):
        arr = _tensor_to_numpy(value)
        if framework == "pytorch":
            import torch
            return torch.tensor(arr)
        elif framework == "jax":
            import jax.numpy as jnp
            return jnp.array(arr)
    if isinstance(value, dict):
        return {k: deserialize_value(v, framework) for k, v in value.items()}
    if isinstance(value, list):
        return [deserialize_value(v, framework) for v in value]
    return value


def serialize_value(value, framework):
    """Convert a framework tensor (or scalar, or nested container) into
    wire-format JSON. Recurses into dicts/tuples/lists so functions that
    return structured outputs (e.g. an Adam step returning `(m_new, v_new,
    theta_new)`, or a forward pass returning `{"loss": tensor, "metrics":
    {...}}`) round-trip cleanly. Without this, nested jax.Array / torch.Tensor
    objects leak through to Flask's JSON encoder and the request 500s.
    """
    import numpy as np

    # Scalars first — must come before isinstance(np.ndarray) since numpy
    # scalars (np.int64 etc.) don't have a `shape` attribute we want.
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, str):
        return value

    # Numpy: handled the same regardless of framework.
    if isinstance(value, np.ndarray):
        return _numpy_to_tensor(value)

    # Framework-specific tensor types.
    if framework == "pytorch":
        import torch
        if isinstance(value, torch.Tensor):
            return _numpy_to_tensor(value.detach().cpu().numpy())
    elif framework == "jax":
        # jax arrays expose .shape + .dtype. We've already excluded ndarray /
        # scalars above, so anything matching here is a jax tracer/array.
        if hasattr(value, "shape") and hasattr(value, "dtype"):
            return _numpy_to_tensor(np.array(value))

    # Recurse into containers — keep the original structure so the comparator
    # can compare element-wise.
    if isinstance(value, dict):
        return {k: serialize_value(v, framework) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serialize_value(v, framework) for v in value]

    return value


def _is_tensor_dict(d):
    return isinstance(d, dict) and "shape" in d and ("data" in d or "values" in d)


def _unwrap_value(x):
    """Some test cases store scalar expected outputs as `{"value": X}` (a
    single-key sentinel dict) rather than the bare scalar. Treat it
    transparently: a dict with only the `value` key collapses to its value
    on both sides of the comparison. This is a one-way unwrap — no other
    single-key dict is treated specially.
    """
    if isinstance(x, dict) and set(x.keys()) == {"value"}:
        return x["value"]
    return x


def _to_scalar(x):
    """If `x` is unambiguously a scalar — a Python int/float/bool, OR a 0-d
    tensor wrapper — return its numerical value. Otherwise return None.

    This bridges the common mismatch where a solution returns
    `torch.tensor(0.0)` (a 0-d tensor) but the stored expected is `0.0`
    (a bare Python scalar). Only 0-d tensors qualify; a shape-[1] tensor is
    NOT collapsed because that would mask real shape errors.
    """
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return x
    if _is_tensor_dict(x):
        import numpy as np
        a = _tensor_to_numpy(x)
        if a.shape == ():
            return a.item()
    return None


# Relative tolerance when comparing float tensors. atol comes from the
# test case (typically 1e-3 since expecteds are rounded to ~3-4 sig figs);
# rtol catches values where atol alone is too loose for very-small numbers
# AND too tight for very-large numbers. Mirrors numpy's allclose defaults
# but with values calibrated for ML practice problems.
_FLOAT_RTOL = 1e-3


def compare_outputs(actual, expected, tolerance):
    """Compare outputs with numerical tolerance.

    Tensor dicts on either side are decoded to numpy and compared with shape
    + dtype awareness. Float/complex dtypes use np.allclose with both atol
    and rtol so very-small AND very-large values are compared sensibly.
    Integer/bool dtypes use exact equality. Lists/tuples and dicts are
    compared element-wise. The {"value": X} sentinel collapses to X on
    either side. Scalars and other types fall back to ==.
    """
    import numpy as np

    actual = _unwrap_value(actual)
    expected = _unwrap_value(expected)

    # Scalar / 0-d-tensor equivalence: if both sides reduce to a numerical
    # scalar, compare numerically with the same atol+rtol as float tensors.
    # Handles the common case where a solution returns `torch.tensor(0.0)`
    # but the test stores `0.0`.
    a_s = _to_scalar(actual)
    e_s = _to_scalar(expected)
    if a_s is not None and e_s is not None:
        if isinstance(a_s, bool) or isinstance(e_s, bool):
            return a_s == e_s
        return abs(a_s - e_s) <= tolerance + _FLOAT_RTOL * abs(e_s)

    if _is_tensor_dict(expected):
        if not _is_tensor_dict(actual):
            return False
        a = _tensor_to_numpy(actual)
        e = _tensor_to_numpy(expected)
        if a.shape != e.shape:
            return False
        if np.issubdtype(e.dtype, np.floating) or np.issubdtype(e.dtype, np.complexfloating):
            return bool(np.allclose(a.astype(np.float64), e.astype(np.float64), atol=tolerance, rtol=_FLOAT_RTOL))
        return bool(np.array_equal(a, e))
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            return False
        return all(compare_outputs(a, e, tolerance) for a, e in zip(actual, expected))
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return False
        if set(actual.keys()) != set(expected.keys()):
            return False
        return all(compare_outputs(actual[k], expected[k], tolerance) for k in expected)
    if isinstance(expected, bool) or isinstance(actual, bool):
        return actual == expected
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        # Same atol+rtol logic for plain Python floats.
        return abs(actual - expected) <= tolerance + _FLOAT_RTOL * abs(expected)
    return actual == expected


def _run_tests_in_namespace(namespace, framework, function_name, test_cases):
    """Run the harness against an already-populated namespace."""
    func = namespace.get(function_name)
    if func is None:
        available = sorted(k for k, v in namespace.items() if callable(v) and not k.startswith("_"))
        suggestion = f" (available: {', '.join(available)})" if available else ""
        return {
            "status": "error",
            "test_results": [],
            "stdout": "",
            "stderr": f"Function '{function_name}' not found in solution{suggestion}",
            "runtime_us": 0,
        }

    results = []
    total_start = time.perf_counter()
    for tc in test_cases:
        start = time.perf_counter()
        try:
            kwargs = {k: deserialize_value(v, framework) for k, v in tc["inputs"].items()}
            actual_raw = func(**kwargs)
            actual = serialize_value(actual_raw, framework)
            passed = compare_outputs(actual, tc["expected"], tc.get("tolerance", 1e-5))
            elapsed_us = (time.perf_counter() - start) * 1_000_000
            results.append({"id": tc["id"], "passed": passed, "actual": actual, "error": "", "runtime_us": round(elapsed_us, 1)})
        except Exception:
            elapsed_us = (time.perf_counter() - start) * 1_000_000
            results.append({"id": tc["id"], "passed": False, "actual": None, "error": traceback.format_exc(), "runtime_us": round(elapsed_us, 1)})

    total_us = (time.perf_counter() - total_start) * 1_000_000
    all_passed = len(results) > 0 and all(r["passed"] for r in results)
    return {"status": "passed" if all_passed else "failed", "test_results": results, "stdout": "", "stderr": "", "runtime_us": round(total_us, 1)}


# Fixed seed used by `_reset_rng_state`. Pick anything; the value just needs
# to be the same across requests so consecutive submits with identical code
# produce identical results.
_TASK_SEED = 1234


def _reset_rng_state(framework):
    """Reset numpy/torch/jax random state to a known seed before each task.

    Without this, consecutive submits handled by the same warm worker
    inherit RNG state from each other (since `maxtasksperchild=8`). Per-call
    reset makes every submit start from the same global state — both for
    correctness (the test-case expected outputs were computed with *some*
    state, this gives us a predictable one) and for reproducibility.

    User code that calls `torch.manual_seed(...)` etc. takes effect after
    this reset, so explicit per-problem seeds still work.
    """
    try:
        import numpy as np

        np.random.seed(_TASK_SEED)
    except Exception:
        pass

    if framework == "pytorch":
        try:
            import torch

            torch.manual_seed(_TASK_SEED)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(_TASK_SEED)
        except Exception:
            pass


def run_tests_with_code(code, framework, function_name, test_cases):
    """Import the user's code from a string, run tests, return result dict.
    Used by the worker pool — keeps the pool worker stateless across requests
    by exec-ing into a fresh namespace each call."""
    _reset_rng_state(framework)

    try:
        namespace = {}
        exec(code, namespace)
    except Exception:
        return {"status": "error", "test_results": [], "stdout": "", "stderr": traceback.format_exc(), "runtime_us": 0}

    return _run_tests_in_namespace(namespace, framework, function_name, test_cases)


def run_tests(framework, function_name, test_cases):
    """Script-mode entrypoint: imports `solution.py` from the cwd."""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("solution", "solution.py")
        solution = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(solution)
    except Exception:
        return {"status": "error", "test_results": [], "stdout": "", "stderr": traceback.format_exc(), "runtime_us": 0}

    return _run_tests_in_namespace(solution.__dict__, framework, function_name, test_cases)


if __name__ == "__main__":
    framework = sys.argv[1]
    function_name = sys.argv[2]
    test_cases = json.loads(sys.argv[3])
    result = run_tests(framework, function_name, test_cases)
    print(json.dumps(result))
