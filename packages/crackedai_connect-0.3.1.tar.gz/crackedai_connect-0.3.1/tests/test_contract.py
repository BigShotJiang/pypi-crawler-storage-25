"""Tests for the wire-protocol validator. These tests are the executable form
of docs/CONTRACT.md — if this file's expectations diverge from the doc,
something is wrong."""

from crackedai_connect.contract import validate_execute_request


def _valid():
    return {
        "code": "def f(): pass",
        "framework": "pytorch",
        "function_name": "f",
        "test_cases": [{"id": "t1", "inputs": {"x": 1}, "expected": 1}],
    }


def test_valid_request_returns_none():
    assert validate_execute_request(_valid()) is None


def test_optional_fields_accepted():
    req = _valid()
    req["timeout_ms"] = 5000
    req["benchmark"] = True
    req["reference_code"] = "def f(): return 1"
    assert validate_execute_request(req) is None


def test_reference_code_may_be_null():
    req = _valid()
    req["reference_code"] = None
    assert validate_execute_request(req) is None


def test_rejects_non_dict_body():
    assert validate_execute_request("not an object") is not None
    assert validate_execute_request(None) is not None
    assert validate_execute_request([]) is not None


def test_rejects_missing_required_fields():
    for field in ("code", "framework", "function_name", "test_cases"):
        req = _valid()
        del req[field]
        err = validate_execute_request(req)
        assert err and field in err


def test_rejects_invalid_framework():
    req = _valid()
    req["framework"] = "tensorflow"
    err = validate_execute_request(req)
    assert err and "framework" in err


def test_rejects_empty_function_name():
    req = _valid()
    req["function_name"] = ""
    assert validate_execute_request(req) is not None


def test_rejects_non_list_test_cases():
    req = _valid()
    req["test_cases"] = {"not": "a list"}
    assert validate_execute_request(req) is not None


def test_rejects_test_case_missing_id():
    req = _valid()
    del req["test_cases"][0]["id"]
    err = validate_execute_request(req)
    assert err and "id" in err


def test_rejects_test_case_with_non_dict_inputs():
    req = _valid()
    req["test_cases"][0]["inputs"] = "not an object"
    assert validate_execute_request(req) is not None


def test_rejects_negative_timeout():
    req = _valid()
    req["timeout_ms"] = -1
    assert validate_execute_request(req) is not None


def test_rejects_oversized_timeout():
    req = _valid()
    req["timeout_ms"] = 10_000_000
    assert validate_execute_request(req) is not None


def test_rejects_non_bool_benchmark():
    req = _valid()
    req["benchmark"] = "yes"
    assert validate_execute_request(req) is not None
