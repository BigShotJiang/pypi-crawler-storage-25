from crackedai_connect.detect import detect_environment


def test_detect_returns_required_keys():
    info = detect_environment()
    assert "hardware" in info
    assert "frameworks" in info
    assert "python" in info
    assert info["hardware"]["platform"] in ("Darwin", "Linux", "Windows")


def test_detect_numpy_available():
    info = detect_environment()
    assert info["frameworks"]["numpy"]["available"] is True
    assert "version" in info["frameworks"]["numpy"]


def test_detect_hardware_has_device():
    info = detect_environment()
    assert info["hardware"]["device"] in ("cuda", "mps", "cpu")
