from crackedai_connect.setup import (
    _is_installed,
    _is_apple_silicon,
    _detect_cuda_version,
    _parse_cuda_version,
    _torch_cuda_tag,
)


def test_is_installed_with_known_package():
    assert _is_installed("json") is True


def test_is_installed_with_missing_package():
    assert _is_installed("nonexistent_package_xyz") is False


def test_parse_cuda_version():
    assert _parse_cuda_version("12.4") == (12, 4)
    assert _parse_cuda_version("11.8") == (11, 8)
    assert _parse_cuda_version("13.0") == (13, 0)
    assert _parse_cuda_version("12") == (12, 0)


def test_torch_cuda_tag_mapping():
    # CUDA 11.x -> cu118
    assert _torch_cuda_tag("11.8") == "cu118"
    assert _torch_cuda_tag("11.7") == "cu118"

    # CUDA 12.0-12.3 -> cu121
    assert _torch_cuda_tag("12.0") == "cu121"
    assert _torch_cuda_tag("12.1") == "cu121"
    assert _torch_cuda_tag("12.3") == "cu121"

    # CUDA 12.4-12.5 -> cu124
    assert _torch_cuda_tag("12.4") == "cu124"
    assert _torch_cuda_tag("12.5") == "cu124"

    # CUDA 12.6+ -> cu126
    assert _torch_cuda_tag("12.6") == "cu126"
    assert _torch_cuda_tag("12.8") == "cu126"

    # CUDA 13+ -> cu126 (latest available)
    assert _torch_cuda_tag("13.0") == "cu126"


def test_is_apple_silicon_returns_bool():
    result = _is_apple_silicon()
    assert isinstance(result, bool)


def test_detect_cuda_returns_string_or_none():
    result = _detect_cuda_version()
    assert result is None or isinstance(result, str)
