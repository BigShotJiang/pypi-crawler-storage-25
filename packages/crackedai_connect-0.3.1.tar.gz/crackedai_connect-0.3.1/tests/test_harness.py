import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run_harness(code, framework, function_name, test_cases):
    """Helper: write code + harness to temp dir, run, parse output."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        (tmpdir / "solution.py").write_text(code)

        import crackedai_connect.harness as h
        harness_source = Path(h.__file__).read_text()
        (tmpdir / "run_tests.py").write_text(harness_source)

        result = subprocess.run(
            [sys.executable, str(tmpdir / "run_tests.py"), framework, function_name, json.dumps(test_cases)],
            capture_output=True, text=True, timeout=10, cwd=str(tmpdir),
        )
        if result.returncode != 0 and not result.stdout.strip():
            return {"status": "error", "stderr": result.stderr}
        return json.loads(result.stdout)


def test_harness_correct_pytorch_solution():
    code = """
import torch

def softmax(x):
    e = torch.exp(x - torch.max(x))
    return e / torch.sum(e)
"""
    test_cases = [{"id": "t1", "inputs": {"x": {"shape": [3], "values": [1.0, 2.0, 3.0]}},
                   "expected": {"shape": [3], "values": [0.0900306, 0.2447285, 0.6652409]}, "tolerance": 1e-4}]
    result = run_harness(code, "pytorch", "softmax", test_cases)
    assert result["status"] == "passed"
    assert result["test_results"][0]["passed"] is True


def test_harness_wrong_answer():
    code = """
import torch

def softmax(x):
    return torch.zeros_like(x)
"""
    test_cases = [{"id": "t1", "inputs": {"x": {"shape": [3], "values": [1.0, 2.0, 3.0]}},
                   "expected": {"shape": [3], "values": [0.0900306, 0.2447285, 0.6652409]}, "tolerance": 1e-4}]
    result = run_harness(code, "pytorch", "softmax", test_cases)
    assert result["status"] == "failed"
    assert result["test_results"][0]["passed"] is False


def test_harness_syntax_error():
    code = "def softmax(x)\n    return x"  # missing colon
    test_cases = [{"id": "t1", "inputs": {"x": {"shape": [3], "values": [1.0, 2.0, 3.0]}},
                   "expected": {"shape": [3], "values": [0.09, 0.24, 0.67]}, "tolerance": 1e-4}]
    result = run_harness(code, "pytorch", "softmax", test_cases)
    assert result["status"] == "error"


def test_harness_scalar_output():
    code = """
def add(a, b):
    return a + b
"""
    test_cases = [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5, "tolerance": 1e-5}]
    result = run_harness(code, "pytorch", "add", test_cases)
    assert result["status"] == "passed"
    assert result["test_results"][0]["passed"] is True
