import pytest
from crackedai_connect import __version__
from crackedai_connect.pool import shutdown_pool
from crackedai_connect.server import create_app


# Use a fixed token for tests so we can construct headers without first
# round-tripping /health on every request.
_TEST_TOKEN = "test-token-do-not-use-in-prod"


@pytest.fixture
def app():
    app = create_app(auth_token=_TEST_TOKEN)
    app.config["TESTING"] = True
    yield app


@pytest.fixture
def client(app):
    with app.test_client() as c:
        yield c


@pytest.fixture(autouse=True, scope="module")
def _teardown_pool():
    yield
    shutdown_pool()


def _auth_headers():
    return {"X-CrackedAI-Token": _TEST_TOKEN}


def test_health_returns_ok(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"
    assert "hardware" in data
    assert "frameworks" in data
    assert "python" in data


def test_health_has_version(client):
    resp = client.get("/health")
    data = resp.get_json()
    assert data["version"] == __version__


def test_health_exposes_auth_token(client):
    resp = client.get("/health")
    data = resp.get_json()
    assert data["auth_token"] == _TEST_TOKEN


def test_execute_correct_solution(client):
    resp = client.post(
        "/execute",
        headers=_auth_headers(),
        json={
            "code": "def add(a, b):\n    return a + b",
            "framework": "pytorch",
            "function_name": "add",
            "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5, "tolerance": 1e-5}],
            "timeout_ms": 5000,
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "passed"
    assert data["test_results"][0]["passed"] is True


def test_execute_wrong_answer(client):
    resp = client.post(
        "/execute",
        headers=_auth_headers(),
        json={
            "code": "def add(a, b):\n    return 0",
            "framework": "pytorch",
            "function_name": "add",
            "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5, "tolerance": 1e-5}],
            "timeout_ms": 5000,
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "failed"


def test_execute_missing_fields(client):
    resp = client.post("/execute", headers=_auth_headers(), json={"code": "pass"})
    assert resp.status_code == 400


def test_execute_rejects_request_without_token(client):
    resp = client.post(
        "/execute",
        json={
            "code": "def add(a, b):\n    return a + b",
            "framework": "pytorch",
            "function_name": "add",
            "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5}],
        },
    )
    assert resp.status_code == 401


def test_execute_rejects_request_with_wrong_token(client):
    resp = client.post(
        "/execute",
        headers={"X-CrackedAI-Token": "nope"},
        json={
            "code": "def add(a, b):\n    return a + b",
            "framework": "pytorch",
            "function_name": "add",
            "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5}],
        },
    )
    assert resp.status_code == 401


def test_health_does_not_require_token(client):
    resp = client.get("/health")
    assert resp.status_code == 200


def test_cors_localhost_allowed(client):
    resp = client.get("/health", headers={"Origin": "http://localhost:4000"})
    assert resp.status_code == 200
    assert resp.headers.get("Access-Control-Allow-Origin") is not None


# --- data_ref tensor caching ---


def _scalar_tc(id_, a, b, expected):
    return {"id": id_, "inputs": {"a": a, "b": b}, "expected": expected, "tolerance": 1e-5}


def test_execute_response_includes_cached_refs_when_data_present(client):
    import base64
    raw = (1.0).to_bytes(4, "little") if False else b"\x00\x00\x80?"  # float32 1.0
    tensor = {"shape": [1], "dtype": "float32", "data": base64.b64encode(raw).decode("ascii")}

    resp = client.post(
        "/execute",
        headers=_auth_headers(),
        json={
            "code": "def add(a, b):\n    return a + b",
            "framework": "pytorch",
            "function_name": "add",
            "test_cases": [{"id": "t1", "inputs": {"a": 1, "b": 2}, "expected": 3, "tolerance": 1e-5}],
        },
    )
    # Plain scalar test case has no tensors → no cached_refs key.
    data = resp.get_json()
    assert "cached_refs" not in data
    # But this proves the wiring doesn't break the scalar path.
    assert resp.status_code == 200


def test_data_ref_cache_miss_returns_422_with_missing_ref(client):
    resp = client.post(
        "/execute",
        headers=_auth_headers(),
        json={
            "code": "def f(x):\n    return x",
            "framework": "pytorch",
            "function_name": "f",
            "test_cases": [
                {
                    "id": "t1",
                    "inputs": {"x": {"shape": [3], "dtype": "float32", "data_ref": "deadbeef"}},
                    "expected": 0,
                }
            ],
        },
    )
    assert resp.status_code == 422
    data = resp.get_json()
    assert data["missing_refs"] == ["deadbeef"]


def test_data_substitution_round_trip(client):
    """Send a tensor as data, get the hash back in cached_refs, then resend
    using data_ref and verify the cached payload was used."""
    import base64
    # float32 tensor [1.0, 2.0, 3.0]
    raw = b"\x00\x00\x80?\x00\x00\x00@\x00\x00@@"
    tensor_full = {"shape": [3], "dtype": "float32", "data": base64.b64encode(raw).decode("ascii")}

    # Function returns a Python int so we can compare with an int expected — this
    # keeps the test focused on the data_ref roundtrip rather than tensor
    # comparison semantics.
    code = "def f(x):\n    return int(float(x[0]) + float(x[1]) + float(x[2]))"
    test_cases = [{"id": "t1", "inputs": {"x": tensor_full}, "expected": 6, "tolerance": 1e-3}]

    resp = client.post(
        "/execute",
        headers=_auth_headers(),
        json={"code": code, "framework": "pytorch", "function_name": "f", "test_cases": test_cases},
    )
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["status"] == "passed", body
    assert "cached_refs" in body
    refs = body["cached_refs"]
    assert len(refs) == 1
    cached_hash = refs[0]

    # Now resend by reference only — substitution should give identical behavior.
    tensor_ref = {"shape": [3], "dtype": "float32", "data_ref": cached_hash}
    test_cases = [{"id": "t1", "inputs": {"x": tensor_ref}, "expected": 6, "tolerance": 1e-3}]

    resp2 = client.post(
        "/execute",
        headers=_auth_headers(),
        json={"code": code, "framework": "pytorch", "function_name": "f", "test_cases": test_cases},
    )
    assert resp2.status_code == 200
    assert resp2.get_json()["status"] == "passed"
