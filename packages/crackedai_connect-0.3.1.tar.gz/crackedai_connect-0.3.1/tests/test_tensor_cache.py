"""Direct unit tests for TensorCache. End-to-end caching behavior is tested
via test_server.py (which exercises the /execute integration)."""

import os

from crackedai_connect.tensor_cache import TensorCache


def test_put_returns_sha256_hex():
    cache = TensorCache()
    h = cache.put(b"hello world")
    # sha256("hello world")
    assert h == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"


def test_get_returns_bytes_after_put():
    cache = TensorCache()
    h = cache.put(b"some bytes")
    assert cache.get(h) == b"some bytes"


def test_get_returns_none_on_miss():
    cache = TensorCache()
    assert cache.get("nonexistent") is None


def test_put_is_idempotent():
    cache = TensorCache()
    h1 = cache.put(b"x")
    h2 = cache.put(b"x")
    assert h1 == h2


def test_eviction_evicts_oldest():
    cache = TensorCache(max_entries=3)
    h1 = cache.put(b"a")
    h2 = cache.put(b"b")
    h3 = cache.put(b"c")
    cache.put(b"d")  # evicts h1
    assert cache.get(h1) is None
    assert cache.get(h2) == b"b"
    assert cache.get(h3) == b"c"


def test_get_is_lru_promoting():
    cache = TensorCache(max_entries=3)
    h1 = cache.put(b"a")
    h2 = cache.put(b"b")
    h3 = cache.put(b"c")
    # Touch h1, then add a new entry. h2 should evict (oldest), not h1.
    cache.get(h1)
    cache.put(b"d")
    assert cache.get(h1) == b"a"
    assert cache.get(h2) is None
    assert cache.get(h3) == b"c"


def test_clear_drops_everything():
    cache = TensorCache()
    h = cache.put(b"x")
    cache.clear()
    assert cache.get(h) is None
