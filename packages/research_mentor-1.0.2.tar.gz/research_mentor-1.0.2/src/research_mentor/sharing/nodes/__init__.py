"""Sharing & Publication graph nodes."""
