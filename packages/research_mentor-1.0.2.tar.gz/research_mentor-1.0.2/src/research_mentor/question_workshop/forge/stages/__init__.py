"""Forge Workshop pipeline stages."""
