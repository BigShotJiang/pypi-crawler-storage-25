from __future__ import annotations

from enum import StrEnum
from typing import cast

from pydantic import BaseModel, Field, field_validator

from anusara._aggregation.mode import AggregationMode
from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.graph_definition import GraphDefinition
from anusara._contracts.json_types import JSONValue
from anusara._core.execution_policy import ExecutionPolicy, FailureMode
from anusara._runtime.retry_policy import RetryPolicy

# ---------------------------------------------------------
# Enums
# ---------------------------------------------------------


class FailureModeEnum(StrEnum):
    FAIL_FAST = "FAIL_FAST"
    CONTINUE = "CONTINUE"


class AggregationModeEnum(StrEnum):
    LATEST_ONLY = "LATEST_ONLY"
    STRICT_ATTEMPT = "STRICT_ATTEMPT"
    SUCCESS_ONLY = "SUCCESS_ONLY"
    ALL_ATTEMPTS = "ALL_ATTEMPTS"
    EXCLUDE_FORCED = "EXCLUDE_FORCED"


# ---------------------------------------------------------
# Health
# ---------------------------------------------------------


class HealthResponse(BaseModel):
    status: str
    service: str
    architecture: str
    version: str


# ---------------------------------------------------------
# Graph
# ---------------------------------------------------------


class NodeDefinitionSchema(BaseModel):
    id: str
    agent: str | None = None
    metadata: dict[str, object] = Field(default_factory=dict)


class GraphDefinitionSchema(BaseModel):
    nodes: list[NodeDefinitionSchema] = Field(default_factory=list)
    edges: list[tuple[str, str]] = Field(default_factory=list)


# ---------------------------------------------------------
# Policy
# ---------------------------------------------------------


class RetryPolicySchema(BaseModel):
    max_attempts: int = Field(default=1, ge=1)
    base_delay_ms: int = Field(default=100, ge=0)
    max_delay_ms: int = Field(default=2000, ge=0)
    jitter: bool = True


class ExecutionPolicySchema(BaseModel):
    failure_mode: FailureModeEnum = FailureModeEnum.FAIL_FAST
    aggregation_mode: AggregationModeEnum = AggregationModeEnum.LATEST_ONLY
    retry_policy: RetryPolicySchema = Field(default_factory=RetryPolicySchema)
    max_hops: int | None = Field(default=None, ge=1)
    max_concurrency: int | None = Field(default=None, ge=1)


# ---------------------------------------------------------
# JSON Validation Helper (deep-safe)
# ---------------------------------------------------------


def _is_valid_json(value: object) -> bool:
    if value is None:
        return True
    if isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(_is_valid_json(v) for v in value)
    if isinstance(value, dict):
        return all(isinstance(k, str) and _is_valid_json(v) for k, v in value.items())
    return False


# ---------------------------------------------------------
# Scenario
# ---------------------------------------------------------


class ExecutionScenarioSchema(BaseModel):
    name: str = Field(default="default")
    flags: dict[str, bool] = Field(default_factory=dict)
    parameters: dict[str, object] = Field(default_factory=dict)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("scenario.name must not be empty")
        return value

    @field_validator("parameters")
    @classmethod
    def validate_parameters(cls, value: dict[str, object]) -> dict[str, object]:
        for k, v in value.items():
            if not isinstance(k, str):
                raise ValueError("scenario.parameters keys must be strings")
            if not _is_valid_json(v):
                raise ValueError(f"Invalid JSON value for key '{k}'")
        return value


# ---------------------------------------------------------
# Execute Request
# ---------------------------------------------------------


class ExecuteRequest(BaseModel):
    entry_nodes: list[str]
    graph_definition: GraphDefinitionSchema | None = None
    payload: dict[str, object] = Field(default_factory=dict)
    metadata: dict[str, object] = Field(default_factory=dict)
    policy: ExecutionPolicySchema = Field(default_factory=ExecutionPolicySchema)
    scenario: ExecutionScenarioSchema | None = None

    # -----------------------------------------------------
    # Validation
    # -----------------------------------------------------

    @field_validator("entry_nodes")
    @classmethod
    def validate_entry_nodes(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("entry_nodes must contain at least one node.")
        return value

    @field_validator("payload", "metadata")
    @classmethod
    def validate_json_fields(cls, value: dict[str, object]) -> dict[str, object]:
        for k, v in value.items():
            if not isinstance(k, str):
                raise ValueError("Keys must be strings")
            if not _is_valid_json(v):
                raise ValueError(f"Invalid JSON value for key '{k}'")
        return value

    # -----------------------------------------------------
    # Conversion
    # -----------------------------------------------------

    def to_execution_request(self, request_id: str) -> ExecutionRequest:

        failure_mode = FailureMode[self.policy.failure_mode.name]
        aggregation_mode = AggregationMode(self.policy.aggregation_mode.value.lower())

        retry_policy = RetryPolicy(
            max_attempts=self.policy.retry_policy.max_attempts,
            base_delay=self.policy.retry_policy.base_delay_ms / 1000.0,
            max_delay=self.policy.retry_policy.max_delay_ms / 1000.0,
            jitter=self.policy.retry_policy.jitter,
        )

        execution_policy = ExecutionPolicy(
            failure_mode=failure_mode,
            retry_policy=retry_policy,
            aggregation_mode=aggregation_mode,
            max_hops=self.policy.max_hops,
            max_concurrency=self.policy.max_concurrency,
        )

        graph_def: GraphDefinition | None = None

        if self.graph_definition is not None:
            graph_def = cast(
                GraphDefinition,
                {
                    "nodes": [
                        {
                            "id": node.id,
                            "agent": node.agent,
                            "metadata": node.metadata,
                        }
                        for node in self.graph_definition.nodes
                    ],
                    "edges": self.graph_definition.edges,
                },
            )

        scenario_obj = (
            ExecutionScenario(
                name=self.scenario.name,
                flags=self.scenario.flags,
                parameters=cast(dict[str, JSONValue], self.scenario.parameters),
            )
            if self.scenario is not None
            else ExecutionScenario(name="default")
        )

        return ExecutionRequest(
            request_id=request_id,
            entry_nodes=self.entry_nodes,
            graph_definition=graph_def,
            payload=cast(dict[str, JSONValue], self.payload),
            metadata=cast(dict[str, JSONValue], self.metadata),
            policy=execution_policy,
            scenario=scenario_obj,
        )


# ---------------------------------------------------------
# Agent Registration
# ---------------------------------------------------------


class PythonImportAgentSourceSchema(BaseModel):
    module: str
    symbol: str


class ExternalAgentRegistrationRequest(BaseModel):
    agent_id: str
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool = False
    source: PythonImportAgentSourceSchema


class ExternalAgentRegistrationResponse(BaseModel):
    agent_id: str
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool
    source_kind: str
    source_ref: str
    factory_type: str
