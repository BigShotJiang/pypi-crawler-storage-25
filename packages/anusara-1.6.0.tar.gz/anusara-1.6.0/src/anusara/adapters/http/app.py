from __future__ import annotations

import asyncio
import uuid
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from typing import Any, cast

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel

from anusara._builtin.agents.echo_agent import EchoAgent
from anusara._builtin.agents.hello_agent import HelloAgent
from anusara._core.execution_engine import ExecutionEngine
from anusara._core.execution_status import ExecutionStatus
from anusara._introspection.serialization import (
    ExecutionSnapshotSerializer,
)
from anusara._registry.agent_registry import AgentRegistry
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.sources.python_import_source import PythonImportAgentSource
from anusara._runtime.config import RuntimeConfig
from anusara.adapters.http.runtime import (
    RuntimeContainer,
    get_container,
    get_engine,
    get_registry,
    initialize_runtime,
)
from anusara.adapters.http.schemas import (
    ExecuteRequest,
    ExternalAgentRegistrationRequest,
    ExternalAgentRegistrationResponse,
    HealthResponse,
)
from anusara.adapters.http.utils import default_root
from anusara.api.helper import JSONValue


class AgentRegisterRequest(BaseModel):
    name: str


def get_package_version() -> str:
    try:
        return pkg_version("anusara")
    except PackageNotFoundError:
        # fallback for local/dev runs
        return "0.0.0-dev"


def create_app(
    *,
    event_log_path: str = "events.jsonl",
    async_mode: bool = True,
    title: str = "Anusara Service",
    version: str | None = None,
    container: RuntimeContainer | None = None,
) -> FastAPI:
    """
    Create and configure the HTTP application.
    """

    if version is None:
        version = get_package_version()

    if container is None:
        initialize_runtime(RuntimeConfig.from_env())
        container = get_container()

    # Register built-in agents here
    register_builtin_agents(container)

    app = FastAPI(title=title, version=version)
    app.state.async_mode = async_mode

    # 🔥 Bind container to this app instance
    def _get_engine_override() -> ExecutionEngine:
        return container.engine

    def _get_registry_override() -> AgentRegistry:
        return container.registry

    def _get_container_override() -> RuntimeContainer:
        return container

    app.dependency_overrides[get_engine] = _get_engine_override
    app.dependency_overrides[get_registry] = _get_registry_override
    app.dependency_overrides[get_container] = _get_container_override

    # ---------------------------------------------------------
    # Root
    # ---------------------------------------------------------
    @app.get("/")
    async def root() -> dict[str, str]:
        return default_root(
            service="anusara",
            version=version,
            architecture="event-driven-mesh",
        )

    # ---------------------------------------------------------
    # Health
    # ---------------------------------------------------------
    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(
            status="ok",
            service="anusara",
            architecture="event-driven-mesh",
            version=version,
        )

    # ---------------------------------------------------------
    # Execute
    # ---------------------------------------------------------
    @app.post("/executions", status_code=status.HTTP_202_ACCEPTED)
    async def execute(
        request: ExecuteRequest,
        http_request: Request,
        engine: ExecutionEngine = Depends(get_engine),
        registry: AgentRegistry = Depends(get_registry),
    ) -> dict[str, str]:

        request_id = str(uuid.uuid4())
        execution_request = request.to_execution_request(request_id)

        try:
            graph = engine.compile(execution_request)

            for node in graph.nodes.values():
                if node.agent and not registry.exists(node.agent):
                    raise HTTPException(
                        status_code=400,
                        detail={
                            "error": f"Agent '{node.agent}' is not registered",
                            "available": registry.list(),
                        },
                    )
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        if http_request.app.state.async_mode:
            asyncio.create_task(engine.execute(execution_request, registry))
        else:
            await engine.execute(execution_request, registry)

        return {
            "request_id": request_id,
            "status": "ACCEPTED",
        }

    # ---------------------------------------------------------
    # Architecture
    # ---------------------------------------------------------
    @app.get("/architecture")
    async def architecture() -> dict[str, JSONValue]:
        return {
            "architecture": "event-driven-mesh",
            "components": [
                "execution-engine",
                "event-log",
                "graph-compiler",
                "agent-registry",
                "mutation-engine",
            ],
        }

    # ---------------------------------------------------------
    # Status
    # ---------------------------------------------------------
    @app.get("/executions/{request_id}")
    async def get_status(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, str]:

        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        return {
            "request_id": request_id,
            "status": status_value.name,
        }

    # ---------------------------------------------------------
    # Snapshot
    # ---------------------------------------------------------
    @app.get("/executions/{request_id}/snapshot")
    async def get_snapshot(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, Any]:
        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        try:
            snapshot = engine.get_snapshot(request_id)

            data = ExecutionSnapshotSerializer.snapshot_to_dict(snapshot)

            return cast(dict[str, Any], jsonable_encoder(data))

        except Exception:
            # Return EMPTY SNAPSHOT SHAPE (important)
            return {
                "request_id": request_id,
                "started_at": None,
                "completed_at": None,
                "overall_success": False,
                "confidence": 0.0,
                "records": {},
            }

    # ---------------------------------------------------------
    # Register Agents
    # ---------------------------------------------------------
    @app.post("/agents/register")
    async def register_agent(
        body: AgentRegisterRequest,
    ) -> dict[str, object]:
        try:
            container = get_container()
            container.create_and_register(body.name)

        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        except RuntimeError as e:
            raise HTTPException(
                status_code=500,
                detail="Runtime not initialized",
            ) from e

        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=str(e),
            ) from e

        return {
            "status": "success",
            "data": {
                "agent": body.name,
            },
        }

    @app.post(
        "/agents/register/external",
        response_model=ExternalAgentRegistrationResponse,
    )
    async def register_external_agent(
        body: ExternalAgentRegistrationRequest,
        registry: AgentRegistry = Depends(get_registry),
    ) -> ExternalAgentRegistrationResponse:
        try:
            spec = AgentRegistrationSpec(
                agent_id=body.agent_id,
                namespace=body.namespace,
                version=body.version,
                is_builtin=body.is_builtin,
                source=PythonImportAgentSource(
                    module=body.source.module,
                    symbol=body.source.symbol,
                ),
            )

            registry.register_spec(spec)
            metadata = registry.metadata(body.agent_id)

            namespace_value = metadata["namespace"] or None
            version_value = metadata["version"] or None
            is_builtin_value = metadata["is_builtin"] == "True"

            return ExternalAgentRegistrationResponse(
                agent_id=metadata["agent_id"],
                namespace=namespace_value,
                version=version_value,
                is_builtin=is_builtin_value,
                source_kind=metadata["source_kind"],
                source_ref=metadata["source_ref"],
                factory_type=metadata["factory_type"],
            )

        except KeyError as e:
            raise HTTPException(status_code=409, detail=str(e)) from e

        except (ValueError, ImportError, AttributeError, TypeError) as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

    @app.get("/agents")
    async def list_agents(
        registry: AgentRegistry = Depends(get_registry),
    ) -> dict[str, object]:
        try:
            registered = registry.list()

        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail="Failed to retrieve registered agents",
            ) from e

        return {
            "status": "success",
            "data": {
                "registered": registered,
            },
        }

    @app.get("/agents/available")
    async def list_available_agents(
        container: RuntimeContainer = Depends(get_container),
    ) -> dict[str, object]:
        try:
            available = container.list_factories()

        except RuntimeError as e:
            # Runtime not initialized (shouldn't happen, but protect anyway)
            raise HTTPException(
                status_code=500,
                detail="Runtime not initialized",
            ) from e

        except Exception as e:
            # Unexpected failure
            raise HTTPException(
                status_code=500,
                detail="Failed to retrieve available agents",
            ) from e

        return {
            "status": "success",
            "data": {
                "available": available,
            },
        }

    return app


def register_builtin_agents(container: RuntimeContainer) -> None:
    factories = set(container.list_factories())

    if "echo" not in factories:
        container.register_factory("echo", lambda: EchoAgent())

    if "hello" not in factories:
        container.register_factory("hello", lambda: HelloAgent())
