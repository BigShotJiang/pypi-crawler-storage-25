from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .network import CloudCourier
from .parser import CISTParser, ValidationError

load_dotenv()

# On Windows, pip --user installs scripts to a folder not on PATH by default.
# Detect this and print a one-time actionable fix before the user hits a
# confusing "not recognized" error (they'd have to be running via python -m to
# even reach this point, so we can give them instructions to fix it properly).
def _warn_windows_path() -> None:
    if sys.platform != "win32":
        return
    scripts_dir = Path(os.environ.get("APPDATA", "")) / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts"
    if not scripts_dir.exists():
        return
    path_dirs = [Path(p) for p in os.environ.get("PATH", "").split(os.pathsep)]
    if scripts_dir not in path_dirs:
        _console = Console(stderr=True)
        _console.print(
            f"\n[yellow bold]Windows PATH notice:[/yellow bold] "
            f"[cyan]{scripts_dir}[/cyan] is not on your PATH.\n"
            f"Run this once in PowerShell to fix it permanently, then reopen your terminal:\n\n"
            f'  [bold][Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";{scripts_dir}", "User")[/bold]\n'
        )

_warn_windows_path()

# 1. ADDED: Antigravity paths alongside VS Code paths
_EDITOR_CANDIDATES: dict[str, list[str]] = {
    "darwin": [
        "/Applications/Antigravity.app/Contents/Resources/app/bin/antigravity",
        str(Path.home() / "Applications/Antigravity.app/Contents/Resources/app/bin/antigravity"),
        "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code",
        str(Path.home() / "Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"),
    ],
    "win32": [
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Antigravity/bin/antigravity.cmd"),
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Microsoft VS Code/bin/code.cmd"),
        str(Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft VS Code/bin/code.cmd"),
    ],
    "linux": [
        "/usr/bin/antigravity",
        "/usr/local/bin/antigravity",
        "/usr/bin/code",
        "/snap/bin/code",
        "/usr/local/bin/code",
        str(Path.home() / ".local/bin/code"),
    ],
}

def _find_editor() -> str | None:
    """Return the Antigravity or VS Code executable path, or None if not found."""
    # 2. ADDED: Check for Antigravity binaries first
    found = (
        shutil.which("antigravity") 
        or shutil.which("agy") 
        or shutil.which("code") 
        or shutil.which("code-insiders")
    )
    if found:
        return found
    platform = sys.platform if sys.platform in _EDITOR_CANDIDATES else "linux"
    for candidate in _EDITOR_CANDIDATES[platform]:
        if candidate and Path(candidate).exists():
            return candidate
    return None

# Extension IDs that used invalid publisher names (spaces) — must be evicted
# before the corrected extension can take their place.
_LEGACY_EXTENSION_IDS: list[str] = [
    "tooig research lab.cist",
]

def _extension_install_roots(editor_exe: str | None) -> list[Path]:
    configured_root = os.environ.get("VSCODE_EXTENSIONS", "").strip()
    user_home = Path(os.environ.get("USERPROFILE") or str(Path.home()))

    roots: list[Path] = []
    if configured_root:
        roots.append(Path(configured_root))

    exe_name = Path(editor_exe).name.lower() if editor_exe else ""
    prefers_antigravity = "antigravity" in exe_name or "agy" in exe_name
    prefers_insiders = "insiders" in exe_name

    # 3. ADDED: Antigravity's hidden extension folder
    antigravity_root = user_home / ".antigravity" / "extensions"
    stable_root = user_home / ".vscode" / "extensions"
    insiders_root = user_home / ".vscode-insiders" / "extensions"

    if prefers_antigravity:
        roots.extend([antigravity_root, stable_root, insiders_root])
    elif prefers_insiders:
        roots.extend([insiders_root, antigravity_root, stable_root])
    else:
        roots.extend([stable_root, antigravity_root, insiders_root])

    unique_roots: list[Path] = []
    seen: set[Path] = set()
    for root in roots:
        if root in seen:
            continue
        seen.add(root)
        unique_roots.append(root)
    return unique_roots

def _read_vsix_package(vsix: Path) -> dict[str, str]:
    with zipfile.ZipFile(vsix) as archive:
        with archive.open("extension/package.json") as package_file:
            package = json.load(package_file)

    return {
        "publisher": str(package["publisher"]),
        "name": str(package["name"]),
        "version": str(package["version"]),
    }

def _remove_extension_dirs(root: Path, prefixes: list[str]) -> None:
    if not root.is_dir():
        return

    for entry in root.iterdir():
        if not entry.is_dir():
            continue

        name_lower = entry.name.lower()
        if any(name_lower.startswith(prefix.lower()) for prefix in prefixes):
            try:
                shutil.rmtree(entry)
            except OSError:
                pass

def _extract_vsix_extension(vsix: Path, target_dir: Path) -> None:
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(vsix) as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.startswith("extension/"):
                continue

            relative_name = member.filename[len("extension/") :]
            if not relative_name:
                continue

            destination = target_dir / relative_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)

def _remove_legacy_extensions(editor_exe: str | None) -> None:
    """Uninstall old CIST extension versions that had spaces in the publisher name."""
    if editor_exe:
        for ext_id in _LEGACY_EXTENSION_IDS:
            subprocess.run(
                [editor_exe, "--uninstall-extension", ext_id],
                capture_output=True,
                text=True,
            )

    prefixes = [f"{ext_id.lower()}-" for ext_id in _LEGACY_EXTENSION_IDS]
    for root in _extension_install_roots(editor_exe):
        _remove_extension_dirs(root, prefixes)

def _latest_bundled_vsix() -> Path | None:
    assets_dir = Path(__file__).parent / "assets"
    vsix_files = sorted(assets_dir.glob("*.vsix"))
    if not vsix_files:
        return None
    return vsix_files[-1]

def _install_vscode_extension(editor_exe: str | None, vsix: Path) -> tuple[bool, str]:
    """Install the bundled CIST VS Code extension by extracting it to the extension directory."""
    try:
        package = _read_vsix_package(vsix)
    except (KeyError, OSError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        return False, f"Could not read VSIX metadata: {exc}"

    extension_id = f"{package['publisher']}.{package['name']}"
    version = package["version"]
    prefixes = [f"{extension_id.lower()}-"]
    install_error: str | None = None
    
    # 4. FIXED: Accumulate installs rather than stopping after the first success
    installed_paths = []

    for root in _extension_install_roots(editor_exe):
        try:
            root.mkdir(parents=True, exist_ok=True)
            _remove_extension_dirs(root, prefixes)

            target_dir = root / f"{extension_id}-{version}"
            _extract_vsix_extension(vsix, target_dir)

            package_json = target_dir / "package.json"
            if package_json.exists():
                installed_paths.append(str(target_dir))
        except (OSError, zipfile.BadZipFile) as exc:
            install_error = str(exc)

    if installed_paths:
        return True, f"Installed to:\n  " + "\n  ".join(installed_paths)

    return False, install_error or "Unable to determine an extensions directory"

def _sync_vscode_extension() -> tuple[bool, str]:
    if os.environ.get("CIST_SKIP_VSCODE_INSTALL") == "1":
        return False, "[dim]Extension install skipped (CIST_SKIP_VSCODE_INSTALL=1)[/dim]"

    editor_exe = _find_editor()
    vsix = _latest_bundled_vsix()
    if vsix is None:
        return False, "[yellow]![/yellow] Bundled extension not found in cist_cli/assets"

    _remove_legacy_extensions(editor_exe)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Installing extension...", total=None)
        ok, install_output = _install_vscode_extension(editor_exe, vsix)

    # 5. FIXED: Dynamic fallback command for error messaging
    exe_display = "antigravity" if editor_exe and ("antigravity" in editor_exe.lower() or "agy" in editor_exe.lower()) else "code"

    if ok:
        lines = [f"[green]✓[/green] Extension synced from [cyan]{vsix.name}[/cyan]"]
        if install_output:
            lines.append(f"  [dim]{install_output}[/dim]")
        lines.append("  [dim]Reload window to activate: Ctrl+Shift+P → Developer: Reload Window[/dim]")
        return True, "\n".join(lines)

    detail = f"\n  [dim]{install_output}[/dim]" if install_output else ""
    return (
        False,
        "[yellow]![/yellow] Extension install failed."
        + detail
        + f"\n  Manual install: [bold]{exe_display} --install-extension \"{vsix}\" --force[/bold]",
    )

EXAMPLE_CONTRACT = """# Example CIST Contract
# Python-like syntax with trading-specific operations

use math
use compute
use risk

# Import market data
market_data := from data (source: "binance", symbols: ["BTC-USD"], resolution: "1h")

# Calculate indicators
sma_fast := math.sma(market_data.close, 10)
sma_slow := math.sma(market_data.close, 30)

# Trading logic
if sma_fast > sma_slow:
    size := risk.calculate_size(portfolio_value: 10000, risk_percent: 2.0)
    execute(market_buy(symbol: "BTC-USD", size: size))
elif sma_fast < sma_slow:
    execute(close_position())
"""

app = typer.Typer(
    name="cist",
    help="Contract Instruction Set",
    no_args_is_help=True,
)
console = Console()


def _resolve_cis_path(filepath: Path) -> Path:
    resolved = filepath.expanduser().resolve()
    if resolved.suffix.lower() != ".cis":
        console.print(f"[red]Error:[/red] Expected .cis file, got {resolved.suffix}")
        raise typer.Exit(1)
    return resolved


def _print_warnings(result: dict[str, Any]) -> None:
    warnings = result.get("warnings", [])
    for warning in warnings:
        console.print(
            f"[yellow]! Line {warning.line}:[/yellow] {warning.message}"
        )


@app.callback()
def callback() -> None:
    """CIST - Contract Instruction Set Toolkit."""


def _init_workspace(path: Path) -> None:
    target = path.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)

    # ── workspace skeleton ────────────────────────────────────────────────────
    contracts_dir = target / "contracts"
    contracts_dir.mkdir(exist_ok=True)

    example_file = contracts_dir / "example.cis"
    if not example_file.exists():
        example_file.write_text(EXAMPLE_CONTRACT, encoding="utf-8")

    env_file = target / ".env"
    if not env_file.exists():
        env_file.write_text(
            "# CIST Cloud API\nCIST_CLOUD_API_KEY=\nCIST_CLOUD_ENDPOINT=https://api.cist.io/v1\n",
            encoding="utf-8",
        )

    # ── VS Code extension install ──────────────────────────────────────────────
    _, vscode_line = _sync_vscode_extension()

    # ── summary ───────────────────────────────────────────────────────────────
    console.print(
        Panel.fit(
            f"[bold green]CIST Ready[/bold green]\n\n"
            f"Workspace:  [cyan]{target}[/cyan]\n"
            f"Contracts:  [cyan]{contracts_dir}[/cyan]\n"
            f"Example:    [cyan]{example_file}[/cyan]\n"
            f"Config:     [cyan]{env_file}[/cyan]\n\n"
            f"{vscode_line}\n\n"
            f"Next steps:\n"
            f"  1. Add your API key to [bold].env[/bold]\n"
            f"  2. Open [bold]{example_file.name}[/bold] and start writing\n"
            f"  3. Run [bold]cist compile <file.cis>[/bold] to build and deploy",
            title=f"cist-kernel v{__version__}",
        )
    )


@app.command()
def init(
    path: Path = typer.Option(
        Path("."),
        "--path",
        "-p",
        file_okay=False,
        help="Target directory",
    ),
) -> None:
    """Initialize a CIST workspace."""
    _init_workspace(path=path)


@app.command("sync-vscode-extension")
def sync_vscode_extension() -> None:
    """Install or update the bundled VS Code extension."""
    ok, message = _sync_vscode_extension()
    console.print(message)
    if not ok:
        raise typer.Exit(1)


@app.command()
def compile(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        "-d",
        help="Deploy to live execution",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Validate locally, then stream the CIST source to the cloud compiler."""
    resolved = _resolve_cis_path(filepath)
    parser = CISTParser()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = parser.validate_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )
    if verbose:
        console.print(f"[dim]  modules  : {ast['modules']}[/dim]")
        console.print(f"[dim]  streams  : {ast['data_streams']}[/dim]")

    console.print("[cyan]Connecting to CIST Cloud...[/cyan]")
    try:
        courier = CloudCourier()
        for event in courier.stream_compile(ast, deploy=deploy):
            event_type = event.get("type")
            if event_type == "log":
                console.print(f"[dim][Cloud][/dim] {event.get('message', '')}")
            elif event_type == "artifact":
                console.print(
                    f"[bold green]ok Compiled:[/bold green] {event.get('artifact_id', 'unknown')}"
                )
            elif event_type == "error":
                console.print(
                    f"[bold red]x Build Error:[/bold red] {event.get('message', '')}"
                )
                raise typer.Exit(1)
            elif event_type == "complete":
                console.print("[green]Compilation complete[/green]")
    except ValueError as exc:
        console.print(f"[bold red]Configuration Error:[/bold red] {exc}")
        raise typer.Exit(1) from exc
    except ConnectionError as exc:
        console.print(f"[bold red]Connection Failed:[/bold red] {exc}")
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    app()