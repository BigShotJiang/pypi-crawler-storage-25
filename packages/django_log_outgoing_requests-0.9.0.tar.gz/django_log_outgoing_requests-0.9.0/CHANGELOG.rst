=========
Changelog
=========

0.9.0 (2026-04-09)
==================

Feature release.

**New features**

* [#2] Added pretty-printing / syntax highlighting to request and response bodies.

0.8.0 (2026-04-08)
==================

Feature release with some breaking changes.

**💥 Breaking changes**

* Dropped support for the end-of-life Django 3.2, 4.1 and 4.2 versions.
* Dropped support for Python versions older than 3.12.

**New features**

* Confirmed Django 5.2 support.
* Confirmed Python 3.12+ support.
* Renamed the log events emitted:

  - ``Outgoing request`` is now ``outgoing_request_response_received``
  - ``Outgoing request error`` is now ``outgoing_request_errored``

* [#48] Add support for structlog:

  - The emitted log events now use ``snake_case`` events.
  - Added an (opt-in) processor in
    ``log_outgoing_requests.structlog.ExtractRequestAndResponseDetails``. See the docs
    for details.

* [#48] Added support for async database logging - see the updated quickstart
  documentation on how to apply this in your project.

**Project maintenance**

* Switched to trusted publishing to PyPI.
* Switched project configuration to ``pyproject.toml``.
* Replaced ``bump2version`` with ``bump-my-version``.
* Cleaned up and simplified CI configuration.
* Replaced black, isort and flake8 with Ruff.
* Github actions usage is now pinned to commit hashes to protect against supply chain
  attacks.
* Removed obsoleted compatibility shims.

0.7.1 (2025-12-09)
==================

Small bugfix release

* Fixed saving logging entries with requests/responses containing text content

0.7.0 (2025-10-30)
==================

* [#13] Enabled JSON/XML prettifying of response body using JavaScript in admin
* [#33] Added ``reset_db_save_after`` option to config model
* [#43] Improved admin response body display by wrapping text over multiple lines for better readability
* [#44] Added response body size column to admin list view

0.6.1 (2024-02-12)
==================

Small bugfix release

* [#34] Properly log data for error responses

0.6.0 (2023-12-11)
==================

Small quality of life release

* Added Celery task and management command to prune log records.
* [#29] Changed request URL-field to textfield to handle arbitrary URL lengths.

0.5.2 (2023-09-22)
==================

Improved robustness after observing (likely) an APM bug.

Crashes when trying to save the log records to the database are now suppressed. This
means you lose the log record, but the application itself should continue to function
properly.

0.5.1 (2023-08-17)
==================

Fixed a bug causing request logging to happen multiple times.

0.5.0 (2023-08-15)
==================

**💥 Breaking changes**

* This library now logs to the "log_outgoing_requests" logger instead of "requests".
  Update your ``settings.LOGGING["loggers"]`` accordingly.

Other changes

* [#15] Ensure that requests are logged when request errors occur
* [#11] Add changelog file

0.4.0 (2023-06-09)
==================

Improved admin UX when viewing log records.

0.3.0 (2023-06-08)
==================

* Added Dutch translations
* Implemented default settings
* Namespace our requests monkeypatch
* Confirmed Python 3.11 and Django 4.2 support
* Fixed missing version bumps in a number of files

0.2.0 (2023-06-08)
==================

* Implemented options to log request/response bodies
