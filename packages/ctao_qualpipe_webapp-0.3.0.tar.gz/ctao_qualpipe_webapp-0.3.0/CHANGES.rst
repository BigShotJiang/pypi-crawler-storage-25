qualpipe_webapp 0.3.0 (2026-04-02)
----------------------------------


API Changes
~~~~~~~~~~~

- Add models and schema generation from ctao-qualpipe modules [`!12 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/12>`__]

- New API to get the list of available data quality metrics for a given observation, telescope, site, and date. [`!60 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/60>`__]


Bug Fixes
~~~~~~~~~


New Features
~~~~~~~~~~~~

- - Backend initial docker setup
  - Frontend initial docker setup
  - Frontend integration with backend endpoints to fetch data files.
  - Frontend renders simple scatter plot data.
  - Double fixed-top navbar, horizontally scrollable for overflow and vertically adaptable to long, line-wrapped content.
  - All page contents adjust responsively.
  - Hover effects on both navbars, with highlighting of the selected item.
  - Both navbars collapse into a button with a dropdown list for smaller viewport sizes, enhancing mobile usability.
  - Common template for all pages to ensure consistent layout and navigation.
  - Plot placeholders dynamically adapt to different viewport sizes.
  - Hover-expandable sidebar for metadata selection, supporting common query parameters (site, date).
  - Sidebar content is context-sensitive: 'Telescope ID' and 'OB ID' appear only when a telescope page is selected.
  - 'Telescope ID' sidebar item updates dynamically according to the selected Site and Telescope.
  - Independent vertical scrolling for sidebar and main page content, enhancing usability.
  - Add a responsive footer with breadcrumb navigation to display the current path.
  - Parameters selected from the collapsible sidebar are visible in the footer.
  - Footer height automatically adapts to its content, supporting content wrapping for improved accessibility.
  - Define the second navigation bar content for telescope pages.
  - Backend endpoints to serve data files. [`!1 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/1>`__]

- Add a helm chart. [`!2 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/2>`__]

- - Add automatic javascript unit testing and coverage reporting with Mocha and c8
  - Add automatic javascript end to end testing (and coverage reporting) with Playwright (and c8?) [`!11 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/11>`__]

- - Convert all CommonJS script to ES javascript modules
  - Update HTML templates to load scripts as modules
  - Update sidebar to use event listeners instead of inline JS
  - Create a config.js file to hold configuration variables (e.g. backend URL) [`!13 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/13>`__]

- - setup js-unittests (Mocha)
  - setup js-end-to-end tests (Playwright)
  - add some unittests
  - add some js-e2e tests [`!15 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/15>`__]

- Setup kind environment for local development. [`!38 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/38>`__]

- - Implemented backend factory pattern with ``BackendAPI`` abstract base class for extensible data source integration.
  - Added ``FileBackend`` as the reference file-based implementation for HDF5 data extraction with support for flatfield timing datasets.
  - Enhanced sidebar and footer with localStorage persistence to maintain user selections (site, date, OB, telescope ID) across page navigation with automatic plot generation. [`!40 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/40>`__]

- Add 1D histogram functionality. [`!44 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/44>`__]

- Add telescope Camera-view. [`!45 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/45>`__]

- Make frontend pages configurable instead of hard-coded

  - add a YAML config to define pages, plots, and layout
  - validate and load the config in the frontend server
  - render pages with a single generic template
  - build sub-navigation from the config
  - update tests to read pages from the config
  - ignore runtime data/toolkit folders
  - split page configs into an index plus per-page YAML files
  - add soft-fail handling for invalid page configs with a dedicated error page
  - add tests for invalid page config rendering [`!54 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/54>`__]

- Make plot configuration frontend‑driven

  - define plot configurations inline in per‑page YAML files
  - preserve plot ordering from the page config
  - inject per‑page plot configs into templates for plotting
  - drop backend plotConfiguration payload
  - validate plot configs per plot and display errors in the grid
  - refine plot config validation per plot type to match JS implementations
  - update frontend config tests for per‑plot‑type validation [`!57 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/57>`__]

- Make plot data config-driven and fix backend image imports

  - add per-plot data config (path_tail, field) to page YAMLs for interleaved plots
  - use plot_id in templates/JS lookups, keep titles for display only
  - validate plot data config and warn when missing or invalid
  - update frontend config tests for plot_id uniqueness and path hashing
  - update tests [`!61 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/61>`__]

- Implement backend metric autodiscovery.

  - backend now discovers available quality metrics directly from HDF5 datasets instead of relying on a fixed list
  - metric availability is now resolved per observation/telescope context [`!64 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/64>`__]


Maintenance
~~~~~~~~~~~

- Add pixi run clean project and reset-env commands for dev cleanup and broken environment recovery respectively. [`!53 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/53>`__]

- Add autosummary templates, required intersphinx mappings and exclude tests from the doc building.
  Added to contribution guide the need to include a changelog. [`!56 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/56>`__]


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- - Add schema validation for "data" and "metadata" objects
  - Metadata schema refactoring, adding "plotConfiguration" key
  - Implement various plot "marks" option
  - Implement Log scale option in plot
  - Add "plotType" key to the metadata schema
  - Refactoring "scatterPlot" function [`!8 <https://gitlab.cta-observatory.org/cta-computing/documentation/TEMPLATE_PROJECT/-/merge_requests/8>`__]
