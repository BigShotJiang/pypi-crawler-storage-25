🧹 Cleanup
===============

When you are done with your development session you can execute a :ref:`soft
clean <soft-clean>` or a :ref:`full clean <full-clean>`, or a more thorough
project cleanup depending on your needs.

.. _soft-clean:

Soft clean
----------

To stop only the pods, preserving the cluster, execute:

.. code:: bash

   pixi run stop

.. note::
   To restart your development workflow, execute one of the following commands, depending on your case:

   - With images rebuilding:

   .. code:: bash

      pixi run dev-restart

   - Without images rebuilding:

   .. code:: bash

      pixi run dev-restart-no-build


.. _full-clean:

Full clean
----------

To stop the pods and remove the cluster execute:

.. code:: bash

   pixi run stop-and-delete

.. note::
   To restart your development workflow, execute one of the following commands, depending on your case:

   - With images rebuilding:

   .. code:: bash

      pixi run dev-up

   - Without images rebuilding:

   .. code:: bash

      pixi run dev-up-no-build


Docker clean
------------

You can remove the unused Docker resources (dangling containers, images, networks,
and cache) with:

.. code:: bash

   pixi run prune

If you want to clean everything related to the project runtime (stop pods, remove cluster, and remove docker images), execute:

.. code:: bash

   pixi run clean-all

.. note:: To restart your development workflow after the ``clean-all`` command, execute:

   .. code:: bash

      pixi run dev-up


Project clean
-------------

If you want to clean the project state and reinstall the development environment
from scratch, you can execute:

.. code:: bash

   pixi run clean-project

This command performs a complete cleanup of everything created by the project
during development and resets the local Pixi environment using the official
Pixi command:

- stops pods and removes the cluster
- removes project Docker images
- prunes unused Docker resources
- cleans the local Pixi environment using ``pixi clean``
- keeps the project lock file (``pixi.lock``)

After this command, you can reinstall and start the development workflow again
by executing:

.. code:: bash

   pixi run dev-setup
   pixi run dev-up

Reset environment
-----------------

If the Pixi itself is in an inconsistent or broken state (for
example after failed installations or interrupted commands), you can execute:

.. code:: bash

   pixi run reset-env

This command performs a full cleanup of the project runtime state using
``clean-all`` and additionally:

- removes the local Pixi environment directory (``.pixi/``)

The project lock file (``pixi.lock``) is preserved, so the environment can be
recreated deterministically.

After running this command, you can reinstall the development environment with:

.. code:: bash

   pixi run dev-setup
   pixi run dev-up

.. note::
   For normal development workflows, ``clean-project`` should be preferred.
   Use ``reset-env`` only if the Pixi environment cannot be recovered otherwise.
