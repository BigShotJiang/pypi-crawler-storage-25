"""
Configuration file for the Sphinx documentation builder.

This file only contains a selection of the most common options. For a full
list see the documentation:
https://www.sphinx-doc.org/en/master/usage/configuration.html
"""

# -- Project information -----------------------------------------------------
# import your own package here
import qualpipe_webapp

project = "qualpipe_webapp"
copyright = "CTAO"
author = (
    "Université de Genève, Département de physique nucléaire et corpusculaire (DPNC)"  # noqa: E501
)
version = qualpipe_webapp.__version__
# The full version, including alpha/beta/rc tags.
release = version


# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.githubpages",
    "sphinx.ext.intersphinx",
    "sphinx.ext.autodoc",
    "sphinx.ext.autosummary",
    "numpydoc",
    "sphinx_changelog",
    "sphinx_copybutton",
    "sphinx.ext.viewcode",
]

autosummary_generate = True

# Render type hints in descriptions to avoid pydantic annotation issues.
autodoc_typehints = "description"
autodoc_typehints_format = "short"

# Numpydoc configuration
numpydoc_show_class_members = False  # Don't auto-generate method summaries

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ["changes", "**/test_*.py", "**/tests/**"]

# have all links automatically associated with the right domain.
default_role = "py:obj"


# intersphinx allows referencing other packages sphinx docs
intersphinx_mapping = {
    "python": ("https://docs.python.org/3/", None),
    "h5py": ("https://docs.h5py.org/en/stable/", None),
    "numpy": ("https://numpy.org/doc/stable/", None),
    "pydantic": ("https://docs.pydantic.dev/latest/", None),
    "fastapi": ("https://fastapi.tiangolo.com/", None),
    # "starlette": ("https://www.starlette.dev/", None),
    # https://github.com/Kludex/starlette/discussions/3099
    "traitlets": ("https://traitlets.readthedocs.io/en/stable/", None),
}

# Ignore references that cannot be resolved even with intersphinx
nitpick_ignore = [
    ("py:obj", "ConfigDict"),
    ("py:class", "traitlets.traitlets.TraitType"),
    ("py:class", "traitlets.traitlets.HasTraits"),
]

# -- Options for HTML output -------------------------------------------------

html_theme = "ctao"
html_theme_options = dict(
    navigation_with_keys=False,
    # setup for displaying multiple versions, also see setup in .gitlab-ci.yml
    switcher=dict(
        json_url="http://cta-computing.gitlab-pages.cta-observatory.org/dpps/qualpipe/qualpipe-webapp/versions.json",  # noqa: E501
        version_match="latest" if ".dev" in version else f"v{version}",
    ),
    navbar_center=["version-switcher", "navbar-nav"],
)

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = []
