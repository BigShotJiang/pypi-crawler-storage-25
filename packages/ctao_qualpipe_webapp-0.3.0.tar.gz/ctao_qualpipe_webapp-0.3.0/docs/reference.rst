API Reference
=============

.. currentmodule:: qualpipe_webapp

.. autosummary::
   :toctree: _autosummary
   :recursive:

   backend
   frontend

.. automodule:: qualpipe_webapp
   :members:
   :undoc-members:
   :show-inheritance:
