import { expect } from "chai";
import { JSDOM } from "jsdom";
import sinon from "sinon";
import * as plotModule from "../static/js/plot.js";
import esmock from "esmock";

// Helper function to build minimal plot data with metadata
function makePlotData(key = "test") {
  return {
    [key]: {
      fetchedData: { x: [1, 2, 3], y: [4, 5, 6] },
      fetchedMetadata: { plotConfiguration: { title: "t" } },
    },
  };
}

// Helper functions to avoid deep nesting in tests
const alwaysTrue = () => true;
const asyncTextFn = (value) => async () => value;
function FakeAjv() {
  this.addSchema = sinon.stub();
  this.compile = sinon.stub().returns(alwaysTrue);
}

function setupMissingInfoDom(initialText = "") {
  document.body.innerHTML = `<div id="missingInfo"></div>`;
  const missingInfo = document.getElementById("missingInfo");
  if (initialText) {
    missingInfo.textContent = initialText;
  }
  return missingInfo;
}

// Helper to test validation functions with consistent pattern
function testValidation(description, validationFn, value, expectedResult) {
  it(description, function () {
    setupMissingInfoDom();
    const result = validationFn(value);
    expect(result).to.equal(expectedResult);
  });
}

// Helper to set up DOM for requestData tests
function setupRequestDom({
  site = "North",
  date = "2025-12-16",
  ob = "123",
  telId = "1",
  plotContainers = [],
} = {}) {
  document.body.innerHTML = `
    <div id="missingInfo"></div>
    <div id="which-Site"></div>
    <input id="date-picker" value="${date}" />
    <div id="which-OB"></div>
    <div id="which-Tel-ID"></div>
  `;

  document.getElementById("which-Site").value = site;
  document.getElementById("which-OB").value = ob;
  document.getElementById("which-Tel-ID").value = telId;

  // Add plot containers if specified
  plotContainers.forEach((id) => {
    const div = document.createElement("div");
    div.id = id;
    document.body.appendChild(div);
  });
}

// Helper to build standardized esmock modules
function buildEsmockMocks({
  validationOverrides = {},
  scatterOverrides = {},
  cameraOverrides = {},
  baseOverrides = {},
} = {}) {
  const validationAbs = new URL("../static/js/validation.js", import.meta.url).pathname;
  const scatterAbs = new URL("../static/js/scatterPlot.js", import.meta.url).pathname;
  const cameraAbs = new URL("../static/js/cameraPlot.js", import.meta.url).pathname;
  const baseAbs = new URL("../static/js/base.js", import.meta.url).pathname;

  return {
    modules: {
      [validationAbs]: {
        isValidMetadata: async () => true,
        isValidData: async () => true,
        ...validationOverrides,
      },
      [scatterAbs]: { scatterPlot: sinon.spy(), ...scatterOverrides },
      [cameraAbs]: {
        ensureCameraViewInitialized: sinon.stub().returns(true),
        updateCameraView: sinon.stub(),
        bootstrapCameraViews: sinon.stub(),
        ...cameraOverrides,
      },
      [baseAbs]: { resizeListeners: {}, ...baseOverrides },
    },
    absUrls: { validationAbs, scatterAbs, cameraAbs, baseAbs },
  };
}

// Helper to parameterize validator tests
function testValidatorFunction({
  validatorFn,
  validatorName,
  plotType,
  validDataFactory = () => ({ x: [1, 2, 3, 4] }),
  includeBaseXInvalidTests = true,
  additionalTests = [],
} = {}) {
  describe(validatorName, function () {
    it("should accept valid data", function () {
      const data = validDataFactory();
      const result = validatorFn(
        data,
        "test",
        "plot-test",
        plotType,
        () => false
      );
      expect(result).to.be.true;
    });

    if (includeBaseXInvalidTests) {
      it("should reject empty x array", function () {
        document.body.innerHTML = `<div id="plot-test"></div>`;
        const data = { x: [] };
        const customError = sinon.spy();
        validatorFn(data, "test", "plot-test", plotType, customError);
        expect(customError.called).to.be.true;
        expect(customError.firstCall.args[0]).to.include("at least one element");
      });

      it("should reject missing x array", function () {
        document.body.innerHTML = `<div id="plot-test"></div>`;
        const data = { y: [1, 2, 3] };
        const customError = sinon.spy();
        validatorFn(data, "test", "plot-test", plotType, customError);
        expect(customError.called).to.be.true;
      });

      it("should reject null x data", function () {
        document.body.innerHTML = `<div id="plot-test"></div>`;
        const data = { x: null };
        const customError = sinon.spy();
        validatorFn(data, "test", "plot-test", plotType, customError);
        expect(customError.called).to.be.true;
      });
    }

    // Add any plot-type-specific tests
    additionalTests.forEach(test => {
      it(test.description, test.fn);
    });
  });
}

// Setup JSDOM
let dom;
let window;
let document;
let fetchStub;

describe("Testing 'plot.js'", function () {
  beforeEach(() => {
    dom = new JSDOM(
      `
      <html>
        <body>
          <div id="missingInfo"></div>
          <div id="which-Site">
            <option value="North">North</option>
            <option value="South">South</option>
          </div>
          <input id="date-picker" value="" />
          <div id="which-OB"></div>
          <div id="which-Tel-ID"></div>
        </body>
      </html>
    `,
      { url: "http://qualpipe.local:8080/LSTs/test" }
    );
    window = dom.window;
    document = window.document;
    global.window = window;
    global.document = document;
    global.fetch = sinon.stub();
    fetchStub = global.fetch;
    window.PLOT_CONFIGURATIONS = {
      foo: { plotType: "scatterplot" },
      test: { plotType: "scatterplot" },
    };

    // Mock jQuery
    global.$ = function (selector) {
      return {
        val: function () {
          const element = document.querySelector(selector);
          return element ? element.value : "";
        },
      };
    };
  });

  afterEach(() => {
    sinon.restore();
    dom?.window?.close();
    delete global.window;
    delete global.document;
    delete global.fetch;
    delete global.$;
  });

  describe("plotAndCreateResizeListener", function () {
    it("should reset plot container color to black on resize", async function () {
      const elementId = "plot-test";
      document.body.innerHTML = `<div id="${elementId}" style="color: red;"></div>`;

      // Ensure scatterPlot sees non-zero dimensions
      document.getElementById(elementId).getBoundingClientRect = () => ({
        width: 200,
        height: 200,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      });

      // Use esmock to replace scatterPlot with a no-op for this test
      const scatterAbs = new URL("../static/js/scatterPlot.js", import.meta.url)
        .pathname;
      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        { [scatterAbs]: { scatterPlot: () => { } } },
        { url: import.meta.url }
      );

      // Provide minimal metadata so handler runs
      const data = makePlotData();
      const key = "test";

      const handler = plotModuleMocked.plotAndCreateResizeListener(
        elementId,
        data,
        key,
        "scatterplot"
      );

      const plotContainer = document.getElementById(elementId);
      // invoke the resize handler to trigger color reset
      handler();
      expect(plotContainer.style.color).to.equal("black");
    });

    it("should use scatterPlot fallback for unknown plot type", async function () {
      const elementId = "plot-test";
      document.body.innerHTML = `<div id="${elementId}" style="color: red;"></div>`;

      document.getElementById(elementId).getBoundingClientRect = () => ({
        width: 200,
        height: 200,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      });

      const scatterAbs = new URL("../static/js/scatterPlot.js", import.meta.url)
        .pathname;
      const scatterSpy = sinon.spy();
      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        { [scatterAbs]: { scatterPlot: scatterSpy } },
        { url: import.meta.url }
      );

      const data = makePlotData();
      const key = "test";

      const handler = plotModuleMocked.plotAndCreateResizeListener(
        elementId,
        data,
        key,
        "unknown-plot-type"
      );

      handler();

      expect(scatterSpy.calledOnce).to.equal(true);
      expect(scatterSpy.firstCall.args[0]).to.equal(elementId);
    });
  });

  describe("handleInvalidData", function () {
    it("should clear the plot and display error message", function () {
      const elementId = "plot-test";
      const message = "Test error message";
      document.body.innerHTML = `<div id="${elementId}"></div>`;

      plotModule.handleInvalidData(message, elementId);

      const container = document.getElementById(elementId);
      const errorDiv = container.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal(message);
      expect(container.style.color).to.equal("red");
    });

    it("should handle null elementId gracefully", function () {
      const message = "Test error message";
      expect(() => plotModule.handleInvalidData(message, null)).to.not.throw();
    });

    it("should broadcast message to all plot-* containers when elementId is null", function () {
      document.body.innerHTML = `
        <div id="plot-a"></div>
        <div id="plot-b"></div>
      `;

      const warnStub = sinon.stub(console, "warn");
      const message = "Broadcast error";

      plotModule.handleInvalidData(message, null, true);

      ["plot-a", "plot-b"].forEach((id) => {
        const container = document.getElementById(id);
        const errorDiv = container.querySelector(".plot-error");
        expect(errorDiv).to.exist;
        expect(errorDiv.textContent).to.equal(message);
        expect(container.style.color).to.equal("red");
      });

      expect(warnStub.called).to.equal(true);
    });
  });

  testValidatorFunction({
    validatorFn: plotModule.validateScatterplot,
    validatorName: "validateScatterplot",
    plotType: "scatterplot",
    includeBaseXInvalidTests: false,
    validDataFactory: () => ({
      x: [1, 2, 3],
      y: [4, 5, 6],
      xerr: [0.1, 0.1, 0.1],
      yerr: [0.2, 0.2, 0.2],
    }),
    additionalTests: [
      {
        description: "should reject when x and y lengths do not match",
        fn: function () {
          const data = { x: [1, 2], y: [4, 5, 6] };
          const customError = sinon.stub().returns(false);
          plotModule.validateScatterplot(
            data,
            "test-key",
            "plot-test",
            "scatterplot",
            customError
          );
          expect(customError.called).to.be.true;
          expect(customError.firstCall.args[0]).to.include(
            "x and y must have the same length"
          );
        },
      },
      {
        description: "should reject when xerr length does not match x",
        fn: function () {
          const data = { x: [1, 2, 3], y: [4, 5, 6], xerr: [0.1, 0.1] };
          const customError = sinon.stub().returns(false);
          plotModule.validateScatterplot(
            data,
            "test-key",
            "plot-test",
            "scatterplot",
            customError
          );
          expect(customError.called).to.be.true;
          expect(customError.firstCall.args[0]).to.include(
            "xerr exists but does not match x length"
          );
        },
      },
      {
        description: "should reject when yerr length does not match y",
        fn: function () {
          const data = { x: [1, 2, 3], y: [4, 5, 6], yerr: [0.2] };
          const customError = sinon.stub().returns(false);
          plotModule.validateScatterplot(
            data,
            "test-key",
            "plot-test",
            "scatterplot",
            customError
          );
          expect(customError.called).to.be.true;
          expect(customError.firstCall.args[0]).to.include(
            "yerr exists but does not match y length"
          );
        },
      },
      {
        description: "should handle data with both xerr and yerr present",
        fn: function () {
          const data = {
            x: [1, 2, 3],
            y: [4, 5, 6],
            xerr: [0.1, 0.2, 0.3],
            yerr: [0.2, 0.3, 0.4],
          };
          const result = plotModule.validateScatterplot(
            data,
            "test",
            "plot-test",
            "scatterplot",
            () => false
          );
          expect(result).to.be.true;
        },
      },
      {
        description: "should reject x array longer than y array",
        fn: function () {
          document.body.innerHTML = `<div id="plot-test"></div>`;
          const data = { x: [1, 2, 3, 4], y: [4, 5, 6] };
          const customError = sinon.spy();
          plotModule.validateScatterplot(
            data,
            "test",
            "plot-test",
            "scatterplot",
            customError
          );
          expect(customError.called).to.be.true;
          expect(customError.firstCall.args[0]).to.include("same length");
        },
      },
    ],
  });

  describe("checkXYLength", function () {
    it("should call validator for known plot types", function () {
      const data = makePlotData();

      const result = plotModule.checkXYLength(
        data["test"],
        "test-key",
        "plot-test",
        "scatterplot"
      );

      expect(result).to.be.true;
    });

    it("should handle unknown plot types", function () {
      document.body.innerHTML = `<div id="plot-test"></div>`;
      const data = makePlotData();

      const result = plotModule.checkXYLength(
        data["test"],
        "test-key",
        "plot-test",
        "unknown-type"
      );

      expect(result).to.be.undefined;
    });

    it("should reject mismatched x and y lengths", function () {
      document.body.innerHTML = `<div id="plot-test"></div>`;
      const data = {
        fetchedData: {
          x: [1, 2],
          y: [4, 5, 6],
        },
      };

      const result = plotModule.checkXYLength(
        data,
        "test-key",
        "plot-test",
        "scatterplot"
      );

      expect(result).to.be.false;
    });
  });

  describe("clearPlotArea", function () {
    it("should clear a single plot by ID", function () {
      document.body.innerHTML = `<div id="plot-test"></div>`;
      const container = document.getElementById("plot-test");
      container.innerHTML = "<svg></svg>";

      plotModule.clearPlotArea("plot-test");

      expect(container.querySelector("svg")).to.not.exist;
      expect(container.textContent).to.equal("");
      expect(container.style.color).to.equal("black");
    });

    it("should clear all plots when plotId is omitted or null", function () {
      document.body.innerHTML = `
        <div id="plot-test1"></div>
        <div id="plot-test2"></div>
      `;
      const plots = document.querySelectorAll('[id^="plot-"]');

      // Add some content to clear
      plots.forEach((plot) => (plot.innerHTML = "<svg></svg><h5>t</h5>old"));

      plotModule.clearPlotArea();

      plots.forEach((plot) => {
        expect(plot.querySelector("svg")).to.not.exist;
        expect(plot.textContent).to.equal("");
        expect(plot.style.color).to.equal("black");
      });
    });

    it("should handle non-existent plot ID gracefully", function () {
      document.body.innerHTML = "";
      expect(() =>
        plotModule.clearPlotArea("Error", "non-existent")
      ).to.not.throw();
    });
  });

  describe("Query parameters validation", function () {
    describe("isValidSite", function () {
      it("should accept 'North' as valid site", function () {
        const result = plotModule.isValidSite("North");
        expect(result).to.be.true;
      });

      it("should accept 'South' as valid site", function () {
        const result = plotModule.isValidSite("South");
        expect(result).to.be.true;
      });

      it("should reject invalid sites", function () {
        setupMissingInfoDom();
        const result = plotModule.isValidSite("Invalid");
        expect(result).to.be.false;
        expect(document.getElementById("missingInfo").textContent).to.include(
          "Site must be either 'North' or 'South'"
        );
      });
    });

    describe("isValidDate", function () {
      testValidation(
        "should accept valid date format YYYY-MM-DD",
        plotModule.isValidDate,
        "2025-12-16",
        true
      );

      [
        { label: "missing date", value: "" },
        { label: "'Choose a date' placeholder", value: "Choose a date" },
        { label: "invalid date format", value: "12/16/2025" },
      ].forEach(({ label, value }) => {
        testValidation(
          `should reject ${label}`,
          plotModule.isValidDate,
          value,
          false
        );
      });
    });

    describe("isValidOB", function () {
      testValidation(
        "should accept valid OB number",
        plotModule.isValidOB,
        "12345",
        true
      );

      [
        { label: "missing OB", value: "" },
        {
          label: "'choose date first' placeholder",
          value: "choose date first",
        },
        { label: "'No OBs available' status", value: "No OBs available" },
        { label: "'Select an OB' placeholder", value: "Select an OB" },
        { label: "non-numeric OB", value: "OB-123" },
      ].forEach(({ label, value }) => {
        testValidation(
          `should reject ${label}`,
          plotModule.isValidOB,
          value,
          false
        );
      });
    });

    describe("isValidTelType", function () {
      const validTelTypes = ["LST", "MST", "SST"];
      for (const telType of validTelTypes) {
        testValidation(
          `should accept '${telType}' as valid telescope type`,
          plotModule.isValidTelType,
          telType,
          true
        );
      }

      const invalidTelTypes = [
        { value: "INVALID", label: "invalid telescope type" },
        { value: "", label: "missing telescope type" },
      ];
      for (const { value, label } of invalidTelTypes) {
        testValidation(
          `should reject ${label}`,
          plotModule.isValidTelType,
          value,
          false
        );
      }
    });

    describe("isValidTelID", function () {
      testValidation(
        "should accept valid numeric Telescope ID",
        plotModule.isValidTelID,
        "123",
        true
      );

      [
        { label: "missing Telescope ID", value: "" },
        { label: "'select a Tel ID' placeholder", value: "select a Tel ID" },
        { label: "non-numeric Telescope ID", value: "TEL-123" },
      ].forEach(({ label, value }) => {
        testValidation(
          `should reject ${label}`,
          plotModule.isValidTelID,
          value,
          false
        );
      });
    });

    describe("checkQueryParams", function () {
      it("should return true for all valid parameters", function () {
        setupMissingInfoDom();
        const result = plotModule.checkQueryParams(
          "LST",
          "North",
          "2025-12-16",
          "123",
          "1"
        );
        expect(result).to.be.true;
      });

      [
        {
          description: "should return false for invalid site",
          args: ["LST", "Invalid", "2025-12-16", "123", "1"],
        },
        {
          description: "should return false for invalid date",
          args: ["LST", "North", "invalid", "123", "1"],
        },
      ].forEach(({ description, args }) => {
        it(description, function () {
          setupMissingInfoDom();
          const result = plotModule.checkQueryParams(...args);
          expect(result).to.be.false;
        });
      });

      it("should clear missingInfo when all parameters are valid", function () {
        setupMissingInfoDom("Some error");
        plotModule.checkQueryParams("LST", "North", "2025-12-16", "123", "1");
        expect(document.getElementById("missingInfo").textContent).to.equal("");
      });
    });
  });

  describe("requestData", function () {
    it("should return data for valid parameters", async function () {
      setupRequestDom();

      const mockData = { test: "data" };
      fetchStub.resolves({
        status: 200,
        json: sinon.stub().resolves(mockData),
      });

      const result = await plotModule.requestData();

      expect(result).to.deep.equal(mockData);
      expect(fetchStub.called).to.be.true;
      expect(fetchStub.firstCall.args[1]).to.deep.equal({ cache: "no-store" });
    });

    it("should handle 404 response", async function () {
      setupRequestDom();

      fetchStub.resolves({
        status: 404,
        json: sinon.stub().resolves({}),
      });

      const result = await plotModule.requestData();

      expect(result).to.be.undefined;
      expect(document.getElementById("missingInfo").textContent).to.include(
        "404"
      );
    });

    it("should return false for invalid parameters", async function () {
      setupRequestDom({ site: "Invalid", date: "", ob: "123", telId: "1" });

      const result = await plotModule.requestData();

      expect(result).to.be.false;
      expect(fetchStub.called).to.be.false;
    });

    it("should handle fetch errors gracefully", async function () {
      setupRequestDom();

      fetchStub.rejects(new Error("Network error"));

      const result = await plotModule.requestData();

      expect(result).to.be.undefined;
    });
  });

  describe("missingInfo", function () {
    it("should set missingInfo element text and background", function () {
      setupMissingInfoDom();
      plotModule.missingInfo("Test error");

      const element = document.getElementById("missingInfo");
      expect(element.textContent).to.equal("Test error");
      expect(element.style.background).to.equal("red");
    });

    it("should handle missing missingInfo element gracefully", function () {
      document.body.innerHTML = "";
      expect(() => plotModule.missingInfo("Test error")).to.not.throw();
    });
  });

  describe("validateAndPlotElement", function () {
    it("should show error when key data is missing", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;

      await plotModule.validateAndPlotElement("plot-foo", { other: {} }, "foo");

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal("No data found for key: foo");
      expect(el.style.color).to.equal("red");
    });

    it("should report invalid metadata when schema fetch fails", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;

      // First two fetch calls are for metadata and criteria schemas
      fetchStub.onFirstCall().resolves({ ok: false, status: 404 });
      fetchStub.onSecondCall().resolves({ ok: false, status: 404 });

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "scatterplot" } },
          fetchedData: { x: [1, 2], y: [1, 2] },
        },
      };

      await plotModule.validateAndPlotElement("plot-foo", data, "foo");

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal("Invalid metadata for key: foo");
      expect(el.style.color).to.equal("red");
    });

    it("should stop with length error when validations pass but x/y mismatch", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;

      // Mock globals required by validators
      window.jsyaml = { load: sinon.stub().returns({}) };
      window.Ajv = FakeAjv;

      // metadata schema and criteria schema
      fetchStub.onCall(0).resolves({ ok: true, text: asyncTextFn("meta") });
      fetchStub.onCall(1).resolves({ ok: true, text: asyncTextFn("crit") });
      // data schema for scatterplot
      fetchStub.onCall(2).resolves({ ok: true, text: asyncTextFn("data") });

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "scatterplot" } },
          fetchedData: { x: [1, 2], y: [1] }, // mismatch to trigger length error
        },
      };

      await plotModule.validateAndPlotElement("plot-foo", data, "foo");

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.match(/Data length error for key: 'foo'/);
      expect(el.style.color).to.equal("red");
    });

    it("should show error when frontend config plotType is missing", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;
      window.PLOT_CONFIGURATIONS = { foo: {} };

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: {} },
          fetchedData: { x: [1, 2], y: [1, 2] },
        },
      };

      await plotModule.validateAndPlotElement("plot-foo", data, "foo");

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal(
        "Missing plotType in frontend config for key: foo"
      );
      expect(el.style.color).to.equal("red");
    });
  });

  describe("makePlot", function () {
    it("should clear plot containers when no data is returned", async function () {
      setupRequestDom({ site: "Invalid", date: "", ob: "123", telId: "1" });
      document.getElementById("plot-foo")?.remove();
      const plotContainer = document.createElement("div");
      plotContainer.id = "plot-foo";
      plotContainer.textContent = "old";
      document.body.appendChild(plotContainer);

      plotModule.makePlot();
      await new Promise((r) => setTimeout(r, 0));

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal("No data received.");
      expect(el.style.color).to.equal("red");
    });

    it("should request data successfully and do nothing if no plot-* elements", async function () {
      setupRequestDom({
        site: "North",
        date: "2025-12-16",
        ob: "123",
        telId: "1",
      });

      fetchStub.resolves({ status: 200, json: async () => ({ ok: true }) });

      plotModule.makePlot();
      await new Promise((r) => setTimeout(r, 0));

      expect(fetchStub.called).to.be.true;
      // No plot-* divs, so nothing else to assert beyond no throw
    });

    it("logs error in catch when requestData throws", async function () {
      // Force requestData to throw synchronously by making getElementById blow up
      const docErr = new Error("boom");
      const originalWindow = global.window;
      const originalDocument = global.document;

      global.window = { location: { pathname: "/LSTs/foo" } };
      global.document = {
        getElementById: () => {
          throw docErr;
        },
        querySelectorAll: () => [],
      };

      const consoleSpy = sinon.spy(console, "error");

      plotModule.makePlot();
      await new Promise((r) => setTimeout(r, 0));

      expect(consoleSpy.called).to.be.true;
      expect(consoleSpy.firstCall.args[0]).to.equal(
        "Error while requesting data:"
      );
      expect(consoleSpy.firstCall.args[1]).to.equal(docErr);

      consoleSpy.restore();
      global.window = originalWindow;
      global.document = originalDocument;
    });

    it("logs error in catch when requestData rejects asynchronously", async function () {
      const asyncErr = new Error("async boom");

      // Keep DOM minimal to avoid plotting loop
      const originalQuerySelectorAll = document.querySelectorAll;
      document.querySelectorAll = () => [];

      const consoleSpy = sinon.spy(console, "error");

      plotModule.makePlot(() => Promise.reject(asyncErr));
      await new Promise((r) => setTimeout(r, 0));

      expect(consoleSpy.called).to.be.true;
      expect(consoleSpy.firstCall.args[0]).to.equal(
        "Error while requesting data:"
      );
      expect(consoleSpy.firstCall.args[1]).to.equal(asyncErr);

      consoleSpy.restore();
      document.querySelectorAll = originalQuerySelectorAll;
    });

    it("shows warning error when plot container misses data-source attribute", async function () {
      setupRequestDom({
        site: "North",
        date: "2025-12-16",
        ob: "123",
        telId: "1",
        plotContainers: ["plot-foo"],
      });

      plotModule.makePlot(() => Promise.resolve({ foo: {} }));
      await new Promise((r) => setTimeout(r, 0));

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal(
        "Missing data-plot-key attribute on plot container."
      );
      expect(el.style.color).to.equal("red");
    });

    it("should ignore stale response and render latest request only", async function () {
      document.body.innerHTML = `
        <div id="missingInfo"></div>
        <div id="plot-foo" data-plot-key="foo"></div>
      `;
      window.PLOT_CONFIGURATIONS = {
        foo: { plotType: "scatterplot" },
      };

      const scatterAbs = new URL("../static/js/scatterPlot.js", import.meta.url)
        .pathname;
      const validationAbs = new URL("../static/js/validation.js", import.meta.url)
        .pathname;
      const baseAbs = new URL("../static/js/base.js", import.meta.url).pathname;
      const cameraAbs = new URL("../static/js/cameraPlot.js", import.meta.url)
        .pathname;

      let resolveFirst;
      let resolveSecond;
      const firstPromise = new Promise((resolve) => {
        resolveFirst = resolve;
      });
      const secondPromise = new Promise((resolve) => {
        resolveSecond = resolve;
      });
      const requestDataFn = sinon.stub();
      requestDataFn.onCall(0).returns(firstPromise);
      requestDataFn.onCall(1).returns(secondPromise);

      const scatterSpy = sinon.spy();
      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        {
          [scatterAbs]: { scatterPlot: scatterSpy },
          [validationAbs]: {
            isValidMetadata: async () => true,
            isValidData: async () => true,
          },
          [baseAbs]: { resizeListeners: {} },
          [cameraAbs]: {
            ensureCameraViewInitialized: sinon.stub().returns(true),
            updateCameraView: sinon.stub(),
            bootstrapCameraViews: sinon.stub(),
          },
        },
        { url: import.meta.url }
      );

      plotModuleMocked.makePlot(requestDataFn);
      plotModuleMocked.makePlot(requestDataFn);

      resolveSecond({
        foo: {
          fetchedMetadata: {},
          fetchedData: { x: [239], y: [1] },
        },
      });
      await new Promise((r) => setTimeout(r, 0));

      resolveFirst({
        foo: {
          fetchedMetadata: {},
          fetchedData: { x: [232], y: [1] },
        },
      });
      await new Promise((r) => setTimeout(r, 0));

      expect(scatterSpy.calledOnce).to.equal(true);
      expect(scatterSpy.firstCall.args[1].fetchedData.x).to.deep.equal([239]);
    });
  });

  describe("validateAndPlotElement (success path)", function () {
    async function setupValidateAndPlotTest({ withOldListener = false } = {}) {
      document.body.innerHTML = `<div id="plot-foo" style="color: red;"></div>`;

      const mockedResizeListeners = {};
      const scatterSpy = sinon.spy();

      if (withOldListener) {
        mockedResizeListeners["plot-foo"] = sinon.spy();
      }

      const { modules } = buildEsmockMocks({
        scatterOverrides: { scatterPlot: scatterSpy },
        baseOverrides: { resizeListeners: mockedResizeListeners },
      });

      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        modules,
        { url: import.meta.url }
      );

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "scatterplot" } },
          fetchedData: { x: [1, 2], y: [3, 4] },
        },
      };

      return { plotModuleMocked, mockedResizeListeners, scatterSpy, data };
    }

    it("calls scatterPlot, registers resize listener, and resets color", async function () {
      const { plotModuleMocked, mockedResizeListeners, scatterSpy, data } =
        await setupValidateAndPlotTest();

      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      expect(scatterSpy.calledOnce).to.be.true;
      expect(scatterSpy.firstCall.args[0]).to.equal("plot-foo");
      expect(typeof mockedResizeListeners["plot-foo"]).to.equal("function");

      const el = document.getElementById("plot-foo");
      expect(el.style.color).to.equal("black");

      window.dispatchEvent(new window.Event("resize"));
      expect(scatterSpy.calledTwice).to.be.true;
    });

    it("uses plotType from frontend config instead of fetched metadata", async function () {
      const { plotModuleMocked, scatterSpy, data } =
        await setupValidateAndPlotTest();

      window.PLOT_CONFIGURATIONS = {
        foo: { plotType: "scatterplot" },
      };
      data.foo.fetchedMetadata.plotConfiguration.plotType = "cameraview";

      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      expect(scatterSpy.calledOnce).to.be.true;
    });

    it("removes old resize listener and registers a new one", async function () {
      const { plotModuleMocked, mockedResizeListeners, data } =
        await setupValidateAndPlotTest({ withOldListener: true });

      const oldListener = mockedResizeListeners["plot-foo"];
      const removeSpy = sinon.spy(window, "removeEventListener");
      const addSpy = sinon.spy(window, "addEventListener");

      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      expect(removeSpy.calledWith("resize", oldListener)).to.be.true;
      expect(addSpy.calledWith("resize")).to.be.true;
      expect(mockedResizeListeners["plot-foo"]).to.be.a("function");
      expect(mockedResizeListeners["plot-foo"]).to.not.equal(oldListener);

      removeSpy.restore();
      addSpy.restore();
    });
  });

  describe("validateAndPlotElement (invalid data path)", function () {
    it("shows 'Invalid data for key' and stops when data validation fails", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;

      const mockedResizeListeners = {};

      const { modules } = buildEsmockMocks({
        validationOverrides: { isValidData: async () => false },
        baseOverrides: { resizeListeners: mockedResizeListeners },
      });

      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        modules,
        { url: import.meta.url }
      );

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "scatterplot" } },
          fetchedData: { x: [1, 2], y: [1, 2] },
        },
      };

      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      const el = document.getElementById("plot-foo");
      const errorDiv = el.querySelector(".plot-error");
      expect(errorDiv).to.exist;
      expect(errorDiv.textContent).to.equal("Invalid data for key: foo");
      expect(el.style.color).to.equal("red");
      expect(mockedResizeListeners["plot-foo"]).to.be.undefined;
    });

    it("stops when cameraview viewer cannot be initialized", async function () {
      document.body.innerHTML = `<div id="plot-foo"></div>`;
      window.PLOT_CONFIGURATIONS = { foo: { plotType: "cameraview" } };

      const mockedResizeListeners = {};

      const { modules } = buildEsmockMocks({
        cameraOverrides: {
          ensureCameraViewInitialized: sinon.stub().returns(false),
          updateCameraView: sinon.stub(),
          bootstrapCameraViews: sinon.stub(),
        },
        baseOverrides: { resizeListeners: mockedResizeListeners },
      });

      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        modules,
        { url: import.meta.url }
      );

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: {} },
          fetchedData: { x: [1, 2] },
        },
      };

      const warnStub = sinon.stub(console, "warn");
      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      expect(
        warnStub.calledWith("Viewer not yet initialised for:", "plot-foo")
      ).to.equal(true);
      expect(mockedResizeListeners["plot-foo"]).to.be.undefined;
      warnStub.restore();
    });
  });

  describe("getConfiguredPlotType", function () {
    [
      {
        description: "returns configured scatterplot",
        configurations: { myplot: { plotType: "scatterplot" } },
        expected: "scatterplot",
      },
      {
        description: "normalizes plotType to lowercase",
        configurations: { myplot: { plotType: "ScatterPlot" } },
        expected: "scatterplot",
      },
      {
        description: "handles histogram1d plotType",
        configurations: { myplot: { plotType: "histogram1d" } },
        expected: "histogram1d",
      },
      {
        description: "handles cameraview plotType",
        configurations: { myplot: { plotType: "cameraview" } },
        expected: "cameraview",
      },
      {
        description: "returns null when plotType is missing",
        configurations: { myplot: {} },
        expected: null,
      },
      {
        description: "returns null when key does not exist",
        configurations: { other: { plotType: "scatterplot" } },
        expected: null,
      },
      {
        description: "returns null when PLOT_CONFIGURATIONS is undefined",
        configurations: undefined,
        expected: null,
      },
      {
        description: "returns null when plotType is not a string",
        configurations: { myplot: { plotType: 123 } },
        expected: null,
      },
    ].forEach(({ description, configurations, expected }) => {
      it(description, function () {
        window.PLOT_CONFIGURATIONS = configurations;
        const result = plotModule.getConfiguredPlotType("myplot");
        expect(result).to.equal(expected);
      });
    });
  });

  testValidatorFunction({
    validatorFn: plotModule.validateCameraViewPlot,
    validatorName: "validateCameraViewPlot",
    plotType: "cameraview",
    additionalTests: [
      {
        description: "should reject non-array x data",
        fn: function () {
          document.body.innerHTML = `<div id="plot-test"></div>`;
          const data = { x: "not an array" };
          const customError = sinon.spy();
          plotModule.validateCameraViewPlot(
            data,
            "test",
            "plot-test",
            "cameraview",
            customError
          );
          expect(customError.called).to.be.true;
        },
      },
    ],
  });

  testValidatorFunction({
    validatorFn: plotModule.validateHistogram1D,
    validatorName: "validateHistogram1D",
    plotType: "histogram1d",
    validDataFactory: () => ({ x: [1, 2, 3, 4, 5] }),
  });

  describe("handleInvalidData with configuration errors", function () {
    it("should skip rendering when data-plot-error attribute is present", function () {
      document.body.innerHTML = `<div id="plot-test" data-plot-error="true">original content</div>`;
      const warnSpy = sinon.spy(console, "warn");

      plotModule.handleInvalidData("This should not be set", "plot-test");

      const el = document.getElementById("plot-test");
      expect(el.textContent).to.equal("original content");
      expect(
        warnSpy.calledWith(
          "Skipping plot render: Static configuration error detected."
        )
      ).to.be.true;
      warnSpy.restore();
    });

    it("should skip validateAndPlotElement when container has data-plot-error attribute", async function () {
      document.body.innerHTML = `
        <div id="plot-test" data-plot-error="true">config error</div>
      `;

      const warnSpy = sinon.spy(console, "warn");
      await plotModule.validateAndPlotElement("plot-test", {}, "foo");

      expect(
        warnSpy.calledWith(
          "Skipping plot render: Static configuration error detected."
        )
      ).to.be.true;
      warnSpy.restore();
    });
  });

  describe("validateAndPlotElement with configuration errors", function () {
    it("should show warning (not error) when data is missing for key", async function () {
      document.body.innerHTML = `<div id="plot-test"></div>`;
      const warnSpy = sinon.spy(console, "warn");
      const errorSpy = sinon.spy(console, "error");

      await plotModule.validateAndPlotElement("plot-test", {}, "foo");

      // handleInvalidData should call console.warn when warnOnly=true
      expect(warnSpy.called).to.be.true;
      // Verify warning message about missing data
      let foundWarning = false;
      for (let i = 0; i < warnSpy.callCount; i++) {
        const args = warnSpy.getCall(i).args;
        if (args.some((arg) => String(arg).includes("No data found"))) {
          foundWarning = true;
          break;
        }
      }
      expect(foundWarning).to.be.true;
      warnSpy.restore();
      errorSpy.restore();
    });
  });

  describe("makePlot with data-source validation", function () {
    it("should handle plot elements with data-source attribute correctly", async function () {
      setupRequestDom({
        site: "North",
        date: "2025-12-16",
        ob: "123",
        telId: "1",
        plotContainers: ["plot-foo"],
      });
      document.getElementById("plot-foo").setAttribute("data-source", "foo");

      const mockData = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "scatterplot" } },
          fetchedData: { x: [1, 2], y: [3, 4] },
        },
      };

      const errorSpy = sinon.spy(console, "error");
      plotModule.makePlot(() => Promise.resolve(mockData));
      await new Promise((r) => setTimeout(r, 10));

      // Should not have errors about missing data-source
      const callsWithMissingDataSource = errorSpy
        .getCalls()
        .filter((call) => String(call.args[0]).includes("Missing data-source"));
      expect(callsWithMissingDataSource).to.have.length(0);

      errorSpy.restore();
    });

    // Covered in makePlot: "shows warning error when plot container misses data-source attribute"
  });

  describe("validateAndPlotElement with cameraview plotting", function () {
    it("should successfully plot cameraview when ensureCameraViewInitialized returns true", async function () {
      document.body.innerHTML = `<div id="plot-foo" style="color: red;"></div>`;

      const mockedResizeListeners = {};
      const updateCameraSpy = sinon.stub().resolves({});

      const { modules } = buildEsmockMocks({
        cameraOverrides: {
          ensureCameraViewInitialized: sinon.stub().returns(true),
          updateCameraView: updateCameraSpy,
          bootstrapCameraViews: sinon.stub(),
        },
        baseOverrides: { resizeListeners: mockedResizeListeners },
      });

      const plotModuleMocked = await esmock(
        "../static/js/plot.js",
        modules,
        { url: import.meta.url }
      );

      // Set up config for cameraview
      window.PLOT_CONFIGURATIONS = {
        foo: { plotType: "cameraview" },
      };

      // Set up the container to have a __cameraViewer property to pass internal checks
      const container = document.getElementById("plot-foo");
      container.__cameraViewer = { initialized: true };

      const data = {
        foo: {
          fetchedMetadata: { plotConfiguration: { plotType: "cameraview" } },
          fetchedData: { x: [1, 2, 3] },
        },
      };

      await plotModuleMocked.validateAndPlotElement("plot-foo", data, "foo");

      // The updateCameraView stub should have been called with correct arguments
      expect(updateCameraSpy.called).to.be.true;
      expect(updateCameraSpy.firstCall.args[0]).to.equal("plot-foo");
      // Verify the entire data object (with fetchedData and fetchedMetadata) was passed
      expect(updateCameraSpy.firstCall.args[1]).to.deep.equal(data.foo);
    });
  });

  describe("checkXYLength with unknown plot type", function () {
    it("should throw TypeError for malformed input with unknown plot type", function () {
      document.body.innerHTML = `<div id="plot-test"></div>`;
      const data = {
        foo: {
          fetchedData: { x: [1, 2], y: [3, 4] },
        },
      };

      expect(() =>
        plotModule.checkXYLength(data, "foo", "plot-test", "unknowntype")
      ).to.throw(TypeError, /fetchedData|Cannot destructure/);
    });
  });
});
