import { expect } from "chai";

describe("Tests for 'cameraUtilities.js':", function () {
    let mod;

    before(async function () {
        mod = await import("../static/js/cameraUtilities.js");
    });

    ["plasma", "not-a-palette"].forEach((palette) => {
        it(`setColorPalette handles '${palette}' and still yields a valid color`, function () {
            expect(() => mod.setColorPalette(palette)).to.not.throw();
            const color = mod.get_color(0, 1, 0.2);
            expect(color).to.be.a("string");
        });
    });

    it("get_color should return gray for invalid values", function () {
        [null, undefined, NaN].forEach((value) => {
            expect(mod.get_color(0, 1, value)).to.equal("#BEBEBE");
        });
    });

    it("get_color should not return gray for valid values", function () {
        mod.setColorPalette("plasma");
        const color = mod.get_color(0, 10, 5);
        expect(color).to.not.equal("#BEBEBE");
    });

    it("getAvailablePalettes should include viridis", function () {
        const palettes = mod.getAvailablePalettes();
        expect(palettes).to.be.an("array");
        expect(palettes).to.include("viridis");
    });
});
