"""CTAO DPPS Data Quality Pipeline Web Application.

This module provides the main entry point for the Qualpipe web application.
"""

from .backend import __all__ as backend_all
from .version import __version__

__all__ = backend_all + [__version__]
