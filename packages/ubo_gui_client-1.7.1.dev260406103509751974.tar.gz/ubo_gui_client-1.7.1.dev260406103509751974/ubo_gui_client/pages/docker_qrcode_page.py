"""Docker QR code page widget for the GUI client."""

from __future__ import annotations

import json
import pathlib

from kivy.lang.builder import Builder
from kivy.properties import ListProperty, NumericProperty, StringProperty

from ubo_gui_client.gui_utils import UboPageWidget


class DockerQRCodePage(UboPageWidget):
    """QR code for the container's url (ip and port)."""

    ips: list[str] = ListProperty()
    port: str = StringProperty()
    index: int = NumericProperty(0)

    def __init__(self, **kwargs: object) -> None:
        """Initialize with JSON-encoded ips if passed as string."""
        ips_raw = kwargs.get('ips')
        if isinstance(ips_raw, str):
            kwargs['ips'] = json.loads(ips_raw)
        super().__init__(**kwargs)

    def go_down(self: DockerQRCodePage) -> None:
        """Go down."""
        self.index = (self.index + 1) % len(self.ips)
        self.ids.slider.animated_value = len(self.ips) - 1 - self.index

    def go_up(self: DockerQRCodePage) -> None:
        """Go up."""
        self.index = (self.index - 1) % len(self.ips)
        self.ids.slider.animated_value = len(self.ips) - 1 - self.index


Builder.load_file(
    pathlib.Path(__file__)
    .parent.joinpath('docker_qrcode_page.kv')
    .resolve()
    .as_posix(),
)
