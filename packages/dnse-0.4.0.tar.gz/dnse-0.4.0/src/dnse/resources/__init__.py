"""DNSE API resource classes."""
