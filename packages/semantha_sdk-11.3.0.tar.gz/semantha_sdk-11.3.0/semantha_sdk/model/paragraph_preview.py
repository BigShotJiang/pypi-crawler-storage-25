from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from typing import Optional

@dataclass
class ParagraphPreview:
    """ author semantha, this is a generated class do not change manually! """
    id: str
    type: str
    text: Optional[str] = None
    data_url_image: Optional[str] = None

ParagraphPreviewSchema = class_schema(ParagraphPreview, base_schema=RestSchema)
