from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from semantha_sdk.model.prompt_validation_template import PromptValidationTemplate
from typing import Dict
from typing import List
from typing import Optional

@dataclass
class PromptValidationRequest:
    """ author semantha, this is a generated class do not change manually! """
    prompt_template: PromptValidationTemplate
    # DEPRECATED: Use argumentMap instead.
    arguments: Optional[List[str]] = None
    # Preferred argument transport. Use this field instead of arguments.
    argument_map: Optional[Dict[str, str]] = None

PromptValidationRequestSchema = class_schema(PromptValidationRequest, base_schema=RestSchema)
