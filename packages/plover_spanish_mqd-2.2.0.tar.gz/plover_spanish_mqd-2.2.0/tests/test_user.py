import json
import os
import unittest

from plover_spanish_mqd import spanish_mqd_single, system

from . import detectDuplicateKeys

DICT = os.path.join(os.path.dirname(__file__), "..", "plover_spanish_mqd", "dictionaries", "user_es.json")


class TestUser(unittest.TestCase):
	def setUp(self):
		self.keys = "".join(system.KEYS)
		self.singleDict = spanish_mqd_single.dict
		with open(DICT, encoding="utf-8") as f:
			self.dict = json.load(f, object_pairs_hook=detectDuplicateKeys)

	def tearDown(self):
		self.keys = None
		self.singleDict = None
		self.dict = None

	def test_keyOrder(self):
		assert self.dict is not None
		assert self.keys is not None
		for k, v in self.dict.items():
			prevIndex = -1
			curIndex = -1
			for char in k:
				if char == "/":
					prevIndex = -1
					curIndex = -1
					continue
				curIndex = self.keys.find(char)
				self.assertTrue(curIndex > prevIndex, k)
				prevIndex = curIndex

	def test_valueType(self):
		assert self.dict is not None
		for k, v in self.dict.items():
			self.assertTrue(isinstance(v, str), k)

	def test_ValueContent(self):
		assert self.dict is not None
		for k, v in self.dict.items():
			self.assertFalse("//" in v, k)

	def test_duplicateKeysInSingle(self):
		assert self.dict is not None
		assert self.singleDict is not None
		dictKeys = self.dict.keys()
		duplicateKeys = []
		value = ""
		for k, v in self.singleDict.items():
			if k in dictKeys:
				value = v[0]
				if value == "":
					continue
				duplicateKeys.append(k)
		self.assertListEqual(duplicateKeys, [], "\rn".join(duplicateKeys))
