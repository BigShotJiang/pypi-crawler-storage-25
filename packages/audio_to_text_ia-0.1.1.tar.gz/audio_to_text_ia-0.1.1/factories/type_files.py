from typing import List, Any, Dict, Optional, TypeVar, Tuple, Union
import os

import shutil
from commands.base import Command
from exceptions.command_exceptions import UnsupportedCommandException, FileProcessingException
from services.whisper_service import WhisperService
from utils.logger import logger
from utils.file_processor import FileProcessor
from config.settings import Settings

# Tipo de resultado para los métodos de procesamiento
ProcessResult = Dict[str, Any]

class TypeFiles(Command[ProcessResult]):
    """
    Factory para manejar diferentes tipos de archivos.
    
    Esta clase implementa el patrón Factory para procesar distintos tipos de 
    archivos como audio, video, texto y zip.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    TYPE_AUDIO = "audio"
    TYPE_VIDEO = "video"
    TYPE_TEXT = "text"
    TYPE_ZIP = "zip"
    
    def __init__(self, whisper_model: str = "base"):
        """
        Inicializa la factory TypeFiles y habilita todos los tipos de archivos.
        
        Parameters
        ----------
        whisper_model : str
            Modelo de Whisper a utilizar para procesamiento de audio
        """
        super().__init__()
        
        # Establecer flags por defecto (todos habilitados)
        self._setup_feature_flags()
        
        # Inicializar servicio de Whisper
        self.whisper_service = WhisperService(model_name=whisper_model)
        
        # Inicializar extensiones de archivo desde configuración
        self.file_extensions = Settings.get_file_extensions()
    
    def _setup_feature_flags(self) -> None:
        """
        Configura las feature flags para los tipos de archivos.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        for file_type in [self.TYPE_AUDIO, self.TYPE_VIDEO, self.TYPE_TEXT, self.TYPE_ZIP]:
            self.feature_flags.set_flag(self.get_feature_name(file_type), True)
    
    def get_available_subcommands(self) -> List[str]:
        """
        Obtiene la lista de tipos de archivos disponibles.
        
        Returns
        -------
        List[str]
            Lista de tipos de archivos disponibles
        """
        available = []
        
        for file_type in [self.TYPE_AUDIO, self.TYPE_VIDEO, self.TYPE_TEXT, self.TYPE_ZIP]:
            if self.feature_flags.is_enabled(self.get_feature_name(file_type)):
                available.append(file_type)
            
        return available
    
    def set_whisper_model(self, model_name: str) -> None:
        """
        Establece el modelo de Whisper a utilizar.
        
        Parameters
        ----------
        model_name : str
            Nombre del modelo de Whisper
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self.whisper_service.set_model(model_name)
    
    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Obtiene los modelos de Whisper disponibles.
        
        Returns
        -------
        Dict[str, Dict[str, Any]]
            Diccionario con información de los modelos
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return self.whisper_service.get_available_models()
    
    def execute(self, type_file: Optional[str] = None, **kwargs) -> ProcessResult:
        """
        Procesa un archivo del tipo especificado.
        
        Parameters
        ----------
        type_file : Optional[str]
            Tipo de archivo a procesar (audio, video, text, zip)
        **kwargs
            Argumentos adicionales para el procesamiento
            
        Returns
        -------
        ProcessResult
            Resultado del procesamiento
            
        Raises
        ------
        UnsupportedCommandException
            Si el tipo de archivo no está soportado
        """
        if not self.is_available:
            logger.warning("La factory TypeFiles no está disponible globalmente.")
            return self._create_error_response("La factory no está disponible globalmente")
            
        available_types = self.get_available_subcommands()
        
        if type_file is None:
            return self._create_info_response(self._suggest_types(available_types))
        
        if type_file not in available_types:
            raise UnsupportedCommandException(type_file, available_types)
        
        # Verificar que la característica esté disponible
        feature_name = self.get_feature_name(type_file)
        self.check_feature_available(feature_name)
        
        # Procesar el tipo de archivo correspondiente
        file_processors = {
            self.TYPE_AUDIO: self._process_audio,
            self.TYPE_VIDEO: self._process_video,
            self.TYPE_TEXT: self._process_text,
            self.TYPE_ZIP: self._process_zip
        }
        
        return file_processors[type_file](**kwargs)
    
    def _suggest_types(self, available_types: List[str]) -> str:
        """
        Sugiere los tipos de archivos disponibles.
        
        Parameters
        ----------
        available_types : List[str]
            Lista de tipos de archivos disponibles
            
        Returns
        -------
        str
            Mensaje con sugerencias de tipos de archivos
        """
        types_str = ", ".join(available_types)
        return f"Por favor, especifique uno de los siguientes tipos de archivo: {types_str}"
    
    def _validate_file_input(
        self, 
        file: Optional[str] = None,
        file_type: str = ""
    ) -> Optional[Dict[str, Any]]:
        """
        Valida la entrada de archivo.
        
        Parameters
        ----------
        file : Optional[str]
            Ruta al archivo a procesar
        file_type : str
            Tipo de archivo para el mensaje de error
            
        Returns
        -------
        Optional[Dict[str, Any]]
            Respuesta de error si la validación falla, None si es válido
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not file:
            return self._create_error_response(f"No se proporcionó un archivo de {file_type}")
        
        if not FileProcessor.validate_file_exists(file):
            return self._create_error_response(f"El archivo no existe: {file}")
            
        return None
    
    def _create_error_response(self, message: str, file: str = "") -> Dict[str, Any]:
        """
        Crea una respuesta de error estándar.
        
        Parameters
        ----------
        message : str
            Mensaje de error
        file : str
            Ruta al archivo (opcional)
            
        Returns
        -------
        Dict[str, Any]
            Respuesta de error formateada
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        response = {
            "message": message,
            "status": "error"
        }
        
        if file:
            response["file"] = file
            
        return response
    
    def _create_info_response(self, message: str) -> Dict[str, Any]:
        """
        Crea una respuesta informativa estándar.
        
        Parameters
        ----------
        message : str
            Mensaje informativo
            
        Returns
        -------
        Dict[str, Any]
            Respuesta informativa formateada
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return {
            "message": message,
            "status": "info"
        }
    
    def _create_success_response(
        self,
        file: str,
        message: str,
        **additional_data
    ) -> Dict[str, Any]:
        """
        Crea una respuesta de éxito estándar.
        
        Parameters
        ----------
        file : str
            Ruta al archivo procesado
        message : str
            Mensaje de éxito
        **additional_data
            Datos adicionales para incluir en la respuesta
            
        Returns
        -------
        Dict[str, Any]
            Respuesta de éxito formateada
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        response = {
            "message": message,
            "status": "success",
            "file": file
        }
        
        response.update(additional_data)
        
        return response
    
    def _process_audio(
        self, 
        file: Optional[str] = None, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        **kwargs
    ) -> ProcessResult:
        """
        Procesa un archivo de audio.
        
        Parameters
        ----------
        file : Optional[str]
            Ruta al archivo de audio a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        **kwargs
            Argumentos adicionales para el procesamiento
            
        Returns
        -------
        ProcessResult
            Resultado del procesamiento con la transcripción
        """
        # Validar entrada
        validation_error = self._validate_file_input(file, "audio")
        if validation_error:
            return validation_error
        
        try:
            # Cargar el modelo Whisper
            self.whisper_service.load_model()
            
            # Procesar el audio con el nuevo método unificado
            result = self.whisper_service.process_audio(
                file,
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp
            )
            
            # Determinar tarea (transcripción o traducción)
            task = WhisperService.TASK_TRANSLATE if translate else WhisperService.TASK_TRANSCRIBE
            
            # Crear respuesta de éxito
            response = self._create_success_response(
                file=file,
                message="Archivo de audio procesado correctamente",
                transcription=result["transcription"],
                language=result["language"],
                segments=result.get("segments", []),
                is_english=result["is_english"],
                transcription_file=result["transcription_file"],
                task=task
            )
            
            # Agregar información de traducción si existe
            if translate and not result["is_english"] and result.get("translation"):
                response.update({
                    "translation": result["translation"],
                    "translated_segments": result.get("translated_segments", []),
                    "translation_file": result["translation_file"]
                })
            
            return response
            
        except FileProcessingException as e:
            logger.error(f"Error de procesamiento: {str(e)}")
            return self._create_error_response(str(e), file)
        except Exception as e:
            logger.error(f"Error al procesar archivo de audio: {str(e)}", exc_info=True)
            return self._create_error_response(f"Error al procesar archivo de audio: {str(e)}", file)

    def _process_video(
        self, 
        file: Optional[str] = None, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        **kwargs
    ) -> ProcessResult:
        """
        Procesa un archivo de video.
        
        Parameters
        ----------
        file : Optional[str]
            Ruta al archivo de video a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        **kwargs
            Argumentos adicionales para el procesamiento
            
        Returns
        -------
        ProcessResult
            Resultado del procesamiento con la transcripción
        """
        # Validar entrada
        validation_error = self._validate_file_input(file, "video")
        if validation_error:
            return validation_error
        
        audio_file = None
        try:
            # Extraer audio del video
            audio_file = self.whisper_service.extract_audio_from_video(file)
            
            # Procesar el audio extraído
            audio_result = self._process_audio(
                file=audio_file, 
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp,
                **kwargs
            )
            
            # Modificar el resultado para reflejar que es un video
            if audio_result["status"] == "success":
                audio_result["file"] = file  # Reemplazar con la ruta del video original
                audio_result["message"] = "Archivo de video procesado correctamente"
            
            return audio_result
            
        except FileProcessingException as e:
            logger.error(f"Error de procesamiento: {str(e)}")
            return self._create_error_response(str(e), file)
        except Exception as e:
            logger.error(f"Error al procesar archivo de video: {str(e)}", exc_info=True)
            return self._create_error_response(f"Error al procesar archivo de video: {str(e)}", file)
        finally:
            # Limpiar archivos temporales
            if audio_file:
                FileProcessor.clean_temp_file(audio_file)
    
    def _process_text(
        self, 
        file: Optional[str] = None,
        **kwargs
    ) -> ProcessResult:
        """
        Procesa un archivo de texto.
        
        Parameters
        ----------
        file : Optional[str]
            Ruta al archivo de texto a procesar
        **kwargs
            Argumentos adicionales para el procesamiento
            
        Returns
        -------
        ProcessResult
            Resultado del procesamiento
        """
        # Validar entrada
        validation_error = self._validate_file_input(file, "texto")
        if validation_error:
            return validation_error
            
        try:
            # Leer el contenido del archivo
            with open(file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # En una implementación más completa, se procesaría el contenido
            # según los parámetros adicionales proporcionados
            
            return self._create_success_response(
                file=file,
                message="Archivo de texto leído correctamente",
                content=content[:200] + "..." if len(content) > 200 else content,
                size=len(content),
                format="text"
            )
        except Exception as e:
            logger.error(f"Error al procesar archivo de texto: {str(e)}", exc_info=True)
            return self._create_error_response(f"Error al procesar archivo de texto: {str(e)}", file)
    
    def _process_zip(
        self, 
        file: Optional[str] = None,
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        **kwargs
    ) -> ProcessResult:
        """
        Procesa un archivo zip extrayendo y procesando su contenido.
        
        Parameters
        ----------
        file : Optional[str]
            Ruta al archivo zip a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        **kwargs
            Argumentos adicionales para el procesamiento
            
        Returns
        -------
        ProcessResult
            Resultado del procesamiento combinado de todos los archivos
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Validar entrada
        validation_error = self._validate_file_input(file, "zip")
        if validation_error:
            return validation_error
            
        temp_dir = None
        try:
            # Obtener información básica del archivo
            file_info = FileProcessor.get_file_info(file)
            
            # Extraer archivos ZIP a directorio temporal
            temp_dir = FileProcessor.extract_zip_to_temp_dir(file)
            
            # Buscar archivos por tipo en el directorio temporal
            audio_extensions = self.file_extensions.get(self.TYPE_AUDIO, [])
            video_extensions = self.file_extensions.get(self.TYPE_VIDEO, [])
            text_extensions = self.file_extensions.get(self.TYPE_TEXT, [])
            
            audio_files = FileProcessor.list_files_by_extensions(temp_dir, audio_extensions, recursive=True)
            video_files = FileProcessor.list_files_by_extensions(temp_dir, video_extensions, recursive=True)
            text_files = FileProcessor.list_files_by_extensions(temp_dir, text_extensions, recursive=True)
            
            # Resultados para cada tipo de archivo
            audio_results = []
            video_results = []
            text_results = []
            
            # Procesar archivos de audio
            for audio_file in audio_files:
                result = self._process_audio(
                    file=audio_file,
                    source_language=source_language,
                    target_language=target_language,
                    translate=translate,
                    timestamp=timestamp,
                    **kwargs
                )
                if result.get("status") == "success":
                    audio_results.append(result)
            
            # Procesar archivos de video
            for video_file in video_files:
                result = self._process_video(
                    file=video_file,
                    source_language=source_language,
                    target_language=target_language,
                    translate=translate,
                    timestamp=timestamp,
                    **kwargs
                )
                if result.get("status") == "success":
                    video_results.append(result)
            
            # Procesar archivos de texto
            for text_file in text_files:
                result = self._process_text(file=text_file, **kwargs)
                if result.get("status") == "success":
                    text_results.append(result)
            
            # Combinar todos los resultados
            all_results = audio_results + video_results + text_results
            
            # Contar los archivos procesados exitosamente
            total_processed = len(all_results)
            total_files = len(audio_files) + len(video_files) + len(text_files)
            
            if total_processed == 0:
                if total_files == 0:
                    message = "El archivo ZIP no contiene archivos compatibles para procesar"
                else:
                    message = f"No se pudo procesar ninguno de los {total_files} archivos encontrados en el ZIP"
                
                return self._create_error_response(message, file)
            
            # Preparar resultado combinado para ser compatible con la interfaz existente
            combined_result = {
                "status": "success",
                "message": f"Archivo ZIP procesado: {total_processed}/{total_files} archivos procesados correctamente",
                "file": file,
                "format": "zip",
                "zip_info": {
                    "size_mb": file_info.get("size_mb", 0),
                    "extracted_files": total_files,
                    "audio_files": len(audio_files),
                    "video_files": len(video_files),
                    "text_files": len(text_files),
                    "processed_files": total_processed,
                },
                "processed_results": all_results,
            }
            
            # Seleccionar el primer resultado exitoso para mantener compatibilidad
            # con la interfaz existente que espera una transcripción única
            primary_result = all_results[0]
            
            # Añadir las propiedades necesarias del primer resultado exitoso
            for key in ["transcription", "language", "is_english", "transcription_file", "segments"]:
                if key in primary_result:
                    combined_result[key] = primary_result[key]
            
            # Añadir información de traducción si existe
            if translate and "translation" in primary_result:
                for key in ["translation", "translation_file", "translated_segments"]:
                    if key in primary_result:
                        combined_result[key] = primary_result[key]
            
            return combined_result
            
        except FileProcessingException as e:
            logger.error(f"Error de procesamiento: {str(e)}")
            return self._create_error_response(str(e), file)
        except Exception as e:
            logger.error(f"Error al procesar archivo ZIP: {str(e)}", exc_info=True)
            return self._create_error_response(f"Error al procesar archivo ZIP: {str(e)}", file)
        finally:
            # Limpiar directorio temporal
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                    logger.info(f"Directorio temporal eliminado: {temp_dir}")
                except Exception as e:
                    logger.warning(f"No se pudo eliminar el directorio temporal {temp_dir}: {str(e)}")