from abc import ABC, abstractmethod
from typing import List, Any, Dict, Optional, TypeVar, Generic

from utils.feature_flags import FeatureFlags
from exceptions.command_exceptions import FeatureNotAvailableException

# Tipo genérico para el resultado de un comando
T = TypeVar('T')

class Command(ABC, Generic[T]):
    """
    Clase base abstracta para todos los comandos.
    
    Esta clase define la interfaz que deben implementar todos los comandos
    y proporciona funcionalidades comunes como la gestión de feature flags.
    
    Type Parameters
    --------------
    T
        Tipo de resultado que devuelve el comando al ejecutarse
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(self, feature_prefix: Optional[str] = None):
        """
        Inicializa un comando con acceso al gestor de feature flags.
        
        Parameters
        ----------
        feature_prefix : Optional[str]
            Prefijo para las feature flags de este comando,
            por defecto se usa el nombre de la clase
        """
        self.feature_flags = FeatureFlags()
        self._is_available = True
        self._feature_prefix = feature_prefix or self.__class__.__name__
    
    @property
    def is_available(self) -> bool:
        """
        Indica si el comando está disponible globalmente.
        
        Returns
        -------
        bool
            True si el comando está disponible, False en caso contrario
        """
        return self._is_available
    
    @is_available.setter
    def is_available(self, value: bool) -> None:
        """
        Establece la disponibilidad global del comando.
        
        Parameters
        ----------
        value : bool
            Nuevo valor de disponibilidad
        """
        self._is_available = bool(value)
    
    @abstractmethod
    def execute(self, **kwargs) -> T:
        """
        Ejecuta el comando con los argumentos proporcionados.
        
        Parameters
        ----------
        **kwargs
            Argumentos específicos del comando
            
        Returns
        -------
        T
            Resultado de la ejecución del comando
        """
        pass
    
    @abstractmethod
    def get_available_subcommands(self) -> List[str]:
        """
        Obtiene la lista de subcomandos disponibles.
        
        Returns
        -------
        List[str]
            Lista de nombres de subcomandos disponibles
        """
        pass
    
    def check_feature_available(self, feature_name: str) -> None:
        """
        Verifica si una característica está disponible.
        
        Parameters
        ----------
        feature_name : str
            Nombre de la característica a verificar
            
        Raises
        ------
        FeatureNotAvailableException
            Si la característica no está disponible
        """
        if not self.feature_flags.is_enabled(feature_name):
            raise FeatureNotAvailableException(feature_name)
    
    def get_feature_name(self, subcommand: str) -> str:
        """
        Obtiene el nombre completo de una feature flag para un subcomando.
        
        Parameters
        ----------
        subcommand : str
            Nombre del subcomando
            
        Returns
        -------
        str
            Nombre completo de la feature flag
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return f"{self._feature_prefix}.{subcommand}"
    
    def enable_subcommand(self, subcommand: str) -> None:
        """
        Habilita un subcomando específico.
        
        Parameters
        ----------
        subcommand : str
            Nombre del subcomando a habilitar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        feature_name = self.get_feature_name(subcommand)
        self.feature_flags.enable(feature_name)
    
    def disable_subcommand(self, subcommand: str) -> None:
        """
        Deshabilita un subcomando específico.
        
        Parameters
        ----------
        subcommand : str
            Nombre del subcomando a deshabilitar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        feature_name = self.get_feature_name(subcommand)
        self.feature_flags.disable(feature_name)
