from typing import List, Any, Dict, Optional, Union, TypeVar
import os

from commands.base import Command
from exceptions.command_exceptions import UnsupportedCommandException, FileProcessingException
from factories.type_files import TypeFiles
from utils.logger import logger
from services.summary_service import SummaryService
from services.whatsapp_service import WhatsAppChatService
from utils.file_processor import FileProcessor

# Tipo de resultado para el comando Generate
GenerateResult = Union[str, Dict[str, Any]]

class Generate(Command[GenerateResult]):
    """
    Comando para generar diferentes tipos de contenido a partir de archivos.
    
    Este comando permite generar resúmenes, subtítulos, etc. a partir de archivos
    de audio, video, texto, etc.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    SUBCOMMAND_RESUMEN = "resumen"
    SUBCOMMAND_SUBTITLE = "subtitle"
    SUBCOMMAND_ZIP_WHATSAPP_CHAT = "zip_whatsapp_chat"
    
    def __init__(self, whisper_model: str = "base"):
        """
        Inicializa el comando Generate y habilita todos los subcomandos.
        
        Parameters
        ----------
        whisper_model : str
            Modelo de Whisper a utilizar
        """
        super().__init__()
        
        # Establecer flags por defecto (todos habilitados)
        self._setup_feature_flags()
        
        # Inicializar factory de tipos de archivos
        self.type_files_factory = TypeFiles(whisper_model=whisper_model)
        
        # Inicializar servicio de WhatsApp
        self.whatsapp_service = WhatsAppChatService(self.type_files_factory.whisper_service)
    
    def _setup_feature_flags(self) -> None:
        """
        Configura las feature flags para los subcomandos.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        for subcommand in [self.SUBCOMMAND_RESUMEN, self.SUBCOMMAND_SUBTITLE, self.SUBCOMMAND_ZIP_WHATSAPP_CHAT]:
            self.feature_flags.set_flag(self.get_feature_name(subcommand), True)
    
    def get_available_subcommands(self) -> List[str]:
        """
        Obtiene la lista de subcomandos disponibles para Generate.
        
        Returns
        -------
        List[str]
            Lista de nombres de subcomandos disponibles
        """
        available = []
        
        for subcommand in [self.SUBCOMMAND_RESUMEN, self.SUBCOMMAND_SUBTITLE, self.SUBCOMMAND_ZIP_WHATSAPP_CHAT]:
            if self.feature_flags.is_enabled(self.get_feature_name(subcommand)):
                available.append(subcommand)
            
        return available
    
    def set_whisper_model(self, model_name: str) -> None:
        """
        Establece el modelo de Whisper a utilizar.
        
        Parameters
        ----------
        model_name : str
            Nombre del modelo de Whisper
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self.type_files_factory.set_whisper_model(model_name)
    
    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Obtiene los modelos de Whisper disponibles.
        
        Returns
        -------
        Dict[str, Dict[str, Any]]
            Diccionario con información de los modelos
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return self.type_files_factory.get_available_models()
    
    def execute(self, subcommand: Optional[str] = None, **kwargs) -> GenerateResult:
        """
        Ejecuta el comando Generate con el subcomando especificado.
        
        Parameters
        ----------
        subcommand : Optional[str]
            Subcomando a ejecutar (resumen, subtitle, zip_whatsapp_chat)
        **kwargs
            Argumentos adicionales para el subcomando
            
        Returns
        -------
        GenerateResult
            Resultado de la ejecución del subcomando
            
        Raises
        ------
        UnsupportedCommandException
            Si el subcomando no está soportado
        """
        if not self.is_available:
            logger.warning("El comando Generate no está disponible globalmente.")
            return self._create_error_response("El comando no está disponible globalmente")
            
        available_subcommands = self.get_available_subcommands()
        
        if subcommand is None:
            return self._suggest_subcommands(available_subcommands)
        
        if subcommand not in available_subcommands:
            raise UnsupportedCommandException(subcommand, available_subcommands)
        
        # Verificar que la característica esté disponible
        feature_name = self.get_feature_name(subcommand)
        self.check_feature_available(feature_name)
        
        # Ejecutar el subcomando correspondiente
        if subcommand == self.SUBCOMMAND_RESUMEN:
            return self._generate_resumen(**kwargs)
        elif subcommand == self.SUBCOMMAND_SUBTITLE:
            return self._generate_subtitle(**kwargs)
        elif subcommand == self.SUBCOMMAND_ZIP_WHATSAPP_CHAT:
            return self._generate_zip_whatsapp_chat(**kwargs)
        
        # Este punto no debería alcanzarse debido a la validación anterior
        raise UnsupportedCommandException(subcommand, available_subcommands)
    
    def _suggest_subcommands(self, available_subcommands: List[str]) -> str:
        """
        Sugiere los subcomandos disponibles.
        
        Parameters
        ----------
        available_subcommands : List[str]
            Lista de subcomandos disponibles
            
        Returns
        -------
        str
            Mensaje con sugerencias de subcomandos
        """
        subcommands_str = ", ".join(available_subcommands)
        return f"Por favor, especifique uno de los siguientes subcomandos de Generate: {subcommands_str}"
    
    def _create_error_response(self, message: str, file: str = "") -> Dict[str, Any]:
        """
        Crea una respuesta de error estándar.
        
        Parameters
        ----------
        message : str
            Mensaje de error
        file : str
            Ruta al archivo (opcional)
            
        Returns
        -------
        Dict[str, Any]
            Respuesta de error formateada
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        response = {
            "message": message,
            "status": "error"
        }
        
        if file:
            response["file"] = file
            
        return response
    
    def _validate_common_params(
        self, 
        type_file: Optional[str] = None, 
        file: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Valida los parámetros comunes entre los subcomandos.
        
        Parameters
        ----------
        type_file : Optional[str]
            Tipo de archivo a procesar
        file : Optional[str]
            Ruta al archivo a procesar
            
        Returns
        -------
        Optional[Dict[str, Any]]
            Respuesta de error si la validación falla, None si es válido
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not type_file or not file:
            return self._create_error_response(
                "Debe especificar el tipo de archivo y la ruta"
            )
        
        if not FileProcessor.validate_file_exists(file):
            return self._create_error_response(
                f"El archivo no existe: {file}",
                file
            )
            
        return None
    
    def _generate_zip_whatsapp_chat(
        self,
        type_file: Optional[str] = None,
        file: Optional[str] = None,
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        fecha_inicio: Optional[str] = None,
        fecha_fin: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Genera las transcripciones para un chat de WhatsApp en formato ZIP.
        
        Este comando procesa un archivo ZIP que contiene un chat de WhatsApp,
        identifica los archivos de audio y video mencionados en el chat,
        los transcribe, y modifica el archivo de chat para incluir las transcripciones.
        
        Parameters
        ----------
        type_file : Optional[str]
            Tipo de archivo (debe ser 'zip')
        file : Optional[str]
            Ruta al archivo ZIP a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        fecha_inicio : Optional[str]
            Fecha de inicio para filtrar mensajes (formato DD/MM/YYYY)
        fecha_fin : Optional[str]
            Fecha de fin para filtrar mensajes (formato DD/MM/YYYY)
        **kwargs
            Argumentos adicionales para la generación
            
        Returns
        -------
        Dict[str, Any]
            Resultado con la información del procesamiento
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Validar parámetros comunes
        validation_error = self._validate_common_params(type_file, file)
        if validation_error:
            return validation_error
        
        # Verificar que el tipo de archivo es ZIP
        if type_file != 'zip':
            return self._create_error_response(
                f"El tipo de archivo debe ser 'zip' para este comando, no '{type_file}'",
                file
            )
        
        try:
            # Procesar el archivo ZIP de WhatsApp
            result = self.whatsapp_service.process_whatsapp_zip(
                file,
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp,
                fecha_inicio=fecha_inicio,
                fecha_fin=fecha_fin
            )
            
            return {
                "status": "success",
                "message": f"Chat de WhatsApp procesado exitosamente con {result.get('transcriptions_count', 0)} transcripciones",
                "file": file,
                "output_file": result.get("output_file", ""),
                "transcriptions_count": result.get("transcriptions_count", 0),
                "audio_files_count": result.get("audio_files_count", 0),
                "video_files_count": result.get("video_files_count", 0),
                "task": "translate" if translate else "transcribe"
            }
            
        except FileProcessingException as e:
            logger.error(f"Error al procesar chat de WhatsApp: {str(e)}")
            return self._create_error_response(str(e), file)
        except Exception as e:
            logger.error(f"Error inesperado al procesar chat de WhatsApp: {str(e)}", exc_info=True)
            return self._create_error_response(
                f"Error inesperado al procesar chat de WhatsApp: {str(e)}",
                file
            )
    
    def _generate_resumen(
        self, 
        type_file: Optional[str] = None, 
        file: Optional[str] = None, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Genera un resumen a partir de un archivo.
        
        Parameters
        ----------
        type_file : Optional[str]
            Tipo de archivo (audio, video, text, zip)
        file : Optional[str]
            Ruta al archivo a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        **kwargs
            Argumentos adicionales para la generación
            
        Returns
        -------
        Dict[str, Any]
            Resultado con el resumen generado
        """
        # Validar parámetros comunes
        validation_error = self._validate_common_params(type_file, file)
        if validation_error:
            return validation_error
        
        try:
            # Procesar el archivo según su tipo
            result = self.type_files_factory.execute(
                type_file=type_file, 
                file=file, 
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp,
                **kwargs
            )
            
            # Si el procesamiento fue exitoso y se trata de audio o video
            if self._is_successful_transcription_result(result):
                return self._process_successful_transcription(
                    result, 
                    file, 
                    timestamp, 
                    translate, 
                    type_file
                )
            else:
                return self._handle_unsuccessful_result(result, type_file, file)
                
        except Exception as e:
            logger.error(f"Error al generar resumen: {str(e)}", exc_info=True)
            return self._create_error_response(
                f"Error al generar resumen: {str(e)}",
                file
            )
    
    def _is_successful_transcription_result(self, result: Dict[str, Any]) -> bool:
        """
        Verifica si el resultado del procesamiento es una transcripción exitosa.
        
        Parameters
        ----------
        result : Dict[str, Any]
            Resultado del procesamiento
            
        Returns
        -------
        bool
            True si es una transcripción exitosa, False en caso contrario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return (isinstance(result, dict) and 
                result.get("status") == "success" and 
                "transcription" in result)
    
    def _process_successful_transcription(
        self,
        result: Dict[str, Any],
        file: str,
        timestamp: str,
        translate: bool,
        type_file: str
    ) -> Dict[str, Any]:
        """
        Procesa un resultado exitoso de transcripción.
        
        Parameters
        ----------
        result : Dict[str, Any]
            Resultado del procesamiento
        file : str
            Ruta al archivo original
        timestamp : str
            Timestamp para el nombre del archivo
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        type_file : str
            Tipo de archivo procesado
            
        Returns
        -------
        Dict[str, Any]
            Resultado con el resumen generado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        transcription = result["transcription"]
        
        # Generar archivo de resumen usando el servicio para la transcripción
        summary_path = SummaryService.generate_summary_file(
            transcription, 
            file, 
            timestamp, 
            is_translation=False
        )
        
        # Preparar la respuesta base
        response = {
            "message": f"Resumen generado correctamente para {type_file}",
            "status": "success",
            "summary": SummaryService.summarize_text(transcription),
            "summary_file": summary_path,
            "transcription": transcription,
            "language": result.get("language", "desconocido"),
            "is_english": result.get("is_english", False),
            "file": file,
            "output_file": result.get("transcription_file", ""),
            "task": "translate" if translate else "transcribe"
        }
        
        # Si hay traducción, agregar información relacionada
        if translate and not result.get("is_english", False) and "translation" in result:
            translation = result["translation"]
            
            # Generar resumen de la traducción
            translation_summary_path = SummaryService.generate_summary_file(
                translation, 
                file, 
                timestamp, 
                is_translation=True
            )
            
            # Agregar información de traducción a la respuesta
            response.update({
                "translation": translation,
                "translation_file": result.get("translation_file", ""),
                "translation_summary": SummaryService.summarize_text(translation),
                "translation_summary_file": translation_summary_path,
            })
        elif translate and result.get("is_english", False):
            # Si se pidió traducción pero el idioma ya es inglés
            response["message"] = f"El idioma original ya es inglés. Solo se generó transcripción para {type_file}"
        
        return response

    def _handle_unsuccessful_result(
        self,
        result: Dict[str, Any],
        type_file: str,
        file: str
    ) -> Dict[str, Any]:
        """
        Maneja un resultado no exitoso del procesamiento.
        
        Parameters
        ----------
        result : Dict[str, Any]
            Resultado del procesamiento
        type_file : str
            Tipo de archivo procesado
        file : str
            Ruta al archivo original
            
        Returns
        -------
        Dict[str, Any]
            Respuesta con información de error
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if isinstance(result, dict) and result.get("status") == "error":
            return result  # Devolver el error original
        else:
            return self._create_error_response(
                f"El tipo de archivo {type_file} no admite generación de resumen",
                file
            )
    
    def _generate_subtitle(
        self, 
        type_file: Optional[str] = None, 
        file: Optional[str] = None, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Genera subtítulos a partir de un archivo.
        
        Parameters
        ----------
        type_file : Optional[str]
            Tipo de archivo (audio, video, text, zip)
        file : Optional[str]
            Ruta al archivo a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        **kwargs
            Argumentos adicionales para la generación
            
        Returns
        -------
        Dict[str, Any]
            Resultado con los subtítulos generados
        """
        # Validar parámetros comunes
        validation_error = self._validate_common_params(type_file, file)
        if validation_error:
            return validation_error
        
        try:
            # Procesar el archivo según su tipo
            result = self.type_files_factory.execute(
                type_file=type_file, 
                file=file, 
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp,
                **kwargs
            )
            
            # Si el procesamiento fue exitoso y se trata de audio o video con segmentos
            if self._is_successful_segments_result(result):
                return self._process_successful_segments(
                    result, 
                    file, 
                    timestamp, 
                    translate, 
                    type_file
                )
            else:
                return self._handle_unsuccessful_result(result, type_file, file)
                
        except Exception as e:
            logger.error(f"Error al generar subtítulos: {str(e)}", exc_info=True)
            return self._create_error_response(
                f"Error al generar subtítulos: {str(e)}",
                file
            )
    
    def _is_successful_segments_result(self, result: Dict[str, Any]) -> bool:
        """
        Verifica si el resultado del procesamiento contiene segmentos exitosos.
        
        Parameters
        ----------
        result : Dict[str, Any]
            Resultado del procesamiento
            
        Returns
        -------
        bool
            True si contiene segmentos exitosos, False en caso contrario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return (isinstance(result, dict) and 
                result.get("status") == "success" and 
                "segments" in result)
    
    def _process_successful_segments(
        self,
        result: Dict[str, Any],
        file: str,
        timestamp: str,
        translate: bool,
        type_file: str
    ) -> Dict[str, Any]:
        """
        Procesa un resultado exitoso con segmentos.
        
        Parameters
        ----------
        result : Dict[str, Any]
            Resultado del procesamiento
        file : str
            Ruta al archivo original
        timestamp : str
            Timestamp para el nombre del archivo
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        type_file : str
            Tipo de archivo procesado
            
        Returns
        -------
        Dict[str, Any]
            Resultado con los subtítulos generados
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        segments = result["segments"]
        task = "translate" if translate else "transcribe"
        
        # Generar archivo de subtítulos usando Whisper Service
        subtitle_file = self.type_files_factory.whisper_service.generate_subtitles(
            segments, 
            file, 
            task=task,
            timestamp=timestamp
        )
        
        # Generar también un resumen del contenido
        transcription = result["transcription"]
        summary_path = SummaryService.generate_summary_file(
            transcription, 
            file, 
            timestamp, 
            is_translation=translate
        )
        
        # Generar resumen para la respuesta
        summary = SummaryService.summarize_text(transcription)
        
        return {
            "message": f"Subtítulos generados correctamente para {type_file}",
            "status": "success",
            "subtitle_file": subtitle_file,
            "summary": summary,
            "summary_file": summary_path,
            "segments_count": len(segments),
            "language": result.get("language", "desconocido"),
            "file": file,
            "output_file": result.get("output_file", ""),
            "task": task
        }