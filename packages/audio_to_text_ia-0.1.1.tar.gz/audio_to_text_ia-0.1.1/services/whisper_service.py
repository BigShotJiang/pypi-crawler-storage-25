from typing import Dict, Any, Optional, List, Union, Tuple
import os
import tempfile
import whisper

from utils.logger import logger
from utils.file_processor import FileProcessor
from exceptions.command_exceptions import FileProcessingException

class WhisperService:
    """
    Servicio para transcribir archivos de audio usando Whisper.
    
    Este servicio proporciona una interfaz para interactuar con el modelo
    de reconocimiento de voz Whisper de OpenAI.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    # Modelos disponibles
    MODEL_TINY = "tiny"
    MODEL_BASE = "base"
    MODEL_SMALL = "small"
    MODEL_MEDIUM = "medium"
    MODEL_LARGE = "large"
    MODEL_TURBO = "turbo"
    
    # Modelos específicos para inglés
    MODEL_TINY_EN = "tiny.en"
    MODEL_BASE_EN = "base.en"
    MODEL_SMALL_EN = "small.en"
    MODEL_MEDIUM_EN = "medium.en"
    
    # Tareas disponibles
    TASK_TRANSCRIBE = "transcribe"  # Mantiene el idioma original
    TASK_TRANSLATE = "translate"    # Traduce a inglés
    
    # Directorio para resultados
    RESULTS_DIR = "transcriptions"
    
    def __init__(self, model_name: str = "base"):
        """
        Inicializa el servicio Whisper con el modelo especificado.
        
        Parameters
        ----------
        model_name : str
            Nombre del modelo de Whisper a utilizar
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self.model_name = model_name
        self.model = None
        
        # Crear directorio de resultados si no existe
        FileProcessor.ensure_directory_exists(self.RESULTS_DIR)
    
    def set_model(self, model_name: str) -> None:
        """
        Cambia el modelo Whisper a utilizar.
        
        Parameters
        ----------
        model_name : str
            Nombre del nuevo modelo a utilizar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if model_name != self.model_name:
            self.model_name = model_name
            self.model = None  # Forzar recarga del modelo
            logger.info(f"Modelo cambiado a: {model_name}")
        
    def load_model(self) -> None:
        """
        Carga el modelo de Whisper en memoria.
        
        Este método debe llamarse antes de realizar transcripciones para
        evitar cargar el modelo repetidamente.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if self.model is None:
            logger.info(f"Cargando modelo Whisper '{self.model_name}'...")
            self.model = whisper.load_model(self.model_name)
            logger.info(f"Modelo Whisper '{self.model_name}' cargado correctamente")
    
    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Obtiene la lista de modelos disponibles con sus características.
        
        Returns
        -------
        Dict[str, Dict[str, Any]]
            Diccionario con los modelos disponibles y sus características
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return {
            self.MODEL_TINY: {
                "name": "Tiny",
                "description": "Modelo más pequeño y rápido (~39M parámetros)",
                "multilingüe": True,
                "vram": "~1 GB",
                "velocidad": "~10x"
            },
            self.MODEL_TINY_EN: {
                "name": "Tiny.en",
                "description": "Modelo pequeño optimizado para inglés",
                "multilingüe": False,
                "vram": "~1 GB",
                "velocidad": "~10x"
            },
            self.MODEL_BASE: {
                "name": "Base",
                "description": "Modelo base (~74M parámetros)",
                "multilingüe": True,
                "vram": "~1 GB",
                "velocidad": "~7x"
            },
            self.MODEL_BASE_EN: {
                "name": "Base.en",
                "description": "Modelo base optimizado para inglés",
                "multilingüe": False,
                "vram": "~1 GB",
                "velocidad": "~7x"
            },
            self.MODEL_SMALL: {
                "name": "Small",
                "description": "Modelo pequeño (~244M parámetros)",
                "multilingüe": True,
                "vram": "~2 GB",
                "velocidad": "~4x"
            },
            self.MODEL_SMALL_EN: {
                "name": "Small.en",
                "description": "Modelo pequeño optimizado para inglés",
                "multilingüe": False,
                "vram": "~2 GB",
                "velocidad": "~4x"
            },
            self.MODEL_MEDIUM: {
                "name": "Medium",
                "description": "Modelo mediano (~769M parámetros)",
                "multilingüe": True,
                "vram": "~5 GB",
                "velocidad": "~2x"
            },
            self.MODEL_MEDIUM_EN: {
                "name": "Medium.en",
                "description": "Modelo mediano optimizado para inglés",
                "multilingüe": False,
                "vram": "~5 GB",
                "velocidad": "~2x"
            },
            self.MODEL_LARGE: {
                "name": "Large",
                "description": "Modelo grande (~1550M parámetros)",
                "multilingüe": True,
                "vram": "~10 GB",
                "velocidad": "1x"
            },
            self.MODEL_TURBO: {
                "name": "Turbo",
                "description": "Modelo optimizado para velocidad (~809M parámetros)",
                "multilingüe": True,
                "vram": "~6 GB",
                "velocidad": "~8x"
            },
        }
    
    def transcribe(
        self, 
        audio_path: str, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        task: str = "transcribe",
        timestamp: str = ""
    ) -> Tuple[Dict[str, Any], str]:
        """
        Transcribe o traduce un archivo de audio a texto.
        
        Parameters
        ----------
        audio_path : str
            Ruta al archivo de audio a transcribir
        source_language : Optional[str]
            Código de idioma de origen (e.g., 'es', 'en', 'fr')
            Si es None, se realizará detección automática del idioma
        target_language : Optional[str]
            Código de idioma de destino, solo aplica si task es "translate"
            Solo se puede traducir a inglés ('en') con el modelo base de Whisper
        task : str
            'transcribe' para transcripción normal o 'translate' para traducir a inglés
        timestamp : str
            Timestamp para el nombre del archivo, por defecto ""
            
        Returns
        -------
        Tuple[Dict[str, Any], str]
            Resultado de la transcripción con:
            - text: texto completo transcrito
            - segments: segmentos individuales con timestamps
            - language: idioma detectado
            Y ruta al archivo de texto guardado
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error al procesar el archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(audio_path):
            raise FileProcessingException(audio_path, "El archivo no existe")
        
        # Cargar el modelo si aún no está cargado
        if self.model is None:
            self.load_model()
        
        # Configurar opciones
        options = {}
        
        # Configurar idioma de origen (si se especifica)
        if source_language:
            options["language"] = source_language
        
        # Verificar si se quiere traducir
        if task == self.TASK_TRANSLATE:
            options["task"] = "translate"
            # Whisper solo traduce a inglés por defecto
            if target_language and target_language.lower() != "en":
                logger.warning(f"Whisper solo traduce a inglés. Se ignorará el idioma destino: {target_language}")
        else:
            options["task"] = "transcribe"
            
        # Realizar la transcripción
        logger.info(f"Procesando audio: {audio_path} (Modelo: {self.model_name}, Tarea: {options['task']})")
        
        try:
            result = self.model.transcribe(audio_path, **options)
            
            detected_language = result.get('language', 'desconocido')
            logger.info(f"Procesamiento completado. Idioma detectado: {detected_language}")
            
            # Guardar resultado en archivo
            save_path = self._save_transcription(audio_path, result, task, timestamp)
            
            return result, save_path
            
        except Exception as e:
            logger.error(f"Error durante la transcripción: {str(e)}", exc_info=True)
            raise FileProcessingException(
                audio_path, 
                f"Error durante la transcripción: {str(e)}"
            )
    
    def _save_transcription(
        self, 
        audio_path: str, 
        result: Dict[str, Any], 
        task: str,
        timestamp: str = ""
    ) -> str:
        """
        Guarda la transcripción en un archivo de texto.
        
        Parameters
        ----------
        audio_path : str
            Ruta al archivo de audio original
        result : Dict[str, Any]
            Resultado de la transcripción de Whisper
        task : str
            Tipo de tarea realizada (transcribe o translate)
        timestamp : str
            Timestamp para el nombre del archivo, por defecto ""
            
        Returns
        -------
        str
            Ruta al archivo guardado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Crear sufijo basado en el tipo de tarea
        task_suffix = "traduccion" if task == self.TASK_TRANSLATE else "transcripcion"
        
        # Generar nombre de archivo
        output_path = FileProcessor.get_output_filename(
            audio_path,
            task_suffix,
            timestamp,
            "txt",
            self.RESULTS_DIR
        )
        
        # Guardar transcripción en archivo
        FileProcessor.save_text_file(result["text"], output_path)
        
        return output_path
    
    def generate_subtitles(
        self, 
        segments: List[Dict[str, Any]], 
        audio_path: str,
        task: str = "transcribe",
        timestamp: str = ""
    ) -> str:
        """
        Genera un archivo de subtítulos en formato SRT.
        
        Parameters
        ----------
        segments : List[Dict[str, Any]]
            Segmentos de la transcripción con timestamps
        audio_path : str
            Ruta al archivo de audio original
        task : str
            Tipo de tarea realizada (transcribe o translate)
        timestamp : str
            Timestamp para el nombre del archivo, por defecto ""
            
        Returns
        -------
        str
            Ruta al archivo de subtítulos generado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Crear sufijo basado en el tipo de tarea
        task_suffix = "subtitulos_" + ("traduccion" if task == self.TASK_TRANSLATE else "transcripcion")
        
        # Generar nombre de archivo
        subtitles_path = FileProcessor.get_output_filename(
            audio_path,
            task_suffix,
            timestamp,
            "srt",
            self.RESULTS_DIR
        )
        
        # Generar contenido de subtítulos
        subtitles_content = self._generate_srt_content(segments)
        
        # Guardar subtítulos en archivo
        FileProcessor.save_text_file(subtitles_content, subtitles_path)
        
        return subtitles_path
    
    def _generate_srt_content(self, segments: List[Dict[str, Any]]) -> str:
        """
        Genera el contenido SRT a partir de los segmentos de transcripción.
        
        Parameters
        ----------
        segments : List[Dict[str, Any]]
            Segmentos de la transcripción con timestamps
            
        Returns
        -------
        str
            Contenido SRT formateado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        subtitles_content = ""
        for i, segment in enumerate(segments):
            start_time = FileProcessor.format_timestamp(segment["start"])
            end_time = FileProcessor.format_timestamp(segment["end"])
            text = segment["text"].strip()
            
            subtitles_content += f"{i+1}\n{start_time} --> {end_time}\n{text}\n\n"
        
        return subtitles_content
    
    def detect_language(self, audio_path: str) -> str:
        """
        Detecta el idioma del archivo de audio.
        
        Parameters
        ----------
        audio_path : str
            Ruta al archivo de audio
            
        Returns
        -------
        str
            Código del idioma detectado
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error al procesar el archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(audio_path):
            raise FileProcessingException(audio_path, "El archivo no existe")
        
        # Cargar el modelo si aún no está cargado
        if self.model is None:
            self.load_model()
        
        try:
            # Cargar y preprocesar el audio
            audio = whisper.load_audio(audio_path)
            audio = whisper.pad_or_trim(audio)
            
            # Calcular espectrograma log-Mel
            mel = whisper.log_mel_spectrogram(audio, n_mels=self.model.dims.n_mels).to(self.model.device)
            
            # Detectar el idioma
            _, probs = self.model.detect_language(mel)
            detected_lang = max(probs, key=probs.get)
            
            logger.info(f"Idioma detectado: {detected_lang}")
            return detected_lang
            
        except Exception as e:
            logger.error(f"Error durante la detección de idioma: {str(e)}", exc_info=True)
            raise FileProcessingException(
                audio_path, 
                f"Error durante la detección de idioma: {str(e)}"
            )
    
    def extract_audio_from_video(self, video_path: str) -> str:
        """
        Extrae el audio de un archivo de video utilizando la utilidad FileProcessor.
        
        Parameters
        ----------
        video_path : str
            Ruta al archivo de video
            
        Returns
        -------
        str
            Ruta al archivo de audio extraído
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error durante la extracción
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return FileProcessor.extract_audio_from_video(video_path)
    def process_audio(
        self, 
        audio_path: str, 
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = ""
    ) -> Dict[str, Any]:
        """
        Procesa un archivo de audio para obtener transcripción y opcionalmente traducción.
        
        Este método centraliza el procesamiento de audio y gestiona la generación de
        transcripción en idioma original y traducción cuando corresponde.
        
        Parameters
        ----------
        audio_path : str
            Ruta al archivo de audio a procesar
        source_language : Optional[str]
            Código de idioma de origen (e.g., 'es', 'en', 'fr')
        target_language : Optional[str]
            Código de idioma de destino, generalmente 'en'
        translate : bool
            Si es True, genera también traducción a inglés
        timestamp : str
            Timestamp para los nombres de archivo
            
        Returns
        -------
        Dict[str, Any]
            Resultado del procesamiento con transcripción y traducción
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error al procesar el archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(audio_path):
            raise FileProcessingException(audio_path, "El archivo no existe")
        
        # Cargar el modelo si aún no está cargado
        if self.model is None:
            self.load_model()
        
        # Detectar idioma si no se especifica
        if not source_language:
            detected_language = self.detect_language(audio_path)
            source_language = detected_language
            logger.info(f"Idioma detectado automáticamente: {source_language}")
        else:
            detected_language = source_language
        
        result = {
            "language": detected_language,
            "is_english": detected_language.lower() == "en",
            "transcription_file": None,
            "translation_file": None,
            "transcription": None,
            "translation": None,
            "segments": None,
            "translated_segments": None
        }
        
        # Siempre hacer la transcripción en el idioma original
        transcription_result, transcription_file = self.transcribe(
            audio_path,
            source_language=source_language,
            task=self.TASK_TRANSCRIBE,
            timestamp=timestamp
        )
        
        result["transcription"] = transcription_result["text"]
        result["segments"] = transcription_result.get("segments", [])
        result["transcription_file"] = transcription_file
        
        # Si se solicita traducción y el idioma no es inglés, traducir también
        if translate and detected_language.lower() != "en":
            translation_result, translation_file = self.transcribe(
                audio_path,
                source_language=source_language,
                target_language="en",
                task=self.TASK_TRANSLATE,
                timestamp=timestamp
            )
            
            result["translation"] = translation_result["text"]
            result["translated_segments"] = translation_result.get("segments", [])
            result["translation_file"] = translation_file
        
        return result
