from typing import Dict, Any, Optional, List, Union
import re
import os

from utils.file_processor import FileProcessor
from utils.logger import logger
from exceptions.command_exceptions import FileProcessingException

class SummaryService:
    """
    Servicio para generar resúmenes automáticos de texto.
    
    Este servicio proporciona funcionalidades para generar resúmenes
    a partir de textos largos.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    # Longitud aproximada del resumen en caracteres
    DEFAULT_SUMMARY_LENGTH = 500
    
    # Directorio para guardar resúmenes
    RESULTS_DIR = "transcriptions"
    
    @classmethod
    def summarize_text(cls, text: str, max_length: Optional[int] = None) -> str:
        """
        Genera un resumen del texto proporcionado.
        
        Este método implementa una lógica básica de resumen, extrayendo
        las oraciones más importantes del texto hasta alcanzar la longitud
        máxima especificada.
        
        Parameters
        ----------
        text : str
            Texto completo a resumir
        max_length : Optional[int], optional
            Longitud máxima aproximada del resumen en caracteres,
            por defecto DEFAULT_SUMMARY_LENGTH
            
        Returns
        -------
        str
            Resumen generado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not text:
            return ""
        
        if max_length is None:
            max_length = cls.DEFAULT_SUMMARY_LENGTH
        
        # Si el texto ya es corto, devolverlo completo
        if len(text) <= max_length:
            return text
        
        # Dividir en oraciones (considerando puntos, signos de exclamación e interrogación)
        sentences = cls._split_into_sentences(text)
        
        # Si solo hay una oración, devolver el principio
        if len(sentences) <= 1:
            return text[:max_length] + "..."
        
        # Generar resumen basado en las primeras oraciones importantes
        return cls._generate_extractive_summary(sentences, max_length)
    
    @staticmethod
    def _split_into_sentences(text: str) -> List[str]:
        """
        Divide un texto en oraciones.
        
        Parameters
        ----------
        text : str
            Texto a dividir
            
        Returns
        -------
        List[str]
            Lista de oraciones
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Dividir por puntos, signos de exclamación e interrogación
        # pero preservando la puntuación
        return re.split(r'(?<=[.!?])\s+', text)
    
    @classmethod
    def _generate_extractive_summary(cls, sentences: List[str], max_length: int) -> str:
        """
        Genera un resumen extractivo basado en las oraciones más importantes.
        
        Parameters
        ----------
        sentences : List[str]
            Lista de oraciones del texto
        max_length : int
            Longitud máxima del resumen
            
        Returns
        -------
        str
            Resumen generado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Tomar las primeras oraciones hasta alcanzar la longitud máxima
        summary = ""
        for sentence in sentences:
            if len(summary) + len(sentence) + 1 <= max_length:
                summary += sentence + " "
            else:
                break
        
        # Si el resumen es muy corto (menos de la mitad de la longitud máxima),
        # incluir al menos la primera oración completa
        if len(summary) < max_length / 2 and sentences:
            return sentences[0] + "..."
            
        return summary.strip()
    
    @classmethod
    def _score_sentences(cls, sentences: List[str]) -> List[float]:
        """
        Calcula puntuaciones para cada oración basado en su importancia.
        
        Este método aplica una puntuación simple basada en la posición
        y la longitud de las oraciones. En una implementación más avanzada,
        se utilizarían técnicas de NLP como TF-IDF o modelos de resumen.
        
        Parameters
        ----------
        sentences : List[str]
            Lista de oraciones a evaluar
            
        Returns
        -------
        List[float]
            Lista de puntuaciones para cada oración (mayor = más importante)
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        scores = []
        total_sentences = len(sentences)
        
        for i, sentence in enumerate(sentences):
            # Factores que contribuyen a la puntuación:
            
            # 1. Posición: las primeras oraciones son más importantes en textos informativos
            position_score = 1.0 if i < total_sentences * 0.3 else 0.5
            
            # 2. Longitud: oraciones muy cortas o muy largas son menos informativas
            length = len(sentence)
            length_score = 0.5
            if 10 <= length <= 200:  # Longitud óptima
                length_score = 1.0
            
            # Puntuación final (media ponderada)
            final_score = (position_score * 0.6) + (length_score * 0.4)
            scores.append(final_score)
        
        return scores
    
    @classmethod
    def generate_summary_file(
        cls,
        text: str, 
        original_file: str, 
        timestamp: str, 
        is_translation: bool = False
    ) -> str:
        """
        Genera un archivo con el resumen del texto.
        
        Parameters
        ----------
        text : str
            Texto completo a resumir
        original_file : str
            Ruta al archivo original
        timestamp : str
            Timestamp para el nombre del archivo
        is_translation : bool, optional
            Indica si es una traducción, por defecto False
            
        Returns
        -------
        str
            Ruta al archivo de resumen generado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Asegurar que exista el directorio para resultados
        FileProcessor.ensure_directory_exists(cls.RESULTS_DIR)
        
        # Generar resumen
        summary = cls.summarize_text(text)
        
        # Crear sufijo basado en el tipo de tarea
        task_suffix = "resumen_" + ("traduccion" if is_translation else "transcripcion")
        
        # Generar nombre para el archivo de resumen
        summary_path = FileProcessor.get_output_filename(
            original_file,
            task_suffix,
            timestamp,
            "txt",
            cls.RESULTS_DIR
        )
        
        try:
            # Guardar resumen en archivo
            FileProcessor.save_text_file(summary, summary_path)
            return summary_path
        except FileProcessingException as e:
            logger.error(f"Error al guardar archivo de resumen: {str(e)}")
            # Devolver la ruta aunque no se haya podido guardar (la excepción ya quedó registrada)
            return summary_path
    
    @classmethod
    def summarize_file(
        cls, 
        file_path: str, 
        max_length: Optional[int] = None,
        output_file: Optional[str] = None
    ) -> Dict[str, Union[str, bool]]:
        """
        Genera un resumen a partir de un archivo de texto.
        
        Parameters
        ----------
        file_path : str
            Ruta al archivo de texto a resumir
        max_length : Optional[int], optional
            Longitud máxima del resumen, por defecto None (usa DEFAULT_SUMMARY_LENGTH)
        output_file : Optional[str], optional
            Ruta para guardar el resumen, por defecto None (genera nombre automáticamente)
            
        Returns
        -------
        Dict[str, Union[str, bool]]
            Diccionario con el resumen y estado de la operación
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Verificar que el archivo existe
        if not FileProcessor.validate_file_exists(file_path):
            return {
                "status": False,
                "message": f"El archivo no existe: {file_path}",
                "summary": ""
            }
        
        try:
            # Leer el contenido del archivo
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Generar resumen
            summary = cls.summarize_text(content, max_length)
            
            # Guardar resumen si se solicita
            if output_file:
                FileProcessor.save_text_file(summary, output_file)
                
                return {
                    "status": True,
                    "message": f"Resumen generado y guardado en: {output_file}",
                    "summary": summary,
                    "output_file": output_file
                }
            
            return {
                "status": True,
                "message": "Resumen generado correctamente",
                "summary": summary
            }
            
        except Exception as e:
            logger.error(f"Error al resumir archivo {file_path}: {str(e)}", exc_info=True)
            return {
                "status": False,
                "message": f"Error al resumir archivo: {str(e)}",
                "summary": ""
            }