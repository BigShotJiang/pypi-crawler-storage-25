import re
from typing import Dict, Union, Optional
import tiktoken

class TokenCalculationException(Exception):
    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class TokenCalculatorService:
    def count_by_words(self, text: str) -> int:
        if not text:
            return 0
        
        pattern = r'\w+|[^\w\s]'
        tokens = re.findall(pattern, text)
        return len(tokens)
    
    def estimate_by_chars(self, text: str) -> int:
        if not text:
            return 0 
        
        char_count = len(text)
        return max(1, round(char_count / 4))
    
    def count_by_tiktoken(self, text: str, model_name: str = "gpt-3.5-turbo") -> int:
        if not text:
            return 0
        
        try:
            encoding = tiktoken.encoding_for_model(model_name)
            tokens = encoding.encode(text)
            return len(tokens)
        except Exception as e:
            raise TokenCalculationException(
                f"Error tokenizing with tiktoken: {str(e)}",
                "tiktoken_error"
            )
    
    def count_all_methods(self, text: str) -> Dict[str, Union[int, str]]:
        results = {
            "text_length": len(text) if text else 0,
            "word_count": 0,
            "char_estimate": 0,
            "tiktoken_count": 0
        }
        
        # Count by words
        results["word_count"] = self.count_by_words(text)
        
        # Estimate by characters
        results["char_estimate"] = self.estimate_by_chars(text)
        
        # Count with tiktoken
        try:
            results["tiktoken_count"] = self.count_by_tiktoken(text)
        except TokenCalculationException as e:
            results["tiktoken_count"] = f"Error: {e.message}"
        
        return results


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Token calculator for text")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-t", "--text", help="Text to analyze")
    group.add_argument("-f", "--file", help="Text file to analyze")
    parser.add_argument("-m", "--method", choices=["words", "chars", "tiktoken", "all"], 
                        default="tiktoken", help="Token calculation method")
    parser.add_argument("--model", default="gpt-3.5-turbo", 
                        help="Model to use with tiktoken (default: gpt-3.5-turbo)")
    
    args = parser.parse_args()
    
    # Get text to analyze
    text = ""
    if args.text:
        text = args.text
    elif args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            print(f"Error reading file: {str(e)}")
            return
    
    # Analyze text
    calculator = TokenCalculatorService()
    
    if args.method == "all":
        results = calculator.count_all_methods(text)
        print("\nToken analysis results:")
        print(f"Text length: {results['text_length']} characters")
        print(f"Word-based tokens: {results['word_count']}")
        print(f"Character-based estimate: {results['char_estimate']}")
        print(f"Tiktoken count ({args.model}): {results['tiktoken_count']}")
    else:
        try:
            if args.method == "words":
                count = calculator.count_by_words(text)
                print(f"Word-based tokens: {count}")
            elif args.method == "chars":
                count = calculator.estimate_by_chars(text)
                print(f"Character-based estimate: {count}")
            elif args.method == "tiktoken":
                count = calculator.count_by_tiktoken(text, args.model)
                print(f"Tiktoken count ({args.model}): {count}")
        except TokenCalculationException as e:
            print(f"Error: {e.message}")


if __name__ == "__main__":
    main()
