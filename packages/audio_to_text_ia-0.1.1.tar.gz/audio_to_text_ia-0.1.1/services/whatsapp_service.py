from typing import Dict, Any, Optional, List, Union, Tuple, Set
import os
import re
import zipfile
import tempfile
import shutil
from pathlib import Path
import logging
from datetime import datetime

from utils.logger import logger
from utils.file_processor import FileProcessor
from services.whisper_service import WhisperService
from exceptions.command_exceptions import (
    FileProcessingException,
    NoAudioStreamException,
)

class WhatsAppChatService:
    """
    Servicio para procesar chats de WhatsApp y transcribir archivos de audio/video.
    
    Este servicio permite analizar archivos de chat de WhatsApp, identificar
    referencias a archivos de audio y video, transcribirlos, y modificar el 
    archivo de chat para incluir las transcripciones.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    # Patrones de expresiones regulares para identificar archivos adjuntos
    AUDIO_PATTERN = r'‎(PTT|AUD)-\d{8}-WA\d{4}\.opus \(archivo adjunto\)'
    VIDEO_PATTERN = r'‎VID-\d{8}-WA\d{4}\.mp4 \(archivo adjunto\)'
    
    # Directorio para resultados
    RESULTS_DIR = "whatsapp_transcriptions"
    
    def __init__(self, whisper_service: WhisperService):
        """
        Inicializa el servicio de procesamiento de chats de WhatsApp.
        
        Parameters
        ----------
        whisper_service : WhisperService
            Servicio de transcripción Whisper a utilizar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self.whisper_service = whisper_service
        
        # Crear directorio de resultados si no existe
        FileProcessor.ensure_directory_exists(self.RESULTS_DIR)
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """
        Parsea una fecha en formato DD/MM/YYYY.
        
        Parameters
        ----------
        date_str : str
            Fecha en formato DD/MM/YYYY
            
        Returns
        -------
        Optional[datetime]
            Objeto datetime o None si no se puede parsear
        """
        try:
            return datetime.strptime(date_str, "%d/%m/%Y")
        except:
            return None
    
    def get_chat_date_range(self, chat_content: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Obtiene el rango de fechas de un archivo de chat.
        
        Parameters
        ----------
        chat_content : str
            Contenido del archivo de chat
            
        Returns
        -------
        Tuple[Optional[str], Optional[str]]
            Tupla con (fecha_inicio, fecha_fin) en formato DD/MM/YYYY
        """
        # Expresión regular para identificar líneas con fecha
        date_pattern = re.compile(r'^(\d{1,2}/\d{1,2}/\d{4}), \d{1,2}:\d{2}')
        
        dates = []
        for line in chat_content.split('\n'):
            date_match = date_pattern.match(line)
            if date_match:
                date_str = date_match.group(1)
                try:
                    # Parsear la fecha para validar
                    date_obj = datetime.strptime(date_str, "%d/%m/%Y")
                    dates.append((date_obj, date_str))
                except:
                    continue
        
        if not dates:
            return None, None
        
        # Ordenar las fechas
        dates.sort(key=lambda x: x[0])
        
        # Retornar la primera y última fecha en formato string
        return dates[0][1], dates[-1][1]
    
    def _filter_chat_by_dates(
        self,
        content: str,
        fecha_inicio: Optional[str] = None,
        fecha_fin: Optional[str] = None
    ) -> Tuple[str, Set[str]]:
        """
        Filtra el contenido del chat por rango de fechas.
        
        Parameters
        ----------
        content : str
            Contenido completo del chat
        fecha_inicio : Optional[str]
            Fecha de inicio (formato DD/MM/YYYY)
        fecha_fin : Optional[str]
            Fecha de fin (formato DD/MM/YYYY)
            
        Returns
        -------
        Tuple[str, Set[str]]
            Tupla con (contenido filtrado, conjunto de archivos mencionados en el rango)
        """
        if not fecha_inicio and not fecha_fin:
            return content, set()
        
        # Parsear fechas
        start_date = self._parse_date(fecha_inicio) if fecha_inicio else None
        end_date = self._parse_date(fecha_fin) if fecha_fin else None
        
        # Si alguna fecha no se puede parsear, devolver contenido original
        if (fecha_inicio and not start_date) or (fecha_fin and not end_date):
            logger.warning(f"No se pudieron parsear las fechas: inicio={fecha_inicio}, fin={fecha_fin}")
            return content, set()
        
        # Expresión regular para identificar líneas con fecha
        date_pattern = re.compile(r'^(\d{1,2}/\d{1,2}/\d{4}), \d{1,2}:\d{2}')
        
        # Expresión regular para archivos adjuntos
        file_pattern = re.compile(r'‎(PTT|AUD|VID)-\d{8}-WA\d{4}\.(opus|mp4)')
        
        filtered_lines = []
        include_message = False
        current_date = None
        referenced_files = set()
        
        for line in content.split('\n'):
            # Verificar si la línea comienza con una fecha
            date_match = date_pattern.match(line)
            
            if date_match:
                # Extraer y parsear la fecha
                date_str = date_match.group(1)
                try:
                    message_date = datetime.strptime(date_str, "%d/%m/%Y")
                    current_date = message_date
                    
                    # Verificar si la fecha está en el rango
                    include_message = True
                    if start_date and message_date < start_date:
                        include_message = False
                    if end_date and message_date > end_date:
                        include_message = False
                except:
                    include_message = False
            
            # Incluir la línea si corresponde
            if include_message:
                filtered_lines.append(line)
                
                # Buscar archivos adjuntos en la línea
                # Patrón más específico para capturar el nombre completo del archivo
                specific_pattern = re.compile(r'‎((PTT|AUD|VID)-\d{8}-WA\d{4}\.(opus|mp4))')
                specific_matches = specific_pattern.findall(line)
                for match in specific_matches:
                    filename = match[0]  # El nombre completo del archivo
                    referenced_files.add(filename)
        
        return '\n'.join(filtered_lines), referenced_files
    
    def process_whatsapp_zip(
        self, 
        zip_path: str,
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        fecha_inicio: Optional[str] = None,
        fecha_fin: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Procesa un archivo ZIP de chat de WhatsApp.
        
        Parameters
        ----------
        zip_path : str
            Ruta al archivo ZIP a procesar
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        fecha_inicio : Optional[str]
            Fecha de inicio para filtrar mensajes (formato DD/MM/YYYY)
        fecha_fin : Optional[str]
            Fecha de fin para filtrar mensajes (formato DD/MM/YYYY)
            
        Returns
        -------
        Dict[str, Any]
            Resultado del procesamiento
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error al procesar el archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(zip_path):
            raise FileProcessingException(zip_path, "El archivo ZIP no existe")
        
        # Extraer archivo ZIP a directorio temporal
        temp_dir = None
        output_zip_path = None
        
        try:
            logger.info(f"Procesando archivo ZIP de WhatsApp: {zip_path}")
            
            # Obtener información básica del archivo
            file_info = FileProcessor.get_file_info(zip_path)
            
            # Extraer archivos ZIP a directorio temporal
            temp_dir = FileProcessor.extract_zip_to_temp_dir(zip_path)
            
            # Buscar archivos relevantes en el directorio temporal
            chat_files = self._find_chat_files(temp_dir)
            audio_files = self._find_audio_files(temp_dir)
            video_files = self._find_video_files(temp_dir)
            
            if not chat_files:
                raise FileProcessingException(zip_path, "No se encontraron archivos de chat en el ZIP")
            
            logger.info(f"Encontrados {len(chat_files)} archivos de chat, {len(audio_files)} archivos de audio y {len(video_files)} archivos de video")
            
            # Mapeo de nombres de archivo a rutas completas
            audio_map = {os.path.basename(f): f for f in audio_files}
            video_map = {os.path.basename(f): f for f in video_files}
            
            # Procesar cada archivo de chat
            processed_files = []
            transcriptions = {}
            
            for chat_file in chat_files:
                # Procesar el archivo de chat
                result = self._process_chat_file(
                    chat_file,
                    audio_map,
                    video_map,
                    source_language,
                    target_language,
                    translate,
                    timestamp,
                    fecha_inicio,
                    fecha_fin
                )
                
                processed_files.append(result["output_file"])
                transcriptions.update(result["transcriptions"])
            
            # Generar archivo ZIP de salida
            output_zip_path = self._create_output_zip(
                zip_path,
                temp_dir,
                processed_files,
                timestamp
            )
            
            return {
                "status": "success",
                "message": f"Chat de WhatsApp procesado exitosamente con {len(transcriptions)} transcripciones",
                "file": zip_path,
                "output_file": output_zip_path,
                "transcriptions_count": len(transcriptions),
                "audio_files_count": len(audio_files),
                "video_files_count": len(video_files),
                "chat_files_count": len(chat_files)
            }
            
        except FileProcessingException as e:
            logger.error(f"Error al procesar chat de WhatsApp: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error inesperado al procesar chat de WhatsApp: {str(e)}", exc_info=True)
            raise FileProcessingException(
                zip_path,
                f"Error inesperado al procesar chat de WhatsApp: {str(e)}"
            )
        finally:
            # Limpiar directorio temporal
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                    logger.info(f"Directorio temporal eliminado: {temp_dir}")
                except Exception as e:
                    logger.warning(f"No se pudo eliminar el directorio temporal {temp_dir}: {str(e)}")
    
    def _find_chat_files(self, directory: str) -> List[str]:
        """
        Busca archivos de chat de WhatsApp (.txt) en el directorio.
        
        Parameters
        ----------
        directory : str
            Directorio donde buscar
            
        Returns
        -------
        List[str]
            Lista de rutas a archivos de chat encontrados
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Buscar archivos con extensión .txt que contengan "Chat de WhatsApp" en el nombre o contenido
        chat_files = []
        
        for root, _, files in os.walk(directory):
            for file in files:
                if file.lower().endswith(".txt"):
                    file_path = os.path.join(root, file)
                    
                    # Verificar por nombre
                    if "chat" in file.lower() and "whatsapp" in file.lower():
                        chat_files.append(file_path)
                        continue
                    
                    # Verificar por contenido (primeras líneas)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read(1000)  # Leer solo los primeros 1000 caracteres
                            if re.search(r'\d{1,2}/\d{1,2}/\d{4}, \d{1,2}:\d{2}', content):
                                chat_files.append(file_path)
                    except Exception as e:
                        logger.warning(f"Error al leer archivo {file_path}: {str(e)}")
        
        return chat_files
    
    def _find_audio_files(self, directory: str) -> List[str]:
        """
        Busca archivos de audio en el directorio.
        
        Parameters
        ----------
        directory : str
            Directorio donde buscar
            
        Returns
        -------
        List[str]
            Lista de rutas a archivos de audio encontrados
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        audio_files = []
        
        for root, _, files in os.walk(directory):
            for file in files:
                # Verificar archivos de audio de WhatsApp (PTT, AUD)
                if (file.startswith("PTT-") or file.startswith("AUD-")) and file.endswith(".opus"):
                    audio_files.append(os.path.join(root, file))
                # Otros formatos de audio comunes
                elif file.lower().endswith((".mp3", ".wav", ".ogg", ".m4a")):
                    audio_files.append(os.path.join(root, file))
        
        return audio_files
    
    def _find_video_files(self, directory: str) -> List[str]:
        """
        Busca archivos de video en el directorio.
        
        Parameters
        ----------
        directory : str
            Directorio donde buscar
            
        Returns
        -------
        List[str]
            Lista de rutas a archivos de video encontrados
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        video_files = []
        
        for root, _, files in os.walk(directory):
            for file in files:
                # Verificar archivos de video de WhatsApp (VID)
                if file.startswith("VID-") and file.endswith(".mp4"):
                    video_files.append(os.path.join(root, file))
                # Otros formatos de video comunes
                elif file.lower().endswith((".mp4", ".avi", ".mov", ".mkv")):
                    video_files.append(os.path.join(root, file))
        
        return video_files
    
    def _process_chat_file(
        self,
        chat_file: str,
        audio_map: Dict[str, str],
        video_map: Dict[str, str],
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False,
        timestamp: str = "",
        fecha_inicio: Optional[str] = None,
        fecha_fin: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Procesa un archivo de chat de WhatsApp.
        
        Parameters
        ----------
        chat_file : str
            Ruta al archivo de chat a procesar
        audio_map : Dict[str, str]
            Mapeo de nombres de archivos de audio a rutas completas
        video_map : Dict[str, str]
            Mapeo de nombres de archivos de video a rutas completas
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
        timestamp : str
            Timestamp para el nombre del archivo
        fecha_inicio : Optional[str]
            Fecha de inicio para filtrar mensajes (formato DD/MM/YYYY)
        fecha_fin : Optional[str]
            Fecha de fin para filtrar mensajes (formato DD/MM/YYYY)
            
        Returns
        -------
        Dict[str, Any]
            Resultado del procesamiento
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        logger.info(f"Procesando archivo de chat: {chat_file}")
        
        # Leer contenido del archivo
        try:
            with open(chat_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Error al leer archivo de chat {chat_file}: {str(e)}")
            raise FileProcessingException(
                chat_file,
                f"Error al leer archivo de chat: {str(e)}"
            )
        
        # Filtrar contenido por fechas si se especificaron
        filtered_content, referenced_files = self._filter_chat_by_dates(content, fecha_inicio, fecha_fin)
        
        # Si hay filtro de fechas, trabajar con el contenido filtrado
        if fecha_inicio or fecha_fin:
            logger.info(f"Aplicando filtro de fechas: inicio={fecha_inicio}, fin={fecha_fin}")
            content_to_process = filtered_content
        else:
            content_to_process = content
            referenced_files = set()  # Sin filtro, procesar todos los archivos
        
        # Identificar referencias a archivos de audio y video
        audio_references = list(re.finditer(self.AUDIO_PATTERN, content_to_process))
        video_references = list(re.finditer(self.VIDEO_PATTERN, content_to_process))
        
        # Diccionario para almacenar las transcripciones
        transcriptions = {}
        
        # Procesar referencias a archivos de audio
        modified_content = content_to_process
        for match in audio_references:
            audio_ref = match.group(0)
            audio_file_name = audio_ref.split()[0].strip('‎')
            
            # Si hay filtro de fechas, solo procesar archivos referenciados en el rango
            if (fecha_inicio or fecha_fin) and audio_file_name not in referenced_files:
                logger.info(f"Omitiendo archivo {audio_file_name} - fuera del rango de fechas")
                continue
            
            if audio_file_name in audio_map:
                # Transcribir el archivo de audio
                try:
                    transcription = self._transcribe_audio(
                        audio_map[audio_file_name],
                        source_language,
                        target_language,
                        translate
                    )
                    # Almacenar la transcripción
                    transcriptions[audio_file_name] = transcription
                    
                    # Modificar el contenido del chat
                    replacement = f"{audio_ref} subtitulos adjuntos apartir de aqui....\n{transcription}"
                    modified_content = modified_content.replace(audio_ref, replacement)
                    
                    logger.info(f"Archivo de audio {audio_file_name} transcrito exitosamente")
                except Exception as e:
                    logger.error(f"Error al transcribir archivo de audio {audio_file_name}: {str(e)}")
            else:
                logger.warning(f"Archivo de audio {audio_file_name} mencionado en el chat pero no encontrado en el ZIP")
        
        # Procesar referencias a archivos de video
        for match in video_references:
            video_ref = match.group(0)
            video_file_name = video_ref.split()[0].strip('‎')
            
            # Si hay filtro de fechas, solo procesar archivos referenciados en el rango
            if (fecha_inicio or fecha_fin) and video_file_name not in referenced_files:
                logger.info(f"Omitiendo archivo {video_file_name} - fuera del rango de fechas")
                continue
            
            if video_file_name in video_map:
                # Transcribir el archivo de video
                try:
                    transcription = self._transcribe_video(
                        video_map[video_file_name],
                        source_language,
                        target_language,
                        translate
                    )
                    # Almacenar la transcripción
                    transcriptions[video_file_name] = transcription
                    
                    # Modificar el contenido del chat
                    replacement = f"{video_ref} subtitulos adjuntos apartir de aqui....\n{transcription}"
                    modified_content = modified_content.replace(video_ref, replacement)
                    
                    logger.info(f"Archivo de video {video_file_name} transcrito exitosamente")
                except NoAudioStreamException:
                    logger.warning(
                        f"Video {video_file_name} sin pista de audio — se omite transcripción"
                    )
                except Exception as e:
                    logger.error(f"Error al transcribir archivo de video {video_file_name}: {str(e)}")
            else:
                logger.warning(f"Archivo de video {video_file_name} mencionado en el chat pero no encontrado en el ZIP")
        
        # Guardar el archivo modificado
        # Si hay filtro de fechas, guardar solo el contenido filtrado con transcripciones
        if fecha_inicio or fecha_fin:
            final_content = modified_content  # Ya es el contenido filtrado y modificado
            # Agregar información del rango de fechas al principio del archivo
            date_info = f"=== CHAT FILTRADO ===\n"
            if fecha_inicio and fecha_fin:
                date_info += f"Rango: {fecha_inicio} al {fecha_fin}\n"
            elif fecha_inicio:
                date_info += f"Desde: {fecha_inicio}\n"
            elif fecha_fin:
                date_info += f"Hasta: {fecha_fin}\n"
            date_info += "=====================\n\n"
            final_content = date_info + final_content
        else:
            # Sin filtro, el contenido completo fue modificado
            final_content = modified_content
        
        output_file = self._save_modified_chat(chat_file, final_content, timestamp)
        
        return {
            "original_file": chat_file,
            "output_file": output_file,
            "transcriptions": transcriptions
        }
    
    def _transcribe_audio(
        self,
        audio_file: str,
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False
    ) -> str:
        """
        Transcribe un archivo de audio.
        
        Parameters
        ----------
        audio_file : str
            Ruta al archivo de audio a transcribir
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
            
        Returns
        -------
        str
            Transcripción del audio
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Cargar el modelo Whisper
        self.whisper_service.load_model()
        
        # Procesar el audio
        result = self.whisper_service.process_audio(
            audio_file,
            source_language=source_language,
            target_language=target_language,
            translate=translate
        )
        
        # Obtener la transcripción
        transcription = result.get("transcription", "")
        
        # Si se solicitó traducción y el idioma no es inglés, usar la traducción
        if translate and not result.get("is_english", False) and result.get("translation"):
            transcription = result.get("translation", "")
        
        return transcription
    
    def _transcribe_video(
        self,
        video_file: str,
        source_language: Optional[str] = None,
        target_language: Optional[str] = None,
        translate: bool = False
    ) -> str:
        """
        Transcribe un archivo de video.
        
        Parameters
        ----------
        video_file : str
            Ruta al archivo de video a transcribir
        source_language : Optional[str]
            Código de idioma de origen para la transcripción
        target_language : Optional[str]
            Código de idioma destino (solo funciona para inglés 'en')
        translate : bool
            Si es True, traduce a inglés en lugar de transcribir
            
        Returns
        -------
        str
            Transcripción del video
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        audio_file = None
        try:
            # Extraer audio del video
            audio_file = self.whisper_service.extract_audio_from_video(video_file)
            
            # Transcribir el audio extraído
            transcription = self._transcribe_audio(
                audio_file,
                source_language,
                target_language,
                translate
            )
            
            return transcription
            
        finally:
            # Limpiar archivos temporales
            if audio_file and os.path.exists(audio_file):
                FileProcessor.clean_temp_file(audio_file)
    
    def _save_modified_chat(
        self,
        original_file: str,
        content: str,
        timestamp: str = ""
    ) -> str:
        """
        Guarda el archivo de chat modificado.
        
        Parameters
        ----------
        original_file : str
            Ruta al archivo original
        content : str
            Contenido modificado
        timestamp : str
            Timestamp para el nombre del archivo
            
        Returns
        -------
        str
            Ruta al archivo guardado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Crear nombre para el archivo de salida
        output_filename = FileProcessor.get_output_filename(
            original_file,
            "transcripcion",
            timestamp,
            "txt",
            self.RESULTS_DIR
        )
        
        # Guardar el archivo
        FileProcessor.save_text_file(content, output_filename)
        
        return output_filename
    
    def _create_output_zip(
        self,
        original_zip: str,
        temp_dir: str,
        modified_files: List[str],
        timestamp: str = ""
    ) -> str:
        """
        Crea un archivo ZIP con los archivos procesados.
        
        Parameters
        ----------
        original_zip : str
            Ruta al archivo ZIP original
        temp_dir : str
            Directorio temporal con los archivos extraídos
        modified_files : List[str]
            Lista de archivos modificados que deben incluirse
        timestamp : str
            Timestamp para el nombre del archivo
            
        Returns
        -------
        str
            Ruta al archivo ZIP creado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Crear nombre para el archivo ZIP de salida
        output_zip = FileProcessor.get_output_filename(
            original_zip,
            "transcripcion",
            timestamp,
            "zip",
            self.RESULTS_DIR
        )
        
        # Crear archivo ZIP
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Agregar archivos modificados
            for file_path in modified_files:
                arcname = os.path.basename(file_path)
                zipf.write(file_path, arcname)
            
            # Agregar archivos originales no modificados
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    # Evitar archivos de chat originales (ya incluidos modificados)
                    if file.lower().endswith(".txt") and any(os.path.basename(file_path) == os.path.basename(f) for f in modified_files):
                        continue
                    
                    # Calcular el nombre en el archivo
                    arcname = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arcname)
        
        return output_zip