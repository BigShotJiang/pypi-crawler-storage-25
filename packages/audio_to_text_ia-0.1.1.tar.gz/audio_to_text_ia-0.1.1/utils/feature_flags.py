from typing import Dict, Any, Optional, Set

class FeatureFlags:
    """
    Gestor de feature flags para habilitar o deshabilitar funcionalidades.
    
    Este gestor permite controlar qué características están disponibles en
    tiempo de ejecución mediante un patrón Singleton.
    
    Parameters
    ----------
    flags : Dict[str, bool], optional
        Diccionario con las flags iniciales, por defecto {}
        
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(FeatureFlags, cls).__new__(cls)
            cls._instance._flags = {}
        return cls._instance
    
    def __init__(self, flags: Optional[Dict[str, bool]] = None):
        """
        Inicializa el gestor de feature flags.
        
        Parameters
        ----------
        flags : Optional[Dict[str, bool]], optional
            Diccionario con las flags iniciales, por defecto None
        """
        if flags is not None:
            self._flags.update(flags)
    
    def is_enabled(self, flag_name: str) -> bool:
        """
        Verifica si una feature flag está habilitada.
        
        Parameters
        ----------
        flag_name : str
            Nombre de la feature flag a verificar
            
        Returns
        -------
        bool
            True si la feature está habilitada, False en caso contrario
        """
        return self._flags.get(flag_name, False)
    
    def enable(self, flag_name: str) -> None:
        """
        Habilita una feature flag.
        
        Parameters
        ----------
        flag_name : str
            Nombre de la feature flag a habilitar
        """
        self._flags[flag_name] = True
    
    def disable(self, flag_name: str) -> None:
        """
        Deshabilita una feature flag.
        
        Parameters
        ----------
        flag_name : str
            Nombre de la feature flag a deshabilitar
        """
        self._flags[flag_name] = False
    
    def set_flag(self, flag_name: str, value: bool) -> None:
        """
        Establece el valor de una feature flag.
        
        Parameters
        ----------
        flag_name : str
            Nombre de la feature flag a establecer
        value : bool
            Valor a establecer
        """
        self._flags[flag_name] = bool(value)
    
    def get_all_flags(self) -> Dict[str, bool]:
        """
        Obtiene todas las feature flags configuradas.
        
        Returns
        -------
        Dict[str, bool]
            Diccionario con todas las feature flags y sus valores
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return self._flags.copy()
    
    def get_enabled_flags(self) -> Set[str]:
        """
        Obtiene las feature flags que están habilitadas.
        
        Returns
        -------
        Set[str]
            Conjunto con los nombres de las feature flags habilitadas
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return {flag for flag, enabled in self._flags.items() if enabled}
    
    def reset(self) -> None:
        """
        Restablece todas las feature flags a su estado inicial.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self._flags = {}
