import os
import json
from typing import Dict, Any, Optional, List, Union, Set
from datetime import datetime

from exceptions.command_exceptions import ConfigurationException
from utils.logger import logger

class ConfigManager:
    """
    Gestor de configuraciones para persistir opciones entre ejecuciones.
    
    Esta clase permite guardar y recuperar las opciones seleccionadas por el usuario
    en un archivo de configuración local, siguiendo un patrón Singleton.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    CONFIG_FILENAME = ".audio_to_text_config.json"
    _instance = None
    _config: Dict[str, Any] = {}
    _config_path: str = ""
    
    def __new__(cls, *args, **kwargs):
        """
        Implementación del patrón Singleton para asegurar una única instancia
        del gestor de configuración en toda la aplicación.
        """
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self) -> None:
        """
        Inicializa el gestor de configuración.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self._config = {}
        self._config_path = os.path.join(os.getcwd(), self.CONFIG_FILENAME)
        self._load_config()
    
    def _load_config(self) -> None:
        """
        Carga la configuración desde el archivo JSON.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not os.path.exists(self._config_path):
            self._config = {}
            return
            
        try:
            with open(self._config_path, 'r', encoding='utf-8') as f:
                self._config = json.load(f)
        except Exception as e:
            logger.warning(f"Error al cargar el archivo de configuración: {str(e)}")
            self._config = {}
    
    def save_config(self) -> bool:
        """
        Guarda la configuración actual en el archivo JSON.
        
        Returns
        -------
        bool
            True si se guardó correctamente, False en caso contrario
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        try:
            with open(self._config_path, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error al guardar la configuración: {str(e)}")
            return False
    
    def get_config(self) -> Dict[str, Any]:
        """
        Obtiene la configuración completa.
        
        Returns
        -------
        Dict[str, Any]
            Diccionario con la configuración completa
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return self._config.copy()
    
    def set_config(self, config: Dict[str, Any]) -> None:
        """
        Establece la configuración completa.
        
        Parameters
        ----------
        config : Dict[str, Any]
            Nueva configuración a establecer
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self._config = config.copy()
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Obtiene un valor de configuración.
        
        Parameters
        ----------
        key : str
            Clave del valor a obtener
        default : Any, optional
            Valor por defecto si la clave no existe, por defecto None
            
        Returns
        -------
        Any
            Valor de configuración, o el valor por defecto si no existe
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """
        Establece un valor de configuración.
        
        Parameters
        ----------
        key : str
            Clave del valor a establecer
        value : Any
            Valor a establecer
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self._config[key] = value
    
    def remove(self, key: str) -> bool:
        """
        Elimina un valor de configuración.
        
        Parameters
        ----------
        key : str
            Clave del valor a eliminar
            
        Returns
        -------
        bool
            True si se eliminó correctamente, False si la clave no existía
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if key in self._config:
            del self._config[key]
            return True
        return False
    
    def clear(self) -> None:
        """
        Limpia toda la configuración.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self._config = {}
    
    def has_key(self, key: str) -> bool:
        """
        Verifica si una clave existe en la configuración.
        
        Parameters
        ----------
        key : str
            Clave a verificar
            
        Returns
        -------
        bool
            True si la clave existe, False en caso contrario
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return key in self._config
    
    def keys(self) -> Set[str]:
        """
        Obtiene todas las claves de configuración.
        
        Returns
        -------
        Set[str]
            Conjunto con todas las claves de configuración
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return set(self._config.keys())
    
    def get_last_command(self) -> str:
        """
        Genera el comando CLI completo a partir de la configuración.
        
        Returns
        -------
        str
            Comando CLI completo
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        cmd_parts = ["python cli.py"]
        
        # Agregar opciones al comando
        if self.get("generate"):
            cmd_parts.append(f"--generate {self.get('generate')}")
            
        if self.get("type_file"):
            cmd_parts.append(f"--type_file {self.get('type_file')}")
            
        if self.get("file"):
            # Escapar espacios en la ruta del archivo
            file_path = self.get("file").replace(" ", "\\ ")
            cmd_parts.append(f"--file {file_path}")
            
        if self.get("model") and self.get("model") != "base":
            cmd_parts.append(f"--model {self.get('model')}")
            
        if self.get("source_language"):
            cmd_parts.append(f"--source_language {self.get('source_language')}")
            
        if self.get("target_language"):
            cmd_parts.append(f"--target_language {self.get('target_language')}")
            
        if self.get("translate"):
            cmd_parts.append("--translate")
            
        # Unir todas las partes del comando
        return " ".join(cmd_parts)
    
    def update_usage_stats(self) -> None:
        """
        Actualiza las estadísticas de uso de la herramienta.
        
        Esta función realiza un seguimiento de cuándo y cuántas veces
        se ha utilizado la herramienta.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Obtener estadísticas actuales
        stats = self.get("usage_stats", {})
        
        # Inicializar si no existen
        if not stats:
            stats = {
                "first_use": datetime.now().isoformat(),
                "total_uses": 0,
                "last_use": None,
                "model_usage": {}
            }
        
        # Actualizar estadísticas
        stats["total_uses"] += 1
        stats["last_use"] = datetime.now().isoformat()
        
        # Actualizar uso de modelos
        model = self.get("model", "base")
        model_usage = stats.get("model_usage", {})
        model_usage[model] = model_usage.get(model, 0) + 1
        stats["model_usage"] = model_usage
        
        # Guardar estadísticas actualizadas
        self.set("usage_stats", stats)
