import os
import zipfile
import shutil
import tempfile
import subprocess
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

from exceptions.command_exceptions import (
    FileProcessingException,
    NoAudioStreamException,
)
from utils.logger import logger

class FileProcessor:
    """
    Clase utilitaria para el procesamiento de archivos.
    
    Esta clase contiene métodos comunes para operaciones con archivos
    como validación, extracción de audio, manipulación de rutas, etc.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    @staticmethod
    def validate_file_exists(file_path: str) -> bool:
        """
        Valida que un archivo existe.
        
        Parameters
        ----------
        file_path : str
            Ruta al archivo a validar
            
        Returns
        -------
        bool
            True si el archivo existe, False en caso contrario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return os.path.exists(file_path) and os.path.isfile(file_path)
    
    @staticmethod
    def ensure_directory_exists(directory_path: str) -> None:
        """
        Garantiza que un directorio existe, creándolo si es necesario.
        
        Parameters
        ----------
        directory_path : str
            Ruta al directorio
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            logger.info(f"Directorio creado: {directory_path}")
    
    @staticmethod
    def video_has_audio_stream(video_path: str) -> bool:
        """
        Verifica si un video contiene al menos un stream de audio.

        Usa ffprobe para inspeccionar metadata sin decodificar (rápido,
        ~50ms). Útil para evitar invocar ffmpeg con `-map a` en videos
        sin audio (ej. stickers animados/GIFs convertidos por WhatsApp),
        donde fallaría con "Stream map 'a' matches no streams".

        Parameters
        ----------
        video_path : str
            Ruta al archivo de video

        Returns
        -------
        bool
            True si el video tiene al menos un stream de audio
        """
        command = [
            "ffprobe",
            "-v", "error",
            "-select_streams", "a",
            "-show_entries", "stream=codec_type",
            "-of", "default=noprint_wrappers=1:nokey=1",
            video_path,
        ]
        try:
            result = subprocess.run(
                command,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            return b"audio" in result.stdout
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            # Si ffprobe falla o no está instalado, asumir que tiene audio
            # y dejar que ffmpeg falle con un error más descriptivo
            logger.warning(
                f"No se pudo verificar streams de audio con ffprobe: {e}. "
                "Continuando con extracción."
            )
            return True

    @staticmethod
    def extract_audio_from_video(video_path: str) -> str:
        """
        Extrae el audio de un archivo de video.

        Parameters
        ----------
        video_path : str
            Ruta al archivo de video

        Returns
        -------
        str
            Ruta al archivo de audio extraído

        Raises
        ------
        NoAudioStreamException
            Si el video no tiene pista de audio
        FileProcessingException
            Si ocurre un error durante la extracción

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(video_path):
            raise FileProcessingException(
                video_path,
                "El archivo de video no existe"
            )

        if not FileProcessor.video_has_audio_stream(video_path):
            raise NoAudioStreamException(video_path)

        # Crear un archivo temporal para el audio extraído
        temp_audio = tempfile.mktemp(suffix=".wav")
        
        try:
            # Usar ffmpeg para extraer el audio
            command = [
                "ffmpeg", 
                "-i", video_path, 
                "-q:a", "0", 
                "-map", "a", 
                temp_audio
            ]
            
            logger.info(f"Extrayendo audio de: {video_path}")
            result = subprocess.run(
                command, 
                check=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE
            )
            logger.info(f"Audio extraído correctamente: {temp_audio}")
            
            return temp_audio
            
        except subprocess.CalledProcessError as e:
            error_message = e.stderr.decode('utf-8') if e.stderr else str(e)
            logger.error(f"Error al extraer audio: {error_message}")
            # Eliminar el archivo temporal si existe
            if os.path.exists(temp_audio):
                os.remove(temp_audio)
            raise FileProcessingException(
                video_path, 
                f"Error al extraer audio con FFmpeg: {error_message}"
            )
        except Exception as e:
            logger.error(f"Error inesperado al extraer audio: {str(e)}")
            # Eliminar el archivo temporal si existe
            if os.path.exists(temp_audio):
                os.remove(temp_audio)
            raise FileProcessingException(
                video_path, 
                f"Error inesperado al extraer audio: {str(e)}"
            )
    
    @staticmethod
    def get_output_filename(
        input_file: str,
        suffix: str,
        timestamp: str = "",
        extension: str = "txt",
        output_dir: Optional[str] = None
    ) -> str:
        """
        Genera un nombre de archivo de salida basado en un archivo de entrada.
        
        Parameters
        ----------
        input_file : str
            Ruta al archivo de entrada
        suffix : str
            Sufijo a agregar al nombre (e.g., "transcripcion", "resumen")
        timestamp : str, optional
            Timestamp a agregar al nombre, por defecto ""
        extension : str, optional
            Extensión del archivo de salida, por defecto "txt"
        output_dir : Optional[str], optional
            Directorio de salida, por defecto None (usa el directorio actual)
            
        Returns
        -------
        str
            Ruta completa al archivo de salida
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Obtener nombre base del archivo de entrada
        input_filename = os.path.basename(input_file)
        input_name = os.path.splitext(input_filename)[0]
        
        # Crear nombre para el archivo de salida
        output_filename = f"{input_name}_{suffix}{timestamp}.{extension}"
        
        # Si se especifica un directorio de salida, asegurar que existe
        if output_dir:
            FileProcessor.ensure_directory_exists(output_dir)
            return os.path.join(output_dir, output_filename)
        
        # Si no se especifica directorio, devolver solo el nombre del archivo
        return output_filename
    
    @staticmethod
    def save_text_file(
        content: str,
        output_path: str,
        encoding: str = "utf-8"
    ) -> None:
        """
        Guarda contenido de texto en un archivo.
        
        Parameters
        ----------
        content : str
            Contenido a guardar
        output_path : str
            Ruta al archivo de salida
        encoding : str, optional
            Codificación a utilizar, por defecto "utf-8"
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error al guardar el archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        try:
            # Asegurar que el directorio existe
            output_dir = os.path.dirname(output_path)
            if output_dir:
                FileProcessor.ensure_directory_exists(output_dir)
            
            # Guardar el archivo
            with open(output_path, "w", encoding=encoding) as f:
                f.write(content)
                
            logger.info(f"Archivo guardado: {output_path}")
            
        except Exception as e:
            logger.error(f"Error al guardar archivo: {str(e)}")
            raise FileProcessingException(
                output_path, 
                f"Error al guardar archivo: {str(e)}"
            )
    
    @staticmethod
    def format_timestamp(seconds: float) -> str:
        """
        Formatea un tiempo en segundos al formato de subtítulos HH:MM:SS,mmm.
        
        Parameters
        ----------
        seconds : float
            Tiempo en segundos
            
        Returns
        -------
        str
            Tiempo formateado en formato HH:MM:SS,mmm
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        milliseconds = int((secs - int(secs)) * 1000)
        
        return f"{hours:02d}:{minutes:02d}:{int(secs):02d},{milliseconds:03d}"
    
    @staticmethod
    def get_current_timestamp() -> str:
        """
        Genera un timestamp con el formato actual para nombres de archivo.
        
        Returns
        -------
        str
            Timestamp en formato "_YYYYMMDD_HHMMSS"
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        return datetime.now().strftime("_%Y%m%d_%H%M%S")
    
    @staticmethod
    def clean_temp_file(file_path: str) -> None:
        """
        Elimina un archivo temporal de forma segura.
        
        Parameters
        ----------
        file_path : str
            Ruta al archivo a eliminar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"Archivo temporal eliminado: {file_path}")
        except Exception as e:
            logger.warning(f"No se pudo eliminar el archivo temporal {file_path}: {str(e)}")
    
    @staticmethod
    def get_file_info(file_path: str) -> Dict[str, Any]:
        """
        Obtiene información básica sobre un archivo.
        
        Parameters
        ----------
        file_path : str
            Ruta al archivo
            
        Returns
        -------
        Dict[str, Any]
            Diccionario con información del archivo
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(file_path):
            return {
                "exists": False,
                "file_name": os.path.basename(file_path),
                "full_path": os.path.abspath(file_path),
            }
        
        file_stat = os.stat(file_path)
        return {
            "exists": True,
            "file_name": os.path.basename(file_path),
            "full_path": os.path.abspath(file_path),
            "directory": os.path.dirname(os.path.abspath(file_path)),
            "extension": os.path.splitext(file_path)[1].lower(),
            "size_bytes": file_stat.st_size,
            "size_mb": file_stat.st_size / (1024 * 1024),
            "created_time": datetime.fromtimestamp(file_stat.st_ctime),
            "modified_time": datetime.fromtimestamp(file_stat.st_mtime),
        }
    
    @staticmethod
    def list_files_by_extensions(
        directory: str, 
        extensions: List[str],
        recursive: bool = False
    ) -> List[str]:
        """
        Lista archivos en un directorio que tienen las extensiones especificadas.
        
        Parameters
        ----------
        directory : str
            Directorio donde buscar
        extensions : List[str]
            Lista de extensiones a filtrar (e.g., ['.mp3', '.wav'])
        recursive : bool, optional
            Si es True, busca también en subdirectorios, por defecto False
            
        Returns
        -------
        List[str]
            Lista de rutas a archivos que coinciden con las extensiones
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        result = []
        if not os.path.exists(directory) or not os.path.isdir(directory):
            return result
        
        # Normalizar extensiones para asegurar que empiecen con punto
        normalized_extensions = [
            ext if ext.startswith('.') else f'.{ext}' for ext in extensions
        ]
        
        if recursive:
            for root, _, files in os.walk(directory):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in normalized_extensions):
                        result.append(os.path.join(root, file))
        else:
            for file in os.listdir(directory):
                file_path = os.path.join(directory, file)
                if os.path.isfile(file_path) and any(
                    file.lower().endswith(ext) for ext in normalized_extensions
                ):
                    result.append(file_path)
        
        return sorted(result)
    
    @staticmethod
    def extract_zip_to_temp_dir(zip_path: str) -> str:
        """
        Extrae un archivo ZIP a un directorio temporal.
        
        Parameters
        ----------
        zip_path : str
            Ruta al archivo ZIP a extraer
            
        Returns
        -------
        str
            Ruta al directorio temporal con los archivos extraídos
            
        Raises
        ------
        FileProcessingException
            Si ocurre un error durante la extracción
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if not FileProcessor.validate_file_exists(zip_path):
            raise FileProcessingException(zip_path, "El archivo ZIP no existe")
        
        # Crear directorio temporal
        temp_dir = tempfile.mkdtemp()
        
        try:
            # Extraer el ZIP usando el módulo zipfile
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            logger.info(f"ZIP extraído en: {temp_dir}")
            return temp_dir
            
        except zipfile.BadZipFile:
            # Limpiar el directorio temporal si hay un error
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise FileProcessingException(zip_path, "Formato de archivo ZIP inválido")
        except Exception as e:
            # Limpiar el directorio temporal si hay un error
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise FileProcessingException(zip_path, f"Error al extraer ZIP: {str(e)}")
