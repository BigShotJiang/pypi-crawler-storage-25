import logging
import os
import sys
import traceback
from datetime import datetime
from inspect import currentframe as inspect_currentframe
from json import dumps as json_dumps
from os import path as os_path
from typing import Optional

from coloredlogs import install as coloredlogs_install

__version__ = '1.1.0'

# Colores ANSI para consola
GRAY = '\033[90m'
RED = '\033[91m'
RED_BOLD = '\033[1m\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
PURPLE = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'
END = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'

LEVEL = {
    'SPAM': GRAY,
    'ERROR': RED,
    'CRITICAL': RED_BOLD,
    'SUCCESS': GREEN,
    'DEBUG': CYAN,
    'WARNING': YELLOW,
    'VERBOSE': BLUE,
    'NOTICE': PURPLE,
    'HEADER': CYAN,
    'INFO': WHITE,
}

# Orden de severidad para filtrado por nivel.
_LEVEL_ORDER = {
    'SILENT': 100,
    'CRITICAL': 50,
    'ERROR': 40,
    'WARNING': 30,
    'SUCCESS': 25,
    'INFO': 20,
    'DEBUG': 10,
}


def _resolve_settings():
    """Importa Settings de forma perezosa para evitar ciclos en el bootstrap."""
    from config.settings import Settings
    return Settings


class Logger:
    """Logger del CLI con soporte para silencio total, niveles y archivo opcional.

    El nivel y el destino se resuelven desde `config.settings.Settings`, que a
    su vez lee envs/{dev,prod} y os.environ. No se crean directorios ni
    archivos al construir la instancia: solo se hace cuando `LOG_FILE=1`.
    """

    def __init__(self, name: str = 'audio_to_text_ia'):
        self.name = name
        settings = _resolve_settings()
        self._console_level = settings.get_log_level()
        self._file_enabled = settings.get_log_file_enabled()
        self._file_dir = settings.get_log_file_dir()

        self.local_logger = logging.getLogger(self.name)
        self._setup_console_logger()

        self.file_logger: Optional[logging.Logger] = None
        self.log_file_path: Optional[str] = None
        if self._file_enabled:
            self._setup_file_logger()

    def _setup_console_logger(self) -> None:
        """Configura coloredlogs solo si el nivel no es SILENT."""
        if self._console_level == 'SILENT':
            self.local_logger.setLevel(logging.CRITICAL + 1)
            return
        coloredlogs_install(level=self._console_level, logger=self.local_logger)

    def _setup_file_logger(self) -> None:
        """Crea el archivo de log lazy. Tolerante a fallos de permisos."""
        try:
            os.makedirs(self._file_dir, exist_ok=True)
        except OSError as exc:
            print(
                f'WARNING: no se pudo crear el directorio de logs '
                f'{self._file_dir!r}: {exc}',
                file=sys.stderr,
            )
            self._file_enabled = False
            return

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.log_file_path = os.path.join(
            self._file_dir, f'{self.name}_{timestamp}.log'
        )

        self.file_logger = logging.getLogger(f'{self.name}_file')
        self.file_logger.setLevel(logging.DEBUG)
        if not self.file_logger.handlers:
            try:
                handler = logging.FileHandler(self.log_file_path)
            except OSError as exc:
                print(
                    f'WARNING: no se pudo abrir el archivo de log '
                    f'{self.log_file_path!r}: {exc}',
                    file=sys.stderr,
                )
                self._file_enabled = False
                self.file_logger = None
                self.log_file_path = None
                return
            handler.setLevel(logging.DEBUG)
            handler.setFormatter(
                logging.Formatter(
                    '%(asctime)s [%(levelname)s] - %(message)s | '
                    '%(filename)s:%(lineno)d'
                )
            )
            self.file_logger.addHandler(handler)

    def _should_emit_console(self, level: str) -> bool:
        if self._console_level == 'SILENT':
            return False
        threshold = _LEVEL_ORDER.get(self._console_level.upper(), 30)
        message_level = _LEVEL_ORDER.get(level.upper(), 20)
        return message_level >= threshold

    def _log(
        self,
        level: str,
        message,
        extra: Optional[dict] = None,
        exc_info: bool = False,
    ) -> None:
        if not extra:
            extra = {}

        emit_console = self._should_emit_console(level)
        emit_file = self._file_enabled and self.file_logger is not None
        if not emit_console and not emit_file:
            return

        log_message = str(message)
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        color = LEVEL.get(level.upper(), WHITE)

        frame = inspect_currentframe().f_back.f_back
        filename = frame.f_code.co_filename
        lineno = frame.f_lineno

        try:
            base_dir = os.getcwd()
            relative_path = os_path.relpath(filename, base_dir)
        except ValueError:
            relative_path = filename
        file_info = f'{relative_path}:{lineno}'

        if level.upper() in {'ERROR', 'WARNING', 'CRITICAL'} and 'ip_address' in extra:
            log_message = f"{log_message} [IP: {extra['ip_address']}]"

        exception_info = ''
        if exc_info:
            exception_info = '\n' + ''.join(traceback.format_exception(*sys.exc_info()))

        if emit_console:
            stream = sys.stderr if level.upper() in {'ERROR', 'CRITICAL', 'WARNING'} else sys.stdout
            formatted_console = (
                f'{GREEN}[{current_time}]{END} '
                f'{BLUE}[{file_info}]{END} '
                f'{color}[{level.upper()}] - {log_message}{END}'
            )
            if extra:
                formatted_console += f' | {json_dumps(extra, indent=2, default=str)}'
            if exception_info:
                formatted_console += f'\n{RED}{exception_info}{END}'
            print(formatted_console, file=stream, flush=True)

        if emit_file:
            formatted_file = f'[{current_time}] [{file_info}] [{level.upper()}] - {log_message}'
            if extra:
                formatted_file += f' | {json_dumps(extra, default=str)}'
            if exception_info:
                formatted_file += f'\n{exception_info}'
            method = getattr(self.file_logger, level.lower(), self.file_logger.info)
            method(formatted_file, exc_info=exc_info)

    def info(self, message, extra=None):
        self._log('INFO', message, extra)

    def warning(self, message, extra=None):
        self._log('WARNING', message, extra)

    def error(self, message, extra=None, exc_info=False):
        self._log('ERROR', message, extra, exc_info)

    def critical(self, message, extra=None, exc_info=False):
        self._log('CRITICAL', message, extra, exc_info)

    def debug(self, message, extra=None):
        self._log('DEBUG', message, extra)

    def success(self, message, extra=None):
        self._log('SUCCESS', message, extra)


# Singleton instance: lazy en el sentido de que aqui no se crean archivos
# salvo que LOG_FILE=1 ya este resuelto al momento del primer import.
logger = Logger()
