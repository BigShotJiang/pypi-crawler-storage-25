#!/usr/bin/env python
import argparse
import shutil
import sys
import os
import re
from typing import Dict, Any, List, Optional, Tuple, Set, Union
from datetime import datetime

import questionary
from questionary import Style

from commands.generate import Generate
from factories.type_files import TypeFiles
from exceptions.command_exceptions import CommandException, FileProcessingException, ValidationException
from utils.logger import logger
from utils.config_manager import ConfigManager
from utils.file_processor import FileProcessor
from config.settings import Settings


class AudioToTextCLI:
    """
    Interfaz de línea de comandos para la herramienta Audio-to-Text-IA.
    
    Esta clase gestiona la interacción con el usuario y la ejecución de comandos.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    # Constantes para subcomandos
    SUBCOMMAND_ZIP_WHATSAPP_CHAT = "zip_whatsapp_chat"
    
    # Definir un estilo personalizado para los prompts
    CUSTOM_STYLES_DICT = {
        'qmark': 'fg:#673ab7 bold',       # token en frente de la pregunta
        'question': 'fg:#0080ff bold',    # texto de la pregunta
        'answer': 'fg:#00aa00 bold',      # texto de respuesta detrás de la pregunta
        'pointer': 'fg:#673ab7 bold',     # puntero usado en select y checkbox
        'highlighted': 'fg:#0080ff bold', # opción seleccionada en prompts select y checkbox
        'selected': 'fg:#00aa00',         # estilo para un elemento seleccionado en checkbox
        'separator': 'fg:#cc5454',        # separador en listas
        'instruction': 'fg:#888888',      # instrucciones para el usuario
        'info': 'fg:#ffffff bold',        # información adicional
        'default': 'fg:#ffffff',          # texto por defecto
    }

    CUSTOM_STYLES = Style(
        [(key, value) for key, value in CUSTOM_STYLES_DICT.items()]
    )
    
    # Modelos disponibles para Whisper
    WHISPER_MODELS = [
        "tiny", "tiny.en", "base", "base.en", "small", "small.en", 
        "medium", "medium.en", "large", "turbo"
    ]

    # Diccionario para idiomas comunes
    COMMON_LANGUAGES = [
        ("Español", "es"),
        ("Inglés", "en"),
        ("Francés", "fr"),
        ("Alemán", "de"),
        ("Italiano", "it"),
        ("Portugués", "pt"),
        ("Ruso", "ru"),
        ("Japonés", "ja"),
        ("Chino", "zh"),
        ("Otro", "other")
    ]
    
    def __init__(self):
        """
        Inicializa la CLI con configuraciones.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Cargar configuraciones
        self.settings = Settings()
        self.config_manager = ConfigManager()
        
        # Determinar el entorno
        self.is_local_env = self.settings.is_local_environment()
        self.project_folders = self.settings.get_project_folders() if self.is_local_env else []
        
        # Definir extensiones permitidas para cada tipo de archivo
        self.file_extensions = self.settings.get_file_extensions()
        
        # Inicializar comandos
        self.generate_command = None
        self.type_files_factory = None
        self.whatsapp_service = None
    
    def parse_args(self) -> Dict[str, Any]:
        """
        Parsea los argumentos de línea de comandos.
        
        Returns
        -------
        Dict[str, Any]
            Diccionario con los argumentos parseados
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        parser = argparse.ArgumentParser(
            description="Herramienta para procesar archivos de audio/video y generar texto con IA"
        )
        
        parser.add_argument(
            "--generate",
            choices=["resumen", "subtitle", "zip_whatsapp_chat"],  # Añadido "zip_whatsapp_chat"
            help="Tipo de generación a realizar"
        )
        
        parser.add_argument(
            "--type_file",
            choices=["audio", "video", "text", "zip"],
            help="Tipo de archivo a procesar"
        )
        
        parser.add_argument(
            "--file",
            help="Ruta al archivo a procesar"
        )
        
        parser.add_argument(
            "--source_language",
            help="Código del idioma de origen para la transcripción (e.g., 'es', 'en', 'fr')"
        )
        
        parser.add_argument(
            "--target_language",
            help="Código del idioma de destino para la traducción (actualmente solo 'en')"
        )
        
        parser.add_argument(
            "--translate",
            action="store_true",
            help="Traducir en lugar de transcribir (actualmente solo a inglés)"
        )
        
        parser.add_argument(
            "--model",
            choices=self.WHISPER_MODELS,
            default="base",
            help="Modelo de Whisper a utilizar (default: base)"
        )
        
        parser.add_argument(
            "--no-save-config",
            action="store_true",
            help="No guardar la configuración utilizada para futuras ejecuciones"
        )
        
        parser.add_argument(
            "--show-command",
            action="store_true",
            help="Mostrar el comando completo utilizado al final de la ejecución"
        )
        
        parser.add_argument(
            "--version",
            action="store_true",
            help="Mostrar la versión de la herramienta y salir"
        )
        
        # Agregar argumentos adicionales para fechas de WhatsApp
        parser.add_argument(
            "--fecha-inicio",
            help="Fecha de inicio para filtrar mensajes de WhatsApp (formato: DD/MM/YYYY)"
        )
        
        parser.add_argument(
            "--fecha-fin",
            help="Fecha de fin para filtrar mensajes de WhatsApp (formato: DD/MM/YYYY)"
        )
        
        return vars(parser.parse_args())
    
    def initialize_commands(self, whisper_model: str = "base") -> None:
        """
        Inicializa los comandos de la aplicación.
        
        Parameters
        ----------
        whisper_model : str, optional
            Modelo de Whisper a utilizar, por defecto "base"
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        self.generate_command = Generate(whisper_model=whisper_model)
        self.type_files_factory = TypeFiles(whisper_model=whisper_model)
    
    def get_files_by_type(self, file_type: str, directory: str = '.') -> Tuple[List[str], List[str]]:
        """
        Obtiene la lista de archivos del tipo especificado y directorios en el directorio indicado.
        Excluye carpetas del proyecto cuando se ejecuta en entorno local.
        
        Parameters
        ----------
        file_type : str
            Tipo de archivo a buscar (audio, video, text, zip)
        directory : str, optional
            Directorio donde buscar, por defecto el directorio actual
            
        Returns
        -------
        Tuple[List[str], List[str]]
            Tupla con dos listas: (archivos que coinciden con el tipo, directorios)
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        allowed_extensions = self.file_extensions.get(file_type, [])
        files = []
        directories = []
        
        # Verificar si estamos en la raíz del proyecto para aplicar el filtrado
        is_project_root = False
        if self.is_local_env and os.path.isfile(os.path.join(directory, 'setup.py')) and os.path.isdir(os.path.join(directory, 'commands')):
            is_project_root = True
            logger.debug("Detectada raíz del proyecto. Se excluirán carpetas del proyecto.")
        
        try:
            for item in os.listdir(directory):
                item_path = os.path.join(directory, item)
                
                # Filtrar carpetas del proyecto si estamos en entorno local y en la raíz del proyecto
                if self.is_local_env and is_project_root and os.path.isdir(item_path) and item in self.project_folders:
                    logger.debug(f"Excluyendo carpeta del proyecto: {item}")
                    continue
                
                # Categorizar entre archivos y directorios
                if os.path.isdir(item_path):
                    directories.append(item)
                elif os.path.isfile(item_path):
                    # Verificar extensión permitida
                    if any(item.lower().endswith(ext) for ext in allowed_extensions):
                        files.append(item)
        except Exception as e:
            logger.error(f"Error al obtener archivos y directorios: {str(e)}")
        
        return sorted(files), sorted(directories)
    
    def select_file(self, file_type: str, default_file: Optional[str] = None) -> str:
        """
        Permite al usuario seleccionar un archivo o navegar por directorios.
        
        Parameters
        ----------
        file_type : str
            Tipo de archivo a seleccionar (audio, video, text, zip)
        default_file : Optional[str], optional
            Archivo predeterminado a seleccionar, por defecto None
            
        Returns
        -------
        str
            Ruta completa al archivo seleccionado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        current_dir = os.getcwd()
        home_dir = os.path.expanduser("~")
        
        # Si hay un archivo predeterminado y existe, ofrecerlo como primera opción
        if default_file and os.path.exists(default_file):
            if questionary.confirm(
                f"¿Deseas usar el archivo seleccionado anteriormente? ({default_file})",
                default=True,
                style=self.CUSTOM_STYLES
            ).ask():
                return default_file
        
        while True:
            files, directories = self.get_files_by_type(file_type, current_dir)
            
            # Preparar opciones para mostrar al usuario
            options = []
            
            # Opciones de navegación
            if current_dir != os.path.abspath(os.sep):
                options.append("📁 .. (Subir directorio)")
            
            if current_dir != home_dir:
                options.append("🏠 ~ (Ir a directorio home)")
            
            # Agregar directorios con un ícono para distinguirlos
            options.extend([f"📁 {directory}" for directory in directories])
            
            # Agregar archivos
            options.extend(files)
            
            # Mensaje informativo para el usuario
            current_dir_display = current_dir
            if len(current_dir_display) > 50:
                # Acortar rutas muy largas
                current_dir_display = "..." + current_dir_display[-47:]
            
            # Si no hay archivos compatibles pero hay directorios, indicarlo
            message = f"Selecciona un archivo de tipo {file_type} en: {current_dir_display}"
            if not files and directories:
                message += f"\n⚠️ No hay archivos de tipo {file_type} en este directorio, pero puedes navegar a otras carpetas"
            elif not files and not directories:
                message += f"\n⚠️ No hay archivos de tipo {file_type} ni subdirectorios en esta ubicación"
            
            # Seleccionar el archivo predeterminado si está en la lista actual
            default_index = None
            if default_file:
                basename = os.path.basename(default_file)
                if basename in options:
                    default_index = options.index(basename)
            
            choice = questionary.select(
                message,
                choices=options,
                default=options[default_index] if default_index is not None else None,
                style=self.CUSTOM_STYLES
            ).ask()
            
            if not choice:
                return ""
            
            # Manejar navegación
            if choice == "📁 .. (Subir directorio)":
                current_dir = os.path.dirname(current_dir)
                continue
            elif choice == "🏠 ~ (Ir a directorio home)":
                current_dir = home_dir
                continue
            elif choice.startswith("📁 "):
                # Navegar a subdirectorio
                directory_name = choice[2:].strip()  # Quitar el ícono y espacios
                current_dir = os.path.join(current_dir, directory_name)
                continue
                
            return os.path.join(current_dir, choice)
    
    def select_whisper_model(self, default_model: str = "base") -> str:
        """
        Permite al usuario seleccionar un modelo de Whisper.
        
        Parameters
        ----------
        default_model : str, optional
            Modelo predeterminado a seleccionar, por defecto "base"
            
        Returns
        -------
        str
            Modelo seleccionado
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Inicializar comandos si es necesario
        if self.generate_command is None:
            self.initialize_commands(default_model)
        
        # Obtener información detallada de los modelos
        models_info = self.generate_command.get_available_models()
        
        # Crear las opciones formateadas
        choices = []
        for model_id in self.WHISPER_MODELS:
            info = models_info.get(model_id, {})
            description = info.get("description", "")
            multilingue = "Sí" if info.get("multilingüe", False) else "Solo inglés"
            vram = info.get("vram", "")
            velocidad = info.get("velocidad", "")
            
            formatted_option = f"{model_id} - {description} | RAM: {vram} | Velocidad: {velocidad} | Multilingüe: {multilingue}"
            choices.append(formatted_option)
        
        # Establecer la opción predeterminada
        default_option = None
        for choice in choices:
            if choice.startswith(default_model + " "):
                default_option = choice
                break
        
        # Preguntar al usuario
        choice = questionary.select(
            "Selecciona el modelo de Whisper:",
            choices=choices,
            default=default_option,
            style=self.CUSTOM_STYLES
        ).ask()
        
        if not choice:
            return default_model  # Modelo predeterminado
        
        # Extraer el ID del modelo de la opción seleccionada
        return choice.split(" - ")[0].strip()
    
    def get_whatsapp_date_range(self, zip_path: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Obtiene el rango de fechas de un archivo ZIP de WhatsApp.
        
        Parameters
        ----------
        zip_path : str
            Ruta al archivo ZIP de WhatsApp
            
        Returns
        -------
        Tuple[Optional[str], Optional[str]]
            Tupla con (fecha_inicio, fecha_fin) en formato DD/MM/YYYY
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        import tempfile
        import shutil
        from services.whatsapp_service import WhatsAppChatService
        from services.whisper_service import WhisperService
        
        temp_dir = None
        try:
            logger.info(f"Extrayendo ZIP para verificar fechas: {zip_path}")
            
            # Extraer archivos
            temp_dir = FileProcessor.extract_zip_to_temp_dir(zip_path)
            
            # Buscar archivos de chat
            chat_files = []
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    if file.lower().endswith(".txt"):
                        file_path = os.path.join(root, file)
                        # Verificar si es un archivo de chat
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read(1000)
                                if re.search(r'\d{1,2}/\d{1,2}/\d{4}, \d{1,2}:\d{2}', content):
                                    chat_files.append(file_path)
                        except:
                            continue
            
            if not chat_files:
                logger.warning("No se encontraron archivos de chat en el ZIP")
                return None, None
            
            # Inicializar servicio de WhatsApp temporalmente si no existe
            if not self.whatsapp_service:
                whisper_service = WhisperService(model_name="base")
                self.whatsapp_service = WhatsAppChatService(whisper_service)
            
            # Analizar el primer archivo de chat para obtener el rango
            first_date = None
            last_date = None
            
            for chat_file in chat_files:
                try:
                    with open(chat_file, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    # Obtener rango de fechas
                    start, end = self.whatsapp_service.get_chat_date_range(content)
                    
                    if start and end:
                        # Si es el primer archivo o tiene fecha más temprana
                        if not first_date or datetime.strptime(start, "%d/%m/%Y") < datetime.strptime(first_date, "%d/%m/%Y"):
                            first_date = start
                        # Si es el primer archivo o tiene fecha más tardía
                        if not last_date or datetime.strptime(end, "%d/%m/%Y") > datetime.strptime(last_date, "%d/%m/%Y"):
                            last_date = end
                except Exception as e:
                    logger.error(f"Error al analizar archivo de chat: {str(e)}")
                    continue
            
            return first_date, last_date
            
        except Exception as e:
            logger.error(f"Error al obtener rango de fechas del ZIP: {str(e)}")
            return None, None
        finally:
            # Limpiar directorio temporal
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                except:
                    pass
    
    def interactive_mode(self) -> Dict[str, Any]:
        """
        Permite al usuario seleccionar opciones de forma interactiva utilizando questionary.
        
        Returns
        -------
        Dict[str, Any]
            Diccionario con las opciones seleccionadas por el usuario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        logger.info("Iniciando modo interactivo")
        print("🎵 Audio-to-Text-IA 🎵\n")
        
        # Cargar configuración anterior
        last_config = self.config_manager.get_config()
        logger.info(f"Configuración anterior cargada: {last_config}")
        
        # Mostrar advertencia si hay una configuración anterior
        if last_config:
            last_cmd = self.config_manager.get_last_command()
            questionary.print(
                f"ℹ️ Configuración anterior encontrada. Comando equivalente:\n{last_cmd}\n",
                style=self.CUSTOM_STYLES_DICT.get('info')
            )
        
        # Seleccionar modelo de Whisper (usar el anterior como predeterminado)
        default_model = last_config.get("model", "base")
        whisper_model = self.select_whisper_model(default_model)
        logger.info(f"Modelo seleccionado: {whisper_model}")
        
        # Inicializar comandos con el modelo seleccionado
        self.initialize_commands(whisper_model)
        
        # Obtener subcomandos disponibles
        generate_options = self.generate_command.get_available_subcommands()
        type_file_options = self.type_files_factory.get_available_subcommands()
        
        # Preguntar al usuario qué tipo de generación desea realizar
        default_generate = last_config.get("generate")
        generate_choice = questionary.select(
            "¿Qué tipo de generación deseas realizar?",
            choices=generate_options,
            default=default_generate if default_generate in generate_options else None,
            style=self.CUSTOM_STYLES
        ).ask()
        
        if not generate_choice:
            logger.warning("Usuario canceló la selección de tipo de generación")
            sys.exit(0)
        
        # Preguntar al usuario qué tipo de archivo desea procesar
        default_type = last_config.get("type_file")
        type_file_choice = questionary.select(
            "¿Qué tipo de archivo deseas procesar?",
            choices=type_file_options,
            default=default_type if default_type in type_file_options else None,
            style=self.CUSTOM_STYLES
        ).ask()
        
        if not type_file_choice:
            logger.warning("Usuario canceló la selección de tipo de archivo")
            sys.exit(0)
        
        # Permitir al usuario navegar y seleccionar un archivo
        default_file = last_config.get("file")
        file_path = self.select_file(type_file_choice, default_file)
        
        if not file_path:
            logger.warning("Usuario canceló la selección de archivo")
            sys.exit(0)
        
        # Preguntar al usuario si desea traducir en lugar de transcribir
        default_translate = last_config.get("translate", False)
        translate = questionary.confirm(
            "¿Deseas traducir el contenido a inglés?",
            default=default_translate,
            style=self.CUSTOM_STYLES
        ).ask()
        
        # Configuración de idiomas
        source_language = None
        target_language = None
        
        # Preguntar por idioma origen si no es traducción o si el usuario lo desea especificar
        default_source = last_config.get("source_language")
        specify_source = questionary.confirm(
            "¿Deseas especificar el idioma de origen?",
            default=bool(default_source),
            style=self.CUSTOM_STYLES
        ).ask()
        
        if specify_source:
            # Encontrar el idioma predeterminado en la lista
            default_lang_option = None
            if default_source:
                for name, code in self.COMMON_LANGUAGES:
                    if code == default_source:
                        default_lang_option = f"{name} ({code})"
                        break
            
            # Mostrar lista de idiomas comunes
            language_choice = questionary.select(
                "Selecciona el idioma de origen:",
                choices=[f"{name} ({code})" for name, code in self.COMMON_LANGUAGES],
                default=default_lang_option,
                style=self.CUSTOM_STYLES
            ).ask()
            
            if language_choice:
                # Extraer el código de idioma
                if "other" in language_choice:
                    # Si el usuario selecciona "Otro", permitirle ingresar manualmente
                    source_language = questionary.text(
                        "Ingresa el código de idioma de origen (e.g., 'es', 'en', 'fr'):",
                        default=default_source if default_source else "",
                        style=self.CUSTOM_STYLES
                    ).ask()
                else:
                    # Extraer el código entre paréntesis
                    source_language = language_choice.split("(")[1].split(")")[0]
        
        # Si es traducción, el idioma destino es inglés
        if translate:
            target_language = "en"
            message = f"NOTA: Whisper solo soporta traducción a inglés actualmente"
            questionary.print(message, style=self.CUSTOM_STYLES_DICT.get('info'))
        
        # Preguntar por fechas si es un zip de WhatsApp
        fecha_inicio = None
        fecha_fin = None
        if generate_choice == self.SUBCOMMAND_ZIP_WHATSAPP_CHAT and type_file_choice == "zip":
            if questionary.confirm(
                "¿Deseas filtrar el chat por rango de fechas?",
                default=False,
                style=self.CUSTOM_STYLES
            ).ask():
                # Analizar el ZIP para obtener el rango de fechas válido
                questionary.print(
                    "Analizando el archivo ZIP para obtener el rango de fechas disponible...",
                    style=self.CUSTOM_STYLES_DICT.get('info')
                )
                
                min_date, max_date = self.get_whatsapp_date_range(file_path)
                
                if not min_date or not max_date:
                    questionary.print(
                        "⚠️ No se pudo determinar el rango de fechas del chat. Se permitirá cualquier fecha.",
                        style=self.CUSTOM_STYLES_DICT.get('separator')
                    )
                    # Pedir fechas sin validación de rango
                    fecha_inicio = questionary.text(
                        "Fecha de inicio (formato DD/MM/YYYY):",
                        validate=lambda text: bool(re.match(r'^\d{1,2}/\d{1,2}/\d{4}$', text)),
                        style=self.CUSTOM_STYLES
                    ).ask()
                    
                    fecha_fin = questionary.text(
                        "Fecha de fin (formato DD/MM/YYYY):",
                        validate=lambda text: bool(re.match(r'^\d{1,2}/\d{1,2}/\d{4}$', text)),
                        style=self.CUSTOM_STYLES
                    ).ask()
                else:
                    # Mostrar el rango válido
                    questionary.print(
                        f"📅 Rango de fechas disponible en el chat: {min_date} hasta {max_date}",
                        style=self.CUSTOM_STYLES_DICT.get('info')
                    )
                    
                    # Función de validación que incluye formato y rango
                    def validate_date_in_range(date_str: str, is_start: bool = True) -> bool:
                        # Primero validar formato
                        if not re.match(r'^\d{1,2}/\d{1,2}/\d{4}$', date_str):
                            return False
                        
                        try:
                            # Parsear la fecha ingresada
                            input_date = datetime.strptime(date_str, "%d/%m/%Y")
                            min_datetime = datetime.strptime(min_date, "%d/%m/%Y")
                            max_datetime = datetime.strptime(max_date, "%d/%m/%Y")
                            
                            # Verificar que esté en el rango
                            return min_datetime <= input_date <= max_datetime
                        except:
                            return False
                    
                    # Pedir fecha de inicio con validación
                    fecha_inicio = questionary.text(
                        f"Fecha de inicio (formato DD/MM/YYYY, mínimo: {min_date}):",
                        validate=lambda text: validate_date_in_range(text, True) or f"La fecha debe estar entre {min_date} y {max_date}",
                        style=self.CUSTOM_STYLES
                    ).ask()
                    
                    # Pedir fecha de fin con validación adicional
                    def validate_end_date(date_str: str) -> Union[bool, str]:
                        if not validate_date_in_range(date_str, False):
                            return f"La fecha debe estar entre {min_date} y {max_date}"
                        
                        # Verificar que la fecha fin sea posterior o igual a la fecha inicio
                        if fecha_inicio:
                            try:
                                start = datetime.strptime(fecha_inicio, "%d/%m/%Y")
                                end = datetime.strptime(date_str, "%d/%m/%Y")
                                if end < start:
                                    return f"La fecha de fin debe ser posterior o igual a {fecha_inicio}"
                            except:
                                pass
                        
                        return True
                    
                    fecha_fin = questionary.text(
                        f"Fecha de fin (formato DD/MM/YYYY, máximo: {max_date}):",
                        validate=validate_end_date,
                        style=self.CUSTOM_STYLES
                    ).ask()
        
        # Mostrar resumen de las opciones seleccionadas
        logger.info(
            f"Opciones seleccionadas: Modelo={whisper_model}, Generación={generate_choice}, " +
            f"Tipo={type_file_choice}, Archivo={file_path}, Idioma origen={source_language}, " +
            f"Idioma destino={target_language}, Traducir={translate}"
        )
        
        # Preparar textos para mostrar al usuario
        model_text = f"✓ Modelo: {whisper_model}"
        source_lang_text = f"✓ Idioma origen: {source_language}" if source_language else "✗ Idioma origen: Detección automática"
        task_text = "✓ Tarea: Traducir a inglés" if translate else "✓ Tarea: Transcribir"
        fecha_text = ""
        
        if fecha_inicio or fecha_fin:
            if fecha_inicio and fecha_fin:
                fecha_text = f"✓ Rango de fechas: {fecha_inicio} al {fecha_fin}\n"
            elif fecha_inicio:
                fecha_text = f"✓ Desde fecha: {fecha_inicio}\n"
            elif fecha_fin:
                fecha_text = f"✓ Hasta fecha: {fecha_fin}\n"
        
        questionary.print(
            f"\n{model_text}\n"
            f"✓ Generación: {generate_choice}\n"
            f"✓ Tipo de archivo: {type_file_choice}\n"
            f"✓ Archivo: {file_path}\n"
            f"{source_lang_text}\n"
            f"{task_text}\n"
            f"{fecha_text}",
            style=self.CUSTOM_STYLES_DICT.get('info'),
        )
        
        # Preguntar sobre guardar configuración
        save_config = questionary.confirm(
            "¿Deseas guardar esta configuración para futuras ejecuciones?",
            default=True,
            style=self.CUSTOM_STYLES
        ).ask()
        
        # Confirmar las opciones
        if questionary.confirm(
            "¿Confirmas estas opciones?",
            default=True,
            style=self.CUSTOM_STYLES
        ).ask():
            options = {
                "generate": generate_choice,
                "type_file": type_file_choice,
                "file": file_path,
                "model": whisper_model,
                "translate": translate,
                "no_save_config": not save_config,
                "show_command": True  # Siempre mostrar el comando en modo interactivo
            }
            
            # Añadir idiomas si se han especificado
            if source_language:
                options["source_language"] = source_language
            
            if target_language:
                options["target_language"] = target_language
            
            # Añadir fechas si se han especificado
            if fecha_inicio:
                options["fecha_inicio"] = fecha_inicio
            
            if fecha_fin:
                options["fecha_fin"] = fecha_fin
                
            return options
        else:
            # Si el usuario no confirma, volver a preguntar
            logger.info("Usuario solicitó reiniciar la selección")
            print("Volviendo a iniciar la selección...\n")
            return self.interactive_mode()
    
    def validate_args(self, args: Dict[str, Any]) -> Optional[List[str]]:
        """
        Valida los argumentos proporcionados.
        
        Parameters
        ----------
        args : Dict[str, Any]
            Argumentos a validar
            
        Returns
        -------
        Optional[List[str]]
            Lista de errores encontrados, None si no hay errores
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        missing_args = []
        
        # Verificar argumentos obligatorios
        if "generate" not in args or args["generate"] is None:
            missing_args.append("--generate")
        if "type_file" not in args or args["type_file"] is None:
            missing_args.append("--type_file")
        if "file" not in args or args["file"] is None:
            missing_args.append("--file")
        
        return missing_args if missing_args else None
    
    def save_config(self, args: Dict[str, Any]) -> None:
        """
        Guarda la configuración para futuras ejecuciones.
        
        Parameters
        ----------
        args : Dict[str, Any]
            Argumentos a guardar
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Crear copia de los argumentos para guardar (sin metadatos)
        config_to_save = {
            "generate": args["generate"],
            "type_file": args["type_file"],
            "file": args["file"],
            "model": args.get("model", "base")
        }
        
        # Agregar opciones adicionales si están presentes
        for key in ["source_language", "target_language", "translate"]:
            if key in args and args[key]:
                config_to_save[key] = args[key]
        
        # Actualizar la configuración
        self.config_manager.set_config(config_to_save)
        self.config_manager.update_usage_stats()
        
        # Guardar en archivo
        if self.config_manager.save_config():
            logger.info(f"Configuración guardada: {config_to_save}")
        else:
            logger.warning("No se pudo guardar la configuración")
    
    def display_result(self, generate_result: Dict[str, Any]) -> None:
        """
        Muestra el resultado de la generación al usuario.
        
        Parameters
        ----------
        generate_result : Dict[str, Any]
            Resultado de la generación
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        if isinstance(generate_result, dict):
            print(f"\nResultado de {generate_result.get('task', 'procesamiento')}:")
            if generate_result.get("status") == "success":
                print(f"✅ {generate_result.get('message', 'Procesamiento exitoso')}")
                print(f"🌍 Idioma detectado: {generate_result.get('language', 'desconocido')}")
                
                # Imprimir información del archivo de transcripción
                if "output_file" in generate_result:
                    print(f"📄 Archivo de transcripción: {generate_result['output_file']}")
                    
                # Imprimir información del archivo de traducción si existe
                if "translation_file" in generate_result:
                    print(f"📄 Archivo de traducción: {generate_result['translation_file']}")
                
                # Imprimir información del resumen
                if "summary_file" in generate_result:
                    print(f"📄 Archivo de resumen (original): {generate_result['summary_file']}")
                    
                # Imprimir información del resumen de traducción si existe
                if "translation_summary_file" in generate_result:
                    print(f"📄 Archivo de resumen (traducción): {generate_result['translation_summary_file']}")
                
                # Imprimir información de subtítulos si existe
                if "subtitle_file" in generate_result:
                    print(f"📄 Archivo de subtítulos: {generate_result['subtitle_file']}")
                    print(f"🔢 Número de segmentos: {generate_result.get('segments_count', 0)}")
            else:
                print(f"❌ {generate_result.get('message', 'Error durante el procesamiento')}")
        else:
            print(generate_result)
    
    def show_command(self, args: Dict[str, Any]) -> None:
        """
        Muestra el comando completo para futuras ejecuciones.
        
        Parameters
        ----------
        args : Dict[str, Any]
            Argumentos utilizados en la ejecución
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Actualizar la configuración actual con los argumentos
        for key, value in args.items():
            if value is not None and key not in ["no_save_config", "show_command"]:
                self.config_manager.set(key, value)
        
        # Obtener el comando
        command = self.config_manager.get_last_command()
        
        print("\n" + "=" * 60)
        print("Para repetir este comando sin el modo interactivo:")
        print(f"\n{command}")
        print("=" * 60)
    
    def show_version(self) -> None:
        """
        Muestra la versión de la herramienta.
        
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        # Importar la versión desde el paquete principal
        try:
            from importlib.metadata import version
            try:
                pkg_version = version("audio-to-text-ia")
            except:
                # Fallback a la versión en __init__.py si el paquete no está instalado
                import importlib.util
                spec = importlib.util.find_spec("__init__")
                if spec:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    pkg_version = getattr(module, "__version__", "desconocida")
                else:
                    pkg_version = "desconocida"
        except ImportError:
            # Para Python < 3.8
            pkg_version = "desconocida"
        
        print(f"Audio-to-Text-IA versión {pkg_version}")
    
    def run(self) -> int:
        """
        Ejecuta la herramienta CLI.
        
        Returns
        -------
        int
            Código de salida (0 para éxito, otro valor para error)
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        try:
            logger.info("Iniciando CLI audio-to-text-ia")
            
            # Verificar si se proporcionaron argumentos
            args = self.parse_args()
            
            # Verificar si solo se quiere mostrar la versión
            if args.get("version", False):
                self.show_version()
                return 0
            
            # Verificar si se deben utilizar argumentos de línea de comandos o modo interactivo
            if len(sys.argv) <= 1:
                # Si no hay argumentos, entrar en modo interactivo
                args = self.interactive_mode()
            else:
                # Si hay argumentos, procesarlos normalmente
                logger.info(f"Argumentos proporcionados: {args}")
            
            # Validar argumentos
            missing_args = self.validate_args(args)
            if missing_args:
                logger.error(f"Faltan argumentos obligatorios: {', '.join(missing_args)}")
                print(f"Error: Faltan argumentos obligatorios: {', '.join(missing_args)}")
                print("Uso: python cli.py --generate <resumen|subtitle|zip_whatsapp_chat> --type_file <audio|video|text|zip> --file <ruta_archivo>")
                print("Para ver todos los flags disponibles: python cli.py --help")
                return 1
            
            # Extraer argumentos comunes
            file_path = args.get("file")
            type_file = args.get("type_file")
            source_language = args.get("source_language")
            target_language = args.get("target_language")
            translate = args.get("translate", False)
            whisper_model = args.get("model", "base")
            fecha_inicio = args.get("fecha_inicio")
            fecha_fin = args.get("fecha_fin")
            
            # Inicializar comandos con el modelo seleccionado
            self.initialize_commands(whisper_model)
            
            # Agregar timestamp para archivos generados
            timestamp = FileProcessor.get_current_timestamp()
            
            # Guardar configuración para futuras ejecuciones si no se especifica lo contrario
            if not args.get("no_save_config", False):
                self.save_config(args)
            
            # Procesar comandos
            logger.info(f"Ejecutando comando generate: {args['generate']}")
            
            # Ejecutar comando generate
            generate_result = self.generate_command.execute(
                subcommand=args["generate"],
                type_file=type_file,
                file=file_path,
                source_language=source_language,
                target_language=target_language,
                translate=translate,
                timestamp=timestamp,
                fecha_inicio=fecha_inicio,
                fecha_fin=fecha_fin
            )
            
            # Mostrar el resultado al usuario
            self.display_result(generate_result)
            
            # Mostrar el comando completo para futuras ejecuciones
            if args.get("show_command", False):
                self.show_command(args)
            
            logger.info("Ejecución completada con éxito")
            return 0
            
        except CommandException as e:
            error_message = f"Error: {str(e)}"
            logger.error(error_message)
            print(error_message)
            return 1
        except Exception as e:
            error_message = f"Error inesperado: {str(e)}"
            logger.critical(error_message, exc_info=True)
            print(error_message)
            return 2


def _check_ffmpeg() -> None:
    """
    Verifica que ffmpeg este disponible en el PATH.

    Whisper necesita ffmpeg para extraer audio de videos y normalizar formatos.
    Como ffmpeg no es pip-installable, aborta con un mensaje accionable cuando
    falta en el sistema.
    """
    if shutil.which('ffmpeg') is not None:
        return

    message = (
        '\nERROR: ffmpeg no esta instalado o no esta en el PATH.\n\n'
        'audio-to-text-ia requiere ffmpeg para procesar audio y video.\n\n'
        'Instalacion segun tu sistema:\n'
        '  - Ubuntu/Debian/WSL: sudo apt install ffmpeg\n'
        '  - macOS (Homebrew):  brew install ffmpeg\n'
        '  - Windows (choco):   choco install ffmpeg\n'
        '  - Windows (scoop):   scoop install ffmpeg\n\n'
        'Despues de instalar, abri una terminal nueva y volve a ejecutar.\n'
    )
    print(message, file=sys.stderr)
    sys.exit(1)


def main() -> int:
    """
    Función principal de entrada para la CLI.

    Returns
    -------
    int
        Código de salida

    :Authors:
        - Pablo Contreras

    :Created:
        - 2025/04/16
    """
    _check_ffmpeg()
    cli = AudioToTextCLI()
    return cli.run()


if __name__ == "__main__":
    sys.exit(main())
