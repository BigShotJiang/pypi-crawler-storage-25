# config/settings.py
import os
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

import yaml


# ---------------------------------------------------------------------------
# Defaults: red de seguridad cuando no hay envs/dev ni envs/prod ni shell vars
# ---------------------------------------------------------------------------
_ENV_DEFAULTS: Dict[str, str] = {
    'LOG_LEVEL': 'WARNING',
    'LOG_FILE': '0',
    'LOG_FILE_DIR': './logs',
}

_VALID_LOG_LEVELS = {'SILENT', 'ERROR', 'WARNING', 'INFO', 'DEBUG'}


def _parse_env_file(path: Path) -> Dict[str, str]:
    """Parser minimo para archivos KEY=VALUE.

    Soporta lineas en blanco, comentarios con `#` y valores entrecomillados.
    No expande variables ni interpreta sintaxis avanzada de bash.
    """
    result: Dict[str, str] = {}
    try:
        text = path.read_text(encoding='utf-8')
    except OSError:
        return result

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        value = value.strip()
        if (value.startswith('"') and value.endswith('"')) or (
            value.startswith("'") and value.endswith("'")
        ):
            value = value[1:-1]
        if key:
            result[key] = value
    return result


def _candidate_env_paths() -> List[Path]:
    """Devuelve rutas candidatas para envs/dev y envs/prod, en orden de busqueda.

    Cuando el codigo corre desde el repo, `envs/` esta al lado de cli.py.
    Cuando corre desde un wheel instalado, el directorio del paquete no
    contiene `envs/`, pero el usuario puede tener una `envs/` en su cwd.
    """
    paths: List[Path] = []

    package_root = Path(__file__).resolve().parent.parent
    paths.append(package_root / 'envs' / 'dev')
    paths.append(package_root / 'envs' / 'prod')

    cwd = Path.cwd()
    if cwd != package_root:
        paths.append(cwd / 'envs' / 'dev')
        paths.append(cwd / 'envs' / 'prod')

    return paths


def _load_env_vars() -> Dict[str, str]:
    """Resuelve las variables aplicando la precedencia documentada.

    Orden (mayor a menor):
      1. os.environ (lo que el usuario haya exportado en su shell).
      2. Primer envs/{dev,prod} encontrado en disco.
      3. Defaults hardcoded en `_ENV_DEFAULTS`.
    """
    resolved: Dict[str, str] = dict(_ENV_DEFAULTS)

    for path in _candidate_env_paths():
        if path.is_file():
            for key, value in _parse_env_file(path).items():
                if key in _ENV_DEFAULTS:
                    resolved[key] = value
            break

    for key in _ENV_DEFAULTS:
        if key in os.environ and os.environ[key] != '':
            resolved[key] = os.environ[key]

    return resolved


class Settings:
    _instance: Optional['Settings'] = None
    _config: Dict[str, Any] = {}
    _env: Dict[str, str] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Settings, cls).__new__(cls)
            cls._instance._load_env()
            cls._instance._load_config()
        return cls._instance

    def _load_env(self) -> None:
        self._env = _load_env_vars()

    def _load_config(self, config_path: str = None):
        """Carga la configuración desde un archivo YAML"""
        default_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'config',
            'settings.yml',
        )

        config_file = config_path or default_path

        try:
            with open(config_file, 'r') as f:
                raw_config = yaml.safe_load(f)
                self._process_config(raw_config)
        except FileNotFoundError:
            raise RuntimeError(f"Archivo de configuración no encontrado: {config_file}")
        except yaml.YAMLError as e:
            raise RuntimeError(f"Error en formato YAML: {str(e)}")

    def _process_config(self, raw_config: Dict[str, Any]):
        """Procesa las configuraciones y aplica formato a extensiones"""
        self._config['file_extensions'] = {
            file_type: [f'.{ext}' for ext in extensions]
            for file_type, extensions in raw_config.get('file_extensions', {}).items()
        }
        self._config['environment'] = raw_config.get('environment', 'local')
        self._config['project_folders'] = raw_config.get('project_folders', [])

    @classmethod
    def get_file_extensions(cls) -> Dict[str, List[str]]:
        """Obtiene las extensiones de archivo configuradas"""
        return cls()._config.get('file_extensions', {})

    @classmethod
    def get_environment(cls) -> str:
        """Obtiene el entorno configurado (local, dev, prod)"""
        return cls()._config.get('environment', 'local')

    @classmethod
    def get_project_folders(cls) -> List[str]:
        """Obtiene la lista de carpetas del proyecto a excluir en navegación local"""
        return cls()._config.get('project_folders', [])

    @classmethod
    def is_local_environment(cls) -> bool:
        """Verifica si el entorno actual es local"""
        return cls.get_environment() == 'local'

    @classmethod
    def get_log_level(cls) -> str:
        """Devuelve el nivel de log normalizado (uno de _VALID_LOG_LEVELS)."""
        raw = cls()._env.get('LOG_LEVEL', 'WARNING').strip().upper()
        if raw not in _VALID_LOG_LEVELS:
            return 'WARNING'
        return raw

    @classmethod
    def get_log_file_enabled(cls) -> bool:
        """Indica si se debe escribir log a archivo."""
        raw = cls()._env.get('LOG_FILE', '0').strip().lower()
        return raw in {'1', 'true', 'yes', 'on'}

    @classmethod
    def get_log_file_dir(cls) -> str:
        """Directorio donde se persistiran los archivos de log."""
        return cls()._env.get('LOG_FILE_DIR', './logs')
