from typing import List, Optional, Dict, Any, Union

class CommandException(Exception):
    """
    Excepción base para errores en comandos CLI.
    
    Esta clase sirve como base para todas las excepciones
    específicas del CLI.
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    pass


class FeatureNotAvailableException(CommandException):
    """
    Excepción para cuando una característica no está disponible.
    
    Se lanza cuando se intenta usar una característica que ha sido
    deshabilitada mediante feature flags.
    
    Parameters
    ----------
    feature_name : str
        Nombre de la característica no disponible
    message : Optional[str]
        Mensaje de error personalizado
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(self, feature_name: str, message: Optional[str] = None):
        self.feature_name = feature_name
        self.message = message or f"La característica '{feature_name}' no está disponible actualmente."
        super().__init__(self.message)


class UnsupportedCommandException(CommandException):
    """
    Excepción para cuando se solicita un comando no soportado.
    
    Se lanza cuando el usuario solicita un comando o subcomando
    que no existe o no está implementado.
    
    Parameters
    ----------
    command_name : str
        Nombre del comando solicitado
    available_commands : List[str]
        Lista de comandos disponibles
    message : Optional[str]
        Mensaje de error personalizado
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(self, command_name: str, available_commands: List[str], message: Optional[str] = None):
        self.command_name = command_name
        self.available_commands = available_commands
        available_str = ", ".join(available_commands)
        self.message = message or (
            f"El comando '{command_name}' no está soportado. "
            f"Comandos disponibles: {available_str}"
        )
        super().__init__(self.message)


class FileProcessingException(CommandException):
    """
    Excepción para errores durante el procesamiento de archivos.
    
    Se lanza cuando ocurre un error al procesar un archivo,
    como falta de permisos, formato inválido, etc.
    
    Parameters
    ----------
    file_path : str
        Ruta al archivo que se estaba procesando
    error_message : str
        Descripción del error ocurrido
    details : Optional[Dict[str, Any]]
        Detalles adicionales sobre el error
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(
        self, 
        file_path: str, 
        error_message: str,
        details: Optional[Dict[str, Any]] = None
    ):
        self.file_path = file_path
        self.error_message = error_message
        self.details = details or {}
        self.message = f"Error al procesar el archivo '{file_path}': {error_message}"
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convierte la excepción a un diccionario para respuestas de API.
        
        Returns
        -------
        Dict[str, Any]
            Representación de la excepción como diccionario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        result = {
            "status": "error",
            "message": self.error_message,
            "file": self.file_path
        }
        
        if self.details:
            result["details"] = self.details
            
        return result


class NoAudioStreamException(FileProcessingException):
    """
    Excepción para videos sin pista de audio.

    Caso esperado y manejable (no crítico): el video existe y es válido,
    pero no contiene stream de audio (ej. stickers animados o GIFs
    convertidos a MP4 por WhatsApp). Hereda de FileProcessingException
    para mantener compatibilidad con catchers existentes.

    Parameters
    ----------
    file_path : str
        Ruta al archivo de video sin audio
    """

    def __init__(self, file_path: str):
        super().__init__(
            file_path,
            "El video no contiene pista de audio (no transcribible)"
        )


class ConfigurationException(CommandException):
    """
    Excepción para errores de configuración.
    
    Se lanza cuando hay problemas con los archivos de configuración
    o los valores configurados son inválidos.
    
    Parameters
    ----------
    config_name : str
        Nombre de la configuración con el problema
    error_message : str
        Descripción del error ocurrido
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(self, config_name: str, error_message: str):
        self.config_name = config_name
        self.error_message = error_message
        self.message = f"Error de configuración en '{config_name}': {error_message}"
        super().__init__(self.message)


class ModelLoadException(CommandException):
    """
    Excepción para errores al cargar modelos de IA.
    
    Se lanza cuando hay problemas al cargar o inicializar
    un modelo de inteligencia artificial.
    
    Parameters
    ----------
    model_name : str
        Nombre del modelo que falló
    error_message : str
        Descripción del error ocurrido
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(self, model_name: str, error_message: str):
        self.model_name = model_name
        self.error_message = error_message
        self.message = f"Error al cargar el modelo '{model_name}': {error_message}"
        super().__init__(self.message)
        
        
class ValidationException(CommandException):
    """
    Excepción para errores de validación.
    
    Se lanza cuando los parámetros proporcionados no cumplen
    con las restricciones esperadas.
    
    Parameters
    ----------
    field : Optional[str]
        Nombre del campo que falló la validación
    error_message : str
        Descripción del error ocurrido
    errors : Optional[Dict[str, Union[str, List[str]]]]
        Diccionario con errores detallados por campo
    
    :Authors:
        - Pablo Contreras
        
    :Created:
        - 2025/04/16
    """
    
    def __init__(
        self, 
        error_message: str,
        field: Optional[str] = None,
        errors: Optional[Dict[str, Union[str, List[str]]]] = None
    ):
        self.field = field
        self.error_message = error_message
        self.errors = errors or {}
        
        field_prefix = f"Campo '{field}': " if field else ""
        self.message = f"Error de validación: {field_prefix}{error_message}"
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convierte la excepción a un diccionario para respuestas de API.
        
        Returns
        -------
        Dict[str, Any]
            Representación de la excepción como diccionario
            
        :Authors:
            - Pablo Contreras
            
        :Created:
            - 2025/04/16
        """
        result = {
            "status": "error",
            "message": self.error_message,
        }
        
        if self.field:
            result["field"] = self.field
            
        if self.errors:
            result["errors"] = self.errors
            
        return result