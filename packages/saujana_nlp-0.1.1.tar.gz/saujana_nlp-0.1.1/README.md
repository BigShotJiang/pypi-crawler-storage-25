# Saujana 🇮🇩

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://pypi.org/project/saujana-nlp/)
[![PyPI](https://img.shields.io/pypi/v/saujana-nlp.svg)](https://pypi.org/project/saujana-nlp/)
[![Website](https://img.shields.io/badge/website-live-brightgreen.svg)](https://saujana-nlp.netlify.app/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Saujana** adalah _standalone framework_ Natural Language Processing (NLP) dan Word Embedding native Bahasa Indonesia. 

---

## ✨ Fitur Utama

- 🚀 **Native Engine**: Pelatihan Word2Vec dan FastText kustom tanpa dependensi eksternal berat.
- 🧠 **Semantic API**: Pencarian kemiripan (*similarity*), analogi kata, dan deteksi OOV (*Out-of-Vocabulary*).
- 🔗 **Multilingual Alignment**: Penyelarasan ruang vektor bahasa daerah (Sunda, Jawa, Bali) ke Bahasa Indonesia menggunakan algoritma Procrustes.
- 🛠️ **Corpus Builder**: Alat untuk membangun dataset pelatihan dari ribuan file teks lokal secara otomatis.
- 🧩 **Saka-NLP Ready**: Terintegrasi penuh dengan ekosistem [Saka-NLP](https://saka-nlp.netlify.app/) untuk morfologi dan normalisasi Nusantara.

---

## 📦 Instalasi

```bash
pip install saujana-nlp
```

---

## 🚀 Penggunaan Cepat

### 1. Memuat Model Vektor
Saujana menyediakan model pre-trained yang siap digunakan untuk ekstraksi fitur semantik.

```python
import saujana

# Memuat model Bahasa Indonesia sedang (~200k kata)
nlp = saujana.load("id_saujana_md")

doc = nlp("Presiden bertolak menuju Jakarta untuk pertemuan tingkat tinggi.")

for token in doc:
    print(f"{token.text:12} | POS: {token.pos_:6} | Lemma: {token.lemma_}")
```

### 2. Analisis Kemiripan (Similarity)
Bandingkan dokumen atau kata berdasarkan konteks semantiknya.

```python
doc1 = nlp("Jokowi mengunjungi ibu kota.")
doc2 = nlp("Presiden pergi ke Jakarta.")

print(f"Skor Kemiripan: {doc1.similarity(doc2):.4f}")
```

---

## 🛠️ Fitur Lanjut

### 1. Pelatihan Model Word Embedding Native
Anda dapat melatih model Anda sendiri secara *native* dengan format `.npz` yang memuat kilat.

```python
from saujana.vectors.loader import train_word2vec

sentences = [["saya", "suka", "nlp"], ["saujana", "sangat", "cepat"]]
vocab = train_word2vec(sentences, vector_size=100, epochs=10)

# Cari kata terdekat
print(vocab.most_similar("nlp"))
```

### 2. Pembangun Korpus (Corpus Builder)
Gunakan ribuan data mentah Anda menjadi korpus siap latih.

```python
from saujana.vectors.training import CorpusBuilder

builder = CorpusBuilder()
builder.add_directory("./data/artikel_berita")
builder.add_file("./data/kamus_tambahan.txt")

# Memproses dan menggabung menjadi satu file korpus bersih
corpus_file = builder.build("data_latih.txt", lang="id")
```

### 3. Penyelarasan Bahasa Daerah (Alignment)
Selaraskan model bahasa daerah agar berada dalam ruang vektor yang sama dengan Bahasa Indonesia.

```python
from saujana.vectors.training import FastTextTrainer

trainer = FastTextTrainer()
# Definisi kata jangkar (anchor words)
anchors = [("makan", "tuang"), ("pergi", "angkat"), ("tidur", "kulem")]

# Putar model Sunda agar selaras dengan Indonesia
aligned_model = trainer.align_models(sunda_model, indo_model, anchors)
```

---

## 🤝 Ekosistem Saka-NLP

Saujana bertindak sebagai **lapisan semantik** (Word Embeddings) yang melengkapi **lapisan linguistik** (Morfologi/Normalisasi) dari **Saka-NLP**.

> [!TIP]
> Untuk dokumentasi lengkap mengenai **Normalisasi Slang**, **Stemming Nusantara**, **Analisis Morfologi Sunda/Jawa/Bali**, dan penggunaan modul **Saka-NLP** lainnya, silakan kunjungi:
> 
> 👉 **[https://saka-nlp.netlify.app/](https://saka-nlp.netlify.app/)**

---

## 📊 API Reference Singkat

| Objek     | Properti Utama                                | Deskripsi                                     |
| :-------- | :-------------------------------------------- | :-------------------------------------------- |
| **Token** | `text`, `pos_`, `lemma_`, `is_stop`, `vector` | Unit kata tunggal dalam dokumen.              |
| **Doc**   | `ents`, `sents`, `vector`, `similarity()`     | Kontainer teks hasil pemrosesan pipeline.     |
| **Vocab** | `most_similar()`, `analogy()`, `get_vector()` | Pusat data representasi vektor kata.          |
| **Span**  | `text`, `label_`, `vector`                    | Potongan dari dokumen (misal: Frasa/Entitas). |

---

## 📜 Lisensi
Saujana didistribusikan di bawah lisensi **MIT**. Bebas digunakan untuk keperluan riset maupun komersial.

---
**Website**: [saujana-nlp.netlify.app](https://saujana-nlp.netlify.app/)  
**Creator**: [Muhammad Ikhwan Fathulloh](https://github.com/Muhammad-Ikhwan-Fathulloh)  

*Dikembangkan dengan ❤️ untuk memperkuat kedaulatan data bahasa Nusantara.*
