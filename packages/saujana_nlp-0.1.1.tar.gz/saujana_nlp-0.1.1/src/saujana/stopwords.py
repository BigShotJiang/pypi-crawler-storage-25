"""
saujana.stopwords
~~~~~~~~~~~~~~~~~
Daftar stopwords (kata-kata fungsi) Bahasa Indonesia yang komprehensif.
Digunakan oleh Token.is_stop dan komponen pipeline.
"""

STOP_WORDS = {
    # Kata ganti orang
    "saya", "aku", "kamu", "engkau", "kau", "anda", "dia", "ia", "beliau",
    "kami", "kita", "mereka", "kalian",
    # Kata ganti penunjuk
    "ini", "itu", "tersebut", "sini", "situ", "sana",
    # Kata depan (preposisi)
    "di", "ke", "dari", "pada", "dalam", "dengan", "oleh", "untuk",
    "kepada", "terhadap", "antara", "hingga", "sampai", "tentang",
    "mengenai", "tanpa", "melalui", "bagi", "demi", "selama",
    # Kata penghubung (konjungsi)
    "dan", "atau", "tetapi", "tapi", "namun", "serta", "maupun",
    "melainkan", "sedangkan", "padahal", "karena", "sebab", "sehingga",
    "agar", "supaya", "jika", "kalau", "apabila", "bila", "walaupun",
    "meskipun", "walau", "meski", "ketika", "saat", "sewaktu",
    "sebelum", "sesudah", "setelah", "sejak", "sambil", "seraya",
    "bahwa", "yakni", "yaitu", "yang",
    # Kata keterangan (adverbia)
    "tidak", "bukan", "belum", "jangan", "tak", "tiada",
    "sangat", "amat", "sekali", "paling", "lebih", "kurang",
    "agak", "cukup", "hampir", "nyaris", "terlalu",
    "sudah", "telah", "akan", "sedang", "masih", "pernah",
    "selalu", "sering", "kadang", "jarang", "biasa",
    "segera", "sekarang", "kemudian", "lalu", "lantas",
    "juga", "pun", "lagi", "pula", "hanya", "saja", "cuma",
    "justru", "malah", "bahkan", "memang", "tentu", "pasti",
    "mungkin", "barangkali", "boleh", "bisa", "dapat", "mampu",
    "harus", "wajib", "perlu", "hendak", "mau", "ingin",
    # Kata bantu bilangan
    "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh",
    "delapan", "sembilan", "sepuluh", "se", "para",
    "semua", "seluruh", "setiap", "tiap", "masing",
    "beberapa", "banyak", "sedikit", "sebuah", "suatu",
    # Kata tanya
    "apa", "siapa", "mana", "kapan", "mengapa", "kenapa",
    "bagaimana", "berapa",
    # Partikel
    "lah", "kah", "tah", "pun",
    # Kata sandang
    "si", "sang", "sri",
    # Kata seru umum
    "ya", "oh", "ah", "eh", "wah", "nah",
    # Verba bantu
    "adalah", "ialah", "merupakan", "yaitu", "yakni",
    "ada", "terdapat", "menjadi", "jadi",
    # Lainnya
    "hal", "cara", "oleh", "sebagai", "seperti", "bagai",
    "daripada", "perihal", "secara", "begitu", "demikian",
    "saling", "sendiri", "diri",
}
