"""
saujana.language
~~~~~~~~~~~~~~~~
Pipeline pemrosesan teks utama.
Menggabungkan tokenisasi, POS tagging, NER, lemmatisasi, dan word embedding.
"""
from typing import List, Generator, Callable, Optional, Dict, Any
from .vectors.vocab import Vocab
from .tokens.doc import Doc
from .tokenizer import Tokenizer

class Language:
    """
    Pipeline pemrosesan teks utama — menyediakan antarmuka terpadu untuk NLP.
    
    Pipeline bawaan:
        1. Tokenizer (tokenisasi teks Indonesia)
        2. StopWordMarker (deteksi stopword)
        3. POSTagger (POS tagging rule-based)
        4. Lemmatizer (lemmatisasi berbasis aturan)
        5. EntityRecognizer (NER lookup)
    
    Contoh Saujana-style:
        nlp = saujana.load("id_saujana_md")
        doc = nlp("Jokowi bertolak ke Jakarta.")
        for token in doc:
            print(token.text, token.pos_, token.lemma_, token.is_stop)
        for ent in doc.ents:
            print(ent.text, ent.label_)
    
    Fitur Vektor:
        nlp.vocab.most_similar("presiden", topn=10)
        nlp.vocab.doesnt_match(["makan", "minum", "tidur", "jakarta"])
        nlp.vocab.analogy(positive=["raja", "wanita"], negative=["pria"])
    """
    
    def __init__(self, vocab: Vocab = None, meta: dict = None):
        self.vocab = vocab if vocab is not None else Vocab()
        self.meta = meta if meta is not None else {}
        self.lang_code = self.meta.get("lang", "id")
        self.tokenizer = Tokenizer()
        
        # Integrasi Saka-NLP jika tersedia
        try:
            import saka
            self.saka = saka
        except ImportError:
            self.saka = None
            
        self._pipeline: List[tuple] = []
        self._disabled: set = set()
        
    def __call__(self, text: str) -> Doc:
        """
        Proses teks melalui pipeline lengkap.
        
        Args:
            text: Teks input bahasa Indonesia.
            
        Returns:
            Objek Doc yang sudah diproses (token, POS, lemma, NER, vektor).
        """
        words = self.tokenizer(text)
        doc = Doc(self.vocab, words=words)
        
        # Jalankan pipeline components
        for name, component in self._pipeline:
            if name not in self._disabled:
                doc = component(doc)
        
        return doc
    
    def add_pipe(self, name: str, component: Callable, 
                 before: str = None, after: str = None, first: bool = False):
        """
        Tambahkan komponen ke pipeline.
        
        Args:
            name: Nama komponen.
            component: Callable yang menerima Doc dan mengembalikan Doc.
            before: Nama komponen sebelum mana ini disisipkan.
            after: Nama komponen sesudah mana ini disisipkan.
            first: Jika True, sisipkan di awal pipeline.
        """
        entry = (name, component)
        
        if first:
            self._pipeline.insert(0, entry)
        elif before:
            idx = self._get_pipe_index(before)
            self._pipeline.insert(idx, entry)
        elif after:
            idx = self._get_pipe_index(after) + 1
            self._pipeline.insert(idx, entry)
        else:
            self._pipeline.append(entry)
    
    def remove_pipe(self, name: str):
        """Hapus komponen dari pipeline."""
        self._pipeline = [(n, c) for n, c in self._pipeline if n != name]
    
    def replace_pipe(self, name: str, component: Callable):
        """Ganti komponen pipeline yang ada."""
        self._pipeline = [
            (n, component if n == name else c) for n, c in self._pipeline
        ]
    
    def disable_pipe(self, name: str):
        """Non-aktifkan komponen pipeline tanpa menghapusnya."""
        self._disabled.add(name)
    
    def enable_pipe(self, name: str):
        """Aktifkan kembali komponen pipeline yang di-disable."""
        self._disabled.discard(name)
    
    def get_pipe(self, name: str):
        """Dapatkan komponen pipeline berdasarkan nama."""
        for n, c in self._pipeline:
            if n == name:
                return c
        raise ValueError(f"Komponen '{name}' tidak ditemukan.")
    
    def _get_pipe_index(self, name: str) -> int:
        for i, (n, _) in enumerate(self._pipeline):
            if n == name:
                return i
        raise ValueError(f"Komponen '{name}' tidak ditemukan.")
        
    def pipe(self, texts: List[str], batch_size: int = 50, 
             n_process: int = 1) -> Generator[Doc, None, None]:
        """
        Proses banyak teks secara efisien (batch processing).
        
        Args:
            texts: List teks untuk diproses.
            batch_size: Ukuran batch.
            n_process: Jumlah proses paralel (future support).
            
        Yields:
            Objek Doc untuk setiap teks.
        """
        for text in texts:
            yield self(text)
    
    @property
    def pipe_names(self) -> List[str]:
        """Nama-nama komponen pipeline yang terpasang."""
        return [name for name, _ in self._pipeline]
    
    @property
    def pipe_labels(self) -> Dict[str, List[str]]:
        """Label-label dari setiap komponen pipeline."""
        return {name: [] for name, _ in self._pipeline}
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Analisis teks secara lengkap dan kembalikan sebagai dictionary.
        Berguna untuk debugging atau integrasi API.
        """
        doc = self(text)
        return {
            "text": doc.text,
            "tokens": [
                {
                    "text": t.text,
                    "pos": t.pos_,
                    "lemma": t.lemma_,
                    "is_stop": t.is_stop,
                    "is_alpha": t.is_alpha,
                    "has_vector": t.has_vector,
                    "ent_type": t.ent_type_,
                    "shape": t.shape_,
                }
                for t in doc
            ],
            "entities": [
                {"text": e.text, "label": e.label_} for e in doc.ents
            ],
            "sentences": [s.text for s in doc.sents],
            "vector_norm": doc.vector_norm,
        }
    
    def __repr__(self):
        name = self.meta.get('name', 'saujana')
        pipes = ', '.join(self.pipe_names)
        return f"<saujana.Language '{name}' pipeline=[{pipes}]>"


# ═══════════════════════════════════════════════════════════════════════════════
# Model Loading — entry point utama
# ═══════════════════════════════════════════════════════════════════════════════

def load(name: str, disable: List[str] = None) -> Language:
    """
    Memuat model bahasa dan mengembalikan objek Language dengan pipeline lengkap.
    
    Model yang tersedia:
        - "id_saujana_sm": Model kecil (50k kata, dim=100)
        - "id_saujana_md": Model sedang (200k kata, dim=300) ← RECOMMENDED
        - "id_saujana_lg": Model besar (500k kata, dim=300)
    
    Contoh:
        nlp = saujana.load("id_saujana_md")
        nlp = saujana.load("id_saujana_md", disable=["ner"])
    
    Args:
        name: Nama model.
        disable: List nama komponen pipeline yang tidak ingin diaktifkan.
        
    Returns:
        Objek Language yang siap digunakan.
    """
    from .vectors.loader import load_model
    from .components import (
        Sentencizer, StopWordMarker, POSTagger, 
        Lemmatizer, EntityRecognizer
    )
    
    # Muat vocab dengan vektor embedding
    vocab = Vocab()
    load_model(name, vocab)
    
    meta = {"name": name, "lang": "id", "version": "0.1.0"}
    nlp = Language(vocab=vocab, meta=meta)
    
    # Pasang pipeline bawaan
    nlp.add_pipe("sentencizer", Sentencizer())
    nlp.add_pipe("stopwords", StopWordMarker())
    nlp.add_pipe("tagger", POSTagger())
    nlp.add_pipe("lemmatizer", Lemmatizer())
    nlp.add_pipe("ner", EntityRecognizer())
    
    # Disable komponen jika diminta
    if disable:
        for pipe_name in disable:
            nlp.disable_pipe(pipe_name)
    
    return nlp
