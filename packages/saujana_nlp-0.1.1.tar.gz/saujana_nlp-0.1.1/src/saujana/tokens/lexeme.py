import numpy as np

class Lexeme:
    """
    Entri leksikal di dalam Vocab.
    
    Merepresentasikan sebuah kata secara independen dari konteks dokumen.
    Berguna untuk mengakses properti kata secara langsung dari Vocab
    tanpa harus membuat Doc terlebih dahulu.
    
    Contoh:
        lexeme = nlp.vocab.get_lexeme("indonesia")
        print(lexeme.text, lexeme.has_vector)
    """
    
    def __init__(self, vocab, text: str, vocab_id: int = -1):
        self.vocab = vocab
        self.text = text
        self.vocab_id = vocab_id
        self.lower_ = text.lower()
        self.is_alpha = text.isalpha()
        self.is_digit = text.isdigit()
        self.is_punct = not text.isalnum() and len(text) > 0
        self.like_num = self._check_like_num(text)
        
    @staticmethod
    def _check_like_num(text: str) -> bool:
        """Cek apakah teks terlihat seperti angka (termasuk format Indonesia)."""
        text = text.replace('.', '').replace(',', '')
        return text.isdigit()
    
    @property
    def has_vector(self) -> bool:
        return self.vocab.has_vector(self.text)
    
    @property
    def vector(self) -> np.ndarray:
        return self.vocab.get_vector(self.text)
    
    @property
    def vector_norm(self) -> float:
        return float(np.linalg.norm(self.vector))
    
    def similarity(self, other) -> float:
        """Cosine similarity dengan Lexeme/Token/Doc lain."""
        from saujana.vectors.vocab import cosine_similarity
        if hasattr(other, 'vector'):
            return cosine_similarity(self.vector, other.vector)
        return 0.0
    
    def __repr__(self):
        return f"Lexeme('{self.text}')"
    
    def __str__(self):
        return self.text
