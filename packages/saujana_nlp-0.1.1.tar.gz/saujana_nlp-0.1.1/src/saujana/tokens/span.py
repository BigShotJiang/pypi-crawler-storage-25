import numpy as np
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .doc import Doc
    from .token import Token

class Span:
    """
    A slice (potongan) dari sebuah Doc — merepresentasikan frasa atau sub-kalimat.
    """
    def __init__(self, doc: "Doc", start: int, end: int, label: str = ""):
        self.doc = doc
        self.start = start
        self.end = end
        self.label_ = label
        
    @property
    def text(self) -> str:
        """Mengembalikan teks mentah dari span ini."""
        return " ".join(t.text for t in self.doc[self.start:self.end])
    
    @property
    def tokens(self):
        """Mengembalikan list Token yang tercakup dalam span ini."""
        return [self.doc[i] for i in range(self.start, self.end)]
        
    @property
    def has_vector(self) -> bool:
        return any(t.has_vector for t in self.tokens)
        
    @property
    def vector(self) -> np.ndarray:
        """Rata-rata vektor dari semua token dalam span."""
        vecs = [t.vector for t in self.tokens if t.has_vector]
        if not vecs:
            return np.zeros(self.doc.vocab.vector_size, dtype=np.float32)
        return np.mean(vecs, axis=0)

    def similarity(self, other) -> float:
        """Cosine similarity dengan objek lain yang punya .vector."""
        from saujana.vectors.vocab import cosine_similarity
        if hasattr(other, 'vector'):
            return cosine_similarity(self.vector, other.vector)
        return 0.0
    
    def __len__(self):
        return self.end - self.start
        
    def __iter__(self):
        for i in range(self.start, self.end):
            yield self.doc[i]
    
    def __repr__(self):
        return self.text
    
    def __str__(self):
        return self.text
