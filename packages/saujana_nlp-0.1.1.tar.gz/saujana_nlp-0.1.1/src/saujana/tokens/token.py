"""
saujana.tokens.token
~~~~~~~~~~~~~~~~~~~~
Representasi satu kata (token) dalam dokumen.
Mendukung atribut linguistik like pos_, lemma_, is_stop, is_alpha, dll.
"""
import numpy as np
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .doc import Doc
    from saujana.vectors.vocab import Vocab

class Token:
    """
    Satu token (kata) dalam sebuah Doc.
    
    Menyimpan referensi ke Doc induk dan Vocab untuk pencarian vektor cepat.
    Atribut tambahan (pos_, lemma_, is_stop, ent_type_) di-set oleh
    komponen pipeline saat proses pembuatan Doc.
    
    Atribut:
        text (str): Teks asli token.
        i (int): Indeks token dalam dokumen.
        has_vector (bool): Apakah token memiliki vektor embedding.
        vector (np.ndarray): Vektor embedding kata.
        pos_ (str): POS tag (misalnya "NOUN", "VERB").
        lemma_ (str): Bentuk dasar kata.
        is_stop (bool): Apakah token adalah stopword.
        is_alpha (bool): Apakah token seluruhnya huruf.
        is_digit (bool): Apakah token seluruhnya angka.
        is_punct (bool): Apakah token tanda baca.
        like_num (bool): Apakah token menyerupai angka.
        ent_type_ (str): Tipe entitas (PERSON, LOC, ORG, "").
    """
    
    __slots__ = [
        'vocab', 'doc', 'vocab_id', 'text', 'i',
        '_pos', '_lemma', '_is_stop', '_ent_type',
        'is_sent_start',
    ]
    
    def __init__(self, vocab, doc, vocab_id: int, text: str, idx: int):
        self.vocab = vocab
        self.doc = doc
        self.vocab_id = vocab_id
        self.text = text
        self.i = idx
        
        # Atribut yang di-set oleh pipeline components
        self._pos = ""
        self._lemma = ""
        self._is_stop = None
        self._ent_type = ""
        self.is_sent_start = None
    
    # ─────────────────────────── Properti Vektor ───────────────────────────────
    
    @property
    def has_vector(self) -> bool:
        """True jika token memiliki vektor embedding."""
        return self.vocab.has_vector(self.text)
        
    @property
    def vector(self) -> np.ndarray:
        """Vektor embedding untuk token ini."""
        return self.vocab.get_vector(self.text)
        
    @property
    def vector_norm(self) -> float:
        """L2 norm dari vektor token."""
        return float(np.linalg.norm(self.vector))
        
    def similarity(self, other) -> float:
        """Cosine similarity dengan Token, Doc, atau Span lain."""
        from saujana.vectors.vocab import cosine_similarity
        if hasattr(other, 'vector'):
            return cosine_similarity(self.vector, other.vector)
        return 0.0
    
    # ─────────────────────────── Properti Linguistik ───────────────────────────
    
    @property
    def pos_(self) -> str:
        """POS tag (Universal Dependencies tagset)."""
        return self._pos
    
    @property
    def lemma_(self) -> str:
        """Bentuk dasar (lemma) dari kata."""
        return self._lemma if self._lemma else self.text.lower()
    
    @property
    def is_stop(self) -> bool:
        """True jika token adalah stopword."""
        if self._is_stop is not None:
            return self._is_stop
        # Fallback: cek langsung
        from saujana.stopwords import STOP_WORDS
        return self.text.lower() in STOP_WORDS
    
    @property
    def ent_type_(self) -> str:
        """Tipe entitas: 'PERSON', 'LOC', 'ORG', atau '' (bukan entitas)."""
        return self._ent_type
    
    @property
    def is_alpha(self) -> bool:
        """True jika token seluruhnya huruf alfabet."""
        return self.text.isalpha()
    
    @property
    def is_digit(self) -> bool:
        """True jika token seluruhnya angka."""
        return self.text.isdigit()
    
    @property
    def is_punct(self) -> bool:
        """True jika token adalah tanda baca."""
        return bool(self.text) and not self.text.isalnum()
    
    @property
    def is_space(self) -> bool:
        """True jika token adalah spasi/whitespace."""
        return self.text.isspace()
    
    @property
    def like_num(self) -> bool:
        """True jika token menyerupai angka (termasuk format Indonesia: 1.000.000)."""
        t = self.text.replace('.', '').replace(',', '')
        return t.isdigit()
    
    @property
    def lower_(self) -> str:
        """Teks dalam huruf kecil."""
        return self.text.lower()
    
    @property
    def shape_(self) -> str:
        """
        Bentuk ortografis token.
        Contoh: "Jakarta" → "Xxxxx", "2024" → "dddd", "NLP" → "XXX"
        """
        result = []
        for ch in self.text:
            if ch.isupper():
                result.append('X')
            elif ch.islower():
                result.append('x')
            elif ch.isdigit():
                result.append('d')
            else:
                result.append(ch)
        # Kompres pengulangan: "Xxxxxxx" → "Xxxxx"
        compressed = []
        for ch in result:
            if len(compressed) < 5 or compressed[-1] != ch:
                compressed.append(ch)
        return ''.join(compressed)
    
    @property
    def is_title(self) -> bool:
        """True jika token bentuk Title Case (huruf kapital di awal)."""
        return self.text.istitle()
    
    @property
    def is_upper(self) -> bool:
        """True jika token seluruhnya huruf besar."""
        return self.text.isupper()
    
    @property
    def is_lower(self) -> bool:
        """True jika token seluruhnya huruf kecil."""
        return self.text.islower()

    # ─────────────────────────── Representasi ──────────────────────────────────

    def __repr__(self):
        return self.text
    
    def __str__(self):
        return self.text
    
    def __len__(self):
        return len(self.text)
    
    def __eq__(self, other):
        if isinstance(other, Token):
            return self.text == other.text and self.i == other.i
        if isinstance(other, str):
            return self.text == other
        return NotImplemented
    
    def __hash__(self):
        return hash((self.text, self.i))
