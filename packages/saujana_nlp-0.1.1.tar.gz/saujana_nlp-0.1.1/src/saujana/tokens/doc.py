"""
saujana.tokens.doc
~~~~~~~~~~~~~~~~~~
Representasi Dokumen — kumpulan Token yang sudah diproses pipeline.
Mendukung similarity, sentence segmentation, NER entities, dan batch vectorization.
"""
import numpy as np
from typing import List, Iterator, Union, Tuple
from .token import Token
from .span import Span

class Doc:
    """
    Representasi sebuah dokumen (teks yang sudah diproses oleh pipeline).
    
    Objek Doc berisi kumpulan Token dan mendukung iterasi, slicing,
    similarity, sentence segmentation, dan named entities.
    
    Contoh:
        nlp = saujana.load("id_saujana_md")
        doc = nlp("Jokowi pergi ke Jakarta.")
        
        for token in doc:
            print(token.text, token.pos_, token.lemma_)
        
        for ent in doc.ents:
            print(ent.text, ent.label_)
    """
    
    def __init__(self, vocab, words: List[str]):
        self.vocab = vocab
        self.text = " ".join(words)
        self._ents: List[Span] = []
        
        # Inisialisasi token
        self._tokens: List[Token] = []
        for i, word in enumerate(words):
            vocab_id = vocab.strings.get(word, -1)
            token = Token(vocab=vocab, doc=self, vocab_id=vocab_id, text=word, idx=i)
            self._tokens.append(token)
    
    # ───────────────────────────── Properti Vektor ─────────────────────────────
    
    @property
    def has_vector(self) -> bool:
        """True jika setidaknya satu token memiliki vektor."""
        return any(t.has_vector for t in self._tokens)
        
    @property
    def vector(self) -> np.ndarray:
        """
        Vektor rata-rata dari seluruh token yang memiliki vektor.
        Mengembalikan zero vector jika tidak ada token ber-vektor.
        """
        if not self._tokens:
            return np.zeros(self.vocab.vector_size, dtype=np.float32)
            
        vecs = [t.vector for t in self._tokens if t.has_vector]
        if not vecs:
            return np.zeros(self.vocab.vector_size, dtype=np.float32)
            
        return np.mean(vecs, axis=0)

    @property
    def vector_norm(self) -> float:
        """L2 norm dari vektor dokumen."""
        return float(np.linalg.norm(self.vector))

    def similarity(self, other) -> float:
        """Cosine similarity dengan objek lain (Doc, Token, atau Span)."""
        from saujana.vectors.vocab import cosine_similarity
        if hasattr(other, 'vector'):
            return cosine_similarity(self.vector, other.vector)
        return 0.0
    
    # ──────────────────── Named Entities (NER) ─────────────────────────────────
    
    @property
    def ents(self) -> List[Span]:
        """Entitas-entitas bernama yang terdeteksi dalam dokumen."""
        return self._ents
    
    # ──────────────────────────── Span & Slicing ───────────────────────────────
    
    def char_span(self, start_idx: int, end_idx: int, label: str = "") -> Span:
        """
        Membuat Span dari indeks token.
        
        Args:
            start_idx: Indeks token awal (inklusif).
            end_idx: Indeks token akhir (eksklusif).
            label: Label opsional (misalnya untuk NER).
        """
        return Span(self, start_idx, end_idx, label=label)
    
    @property
    def sents(self):
        """
        Generator yang memecah dokumen menjadi kalimat
        berdasarkan tanda titik, tanda seru, dan tanda tanya.
        """
        start = 0
        for i, token in enumerate(self._tokens):
            if token.text in ('.', '!', '?'):
                yield Span(self, start, i + 1)
                start = i + 1
        # Sisa terakhir
        if start < len(self._tokens):
            yield Span(self, start, len(self._tokens))
    
    @property
    def noun_chunks(self):
        """
        Generator sederhana untuk mengekstrak frasa nomina.
        Menggunakan heuristik: DET? ADJ* NOUN+ (PROPN | NOUN)*
        """
        i = 0
        while i < len(self._tokens):
            token = self._tokens[i]
            
            if token.pos_ in ("NOUN", "PROPN"):
                start = i
                # Cek apakah ada DET/ADJ sebelumnya
                if i > 0 and self._tokens[i-1].pos_ in ("DET", "ADJ"):
                    start = i - 1
                # Perluas ke NOUN/PROPN berikutnya
                j = i + 1
                while j < len(self._tokens) and self._tokens[j].pos_ in ("NOUN", "PROPN"):
                    j += 1
                yield Span(self, start, j)
                i = j
            else:
                i += 1
    
    # ─────────────────────── Informasi Dokumen ─────────────────────────────────

    def count_by(self, attr: str) -> dict:
        """
        Hitung frekuensi berdasarkan atribut tertentu.
        
        Args:
            attr: Nama atribut token ("pos_", "lemma_", "text", "lower_", dll)
            
        Returns:
            Dict {nilai_atribut: jumlah}.
        """
        counts = {}
        for token in self._tokens:
            val = getattr(token, attr, token.text)
            counts[val] = counts.get(val, 0) + 1
        return counts
    
    def to_array(self, attr: str = "vector") -> np.ndarray:
        """
        Konversi dokumen ke array numpy.
        
        Args:
            attr: "vector" untuk matriks embedding (N x dim),
                  atau atribut lain untuk array 1D.
        """
        if attr == "vector":
            return np.array([t.vector for t in self._tokens], dtype=np.float32)
        return np.array([getattr(t, attr) for t in self._tokens])
    
    # ──────────────────────── Akses Token & Iterasi ────────────────────────────

    def __iter__(self) -> Iterator[Token]:
        return iter(self._tokens)
        
    def __len__(self) -> int:
        return len(self._tokens)
        
    def __getitem__(self, i) -> Union[Token, List[Token]]:
        if isinstance(i, slice):
            return self._tokens[i]
        return self._tokens[i]
    
    def __contains__(self, text: str) -> bool:
        """Cek apakah teks ada di dalam dokumen."""
        return any(t.text == text for t in self._tokens)
    
    # ──────────────────────────── Representasi ─────────────────────────────────
        
    def __repr__(self):
        return self.text
    
    def __str__(self):
        return self.text
