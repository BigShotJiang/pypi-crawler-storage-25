"""
Saujana — Library NLP dan Word Embedding untuk Bahasa Indonesia.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Saujana menyediakan objek Doc, Token, Span, dan Vocab yang terintegrasi 
dengan representasi vektor kata (word embeddings).

Contoh penggunaan:
    >>> import saujana
    >>> nlp = saujana.load("id_saujana_md")
    >>> doc = nlp("Jokowi bertolak ke Jakarta.")
    >>> for token in doc:
    ...     print(token.text, token.pos_, token.lemma_, token.is_stop)
    >>> for ent in doc.ents:
    ...     print(ent.text, ent.label_)

Fitur Word Embedding:
    >>> nlp.vocab.most_similar("presiden", topn=10)
    >>> nlp.vocab.doesnt_match(["makan", "minum", "tidur", "jakarta"])
    >>> nlp.vocab.analogy(positive=["raja", "wanita"], negative=["pria"])
"""

from .language import Language, load
from .tokens.doc import Doc
from .tokens.token import Token
from .tokens.span import Span
from .tokens.lexeme import Lexeme
from .vectors.vocab import Vocab, cosine_similarity
from .vectors.loader import (
    train_word2vec,
    from_keyed_vectors,
    to_keyed_vectors,
    load_vec_file,
    get_cache_dir,
    MODEL_REGISTRY,
)
from .stopwords import STOP_WORDS

__version__ = "0.1.1"
__all__ = [
    # Core
    "Language", "load",
    # Token objects
    "Doc", "Token", "Span", "Lexeme",
    # Vectors
    "Vocab", "cosine_similarity",
    # Training & Loading
    "train_word2vec",
    "from_keyed_vectors",
    "to_keyed_vectors",
    "load_vec_file",
    # Utilities
    "get_cache_dir", "MODEL_REGISTRY", "STOP_WORDS",
]
