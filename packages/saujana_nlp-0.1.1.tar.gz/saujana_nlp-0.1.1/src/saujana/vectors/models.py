"""
saujana.vectors.models
~~~~~~~~~~~~~~~~~~~~~~
Implementasi native Word2Vec (Skip-gram) dan FastText menggunakan NumPy.
Dibuat untuk kemandirian pustaka Saujana.
"""

import os
import json
import logging
import random
import collections
from typing import List, Dict, Optional, Tuple, Union, Iterable

import numpy as np
from tqdm import tqdm

# Konfigurasi Logging
logger = logging.getLogger(__name__)

def fnv1a_hash(data: str) -> int:
    """
    Implementasi hash FNV-1a untuk kompatibilitas FastText.
    Mengembalikan unsigned 32-bit integer.
    """
    hval = 0x811c9dc5
    for char in data.encode('utf-8'):
        hval = (hval ^ char) * 0x01000193
        hval &= 0xffffffff
    return hval

def sigmoid(x):
    """Fungsi aktivasi sigmoid yang stabil secara numerik."""
    return 1 / (1 + np.exp(-np.clip(x, -15, 15)))

class WordVectorModel:
    """Base class untuk model word embedding (Word2Vec/FastText)."""
    
    def __init__(
        self, 
        vector_size: int = 300, 
        window: int = 5, 
        min_count: int = 5, 
        negative: int = 5,
        epochs: int = 5,
        alpha: float = 0.025,
        min_alpha: float = 0.0001
    ):
        self.vector_size = vector_size
        self.window = window
        self.min_count = min_count
        self.negative = negative
        self.epochs = epochs
        self.alpha = alpha
        self.min_alpha = min_alpha
        
        self.wv = {}            # word -> vector (untuk inference cepat jika bukan FastText)
        self.vocab = {}         # word -> count
        self.index_to_word = [] # idx -> word
        self.word_to_index = {} # word -> idx
        
        self.vectors = None         # W (input vectors)
        self.vectors_lockf = None   # Untuk learning rate per word (optional)
        self.vectors_ngrams = None  # Untuk FastText
        self.syn1neg = None         # W' (negative sampling vectors)
        
        self.unigram_table = None
        self.table_size = 100_000_000

    def build_vocab(self, sentences: Iterable[List[str]]):
        """Membangun vocabulary dari generator kalimat."""
        logger.info("Building vocabulary...")
        word_counts = collections.Counter()
        for sentence in sentences:
            word_counts.update(sentence)
        
        # Filter berdasarkan min_count
        self.vocab = {w: c for w, c in word_counts.items() if c >= self.min_count}
        self.index_to_word = sorted(self.vocab.keys(), key=lambda w: self.vocab[w], reverse=True)
        self.word_to_index = {w: i for i, w in enumerate(self.index_to_word)}
        
        vocab_size = len(self.index_to_word)
        logger.info(f"Vocab size: {vocab_size:,} (filtered from {len(word_counts):,})")
        
        # Inisialisasi matriks
        self.vectors = (np.random.rand(vocab_size, self.vector_size) - 0.5) / self.vector_size
        self.syn1neg = np.zeros((vocab_size, self.vector_size))
        
        self._init_unigram_table()

    def _init_unigram_table(self):
        """Inisialisasi tabel untuk negative sampling (distribusi 3/4)."""
        logger.info("Initializing unigram table...")
        pow_counts = np.array([self.vocab[w]**0.75 for w in self.index_to_word])
        total_pow = pow_counts.sum()
        
        nums = np.round((pow_counts / total_pow) * self.table_size).astype(int)
        self.unigram_table = np.repeat(np.arange(len(self.index_to_word)), nums)
        np.random.shuffle(self.unigram_table)

    def train(self, sentences: List[List[str]]):
        """Melatih model menggunakan Skip-gram with Negative Sampling (SGNS)."""
        alpha = self.alpha
        alpha_step = (self.alpha - self.min_alpha) / self.epochs
        
        for epoch in range(self.epochs):
            logger.info(f"Epoch {epoch+1}/{self.epochs} (alpha={alpha:.4f})")
            
            # Shuffle sentences per epoch
            random.shuffle(sentences)
            
            pbar = tqdm(sentences, desc=f"Training epoch {epoch+1}")
            for sentence in pbar:
                indices = [self.word_to_index[w] for w in sentence if w in self.word_to_index]
                
                for i, target_idx in enumerate(indices):
                    # Dynamic window size
                    current_window = random.randint(1, self.window)
                    
                    start = max(0, i - current_window)
                    end = min(len(indices), i + current_window + 1)
                    
                    context_indices = [indices[j] for j in range(start, end) if i != j]
                    
                    for context_idx in context_indices:
                        self._train_sample(target_idx, context_idx, alpha)
            
            alpha -= alpha_step

    def _train_sample(self, target_idx, context_idx, alpha):
        """Satu langkah update SGNS."""
        # 1. Negative targets
        neg_indices = np.random.choice(self.unigram_table, self.negative)
        
        # Target + Negatives
        all_indices = np.concatenate(([context_idx], neg_indices))
        labels = np.zeros(len(all_indices))
        labels[0] = 1.0 # Context asli adalah positive label
        
        # Dot products
        dots = np.dot(self.syn1neg[all_indices], self.vectors[target_idx])
        probs = sigmoid(dots)
        
        # Gradients
        errors = probs - labels
        
        # Update context/negative weights: syn1neg = syn1neg - alpha * error * vectors[target]
        grad_syn1neg = np.outer(errors, self.vectors[target_idx])
        self.syn1neg[all_indices] -= alpha * grad_syn1neg
        
        # Update target weights: vectors = vectors - alpha * sum(error * syn1neg)
        grad_vectors = np.dot(errors, self.syn1neg[all_indices])
        self.vectors[target_idx] -= alpha * grad_vectors

class FastText(WordVectorModel):
    """Ekstensi FastText dengan dukungan subword (n-grams)."""
    
    def __init__(self, bucket: int = 2_000_000, min_n: int = 3, max_n: int = 6, **kwargs):
        super().__init__(**kwargs)
        self.bucket = bucket
        self.min_n = min_n
        self.max_n = max_n
        self.vectors_ngrams = None

    def build_vocab(self, sentences: List[List[str]]):
        super().build_vocab(sentences)
        # Inisialisasi n-gram weights
        logger.info(f"Initializing n-gram buckets ({self.bucket:,})...")
        self.vectors_ngrams = (np.random.rand(self.bucket, self.vector_size) - 0.5) / self.vector_size

    def get_ngrams(self, word: str) -> List[int]:
        """Mendapatkan bucket indices untuk n-grams dari sebuah kata."""
        word_marked = f"<{word}>"
        indices = []
        for n in range(self.min_n, self.max_n + 1):
            for i in range(len(word_marked) - n + 1):
                ngram = word_marked[i:i+n]
                # Filter agar tidak memasukkan kata utuh jika pas panjangnya (opsional, FT asli masukkan)
                h = fnv1a_hash(ngram)
                indices.append(h % self.bucket)
        return indices

    def _train_sample(self, target_idx, context_idx, alpha):
        """Update SGNS versi FastText (melibatkan n-grams)."""
        word = self.index_to_word[target_idx]
        ngram_indices = self.get_ngrams(word)
        
        # Vector target adalah rata-rata word vector + n-gram vectors (FT menjumlahkan)
        # Di sini kita gunakan penjumlahan agar sesuai dengan paper asli
        target_vec = self.vectors[target_idx].copy()
        if ngram_indices:
            target_vec += np.sum(self.vectors_ngrams[ngram_indices], axis=0)
        
        # Negative sampling
        neg_indices = np.random.choice(self.unigram_table, self.negative)
        all_indices = np.concatenate(([context_idx], neg_indices))
        labels = np.zeros(len(all_indices))
        labels[0] = 1.0
        
        dots = np.dot(self.syn1neg[all_indices], target_vec)
        probs = sigmoid(dots)
        errors = probs - labels
        
        # Update context vectors
        grad_syn1neg = np.outer(errors, target_vec)
        self.syn1neg[all_indices] -= alpha * grad_syn1neg
        
        # Update word + n-gram vectors
        main_grad = np.dot(errors, self.syn1neg[all_indices])
        self.vectors[target_idx] -= alpha * main_grad
        for idx in ngram_indices:
            self.vectors_ngrams[idx] -= alpha * main_grad

    def get_vector(self, word: str) -> np.ndarray:
        """Inference vektor untuk kata (mendukung OOV)."""
        if word in self.word_to_index:
            idx = self.word_to_index[word]
            vec = self.vectors[idx].copy()
        else:
            vec = np.zeros(self.vector_size)
        
        ngram_indices = self.get_ngrams(word)
        if ngram_indices:
            vec += np.sum(self.vectors_ngrams[ngram_indices], axis=0)
            
        # Normalisasi ke unit vector (opsional, tapi umum di FT)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec

    def save(self, path: str):
        """Menyimpan model ke format .npz Saujana."""
        data = {
            "index_to_word": np.array(self.index_to_word, dtype=object),
            "vectors": self.vectors,
            "vectors_ngrams": self.vectors_ngrams,
            "vector_size": np.array([self.vector_size]),
            "bucket": np.array([self.bucket]),
            "min_n": np.array([self.min_n]),
            "max_n": np.array([self.max_n])
        }
        np.savez_compressed(path, **data)
        logger.info(f"Model saved to {path}")

    @classmethod
    def load(cls, path: str):
        """Memuat model dari format .npz Saujana."""
        data = np.load(path, allow_pickle=True)
        model = cls(
            vector_size=int(data["vector_size"][0]),
            bucket=int(data["bucket"][0]),
            min_n=int(data["min_n"][0]),
            max_n=int(data["max_n"][0])
        )
        model.index_to_word = list(data["index_to_word"])
        model.word_to_index = {w: i for i, w in enumerate(model.index_to_word)}
        model.vectors = data["vectors"]
        model.vectors_ngrams = data["vectors_ngrams"]
        return model
