"""
saujana.vectors.loader
~~~~~~~~~~~~~~~~~~~~~~
Modul untuk mengunduh dan memuat model embedding pre-trained 
bahasa Indonesia ke dalam objek Vocab.

Mendukung format:
- .vec (FastText format: header + word vector per baris)
- .npz (format binary numpy saujana native — loading cepat)
- KeyedVectors (format standar vektor kata)
- native Saujana models
"""

import os
import sys
import gzip
import shutil
import urllib.request
from pathlib import Path
from typing import Optional

import numpy as np
from tqdm import tqdm

# ═══════════════════════════════════════════════════════════════════════════════
# Model Registry — daftar model yang tersedia untuk diunduh
# ═══════════════════════════════════════════════════════════════════════════════

MODEL_REGISTRY = {
    "id_saujana_sm": {
        "description": "Model kecil Bahasa Indonesia (~50k kata, dimensi 300)",
        "url": "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.id.300.vec.gz",
        "vector_size": 300,
        "max_vectors": 50000,
    },
    "id_saujana_md": {
        "description": "Model sedang Bahasa Indonesia (~200k kata, dimensi 300)",
        "url": "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.id.300.vec.gz",
        "vector_size": 300,
        "max_vectors": 200000,
    },
    "id_su_jw_ban_saujana_md": {
        "description": "Model Multilingual (ID, SU, JW, BAN) - Backbone + Alignment + Synthetic",
        "url": None, # Akan dilatih secara lokal/hosting kustom
        "vector_size": 300,
        "max_vectors": 0,
    },
    "id_saujana_lg": {
        "description": "Model besar Bahasa Indonesia (~2jt kata, dimensi 300)",
        "url": "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.id.300.vec.gz",
        "vector_size": 300,
        "max_vectors": 0,  # 0 = semua
    },
}

try:
    import saka
    HAS_SAKA = True
except ImportError:
    HAS_SAKA = False


# ═══════════════════════════════════════════════════════════════════════════════
# Helper Functions
# ═══════════════════════════════════════════════════════════════════════════════

def get_cache_dir() -> Path:
    """Mendapatkan direktori cache default untuk model Saujana."""
    home = Path.home()
    cache_dir = home / ".saujana_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def _download_with_progress(url: str, dest: str):
    """Download file dengan progress bar tqdm."""
    class _ProgressBar(tqdm):
        def update_to(self, b=1, bsize=1, tsize=None):
            if tsize is not None:
                self.total = tsize
            self.update(b * bsize - self.n)

    with _ProgressBar(unit='B', unit_scale=True, miniters=1,
                      desc=os.path.basename(dest)) as t:
        urllib.request.urlretrieve(url, filename=dest, reporthook=t.update_to)


# ═══════════════════════════════════════════════════════════════════════════════
# File Parsers
# ═══════════════════════════════════════════════════════════════════════════════

def load_vec_file(filepath: str, vocab, max_vectors: int = 0):
    """
    Memuat file format .vec (teks, format FastText/GloVe).
    
    Format baris:
        word 0.123 -0.456 0.789 ...
    
    Baris pertama boleh berisi header "N D" (jumlah kata dan dimensi).
    
    Args:
        filepath: Path ke file .vec.
        vocab: Objek Vocab yang akan diisi.
        max_vectors: Batas maksimal vektor yang dimuat (0 = semua).
    """
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        first_line = f.readline().rstrip()
        parts = first_line.split()
        
        # Deteksi header
        has_header = len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit()
        
        if has_header:
            total_words = int(parts[0])
            dim = int(parts[1])
        else:
            f.seek(0)
            total_words = None
            dim = None
        
        effective_total = min(total_words, max_vectors) if (total_words and max_vectors > 0) else total_words
        
        count = 0
        for line in tqdm(f, total=effective_total, desc="📖 Memuat vektor", unit=" kata"):
            line = line.rstrip()
            if not line:
                continue
                
            parts = line.split(' ')
            word = parts[0]
            
            try:
                vec = np.array([float(x) for x in parts[1:]], dtype=np.float32)
            except ValueError:
                continue
            
            if dim is None:
                dim = len(vec)
            
            if len(vec) != dim:
                continue
                
            vocab.add(word, vec)
            count += 1
            
            if max_vectors > 0 and count >= max_vectors:
                break
    
    print(f"Dimuat {count:,} vektor (dimensi={dim}) dari {os.path.basename(filepath)}")


def save_to_native(vocab, filepath: str):
    """
    Simpan Vocab ke format binary native Saujana untuk loading cepat.
    """
    words = [vocab._id_to_string[i] for i in range(len(vocab))]
    np.savez_compressed(
        filepath,
        words=np.array(words, dtype=object),
        vectors=vocab.vectors,
    )
    size_mb = os.path.getsize(filepath) / (1024 * 1024)
    print(f"💾 Tersimpan ke format native: {os.path.basename(filepath)} ({size_mb:.1f} MB)")


def load_from_native(filepath: str, vocab):
    """
    Muat Vocab dari format binary native Saujana (sangat cepat).
    """
    data = np.load(filepath, allow_pickle=True)
    words = data['words']
    vectors = data['vectors']
    
    vocab.vector_size = vectors.shape[1]
    vocab.vectors = vectors.astype(np.float32)
    
    for i, word in enumerate(words):
        word = str(word)
        vocab.strings[word] = i
        vocab._id_to_string[i] = word
    
    vocab._next_id = len(words)
    vocab._norms = None
    
    print(f"Dimuat {len(words):,} vektor dari format native (instant load)")


# ═══════════════════════════════════════════════════════════════════════════════
# KeyedVectors Bridge — integrasi dengan format vektor standar
# ═══════════════════════════════════════════════════════════════════════════════

def from_keyed_vectors(kv, vocab, max_vectors: int = 0):
    """
    Impor vektor dari objek KeyedVectors ke dalam Vocab Saujana.
    
    Contoh:
        from gensim.models import KeyedVectors
        kv = KeyedVectors.load_word2vec_format('model.vec')
        from_keyed_vectors(kv, vocab)
    
    Args:
        kv: Objek KeyedVectors.
        vocab: Objek Vocab Saujana yang akan diisi.
        max_vectors: Batas maksimal vektor (0 = semua).
    """
    words = kv.index_to_key
    vectors = kv.vectors
    
    if max_vectors > 0:
        words = words[:max_vectors]
        vectors = vectors[:max_vectors]
    
    vocab.vector_size = vectors.shape[1]
    vocab.vectors = np.empty((0, vocab.vector_size), dtype=np.float32)
    
    for word, vec in tqdm(zip(words, vectors), total=len(words), 
                          desc="🔄 Impor dari gensim", unit=" kata"):
        vocab.add(word, vec)
    
    print(f"Diimpor {len(vocab):,} vektor dari KeyedVectors")


def to_keyed_vectors(vocab):
    """
    Ekspor Vocab Saujana ke objek KeyedVectors.
    
    Contoh:
        kv = to_keyed_vectors(nlp.vocab)
        kv.save("model.kv")
    
    Returns:
        Objek KeyedVectors.
        
    Raises:
        ImportError: Jika gensim tidak terinstall (diperlukan untuk struktur data ini).
    """
    try:
        from gensim.models import KeyedVectors
    except ImportError:
        raise ImportError(
            "gensim diperlukan untuk ekspor. Install: pip install gensim"
        )
    
    kv = KeyedVectors(vector_size=vocab.vector_size)
    words = [vocab._id_to_string[i] for i in range(len(vocab))]
    kv.add_vectors(words, vocab.vectors)
    
    print(f"Diekspor {len(words):,} vektor ke KeyedVectors")
    return kv


# ═══════════════════════════════════════════════════════════════════════════════
# Word2Vec Training — melatih model dari corpus sendiri
# ═══════════════════════════════════════════════════════════════════════════════

def train_word2vec(
    sentences: list,
    vector_size: int = 100,
    window: int = 5,
    min_count: int = 2,
    epochs: int = 5,
    sg: int = 1, # Default ke skip-gram
) -> "Vocab":
    """
    Melatih model Word2Vec dari corpus kalimat sendiri menggunakan implementasi native.
    
    Contoh:
        corpus = [
            ["saya", "makan", "nasi"],
            ["dia", "minum", "kopi"],
            ["kami", "pergi", "ke", "sekolah"],
        ]
        vocab = train_word2vec(corpus, vector_size=100, epochs=10)
    
    Args:
        sentences: List of list of strings (sudah ter-tokenisasi).
        vector_size: Dimensi vektor output.
        window: Ukuran jendela konteks.
        min_count: Frekuensi minimum kata.
        epochs: Jumlah iterasi training.
        sg: Diabaikan (selalu Skip-gram dalam implementasi native ini).
        
    Returns:
        Objek Vocab Saujana yang terisi vektor hasil training.
    """
    from saujana.vectors.models import WordVectorModel
    from saujana.vectors.vocab import Vocab as VocabClass
    
    print("Melatih model Word2Vec (Native)...")
    model = WordVectorModel(
        vector_size=vector_size,
        window=window,
        min_count=min_count,
        epochs=epochs,
    )
    
    model.build_vocab(sentences)
    model.train(sentences)
    
    vocab = VocabClass()
    # Pindahkan vektor ke Vocab
    for i, word in enumerate(model.index_to_word):
        vocab.add(word, model.vectors[i])
    
    print(f"Training selesai! {len(vocab):,} kata, dimensi={vector_size}")
    return vocab


# ═══════════════════════════════════════════════════════════════════════════════
# Unified Loader — entry point utama
# ═══════════════════════════════════════════════════════════════════════════════

def load_model(model_name: str, vocab):
    """
    Memuat model embedding ke dalam vocab.
    
    Urutan percobaan:
    1. Cek file native (.npz) di cache → load instan.
    2. Cek file .vec di cache → parse dan simpan sebagai native.
    3. Download dari registry → parse → simpan native.
    4. Fallback → buat data demonstrasi.
    
    Args:
        model_name: Nama model (misal "id_saujana_md").
        vocab: Objek Vocab yang akan diisi.
    """
    cache_dir = get_cache_dir()
    native_path = cache_dir / f"{model_name}.npz"
    vec_path = cache_dir / f"{model_name}.vec"
    
    # 1. Format native (tercepat)
    if native_path.exists():
        load_from_native(str(native_path), vocab)
        return
    
    # 2. Format .vec di cache
    if vec_path.exists():
        registry = MODEL_REGISTRY.get(model_name, {})
        max_v = registry.get("max_vectors", 0)
        load_vec_file(str(vec_path), vocab, max_vectors=max_v)
        save_to_native(vocab, str(native_path))
        return
    
    # 3. Download dari registry
    registry_entry = MODEL_REGISTRY.get(model_name)
    if registry_entry and registry_entry.get("url"):
        url = registry_entry["url"]
        max_v = registry_entry.get("max_vectors", 0)
        
        # Cek apakah file .vec.gz original sudah di-cache (shared antar model)
        original_vec = cache_dir / "cc.id.300.vec"
        original_gz = cache_dir / "cc.id.300.vec.gz"
        
        if original_vec.exists():
            # Sudah ada file .vec dari download sebelumnya
            load_vec_file(str(original_vec), vocab, max_vectors=max_v)
            save_to_native(vocab, str(native_path))
            return
        
        if not original_gz.exists():
            print(f"Mengunduh model FastText Indonesia...")
            print(f"   Sumber: {url}")
            print(f"   Ukuran: ~1.2 GB (hanya perlu download sekali)")
            _download_with_progress(url, str(original_gz))
        
        # Dekompresi
        print("Mengekstrak file vektor...")
        with gzip.open(str(original_gz), 'rb') as f_in:
            with open(str(original_vec), 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        load_vec_file(str(original_vec), vocab, max_vectors=max_v)
        save_to_native(vocab, str(native_path))
        return
    
    # 4. Fallback: data demonstrasi
    print(f"Model '{model_name}' tidak ditemukan di registry.")
    print(f"   Menggunakan data demonstrasi ({len(_DEMO_WORDS)} kata).")
    print(f"   Untuk vektor sungguhan, gunakan: saujana.load('id_saujana_md')")
    _load_demo_data(vocab)


# ═══════════════════════════════════════════════════════════════════════════════
# Data Demonstrasi
# ═══════════════════════════════════════════════════════════════════════════════

_DEMO_WORDS = [
    # Kata kerja
    "makan", "minum", "pergi", "datang", "tidur", "bangun", "belajar",
    "bekerja", "bermain", "berlari", "menulis", "membaca", "bertolak",
    "mengajar", "berbicara", "mendengar", "melihat", "mencari", "membuat",
    "memberikan", "mengambil", "membangun", "mengenal", "memiliki",
    # Kata benda
    "rumah", "sekolah", "kantor", "universitas", "kota", "desa", "negara",
    "presiden", "menteri", "guru", "mahasiswa", "anak", "ibu", "bapak",
    "pemerintah", "rakyat", "bangsa", "dunia", "buku", "mobil", "air",
    "makanan", "pekerjaan", "uang", "waktu", "hari", "tahun", "bulan",
    # Nama/lokasi
    "indonesia", "jakarta", "bandung", "surabaya", "medan", "semarang",
    "jokowi", "soekarno", "yogyakarta", "bali", "kalimantan", "sumatera",
    # Kata sifat
    "besar", "kecil", "indah", "cantik", "pintar", "rajin", "malas",
    "baik", "buruk", "cepat", "lambat", "tinggi", "rendah", "panjang",
    "pendek", "baru", "lama", "muda", "tua", "kaya", "miskin",
    # Kata fungsi
    "ke", "di", "dari", "dan", "atau", "yang", "adalah", "dengan",
    "untuk", "pada", "ini", "itu", "tidak", "sudah", "akan", "sedang",
    "juga", "saya", "kamu", "dia", "kami", "mereka", "kita",
    # Kata benda lanjut
    "raja", "ratu", "wanita", "pria", "laki", "putri", "pangeran",
    "dokter", "petani", "nelayan", "tentara", "polisi", "hakim",
]

# Kluster semantik untuk demonstrasi yang realistis
_DEMO_CLUSTERS = [
    (["presiden", "jokowi", "soekarno", "menteri", "pemerintah"], 0.6),
    (["jakarta", "bandung", "surabaya", "medan", "semarang", "kota"], 0.5),
    (["indonesia", "negara", "bangsa", "rakyat"], 0.5),
    (["makan", "minum", "makanan", "air"], 0.6),
    (["pergi", "bertolak", "datang"], 0.7),
    (["ibu", "bapak", "anak", "wanita", "pria"], 0.5),
    (["raja", "ratu", "pangeran", "putri"], 0.7),
    (["guru", "mahasiswa", "belajar", "sekolah", "universitas"], 0.5),
    (["besar", "kecil", "tinggi", "rendah", "panjang", "pendek"], 0.4),
    (["indah", "cantik", "baik"], 0.6),
    (["dokter", "polisi", "tentara", "hakim", "petani", "nelayan"], 0.4),
    (["buku", "menulis", "membaca"], 0.6),
    (["rumah", "kantor", "sekolah"], 0.5),
    (["cepat", "lambat"], 0.5),
    (["baru", "lama", "muda", "tua"], 0.5),
    (["kaya", "miskin", "uang"], 0.5),
    (["pintar", "rajin", "malas"], 0.4),
]


def _load_demo_data(vocab):
    """Memuat data demonstrasi dengan kluster semantik yang realistis."""
    np.random.seed(42)
    base_dim = 300
    
    for word in _DEMO_WORDS:
        vec = np.random.normal(0, 0.3, base_dim).astype(np.float32)
        vocab.add(word, vec)
    
    # Terapkan kluster semantik
    for cluster_words, strength in _DEMO_CLUSTERS:
        valid = [w for w in cluster_words if w in vocab]
        if len(valid) < 2:
            continue
        # Hitung centroid kluster
        centroid = np.mean(
            [vocab.vectors[vocab.strings[w]] for w in valid], axis=0
        )
        # Geser vektor mendekati centroid
        for w in valid:
            idx = vocab.strings[w]
            original = vocab.vectors[idx].copy()
            vocab.vectors[idx] = (1 - strength) * original + strength * centroid
    
    vocab._norms = None
    print(f"Dimuat {len(vocab)} kata demonstrasi (dimensi={base_dim})")


# Legacy alias untuk backward compatibility
def load_from_fasttext(model_name: str, vocab):
    """Alias backward-compatible untuk load_model()."""
    load_model(model_name, vocab)
