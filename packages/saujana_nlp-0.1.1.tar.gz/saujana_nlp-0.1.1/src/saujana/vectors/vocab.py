"""
saujana.vectors.vocab
~~~~~~~~~~~~~~~~~~~~~
Vocabulary — menyimpan matriks vektor dan pemetaan kata → indeks.
Mendukung fitur pencarian kemiripan: most_similar, analogy, doesnt_match, n_similarity.
Serta fitur pemrosesan teks: get_lexeme, Vocab sebagai pusat data.
"""
import numpy as np
from typing import List, Tuple, Optional

def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """Menghitung cosine similarity antara dua vektor numpy."""
    vec1 = np.asarray(vec1, dtype=np.float32).flatten()
    vec2 = np.asarray(vec2, dtype=np.float32).flatten()
    
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return float(np.dot(vec1, vec2) / (norm1 * norm2))


class Vocab:
    """
    Vocabulary — menyimpan matriks vektor dan pemetaan kata → indeks.
    
    Dioptimalkan dengan pre-alokasi numpy array agar hemat RAM.
    Menggabungkan fitur Word Embedding (most_similar, analogy, doesnt_match)
    dengan fitur pemrosesan teks (get_lexeme, Vocab sebagai pusat data).
    
    Contoh Fitur Vektor:
        vocab.most_similar("presiden", topn=10)
        vocab.analogy(positive=["raja", "wanita"], negative=["pria"])
        vocab.doesnt_match(["makan", "minum", "tidur", "jakarta"])
        vocab.n_similarity(["raja", "pangeran"], ["ratu", "putri"])
        
    Contoh Lexeme:
        lexeme = vocab.get_lexeme("indonesia")
        print(lexeme.has_vector, lexeme.vector_norm)
    """
    
    def __init__(self):
        self.strings = {}          # word → int index
        self._id_to_string = {}    # int index → word
        self.vectors = None        # np.ndarray (N, dim)
        self.vector_size = 0
        self._next_id = 0
        self._norms = None         # cache untuk norm vektor
        
        # FastText subword support
        self.vectors_ngrams = None
        self.bucket = 0
        self.min_n = 3
        self.max_n = 6
        
    def add(self, word: str, vector: np.ndarray):
        """Menambahkan kata dan vektornya ke vocab."""
        if self.vectors is None:
            self.vector_size = len(vector)
            self.vectors = np.empty((0, self.vector_size), dtype=np.float32)
            
        if word not in self.strings:
            self.strings[word] = self._next_id
            self._id_to_string[self._next_id] = word
            self._next_id += 1
            self.vectors = np.vstack([self.vectors, np.asarray(vector, dtype=np.float32)])
            self._norms = None  # invalidate cache
    
    def add_bulk(self, words: List[str], vectors: np.ndarray):
        """
        Menambahkan banyak kata sekaligus (lebih cepat dari add() satu per satu).
        
        Args:
            words: List kata.
            vectors: Numpy array (N, dim) dari vektor.
        """
        if self.vectors is None:
            self.vector_size = vectors.shape[1]
            self.vectors = np.empty((0, self.vector_size), dtype=np.float32)
        
        new_words = []
        new_vecs = []
        for word, vec in zip(words, vectors):
            if word not in self.strings:
                self.strings[word] = self._next_id
                self._id_to_string[self._next_id] = word
                self._next_id += 1
                new_words.append(word)
                new_vecs.append(vec)
        
        if new_vecs:
            self.vectors = np.vstack([
                self.vectors, 
                np.array(new_vecs, dtype=np.float32)
            ])
            self._norms = None
    
    def __contains__(self, word: str) -> bool:
        return word in self.strings
        
    def __len__(self) -> int:
        return self._next_id
        
    def __getitem__(self, word: str) -> np.ndarray:
        """Akses vektor dengan indexing: vocab["kata"]"""
        return self.get_vector(word)
    
    def get_vector(self, word: str) -> np.ndarray:
        """
        Mendapatkan vektor dari sebuah kata. 
        Mendukung OOV menggunakan n-grams jika model FastText tersedia.
        """
        if word in self.strings:
            idx = self.strings[word]
            return self.vectors[idx]
        
        # OOV Support via FastText n-grams
        if self.vectors_ngrams is not None:
            from saujana.vectors.models import fnv1a_hash
            
            word_marked = f"<{word}>"
            vec = np.zeros(self.vector_size, dtype=np.float32)
            count = 0
            
            for n in range(self.min_n, self.max_n + 1):
                for i in range(len(word_marked) - n + 1):
                    ngram = word_marked[i:i+n]
                    h = fnv1a_hash(ngram)
                    idx = h % self.bucket
                    vec += self.vectors_ngrams[idx]
                    count += 1
            
            if count > 0:
                # Normalisasi seperti FastText
                norm = np.linalg.norm(vec)
                if norm > 0:
                    vec /= norm
                return vec
                
        return np.zeros(self.vector_size, dtype=np.float32)
        
    def has_vector(self, word: str) -> bool:
        """Cek apakah kata memiliki vektor."""
        return word in self.strings
    
    def _compute_norms(self):
        """Hitung semua norm sekaligus (vectorized, cepat)."""
        if self._norms is None and self.vectors is not None and len(self.vectors) > 0:
            self._norms = np.linalg.norm(self.vectors, axis=1)
            self._norms[self._norms == 0] = 1.0
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Fitur Word Embedding
    # ═══════════════════════════════════════════════════════════════════════════
    
    def most_similar(
        self, 
        positive: object = None,
        negative: List[str] = None,
        topn: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Mencari kata-kata yang paling mirip secara semantik.
        Mendukung string tunggal atau list.
        
        Contoh:
            vocab.most_similar("presiden")
            vocab.most_similar(positive=["raja", "wanita"], negative=["pria"])
        
        Args:
            positive: Kata tunggal (str) atau list kata yang vektornya dijumlahkan.
            negative: List kata yang vektornya dikurangkan.
            topn: Jumlah kata teratas yang dikembalikan.
            
        Returns:
            List tuple (kata, skor_kemiripan), diurutkan terbesar ke terkecil.
        """
        if positive is None:
            return []
        
        # Normalisasi: single word → list
        if isinstance(positive, str):
            positive = [positive]
        if negative is None:
            negative = []
        
        # Hitung vektor hasil
        result_vec = np.zeros(self.vector_size, dtype=np.float32)
        exclude = []
        
        for w in positive:
            if w in self.strings:
                result_vec += self.get_vector(w)
                exclude.append(w)
        for w in negative:
            if w in self.strings:
                result_vec -= self.get_vector(w)
                exclude.append(w)
        
        return self.most_similar_by_vector(result_vec, topn=topn, exclude=exclude)
    
    def most_similar_by_vector(
        self,
        vector: np.ndarray,
        topn: int = 10,
        exclude: Optional[List[str]] = None
    ) -> List[Tuple[str, float]]:
        """
        Cari kata-kata terdekat berdasarkan vektor tertentu.
        """
        if self.vectors is None or len(self.vectors) == 0:
            return []
            
        self._compute_norms()
        
        vec = np.asarray(vector, dtype=np.float32)
        vec_norm = np.linalg.norm(vec)
        if vec_norm == 0:
            return []
        
        similarities = self.vectors.dot(vec) / (self._norms * vec_norm)
        top_indices = np.argsort(similarities)[::-1]
        
        exclude_set = set(exclude) if exclude else set()
        results = []
        for idx in top_indices:
            w = self._id_to_string[idx]
            if w in exclude_set:
                continue
            results.append((w, float(similarities[idx])))
            if len(results) >= topn:
                break
        
        return results

    def analogy(
        self,
        positive: List[str],
        negative: List[str] = None,
        topn: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Operasi analogi vektor.
        Contoh: analogy(positive=["raja", "wanita"], negative=["pria"]) → "ratu"
        """
        return self.most_similar(positive=positive, negative=negative, topn=topn)

    def similarity(self, word1: str, word2: str) -> float:
        """
        Cosine similarity antara dua kata.
        
        Contoh:
            vocab.similarity("raja", "ratu")  # → ~0.7
        """
        if word1 not in self.strings or word2 not in self.strings:
            return 0.0
        return cosine_similarity(self.get_vector(word1), self.get_vector(word2))
    
    def n_similarity(self, words1: List[str], words2: List[str]) -> float:
        """
        Cosine similarity antara rata-rata vektor dua kelompok kata.
        
        Contoh:
            vocab.n_similarity(["raja", "pangeran"], ["ratu", "putri"])
        """
        vecs1 = [self.get_vector(w) for w in words1 if w in self.strings]
        vecs2 = [self.get_vector(w) for w in words2 if w in self.strings]
        
        if not vecs1 or not vecs2:
            return 0.0
        
        avg1 = np.mean(vecs1, axis=0)
        avg2 = np.mean(vecs2, axis=0)
        
        return cosine_similarity(avg1, avg2)
    
    def doesnt_match(self, words: List[str]) -> str:
        """
        Menemukan kata yang paling tidak cocok dalam sekelompok kata.
        
        Contoh:
            vocab.doesnt_match(["makan", "minum", "tidur", "jakarta"])  # → "jakarta"
        """
        valid_words = [w for w in words if w in self.strings]
        if len(valid_words) <= 1:
            return words[0] if words else ""
        
        # Hitung vektor rata-rata
        vecs = np.array([self.get_vector(w) for w in valid_words], dtype=np.float32)
        mean_vec = np.mean(vecs, axis=0)
        
        # Cari kata yang paling jauh dari rata-rata
        min_sim = float('inf')
        outlier = valid_words[0]
        for w in valid_words:
            sim = cosine_similarity(self.get_vector(w), mean_vec)
            if sim < min_sim:
                min_sim = sim
                outlier = w
        
        return outlier
    
    def distance(self, word1: str, word2: str) -> float:
        """
        Jarak kosinus antara dua kata (1 - similarity).
        
        Contoh:
            vocab.distance("raja", "ratu")  # → ~0.3
        """
        return 1.0 - self.similarity(word1, word2)
    
    def distances(self, word: str, other_words: List[str] = None) -> np.ndarray:
        """
        Jarak kosinus dari satu kata ke banyak kata lain.
        Jika other_words=None, hitung jarak ke semua kata di vocab.
        """
        if word not in self.strings:
            return np.array([])
        
        word_vec = self.get_vector(word)
        
        if other_words is None:
            self._compute_norms()
            word_norm = np.linalg.norm(word_vec)
            if word_norm == 0:
                return np.ones(len(self.vectors))
            sims = self.vectors.dot(word_vec) / (self._norms * word_norm)
            return 1.0 - sims
        
        return np.array([
            1.0 - cosine_similarity(word_vec, self.get_vector(w))
            for w in other_words
        ])
    
    def closer_than(self, word1: str, word2: str) -> List[str]:
        """
        Mengembalikan semua kata yang lebih dekat ke word1 daripada word2.
        
        Contoh:
            vocab.closer_than("jakarta", "surabaya")
        """
        if word1 not in self.strings or word2 not in self.strings:
            return []
        
        threshold = self.similarity(word1, word2)
        self._compute_norms()
        
        word_vec = self.get_vector(word1)
        word_norm = np.linalg.norm(word_vec)
        if word_norm == 0:
            return []
        
        sims = self.vectors.dot(word_vec) / (self._norms * word_norm)
        
        results = []
        for idx in range(len(sims)):
            if sims[idx] > threshold:
                w = self._id_to_string[idx]
                if w != word1:
                    results.append(w)
        
        return results

    # ═══════════════════════════════════════════════════════════════════════════
    # Fitur Pemrosesan Teks
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_lexeme(self, word: str):
        """Mendapatkan objek Lexeme untuk sebuah kata."""
        from saujana.tokens.lexeme import Lexeme
        vocab_id = self.strings.get(word, -1)
        return Lexeme(self, word, vocab_id=vocab_id)
    
    @property
    def words(self) -> List[str]:
        """Semua kata di dalam vocabulary."""
        return list(self.strings.keys())

    def __repr__(self):
        return f"<Vocab: {len(self)} kata, dimensi={self.vector_size}>"
