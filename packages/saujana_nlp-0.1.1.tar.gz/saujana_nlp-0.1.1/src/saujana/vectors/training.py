"""
saujana.vectors.training
~~~~~~~~~~~~~~~~~~~~~~~~
Modul untuk melatih model FastText kustom dengan dukungan multibahasa
(Indonesia, Sunda, Jawa, Bali) dan penyelarasan (alignment) vektor.
"""

import os
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional, Union

import numpy as np
import requests
from tqdm import tqdm

from saujana.vectors.models import FastText, WordVectorModel

try:
    import saka
except ImportError:
    saka = None

# Konfigurasi Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatasetRegistry:
    """Registri dataset untuk training Saujana FastText."""
    
    SOURCES = {
        "wiki": {
            "id": "https://dumps.wikimedia.org/idwiki/latest/idwiki-latest-pages-articles.xml.bz2",
            "su": "https://dumps.wikimedia.org/suwiki/latest/suwiki-latest-pages-articles.xml.bz2",
            "jw": "https://dumps.wikimedia.org/jwwiki/latest/jwwiki-latest-pages-articles.xml.bz2",
            "ban": "https://dumps.wikimedia.org/banwiki/latest/banwiki-latest-pages-articles.xml.bz2",
        },
        "bible": {
            # Repositori parallel corpora (contoh: dari Bible.com atau repository open source)
            "id": "https://raw.githubusercontent.com/christos-c/bible-corpus/master/bibles/Indonesian-Indonesian.txt",
            "su": "https://raw.githubusercontent.com/christos-c/bible-corpus/master/bibles/Sundanese-Sundanese.txt",
            "jw": "https://raw.githubusercontent.com/christos-c/bible-corpus/master/bibles/Javanese-Javanese.txt",
        },
        "folklore": {
             # Update URL jika sudah tersedia di Saka-NLP
             "regional": "https://raw.githubusercontent.com/Muhammad-Ikhwan-Fathulloh/Saka-NLP/main/data/folklores.json"
        }
    }

    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = cache_dir or (Path.home() / ".saujana_cache" / "datasets")
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def download(self, source: str, lang: str) -> Path:
        """Mengunduh dataset dari sumber tertentu."""
        url = self.SOURCES.get(source, {}).get(lang)
        if not url:
            raise ValueError(f"Sumber '{source}' untuk bahasa '{lang}' tidak tersedia.")
        
        dest = self.cache_dir / f"{source}_{lang}.raw"
        if dest.exists():
            logger.info(f"Using cached dataset: {dest}")
            return dest
        
        logger.info(f"Downloading {source} ({lang}) from {url}...")
        response = requests.get(url, stream=True)
        total_size = int(response.headers.get('content-length', 0))
        
        with open(dest, 'wb') as f, tqdm(
            total=total_size, unit='B', unit_scale=True, desc=f"Download {source}_{lang}"
        ) as pbar:
            for data in response.iter_content(chunk_size=1024):
                f.write(data)
                pbar.update(len(data))
        
        return dest

class CorpusProcessor:
    """Pemroses korpus menggunakan Saka-NLP untuk tokenisasi dan normalisasi."""
    
    def __init__(self):
        if not saka:
            logger.warning("Saka-NLP tidak terdeteksi. Tokenisasi akan menggunakan fallback standar.")

    def process_line(self, text: str, lang: str = "id") -> str:
        """Membersihkan dan menormalisasi satu baris teks."""
        if not text.strip():
            return ""
        
        if saka:
            # Menggunakan normalizer Saka jika tersedia
            text = saka.normalize(text)
            tokens = saka.tokenize(text.lower())
        else:
            tokens = text.lower().split()
            
        return " ".join(tokens)

    def prepare_corpus(self, input_path: Path, output_path: Path, lang: str = "id"):
        """Memproses seluruh file korpus."""
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as fin, \
             open(output_path, 'w', encoding='utf-8') as fout:
            for line in tqdm(fin, desc=f"Processing {lang} corpus"):
                processed = self.process_line(line, lang)
                if processed:
                    fout.write(processed + "\n")

class CorpusBuilder:
    """
    Membangun dataset kustom untuk word embedding dari berbagai sumber file lokal.
    
    Contoh:
        builder = CorpusBuilder()
        builder.add_directory("./data/raw_txt")
        builder.add_file("./data/extra.txt")
        builder.build("my_corpus.txt", lang="id")
    """
    
    def __init__(self):
        self.files: List[Path] = []
        self.processor = CorpusProcessor()

    def add_file(self, path: Union[str, Path]):
        """Menambahkan satu file teks ke dalam daftar sumber."""
        p = Path(path)
        if p.exists() and p.is_file():
            self.files.append(p)
            logger.info(f"File ditambahkan: {p.name}")
        else:
            logger.error(f"File tidak ditemukan: {path}")

    def add_directory(self, directory: Union[str, Path], extension: str = "txt"):
        """Menambahkan semua file dengan ekstensi tertentu dalam sebuah direktori."""
        dir_path = Path(directory)
        if dir_path.exists() and dir_path.is_directory():
            count = 0
            for file in dir_path.glob(f"*.{extension}"):
                self.files.append(file)
                count += 1
            logger.info(f"{count} file dari direktori '{dir_path.name}' ditambahkan.")
        else:
            logger.error(f"Direktori tidak ditemukan: {directory}")

    def build(self, output_path: Union[str, Path], lang: str = "id"):
        """
        Memproses semua file yang sudah ditambahkan dan menggabungkannya 
        menjadi satu file korpus yang bersih.
        """
        output_p = Path(output_path)
        logger.info(f"Membangun korpus ke {output_p}...")
        
        total_lines = 0
        with open(output_p, 'w', encoding='utf-8') as fout:
            for file_path in self.files:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as fin:
                    # Proses per baris untuk efisiensi memori
                    for line in fin:
                        processed = self.processor.process_line(line, lang)
                        if processed:
                            fout.write(processed + "\n")
                            total_lines += 1
                            
        logger.info(f"Selesai! Korpus '{output_p.name}' berisi {total_lines:,} baris.")
        return output_p

class FastTextTrainer:
    """Pipeline pelatihan FastText."""
    
    def __init__(self, vector_size: int = 300, window: int = 5, min_count: int = 5):
        self.vector_size = vector_size
        self.window = window
        self.min_count = min_count

    def train(self, corpus_path: Path, model_output: Path):
        """Melatih model FastText dari file korpus menggunakan implementasi native."""
        logger.info(f"Training native FastText model on {corpus_path}...")
        
        # Baca kalimat
        sentences = []
        with open(corpus_path, 'r', encoding='utf-8') as f:
            for line in f:
                tokens = line.strip().split()
                if tokens:
                    sentences.append(tokens)
        
        model = FastText(
            vector_size=self.vector_size,
            window=self.window,
            min_count=self.min_count,
            epochs=5 # Default
        )
        
        model.build_vocab(sentences)
        model.train(sentences)
        
        model.save(str(model_output))
        logger.info(f"Model saved to {model_output}")
        return model

    def align_models(self, source_model, target_model, anchors: List[tuple]):
        """
        Penyelarasan ruang vektor (Cross-Lingual Alignment) menggunakan Procrustes.
        anchors: List of (source_word, target_word) pairs.
        """
        logger.info(f"Aligning models using {len(anchors)} anchors...")
        
        source_vecs = []
        target_vecs = []
        
        for src_w, tgt_w in anchors:
            if src_w in source_model.word_to_index and tgt_w in target_model.word_to_index:
                source_vecs.append(source_model.vectors[source_model.word_to_index[src_w]])
                target_vecs.append(target_model.vectors[target_model.word_to_index[tgt_w]])
        
        if len(source_vecs) < 2:
            logger.warning("Not enough anchors found in both models for alignment.")
            return source_model
            
        X = np.array(source_vecs)
        Y = np.array(target_vecs)
        
        # SVD Procrustes: W = UV^T where U, S, V^T = SVD(Y^T X)
        # Note: matrices should be centered or normalized for better results
        M = Y.T @ X
        U, S, Vt = np.linalg.svd(M)
        W = U @ Vt
        
        # Apply transformation to the entire source model
        source_model.vectors = source_model.vectors @ W.T
        if source_model.vectors_ngrams is not None:
            source_model.vectors_ngrams = source_model.vectors_ngrams @ W.T
            
        logger.info("Alignment complete.")
        return source_model
