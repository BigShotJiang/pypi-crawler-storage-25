"""
saujana.tokenizer
~~~~~~~~~~~~~~~~~
Tokenizer khusus Bahasa Indonesia. Memisahkan teks menjadi token
berdasarkan whitespace, tanda baca, dan aturan khusus Indonesia.
"""
import re
from typing import List

# Pola regex untuk tokenisasi dasar Indonesia
# Memecah tanda baca dari kata, namun menjaga singkatan umum
_PUNCTUATION = r'([!\"#$%&\'()*+,\-./:;<=>?@\[\\\]^_`{|}~])'
_WHITESPACE = re.compile(r'\s+')

# Singkatan umum bahasa Indonesia yang TIDAK boleh dipecah
_ID_ABBREVIATIONS = {
    "dr.", "drs.", "prof.", "ir.", "st.", "s.t.", "s.kom.", "s.h.",
    "m.t.", "m.kom.", "m.h.", "ph.d.", "dll.", "dsb.", "dkk.",
    "no.", "tel.", "fax.", "jl.", "kel.", "kec.", "kab.", "prov.",
    "sdr.", "sdri.", "yth.", "a.n.", "u.p.", "c.q.",
}

class Tokenizer:
    """
    Tokenizer sederhana namun cerdas untuk Bahasa Indonesia.
    Menangani:
    - Pemisahan tanda baca
    - Penanganan singkatan umum Indonesia
    - Penanganan angka dan satuan
    - Normalisasi whitespace
    """
    
    def __init__(self):
        self.abbreviations = _ID_ABBREVIATIONS
        # Regex: tangkap tanda baca sebagai token terpisah
        self._punct_re = re.compile(
            r'(\.\.\.|[!\"#$%&\'()*+,\/:;<=>?@\[\\\]^_`{|}~])'
        )
        # Regex khusus untuk titik di akhir kata (perlu hati-hati dengan singkatan)
        self._period_re = re.compile(r'(\.)$')
    
    def __call__(self, text: str) -> List[str]:
        """Tokenisasi teks dan kembalikan list kata/token."""
        return self.tokenize(text)
        
    def tokenize(self, text: str) -> List[str]:
        """
        Tokenisasi teks menjadi list string.
        
        Args:
            text: Teks input dalam bahasa Indonesia.
        
        Returns:
            List token (string).
        """
        if not text or not text.strip():
            return []
        
        # Normalisasi whitespace
        text = _WHITESPACE.sub(' ', text.strip())
        
        # Pisahkan tanda baca KECUALI titik (ditangani khusus)
        text = self._punct_re.sub(r' \1 ', text)
        
        # Split berdasarkan spasi
        raw_tokens = text.split()
        
        # Perbaikan: gabungkan kembali singkatan yang terpecah dan tangani titik akhir
        tokens = []
        i = 0
        while i < len(raw_tokens):
            token = raw_tokens[i]
            
            # Cek apakah token tergabung berikutnya membentuk singkatan
            if i + 1 < len(raw_tokens) and raw_tokens[i + 1] == '.':
                combined = token + '.'
                if combined.lower() in self.abbreviations:
                    tokens.append(combined)
                    i += 2
                    continue
            
            # Cek titik di akhir token
            if token.endswith('.') and len(token) > 1:
                if token.lower() in self.abbreviations:
                    tokens.append(token)
                else:
                    # Pisahkan titik dari kata
                    tokens.append(token[:-1])
                    tokens.append('.')
            else:
                if token:  # skip empty strings
                    tokens.append(token)
            
            i += 1
        
        return tokens
