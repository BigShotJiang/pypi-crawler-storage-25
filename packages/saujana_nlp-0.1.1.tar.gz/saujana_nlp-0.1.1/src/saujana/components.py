"""
saujana.components
~~~~~~~~~~~~~~~~~~
Komponen pipeline bawaan untuk Saujana.
Terdiri dari: Sentencizer, StopWordMarker, POSTagger (rule-based), Lemmatizer.
"""

import re
from typing import List, Dict, Set

# ═══════════════════════════════════════════════════════════════════════════════
# Sentencizer — segmentasi kalimat
# ═══════════════════════════════════════════════════════════════════════════════

class Sentencizer:
    """
    Komponen pipeline yang menandai batas kalimat.
    """
    
    def __init__(self, punct_chars=None):
        self.punct_chars = punct_chars or {'.', '!', '?'}
    
    def __call__(self, doc):
        for token in doc:
            if token.i == 0:
                token.is_sent_start = True
            elif doc[token.i - 1].text in self.punct_chars:
                token.is_sent_start = True
            else:
                token.is_sent_start = False
        return doc


# ═══════════════════════════════════════════════════════════════════════════════
# StopWordMarker — deteksi stopword
# ═══════════════════════════════════════════════════════════════════════════════

class StopWordMarker:
    """Menandai token-token yang merupakan stopword."""
    
    def __init__(self, stop_words=None):
        if stop_words is None:
            from saujana.stopwords import STOP_WORDS
            stop_words = STOP_WORDS
        self.stop_words = stop_words
    
    def __call__(self, doc):
        for token in doc:
            token._is_stop = token.text.lower() in self.stop_words
        return doc


# ═══════════════════════════════════════════════════════════════════════════════
# POSTagger — POS tagging berbasis aturan untuk Bahasa Indonesia
# ═══════════════════════════════════════════════════════════════════════════════

# Tag POS yang digunakan (subset Universal Dependencies)
# NOUN, VERB, ADJ, ADV, ADP, CONJ, DET, NUM, PRON, PUNCT, PART, X

_PUNCT_RE = re.compile(r'^[^\w\s]+$')
_NUM_RE = re.compile(r'^[\d.,]+$')

# Lookup table untuk kata-kata umum Indonesia
_POS_LOOKUP: Dict[str, str] = {
    # Pronouns (PRON)
    "saya": "PRON", "aku": "PRON", "kamu": "PRON", "engkau": "PRON",
    "anda": "PRON", "dia": "PRON", "ia": "PRON", "beliau": "PRON",
    "kami": "PRON", "kita": "PRON", "mereka": "PRON", "kalian": "PRON",
    "ini": "PRON", "itu": "PRON",
    # Adpositions (ADP)
    "di": "ADP", "ke": "ADP", "dari": "ADP", "pada": "ADP",
    "dalam": "ADP", "dengan": "ADP", "oleh": "ADP", "untuk": "ADP",
    "kepada": "ADP", "terhadap": "ADP", "antara": "ADP", "hingga": "ADP",
    "sampai": "ADP", "tentang": "ADP", "tanpa": "ADP", "melalui": "ADP",
    "bagi": "ADP", "demi": "ADP",
    # Conjunctions (CONJ / SCONJ)
    "dan": "CCONJ", "atau": "CCONJ", "serta": "CCONJ", "maupun": "CCONJ",
    "tetapi": "CCONJ", "tapi": "CCONJ", "namun": "CCONJ",
    "karena": "SCONJ", "sebab": "SCONJ", "sehingga": "SCONJ",
    "agar": "SCONJ", "supaya": "SCONJ", "jika": "SCONJ", "kalau": "SCONJ",
    "apabila": "SCONJ", "bila": "SCONJ", "walaupun": "SCONJ",
    "meskipun": "SCONJ", "ketika": "SCONJ", "bahwa": "SCONJ",
    "sebelum": "SCONJ", "sesudah": "SCONJ", "setelah": "SCONJ",
    "sejak": "SCONJ", "sambil": "SCONJ",
    # Determiners (DET)
    "sebuah": "DET", "suatu": "DET", "para": "DET", "sang": "DET",
    "si": "DET", "semua": "DET", "seluruh": "DET", "setiap": "DET",
    "beberapa": "DET", "segala": "DET",
    # Adverbs (ADV)
    "tidak": "ADV", "bukan": "ADV", "belum": "ADV", "jangan": "ADV",
    "sangat": "ADV", "amat": "ADV", "paling": "ADV", "lebih": "ADV",
    "kurang": "ADV", "sudah": "ADV", "telah": "ADV", "akan": "ADV",
    "sedang": "ADV", "masih": "ADV", "pernah": "ADV", "selalu": "ADV",
    "sering": "ADV", "jarang": "ADV", "segera": "ADV", "hanya": "ADV",
    "juga": "ADV", "bahkan": "ADV", "memang": "ADV", "tentu": "ADV",
    "mungkin": "ADV", "pasti": "ADV",
    # Auxiliary (AUX)
    "adalah": "AUX", "ialah": "AUX", "merupakan": "AUX",
    "bisa": "AUX", "dapat": "AUX", "mampu": "AUX",
    "harus": "AUX", "boleh": "AUX", "perlu": "AUX",
    "hendak": "AUX", "mau": "AUX", "ingin": "AUX",
    # Particles (PART)
    "lah": "PART", "kah": "PART", "pun": "PART", "tah": "PART",
    # Numbers
    "satu": "NUM", "dua": "NUM", "tiga": "NUM", "empat": "NUM",
    "lima": "NUM", "enam": "NUM", "tujuh": "NUM", "delapan": "NUM",
    "sembilan": "NUM", "sepuluh": "NUM", "seratus": "NUM", "seribu": "NUM",
    "juta": "NUM", "miliar": "NUM", "ribu": "NUM",
}

# Prefiks dan sufiks verbal Indonesia
_VERB_PREFIXES = {"me", "men", "mem", "meng", "meny", "ber", "di", "ter", "per", "ke"}
_VERB_SUFFIXES = {"kan", "an", "i"}
_ADJ_SUFFIXES = {"if", "is", "al", "il", "ik"}

# Prefiks nomina
_NOUN_PREFIXES = {"pe", "pen", "pem", "peng", "peny", "per", "ke"}


class POSTagger:
    """
    POS Tagger berbasis aturan untuk Bahasa Indonesia.
    Menggunakan kombinasi lookup table dan aturan morfologis (prefiks/sufiks).
    
    Tags mengikuti Universal Dependencies (UD) tagset.
    """
    
    def __init__(self, lookup: Dict[str, str] = None):
        self.lookup = lookup if lookup is not None else _POS_LOOKUP
    
    def _predict_pos(self, word: str) -> str:
        """Prediksi POS tag untuk satu kata."""
        lower = word.lower()
        
        # 1. Lookup langsung
        if lower in self.lookup:
            return self.lookup[lower]
        
        # 2. Tanda baca
        if _PUNCT_RE.match(word):
            return "PUNCT"
        
        # 3. Angka
        if _NUM_RE.match(word):
            return "NUM"
        
        # 4. Aturan morfologis — prefiks verbal
        for prefix in sorted(_VERB_PREFIXES, key=len, reverse=True):
            if lower.startswith(prefix) and len(lower) > len(prefix) + 2:
                return "VERB"
        
        # 5. Sufiks verbal
        for suffix in _VERB_SUFFIXES:
            if lower.endswith(suffix) and len(lower) > len(suffix) + 2:
                return "VERB"
        
        # 6. Sufiks adjektival
        for suffix in _ADJ_SUFFIXES:
            if lower.endswith(suffix) and len(lower) > len(suffix) + 2:
                return "ADJ"
        
        # 7. Proper noun (huruf kapital)
        if word[0].isupper() and word[1:].islower() if len(word) > 1 else word.isupper():
            return "PROPN"
        
        # 8. Default: NOUN
        return "NOUN"
    
    def __call__(self, doc):
        """Terapkan POS tagging ke seluruh dokumen."""
        for token in doc:
            token._pos = self._predict_pos(token.text)
        return doc


# ═══════════════════════════════════════════════════════════════════════════════
# Lemmatizer — lemmatisasi sederhana berbasis aturan Indonesia
# ═══════════════════════════════════════════════════════════════════════════════

# Prefiks-prefiks yang akan dihapus saat lemmatisasi
_LEMMA_PREFIXES = [
    ("memper", 6), ("member", 6), ("diper", 5), ("diter", 5),
    ("meny", 4), ("meng", 4), ("mem", 3), ("men", 3), ("me", 2),
    ("peny", 4), ("peng", 4), ("pem", 3), ("pen", 3), ("pe", 2),
    ("ber", 3), ("di", 2), ("ter", 3), ("se", 2), ("ke", 2),
]

_LEMMA_SUFFIXES = [
    ("kan", 3), ("an", 2), ("i", 1),
]

_LEMMA_CONFIXES = [
    ("ke", "an"), ("per", "an"), ("ber", "an"), ("se", "nya"),
]


class Lemmatizer:
    """
    Lemmatizer sederhana berbasis aturan untuk Bahasa Indonesia.
    Menghapus imbuhan (prefiks dan sufiks) untuk mendapatkan kata dasar.
    """
    
    def __init__(self, dictionary: Set[str] = None):
        self.dictionary = dictionary or set()
    
    def _lemmatize(self, word: str) -> str:
        """Lemmatisasi satu kata."""
        lower = word.lower()
        
        # Jika kata ada di kamus, langsung kembalikan
        if lower in self.dictionary:
            return lower
        
        # Coba hapus confiks terlebih dahulu (ke-...-an, ber-...-an, etc)
        for prefix, suffix in _LEMMA_CONFIXES:
            if lower.startswith(prefix) and lower.endswith(suffix):
                stem = lower[len(prefix):-len(suffix)]
                if len(stem) > 2:
                    if not self.dictionary or stem in self.dictionary:
                        return stem
        
        # Coba hapus sufiks
        stemmed = lower
        for suffix, length in _LEMMA_SUFFIXES:
            if stemmed.endswith(suffix) and len(stemmed) > length + 2:
                stemmed = stemmed[:-length]
                break
        
        # Coba hapus prefiks
        for prefix, length in _LEMMA_PREFIXES:
            if stemmed.startswith(prefix) and len(stemmed) > length + 2:
                stemmed = stemmed[length:]
                break
        
        return stemmed if len(stemmed) > 1 else lower
    
    def __call__(self, doc):
        """Terapkan lemmatisasi ke seluruh dokumen."""
        for token in doc:
            token._lemma = self._lemmatize(token.text)
        return doc


# ═══════════════════════════════════════════════════════════════════════════════
# EntityRecognizer — NER rule-based sederhana untuk Indonesia
# ═══════════════════════════════════════════════════════════════════════════════

# Daftar entitas terkenal Indonesia
_KNOWN_PERSONS = {
    "jokowi", "soekarno", "soeharto", "habibie", "megawati",
    "sukarno", "hatta", "sukarnoputri", "yudhoyono", "widodo",
    "prabowo", "gibran", "ganjar", "anies", "baswedan",
}

_KNOWN_LOCATIONS = {
    "indonesia", "jakarta", "bandung", "surabaya", "medan", "semarang",
    "makassar", "palembang", "denpasar", "yogyakarta", "solo", "malang",
    "bogor", "depok", "tangerang", "bekasi", "bali", "lombok",
    "kalimantan", "sumatera", "sulawesi", "papua", "jawa", "borneo",
    "nusantara", "aceh", "riau", "jambi", "lampung",
}

_KNOWN_ORGS = {
    "bumn", "dpr", "mpr", "kpk", "polri", "tni", "bappenas",
    "kemenkeu", "kemendikbud", "kemenkes", "kemenag", "bpk",
    "ojk", "bi", "bps", "bmkg", "bnpb", "basarnas",
}


class EntityRecognizer:
    """
    Named Entity Recognition (NER) rule-based sederhana untuk Indonesia.
    Mengenali PERSON, LOC, ORG berdasarkan lookup dan heuristik.
    """
    
    def __init__(self):
        self.persons = _KNOWN_PERSONS
        self.locations = _KNOWN_LOCATIONS
        self.orgs = _KNOWN_ORGS
    
    def __call__(self, doc):
        from saujana.tokens.span import Span
        doc._ents = []
        
        for i, token in enumerate(doc):
            lower = token.text.lower()
            
            if lower in self.persons:
                token._ent_type = "PERSON"
                doc._ents.append(Span(doc, i, i + 1, label="PERSON"))
            elif lower in self.locations:
                token._ent_type = "LOC"
                doc._ents.append(Span(doc, i, i + 1, label="LOC"))
            elif lower in self.orgs:
                token._ent_type = "ORG"
                doc._ents.append(Span(doc, i, i + 1, label="ORG"))
            else:
                token._ent_type = ""
        
        return doc
