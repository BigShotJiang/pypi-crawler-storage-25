"""
Test suite lengkap untuk Saujana — Indonesian NLP Library.
Menguji fitur NLP dan Word Embedding secara komprehensif.
"""
import pytest
import numpy as np
import saujana
from saujana.tokenizer import Tokenizer
from saujana.stopwords import STOP_WORDS


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Loading & Tokenisasi Dasar
# ═══════════════════════════════════════════════════════════════════════════════

class TestLoadAndTokenize:
    def test_load_returns_language(self):
        nlp = saujana.load("id_test_md")
        assert isinstance(nlp, saujana.Language)
    
    def test_call_returns_doc(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        assert isinstance(doc, saujana.Doc)
    
    def test_token_count(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        assert len(doc) == 4
    
    def test_token_text(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        assert doc[0].text == "presiden"
        assert doc[3].text == "jakarta"
    
    def test_doc_str(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        assert "presiden" in str(doc)

    def test_doc_iteration(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden pergi")
        texts = [t.text for t in doc]
        assert texts == ["presiden", "pergi"]
    
    def test_repr(self):
        nlp = saujana.load("id_test_md")
        assert "saujana.Language" in repr(nlp)
    
    def test_contains(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        assert "presiden" in doc
        assert "xyz" not in doc


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Vektor & Similarity
# ═══════════════════════════════════════════════════════════════════════════════

class TestVectors:
    def test_doc_has_vector(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden jokowi pergi")
        assert doc.has_vector
    
    def test_doc_vector_shape(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden jokowi pergi")
        assert doc.vector.shape == (300,)
    
    def test_token_vector(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden jokowi pergi")
        token = doc[0]
        assert token.has_vector
        assert token.vector.shape == (300,)
        assert token.vector_norm > 0
    
    def test_doc_similarity_range(self):
        nlp = saujana.load("id_test_md")
        doc1 = nlp("presiden bertolak ke jakarta")
        doc2 = nlp("jokowi pergi ke kota")
        sim = doc1.similarity(doc2)
        assert -1.0 <= sim <= 1.0
    
    def test_token_similarity(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden jokowi")
        sim = doc[0].similarity(doc[1])
        assert -1.0 <= sim <= 1.0
    
    def test_self_similarity(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        sim = doc.similarity(doc)
        assert sim == pytest.approx(1.0, abs=0.01)


# ═══════════════════════════════════════════════════════════════════════════════
# Test: OOV
# ═══════════════════════════════════════════════════════════════════════════════

class TestOOV:
    def test_oov_no_vector(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("xyzabcunknown")
        token = doc[0]
        assert not token.has_vector
        assert np.all(token.vector == 0)
        assert token.vector_norm == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Token Attributes
# ═══════════════════════════════════════════════════════════════════════════════

class TestTokenAttributes:
    def test_is_alpha(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden ke 123")
        assert doc[0].is_alpha
        assert doc[1].is_alpha
        assert not doc[2].is_alpha
    
    def test_is_stop(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden ke jakarta dan")
        assert not doc[0].is_stop  # presiden
        assert doc[1].is_stop      # ke
        assert doc[3].is_stop      # dan
    
    def test_lower(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("Jakarta INDONESIA")
        assert doc[0].lower_ == "jakarta"
        assert doc[1].lower_ == "indonesia"
    
    def test_shape(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("Jakartaa 2024 NLP")
        assert doc[0].shape_ == "Xxxxx"  # Title case (8 chars)
        assert doc[1].shape_ == "dddd"   # Digits
        assert doc[2].shape_ == "XXX"    # Upper
    
    def test_like_num(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("100 presiden 1.000")
        assert doc[0].like_num
        assert not doc[1].like_num
        assert doc[2].like_num
    
    def test_pos_tag(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden ke jakarta dan membaca")
        # ke should be ADP, dan should be CCONJ
        assert doc[1].pos_ == "ADP"
        assert doc[3].pos_ == "CCONJ"
    
    def test_lemma(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("membaca berlari")
        # Prefiks "mem" dan "ber" should be stripped
        assert doc[0].lemma_ != "membaca"  # Should be "baca" or similar
        assert doc[1].lemma_ != "berlari"  # Should be "lari" or similar
    
    def test_ent_type(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("jokowi pergi ke jakarta")
        assert doc[0].ent_type_ == "PERSON"
        assert doc[3].ent_type_ == "LOC"


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Span
# ═══════════════════════════════════════════════════════════════════════════════

class TestSpan:
    def test_span_text(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        span = doc.char_span(0, 2)
        assert span.text == "presiden bertolak"
    
    def test_span_length(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        span = doc.char_span(1, 3)
        assert len(span) == 2
    
    def test_span_iteration(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        span = doc.char_span(0, 2)
        texts = [t.text for t in span]
        assert texts == ["presiden", "bertolak"]
    
    def test_span_similarity(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta")
        span1 = doc.char_span(0, 2)
        span2 = doc.char_span(2, 4)
        sim = span1.similarity(span2)
        assert -1.0 <= sim <= 1.0


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Named Entities (NER)
# ═══════════════════════════════════════════════════════════════════════════════

class TestNER:
    def test_doc_ents(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("jokowi pergi ke jakarta")
        ents = doc.ents
        assert len(ents) >= 2
        labels = {e.label_ for e in ents}
        assert "PERSON" in labels
        assert "LOC" in labels
    
    def test_ent_text(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("jokowi pergi ke jakarta")
        ent_texts = [e.text.lower() for e in doc.ents]
        assert "jokowi" in ent_texts
        assert "jakarta" in ent_texts


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Tokenizer Indonesia
# ═══════════════════════════════════════════════════════════════════════════════

class TestTokenizer:
    def setup_method(self):
        self.tokenizer = Tokenizer()
    
    def test_basic_tokenize(self):
        tokens = self.tokenizer("Saya makan nasi.")
        assert "Saya" in tokens
        assert "makan" in tokens
        assert "nasi" in tokens
    
    def test_punctuation_split(self):
        tokens = self.tokenizer("Halo, dunia!")
        assert "," in tokens
        assert "!" in tokens
    
    def test_abbreviation_kept(self):
        tokens = self.tokenizer("dr. Andi pergi ke jl. Sudirman")
        assert "dr." in tokens
        assert "jl." in tokens
    
    def test_empty_string(self):
        tokens = self.tokenizer("")
        assert tokens == []
    
    def test_whitespace_normalization(self):
        tokens = self.tokenizer("  Saya   makan   nasi  ")
        assert tokens[0] == "Saya"
        assert len([t for t in tokens if t.strip()]) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Vocab — Word Embedding features
# ═══════════════════════════════════════════════════════════════════════════════

class TestVocabEmbeddings:
    def test_most_similar_string(self):
        nlp = saujana.load("id_test_md")
        results = nlp.vocab.most_similar("presiden", topn=3)
        assert len(results) > 0
        for word, score in results:
            assert isinstance(word, str)
            assert -1.0 <= score <= 1.0
    
    def test_most_similar_positive_negative(self):
        nlp = saujana.load("id_test_md")
        results = nlp.vocab.most_similar(
            positive=["raja", "wanita"], 
            negative=["pria"], 
            topn=5
        )
        assert len(results) > 0
    
    def test_most_similar_oov(self):
        nlp = saujana.load("id_test_md")
        results = nlp.vocab.most_similar("xyzunknown123", topn=3)
        assert results == []
    
    def test_analogy(self):
        nlp = saujana.load("id_test_md")
        results = nlp.vocab.analogy(positive=["presiden", "jakarta"], topn=3)
        assert len(results) > 0
    
    def test_similarity_word_pair(self):
        nlp = saujana.load("id_test_md")
        sim = nlp.vocab.similarity("presiden", "jokowi")
        assert -1.0 <= sim <= 1.0
    
    def test_n_similarity(self):
        nlp = saujana.load("id_test_md")
        sim = nlp.vocab.n_similarity(
            ["raja", "presiden"], 
            ["ratu", "menteri"]
        )
        assert -1.0 <= sim <= 1.0
    
    def test_doesnt_match(self):
        nlp = saujana.load("id_test_md")
        outlier = nlp.vocab.doesnt_match(["makan", "minum", "tidur", "jakarta"])
        assert isinstance(outlier, str)
        # jakarta seharusnya outlier karena bukan kata kerja
        assert outlier == "jakarta"
    
    def test_distance(self):
        nlp = saujana.load("id_test_md")
        d = nlp.vocab.distance("presiden", "jokowi")
        assert 0.0 <= d <= 2.0
    
    def test_vocab_len(self):
        nlp = saujana.load("id_test_md")
        assert len(nlp.vocab) > 0
    
    def test_vocab_contains(self):
        nlp = saujana.load("id_test_md")
        assert "presiden" in nlp.vocab
        assert "xyznotexist" not in nlp.vocab
    
    def test_vocab_indexing(self):
        nlp = saujana.load("id_test_md")
        vec = nlp.vocab["presiden"]
        assert isinstance(vec, np.ndarray)
        assert vec.shape == (300,)
    
    def test_vocab_words(self):
        nlp = saujana.load("id_test_md")
        words = nlp.vocab.words
        assert isinstance(words, list)
        assert "presiden" in words


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Sentence Segmentation
# ═══════════════════════════════════════════════════════════════════════════════

class TestSents:
    def test_single_sentence(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden bertolak ke jakarta .")
        sents = list(doc.sents)
        assert len(sents) == 1
    
    def test_multi_sentence(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden pergi . jokowi ke jakarta .")
        sents = list(doc.sents)
        assert len(sents) == 2


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Pipeline Management
# ═══════════════════════════════════════════════════════════════════════════════

class TestPipeline:
    def test_pipe_multiple_texts(self):
        nlp = saujana.load("id_test_md")
        texts = ["presiden pergi", "jokowi ke jakarta"]
        docs = list(nlp.pipe(texts))
        assert len(docs) == 2
        assert isinstance(docs[0], saujana.Doc)
    
    def test_pipe_names(self):
        nlp = saujana.load("id_test_md")
        names = nlp.pipe_names
        assert "tagger" in names
        assert "ner" in names
        assert "lemmatizer" in names
        assert "stopwords" in names
    
    def test_add_custom_pipe(self):
        nlp = saujana.load("id_test_md")
        
        def custom(doc):
            doc._custom_flag = True
            return doc
        
        nlp.add_pipe("custom", custom)
        assert "custom" in nlp.pipe_names
        
        doc = nlp("presiden pergi")
        assert hasattr(doc, '_custom_flag')
        assert doc._custom_flag is True
    
    def test_remove_pipe(self):
        nlp = saujana.load("id_test_md")
        nlp.remove_pipe("ner")
        assert "ner" not in nlp.pipe_names
    
    def test_disable_pipe(self):
        nlp = saujana.load("id_test_md")
        nlp.disable_pipe("ner")
        doc = nlp("jokowi pergi")
        # NER disabled, so no ents
        assert len(doc.ents) == 0
    
    def test_load_with_disable(self):
        nlp = saujana.load("id_test_md", disable=["ner", "lemmatizer"])
        doc = nlp("jokowi pergi")
        assert len(doc.ents) == 0
    
    def test_analyze(self):
        nlp = saujana.load("id_test_md")
        result = nlp.analyze("jokowi pergi ke jakarta")
        assert "tokens" in result
        assert "entities" in result
        assert "sentences" in result
        assert len(result["tokens"]) == 4


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Doc Advanced Features
# ═══════════════════════════════════════════════════════════════════════════════

class TestDocAdvanced:
    def test_count_by(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden ke jakarta dan ke bandung")
        counts = doc.count_by("text")
        assert counts["ke"] == 2
    
    def test_to_array(self):
        nlp = saujana.load("id_test_md")
        doc = nlp("presiden pergi ke jakarta")
        arr = doc.to_array("vector")
        assert arr.shape == (4, 300)


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Stopwords
# ═══════════════════════════════════════════════════════════════════════════════

class TestStopwords:
    def test_stopwords_is_set(self):
        assert isinstance(STOP_WORDS, set)
    
    def test_common_stopwords(self):
        assert "dan" in STOP_WORDS
        assert "ke" in STOP_WORDS
        assert "di" in STOP_WORDS
        assert "adalah" in STOP_WORDS
    
    def test_content_words_not_stop(self):
        assert "presiden" not in STOP_WORDS
        assert "indonesia" not in STOP_WORDS


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Lexeme
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# Test: CorpusBuilder & Dataset Creation
# ═══════════════════════════════════════════════════════════════════════════════

class TestCorpusBuilder:
    def test_add_file(self, tmp_path):
        from saujana.vectors.training import CorpusBuilder
        d = tmp_path / "data"
        d.mkdir()
        f = d / "test.txt"
        f.write_text("Ini adalah teks tes.")
        
        builder = CorpusBuilder()
        builder.add_file(f)
        assert len(builder.files) == 1
    
    def test_build_corpus(self, tmp_path):
        from saujana.vectors.training import CorpusBuilder
        d = tmp_path / "data"
        d.mkdir()
        f1 = d / "1.txt"
        f1.write_text("Saya makan nasi.")
        f2 = d / "2.txt"
        f2.write_text("Dia minum kopi.")
        
        builder = CorpusBuilder()
        builder.add_file(f1)
        builder.add_file(f2)
        
        out = tmp_path / "corpus.txt"
        builder.build(out)
        
        content = out.read_text().strip().split('\n')
        assert len(content) == 2
        # Teks yang sudah diproses (lowercase & tokenized)
        assert "saya makan nasi" in content
        assert "dia minum kopi" in content
