import uuid
from typing import Iterable

import pytest
from httpx import ASGITransport, Client
from sqlalchemy import Column, String
from tigrbl import TableBase, TigrblApp, TigrblRouter
from tigrbl_core.config.constants import TIGRBL_AUTH_CONTEXT_ATTR
from tigrbl.orm.mixins import GUIDPk
from tigrbl.orm.mixins.ownable import Ownable, OwnerPolicy
from tigrbl.orm.mixins.tenant_bound import TenantBound, TenantPolicy
from tigrbl import Request
from tigrbl.runtime.status import HTTPException
from tigrbl import HTTPBearer
from tigrbl.security import Security
from tigrbl._concrete._security.http_bearer import HTTPAuthorizationCredentials
from tigrbl_typing.types.authn_abc import AuthNProvider


class DummyAuth(AuthNProvider):
    def __init__(self, user_id: uuid.UUID, tenant_id: uuid.UUID):
        self.user_id = user_id
        self.tenant_id = tenant_id

    async def get_principal(
        self,
        request: Request,
        creds: HTTPAuthorizationCredentials = Security(HTTPBearer()),
    ):
        if creds.credentials != "secret":
            raise HTTPException(status_code=401)
        principal = {"user_id": self.user_id, "tenant_id": self.tenant_id}
        request.state.principal = principal
        setattr(request.state, TIGRBL_AUTH_CONTEXT_ATTR, principal)
        return principal


def _client_for_owner(
    policy: OwnerPolicy,
    user_id: uuid.UUID,
    tenant_id: uuid.UUID,
    extra_user_ids: Iterable[uuid.UUID] | None = None,
) -> Client:
    TableBase.metadata.clear()

    class User(TableBase, GUIDPk):
        __tablename__ = "users"
        __table_args__ = {"schema": "main"}
        name = Column(String, nullable=False)

    class Item(TableBase, GUIDPk, Ownable):
        __tablename__ = "items"
        __table_args__ = {"schema": "main"}
        name = Column(String, nullable=False)
        __tigrbl_owner_policy__ = policy

    from tigrbl._concrete._engine import Engine
    from tigrbl._spec import EngineSpec
    from tigrbl.factories.engine import mem

    cfg = {**mem(async_=False), "tag": str(uuid.uuid4())}
    engine = Engine(EngineSpec.from_any(cfg))
    db_engine, _ = engine.raw()
    TableBase.metadata.create_all(bind=db_engine)

    with engine.session() as session:
        session.execute(User.__table__.insert().values(id=user_id, name="owner"))
        for extra in extra_user_ids or []:
            session.execute(User.__table__.insert().values(id=extra, name="extra"))
        session.commit()

    authn = DummyAuth(user_id, tenant_id)
    app = TigrblApp(engine=engine)
    app.set_auth(authn=authn.get_principal)
    app.include_tables([User, Item])
    router = TigrblRouter()
    app.include_router(router)
    app.initialize()
    transport = ASGITransport(app=app)
    return Client(transport=transport, base_url="http://test")


@pytest.mark.i9n
def test_owner_policy_runtime_switch():
    user_id = uuid.uuid4()
    tenant_id = uuid.uuid4()
    headers = {"Authorization": "Bearer secret"}

    client = _client_for_owner(OwnerPolicy.STRICT_SERVER, user_id, tenant_id)
    try:
        res = client.post(
            "/item",
            json={"name": "one", "owner_id": str(user_id)},
            headers=headers,
        )
        assert res.status_code == 400
    finally:
        client.close()

    supplied = uuid.uuid4()
    client = _client_for_owner(
        OwnerPolicy.CLIENT_SET, user_id, tenant_id, extra_user_ids=[supplied]
    )
    try:
        res = client.post(
            "/item",
            json={"name": "two", "owner_id": str(supplied)},
            headers=headers,
        )
        assert res.status_code == 201
        assert res.json()["owner_id"] == str(supplied)
    finally:
        client.close()


def _client_for_tenant(
    policy: TenantPolicy,
    user_id: uuid.UUID,
    tenant_id: uuid.UUID,
    extra_tenant_ids: Iterable[uuid.UUID] | None = None,
) -> Client:
    TableBase.metadata.clear()

    class Tenant(TableBase, GUIDPk):
        __tablename__ = "tenants"
        __table_args__ = {"schema": "main"}
        name = Column(String, nullable=False)

    class Item(TableBase, GUIDPk, TenantBound):
        __tablename__ = "items"
        __table_args__ = {"schema": "main"}
        name = Column(String, nullable=False)
        __tigrbl_tenant_policy__ = policy

    from tigrbl._concrete._engine import Engine
    from tigrbl._spec import EngineSpec
    from tigrbl.factories.engine import mem

    cfg = {**mem(async_=False), "tag": str(uuid.uuid4())}
    engine = Engine(EngineSpec.from_any(cfg))
    db_engine, _ = engine.raw()
    TableBase.metadata.create_all(bind=db_engine)

    with engine.session() as session:
        session.execute(Tenant.__table__.insert().values(id=tenant_id, name="acme"))
        for extra in extra_tenant_ids or []:
            session.execute(Tenant.__table__.insert().values(id=extra, name="extra"))
        session.commit()

    authn = DummyAuth(user_id, tenant_id)
    app = TigrblApp(engine=engine)
    app.set_auth(authn=authn.get_principal)

    router = TigrblRouter()
    router.include_tables([Tenant, Item])
    app.include_router(router)
    app.initialize()
    transport = ASGITransport(app=app)
    return Client(transport=transport, base_url="http://test")


@pytest.mark.i9n
def test_tenant_policy_runtime_switch():
    user_id = uuid.uuid4()
    tenant_id = uuid.uuid4()
    headers = {"Authorization": "Bearer secret"}

    client = _client_for_tenant(TenantPolicy.STRICT_SERVER, user_id, tenant_id)
    try:
        res = client.post(
            "/item",
            json={"name": "one", "tenant_id": str(tenant_id)},
            headers=headers,
        )
        assert res.status_code == 400
    finally:
        client.close()

    supplied = uuid.uuid4()
    client = _client_for_tenant(
        TenantPolicy.CLIENT_SET, user_id, tenant_id, extra_tenant_ids=[supplied]
    )
    try:
        res = client.post(
            "/item",
            json={"name": "two", "tenant_id": str(supplied)},
            headers=headers,
        )
        assert res.status_code == 201
        assert res.json()["tenant_id"] == str(supplied)
    finally:
        client.close()

