import httpx
import pytest
import pytest_asyncio
from tigrbl import TableBase, TigrblApp, TigrblRouter
from tigrbl.factories.engine import mem
from tigrbl.orm.mixins import GUIDPk
from tigrbl import HTTPBearer
from tigrbl.security import Security
from tigrbl._concrete._security.http_bearer import HTTPAuthorizationCredentials
from tigrbl._spec import IO, F, S
from tigrbl.factories.column import acol
from tigrbl.types import Mapped, String

from .uvicorn_utils import run_uvicorn_in_task, stop_uvicorn_server

bearer = HTTPBearer()


def auth_dependency(
    credentials: HTTPAuthorizationCredentials = Security(bearer),
) -> HTTPAuthorizationCredentials:
    return credentials


class Kappa(TableBase, GUIDPk):
    __tablename__ = "kappa_router_app_usage"
    __allow_unmapped__ = True

    name: Mapped[str] = acol(
        storage=S(type_=String, nullable=False),
        field=F(py_type=str),
        io=IO(in_verbs=("create",), out_verbs=("create", "read", "list")),
    )

    __tigrbl_cols__ = {"id": GUIDPk.id, "name": name}


class KappaApi(TigrblRouter):
    TABLES = (Kappa,)


@pytest_asyncio.fixture()
async def running_router_app():
    router = KappaApi(engine=mem(async_=False))
    router.set_auth(authn=auth_dependency, allow_anon=False)
    router.include_tables([Kappa])
    await router.initialize()

    class KappaApp(TigrblApp):
        ROUTERS = (router,)

    app = KappaApp(engine=mem(async_=False))
    app.include_router(router)

    base_url, server, task = await run_uvicorn_in_task(app)
    try:
        yield base_url
    finally:
        await stop_uvicorn_server(server, task)


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_tigrbl_router_app_deploys_and_serves_openapi(running_router_app) -> None:
    base_url = running_router_app

    async with httpx.AsyncClient() as client:
        openapi_resp = await client.get(f"{base_url}/openapi.json")

    assert openapi_resp.status_code == 200
    openapi = openapi_resp.json()
    paths = openapi["paths"]

    assert "/kappa" in paths
    assert "/kappa/{item_id}" in paths
    assert {"get", "post", "delete"}.issubset(paths["/kappa"])
    assert {"get", "patch", "put", "delete"}.issubset(paths["/kappa/{item_id}"])

    security_schemes = openapi.get("components", {}).get("securitySchemes", {})
    assert "HTTPBearer" in security_schemes


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_tigrbl_router_app_handles_authenticated_request(
    running_router_app,
) -> None:
    base_url = running_router_app
    headers = {"Authorization": "Bearer demo"}

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{base_url}/kappa",
            json={"name": "Kappa"},
            headers=headers,
        )

    assert resp.status_code == 201
    payload = resp.json()
    assert payload["name"] == "Kappa"

