import httpx
import pytest
import pytest_asyncio
from tigrbl import TigrblApp, TigrblRouter
from tigrbl.orm.mixins import GUIDPk
from tigrbl._spec import IO, F, S
from tigrbl.factories.column import acol
from tigrbl.orm.tables import TableBase
from tigrbl.types import Mapped, String

from .uvicorn_utils import run_uvicorn_in_task, stop_uvicorn_server


class Item(TableBase, GUIDPk):
    __tablename__ = "items_hdr"
    __resource__ = "item"

    name: Mapped[str] = acol(
        storage=S(String, nullable=False),
        field=F(py_type=str),
        io=IO(in_verbs=("create",), out_verbs=("create", "read")),
    )
    worker_key: Mapped[str] = acol(
        storage=S(String, nullable=False),
        field=F(py_type=str),
        io=IO(
            in_verbs=("create",),
            out_verbs=("create", "read"),
            header_in="X-Worker-Key",
            header_required_in=True,
        ),
    )
    __tigrbl_cols__ = {
        "id": GUIDPk.id,
        "name": name,
        "worker_key": worker_key,
    }


@pytest_asyncio.fixture()
async def running_app(sync_db_session):
    engine, get_sync_db = sync_db_session

    app = TigrblApp()
    router = TigrblRouter(get_db=get_sync_db)
    app.include_tables([Item])
    await app.initialize()
    app.include_router(router)

    base_url, server, task = await run_uvicorn_in_task(app)
    try:
        yield base_url
    finally:
        await stop_uvicorn_server(server, task)


@pytest.mark.i9n
@pytest.mark.asyncio
@pytest.mark.parametrize(
    "headers, status, expected_worker_key",
    [({}, 201, "body"), ({"X-Worker-Key": "alpha"}, 201, "body")],
)
async def test_header_in_out(running_app, headers, status, expected_worker_key):
    base_url = running_app
    payload = {"name": "foo", "worker_key": "body"}
    async with httpx.AsyncClient() as client:
        resp = await client.post(f"{base_url}/item", json=payload, headers=headers)
    assert resp.status_code == status
    if status == 201:
        body = resp.json()
        assert body["worker_key"] == expected_worker_key

