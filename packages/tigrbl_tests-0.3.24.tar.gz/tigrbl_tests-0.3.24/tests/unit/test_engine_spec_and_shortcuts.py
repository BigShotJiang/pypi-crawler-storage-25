# tests/test_engine_spec_and_shortcuts.py
import json

import pytest

from tigrbl.factories.engine import (
    engine_spec,
    engine,
    mem,
    prov,
    sqlitef,
)  # :contentReference[oaicite:2]{index=2}
from tigrbl._spec import EngineSpec
from tigrbl.engine.resolver import _SECRET_KEYS, _hash_secret, _spec_key


def test_engine_spec_builds_from_kwargs_sqlite_memory_async():
    spec = engine_spec(
        kind="sqlite", mode="memory", async_=True
    )  # collapsed ctx builder
    assert isinstance(spec, EngineSpec)  # normalized
    assert (
        spec.kind == "sqlite" and spec.async_ is True and spec.memory is True
    )  # :contentReference[oaicite:4]{index=4}


def test_engine_spec_builds_from_mapping_postgres_sync():
    spec = engine_spec(
        {"kind": "postgres", "async": False, "host": "db", "db": "foo"}
    )  # mapping path
    assert (
        spec.kind == "postgres" and spec.async_ is False and spec.host == "db"
    )  # :contentReference[oaicite:5]{index=5}


def test_engine_spec_builds_from_dsn_postgres():
    dsn = "postgresql://user:pwd@localhost:5432/db"
    spec = engine_spec(dsn)
    assert spec.kind == "postgres" and spec.dsn == dsn
    assert spec.host is None and spec.user is None


def test_engine_spec_repr_redacts_password():
    spec = engine_spec({"kind": "postgres", "pwd": "s3cret"})
    assert "s3cret" not in repr(spec)

    spec = engine_spec("postgresql://user:pwd@localhost:5432/db")
    rep = repr(spec)
    assert "pwd" not in rep
    assert "***" in rep


def test_spec_key_accounts_for_pwd_in_direct_spec():
    base = dict(kind="postgres", user="app", host="db", name="app_db", port=5432)
    spec_a = EngineSpec(**base, pwd="alpha")
    spec_b = EngineSpec(**base, pwd="bravo")

    assert _spec_key(spec_a) != _spec_key(spec_b)


@pytest.mark.parametrize("secret_key", sorted(_SECRET_KEYS))
def test_spec_key_hashes_secret_mapping_values(secret_key: str):
    mapping = {secret_key: "s3cret", "other": "value"}
    spec = EngineSpec(kind="postgres", mapping=mapping)

    key = _spec_key(spec)
    mapping_s = key[-1]
    normalized = json.loads(mapping_s)

    assert normalized["other"] == "value"
    assert normalized[secret_key] == {"__sha256__": _hash_secret("s3cret")}


def test_engine_builds_from_dsn_postgres():
    dsn = "postgresql://user:pwd@localhost:5432/db"
    spec = EngineSpec.from_any(dsn)
    eng, _ = spec.build()
    assert eng.url.database == "db"
    assert eng.url.host == "localhost"
    eng.dispose()


def test_prov_lazily_constructs_and_sessions_are_fresh_sync(tmp_path):
    p = prov(
        sqlitef(str(tmp_path / "x.sqlite"))
    )  # mapping helper â†’ Provider  :contentReference[oaicite:6]{index=6}
    assert p.kind == "sync"
    s1 = p.session()
    s2 = p.session()
    assert s1 is not s2  # fresh sessions per call
    for s in (s1, s2):
        close = getattr(s, "close", None)
        if callable(close):
            close()


@pytest.mark.asyncio
async def test_engine_async_context_manager_ok():
    e = engine(
        mem(async_=True)
    )  # async sqlite in-memory  :contentReference[oaicite:7]{index=7}
    # Just enter/exit; if builders are wired, this should pass
    async with e.asession() as s:
        # smoke: check basic API surface
        close = getattr(s, "close", None)
        assert close is not None

