"""
Core data models for the Manta SDK.

These models define the contract between the Manta execution engine and
custom runner implementations. The engine passes a RunContext in, and
expects a RunResult back.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class RunStatus(StrEnum):
    """Terminal and intermediate states of a test execution run."""

    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"
    XFAIL = "xfail"


class RunContext(BaseModel):
    """
    Execution context injected by the Manta engine before a run starts.

    Custom runners receive this object via BaseRunner.execute() and use it
    to discover test files, read secrets, and configure the test environment.

    For SaaS / HTTP surface targets, the optional fields below describe the
    live system under test.  Binary/wheel runners can ignore them.
    """

    run_id: UUID = Field(default_factory=uuid4, description="Unique run identifier")
    team_id: str = Field(description="Team that triggered this run")
    test_files: list[str] = Field(description="Absolute paths to test files to execute")
    env: dict[str, str] = Field(default_factory=dict, description="Environment variables")
    timeout_seconds: int = Field(default=3600, description="Hard timeout for the whole run")
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary metadata attached by the CI trigger (PR number, branch, etc.)",
    )

    # ── SaaS / HTTP surface fields (optional — populated for URL-based targets) ──

    target_url: str | None = Field(
        default=None,
        description="Base URL of the live system under test (e.g. https://staging.myapp.com)",
    )
    auth_config: dict[str, str] | None = Field(
        default=None,
        description=(
            "Authentication configuration for the target.  Keys vary by scheme: "
            "api_key → {'type': 'api_key', 'header': 'X-API-Key', 'value': '<key>'}; "
            "bearer → {'type': 'bearer', 'token': '<token>'}; "
            "basic → {'type': 'basic', 'username': '...', 'password': '...'}."
        ),
    )
    service_type: str | None = Field(
        default=None,
        description=(
            "Surface type hint for the generated runner: "
            "'saas_api' | 'saas_ui' | 'saas_fullstack' | 'binary' (default)."
        ),
    )
    compose_file: str | None = Field(
        default=None,
        description="Path to a docker-compose.yml for local service spinup (runner-compose profile).",
    )


class TestCaseResult(BaseModel):
    """Result for a single test case within a run."""

    name: str
    status: RunStatus
    duration_ms: int
    error_message: str | None = None
    stdout: str = ""
    started_at: datetime | None = Field(default=None, description="Wall-clock time when the test call phase started")
    finished_at: datetime | None = Field(default=None, description="Wall-clock time when the test call phase ended")
    test_summary: str | None = Field(
        default=None, description="Structured summary emitted via manta_test_summary fixture"
    )
    backup_path: str | None = Field(
        default=None, description="Storage asset_id of the backup artifact for this test case"
    )


class RunResult(BaseModel):
    """
    Final result returned by a runner after test execution completes.

    The engine persists this to BigQuery via the Analytics Manager.
    """

    run_id: UUID
    status: RunStatus
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    finished_at: datetime | None = None
    duration_ms: int = 0
    total_tests: int = 0
    passed: int = 0
    failed: int = 0
    errors: int = 0
    test_cases: list[TestCaseResult] = Field(default_factory=list)
    exit_code: int = 0
