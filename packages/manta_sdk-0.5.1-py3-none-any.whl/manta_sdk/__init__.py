"""
Manta SDK
---------
Pytest-native test runner framework for the Manta platform.

The SDK owns all infrastructure: SUT download, pytest execution, result
collection, artifact upload, and callback POST to the queue-manager.
Generated runners are pure pytest test classes — no boilerplate.

Quick start::

    # In your generated _cli.py:
    from pathlib import Path
    from manta_sdk.cli import run_tests

    def main() -> None:
        run_tests(Path(__file__).parent / "tests")
"""

from manta_sdk.backup import BackupStorage, LocalBackupStorage
from manta_sdk.cli import run_tests
from manta_sdk.fixtures import SutFiles, make_sut_dir_fixture, make_sut_files_fixture
from manta_sdk.models import RunContext, RunResult, RunStatus, TestCaseResult
from manta_sdk.plugin import BackupCollector, MantaPlugin, SummaryContext
from manta_sdk.runner import BaseRunner

__all__ = [
    "BackupCollector",
    "BackupStorage",
    "BaseRunner",
    "LocalBackupStorage",
    "MantaPlugin",
    "RunContext",
    "RunResult",
    "RunStatus",
    "SummaryContext",
    "SutFiles",
    "TestCaseResult",
    "make_sut_dir_fixture",
    "make_sut_files_fixture",
    "run_tests",
]
