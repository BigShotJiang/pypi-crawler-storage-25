"""
Manta SDK — backup storage abstraction for test artifact persistence.

Provides an abstract BackupStorage interface and a concrete LocalBackupStorage
implementation that stores artifacts on the local filesystem.  The SDK's
``manta_backup`` pytest fixture injects a ``BackupCollector`` backed by
whichever storage implementation is active.

Custom runners may override the storage backend by passing a ``BackupStorage``
instance when constructing ``MantaPlugin``::

    from manta_sdk.backup import LocalBackupStorage
    from manta_sdk.plugin import MantaPlugin

    plugin = MantaPlugin(run_id, backup_storage=LocalBackupStorage("/my/backup/dir"))
"""

from __future__ import annotations

import abc
import shutil
from pathlib import Path


class BackupStorage(abc.ABC):
    """
    Abstract interface for test artifact backup storage.

    Implementations must provide ``upload`` (single file) and
    ``upload_dir`` (directory tree) methods.  Both return an opaque
    string key that can be used to retrieve the artifact later.
    """

    @abc.abstractmethod
    def upload(self, src: Path, *, key: str) -> str:
        """
        Store a single file under the given key.

        Args:
            src:  Path to the file to store.
            key:  Logical storage key (e.g. ``"test_foo/screenshot.png"``).

        Returns:
            A storage reference string (key or URL) for later retrieval.
        """

    @abc.abstractmethod
    def upload_dir(self, src: Path, *, key: str) -> str:
        """
        Store an entire directory tree under the given key prefix.

        Args:
            src:  Path to the directory to store.
            key:  Logical key prefix (e.g. ``"test_foo/artifacts"``).

        Returns:
            A storage reference string for the root of the stored tree.
        """


class LocalBackupStorage(BackupStorage):
    """
    Filesystem-backed backup storage implementation.

    Stores artifacts inside a configurable root directory.  Suitable for
    local development, CI pipelines with shared volumes, and integration
    tests.

    Args:
        root: Root directory under which all artifacts are stored.
              Created automatically if it does not exist.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def upload(self, src: Path, *, key: str) -> str:
        """
        Copy a single file into ``root / key``.

        Parent directories are created automatically.

        Returns:
            The absolute path of the stored file as a string.
        """
        dest = self.root / key
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        return str(dest)

    def upload_dir(self, src: Path, *, key: str) -> str:
        """
        Copy an entire directory tree into ``root / key``.

        If the destination already exists it is removed first so that stale
        files from a previous run do not contaminate the backup.

        Returns:
            The absolute path of the stored directory root as a string.
        """
        dest = self.root / key
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)
        return str(dest)


__all__ = ["BackupStorage", "LocalBackupStorage"]
