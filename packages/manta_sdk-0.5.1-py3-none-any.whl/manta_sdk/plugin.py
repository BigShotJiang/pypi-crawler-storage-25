"""
MantaPlugin — programmatic pytest plugin for result collection.

Registered by cli.py at runtime (NOT as a pytest11 entry point).

Improvements over the v0.4.x plugin:
- SKIPPED and XFAIL status mapping (no longer conflated with ERROR).
- Per-test wall-clock timing via time.monotonic() in pytest_runtest_call.
- Setup-phase skip capture: if a test is skipped at setup (e.g. a
  pytest.importorskip guard) MantaPlugin records it as SKIPPED so the
  dashboard shows the test rather than silently dropping it.
- ``manta_test_summary`` fixture: lets tests push a structured summary
  string into the result.  The fixture is function-scoped and registered
  dynamically via pytest_configure so generated conftest.py files don't
  need to import anything.
- ``manta_backup`` fixture: injects a ``BackupCollector`` backed by
  ``BackupStorage`` so test bodies can persist arbitrary artifacts.
"""

from __future__ import annotations

import time
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

import pytest

from manta_sdk.models import RunResult, RunStatus, TestCaseResult

# ---------------------------------------------------------------------------
# Helper containers
# ---------------------------------------------------------------------------


class SummaryContext:
    """
    Mutable container injected into tests via the ``manta_test_summary`` fixture.

    Tests call ``summary.set(...)`` to attach a structured text string to the
    current test case result.  The plugin reads it in ``pytest_runtest_logreport``
    after the call phase completes.

    Example::

        def test_api_health(manta_test_summary):
            resp = httpx.get("/health")
            manta_test_summary.set(f"status={resp.status_code}")
            assert resp.status_code == 200
    """

    def __init__(self) -> None:
        self._value: str | None = None

    def set(self, value: str) -> None:
        """Attach a summary string to the current test."""
        self._value = value

    def get(self) -> str | None:
        return self._value

    def reset(self) -> None:
        self._value = None


class BackupCollector:
    """
    Thin facade around a ``BackupStorage`` instance for use inside test bodies.

    Injected via the ``manta_backup`` fixture.  Collected backup references
    are stored in ``_refs`` and the last one is used as ``backup_path`` on
    the corresponding ``TestCaseResult``.

    Example::

        def test_with_screenshot(manta_backup, tmp_path):
            screenshot = tmp_path / "screen.png"
            screenshot.write_bytes(b"...")
            manta_backup.store(screenshot, key="screen.png")
    """

    def __init__(self, storage: Any) -> None:  # storage: BackupStorage | None
        self._storage = storage
        self._refs: list[str] = []

    def store(self, src: Any, *, key: str) -> str | None:
        """Store a file or directory and record the returned reference."""
        if self._storage is None:
            return None
        from pathlib import Path

        p = Path(src)
        if p.is_dir():
            ref = self._storage.upload_dir(p, key=key)
        else:
            ref = self._storage.upload(p, key=key)
        self._refs.append(ref)
        return ref

    def last_ref(self) -> str | None:
        return self._refs[-1] if self._refs else None

    def reset(self) -> None:
        self._refs.clear()


# ---------------------------------------------------------------------------
# MantaPlugin
# ---------------------------------------------------------------------------


class MantaPlugin:
    """
    Pytest plugin that collects per-test results and builds a RunResult.

    Usage::

        plugin = MantaPlugin(run_id=UUID(job_id))
        pytest.main([str(tests_dir), ...], plugins=[plugin])
        result = plugin.build_result()

    Args:
        run_id:         UUID identifying this run (from MANTA_JOB_ID).
        backup_storage: Optional BackupStorage implementation.  When provided
                        a ``BackupCollector`` backed by this storage is
                        injected via the ``manta_backup`` fixture.
    """

    def __init__(self, run_id: UUID, backup_storage: Any = None) -> None:
        self.run_id = run_id
        self._backup_storage = backup_storage
        self._results: list[TestCaseResult] = []
        # Per-test state reset in pytest_runtest_call
        self._call_start: dict[str, float] = {}
        self._summaries: dict[str, SummaryContext] = {}
        self._backups: dict[str, BackupCollector] = {}

    # ------------------------------------------------------------------
    # pytest_configure — register dynamic fixtures
    # ------------------------------------------------------------------

    def pytest_configure(self, config: pytest.Config) -> None:
        """Register manta_test_summary and manta_backup as dynamic fixtures."""
        plugin_ref = self

        @pytest.fixture(scope="function")
        def manta_test_summary(request: pytest.FixtureRequest) -> SummaryContext:
            ctx = SummaryContext()
            plugin_ref._summaries[request.node.nodeid] = ctx
            yield ctx
            # No teardown needed — MantaPlugin reads the context after call phase

        @pytest.fixture(scope="function")
        def manta_backup(request: pytest.FixtureRequest) -> BackupCollector:
            collector = BackupCollector(plugin_ref._backup_storage)
            plugin_ref._backups[request.node.nodeid] = collector
            yield collector
            collector.reset()

        fixtures_cls = type(
            "_MantaFixtures",
            (),
            {
                "manta_test_summary": staticmethod(manta_test_summary),
                "manta_backup": staticmethod(manta_backup),
            },
        )
        config.pluginmanager.register(fixtures_cls(), name="_manta_fixtures")

    # ------------------------------------------------------------------
    # pytest_runtest_setup — capture setup-phase skips
    # ------------------------------------------------------------------

    def pytest_runtest_setup(self, item: pytest.Item) -> None:
        """Record the call-phase start time before setup completes."""
        # Start timing here so that setup cost is not baked into duration_ms.
        # The actual call-phase start is overwritten in pytest_runtest_call.
        self._call_start[item.nodeid] = time.monotonic()

    # ------------------------------------------------------------------
    # pytest_runtest_call — record precise call-phase start
    # ------------------------------------------------------------------

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item: pytest.Item) -> Any:  # type: ignore[override]
        self._call_start[item.nodeid] = time.monotonic()
        yield

    # ------------------------------------------------------------------
    # pytest_runtest_logreport — main result capture
    # ------------------------------------------------------------------

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_logreport(self, report: pytest.TestReport) -> Any:  # type: ignore[override]
        yield

        nodeid = report.nodeid

        # ── setup-phase skip: test was skipped before it even ran ──
        if report.when == "setup" and report.skipped:
            reason = str(report.longrepr) if report.longrepr else "skipped"
            self._results.append(
                TestCaseResult(
                    name=nodeid,
                    status=RunStatus.SKIPPED,
                    duration_ms=0,
                    error_message=reason,
                    started_at=datetime.now(UTC),
                    finished_at=datetime.now(UTC),
                )
            )
            return

        # Only capture the "call" phase for all other outcomes
        if report.when != "call":
            return

        # ── timing ──
        start_mono = self._call_start.pop(nodeid, None)
        call_started_at = datetime.now(UTC)
        call_finished_at = datetime.now(UTC)
        duration_ms = int(report.duration * 1000)
        if start_mono is not None:
            elapsed = time.monotonic() - start_mono
            duration_ms = max(duration_ms, int(elapsed * 1000))

        # ── status mapping ──
        wasxfail = getattr(report, "wasxfail", None)
        if wasxfail is not None:
            # xfail (expected failure) or xpass (unexpectedly passed)
            status = RunStatus.XFAIL
            error_message: str | None = str(wasxfail) if wasxfail else None
        elif report.passed:
            status = RunStatus.PASSED
            error_message = None
        elif report.failed:
            status = RunStatus.FAILED
            error_message = str(report.longrepr) if report.longrepr else None
        else:
            # call-phase skipped (e.g. pytest.skip() inside test body)
            status = RunStatus.SKIPPED
            error_message = str(report.longrepr) if report.longrepr else "skipped"

        # ── fixtures ──
        summary_ctx = self._summaries.pop(nodeid, None)
        test_summary = summary_ctx.get() if summary_ctx else None

        backup_collector = self._backups.get(nodeid)
        backup_path = backup_collector.last_ref() if backup_collector else None

        stdout = report.capstdout or ""

        self._results.append(
            TestCaseResult(
                name=nodeid,
                status=status,
                duration_ms=duration_ms,
                error_message=error_message,
                stdout=stdout,
                started_at=call_started_at,
                finished_at=call_finished_at,
                test_summary=test_summary,
                backup_path=backup_path,
            )
        )

    # ------------------------------------------------------------------
    # build_result
    # ------------------------------------------------------------------

    def build_result(self) -> RunResult:
        """Aggregate collected test reports into a RunResult."""
        passed = sum(1 for r in self._results if r.status == RunStatus.PASSED)
        failed = sum(1 for r in self._results if r.status == RunStatus.FAILED)
        # errors: ERROR + XFAIL (unexpected failures) — SKIPPED is not an error
        errors = sum(1 for r in self._results if r.status in (RunStatus.ERROR, RunStatus.XFAIL))
        total_ms = sum(r.duration_ms for r in self._results)

        if failed > 0 or errors > 0:
            overall = RunStatus.FAILED
        elif passed > 0:
            overall = RunStatus.PASSED
        else:
            overall = RunStatus.ERROR  # no tests ran at all

        return RunResult(
            run_id=self.run_id,
            status=overall,
            duration_ms=total_ms,
            total_tests=len(self._results),
            passed=passed,
            failed=failed,
            errors=errors,
            test_cases=list(self._results),
        )
