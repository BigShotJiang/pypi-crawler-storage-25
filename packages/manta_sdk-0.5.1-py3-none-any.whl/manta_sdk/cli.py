"""
CLI entry point owned by manta-sdk.

Each generated runner package has a thin _cli.py shim that calls run_tests()
from here. The SDK owns all infrastructure:
  - Reading MANTA_* env vars
  - Downloading the SUT from storage-service
  - Installing / preparing it
  - Running pytest with MantaPlugin
  - Uploading allure-results.zip + junit.xml to storage-service
  - POSTing RunResult to the queue-manager callback URL

The generated runner owns only pure pytest test classes under tests/.

Environment variables (injected by queue-manager when dispatching the container):
  MANTA_JOB_ID          — job UUID (used as run_id and as pytest run_id fixture)
  MANTA_CALLBACK_URL    — queue-manager endpoint to POST RunResult (omitted in collect mode)
  MANTA_ASSET_ID        — SUT asset_id for storage-service download
  MANTA_STORAGE_URL     — storage-service base URL (default: http://storage-service:8004)
  MANTA_TEAM_ID         — team identifier (default: "manta")
  MANTA_SUT_TYPE        — one of: elf_binary, macho, pe, shell_script,
                                   python_script, python_wheel, or raw file(1) output
                                   for binary types (default: elf_binary).
                                   Zip archives are auto-detected regardless of this value.
  MANTA_SUT_MODULE      — installed module name (required when MANTA_SUT_TYPE=python_wheel)

Queue-based stability mode (set by queue-manager for stability workers):
  MANTA_COLLECT_ONLY=1  — collect test node_ids, print one per line to stdout, then exit.
                           Does NOT run tests or POST a RunResult.
  MANTA_TEST_LIST       — comma-separated pytest node_ids to run (may include duplicates).
                           Each node_id is run as a separate pytest.main() call so
                           duplicates accumulate independently. Results are merged into
                           one combined RunResult and POSTed to MANTA_CALLBACK_URL.
"""

from __future__ import annotations

import asyncio
import json
import os
import platform
import stat
import subprocess
import sys
import zipfile
from importlib.metadata import version as _pkg_version
from io import BytesIO
from pathlib import Path
from uuid import UUID

import httpx
import pytest

from manta_sdk.models import RunResult
from manta_sdk.plugin import MantaPlugin

# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_tests(tests_dir: Path) -> None:
    """
    Main entry point for generated runner packages.

    Called by the _cli.py shim::

        from pathlib import Path
        from manta_sdk.cli import run_tests

        def main() -> None:
            run_tests(Path(__file__).parent / "tests")
    """
    asyncio.run(_run_async(tests_dir))


# ---------------------------------------------------------------------------
# Internal implementation
# ---------------------------------------------------------------------------


async def _run_async(tests_dir: Path) -> None:
    job_id = os.environ["MANTA_JOB_ID"]
    callback_url = os.environ.get("MANTA_CALLBACK_URL", "")
    asset_id = os.environ["MANTA_ASSET_ID"]
    storage_url = os.environ.get("MANTA_STORAGE_URL", "http://storage-service:8004")
    team_id = os.environ.get("MANTA_TEAM_ID", "manta")
    sut_type = os.environ.get("MANTA_SUT_TYPE", "elf_binary")
    sut_module = os.environ.get("MANTA_SUT_MODULE", "")

    # Download and prepare the SUT (needed for both collection and test execution
    # so that conftest imports and test collection both see the installed package).
    sut_bytes = await _download_asset(storage_url, asset_id)
    _prepare_sut(sut_type, sut_module, sut_bytes)

    # Collection-only mode: print node_ids to stdout and exit without running tests.
    if os.environ.get("MANTA_COLLECT_ONLY") == "1":
        await asyncio.to_thread(_collect_and_print, tests_dir)
        return

    run_id = UUID(job_id)

    allure_dir = Path("/tmp/allure-results")  # noqa: S108
    junit_xml = Path("/tmp/junit.xml")  # noqa: S108
    allure_dir.mkdir(parents=True, exist_ok=True)

    queue_url = os.environ.get("MANTA_QUEUE_URL", "")

    if queue_url:
        # Worker-pull stability mode: loop GET /next → run test → POST /result.
        await _worker_loop(tests_dir, run_id, queue_url, allure_dir, junit_xml)
        # Upload allure results so the report shows all tests this worker ran.
        _write_allure_environment(allure_dir, job_id, team_id, asset_id, sut_type)
        await _upload_artifacts(storage_url, team_id, job_id, allure_dir, junit_xml)
    else:
        # Normal first-run mode: run the full suite and POST one RunResult.
        plugin = MantaPlugin(run_id)
        exit_code = await asyncio.to_thread(
            lambda: pytest.main(
                [
                    str(tests_dir),
                    "-v",
                    f"--alluredir={allure_dir}",
                    f"--junit-xml={junit_xml}",
                ],
                plugins=[plugin],
            )
        )
        result = plugin.build_result()
        result.exit_code = int(exit_code)

        # Build analytics records from test case results
        analytics_records = _build_analytics_records(result)

        # Write Allure environment tab and analytics.json before zipping
        _write_allure_environment(allure_dir, job_id, team_id, asset_id, sut_type)
        _write_analytics_json(allure_dir, job_id, team_id, analytics_records)

        # Upload artifacts and POST result
        allure_asset_id = await _upload_artifacts(storage_url, team_id, job_id, allure_dir, junit_xml)
        if callback_url:
            await _post_result(callback_url, result, allure_asset_id, analytics_records=analytics_records)

        # Trigger analytics ingest (non-blocking, best-effort)
        analytics_url = os.environ.get("MANTA_ANALYTICS_URL", "")
        commit_hash = os.environ.get("MANTA_COMMIT_HASH", "")
        sut_version = commit_hash or None
        if analytics_url:
            await _trigger_analytics_ingest(analytics_url, job_id, team_id, asset_id, sut_version, analytics_records)


# ---------------------------------------------------------------------------
# Queue-based stability helpers
# ---------------------------------------------------------------------------


class MantaCollectPlugin:
    """Pytest plugin that records collected item node_ids during --collect-only."""

    def __init__(self) -> None:
        self.collected_ids: list[str] = []

    def pytest_collection_finish(self, session: pytest.Session) -> None:  # type: ignore[name-defined]
        for item in session.items:
            self.collected_ids.append(item.nodeid)


def _collect_and_print(tests_dir: Path) -> None:
    """
    Run pytest --collect-only and print one node_id per line to stdout.

    Called when MANTA_COLLECT_ONLY=1. The queue-manager captures stdout and
    builds the stability queue from these node_ids. Exits without running any
    test bodies, uploading artifacts, or posting a RunResult callback.
    """
    plugin = MantaCollectPlugin()
    pytest.main(
        [
            str(tests_dir),
            "--collect-only",
            "-q",
            "--no-header",
            "-p",
            "no:terminal",
            f"--rootdir={tests_dir.parent}",
        ],
        plugins=[plugin],
    )
    for node_id in plugin.collected_ids:
        print(node_id, flush=True)


async def _worker_loop(
    tests_dir: Path,
    run_id: UUID,
    queue_url: str,
    allure_dir: Path,
    junit_xml: Path,
) -> None:
    """
    Stability worker-pull loop.

    Repeatedly polls the queue-manager for the next test node_id, runs it,
    and posts the individual result back.  Exits when the queue is empty.

    Each test runs in its own isolated --alluredir subdirectory so that
    session-scoped fixture containers are self-contained (one container per
    test, not one shared container per pytest session).  After the loop the
    subdirs are merged into allure_dir so the final upload aggregates every
    test run into a single clean Allure report with proper retry grouping.
    """
    import shutil
    import time

    root = tests_dir.parent
    next_url = f"{queue_url}/stability/next"
    result_url = f"{queue_url}/stability/result"
    run_index = 0

    async with httpx.AsyncClient(timeout=30.0) as client:
        while True:
            # --- pull next test ---
            resp = await client.get(next_url)
            resp.raise_for_status()
            node_id: str | None = resp.json().get("node_id")
            if node_id is None:
                break  # queue exhausted — exit cleanly

            # Use an isolated allure subdir per run so session-scoped fixture
            # containers are not shared across pytest sessions (which causes
            # them to appear as orphaned "broken" entries in the Allure report).
            run_allure_dir = allure_dir / f"_run_{run_index}"
            run_allure_dir.mkdir(parents=True, exist_ok=True)
            run_index += 1

            # --- run it ---
            abs_node = str(root / node_id) if not os.path.isabs(node_id) else node_id
            plugin = MantaPlugin(run_id)
            started = time.monotonic()
            await asyncio.to_thread(
                lambda: pytest.main(
                    [
                        abs_node,
                        "-v",
                        f"--rootdir={root}",
                        f"--alluredir={run_allure_dir}",
                        f"--junit-xml={junit_xml}",
                    ],
                    plugins=[plugin],
                )
            )
            duration_ms = int((time.monotonic() - started) * 1000)

            # Merge this run's allure files into the shared dir now so that
            # allure file names (UUIDs) remain unique and associations are clean.
            for f in run_allure_dir.iterdir():
                if f.is_file():
                    shutil.move(str(f), allure_dir / f.name)

            # --- report result ---
            test_results = plugin.build_result()
            # If the test ran, use its recorded outcome; otherwise report error.
            if test_results.test_cases:
                tc = test_results.test_cases[-1]
                tc_status = tc.status.value
                tc_duration = tc.duration_ms
                tc_error = tc.error_message
            else:
                tc_status = "error"
                tc_duration = duration_ms
                tc_error = "pytest produced no test report"

            try:
                await client.post(
                    result_url,
                    json={
                        "node_id": node_id,
                        "status": tc_status,
                        "duration_ms": tc_duration,
                        "error_message": tc_error,
                    },
                )
            except Exception:
                pass  # keep looping even if the POST fails


async def _download_asset(storage_url: str, asset_id: str) -> bytes:
    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.get(f"{storage_url}/assets/{asset_id}/download")
        resp.raise_for_status()
        return resp.content


def _prepare_sut(sut_type: str, sut_module: str, sut_bytes: bytes) -> None:
    """Download SUT, install/chmod, and set env vars consumed by conftest fixtures."""
    sut_dir = Path("/tmp/manta-sut")  # noqa: S108
    sut_dir.mkdir(parents=True, exist_ok=True)

    if sut_type == "python_wheel":
        sut_path = sut_dir / "sut.whl"
        sut_path.write_bytes(sut_bytes)
        subprocess.run(  # noqa: S603
            ["pip", "install", str(sut_path)],
            check=True,
            capture_output=True,
            text=True,
        )
        os.environ["MANTA_SUT_MODULE"] = sut_module
        os.environ["MANTA_SUT_TYPE"] = sut_type
    elif sut_type == "python_script":
        sut_path = sut_dir / "sut.py"
        sut_path.write_bytes(sut_bytes)
        os.environ["MANTA_SUT_PATH"] = str(sut_path)
        os.environ["MANTA_SUT_TYPE"] = sut_type
    elif zipfile.is_zipfile(BytesIO(sut_bytes)):
        # Zip archive: extract and locate the primary entry point.
        # Covers: Python modules packaged as zips, native binaries shipped in zips,
        # and any other archive the file(1) command reports as "Zip archive data".
        extract_dir = sut_dir / "extracted"
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(BytesIO(sut_bytes)) as zf:
            zf.extractall(extract_dir)
        sut_path = _find_zip_entry(extract_dir)
        if sut_path.is_file():
            sut_path.chmod(sut_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        os.environ["MANTA_SUT_PATH"] = str(sut_path)
        os.environ["MANTA_SUT_TYPE"] = sut_type
    else:
        # Binary SUTs: elf_binary, macho, pe, shell_script, jar, etc.
        sut_path = sut_dir / "binary"
        sut_path.write_bytes(sut_bytes)
        sut_path.chmod(sut_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        os.environ["MANTA_SUT_PATH"] = str(sut_path)
        os.environ["MANTA_SUT_TYPE"] = sut_type

    # Universal directory pointer — consumed by make_sut_dir_fixture().
    os.environ["MANTA_SUT_DIR"] = str(sut_dir)


def _find_zip_entry(extract_dir: Path) -> Path:
    """Return the most likely executable entry point inside an extracted zip.

    Preference order:
    1. Single top-level file — unambiguous intent.
    2. Top-level non-.py file — native binary over Python source.
    3. Any top-level file.
    4. First top-level directory — Python package invokable with ``python dir/``.
    5. The extraction root itself (last resort).
    """
    top_level = sorted(extract_dir.iterdir())
    files = [p for p in top_level if p.is_file()]
    dirs = [p for p in top_level if p.is_dir()]

    if len(files) == 1:
        return files[0]

    non_py = [f for f in files if f.suffix != ".py"]
    if non_py:
        return non_py[0]

    if files:
        return files[0]

    if dirs:
        return dirs[0]

    return extract_dir


def _build_analytics_records(result: RunResult) -> list[dict]:
    """Convert a RunResult's test cases into analytics ingest records."""
    records = []
    for tc in result.test_cases:
        records.append(
            {
                "test_name": tc.name,
                "status": tc.status.value,
                "duration_ms": tc.duration_ms,
                "error_message": tc.error_message,
                "started_at": tc.started_at.isoformat() if tc.started_at else None,
                "finished_at": tc.finished_at.isoformat() if tc.finished_at else None,
                "test_summary": tc.test_summary,
                "backup_path": tc.backup_path,
            }
        )
    return records


def _write_analytics_json(allure_dir: Path, job_id: str, team_id: str, records: list[dict]) -> None:
    """Write analytics.json alongside the Allure results for offline consumption."""
    payload = {
        "execution_id": job_id,
        "team_id": team_id,
        "records": records,
    }
    (allure_dir / "analytics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


async def _trigger_analytics_ingest(
    analytics_url: str,
    job_id: str,
    team_id: str,
    asset_id: str,
    sut_version: str | None,
    records: list[dict],
) -> None:
    """POST analytics records to analytics-manager ingest endpoint."""
    payload = {
        "execution_id": job_id,
        "team_id": team_id,
        "asset_id": asset_id,
        "sut_version": sut_version,
        "records": records,
    }
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(f"{analytics_url}/analytics/ingest", json=payload)
            resp.raise_for_status()
    except Exception as exc:
        print(f"[manta-sdk] analytics ingest failed (non-fatal): {exc}", flush=True)


def _write_allure_environment(
    allure_dir: Path,
    job_id: str,
    team_id: str,
    asset_id: str,
    sut_type: str,
) -> None:
    """Write environment.properties into the allure-results directory.

    Allure reads this file and renders it as the "Environment" tab in the
    generated report. Format: Java properties (KEY=VALUE, one per line).
    """
    try:
        sdk_ver = _pkg_version("manta-sdk")
    except Exception:
        sdk_ver = "unknown"

    props = [
        f"MANTA_JOB_ID={job_id}",
        f"MANTA_TEAM_ID={team_id}",
        f"MANTA_ASSET_ID={asset_id}",
        f"MANTA_SUT_TYPE={sut_type}",
        f"manta_sdk_version={sdk_ver}",
        f"python_version={sys.version.split()[0]}",
        f"platform={platform.system()} {platform.release()} {platform.machine()}",
    ]
    runner_distro = os.environ.get("MANTA_RUNNER_DISTRO")
    if runner_distro:
        props.append(f"MANTA_RUNNER_DISTRO={runner_distro}")
    (allure_dir / "environment.properties").write_text("\n".join(props) + "\n", encoding="utf-8")


async def _upload_artifacts(
    storage_url: str,
    team_id: str,
    job_id: str,
    allure_dir: Path,
    junit_xml: Path,
) -> str | None:
    """Upload allure-results.zip and junit.xml to storage-service.

    Returns the allure asset_id if the allure zip upload succeeded, else None.
    """
    allure_asset_id: str | None = None
    async with httpx.AsyncClient(timeout=60.0) as client:
        allure_bytes = _zip_dir(allure_dir)
        if allure_bytes:
            resp = await client.post(
                f"{storage_url}/assets/upload",
                params={"team_id": team_id},
                files={"file": (f"{job_id}-allure-results.zip", allure_bytes, "application/zip")},
            )
            try:
                allure_asset_id = resp.json().get("asset_id")
            except Exception:
                allure_asset_id = None

        if junit_xml.exists():
            await client.post(
                f"{storage_url}/assets/upload",
                params={"team_id": team_id},
                files={"file": (f"{job_id}-junit.xml", junit_xml.read_bytes(), "application/xml")},
            )

    return allure_asset_id


def _zip_dir(directory: Path) -> bytes:
    """Zip all files in directory into a bytes buffer. Returns empty bytes if no files."""
    buf = BytesIO()
    count = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in directory.rglob("*"):
            if file.is_file():
                zf.write(file, file.relative_to(directory))
                count += 1
    return buf.getvalue() if count > 0 else b""


async def _post_result(
    callback_url: str,
    result: RunResult,
    allure_asset_id: str | None = None,
    analytics_records: list[dict] | None = None,
) -> None:
    payload = {
        "status": result.status.value,
        "total_cases": result.total_tests,
        "passed": result.passed,
        "failed": result.failed,
        "error": result.errors,
        "duration_seconds": result.duration_ms / 1000,
        "test_cases": [
            {
                "name": tc.name,
                "status": tc.status.value,
                "duration_seconds": tc.duration_ms / 1000,
                "error_message": tc.error_message,
            }
            for tc in result.test_cases
        ],
        "allure_asset_id": allure_asset_id,
        "analytics_records": analytics_records,
    }
    max_attempts = 3
    backoff_seconds = [1, 2, 4]
    async with httpx.AsyncClient(timeout=30.0) as client:
        for attempt in range(max_attempts):
            try:
                resp = await client.post(callback_url, json=payload)
                resp.raise_for_status()
                return
            except (httpx.HTTPStatusError, httpx.TransportError) as exc:
                if attempt < max_attempts - 1:
                    delay = backoff_seconds[attempt]
                    print(
                        f"[manta-sdk] callback POST failed (attempt {attempt + 1}/{max_attempts}), "
                        f"retrying in {delay}s: {exc}",
                        flush=True,
                    )
                    await asyncio.sleep(delay)
                else:
                    print(
                        f"[manta-sdk] callback POST failed after {max_attempts} attempts: {exc}",
                        flush=True,
                    )
                    raise


# ---------------------------------------------------------------------------
# Expose build_result for callers that run tests themselves (testing / CI)
# ---------------------------------------------------------------------------


def build_run_result_from_exit_code(exit_code: int, plugin: MantaPlugin) -> RunResult:
    """Utility for callers that invoke pytest.main themselves and want a RunResult."""
    result = plugin.build_result()
    result.exit_code = int(exit_code)
    return result


__all__ = ["run_tests", "build_run_result_from_exit_code", "MantaCollectPlugin"]
