from seqs.core import *
from seqs.tests import *

if __name__ == "__main__":
    main()
