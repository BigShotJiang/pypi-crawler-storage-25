"""
AXON Compiler — AST Node Definitions
======================================
The cognitive Abstract Syntax Tree of the AXON language.

KEY DESIGN PRINCIPLE:
  This AST has ZERO mechanical nodes (no ForLoop, no Variable, no AssignStmt).
  Every node represents a *cognitive* concept:
    - PersonaDefinition (not ClassDecl)
    - IntentNode        (not FunctionCall)
    - ReasonChain       (not ForLoop)
    - AnchorConstraint  (not AssertStatement)
    - ProbeDirective    (not SelectQuery)
    - WeaveNode         (not JoinExpression)

  The tree itself speaks the language of intelligence.
"""

from __future__ import annotations
from dataclasses import dataclass, field


# ═══════════════════════════════════════════════════════════════════
#  TRIVIA — comment metadata (Fase 14.a — Lossless lexing)
# ═══════════════════════════════════════════════════════════════════
#
# Trivia objects are the parser's materialisation of the comment tokens
# the lexer now emits (``LINE_COMMENT`` / ``BLOCK_COMMENT`` /
# ``DOC_LINE_COMMENT`` / ``DOC_BLOCK_COMMENT``). Each AST node carries
# a ``leading_trivia`` tuple (comments preceding the node's first
# token, up to the last newline-separator from the previous node) and
# a ``trailing_trivia`` tuple (comments on the same line as the node's
# last token, before the next newline). This is the Roslyn / Swift /
# rust-analyzer convention — it lets a downstream consumer round-trip
# parse → re-emit with comments preserved, and lets LSP hover surface
# the doc comment that precedes a definition.
#
# ``kind`` is a plain string ("line"|"block"|"doc_line"|"doc_block")
# rather than a TokenType reference so this module does not pull in
# `tokens.py` (would create a cycle: parser imports ast → ast imports
# tokens → tokens has no cycle but the directionality is cleaner kept
# in ast → tokens, not the reverse).

@dataclass(frozen=True, slots=True)
class Trivia:
    """A comment attached to an AST node (Fase 14.a / 14.c).

    The ``kind`` discriminator covers six varieties:
      - ``"line"``           — regular ``//``
      - ``"block"``          — regular ``/* */``
      - ``"doc_line"``       — outer doc ``///`` (documents the next item)
      - ``"doc_block"``      — outer doc ``/** */`` (documents the next item)
      - ``"inner_doc_line"`` — inner doc ``//!`` (documents enclosing module/file)
      - ``"inner_doc_block"``— inner doc ``/*! */`` (documents enclosing module/file)

    Inner doc comments (Fase 14.c) follow the Rust convention: they are
    intended to document the *enclosing* item (module / file), not the
    next sibling. They typically appear at the top of a file or just
    inside the opening brace of a block. ``axon doc`` consumers use the
    inner/outer distinction to decide whether the documentation applies
    to the parent or the next-following item.
    """
    kind: str          # "line"|"block"|"doc_line"|"doc_block"|"inner_doc_line"|"inner_doc_block"
    text: str          # raw text including markers (//, ///, /* */, /** */, //!, /*! */)
    line: int
    column: int

    @property
    def is_doc(self) -> bool:
        """True iff this trivia is any kind of doc comment (outer or inner)."""
        return self.kind in (
            "doc_line", "doc_block", "inner_doc_line", "inner_doc_block",
        )

    @property
    def is_inner_doc(self) -> bool:
        """True iff this trivia is an inner doc comment (//! or /*!)."""
        return self.kind in ("inner_doc_line", "inner_doc_block")

    def stripped_text(self) -> str:
        """The body of the comment with marker prefixes/suffixes removed.

        Useful for LSP hover rendering and doc generators. For block
        comments the leading ``/*`` (or ``/**`` / ``/*!``) and trailing
        ``*/`` are removed. For line comments the leading ``//`` (or
        ``///`` / ``//!``) is removed. No further normalisation (no
        whitespace trim, no de-indent of ``*``-prefixed lines) is
        performed — callers can layer their own cosmetic pass on top.
        """
        if self.kind == "doc_line":
            return self.text[3:] if self.text.startswith("///") else self.text
        if self.kind == "inner_doc_line":
            return self.text[3:] if self.text.startswith("//!") else self.text
        if self.kind == "line":
            return self.text[2:] if self.text.startswith("//") else self.text
        if self.kind == "doc_block":
            body = self.text
            if body.startswith("/**"):
                body = body[3:]
            if body.endswith("*/"):
                body = body[:-2]
            return body
        if self.kind == "inner_doc_block":
            body = self.text
            if body.startswith("/*!"):
                body = body[3:]
            if body.endswith("*/"):
                body = body[:-2]
            return body
        if self.kind == "block":
            body = self.text
            if body.startswith("/*"):
                body = body[2:]
            if body.endswith("*/"):
                body = body[:-2]
            return body
        return self.text


# ═══════════════════════════════════════════════════════════════════
#  BASE NODE
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ASTNode:
    """Base class for all AXON AST nodes.

    Every node carries source position (``line``, ``column``) plus two
    trivia channels (``leading_trivia`` / ``trailing_trivia``, Fase
    14.a). The trivia tuples default to empty so existing code that
    constructs AST nodes without trivia continues to work unchanged.
    """
    line: int = 0
    column: int = 0
    leading_trivia: tuple[Trivia, ...] = field(default_factory=tuple)
    trailing_trivia: tuple[Trivia, ...] = field(default_factory=tuple)


# ═══════════════════════════════════════════════════════════════════
#  TOP-LEVEL NODES
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ProgramNode(ASTNode):
    """Root of the AXON AST — a list of top-level declarations."""
    declarations: list[ASTNode] = field(default_factory=list)


@dataclass
class ImportNode(ASTNode):
    """
    import axon.anchors.{NoHallucination, NoBias}

    module_path: ["axon", "anchors"]
    names: ["NoHallucination", "NoBias"]  (empty = import all)
    """
    module_path: list[str] = field(default_factory=list)
    names: list[str] = field(default_factory=list)
    apx_enabled: bool = False
    apx_policy: dict[str, object] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════
#  DECLARATION NODES — the "who" and "what"
# ═══════════════════════════════════════════════════════════════════

@dataclass
class PersonaDefinition(ASTNode):
    """
    persona LegalExpert {
      domain: ["contract law", "IP"]
      tone: precise
      confidence_threshold: 0.85
      ...
    }

    The cognitive identity executing the flow.
    """
    name: str = ""
    domain: list[str] = field(default_factory=list)
    tone: str = ""
    confidence_threshold: float | None = None
    cite_sources: bool | None = None
    refuse_if: list[str] = field(default_factory=list)
    language: str = ""
    description: str = ""


@dataclass
class ContextDefinition(ASTNode):
    """
    context LegalReview {
      memory: session
      language: "es"
      depth: exhaustive
      max_tokens: 4096
      temperature: 0.3
    }

    The working memory and session configuration.
    """
    name: str = ""
    memory_scope: str = ""  # session | persistent | none
    language: str = ""
    depth: str = ""  # shallow | standard | deep | exhaustive
    max_tokens: int | None = None
    temperature: float | None = None
    cite_sources: bool | None = None


@dataclass
class AnchorConstraint(ASTNode):
    """
    anchor NoHallucination {
      require: source_citation
      confidence_floor: 0.75
      unknown_response: "I don't have sufficient information..."
      on_violation: raise AnchorBreachError
    }

    A hard constraint that can NEVER be violated.
    """
    name: str = ""
    require: str = ""
    reject: list[str] = field(default_factory=list)
    enforce: str = ""
    description: str = ""
    confidence_floor: float | None = None
    unknown_response: str = ""
    on_violation: str = ""
    on_violation_target: str = ""  # for "raise <ErrorName>" or "fallback(...)"


@dataclass
class MemoryDefinition(ASTNode):
    """
    memory LongTermKnowledge {
      store: persistent
      backend: vector_db
      retrieval: semantic
      decay: none
    }

    Persistent semantic storage.
    """
    name: str = ""
    store: str = ""  # session | persistent | ephemeral
    backend: str = ""  # vector_db | in_memory | redis | custom
    retrieval: str = ""  # semantic | exact | hybrid
    decay: str = ""  # none | daily | weekly | <duration>


@dataclass
class ToolDefinition(ASTNode):
    """
    tool WebSearch {
      provider: brave
      max_results: 5
      filter: recent(days: 30)
      timeout: 10s
      effects: <io, network, epistemic:speculate>
    }

    An external capability the model can invoke.

    Convergence Theorem 2 extension:
      The ``effects`` field declares the algebraic effect row for this tool.
      This enables the type checker to verify epistemic compatibility
      between tools and anchors (e.g., a ``require: source_citation``
      anchor rejects tools with ``epistemic:speculate`` without shield).
    """
    name: str = ""
    provider: str = ""
    max_results: int | None = None
    filter_expr: str = ""
    timeout: str = ""  # duration string
    runtime: str = ""
    sandbox: bool | None = None
    effects: EffectRowNode | None = None  # Convergence Theorem 2


# ═══════════════════════════════════════════════════════════════════
#  STREAMING & EFFECT NODES — Convergence Theorems 1 & 2
# ═══════════════════════════════════════════════════════════════════

@dataclass
class EffectRowNode(ASTNode):
    """
    effects: <io, network, epistemic:speculate>

    An algebraic effect row declaration for a tool or step.

    Theoretical basis — Convergence Theorem 2:
      Effects are first-class citizens with epistemic signatures.
      The effect row is a Koka-style row type that declares:
        - Side-effect categories: io, network, pure
        - Epistemic classification: know, believe, speculate, doubt

    The type checker uses effect rows to enforce:
      1. Anchors requiring citations reject speculate-level tools
      2. Taint propagation follows the Denning security lattice
      3. Pure tools (no I/O) are statically verified as deterministic
    """
    effects: list[str] = field(default_factory=list)  # ["io", "network"]
    epistemic_level: str = ""  # "know" | "believe" | "speculate" | "doubt"


@dataclass
class StreamHandlerNode(ASTNode):
    """
    on_chunk(chunk) { shield.scan_incremental(chunk) }
    on_complete(full_response) { promote(believe → know) }

    Handler for co-inductive stream evaluation.

    Theoretical basis — Convergence Theorem 1:
      Streams are coinductive structures (νX. StreamChunk × X).
      Handlers evaluate the stream co-inductively: the safety
      property holds for the head AND recursively for the tail.
    """
    handler_type: str = ""  # "on_chunk" | "on_complete"
    param_name: str = ""    # parameter name for the handler
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class StreamDefinition(ASTNode):
    """
    stream<Diagnosis> {
      epistemic_gradient: doubt → speculate → believe → know

      on_chunk(chunk) {
        shield.scan_incremental(chunk)
      }

      on_complete(full_response) {
        if anchor.validate(full_response) and contracts.satisfied():
          promote(believe → know)
      }
    }

    A semantic streaming declaration with epistemic gradient.

    Theoretical basis — Convergence Theorem 1:
      Stream(τ) = νX. (StreamChunk × EpistemicState × X)
      where EpistemicState ∈ {⊥, doubt, speculate, believe, know}
      and the transition is monotonic on the epistemic lattice.

      The gradient defines the valid progression path for epistemic
      state during streaming. Backpressure is modeled as a linear
      type: Budget(n) ⊸ Stream(τ) → (Chunk × Budget(n-1)).
    """
    name: str = ""                                          # element type name
    element_type: TypeExprNode | None = None                # generic parameter
    epistemic_gradient: list[str] = field(default_factory=list)  # ["doubt", "speculate", ...]
    handlers: list[StreamHandlerNode] = field(default_factory=list)
    shield_ref: str = ""                                    # optional shield for co-inductive eval


# ═══════════════════════════════════════════════════════════════════
#  TYPE SYSTEM NODES
# ═══════════════════════════════════════════════════════════════════

@dataclass
class TypeExprNode(ASTNode):
    """
    A type reference: Document, List<Party>, FactualClaim?

    name: "Document" | "List" | "FactualClaim"
    generic_param: "Party" (for List<Party>)
    optional: True (for FactualClaim?)
    """
    name: str = ""
    generic_param: str = ""
    optional: bool = False


@dataclass
class RangeConstraint(ASTNode):
    """
    (0.0..1.0) — numeric range constraint on a type.
    """
    min_value: float = 0.0
    max_value: float = 0.0


@dataclass
class WhereClause(ASTNode):
    """
    where confidence >= 0.85
    where sources.length > 0

    A constraint expression on a type.
    """
    expression: str = ""  # raw condition string for now


@dataclass
class TypeFieldNode(ASTNode):
    """
    name: FactualClaim
    role: FactualClaim
    legal_standing: Opinion?

    A single field in a structured type definition.
    """
    name: str = ""
    type_expr: TypeExprNode | None = None


@dataclass
class TypeDefinition(ASTNode):
    """
    type RiskScore(0.0..1.0)
    type Party { name: FactualClaim, role: FactualClaim }
    type HighConfidenceClaim where confidence >= 0.85

    type PatientRecord compliance [HIPAA] {
        name: String
        ssn: String
    }

    A semantic type declaration with optional fields, range, where
    clause, and regulatory compliance annotations (ESK Fase 6.1).

    When `compliance` is non-empty, the type carries a **regulatory
    class κ** (per paper ΛD v6 and plan_io_cognitivo.md §6.1).  The
    compiler enforces that any flow/endpoint consuming such a type
    must be gated by a shield whose compliance list ⊇ this type's
    compliance set — a *compile-time* proof of regulatory coverage.
    """
    name: str = ""
    fields: list[TypeFieldNode] = field(default_factory=list)
    range_constraint: RangeConstraint | None = None
    where_clause: WhereClause | None = None
    compliance: list[str] = field(default_factory=list)  # κ — regulatory class (ESK)


# ═══════════════════════════════════════════════════════════════════
#  FLOW & STEP NODES — the "how"
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ParameterNode(ASTNode):
    """
    doc: Document
    depth: Integer

    A typed parameter for a flow.
    """
    name: str = ""
    type_expr: TypeExprNode | None = None


@dataclass
class FlowDefinition(ASTNode):
    """
    flow AnalyzeContract(doc: Document) -> ContractAnalysis {
      step Extract { ... }
      probe doc for [parties]
      reason about Risks { ... }
    }

    The "function" of AXON — a composable cognitive pipeline.
    """
    name: str = ""
    parameters: list[ParameterNode] = field(default_factory=list)
    return_type: TypeExprNode | None = None
    body: list[ASTNode] = field(default_factory=list)  # list of flow steps


@dataclass
class StepNode(ASTNode):
    """
    step Extract {
      given: doc
      probe doc for [parties, dates]
      output: EntityMap
    }

    A named cognitive step inside a flow.
    """
    name: str = ""
    persona_ref: str = ""                          # step X use Persona { }
    given: str = ""  # input expression
    ask: str = ""  # instruction string
    use_tool: UseToolNode | None = None
    probe: ProbeDirective | None = None
    reason: ReasonChain | None = None
    weave: WeaveNode | None = None
    output_type: str = ""
    confidence_floor: float | None = None
    navigate_ref: str = ""                         # navigate: pix.document_tree
    apply_ref: str = ""                            # apply: AnchorName
    body: list[ASTNode] = field(default_factory=list)  # sub-steps


# ═══════════════════════════════════════════════════════════════════
#  COGNITIVE STEP NODES — the intelligence
# ═══════════════════════════════════════════════════════════════════

@dataclass
class IntentNode(ASTNode):
    """
    intent ExtractParties {
      given: Document
      ask: "Identify all parties..."
      output: List<Party>
      confidence_floor: 0.9
    }

    An atomic semantic instruction with typed I/O.
    """
    name: str = ""
    given: str = ""
    ask: str = ""
    output_type: TypeExprNode | None = None
    confidence_floor: float | None = None


@dataclass
class ProbeDirective(ASTNode):
    """
    probe document for [parties, dates, obligations, penalties]

    Targeted structured extraction — declarative "look for this".
    """
    target: str = ""  # what to probe (expression / identifier)
    fields: list[str] = field(default_factory=list)  # what to extract


@dataclass
class ReasonChain(ASTNode):
    """
    reason about Risks {
      given: EntityMap
      depth: 3
      show_work: true
      ask: "What clauses present risk?"
      output: RiskAnalysis
    }

    Explicit chain-of-thought directive with configurable depth.
    """
    name: str = ""
    about: str = ""  # topic identifier
    given: str | list[str] = ""
    depth: int = 1
    show_work: bool = False
    chain_of_thought: bool = False
    ask: str = ""
    output_type: str = ""


@dataclass
class ValidateRule(ASTNode):
    """
    if confidence < 0.80 -> refine(max_attempts: 2)
    if structural_mismatch -> raise ValidationError

    A single validation rule inside a validate block.
    """
    condition: str = ""
    comparison_op: str = ""
    comparison_value: str = ""
    action: str = ""  # "refine" | "raise" | "warn" | "pass"
    action_target: str = ""  # error class or string for warn
    action_params: dict[str, str] = field(default_factory=dict)


@dataclass
class ValidateGate(ASTNode):
    """
    validate Assess.output against RiskSchema {
      if confidence < 0.80 -> refine(max_attempts: 2)
      if structural_mismatch -> raise ValidationError
    }

    A semantic validation checkpoint.
    """
    target: str = ""  # expression to validate
    schema: str = ""  # type/schema to validate against
    rules: list[ValidateRule] = field(default_factory=list)


@dataclass
class RefineBlock(ASTNode):
    """
    refine {
      max_attempts: 3
      pass_failure_context: true
      backoff: exponential
      on_exhaustion: escalate
    }

    Adaptive retry with failure context injection.
    """
    max_attempts: int = 3
    pass_failure_context: bool = True
    backoff: str = "none"  # none | linear | exponential
    on_exhaustion: str = ""  # raise <X> | escalate | fallback(...)
    on_exhaustion_target: str = ""


@dataclass
class WeaveNode(ASTNode):
    """
    weave [EntityMap, RiskAnalysis, LegalPrecedents] into FinalReport {
      format: StructuredReport
      priority: [risks, recommendations, summary]
    }

    Semantic synthesis — combines multiple outputs into a coherent result.
    """
    sources: list[str] = field(default_factory=list)
    target: str = ""  # output identifier
    format_type: str = ""
    priority: list[str] = field(default_factory=list)
    style: str = ""


@dataclass
class UseToolNode(ASTNode):
    """
    use WebSearch("quantum computing 2025")
    use create_markdown(path="./out.md", mode="append")

    Invoke an external tool capability.
    Supports both positional (argument) and named (static_args) parameters.
    When static_args is non-empty, the runtime bypasses LLM inference (v0.25.5).
    """
    tool_name: str = ""
    argument: str = ""
    static_args: dict[str, object] = field(default_factory=dict)


@dataclass
class RememberNode(ASTNode):
    """
    remember(ResearchSummary) -> ResearchKnowledge

    Store a value into semantic memory.
    """
    expression: str = ""
    memory_target: str = ""


@dataclass
class RecallNode(ASTNode):
    """
    recall("quantum computing") from ResearchKnowledge

    Retrieve from semantic memory.
    """
    query: str = ""
    memory_source: str = ""


@dataclass
class ConditionalNode(ASTNode):
    """
    if confidence < 0.5 -> step Retry { ... }
    else -> step Skip { ... }

    A cognitive conditional branching.
    """
    condition: str = ""
    comparison_op: str = ""
    comparison_value: str = ""
    then_step: ASTNode | None = None
    else_step: ASTNode | None = None
    then_body: list[ASTNode] = field(default_factory=list)  # block { }
    else_body: list[ASTNode] = field(default_factory=list)
    conditions: list[tuple[str, str, str]] = field(default_factory=list)  # compound
    conjunctor: str = ""  # "or" | "and"



@dataclass
class ForInStatement(ASTNode):
    """
    for chapter in thesis.chapters {
        step AnalyzeChapter { ... }
    }

    Cognitive iteration — systematic traversal of a structured
    collection.  Each element is bound to `variable` and the
    body steps are executed per-element.

    The iterable is a dotted path expression resolved at runtime
    (e.g. ``thesis.chapters``, ``corpus.documents``).
    """
    variable: str = ""                              # loop binding name
    iterable: str = ""                              # dotted path expression
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class LetStatement(ASTNode):
    """
    let draft_path = "workspace/drafts/tesis_completa.md"

    SSA immutable binding — a lexical axiom that cannot be rebound.
    Equivalent to λ-calculus ``let x = v in E``: a static,
    referentially transparent substitution.

    The value_expr is a compile-time constant: a string literal,
    numeric literal, boolean, dotted identifier path, or a list
    literal of such values.

    `value_kind` (Fase 17.a) preserves the parser's tokenization
    intent so the runtime dispatcher can distinguish literal strings
    from dotted-identifier references — without it, `let X = "step_a"`
    and `let X = step_a` collapse into the same IR shape and the
    runtime cannot decide whether to bind verbatim or resolve via the
    context. Values:

      "literal"     — bound verbatim (str/int/float/bool/list)
      "reference"   — dotted identifier resolved at runtime via
                      `ctx.resolve_value_ref` (e.g., `step_a.output`)
      "expression"  — arithmetic expression for runtime evaluation
                      (e.g., `2 + 3` joined by parser into "2 + 3";
                      currently bound as a string until the
                      NativeComputeDispatcher integration ships)
    """
    identifier: str = ""                            # binding name
    value_expr: str | int | float | bool | list = field(default_factory=str)
    value_kind: str = "literal"                     # Fase 17.a — see docstring


@dataclass
class ReturnStatement(ASTNode):
    """return expr — Early Exit Sink in the cognitive DAG.

    The flow collapses when epistemic certainty is achieved.
    The value_expr is a sub-tree (ASTNode), not a primitive —
    parsed via the expression method for structural integrity.
    """
    value_expr: ASTNode | None = None


@dataclass
class BreakStatement(ASTNode):
    """break — exit the enclosing ``for ... in`` body (Fase 19.e).

    Like Python's ``break``: terminates the innermost loop and
    transfers control to the step immediately after the loop.
    Outside a loop body, the parser raises ``AxonParseError`` —
    break has no other meaning at flow scope.
    """


@dataclass
class ContinueStatement(ASTNode):
    """continue — skip to the next iteration of the enclosing
    ``for ... in`` body (Fase 19.e).

    Like Python's ``continue``: aborts the current iteration's
    remaining steps and advances the loop variable to the next
    element. Outside a loop body, the parser raises
    ``AxonParseError``."""


# ═══════════════════════════════════════════════════════════════════
#  PARADIGM SHIFT NODES — epistemic scoping, parallelism, yielding
# ═══════════════════════════════════════════════════════════════════

@dataclass
class EpistemicBlock(ASTNode):
    """
    know { flow SummarizeEvidence(...) -> HighConfidenceFact }
    speculate { flow Brainstorm(...) -> Opinion }

    A cognitive scope modifier that injects epistemic constraints and
    tunes LLM parameters based on the confidence state.

    Modes:
      know      — strict: low temperature, citation required
      believe   — moderate: medium temperature, no hallucination
      speculate — creative: high temperature, relaxed constraints
      doubt     — analytical: low temperature, syllogistic checks
    """
    mode: str = ""           # "know" | "believe" | "speculate" | "doubt"
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class ParallelBlock(ASTNode):
    """
    par {
        step Financial { ... }
        step Legal { ... }
    }

    Concurrent cognitive dispatch — branches run in parallel via
    asyncio.gather and their results are collected into context.
    """
    branches: list[ASTNode] = field(default_factory=list)


@dataclass
class HibernateNode(ASTNode):
    """
    hibernate until "amendment_received"

    Suspends execution, serializes the cognitive state (call stack,
    local variables, IR pointer), and waits for an external event
    to resume. Creates an immortal agent checkpoint.
    """
    event_name: str = ""     # the event to wait for
    timeout: str = ""        # optional duration before auto-resume


@dataclass
class DeliberateBlock(ASTNode):
    """
    deliberate {
        budget: 8000
        depth: 3
        strategy: thorough
        step DeepAnalysis { ... }
    }

    Declares a computational budget for wrapped steps. Controls how
    much inference compute the model should allocate (System 2 depth).

    Fields:
        budget:   maximum tokens for reasoning (0 = no limit)
        depth:    maximum reasoning iterations
        strategy: "quick" | "balanced" | "thorough" | "exhaustive"
    """
    budget: int = 0
    depth: int = 1
    strategy: str = "balanced"
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class ConsensusBlock(ASTNode):
    """
    consensus {
        branches: 5
        reward: AccuracyAnchor
        selection: best
        step Classify { ... }
    }

    Runs the same task N times under speculative mode and selects
    the best result via a reward anchor. Implements Best-of-N
    selection with deterministic validation.

    Fields:
        branches:       number of parallel runs (>= 2)
        reward_anchor:  anchor name used as the reward function
        selection:      "best" | "majority"
    """
    branches: int = 3
    reward_anchor: str = ""
    selection: str = "best"
    body: list[ASTNode] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  CREATIVE SYNTHESIS NODES — the forge engine
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ForgeBlock(ASTNode):
    """
    forge Painting(seed: "aurora boreal") -> Visual {
        mode: combinatory
        novelty: 0.8
        constraints: GoldenRatio
        depth: 3
        branches: 5
        step Compose { ... }
    }

    Directed creative synthesis — orchestrates the full Poincaré
    pipeline (Preparation → Incubation → Illumination → Verification)
    with mathematical control of the novelty-utility tradeoff (Boden).

    The forge primitive does NOT claim imagination. It formalizes
    the mathematical operation of directed movement through a
    conceptual space, maximizing compression and novelty — exactly
    what human creativity does (Friston, Schmidhuber, Bennett).

    Fields:
        name:         identifier for the forge block
        seed:         input seed concept (string expression)
        output_type:  declared output type name
        mode:         "combinatory" | "exploratory" | "transformational"
        novelty:      0.0..1.0 — creative freedom vs constraint adherence
        constraints:  anchor name for quality/beauty/coherence criteria
        depth:        incubation depth (Poincaré phase 2 iterations)
        branches:     Best-of-N branch count for illumination (phase 3)
    """
    name: str = ""
    seed: str = ""
    output_type: str = ""
    mode: str = "combinatory"
    novelty: float = 0.7
    constraints: str = ""
    depth: int = 3
    branches: int = 5
    body: list[ASTNode] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  ONTOLOGICAL TOOL SYNTHESIS (OTS) NODES
# ═══════════════════════════════════════════════════════════════════

@dataclass
class OtsDefinition(ASTNode):
    """
    ots DataExtractor<InputType, OutputType> {
        teleology: "Consume fragmented PDF invoice files to strictly emit normalized SQL inserts"
        homotopy_search: deep
        linear_constraints: {
            Consumption: strictly_once
        }
        loss_function: L_accuracy + 0.1 * L_complexity
    }

    The **ots** primitive — Ontological Tool Synthesis.
    Moves beyond static/dynamic tool binding to a continual capability space.
    """
    name: str = ""
    input_type: TypeExprNode | None = None
    output_type: TypeExprNode | None = None
    teleology: str = ""
    homotopy_search: str = "shallow"  # shallow | deep | speculative
    linear_constraints: dict[str, str] = field(default_factory=dict)
    loss_function: str = ""
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class OtsApplyNode(ASTNode):
    """
    ots DataExtractor(invoice_data) -> SqlInserts

    Application of a synthesized tool with ephemeral execution.
    """
    ots_name: str = ""
    target: str = ""
    output_type: str = ""


# ═══════════════════════════════════════════════════════════════════
#  AGENT NODES — BDI autonomous agent primitive
# ═══════════════════════════════════════════════════════════════════

@dataclass
class AgentBudget(ASTNode):
    """
    budget: {
        max_iterations: 10
        max_tokens: 50000
        max_time: 120s
        max_cost: 0.50
    }

    Resource constraints for the agent's deliberation cycle.

    Theoretical grounding — **Linear Logic** (Girard, 1987):
      Each resource token is *consumed* by an action and cannot be
      duplicated or discarded. This prevents unbounded computation
      and guarantees termination (unlike LangChain's max_iterations
      which is a soft cap with no formal resource semantics).

    Formal invariant:
      ∀ iteration i: Σ(cost_i) ≤ max_cost ∧ Σ(tokens_i) ≤ max_tokens
    """
    max_iterations: int = 10
    max_tokens: int = 0          # 0 = unlimited
    max_time: str = ""           # duration string (e.g., "120s", "5m")
    max_cost: float = 0.0        # 0.0 = unlimited, in fractional currency


@dataclass
class AgentDefinition(ASTNode):
    """
    agent LeadQualifier(prospect: ProspectData) -> QualifiedLead {
        goal: "Qualify and score the prospect using all available data"
        tools: [WebSearch, CRMQuery, EmailVerifier]
        budget: { max_iterations: 10, max_tokens: 50000 }
        memory: ConversationMemory
        strategy: react
        on_stuck: forge
        step GatherInfo { ... }
        step ScoreLead { ... }
    }

    The **agent** primitive — a first-class BDI cognitive entity.

    ╔══════════════════════════════════════════════════════════════╗
    ║  THEORETICAL FOUNDATIONS                                     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  BDI Architecture (Bratman, 1987; Rao & Georgeff, 1995):     ║
    ║    Agent = ⟨B, D, I, Plan_Library, Deliberation_Cycle⟩      ║
    ║    • Beliefs  = working memory + tool results                ║
    ║    • Desires  = goal string (Davidson's pro-attitude)        ║
    ║    • Intentions = body steps (plan library)                  ║
    ║                                                              ║
    ║  Coalgebraic Semantics:                                      ║
    ║    Agent = (S, O, step: S × Action → S, obs: S → O)         ║
    ║    Bisimulation equivalence ensures compositionality.        ║
    ║                                                              ║
    ║  Convergence — Fixed-Point (Tarski/Knaster):                 ║
    ║    T(σ*) = σ* on the epistemic lattice:                      ║
    ║    doubt ⊏ speculate ⊏ believe ⊏ know                       ║
    ║                                                              ║
    ║  Concurrency — π-Calculus (Milner, 1999):                    ║
    ║    Agent ≡ goal.( ν ch )( tool₁⟨ch⟩ | tool₂⟨ch⟩ | … )     ║
    ║                                                              ║
    ║  Self-Regulation — Ashby's Law of Requisite Variety:         ║
    ║    V(regulator) ≥ V(disturbance)                             ║
    ║    6+ regulatory mechanisms: anchors, validation, budget,    ║
    ║    refine, forge, epistemic modes, on_stuck, deliberate.     ║
    ║                                                              ║
    ║  Recovery — STIT Logic (Belnap, Perloff, Xu, 2001):          ║
    ║    [agent stit: φ] — "agent sees to it that φ"               ║
    ║    When ¬◇φ (no available option achieves φ), invoke         ║
    ║    on_stuck to escalate, forge, or hibernate.                ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

    Fields:
        name:        unique identifier for the agent definition
        parameters:  typed inputs (reuses FlowDefinition's ParameterNode)
        return_type: declared output type (optional)
        goal:        natural-language objective — Davidson's pro-attitude
        tools:       list of tool names available to the agent
        budget:      resource constraints (AgentBudget)
        memory_ref:  reference to a declared memory {} block
        strategy:    deliberation strategy:
                       "react"             — ReAct loop (Yao et al., 2023)
                       "reflexion"         — Reflexion with self-critique
                       "plan_and_execute"  — plan first, then execute
                       "custom"            — user-defined via body steps
        on_stuck:    recovery when no progress is detected:
                       "forge"     — creative synthesis to find new angles
                       "hibernate" — suspend and wait for external input
                       "escalate"  — raise to human operator
                       "retry"     — retry with modified parameters
        body:        list of flow steps (the agent's plan library)
    """
    name: str = ""
    parameters: list[ParameterNode] = field(default_factory=list)
    return_type: TypeExprNode | None = None
    goal: str = ""
    tools: list[str] = field(default_factory=list)
    budget: AgentBudget | None = None
    memory_ref: str = ""                   # reference to a memory {} block
    strategy: str = "react"                # react | reflexion | plan_and_execute | custom
    on_stuck: str = "escalate"             # forge | hibernate | escalate | retry
    shield_ref: str = ""                   # reference to a declared shield
    body: list[ASTNode] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  DAEMON NODES — AxonServer π-calculus reactive primitive
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ListenBlock(ASTNode):
    """
    Dual-mode listener (Fase 13 D4):

      # Canonical: typed channel reference (v1.5.0+)
      listen OrdersCreated as order_event { ... }

      # Legacy: string topic — emits deprecation warning (removed in v2.0)
      listen "orders" as event { ... }

    A single reactive listener within a daemon. Binds an event
    channel to a local alias and executes the body on each event.

    π-Calculus correspondence:
      listen "ch" as x { Q }  ≡  c(x).Q  (channel input prefix)

    Fields:
      channel_expr — for string-topic mode: the topic name as a Python
                     str.  For channel-reference mode (Fase 13): the
                     name of a declared ChannelDefinition.
      channel_is_ref — True when the listener refers to a
                     ChannelDefinition (typed); False when the listener
                     uses a string topic (legacy, deprecated).  The
                     type checker uses this flag to dispatch schema
                     verification vs legacy string-topic handling.
      event_alias  — local binding for the received event payload.
      body         — flow steps executed per event.
    """
    channel_expr: str = ""       # event channel name — topic string OR ChannelDefinition ref
    channel_is_ref: bool = False # True: channel_expr is a declared channel name (Fase 13)
    event_alias: str = ""        # local binding for event payload
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class DaemonBudget(ASTNode):
    """
    budget_per_event: {
        max_tokens: 5000
        max_time: 30s
        max_cost: 0.10
    }

    Linear logic resource envelope consumed per event cycle:
      Budget(n) ⊗ Event ⊸ Output ⊗ Budget(n-c)

    Unlike AgentBudget, there is no max_iterations — daemons are
    co-inductive (νX) and never terminate by iteration count.
    """
    max_tokens: int = 0          # 0 = unlimited
    max_time: str = ""           # duration string (e.g., "30s", "5m")
    max_cost: float = 0.0        # 0.0 = unlimited, in fractional currency


@dataclass
class DaemonDefinition(ASTNode):
    """
    daemon OrderProcessor(config: ServerConfig) -> OrderResult {
        goal: "Process incoming orders in real time"
        tools: [DBQuery, EmailSender]
        budget_per_event: { max_tokens: 5000, max_time: 30s, max_cost: 0.10 }
        memory: OrderMemory
        strategy: react
        on_stuck: hibernate
        shield: InputGuard

        listen "orders" as order_event {
            step Validate { ... }
            step Process { ... }
        }
        listen "cancellations" as cancel_event {
            step HandleCancel { ... }
        }
    }

    The **daemon** primitive — a co-inductive, perpetually reactive
    cognitive server grounded in π-calculus process theory.

    ╔══════════════════════════════════════════════════════════════╗
    ║  THEORETICAL FOUNDATIONS                                     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  π-Calculus (Milner, 1999):                                  ║
    ║    P ::= !c(x).Q — replicated listener (daemon model)       ║
    ║    The bang (!) makes the listener perpetual: after           ║
    ║    processing one event, the process replicates itself.      ║
    ║                                                              ║
    ║  Co-algebraic Semantics (greatest fixpoint νX):              ║
    ║    δ : S → S × E — daemon transition function                ║
    ║    Unlike flows (μX, least fixpoint = finite computation),   ║
    ║    daemons are νX (greatest fixpoint = infinite behaviour).  ║
    ║    The daemon never terminates — it observes and reacts.     ║
    ║                                                              ║
    ║  Linear Logic (Girard, 1987):                                ║
    ║    Budget(n) ⊗ Event ⊸ Output ⊗ Budget(n-c)                 ║
    ║    Each event cycle consumes resources from a per-event      ║
    ║    budget. Budget is replenished per cycle, not accumulated. ║
    ║                                                              ║
    ║  CPS Integration (hibernate):                                ║
    ║    Between events, the daemon auto-hibernates, serializing   ║
    ║    its cognitive state. On event arrival, it resumes,        ║
    ║    processes, and re-hibernates — the BDI agent recovers     ║
    ║    its full cognitive matrix each cycle.                     ║
    ║                                                              ║
    ║  OTP Supervision (Erlang, Armstrong 2003):                   ║
    ║    Crashed daemons are restarted by DaemonSupervisor with    ║
    ║    preserved global memory — "let it crash" philosophy.      ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

    Fields:
        name:             unique identifier for the daemon
        parameters:       typed configuration inputs
        return_type:      declared output type per event cycle
        goal:             natural-language objective (Davidson's pro-attitude)
        tools:            list of tool names available to the daemon
        budget_per_event: resource constraints per event cycle (linear logic)
        memory_ref:       reference to a declared memory {} block
        strategy:         deliberation strategy (react, reflexion, etc.)
        on_stuck:         recovery policy (hibernate, escalate, retry, forge)
        shield_ref:       reference to a declared shield
        listeners:        list of ListenBlock — the daemon's event channels
    """
    name: str = ""
    parameters: list[ParameterNode] = field(default_factory=list)
    return_type: TypeExprNode | None = None
    goal: str = ""
    tools: list[str] = field(default_factory=list)
    budget_per_event: DaemonBudget | None = None
    memory_ref: str = ""                   # reference to a memory {} block
    strategy: str = "react"                # react | reflexion | plan_and_execute | custom
    on_stuck: str = "hibernate"            # hibernate | escalate | retry | forge
    shield_ref: str = ""                   # reference to a declared shield
    listeners: list[ListenBlock] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  SHIELD NODES — compiler-level LLM security
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ShieldDefinition(ASTNode):
    """
    shield InputGuard {
        scan:     [prompt_injection, jailbreak, data_exfil, pii_leak]
        strategy: dual_llm
        quarantine: untrusted_input
        on_breach: halt
        severity: critical
    }

    shield ToolPolicy {
        allow: [WebSearch, Calculator]
        deny:  [CodeExecutor, FileWriter]
        sandbox: true
    }

    A **compiled security boundary** that the AXON compiler verifies
    and the runtime enforces.

    ╔══════════════════════════════════════════════════════════════╗
    ║  THEORETICAL FOUNDATIONS                                     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  Information Flow Control (Denning, 1976):                   ║
    ║    Trust Lattice (SC, →, ⊕):                                ║
    ║    Untrusted → Quarantined → Sanitized → Validated → Trusted ║
    ║    Legal flow: data may only flow UP the lattice.            ║
    ║                                                              ║
    ║  Noninterference (Goguen & Meseguer, 1982):                  ║
    ║    Untrusted variations cannot change Trusted execution.     ║
    ║    ∀ u,u' ∈ Untrusted : P(s|u) = P(s|u')                   ║
    ║                                                              ║
    ║  Taint Analysis:                                             ║
    ║    Source → Propagation → Sink                               ║
    ║    Vulnerability ≡ ∃ path from Source to Sink with no shield ║
    ║    Shield = type transformer: Untrusted → Sanitized          ║
    ║                                                              ║
    ║  Capability-Based Security (WASI/OCM):                       ║
    ║    Principle of Least Privilege — agents only access          ║
    ║    tools explicitly granted by their shield's allow list.    ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

    Shield operates at three levels:
      1. Input shields  — sanitize data before LLM context
      2. Output shields — validate LLM responses before consumption
      3. Capability shields — restrict tool access to declared permissions

    Strategies:
      pattern     — regex/heuristic scan (fast, low cost)
      classifier  — fine-tuned classifier model (Llama Guard style)
      dual_llm    — privileged/quarantined model architecture
      canary      — inject traceable tokens, detect if leaked
      perplexity  — statistical anomaly detection
      ensemble    — multiple strategies with majority voting

    Fields:
        name:                 shield identifier
        scan:                 list of threat categories to scan for
        strategy:             detection mechanism
        on_breach:            action on threat detection
        severity:             severity level for logging/alerting
        quarantine:           label for quarantined data
        max_retries:          retry count for sanitize_and_retry
        confidence_threshold: minimum confidence for pass decision
        allow_tools:          permitted tools (capability shield)
        deny_tools:           forbidden tools (capability shield)
        sandbox:              whether to sandbox tool execution
        redact:               PII fields to auto-redact before LLM
        log:                  logging directive
        deflect_message:      canned response for deflect on_breach
        budget:               optional resource constraints
    """
    name: str = ""
    scan: list[str] = field(default_factory=list)
    strategy: str = "pattern"          # pattern|classifier|dual_llm|canary|perplexity|ensemble
    on_breach: str = "halt"            # halt|sanitize_and_retry|escalate|quarantine|deflect
    severity: str = "critical"         # low|medium|high|critical
    quarantine: str = ""               # quarantine label
    max_retries: int = 0               # for sanitize_and_retry
    confidence_threshold: float | None = None
    allow_tools: list[str] = field(default_factory=list)
    deny_tools: list[str] = field(default_factory=list)
    sandbox: bool | None = None
    redact: list[str] = field(default_factory=list)
    log: str = ""                      # logging directive
    deflect_message: str = ""          # canned response for deflect
    budget: AgentBudget | None = None  # optional resource constraints
    taint: str = ""                    # EMCP: expected taint label
    compliance: list[str] = field(default_factory=list)  # ESK Fase 6.1 — regulatory coverage


@dataclass
class ShieldApplyNode(ASTNode):
    """
    shield InputGuard on user_input

    Applies a declared shield to a target expression within a flow step.
    This is the in-flow application point — the source → sink sanitizer.

    The compiler verifies that this node exists on every path from
    untrusted sources to trusted sinks (taint analysis).

    Fields:
        shield_name:   reference to a declared shield
        target:        expression/identifier to shield
        output_type:   optional explicit output type after shielding
    """
    shield_name: str = ""
    target: str = ""
    output_type: str = ""


# ═══════════════════════════════════════════════════════════════════
#  DATA SCIENCE NODES — the associative engine
# ═══════════════════════════════════════════════════════════════════

@dataclass
class DataSpaceDefinition(ASTNode):
    """
    dataspace SalesAnalysis { ... }

    Defines an in-memory associative data container.
    """
    name: str = ""
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class IngestNode(ASTNode):
    """
    ingest "sales.csv" into SalesData
    ingest SalesAPI into SalesData

    Loads external data into a DataSpace.
    Source can be a string literal (file path) or an identifier (variable/API).
    """
    source: str = ""       # file path string or identifier
    target: str = ""       # DataSpace identifier (after "into")


@dataclass
class FocusNode(ASTNode):
    """
    focus on Sales.Region == "LATAM"
    focus on Revenue > 1000

    Sets the selection context — filters the associative engine.
    """
    expression: str = ""   # the filtering expression


@dataclass
class AssociateNode(ASTNode):
    """
    associate Sales with Products
    associate Sales with Products using ProductID

    Explicitly links two tables/dataspaces.
    """
    left: str = ""         # first table/space identifier
    right: str = ""        # second table/space identifier (after "with")
    using_field: str = ""  # optional linking field (after "using")


@dataclass
class AggregateNode(ASTNode):
    """
    aggregate Revenue by Region
    aggregate Revenue by Region, Year as AnnualReport

    Performs summary reduction on data.
    """
    target: str = ""                            # column to aggregate
    group_by: list[str] = field(default_factory=list)  # grouping columns
    alias: str = ""                             # optional result name (after "as")


@dataclass
class ExploreNode(ASTNode):
    """
    explore SalesData
    explore SalesData limit 100

    Interactive data exploration/display.
    """
    target: str = ""       # DataSpace or table to explore
    limit: int | None = None  # optional row limit


# ═══════════════════════════════════════════════════════════════════
#  PIX NODES — Structured Cognitive Retrieval
# ═══════════════════════════════════════════════════════════════════

@dataclass
class PixDefinition(ASTNode):
    """
    pix ContractIndex {
        source: "contracts/master_agreement.pdf"
        depth: 4
        branching: 3
        model: fast
    }

    The **pix** primitive — structured cognitive retrieval via
    navigational semantics.

    ╔══════════════════════════════════════════════════════════════╗
    ║  THEORETICAL FOUNDATIONS                                     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  Document Tree: D = (N, E, ρ, κ)                            ║
    ║    Properties: acyclicity, exhaustive coverage,             ║
    ║    controlled disjunction between siblings.                 ║
    ║                                                              ║
    ║  Monotonic Entropy Reduction:                                ║
    ║    H(R|Q, n₁..nₜ) ≤ H(R|Q, n₁..nₜ₋₁)                    ║
    ║    Each navigation step reduces answer uncertainty.         ║
    ║                                                              ║
    ║  Bayesian Navigation:                                        ║
    ║    P(nᵢ relevant|Q, evidence) ∝                             ║
    ║      P(Q|nᵢ relevant) · P(nᵢ relevant|evidence)            ║
    ║                                                              ║
    ║  Information Foraging (Pirolli & Card, 1999):               ║
    ║    LLM follows information scent through summaries.         ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    name: str = ""
    source: str = ""
    depth: int = 4
    branching: int = 3
    model: str = "fast"
    effects: EffectRowNode | None = None  # optional effect declaration


@dataclass
class NavigateNode(ASTNode):
    """
    navigate ContractIndex with query: question
    trail: enabled

    LLM-guided tree traversal — the core PIX retrieval primitive.
    Produces a set of relevant leaf nodes and a reasoning path (trail).

    Epistemic level: output is always 'believe' (external I/O involved).
    """
    pix_name: str = ""         # reference to declared pix definition
    corpus_name: str = ""      # NEW: corpus reference (multi-doc mode, §5.3)
    query_expr: str = ""       # query expression (string or reference)
    trail_enabled: bool = False  # whether to record reasoning path
    output_name: str = ""      # named output
    budget_depth: int | None = None    # NEW: override budget max_depth
    budget_nodes: int | None = None    # NEW: override budget max_nodes
    edge_filter: list[str] = field(default_factory=list)  # NEW: relation type filter


@dataclass
class DrillNode(ASTNode):
    """
    drill ContractIndex into "Section3.Liabilities" with query: question

    Explicit descent into a named subtree — bypasses root navigation.
    Useful when the user knows which section is relevant.
    """
    pix_name: str = ""         # reference to declared pix definition
    subtree_path: str = ""     # node ID or title path to drill into
    query_expr: str = ""       # query expression
    output_name: str = ""      # named output


@dataclass
class TrailNode(ASTNode):
    """
    trail Navigate.reasoning_path

    Access the reasoning path — the explainability backbone.
    Every PIX retrieval produces a complete trace of navigational
    decisions, enabling 'why was this retrieved?' auditing.
    """
    navigate_ref: str = ""     # reference to a navigate step's output


# ═══════════════════════════════════════════════════════════════════
#  MDN NODES — Multi-Document Navigation (§5.3)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class CorpusDocEntry(ASTNode):
    """
    A document entry in a corpus definition.

    References a previously declared PIX index and annotates it
    with a document type and optional role within the corpus.
    """
    pix_ref: str = ""          # reference to declared pix definition
    doc_type: str = ""         # document classification (e.g., "Statute", "CaseLaw")
    role: str = ""             # optional role (e.g., "primary", "supporting")


@dataclass
class CorpusEdgeEntry(ASTNode):
    """
    An edge definition in a corpus — (source, target, relation_type).

    Represents a typed, directed edge: r ∈ R ⊆ D × D × L
    from Definition 1 (§2.1).
    """
    source_ref: str = ""       # source document identifier
    target_ref: str = ""       # target document identifier
    relation_type: str = ""    # edge label (e.g., "cite", "implement", "contradict")


@dataclass
class CorpusDefinition(ASTNode):
    """
    corpus LegalCorpus {
        documents: [statute_A, case_law_B, regulation_C]
        relationships: [
            (case_law_B, statute_A, cite)
            (regulation_C, statute_A, implement)
        ]
        weights: {
            (case_law_B, statute_A, cite): 0.9
        }
    }

    The **corpus** primitive — multi-document knowledge graph
    construction. Maps to C = (D, R, τ, ω, σ) from §2.1.

    ╔══════════════════════════════════════════════════════════════╗
    ║  FORMAL BASIS                                                ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  Definition 1 (§2.1): C = (D, R, τ, ω, σ)                  ║
    ║    D = finite set of documents                               ║
    ║    R ⊆ D × D × L = typed, directed edges                   ║
    ║    τ : R → L = edge type assignment                          ║
    ║    ω : R → (0, 1] = edge weight function                    ║
    ║    σ : D → R^m = summary embedding                          ║
    ║                                                              ║
    ║  Invariants G1–G4 enforced at build time.                    ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    name: str = ""
    documents: list[CorpusDocEntry] = field(default_factory=list)
    edges: list[CorpusEdgeEntry] = field(default_factory=list)
    weights: dict[str, float] = field(default_factory=dict)
    mcp_server: str = ""
    mcp_resource_uri: str = ""


@dataclass
class CorroborateNode(ASTNode):
    """
    corroborate nav_result as: verified_claims

    Cross-path verification — implements the Principle of Epistemic
    Corroboration from §4.2. Checks independent provenance paths
    for claim confirmation.

    Formal basis (Proposition 6, §4.1):
      C(D₀, φ, π) = ∏ᵢ ω(rᵢ) · EPR(D_last)
    """
    navigate_ref: str = ""     # reference to a navigate result
    output_name: str = ""      # named output for corroborated claims


# ═══════════════════════════════════════════════════════════════════
#  PSYCHE PRIMITIVE — Psychological-Epistemic Modeling (§PEM)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class PsycheDefinition(ASTNode):
    """
    psyche TherapeuticProfile {
        dimensions: [affect, cognitive_load, certainty, openness, trust]
        manifold: {
            curvature: { certainty: 0.8, trust: 0.9 }
            noise: 0.05
            momentum: 0.7
        }
        safety: [non_diagnostic, non_prescriptive]
        quantum: enabled
        inference: active
    }

    The **psyche** primitive — Psychological-Epistemic Modeling.

    Models mental states as epistemological objects with structured
    uncertainty, grounded in 4 mathematical pillars:

    ╔══════════════════════════════════════════════════════════════╗
    ║  §1  Riemannian Manifold — state dynamics with inertia      ║
    ║  §2  Density Operators — quantum cognitive probability       ║
    ║  §3  Active Inference — free energy minimization             ║
    ║  §4  Dependent Types — NonDiagnostic safety constraint       ║
    ╚══════════════════════════════════════════════════════════════╝

    Formal basis:
      ψ ∈ M  (cognitive state on Riemannian manifold)
      dψ_t = -∇U(ψ_t, I_t)dt + σ·dW_t  (SDE dynamics)
      P(D|ψ) = Tr(Π_D · ρ_ψ · Π_D)    (Born's rule projection)
      G(π,τ) = E_q[DKL[q||p] - ln p(o_τ|s_τ)]  (expected free energy)

    Safety invariant: ∀ output ∈ Results(q') : ¬IsClinicalDiagnosis(output)
    """
    name: str = ""
    dimensions: list[str] = field(default_factory=list)
    manifold_curvature: dict[str, float] = field(default_factory=dict)
    manifold_noise: float = 0.05
    manifold_momentum: float = 0.7
    safety_constraints: list[str] = field(default_factory=list)
    quantum_enabled: bool = False
    inference_mode: str = ""  # "active" | "passive" | ""


# ═══════════════════════════════════════════════════════════════════
#  MANDATE PRIMITIVE — Cybernetic Refinement Calculus (§CRC)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class MandateDefinition(ASTNode):
    """
    mandate StrictJSON {
        constraint: "Output must be valid JSON with keys: name, score, reasoning"
        kp: 10.0
        ki: 0.1
        kd: 0.05
        tolerance: 0.01
        max_steps: 50
        on_violation: coerce
    }

    The **mandate** primitive — Cybernetic Refinement Calculus.

    Operationalizes the CRC framework (paper_mandate.md) by embedding
    deterministic control of LLM outputs directly in the compiler.
    Unifies three mathematical pillars:

    ╔══════════════════════════════════════════════════════════════╗
    ║  Vía C — Refinement Type (Curry-Howard Isomorphism):        ║
    ║    T_M = { x ∈ Σ* | M(x) ⊢ ⊤ }                           ║
    ║    Γ ⊢ generate(prompt) : T_M                               ║
    ║    Inference: (Γ ⊢ e : Σ*)  ∧  (M(e) ⇓ ⊤)                 ║
    ║             ――――――――――――――――――――――――――――                    ║
    ║                  Γ ⊢ e : T_M                                ║
    ║                                                              ║
    ║  Vía A — Lyapunov Stability (PID Control):                   ║
    ║    u(t) = Kp·e(t) + Ki·∫e(τ)dτ + Kd·de/dt                  ║
    ║    V(e) = ½e²  →  V̇(e) ≈ -λe² < 0  (asymptotic conv.)     ║
    ║                                                              ║
    ║  Vía B — Thermodynamic Logit Bias:                           ║
    ║    ΔL_t collapses violating token probability mass           ║
    ║    before Softmax via negative logit injection.              ║
    ╚══════════════════════════════════════════════════════════════╝

    Theorem 1 (Convergence): Under Kp,Ki,Kd > 0 and
    L-Lipschitz error function, V̇(e) < 0 ∀ e ≠ 0,
    guaranteeing asymptotic convergence to mandate setpoint.
    """
    name: str = ""
    constraint: str = ""           # M(x) — the semantic constraint predicate
    kp: float = 10.0               # Kp — proportional gain
    ki: float = 0.1                # Ki — integral gain
    kd: float = 0.05               # Kd — derivative gain
    tolerance: float = 0.01        # convergence tolerance ε
    max_steps: int = 50            # max PID correction steps N
    on_violation: str = "coerce"   # policy: coerce | halt | retry


@dataclass
class MandateApplyNode(ASTNode):
    """
    mandate StrictJSON on llm_output
    mandate StrictJSON on raw_data -> ValidatedData

    Applies a declared mandate to constrain a target expression
    within a flow body. The compiler verifies the refinement type
    T_M at compile time, and the runtime applies PID control
    at inference time to enforce convergence.
    """
    mandate_name: str = ""
    target: str = ""
    output_type: str = ""


# ═══════════════════════════════════════════════════════════════════
#  LAMBDA DATA NODES — Epistemic State Vectors (§ΛD)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class LambdaDataDefinition(ASTNode):
    """
    lambda Currency {
        ontology: Measure
        certainty: 0.95
        temporal_frame: ["2024-01-01", "2024-12-31"]
        provenance: "exchange_api_v2"
        derivation: observed
    }

    Declares an Epistemic State Vector ψ = ⟨T, V, E⟩ where:
      T — Ontological type from the type universe O  (Invariant 1)
      V — Valid value domain (enforced at runtime)
      E = ⟨c, τ, ρ, δ⟩ — Epistemic tensor encoding:
          c — certainty scalar c ∈ [0,1]          (Invariant 4)
          τ — temporal validity frame
          ρ — provenance EntityRef (origin)
          δ — derivation ∈ Δ = {axiomatic, observed, inferred, mutated}

    ╔══════════════════════════════════════════════════════════════╗
    ║  Invariant 1 — Ontological Rigidity:                        ║
    ║    ∀ ψ = ⟨T, V, E⟩ : T ∈ O ∧ T ≠ ⊥                       ║
    ║                                                              ║
    ║  Invariant 2 — Semantic Interpretation:                      ║
    ║    V ∈ Domain(T) ⊂ Universe(O)                              ║
    ║                                                              ║
    ║  Invariant 3 — Semantic Conservation:                        ║
    ║    f(ψ) ≠ ⊥ ⟹ T(f(ψ)) ⊇ T(ψ) ∨ explicit_cast            ║
    ║                                                              ║
    ║  Invariant 4 — Epistemic Bounding:                           ║
    ║    c ∈ [0,1] ∧ |τ| ≥ 0 ∧ ρ ∈ EntityRef ∧ δ ∈ Δ            ║
    ╚══════════════════════════════════════════════════════════════╝

    Theorem 5.1 (Epistemic Degradation):
      For any transformation f operating on ΛD inputs,
        c_out ≤ min(c_in₁, c_in₂, …, c_inₙ)
      Output certainty cannot exceed the minimum input certainty.
      This is enforced at compile time for static compositions.
    """
    name: str = ""
    ontology: str = ""                     # T ∈ O — ontological type
    certainty: float = 1.0                 # c ∈ [0,1] — epistemic certainty scalar
    temporal_frame_start: str = ""         # τ_start — temporal validity window start
    temporal_frame_end: str = ""           # τ_end — temporal validity window end
    provenance: str = ""                   # ρ ∈ EntityRef — causal origin
    derivation: str = ""                   # δ ∈ Δ = {raw, derived, inferred, aggregated, transformed}


@dataclass
class LambdaDataApplyNode(ASTNode):
    """
    lambda Currency on raw_amount
    lambda Currency on raw_amount -> TypedAmount

    Applies a declared ΛD epistemic projection to a target expression
    within a flow body. This binds the epistemic state vector ψ to
    the data flowing through the pipeline, enabling the compiler to:

      1. Track certainty propagation (Theorem 5.1: Epistemic Degradation)
      2. Enforce ontological consistency (Invariant 1)
      3. Verify temporal validity windows (Invariant 4)
      4. Preserve provenance chains across transformations (Invariant 3)

    The resulting typed expression carries its full epistemic context,
    enabling the runtime to project to JSON (lossy) or maintain
    full ΛD fidelity internally.
    """
    lambda_data_name: str = ""             # reference to LambdaDataDefinition
    target: str = ""                       # expression to bind
    output_type: str = ""                  # result type after epistemic binding


# ═══════════════════════════════════════════════════════════════════
#  COMPUTE NODES — Deterministic Muscle Primitive (§CM)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ComputeDefinition(ASTNode):
    """
    compute CalculateTax {
        input: amount (Float), rate (Float)
        output: TaxResult
        shield: TypeSafety
        logic {
            let tax = amount * rate
            let total = amount + tax
            return { tax: tax, total: total }
        }
    }

    The **compute** primitive — deterministic "muscle" execution.

    ╔══════════════════════════════════════════════════════════════╗
    ║  THEORETICAL FOUNDATIONS                                     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║                                                              ║
    ║  Dual Process Theory (Kahneman):                             ║
    ║    System 1 — fast, automatic, deterministic.                ║
    ║    compute IS System 1 for the AXON cognitive architecture.  ║
    ║                                                              ║
    ║  Category Theory — Strict Monoidal Functor:                  ║
    ║    F: V → W  where F(f ∘ g) = F(f) ∘ F(g)                  ║
    ║    Deterministic, identity-preserving, composable.           ║
    ║                                                              ║
    ║  Linear Logic (Girard, 1987):                                ║
    ║    A ⊸ B — resources consumed exactly once.                  ║
    ║    Prevents double-free, guarantees termination.             ║
    ║                                                              ║
    ║  Curry-Howard Isomorphism:                                   ║
    ║    Types = Propositions, Programs = Proofs.                  ║
    ║    Shield acts as Theorem Prover — verified compute          ║
    ║    produces Proof-Carrying Code (0% hallucination).          ║
    ║                                                              ║
    ║  Enactive Cognition (Heidegger — Zuhandenheit):              ║
    ║    The agent does not "ask" an external service to compute;  ║
    ║    it "contracts" its own compiled tissue directly on CPU    ║
    ║    registers. The function IS the agent's muscle.            ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

    Execution path (Fast-Path — bypasses LLM entirely):
      1. DSL logic transpiled to Rust source
      2. Compiled to native shared library via rustc
      3. Loaded via CFFI (zero-copy on MEK buffers)
      4. Executed in nanoseconds on CPU registers
      5. Result returned as Latent Pointer to flow

    Fields:
        name:        unique identifier for the compute definition
        inputs:      typed input parameters (reuses ParameterNode)
        output_type: declared output type
        logic_body:  list of deterministic AST nodes (let, if, return)
        shield_ref:  optional shield for theorem-prover verification
    """
    name: str = ""
    inputs: list[ParameterNode] = field(default_factory=list)
    output_type: TypeExprNode | None = None
    logic_body: list[ASTNode] = field(default_factory=list)
    shield_ref: str = ""


@dataclass
class ComputeApplyNode(ASTNode):
    """
    compute CalculateTax on order.amount, 0.19 -> tax_result

    Applies a declared compute definition to target expressions
    within a flow body. This is the in-flow application point —
    the Fast-Path insertion where the executor bypasses the LLM
    and routes directly to the NativeComputeDispatcher.

    The compiler verifies that:
      1. The referenced compute definition exists
      2. Argument count matches input parameter count
      3. If shield_ref is set, types are theorem-proved

    Fields:
        compute_name:  reference to a declared compute definition
        arguments:     list of expressions to pass as inputs
        output_name:   optional binding name for the result
    """
    compute_name: str = ""
    arguments: list[str] = field(default_factory=list)
    output_name: str = ""


# ═══════════════════════════════════════════════════════════════════
#  EXECUTION NODE
# ═══════════════════════════════════════════════════════════════════

@dataclass
class RunStatement(ASTNode):
    """
    run AnalyzeContract(myContract.pdf)
      as ContractLawyer
      within LegalReview
      constrained_by [NoHallucination, StrictFactual, NoBias]
      on_failure: retry(backoff: exponential)
      output_to: "contract_report.json"
      effort: high

    The entry point — wires flow + persona + context + anchors.
    """
    flow_name: str = ""
    arguments: list[str] = field(default_factory=list)
    persona: str = ""  # as <Persona>
    context: str = ""  # within <Context>
    anchors: list[str] = field(default_factory=list)  # constrained_by [...]
    on_failure: str = ""  # log | retry(...) | escalate | raise <X>
    on_failure_params: dict[str, str] = field(default_factory=dict)
    output_to: str = ""  # output destination
    effort: str = ""  # low | medium | high | max


@dataclass
class AxonEndpointDefinition(ASTNode):
    """
    axonendpoint ContractsAPI {
        method: post
        path: "/v1/contracts/analyze"
        body: ContractInput
        execute: AnalyzeContract
        output: ContractReport
        shield: EdgeShield
        compliance: [HIPAA, PCI_DSS]
        retries: 2
        timeout: 10s
    }

    Declarative HTTP boundary primitive that binds transport ingress
    to a validated AXON flow execution target.

    The optional `compliance` field (ESK Fase 6.1) declares the
    regulatory classes handled by this boundary.  The type checker
    verifies that the endpoint's shield covers every declared class
    AND that the body/output types' compliance sets are covered.
    """
    name: str = ""
    method: str = "POST"
    path: str = ""
    body_type: str = ""
    execute_flow: str = ""
    output_type: str = ""
    shield_ref: str = ""
    retries: int = 0
    timeout: str = ""
    compliance: list[str] = field(default_factory=list)  # ESK Fase 6.1
    # §Fase 30 — HTTP transport for algebraic stream effects.
    # `transport` is the EFFECTIVE wire format the server uses to
    # materialise the response. Closed enum per D2 ratified 2026-05-10:
    #   - "json"   (default per D1) — application/json single response
    #   - "sse"    — text/event-stream Server-Sent Events single-shot
    #   - "ndjson" — application/x-ndjson namespace reserved; wire
    #                emission deferred to a future Fase (D2)
    # When `transport == "sse"`, the type-checker (30.c) verifies
    # that `execute_flow` produces a Stream<T> (D3).
    transport: str = "json"
    # §Fase 30 — Keepalive comment interval for SSE transport (D6).
    # Optional; defaults applied at runtime when transport == "sse".
    # Closed enum of accepted values: {"5s", "15s", "30s", "60s"}.
    # Empty string means "use runtime default" (15s).
    keepalive: str = ""
    # §Fase 31.b — Type-Driven Wire Inference (D1, D7).
    # `transport_explicit` is True if the source declared `transport:`
    # explicitly (any of json/sse/ndjson). False if the field was
    # omitted, in which case `transport` reflects the dataclass D1
    # default "json" but `implicit_transport` (computed by the
    # type-checker pass) carries the inferred value.
    transport_explicit: bool = False
    # §Fase 31.b — Inferred wire transport per D1:
    #   implicit_transport(E) =
    #     declared_transport(E)   if transport_explicit
    #     "sse"                    if produces_stream(execute_flow) ∧ ¬explicit
    #     "json"                   otherwise
    # Computed by `_implicit_transport` in type_checker.py and attached
    # to every AxonEndpointDefinition during the type-check pass.
    # Empty string "" before the type-checker runs (an AST consumed
    # without type-checking — e.g. raw parser output for tooling —
    # will see "" and must run the inference itself or fall back).
    # The Rust mirror sets the field byte-identically (D7).
    implicit_transport: str = ""
    # §Fase 32.g — Auth scope per axonendpoint (D8).
    # Optional list of capability slugs the request bearer must hold
    # for the endpoint to dispatch. Empty list means "no auth gate"
    # (D9 backwards-compat — existing axonendpoints without
    # `requires:` declarations keep current behaviour). Slug grammar
    # (closed): `^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$`. Examples:
    # `admin`, `legal.read`, `hipaa.phi.read`, `bank.officer.senior`.
    # The runtime checks declared_requires ⊆ token_capabilities (AND
    # semantics — every declared capability must be present). The
    # Rust mirror sets the field byte-identically (D11 cross-stack).
    requires_capabilities: list[str] = field(default_factory=list)
    # §Fase 32.h — Replay-token binding (D9 plan-vivo).
    # When True (the resolved default for POST/PUT, or explicitly
    # declared `replay: true` on any method), every successful 2xx
    # response is recorded in the runtime's axonendpoint replay log
    # keyed by trace_id. Auditors can later replay the exact request
    # via `GET /v1/replay/<trace_id>` and get the same response back
    # (deterministic backends only — temperature>0 LLM calls are
    # marked `non_deterministic` per the Replay-Status header).
    #
    # `replay_explicit` is True when the source declared `replay:`
    # explicitly. False when the field was omitted, in which case
    # `replay` reflects the method-default heuristic (POST/PUT →
    # True, GET/DELETE → False) computed at deploy-time.
    replay_explicit: bool = False
    replay: bool = False


# ═══════════════════════════════════════════════════════════════════
#  AXONSTORE PRIMITIVE — HoTT Transactional Persistence (§AS)
# ═══════════════════════════════════════════════════════════════════

@dataclass
class StoreColumnNode(ASTNode):
    """
    id: integer primary_key auto_increment
    name: text not_null
    balance: decimal default 0.00

    A single column in an ``axonstore`` schema.

    HoTT interpretation: each column is a fiber in the dependent
    type family  Σ(c : ColName). ColType(c) , where constraints
    (primary_key, not_null, unique) restrict the fiber's
    inhabitants.
    """
    col_name: str = ""
    col_type: str = ""                                # integer | text | decimal | timestamp | boolean
    primary_key: bool = False
    auto_increment: bool = False
    not_null: bool = False
    unique: bool = False
    default_value: str = ""                           # literal default value


@dataclass
class StoreSchemaNode(ASTNode):
    """
    schema {
        id: integer primary_key auto_increment
        name: text not_null
        email: text unique not_null
    }

    The schema sub-block inside an ``axonstore`` definition.

    HoTT interpretation: the schema is a **product type**
    (record type) whose univalence path to the DB schema
    must be constructible for any CRUD operation to be valid:

      (AxonType ≃ DBSchema) ≃ (AxonType = DBSchema)
    """
    columns: list[StoreColumnNode] = field(default_factory=list)


@dataclass
class AxonStoreDefinition(ASTNode):
    """
    axonstore Users {
        backend: sqlite
        connection: "env:DATABASE_URL"
        schema { ... }
        confidence_floor: 0.92
        isolation: serializable
        on_breach: rollback
    }

    The **axonstore** primitive — HoTT Transactional Persistence.

    Acts as a transducer between the Open World Assumption (OWA)
    of LLMs and the Closed World Assumption (CWA) of relational
    databases.  Formal pillars:

    ╔══════════════════════════════════════════════════════════════╗
    ║  §1  HoTT Univalence — schema isomorphism verification      ║
    ║  §2  Linear Logic    — single-use transaction tokens (⊸)    ║
    ║  §3  Design by Contract — anchor-based ACID invariants      ║
    ╚══════════════════════════════════════════════════════════════╝

    Axiom of Univalence:
      (A ≃ B) ≃ (A = B)
      If the compiler can construct a homotopy path between
      the cognitive type (B) and the DB schema (A), any
      validated operation is mathematically correct.

    Linear Logic (A ⊸ B):
      Each transaction consumes a unique ephemeral token.
      No duplication (no hallucinatory re-inserts).
      No weakening (no silently dropped COMMITs).
    """
    name: str = ""
    backend: str = "sqlite"                    # sqlite | postgresql | mysql
    connection: str = ""                       # connection string or env ref
    schema: StoreSchemaNode | None = None
    confidence_floor: float = 0.9              # HoTT epistemic threshold
    isolation: str = "serializable"            # read_committed | repeatable_read | serializable
    on_breach: str = "rollback"                # rollback | raise | log


@dataclass
class PersistNode(ASTNode):
    """
    persist into Users {
        name: "John Doe"
        email: "john@example.com"
    }

    INSERT operation under Linear Logic ⊗ guarantees.
    Consumes a write token — cannot be duplicated.
    """
    store_name: str = ""                       # target axonstore
    fields: dict[str, str] = field(default_factory=dict)


@dataclass
class RetrieveNode(ASTNode):
    """
    retrieve from Users where "email == 'john@example.com'" as result

    SELECT/QUERY with optional filter and result binding.
    """
    store_name: str = ""
    where_expr: str = ""                       # filter expression
    alias: str = ""                            # result binding name


@dataclass
class MutateNode(ASTNode):
    """
    mutate Users where "id == 1" {
        balance: 150.00
    }

    UPDATE operation — atomic mutation under ACID isolation.
    """
    store_name: str = ""
    where_expr: str = ""
    fields: dict[str, str] = field(default_factory=dict)


@dataclass
class PurgeNode(ASTNode):
    """
    purge from Users where "status == 'inactive'"

    DELETE operation — controlled purge with mandatory filter.
    """
    store_name: str = ""
    where_expr: str = ""


@dataclass
class TransactNode(ASTNode):
    """
    transact {
        persist into Users { name: "Alice" }
        mutate Accounts where "id == 1" { balance: 500.00 }
    }

    Transaction block — Linear Logic implication (A ⊸ B).
    Generates a single-use ephemeral token.  All operations
    within the block share the token; on failure, rollback
    consumes the token and reverts all mutations.
    """
    body: list[ASTNode] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  I/O COGNITIVO PRIMITIVES — Cálculo Lambda Lineal Epistémico (λ-L-E)
#  (Plan: docs/plan_io_cognitivo.md · Fase 1)
#
#  Four cognitive I/O primitives that model infrastructure as
#  linear/affine resources with epistemic state:
#
#    resource  — an affine/linear infrastructure token
#                (A, !A, A ⊸ B under Girard's Linear Logic)
#    fabric    — a tagged substrate / namespace (region, zones)
#                (topological container for resources)
#    manifest  — a declarative belief about desired shape
#                (refinement spec, not imperative state)
#    observe   — a quorum-gated observation with lag τ
#                (Fagin-Halpern common knowledge `Cφ` aggregation)
#
#  The primitives return a pure Intention Tree (Free Monad); a
#  Handler interprets it (Fase 2).  Separation Logic disjointness
#  and affine-type linearity are enforced at compile-time.
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ResourceDefinition(ASTNode):
    """
    resource DatabasePool {
        kind: postgres
        endpoint: "db.internal:5432"
        capacity: 100
        lifetime: linear
        certainty_floor: 0.85
        shield: DBShield
    }

    An infrastructure resource declared as a linear, affine, or
    persistent token.  Linear/affine resources cannot be aliased
    across manifests (Separation Logic `*` disjointness).
    """
    name: str = ""
    kind: str = ""                       # postgres | redis | s3 | vpc | gpu | compute | custom
    endpoint: str = ""                   # connection URI
    capacity: int | None = None          # hint for pool size / instance count
    lifetime: str = "affine"             # linear | affine | persistent
    certainty_floor: float | None = None # epistemic gate c ∈ [0.0, 1.0]
    shield_ref: str = ""                 # optional shield reference


@dataclass
class FabricDefinition(ASTNode):
    """
    fabric AWS_VPC {
        provider: aws
        region: "us-east-1"
        zones: 3
        ephemeral: true
        shield: NetworkShield
    }

    A tagged substrate — the topological container where
    resources are provisioned. Maps to VPC / cluster / namespace.
    """
    name: str = ""
    provider: str = ""                   # aws | gcp | azure | kubernetes | bare_metal | custom
    region: str = ""                     # provider-specific region id
    zones: int | None = None             # number of availability zones
    ephemeral: bool | None = None        # true = destroy on program end
    shield_ref: str = ""                 # optional shield reference


@dataclass
class ManifestDefinition(ASTNode):
    """
    manifest ProductionCluster {
        resources: [DatabasePool, RedisCache]
        fabric: AWS_VPC
        region: "us-east-1"
        zones: 3
        compliance: [HIPAA, PCI_DSS]
    }

    A declarative specification of desired shape.  Not a "desired
    state" in the Terraform sense — a *belief* about structure.
    Resources listed here must be disjoint (no aliasing); linear
    and affine resources can belong to only one manifest.
    """
    name: str = ""
    resources: list[str] = field(default_factory=list)   # references to ResourceDefinition names
    fabric_ref: str = ""                                 # reference to FabricDefinition name
    region: str = ""
    zones: int | None = None
    compliance: list[str] = field(default_factory=list)  # κ — regulatory class (Fase 6.1)


@dataclass
class ObserveDefinition(ASTNode):
    """
    observe ClusterState from ProductionCluster {
        sources: [prometheus, cloudwatch, healthcheck]
        quorum: 2
        timeout: 5s
        on_partition: fail
        certainty_floor: 0.90
    }

    A quorum-gated observation of a manifest's real state.  Each
    output carries ΛD envelope E = ⟨c, τ, ρ, δ⟩; `τ` records the
    observation lag explicitly.  `on_partition: fail` raises a
    CT-3 (Network Error) — partitions are ⊥ void, not `doubt`.
    """
    name: str = ""
    target: str = ""                     # name of ManifestDefinition being observed
    sources: list[str] = field(default_factory=list)
    quorum: int | None = None            # Byzantine quorum threshold (default: len(sources))
    timeout: str = ""                    # duration literal "5s", "100ms", etc.
    on_partition: str = "fail"           # fail (CT-3) | shield_quarantine
    certainty_floor: float | None = None


# ═══════════════════════════════════════════════════════════════════
#  CONTROL COGNITIVO PRIMITIVES — Fase 3 of the λ-L-E calculus
#  (Plan: docs/plan_io_cognitivo.md)
#
#  Three control-layer primitives that close the Active Inference loop:
#
#    reconcile — free-energy-minimizing control loop that closes the
#                gap between a manifest (belief) and an observe
#                (evidence), gated by shield + epistemic threshold
#    lease     — affine/linear resource token with explicit τ-decay,
#                raising CT-2 Anchor Breach on post-expiry access
#    ensemble  — Byzantine quorum aggregator that fuses multiple
#                observations into a single `Cφ` common-knowledge
#                outcome
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ReconcileDefinition(ASTNode):
    """
    reconcile ProductionReconciler {
        observe: ClusterHealth
        threshold: 0.85
        tolerance: 0.10
        on_drift: provision
        shield: ReconcileShield
        mandate: ClusterPid
        max_retries: 3
    }

    A cognitive control loop over a manifest/observe pair.  Each tick
    consumes the latest observation, computes a drift metric against
    the manifest's belief, and — if certainty > threshold AND drift >
    tolerance AND shield approves — triggers `on_drift`.

    Formally: the loop minimizes variational free energy
        F = D_KL(q(s) || p(s, o))
    where `q(s)` is the manifest's belief and `p(s, o)` is the joint
    distribution evidenced by `observe`.  Acting on the environment
    (provision) is one of the two classical routes to reducing F, the
    other being belief revision (`refine`).
    """
    name: str = ""
    observe_ref: str = ""
    threshold: float | None = None       # epistemic gate [0.0, 1.0]
    tolerance: float | None = None       # drift tolerance [0.0, 1.0]
    on_drift: str = "provision"          # provision | alert | refine
    shield_ref: str = ""
    mandate_ref: str = ""
    max_retries: int = 3


@dataclass
class LeaseDefinition(ASTNode):
    """
    lease DbWriteLease {
        resource: PrimaryDatabase
        duration: 30s
        acquire: on_start
        on_expire: anchor_breach
    }

    An affine/linear lease on a resource, with an explicit Δt window
    encoded in the `τ` of the ΛD envelope.  The runtime LeaseKernel
    materializes each lease as a revocable token; use post-expiry
    raises `LeaseExpiredError` (CT-2) per decision D2.
    """
    name: str = ""
    resource_ref: str = ""
    duration: str = ""                   # duration literal "30s", "5m", "2h"
    acquire: str = "on_start"            # on_start | on_demand
    on_expire: str = "anchor_breach"     # anchor_breach | release | extend


@dataclass
class EnsembleDefinition(ASTNode):
    """
    ensemble ClusterTruth {
        observations: [ClusterProm, ClusterCW, ClusterHC]
        quorum: 2
        aggregation: majority
        certainty_mode: min
    }

    A Byzantine quorum aggregator over >=2 independent observations.
    Computes common knowledge `Cφ` (Fagin-Halpern) when at least
    `quorum` observers agree.  Failed/partitioned observations are
    excluded; if fewer than `quorum` outcomes remain, the ensemble
    raises a CT-3 structural failure.
    """
    name: str = ""
    observations: list[str] = field(default_factory=list)
    quorum: int | None = None
    aggregation: str = "majority"        # majority | weighted | byzantine
    certainty_mode: str = "min"          # min | weighted | harmonic


# ═══════════════════════════════════════════════════════════════════
#  TOPOLOGY & SESSION TYPES — Fase 4 of the λ-L-E calculus
#  (Plan: docs/plan_io_cognitivo.md)
#
#  A topology is a typed directed graph over already-declared Axon
#  entities (resources, fabrics, manifests, observes, axonendpoints,
#  daemons, agents, axonstores).  Each edge carries a `session`
#  reference: a binary protocol descriptor in the style of
#  Honda-Vasconcelos-Yoshida session types.
#
#  Compile-time guarantees (Fase 4 acceptance criterion):
#    1. Duality   — the two roles of every session are dual: zipped
#                   pairwise, every (send T, receive T) opposes a
#                   (receive T, send T), and loop/end positions match.
#    2. Closure   — every node referenced in `nodes` is a declared
#                   entity; every edge endpoint is in `nodes`; every
#                   `session_ref` resolves to a SessionDefinition.
#    3. Liveness  — directed cycles whose every edge is `receive`-first
#                   are flagged as static deadlocks.  Cycles that
#                   contain at least one `send`-first edge are
#                   liveness-preserving and pass.
# ═══════════════════════════════════════════════════════════════════

@dataclass
class SessionStep(ASTNode):
    """
    A single primitive in a session protocol:

        send T      — emit a message of type T
        receive T   — block-await a message of type T
        loop        — branch back to the protocol's first step
        end         — terminate the session

    Steps are ordered; a role's protocol is a flat list of steps.
    """
    op: str = ""              # "send" | "receive" | "loop" | "end"
    message_type: str = ""    # only meaningful for send / receive


@dataclass
class SessionRole(ASTNode):
    """
    One side of a binary session — name + ordered list of steps.

        client: [send Query, receive Result, end]
    """
    name: str = ""
    steps: list[SessionStep] = field(default_factory=list)


@dataclass
class SessionDefinition(ASTNode):
    """
    session DbSession {
        client: [send Query, receive Result, end]
        server: [receive Query, send Result, end]
    }

    A binary session type — exactly two roles whose protocols MUST be
    pairwise dual.  Duality is verified by the type checker, so any
    program that uses a non-dual session is rejected at compile time.
    """
    name: str = ""
    roles: list[SessionRole] = field(default_factory=list)


@dataclass
class TopologyEdge(ASTNode):
    """
    A directed, session-typed edge between two nodes:

        AppServer -> PrimaryDb : DbSession

    The source plays the FIRST role of the session; the target plays
    the SECOND role.  Convention is fixed so that an Axon program
    has a single, unambiguous protocol assignment per edge.
    """
    source: str = ""
    target: str = ""
    session_ref: str = ""


@dataclass
class TopologyDefinition(ASTNode):
    """
    topology ProductionTopology {
        nodes: [PrimaryDb, AppServer, ContractsAPI, OrdersDaemon]
        edges: [
            AppServer -> PrimaryDb : DbSession,
            ContractsAPI -> AppServer : RequestSession,
            OrdersDaemon -> AppServer : OrderEventStream
        ]
    }

    A typed directed graph over Axon entities.  Edges carry session
    references whose duality the type checker enforces, and the
    overall graph is statically analyzed for liveness deadlocks.
    """
    name: str = ""
    nodes: list[str] = field(default_factory=list)
    edges: list[TopologyEdge] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════
#  COGNITIVE IMMUNE SYSTEM — Fase 5 of the λ-L-E calculus
#  (Formalization: docs/paper_inmune.md — Jerne + Friston FEP)
#
#  Three composable primitives that form Axon's active defense layer:
#
#    immune — anomaly detector via KL divergence + Free Energy Principle.
#             Emits a HealthReport (ΛD envelope) but takes no action.
#             Reuses the `psyche` FEP solver (per paper §3.3).
#    reflex — deterministic, O(1), LLM-free motor response.
#             Fires when the HealthReport crosses an epistemic threshold
#             (know / believe / speculate / doubt).
#    heal   — Linear Logic one-shot patch synthesis.  Three compliance
#             modes: audit_only / human_in_loop / adversarial (paper §7).
#
#  MANDATORY `scope` — per paper §8.2, the compiler REJECTS any immune,
#  reflex, or heal without an explicit `scope` declaration.  No implicit
#  `global` default exists; blast radius must be a conscious decision.
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ImmuneDefinition(ASTNode):
    """
    immune AppVigilante {
        watch: [network_traffic, sql_queries, auth_logs]
        sensitivity: 0.9
        baseline: learned
        window: 200
        scope: tenant
        tau: 300s
        decay: exponential
    }

    A continuous anomaly sensor over a declared observation vector.
    Computes D_KL(q_baseline || p_observed) per paper §3.2 and emits
    a HealthReport with an epistemic level derived from the KL magnitude
    (paper §5.2 lattice: [0,0.3)→know, [0.3,0.6)→believe,
    [0.6,0.9)→speculate, [0.9,1.0]→doubt).

    IMPORTANT: `immune` takes NO action — it is a pure sensor.  Action
    is delegated to `reflex` and `heal` which consume its HealthReport.
    """
    name: str = ""
    watch: list[str] = field(default_factory=list)   # observe / ensemble / any ref names
    sensitivity: float | None = None                 # [0.0, 1.0]
    baseline: str = "learned"                        # "learned" or name of a prior
    window: int = 100                                # samples used to estimate baseline
    scope: str = ""                                  # tenant | flow | global (MANDATORY)
    tau: str = ""                                    # duration half-life
    decay: str = "exponential"                       # exponential | linear | none


@dataclass
class ReflexDefinition(ASTNode):
    """
    reflex TerminateConnection {
        trigger: AppVigilante
        on_level: doubt
        action: drop
        scope: tenant
        sla: 1ms
    }

    Deterministic, O(1) motor response that fires when a referenced
    `immune` sensor's HealthReport reaches the declared epistemic level.
    Contract invariants (per paper §4.2):
      • never invokes an LLM
      • no long-running blocking I/O
      • every activation emits a signed_trace
      • idempotent — same HealthReport ⇒ same effect, no duplication
    """
    name: str = ""
    trigger: str = ""                                 # immune name
    on_level: str = "doubt"                           # know | believe | speculate | doubt
    action: str = ""                                  # drop | revoke | emit | redact | quarantine | terminate | alert
    scope: str = ""                                   # MANDATORY
    sla: str = ""                                     # duration budget, e.g. "1ms"


@dataclass
class HealDefinition(ASTNode):
    """
    heal ZeroDayPatcher {
        source: AppVigilante
        on_level: doubt
        mode: human_in_loop
        scope: tenant
        review_sla: 24h
        shield: HealShield
        max_patches: 3
    }

    Linear-Logic one-shot patch synthesis.  Per paper §6 the patch has
    type !Synthesized ⊸ Applied ⊸ Collapsed — each transition consumes
    its predecessor, guaranteeing single application and forced collapse.

    Three compliance modes (paper §7) control the level of automation:
      audit_only     — patches synthesized but NEVER applied
      human_in_loop  — default; requires explicit human approval
      adversarial    — autonomous application (opt-in, risk-accepted)
    """
    name: str = ""
    source: str = ""                                  # immune name (MANDATORY)
    on_level: str = "doubt"                           # know | believe | speculate | doubt
    mode: str = "human_in_loop"                       # audit_only | human_in_loop | adversarial
    scope: str = ""                                   # MANDATORY
    review_sla: str = ""                              # duration
    shield_ref: str = ""                              # optional shield gate
    max_patches: int = 3                              # bounded heal attempts


# ═══════════════════════════════════════════════════════════════════
#  UI COGNITIVA — Fase 9 of the λ-L-E calculus
#  (Plan: docs/plan_io_cognitivo.md Fase 9)
#
#  A component renders a declared Axon type. If the type carries κ
#  (regulatory class), the component MUST declare a `via_shield` that
#  covers that κ — the type-checker rejects unshielded regulated
#  renders at compile time. Events route to declared flows with the
#  signature enforced against the component's render type.
# ═══════════════════════════════════════════════════════════════════


@dataclass
class ComponentDefinition(ASTNode):
    """
    component PatientCard {
        renders:     PatientRecord
        via_shield:  PHIShield
        on_interact: SummarizeRecord
        render_hint: card          # card | list | form | chart | custom
    }

    A reusable UI fragment. `renders` is the data type the component
    visualizes; if that type has κ, `via_shield` is mandatory and its
    compliance set MUST cover the type's κ (compile-time enforcement).
    `on_interact` is optional: when present, it must be a flow whose
    first parameter type matches `renders`.
    """
    name: str = ""
    renders: str = ""                  # type name this component visualizes
    via_shield: str = ""               # shield that gates user input + redacts output
    on_interact: str = ""              # optional flow triggered by user interaction
    render_hint: str = "custom"        # card | list | form | chart | custom


@dataclass
class ViewDefinition(ASTNode):
    """
    view PatientDashboard {
        title:      "Patient Dashboard"
        components: [PatientCard, TrialList]
        route:      "/patients"
    }

    A top-level screen. `components` is an ordered list of declared
    `component` names composed in the view's primary layout. `route`
    is an optional URL path; the renderer wires this into the
    browser/desktop app shell.
    """
    name: str = ""
    title: str = ""
    components: list[str] = field(default_factory=list)
    route: str = ""


# ═══════════════════════════════════════════════════════════════════
#  MOBILE TYPED CHANNELS — Fase 13 of the λ-L-E calculus
#  (Formalization: docs/paper_mobile_channels.md)
#
#  Lifts Axon channels from runtime-routed strings (listen "topic")
#  to first-class affine resources typed as Channel<τ, q, ℓ, π>.
#  Handles are passable as values (π-calculus mobility, Milner 1991)
#  and exposable via capability-gated publish/discover (ESK shield).
#
#  Compile-time guarantees (paper §3 + Theorem 6.1):
#    1. Affinity   — no handle is duplicated; drop is permitted (D1).
#    2. Mobility   — Channel<τ> is a first-class value; passing it
#                    through another channel preserves affinity (D2).
#    3. Schema     — emit/listen operations verify producer-consumer
#                    type agreement at compile time (D3).
#    4. Capability — publish requires a shield whose compliance
#                    list ⊇ κ(τ); without shield, publish is a
#                    compile error (D8).
#    5. Second-order sessions — a session step over Channel<τ> is
#                    dual iff its carried-type steps are dual (D6.d).
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ChannelDefinition(ASTNode):
    """
    channel OrdersCreated {
        message: Order                  # schema type (TypeDefinition name)
        qos: at_least_once              # AMO | ALO | EO | broadcast | queue
        lifetime: affine                # linear | affine | persistent
        persistence: ephemeral          # ephemeral | persistent_axonstore
        shield: PublicBroker            # optional: required for publish (D8)
    }

    A typed event channel as an affine resource.  Holders of a
    `Channel<message_type>` handle may emit, receive, publish (gated),
    or persist the handle; affinity prevents aliasing across concurrent
    consumers without explicit duplication through a broadcast QoS.

    The `message` field is the static type carried by the channel — a
    reference to a TypeDefinition (existing `type` keyword) or a nested
    `Channel<...>` for second-order mobility (paper §3.3).  Nested
    channel types are stored in `message` as the verbatim source text
    (e.g. "Channel<Order>") and resolved by the type checker in 13.b.
    """
    name: str = ""
    message: str = ""                    # type name or "Channel<T>" (second-order)
    qos: str = "at_least_once"           # at_most_once | at_least_once | exactly_once | broadcast | queue
    lifetime: str = "affine"             # linear | affine | persistent (D1 default: affine)
    persistence: str = "ephemeral"       # ephemeral | persistent_axonstore (D3 default)
    shield_ref: str = ""                 # optional σ-shield for publish gating (D8)


@dataclass
class EmitStatement(ASTNode):
    """
    emit OrdersCreated(order_payload)
    emit BrokerHandoff(OrdersCreated)         # (Chan-Mobility) — channel as value

    Output prefix in the π-calculus sense: `c⟨v⟩.P`.  The channel
    reference `c` is a declared ChannelDefinition name; the value
    expression `v` is either a term of the channel's message type or
    — under mobility — a Channel<τ> handle for which v's type must
    match the outer channel's declared message.

    Affinity is enforced by the type checker (13.b): after `emit c(v)`,
    the handle `v` is consumed in the current scope if `v` itself is
    a channel reference.
    """
    channel_ref: str = ""                # name of the ChannelDefinition receiving the value
    value_ref: str = ""                  # identifier of the value (message or channel handle)


@dataclass
class PublishStatement(ASTNode):
    """
    publish OrdersCreated within PublicBroker

    Capability extrusion (Milner–Parrow–Walker 1992, paper §4.3).
    Exposes the handle to a dynamic discovery surface materialized
    by the named shield.  Compile-time requirements (paper §3.4, D8):

      • `PublicBroker` must be a ShieldDefinition in scope.
      • Shield.compliance ⊇ κ(channel.message_type).
      • The caller's certainty envelope is attenuated by δ_pub (default
        0.05 per hop) — recorded by the runtime, not visible in AST.

    Without `within <Shield>`, publish is a compile error.
    """
    channel_ref: str = ""                # name of the ChannelDefinition being published
    shield_ref: str = ""                 # name of the σ-shield gating the extrusion


@dataclass
class DiscoverStatement(ASTNode):
    """
    discover OrdersCreated as orders_ch

    Dual of `publish` — imports a handle previously extruded through
    a shield.  The alias `orders_ch` binds the received handle in the
    local scope with the schema of the originating ChannelDefinition.
    Post-discover, the handle is affine: exactly one of `emit orders_ch(…)`
    / further mobility / drop is permitted.
    """
    capability_ref: str = ""             # name of the published channel (ChannelDefinition)
    alias: str = ""                      # local binding introduced


# ═══════════════════════════════════════════════════════════════════
#  ALGEBRAIC EFFECTS — Fase 23
#  (Operationalises paper docs/algebraic_effects_streaming.md §1-§6)
#
#  Plotkin/Pretnar handlers + one-shot delimited continuations as
#  first-class language citizens. Surface syntax is Koka-shape:
#  `effect`, `perform`, `handle ... in ...`, `resume`, `abort`, `forward`.
#
#  Decisions ratified 2026-05-08 (founder criterion: born mature,
#  30-year vision, 100% Rust + C destiny, mathematical purity per paper):
#    D1  — Effect operations are polymorphic in their type parameters
#          (`Send<T>(value: T) -> Unit`). Typechecker monomorphises at perform site.
#    D2  — One-shot continuations only (multi-resume = type error). Aligns
#          with linear logic; permits Rust state-machine without continuation cloning.
#    D3  — Handler scope delimited via `in` block — preserves referential
#          transparency local + decidable inference.
#    D6  — Rust-only runtime — Python frontend compiles to IR, axon-rs executes.
#    D8  — `stream<τ>` desugars internally to `handle _StreamBuiltin<T> { ... } in { ... }`
#          (backward compat 100% — adopters' source unchanged).
#    D9  — Perform without enclosing handle = compile error (no runtime fallback).
#    D10 — Linear-resume discipline typechecker-enforced (control-flow walk).
#    D11 — Effect row polymorphism via row variables in step type signatures
#          (`step compose(...) -> ... !ε`). Open vs closed rows distinguished.
#    D12 — `forward` keyword for transparent effect propagation to outer handler.
# ═══════════════════════════════════════════════════════════════════


@dataclass
class EffectOperation(ASTNode):
    """
    A single operation declared inside an `effect` block.

      Emit(token: Token) -> Unit
      Send<T>(value: T) -> Unit          # D1: operation polymorphism
      Done() -> Never
      Recv<T>() -> T

    `type_parameters` is the list of operation-scoped type variables
    (Koka-style rank-1 polymorphism, D1). Empty for monomorphic ops.
    `parameters` is the parameter list (may be empty). `return_type`
    is the result type returned to the resumed continuation; for
    `Done() -> Never` the return type is the bottom type, semantically
    encoding "this operation never resumes" (handler must `abort` or
    not call `resume`).
    """
    name: str = ""
    type_parameters: list[str] = field(default_factory=list)  # D1 — operation polymorphism
    parameters: list[ParameterNode] = field(default_factory=list)
    return_type: TypeExprNode | None = None


@dataclass
class EffectDeclaration(ASTNode):
    """
    Top-level effect declaration.

        effect SSE {
            Emit(token: Token) -> Unit
            Done() -> Never
        }

        effect Channel {
            Send<T>(value: T) -> Unit          # D1
            Recv<T>() -> T
        }

    An effect is a typed signature of operations a step can `perform`.
    Until discharged by an enclosing `handle SSE { ... } in { ... }`,
    the effect remains in the step's effect row (visible at type level).
    Reaching the top-level `run` with a non-empty effect row is a
    compile error (D9 — exhaustiveness).
    """
    name: str = ""
    operations: list[EffectOperation] = field(default_factory=list)


@dataclass
class PerformExpression(ASTNode):
    """
    perform SSE.Emit(token)
    perform Channel.Send(payload)
    let result = perform Channel.Recv()        # binds the resumed value

    Invokes an effect operation. The current continuation is captured
    (one-shot, D2) and yielded to the enclosing handler. When the
    handler invokes `resume(value)`, the continuation resumes here with
    `value` as the result of the perform expression.

    `arguments` are stored as raw expression strings (consistent with
    existing AXON convention for argument lists in `run`, `use`,
    `emit`, etc.). The typechecker resolves them to typed expressions
    in 23.c.
    """
    effect_name: str = ""
    operation_name: str = ""
    arguments: list[str] = field(default_factory=list)


@dataclass
class HandlerClause(ASTNode):
    """
    A single clause inside a `handle` block.

        Emit(token) -> { log.info(token); resume() }
        Done() -> { abort }
        Send(value) -> {
            buffer.append(value)
            resume()
        }

    `parameters` are the operation parameters bound by this clause
    (matching the operation's parameter list). `body` is the list of
    AST nodes (steps / statements) executed when the operation fires.
    The continuation is implicitly available in scope; the body must
    invoke either `resume(value)` (continue) exactly once on each path
    (D10 — linear discipline) or `abort` (terminate). Failure to do
    either is a compile error (effect operations must be discharged).
    """
    operation_name: str = ""
    parameters: list[ParameterNode] = field(default_factory=list)
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class HandleExpression(ASTNode):
    """
    handle SSE {
        Emit(token) -> { ... resume() }
        Done() -> { abort }
    } in {
        body containing perform SSE.Emit(...)
    }

    Multi-effect handlers are a comma list:

        handle SSE, ToolCall {
            Emit(t) -> { ... }
            Call(name, args) -> { ... }
        } in { body }

    Discharges every operation of every named effect within the body.
    After this expression the named effects no longer appear in the
    surrounding scope's effect row.
    """
    effect_names: list[str] = field(default_factory=list)  # one or more (handle SSE, ToolCall { ... })
    clauses: list[HandlerClause] = field(default_factory=list)
    body: list[ASTNode] = field(default_factory=list)


@dataclass
class ResumeStatement(ASTNode):
    """
    resume               # resume the captured continuation with Unit
    resume(value)        # resume with `value` injected at the perform site

    One-shot only (D2). The typechecker enforces that within each
    handler clause body, on every control-flow path, exactly one of
    `resume(...)` or `abort(...)` appears (D10 — linear discipline).
    Multi-resume on the same path is a compile error.
    """
    value_expr: str = ""  # raw expression text; empty for bare `resume`


@dataclass
class AbortStatement(ASTNode):
    """
    abort               # terminate the handle expression with Unit
    abort(value)        # terminate with `value` as the handle expression's result

    Discards the captured continuation entirely (the perform site
    never resumes) and yields control past the enclosing `handle ... in`
    block. Counts toward the linear-resume discipline (D10) — a
    handler clause that aborts on every path is well-typed.
    """
    value_expr: str = ""


@dataclass
class ForwardExpression(ASTNode):
    """
    forward SSE.Emit(token)

    Propagates the operation to the *next* enclosing handler frame
    (delegate / pass-through). Useful for transparent decorators —
    a handler that logs / traces / metricates without intercepting:

        handle SSE {
            Emit(t) -> { log.info(t); forward Emit(t) }
            Done() -> { log.info("done"); forward Done() }
        } in { body }

    Counts as a discharge for linear-resume purposes (D10): control
    leaves this handler frame and the outer frame becomes responsible
    for resuming the continuation.

    D12 — without `forward`, handlers are strict (intercept-only). With
    `forward`, they compose middleware-style.
    """
    effect_name: str = ""
    operation_name: str = ""
    arguments: list[str] = field(default_factory=list)


@dataclass
class AlgebraicEffectRowNode(ASTNode):
    """
    A type-level effect annotation attached to a TypeExprNode.

        Token!{SSE}                          # closed row, single effect
        Token!{SSE, ToolCall}                # closed row, multiple effects
        Token!{SSE, ε}                       # open row with row variable ε (D11)
        Token!{}                             # explicit empty row (pure)

    Open rows (those with a row variable) are how Fase 23 supports
    effect polymorphism: `step compose(f: A -> B!ε, g: B -> C!ε) -> A -> C!ε`
    works because `ε` unifies with whatever effects the caller's
    context happens to need.

    Distinct from the legacy `EffectRowNode`, which carries categorical
    effect classes (`io`, `network`) + epistemic level for tool
    declarations. The two are orthogonal — declared algebraic effects
    are typed handles (`SSE`, `ToolCall`); legacy effect rows are taint
    classifications. They may coexist on the same step in v1.17.0+.
    """
    effect_names: list[str] = field(default_factory=list)
    row_variable: str = ""  # empty = closed row; non-empty (e.g. "ε") = open row
