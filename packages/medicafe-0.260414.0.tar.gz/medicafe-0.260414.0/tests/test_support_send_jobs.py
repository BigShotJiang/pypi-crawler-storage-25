#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _wait_worker_quiet(manager, rounds=80, delay_sec=0.02):
    for _ in range(int(max(1, rounds))):
        thread = getattr(manager, '_worker_thread', None)
        if thread is None or not thread.is_alive():
            return
        time.sleep(delay_sec)


class TestSupportSendQueuePolicy(unittest.TestCase):

    def test_dedup_key_includes_anchor_context_and_issue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy(dedup_ttl_sec=60)
        key = policy.dedup_key({
            'send_type': 'run_evidence',
            'anchor_run_id': 'a1',
            'context_run_id': 'c1',
            'issue_code': 'x1',
            'source_scope_hash': 'h1',
        })
        self.assertEqual(key, 'run_evidence|a1|c1|x1|h1')


class TestSupportSendJobManager(unittest.TestCase):

    def test_enqueue_accepts_even_if_legacy_async_env_is_off(self):
        """MEDICAFE_SUPPORT_SEND_ASYNC is obsolete; queue is always used for supported types."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_ASYNC': '0',
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-legacy',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                self.assertNotEqual(str(res.get('policy_decision', '')), 'sync_fallback')
                _wait_worker_quiet(mgr)

    def test_enqueue_deduplicates_recent_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                # Give worker a brief moment to persist running/terminal state.
                time.sleep(0.05)
                second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                _wait_worker_quiet(mgr)

    def test_blocked_job_is_requeued_when_single_flight_busy(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                # Simulate post-dequeue state where picked job id was removed.
                mgr._write_queue_state([])
                mgr._acquire_single_flight = lambda _job_id: False
                mgr._run_single_job(job)
                refreshed = mgr._read_job(job_id)
                queue_state = mgr._read_queue_state()
                self.assertEqual(str(refreshed.get('status', '')), 'blocked')
                self.assertIn(job_id, queue_state.get('queued_job_ids', []))

    def test_retry_preserves_source_scope_hash_for_dedup_key(self):
        from MediCafe.support_send_jobs import SupportSendJobManager, SupportSendQueuePolicy
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')
                first_job = mgr._read_job(first_job_id)
                first_job['created_epoch'] = float(time.time()) - 3600.0
                mgr._write_job(first_job)

                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                retried_id = str(retried.get('job_id', '') or '')
                self.assertTrue(retried_id and retried_id != first_job_id)
                retried_job = mgr._read_job(retried_id)
                self.assertEqual(str(retried_job.get('source_scope_hash', '') or ''), 'scope-1')
                expected = SupportSendQueuePolicy().dedup_key({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                })
                self.assertEqual(str(retried_job.get('dedup_key', '') or ''), expected)
                _wait_worker_quiet(mgr)


class TestFrozenRecommendationRunEvidence(unittest.TestCase):

    def test_run_evidence_send_skips_recompute_when_frozen_recommendation_provided(self):
        from MediCafe import cloud_readiness_recommendations as rec_mod
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            triage_path = os.path.join(reports_dir, 'artifact_triage_pack_test.txt')
            index_path = os.path.join(reports_dir, 'run_artifact_index_test.txt')
            bundle_path = os.path.join(reports_dir, 'support_bundle_test.zip')
            for p in (triage_path, index_path, bundle_path):
                with open(p, 'w') as h:
                    h.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab_root,
                'reports_dir': reports_dir,
                'run_id': '20260410-011341-b73de336',
                'artifact_files': [],
                'context_files': [],
            }
            frozen = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': '20260410-011341-b73de336',
                'action_preview': {'anchor_run_id': '20260410-011341-b73de336'},
            }
            with patch.object(rec_mod, 'collect_support_bundle', return_value=bundle_path, create=True), \
                    patch.object(rec_mod, 'submit_support_bundle_email', return_value=True, create=True), \
                    patch.object(rec_mod, '_build_run_artifact_snapshot', return_value=(True, '', snapshot), create=True), \
                    patch.object(rec_mod, '_artifact_bundle_quality', return_value={
                        'score': 100, 'label': 'GREEN', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'ready'
                    }, create=True), \
                    patch.object(rec_mod, '_write_artifact_triage_pack', return_value=triage_path, create=True), \
                    patch.object(rec_mod, '_write_run_artifact_index', return_value=index_path, create=True), \
                    patch.object(rec_mod, 'open_report_delivery_status', return_value=(False, '', ''), create=True), \
                    patch.object(rec_mod, '_collect_run_evidence_context_attachment', return_value=('', {}), create=True), \
                    patch.object(rec_mod, '_phase_d_dat_smoke_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(rec_mod, '_review_dat_qa_full_block_forced_attachment_paths', return_value=[], create=True), \
                    patch.object(rec_mod, '_phase_d_reprocess_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(rec_mod, '_latest_interrupt_report_paths', return_value=[], create=True), \
                    patch.object(rec_mod, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {}), create=True), \
                    patch.object(rec_mod, 'compute_operator_support_send_recommendation_core') as mock_compute:
                ok, msg, data = rec_mod.send_latest_run_evidence_bundle(
                    repo,
                    frozen_recommendation=frozen,
                )
            mock_compute.assert_not_called()
            self.assertTrue(isinstance(ok, bool))
            self.assertTrue(isinstance(msg, str))

