﻿#!/usr/bin/env python
"""
Run-centric cloud artifact tooling.

This module keeps run-id discovery/index/triage builders separate from
cloud_readiness.py orchestration wrappers.
"""
from __future__ import print_function

import json
import os
import re
import time


ARTIFACT_PHASE_LAYOUT = (
    {
        'code': 'B',
        'name': 'Discovery',
        'required': (
            {'label': 'summary', 'prefix': 'artifact_discovery_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'manifest', 'prefix': 'artifact_manifest_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'C',
        'name': 'Ingest',
        'required': (
            {'label': 'summary', 'prefix': 'ingest_write_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'anomalies', 'prefix': 'ingest_write_anomalies_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'D',
        'name': 'QA',
        'required': (
            {'label': 'summary', 'prefix': 'qa_canonical_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'reject_samples', 'prefix': 'qa_reject_samples_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'E',
        'name': 'Projection',
        'required': (
            {'label': 'summary', 'prefix': 'projection_parity_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'deviation_samples', 'prefix': 'projection_deviation_samples_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'F',
        'name': 'Shadow Health',
        'required': (
            {'label': 'shadow_report', 'prefix': 'shadow_run_report_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'evidence_index', 'prefix': 'shadow_evidence_index_', 'suffixes': ('.json',)},
            {'label': 'mismatch', 'prefix': 'phase_f_mismatch_', 'suffixes': ('.txt',)},
        ),
    },
)


def append_unique_path(paths, seen, path):
    if not path:
        return
    try:
        norm = os.path.normcase(os.path.abspath(path))
    except Exception:
        norm = str(path)
    if norm in seen:
        return
    seen.add(norm)
    paths.append(path)


def safe_run_token(run_id):
    token = str(run_id or '').strip()
    if not token:
        return 'unknown'
    return re.sub(r'[^A-Za-z0-9._-]+', '_', token)


def ensure_operator_unblock_auto_ack(recommendation):
    """
    Keep live operator-unblock fields coherent after auto-ack style suppression.

    Some callers clear top-level `reply_required_for_unblock` after an embedded
    auto-ack path, but may still carry stale `live_operator_unblock.reply_required=True`
    from the original live diagnostics snapshot. Downstream formatters prefer
    `live_operator_unblock`, so normalize the payload here to avoid showing a
    manual-reply requirement that has already been auto-satisfied.
    """
    rec = recommendation if isinstance(recommendation, dict) else {}
    if not rec:
        return {}
    lou = rec.get('live_operator_unblock') if isinstance(rec.get('live_operator_unblock'), dict) else {}
    if not lou:
        return rec
    issue_code = str(lou.get('reply_required_issue_code', '') or '').strip()
    issue_key = str(lou.get('reply_required_issue_key', '') or '').strip()
    top_reply_required = bool(rec.get('reply_required_for_unblock'))
    if (not top_reply_required) and issue_code == 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT':
        lou['reply_required'] = False
        lou['deprecation_active'] = True
        if not str(lou.get('closure_mode', '') or '').strip():
            lou['closure_mode'] = 'embedded_auto_closure'
        if not str(rec.get('reply_required_issue_code', '') or '').strip():
            rec['reply_required_issue_code'] = issue_code
        if not str(rec.get('reply_required_issue_key', '') or '').strip():
            rec['reply_required_issue_key'] = issue_key
        rec['live_operator_unblock'] = lou
    return rec


def format_recommended_action_lines(recommendation, title='Recommended Next Action:'):
    """Render a compact recommendation block for runbook-style text reports."""
    rec = ensure_operator_unblock_auto_ack(recommendation)
    if not rec:
        return []
    preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
    lines = [title]
    lines.append(' - recommended_action_kind={0}'.format(str(rec.get('recommended_action_kind', '') or 'send_bundle')))
    lines.append(' - preferred_when_stable_action_kind={0}'.format(str(rec.get('preferred_when_stable_action_kind', '') or '-')))
    lines.append(' - best_now_action_kind={0}'.format(str(rec.get('best_now_action_kind', '') or '-')))
    lines.append(' - recommended_report_kind={0}'.format(str(rec.get('recommended_report_kind', '') or '-')))
    lines.append(' - operator_primary_report_surface={0}'.format(recommendation_operator_report_surface(rec)))
    lines.append(' - follow_recommendation_now={0}'.format(recommendation_followthrough_now(rec)))
    lines.append(' - follow_recommendation_when_stable={0}'.format(recommendation_followthrough_when_stable(rec)))
    rss = str(rec.get('recommendation_source_scope', '') or '').strip()
    if rss:
        lines.append(' - recommendation_source_scope={0}'.format(rss))
    ar = str(rec.get('recommendation_anchor_run_id', '') or '').strip()
    if ar:
        lines.append(' - recommendation_anchor_run_id={0}'.format(ar))
    lr = str(rec.get('recommendation_live_run_id', '') or '').strip()
    if lr:
        lines.append(' - recommendation_live_run_id={0}'.format(lr))
    lrs = str(rec.get('recommendation_live_run_status', '') or '').strip()
    if lrs:
        lines.append(' - recommendation_live_run_status={0}'.format(lrs))
    classes = rec.get('recommended_artifact_classes', []) if isinstance(rec.get('recommended_artifact_classes', []), list) else []
    lines.append(' - targeted_artifact_classes={0}'.format(','.join([str(item) for item in classes if str(item or '').strip()]) or '-'))
    lines.append(' - action_requires_confirmation={0}'.format(bool(rec.get('action_requires_confirmation'))))
    qa_fb_kind = str(rec.get('recommended_action_kind', '') or '').strip() == 'review_dat_qa_full_block'
    if qa_fb_kind:
        lines.append(' - operator_followthrough=send_anchored_run_evidence_bundle')
        lines.append(' - operator_manual_review_required=False')
    mv = str(rec.get('milestone_verdict', '') or '').strip()
    smv = str(rec.get('strict_milestone_verdict', '') or '').strip()
    mr = str(rec.get('milestone_reason', '') or '').strip()
    amr = str(rec.get('anchored_milestone_run_id', '') or '').strip()
    if mv or smv or mr or amr:
        lines.append('Milestone verdict (anchored shadow payload):')
        lines.append(' - milestone_verdict={0}'.format(mv or '-'))
        lines.append(' - strict_milestone_verdict={0}'.format(smv or '-'))
        lines.append(' - milestone_reason={0}'.format(mr or '-'))
        lines.append(' - anchored_milestone_run_id={0}'.format(amr or '-'))
    lines.append('Operator unblock (live alert / diagnostics):')
    lou = rec.get('live_operator_unblock') if isinstance(rec.get('live_operator_unblock'), dict) else {}
    if lou:
        dep = bool(lou.get('deprecation_active'))
        cm = str(lou.get('closure_mode', '') or '').strip()
        rr = bool(lou.get('reply_required'))
        if rec.get('reply_required_for_unblock') is False or dep or cm == 'embedded_auto_closure':
            rr = False
        lines.append(' - reply_required={0}'.format(rr))
        if rr:
            lines.append(' - reply_required_for_unblock=True')
        lines.append(' - deprecation_active={0}'.format(dep))
        if cm:
            lines.append(' - closure_mode={0}'.format(cm))
        lk = str(lou.get('reply_required_issue_key', '') or '').strip()
        lc = str(lou.get('reply_required_issue_code', '') or '').strip()
        if lk:
            lines.append(' - reply_required_issue_key={0}'.format(lk))
        if lc:
            lines.append(' - reply_required_issue_code={0}'.format(lc))
        closure_tasks = lou.get('closure_tasks', []) if isinstance(lou.get('closure_tasks', []), list) else []
        if closure_tasks:
            lines.append(' - closure_tasks={0}'.format(','.join([str(item) for item in closure_tasks if str(item or '').strip()])))
    else:
        rr = bool(rec.get('reply_required_for_unblock'))
        lines.append(' - reply_required={0}'.format(rr))
        if rr:
            lines.append(' - reply_required_for_unblock=True')
        code = str(rec.get('reply_required_issue_code', '') or '').strip()
        key = str(rec.get('reply_required_issue_key', '') or '').strip()
        if code:
            lines.append(' - reply_required_issue_code={0}'.format(code))
        if key:
            lines.append(' - reply_required_issue_key={0}'.format(key))
    qa_fb_kind = str(rec.get('recommended_action_kind', '') or '').strip() == 'review_dat_qa_full_block'
    step2 = rec.get('step2_run_coherence') if isinstance(rec.get('step2_run_coherence'), dict) else {}
    if step2:
        lines.append('Step 2 run coherence telemetry:')
        lines.append(' - alignment_ok={0}'.format(bool(step2.get('alignment_ok'))))
        lines.append(' - alignment_note={0}'.format(str(step2.get('alignment_note', '') or '-')))
        lines.append(' - required_artifacts_present={0}'.format(bool(step2.get('required_artifacts_present'))))
        lines.append(' - coherence_blocked={0}'.format(bool(step2.get('coherence_blocked'))))
        lines.append(' - lineage_issue_count={0}'.format(int(step2.get('lineage_issue_count', 0) or 0)))
        lines.append(' - shadow_run_report_path={0}'.format(str(step2.get('shadow_run_report_path', '') or '-')))
        lines.append(' - shadow_evidence_index_path={0}'.format(str(step2.get('shadow_evidence_index_path', '') or '-')))
        lines.append(' - phase_d_summary_path={0}'.format(str(step2.get('phase_d_summary_path', '') or '-')))
        lines.append(' - expected_phase_d_run_id={0}'.format(str(step2.get('expected_phase_d_run_id', '') or '-')))
        lines.append(' - observed_phase_d_run_id={0}'.format(str(step2.get('observed_phase_d_run_id', '') or '-')))
        lines.append(' - phase_d_run_id_match={0}'.format(bool(step2.get('phase_d_run_id_match'))))
    if qa_fb_kind:
        lines.append('QA full-block review provenance:')
        lines.append(' - anchored_diagnosis_source={0}'.format(str(preview.get('anchored_diagnosis_source', '') or '-')))
        lines.append(' - smoke_source_accepted={0}'.format(bool(preview.get('smoke_source_accepted'))))
        lines.append(' - ignored_smoke_mismatch={0}'.format(bool(preview.get('ignored_smoke_mismatch'))))
        sak = str(preview.get('smoke_anchor_run_id', '') or '').strip()
        if sak:
            lines.append(' - smoke_anchor_run_id={0}'.format(sak))
        smn = str(preview.get('source_mismatch_note', '') or '').strip()
        if smn:
            lines.append(' - source_mismatch_note={0}'.format(smn))
    hist_kind = str(rec.get('recommended_action_kind', '') or '') == 'historical_phase_d_reprocess'
    dat_smoke_kind = str(rec.get('recommended_action_kind', '') or '') == 'phase_d_dat_smoke'
    hist_eval = bool(rec.get('historical_reprocess_evaluated'))
    hist_available = bool(rec.get('historical_reprocess_available'))
    dat_eval = bool(rec.get('dat_smoke_evaluated'))
    dat_available = bool(rec.get('dat_smoke_available'))
    follow_on_kind = str(rec.get('follow_on_action_kind', '') or '').strip()
    if follow_on_kind:
        lines.append(' - follow_on_action_kind={0}'.format(follow_on_kind))
        lines.append(' - follow_on_report_kind={0}'.format(str(rec.get('follow_on_report_kind', '') or '-')))
        lines.append(' - follow_on_requires_confirmation={0}'.format(bool(rec.get('follow_on_requires_confirmation'))))
        follow_on_classes = rec.get('follow_on_artifact_classes', []) if isinstance(rec.get('follow_on_artifact_classes', []), list) else []
        lines.append(' - follow_on_artifact_classes={0}'.format(','.join([str(item) for item in follow_on_classes if str(item or '').strip()]) or '-'))
    if hist_eval or hist_available or hist_kind:
        lines.append('Historical reprocess telemetry:')
        lines.append(' - historical_reprocess_evaluated={0}'.format(hist_eval))
        lines.append(' - historical_reprocess_available={0}'.format(hist_available))
    if hist_kind:
        lines.append(' - latest_phase_c_inserted_count={0}'.format(int(preview.get('latest_phase_c_inserted_count', 0) or 0)))
        lines.append(' - latest_phase_c_skipped_count={0}'.format(int(preview.get('latest_phase_c_skipped_count', 0) or 0)))
        lines.append(' - latest_phase_d_rows_selected={0}'.format(int(preview.get('latest_phase_d_rows_selected', 0) or 0)))
        lines.append(' - latest_phase_d_pass_count={0}'.format(int(preview.get('latest_phase_d_pass_count', 0) or 0)))
        lines.append(' - latest_phase_d_reject_count={0}'.format(int(preview.get('latest_phase_d_reject_count', 0) or 0)))
    tqv = preview.get('targeted_qa_versions', [])
    if hist_kind and isinstance(tqv, list) and tqv:
        lines.append(' - targeted_qa_versions={0}'.format(','.join(str(x) for x in tqv if str(x or '').strip())))
    reject_counts = preview.get('historical_reject_counts_by_class', {}) if isinstance(preview.get('historical_reject_counts_by_class', {}), dict) else {}
    items = []
    for key, value in reject_counts.items():
        try:
            value_i = int(value or 0)
        except Exception:
            value_i = 0
        if value_i > 0:
            items.append((str(key), value_i))
    items.sort(key=lambda item: (-item[1], item[0]))
    if hist_kind:
        if items:
            lines.append(' - historical_reject_counts_by_class={0}'.format(','.join('{0}:{1}'.format(key, value) for key, value in items)))
        else:
            lines.append(' - historical_reject_counts_by_class=none')
    by_ver = preview.get('historical_reject_counts_by_version', {})
    if hist_kind and isinstance(by_ver, dict) and by_ver:
        ver_items = []
        for key, value in by_ver.items():
            try:
                vi = int(value or 0)
            except Exception:
                vi = 0
            if vi > 0:
                ver_items.append((str(key), vi))
        ver_items.sort(key=lambda item: (-item[1], item[0]))
        if ver_items:
            lines.append(' - historical_reject_counts_by_version={0}'.format(
                ','.join('{0}:{1}'.format(k, v) for k, v in ver_items)))
    hprev = str(rec.get('historical_reprocess_preview_path', '') or '').strip()
    if hprev:
        lines.append(' - historical_reprocess_preview_path={0}'.format(hprev))
    skip = str(rec.get('historical_reprocess_not_triggered_reason', '') or '').strip()
    if skip and hist_eval and not hist_kind:
        lines.append(' - historical_reprocess_not_triggered_reason={0}'.format(skip))
    dat_skip = str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip()
    dat_state_path = str(rec.get('dat_smoke_state_path', '') or '').strip()
    dat_last_status = str(rec.get('dat_smoke_last_status', '') or '').strip()
    dat_last_report = str(rec.get('dat_smoke_last_report_path', '') or '').strip()
    dat_last_assessment = str(rec.get('dat_smoke_last_assessment', '') or '').strip()
    dat_cooldown = str(rec.get('dat_smoke_cooldown_until_utc', '') or '').strip()
    dat_deferred_path = str(rec.get('dat_smoke_deferred_path', '') or '').strip()
    dat_deferred_reason = str(rec.get('dat_smoke_deferred_reason', '') or '').strip()
    dat_deferred_anchor = str(rec.get('dat_smoke_deferred_anchor_run_id', '') or '').strip()
    dat_deferred_context = str(rec.get('dat_smoke_deferred_context_run_id', '') or '').strip()
    dat_deferred_issue = str(rec.get('dat_smoke_deferred_issue_code', '') or '').strip()
    if dat_eval or dat_available or dat_smoke_kind or dat_last_status or dat_deferred_path:
        lines.append('DAT smoke telemetry:')
        lines.append(' - dat_smoke_evaluated={0}'.format(dat_eval))
        lines.append(' - dat_smoke_available={0}'.format(dat_available))
        if dat_skip and not dat_smoke_kind:
            lines.append(' - dat_smoke_not_triggered_reason={0}'.format(dat_skip))
        if dat_state_path:
            lines.append(' - dat_smoke_state_path={0}'.format(dat_state_path))
        if dat_last_status:
            lines.append(' - dat_smoke_last_status={0}'.format(dat_last_status))
        if dat_last_report:
            lines.append(' - dat_smoke_last_report_path={0}'.format(dat_last_report))
        if dat_last_assessment:
            lines.append(' - dat_smoke_last_assessment={0}'.format(dat_last_assessment))
        if dat_cooldown:
            lines.append(' - dat_smoke_cooldown_until_utc={0}'.format(dat_cooldown))
        if dat_deferred_path:
            lines.append(' - dat_smoke_deferred_path={0}'.format(dat_deferred_path))
        if dat_deferred_reason:
            lines.append(' - dat_smoke_deferred_reason={0}'.format(dat_deferred_reason))
        if dat_deferred_anchor:
            lines.append(' - dat_smoke_deferred_anchor_run_id={0}'.format(dat_deferred_anchor))
        if dat_deferred_context:
            lines.append(' - dat_smoke_deferred_context_run_id={0}'.format(dat_deferred_context))
        if dat_deferred_issue:
            lines.append(' - dat_smoke_deferred_issue_code={0}'.format(dat_deferred_issue))
    if dat_smoke_kind:
        lines.append(' - dat_smoke_anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
        lines.append(' - dat_smoke_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')))
        lines.append(' - dat_smoke_issue_code={0}'.format(str(preview.get('remediation_issue_code', '') or '-')))
        lines.append(' - dat_smoke_expected_report_path={0}'.format(str(preview.get('expected_report_path', '') or '-')))
        lines.append(' - dat_smoke_reports_dir={0}'.format(str(preview.get('smoke_reports_dir', '') or '-')))
        lines.append(' - dat_smoke_reference_phase_d_summary_path={0}'.format(
            str(preview.get('reference_phase_d_summary_path', '') or '-')))
    pdr = rec.get('phase_d_remediation') if isinstance(rec.get('phase_d_remediation'), dict) else {}
    if pdr:
        lines.append(' - phase_d_remediation_version={0}'.format(int(pdr.get('version', 0) or 0)))
        for surf in format_phase_d_remediation_surfaces(pdr):
            lines.append(' - {0}'.format(surf))
    for item in rec.get('action_reason_lines', []) or []:
        msg = str(item or '').strip()
        if msg:
            lines.append(' - reason: {0}'.format(msg))
    return lines


def recommended_action_kind(recommended_action):
    rec = recommended_action if isinstance(recommended_action, dict) else {}
    return str(rec.get('recommended_action_kind', '') or '').strip()


def ready_triage_actions(recommended_action):
    kind = recommended_action_kind(recommended_action)
    if kind == 'review_dat_qa_full_block':
        primary = (
            'Use Follow recommendation to send the anchored run evidence bundle; QA summary, '
            'reject samples, shadow report, and closure context are auto-attached for this '
            'DAT QA full-block lane.'
        )
    elif kind == 'send_bundle':
        primary = (
            'Use Follow recommendation to send the latest run evidence bundle; the triage pack '
            'already captures the runbook interpretation for this run.'
        )
    elif kind == 'historical_phase_d_reprocess':
        primary = (
            'Use Follow recommendation to open the historical Phase D reprocess preview/action; '
            'do not stop in raw artifact files to decide what happens next.'
        )
    elif kind == 'phase_d_dat_smoke':
        primary = (
            'Use Follow recommendation to open the DAT smoke path; do not stop in raw artifact '
            'files to decide what happens next.'
        )
    elif kind:
        primary = (
            'Use Follow recommendation to execute the recommended next step; the operator should '
            'not decide what happens next from raw artifact files.'
        )
    else:
        primary = (
            'Use the recommended next action shown above; the operator should not decide what '
            'happens next from raw artifact files.'
        )
    return [
        primary,
        'Open run artifact index only if developer/support asks for file-level verification or specific file paths.',
    ]


def ready_index_actions(recommended_action):
    kind = recommended_action_kind(recommended_action)
    if kind:
        primary = (
            'This run has required artifacts across B..F; the triage pack and Follow recommendation '
            'are the primary operator surfaces.'
        )
    else:
        primary = 'This run has required artifacts across B..F; the triage pack is the primary operator surface.'
    return [
        primary,
        'Use this index only if developer/support asks for file-level verification or specific file paths.',
    ]

def _send_followthrough_label(send_type):
    st = str(send_type or '').strip()
    if st == 'system_health':
        return 'send_system_health_pack'
    return 'send_run_evidence_bundle'


def recommendation_operator_report_surface(recommended_action):
    rec = recommended_action if isinstance(recommended_action, dict) else {}
    report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
    if report_kind in ('artifact_triage_pack', 'system_health_pack'):
        return report_kind
    preferred_send = str(rec.get('preferred_when_stable', '') or rec.get('primary_send', '') or '').strip()
    if preferred_send == 'system_health':
        return 'system_health_pack'
    return 'artifact_triage_pack'


def _followthrough_from_action(action_kind, send_type):
    kind = str(action_kind or '').strip()
    if kind == 'review_dat_qa_full_block':
        return 'send_anchored_run_evidence_bundle'
    if kind == 'historical_phase_d_reprocess':
        return 'run_historical_phase_d_reprocess'
    if kind == 'phase_d_dat_smoke':
        return 'run_phase_d_dat_smoke'
    if kind == 'wait_for_stable':
        return 'defer_until_idle'
    return _send_followthrough_label(send_type)


def recommendation_followthrough_now(recommended_action):
    rec = recommended_action if isinstance(recommended_action, dict) else {}
    preferred_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
    best_now_action = str(rec.get('best_now_action_kind', '') or preferred_action or 'send_bundle').strip()
    best_now_send = str(rec.get('best_now_send', '') or rec.get('preferred_when_stable', '') or rec.get('primary_send', '') or 'system_health').strip()
    if best_now_send not in ('run_evidence', 'system_health'):
        best_now_send = 'system_health'
    if bool(rec.get('pipeline_running')) and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
        return 'defer_until_idle'
    return _followthrough_from_action(best_now_action or preferred_action or 'send_bundle', best_now_send)


def recommendation_followthrough_when_stable(recommended_action):
    rec = recommended_action if isinstance(recommended_action, dict) else {}
    preferred_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
    preferred_send = str(rec.get('preferred_when_stable', '') or rec.get('primary_send', '') or 'system_health').strip()
    if preferred_send not in ('run_evidence', 'system_health'):
        preferred_send = 'system_health'
    return _followthrough_from_action(preferred_action or 'send_bundle', preferred_send)

def _default_load_json_dict(path):
    """Fallback when build_run_artifact_snapshot is called without load_json_dict_fn (matches cloud_readiness _load_json_dict)."""
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _default_resolve_lab_root(repo_root):
    """Fallback lab path when resolve_lab_root_fn is omitted (common test/repo layout)."""
    return os.path.join(str(repo_root), 'lab')


def _default_reports_dir_access_error(_lab_root):
    """No injected access check => treat reports dir as accessible."""
    return ''


def _default_pipeline_not_running(_lab_root):
    """No injected pipeline probe => assume not running."""
    return False


def compute_run_id_alignment(run_id, active_run_id, last_shadow_pipeline_run_id):
    """How snapshot run_id relates to diagnostics active / last-completed pipeline run."""
    run_id = str(run_id or '').strip()
    active_run_id = str(active_run_id or '').strip()
    last_rid = str(last_shadow_pipeline_run_id or '').strip()
    if active_run_id and run_id == active_run_id:
        return 'active'
    if last_rid and run_id == last_rid:
        return 'last_completed'
    if active_run_id or last_rid:
        return 'mismatch'
    return 'none'


def build_minimal_snapshot_for_coherence(lab_root, run_id):
    """
    Minimal snapshot dict for artifact_snapshot_coherence_blocked using only lab_root on disk.
    Aligns backlog / resolver predicates with recommendation paths that require coherent run alignment.
    """
    lab_root = str(lab_root or '').strip()
    rid = str(run_id or '').strip()
    if not lab_root or not rid:
        return {}
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    state = _default_load_json_dict(state_path)
    if not isinstance(state, dict):
        state = {}
    return {'run_id': rid, 'diagnostics_state': state}


def format_phase_d_remediation_surfaces(rem):
    """
    DRY lines for verification_target, verification_scope, and milestone vs DAT-lane distinction.
    Returns a list of strings suitable for why_lines / runbook blocks.
    """
    rem = rem if isinstance(rem, dict) else {}
    lines = []
    vt = str(rem.get('verification_target', '') or '').strip()
    vs = str(rem.get('verification_scope', '') or '').strip()
    mer = rem.get('milestone_exit_ready')
    if vt:
        lines.append('phase_d_remediation: verification_target={0}'.format(vt))
    if vs:
        lines.append('phase_d_remediation: verification_scope={0}'.format(vs))
    if mer is not None:
        lines.append('phase_d_remediation: milestone_exit_ready={0}'.format(bool(mer)))
    ic = str(rem.get('issue_code', '') or '').strip()
    st = str(rem.get('status', '') or '').strip()
    crid = str(rem.get('context_run_id', '') or '').strip()
    if ic or st:
        lines.append(
            'phase_d_remediation: issue_code={0} status={1} context_run_id={2}'.format(
                ic or '-', st or '-', crid or '-'))
    if lines:
        lines.append(
            'phase_d_remediation glossary: verification_scope=dat_lane_only means the DAT-lane gate only; '
            'status=resolved there does not imply full milestone exit unless milestone_exit_ready=true.'
        )
    return lines


def artifact_snapshot_coherence_blocked(snapshot):
    """True when lab diagnostics or run-lineage checks conflict with treating this snapshot as handoff-ready."""
    if not isinstance(snapshot, dict):
        return False
    state = snapshot.get('diagnostics_state', {})
    if not isinstance(state, dict):
        state = {}
    run_id = str(snapshot.get('run_id', '') or '').strip()
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    alignment = compute_run_id_alignment(run_id, active_run_id, last_run_id)
    if pipeline_state == 'failed':
        return True
    if alignment == 'mismatch':
        return True
    if pipeline_state in ('running', 'bootstrapping') and active_run_id and active_run_id != run_id:
        return True
    lineage_issues = snapshot.get('lineage_issues', []) if isinstance(snapshot.get('lineage_issues', []), list) else []
    for item in lineage_issues:
        if str(item or '').strip():
            return True
    return False


def _snapshot_phase_json_path(snapshot, phase_code, prefix=''):
    rows = snapshot.get('phase_rows', []) if isinstance(snapshot.get('phase_rows', []), list) else []
    code = str(phase_code or '').strip().upper()
    for row in rows:
        if str(row.get('code', '') or '').strip().upper() != code:
            continue
        files = row.get('files', []) if isinstance(row.get('files', []), list) else []
        for path in files:
            base = os.path.basename(str(path or ''))
            if prefix and not base.startswith(prefix):
                continue
            if base.lower().endswith('.json'):
                return path
    return ''


def _collect_snapshot_lineage_issues(snapshot, load_json_dict_fn=None):
    if not isinstance(snapshot, dict):
        return []
    if load_json_dict_fn is None:
        load_json_dict_fn = _default_load_json_dict
    issues = []
    phase_run_ids = snapshot.get('phase_run_ids', {}) if isinstance(snapshot.get('phase_run_ids', {}), dict) else {}
    expected_c = str(phase_run_ids.get('C', '') or '').strip()
    expected_d = str(phase_run_ids.get('D', '') or '').strip()
    d_json_path = _snapshot_phase_json_path(snapshot, 'D', prefix='qa_canonical_summary_')
    d_summary = load_json_dict_fn(d_json_path) if d_json_path else {}
    if d_json_path and not isinstance(d_summary, dict):
        d_summary = {}
    if d_json_path and d_summary:
        actual_d = str(d_summary.get('run_id', '') or '').strip()
        if expected_d and actual_d and actual_d != expected_d:
            issues.append(
                'phase_d_summary_run_id_mismatch expected_phase_d={0} actual_phase_d={1}'.format(expected_d, actual_d)
            )
        resolved_c = str(d_summary.get('phase_c_summary_run_id_used_for_zero_selection', '') or '').strip()
        if expected_c and resolved_c and resolved_c != expected_c:
            issues.append(
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c={0} resolved_phase_c={1}'.format(
                    expected_c, resolved_c)
            )
        mismatch = str(d_summary.get('phase_c_context_mismatch_warning', '') or '').strip()
        if mismatch:
            issues.append('phase_d_zero_selection_context_warning {0}'.format(mismatch))
    shadow_json_path = _snapshot_phase_json_path(snapshot, 'F', prefix='shadow_run_report_')
    shadow_payload = load_json_dict_fn(shadow_json_path) if shadow_json_path else {}
    if shadow_json_path and not isinstance(shadow_payload, dict):
        shadow_payload = {}
    if shadow_json_path and shadow_payload:
        shadow_phase_run_ids = shadow_payload.get('phase_run_ids', {}) if isinstance(shadow_payload.get('phase_run_ids', {}), dict) else {}
        for code in ('B', 'C', 'D', 'E'):
            expected = str(phase_run_ids.get(code, '') or '').strip()
            observed = str(shadow_phase_run_ids.get(code, '') or '').strip()
            if expected and observed and expected != observed:
                issues.append(
                    'shadow_phase_run_id_mismatch phase={0} expected={1} observed={2}'.format(code, expected, observed)
                )
    return issues


def collect_group_paths_for_run(reports_dir, run_id, group):
    prefix = group.get('prefix', '')
    suffixes = tuple(group.get('suffixes', ()) or ())
    if not suffixes:
        return []
    available = []
    for order, suffix in enumerate(suffixes):
        path = os.path.join(reports_dir, '{0}{1}{2}'.format(prefix, run_id, suffix))
        if os.path.isfile(path):
            try:
                mtime = os.path.getmtime(path)
            except (IOError, OSError, ValueError):
                mtime = 0
            available.append((order, mtime, path))
    if not available:
        return []
    # Emit one canonical file per logical artifact group so bundles do not
    # attach stale .txt and fresher .json variants for the same summary.
    available.sort(key=lambda item: (item[1], -item[0], item[2]), reverse=True)
    return [available[0][2]]


def collect_artifact_run_candidates(reports_dir, artifact_phase_layout=None, include_optional=True):
    """Collect (mtime, run_id, path) candidates across known artifact prefixes."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    try:
        names = os.listdir(reports_dir)
    except (IOError, OSError):
        return []
    candidates = []
    for phase in artifact_phase_layout:
        groups = list(phase.get('required', ()))
        if include_optional:
            groups += list(phase.get('optional', ()))
        for group in groups:
            prefix = group.get('prefix', '')
            suffixes = group.get('suffixes', ()) or ()
            for name in names:
                if not name.startswith(prefix):
                    continue
                if not any(name.endswith(suf) for suf in suffixes):
                    continue
                path = os.path.join(reports_dir, name)
                if not os.path.isfile(path):
                    continue
                run_id = name[len(prefix):]
                if '.' in run_id:
                    run_id = run_id.rsplit('.', 1)[0]
                if not run_id:
                    continue
                try:
                    mt = os.path.getmtime(path)
                except (IOError, OSError):
                    mt = 0
                candidates.append((mt, run_id, path))
    return candidates


def recent_artifact_run_ids(reports_dir, limit=20, collect_artifact_run_candidates_fn=None):
    """Return unique run_ids ordered newest-first by artifact mtime."""
    if collect_artifact_run_candidates_fn is None:
        collect_artifact_run_candidates_fn = collect_artifact_run_candidates
    candidates = collect_artifact_run_candidates_fn(reports_dir)
    if not candidates:
        return []
    candidates.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
    run_ids = []
    seen = set()
    for _mt, run_id, _path in candidates:
        if run_id in seen:
            continue
        seen.add(run_id)
        run_ids.append(run_id)
        if len(run_ids) >= int(limit or 20):
            break
    return run_ids


def run_has_required_artifacts(
        reports_dir,
        run_id,
        run_id_by_phase=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None):
    """Return (complete_bool, missing_required_labels)."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    phase_map = run_id_by_phase if isinstance(run_id_by_phase, dict) else {}
    missing = []
    for phase in artifact_phase_layout:
        phase_code = str(phase.get('code', '') or '').strip().upper()
        phase_run_id = str(phase_map.get(phase_code, run_id) or '').strip()
        for group in list(phase.get('required', ())):
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group)
            if not paths:
                missing.append('{0}:{1}'.format(phase.get('code', '?'), group.get('label', 'required')))
    return (len(missing) == 0, missing)


def find_latest_complete_artifact_run_id(
        reports_dir,
        exclude_run_id='',
        recent_artifact_run_ids_fn=None,
        run_has_required_artifacts_fn=None):
    """Return latest run_id where all phase required artifacts are present."""
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids
    if run_has_required_artifacts_fn is None:
        run_has_required_artifacts_fn = run_has_required_artifacts
    exclude = str(exclude_run_id or '').strip()
    for run_id in recent_artifact_run_ids_fn(reports_dir, limit=50):
        if exclude and run_id == exclude:
            continue
        is_complete, _ = run_has_required_artifacts_fn(reports_dir, run_id)
        if is_complete:
            return run_id
    return ''


def find_latest_artifact_run_id(reports_dir, collect_artifact_run_candidates_fn=None):
    if collect_artifact_run_candidates_fn is None:
        collect_artifact_run_candidates_fn = collect_artifact_run_candidates
    candidates = collect_artifact_run_candidates_fn(reports_dir)
    if not candidates:
        return ''
    candidates.sort(key=lambda item: (item[0], item[1], item[2]))
    return candidates[-1][1]


def prefer_diagnostics_run_id(reports_dir, diagnostics_state, pipeline_running, run_has_required_artifacts_fn=None):
    """
    Prefer the run lineage declared by diagnostics state before falling back to
    mtime heuristics. This avoids optional-artifact rewrites making an older or
    partial run appear to be the latest coherent bundle.
    """
    if run_has_required_artifacts_fn is None:
        run_has_required_artifacts_fn = run_has_required_artifacts
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    ordered = []
    if pipeline_running and active_run_id:
        ordered.append(active_run_id)
    if last_run_id and last_run_id not in ordered:
        ordered.append(last_run_id)
    if active_run_id and active_run_id not in ordered:
        ordered.append(active_run_id)
    for run_id in ordered:
        if not run_id:
            continue
        try:
            is_complete, missing = run_has_required_artifacts_fn(reports_dir, run_id)
        except Exception:
            is_complete, missing = (False, [])
        if is_complete:
            return run_id
        if isinstance(missing, list) and len(missing) < 5:
            return run_id
    return ''


def _phase_codes(artifact_phase_layout):
    return [str(x.get('code', '') or '').strip().upper() for x in (artifact_phase_layout or []) if x.get('code')]


def _build_single_token_phase_map(run_id, artifact_phase_layout):
    rid = str(run_id or '').strip()
    out = {}
    for code in _phase_codes(artifact_phase_layout):
        out[code] = rid
    return out


def _extract_run_id_from_group_path(path, group):
    if not path:
        return ''
    name = os.path.basename(str(path))
    prefix = str(group.get('prefix', '') or '')
    suffixes = group.get('suffixes', ()) or ()
    if not prefix or not name.startswith(prefix):
        return ''
    for suffix in suffixes:
        if suffix and name.endswith(suffix):
            return name[len(prefix):-len(suffix)]
    return ''


def _extract_phase_run_id_from_path(path, phase):
    groups = list(phase.get('required', ())) + list(phase.get('optional', ()))
    for group in groups:
        rid = _extract_run_id_from_group_path(path, group)
        if rid:
            return rid
    return ''


def _phase_run_ids_from_shadow_report(
        reports_dir,
        run_id,
        artifact_phase_layout=None,
        load_json_dict_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    json_path = os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(run_id))
    if not os.path.isfile(json_path):
        return ({}, 'shadow_report_json_missing')
    report = load_json_dict_fn(json_path)
    source_paths = report.get('source_summary_paths', []) if isinstance(report.get('source_summary_paths', []), list) else []
    if not source_paths:
        return ({}, 'shadow_report_missing_source_summary_paths')
    phase_run_ids = {}
    phase_layout_no_f = [x for x in artifact_phase_layout if str(x.get('code', '') or '').strip().upper() != 'F']
    for candidate in source_paths:
        if not candidate or str(candidate) == '__MISSING__':
            continue
        for phase in phase_layout_no_f:
            code = str(phase.get('code', '') or '').strip().upper()
            rid = _extract_phase_run_id_from_path(candidate, phase)
            if rid:
                phase_run_ids[code] = rid
                break
    return (phase_run_ids, 'shadow_report_source_summary_paths')


def _evaluate_phase_rows(
        reports_dir,
        run_id_by_phase,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        append_unique_path_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path

    rows = []
    all_files = []
    seen_all = set()
    missing_required = []
    required_hits = 0
    required_total = 0

    for phase in artifact_phase_layout:
        phase_code = str(phase.get('code', '') or '').strip().upper()
        phase_run_id = str((run_id_by_phase or {}).get(phase_code, '') or '').strip()
        required_groups = list(phase.get('required', ()))
        optional_groups = list(phase.get('optional', ()))
        phase_files = []
        seen_phase = set()
        required_missing = []
        required_met = True
        has_any = False

        for group in required_groups:
            required_total += 1
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group) if phase_run_id else []
            if not paths:
                required_met = False
                required_missing.append(group.get('label', 'required'))
                continue
            required_hits += 1
            has_any = True
            for path in paths:
                append_unique_path_fn(phase_files, seen_phase, path)
                append_unique_path_fn(all_files, seen_all, path)

        for group in optional_groups:
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group) if phase_run_id else []
            if paths:
                has_any = True
            for path in paths:
                append_unique_path_fn(phase_files, seen_phase, path)
                append_unique_path_fn(all_files, seen_all, path)

        if required_met:
            status = 'complete'
        elif has_any:
            status = 'partial'
        else:
            status = 'missing'
        if required_missing:
            missing_required.append('{0}:{1}'.format(phase.get('code', '?'), ','.join(required_missing)))
        rows.append({
            'code': phase.get('code', '?'),
            'name': phase.get('name', 'Phase'),
            'status': status,
            'required_missing': required_missing,
            'resolved_run_id': phase_run_id or '-',
            'files': phase_files,
        })

    return {
        'rows': rows,
        'artifact_files': all_files,
        'missing_required': missing_required,
        'required_hits': int(required_hits),
        'required_total': int(required_total),
    }


def decide_run_artifact_resolution(
        reports_dir,
        run_id,
        diagnostics_state,
        pipeline_running=False,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        load_json_dict_fn=None,
        append_unique_path_fn=None):
    """Auto-decide artifact resolution path for runbook generation."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path

    resolved_run_id = str(run_id or '').strip()
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    last_pipeline_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    state_phase_map_raw = state.get('last_shadow_pipeline_phase_run_ids', {})
    state_phase_map_raw = state_phase_map_raw if isinstance(state_phase_map_raw, dict) else {}
    is_last_pipeline_root = bool(last_pipeline_run_id and last_pipeline_run_id == resolved_run_id)
    is_active_pipeline_root = bool(pipeline_running and active_run_id and active_run_id == resolved_run_id)
    state_map_is_anchored = bool(is_last_pipeline_root or is_active_pipeline_root)

    single_map = _build_single_token_phase_map(resolved_run_id, artifact_phase_layout)
    single_eval = _evaluate_phase_rows(
        reports_dir,
        single_map,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        append_unique_path_fn=append_unique_path_fn,
    )

    decision = {
        'decision': 'single_token',
        'confidence': 'high',
        'reason': 'single_run_id_lookup',
        'notes': [],
        'pipeline_run_id': resolved_run_id,
        'run_id_by_phase': single_map,
        'evaluation': single_eval,
    }

    shadow_json = os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(resolved_run_id))
    pipeline_candidate = bool(
        resolved_run_id and (
            resolved_run_id == last_pipeline_run_id
            or os.path.isfile(shadow_json)
        )
    )
    if not pipeline_candidate:
        decision['reason'] = 'requested_run_not_pipeline_root'
        return decision

    # Candidate 1: diagnostics_state phase map
    map_state = {}
    for phase in artifact_phase_layout:
        code = str(phase.get('code', '') or '').strip().upper()
        if code == 'F':
            continue
        rid = str(state_phase_map_raw.get(code, '') or '').strip()
        if rid:
            map_state[code] = rid
    has_full_state_map = all(map_state.get(code, '') for code in ('B', 'C', 'D', 'E'))

    # Candidate 2: shadow report source paths
    map_shadow, shadow_reason = _phase_run_ids_from_shadow_report(
        reports_dir,
        resolved_run_id,
        artifact_phase_layout=artifact_phase_layout,
        load_json_dict_fn=load_json_dict_fn,
    )
    has_full_shadow_map = all(str(map_shadow.get(code, '') or '').strip() for code in ('B', 'C', 'D', 'E'))
    map_state_eval = None
    map_shadow_eval = None

    # Prefer explicit run-local lineage encoded by the requested run's shadow report.
    if has_full_shadow_map:
        candidate_shadow_map = dict(single_map)
        candidate_shadow_map.update(map_shadow)
        map_shadow_eval = _evaluate_phase_rows(
            reports_dir,
            candidate_shadow_map,
            artifact_phase_layout=artifact_phase_layout,
            collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
            append_unique_path_fn=append_unique_path_fn,
        )
        if not map_shadow_eval.get('missing_required'):
            decision.update({
                'decision': 'pipeline_phase_map',
                'confidence': 'medium',
                'reason': shadow_reason,
                'run_id_by_phase': candidate_shadow_map,
                'evaluation': map_shadow_eval,
            })
            decision['notes'].append('Resolved per-phase run IDs from shadow_run_report source_summary_paths.')
            return decision

    # Candidate 1 (fallback): diagnostics_state phase map, only when anchored to requested pipeline root.
    if has_full_state_map and state_map_is_anchored:
        state_shadow_conflict = False
        for code in ('B', 'C', 'D', 'E'):
            shadow_rid = str(map_shadow.get(code, '') or '').strip()
            state_rid = str(map_state.get(code, '') or '').strip()
            if shadow_rid and state_rid and shadow_rid != state_rid:
                state_shadow_conflict = True
                break
        if state_shadow_conflict:
            decision['notes'].append(
                'State phase map conflicts with run-local shadow source lineage; ignoring state map for this run.'
            )
        else:
            candidate_map = dict(single_map)
            candidate_map.update(map_state)
            map_state_eval = _evaluate_phase_rows(
                reports_dir,
                candidate_map,
                artifact_phase_layout=artifact_phase_layout,
                collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
                append_unique_path_fn=append_unique_path_fn,
            )
            if not map_state_eval.get('missing_required'):
                decision.update({
                    'decision': 'pipeline_phase_map',
                    'confidence': 'high',
                    'reason': 'diagnostics_state_phase_map_valid',
                    'run_id_by_phase': candidate_map,
                    'evaluation': map_state_eval,
                })
                decision['notes'].append(
                    'Resolved per-phase run IDs from diagnostics_state.last_shadow_pipeline_phase_run_ids for anchored pipeline root.'
                )
                return decision

    if has_full_state_map and not state_map_is_anchored:
        decision['notes'].append(
            'Ignoring diagnostics_state phase map because requested run is not active/last pipeline root.'
        )

    # If the pipeline is still running for this run_id, keep map semantics to avoid false stale classification.
    if is_active_pipeline_root and has_full_state_map:
        candidate_map = dict(single_map)
        candidate_map.update(map_state)
        if map_state_eval is None:
            map_state_eval = _evaluate_phase_rows(
                reports_dir,
                candidate_map,
                artifact_phase_layout=artifact_phase_layout,
                collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
                append_unique_path_fn=append_unique_path_fn,
            )
        decision.update({
            'decision': 'pipeline_phase_map',
            'confidence': 'low',
            'reason': 'pipeline_active_phase_map_pending',
            'run_id_by_phase': candidate_map,
            'evaluation': map_state_eval,
        })
        decision['notes'].append('Pipeline is active; mapped phase artifacts may still be materializing.')
        return decision

    # Drift guard: if mapped candidates are weaker than single-token, fall back and explain.
    weak_state_map = bool(
        has_full_state_map and map_state_eval is not None
        and len(map_state_eval.get('missing_required', [])) > len(single_eval.get('missing_required', []))
    )
    weak_shadow_map = bool(
        has_full_shadow_map and map_shadow_eval is not None
        and len(map_shadow_eval.get('missing_required', [])) > len(single_eval.get('missing_required', []))
    )
    if weak_state_map or weak_shadow_map:
        decision['reason'] = 'phase_map_state_file_drift_fallback_single_token'
        decision['notes'].append('Phase map exists but produced more required gaps than single-token lookup.')
    elif has_full_state_map and not state_map_is_anchored:
        decision['reason'] = 'state_phase_map_unanchored_fallback_single_token'
        decision['notes'].append('State phase map is not tied to this run_id lineage.')
    elif has_full_state_map or has_full_shadow_map:
        decision['reason'] = 'phase_map_incomplete_fallback_single_token'
        decision['notes'].append('Phase map was available but required artifacts were incomplete.')
    else:
        decision['reason'] = 'pipeline_phase_map_unavailable_fallback_single_token'
        decision['notes'].append('No complete phase map found in diagnostics state or shadow report JSON.')
    return decision


def _find_nearest_complete_run_id_with_decision(
        reports_dir,
        exclude_run_id,
        diagnostics_state,
        pipeline_running,
        recent_artifact_run_ids_fn=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        load_json_dict_fn=None,
        append_unique_path_fn=None):
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path
    exclude = str(exclude_run_id or '').strip()
    for candidate_run_id in recent_artifact_run_ids_fn(reports_dir, limit=50):
        if exclude and candidate_run_id == exclude:
            continue
        decision = decide_run_artifact_resolution(
            reports_dir,
            candidate_run_id,
            diagnostics_state,
            pipeline_running=pipeline_running,
            artifact_phase_layout=artifact_phase_layout,
            collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
            load_json_dict_fn=load_json_dict_fn,
            append_unique_path_fn=append_unique_path_fn,
        )
        evaluation = decision.get('evaluation', {}) if isinstance(decision.get('evaluation', {}), dict) else {}
        missing_required = evaluation.get('missing_required', []) if isinstance(evaluation.get('missing_required', []), list) else []
        if not missing_required:
            return candidate_run_id
    return ''


def build_run_artifact_snapshot(
        repo_root,
        run_id='',
        resolve_lab_root_fn=None,
        reports_dir_access_error_fn=None,
        find_latest_artifact_run_id_fn=None,
        load_json_dict_fn=None,
        find_latest_complete_artifact_run_id_fn=None,
        recent_artifact_run_ids_fn=None,
        is_pipeline_running_fn=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        append_unique_path_fn=None,
        prefer_diagnostics_run_id_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path
    if find_latest_artifact_run_id_fn is None:
        find_latest_artifact_run_id_fn = find_latest_artifact_run_id
    if find_latest_complete_artifact_run_id_fn is None:
        find_latest_complete_artifact_run_id_fn = find_latest_complete_artifact_run_id
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids
    if resolve_lab_root_fn is None:
        resolve_lab_root_fn = _default_resolve_lab_root
    if reports_dir_access_error_fn is None:
        reports_dir_access_error_fn = _default_reports_dir_access_error
    if load_json_dict_fn is None:
        load_json_dict_fn = _default_load_json_dict
    if is_pipeline_running_fn is None:
        is_pipeline_running_fn = _default_pipeline_not_running
    if prefer_diagnostics_run_id_fn is None:
        prefer_diagnostics_run_id_fn = prefer_diagnostics_run_id

    lab_root = resolve_lab_root_fn(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    reports_err = reports_dir_access_error_fn(lab_root)
    if reports_err:
        return (False, reports_err, None)
    if reports_dir and not os.path.exists(reports_dir):
        return (False, 'No reports directory: {0}'.format(reports_dir), None)

    diagnostics_state = load_json_dict_fn(os.path.join(lab_root, 'diagnostics_state.json'))
    pipeline_running = bool(is_pipeline_running_fn(lab_root))
    resolved_run_id = str(run_id or '').strip()
    if not resolved_run_id:
        resolved_run_id = prefer_diagnostics_run_id_fn(
            reports_dir,
            diagnostics_state,
            pipeline_running,
            run_has_required_artifacts_fn=lambda rd, rid: run_has_required_artifacts(
                rd,
                rid,
                artifact_phase_layout=artifact_phase_layout,
                collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
            ),
        )
    if not resolved_run_id:
        resolved_run_id = find_latest_artifact_run_id_fn(reports_dir)
    if not resolved_run_id:
        return (False, 'No run-scoped artifacts found in reports directory.', None)
    resolution = decide_run_artifact_resolution(
        reports_dir,
        resolved_run_id,
        diagnostics_state,
        pipeline_running=pipeline_running,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        load_json_dict_fn=load_json_dict_fn,
        append_unique_path_fn=append_unique_path_fn,
    )
    evaluation = resolution.get('evaluation', {}) if isinstance(resolution.get('evaluation', {}), dict) else {}
    rows = evaluation.get('rows', []) if isinstance(evaluation.get('rows', []), list) else []
    all_files = evaluation.get('artifact_files', []) if isinstance(evaluation.get('artifact_files', []), list) else []
    missing_required = evaluation.get('missing_required', []) if isinstance(evaluation.get('missing_required', []), list) else []

    if not all_files:
        return (False, 'No artifacts found for run_id={0}.'.format(resolved_run_id), None)

    context_files = []
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            context_files.append(ctx_path)
    recent_run_ids = recent_artifact_run_ids_fn(reports_dir, limit=12)
    nearest_complete_run_id = _find_nearest_complete_run_id_with_decision(
        reports_dir,
        exclude_run_id=resolved_run_id,
        diagnostics_state=diagnostics_state,
        pipeline_running=pipeline_running,
        recent_artifact_run_ids_fn=recent_artifact_run_ids_fn,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        load_json_dict_fn=load_json_dict_fn,
        append_unique_path_fn=append_unique_path_fn,
    )

    snapshot = {
        'repo_root': repo_root,
        'lab_root': lab_root,
        'reports_dir': reports_dir,
        'run_id': resolved_run_id,
        'phase_rows': rows,
        'artifact_files': all_files,
        'context_files': context_files,
        'missing_required': missing_required,
        'diagnostics_state': diagnostics_state,
        'nearest_complete_run_id': nearest_complete_run_id,
        'recent_run_ids': recent_run_ids,
        'pipeline_running': pipeline_running,
        'pipeline_run_id': resolution.get('pipeline_run_id', resolved_run_id),
        'phase_run_ids': resolution.get('run_id_by_phase', {}),
        'resolution_decision': resolution.get('decision', 'single_token'),
        'resolution_confidence': resolution.get('confidence', 'unknown'),
        'resolution_reason': resolution.get('reason', ''),
        'resolution_notes': resolution.get('notes', []),
    }
    snapshot['lineage_issues'] = _collect_snapshot_lineage_issues(snapshot, load_json_dict_fn=load_json_dict_fn)
    return (True, '', snapshot)


def write_run_artifact_index(snapshot, latest_alias=False, recommended_action=None):
    reports_dir = snapshot.get('reports_dir', '')
    run_id = snapshot.get('run_id', '')
    token = safe_run_token(run_id)
    if latest_alias:
        filename = 'run_artifact_index_latest.txt'
    else:
        filename = 'run_artifact_index_{0}.txt'.format(token)
    path = os.path.join(reports_dir, filename)
    lines = []
    lines.append('Run Artifact Index')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('run_id={0}'.format(run_id))
    lines.append('pipeline_run_id={0}'.format(snapshot.get('pipeline_run_id', run_id)))
    lines.append('lab_root={0}'.format(snapshot.get('lab_root', '')))
    lines.append('')
    for row in snapshot.get('phase_rows', []):
        lines.append('[{0}] {1} status={2} resolved_run_id={3}'.format(
            row.get('code', '?'),
            row.get('name', 'Phase'),
            row.get('status', 'missing').upper(),
            row.get('resolved_run_id', '-')))
        missing = row.get('required_missing', [])
        if missing:
            lines.append(' - missing_required={0}'.format(','.join(missing)))
        files = row.get('files', [])
        if files:
            for fp in files:
                lines.append(' - {0}'.format(fp))
        else:
            lines.append(' - (no files)')
        lines.append('')
    if snapshot.get('context_files'):
        lines.append('Context files:')
        for fp in snapshot.get('context_files', []):
            lines.append(' - {0}'.format(fp))
        lines.append('')

    status_counts = {'complete': 0, 'partial': 0, 'missing': 0}
    for row in snapshot.get('phase_rows', []):
        st = row.get('status', 'missing')
        status_counts[st] = status_counts.get(st, 0) + 1
    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    run_id = snapshot.get('run_id', '')
    alignment = compute_run_id_alignment(run_id, active_run_id, last_run_id)
    lineage_issues = snapshot.get('lineage_issues', []) if isinstance(snapshot.get('lineage_issues', []), list) else []
    coherence_blocked = artifact_snapshot_coherence_blocked(snapshot)

    lines.append('Runbook Interpretation:')
    lines.append(' - phase_counts=complete:{0},partial:{1},missing:{2}'.format(
        status_counts.get('complete', 0),
        status_counts.get('partial', 0),
        status_counts.get('missing', 0),
    ))
    lines.append(' - resolution_decision={0}'.format(snapshot.get('resolution_decision', 'single_token')))
    lines.append(' - resolution_confidence={0}'.format(snapshot.get('resolution_confidence', 'unknown')))
    lines.append(' - resolution_reason={0}'.format(snapshot.get('resolution_reason', '')))
    phase_run_ids = snapshot.get('phase_run_ids', {}) if isinstance(snapshot.get('phase_run_ids', {}), dict) else {}
    if phase_run_ids:
        parts = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            rid = str(phase_run_ids.get(code, '') or '-')
            parts.append('{0}:{1}'.format(code, rid))
        lines.append(' - phase_run_ids={0}'.format(','.join(parts)))
    if lineage_issues:
        lines.append(' - lineage_issue_count={0}'.format(len(lineage_issues)))
        for item in lineage_issues[:5]:
            lines.append(' - lineage_issue={0}'.format(item))
    lines.append(' - run_alignment={0}'.format(alignment))
    lines.append(' - nearest_complete_run_id={0}'.format(snapshot.get('nearest_complete_run_id', '') or '-'))
    rec = recommended_action if isinstance(recommended_action, dict) else {}
    if rec:
        idx_lines = format_recommended_action_lines(rec, title='Operator recommendation (anchored vs live):')
        if idx_lines:
            lines.append('')
            lines.extend(idx_lines)
    lines.append('What To Do Now:')
    if status_counts.get('missing', 0) > 0:
        lines.append(' 1) Treat this run as incomplete for full-phase evidence.')
        lines.append(' 2) Open latest Artifact Triage Pack for consolidated gap/runbook guidance.')
        if snapshot.get('nearest_complete_run_id'):
            lines.append(' 3) Inspect nearest complete run_id={0} for baseline evidence.'.format(
                snapshot.get('nearest_complete_run_id')))
    elif coherence_blocked:
        if lineage_issues:
            lines.append(' 1) Phase files are present, but anchored phase lineage is contradictory; treat this bundle as cross-run contaminated.')
            lines.append(' 2) Read the Artifact Triage Pack Consequential Diagnostics and repair the missing or stale phase artifact before handoff.')
            lines.append(' 3) Re-export run evidence only after the anchored D/F summaries agree with the mapped C/D/E run ids.')
        else:
            lines.append(' 1) Phase files are present for this run_id, but lab diagnostics show pipeline failure or run misalignment.')
            lines.append(' 2) Read diagnostics_state.json and the Artifact Triage Pack Consequential Diagnostics before handoff.')
            lines.append(' 3) Resolve pipeline state / alignment, then re-export run evidence if escalation is still needed.')
    else:
        for index, action in enumerate(ready_index_actions(recommended_action), 1):
            lines.append(' {0}) {1}'.format(index, action))
    lines.append('')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=None):
    reports_dir = snapshot.get('reports_dir', '')
    run_id = snapshot.get('run_id', '')
    token = safe_run_token(run_id)
    if latest_alias:
        filename = 'artifact_triage_pack_latest.txt'
    else:
        filename = 'artifact_triage_pack_{0}.txt'.format(token)
    path = os.path.join(reports_dir, filename)

    status_counts = {'complete': 0, 'partial': 0, 'missing': 0}
    for row in snapshot.get('phase_rows', []):
        st = row.get('status', 'missing')
        status_counts[st] = status_counts.get(st, 0) + 1

    if status_counts.get('missing', 0) > 0:
        overall = 'MISSING'
    elif status_counts.get('partial', 0) > 0:
        overall = 'PARTIAL'
    else:
        overall = 'COMPLETE'

    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    last_error_code = str(state.get('last_error_code', '') or state.get('last_shadow_pipeline_error_code', '') or '').strip()
    pipeline_running = bool(snapshot.get('pipeline_running'))
    nearest_complete = str(snapshot.get('nearest_complete_run_id', '') or '').strip()
    resolution_decision = str(snapshot.get('resolution_decision', '') or 'single_token').strip()
    resolution_confidence = str(snapshot.get('resolution_confidence', '') or 'unknown').strip()
    resolution_reason = str(snapshot.get('resolution_reason', '') or '').strip()
    resolution_notes = snapshot.get('resolution_notes', []) if isinstance(snapshot.get('resolution_notes', []), list) else []
    lineage_issues = snapshot.get('lineage_issues', []) if isinstance(snapshot.get('lineage_issues', []), list) else []

    run_alignment = compute_run_id_alignment(run_id, active_run_id, last_run_id)
    coherence_blocked = artifact_snapshot_coherence_blocked(snapshot)

    reasoning = []
    actions = []
    if overall == 'COMPLETE':
        if coherence_blocked:
            classification = 'REVIEW_REQUIRED'
            if lineage_issues:
                reasoning.append(
                    'All required phase artifacts (B..F) are present on disk, but anchored phase lineage inside the packaged summaries is contradictory; see Consequential Diagnostics below.')
                reasoning.append(
                    'Do not treat this bundle as a single coherent successful pipeline run until the anchored D/F summaries agree with the mapped C/D/E run ids.')
                actions.append('Repair or wait for the missing/stale phase summary so the anchored D/F lineage matches the mapped C/D/E run ids.')
                actions.append('Regenerate triage pack and index after the conflicting phase artifact is rewritten for this anchor.')
            else:
                reasoning.append(
                    'All required phase artifacts (B..F) are present on disk, but lab pipeline state or run-id alignment '
                    'does not support a clean handoff; see Consequential Diagnostics below.')
                reasoning.append(
                    'Do not treat this bundle as a single coherent successful pipeline run until diagnostics align.')
                actions.append('Review diagnostics_state.json and last_shadow_pipeline_run_id vs this run_id.')
                actions.append('Resolve pipeline failure or rerun shadow pipeline, then regenerate triage pack and index.')
            if nearest_complete:
                actions.append('Compare against nearest complete run_id={0} if you need baseline evidence.'.format(
                    nearest_complete))
        else:
            classification = 'READY'
            reasoning.append('All required phase artifacts (B..F) are present for this run.')
            actions.extend(ready_triage_actions(recommended_action))
    else:
        classification = 'INCOMPLETE'
        if pipeline_state in ('running', 'bootstrapping') and active_run_id and active_run_id == run_id:
            reasoning.append('This run is currently active; missing artifacts may be expected until completion.')
            actions.append('Wait for pipeline completion, then reopen latest Artifact Triage Pack.')
        elif pipeline_state in ('running', 'bootstrapping') and active_run_id and active_run_id != run_id:
            reasoning.append('A different active run exists; this run may be a stale or partial artifact set.')
            actions.append('Inspect active run_id={0} first using run-ID artifact index.'.format(active_run_id))
            actions.append('Reopen latest Artifact Triage Pack after active run settles.')
        else:
            if resolution_decision == 'pipeline_phase_map':
                reasoning.append('Phase-mapped pipeline lineage detected; missing artifacts are relative to mapped per-phase run IDs.')
            elif status_counts.get('complete', 0) <= 1 and status_counts.get('missing', 0) >= 3:
                reasoning.append('Pattern suggests a partial/manual phase run rather than a coherent A->F pipeline run.')
            else:
                reasoning.append('Required artifacts are missing while pipeline is not actively writing them.')
            actions.append('Trigger full shadow pipeline (A->F) from Cloud Readiness Manual Pipeline Control.')
            actions.append('Reopen latest Artifact Triage Pack to confirm all required artifacts appear.')
        if nearest_complete:
            actions.append('Inspect previous coherent run_id={0} for baseline comparison.'.format(nearest_complete))
        actions.append('If blockers remain, send latest run evidence bundle for support triage.')

    lines = []
    lines.append('Artifact Triage Pack')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('run_id={0}'.format(run_id))
    lines.append('pipeline_run_id={0}'.format(snapshot.get('pipeline_run_id', run_id)))
    lines.append(
        'bundle_scope_note=Phase files above are run-scoped; diagnostics_state.json, run_cursor.json, and log_tail.txt '
        'in the zip may reflect current lab or application state, not only this run_id.')
    lines.append('overall={0}'.format(overall))
    lines.append('phase_counts=complete:{0},partial:{1},missing:{2}'.format(
        status_counts.get('complete', 0),
        status_counts.get('partial', 0),
        status_counts.get('missing', 0),
    ))
    lines.append('')
    lines.append('Phase coverage:')
    for row in snapshot.get('phase_rows', []):
        files = row.get('files', [])
        line = ' - [{0}] {1}: {2} (files={3})'.format(
            row.get('code', '?'),
            row.get('name', 'Phase'),
            row.get('status', 'missing').upper(),
            len(files),
        )
        lines.append(line)
        lines.append('   resolved_run_id={0}'.format(row.get('resolved_run_id', '-')))
        missing = row.get('required_missing', [])
        if missing:
            lines.append('   missing_required={0}'.format(','.join(missing)))
    lines.append('')
    lines.append('Critical gaps:')
    missing_required = snapshot.get('missing_required', [])
    gap_items = []
    if isinstance(missing_required, list):
        gap_items.extend([item for item in missing_required if str(item or '').strip()])
    gap_items.extend([item for item in lineage_issues if str(item or '').strip()])
    if gap_items:
        for item in gap_items:
            lines.append(' - {0}'.format(item))
    else:
        lines.append(' - none')
    lines.append('')
    lines.append('Runbook Interpretation:')
    lines.append(' - classification={0}'.format(classification))
    for item in reasoning:
        lines.append(' - reasoning: {0}'.format(item))
    lines.append('')
    lines.append('Consequential Diagnostics:')
    lines.append(' - pipeline_state={0}'.format(pipeline_state or 'unknown'))
    lines.append(' - pipeline_lock_running={0}'.format(pipeline_running))
    lines.append(' - active_run_id={0}'.format(active_run_id or '-'))
    lines.append(' - last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'))
    lines.append(' - resolution_decision={0}'.format(resolution_decision))
    lines.append(' - resolution_confidence={0}'.format(resolution_confidence))
    lines.append(' - resolution_reason={0}'.format(resolution_reason or '-'))
    phase_run_ids = snapshot.get('phase_run_ids', {}) if isinstance(snapshot.get('phase_run_ids', {}), dict) else {}
    if phase_run_ids:
        parts = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            rid = str(phase_run_ids.get(code, '') or '-')
            parts.append('{0}:{1}'.format(code, rid))
        lines.append(' - phase_run_ids={0}'.format(','.join(parts)))
    if lineage_issues:
        lines.append(' - lineage_issue_count={0}'.format(len(lineage_issues)))
        for item in lineage_issues[:5]:
            lines.append(' - lineage_issue={0}'.format(item))
    for note in resolution_notes[:3]:
        lines.append(' - resolution_note={0}'.format(note))
    lines.append(' - run_id_alignment={0}'.format(run_alignment))
    lines.append(' - last_error_code={0}'.format(last_error_code or '-'))
    lines.append(' - nearest_complete_run_id={0}'.format(nearest_complete or '-'))
    recent_runs = snapshot.get('recent_run_ids', []) if isinstance(snapshot.get('recent_run_ids', []), list) else []
    if recent_runs:
        lines.append(' - recent_run_ids={0}'.format(','.join(recent_runs[:6])))
    rec_lines = format_recommended_action_lines(recommended_action)
    if rec_lines:
        lines.append('')
        lines.extend(rec_lines)
    lines.append('')
    lines.append('What To Do Now:')
    step = 1
    for action in actions:
        lines.append(' {0}) {1}'.format(step, action))
        step += 1
    lines.append('')
    lines.append('Tip: open run artifact index for full file paths.')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def artifact_bundle_quality(snapshot):
    """Return quality summary for run-evidence bundle decisions."""
    rows = snapshot.get('phase_rows', []) if isinstance(snapshot.get('phase_rows', []), list) else []
    total = len(rows) or 1
    complete = len([r for r in rows if str(r.get('status', '')).lower() == 'complete'])
    partial = len([r for r in rows if str(r.get('status', '')).lower() == 'partial'])
    missing = len([r for r in rows if str(r.get('status', '')).lower() == 'missing'])
    score = int(round((complete * 1.0 + partial * 0.5) / float(total) * 100.0))
    if score >= 90 and missing == 0:
        label = 'HIGH'
    elif score >= 60:
        label = 'MEDIUM'
    else:
        label = 'LOW'
    blocked = artifact_snapshot_coherence_blocked(snapshot)
    if blocked:
        score = min(score, 79)
        if label == 'HIGH':
            label = 'MEDIUM'
    recommendation = 'send_current_run'
    if label == 'LOW' and snapshot.get('nearest_complete_run_id'):
        recommendation = 'prefer_nearest_complete'
    elif blocked:
        recommendation = 'review_lab_state'
    return {
        'score': score,
        'label': label,
        'complete': complete,
        'partial': partial,
        'missing': missing,
        'recommendation': recommendation,
    }


def build_run_id_diagnostics(snapshot, requested_run_id):
    """Build diagnostics text when explicit run-id inspect fails."""
    if not isinstance(snapshot, dict):
        snapshot = {}
    recent = snapshot.get('recent_run_ids', []) if isinstance(snapshot.get('recent_run_ids', []), list) else []
    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    nearest_complete = str(snapshot.get('nearest_complete_run_id', '') or '').strip()

    bits = []
    bits.append('Run ID diagnostics for {0}:'.format(requested_run_id))
    bits.append('active_run_id={0}'.format(active_run_id or '-'))
    bits.append('last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'))
    bits.append('nearest_complete_run_id={0}'.format(nearest_complete or '-'))
    if recent:
        bits.append('recent_run_ids={0}'.format(','.join(recent[:8])))
    if active_run_id and requested_run_id != active_run_id:
        bits.append('note=requested run differs from currently active run.')
    if nearest_complete and requested_run_id != nearest_complete:
        bits.append('note=requested run is not latest complete run.')
    return ' '.join(bits)



