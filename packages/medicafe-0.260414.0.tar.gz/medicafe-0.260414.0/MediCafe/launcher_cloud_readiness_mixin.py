﻿#!/usr/bin/env python
# pyright: reportAttributeAccessIssue=false
"""
Cloud Readiness launcher menu/actions extracted from launcher.py.

Keeps top-level launcher flow small while preserving exact operator-facing
menu wording and behavior.
"""
from __future__ import print_function

import json
import os
import re
import sys
import threading
import time
from contextlib import contextmanager


def _console_heartbeat_enabled():
    env = str(os.environ.get('MEDICAFE_FORCE_CONSOLE_HEARTBEAT', '') or '').strip().lower()
    if env in ('1', 'true', 'yes', 'on'):
        return True
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _stdout_is_tty():
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _heartbeat_legacy_mode():
    env = str(os.environ.get('MEDICAFE_CONSOLE_HEARTBEAT_LEGACY', '') or '').strip().lower()
    return env in ('1', 'true', 'yes', 'on')


# ASCII-only spinner for XP / narrow consoles (no Unicode).
_HEARTBEAT_SPINNER_FRAMES = ('|', '/', '-', '\\')


class _ConsoleHeartbeatProgress(object):
    """Thread-safe mutable stage text for console heartbeat updates."""

    def __init__(self, activity_label, sparse_log=False):
        self._activity_label = str(activity_label or 'working').strip() or 'working'
        self._stage = ''
        self._lock = threading.Lock()
        self._sparse_log = bool(sparse_log)
        self._sparse_last = None

    def update(self, stage_label):
        stage_text = str(stage_label or '').strip()
        with self._lock:
            self._stage = stage_text
            if self._sparse_log and stage_text and stage_text != self._sparse_last:
                self._sparse_last = stage_text
                try:
                    print('  ... {0}'.format(stage_text), flush=True)
                except Exception:
                    pass

    def render(self):
        with self._lock:
            stage_text = self._stage
        if stage_text:
            return '{0}; {1}'.format(self._activity_label, stage_text)
        return self._activity_label

    def get_activity(self):
        with self._lock:
            return self._activity_label

    def get_stage(self):
        with self._lock:
            return self._stage


@contextmanager
def _console_activity_heartbeat(activity_label, first_delay_sec=2.0, interval_sec=4.0):
    """Show liveness during blocking work: TTY uses milestone + single-line pulse; else sparse stage lines."""
    tty = _stdout_is_tty()
    legacy = _heartbeat_legacy_mode()
    enabled = _console_heartbeat_enabled()

    use_legacy_worker = enabled and tty and legacy
    use_new_pulse = enabled and tty and not legacy
    sparse_log = not (use_legacy_worker or use_new_pulse)

    progress = _ConsoleHeartbeatProgress(activity_label, sparse_log=sparse_log)

    if not use_legacy_worker and not use_new_pulse:
        yield progress
        return

    stop = threading.Event()
    state = {'live_width': 0}

    def _worker_legacy():
        delay = first_delay_sec
        while True:
            if stop.wait(delay):
                return
            try:
                print('  ... still working ({0})'.format(progress.render()), flush=True)
            except Exception:
                pass
            delay = interval_sec

    def _worker_new_pulse():
        delay = first_delay_sec
        last_milestone_stage = None
        stage_idx = 0
        live_width = 0
        live_first = True
        pulse = 0
        had_live = False

        while True:
            if stop.wait(delay):
                break
            activity = progress.get_activity()
            stage = progress.get_stage()
            label = stage if stage else activity

            if stage and stage != last_milestone_stage:
                if had_live and live_width > 0:
                    try:
                        sys.stdout.write('\n')
                        sys.stdout.flush()
                    except Exception:
                        pass
                stage_idx += 1
                try:
                    print('  [{0}] {1}'.format(stage_idx, stage), flush=True)
                except Exception:
                    pass
                last_milestone_stage = stage
                live_first = True
                live_width = 0
                had_live = True

            spin = _HEARTBEAT_SPINNER_FRAMES[pulse % len(_HEARTBEAT_SPINNER_FRAMES)]
            pulse += 1
            line = '  working: {0}  {1}'.format(label, spin)
            try:
                padded = line.ljust(max(live_width, len(line)))
                if live_first:
                    sys.stdout.write(padded)
                    live_first = False
                else:
                    sys.stdout.write('\r' + padded)
                sys.stdout.flush()
                live_width = len(padded)
                state['live_width'] = live_width
                had_live = True
            except Exception:
                pass
            delay = interval_sec

    target = _worker_legacy if use_legacy_worker else _worker_new_pulse
    thread = threading.Thread(target=target)
    thread.daemon = True
    thread.start()
    try:
        yield progress
    finally:
        stop.set()
        thread.join(timeout=0.5)
        if use_new_pulse and state.get('live_width', 0) > 0:
            try:
                w = int(state['live_width'])
                sys.stdout.write('\r' + (' ' * w) + '\n')
                sys.stdout.flush()
            except Exception:
                pass


class LauncherCloudReadinessMixin(object):
    """Mixin providing Cloud Readiness menus and action handlers."""

    def _new_support_send_operation_id(self, send_type):
        token = ''
        try:
            token = os.urandom(3).encode('hex')
        except Exception:
            token = str(int(time.time() * 1000) % 1000000)
        return 'ssop_{0}_{1}_{2}'.format(
            str(send_type or 'unknown').strip() or 'unknown',
            time.strftime('%Y%m%d%H%M%S', time.gmtime()),
            token,
        )

    def _log_support_send_event(self, event_name, details):
        """Best-effort centralized logging for support send diagnostics."""
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            payload = details if isinstance(details, dict) else {}
            parts = []
            for key in (
                    'operation_id',
                    'send_type',
                    'phase',
                    'status',
                    'duration_ms',
                    'send_source',
                    'operator_execution_mode',
                    'frozen_recommendation',
                    'result_message'):
                if key in payload:
                    parts.append('{0}={1}'.format(key, payload.get(key)))
            summary = ' '.join(parts).strip()
            config_log(
                'CloudReadiness {0}{1}'.format(
                    str(event_name or ''),
                    (' ' + summary) if summary else '',
                ),
                level='INFO',
                console_output=False,
            )
        except Exception:
            pass

    def _cloud_readiness_service(self):
        resolver = getattr(self, '_cloud_readiness_resolver', None)
        if callable(resolver):
            try:
                return resolver()
            except Exception:
                return None
        return None

    def _env_flag_value(self, name, default=False):
        env_flag_fn = getattr(self, '_env_flag_fn', None)
        if callable(env_flag_fn):
            try:
                return env_flag_fn(name, default)
            except Exception:
                return default
        return default

    def _print_phase_f_status(self):
        """Print interpreted pipeline health snapshot before Cloud Readiness choices."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        lab_root = cr.resolve_lab_root(self.repo_root)
        for line in cr.get_health_lines(lab_root, self._env_flag_value):
            print(line)

    def _print_manual_pipeline_runbook(self, action_code):
        """Print what-to-expect runbook after manual pipeline trigger."""
        code = str(action_code or '').upper().strip()
        print('')
        print('Manual pipeline runbook:')
        print(' - heartbeat_timeout_sec=120')
        if code == 'A':
            print(' - expected_progression=B->C->D->E->F')
            print(' - expected_artifacts=artifact_discovery_summary_, ingest_write_summary_, qa_canonical_summary_, projection_parity_summary_, shadow_run_report_')
            print(' - if_no_new_artifacts_within_timeout=Open latest Artifact Triage Pack; if still stalled, retrigger A and inspect delivery diagnostics.')
        elif code == 'B':
            print(' - expected_artifact=artifact_discovery_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Verify source folders, then retrigger B or run A for coherent pipeline execution.')
        elif code == 'C':
            print(' - expected_artifact=ingest_write_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Confirm manifest exists; review ingest anomalies and rerun C or full A.')
        elif code == 'D':
            print(' - expected_artifact=qa_canonical_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Check QA prerequisites and rerun D; inspect reject samples when produced.')
        elif code == 'E':
            print(' - expected_artifact=projection_parity_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Validate parity inputs and rerun E; inspect deviation samples if coverage/parity issues appear.')
        print(' - verify_with=Cloud Phase Artifact Tools -> A/B')

    def _run_system_health_triage(self):
        """Run migration audit + refresh unified system-health pack, then print quick hints."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        migration_stage = str(os.environ.get('MEDICAFE_MIGRATION_STAGE', 'xp_validation') or 'xp_validation').strip().lower()
        if migration_stage not in ('xp_validation', 'dual_run_pre_cutover', 'cutover'):
            migration_stage = 'xp_validation'
        cloud_required = str(os.environ.get('MEDICAFE_CLOUD_REQUIRED', '') or '').strip().lower() in (
            '1', 'true', 'yes', 'on',
        )
        with _console_activity_heartbeat('system health triage: audit + pack refresh'):
            ok, msg, data = cr.run_system_health_triage(
                self.repo_root,
                self.python_exe,
                self.environment,
                self._env_flag_value,
                scope='both',
                cloud_required=cloud_required,
                migration_stage=migration_stage,
            )
        if msg:
            print(msg)
        hints = []
        artifacts = []
        if isinstance(data, dict):
            hints = data.get('hints', []) if isinstance(data.get('hints', []), list) else []
            artifacts = data.get('artifacts', []) if isinstance(data.get('artifacts', []), list) else []
            runbook_lines = data.get('runbook_lines', []) if isinstance(data.get('runbook_lines', []), list) else []
        else:
            runbook_lines = []
        if hints:
            print('')
            print('Manual validation quick hints:')
            for line in hints:
                print(' - {0}'.format(line))
        if runbook_lines:
            print('')
            print('Decision runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if artifacts:
            print('')
            print('Generated artifacts:')
            for path in artifacts:
                print(' - {0}'.format(path))
        if not ok:
            print('Triage finished with issues. Review artifacts for details.')

    def _open_latest_system_health_pack(self):
        """Open latest combined system-health pack snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('building system health pack snapshot') as heartbeat:
            ok, msg, path = cr.open_latest_system_health_pack(
                self.repo_root,
                self._env_flag_value,
                progress_callback=heartbeat.update,
            )
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_data_plane_audit_report(self, report_type='overview', limit=40):
        """Generate and open DB data audit report (counts + patient chain sample)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        hb_label = 'DB data audit report ({0})'.format(report_type)
        with _console_activity_heartbeat(hb_label):
            ok, msg, path = cr.open_data_plane_audit_report(
                self.repo_root, report_type=report_type, limit=limit)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _open_latest_data_plane_audit_report(self, report_type='overview'):
        """Open latest generated DB data audit report for report_type."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_data_plane_audit_report(
            self.repo_root, report_type=report_type)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_patient_flow_runbook_by_reference(self):
        """Prompt for patient reference and open patient flow runbook."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        patient_ref = (self._prompt(
            'Enter patient reference (patient_id / external_patient_id / patient_key): ') or '').strip()
        if not patient_ref:
            print('Cancelled.')
            return
        with _console_activity_heartbeat('patient flow runbook: generating'):
            ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _cloud_db_inspection_menu(self):
        """DB content inspection tools for manual data-quality audits."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud DB Inspection', width=40)
            self._print_troubleshooting_group('Inventory & Quality', [
                '1)  Generate DB overview report (counts + quality)',
                '2)  Open latest DB overview report',
                '3)  Generate recent patient sample report',
                '4)  Generate high-risk patient sample report',
            ])
            self._print_troubleshooting_group('Patient Drilldown', [
                '5)  Open patient flow runbook by patient reference',
                '6)  Open Patient Flow Runbook (auto-populated list)',
                '7)  Guided Patient Completeness Runbook',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Generating DB overview report...')
                self._open_data_plane_audit_report(report_type='overview', limit=60)
            elif choice == '2':
                print('Opening latest DB overview report...')
                self._open_latest_data_plane_audit_report(report_type='overview')
            elif choice == '3':
                print('Generating recent patient sample report...')
                self._open_data_plane_audit_report(report_type='recent', limit=60)
            elif choice == '4':
                print('Generating high-risk patient sample report...')
                self._open_data_plane_audit_report(report_type='high_risk', limit=60)
            elif choice == '5':
                print('Opening patient flow runbook by manual reference...')
                self._open_patient_flow_runbook_by_reference()
            elif choice == '6':
                print('Opening patient flow runbook by auto-populated reference...')
                self._open_patient_flow_runbook_for_id()
            elif choice == '7':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _open_report_delivery_status(self):
        """Open compact report delivery/send diagnostics snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_report_delivery_status(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_phase_f_shadow_report(self):
        """View latest Shadow Health report (Phase F) - txt or json."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_shadow_report(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_latest_system_health_pack(self, send_source='manual_system_health_pack', operator_execution_mode='explicit_send_menu', recommendation=None):
        """Send latest unified system-health pack with related artifacts. Returns True on send success."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        op_id = self._new_support_send_operation_id('system_health')
        t0 = time.time()
        has_recommendation = bool(isinstance(recommendation, dict) and recommendation)
        self._log_support_send_event('support_send_start', {
            'operation_id': op_id,
            'send_type': 'system_health',
            'phase': 'start',
            'status': 'running',
            'send_source': str(send_source or 'manual_system_health_pack'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
        })
        with _console_activity_heartbeat('sending system health pack: bundle + delivery') as heartbeat:
            ok, msg, data = cr.send_latest_system_health_pack(
                self.repo_root,
                self._env_flag_value,
                progress_callback=heartbeat.update,
                recommendation=recommendation,
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
            )
        elapsed_ms = int(max(0.0, time.time() - t0) * 1000.0)
        self._log_support_send_event('support_send_finish', {
            'operation_id': op_id,
            'send_type': 'system_health',
            'phase': 'finish',
            'status': 'ok' if ok else 'failed',
            'duration_ms': elapsed_ms,
            'send_source': str(send_source or 'manual_system_health_pack'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
            'result_message': str(msg or ''),
        })
        if msg:
            print(msg)
        runbook_lines = data.get('pre_send_runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Pre-send runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()
        return bool(ok)

    def _operator_support_send_rec(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return {}
        try:
            rec = cr.compute_operator_support_send_recommendation(
                self.repo_root, self._env_flag_value)
            return rec if isinstance(rec, dict) else {}
        except Exception:
            return {}

    def _print_operator_send_why(self):
        rec = self._operator_support_send_rec()
        if not rec:
            print('Recommendation unavailable.')
            return
        line = rec.get('summary_line', '')
        if line:
            print(line)
        for w in rec.get('why_lines', []) or []:
            w = str(w or '').strip()
            if w:
                print(' - {0}'.format(w))
        hist_skip = str(rec.get('historical_reprocess_not_triggered_reason', '') or '').strip()
        dat_skip = str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip()
        qa_full_block_skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '').strip()
        if hist_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'historical_phase_d_reprocess':
            print(' - historical_reprocess_not_triggered_reason={0}'.format(hist_skip))
        if dat_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            print(' - dat_smoke_not_triggered_reason={0}'.format(dat_skip))
        if qa_full_block_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'review_dat_qa_full_block':
            print(' - dat_qa_full_block_not_triggered_reason={0}'.format(qa_full_block_skip))
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'historical_phase_d_reprocess':
            print(' - targeted_artifact_classes={0}'.format(','.join(self._recommended_artifact_classes(rec)) or '-'))
            print(' - qa_policy_version={0}'.format(str(preview.get('qa_policy_version', '') or '-')))
            print(' - latest_phase_c_inserted_count={0}'.format(int(preview.get('latest_phase_c_inserted_count', 0) or 0)))
            print(' - latest_phase_c_skipped_count={0}'.format(int(preview.get('latest_phase_c_skipped_count', 0) or 0)))
            print(' - latest_phase_d_rows_selected={0}'.format(int(preview.get('latest_phase_d_rows_selected', 0) or 0)))
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'phase_d_dat_smoke':
            print(' - anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
            print(' - phase_d_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')))
            print(' - strict_milestone_verdict={0}'.format(str(preview.get('strict_milestone_verdict', '') or '-')))
            print(' - reference_phase_d_summary_path={0}'.format(str(preview.get('reference_phase_d_summary_path', '') or '-')))
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'review_dat_qa_full_block':
            print(' - anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
            print(' - anchored_diagnosis_source={0}'.format(str(preview.get('anchored_diagnosis_source', '') or '-')))
            print(' - smoke_source_accepted={0}'.format(bool(preview.get('smoke_source_accepted'))))
            print(' - ignored_smoke_mismatch={0}'.format(bool(preview.get('ignored_smoke_mismatch'))))
            sak = str(preview.get('smoke_anchor_run_id', '') or '').strip()
            if sak:
                print(' - smoke_anchor_run_id={0}'.format(sak))
            smn = str(preview.get('source_mismatch_note', '') or '').strip()
            if smn:
                print(' - source_mismatch_note={0}'.format(smn))
            print(' - dat_selected_count={0}'.format(int(preview.get('dat_selected_count', 0) or 0)))
            print(' - dat_qa_pass_count={0}'.format(int(preview.get('dat_qa_pass_count', 0) or 0)))
            print(' - dat_qa_reject_count={0}'.format(int(preview.get('dat_qa_reject_count', 0) or 0)))
            print(' - dat_canonical_record_count={0}'.format(int(preview.get('dat_canonical_record_count', 0) or 0)))
            print(' - phase_d_summary_path={0}'.format(str(preview.get('phase_d_summary_path', '') or '-')))
            print(' - qa_reject_samples_path={0}'.format(str(preview.get('qa_reject_samples_path', '') or '-')))
            srp = str(preview.get('smoke_report_path', '') or '').strip()
            if bool(preview.get('ignored_smoke_mismatch')):
                print(' - ignored_smoke_report_path={0}'.format(srp or '-'))
                if srp:
                    print(' - (ignore this smoke report for anchored review unless its report JSON anchor matches the reviewed run.)')
            else:
                print(' - smoke_report_path={0}'.format(srp or '-'))
                if srp:
                    print(' - (smoke reports use the filename written under phase_d_dat_smoke_lab/reports/, often keyed by the smoke pipeline run id or anchor id from the report JSON.)')

    def _support_send_type_label(self, primary_send):
        p = str(primary_send or '').strip()
        if p == 'run_evidence':
            return 'run evidence bundle (B..F)'
        if p == 'system_health':
            return 'System Health Pack'
        return p or '(unknown)'

    def _recommended_artifact_classes(self, rec):
        classes = rec.get('recommended_artifact_classes', []) if isinstance(rec, dict) else []
        if not isinstance(classes, list):
            return []
        out = []
        for item in classes:
            text = str(item or '').strip().lower()
            if text and text not in out:
                out.append(text)
        return out

    def _recommended_action_label(self, action_kind, rec, send_type=''):
        kind = str(action_kind or 'send_bundle').strip()
        if kind == 'historical_phase_d_reprocess':
            classes = self._recommended_artifact_classes(rec)
            label = ', '.join(classes) if classes else 'targeted classes'
            return 'historical Phase D re-evaluation ({0})'.format(label)
        if kind == 'phase_d_dat_smoke':
            preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or '').strip()
            if anchor:
                return 'Phase D DAT smoke (anchor {0})'.format(anchor)
            return 'Phase D DAT smoke'
        if kind == 'review_dat_qa_full_block':
            preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or '').strip()
            if anchor:
                return 'anchored run evidence bundle for DAT QA full-block (anchor {0})'.format(anchor)
            return 'anchored run evidence bundle for DAT QA full-block'
        if kind == 'wait_for_stable':
            stable_kind = str(
                rec.get('preferred_when_stable_action_kind')
                or rec.get('recommended_action_kind')
                or 'send_bundle'
            ).strip()
            if stable_kind == 'wait_for_stable':
                return 'wait for stable pipeline state'
            return 'wait for stable pipeline state, then {0}'.format(
                self._recommended_action_label(stable_kind, rec, send_type=send_type)
            )
        return self._support_send_type_label(send_type or rec.get('best_now_send') or rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health')

    def _print_historical_phase_d_reprocess_preview(self, data):
        preview = data if isinstance(data, dict) else {}
        print('Historical Phase D re-evaluation preview:')
        print(' - targeted_artifact_classes={0}'.format(','.join(self._recommended_artifact_classes({'recommended_artifact_classes': preview.get('targeted_artifact_classes', [])})) or '-'))
        print(' - qa_policy_version={0}'.format(str(preview.get('qa_version', '') or '-')))
        print(' - targeted_artifact_count={0}'.format(int(preview.get('targeted_artifact_count', 0) or 0)))
        reject_counts = preview.get('reject_counts_by_class', {}) if isinstance(preview.get('reject_counts_by_class', {}), dict) else {}
        if reject_counts:
            parts = []
            for key in sorted(reject_counts):
                try:
                    value = int(reject_counts.get(key, 0) or 0)
                except Exception:
                    value = 0
                if value > 0:
                    parts.append('{0}:{1}'.format(key, value))
            print(' - reject_counts_by_class={0}'.format(', '.join(parts) if parts else 'none'))
        pending_counts = preview.get('pending_replay_counts_by_class', {}) if isinstance(preview.get('pending_replay_counts_by_class', {}), dict) else {}
        if pending_counts:
            parts = []
            for key in sorted(pending_counts):
                try:
                    value = int(pending_counts.get(key, 0) or 0)
                except Exception:
                    value = 0
                if value > 0:
                    parts.append('{0}:{1}'.format(key, value))
            print(' - pending_replay_counts_by_class={0}'.format(', '.join(parts) if parts else 'none'))
        report_path = str(preview.get('report_path', '') or '').strip()
        if report_path:
            print(' - preview_report={0}'.format(report_path))

    def _run_historical_phase_d_reprocess_action(self, rec, confirm_prompt=True):
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        classes = self._recommended_artifact_classes(rec)
        ctx_rid = ''
        if isinstance(rec, dict):
            ctx_rid = str(rec.get('recommendation_anchor_run_id') or rec.get('run_id') or '').strip()
        with _console_activity_heartbeat('historical Phase D re-evaluation: preview'):
            ok_preview, msg_preview, preview = cr.preview_historical_phase_d_reprocess(
                self.repo_root,
                artifact_classes=classes,
                remediation_context_run_id=ctx_rid or None,
            )
        if msg_preview:
            print(msg_preview)
        if preview:
            self._print_historical_phase_d_reprocess_preview(preview)
        if not ok_preview:
            return False
        if confirm_prompt:
            confirm = (self._prompt('Proceed with historical Phase D re-evaluation? [y/N]: ') or 'n').strip().lower()
            if confirm not in ('y', 'yes'):
                print('Cancelled.')
                return False
        else:
            print('Auto-follow-through: proceeding with historical Phase D re-evaluation without prompt.')
        with _console_activity_heartbeat('historical Phase D re-evaluation: reset + Phase D launch') as heartbeat:
            ok_run, msg_run, data = cr.run_historical_phase_d_reprocess(
                self.repo_root,
                self.python_exe,
                self.environment,
                artifact_classes=classes,
                remediation_context_run_id=ctx_rid or None,
            )
        if msg_run:
            print(msg_run)
        if isinstance(data, dict):
            report_path = str(data.get('execution_report_path', '') or '').strip()
            if report_path:
                print('Execution report: {0}'.format(report_path))
        return bool(ok_run)

    def _dat_smoke_target_from_rec(self, rec):
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        rem = rec.get('phase_d_remediation') if isinstance(rec.get('phase_d_remediation'), dict) else {}
        anchor = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        context = str(preview.get('phase_d_context_run_id') or anchor or '').strip()
        issue_code = str(
            preview.get('remediation_issue_code')
            or rem.get('issue_code')
            or ''
        ).strip()
        ref_path = str(preview.get('reference_phase_d_summary_path', '') or '').strip()
        return anchor, context, issue_code, ref_path

    def _run_phase_d_dat_smoke_action(self, rec, announce_prefix=''):
        anchor, context, issue_code, ref_path = self._dat_smoke_target_from_rec(rec if isinstance(rec, dict) else {})
        if announce_prefix:
            print(str(announce_prefix))
        if self._run_phase_d_dat_smoke(
                reference_phase_d_summary_path=ref_path,
                anchor_run_id=anchor,
                context_run_id=context,
                issue_code=issue_code):
            return True
        return False

    def _review_dat_qa_full_block_action(self, rec, operator_execution_mode='follow_recommendation', pause_for_ack=True):
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        anchor_run_id = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        if anchor_run_id:
            print('Sending anchored run evidence bundle for DAT QA full-block (anchor {0})...'.format(anchor_run_id))
        else:
            print('Sending anchored run evidence bundle for DAT QA full-block...')
        print('QA summary, reject samples, shadow report, and embedded closure context will be attached automatically.')
        ok_send = bool(self._send_bundle_for_operator_type(
            'run_evidence',
            recommendation=rec,
            operator_execution_mode=operator_execution_mode,
            source='cloud_readiness_follow_recommendation',
            priority='high',
            pause_for_ack=pause_for_ack,
            send_source_override='follow_rec_deferred_dat_qa_full_block'
            if operator_execution_mode == 'follow_recommendation_deferred'
            else 'follow_rec_dat_qa_full_block',
        ))
        if ok_send:
            return True
        print('Run-evidence send did not complete; opening latest artifact triage pack for context.')
        self._open_latest_artifact_triage_pack()
        return False

    def _queue_phase_d_dat_smoke_deferred(self, rec, reason='pipeline_running'):
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        anchor, context, issue_code, ref_path = self._dat_smoke_target_from_rec(rec if isinstance(rec, dict) else {})
        return bool(cr.write_operator_deferred_phase_d_dat_smoke(
            self.repo_root,
            anchor,
            context,
            issue_code=issue_code,
            reference_phase_d_summary_path=ref_path,
            reason=reason,
        ))

    def _try_deferred_phase_d_dat_smoke(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        intent = cr.read_operator_deferred_phase_d_dat_smoke(self.repo_root)
        if not isinstance(intent, dict):
            return
        running, _ = cr.check_pipeline_running_for_action(self.repo_root, 'Deferred Phase D DAT smoke')
        if running:
            return
        rec = self._operator_support_send_rec()
        if not isinstance(rec, dict):
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        if str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        live_anchor, live_context, live_issue, _live_ref = self._dat_smoke_target_from_rec(rec)
        stale = (
            str(intent.get('anchor_run_id', '') or '').strip() != live_anchor
            or str(intent.get('context_run_id', '') or '').strip() != live_context
            or str(intent.get('issue_code', '') or '').strip() != live_issue
        )
        if stale:
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        if self._run_phase_d_dat_smoke_action(rec, announce_prefix='Auto-starting deferred DAT smoke...'):
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)

    def _maybe_autorun_phase_d_dat_smoke(self, rec):
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        if not isinstance(rec, dict):
            return
        if str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            return
        if bool(rec.get('pipeline_running')):
            # Queue one-shot deferred smoke while pipeline is active.
            self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running')
            return
        anchor, context, issue_code, _ref = self._dat_smoke_target_from_rec(rec)
        if not anchor or not context:
            return
        target_key = '{0}|{1}|{2}'.format(anchor, context, issue_code)
        attempted = str(getattr(self, '_dat_smoke_autorun_target_attempted', '') or '').strip()
        if attempted == target_key:
            return
        setattr(self, '_dat_smoke_autorun_target_attempted', target_key)
        state = cr.read_phase_d_dat_smoke_state(self.repo_root)
        if isinstance(state, dict):
            same = (
                str(state.get('last_requested_anchor_run_id', '') or '').strip() == anchor
                and str(state.get('last_requested_context_run_id', '') or '').strip() == context
                and str(state.get('last_remediation_issue_code', '') or '').strip() == issue_code
            )
            if same:
                status = str(state.get('last_status', '') or '').strip().lower()
                if status in ('running', 'started'):
                    return
                cooldown = str(state.get('cooldown_until_utc', '') or '').strip()
                if cooldown:
                    try:
                        from calendar import timegm
                        from datetime import datetime
                        until_epoch = timegm(datetime.strptime(cooldown, '%Y-%m-%dT%H:%M:%SZ').timetuple())
                    except Exception:
                        until_epoch = 0
                    if until_epoch and until_epoch > time.time():
                        return
        if self._run_phase_d_dat_smoke_action(
                rec,
                announce_prefix='DAT smoke auto-started from current recommendation.'):
            # Clear stale deferred intent after successful auto-start for same target.
            intent = cr.read_operator_deferred_phase_d_dat_smoke(self.repo_root)
            if isinstance(intent, dict):
                same = (
                    str(intent.get('anchor_run_id', '') or '').strip() == anchor
                    and str(intent.get('context_run_id', '') or '').strip() == context
                    and str(intent.get('issue_code', '') or '').strip() == issue_code
                )
                if same:
                    cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)

    def _print_health_reporting_status(self, rec):
        """Compact status for Health & Reporting (uses compute_operator_support_send_recommendation)."""
        if not isinstance(rec, dict):
            return
        pipe = str(rec.get('pipeline_label', '') or ('running' if rec.get('pipeline_running') else 'idle'))
        run_disp = str(rec.get('run_id', '') or '').strip() or '-'
        pws = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if pws not in ('run_evidence', 'system_health'):
            pws = 'system_health'
        bns = str(rec.get('best_now_send') or pws).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = pws
        best_now_action = str(rec.get('best_now_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        stable_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        why = str(rec.get('why_summary', '') or '').strip() or '-'
        print('Health & Reporting - Status:')
        print('  Pipeline: {0}'.format(pipe))
        print('  Current run: {0}'.format(run_disp))
        print('  Best now: {0}'.format(self._recommended_action_label(best_now_action, rec, send_type=bns)))
        print('  Best after stable: {0}'.format(self._recommended_action_label(stable_action, rec, send_type=pws)))
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        if report_kind:
            print('  Recommended report: {0}'.format(report_kind))
        print('  Why: {0}'.format(why))
        print('')

    def _support_send_job_manager(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return None
        try:
            from MediCafe import support_send_jobs
        except Exception:
            return None
        lab_root = cr.resolve_lab_root(self.repo_root)
        cache = getattr(self, '_support_send_job_manager_cache', None)
        if isinstance(cache, dict):
            if cache.get('lab_root') == lab_root and cache.get('manager') is not None:
                return cache.get('manager')

        def _manager_logger(line):
            self._log_support_send_event('support_send_manager', {'result_message': str(line or '')})

        manager = support_send_jobs.SupportSendJobManager(
            repo_root=self.repo_root,
            lab_root=lab_root,
            logger_fn=_manager_logger,
            python_exe=getattr(self, 'python_exe', ''),
        )
        setattr(self, '_support_send_job_manager_cache', {'lab_root': lab_root, 'manager': manager})
        return manager

    def _background_support_send_jobs(self, limit=30):
        manager = self._support_send_job_manager()
        if manager is None:
            return []
        try:
            jobs = manager.list_jobs(limit=limit)
        except Exception:
            return []
        return jobs if isinstance(jobs, list) else []

    def _active_background_support_send_jobs(self, limit=30):
        active = []
        for row in self._background_support_send_jobs(limit=limit):
            if not isinstance(row, dict):
                continue
            status = str(row.get('status', '') or '').strip()
            if status in ('queued', 'running'):
                active.append(row)
        return active

    def _latest_finished_background_support_send_job(self, limit=30):
        for row in self._background_support_send_jobs(limit=limit):
            if not isinstance(row, dict):
                continue
            status = str(row.get('status', '') or '').strip()
            if status not in ('succeeded', 'failed', 'canceled', 'blocked'):
                continue
            if str(row.get('finished_at_utc', '') or '').strip():
                return row
        return None

    def _print_background_support_send_status_banner(self):
        active = self._active_background_support_send_jobs(limit=30)
        if not active and getattr(self, '_cloud_update_followthrough_guard', False):
            self._cloud_update_followthrough_guard = False
        if not active:
            return False
        latest = active[0]
        job_id = str(latest.get('job_id', '') or '-')
        status = str(latest.get('status', '') or '-')
        stage = str(latest.get('progress_stage', '') or '-')
        print('')
        print('[BACKGROUND CLOUD JOB ACTIVE] Keep MediCafe open until completion.')
        print('  Job: {0} status={1} stage={2}'.format(job_id, status, stage))
        if len(active) > 1:
            print('  Additional active jobs: {0}'.format(len(active) - 1))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        return True

    def _confirm_exit_with_active_support_send_jobs(self):
        active = self._active_background_support_send_jobs(limit=30)
        if not active:
            if getattr(self, '_cloud_update_followthrough_guard', False):
                self._cloud_update_followthrough_guard = False
            return True
        if self._is_cloud_followthrough_guard_active():
            latest = active[0]
            job_id = str(latest.get('job_id', '') or '-')
            status = str(latest.get('status', '') or '-')
            stage = str(latest.get('progress_stage', '') or '-')
            print('')
            print('[BLOCKED] Cloud follow-through is still running.')
            print('  Exit is disabled until the cloud recommended action finishes.')
            print('  Job: {0} status={1} stage={2}'.format(job_id, status, stage))
            print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
            print('')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass
            return False
        latest = active[0]
        job_id = str(latest.get('job_id', '') or '-')
        status = str(latest.get('status', '') or '-')
        stage = str(latest.get('progress_stage', '') or '-')
        print('')
        print('[WARNING] Background cloud job still active.')
        print('  Closing MediCafe now may interrupt evidence delivery.')
        print('  Job: {0} status={1} stage={2}'.format(job_id, status, stage))
        if len(active) > 1:
            print('  Additional active jobs: {0}'.format(len(active) - 1))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        try:
            choice = (self._prompt('Type YES to exit anyway, or press Enter to keep MediCafe open: ') or '').strip()
        except Exception:
            choice = ''
        if choice == 'YES':
            return True
        print('Exit canceled. Keep MediCafe open until the background cloud job finishes.')
        try:
            self._prompt('Press Enter to return to menu...')
        except Exception:
            pass
        return False

    def _is_cloud_followthrough_guard_active(self):
        """True when launcher auto-follow-through is active and a support-send job is still running."""
        if not getattr(self, '_cloud_update_followthrough_guard', False):
            return False
        return bool(self._active_background_support_send_jobs(limit=30))

    def _recommendation_execution_plan(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        preferred_action = str(
            rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or 'send_bundle'
        ).strip()
        unstable = bool(rec.get('pipeline_running'))
        preferred_send = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if preferred_send not in ('run_evidence', 'system_health'):
            preferred_send = 'system_health'
        best_now_send = str(rec.get('best_now_send') or preferred_send).strip()
        if best_now_send not in ('run_evidence', 'system_health'):
            best_now_send = preferred_send
        return {
            'preferred_action': preferred_action,
            'unstable': unstable,
            'preferred_send': preferred_send,
            'best_now_send': best_now_send,
            'artifact_classes': self._recommended_artifact_classes(rec),
            'report_kind': str(rec.get('recommended_report_kind', '') or '').strip(),
        }

    def _start_cloud_recommendation_followthrough(self, trigger='launcher'):
        """
        Auto-follow Cloud Readiness recommendation without manual menu navigation.
        Returns True when a run/send/defer action was accepted.
        """
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        rec = self._operator_support_send_rec()
        if not isinstance(rec, dict) or not rec:
            return False
        plan = self._recommendation_execution_plan(rec)
        preferred_action = plan['preferred_action']
        unstable = plan['unstable']
        pws = plan['preferred_send']
        bns = plan['best_now_send']
        classes = plan['artifact_classes']
        report_kind = plan['report_kind']

        print('')
        print('[AUTO CLOUD] Follow-through triggered ({0}).'.format(str(trigger or 'launcher')))
        summary = str(rec.get('summary_line', '') or '').strip()
        if summary:
            print('  {0}'.format(summary))
        print('  Status updates appear in menu banners and Cloud Readiness background jobs.')
        self._log_support_send_event('auto_followthrough_start', {
            'trigger': str(trigger or 'launcher'),
            'preferred_action': preferred_action,
            'unstable': unstable,
            'preferred_send': pws,
            'best_now_send': bns,
        })

        started = False
        if unstable and preferred_action == 'phase_d_dat_smoke':
            started = bool(self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running'))
        elif unstable and preferred_action in ('historical_phase_d_reprocess', 'review_dat_qa_full_block'):
            started = bool(cr.write_operator_deferred_support_send(
                self.repo_root,
                pws,
                'pipeline_running',
                action_kind=preferred_action,
                artifact_classes=classes,
                recommended_report_kind=report_kind,
            ))
        elif unstable:
            started = bool(self._send_bundle_for_operator_type(
                bns,
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='launcher_update_autofollow',
                priority='high',
                pause_for_ack=False,
            ))
        elif preferred_action == 'historical_phase_d_reprocess':
            started = bool(self._run_historical_phase_d_reprocess_action(rec, confirm_prompt=False))
        elif preferred_action == 'phase_d_dat_smoke':
            started = bool(self._run_phase_d_dat_smoke_action(
                rec, announce_prefix='Starting DAT smoke (diagnostic, non-blocking)...'))
        elif preferred_action == 'review_dat_qa_full_block':
            started = bool(self._review_dat_qa_full_block_action(
                rec, operator_execution_mode='follow_recommendation_deferred', pause_for_ack=False))
        else:
            started = bool(self._send_bundle_for_operator_type(
                pws,
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='launcher_update_autofollow',
                priority='high',
                pause_for_ack=False,
            ))
        self._log_support_send_event('auto_followthrough_finish', {
            'trigger': str(trigger or 'launcher'),
            'preferred_action': preferred_action,
            'unstable': unstable,
            'started': started,
        })
        return started

    def _normalize_recommendation_for_send_job(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        if not rec:
            return {}
        normalized = {}
        for key in (
                'recommended_action_kind',
                'preferred_when_stable_action_kind',
                'best_now_action_kind',
                'recommended_report_kind',
                'recommendation_source_scope',
                'recommendation_anchor_run_id',
                'recommendation_live_run_id',
                'recommendation_live_run_status',
                'summary_line'):
            if key in rec:
                normalized[key] = rec.get(key)
        preview = rec.get('action_preview', {})
        if isinstance(preview, dict):
            normalized['action_preview'] = dict(preview)
        rem = rec.get('phase_d_remediation', {})
        if isinstance(rem, dict):
            normalized['phase_d_remediation'] = dict(rem)
        return normalized

    def _send_job_anchor_context_issue(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        rem = rec.get('phase_d_remediation', {}) if isinstance(rec.get('phase_d_remediation', {}), dict) else {}
        anchor = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        context = str(
            preview.get('phase_d_context_run_id')
            or rec.get('recommendation_live_run_id')
            or anchor
            or ''
        ).strip()
        issue_code = str(
            preview.get('remediation_issue_code')
            or rem.get('issue_code')
            or ''
        ).strip()
        return anchor, context, issue_code

    def _try_enqueue_support_send(self, send_type, recommendation=None, source='cloud_readiness_follow_recommendation', operator_execution_mode='follow_recommendation', priority='high', pause_for_ack=True):
        manager = self._support_send_job_manager()
        if manager is None:
            print('Background cloud jobs unavailable (support send queue could not be initialized).')
            return {'handled': True, 'ok': False}
        rec = recommendation if isinstance(recommendation, dict) else {}
        anchor, context, issue_code = self._send_job_anchor_context_issue(rec)
        scope = str(rec.get('recommendation_source_scope', '') or 'latest_live_snapshot').strip()
        result = manager.enqueue({
            'source': str(source or 'cloud_readiness_follow_recommendation'),
            'priority': str(priority or 'high'),
            'send_type': str(send_type or ''),
            'anchor_run_id': anchor,
            'context_run_id': context,
            'issue_code': issue_code,
            'requested_artifact_scope': scope,
            'source_scope_hash': '{0}|{1}|{2}'.format(str(source or ''), str(operator_execution_mode or ''), scope),
            'frozen_recommendation': self._normalize_recommendation_for_send_job(rec),
        })
        if not bool(result.get('accepted')):
            msg = str(result.get('message', '') or 'Unable to schedule background support send.')
            print(msg)
            return {'handled': True, 'ok': False}
        job_id = str(result.get('job_id', '') or '').strip() or '-'
        print('Background cloud job accepted: {0}'.format(job_id))
        print('Policy: {0} ({1})'.format(
            str(result.get('policy_decision', '') or '-'),
            str(result.get('policy_reason', '') or '-'),
        ))
        print('Keep MediCafe open until this job finishes.')
        print('Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('Completion will appear on the next MediCafe menu refresh.')
        if pause_for_ack:
            try:
                self._prompt('Press Enter to continue...')
            except Exception:
                pass
        return {'handled': True, 'ok': True}

    def _send_bundle_for_operator_type(
            self,
            send_type,
            recommendation=None,
            operator_execution_mode='follow_recommendation',
            source='cloud_readiness_follow_recommendation',
            priority='high',
            pause_for_ack=True,
            send_source_override=''):
        """Queue run_evidence or system_health send; returns True if the job was accepted.

        send_source_override is kept for call-site compatibility; execution uses the job
        worker and frozen recommendation context.
        """
        _ = send_source_override
        st = str(send_type or '').strip()
        if st == 'run_evidence':
            self._maybe_warn_pipeline_running('Send latest run evidence bundle')
            enqueue = self._try_enqueue_support_send(
                'run_evidence',
                recommendation=recommendation,
                source=source,
                operator_execution_mode=operator_execution_mode,
                priority=priority,
                pause_for_ack=pause_for_ack,
            )
            return bool(enqueue.get('ok'))
        cr = self._cloud_readiness_service()
        if cr is not None:
            _, warn_msg = cr.check_pipeline_running_for_action(self.repo_root, 'Send System Health Pack')
            if warn_msg:
                print(warn_msg)
        enqueue = self._try_enqueue_support_send(
            'system_health',
            recommendation=recommendation,
            source=source,
            operator_execution_mode=operator_execution_mode,
            priority=priority,
            pause_for_ack=pause_for_ack,
        )
        return bool(enqueue.get('ok'))

    def _offer_explicit_sends_after_failure(self):
        ans = (self._prompt('Open explicit send and phase tools menu? [y/N]: ') or 'n').strip().lower()
        if ans in ('y', 'yes'):
            self._cloud_other_support_sends_menu()

    def _follow_recommendation_flow(self):
        """Single guided path: send now, defer, why, package override, historical re-eval, or DAT smoke."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        rec = self._operator_support_send_rec()
        if not rec:
            print('Recommendation unavailable.')
            return
        pws = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if pws not in ('run_evidence', 'system_health'):
            pws = 'system_health'
        bns = str(rec.get('best_now_send') or pws).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = pws
        summary = rec.get('summary_line', '')
        if summary:
            print(summary)
        unstable = bool(rec.get('pipeline_running'))
        preferred_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        best_now_action = str(rec.get('best_now_action_kind', '') or preferred_action or 'send_bundle').strip()
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        classes = self._recommended_artifact_classes(rec)

        while True:
            print('')
            if unstable and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
                print('Follow recommendation (pipeline active):')
                if preferred_action == 'review_dat_qa_full_block':
                    print('  1) Remind me when stable (then send {0})'.format(
                        self._recommended_action_label(preferred_action, rec, send_type=pws)))
                else:
                    print('  1) Remind me when stable (then run {0})'.format(
                        self._recommended_action_label(preferred_action, rec, send_type=pws)))
                print('  2) Send best available now ({0})'.format(self._support_send_type_label(bns)))
                print('  3) Show why')
                print('  4) Choose a different package')
                print('  0) Back')
            elif unstable:
                print('Follow recommendation (pipeline active):')
                print('  1) Send best available now ({0})'.format(self._support_send_type_label(bns)))
                print('  2) Remind me when stable (then send preferred after idle)')
                print('  3) Show why')
                print('  4) Choose a different package')
                print('  0) Back')
            elif preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
                print('Follow recommendation:')
                if preferred_action == 'review_dat_qa_full_block':
                    print('  1) Send {0}'.format(self._recommended_action_label(preferred_action, rec, send_type=pws)))
                else:
                    print('  1) Run {0}'.format(self._recommended_action_label(preferred_action, rec, send_type=pws)))
                print('  2) Show why')
                print('  3) Choose a different package')
                print('  0) Back')
            else:
                print('Follow recommendation:')
                print('  1) Send now ({0})'.format(self._support_send_type_label(pws)))
                print('  2) Show why')
                print('  3) Choose a different package')
                print('  0) Back')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            if unstable and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
                if choice == '1':
                    if preferred_action == 'phase_d_dat_smoke':
                        if self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running'):
                            print('Saved. Open Cloud Readiness again after the pipeline idles to auto-run DAT smoke.')
                        else:
                            print('Could not save reminder.')
                    else:
                        if cr.write_operator_deferred_support_send(
                                self.repo_root,
                                pws,
                                'pipeline_running',
                                action_kind=preferred_action,
                                artifact_classes=classes,
                                recommended_report_kind=report_kind):
                            if preferred_action == 'review_dat_qa_full_block':
                                print('Saved. Open Cloud Readiness again after the pipeline idles to send the anchored DAT QA full-block run evidence bundle.')
                            else:
                                print('Saved. Open Cloud Readiness again after the pipeline idles to run the historical Phase D re-evaluation.')
                        else:
                            print('Could not save reminder.')
                    return
                if choice == '2':
                    ok_send = self._send_bundle_for_operator_type(bns, recommendation=rec, operator_execution_mode='follow_recommendation')
                    if not ok_send:
                        self._offer_explicit_sends_after_failure()
                    return
                if choice == '3':
                    self._print_operator_send_why()
                    continue
                if choice == '4':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if unstable:
                if choice == '1':
                    ok_send = self._send_bundle_for_operator_type(bns, recommendation=rec, operator_execution_mode='follow_recommendation')
                    if not ok_send:
                        self._offer_explicit_sends_after_failure()
                    return
                if choice == '2':
                    if cr.write_operator_deferred_support_send(
                            self.repo_root,
                            pws,
                            'pipeline_running',
                            action_kind=preferred_action,
                            artifact_classes=classes,
                            recommended_report_kind=report_kind):
                        print('Saved. Open Cloud Readiness again after the pipeline idles to follow the current recommendation.')
                    else:
                        print('Could not save reminder.')
                    return
                if choice == '3':
                    self._print_operator_send_why()
                    continue
                if choice == '4':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
                if choice == '1':
                    if preferred_action == 'phase_d_dat_smoke':
                        ok_action = self._run_phase_d_dat_smoke_action(
                            rec, announce_prefix='Starting DAT smoke (diagnostic, non-blocking)...'
                        )
                    elif preferred_action == 'review_dat_qa_full_block':
                        ok_action = self._review_dat_qa_full_block_action(rec, operator_execution_mode='follow_recommendation')
                    else:
                        ok_action = self._run_historical_phase_d_reprocess_action(rec)
                    if ok_action:
                        cr.clear_operator_deferred_support_send(self.repo_root)
                        cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
                    return
                if choice == '2':
                    self._print_operator_send_why()
                    continue
                if choice == '3':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if choice == '1':
                ok_send = self._send_bundle_for_operator_type(pws, recommendation=rec, operator_execution_mode='follow_recommendation')
                if not ok_send:
                    self._offer_explicit_sends_after_failure()
                return
            if choice == '2':
                self._print_operator_send_why()
                continue
            if choice == '3':
                self._cloud_other_support_sends_menu()
                return
            print('Invalid choice.')

    def _cloud_investigate_patient_data_menu(self):
        while True:
            self._clear_console()
            self._print_legacy_banner('Investigate Patient / Data Issue', width=40)
            self._print_troubleshooting_group('Choose action', [
                '1) Guided completeness check',
                '2) Trace a patient flow',
                '3) DB / audit tools',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                print('Opening patient flow runbook (auto-populated list)...')
                self._open_patient_flow_runbook_for_id()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                self._cloud_db_inspection_menu()
            else:
                print('Invalid choice.')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _open_recommended_lab_report(self):
        """Open the report aligned with the current recommendation."""
        rec = self._operator_support_send_rec()
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        action_kind = str(
            rec.get('best_now_action_kind')
            or rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or ''
        ).strip()
        bns = str(
            rec.get('best_now_send')
            or rec.get('preferred_when_stable')
            or rec.get('primary_send')
            or 'system_health'
        ).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = 'system_health'
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        if report_kind == 'artifact_triage_pack' or bns == 'run_evidence':
            print('Opening latest artifact triage pack...')
            ok, msg, path = cr.open_latest_artifact_triage_pack(self.repo_root)
            if ok and path:
                print('Opening: {0}'.format(path))
                self._launch_viewer(path)
                return
            if msg:
                print(msg)
            print('Falling back to run artifact index...')
            self._open_latest_run_artifact_index()
            return
        print('Opening latest System Health Pack...')
        self._open_latest_system_health_pack()

    def _cloud_health_reporting_advanced_menu(self):
        """Power-user Health & Reporting actions (triage, explicit open, phase tools, sends)."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Advanced Tools (Health & Reporting)', width=40)
            self._print_troubleshooting_group('Choose action', [
                '1) Run System Health Triage now',
                '2) Open latest System Health Pack',
                '3) Open phase artifact tools',
                '4) Other support sends',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Running system health triage (audit + pack refresh)...')
                self._run_system_health_triage()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                print('Opening latest System Health Pack...')
                self._open_latest_system_health_pack()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                self._cloud_phase_artifacts_menu()
            elif choice == '4':
                self._cloud_other_support_sends_menu()
            else:
                print('Invalid choice.')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _try_print_background_support_send_notice(self):
        manager = self._support_send_job_manager()
        if manager is None:
            return
        latest = self._latest_finished_background_support_send_job(limit=30)
        if not isinstance(latest, dict):
            return
        finished = str(latest.get('finished_at_utc', '') or '').strip()
        if not finished:
            return
        state = manager.read_notice_state()
        seen = str(state.get('last_seen_finished_at_utc', '') or '').strip() if isinstance(state, dict) else ''
        if seen == finished:
            return
        print('[NOTICE] Background cloud job {0}: {1}'.format(
            str(latest.get('job_id', '') or '-'),
            str(latest.get('status', '') or '-'),
        ))
        msg = str(latest.get('result_message', '') or '').strip()
        if msg:
            print('         {0}'.format(msg))
        manager.write_notice_state({
            'last_seen_finished_at_utc': finished,
            'last_seen_job_id': str(latest.get('job_id', '') or ''),
        })

    def _background_cloud_jobs_menu(self):
        manager = self._support_send_job_manager()
        if manager is None:
            print('Background cloud jobs unavailable.')
            return
        while True:
            self._clear_console()
            self._print_legacy_banner('Background Cloud Jobs', width=40)
            jobs = manager.list_jobs(limit=20)
            if not jobs:
                print('No background jobs yet.')
            else:
                print('Recent jobs:')
                idx = 1
                for row in jobs:
                    jid = str(row.get('job_id', '') or '-')
                    status = str(row.get('status', '') or '-')
                    stage = str(row.get('progress_stage', '') or '-')
                    anchor = str(row.get('anchor_run_id', '') or '-')
                    hb = str(row.get('heartbeat_at_utc', '') or '-')
                    print(' {0}) {1} status={2} anchor={3}'.format(idx, jid, status, anchor))
                    print('    heartbeat={0} stage={1}'.format(hb, stage))
                    msg = str(row.get('result_message', '') or '').strip()
                    if msg:
                        print('    message={0}'.format(msg))
                    idx += 1
            print('')
            print('Actions')
            print(' O<n>) Open job log for item n   (example: O1)')
            print(' D<n>) Open delivery diagnostics path for item n')
            print(' R<n>) Retry item n')
            print(' 0) Back')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            if not choice:
                continue
            action = choice[:1].upper()
            idx_raw = choice[1:].strip()
            try:
                idx = int(idx_raw)
            except Exception:
                idx = -1
            if idx < 1 or idx > len(jobs):
                print('Invalid selection.')
                try:
                    self._prompt('Press Enter to continue...')
                except Exception:
                    pass
                continue
            row = jobs[idx - 1]
            job_id = str(row.get('job_id', '') or '').strip()
            if action == 'O':
                log_path = os.path.join(manager.jobs_dir, 'job_{0}.log'.format(job_id))
                if os.path.exists(log_path):
                    print('Opening: {0}'.format(log_path))
                    self._launch_viewer(log_path)
                else:
                    print('Log file not found.')
            elif action == 'D':
                delivery = str(row.get('delivery_status_path', '') or '').strip()
                if delivery and os.path.exists(delivery):
                    print('Opening: {0}'.format(delivery))
                    self._launch_viewer(delivery)
                else:
                    print('Delivery diagnostics path unavailable for this job.')
            elif action == 'R':
                res = manager.retry(job_id)
                if bool(res.get('accepted')):
                    print('Retry queued: {0}'.format(str(res.get('job_id', '') or '-')))
                else:
                    print(str(res.get('message', '') or 'Retry rejected.'))
            else:
                print('Invalid action.')
            try:
                self._prompt('Press Enter to continue...')
            except Exception:
                pass

    def _try_prompt_deferred_operator_send(self):
        """One-shot: if a deferred recommended action exists and pipeline is idle, offer to run it."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        intent = cr.read_operator_deferred_support_send(self.repo_root)
        if not intent:
            return
        running, _ = cr.check_pipeline_running_for_action(self.repo_root, 'Deferred recommended action')
        if running:
            return

        rec = self._operator_support_send_rec()
        fresh_send = str(
            (rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health')).strip()
        if fresh_send not in ('run_evidence', 'system_health'):
            fresh_send = 'system_health'
        stale_send = str(intent.get('primary_send', '') or '').strip()
        if stale_send not in ('run_evidence', 'system_health'):
            stale_send = 'system_health'
        fresh_action = str(
            rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or 'send_bundle'
        ).strip()
        stale_action = str(intent.get('action_kind', '') or 'send_bundle').strip()

        print('')
        print('A deferred support action is pending (pipeline is now idle).')
        if fresh_action != stale_action or fresh_send != stale_send:
            print('When you deferred, the suggested action was: {0}.'.format(
                self._recommended_action_label(stale_action, rec, send_type=stale_send)))
            summ = rec.get('summary_line', '')
            if summ:
                print('Current recommendation: {0}'.format(summ))
            else:
                print('Current recommendation: {0}.'.format(
                    self._recommended_action_label(fresh_action, rec, send_type=fresh_send)))
        else:
            print('Current recommendation: {0}.'.format(
                self._recommended_action_label(fresh_action, rec, send_type=fresh_send)))

        prompt = 'Run the current recommendation now? [Y/n]: '
        if fresh_action == 'send_bundle':
            prompt = 'Send using the current recommendation now? [Y/n]: '
        ans = (self._prompt(prompt) or 'y').strip().lower()
        if ans not in ('y', 'yes', ''):
            print('Skipped. The reminder will stay pending.')
            return

        ok_action = False
        if fresh_action == 'historical_phase_d_reprocess':
            ok_action = self._run_historical_phase_d_reprocess_action(rec)
        elif fresh_action == 'phase_d_dat_smoke':
            ok_action = self._run_phase_d_dat_smoke_action(
                rec, announce_prefix='Starting deferred DAT smoke (diagnostic, non-blocking)...'
            )
        elif fresh_action == 'review_dat_qa_full_block':
            ok_action = self._review_dat_qa_full_block_action(
                rec,
                operator_execution_mode='follow_recommendation_deferred',
            )
        elif fresh_send == 'run_evidence':
            self._maybe_warn_pipeline_running('Send latest run evidence bundle')
            ok_action = bool(self._send_bundle_for_operator_type(
                'run_evidence',
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='deferred_operator_send',
                priority='high',
            ))
        else:
            _, warn_msg = cr.check_pipeline_running_for_action(self.repo_root, 'Send System Health Pack')
            if warn_msg:
                print(warn_msg)
            ok_action = bool(self._send_bundle_for_operator_type(
                'system_health',
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='deferred_operator_send',
                priority='high',
            ))

        if ok_action:
            cr.clear_operator_deferred_support_send(self.repo_root)
        else:
            print('The deferred action did not complete successfully. The reminder will stay pending.')

    def _send_recommended_support_bundle(self):
        """Compatibility: same as Follow recommendation guided flow."""
        self._follow_recommendation_flow()

    def _cloud_other_support_sends_menu(self):
        """Explicit sends beyond the recommended default."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Other Support Sends', width=40)
            self._print_troubleshooting_group('Choose send', [
                '1) Send latest System Health Pack (broad audit + companions)',
                '2) Send latest run evidence bundle (coherent B..F)',
                '3) Open Cloud Phase Artifact tools (phase-specific evidence sends)',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                rec = self._operator_support_send_rec()
                cr = self._cloud_readiness_service()
                if cr is not None:
                    _, warn_msg = cr.check_pipeline_running_for_action(
                        self.repo_root, 'Send System Health Pack')
                    if warn_msg:
                        print(warn_msg)
                ok_send = self._send_bundle_for_operator_type(
                    'system_health',
                    recommendation=rec,
                    operator_execution_mode='explicit_send_menu',
                    source='other_support_sends_menu',
                    priority='normal',
                )
                if not ok_send:
                    print('System Health Pack send did not complete successfully.')
            elif choice == '2':
                rec = self._operator_support_send_rec()
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
                ok_send = self._send_bundle_for_operator_type(
                    'run_evidence',
                    recommendation=rec,
                    operator_execution_mode='explicit_send_menu',
                    source='other_support_sends_menu',
                    priority='normal',
                )
                if not ok_send:
                    print('Run evidence bundle send did not complete successfully.')
            elif choice == '3':
                self._cloud_phase_artifacts_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _print_runbook_block(self, heading, runbook_lines):
        """Print runbook lines while preserving headings and numbered actions."""
        if not runbook_lines:
            return
        print('')
        print(heading)
        for line in runbook_lines:
            line_text = str(line or '')
            stripped = line_text.strip()
            if not stripped:
                continue
            if line_text.startswith(' - ') or line_text.startswith('- '):
                print(line_text)
                continue
            is_numbered = False
            for idx in range(1, 10):
                if stripped.startswith('{0})'.format(idx)):
                    is_numbered = True
                    break
            if stripped.endswith(':'):
                print(stripped)
            elif is_numbered:
                print(' {0}'.format(stripped))
            else:
                print(' - {0}'.format(stripped))

    def _guided_patient_completeness_runbook(self):
        """Run guided letter-based patient completeness inspection with embedded runbook output."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('guided patient completeness: loading options'):
            ok, msg, data = cr.get_guided_patient_completeness_options(self.repo_root)
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        actions = data.get('actions', []) if isinstance(data, dict) else []
        if not ok:
            self._print_runbook_block('Guided runbook context:', runbook_lines)
            has_action_section = any(
                str(line or '').strip().lower() == 'what to do now:'
                for line in runbook_lines
            )
            if actions and not has_action_section:
                print('')
                print('What To Do Now:')
                step = 1
                for item in actions:
                    print(' {0}) {1}'.format(step, item))
                    step += 1
            return

        options = data.get('options', []) if isinstance(data, dict) else []
        self._print_runbook_block('Guided runbook context:', runbook_lines)
        if not options:
            print('No guided patient options available.')
            return

        print('')
        print('Guided patient completeness selections:')
        for item in options:
            code = str(item.get('code', '') or '').upper()
            title = item.get('title', '')
            display_id = item.get('display_id', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            reason = item.get('reason', '')
            run_id = item.get('context_run_id', '') or '-'
            print(' {0}) {1}'.format(code, title))
            print('    patient={0} risk={1} run_id={2}'.format(display_id, risk, run_id))
            print('    why={0}'.format(reason))
        print(' 0) Cancel')

        choice = (self._prompt('Select guided option: ') or '').strip().upper()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        print('Generating patient completeness runbook...')
        with _console_activity_heartbeat('guided patient completeness: generating runbook'):
            ok_open, msg_open, path = cr.open_guided_patient_completeness_runbook(
                self.repo_root, choice)
        if msg_open:
            print(msg_open)
        if ok_open and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)



    def _open_patient_flow_runbook_for_id(self):
        """Open patient flow runbook from auto-populated patient references."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('patient flow runbook: loading references'):
            ok_opts, msg_opts, data_opts = cr.get_patient_flow_reference_options(self.repo_root, limit=12)
        if msg_opts:
            print(msg_opts)
        if not ok_opts or not isinstance(data_opts, dict):
            runbook_lines = data_opts.get('runbook_lines', []) if isinstance(data_opts, dict) else []
            self._print_runbook_block('Patient flow context:', runbook_lines)
            return

        options = data_opts.get('options', []) if isinstance(data_opts.get('options', []), list) else []
        if not options:
            print('No patient flow options available.')
            return

        print('')
        print('Patient flow references (auto-populated):')
        for item in options:
            idx = item.get('index', '?')
            display_id = item.get('display_id', '-')
            ref = item.get('patient_ref', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            score = item.get('risk_score', 0)
            print(' {0}) patient={1} ref={2} risk={3} score={4}'.format(idx, display_id, ref, risk, score))
        print(' 0) Cancel')

        choice = (self._prompt('Select patient flow option: ') or '').strip()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        selected = None
        for item in options:
            if str(item.get('index', '')) == choice:
                selected = item
                break
        if not isinstance(selected, dict):
            print('Invalid selection.')
            return

        patient_ref = str(selected.get('patient_ref', '') or '').strip()
        print('Generating patient flow runbook for {0}...'.format(patient_ref))
        with _console_activity_heartbeat('patient flow runbook: generating'):
            ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _open_latest_artifact_triage_pack(self):
        """Open latest run-scoped artifact triage pack."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_artifact_triage_pack(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_latest_run_artifact_index(self):
        """Open latest run-scoped artifact index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_run_artifact_index(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_run_artifact_index_for_run_id(self, run_id):
        """Open run-scoped artifact index for explicit run ID."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_run_artifact_index_for_run_id(self.repo_root, run_id)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_latest_run_evidence_bundle(self, send_source='manual_run_evidence_bundle', operator_execution_mode='explicit_send_menu', frozen_recommendation=None):
        """Send latest coherent run evidence bundle across phases B..F. Returns True on send success."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        op_id = self._new_support_send_operation_id('run_evidence')
        t0 = time.time()
        has_recommendation = bool(isinstance(frozen_recommendation, dict) and frozen_recommendation)
        self._log_support_send_event('support_send_start', {
            'operation_id': op_id,
            'send_type': 'run_evidence',
            'phase': 'start',
            'status': 'running',
            'send_source': str(send_source or 'manual_run_evidence_bundle'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
        })
        with _console_activity_heartbeat('sending run evidence bundle: bundle + delivery') as heartbeat:
            ok, msg, data = cr.send_latest_run_evidence_bundle(
                self.repo_root,
                progress_callback=heartbeat.update,
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
                frozen_recommendation=frozen_recommendation if isinstance(frozen_recommendation, dict) else None,
            )
        elapsed_ms = int(max(0.0, time.time() - t0) * 1000.0)
        self._log_support_send_event('support_send_finish', {
            'operation_id': op_id,
            'send_type': 'run_evidence',
            'phase': 'finish',
            'status': 'ok' if ok else 'failed',
            'duration_ms': elapsed_ms,
            'send_source': str(send_source or 'manual_run_evidence_bundle'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
            'result_message': str(msg or ''),
        })
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Bundle runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()
        return bool(ok)

    def _cloud_readiness_advanced_menu(self):
        """Cloud Readiness & Advanced submenu with consolidated health-first actions."""
        cr = self._cloud_readiness_service()
        if cr is None:
            print('Cloud Readiness unavailable this session.')
            return
        bootstrap_ok, bootstrap_msg, _ = cr.ensure_lab_ready(
            self.repo_root, self.python_exe, self.environment, self._env_flag_value,
            skip_recent_success_autopipeline=True)
        first_loop = True
        deferred_prompt_done = False
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Readiness & Advanced Tools', width=40)
            if first_loop:
                print('Tip: Use 1) Follow recommendation for guided send/defer; 3) Open recommended lab report.')
                print('      S/W/O still work as shortcuts. Use Troubleshooting item 1 only for crash/incident bundles.')
            if first_loop and bootstrap_msg:
                level = 'WARNING' if not bootstrap_ok else 'INFO'
                print('[{0}] {1}'.format(level, bootstrap_msg))
            first_loop = False
            if not deferred_prompt_done:
                self._try_prompt_deferred_operator_send()
                self._try_deferred_phase_d_dat_smoke()
                deferred_prompt_done = True
            self._try_print_background_support_send_notice()
            self._print_background_support_send_status_banner()
            self._print_phase_f_status()
            print('')
            rec = self._operator_support_send_rec()
            self._maybe_autorun_phase_d_dat_smoke(rec)
            self._print_health_reporting_status(rec)
            self._print_troubleshooting_group('Health & Reporting', [
                '1)  Follow recommendation...',
                '2)  Investigate patient / data issue...',
                '3)  Open recommended lab report',
                '4)  Background cloud jobs...',
                '9)  Advanced tools (triage, explicit open, phase tools, sends)...',
                '     (aliases: S=follow  W=why  O=other sends)',
            ])
            self._print_troubleshooting_group('Manual Pipeline Control', [
                'A) Trigger full shadow pipeline (A->F, background)',
                'B) Trigger Phase B discovery (background)',
                'C) Trigger Phase C ingest (background)',
                'D) Trigger Phase D QA (background)',
                'E) Trigger Phase E projection/parity (background)',
                'M) Run DAT smoke (diagnostic; not milestone closure)',
                '     Report: see phase_d_dat_smoke_lab/reports/ after completion (filename from smoke run; check report JSON for paths).',
            ])
            print('Navigation')
            print(' 0)  Back to Troubleshooting menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            need_pause = False
            if choice_u == 'S' or choice == '1':
                self._follow_recommendation_flow()
            elif choice_u == 'W':
                self._print_operator_send_why()
                need_pause = True
            elif choice_u == 'O':
                self._cloud_other_support_sends_menu()
            elif choice == '2':
                self._cloud_investigate_patient_data_menu()
            elif choice == '3':
                self._open_recommended_lab_report()
                need_pause = True
            elif choice == '4':
                self._background_cloud_jobs_menu()
            elif choice_u == 'A':
                print('Triggering full shadow pipeline (non-blocking)...')
                if self._run_shadow_pipeline():
                    self._print_manual_pipeline_runbook('A')
                need_pause = True
            elif choice_u == 'B':
                print('Triggering manual discovery run (non-blocking)...')
                if self._run_phase_b_discovery_manual():
                    self._print_manual_pipeline_runbook('B')
                need_pause = True
            elif choice_u == 'C':
                print('Triggering manual Phase C ingest pass (non-blocking)...')
                if self._run_phase_c_ingest_manual():
                    self._print_manual_pipeline_runbook('C')
                need_pause = True
            elif choice_u == 'D':
                print('Triggering manual Phase D run (non-blocking)...')
                if self._run_phase_d_manual():
                    self._print_manual_pipeline_runbook('D')
                need_pause = True
            elif choice_u == 'E':
                print('Triggering manual Phase E run (non-blocking)...')
                if self._run_phase_e_manual():
                    self._print_manual_pipeline_runbook('E')
                need_pause = True
            elif choice_u == 'M':
                print('Starting DAT smoke (diagnostic, non-blocking)...')
                rec_now = rec if isinstance(rec, dict) else {}
                if str(rec_now.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke':
                    ok_smoke = self._run_phase_d_dat_smoke_action(rec_now)
                else:
                    ok_smoke = self._run_phase_d_dat_smoke()
                if ok_smoke:
                    print(
                        'When complete, open the report path printed by the smoke runner under phase_d_dat_smoke_lab/reports/ '
                        '(filename uses the smoke pipeline run id or anchor id from the generated report).'
                    )
                need_pause = True
            elif choice == '9':
                self._cloud_health_reporting_advanced_menu()
            else:
                print('Invalid choice.')
                need_pause = True
            if need_pause:
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _cloud_phase_artifacts_menu(self):
        """Run-centric artifact tools for latest coherent pipeline evidence."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Artifact Tools', width=40)
            self._print_troubleshooting_group('Run-Centric Artifact Workflow', [
                'A) Open latest Artifact Triage Pack',
                'B) Open latest run artifact index',
                'C) Send latest run evidence bundle',
                'D) Enter run ID and inspect artifact index',
            ])
            self._print_troubleshooting_group('Advanced', [
                'E) Phase-specific deep dive tools...',
                'F) Open report delivery diagnostics',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            elif choice_u == 'A':
                print('Opening latest artifact triage pack...')
                self._open_latest_artifact_triage_pack()
            elif choice_u == 'B':
                print('Opening latest run artifact index...')
                self._open_latest_run_artifact_index()
            elif choice_u == 'C':
                rec = self._operator_support_send_rec()
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
                ok_send = self._send_bundle_for_operator_type(
                    'run_evidence',
                    recommendation=rec,
                    operator_execution_mode='phase_artifact_tools',
                    source='phase_artifact_tools',
                    priority='normal',
                )
                if not ok_send:
                    print('Run evidence bundle send did not complete successfully.')
            elif choice_u == 'D':
                run_id = (self._prompt('Enter run ID to inspect: ') or '').strip()
                if not run_id:
                    print('Cancelled.')
                else:
                    print('Opening artifact index for run {0}...'.format(run_id))
                    self._open_run_artifact_index_for_run_id(run_id)
            elif choice_u == 'E':
                self._cloud_phase_deep_dive_menu()
            elif choice_u == 'F':
                print('Opening report delivery diagnostics...')
                self._open_report_delivery_status()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _print_deep_dive_action_runbook(self, action_key):
        """Print short runbook note for deep-dive phase action."""
        key = str(action_key or '').strip()
        print('')
        if key == '1':
            print('Runbook: Use discovery summary to confirm artifact classes/total before downstream phases.')
        elif key == '2':
            print('Runbook: Use manifest location when diagnosing ingest source selection/path drift.')
        elif key == '3':
            print('Runbook: Send B evidence when discovery outputs appear inconsistent or empty.')
        elif key == '4':
            print('Runbook: Use ingest summary to verify inserted/failed/anomaly counters.')
        elif key == '5':
            print('Runbook: Send C evidence when ingest counters or anomalies need external triage.')
        elif key == '6':
            print('Runbook: Use QA summary for pass/reject ratios and cutover quality checks.')
        elif key == '7':
            print('Runbook: Reject samples are for root-causing QA failures, not routine healthy runs.')
        elif key == '8':
            print('Runbook: Send D evidence when reject patterns need support analysis.')
        elif key == '9':
            print('Runbook: Projection summary confirms coverage and parity status.')
        elif key == '10':
            print('Runbook: Deviation samples explain projection/parity drifts in detail.')
        elif key == '11':
            print('Runbook: Send E evidence for parity/coverage escalation cases.')
        elif key == '12':
            print('Runbook: Phase F advanced is for packaging/index rebuild and strict run-id recovery.')

    def _cloud_phase_deep_dive_menu(self):
        """Deep-dive submenu for per-phase summary/sample/evidence files."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Deep Dive', width=40)
            self._print_troubleshooting_group('Phase B Discovery', [
                '1)  Open latest artifact discovery summary',
                '2)  Open latest manifest location',
                '3)  Send latest discovery evidence bundle',
            ])
            self._print_troubleshooting_group('Phase C Ingest', [
                '4)  Open latest Phase C summary',
                '5)  Send latest Phase C evidence bundle',
            ])
            self._print_troubleshooting_group('Phase D QA', [
                '6)  Open latest Phase D summary',
                '7)  Open latest Phase D reject sample file',
                '8)  Send Phase D evidence bundle',
            ])
            self._print_troubleshooting_group('Phase E Projection', [
                '9)  Open latest Phase E summary',
                '10) Open latest Phase E deviation sample file',
                '11) Send Phase E evidence bundle',
            ])
            self._print_troubleshooting_group('Phase F', [
                '12) Phase F advanced tools...',
            ])
            print('Navigation')
            print(' 0)  Back to Artifact Tools')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest artifact discovery summary...')
                self._open_phase_b_summary()
            elif choice == '2':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest manifest location...')
                self._open_phase_b_manifest_location()
            elif choice == '3':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase B evidence')
                print('Sending latest discovery evidence via support bundle...')
                self._send_phase_b_evidence()
            elif choice == '4':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase C summary...')
                self._open_phase_c_summary()
            elif choice == '5':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase C evidence')
                print('Sending latest Phase C evidence via support bundle...')
                self._send_phase_c_evidence()
            elif choice == '6':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase D summary...')
                self._open_phase_d_summary()
            elif choice == '7':
                self._print_deep_dive_action_runbook(choice)
                print('Opening reject sample file...')
                self._open_phase_d_reject_sample()
            elif choice == '8':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase D evidence')
                print('Sending Phase D evidence via support bundle...')
                self._send_phase_d_evidence()
            elif choice == '9':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase E summary...')
                self._open_phase_e_summary()
            elif choice == '10':
                self._print_deep_dive_action_runbook(choice)
                print('Opening deviation sample file...')
                self._open_phase_e_deviation_samples()
            elif choice == '11':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase E evidence')
                print('Sending Phase E evidence via support bundle...')
                self._send_phase_e_evidence()
            elif choice == '12':
                self._print_deep_dive_action_runbook(choice)
                self._phase_f_advanced_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _phase_f_advanced_menu(self):
        """Phase F advanced submenu."""
        _RUN_ID_RE = re.compile(r'^\d{8}-\d{6}-[a-f0-9]{8}$')
        while True:
            print('')
            print('Phase F Advanced')
            print(' 1) Rebuild Shadow Health report (latest)')
            print(' 2) Rebuild Shadow Health report for run ID (strict)')
            suggested = self._get_last_shadow_pipeline_run_id()
            if suggested:
                print('     (suggested: {0})'.format(suggested))
            print(' 3) Open Phase F Evidence Index')
            print(' 0) Back')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._maybe_warn_pipeline_running('Rebuild Phase F')
                print('Triggering manual Phase F packaging pass...')
                self._run_phase_f_manual()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                self._maybe_warn_pipeline_running('Rebuild Phase F (strict)')
                prompt_text = 'Enter run ID [YYYYMMDD-HHMMSS-<8hex>]'
                if suggested:
                    prompt_text += ' (suggested: {0})'.format(suggested)
                prompt_text += ': '
                rid = (self._prompt(prompt_text) or '').strip()
                if not rid:
                    print('Cancelled.')
                    try:
                        self._prompt('Press Enter to return to menu...')
                    except Exception:
                        pass
                    continue
                if not _RUN_ID_RE.match(rid):
                    confirm = (self._prompt(
                        'Format may be non-standard; proceed anyway? [y/N]: ') or '').strip().lower()
                    if confirm not in ('y', 'yes'):
                        print('Cancelled.')
                        try:
                            self._prompt('Press Enter to return to menu...')
                        except Exception:
                            pass
                        continue
                print('Triggering Phase F packaging for run {0}...'.format(rid))
                cr = self._cloud_readiness_service()
                if cr is not None:
                    ok, msg, _ = cr.run_phase_f_manual_for_run_id(
                        self.repo_root, self.python_exe, self.environment, rid)
                    if ok:
                        print('Phase F packaging started in background.')
                    elif msg:
                        print(msg)
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                print('Opening latest Phase F evidence index...')
                self._open_phase_f_evidence_index()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            else:
                print('Invalid choice.')

    def _get_last_shadow_pipeline_run_id(self):
        """Return last_shadow_pipeline_run_id from diagnostics_state.json or empty string."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        lab_root = cr.resolve_lab_root(self.repo_root)
        state_path = os.path.join(lab_root, 'diagnostics_state.json')
        if not os.path.exists(state_path):
            return ''
        try:
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            return state.get('last_shadow_pipeline_run_id', '') or ''
        except (IOError, OSError, ValueError):
            return ''

    def _maybe_warn_pipeline_running(self, action_name):
        """Print warning if pipeline is running."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        running, warn_msg = cr.check_pipeline_running_for_action(
            self.repo_root, action_name)
        if warn_msg:
            print(warn_msg)

    def _run_phase_f_manual(self):
        """Trigger manual Phase F packaging pass (non-blocking)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, _ = cr.run_phase_f_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase F packaging started in background.')
        elif msg:
            print(msg)

    def _open_phase_f_evidence_index(self):
        """View latest Phase F evidence index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_evidence_index(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)
