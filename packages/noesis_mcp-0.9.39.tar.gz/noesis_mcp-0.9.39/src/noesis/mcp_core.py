"""Noesis core — config management and MiniMax passthrough."""

import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional


CONFIG_PATH = Path("~/.mcp/config.json").expanduser()

logger = logging.getLogger(__name__)


def _load_config() -> Dict[str, Any]:
    """Load config from ~/.mcp/config.json.
    
    Returns an empty dictionary if the config file is missing,
    cannot be read, or contains invalid JSON.
    """
    try:
        if CONFIG_PATH.exists():
            return json.loads(CONFIG_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_config(cfg: Dict[str, Any]) -> None:
    """Save config to ~/.mcp/config.json.
    
    Raises:
        OSError: if the config file cannot be written.
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2))
        CONFIG_PATH.chmod(0o600)
    except OSError as e:
        logger.error("Failed to save config to %s: %s", CONFIG_PATH, e)
        raise


class MCP:
    """Noesis config manager and MiniMax passthrough.

    The original cognitive pipeline (Creator/Critic/Analyst agents) has been
    replaced by direct MiniMax API calls. This class manages the API key
    configuration and provides a simple passthrough to MiniMax for backward-
    compatible CLI operation.
    """

    def __init__(self, skip_api_key_check: bool = False) -> None:
        self.config = _load_config()
        self.config_path = CONFIG_PATH

        # For backward compat: also check MINIMAX_API_KEY env var
        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not skip_api_key_check and not api_key:
            raise ValueError(
                "Noesis not configured. Run 'noesis setup' or set MINIMAX_API_KEY."
            )

    def is_setup(self) -> bool:
        """Return True if an API key is configured."""
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "MiniMax-M2.7") -> None:
        """Save API key and model to config.
        
        Raises:
            OSError: if the config file cannot be written.
        """
        self.config["api_key"] = api_key
        self.config["model"] = model
        try:
            _save_config(self.config)
        except OSError as e:
            raise OSError(
                f"Failed to save configuration to {CONFIG_PATH}: {e}"
            ) from e

    def process_task(
        self,
        task: str,
        verbose: bool = False,
        extra_context: str = "",
    ) -> Dict[str, Any]:
        """Process a task by calling MiniMax directly.

        Returns a result dict compatible with the original CLI format:
        {
            "session_id": str,
            "solution": str,
            "duration_seconds": float,
            "evaluation": str,
            "analysis": str,
        }
        """
        import httpx

        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        model = self.config.get("model", "MiniMax-M2.7")

        messages = []
        if extra_context:
            messages.append({"role": "system", "content": extra_context})
        messages.append({"role": "user", "content": task})

        start = time.time()
        try:
            with httpx.Client(timeout=120.0) as client:
                response = client.post(
                    "https://api.minimax.io/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": model,
                        "messages": messages,
                        "max_tokens": 4096,
                        "temperature": 0.7,
                    },
                )
                response.raise_for_status()
                data = response.json()

                # Safely access the nested structure with chained .get()
                content = (
                    (data.get("choices") or [{}])[0]
                    .get("message", {})
                    .get("content")
                    or "[Error: response message content missing]"
                )
        except Exception:
            content = "[Error calling MiniMax: request failed]"

        duration = time.time() - start

        return {
            "session_id": uuid.uuid4().hex[:8],
            "solution": content or "(no response)",
            "duration_seconds": round(duration, 2),
            "evaluation": "",
            "analysis": "",
        }

    def report_outcome(
        self,
        session_id: str,
        outcome: str,
        rating: Optional[int] = None,
        notes: str = "",
    ) -> Dict[str, Any]:
        """Stub for backward compatibility with the CLI feedback command.

        The learning-from-outcomes system is not yet implemented in the
        current architecture. This stub prevents CLI errors but does nothing.
        """
        # TODO: implement outcome recording when the learned-memory system
        # is reconnected to the new architecture
        return {"success": True}