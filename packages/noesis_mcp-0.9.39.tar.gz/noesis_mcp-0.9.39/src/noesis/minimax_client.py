"""MiniMax AI API client — async, with retry/backoff, structured logging, and metrics."""

import json
import os
import time
import asyncio
import threading
import httpx
import structlog
from typing import Optional, List, Dict, Any, Iterator, Union, Callable
from datetime import datetime

from .logging_config import log, get_correlation_id


class MiniMaxError(Exception):
    """Raised when MiniMax API returns an error."""
    pass


class MiniMaxAPIError(MiniMaxError):
    """Raised when MiniMax API returns a non-200 response."""
    def __init__(self, status_code: int, message: str):
        super().__init__(f"API Error {status_code}: {message}")
        self.status_code = status_code


class MiniMaxRateLimitError(MiniMaxError):
    """Raised on 429 rate-limit response."""
    pass


# ── Metrics ───────────────────────────────────────────────────────────────────

class Metrics:
    """Simple in-process metrics — expose via /metrics endpoint later."""

    def __init__(self):
        self._lock = threading.Lock()
        self.request_count = 0
        self.error_count = 0
        self.rate_limit_count = 0
        self.total_tokens = 0
        self.total_latency = 0.0

    def record_request(self, latency: float, tokens: int = 0):
        with self._lock:
            self.request_count += 1
            self.total_latency += latency
            if tokens:
                self.total_tokens += tokens

    def record_error(self):
        with self._lock:
            self.error_count += 1

    def record_rate_limit(self):
        with self._lock:
            self.rate_limit_count += 1

    def summary(self) -> Dict[str, Any]:
        avg_latency = (
            round(self.total_latency / self.request_count, 3)
            if self.request_count > 0 else 0
        )
        return {
            "requests": self.request_count,
            "errors": self.error_count,
            "rate_limits": self.rate_limit_count,
            "total_tokens": self.total_tokens,
            "avg_latency_s": avg_latency,
        }


METRICS = Metrics()


# ── Retry with exponential backoff ────────────────────────────────────────────

async def _retry_with_backoff(
    func,
    *args,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    retry_on: tuple = (429, 500, 502, 503, 504),
    **kwargs,
):
    """Call awaitable func(*args, **kwargs) with exponential backoff retry.

    Retries on HTTP status codes in retry_on (default: rate-limit and 5xx).
    Returns (result, attempt_count) on success, or re-raises on exhaustion.
    """
    last_exc = None
    for attempt in range(1, max_retries + 1):
        try:
            result = await func(*args, **kwargs)
            return result, attempt
        except httpx.HTTPStatusError as e:
            last_exc = e
            status = e.response.status_code
            if status not in retry_on:
                raise
            if attempt == max_retries:
                break
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            if status == 429:
                METRICS.record_rate_limit()
                delay = min(delay * 2, max_delay)
            log.warning(
                "minimax_api_retry",
                status=status,
                attempt=attempt,
                max_retries=max_retries,
                delay_s=round(delay, 1),
            )
            await asyncio.sleep(delay)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            last_exc = e
            if attempt == max_retries:
                break
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            log.warning(
                "minimax_api_retry_connect",
                error=str(e),
                attempt=attempt,
                delay_s=round(delay, 1),
            )
            await asyncio.sleep(delay)
        except Exception as e:
            last_exc = e
            raise

    if last_exc is None:
        raise RuntimeError("All retries exhausted — last_exc was never set")
    raise last_exc


# ── MiniMax Client ─────────────────────────────────────────────────────────────

class MiniMaxClient:
    """Async client for MiniMax Chat API — httpx-based with retry and metrics."""

    # Known MiniMax chat models
    KNOWN_MODELS = ["MiniMax-M2.7", "MiniMax-M2", "MiniMax-M2.5"]

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.minimax.io/v1",
        timeout: float = 120.0,
    ):
        self.api_key = api_key or os.environ.get("MINIMAX_API_KEY")
        if not self.api_key:
            raise ValueError(
                "MiniMax API key not found. Set MINIMAX_API_KEY env var or pass api_key."
            )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        # httpx AsyncClient handles connection pooling automatically
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazily create and return the shared AsyncClient (pooled connections)."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
            )
        return self._client

    async def aclose(self):
        """Close the underlying HTTP client. Call on shutdown."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # ── generate (non-streaming) ─────────────────────────────────────────────

    async def generate(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[list] = None,
    ) -> str:
        """Generate a response from MiniMax (non-streaming)."""
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools

        client = await self._get_client()
        url = f"{self.base_url}/chat/completions"
        start = time.monotonic()

        async def _do_post():
            return await client.post(url, json=payload)

        response, attempts = await _retry_with_backoff(_do_post)
        latency = time.monotonic() - start

        if response.status_code == 429:
            # Already recorded in _retry_with_backoff — just raise
            raise MiniMaxRateLimitError("Rate limited by MiniMax API")

        if response.status_code != 200:
            METRICS.record_error()
            raise MiniMaxAPIError(response.status_code, response.text)

        result = response.json()
        tokens = (
            result.get("usage", {})
            .get("total_tokens", 0)
        )
        METRICS.record_request(latency, tokens)

        log.info(
            "minimax_generate",
            model=model,
            latency_s=round(latency, 3),
            tokens=tokens,
            attempts=attempts,
            cached=False,
        )

        return result["choices"][0]["message"]["content"]

    # ── generate_stream (async streaming) ─────────────────────────────────────

    async def generate_stream(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Iterator[Union[str, Dict[str, Any]]]:
        """Stream a response from MiniMax (async).

        Yields dicts with type info to support tool_calls:
            {"type": "token", "content": "..."}
            {"type": "tool_call", "name": "skill_view", "arguments": '{"skill_name": "llm-wiki"}'}

        When tools are NOT provided, yields plain strings (backward compatible).
        """
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if tools:
            payload["tools"] = tools

        client = await self._get_client()
        url = f"{self.base_url}/chat/completions"
        start = time.monotonic()

        async def _do_post():
            return await client.post(
                url,
                json=payload,
                timeout=httpx.Timeout(self.timeout, connect=10.0),
            )

        response, attempts = await _retry_with_backoff(_do_post)
        latency = time.monotonic() - start

        if response.status_code == 429:
            raise MiniMaxRateLimitError("Rate limited by MiniMax API")

        if response.status_code != 200:
            METRICS.record_error()
            raise MiniMaxAPIError(response.status_code, response.text)

        pending_tool_calls: Dict[int, Dict[str, Any]] = {}
        emit_dicts = tools is not None
        total_content = []
        first_token_time = None

        async for line in response.aiter_lines():
            if line and line.startswith("data: "):
                data = line[6:]
                if data.strip() == "[DONE]":
                    for tc in sorted(
                        pending_tool_calls.values(),
                        key=lambda x: x.get("index", 0),
                    ):
                        yield tc
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue

                delta = chunk.get("choices", [{}])[0].get("delta", {})
                finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")

                if "tool_calls" in delta:
                    for tc in delta["tool_calls"]:
                        idx = tc.get("index", 0)
                        fn = tc.get("function", {})
                        name = fn.get("name")
                        args = fn.get("arguments", "")

                        if idx not in pending_tool_calls:
                            pending_tool_calls[idx] = {
                                "type": "tool_call",
                                "index": idx,
                                "name": name or "",
                                "arguments": "",
                            }
                        if name:
                            pending_tool_calls[idx]["name"] = name
                        if args:
                            pending_tool_calls[idx]["arguments"] += args

                if "content" in delta and delta["content"]:
                    content = delta["content"]
                    if first_token_time is None:
                        first_token_time = time.monotonic()
                        ttft = first_token_time - start
                        log.info(
                            "minimax_stream_start",
                            model=model,
                            time_to_first_token_s=round(ttft, 3),
                        )
                    if emit_dicts:
                        yield {"type": "token", "content": content}
                    else:
                        yield content
                    total_content.append(content)

                if finish_reason in ("tool_calls", "stop"):
                    for tc in sorted(
                        pending_tool_calls.values(),
                        key=lambda x: x.get("index", 0),
                    ):
                        yield tc
                    pending_tool_calls.clear()
                    if finish_reason == "tool_calls":
                        break

        METRICS.record_request(latency, len("".join(total_content)) // 4)  # rough char-based token estimate

        log.info(
            "minimax_stream_done",
            model=model,
            latency_s=round(latency, 3),
            content_chars=len("".join(total_content)),
            attempts=attempts,
        )

    # ── generate_stream_from_messages (async streaming, full message history) ──

    async def generate_stream_from_messages(
        self,
        messages: List[Dict[str, str]],
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Iterator[Union[str, Dict[str, Any]]]:
        """Stream using a full messages array (preserves history/system role)."""
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if tools:
            payload["tools"] = tools

        client = await self._get_client()
        url = f"{self.base_url}/chat/completions"
        start = time.monotonic()

        async def _do_post():
            return await client.post(
                url,
                json=payload,
                timeout=httpx.Timeout(self.timeout, connect=10.0),
            )

        response, attempts = await _retry_with_backoff(_do_post)
        latency = time.monotonic() - start

        if response.status_code == 429:
            raise MiniMaxRateLimitError("Rate limited by MiniMax API")

        if response.status_code != 200:
            raise MiniMaxAPIError(response.status_code, response.text)

        pending_tool_calls: Dict[int, Dict[str, Any]] = {}
        emit_dicts = tools is not None
        total_content = []

        async for line in response.aiter_lines():
            if line and line.startswith("data: "):
                data = line[6:]
                if data.strip() == "[DONE]":
                    for tc in sorted(
                        pending_tool_calls.values(),
                        key=lambda x: x.get("index", 0),
                    ):
                        yield tc
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue

                delta = chunk.get("choices", [{}])[0].get("delta", {})
                finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")

                if "tool_calls" in delta:
                    for tc in delta["tool_calls"]:
                        idx = tc.get("index", 0)
                        fn = tc.get("function", {})
                        name = fn.get("name")
                        args = fn.get("arguments", "")

                        if idx not in pending_tool_calls:
                            pending_tool_calls[idx] = {
                                "type": "tool_call",
                                "index": idx,
                                "name": name or "",
                                "arguments": "",
                            }
                        if name:
                            pending_tool_calls[idx]["name"] = name
                        if args:
                            pending_tool_calls[idx]["arguments"] += args

                if "content" in delta and delta["content"]:
                    content = delta["content"]
                    if emit_dicts:
                        yield {"type": "token", "content": content}
                    else:
                        yield content
                    total_content.append(content)

                if finish_reason in ("tool_calls", "stop"):
                    for tc in sorted(
                        pending_tool_calls.values(),
                        key=lambda x: x.get("index", 0),
                    ):
                        yield tc
                    pending_tool_calls.clear()
                    if finish_reason == "tool_calls":
                        break

        METRICS.record_request(latency, len("".join(total_content)) // 4)  # rough char-based token estimate

    # ── model listing ─────────────────────────────────────────────────────────

    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models — tries /v1/models, falls back to known models."""
        try:
            client = await self._get_client()
            response = await client.get(
                f"{self.base_url}/models",
                timeout=httpx.Timeout(15.0, connect=5.0),
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("data", [])
        except Exception as e:
            log.warning("minimax_list_models_fallback", error=str(e))

        return [{"id": m, "object": "model"} for m in self.KNOWN_MODELS]
