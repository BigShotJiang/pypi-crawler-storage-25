"""Logging configuration for Noesis with correlation ID support."""

import logging
import structlog
from contextvars import ContextVar
from typing import Optional

correlation_id_var: ContextVar[Optional[str]] = ContextVar(
    "correlation_id", default=None
)


def get_correlation_id() -> Optional[str]:
    """Retrieve the current correlation ID from the context variable.

    Returns:
        The current correlation ID if set, otherwise None.
    """
    return correlation_id_var.get()


def set_correlation_id(value: str) -> None:
    """Set the correlation ID in the current context.

    Args:
        value: The correlation ID string to set.
    """
    correlation_id_var.set(value)


def new_correlation_id() -> str:
    """Generate a new unique correlation ID and set it in the context.

    Returns:
        The newly generated correlation ID (UUID string).
    """
    import uuid
    cid = str(uuid.uuid4())
    set_correlation_id(cid)
    return cid


def bind_correlation_id(record: logging.LogRecord) -> None:
    """Bind correlation ID to a log record for structured logging.

    Args:
        record: The logging.LogRecord to modify in-place.
    """
    record.correlation_id = get_correlation_id() or "no-correlation-id"


def has_handler(logger: logging.Logger, handler_class: type) -> bool:
    """Check if a logger already has a handler of the specified class.

    Args:
        logger: The logger instance to check.
        handler_class: The handler class type to look for.

    Returns:
        True if a handler of the given class exists, False otherwise.
    """
    return any(isinstance(h, handler_class) for h in logger.handlers)


def configure_logging(level: int = logging.INFO) -> None:
    """Configure root logger with correlation ID support.

    Args:
        level: The logging level to set (default: INFO).
    """
    root = logging.getLogger()
    if has_handler(root, logging.StreamHandler):
        return
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s | %(correlation_id)s | %(message)s"
    )
    handler.setFormatter(formatter)
    handler.addFilter(bind_correlation_id)
    root.addHandler(handler)
    root.setLevel(level)
    logging.getLogger("noesis").setLevel(level)


logger = logging.getLogger("noesis")
log = structlog.get_logger()