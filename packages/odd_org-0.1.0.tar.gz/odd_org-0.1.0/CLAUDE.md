# ODD - Organization Driven Development

## What is this?
A Python CLI tool that lets you be the CEO of an AI software company. Agents organized like a real company (Lead Dev, QA, Recruiter, Secretary, Consultants) collaborate through agile processes to build software.

## Architecture
- `src/odd/` - Main package
  - `cli.py` - Click CLI entry point (`odd init`, `odd sprint`, `odd standup`, `odd team`, `odd hire`, `odd status`)
  - `agent.py` - Agent invocation engine. Each agent is a strictly isolated API call via a Provider.
  - `provider.py` - Provider protocol (the abstraction boundary between ODD and LLM APIs)
  - `providers/` - Provider implementations (anthropic.py is the default)
  - `models.py` - Pydantic data models (Persona, Sprint, ProjectConfig, etc.)
  - `roles.py` - Core team definitions + recruiter pipeline (JD → resume)
  - `sprint.py` - Sprint lifecycle engine (plan → QA writes tests → implement → demo)
  - `state.py` - `.odd/` directory state management
  - `tools.py` - File/shell tools in neutral format; providers wrap for their wire format

## Key Design Principles
- **Strict agent isolation**: Each agent is a separate API call with its own system prompt built from persona files. NEVER share conversation history across personas.
- **Claude-default**: Anthropic is the default, best-tested provider. Other providers can plug in via the Provider protocol.
- **TDD as quality gate**: QA writes tests first, agents implement to pass them.
- **Scope-boxed sprints**: Sprint boundaries are CEO decision points, not time-based.

## Commands
```
pip install -e .
odd init          # Boot the org, talk to lead dev
odd sprint        # Start a sprint
odd standup       # Run a team standup
odd team          # Show team roster
odd hire "desc"   # Hire a consultant
odd status        # Project status
```

## Testing
```
pytest
```
