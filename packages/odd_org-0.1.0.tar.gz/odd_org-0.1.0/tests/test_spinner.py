"""Tests for odd.spinner - ThinkingSpinner and stream factory integration."""

from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console

from odd.spinner import ThinkingSpinner
from odd.provider import StreamEvent, StreamEventType


# ---------------------------------------------------------------------------
# ThinkingSpinner unit tests
# ---------------------------------------------------------------------------

class TestThinkingSpinner:
    def test_starts_not_running(self):
        spinner = ThinkingSpinner("Cody", Console())
        assert not spinner.running

    def test_start_sets_running(self):
        spinner = ThinkingSpinner("Cody", Console())
        spinner.start()
        assert spinner.running
        spinner.stop()  # cleanup

    def test_stop_clears_running(self):
        spinner = ThinkingSpinner("Cody", Console())
        spinner.start()
        spinner.stop()
        assert not spinner.running

    def test_stop_is_idempotent(self):
        spinner = ThinkingSpinner("Cody", Console())
        spinner.start()
        spinner.stop()
        spinner.stop()  # should not raise
        spinner.stop()
        assert not spinner.running

    def test_start_is_idempotent(self):
        spinner = ThinkingSpinner("Cody", Console())
        spinner.start()
        spinner.start()  # should not raise or double-start
        assert spinner.running
        spinner.stop()

    def test_agent_name_in_spinner(self):
        spinner = ThinkingSpinner("Vera", Console())
        # The status text is set during construction
        assert spinner.agent_name == "Vera"


# ---------------------------------------------------------------------------
# Stream factory integration tests
# ---------------------------------------------------------------------------

class TestCodyStreamFactorySpinner:
    """Test that _cody_stream_factory starts a spinner and stops on first text."""

    def test_factory_returns_callback_for_all_agents(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            MockSpinner.return_value = MagicMock()
            assert _cody_stream_factory("Vera") is not None
            assert _cody_stream_factory("Scout") is not None

    def test_factory_returns_callback_for_cody(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            MockSpinner.return_value = MagicMock()
            cb = _cody_stream_factory("Cody")
        assert cb is not None
        assert callable(cb)

    def test_spinner_starts_on_factory_call(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            mock_spinner = MagicMock()
            MockSpinner.return_value = mock_spinner
            _cody_stream_factory("Cody")
        mock_spinner.start.assert_called_once()

    def test_spinner_stops_on_text_delta(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            mock_spinner = MagicMock()
            MockSpinner.return_value = mock_spinner
            cb = _cody_stream_factory("Cody")

        event = StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="Hello")
        cb(event)
        mock_spinner.stop.assert_called()

    def test_spinner_stops_on_tool_use_start(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            mock_spinner = MagicMock()
            MockSpinner.return_value = mock_spinner
            cb = _cody_stream_factory("Cody")

        event = StreamEvent(
            event_type=StreamEventType.TOOL_USE_START,
            tool_name="read_file",
            tool_id="t1",
        )
        cb(event)
        mock_spinner.stop.assert_called()

    def test_spinner_stops_on_message_stop(self):
        from odd.cli import _cody_stream_factory
        with patch("odd.cli.ThinkingSpinner") as MockSpinner:
            mock_spinner = MagicMock()
            MockSpinner.return_value = mock_spinner
            cb = _cody_stream_factory("Cody")

        event = StreamEvent(event_type=StreamEventType.MESSAGE_STOP)
        cb(event)
        mock_spinner.stop.assert_called()


# ---------------------------------------------------------------------------
# _thinking_context tests
# ---------------------------------------------------------------------------

class TestThinkingContext:
    """Test that _thinking_context avoids double spinners for streaming agents."""

    def test_returns_status_for_non_streaming_agent(self):
        from odd.processes import _thinking_context
        from odd.models import Persona, RoleType
        from rich.status import Status

        engine = MagicMock()
        engine.default_stream_factory = None
        persona = Persona(
            role_type=RoleType.QA, name="Vera", title="QA",
            job_description="QA",
        )
        ctx = _thinking_context(engine, persona)
        assert isinstance(ctx, Status)

    def test_returns_nullcontext_for_streaming_agent(self):
        from odd.processes import _thinking_context
        from odd.models import Persona, RoleType
        from contextlib import nullcontext

        engine = MagicMock()
        engine.default_stream_factory = MagicMock(return_value=lambda e: None)
        persona = Persona(
            role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev",
            job_description="Lead Dev",
        )
        ctx = _thinking_context(engine, persona)
        assert isinstance(ctx, nullcontext)

    def test_returns_nullcontext_when_factory_exists_but_returns_none(self):
        from odd.processes import _thinking_context
        from odd.models import Persona, RoleType
        from contextlib import nullcontext

        engine = MagicMock()
        engine.default_stream_factory = MagicMock(return_value=None)
        persona = Persona(
            role_type=RoleType.QA, name="Vera", title="QA",
            job_description="QA",
        )
        ctx = _thinking_context(engine, persona)
        # Factory exists → nullcontext (factory is never called to avoid side effects)
        assert isinstance(ctx, nullcontext)
