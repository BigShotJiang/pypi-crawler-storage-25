"""Tests for provider configuration and factory wiring (Phase 3)."""

import os
from unittest.mock import MagicMock, patch

import pytest

from odd.models import ProjectConfig, ProviderConfig
from odd.providers import resolve_provider
from odd.providers.anthropic import AnthropicProvider


# ---------------------------------------------------------------------------
# ProviderConfig model
# ---------------------------------------------------------------------------

class TestProviderConfig:
    def test_defaults(self):
        pc = ProviderConfig()
        assert pc.name == "anthropic"
        assert pc.api_key_env == "ANTHROPIC_API_KEY"
        assert pc.base_url == ""
        assert pc.model_map == {}

    def test_custom_values(self):
        pc = ProviderConfig(
            name="openai-compat",
            api_key_env="OPENAI_API_KEY",
            base_url="http://localhost:3000/v1",
            model_map={"high": "gpt-4o", "standard": "gpt-4o-mini"},
        )
        assert pc.name == "openai-compat"
        assert pc.base_url == "http://localhost:3000/v1"
        assert pc.model_map["high"] == "gpt-4o"

    def test_serialization_roundtrip(self):
        pc = ProviderConfig(name="openai-compat", base_url="http://localhost:3000/v1")
        data = pc.model_dump_json()
        restored = ProviderConfig.model_validate_json(data)
        assert restored.name == "openai-compat"
        assert restored.base_url == "http://localhost:3000/v1"


# ---------------------------------------------------------------------------
# ProjectConfig with provider field
# ---------------------------------------------------------------------------

class TestProjectConfigProvider:
    def test_default_provider_is_anthropic(self):
        config = ProjectConfig(name="test")
        assert config.provider.name == "anthropic"

    def test_provider_included_in_serialization(self):
        config = ProjectConfig(
            name="test",
            provider=ProviderConfig(name="openai-compat", base_url="http://example.com/v1"),
        )
        data = config.model_dump_json()
        restored = ProjectConfig.model_validate_json(data)
        assert restored.provider.name == "openai-compat"
        assert restored.provider.base_url == "http://example.com/v1"

    def test_backward_compat_no_provider_field(self):
        """Old config.json files without a 'provider' key should still load."""
        import json
        old_config = json.dumps({"name": "legacy-project", "description": "old"})
        config = ProjectConfig.model_validate_json(old_config)
        assert config.provider.name == "anthropic"


# ---------------------------------------------------------------------------
# resolve_provider - factory
# ---------------------------------------------------------------------------

class TestResolveProvider:
    def test_anthropic_default(self):
        config = ProviderConfig()
        provider = resolve_provider(config)
        assert isinstance(provider, AnthropicProvider)

    def test_anthropic_explicit(self):
        config = ProviderConfig(name="anthropic")
        provider = resolve_provider(config)
        assert isinstance(provider, AnthropicProvider)

    @pytest.mark.skipif(
        not pytest.importorskip("requests", reason="requests not installed"),
        reason="requests not installed",
    )
    def test_openai_compat(self):
        config = ProviderConfig(
            name="openai-compat",
            api_key_env="TEST_KEY",
            base_url="http://localhost:3000/v1",
        )
        with patch.dict(os.environ, {"TEST_KEY": "sk-test"}):
            provider = resolve_provider(config)
        from odd.providers.openai_compat import OpenAICompatProvider
        assert isinstance(provider, OpenAICompatProvider)
        assert provider.base_url == "http://localhost:3000/v1"
        assert provider.api_key == "sk-test"

    @pytest.mark.skipif(
        not pytest.importorskip("requests", reason="requests not installed"),
        reason="requests not installed",
    )
    def test_openai_compat_requires_base_url(self):
        config = ProviderConfig(name="openai-compat", base_url="")
        with pytest.raises(ValueError, match="base_url"):
            resolve_provider(config)

    @pytest.mark.skipif(
        not pytest.importorskip("requests", reason="requests not installed"),
        reason="requests not installed",
    )
    def test_openai_compat_custom_model_map(self):
        custom_map = {"high": "llama-70b", "standard": "llama-8b", "fast": "llama-8b"}
        config = ProviderConfig(
            name="openai-compat",
            api_key_env="TEST_KEY",
            base_url="http://localhost:11434/v1",
            model_map=custom_map,
        )
        with patch.dict(os.environ, {"TEST_KEY": "ollama"}):
            provider = resolve_provider(config)
        assert provider.model_map == custom_map

    def test_anthropic_reads_api_key_from_env(self):
        config = ProviderConfig(api_key_env="MY_ANTHROPIC_KEY")
        with patch.dict(os.environ, {"MY_ANTHROPIC_KEY": "sk-ant-test"}):
            provider = resolve_provider(config)
        assert isinstance(provider, AnthropicProvider)
