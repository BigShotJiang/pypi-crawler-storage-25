"""Tests for odd.providers.openai_compat - OpenAI-compatible provider."""

import json
from unittest.mock import MagicMock, patch

import pytest

from odd.provider import AgentResponse, ToolCall, Usage


# ---------------------------------------------------------------------------
# Skip if requests is not installed
# ---------------------------------------------------------------------------
requests = pytest.importorskip("requests")

from odd.providers.openai_compat import (
    OPENAI_MODEL_MAP,
    OpenAICompatProvider,
    _wrap_tools_openai,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_provider(**kwargs):
    defaults = {"api_key": "sk-test-key", "base_url": "https://api.example.com/v1"}
    defaults.update(kwargs)
    return OpenAICompatProvider(**defaults)


def _chat_response(
    content: str | None = "Hello",
    tool_calls: list | None = None,
    finish_reason: str = "stop",
    prompt_tokens: int = 10,
    completion_tokens: int = 20,
):
    """Build a fake OpenAI chat completions JSON response."""
    message: dict = {"role": "assistant"}
    if content is not None:
        message["content"] = content
    if tool_calls:
        message["tool_calls"] = tool_calls
        message["content"] = None
    return {
        "choices": [{"message": message, "finish_reason": finish_reason}],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
        },
    }


def _tool_call_block(
    name: str = "read_file",
    arguments: dict | None = None,
    call_id: str = "call_abc123",
):
    return {
        "id": call_id,
        "type": "function",
        "function": {
            "name": name,
            "arguments": json.dumps(arguments or {"path": "foo.txt"}),
        },
    }


# ---------------------------------------------------------------------------
# Tool wrapping
# ---------------------------------------------------------------------------

class TestWrapToolsOpenAI:
    def test_wraps_neutral_to_openai_format(self):
        neutral = [
            {
                "name": "read_file",
                "description": "Read a file.",
                "parameters": {"type": "object", "properties": {"path": {"type": "string"}}},
            }
        ]
        wrapped = _wrap_tools_openai(neutral)
        assert len(wrapped) == 1
        assert wrapped[0]["type"] == "function"
        assert wrapped[0]["function"]["name"] == "read_file"
        assert wrapped[0]["function"]["description"] == "Read a file."
        assert wrapped[0]["function"]["parameters"] == neutral[0]["parameters"]

    def test_preserves_multiple_tools(self):
        neutral = [
            {"name": "a", "description": "A", "parameters": {}},
            {"name": "b", "description": "B", "parameters": {}},
        ]
        assert len(_wrap_tools_openai(neutral)) == 2


# ---------------------------------------------------------------------------
# Model resolution
# ---------------------------------------------------------------------------

class TestModelResolution:
    def test_tier_resolves_to_model_id(self):
        provider = _make_provider()
        assert provider.model_map["high"] == "gpt-4o"
        assert provider.model_map["standard"] == "gpt-4o-mini"

    def test_custom_model_map(self):
        custom = {"high": "my-model", "standard": "my-small-model", "fast": "my-tiny"}
        provider = _make_provider(model_map=custom)
        assert provider.model_map["high"] == "my-model"

    def test_raw_model_id_passes_through(self):
        provider = _make_provider()
        # Raw IDs not in the map pass through unchanged
        assert provider.model_map.get("gpt-4-turbo", "gpt-4-turbo") == "gpt-4-turbo"


# ---------------------------------------------------------------------------
# create_message - response parsing
# ---------------------------------------------------------------------------

class TestCreateMessage:
    @patch("odd.providers.openai_compat.requests.post")
    def test_basic_text_response(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response(content="Hi there")
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        result = provider.create_message(
            model="standard",
            system="You are helpful.",
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert isinstance(result, AgentResponse)
        assert result.text_blocks == ["Hi there"]
        assert result.tool_calls == []
        assert result.stop_reason == "end_turn"
        assert result.usage.input_tokens == 10
        assert result.usage.output_tokens == 20

    @patch("odd.providers.openai_compat.requests.post")
    def test_tool_call_response(self, mock_post):
        tc = _tool_call_block(name="read_file", arguments={"path": "main.py"}, call_id="call_1")
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response(
            content=None, tool_calls=[tc], finish_reason="tool_calls"
        )
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        result = provider.create_message(
            model="high",
            system="sys",
            messages=[{"role": "user", "content": "read main.py"}],
            tools=[{"name": "read_file", "description": "Read", "parameters": {}}],
        )

        assert result.stop_reason == "tool_use"
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "read_file"
        assert result.tool_calls[0].input == {"path": "main.py"}
        assert result.tool_calls[0].id == "call_1"

    @patch("odd.providers.openai_compat.requests.post")
    def test_system_message_prepended(self, mock_post):
        """System prompt should be the first message with role='system'."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        provider.create_message(
            model="standard",
            system="Be concise.",
            messages=[{"role": "user", "content": "Hi"}],
        )

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        msgs = payload["messages"]
        assert msgs[0]["role"] == "system"
        assert msgs[0]["content"] == "Be concise."
        assert msgs[1]["role"] == "user"

    @patch("odd.providers.openai_compat.requests.post")
    def test_tools_wrapped_in_payload(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        tools = [{"name": "read_file", "description": "Read", "parameters": {"type": "object"}}]
        provider.create_message(
            model="standard",
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            tools=tools,
        )

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert "tools" in payload
        assert payload["tools"][0]["type"] == "function"

    @patch("odd.providers.openai_compat.requests.post")
    def test_no_tools_omits_key(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        provider.create_message(
            model="standard",
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert "tools" not in payload

    @patch("odd.providers.openai_compat.requests.post")
    def test_no_usage_in_response(self, mock_post):
        resp_data = _chat_response()
        del resp_data["usage"]
        mock_resp = MagicMock()
        mock_resp.json.return_value = resp_data
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()
        result = provider.create_message(
            model="standard", system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result.usage is None


# ---------------------------------------------------------------------------
# wrap_tool_results
# ---------------------------------------------------------------------------

class TestWrapToolResults:
    def test_returns_assistant_and_tool_messages(self):
        provider = _make_provider()
        tcs = [
            ToolCall(name="read_file", input={"path": "a.py"}, id="call_1"),
            ToolCall(name="write_file", input={"path": "b.py", "content": "x"}, id="call_2"),
        ]
        results = ["contents of a.py", "wrote b.py"]

        assistant_msg, tool_msg = provider.wrap_tool_results(tcs, results)

        # Assistant message has tool_calls
        assert assistant_msg["role"] == "assistant"
        assert len(assistant_msg["tool_calls"]) == 2
        assert assistant_msg["tool_calls"][0]["function"]["name"] == "read_file"

        # Tool results are packed in the sentinel
        assert tool_msg["role"] == "tool_results"
        tool_messages = tool_msg["_tool_messages"]
        assert len(tool_messages) == 2
        assert tool_messages[0]["role"] == "tool"
        assert tool_messages[0]["tool_call_id"] == "call_1"
        assert tool_messages[0]["content"] == "contents of a.py"
        assert tool_messages[1]["tool_call_id"] == "call_2"


# ---------------------------------------------------------------------------
# Message flattening (tool_results sentinel → individual tool messages)
# ---------------------------------------------------------------------------

class TestMessageFlattening:
    @patch("odd.providers.openai_compat.requests.post")
    def test_tool_results_sentinel_flattened(self, mock_post):
        """Messages with role='tool_results' should be expanded before sending."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider()

        # Simulate conversation with a tool result round
        messages = [
            {"role": "user", "content": "read foo"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {"id": "call_1", "type": "function", "function": {"name": "read_file", "arguments": '{"path": "foo"}'}}
                ],
            },
            {
                "role": "tool_results",
                "_tool_messages": [
                    {"role": "tool", "tool_call_id": "call_1", "content": "file contents"},
                ],
            },
            {"role": "user", "content": "now what?"},
        ]

        provider.create_message(
            model="standard", system="sys", messages=messages,
        )

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        api_msgs = payload["messages"]

        # Should be: system, user, assistant, tool, user (no tool_results sentinel)
        roles = [m["role"] for m in api_msgs]
        assert "tool_results" not in roles
        assert roles == ["system", "user", "assistant", "tool", "user"]


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------

class TestRetryLogic:
    @patch("odd.providers.openai_compat.time.sleep")
    @patch("odd.providers.openai_compat.requests.post")
    def test_retries_on_connection_error(self, mock_post, mock_sleep):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.side_effect = [
            requests.ConnectionError("refused"),
            mock_resp,
        ]

        provider = _make_provider()
        result = provider.create_message(
            model="standard", system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result.text_blocks == ["Hello"]
        mock_sleep.assert_called_once()

    @patch("odd.providers.openai_compat.time.sleep")
    @patch("odd.providers.openai_compat.requests.post")
    def test_retries_on_rate_limit(self, mock_post, mock_sleep):
        error_resp = MagicMock()
        error_resp.status_code = 429
        error_resp.raise_for_status.side_effect = requests.HTTPError(response=error_resp)

        ok_resp = MagicMock()
        ok_resp.json.return_value = _chat_response()
        ok_resp.raise_for_status = MagicMock()

        mock_post.side_effect = [error_resp, ok_resp]

        provider = _make_provider()
        result = provider.create_message(
            model="standard", system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result.text_blocks == ["Hello"]

    @patch("odd.providers.openai_compat.time.sleep")
    @patch("odd.providers.openai_compat.requests.post")
    def test_raises_after_max_retries(self, mock_post, mock_sleep):
        mock_post.side_effect = requests.ConnectionError("refused")

        provider = _make_provider()
        with pytest.raises(ConnectionError, match="Failed to connect"):
            provider.create_message(
                model="standard", system="sys",
                messages=[{"role": "user", "content": "Hi"}],
            )

    @patch("odd.providers.openai_compat.requests.post")
    def test_non_retryable_http_error_raises_immediately(self, mock_post):
        error_resp = MagicMock()
        error_resp.status_code = 401
        error_resp.raise_for_status.side_effect = requests.HTTPError(response=error_resp)
        mock_post.return_value = error_resp

        provider = _make_provider()
        with pytest.raises(requests.HTTPError):
            provider.create_message(
                model="standard", system="sys",
                messages=[{"role": "user", "content": "Hi"}],
            )


# ---------------------------------------------------------------------------
# URL construction
# ---------------------------------------------------------------------------

class TestURLConstruction:
    @patch("odd.providers.openai_compat.requests.post")
    def test_uses_configured_base_url(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider(base_url="http://localhost:3000/api/v1")
        provider.create_message(
            model="standard", system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )

        url = mock_post.call_args.args[0] if mock_post.call_args.args else mock_post.call_args.kwargs.get("url", mock_post.call_args[0][0])
        assert url == "http://localhost:3000/api/v1/chat/completions"

    @patch("odd.providers.openai_compat.requests.post")
    def test_trailing_slash_stripped(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = _chat_response()
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        provider = _make_provider(base_url="http://localhost:3000/v1/")
        provider.create_message(
            model="standard", system="sys",
            messages=[{"role": "user", "content": "Hi"}],
        )

        url = mock_post.call_args[0][0]
        assert url == "http://localhost:3000/v1/chat/completions"


# ---------------------------------------------------------------------------
# Provider protocol compliance
# ---------------------------------------------------------------------------

class TestProviderProtocol:
    def test_satisfies_provider_protocol(self):
        from odd.provider import Provider
        provider = _make_provider()
        assert isinstance(provider, Provider)
