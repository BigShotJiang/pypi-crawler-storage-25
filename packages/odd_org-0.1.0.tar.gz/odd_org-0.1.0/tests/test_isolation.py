"""Architectural tests - enforce persona isolation invariants.

These tests inspect the code structure to ensure that no accidental
cross-agent context sharing can creep in.  They don't test runtime
behaviour (test_agent.py covers that); they test the *shape* of the code.
"""

from __future__ import annotations

import ast
import inspect
import textwrap
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from odd.agent import AgentEngine, build_system_prompt
from odd.models import ModelTier, Persona, RoleType
from odd.provider import AgentResponse, Usage


SRC_DIR = Path(__file__).resolve().parent.parent / "src" / "odd"


# ---------------------------------------------------------------------------
# 1. build_system_prompt accepts ONLY the documented inputs
# ---------------------------------------------------------------------------

class TestSystemPromptIsolation:
    """The system prompt builder must never accept raw messages or history."""

    def test_signature_has_no_messages_param(self):
        """build_system_prompt must not accept 'messages' or 'history'."""
        sig = inspect.signature(build_system_prompt)
        forbidden = {"messages", "history", "conversation_history", "chat_history"}
        assert forbidden.isdisjoint(sig.parameters), (
            f"build_system_prompt gained a forbidden parameter: "
            f"{forbidden & set(sig.parameters)}"
        )

    def test_prompt_contains_only_persona_data(self):
        """The output should only contain data from persona + project context."""
        persona = Persona(
            role_type=RoleType.LEAD_DEV,
            name="Cody",
            title="Lead Developer",
            job_description="Build things",
            resume="Senior engineer",
        )
        prompt = build_system_prompt(
            persona,
            project_context="Sprint 1 context",
            company_values="Be excellent",
        )
        # Must contain persona data
        assert "Build things" in prompt
        assert "Senior engineer" in prompt
        assert "Sprint 1 context" in prompt
        assert "Be excellent" in prompt

        # Must NOT contain anything resembling conversation content
        # (this is a canary - if someone accidentally injects messages)
        assert "user:" not in prompt.lower().split("project context")[0]


# ---------------------------------------------------------------------------
# 2. AgentEngine.invoke starts with empty messages each call
# ---------------------------------------------------------------------------

class TestInvokeIsolation:
    """Each invoke() call must start with a fresh message list."""

    def _make_engine(self):
        provider = MagicMock()
        provider.create_message.return_value = AgentResponse(
            text_blocks=["OK"],
            tool_calls=[],
            stop_reason="end_turn",
            usage=Usage(input_tokens=10, output_tokens=5),
        )
        return AgentEngine(provider=provider)

    def _persona(self, role: RoleType, name: str = "Agent") -> Persona:
        return Persona(
            role_type=role,
            name=name,
            title=name,
            job_description="test",
            resume="test",
        )

    def test_successive_invokes_dont_leak_messages(self):
        """Calling invoke() twice for the same persona must not carry state."""
        engine = self._make_engine()
        persona = self._persona(RoleType.LEAD_DEV, "Cody")

        engine.invoke(persona, "First task")
        engine.invoke(persona, "Second task")

        calls = engine.provider.create_message.call_args_list
        # Each call should have only 1 user message (no leakage from prior call)
        for call in calls:
            messages = call.kwargs.get("messages") or call[1].get("messages") or call[0][2]
            user_msgs = [m for m in messages if m.get("role") == "user"]
            assert len(user_msgs) == 1

    def test_different_personas_dont_share_messages(self):
        """Invoking two different personas must not share any messages."""
        engine = self._make_engine()
        lead = self._persona(RoleType.LEAD_DEV, "Cody")
        qa = self._persona(RoleType.QA, "Vera")

        engine.invoke(lead, "Build feature X")
        engine.invoke(qa, "Test feature X")

        calls = engine.provider.create_message.call_args_list
        messages_0 = calls[0].kwargs.get("messages") or calls[0][1].get("messages") or calls[0][0][2]
        messages_1 = calls[1].kwargs.get("messages") or calls[1][1].get("messages") or calls[1][0][2]

        # Messages should be completely independent lists
        assert messages_0 is not messages_1
        assert "Build feature X" in str(messages_0)
        assert "Build feature X" not in str(messages_1)

    def test_conversation_history_only_for_same_agent(self):
        """conversation_history parameter is for continuing ONE agent's conversation."""
        engine = self._make_engine()
        persona = self._persona(RoleType.LEAD_DEV, "Cody")

        history = [
            {"role": "user", "content": "prior question"},
            {"role": "assistant", "content": "prior answer"},
        ]
        engine.invoke(persona, "Follow-up", conversation_history=history)

        call = engine.provider.create_message.call_args_list[0]
        messages = call.kwargs.get("messages") or call[1].get("messages") or call[0][2]
        # Should contain history + new message
        assert len(messages) == 3
        assert messages[0]["content"] == "prior question"
        assert messages[2]["content"] == "Follow-up"

    def test_fork_creates_independent_engine(self):
        """Forked engines must have independent escalation/submission lists."""
        engine = self._make_engine()
        forked = engine.fork()

        engine.escalations.append({"reason": "test", "severity": "heads_up"})
        assert len(forked.escalations) == 0

        forked.submissions.append({"tool": "test", "data": {}})
        assert len(engine.submissions) == 0


# ---------------------------------------------------------------------------
# 3. Static analysis - no global mutable conversation state
# ---------------------------------------------------------------------------

class TestNoGlobalConversationState:
    """Ensure agent.py has no module-level mutable state that could leak."""

    def test_no_module_level_messages_list(self):
        """agent.py must not have a module-level messages list or dict."""
        source = (SRC_DIR / "agent.py").read_text()
        tree = ast.parse(source)

        conversation_keywords = {"message", "history", "conversation", "chat"}
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id.lower()
                        # Catch any module-level mutable (list/dict) whose name
                        # suggests conversation state
                        if isinstance(node.value, (ast.List, ast.Dict)):
                            assert not any(
                                keyword in name
                                for keyword in conversation_keywords
                            ), f"Suspicious module-level mutable state: {target.id}"

    def test_invoke_builds_messages_locally(self):
        """invoke() must build its messages list inside the method, not from self."""
        source = (SRC_DIR / "agent.py").read_text()
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "invoke":
                # Find the `messages = []` assignment
                found_local_init = False
                for stmt in ast.walk(node):
                    if isinstance(stmt, ast.Assign):
                        for target in stmt.targets:
                            if isinstance(target, ast.Name) and target.id == "messages":
                                if isinstance(stmt.value, ast.List):
                                    found_local_init = True
                assert found_local_init, (
                    "invoke() must initialize messages as a local empty list"
                )
                break


# ---------------------------------------------------------------------------
# 4. System prompts are unique per role
# ---------------------------------------------------------------------------

class TestSystemPromptUniqueness:
    """Each role must produce a distinct system prompt."""

    def test_different_roles_get_different_prompts(self):
        personas = {}
        for role in RoleType:
            personas[role] = Persona(
                role_type=role,
                name=f"Agent_{role.value}",
                title=f"Title_{role.value}",
                job_description=f"JD for {role.value}",
                resume=f"Resume for {role.value}",
            )

        prompts = {
            role: build_system_prompt(persona)
            for role, persona in personas.items()
        }

        # Every pair of roles must produce different prompts
        roles = list(prompts.keys())
        for i, r1 in enumerate(roles):
            for r2 in roles[i + 1 :]:
                assert prompts[r1] != prompts[r2], (
                    f"Roles {r1} and {r2} produced identical system prompts"
                )
