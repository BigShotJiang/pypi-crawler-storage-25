"""Tests for odd.processes - beta testing, retro, 1:1, spike, review, onboarding."""

from unittest.mock import MagicMock, patch, call

import pytest

from odd.cfo import CFO
from odd.models import ConsultantRecord, Persona, ProjectConfig, RoleType, Sprint, SprintStatus, TaskOutcome
from odd.processes import (
    enrich_context_with_experience,
    generate_onboarding_brief,
    generate_performance_review,
    run_beta_test,
    run_one_on_one,
    run_retrospective,
    run_spike,
)
from odd.state import StateManager


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def state(tmp_path):
    s = StateManager(tmp_path)
    config = ProjectConfig(name="TestProject", description="A test project", current_sprint=1)
    s.init(config)
    return s


def _make_mock_conv(responses):
    """Create a mock conversation context manager with send() side effects."""
    conv = MagicMock()
    conv.send.side_effect = list(responses)
    conv.__enter__ = lambda self: conv
    conv.__exit__ = lambda self, *a: False
    return conv


@pytest.fixture
def mock_engine():
    engine = MagicMock()
    engine.invoke.return_value = "Mock agent response"
    engine.pop_submissions.return_value = []
    # Default conversation mock - returns "Mock agent response" for each send()
    conv = MagicMock()
    conv.send.return_value = "Mock agent response"
    conv.__enter__ = lambda self: conv
    conv.__exit__ = lambda self, *a: False
    engine.conversation.return_value = conv
    return engine


@pytest.fixture
def recruiter():
    return Persona(
        role_type=RoleType.RECRUITER,
        name="Recruiter",
        title="Technical Recruiter",
        job_description="Find talent",
    )


@pytest.fixture
def lead_dev():
    return Persona(
        role_type=RoleType.LEAD_DEV,
        name="Lead Developer",
        title="Lead Developer",
        job_description="Build things",
    )


@pytest.fixture
def secretary():
    return Persona(
        role_type=RoleType.SECRETARY,
        name="Secretary",
        title="Project Secretary",
        job_description="Keep notes",
    )


@pytest.fixture
def qa():
    return Persona(
        role_type=RoleType.QA,
        name="Glitch Hunter",
        title="QA Engineer",
        job_description="Break things",
    )


@pytest.fixture
def team(lead_dev, qa, recruiter, secretary):
    return {
        "lead_dev": lead_dev,
        "qa": qa,
        "recruiter": recruiter,
        "secretary": secretary,
    }


@pytest.fixture
def sprint():
    return Sprint(
        number=1,
        goal="Build auth module",
        tasks=[],
        status=SprintStatus.REVIEW,
    )


# ---------------------------------------------------------------------------
# run_beta_test
# ---------------------------------------------------------------------------

class TestRunBetaTestSingle:
    def test_recruits_tester_and_gets_feedback(self, mock_engine, state, recruiter):
        """Single beta test should recruit a tester, invoke them, and archive."""
        from odd.processes import run_beta_test_single

        mock_tester = Persona(
            role_type=RoleType.CONSULTANT,
            name="Test User",
            title="Beta Tester",
            job_description="Beta test JD",
            resume="NAME: Test User\nTITLE: Beta Tester",
        )

        with patch("odd.processes.recruit_consultant", return_value=mock_tester):
            feedback = run_beta_test_single(
                engine=mock_engine,
                state=state,
                recruiter=recruiter,
                tester_description="Power user who hates bad UX",
                tester_name="Test User",
                test_instructions="Run `odd status` and tell me what you think",
            )

        assert feedback == "Mock agent response"
        mock_engine.invoke.assert_called_once()
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "beta test" in call_kwargs["user_message"].lower() or "test" in call_kwargs["user_message"].lower()

    def test_tester_is_archived_after_test(self, mock_engine, state, recruiter):
        """Beta tester should be archived after giving feedback."""
        from odd.processes import run_beta_test_single

        mock_tester = Persona(
            role_type=RoleType.CONSULTANT,
            name="Temp Tester",
            title="Beta Tester",
            job_description="JD",
        )

        with patch("odd.processes.recruit_consultant", return_value=mock_tester):
            run_beta_test_single(
                mock_engine, state, recruiter,
                "Description", "Temp Tester", "Instructions",
            )

        consultants = state.list_consultants()
        assert all(c.name != "Temp Tester" for c in consultants)

    def test_beta_jd_is_user_focused(self, mock_engine, state, recruiter):
        """The JD passed to the recruiter should emphasize user perspective."""
        from odd.processes import run_beta_test_single

        with patch("odd.processes.recruit_consultant") as mock_recruit:
            mock_recruit.return_value = Persona(
                role_type=RoleType.CONSULTANT, name="TestUser", title="Beta Tester", job_description="JD",
            )
            run_beta_test_single(
                mock_engine, state, recruiter,
                "Casual mobile user", "TestUser", "Try it",
            )

        jd_arg = mock_recruit.call_args.args[2]  # third positional arg is the JD
        assert "USER" in jd_arg or "user" in jd_arg
        assert "BETA TESTER" in jd_arg


class TestRunBetaTest:
    def test_lead_dev_designs_testers_and_synthesis(self, mock_engine, state, recruiter):
        """Full beta test: Lead Dev designs profiles, testers run, synthesis returned."""
        lead_dev = Persona(
            role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Developer",
            job_description="Lead dev", system_prompt="You are the lead dev.",
        )

        # First call: Lead Dev designs tester profiles
        # Subsequent calls: tester feedback, then synthesis
        tester_plan = (
            "TESTER: Alice\n"
            "PROFILE: First-time user, non-technical\n"
            "INSTRUCTIONS: Run odd status and see if it makes sense\n\n"
            "TESTER: Bob\n"
            "PROFILE: Experienced developer evaluating the tool\n"
            "INSTRUCTIONS: Run odd init and odd sprint\n"
        )
        mock_engine.invoke.side_effect = [
            tester_plan,         # Lead Dev designs testers
            "Alice feedback",    # Alice's beta test
            "Bob feedback",      # Bob's beta test
            "Synthesis report",  # Lead Dev synthesizes
        ]

        mock_alice = Persona(
            role_type=RoleType.CONSULTANT, name="Alice", title="Beta Tester", job_description="JD",
        )
        mock_bob = Persona(
            role_type=RoleType.CONSULTANT, name="Bob", title="Beta Tester", job_description="JD",
        )
        with patch("odd.processes.recruit_consultant", side_effect=[mock_alice, mock_bob]):
            result = run_beta_test(
                engine=mock_engine,
                state=state,
                lead_dev=lead_dev,
                recruiter=recruiter,
                count=2,
                project_context="Project: Test",
            )

        assert result == "Synthesis report"
        assert mock_engine.invoke.call_count == 4


# ---------------------------------------------------------------------------
# run_retrospective
# ---------------------------------------------------------------------------

class TestRunRetrospective:
    def test_consolidates_notes_with_secretary(self, mock_engine, state, sprint, team, secretary):
        """Retro reads agent notes from disk and has secretary consolidate."""
        # Write some agent notes to disk
        notes_dir = state.sprint_notes_dir(sprint.number)
        (notes_dir / "lead_dev.md").write_text("Built the auth module, all tests pass.")
        (notes_dir / "qa.md").write_text("Wrote 12 tests, found 2 edge cases.")

        summary = run_retrospective(mock_engine, state, sprint, team, secretary)

        assert summary == "Mock agent response"
        # Only secretary should be invoked (consolidation), not individual agents
        assert mock_engine.invoke.call_count == 1
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["persona"].role_type == RoleType.SECRETARY
        assert "lead_dev" in call_kwargs["user_message"]
        assert "qa" in call_kwargs["user_message"]

    def test_fallback_when_no_notes(self, mock_engine, state, sprint, team, secretary):
        """Retro should still work if no agent notes exist (e.g. old sprints)."""
        summary = run_retrospective(mock_engine, state, sprint, team, secretary)

        assert summary == "Mock agent response"
        assert mock_engine.invoke.call_count == 1

    def test_sprint_context_included(self, mock_engine, state, sprint, team, secretary):
        """Retro prompts should include sprint goal."""
        notes_dir = state.sprint_notes_dir(sprint.number)
        (notes_dir / "lead_dev.md").write_text("Did stuff.")

        run_retrospective(mock_engine, state, sprint, team, secretary)

        first_call = mock_engine.invoke.call_args_list[0]
        user_msg = first_call.kwargs.get("user_message", "")
        assert str(sprint.number) in user_msg


# ---------------------------------------------------------------------------
# run_one_on_one
# ---------------------------------------------------------------------------

class TestRunOneOnOne:
    def test_opening_message_and_done(self, mock_engine, lead_dev):
        """1:1 should send opening, then handle 'done' from CEO."""
        with patch("odd.processes.Prompt.ask", return_value="done"):
            run_one_on_one(mock_engine, lead_dev, project_context="Sprint 1")

        # conversation() should be called for multi-turn, send() for opening
        mock_engine.conversation.assert_called_once()
        conv = mock_engine.conversation.return_value
        assert conv.send.call_count == 1

    def test_multi_turn_conversation(self, mock_engine, lead_dev):
        """CEO can have multiple turns before saying done."""
        with patch("odd.processes.Prompt.ask", side_effect=["What's the status?", "Tell me more", "done"]):
            run_one_on_one(mock_engine, lead_dev)

        # Opening + 2 follow-ups = 3 send() calls
        conv = mock_engine.conversation.return_value
        assert conv.send.call_count == 3

    def test_conversation_sends_user_messages(self, mock_engine, lead_dev):
        """Each user message should be sent via conv.send()."""
        conv = _make_mock_conv(["Opening", "Response 1", "Response 2"])
        mock_engine.conversation.return_value = conv

        with patch("odd.processes.Prompt.ask", side_effect=["msg1", "msg2", "done"]):
            run_one_on_one(mock_engine, lead_dev)

        # Verify the user messages were sent
        send_calls = conv.send.call_args_list
        assert len(send_calls) == 3
        assert "msg1" in send_calls[1].args[0]
        assert "msg2" in send_calls[2].args[0]

    def test_one_shot_message(self, mock_engine, lead_dev):
        """When message is provided, send it directly without interactive loop."""
        run_one_on_one(mock_engine, lead_dev, message="refactor the auth module")

        assert mock_engine.invoke.call_count == 1
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["user_message"] == "refactor the auth module"

    def test_one_shot_does_not_prompt(self, mock_engine, lead_dev):
        """One-shot mode should never call Prompt.ask."""
        with patch("odd.processes.Prompt.ask") as mock_ask:
            run_one_on_one(mock_engine, lead_dev, message="do the thing")
            mock_ask.assert_not_called()

    def test_project_context_passed(self, mock_engine, lead_dev):
        """Project context should be forwarded to conversation()."""
        with patch("odd.processes.Prompt.ask", return_value="done"):
            run_one_on_one(mock_engine, lead_dev, project_context="Sprint 5")

        call_kwargs = mock_engine.conversation.call_args.kwargs
        assert call_kwargs["project_context"] == "Sprint 5"

    def test_multi_turn_defaults_to_sonnet(self, mock_engine, lead_dev):
        """Multi-turn 1:1 should default to Sonnet for cost efficiency."""
        from odd.config import SONNET_MODEL

        with patch("odd.processes.Prompt.ask", return_value="done"):
            run_one_on_one(mock_engine, lead_dev)

        # conversation() should be called with Sonnet model override
        call_kwargs = mock_engine.conversation.call_args.kwargs
        assert call_kwargs["model_override"] == SONNET_MODEL

    def test_one_shot_uses_persona_default(self, mock_engine, lead_dev):
        """One-shot mode should use the persona's default model (no override)."""
        run_one_on_one(mock_engine, lead_dev, message="do the thing")

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs.get("model_override") is None

    def test_model_override_respected_multi_turn(self, mock_engine, lead_dev):
        """Explicit model_override should be used instead of Sonnet default."""
        with patch("odd.processes.Prompt.ask", return_value="done"):
            run_one_on_one(mock_engine, lead_dev, model_override="claude-opus-4-6")

        call_kwargs = mock_engine.conversation.call_args.kwargs
        assert call_kwargs["model_override"] == "claude-opus-4-6"

    def test_model_override_respected_one_shot(self, mock_engine, lead_dev):
        """Explicit model_override should be forwarded in one-shot mode."""
        run_one_on_one(mock_engine, lead_dev, message="do it", model_override="claude-haiku-4-5-20251001")

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["model_override"] == "claude-haiku-4-5-20251001"


# ---------------------------------------------------------------------------
# run_spike
# ---------------------------------------------------------------------------

class TestRunSpike:
    def test_returns_findings(self, mock_engine, lead_dev):
        mock_engine.invoke.return_value = "Findings: use PostgreSQL"
        result = run_spike(mock_engine, lead_dev, "Which database?")
        assert result == "Findings: use PostgreSQL"

    def test_topic_in_prompt(self, mock_engine, lead_dev):
        run_spike(mock_engine, lead_dev, "Should we use GraphQL?")
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "GraphQL" in call_kwargs["user_message"]

    def test_project_context_forwarded(self, mock_engine, lead_dev):
        run_spike(mock_engine, lead_dev, "topic", project_context="Sprint 2")
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["project_context"] == "Sprint 2"

    def test_single_invocation(self, mock_engine, lead_dev):
        run_spike(mock_engine, lead_dev, "topic")
        assert mock_engine.invoke.call_count == 1


# ---------------------------------------------------------------------------
# generate_performance_review
# ---------------------------------------------------------------------------

class TestGeneratePerformanceReview:
    def test_no_data(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        result = generate_performance_review(cfo, state)
        assert "No data" in result

    def test_with_data(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        cfo.record("Lead Dev", "claude-opus-4-6", 10000, 5000, sprint=1)
        cfo.record("QA", "claude-sonnet-4-6", 8000, 3000, sprint=1)

        result = generate_performance_review(cfo, state)
        assert "Performance Review" in result
        assert "Lead Dev" in result
        assert "QA" in result
        assert "Total org spend" in result

    def test_includes_model_tier_efficiency(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        cfo.record("A", "claude-opus-4-6", 10000, 5000, sprint=1)
        cfo.record("B", "claude-sonnet-4-6", 8000, 3000, sprint=1)

        result = generate_performance_review(cfo, state)
        assert "Model Tier" in result

    def test_includes_sprint_trend_with_multiple_sprints(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        cfo.record("A", "claude-opus-4-6", 10000, 5000, sprint=1)
        cfo.record("A", "claude-opus-4-6", 8000, 3000, sprint=2)

        result = generate_performance_review(cfo, state)
        assert "Sprint Cost Trend" in result
        assert "Sprint 1" in result
        assert "Sprint 2" in result
        assert "Average" in result

    def test_no_sprint_trend_with_single_sprint(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        cfo.record("A", "claude-opus-4-6", 10000, 5000, sprint=1)

        result = generate_performance_review(cfo, state)
        assert "Sprint Cost Trend" not in result

    def test_includes_recommendations(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        cfo.record("A", "claude-opus-4-6", 10000, 5000, sprint=1)

        result = generate_performance_review(cfo, state)
        assert "Recommendations" in result

    def test_percentage_calculation(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", description="Test")
        state.init(config)

        # Only one agent - should be 100%
        cfo.record("Solo", "claude-opus-4-6", 10000, 5000, sprint=1)

        result = generate_performance_review(cfo, state)
        assert "100.0%" in result


# ---------------------------------------------------------------------------
# generate_onboarding_brief
# ---------------------------------------------------------------------------

class TestGenerateOnboardingBrief:
    def test_invokes_secretary(self, mock_engine, state, secretary):
        result = generate_onboarding_brief(mock_engine, secretary, state)
        assert result == "Mock agent response"
        mock_engine.invoke.assert_called_once()

    def test_includes_project_info_in_prompt(self, mock_engine, state, secretary):
        generate_onboarding_brief(mock_engine, secretary, state)
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "TestProject" in call_kwargs["user_message"]

    def test_includes_existing_notes(self, mock_engine, state, secretary):
        """If notes exist, they should be included in the prompt."""
        notes_dir = state.notes_dir
        notes_dir.mkdir(parents=True, exist_ok=True)
        (notes_dir / "standup.md").write_text("Standup notes from sprint 1")

        generate_onboarding_brief(mock_engine, secretary, state)
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "Standup notes from sprint 1" in call_kwargs["user_message"]

    def test_no_notes_dir_still_works(self, mock_engine, secretary, tmp_path):
        """If notes dir doesn't exist, should still work."""
        s = StateManager(tmp_path)
        config = ProjectConfig(name="NoNotes", description="No notes yet")
        s.init(config)

        result = generate_onboarding_brief(mock_engine, secretary, s)
        assert result == "Mock agent response"


# ---------------------------------------------------------------------------
# enrich_context_with_experience
# ---------------------------------------------------------------------------

class TestEnrichContextWithExperience:
    def test_returns_unchanged_for_non_consultant(self, state):
        persona = Persona(
            role_type=RoleType.LEAD_DEV,
            name="Cody",
            title="Lead Developer",
            job_description="Build things",
        )
        ctx = "Project: Test\nSprint: 1"
        assert enrich_context_with_experience(state, persona, ctx) == ctx

    def test_returns_unchanged_for_consultant_with_no_outcomes(self, state):
        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="Maya",
            title="DB Expert",
            job_description="Database work",
        )
        state.save_persona(persona)
        ctx = "Project: Test\nSprint: 1"
        assert enrich_context_with_experience(state, persona, ctx) == ctx

    def test_appends_experience_for_consultant_with_outcomes(self, state):
        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="Maya",
            title="DB Expert",
            job_description="Database work",
        )
        state.save_persona(persona)
        record = ConsultantRecord(name="Maya", outcomes=[
            TaskOutcome(sprint_number=1, task_id="t1", task_description="task", passed=True, retries=0),
        ])
        state.save_consultant_record(record)
        ctx = "Project: Test\nSprint: 1"
        result = enrich_context_with_experience(state, persona, ctx)
        assert result.startswith(ctx)
        assert "Your Work Experience:" in result
        assert "Tasks completed: 1/1" in result
