"""Tests for odd.roles - core team creation and recruiter pipeline."""

from unittest.mock import MagicMock, patch

import pytest

from odd.agent import AgentEngine
from odd.models import ModelTier, Persona, RoleType
from odd.provider import AgentResponse, Usage
from odd.roles import create_core_team, recruit_consultant


# ---------------------------------------------------------------------------
# create_core_team
# ---------------------------------------------------------------------------

class TestCreateCoreTeam:
    def test_returns_four_members(self):
        team = create_core_team()
        assert set(team.keys()) == {"lead_dev", "qa", "recruiter", "secretary"}

    def test_role_types(self):
        team = create_core_team()
        assert team["lead_dev"].role_type == RoleType.LEAD_DEV
        assert team["qa"].role_type == RoleType.QA
        assert team["recruiter"].role_type == RoleType.RECRUITER
        assert team["secretary"].role_type == RoleType.SECRETARY

    def test_default_models(self):
        team = create_core_team()
        assert team["lead_dev"].effective_model() == ModelTier.HIGH
        assert team["qa"].effective_model() == ModelTier.HIGH
        assert team["recruiter"].effective_model() == ModelTier.STANDARD
        assert team["secretary"].effective_model() == ModelTier.STANDARD

    def test_model_overrides(self):
        overrides = {
            RoleType.LEAD_DEV: ModelTier.FAST,
            RoleType.QA: ModelTier.STANDARD,
        }
        team = create_core_team(overrides)
        assert team["lead_dev"].effective_model() == ModelTier.FAST
        assert team["qa"].effective_model() == ModelTier.STANDARD
        # Non-overridden stays default
        assert team["recruiter"].effective_model() == ModelTier.STANDARD

    def test_all_have_job_descriptions(self):
        team = create_core_team()
        for persona in team.values():
            assert persona.job_description, f"{persona.name} missing JD"

    def test_all_have_names_and_titles(self):
        team = create_core_team()
        for persona in team.values():
            assert persona.name
            assert persona.title

    def test_qa_is_glitch_hunter(self):
        team = create_core_team()
        assert "Glitch Hunter" in team["qa"].name or "Glitch Hunter" in team["qa"].title


# ---------------------------------------------------------------------------
# recruit_consultant - mocked API
# ---------------------------------------------------------------------------

class TestRecruitConsultant:
    """Test the recruiter pipeline with a mocked AgentEngine."""

    def _mock_engine(self, resume_text: str) -> AgentEngine:
        mock_provider = MagicMock()
        mock_provider.create_message.return_value = AgentResponse(
            text_blocks=[resume_text], tool_calls=[], stop_reason="end_turn",
            usage=Usage(input_tokens=100, output_tokens=50),
        )
        engine = AgentEngine(provider=mock_provider)
        # invoke is called twice: recruiter + self-refinement
        engine.invoke = MagicMock(return_value=resume_text)
        # pop_submissions is called twice: after recruiter, after refinement
        engine.pop_submissions = MagicMock(return_value=[])
        return engine

    def _recruiter(self) -> Persona:
        return Persona(
            role_type=RoleType.RECRUITER,
            name="Recruiter",
            title="Technical Recruiter",
            job_description="Find talent",
        )

    def test_parses_name_and_title(self):
        resume = (
            "NAME: Alice Chen\n"
            "TITLE: Senior Security Architect\n\n"
            "10 years of experience in application security..."
        )
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "Security expert needed")

        assert result.name == "Alice Chen"
        assert result.title == "Senior Security Architect"
        assert result.role_type == RoleType.CONSULTANT
        assert result.resume == resume
        assert result.job_description == "Security expert needed"

    def test_explicit_name_overrides_parsed(self):
        """When consultant_name is passed, it takes precedence over NAME: in resume."""
        resume = (
            "NAME: Generated Name\n"
            "TITLE: DevOps Engineer\n\n"
            "Background..."
        )
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "DevOps JD", consultant_name="Bob Override")

        assert result.name == "Bob Override"
        # Title should still be parsed from resume
        assert result.title == "DevOps Engineer"

    def test_explicit_name_used_for_title_fallback(self):
        """When consultant_name is passed but no TITLE: in resume, title falls back to name."""
        resume = "Just a resume with no structured NAME: or TITLE: lines."
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD", consultant_name="Alice")

        assert result.name == "Alice"
        assert result.title == "Alice"  # Falls back to consultant_name

    def test_no_name_no_parsed_name_fallback(self):
        """When no consultant_name and no NAME: in resume, defaults to 'Consultant'."""
        resume = "A resume without any structured lines at all."
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "Generic JD")

        assert result.name == "Consultant"
        assert result.title == "Consultant"  # title defaults to name

    def test_name_line_in_middle_of_resume(self):
        """NAME: line doesn't have to be first."""
        resume = (
            "Here is the ideal candidate:\n\n"
            "NAME: Deep In Resume\n"
            "TITLE: Backend Specialist\n"
            "Details follow..."
        )
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.name == "Deep In Resume"
        assert result.title == "Backend Specialist"

    def test_case_insensitive_name_title(self):
        """name: and title: should work regardless of case."""
        resume = "name: Case Test\ntitle: Case Title\nResume body"
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.name == "Case Test"
        assert result.title == "Case Title"

    def test_invokes_engine_with_correct_args(self):
        engine = self._mock_engine("NAME: X\nTITLE: Y\n")
        recruiter = self._recruiter()
        recruit_consultant(engine, recruiter, "Find a DB expert")

        # First call is the recruiter, second is the self-refinement
        assert engine.invoke.call_count == 2
        recruiter_call = engine.invoke.call_args_list[0]
        assert recruiter_call.kwargs["persona"] is recruiter
        assert "DB expert" in recruiter_call.kwargs["user_message"]
        assert recruiter_call.kwargs["tools"] is False

    def test_resume_stored_in_persona(self):
        resume = "NAME: X\nTITLE: Y\nFull resume content here."
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.resume == resume

    def test_multiple_name_lines_last_wins(self):
        """If multiple NAME: lines exist, the last one wins (loop overwrites)."""
        resume = "NAME: First\nNAME: Second\nTITLE: Title\n"
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.name == "Second"

    def test_title_without_name_still_sets_title(self):
        """If there's a TITLE: but no NAME:, name defaults but title is parsed."""
        resume = "TITLE: Expert Title\nResume body"
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.name == "Consultant"  # fallback
        assert result.title == "Expert Title"

    def test_empty_resume(self):
        """Edge case: empty string from engine."""
        engine = self._mock_engine("")
        result = recruit_consultant(engine, self._recruiter(), "JD")

        assert result.name == "Consultant"
        assert result.title == "Consultant"
        assert result.resume == ""

    def test_model_tier_parameter_sets_model(self):
        """When model_tier is provided, the consultant's model is set."""
        resume = "NAME: Alice\nTITLE: Architect\n"
        engine = self._mock_engine(resume)
        result = recruit_consultant(
            engine, self._recruiter(), "JD", model_tier=ModelTier.HIGH,
        )
        assert result.model == ModelTier.HIGH
        assert result.effective_model() == ModelTier.HIGH

    def test_model_tier_fast(self):
        """Fast tier is correctly applied."""
        resume = "NAME: Bob\nTITLE: Formatter\n"
        engine = self._mock_engine(resume)
        result = recruit_consultant(
            engine, self._recruiter(), "JD", model_tier=ModelTier.FAST,
        )
        assert result.model == ModelTier.FAST
        assert result.effective_model() == ModelTier.FAST

    def test_model_tier_none_uses_default(self):
        """When model_tier is None, consultant uses default for role."""
        resume = "NAME: Carol\nTITLE: Dev\n"
        engine = self._mock_engine(resume)
        result = recruit_consultant(engine, self._recruiter(), "JD")
        assert result.model is None
        assert result.effective_model() == ModelTier.STANDARD  # CONSULTANT default

    def test_model_tier_with_consultant_name(self):
        """model_tier works alongside consultant_name."""
        resume = "NAME: Generated\nTITLE: Expert\n"
        engine = self._mock_engine(resume)
        result = recruit_consultant(
            engine, self._recruiter(), "JD",
            consultant_name="Override",
            model_tier=ModelTier.HIGH,
        )
        assert result.name == "Override"
        assert result.model == ModelTier.HIGH

    def test_resume_refinement_called(self):
        """Engine should be invoked twice: recruiter + self-refinement."""
        resume = "NAME: Alice\nTITLE: Dev\nOriginal resume."
        engine = self._mock_engine(resume)
        recruit_consultant(engine, self._recruiter(), "JD")

        assert engine.invoke.call_count == 2
        # Second call should be the refinement - prompt mentions "preparing to apply"
        refinement_call = engine.invoke.call_args_list[1]
        assert "preparing to apply" in refinement_call.kwargs["user_message"]

    def test_refinement_updates_resume(self):
        """When refinement submits, the improved resume replaces the original."""
        resume = "NAME: Alice\nTITLE: Dev\nVague resume."
        engine = self._mock_engine(resume)

        # First pop_submissions (recruiter): no structured submission
        # Second pop_submissions (refinement): has improved resume
        engine.pop_submissions = MagicMock(side_effect=[
            [],  # recruiter call - parsed from text
            [{"tool": "submit_candidate", "data": {
                "name": "Alice", "title": "Dev",
                "resume": "Specific improved resume with concrete details.",
            }}],
        ])

        result = recruit_consultant(engine, self._recruiter(), "JD")
        assert result.resume == "Specific improved resume with concrete details."

    def test_refinement_failure_falls_back(self):
        """If refinement raises, original resume is preserved."""
        resume = "NAME: Alice\nTITLE: Dev\nOriginal resume."
        engine = self._mock_engine(resume)

        # invoke succeeds first time (recruiter), fails second time (refinement)
        engine.invoke = MagicMock(side_effect=[resume, RuntimeError("API down")])

        result = recruit_consultant(engine, self._recruiter(), "JD")
        assert result.resume == resume
        assert result.name == "Alice"
