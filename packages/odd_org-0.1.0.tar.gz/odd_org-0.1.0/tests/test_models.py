"""Tests for odd.models - enums, Pydantic models, model tier resolution."""

import pytest
from pydantic import ValidationError

from odd.models import (
    CEOGate,
    CEOInvolvement,
    CEOStyle,
    ConsultantRecord,
    DEFAULT_MODEL_MAP,
    RESERVED_SLUGS,
    ModelTier,
    Persona,
    ProjectConfig,
    RoleType,
    Sprint,
    SprintStatus,
    SprintTask,
    TaskOutcome,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TestModelTier:
    def test_values_are_capability_tiers(self):
        assert ModelTier.HIGH.value == "high"
        assert ModelTier.STANDARD.value == "standard"
        assert ModelTier.FAST.value == "fast"

    def test_is_str_enum(self):
        # ModelTier values can be used as plain strings
        assert isinstance(ModelTier.HIGH, str)

    def test_from_name_alias(self):
        assert ModelTier.from_name("opus") == ModelTier.HIGH
        assert ModelTier.from_name("sonnet") == ModelTier.STANDARD
        assert ModelTier.from_name("haiku") == ModelTier.FAST

    def test_from_name_value(self):
        assert ModelTier.from_name("high") == ModelTier.HIGH
        assert ModelTier.from_name("standard") == ModelTier.STANDARD
        assert ModelTier.from_name("fast") == ModelTier.FAST

    def test_from_name_case_insensitive(self):
        assert ModelTier.from_name("OPUS") == ModelTier.HIGH
        assert ModelTier.from_name("Sonnet") == ModelTier.STANDARD

    def test_from_name_unknown_returns_standard(self):
        assert ModelTier.from_name("gpt4") == ModelTier.STANDARD
        assert ModelTier.from_name("") == ModelTier.STANDARD


class TestRoleType:
    def test_all_roles_present(self):
        names = {r.value for r in RoleType}
        assert names == {"lead_dev", "qa", "recruiter", "secretary", "consultant"}

    def test_is_str_enum(self):
        assert isinstance(RoleType.LEAD_DEV, str)


class TestCEOStyle:
    def test_values(self):
        assert CEOStyle.HANDS_ON.value == "hands_on"
        assert CEOStyle.BALANCED.value == "balanced"
        assert CEOStyle.DELEGATOR.value == "delegator"

    def test_is_str_enum(self):
        assert isinstance(CEOStyle.BALANCED, str)


class TestCEOGate:
    def test_all_gates(self):
        expected = {"streaming", "war_room", "escalations", "plan_approval",
                    "code_review", "ship_approval", "hiring"}
        assert {g.value for g in CEOGate} == expected

    def test_is_str_enum(self):
        assert isinstance(CEOGate.STREAMING, str)


class TestCEOInvolvement:
    def test_from_ceo_style_hands_on(self):
        assert CEOInvolvement.from_ceo_style(CEOStyle.HANDS_ON) == CEOInvolvement.EVERY_SPRINT

    def test_from_ceo_style_balanced(self):
        assert CEOInvolvement.from_ceo_style(CEOStyle.BALANCED) == CEOInvolvement.MILESTONES

    def test_from_ceo_style_delegator(self):
        assert CEOInvolvement.from_ceo_style(CEOStyle.DELEGATOR) == CEOInvolvement.BLOCKERS_ONLY


class TestSprintStatus:
    def test_all_statuses(self):
        names = {s.value for s in SprintStatus}
        assert names == {"planning", "in_progress", "review", "demo", "complete", "cancelled"}


# ---------------------------------------------------------------------------
# DEFAULT_MODEL_MAP
# ---------------------------------------------------------------------------

class TestDefaultModelMap:
    def test_every_role_has_default(self):
        for role in RoleType:
            assert role in DEFAULT_MODEL_MAP

    def test_thinking_roles_use_high(self):
        assert DEFAULT_MODEL_MAP[RoleType.LEAD_DEV] == ModelTier.HIGH
        assert DEFAULT_MODEL_MAP[RoleType.QA] == ModelTier.HIGH

    def test_execution_roles_use_standard(self):
        assert DEFAULT_MODEL_MAP[RoleType.RECRUITER] == ModelTier.STANDARD
        assert DEFAULT_MODEL_MAP[RoleType.SECRETARY] == ModelTier.STANDARD
        assert DEFAULT_MODEL_MAP[RoleType.CONSULTANT] == ModelTier.STANDARD


# ---------------------------------------------------------------------------
# Persona
# ---------------------------------------------------------------------------

class TestPersona:
    def test_effective_model_default(self):
        p = Persona(role_type=RoleType.LEAD_DEV, name="Alice", title="Lead Dev")
        assert p.effective_model() == ModelTier.HIGH

    def test_effective_model_override(self):
        p = Persona(
            role_type=RoleType.LEAD_DEV,
            name="Alice",
            title="Lead Dev",
            model=ModelTier.FAST,
        )
        assert p.effective_model() == ModelTier.FAST

    def test_optional_fields_default_empty(self):
        p = Persona(role_type=RoleType.QA, name="Bob", title="QA")
        assert p.job_description == ""
        assert p.resume == ""
        assert p.model is None

    def test_roundtrip_json(self):
        p = Persona(
            role_type=RoleType.CONSULTANT,
            name="Carol",
            title="Security Expert",
            job_description="Pen testing",
            resume="10 years experience",
            model=ModelTier.STANDARD,
        )
        raw = p.model_dump_json()
        p2 = Persona.model_validate_json(raw)
        assert p2 == p

    # --- Reserved name protection ---

    def test_consultant_named_cody_rejected(self):
        with pytest.raises(ValidationError, match="reserved core team name"):
            Persona(role_type=RoleType.CONSULTANT, name="Cody", title="Impersonator")

    def test_consultant_named_vera_rejected(self):
        with pytest.raises(ValidationError, match="reserved core team name"):
            Persona(role_type=RoleType.CONSULTANT, name="Vera", title="Fake QA")

    def test_consultant_named_paige_rejected(self):
        with pytest.raises(ValidationError, match="reserved core team name"):
            Persona(role_type=RoleType.CONSULTANT, name="Paige", title="Spy")

    def test_consultant_named_bill_rejected(self):
        with pytest.raises(ValidationError, match="reserved core team name"):
            Persona(role_type=RoleType.CONSULTANT, name="Bill", title="Fake CFO")

    def test_consultant_named_scout_rejected(self):
        with pytest.raises(ValidationError, match="reserved core team name"):
            Persona(role_type=RoleType.CONSULTANT, name="Scout", title="Recruiter Clone")

    def test_core_team_with_reserved_name_allowed(self):
        """Core team members can use reserved names (they're the real ones)."""
        p = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")
        assert p.name == "Cody"

    def test_consultant_with_non_reserved_name_allowed(self):
        """Normal consultant names are fine."""
        p = Persona(role_type=RoleType.CONSULTANT, name="Alice", title="Expert")
        assert p.name == "Alice"

    def test_consultant_similar_but_different_name_allowed(self):
        """A name that contains a reserved name but has a different slug is fine."""
        p = Persona(role_type=RoleType.CONSULTANT, name="Cody Smith", title="Dev")
        assert p.name == "Cody Smith"  # slug is "cody_smith", not "cody"

    def test_reserved_slugs_includes_all_core_names(self):
        assert RESERVED_SLUGS == {"cody", "vera", "scout", "paige", "bill"}

    def test_cyrillic_homoglyph_cody_rejected(self):
        """Cyrillic 'С' (U+0421) looks like Latin 'C' - must be caught."""
        with pytest.raises(ValidationError, match="non-ASCII"):
            # \u0421 is Cyrillic Es, visually identical to Latin C
            Persona(role_type=RoleType.CONSULTANT, name="\u0421ody", title="Impersonator")

    def test_roman_numeral_homoglyph_vera_rejected(self):
        """Roman numeral Ⅴ (U+2164) looks like Latin 'V' - must be caught."""
        with pytest.raises(ValidationError, match="non-ASCII"):
            Persona(role_type=RoleType.CONSULTANT, name="\u2164era", title="Fake QA")

    def test_pure_non_ascii_name_rejected(self):
        """A name with no ASCII letters at all is rejected."""
        with pytest.raises(ValidationError, match="non-ASCII"):
            Persona(role_type=RoleType.CONSULTANT, name="\u0410\u0411\u0412", title="Ghost")

    def test_ascii_zero_for_o_confusable_rejected(self):
        """'C0dy' (zero for 'o') is visually confusable with 'Cody'."""
        with pytest.raises(ValidationError, match="visually confusable"):
            Persona(role_type=RoleType.CONSULTANT, name="C0dy", title="Impersonator")

    def test_ascii_one_for_l_confusable_rejected(self):
        """'Bi1l' (one for 'l') is visually confusable with 'Bill'."""
        with pytest.raises(ValidationError, match="visually confusable"):
            Persona(role_type=RoleType.CONSULTANT, name="Bi1l", title="Fake CFO")

    def test_ascii_five_for_s_confusable_rejected(self):
        """'5cout' (five for 's') is visually confusable with 'Scout'."""
        with pytest.raises(ValidationError, match="visually confusable"):
            Persona(role_type=RoleType.CONSULTANT, name="5cout", title="Fake Recruiter")

    def test_ascii_eight_for_b_confusable_rejected(self):
        """'8ill' (eight for 'b') is visually confusable with 'Bill'."""
        with pytest.raises(ValidationError, match="visually confusable"):
            Persona(role_type=RoleType.CONSULTANT, name="8ill", title="Fake CFO")

    def test_ascii_three_for_e_confusable_rejected(self):
        """'V3ra' (three for 'e') is visually confusable with 'Vera'."""
        with pytest.raises(ValidationError, match="visually confusable"):
            Persona(role_type=RoleType.CONSULTANT, name="V3ra", title="Fake QA")

    def test_non_confusable_digit_name_allowed(self):
        """A name with digits that don't create a reserved collision is fine."""
        p = Persona(role_type=RoleType.CONSULTANT, name="Agent007", title="Spy")
        assert p.name == "Agent007"


# ---------------------------------------------------------------------------
# SprintTask
# ---------------------------------------------------------------------------

class TestSprintTask:
    def test_defaults(self):
        t = SprintTask(id="s1_t1", description="Build the thing", assigned_to="Lead Dev")
        assert t.status == "pending"
        assert t.test_file is None

    def test_roundtrip(self):
        t = SprintTask(
            id="s2_t3",
            description="Fix bug",
            assigned_to="QA",
            status="done",
            test_file="tests/test_bug.py",
        )
        raw = t.model_dump_json()
        t2 = SprintTask.model_validate_json(raw)
        assert t2 == t


# ---------------------------------------------------------------------------
# Sprint
# ---------------------------------------------------------------------------

class TestSprint:
    def test_defaults(self):
        s = Sprint(number=1, goal="Ship MVP")
        assert s.tasks == []
        assert s.status == SprintStatus.PLANNING
        assert s.standup_log == []
        assert s.notes == ""

    def test_with_tasks(self):
        task = SprintTask(id="s1_t1", description="Do stuff", assigned_to="Lead Dev")
        s = Sprint(number=1, goal="Ship it", tasks=[task])
        assert len(s.tasks) == 1
        assert s.tasks[0].id == "s1_t1"

    def test_roundtrip(self):
        task = SprintTask(id="s1_t1", description="Do stuff", assigned_to="Lead Dev")
        s = Sprint(
            number=3,
            goal="Polish",
            tasks=[task],
            status=SprintStatus.REVIEW,
            standup_log=[{"summary": "all good"}],
            notes="Looking great",
        )
        raw = s.model_dump_json()
        s2 = Sprint.model_validate_json(raw)
        assert s2.number == 3
        assert s2.status == SprintStatus.REVIEW
        assert len(s2.tasks) == 1


# ---------------------------------------------------------------------------
# ProjectConfig
# ---------------------------------------------------------------------------

class TestProjectConfig:
    def test_defaults(self):
        c = ProjectConfig(name="MyProject")
        assert c.description == ""
        assert c.model_overrides == {}
        assert c.current_sprint == 0
        assert c.ceo_style == CEOStyle.BALANCED

    def test_ceo_style_override(self):
        c = ProjectConfig(name="P", ceo_style=CEOStyle.HANDS_ON)
        assert c.ceo_style == CEOStyle.HANDS_ON

    def test_ceo_style_roundtrip(self):
        c = ProjectConfig(name="P", ceo_style=CEOStyle.DELEGATOR)
        raw = c.model_dump_json()
        c2 = ProjectConfig.model_validate_json(raw)
        assert c2.ceo_style == CEOStyle.DELEGATOR

    def test_ceo_overrides_default_empty(self):
        c = ProjectConfig(name="P")
        assert c.ceo_overrides == {}

    def test_style_at_returns_default(self):
        c = ProjectConfig(name="P", ceo_style=CEOStyle.DELEGATOR)
        assert c.style_at(CEOGate.STREAMING) == CEOStyle.DELEGATOR
        assert c.style_at(CEOGate.HIRING) == CEOStyle.DELEGATOR

    def test_style_at_with_override(self):
        c = ProjectConfig(
            name="P", ceo_style=CEOStyle.BALANCED,
            ceo_overrides={CEOGate.WAR_ROOM: CEOStyle.HANDS_ON},
        )
        assert c.style_at(CEOGate.WAR_ROOM) == CEOStyle.HANDS_ON
        assert c.style_at(CEOGate.STREAMING) == CEOStyle.BALANCED

    def test_ceo_overrides_roundtrip(self):
        c = ProjectConfig(
            name="P", ceo_style=CEOStyle.BALANCED,
            ceo_overrides={
                CEOGate.WAR_ROOM: CEOStyle.HANDS_ON,
                CEOGate.HIRING: CEOStyle.DELEGATOR,
            },
        )
        raw = c.model_dump_json()
        c2 = ProjectConfig.model_validate_json(raw)
        assert c2.ceo_overrides[CEOGate.WAR_ROOM] == CEOStyle.HANDS_ON
        assert c2.ceo_overrides[CEOGate.HIRING] == CEOStyle.DELEGATOR
        assert c2.style_at(CEOGate.STREAMING) == CEOStyle.BALANCED

    def test_get_model_default(self):
        c = ProjectConfig(name="P")
        assert c.get_model(RoleType.LEAD_DEV) == ModelTier.HIGH
        assert c.get_model(RoleType.CONSULTANT) == ModelTier.STANDARD

    def test_get_model_override(self):
        c = ProjectConfig(
            name="P",
            model_overrides={RoleType.LEAD_DEV: ModelTier.FAST},
        )
        assert c.get_model(RoleType.LEAD_DEV) == ModelTier.FAST
        # Non-overridden role still uses default
        assert c.get_model(RoleType.QA) == ModelTier.HIGH

    def test_roundtrip(self):
        c = ProjectConfig(
            name="Test",
            description="A test project",
            model_overrides={RoleType.QA: ModelTier.STANDARD},
            current_sprint=5,
        )
        raw = c.model_dump_json()
        c2 = ProjectConfig.model_validate_json(raw)
        assert c2.name == "Test"
        assert c2.current_sprint == 5


# ---------------------------------------------------------------------------
# Submission Tool Schemas
# ---------------------------------------------------------------------------

class TestSubmitTestReviewDecisionSchema:
    def test_schema_exists_and_has_required_fields(self):
        from odd.tools.schemas import SUBMIT_TEST_REVIEW_DECISION

        assert SUBMIT_TEST_REVIEW_DECISION["name"] == "submit_test_review_decision"
        props = SUBMIT_TEST_REVIEW_DECISION["parameters"]["properties"]
        assert "verdict" in props
        assert "reason" in props
        assert "test_file" in props
        assert props["verdict"]["enum"] == ["accept", "reject"]

    def test_schema_in_submission_tool_names(self):
        from odd.tools.schemas import SUBMISSION_TOOL_NAMES

        assert "submit_test_review_decision" in SUBMISSION_TOOL_NAMES


# ---------------------------------------------------------------------------
# ConsultantRecord - work experience properties
# ---------------------------------------------------------------------------

def _make_outcome(sprint: int, passed: bool, retries: int = 0, task_id: str = "t1") -> TaskOutcome:
    return TaskOutcome(
        sprint_number=sprint, task_id=task_id,
        task_description="test task", passed=passed, retries=retries,
    )


class TestConsultantRecord:
    def test_empty_record(self):
        r = ConsultantRecord(name="Alice")
        assert r.summary() == "no track record"
        assert r.first_run_pass_rate == 0.0
        assert r.self_correction_rate == 0.0
        assert r.tasks_still_failing == 0
        assert r.max_retries == 0
        assert r.tenure == 0
        assert r.total_tasks == 0
        assert r.retry_trend == 0.0

    def test_first_run_pass_rate(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),
            _make_outcome(1, passed=True, retries=2, task_id="t2"),
            _make_outcome(1, passed=False, retries=3, task_id="t3"),
        ])
        # Only 1 of 3 tasks passed on first try
        assert r.first_run_pass_rate == pytest.approx(1 / 3)

    def test_self_correction_rate(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),   # no retries needed
            _make_outcome(1, passed=True, retries=2, task_id="t2"),   # retried and passed
            _make_outcome(1, passed=False, retries=3, task_id="t3"),  # retried and failed
        ])
        # 2 tasks needed retries, 1 of those passed -> 50%
        assert r.self_correction_rate == pytest.approx(0.5)

    def test_self_correction_rate_no_retries_needed(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0),
        ])
        assert r.self_correction_rate == 0.0

    def test_tasks_still_failing(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),
            _make_outcome(1, passed=False, retries=3, task_id="t2"),
            _make_outcome(2, passed=False, retries=2, task_id="t3"),
        ])
        assert r.tasks_still_failing == 2

    def test_max_retries(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=1, task_id="t1"),
            _make_outcome(1, passed=True, retries=5, task_id="t2"),
            _make_outcome(2, passed=False, retries=3, task_id="t3"),
        ])
        assert r.max_retries == 5

    def test_sprints_participated(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, task_id="t1"),
            _make_outcome(3, passed=True, task_id="t2"),
            _make_outcome(1, passed=True, task_id="t3"),
        ])
        assert r.sprints_participated == [1, 3]
        assert r.tenure == 2

    def test_retry_trend_improving(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=4, task_id="t1"),
            _make_outcome(2, passed=True, retries=3, task_id="t2"),
            _make_outcome(3, passed=True, retries=1, task_id="t3"),
            _make_outcome(4, passed=True, retries=0, task_id="t4"),
        ])
        # Old sprints (1,2) avg retries = 3.5, new sprints (3,4) avg = 0.5
        assert r.retry_trend < 0  # negative = improving

    def test_retry_trend_worsening(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),
            _make_outcome(2, passed=True, retries=1, task_id="t2"),
            _make_outcome(3, passed=True, retries=3, task_id="t3"),
            _make_outcome(4, passed=True, retries=5, task_id="t4"),
        ])
        assert r.retry_trend > 0  # positive = worsening

    def test_retry_trend_single_sprint(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=2),
        ])
        assert r.retry_trend == 0.0  # not enough data

    def test_summary_format(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),
            _make_outcome(2, passed=True, retries=2, task_id="t2"),
            _make_outcome(3, passed=False, retries=3, task_id="t3"),
        ])
        s = r.summary()
        assert "2/3 tasks passed" in s
        assert "first-run" in s
        assert "retries" in s

    def test_summary_includes_sprints_when_multiple(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, task_id="t1"),
            _make_outcome(2, passed=True, task_id="t2"),
        ])
        assert "2 sprints" in r.summary()

    def test_experience_summary(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0, task_id="t1"),
            _make_outcome(1, passed=True, retries=2, task_id="t2"),
            _make_outcome(2, passed=False, retries=3, task_id="t3"),
        ])
        s = r.experience_summary()
        assert "Tasks completed: 2/3" in s
        assert "First-run pass rate:" in s
        assert "Self-correction rate:" in s
        assert "Unresolved tasks: 1" in s

    def test_experience_summary_empty(self):
        r = ConsultantRecord(name="Alice")
        assert r.experience_summary() == "No work experience recorded yet."

    def test_roundtrip_json(self):
        r = ConsultantRecord(name="Alice", outcomes=[
            _make_outcome(1, passed=True, retries=0),
            _make_outcome(2, passed=False, retries=3),
        ])
        raw = r.model_dump_json()
        r2 = ConsultantRecord.model_validate_json(raw)
        assert r2.name == r.name
        assert len(r2.outcomes) == 2
        assert r2.first_run_pass_rate == r.first_run_pass_rate
