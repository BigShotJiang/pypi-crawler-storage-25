"""Tests for odd.agent - prompt building, persona notes, engine invoke (mocked)."""

from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from odd.agent import (
    ROLE_PREAMBLES,
    AgentEngine,
    AgentStuckError,
    BudgetExceededError,
    MaxIterationsError,
    build_system_prompt,
    load_persona_notes,
)
from odd.models import ModelTier, Persona, RoleType
from odd.provider import AgentResponse, ToolCall, Usage


# ---------------------------------------------------------------------------
# ROLE_PREAMBLES
# ---------------------------------------------------------------------------

class TestRolePreambles:
    def test_every_role_has_preamble(self):
        for role in RoleType:
            assert role in ROLE_PREAMBLES
            assert len(ROLE_PREAMBLES[role]) > 50  # Not a stub

    def test_lead_dev_mentions_technical(self):
        assert "technical" in ROLE_PREAMBLES[RoleType.LEAD_DEV].lower()

    def test_qa_mentions_tests(self):
        preamble = ROLE_PREAMBLES[RoleType.QA].lower()
        assert "test" in preamble

    def test_consultant_mentions_specialist(self):
        preamble = ROLE_PREAMBLES[RoleType.CONSULTANT].lower()
        assert "specialized" in preamble or "specialist" in preamble or "specialty" in preamble


# ---------------------------------------------------------------------------
# build_system_prompt
# ---------------------------------------------------------------------------

class TestBuildSystemPrompt:
    def _lead_dev(self):
        return Persona(
            role_type=RoleType.LEAD_DEV,
            name="Lead Dev",
            title="Lead Developer",
            job_description="Build the product",
            resume="10 years of experience",
        )

    def test_includes_role_preamble(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona)
        assert ROLE_PREAMBLES[RoleType.LEAD_DEV] in prompt

    def test_includes_job_description(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona)
        assert "Build the product" in prompt

    def test_includes_resume(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona)
        assert "10 years of experience" in prompt

    def test_includes_project_context(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona, project_context="Sprint 3 in progress")
        assert "Sprint 3 in progress" in prompt

    def test_includes_company_values(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona, company_values="Ship fast, break nothing")
        assert "Ship fast, break nothing" in prompt

    def test_includes_working_dir_section(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona)
        assert "Working Directory" in prompt

    def test_minimal_persona(self):
        """Persona with no JD or resume should still produce a valid prompt."""
        persona = Persona(role_type=RoleType.QA, name="QA", title="QA")
        prompt = build_system_prompt(persona)
        assert ROLE_PREAMBLES[RoleType.QA] in prompt
        assert "Working Directory" in prompt

    def test_sections_separated(self):
        persona = self._lead_dev()
        prompt = build_system_prompt(persona, project_context="ctx", company_values="vals")
        # Each section should be separated by double newlines
        assert "\n\n" in prompt

    def test_no_jd_section_when_empty(self):
        persona = Persona(role_type=RoleType.QA, name="QA", title="QA", job_description="")
        prompt = build_system_prompt(persona)
        assert "Job Description" not in prompt

    def test_no_resume_section_when_empty(self):
        persona = Persona(role_type=RoleType.QA, name="QA", title="QA", resume="")
        prompt = build_system_prompt(persona)
        assert "Your Background" not in prompt

    def test_all_role_types_produce_valid_prompt(self):
        for role in RoleType:
            persona = Persona(role_type=role, name="Test", title="Test")
            prompt = build_system_prompt(persona)
            assert len(prompt) > 50


# ---------------------------------------------------------------------------
# load_persona_notes
# ---------------------------------------------------------------------------

class TestLoadPersonaNotes:
    def test_no_notes_dir(self, tmp_path):
        persona = Persona(role_type=RoleType.LEAD_DEV, name="LD", title="LD")
        result = load_persona_notes(persona, tmp_path / "nonexistent")
        assert result == ""

    def test_loads_md_files(self, tmp_path):
        notes_dir = tmp_path / "notes"
        notes_dir.mkdir()
        (notes_dir / "standup.md").write_text("standup notes here")
        (notes_dir / "retro.md").write_text("retro notes here")

        persona = Persona(role_type=RoleType.LEAD_DEV, name="LD", title="LD")
        result = load_persona_notes(persona, notes_dir)
        assert "standup" in result
        assert "retro" in result
        assert "standup notes here" in result
        assert "retro notes here" in result

    def test_ignores_non_md_files(self, tmp_path):
        notes_dir = tmp_path / "notes"
        notes_dir.mkdir()
        (notes_dir / "notes.md").write_text("real notes")
        (notes_dir / "data.json").write_text("{}")

        persona = Persona(role_type=RoleType.LEAD_DEV, name="LD", title="LD")
        result = load_persona_notes(persona, notes_dir)
        assert "real notes" in result
        assert "{}" not in result

    def test_empty_notes_dir(self, tmp_path):
        notes_dir = tmp_path / "notes"
        notes_dir.mkdir()
        persona = Persona(role_type=RoleType.LEAD_DEV, name="LD", title="LD")
        result = load_persona_notes(persona, notes_dir)
        assert result == ""


# ---------------------------------------------------------------------------
# AgentEngine (mocked - no real API calls)
# ---------------------------------------------------------------------------

class TestAgentEngineInit:
    def test_stores_cfo_and_sprint(self):
        engine = AgentEngine(provider=MagicMock(), cfo="mock_cfo", current_sprint=5)
        assert engine.cfo == "mock_cfo"
        assert engine.current_sprint == 5

    def test_stores_company_values(self):
        engine = AgentEngine(provider=MagicMock(), company_values="Be excellent")
        assert engine.company_values == "Be excellent"

    def test_escalations_initialized_empty(self):
        engine = AgentEngine(provider=MagicMock())
        assert engine.escalations == []

    def test_get_escalations_returns_and_clears(self):
        engine = AgentEngine(provider=MagicMock())
        engine.escalations.append({"reason": "test", "severity": "blocker"})
        engine.escalations.append({"reason": "test2", "severity": "heads_up"})
        result = engine.get_escalations()
        assert len(result) == 2
        assert result[0]["reason"] == "test"
        assert engine.escalations == []


class TestBudgetExceededError:
    def test_is_exception(self):
        assert issubclass(BudgetExceededError, Exception)

    def test_can_raise(self):
        with pytest.raises(BudgetExceededError, match="over"):
            raise BudgetExceededError("over budget")


# ---------------------------------------------------------------------------
# Helper to build mock API responses
# ---------------------------------------------------------------------------

def _make_response(text_blocks=None, tool_calls=None, stop_reason="end_turn", input_tokens=100, output_tokens=50):
    return AgentResponse(
        text_blocks=text_blocks or [],
        tool_calls=tool_calls or [],
        stop_reason=stop_reason,
        usage=Usage(input_tokens=input_tokens, output_tokens=output_tokens),
    )


def _lead_dev():
    return Persona(
        role_type=RoleType.LEAD_DEV,
        name="Lead Developer",
        title="Lead Developer",
        job_description="Build things",
    )


# ---------------------------------------------------------------------------
# AgentEngine.invoke - mocked API
# ---------------------------------------------------------------------------

class TestAgentEngineInvoke:
    """Test the invoke() method with mocked provider."""

    def test_simple_text_response(self):
        """Agent returns a single text block, no tool use."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(
            text_blocks=["Hello CEO!"],
        )

        result = engine.invoke(persona=_lead_dev(), user_message="Hi")
        assert result == "Hello CEO!"

    def test_multi_text_blocks_joined(self):
        """Multiple text blocks are joined with newlines."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(
            text_blocks=["Part 1", "Part 2"],
        )

        result = engine.invoke(persona=_lead_dev(), user_message="Hi")
        assert "Part 1" in result
        assert "Part 2" in result

    def test_tool_use_loop(self):
        """Agent uses a tool, then responds with text."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        # First response: tool use
        first_response = _make_response(
            text_blocks=["Let me read that file."],
            tool_calls=[ToolCall(name="read_file", input={"path": "/tmp/test.txt"}, id="tool_1")],
            stop_reason="tool_use",
        )

        # Second response: text only (done)
        second_response = _make_response(text_blocks=["File contents look good."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="file content here"):
            result = engine.invoke(persona=_lead_dev(), user_message="Read that file")

        assert "Let me read that file." in result
        assert "File contents look good." in result
        assert mock_provider.create_message.call_count == 2

    def test_multiple_tool_calls_in_one_response(self):
        """Agent calls multiple tools in a single response."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        first_response = _make_response(
            text_blocks=["Checking..."],
            tool_calls=[
                ToolCall(name="read_file", input={"path": "a.py"}, id="t1"),
                ToolCall(name="list_directory", input={"path": "."}, id="t2"),
            ],
            stop_reason="tool_use",
        )
        second_response = _make_response(text_blocks=["Done."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="ok"):
            result = engine.invoke(persona=_lead_dev(), user_message="Explore the codebase")

        assert "Done." in result

    def test_tools_disabled(self):
        """When tools=False, TOOL_DEFINITIONS should not be in kwargs."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(text_blocks=["No tools."])

        engine.invoke(persona=_lead_dev(), user_message="Think", tools=False)

        call_kwargs = mock_provider.create_message.call_args.kwargs
        assert call_kwargs.get("tools") is None

    def test_tools_enabled(self):
        """When tools=True (default), TOOL_DEFINITIONS should be in kwargs."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(text_blocks=["With tools."])

        engine.invoke(persona=_lead_dev(), user_message="Build it")

        call_kwargs = mock_provider.create_message.call_args.kwargs
        assert "tools" in call_kwargs

    def test_conversation_history_prepended(self):
        """Prior conversation history is included in messages."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(text_blocks=["Continuing."])

        history = [
            {"role": "user", "content": "Previous message"},
            {"role": "assistant", "content": "Previous response"},
        ]
        engine.invoke(persona=_lead_dev(), user_message="Next", conversation_history=history)

        call_kwargs = mock_provider.create_message.call_args.kwargs
        messages = call_kwargs["messages"]
        assert len(messages) == 3  # 2 history + 1 new
        assert messages[0]["content"] == "Previous message"
        assert messages[-1]["content"] == "Next"

    def test_budget_check_before_api_call(self):
        """If budget is exceeded, BudgetExceededError is raised before API call."""
        mock_cfo = MagicMock()
        mock_cfo.check_budget.return_value = (False, "BUDGET EXCEEDED: over limit")

        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, cfo=mock_cfo, current_sprint=1)

        with pytest.raises(BudgetExceededError, match="BUDGET EXCEEDED"):
            engine.invoke(persona=_lead_dev(), user_message="Build something expensive")

        # API should NOT have been called
        mock_provider.create_message.assert_not_called()

    def test_budget_check_passes(self):
        """When budget is OK, API call proceeds normally."""
        mock_cfo = MagicMock()
        mock_cfo.check_budget.return_value = (True, "")

        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, cfo=mock_cfo, current_sprint=1)
        mock_provider.create_message.return_value = _make_response(text_blocks=["Done."])

        result = engine.invoke(persona=_lead_dev(), user_message="Do something")
        assert result == "Done."

    def test_cfo_records_usage(self):
        """After API call, token usage is recorded with the CFO."""
        mock_cfo = MagicMock()
        mock_cfo.check_budget.return_value = (True, "")

        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, cfo=mock_cfo, current_sprint=3)
        mock_provider.create_message.return_value = _make_response(
            text_blocks=["OK"],
            input_tokens=500,
            output_tokens=200,
        )

        engine.invoke(persona=_lead_dev(), user_message="Work")

        mock_cfo.record.assert_called_once_with(
            agent_name="Lead Developer",
            model=ModelTier.HIGH.value,
            input_tokens=500,
            output_tokens=200,
            sprint=3,
            phase=None,
        )

    def test_budget_checked_each_loop_iteration(self):
        """Budget is checked before EACH API call in the agentic loop."""
        mock_cfo = MagicMock()
        # First call: OK. Second call: over budget.
        mock_cfo.check_budget.side_effect = [(True, ""), (False, "BUDGET EXCEEDED")]

        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, cfo=mock_cfo, current_sprint=1)

        first_response = _make_response(
            text_blocks=["Reading..."],
            tool_calls=[ToolCall(name="read_file", input={"path": "x.py"}, id="t1")],
            stop_reason="tool_use",
        )

        mock_provider.create_message.return_value = first_response
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="content"):
            with pytest.raises(BudgetExceededError):
                engine.invoke(persona=_lead_dev(), user_message="Expensive task")

        # Only one API call made (second was blocked by budget)
        assert mock_provider.create_message.call_count == 1

    def test_no_cfo_skips_budget_and_recording(self):
        """When no CFO is set, budget checks and recording are skipped."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)  # No cfo
        mock_provider.create_message.return_value = _make_response(text_blocks=["OK"])

        result = engine.invoke(persona=_lead_dev(), user_message="Work")
        assert result == "OK"

    def test_max_tokens_passed(self):
        """Custom max_tokens is forwarded to the API."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(text_blocks=["OK"])

        engine.invoke(persona=_lead_dev(), user_message="Short", max_tokens=1024)

        call_kwargs = mock_provider.create_message.call_args.kwargs
        assert call_kwargs["max_tokens"] == 1024

    def test_model_from_persona(self):
        """The model used comes from persona.effective_model()."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)
        mock_provider.create_message.return_value = _make_response(text_blocks=["OK"])

        persona = Persona(
            role_type=RoleType.SECRETARY,
            name="Secretary",
            title="Secretary",
        )
        engine.invoke(persona=persona, user_message="Note")

        call_kwargs = mock_provider.create_message.call_args.kwargs
        assert call_kwargs["model"] == ModelTier.STANDARD.value

    def test_system_prompt_passed(self):
        """The built system prompt is passed to the API."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, company_values="Be fast")
        mock_provider.create_message.return_value = _make_response(text_blocks=["OK"])

        engine.invoke(
            persona=_lead_dev(),
            user_message="Go",
            project_context="Sprint 1",
        )

        call_kwargs = mock_provider.create_message.call_args.kwargs
        system = call_kwargs["system"]
        assert "Be fast" in system
        assert "Sprint 1" in system
        assert "Build things" in system  # JD

    def test_no_usage_on_response_skips_recording(self):
        """If response has no usage attr, recording doesn't crash."""
        mock_cfo = MagicMock()
        mock_cfo.check_budget.return_value = (True, "")

        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider, cfo=mock_cfo, current_sprint=1)
        response = _make_response(text_blocks=["OK"])
        response = AgentResponse(
            text_blocks=["OK"],
            tool_calls=[],
            stop_reason="end_turn",
            usage=None,
        )
        mock_provider.create_message.return_value = response

        result = engine.invoke(persona=_lead_dev(), user_message="Work")
        assert result == "OK"
        mock_cfo.record.assert_not_called()


# ---------------------------------------------------------------------------
# DirectRunner._execute_tool
# ---------------------------------------------------------------------------

class TestExecuteTool:
    def test_delegates_to_tools_module(self):
        from odd.fallback.runner import DirectRunner
        runner = DirectRunner(
            provider=MagicMock(),
            escalations=[],
            submissions=[],
        )
        with patch("odd.tools.execute_tool", return_value="tool result") as mock:
            result = runner._execute_tool("read_file", {"path": "/tmp/x"}, agent_name="Cody")
        assert result == "tool result"
        mock.assert_called_once_with("read_file", {"path": "/tmp/x"}, cwd=None, agent_name="Cody", sprint=None)


# ---------------------------------------------------------------------------
# Escalation capture on AgentEngine
# ---------------------------------------------------------------------------

class TestEscalationCapture:
    """Test that escalation tool calls are captured on the engine instance."""

    def test_escalation_tool_captured_on_engine(self):
        """When agent calls 'escalate' tool, data is stored on engine.escalations."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        first_response = _make_response(
            text_blocks=["I'm stuck."],
            tool_calls=[ToolCall(name="escalate", input={"reason": "blocked", "severity": "blocker"}, id="t1")],
            stop_reason="tool_use",
        )
        second_response = _make_response(text_blocks=["Waiting."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.tools.execute_tool", return_value="Escalation registered."):
            engine.invoke(persona=_lead_dev(), user_message="Do something hard")

        assert len(engine.escalations) == 1
        assert engine.escalations[0]["reason"] == "blocked"
        assert engine.escalations[0]["severity"] == "blocker"

    def test_get_escalations_clears(self):
        engine = AgentEngine(provider=MagicMock())
        engine.escalations.append({"reason": "a", "severity": "heads_up"})
        result = engine.get_escalations()
        assert len(result) == 1
        assert engine.escalations == []
        assert engine.get_escalations() == []


# ---------------------------------------------------------------------------
# Stuck detection
# ---------------------------------------------------------------------------

class TestStuckDetection:
    """Test that the agent breaks out when repeating the same tool call."""

    def test_same_tool_call_three_times_raises(self):
        """Making the same tool call 3 times in a row should raise AgentStuckError."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        tool_response = _make_response(
            text_blocks=["Trying..."],
            tool_calls=[ToolCall(name="read_file", input={"path": "same.txt"}, id="t1")],
            stop_reason="tool_use",
        )

        # Return tool_use response every time
        mock_provider.create_message.return_value = tool_response
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="content"):
            with pytest.raises(AgentStuckError):
                engine.invoke(persona=_lead_dev(), user_message="Read the file")

        # Should have escalated
        assert len(engine.escalations) == 1
        assert engine.escalations[0]["severity"] == "blocker"
        assert "stuck" in engine.escalations[0]["reason"].lower()

    def test_different_tool_calls_dont_trigger(self):
        """Different tool calls should not trigger stuck detection."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        responses = []
        for i in range(3):
            responses.append(_make_response(
                text_blocks=[f"Try {i}"],
                tool_calls=[ToolCall(name="read_file", input={"path": f"file{i}.txt"}, id=f"t{i}")],
                stop_reason="tool_use",
            ))
        responses.append(_make_response(text_blocks=["Done."]))

        mock_provider.create_message.side_effect = responses
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        # Different inputs AND different outputs - neither detection should fire
        outputs = iter([f"content of file{i}" for i in range(3)])
        with patch("odd.fallback.runner.DirectRunner._execute_tool", side_effect=outputs):
            result = engine.invoke(persona=_lead_dev(), user_message="Explore")

        assert "Done." in result

    def test_same_outputs_different_inputs_raises(self):
        """Same tool outputs with different inputs should trigger semantic stuck detection."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        # Three different tool calls that all produce the same output
        responses = []
        for i in range(3):
            responses.append(_make_response(
                text_blocks=[f"Attempt {i}"],
                tool_calls=[ToolCall(name="read_file", input={"path": f"file{i}.txt"}, id=f"t{i}")],
                stop_reason="tool_use",
            ))
        responses.append(_make_response(text_blocks=["Done."]))

        mock_provider.create_message.side_effect = responses
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        # All tool executions return the same output
        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="identical content"):
            with pytest.raises(AgentStuckError, match="identical outputs"):
                engine.invoke(persona=_lead_dev(), user_message="Read files")

        assert len(engine.escalations) == 1
        assert "identical outputs" in engine.escalations[0]["reason"]

    def test_different_outputs_dont_trigger(self):
        """Varying tool outputs should not trigger semantic stuck detection."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        responses = []
        for i in range(3):
            responses.append(_make_response(
                text_blocks=[f"Try {i}"],
                tool_calls=[ToolCall(name="read_file", input={"path": f"v{i}.txt"}, id=f"t{i}")],
                stop_reason="tool_use",
            ))
        responses.append(_make_response(text_blocks=["Done."]))

        mock_provider.create_message.side_effect = responses
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        # Different inputs AND different outputs - neither detection should fire
        outputs = iter(["content A", "content B", "content C"])
        with patch("odd.fallback.runner.DirectRunner._execute_tool", side_effect=outputs):
            result = engine.invoke(persona=_lead_dev(), user_message="Read files")

        assert "Done." in result


# ---------------------------------------------------------------------------
# Max iterations cap
# ---------------------------------------------------------------------------

class TestMaxIterations:
    def test_exceeding_max_iterations_raises(self):
        """Going over the iteration cap should raise MaxIterationsError."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        # Create unique tool calls each time to avoid stuck detection
        # Need more than MAX_AGENTIC_ITERATIONS (40) to trigger the cap
        tool_responses = []
        for i in range(50):
            tool_responses.append(_make_response(
                text_blocks=[f"Iteration {i}"],
                tool_calls=[ToolCall(name="list_directory", input={"path": f"dir{i}"}, id=f"t{i}")],
                stop_reason="tool_use",
            ))

        mock_provider.create_message.side_effect = tool_responses
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        # Each call returns unique output to avoid semantic stuck detection
        outputs = iter([f"result_{i}" for i in range(50)])
        with patch("odd.fallback.runner.DirectRunner._execute_tool", side_effect=outputs):
            with pytest.raises(MaxIterationsError):
                engine.invoke(persona=_lead_dev(), user_message="Do many things")

        # Should have escalated
        assert len(engine.escalations) == 1
        assert engine.escalations[0]["severity"] == "blocker"


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------

class TestRetryLogic:
    """Retry logic now lives in AnthropicProvider._call_with_retry."""

    def test_retries_on_connection_error(self):
        """API connection errors should be retried with backoff."""
        import anthropic as anth
        from odd.providers.anthropic import AnthropicProvider

        provider = AnthropicProvider.__new__(AnthropicProvider)
        provider.client = MagicMock()

        # Build a fake raw Anthropic response for the success case
        success_block = MagicMock(type="text", text="OK")
        success_raw = MagicMock()
        success_raw.content = [success_block]
        success_raw.stop_reason = "end_turn"
        success_raw.usage = MagicMock(input_tokens=10, output_tokens=5)

        provider.client.messages.create.side_effect = [
            anth.APIConnectionError(request=MagicMock()),
            success_raw,
        ]

        with patch("odd.providers.anthropic.time.sleep"):
            resp = provider.create_message(
                model="high", system="test", messages=[{"role": "user", "content": "Hi"}]
            )

        assert resp.text_blocks == ["OK"]
        assert provider.client.messages.create.call_count == 2

    def test_retries_exhausted_raises(self):
        """If all retries fail, the error is raised."""
        import anthropic as anth
        from odd.providers.anthropic import AnthropicProvider

        provider = AnthropicProvider.__new__(AnthropicProvider)
        provider.client = MagicMock()

        provider.client.messages.create.side_effect = anth.APIConnectionError(
            request=MagicMock()
        )

        with patch("odd.providers.anthropic.time.sleep"):
            with pytest.raises(anth.APIConnectionError):
                provider.create_message(
                    model="high", system="test", messages=[{"role": "user", "content": "Hi"}]
                )
