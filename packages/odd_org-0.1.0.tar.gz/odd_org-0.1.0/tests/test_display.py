"""Tests for odd.display - AgentOutputStream, WarRoom, OfficeVisit."""

import threading

import pytest

from odd.display import (
    AgentOutputStream,
    AgentStatus,
    OfficeVisit,
    WarRoom,
    _agent_panel,
    _build_war_room_layout,
    _collapsed_summary,
)
from odd.provider import StreamEvent, StreamEventType, ToolCall


# ---------------------------------------------------------------------------
# AgentOutputStream
# ---------------------------------------------------------------------------


class TestAgentOutputStream:
    def test_initial_state(self):
        s = AgentOutputStream("Alice")
        assert s.agent_name == "Alice"
        assert s.status == AgentStatus.IDLE
        assert s.cancelled is False
        assert s.tail() == []
        assert s.full() == []

    def test_append_splits_on_newlines(self):
        s = AgentOutputStream("Alice")
        s.append("line1\nline2\nline3\n")
        assert s.full() == ["line1", "line2", "line3"]

    def test_partial_line_buffered_until_newline(self):
        s = AgentOutputStream("Alice")
        s.append("hello ")
        assert s.full() == []  # no newline yet
        s.append("world\n")
        assert s.full() == ["hello world"]

    def test_flush_pushes_partial_line(self):
        s = AgentOutputStream("Alice")
        s.append("partial")
        assert s.full() == []
        s.flush()
        assert s.full() == ["partial"]

    def test_flush_noop_when_empty(self):
        s = AgentOutputStream("Alice")
        s.flush()
        assert s.full() == []

    def test_ring_buffer_capacity(self):
        s = AgentOutputStream("Alice", capacity=3)
        for i in range(5):
            s.append(f"line{i}\n")
        # Ring keeps last 3
        assert s.tail(3) == ["line2", "line3", "line4"]
        # Full log keeps everything
        assert len(s.full()) == 5

    def test_tail_fewer_than_n(self):
        s = AgentOutputStream("Alice")
        s.append("only\n")
        assert s.tail(5) == ["only"]

    def test_status_property(self):
        s = AgentOutputStream("Alice")
        s.status = AgentStatus.WORKING
        assert s.status == AgentStatus.WORKING

    def test_cancel_sets_killed(self):
        s = AgentOutputStream("Alice")
        s.cancel()
        assert s.cancelled is True
        assert s.status == AgentStatus.KILLED

    def test_status_dot_all_statuses(self):
        s = AgentOutputStream("Alice")
        for status in AgentStatus:
            s.status = status
            dot = s.status_dot
            assert isinstance(dot, str)
            assert len(dot) > 0

    def test_thread_safety_append(self):
        """Multiple threads appending concurrently should not lose data."""
        s = AgentOutputStream("Alice", capacity=1000)
        lines_per_thread = 100
        num_threads = 4

        def writer(thread_id: int) -> None:
            for i in range(lines_per_thread):
                s.append(f"t{thread_id}-{i}\n")

        threads = [threading.Thread(target=writer, args=(t,)) for t in range(num_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(s.full()) == lines_per_thread * num_threads

    def test_thread_safety_cancel_during_append(self):
        """Cancel from one thread while another appends."""
        s = AgentOutputStream("Alice")
        barrier = threading.Barrier(2)

        def appender() -> None:
            barrier.wait()
            for i in range(50):
                s.append(f"line{i}\n")

        def canceller() -> None:
            barrier.wait()
            s.cancel()

        t1 = threading.Thread(target=appender)
        t2 = threading.Thread(target=canceller)
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        assert s.cancelled is True
        assert s.status == AgentStatus.KILLED


# ---------------------------------------------------------------------------
# Stream callback bridge (6d)
# ---------------------------------------------------------------------------


class TestStreamCallback:
    def test_text_delta_appended(self):
        s = AgentOutputStream("Alice")
        cb = s.as_stream_callback()
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="hello\n"))
        assert s.full() == ["hello"]

    def test_tool_use_end_shown_as_summary(self):
        """TOOL_USE_END events produce an inline tool summary line."""
        s = AgentOutputStream("Alice")
        cb = s.as_stream_callback()
        tc = ToolCall(name="Read", input={"file_path": "src/odd/sprint.py"}, id="t1")
        cb(StreamEvent(event_type=StreamEventType.TOOL_USE_END, tool_call=tc))
        assert s.full() == ["↳ Read src/odd/sprint.py"]

    def test_message_stop_flushes(self):
        s = AgentOutputStream("Alice")
        cb = s.as_stream_callback()
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="partial"))
        assert s.full() == []  # not flushed yet
        cb(StreamEvent(event_type=StreamEventType.MESSAGE_STOP))
        assert "partial" in s.full()[-1]

    def test_non_text_events_ignored(self):
        s = AgentOutputStream("Alice")
        cb = s.as_stream_callback()
        cb(StreamEvent(event_type=StreamEventType.TOOL_INPUT_DELTA, text='{"key":'))
        cb(StreamEvent(event_type=StreamEventType.TOOL_USE_END))
        s.flush()
        # TOOL_INPUT_DELTA and TOOL_USE_END are not captured
        assert s.full() == []


# ---------------------------------------------------------------------------
# War Room panels (6b)
# ---------------------------------------------------------------------------


class TestWarRoomPanels:
    def test_agent_panel_renders(self):
        s = AgentOutputStream("Dev")
        s.status = AgentStatus.WORKING
        s.append("doing stuff\n")
        panel = _agent_panel(s)
        assert panel.title is not None
        assert "Dev" in str(panel.title)

    def test_agent_panel_no_output(self):
        s = AgentOutputStream("Dev")
        panel = _agent_panel(s)
        # Should render without error even with no output
        assert panel is not None

    def test_collapsed_summary(self):
        streams = [
            AgentOutputStream("A"),
            AgentOutputStream("B"),
        ]
        streams[0].status = AgentStatus.DONE
        streams[1].status = AgentStatus.IDLE
        panel = _collapsed_summary(streams)
        assert "completed" in str(panel.title).lower() or "idle" in str(panel.title).lower()

    def test_build_layout_active_agents(self):
        streams = [AgentOutputStream(f"Agent{i}") for i in range(4)]
        for s in streams:
            s.status = AgentStatus.WORKING
        layout = _build_war_room_layout(streams)
        assert layout is not None

    def test_build_layout_mixed_status(self):
        streams = [AgentOutputStream(f"Agent{i}") for i in range(4)]
        streams[0].status = AgentStatus.WORKING
        streams[1].status = AgentStatus.WAITING
        streams[2].status = AgentStatus.DONE
        streams[3].status = AgentStatus.IDLE
        layout = _build_war_room_layout(streams)
        assert layout is not None

    def test_build_layout_all_done(self):
        streams = [AgentOutputStream(f"Agent{i}") for i in range(2)]
        for s in streams:
            s.status = AgentStatus.DONE
        layout = _build_war_room_layout(streams)
        assert layout is not None

    def test_build_layout_empty(self):
        layout = _build_war_room_layout([])
        assert layout is not None

    def test_build_layout_7_plus_uses_3_cols(self):
        """7+ active agents should trigger 3-column layout."""
        streams = [AgentOutputStream(f"Agent{i}") for i in range(8)]
        for s in streams:
            s.status = AgentStatus.WORKING
        # Should not raise - 3-col layout path exercised
        layout = _build_war_room_layout(streams)
        assert layout is not None

    def test_build_layout_single_active(self):
        """Single active agent gets a standalone panel (no row split)."""
        streams = [AgentOutputStream("Solo")]
        streams[0].status = AgentStatus.WORKING
        layout = _build_war_room_layout(streams)
        assert layout is not None


# ---------------------------------------------------------------------------
# WarRoom class (6b)
# ---------------------------------------------------------------------------


class TestWarRoom:
    def test_init(self):
        streams = [AgentOutputStream("A")]
        wr = WarRoom(streams)
        assert wr.streams == streams
        assert wr.is_running is False

    def test_context_manager(self):
        streams = [AgentOutputStream("A")]
        with WarRoom(streams) as wr:
            assert wr.is_running is True
        assert wr.is_running is False

    def test_focus_and_unfocus(self):
        s = AgentOutputStream("A")
        wr = WarRoom([s])

        wr.focus(s)
        assert wr._focused is s

        wr.unfocus()
        assert wr._focused is None

    def test_kill(self):
        s = AgentOutputStream("A")
        s.status = AgentStatus.WORKING
        wr = WarRoom([s])
        wr.kill(s)
        assert s.cancelled is True
        assert s.status == AgentStatus.KILLED

    def test_kill_all(self):
        streams = [AgentOutputStream(f"A{i}") for i in range(3)]
        for s in streams:
            s.status = AgentStatus.WORKING
        wr = WarRoom(streams)
        wr.kill_all()
        for s in streams:
            assert s.cancelled is True

    def test_kill_all_skips_done(self):
        s1 = AgentOutputStream("A")
        s2 = AgentOutputStream("B")
        s1.status = AgentStatus.DONE
        s2.status = AgentStatus.WORKING
        wr = WarRoom([s1, s2])
        wr.kill_all()
        assert s1.cancelled is False  # DONE agent not touched
        assert s2.cancelled is True

    def test_refresh_no_crash_when_not_started(self):
        wr = WarRoom([AgentOutputStream("A")])
        wr.refresh()  # should be a no-op, not crash


# ---------------------------------------------------------------------------
# OfficeVisit (6c)
# ---------------------------------------------------------------------------


class TestOfficeVisit:
    def test_inject_message(self):
        s = AgentOutputStream("Dev")
        ov = OfficeVisit(s)
        ov.inject("focus on error handling")
        assert len(ov.ceo_messages) == 1
        assert "CEO interrupt" in ov.ceo_messages[0]
        assert "focus on error handling" in ov.ceo_messages[0]

    def test_inject_appends_to_stream(self):
        s = AgentOutputStream("Dev")
        ov = OfficeVisit(s)
        ov.inject("hey")
        s.flush()
        log = s.full()
        assert any("CEO interrupt" in line for line in log)

    def test_inject_callback(self):
        s = AgentOutputStream("Dev")
        received: list[str] = []
        ov = OfficeVisit(s, on_ceo_message=lambda msg: received.append(msg))
        ov.inject("do this")
        assert len(received) == 1
        assert "CEO interrupt" in received[0]

    def test_render_log(self):
        s = AgentOutputStream("Dev")
        s.append("line1\nline2\n")
        ov = OfficeVisit(s)
        panel = ov.render_log()
        assert "Office Visit" in str(panel.title)
        assert "Dev" in str(panel.title)

    def test_render_log_empty(self):
        s = AgentOutputStream("Dev")
        ov = OfficeVisit(s)
        panel = ov.render_log()
        assert panel is not None

    def test_multiple_injections(self):
        s = AgentOutputStream("Dev")
        ov = OfficeVisit(s)
        ov.inject("first")
        ov.inject("second")
        assert len(ov.ceo_messages) == 2
