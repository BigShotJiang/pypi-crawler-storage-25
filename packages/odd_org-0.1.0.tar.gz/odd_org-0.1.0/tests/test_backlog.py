"""Tests for odd.backlog - persistent prioritized backlog."""

import json

import pytest

from odd.backlog import Backlog, BacklogItem, Priority


@pytest.fixture
def backlog(tmp_path):
    odd_dir = tmp_path / ".odd"
    odd_dir.mkdir()
    return Backlog(odd_dir)


# ---------------------------------------------------------------------------
# Priority Enum
# ---------------------------------------------------------------------------

class TestPriority:
    def test_all_levels(self):
        assert set(Priority) == {
            Priority.CRITICAL, Priority.HIGH, Priority.MEDIUM,
            Priority.LOW, Priority.NICE_TO_HAVE,
        }

    def test_string_values(self):
        assert Priority.CRITICAL.value == "critical"
        assert Priority.NICE_TO_HAVE.value == "nice_to_have"


# ---------------------------------------------------------------------------
# BacklogItem
# ---------------------------------------------------------------------------

class TestBacklogItem:
    def test_defaults(self):
        item = BacklogItem(id="bl_1", description="Do something")
        assert item.priority == Priority.MEDIUM
        assert item.added_by == "CEO"
        assert item.sprint_assigned is None
        assert item.status == "open"
        assert item.notes == ""

    def test_to_dict(self):
        item = BacklogItem(id="bl_1", description="thing", priority=Priority.HIGH)
        d = item.to_dict()
        assert d["id"] == "bl_1"
        assert d["priority"] == "high"


# ---------------------------------------------------------------------------
# Backlog CRUD
# ---------------------------------------------------------------------------

class TestBacklogCRUD:
    def test_add(self, backlog):
        item = backlog.add("Build auth")
        assert item.id == "bl_1"
        assert item.description == "Build auth"
        assert item.priority == Priority.MEDIUM

    def test_add_with_priority(self, backlog):
        item = backlog.add("Fix crash", priority=Priority.CRITICAL)
        assert item.priority == Priority.CRITICAL

    def test_add_increments_ids(self, backlog):
        i1 = backlog.add("First")
        i2 = backlog.add("Second")
        assert i1.id == "bl_1"
        assert i2.id == "bl_2"

    def test_get(self, backlog):
        backlog.add("Thing")
        item = backlog.get("bl_1")
        assert item is not None
        assert item.description == "Thing"

    def test_get_nonexistent(self, backlog):
        assert backlog.get("bl_999") is None

    def test_assign_to_sprint(self, backlog):
        backlog.add("Feature")
        backlog.assign_to_sprint("bl_1", 1)
        item = backlog.get("bl_1")
        assert item.sprint_assigned == 1
        assert item.status == "in_sprint"

    def test_complete(self, backlog):
        backlog.add("Bug fix")
        backlog.complete("bl_1")
        assert backlog.get("bl_1").status == "done"

    def test_cut(self, backlog):
        backlog.add("Nice to have")
        backlog.cut("bl_1")
        assert backlog.get("bl_1").status == "cut"


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------

class TestBacklogQueries:
    def test_all_items(self, backlog):
        backlog.add("A")
        backlog.add("B")
        assert len(backlog.all_items()) == 2

    def test_open_items(self, backlog):
        backlog.add("A")
        backlog.add("B")
        backlog.complete("bl_1")
        open_items = backlog.open_items()
        assert len(open_items) == 1
        assert open_items[0].description == "B"

    def test_sprint_items(self, backlog):
        backlog.add("A")
        backlog.add("B")
        backlog.add("C")
        backlog.assign_to_sprint("bl_1", 1)
        backlog.assign_to_sprint("bl_3", 1)
        items = backlog.sprint_items(1)
        assert len(items) == 2

    def test_sprint_items_empty(self, backlog):
        backlog.add("A")
        assert backlog.sprint_items(99) == []


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

class TestBacklogPersistence:
    def test_persists_to_disk(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()

        b1 = Backlog(odd_dir)
        b1.add("Feature A", priority=Priority.HIGH)
        b1.add("Feature B")

        # Reload from disk
        b2 = Backlog(odd_dir)
        assert len(b2.all_items()) == 2
        assert b2.get("bl_1").priority == Priority.HIGH

    def test_empty_backlog_no_file(self, backlog):
        # Before any adds, file shouldn't exist
        assert not backlog.path.exists()
        assert backlog.all_items() == []


# ---------------------------------------------------------------------------
# Summary for Agent
# ---------------------------------------------------------------------------

class TestSummaryForAgent:
    def test_empty(self, backlog):
        assert backlog.summary_for_agent() == "Backlog is empty."

    def test_with_items(self, backlog):
        backlog.add("Critical fix", priority=Priority.CRITICAL)
        backlog.add("Nice thing", priority=Priority.NICE_TO_HAVE)
        summary = backlog.summary_for_agent()
        assert "CRITICAL" in summary
        assert "Critical fix" in summary
        assert "NICE_TO_HAVE" in summary

    def test_excludes_done_items(self, backlog):
        backlog.add("Done thing")
        backlog.complete("bl_1")
        backlog.add("Open thing")
        summary = backlog.summary_for_agent()
        assert "Open thing" in summary
        assert "Done thing" not in summary
