"""Tests for odd.health - state integrity checks and auto-repair."""

import json

import pytest

from odd.config import CONSULTANTS_DIR_NAME, PERSONA_FILE
from odd.health import check_and_repair
from odd.models import Persona, ProjectConfig, RoleType, ModelTier
from odd.state import StateManager


@pytest.fixture
def state(tmp_path):
    sm = StateManager(tmp_path)
    sm.init(ProjectConfig(name="TestProject", description="test"))
    # Save core team so the baseline is clean
    for role in ["lead_dev", "qa", "recruiter", "secretary"]:
        sm.save_persona(Persona(
            role_type=RoleType(role),
            name=role.replace("_", " ").title(),
            title=f"The {role}",
            job_description="does stuff",
            resume="has experience",
        ))
    return sm


def test_clean_state_no_issues(state):
    report = check_and_repair(state.odd_dir)
    assert report.clean


def test_empty_consultant_dir_removed(state):
    """A consultant folder with no persona.json gets cleaned up."""
    ghost = state.team_dir / CONSULTANTS_DIR_NAME / "ghost_expert"
    ghost.mkdir(parents=True)
    assert ghost.exists()

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert report.all_repaired
    assert not ghost.exists()
    assert "ghost_expert" in report.issues[0].description


def test_empty_persona_json_consultant_removed(state):
    """A consultant with an empty persona.json gets cleaned up."""
    broken = state.team_dir / CONSULTANTS_DIR_NAME / "broken_dev"
    broken.mkdir(parents=True)
    (broken / PERSONA_FILE).write_text("", encoding="utf-8")

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert report.all_repaired
    assert not broken.exists()


def test_corrupt_json_consultant_removed(state):
    """A consultant with garbage JSON gets cleaned up."""
    broken = state.team_dir / CONSULTANTS_DIR_NAME / "corrupt_dev"
    broken.mkdir(parents=True)
    (broken / PERSONA_FILE).write_text("{bad json", encoding="utf-8")

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert not broken.exists()


def test_consultant_missing_jd_and_resume_removed(state):
    """A consultant persona with no JD and no resume is incomplete."""
    shell = state.team_dir / CONSULTANTS_DIR_NAME / "shell_dev"
    shell.mkdir(parents=True)
    (shell / PERSONA_FILE).write_text(json.dumps({
        "role_type": "consultant",
        "name": "Shell Dev",
        "title": "Empty Shell",
        "job_description": "",
        "resume": "",
    }), encoding="utf-8")

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert not shell.exists()


def test_valid_consultant_kept(state):
    """A properly set up consultant is left alone."""
    state.save_persona(Persona(
        role_type=RoleType.CONSULTANT,
        name="Good Dev",
        title="Expert",
        job_description="Build things",
        resume="10 years experience",
    ))

    report = check_and_repair(state.odd_dir)
    assert report.clean


def test_empty_core_persona_reported(state):
    """An empty core team persona.json is flagged but not deleted."""
    persona_path = state.team_dir / "lead_dev" / PERSONA_FILE
    persona_path.write_text("", encoding="utf-8")

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert any("lead_dev" in i.description for i in report.issues)
    # Core team is NOT auto-deleted - just reported
    assert persona_path.exists()


def test_corrupt_sprint_reported(state):
    """A broken sprint.json is flagged."""
    sprint_dir = state.sprints_dir / "sprint_1"
    sprint_dir.mkdir()
    (sprint_dir / "sprint.json").write_text("not json", encoding="utf-8")

    report = check_and_repair(state.odd_dir)
    assert not report.clean
    assert any("sprint" in i.description.lower() for i in report.issues)


def test_not_initialized_is_noop(tmp_path):
    """If .odd/ doesn't exist, health check returns clean."""
    report = check_and_repair(tmp_path / ".odd")
    assert report.clean
