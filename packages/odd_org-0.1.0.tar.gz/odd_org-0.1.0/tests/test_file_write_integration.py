"""Integration tests: prove that agents can actually write files to disk.

Tests the full chain: Provider returns write_file tool call →
DirectRunner._process_tool_calls() → execute_tool() → file on disk.

This is NOT a unit test of execute_tool (that lives in test_tools.py).
This proves the wiring works end-to-end through the agentic loop.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from odd.fallback.runner import DirectRunner
from odd.middleware import RunnerMiddleware
from odd.models import Persona, RoleType
from odd.provider import AgentResponse, Provider, ToolCall, Usage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _persona(name: str = "Vera", role: RoleType = RoleType.QA) -> Persona:
    return Persona(role_type=role, name=name, title="QA Engineer")


def _response_write(path: str, content: str, *, tool_id: str = "t1") -> AgentResponse:
    """AgentResponse containing a single write_file tool call."""
    return AgentResponse(
        text_blocks=["I'll write the file now."],
        tool_calls=[ToolCall(name="write_file", input={"path": path, "content": content}, id=tool_id)],
        stop_reason="tool_use",
        usage=Usage(input_tokens=100, output_tokens=50),
    )


def _response_done(text: str = "Done.") -> AgentResponse:
    return AgentResponse(
        text_blocks=[text],
        tool_calls=[],
        stop_reason="end_turn",
        usage=Usage(input_tokens=50, output_tokens=20),
    )


def _response_read(path: str, *, tool_id: str = "t1") -> AgentResponse:
    """AgentResponse containing a single read_file tool call."""
    return AgentResponse(
        text_blocks=["Let me read the file."],
        tool_calls=[ToolCall(name="read_file", input={"path": path}, id=tool_id)],
        stop_reason="tool_use",
        usage=Usage(input_tokens=80, output_tokens=30),
    )


def _response_edit(path: str, old: str, new: str, *, tool_id: str = "t1") -> AgentResponse:
    """AgentResponse containing a single edit_file tool call."""
    return AgentResponse(
        text_blocks=["I'll edit the file."],
        tool_calls=[ToolCall(name="edit_file", input={"path": path, "old_string": old, "new_string": new}, id=tool_id)],
        stop_reason="tool_use",
        usage=Usage(input_tokens=90, output_tokens=40),
    )


class FakeProvider:
    """Provider that returns a pre-loaded sequence of responses."""

    def __init__(self, responses: list[AgentResponse]):
        self._responses = list(responses)
        self._call_index = 0

    def create_message(self, **kwargs) -> AgentResponse:
        resp = self._responses[self._call_index]
        self._call_index += 1
        return resp

    def wrap_tool_results(
        self, tool_calls: list[ToolCall], results: list[str], *, text_blocks: list[str] | None = None,
    ) -> tuple[dict, dict]:
        """Minimal Anthropic-style wrapping for the conversation loop."""
        assistant_content = []
        if text_blocks:
            for t in text_blocks:
                assistant_content.append({"type": "text", "text": t})
        for tc in tool_calls:
            assistant_content.append({
                "type": "tool_use", "id": tc.id,
                "name": tc.name, "input": tc.input,
            })
        user_content = []
        for tc, result in zip(tool_calls, results):
            user_content.append({
                "type": "tool_result", "tool_use_id": tc.id,
                "content": result,
            })
        return (
            {"role": "assistant", "content": assistant_content},
            {"role": "user", "content": user_content},
        )


def _run(provider: FakeProvider, tmp_path: Path, persona: Persona | None = None) -> str:
    """Run DirectRunner with the fake provider and return the text response."""
    p = persona or _persona()
    runner = DirectRunner(
        provider=provider,
        escalations=[],
        submissions=[],
        working_dir=tmp_path,
    )
    middleware = RunnerMiddleware()
    return runner.invoke(
        p,
        system="You are a test agent.",
        messages=[{"role": "user", "content": "Do the thing."}],
        tool_defs=[],  # DirectRunner doesn't validate tool defs
        model="test-model",
        middleware=middleware,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestWriteFileEndToEnd:
    """Prove that a write_file tool call in the agentic loop creates a real file."""

    def test_write_creates_file_on_disk(self, tmp_path):
        """The core test: agent says write_file → file exists on disk."""
        provider = FakeProvider([
            _response_write("hello.txt", "Hello from Vera!"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        target = tmp_path / "hello.txt"
        assert target.exists(), "write_file tool call did not create the file"
        assert target.read_text(encoding="utf-8") == "Hello from Vera!"

    def test_write_creates_nested_directories(self, tmp_path):
        """write_file should create parent dirs that don't exist yet."""
        provider = FakeProvider([
            _response_write("src/tests/test_new.py", "def test_it(): pass"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        target = tmp_path / "src" / "tests" / "test_new.py"
        assert target.exists()
        assert "def test_it" in target.read_text()

    def test_write_overwrites_existing_file(self, tmp_path):
        """write_file to an existing path replaces the content."""
        existing = tmp_path / "config.txt"
        existing.write_text("old stuff", encoding="utf-8")

        provider = FakeProvider([
            _response_write("config.txt", "new stuff"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        assert existing.read_text(encoding="utf-8") == "new stuff"

    def test_write_then_read_round_trip(self, tmp_path):
        """Agent writes a file, then reads it back - content matches."""
        provider = FakeProvider([
            _response_write("data.json", '{"key": "value"}'),
            _response_read("data.json", tool_id="t2"),
            _response_done(),
        ])
        result = _run(provider, tmp_path)
        target = tmp_path / "data.json"
        assert target.exists()
        assert target.read_text(encoding="utf-8") == '{"key": "value"}'

    def test_write_then_edit(self, tmp_path):
        """Agent writes a file, then edits it - both operations land on disk."""
        provider = FakeProvider([
            _response_write("app.py", "def main():\n    return 1\n"),
            _response_edit("app.py", "return 1", "return 42", tool_id="t2"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        content = (tmp_path / "app.py").read_text(encoding="utf-8")
        assert "return 42" in content
        assert "return 1" not in content

    def test_multiple_files_in_sequence(self, tmp_path):
        """Agent writes multiple files across loop iterations."""
        provider = FakeProvider([
            _response_write("a.txt", "alpha"),
            _response_write("b.txt", "bravo", tool_id="t2"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        assert (tmp_path / "a.txt").read_text() == "alpha"
        assert (tmp_path / "b.txt").read_text() == "bravo"

    def test_write_result_fed_back_to_provider(self, tmp_path):
        """The success message from write_file gets appended to conversation."""
        provider = FakeProvider([
            _response_write("out.txt", "data"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        # Check what was fed back: the second create_message call
        # should have received messages containing the tool result
        assert provider._call_index == 2  # called twice

    def test_write_empty_file(self, tmp_path):
        """Writing empty content should create an empty file."""
        provider = FakeProvider([
            _response_write("empty.txt", ""),
            _response_done(),
        ])
        _run(provider, tmp_path)
        target = tmp_path / "empty.txt"
        assert target.exists()
        assert target.read_text() == ""

    def test_write_unicode_content(self, tmp_path):
        """Agent can write files with unicode content."""
        content = "def greet():\n    return '你好世界 🌍'\n"
        provider = FakeProvider([
            _response_write("greeting.py", content),
            _response_done(),
        ])
        _run(provider, tmp_path)
        assert (tmp_path / "greeting.py").read_text(encoding="utf-8") == content

    def test_write_large_file(self, tmp_path):
        """Agent can write a non-trivial amount of content."""
        lines = [f"line {i}: {'x' * 80}" for i in range(500)]
        content = "\n".join(lines)
        provider = FakeProvider([
            _response_write("big.txt", content),
            _response_done(),
        ])
        _run(provider, tmp_path)
        written = (tmp_path / "big.txt").read_text(encoding="utf-8")
        assert written == content
        assert written.count("\n") == 499


class TestWriteFileIsolation:
    """Prove that isolation policies are enforced through the full runner chain."""

    def test_path_traversal_blocked(self, tmp_path):
        """Agent can't write outside the project root via ../"""
        provider = FakeProvider([
            _response_write("../../etc/evil.txt", "pwned"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        # The file must NOT exist outside tmp_path
        assert not (tmp_path.parent.parent / "etc" / "evil.txt").exists()

    def test_lead_dev_cannot_write_test_files(self, tmp_path):
        """Lead dev persona is blocked from writing test files."""
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Marcus", title="Lead Dev")
        provider = FakeProvider([
            _response_write("tests/test_new.py", "def test_it(): pass"),
            _response_done(),
        ])
        _run(provider, tmp_path, persona=lead)
        # test file should NOT be created - isolation blocks it
        assert not (tmp_path / "tests" / "test_new.py").exists()

    def test_qa_can_write_test_files(self, tmp_path):
        """QA persona IS allowed to write test files."""
        qa = _persona("Vera", RoleType.QA)
        provider = FakeProvider([
            _response_write("tests/test_feature.py", "def test_feature(): assert True"),
            _response_done(),
        ])
        _run(provider, tmp_path, persona=qa)
        assert (tmp_path / "tests" / "test_feature.py").exists()


class TestEditFileEndToEnd:
    """Prove edit_file tool calls modify files on disk through the runner."""

    def test_edit_modifies_file(self, tmp_path):
        """edit_file changes content of an existing file."""
        (tmp_path / "code.py").write_text("x = 1\ny = 2\n", encoding="utf-8")
        provider = FakeProvider([
            _response_edit("code.py", "x = 1", "x = 99"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        content = (tmp_path / "code.py").read_text(encoding="utf-8")
        assert "x = 99" in content
        assert "y = 2" in content

    def test_edit_nonexistent_file_returns_error(self, tmp_path):
        """edit_file on a missing file doesn't crash the loop."""
        provider = FakeProvider([
            _response_edit("nope.py", "old", "new"),
            _response_done(),
        ])
        # Should complete without raising
        _run(provider, tmp_path)
        assert not (tmp_path / "nope.py").exists()


class TestMultiToolSingleIteration:
    """Prove that multiple tool calls in one response all execute."""

    def test_two_writes_in_one_response(self, tmp_path):
        """Agent returns two write_file calls in a single API response."""
        response_with_two = AgentResponse(
            text_blocks=["Writing both files."],
            tool_calls=[
                ToolCall(name="write_file", input={"path": "one.txt", "content": "first"}, id="t1"),
                ToolCall(name="write_file", input={"path": "two.txt", "content": "second"}, id="t2"),
            ],
            stop_reason="tool_use",
            usage=Usage(input_tokens=100, output_tokens=50),
        )
        provider = FakeProvider([response_with_two, _response_done()])
        _run(provider, tmp_path)
        assert (tmp_path / "one.txt").read_text() == "first"
        assert (tmp_path / "two.txt").read_text() == "second"

    def test_write_and_read_in_one_response(self, tmp_path):
        """Agent writes and reads in the same batch - both execute."""
        (tmp_path / "existing.txt").write_text("hello", encoding="utf-8")
        response = AgentResponse(
            text_blocks=["Doing both."],
            tool_calls=[
                ToolCall(name="write_file", input={"path": "new.txt", "content": "fresh"}, id="t1"),
                ToolCall(name="read_file", input={"path": "existing.txt"}, id="t2"),
            ],
            stop_reason="tool_use",
            usage=Usage(input_tokens=100, output_tokens=50),
        )
        provider = FakeProvider([response, _response_done()])
        _run(provider, tmp_path)
        assert (tmp_path / "new.txt").read_text() == "fresh"


class TestOnToolResultCallback:
    """Prove that on_tool_result fires after each tool execution."""

    def test_callback_receives_write_result(self, tmp_path):
        """on_tool_result callback fires with tool name, input, and result."""
        captured = []

        def _capture(tool_name, tool_input, result):
            captured.append((tool_name, tool_input, result))

        provider = FakeProvider([
            _response_write("out.txt", "hello"),
            _response_done(),
        ])
        p = _persona()
        runner = DirectRunner(
            provider=provider, escalations=[], submissions=[], working_dir=tmp_path,
        )
        middleware = RunnerMiddleware()
        runner.invoke(
            p, system="test", messages=[{"role": "user", "content": "go"}],
            tool_defs=[], model="test", middleware=middleware,
            on_tool_result=_capture,
        )
        assert len(captured) == 1
        assert captured[0][0] == "write_file"
        assert captured[0][1]["path"] == "out.txt"
        assert "Successfully" in captured[0][2]

    def test_callback_fires_for_each_tool(self, tmp_path):
        """Multiple tool calls in sequence each fire the callback."""
        captured = []

        def _capture(tool_name, tool_input, result):
            captured.append(tool_name)

        provider = FakeProvider([
            _response_write("a.txt", "one"),
            _response_write("b.txt", "two", tool_id="t2"),
            _response_done(),
        ])
        runner = DirectRunner(
            provider=provider, escalations=[], submissions=[], working_dir=tmp_path,
        )
        runner.invoke(
            _persona(), system="test", messages=[{"role": "user", "content": "go"}],
            tool_defs=[], model="test", middleware=RunnerMiddleware(),
            on_tool_result=_capture,
        )
        assert captured == ["write_file", "write_file"]

    def test_callback_not_required(self, tmp_path):
        """on_tool_result=None is the default and doesn't break anything."""
        provider = FakeProvider([
            _response_write("ok.txt", "data"),
            _response_done(),
        ])
        _run(provider, tmp_path)
        assert (tmp_path / "ok.txt").exists()


class TestWarRoomToolFormatting:
    """Test that tool result lines format correctly for the War Room."""

    def test_write_success(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("write_file", {"path": "src/app.py", "content": "x" * 100}, "Successfully wrote 100 characters to 'src/app.py'.")
        assert "Write" in line
        assert "src/app.py" in line
        assert "100 chars" in line
        assert line.startswith("✓")

    def test_write_blocked(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("write_file", {"path": "../../evil.txt", "content": "x"}, "Error: Path escapes project root: ../../evil.txt")
        assert line.startswith("✗")
        assert "blocked" in line

    def test_read_success(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("read_file", {"path": "src/main.py"}, "file contents here")
        assert "Read" in line
        assert "src/main.py" in line
        assert line.startswith("✓")

    def test_edit_success(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("edit_file", {"path": "src/cli.py"}, "Successfully edited 'src/cli.py'.")
        assert "Edit" in line
        assert "src/cli.py" in line

    def test_run_command_success(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("run_command", {"command": "pytest tests/ -x"}, "3 passed")
        assert "Bash" in line
        assert "pytest" in line

    def test_escalate_formatting(self):
        from odd.display import format_tool_result_line
        line = format_tool_result_line("escalate", {"reason": "Can't find the API", "severity": "blocker"}, "Escalation registered.")
        assert "Escalate" in line
        assert "blocker" in line


class TestActivityLogging:
    """Prove that tool executions through the runner produce activity log entries."""

    def test_write_logged_to_activity(self, tmp_path):
        """write_file through the runner logs to activity.jsonl."""
        import json
        from odd.tracing import init_tracing

        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        init_tracing(odd_dir)

        provider = FakeProvider([
            _response_write("logged.txt", "content"),
            _response_done(),
        ])
        _run(provider, tmp_path, persona=_persona("Vera"))

        log_path = odd_dir / "logs" / "activity.jsonl"
        assert log_path.exists(), "activity.jsonl was not created"
        records = [json.loads(line) for line in log_path.read_text().splitlines() if line.strip()]

        tool_records = [r for r in records if r.get("type") == "tool_use"]
        assert len(tool_records) >= 1
        write_rec = next(r for r in tool_records if r["tool"] == "write_file")
        assert write_rec["agent"] == "Vera"
        assert write_rec["input"]["path"] == "logged.txt"
        assert "Successfully" in write_rec["result"]
