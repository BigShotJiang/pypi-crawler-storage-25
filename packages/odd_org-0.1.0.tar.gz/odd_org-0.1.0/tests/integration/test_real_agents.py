"""Integration tests that exercise real Anthropic API calls using FAST tier.

Every test is marked @pytest.mark.integration and skipped when
ANTHROPIC_API_KEY is not set. All personas are forced to FAST tier
regardless of role defaults.

Run with:  pytest -m integration
"""

from __future__ import annotations

import ast
import os

import pytest

from odd.agent import AgentEngine, BudgetExceededError
from odd.cfo import CFO
from odd.models import ModelTier, Persona, RoleType
from odd.providers.anthropic import AnthropicProvider


pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Tool-use loop tests
# ---------------------------------------------------------------------------


class TestAgentReadsFile:
    """Full agentic loop: prompt -> tool_use -> tool_result -> response."""

    def test_agent_reads_file_and_responds(
        self, haiku_engine, haiku_persona, project_dir
    ):
        # Create a file for the agent to read
        test_file = project_dir / "hello.txt"
        test_file.write_text("The secret number is 42.", encoding="utf-8")

        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "Read the file 'hello.txt' and tell me what the secret number is. "
                "Reply with ONLY the number after you read it."
            ),
        )

        assert "42" in response


class TestAgentWritesFile:
    """Agent creates a file via write_file tool, verify on disk."""

    def test_agent_writes_file(self, haiku_engine, haiku_persona, project_dir):
        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "Create a file called 'output.txt' containing exactly the text "
                "'Hello from Haiku'. Do not include any other content in the file."
            ),
        )

        output_file = project_dir / "output.txt"
        assert output_file.exists(), "Agent should have created output.txt"
        content = output_file.read_text(encoding="utf-8")
        assert "Hello from Haiku" in content


class TestAgentEditsFile:
    """Agent edits an existing file, verify edit applied."""

    def test_agent_edits_file(self, haiku_engine, haiku_persona, project_dir):
        target = project_dir / "config.txt"
        target.write_text("version=1.0\nmode=debug\n", encoding="utf-8")

        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "Edit the file 'config.txt': change 'mode=debug' to 'mode=production'."
            ),
        )

        content = target.read_text(encoding="utf-8")
        assert "mode=production" in content
        assert "mode=debug" not in content


class TestAgentRunsCommand:
    """Agent runs a shell command, verify output is captured."""

    def test_agent_runs_command(self, haiku_engine, haiku_persona, project_dir):
        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "Run the command 'python -c \"print(7 * 6)\"' and tell me the result. "
                "Reply with ONLY the number."
            ),
        )

        assert "42" in response


# ---------------------------------------------------------------------------
# Role-specific structural tests
# ---------------------------------------------------------------------------


class TestQAWritesTests:
    """QA writes pytest tests, verify they are valid Python."""

    def test_qa_writes_tests_that_are_valid_python(
        self, haiku_engine, haiku_qa_persona, project_dir
    ):
        response = haiku_engine.invoke(
            persona=haiku_qa_persona,
            user_message=(
                "Write a small pytest test file to 'tests/test_math.py' that tests "
                "a function called 'add(a, b)' which returns a + b. Include at least "
                "2 test cases. Define the add function at the top of the test file."
            ),
        )

        test_file = project_dir / "tests" / "test_math.py"
        assert test_file.exists(), "QA should have created tests/test_math.py"

        source = test_file.read_text(encoding="utf-8")
        # Verify it's valid Python by parsing the AST
        tree = ast.parse(source)
        # Verify it contains at least one function starting with test_
        test_funcs = [
            node
            for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name.startswith("test_")
        ]
        assert len(test_funcs) >= 2, f"Expected >= 2 test functions, got {len(test_funcs)}"


class TestRecruiterResume:
    """Recruiter generates resume with NAME:/TITLE:, verify parsing."""

    def test_recruiter_produces_parseable_resume(
        self, haiku_engine, haiku_recruiter_persona, project_dir
    ):
        response = haiku_engine.invoke(
            persona=haiku_recruiter_persona,
            user_message=(
                "Write a resume for a Python backend specialist. "
                "Start with a line 'NAME: <name>' and a line 'TITLE: <title>'. "
                "Include skills and experience."
            ),
            tools=False,
        )

        # Verify NAME: and TITLE: are present and parseable
        name_found = False
        title_found = False
        for line in response.split("\n"):
            stripped = line.strip()
            if stripped.upper().startswith("NAME:"):
                name_value = stripped[5:].strip()
                assert len(name_value) > 0, "NAME: should have a value"
                name_found = True
            elif stripped.upper().startswith("TITLE:"):
                title_value = stripped[6:].strip()
                assert len(title_value) > 0, "TITLE: should have a value"
                title_found = True

        assert name_found, "Response should contain a NAME: line"
        assert title_found, "Response should contain a TITLE: line"


# ---------------------------------------------------------------------------
# Budget enforcement
# ---------------------------------------------------------------------------


class TestBudgetEnforcement:
    """Tiny budget triggers BudgetExceededError."""

    def test_budget_enforcement_stops_loop(self, project_dir):
        # Set up CFO with a tiny budget that will be exceeded after one call
        odd_dir = project_dir / ".odd"
        odd_dir.mkdir()
        cfo = CFO(odd_dir)
        cfo.set_budget(total_budget=0.0001)  # Effectively zero

        # Pre-record some usage to blow the budget before the first call
        cfo.record(
            agent_name="setup",
            model=ModelTier.FAST.value,
            input_tokens=1000,
            output_tokens=1000,
            sprint=1,
        )

        provider = AnthropicProvider(api_key=os.environ.get("ANTHROPIC_API_KEY"))
        engine = AgentEngine(
            provider=provider,
            cfo=cfo,
            current_sprint=1,
        )

        persona = Persona(
            role_type=RoleType.LEAD_DEV,
            name="BudgetTest",
            title="Budget Test Agent",
            model=ModelTier.FAST,
        )

        with pytest.raises(BudgetExceededError):
            engine.invoke(persona=persona, user_message="This should fail.")


# ---------------------------------------------------------------------------
# Sprint plan parsing
# ---------------------------------------------------------------------------


class TestLeadDevPlan:
    """Lead dev plans sprint, verify _parse_tasks finds tasks."""

    def test_lead_dev_produces_parseable_plan(
        self, haiku_engine, haiku_persona, project_dir
    ):
        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "Plan a sprint to build a calculator module. Break it down into tasks.\n\n"
                "Format EACH task exactly like this:\n"
                "TASK: <description>\n"
                "ASSIGN: <role>\n\n"
                "Include at least 2 tasks."
            ),
            tools=False,
        )

        # Use the real parser
        from odd.parsers import parse_tasks

        tasks = parse_tasks(response, sprint_number=1)
        assert len(tasks) >= 2, f"Expected >= 2 tasks, got {len(tasks)}: {response}"
        for task in tasks:
            assert task.description
            assert task.assigned_to


# ---------------------------------------------------------------------------
# Escalation tool
# ---------------------------------------------------------------------------


class TestEscalationTool:
    """Agent uses escalate tool, verify in engine.get_escalations()."""

    def test_escalation_tool_registers(
        self, haiku_engine, haiku_persona, project_dir
    ):
        response = haiku_engine.invoke(
            persona=haiku_persona,
            user_message=(
                "You need to escalate an issue to the CEO. Use the escalate tool "
                "with reason 'Need clarification on requirements' and severity "
                "'needs_decision'. After escalating, say 'ESCALATED'."
            ),
        )

        escalations = haiku_engine.get_escalations()
        assert len(escalations) >= 1, f"Expected at least 1 escalation, got {len(escalations)}"
        assert any("clarification" in e["reason"].lower() or "requirement" in e["reason"].lower() for e in escalations)
