"""Shared fixtures for integration tests.

All integration tests hit the real Anthropic API using the FAST tier (cheapest).
They are skipped automatically when ANTHROPIC_API_KEY is not set.
"""

from __future__ import annotations

import os

import pytest

from odd.agent import AgentEngine
from odd.models import ModelTier, Persona, RoleType
from odd.providers.anthropic import AnthropicProvider


# Skip the entire module if no API key is available
def pytest_collection_modifyitems(config, items):
    if not os.environ.get("ANTHROPIC_API_KEY"):
        skip = pytest.mark.skip(reason="ANTHROPIC_API_KEY not set")
        for item in items:
            if "integration" in item.keywords:
                item.add_marker(skip)


@pytest.fixture
def haiku_engine() -> AgentEngine:
    """Create an AgentEngine that talks to the real API."""
    provider = AnthropicProvider(api_key=os.environ.get("ANTHROPIC_API_KEY"))
    return AgentEngine(provider=provider)


@pytest.fixture
def haiku_persona() -> Persona:
    """A minimal FAST-tier persona for cheap integration tests."""
    return Persona(
        role_type=RoleType.LEAD_DEV,
        name="TestDev",
        title="Integration Test Agent",
        job_description="You are a helpful agent used for integration testing. Be concise.",
        model=ModelTier.FAST,
    )


@pytest.fixture
def haiku_qa_persona() -> Persona:
    """QA persona forced to FAST tier."""
    return Persona(
        role_type=RoleType.QA,
        name="TestQA",
        title="Integration Test QA",
        job_description=(
            "You are the QA engineer. You write pytest tests. "
            "Be concise and produce valid Python."
        ),
        model=ModelTier.FAST,
    )


@pytest.fixture
def haiku_recruiter_persona() -> Persona:
    """Recruiter persona forced to FAST tier."""
    return Persona(
        role_type=RoleType.RECRUITER,
        name="TestRecruiter",
        title="Integration Test Recruiter",
        job_description=(
            "You find the perfect specialist for any job. Given a job description, "
            "you craft a detailed resume/profile. Start with NAME: and TITLE: lines."
        ),
        model=ModelTier.FAST,
    )


@pytest.fixture
def project_dir(tmp_path):
    """A temporary project directory for integration tests.

    Sets the working directory so agent file tools operate in isolation.
    """
    original = os.getcwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original)
