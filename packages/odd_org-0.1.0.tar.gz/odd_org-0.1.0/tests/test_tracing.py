"""Tests for odd.tracing - unified activity logging."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from odd.tracing import (
    init_tracing,
    load_sprint_trace,
    load_trace,
    log_agent_call,
    log_escalation,
    log_tool_use,
)


@pytest.fixture
def odd_dir(tmp_path):
    """Create a temporary .odd/ directory and initialize tracing."""
    d = tmp_path / ".odd"
    d.mkdir()
    init_tracing(d)
    yield d
    # Reset module state
    import odd.tracing as _t
    _t._logs_dir = None


class TestInitTracing:
    def test_creates_logs_dir(self, odd_dir):
        assert (odd_dir / "logs").is_dir()


class TestLogAgentCall:
    def test_writes_jsonl_record(self, odd_dir):
        log_agent_call(
            agent_name="Cody",
            role="lead_dev",
            model="claude-opus-4-6",
            system_prompt_len=500,
            user_message="Build feature X",
            input_tokens=1000,
            output_tokens=500,
            input_cost=0.005,
            output_cost=0.0125,
            tool_calls=3,
            iterations=2,
            stop_reason="end_turn",
            duration_ms=5000,
            sprint=1,
            phase="implementation",
        )

        log_path = odd_dir / "logs" / "activity.jsonl"
        assert log_path.exists()
        records = [json.loads(line) for line in log_path.read_text().splitlines()]
        assert len(records) == 1

        r = records[0]
        assert r["type"] == "api_call"
        assert r["agent"] == "Cody"
        assert r["role"] == "lead_dev"
        assert r["model"] == "claude-opus-4-6"
        assert r["input_tokens"] == 1000
        assert r["output_tokens"] == 500
        assert r["input_cost"] == 0.005
        assert r["output_cost"] == 0.0125
        assert r["tool_calls"] == 3
        assert r["sprint"] == 1
        assert r["phase"] == "implementation"
        assert "ts" in r

    def test_truncates_user_message(self, odd_dir):
        long_msg = "x" * 300
        log_agent_call(
            agent_name="Cody",
            role="lead_dev",
            model="test",
            system_prompt_len=0,
            user_message=long_msg,
        )
        records = load_trace(odd_dir)
        assert len(records[0]["user_message_preview"]) == 200

    def test_noop_when_not_initialized(self):
        """Logging before init_tracing is a no-op, not an error."""
        import odd.tracing as _t
        _t._logs_dir = None
        log_agent_call(
            agent_name="Ghost",
            role="qa",
            model="test",
            system_prompt_len=0,
            user_message="ignored",
        )
        # No exception, no file written


class TestLogEscalation:
    def test_writes_escalation_event(self, odd_dir):
        log_escalation(
            agent_name="Vera",
            reason="Tests are failing",
            severity="blocker",
            sprint=2,
        )
        records = load_trace(odd_dir)
        assert len(records) == 1
        assert records[0]["type"] == "escalation"
        assert records[0]["agent"] == "Vera"
        assert records[0]["severity"] == "blocker"


class TestLogToolUse:
    def test_writes_tool_use_record(self, odd_dir):
        log_tool_use(
            agent="Cody",
            tool="write_file",
            tool_input={"file_path": "foo.py", "content": "x"},
            result="ok",
            duration_ms=15,
            exit_code=0,
            sprint=1,
        )
        records = load_trace(odd_dir, record_type="tool_use")
        assert len(records) == 1
        r = records[0]
        assert r["type"] == "tool_use"
        assert r["agent"] == "Cody"
        assert r["tool"] == "write_file"
        assert r["duration_ms"] == 15
        assert r["exit_code"] == 0
        assert r["sprint"] == 1

    def test_blocked_field(self, odd_dir):
        log_tool_use(
            agent="Cody",
            tool="write_file",
            tool_input={},
            result="blocked by hooks",
            duration_ms=1,
            blocked=True,
            sprint=1,
        )
        records = load_trace(odd_dir, record_type="tool_use")
        assert records[0]["blocked"] is True

    def test_sprint_filtering(self, odd_dir):
        """tool_use records with sprint should be found by load_sprint_trace."""
        log_tool_use(agent="A", tool="x", tool_input={}, result="ok", duration_ms=1, sprint=1)
        log_tool_use(agent="B", tool="y", tool_input={}, result="ok", duration_ms=1, sprint=2)
        log_tool_use(agent="C", tool="z", tool_input={}, result="ok", duration_ms=1)  # no sprint

        from odd.tracing import load_sprint_trace
        sprint1_tools = load_sprint_trace(odd_dir, 1, record_type="tool_use")
        assert len(sprint1_tools) == 1
        assert sprint1_tools[0]["agent"] == "A"


class TestLoadTrace:
    def test_empty_when_no_logs(self, odd_dir):
        assert load_trace(odd_dir) == []

    def test_loads_multiple_records(self, odd_dir):
        for i in range(3):
            log_agent_call(
                agent_name=f"Agent{i}",
                role="lead_dev",
                model="test",
                system_prompt_len=0,
                user_message=f"task {i}",
                sprint=1,
            )
        records = load_trace(odd_dir)
        assert len(records) == 3

    def test_filters_by_type(self, odd_dir):
        log_agent_call(
            agent_name="Cody", role="lead_dev", model="t",
            system_prompt_len=0, user_message="go", sprint=1,
        )
        log_escalation(agent_name="Vera", reason="fail", severity="blocker", sprint=1)
        log_tool_use(agent="Cody", tool="read_file", tool_input={}, result="ok", duration_ms=5)

        assert len(load_trace(odd_dir)) == 3
        assert len(load_trace(odd_dir, record_type="api_call")) == 1
        assert len(load_trace(odd_dir, record_type="escalation")) == 1
        assert len(load_trace(odd_dir, record_type="tool_use")) == 1


class TestLoadSprintTrace:
    def test_filters_by_sprint(self, odd_dir):
        log_agent_call(agent_name="A", role="qa", model="t", system_prompt_len=0, user_message="s1", sprint=1)
        log_agent_call(agent_name="B", role="qa", model="t", system_prompt_len=0, user_message="s2", sprint=2)
        log_agent_call(agent_name="C", role="qa", model="t", system_prompt_len=0, user_message="s1", sprint=1)

        sprint1 = load_sprint_trace(odd_dir, 1)
        assert len(sprint1) == 2
        assert all(r["sprint"] == 1 for r in sprint1)

        sprint2 = load_sprint_trace(odd_dir, 2)
        assert len(sprint2) == 1

    def test_filters_by_sprint_and_type(self, odd_dir):
        log_agent_call(agent_name="A", role="qa", model="t", system_prompt_len=0, user_message="go", sprint=1)
        log_escalation(agent_name="B", reason="oops", severity="blocker", sprint=1)
        log_tool_use(agent="A", tool="x", tool_input={}, result="ok", duration_ms=1, sprint=1)

        api_only = load_sprint_trace(odd_dir, 1, record_type="api_call")
        assert len(api_only) == 1
        assert api_only[0]["type"] == "api_call"

        tool_only = load_sprint_trace(odd_dir, 1, record_type="tool_use")
        assert len(tool_only) == 1
        assert tool_only[0]["tool"] == "x"


class TestMigration:
    def test_migrates_legacy_audit_log(self, tmp_path):
        """Legacy audit.jsonl entries get tagged and moved to activity.jsonl."""
        d = tmp_path / ".odd"
        d.mkdir()
        logs = d / "logs"
        logs.mkdir()

        # Write a legacy audit record
        legacy = {"ts": "2025-01-01T00:00:00Z", "agent": "cody", "tool": "write_file",
                  "input": {}, "result": "ok", "duration_ms": 10}
        (logs / "audit.jsonl").write_text(json.dumps(legacy) + "\n", encoding="utf-8")

        init_tracing(d)

        # Legacy file should be renamed
        assert not (logs / "audit.jsonl").exists()
        assert (logs / "audit.jsonl.migrated").exists()

        # Activity log should contain the migrated record with type tag
        records = load_trace(d, record_type="tool_use")
        assert len(records) == 1
        assert records[0]["type"] == "tool_use"
        assert records[0]["agent"] == "cody"

        # Reset
        import odd.tracing as _t
        _t._logs_dir = None
