"""Tests for odd.cfo - cost tracking, budgets, financial reports."""

import json

import pytest

from odd.cfo import CFO, SprintFinancials, TokenUsage
from odd.config import OPUS_MODEL, SONNET_MODEL
from odd.tracing import init_tracing, log_agent_call


@pytest.fixture
def cfo(tmp_path):
    """CFO with a fresh .odd/ directory and tracing initialized."""
    odd_dir = tmp_path / ".odd"
    odd_dir.mkdir()
    init_tracing(odd_dir)
    yield CFO(odd_dir)
    # Reset tracing module state
    import odd.tracing as _t
    _t._logs_dir = None


def _persist_record(cfo, usage):
    """Write a CFO record to the activity log (mirrors what runners do)."""
    log_agent_call(
        agent_name=usage.agent_name,
        role="test",
        model=usage.model,
        system_prompt_len=0,
        user_message="",
        input_tokens=usage.input_tokens,
        output_tokens=usage.output_tokens,
        input_cost=usage.input_cost,
        output_cost=usage.output_cost,
        sprint=usage.sprint,
        phase=usage.phase,
    )


# ---------------------------------------------------------------------------
# TokenUsage dataclass
# ---------------------------------------------------------------------------

class TestTokenUsage:
    def test_total_cost(self):
        u = TokenUsage(
            agent_name="LD", model="m", input_tokens=100, output_tokens=50,
            sprint=1, timestamp="t", input_cost=0.10, output_cost=0.05,
        )
        assert u.total_cost == pytest.approx(0.15)

    def test_total_tokens(self):
        u = TokenUsage(
            agent_name="LD", model="m", input_tokens=100, output_tokens=50,
            sprint=1, timestamp="t",
        )
        assert u.total_tokens == 150

    def test_to_dict(self):
        u = TokenUsage(
            agent_name="LD", model="m", input_tokens=100, output_tokens=50,
            sprint=1, timestamp="t", input_cost=0.10, output_cost=0.05,
        )
        d = u.to_dict()
        assert d["agent_name"] == "LD"
        assert d["input_tokens"] == 100
        assert d["input_cost"] == 0.10


# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------

class TestRecord:
    def test_record_calculates_costs(self, cfo):
        usage = cfo.record("Lead Dev", OPUS_MODEL, 1_000_000, 100_000, sprint=1)
        # Opus: $5/M in, $25/M out
        assert usage.input_cost == pytest.approx(5.0)
        assert usage.output_cost == pytest.approx(2.5)

    def test_record_persists(self, cfo):
        usage = cfo.record("LD", SONNET_MODEL, 500, 100, sprint=1)
        _persist_record(cfo, usage)
        # Reload from disk
        cfo2 = CFO(cfo.odd_dir)
        assert len(cfo2._ledger) == 1
        assert cfo2._ledger[0].agent_name == "LD"

    def test_record_unknown_model_zero_cost(self, cfo):
        usage = cfo.record("X", "unknown-model", 1000, 500)
        assert usage.input_cost == 0.0
        assert usage.output_cost == 0.0

    def test_multiple_records(self, cfo):
        cfo.record("A", SONNET_MODEL, 100, 50, sprint=1)
        cfo.record("B", OPUS_MODEL, 200, 100, sprint=1)
        cfo.record("A", SONNET_MODEL, 300, 150, sprint=2)
        assert len(cfo._ledger) == 3


# ---------------------------------------------------------------------------
# Budget
# ---------------------------------------------------------------------------

class TestBudget:
    def test_no_budget_by_default(self, cfo):
        ok, msg = cfo.check_budget()
        assert ok is True

    def test_set_and_check_total_budget(self, cfo):
        cfo.set_budget(total_budget=1.00)
        # Under budget
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        ok, msg = cfo.check_budget()
        assert ok is True

    def test_total_budget_exceeded(self, cfo):
        cfo.set_budget(total_budget=0.0001)
        cfo.record("A", OPUS_MODEL, 1_000_000, 100_000, sprint=1)
        ok, msg = cfo.check_budget()
        assert ok is False
        assert "BUDGET EXCEEDED" in msg

    def test_sprint_budget_exceeded(self, cfo):
        cfo.set_budget(sprint_budget=0.0001)
        cfo.record("A", OPUS_MODEL, 1_000_000, 100_000, sprint=1)
        ok, msg = cfo.check_budget(sprint=1)
        assert ok is False
        assert "SPRINT BUDGET" in msg

    def test_sprint_budget_different_sprint_ok(self, cfo):
        cfo.set_budget(sprint_budget=0.0001)
        cfo.record("A", OPUS_MODEL, 1_000_000, 100_000, sprint=1)
        # Sprint 2 hasn't spent anything
        ok, msg = cfo.check_budget(sprint=2)
        assert ok is True

    def test_load_budget_empty(self, cfo):
        budget = cfo._load_budget()
        assert budget == {}

    def test_set_budget_persists(self, cfo):
        cfo.set_budget(sprint_budget=5.0, total_budget=50.0)
        cfo2 = CFO(cfo.odd_dir)
        budget = cfo2._load_budget()
        assert budget["sprint_budget"] == 5.0
        assert budget["total_budget"] == 50.0

    def test_session_budget_exceeded(self, cfo):
        cfo.set_budget(session_budget=0.0001)
        cfo.record("A", OPUS_MODEL, 1_000_000, 100_000, sprint=1)
        ok, msg = cfo.check_budget()
        assert ok is False
        assert "SESSION BUDGET" in msg

    def test_session_budget_ok_when_within(self, cfo):
        cfo.set_budget(session_budget=100.0)
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        ok, msg = cfo.check_budget()
        assert ok is True

    def test_warning_does_not_mask_hard_stop(self, cfo):
        """A total-budget warning must not prevent a sprint-budget hard stop."""
        # Total budget: $20, will be at ~85% → warning territory
        # Sprint budget: tiny → will be exceeded
        cfo.set_budget(total_budget=20.0, sprint_budget=0.0001)
        cfo.record("A", OPUS_MODEL, 1_000_000, 500_000, sprint=1)
        ok, msg = cfo.check_budget(sprint=1)
        # Sprint budget should be exceeded, not masked by total warning
        assert ok is False
        assert "SPRINT BUDGET" in msg

    def test_warning_threshold_fires(self, cfo):
        cfo.set_budget(total_budget=10.0)
        # Spend ~$8.50 on a $10 budget → 85% → warning
        cfo.record("A", OPUS_MODEL, 1_000_000, 100_000, sprint=1)  # $5 + $2.5 = $7.5
        cfo.record("A", SONNET_MODEL, 500_000, 0, sprint=1)        # $1.5
        ok, msg = cfo.check_budget()
        assert ok is True
        assert msg.startswith("WARNING:")

    def test_set_session_budget_persists(self, cfo):
        cfo.set_budget(session_budget=25.0)
        cfo2 = CFO(cfo.odd_dir)
        budget = cfo2._load_budget()
        assert budget["session_budget"] == 25.0


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------

class TestQueries:
    def test_total_cost_empty(self, cfo):
        assert cfo.total_cost() == 0.0

    def test_total_cost(self, cfo):
        cfo.record("A", SONNET_MODEL, 1_000_000, 500_000, sprint=1)
        # Sonnet: $3/M in, $15/M out → $3 + $7.5 = $10.5
        assert cfo.total_cost() == pytest.approx(10.5)

    def test_total_tokens(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", OPUS_MODEL, 2000, 1000, sprint=1)
        input_t, output_t = cfo.total_tokens()
        assert input_t == 3000
        assert output_t == 1500

    def test_sprint_cost(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", SONNET_MODEL, 1000, 500, sprint=2)
        # Each sprint should have independent costs
        s1 = cfo.sprint_cost(1)
        s2 = cfo.sprint_cost(2)
        assert s1 == pytest.approx(s2)
        assert cfo.sprint_cost(99) == 0.0

    def test_sprint_financials(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", OPUS_MODEL, 2000, 1000, sprint=1)
        fin = cfo.sprint_financials(1)
        assert isinstance(fin, SprintFinancials)
        assert fin.sprint_number == 1
        assert fin.calls == 2
        assert "A" in fin.by_agent
        assert "B" in fin.by_agent
        assert SONNET_MODEL in fin.by_model

    def test_cost_per_sprint_average(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=2)
        avg = cfo.cost_per_sprint_average()
        assert avg == pytest.approx(cfo.total_cost() / 2)

    def test_cost_per_sprint_average_empty(self, cfo):
        assert cfo.cost_per_sprint_average() == 0.0

    def test_cost_by_agent(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", SONNET_MODEL, 1000, 500, sprint=1)
        by_agent = cfo.cost_by_agent()
        assert len(by_agent) == 2
        assert by_agent["A"] > by_agent["B"]

    def test_cost_by_model(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", OPUS_MODEL, 1000, 500, sprint=1)
        by_model = cfo.cost_by_model()
        assert SONNET_MODEL in by_model
        assert OPUS_MODEL in by_model

    def test_session_cost(self, cfo):
        cfo.record("A", SONNET_MODEL, 1_000_000, 500_000, sprint=1)
        assert cfo.session_cost() == pytest.approx(10.5)

    def test_session_cost_excludes_prior_ledger(self, tmp_path):
        """Session cost should only include calls from this session."""
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        init_tracing(odd_dir)
        cfo1 = CFO(odd_dir)
        usage = cfo1.record("A", SONNET_MODEL, 1_000_000, 500_000, sprint=1)
        _persist_record(cfo1, usage)
        # New CFO instance = new session
        cfo2 = CFO(odd_dir)
        assert cfo2.session_cost() == 0.0
        assert cfo2.total_cost() == pytest.approx(10.5)

    def test_session_tokens(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", OPUS_MODEL, 2000, 1000, sprint=1)
        input_t, output_t = cfo.session_tokens()
        assert input_t == 3000
        assert output_t == 1500


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------

class TestReports:
    def test_financial_report_empty(self, cfo):
        report = cfo.financial_report()
        assert "Financial Report" in report
        assert "$0.0000" in report

    def test_financial_report_with_data(self, cfo):
        cfo.record("Lead Dev", OPUS_MODEL, 10000, 5000, sprint=1)
        cfo.record("QA", SONNET_MODEL, 8000, 3000, sprint=1)
        report = cfo.financial_report()
        assert "Financial Report" in report
        assert "Lead Dev" in report
        assert "QA" in report
        assert "Sprint" in report

    def test_financial_report_with_budget(self, cfo):
        cfo.set_budget(total_budget=100.0, sprint_budget=10.0)
        report = cfo.financial_report()
        assert "Budget Remaining" in report

    def test_sprint_report(self, cfo):
        cfo.record("Lead Dev", OPUS_MODEL, 10000, 5000, sprint=1)
        report = cfo.sprint_report(1)
        assert "Sprint 1" in report
        assert "Lead Dev" in report

    def test_sprint_report_empty_sprint(self, cfo):
        report = cfo.sprint_report(99)
        assert "Sprint 99" in report
        assert "$0.0000" in report

    def test_cost_footer_empty(self, cfo):
        assert cfo.cost_footer() == ""

    def test_cost_footer_with_data(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        footer = cfo.cost_footer()
        assert "$" in footer
        assert "1,500 tokens" in footer
        assert "1 API call" in footer

    def test_cost_footer_plural_calls(self, cfo):
        cfo.record("A", SONNET_MODEL, 1000, 500, sprint=1)
        cfo.record("B", OPUS_MODEL, 2000, 1000, sprint=1)
        footer = cfo.cost_footer()
        assert "2 API calls" in footer


# ---------------------------------------------------------------------------
# Thread safety (Phase 2 hardening)
# ---------------------------------------------------------------------------

class TestCFOThreadSafety:
    def test_concurrent_records_no_lost_entries(self, cfo):
        """Multiple threads recording simultaneously should not lose entries."""
        import threading

        errors = []
        def record_n(agent, n):
            try:
                for _ in range(n):
                    cfo.record(agent, SONNET_MODEL, 100, 50, sprint=1)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=record_n, args=(f"agent_{i}", 50)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(cfo._ledger) == 200
        assert len(cfo._session_entries) == 200

    def test_has_lock_attribute(self, cfo):
        import threading
        assert isinstance(cfo._lock, type(threading.Lock()))
