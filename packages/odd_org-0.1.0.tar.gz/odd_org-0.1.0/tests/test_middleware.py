"""Tests for RunnerMiddleware - shared cross-cutting concerns."""

from unittest.mock import MagicMock, patch

import pytest

from odd.middleware import (
    BudgetStatus,
    CONTEXT_WRAP_UP_NOTICE,
    RunnerMiddleware,
    TokenUsage,
    WRAP_UP_NOTICE,
    estimate_tokens,
)


# ---------------------------------------------------------------------------
# estimate_tokens
# ---------------------------------------------------------------------------

class TestEstimateTokens:
    def test_simple_string(self):
        assert estimate_tokens("x" * 400, []) == 100

    def test_string_message(self):
        msgs = [{"role": "user", "content": "y" * 200}]
        assert estimate_tokens("x" * 200, msgs) == 100

    def test_list_content(self):
        msgs = [{"role": "user", "content": [{"type": "text", "text": "hello"}]}]
        result = estimate_tokens("", msgs)
        assert result > 0

    def test_empty(self):
        assert estimate_tokens("", []) == 0


# ---------------------------------------------------------------------------
# Budget checking
# ---------------------------------------------------------------------------

class TestCheckBudget:
    def test_no_cfo_returns_ok(self):
        mw = RunnerMiddleware()
        status = mw.check_budget()
        assert status.ok is True
        assert status.exceeded is False

    def test_hard_budget_exceeded(self):
        cfo = MagicMock()
        cfo.check_budget.return_value = (False, "Over budget")
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1)
        status = mw.check_budget()
        assert status.ok is False
        assert status.exceeded is True
        assert status.warning == "Over budget"

    def test_budget_warning(self):
        cfo = MagicMock()
        cfo.check_budget.return_value = (True, "WARNING: 80% used")
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1)
        status = mw.check_budget()
        assert status.ok is True
        assert status.warning == "WARNING: 80% used"

    def test_phase_budget_triggers_wind_down(self):
        cfo = MagicMock()
        cfo.check_budget.return_value = (True, "")
        cfo.check_phase_budget.return_value = (False, "Phase over")
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1, phase="implementation")
        status = mw.check_budget()
        assert status.phase_exceeded is True
        assert mw.winding_down is True
        assert mw.wind_down_remaining > 0

    def test_phase_budget_not_checked_without_phase(self):
        cfo = MagicMock()
        cfo.check_budget.return_value = (True, "")
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1)  # no phase
        status = mw.check_budget()
        assert status.phase_exceeded is False
        cfo.check_phase_budget.assert_not_called()

    def test_phase_budget_not_rechecked_when_winding_down(self):
        cfo = MagicMock()
        cfo.check_budget.return_value = (True, "")
        cfo.check_phase_budget.return_value = (False, "Phase over")
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1, phase="implementation")

        # First call triggers wind-down
        mw.check_budget()
        assert mw.winding_down is True

        # Second call should not re-check phase budget
        cfo.check_phase_budget.reset_mock()
        status2 = mw.check_budget()
        cfo.check_phase_budget.assert_not_called()
        assert status2.phase_exceeded is False


# ---------------------------------------------------------------------------
# Context window guard
# ---------------------------------------------------------------------------

class TestCheckContextWindow:
    def test_triggers_on_high_usage(self):
        mw = RunnerMiddleware()
        with patch("odd.middleware.resolve_context_window", return_value=100):
            # 400 chars = 100 tokens, threshold = 100 * 0.85 = 85
            triggered = mw.check_context_window("model", "x" * 400, [])
        assert triggered is True
        assert mw.winding_down is True

    def test_does_not_trigger_on_low_usage(self):
        mw = RunnerMiddleware()
        with patch("odd.middleware.resolve_context_window", return_value=10000):
            triggered = mw.check_context_window("model", "x" * 100, [])
        assert triggered is False
        assert mw.winding_down is False

    def test_only_fires_once(self):
        mw = RunnerMiddleware()
        with patch("odd.middleware.resolve_context_window", return_value=100):
            first = mw.check_context_window("model", "x" * 400, [])
            second = mw.check_context_window("model", "x" * 400, [])
        assert first is True
        assert second is False

    def test_skipped_when_already_winding_down(self):
        mw = RunnerMiddleware()
        mw.winding_down = True
        with patch("odd.middleware.resolve_context_window", return_value=100):
            triggered = mw.check_context_window("model", "x" * 400, [])
        assert triggered is False


# ---------------------------------------------------------------------------
# Cost recording
# ---------------------------------------------------------------------------

class TestRecordUsage:
    def test_no_cfo_returns_zero_cost(self):
        mw = RunnerMiddleware()
        usage = mw.record_usage("Agent", "model", 100, 50)
        assert usage.input_cost == 0.0
        assert usage.output_cost == 0.0
        # Tokens still accumulated
        assert mw._total_input_tokens == 100
        assert mw._total_output_tokens == 50

    def test_with_cfo_records_and_accumulates(self):
        cfo = MagicMock()
        cfo.record.return_value = MagicMock(input_cost=0.01, output_cost=0.05)
        mw = RunnerMiddleware(cfo=cfo, current_sprint=1, phase="impl")

        usage = mw.record_usage("Agent", "model", 100, 50)
        assert usage.input_cost == 0.01
        assert usage.output_cost == 0.05

        cfo.record.assert_called_once_with(
            agent_name="Agent",
            model="model",
            input_tokens=100,
            output_tokens=50,
            sprint=1,
            phase="impl",
        )

        # Accumulation
        assert mw._total_input_cost == 0.01
        assert mw._total_output_cost == 0.05

    def test_accumulates_across_calls(self):
        cfo = MagicMock()
        cfo.record.return_value = MagicMock(input_cost=0.01, output_cost=0.05)
        mw = RunnerMiddleware(cfo=cfo)

        mw.record_usage("Agent", "model", 100, 50)
        mw.record_usage("Agent", "model", 200, 100)

        assert mw._total_input_tokens == 300
        assert mw._total_output_tokens == 150
        assert mw._total_input_cost == pytest.approx(0.02)
        assert mw._total_output_cost == pytest.approx(0.10)


# ---------------------------------------------------------------------------
# Tool call counter
# ---------------------------------------------------------------------------

class TestAddToolCalls:
    def test_increments(self):
        mw = RunnerMiddleware()
        mw.add_tool_calls(3)
        mw.add_tool_calls(2)
        assert mw._total_tool_calls == 5


# ---------------------------------------------------------------------------
# Trace logging
# ---------------------------------------------------------------------------

class TestLogInvocation:
    @patch("odd.middleware.log_agent_call")
    def test_logs_accumulated_data(self, mock_log):
        cfo = MagicMock()
        cfo.record.return_value = MagicMock(input_cost=0.01, output_cost=0.05)
        mw = RunnerMiddleware(cfo=cfo, current_sprint=2, phase="qa")

        mw.record_usage("Cody", "opus", 500, 200)
        mw.add_tool_calls(4)

        mw.log_invocation(
            agent_name="Cody",
            role="lead_dev",
            model="opus",
            system_prompt_len=1000,
            user_message="do stuff",
            iterations=3,
            stop_reason="end_turn",
        )

        mock_log.assert_called_once()
        call_kwargs = mock_log.call_args.kwargs
        assert call_kwargs["agent_name"] == "Cody"
        assert call_kwargs["input_tokens"] == 500
        assert call_kwargs["output_tokens"] == 200
        assert call_kwargs["input_cost"] == 0.01
        assert call_kwargs["output_cost"] == 0.05
        assert call_kwargs["tool_calls"] == 4
        assert call_kwargs["sprint"] == 2
        assert call_kwargs["phase"] == "qa"
        assert call_kwargs["duration_ms"] >= 0

    @patch("odd.middleware.log_agent_call")
    def test_tool_calls_override(self, mock_log):
        """Caller can override tool_calls count."""
        mw = RunnerMiddleware()
        mw.add_tool_calls(10)

        mw.log_invocation(
            agent_name="X",
            role="qa",
            model="m",
            system_prompt_len=0,
            user_message="",
            tool_calls=42,  # override
        )

        call_kwargs = mock_log.call_args.kwargs
        assert call_kwargs["tool_calls"] == 42


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_wrap_up_notice_is_string(self):
        assert isinstance(WRAP_UP_NOTICE, str)
        assert "BUDGET" in WRAP_UP_NOTICE

    def test_context_notice_is_string(self):
        assert isinstance(CONTEXT_WRAP_UP_NOTICE, str)
        assert "CONTEXT" in CONTEXT_WRAP_UP_NOTICE
