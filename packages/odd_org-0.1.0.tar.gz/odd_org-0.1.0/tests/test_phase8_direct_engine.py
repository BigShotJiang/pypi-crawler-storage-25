"""Tests for Phase 8: Direct Engine Improvements.

Covers:
- Open WebUI provider
- Context window guard (resolve_context_window)
- CLI engine display enhancements
- Feature matrix
"""

import os
from unittest.mock import MagicMock, patch

import pytest

from odd.config import (
    WRAP_UP_THRESHOLD,
    DEFAULT_CONTEXT_WINDOW,
    MODEL_CONTEXT_WINDOWS,
    resolve_context_window,
)
from odd.models import ProviderConfig


# ---------------------------------------------------------------------------
# resolve_context_window
# ---------------------------------------------------------------------------

class TestResolveContextWindow:
    def test_exact_match_anthropic(self):
        assert resolve_context_window("claude-opus-4-6") == 200_000

    def test_exact_match_openai(self):
        assert resolve_context_window("gpt-4o") == 128_000

    def test_exact_match_openai_mini(self):
        assert resolve_context_window("gpt-4o-mini") == 128_000

    def test_exact_match_llama(self):
        assert resolve_context_window("llama3.1:70b") == 128_000

    def test_prefix_match(self):
        # "gpt-4o-2024-05-13" should match "gpt-4o" prefix
        assert resolve_context_window("gpt-4o-2024-05-13") == 128_000

    def test_prefix_longest_wins(self):
        # "gpt-4o-mini-2024" should match "gpt-4o-mini" (longer) not "gpt-4o"
        assert resolve_context_window("gpt-4o-mini-2024") == 128_000

    def test_haiku_prefix_match(self):
        # Haiku with full version should match the prefix
        assert resolve_context_window("claude-haiku-4-5-20251001") == 200_000

    def test_unknown_model_returns_default(self):
        assert resolve_context_window("some-unknown-model-v99") == DEFAULT_CONTEXT_WINDOW

    def test_empty_string_returns_default(self):
        assert resolve_context_window("") == DEFAULT_CONTEXT_WINDOW

    def test_mistral_match(self):
        assert resolve_context_window("mistral") == 32_000

    def test_deepseek_match(self):
        assert resolve_context_window("deepseek") == 128_000

    def test_wrap_up_threshold(self):
        assert WRAP_UP_THRESHOLD == 0.85


# ---------------------------------------------------------------------------
# Open WebUI provider
# ---------------------------------------------------------------------------

requests = pytest.importorskip("requests")

from odd.providers.openwebui import (
    OPENWEBUI_DEFAULT_BASE_URL,
    OPENWEBUI_MODEL_MAP,
    OpenWebUIProvider,
)
from odd.providers.openai_compat import OpenAICompatProvider
from odd.providers import resolve_provider


class TestOpenWebUIProvider:
    def test_is_openai_compat_subclass(self):
        assert issubclass(OpenWebUIProvider, OpenAICompatProvider)

    def test_default_base_url(self):
        p = OpenWebUIProvider()
        assert p.base_url == "http://localhost:3000/api"

    def test_default_model_map(self):
        p = OpenWebUIProvider()
        assert p.model_map["high"] == "llama3.1:70b"
        assert p.model_map["standard"] == "llama3.1:8b"

    def test_custom_base_url(self):
        p = OpenWebUIProvider(base_url="http://myhost:8080/api")
        assert p.base_url == "http://myhost:8080/api"

    def test_custom_model_map(self):
        custom = {"high": "qwen:72b", "standard": "qwen:7b", "fast": "qwen:7b"}
        p = OpenWebUIProvider(model_map=custom)
        assert p.model_map["high"] == "qwen:72b"

    def test_repr(self):
        p = OpenWebUIProvider()
        assert "OpenWebUIProvider" in repr(p)
        assert "localhost" in repr(p)

    def test_api_key_optional(self):
        p = OpenWebUIProvider()
        assert p.api_key == ""

    def test_api_key_passthrough(self):
        p = OpenWebUIProvider(api_key="my-key")
        assert p.api_key == "my-key"


class TestResolveProviderOpenWebUI:
    def test_openwebui_resolved(self):
        config = ProviderConfig(name="openwebui")
        provider = resolve_provider(config)
        assert isinstance(provider, OpenWebUIProvider)
        assert provider.base_url == OPENWEBUI_DEFAULT_BASE_URL

    def test_openwebui_custom_base_url(self):
        config = ProviderConfig(
            name="openwebui",
            base_url="http://myhost:9090/api",
        )
        provider = resolve_provider(config)
        assert isinstance(provider, OpenWebUIProvider)
        assert provider.base_url == "http://myhost:9090/api"

    def test_openwebui_custom_model_map(self):
        custom = {"high": "mistral:7b", "standard": "mistral:7b", "fast": "mistral:7b"}
        config = ProviderConfig(name="openwebui", model_map=custom)
        provider = resolve_provider(config)
        assert provider.model_map == custom

    def test_openwebui_reads_api_key(self):
        config = ProviderConfig(name="openwebui", api_key_env="OWUI_KEY")
        with patch.dict(os.environ, {"OWUI_KEY": "test-key-123"}):
            provider = resolve_provider(config)
        assert provider.api_key == "test-key-123"

    def test_openwebui_no_base_url_uses_default(self):
        config = ProviderConfig(name="openwebui", base_url="")
        provider = resolve_provider(config)
        assert provider.base_url == OPENWEBUI_DEFAULT_BASE_URL


# ---------------------------------------------------------------------------
# DirectRunner context guard uses centralized config
# ---------------------------------------------------------------------------

class TestDirectRunnerContextGuard:
    def test_estimate_tokens(self):
        from odd.middleware import estimate_tokens
        # chars / 4
        system = "x" * 400
        messages = [{"role": "user", "content": "y" * 400}]
        assert estimate_tokens(system, messages) == 200

    def test_context_guard_uses_resolve(self):
        """DirectRunner should use middleware's context window guard."""
        from odd.fallback.runner import DirectRunner
        from odd.middleware import RunnerMiddleware
        from odd.provider import AgentResponse, Usage
        from odd.models import Persona, RoleType

        provider = MagicMock()
        # Return end_turn immediately (no tool calls)
        provider.create_message.return_value = AgentResponse(
            text_blocks=["done"],
            tool_calls=[],
            stop_reason="end_turn",
            usage=Usage(input_tokens=10, output_tokens=10),
        )

        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="TestBot",
            title="Test",
        )

        runner = DirectRunner(
            provider=provider,
            escalations=[],
            submissions=[],
        )

        middleware = RunnerMiddleware()

        # With a small-context model and a huge prompt, context guard should trigger
        with patch("odd.middleware.resolve_context_window", return_value=100):
            # System + message > 100 * 0.85 = 85 tokens → should wind down
            result = runner.invoke(
                persona,
                system="x" * 400,  # 100 tokens
                messages=[{"role": "user", "content": "y" * 400}],  # 100 tokens
                tool_defs=None,
                model="tiny-model",
                middleware=middleware,
            )
        assert "done" in result


# ---------------------------------------------------------------------------
# CLI provider labels
# ---------------------------------------------------------------------------

class TestCLIProviderLabels:
    def test_provider_labels_exist(self):
        from odd.cli.config_cmds import PROVIDER_LABELS
        assert "anthropic" in PROVIDER_LABELS
        assert "openai-compat" in PROVIDER_LABELS
        assert "openwebui" in PROVIDER_LABELS


# ---------------------------------------------------------------------------
# CLI _default_api_key_env
# ---------------------------------------------------------------------------

class TestDefaultApiKeyEnv:
    def test_anthropic_default(self):
        from odd.cli import _default_api_key_env
        assert _default_api_key_env("anthropic") == "ANTHROPIC_API_KEY"

    def test_openai_compat(self):
        from odd.cli import _default_api_key_env
        assert _default_api_key_env("openai-compat") == "OPENAI_API_KEY"

    def test_openwebui(self):
        from odd.cli import _default_api_key_env
        assert _default_api_key_env("openwebui") == "OPENWEBUI_API_KEY"

    def test_unknown_falls_back_to_anthropic(self):
        from odd.cli import _default_api_key_env
        assert _default_api_key_env("unknown") == "ANTHROPIC_API_KEY"
