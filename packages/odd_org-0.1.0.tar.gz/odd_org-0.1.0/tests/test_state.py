"""Tests for odd.state - StateManager filesystem operations."""

import pytest

from odd.models import ModelTier, Persona, ProjectConfig, RoleType, Sprint, SprintStatus, SprintTask
from odd.state import StateManager, _slugify


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def state(tmp_path):
    """A StateManager rooted in a temporary directory."""
    return StateManager(tmp_path)


@pytest.fixture
def initialized_state(state):
    """A StateManager with init() already called."""
    config = ProjectConfig(name="TestProject", description="A test project")
    state.init(config)
    return state


# ---------------------------------------------------------------------------
# _slugify
# ---------------------------------------------------------------------------

class TestSlugify:
    def test_spaces_to_underscores(self):
        assert _slugify("Alice Jones") == "alice_jones"

    def test_hyphens_to_underscores(self):
        assert _slugify("some-name") == "some_name"

    def test_lowercase(self):
        assert _slugify("LeadDev") == "leaddev"

    def test_mixed(self):
        assert _slugify("My Cool-Agent") == "my_cool_agent"


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

class TestInit:
    def test_not_initialized_by_default(self, state):
        assert not state.is_initialized()

    def test_init_creates_directories(self, initialized_state):
        s = initialized_state
        assert s.is_initialized()
        assert s.odd_dir.exists()
        assert s.team_dir.exists()
        assert s.sprints_dir.exists()
        assert s.notes_dir.exists()

    def test_init_creates_role_subdirs(self, initialized_state):
        s = initialized_state
        for role in ["lead_dev", "qa", "recruiter", "secretary"]:
            assert (s.team_dir / role).is_dir()
        assert (s.team_dir / "consultants").is_dir()

    def test_init_saves_config(self, initialized_state):
        s = initialized_state
        assert s.config_path.exists()
        config = s.load_config()
        assert config.name == "TestProject"

    def test_init_idempotent(self, initialized_state):
        """Calling init twice shouldn't error (exist_ok=True)."""
        config = ProjectConfig(name="TestProject")
        initialized_state.init(config)
        assert initialized_state.is_initialized()


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

class TestConfig:
    def test_save_and_load(self, initialized_state):
        s = initialized_state
        config = s.load_config()
        config.description = "Updated description"
        config.current_sprint = 3
        s.save_config(config)

        reloaded = s.load_config()
        assert reloaded.description == "Updated description"
        assert reloaded.current_sprint == 3

    def test_load_nonexistent_raises(self, state):
        with pytest.raises(Exception):
            state.load_config()


# ---------------------------------------------------------------------------
# Personas
# ---------------------------------------------------------------------------

class TestPersonas:
    def test_save_and_load_core_role(self, initialized_state):
        s = initialized_state
        persona = Persona(
            role_type=RoleType.LEAD_DEV,
            name="Lead Developer",
            title="Lead Dev",
            job_description="Build stuff",
        )
        s.save_persona(persona)

        loaded = s.load_persona("lead_dev")
        assert loaded.name == "Lead Developer"
        assert loaded.job_description == "Build stuff"

    def test_save_writes_jd_and_resume_files(self, initialized_state):
        s = initialized_state
        persona = Persona(
            role_type=RoleType.QA,
            name="QA",
            title="QA Engineer",
            job_description="Break things",
            resume="10 years of breaking things",
        )
        s.save_persona(persona)

        qa_dir = s.team_dir / "qa"
        assert (qa_dir / "job_description.md").read_text() == "Break things"
        assert (qa_dir / "resume.md").read_text() == "10 years of breaking things"

    def test_save_and_load_consultant(self, initialized_state):
        s = initialized_state
        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="Alice Jones",
            title="Security Expert",
            job_description="Pen testing",
            resume="Elite hacker background",
        )
        s.save_persona(persona)

        loaded = s.load_persona("consultant", "Alice Jones")
        assert loaded.name == "Alice Jones"
        assert loaded.resume == "Elite hacker background"

    def test_consultant_saved_in_slugified_dir(self, initialized_state):
        s = initialized_state
        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="Bob Smith",
            title="DB Expert",
        )
        s.save_persona(persona)
        assert (s.team_dir / "consultants" / "bob_smith" / "persona.json").exists()

    def test_load_nonexistent_persona_raises(self, initialized_state):
        with pytest.raises(Exception):
            initialized_state.load_persona("lead_dev")  # never saved


# ---------------------------------------------------------------------------
# Consultants
# ---------------------------------------------------------------------------

class TestConsultants:
    def _make_consultant(self, name):
        return Persona(
            role_type=RoleType.CONSULTANT,
            name=name,
            title=name,
        )

    def test_list_consultants_empty(self, initialized_state):
        assert initialized_state.list_consultants() == []

    def test_list_consultants(self, initialized_state):
        s = initialized_state
        s.save_persona(self._make_consultant("Alice"))
        s.save_persona(self._make_consultant("Bob"))

        consultants = s.list_consultants()
        names = {c.name for c in consultants}
        assert names == {"Alice", "Bob"}

    def test_archive_consultant(self, initialized_state):
        s = initialized_state
        s.save_persona(self._make_consultant("Charlie"))
        assert len(s.list_consultants()) == 1

        s.archive_consultant("Charlie")
        assert len(s.list_consultants()) == 0

        # Archived folder exists
        assert (s.team_dir / "consultants" / "_archived" / "charlie").exists()

    def test_archive_nonexistent_raises(self, initialized_state):
        with pytest.raises(FileNotFoundError):
            initialized_state.archive_consultant("Nobody")

    def test_list_excludes_archived(self, initialized_state):
        s = initialized_state
        s.save_persona(self._make_consultant("Alice"))
        s.save_persona(self._make_consultant("Bob"))
        s.archive_consultant("Alice")

        consultants = s.list_consultants()
        names = {c.name for c in consultants}
        assert names == {"Bob"}


# ---------------------------------------------------------------------------
# Sprints
# ---------------------------------------------------------------------------

class TestSprints:
    def test_save_and_load(self, initialized_state):
        s = initialized_state
        task = SprintTask(id="s1_t1", description="Build it", assigned_to="Lead Dev")
        sprint = Sprint(number=1, goal="Ship MVP", tasks=[task])
        s.save_sprint(sprint)

        loaded = s.load_sprint(1)
        assert loaded.goal == "Ship MVP"
        assert len(loaded.tasks) == 1
        assert loaded.tasks[0].id == "s1_t1"

    def test_save_creates_sprint_dir(self, initialized_state):
        s = initialized_state
        sprint = Sprint(number=5, goal="Polish")
        s.save_sprint(sprint)
        assert (s.sprints_dir / "sprint_5" / "sprint.json").exists()

    def test_load_nonexistent_raises(self, initialized_state):
        with pytest.raises(Exception):
            initialized_state.load_sprint(999)

    def test_overwrite_sprint(self, initialized_state):
        s = initialized_state
        sprint = Sprint(number=1, goal="V1")
        s.save_sprint(sprint)

        sprint.goal = "V2"
        sprint.status = SprintStatus.COMPLETE
        s.save_sprint(sprint)

        loaded = s.load_sprint(1)
        assert loaded.goal == "V2"
        assert loaded.status == SprintStatus.COMPLETE


# ---------------------------------------------------------------------------
# Persona Notes Directory
# ---------------------------------------------------------------------------

class TestPersonaNotesDir:
    def test_core_role_notes_dir(self, initialized_state):
        s = initialized_state
        persona = Persona(role_type=RoleType.LEAD_DEV, name="LD", title="Lead Dev")
        notes_dir = s.get_persona_notes_dir(persona)
        assert notes_dir.exists()
        assert "lead_dev" in str(notes_dir)

    def test_consultant_notes_dir(self, initialized_state):
        s = initialized_state
        persona = Persona(
            role_type=RoleType.CONSULTANT,
            name="Alice Jones",
            title="Expert",
        )
        notes_dir = s.get_persona_notes_dir(persona)
        assert notes_dir.exists()
        assert "alice_jones" in str(notes_dir)


# ---------------------------------------------------------------------------
# Consultant ratings
# ---------------------------------------------------------------------------

class TestConsultantRatings:
    def _make_consultant(self, state, name="Rex"):
        persona = Persona(
            role_type=RoleType.CONSULTANT, name=name, title="Expert",
        )
        state.save_persona(persona)
        return persona

    def test_empty_record(self, initialized_state):
        record = initialized_state.load_consultant_record("Nobody")
        assert record.name == "Nobody"
        assert record.outcomes == []
        assert record.summary() == "no track record"

    def test_record_and_reload(self, initialized_state):
        s = initialized_state
        self._make_consultant(s)
        s.record_task_outcome("Rex", 1, "t1", "Build widget", True, retries=0)
        s.record_task_outcome("Rex", 1, "t2", "Fix bug", False, retries=2)

        record = s.load_consultant_record("Rex")
        assert len(record.outcomes) == 2
        assert record.tasks_completed == 1
        assert record.tasks_failed == 1
        assert record.success_rate == 0.5
        assert record.avg_retries == 1.0

    def test_record_task_outcome_returns_updated(self, initialized_state):
        s = initialized_state
        self._make_consultant(s)
        record = s.record_task_outcome("Rex", 1, "t1", "task", True)
        assert len(record.outcomes) == 1

    def test_all_consultant_records(self, initialized_state):
        s = initialized_state
        self._make_consultant(s, "Rex")
        self._make_consultant(s, "Ivy")
        s.record_task_outcome("Rex", 1, "t1", "task", True)

        records = s.all_consultant_records()
        assert "Rex" in records
        assert "Ivy" in records
        assert len(records["Rex"].outcomes) == 1
        assert len(records["Ivy"].outcomes) == 0

    def test_summary_perfect(self, initialized_state):
        s = initialized_state
        self._make_consultant(s)
        for i in range(3):
            s.record_task_outcome("Rex", 1, f"t{i}", "task", True)
        record = s.load_consultant_record("Rex")
        assert "100%" in record.summary()
        assert "3/3" in record.summary()


# ---------------------------------------------------------------------------
# Thread safety (Phase 2 hardening)
# ---------------------------------------------------------------------------

class TestRecordTaskOutcomeThreadSafety:
    def test_concurrent_records_no_lost_outcomes(self, initialized_state):
        """Multiple threads recording to different consultants should not corrupt data."""
        import threading

        s = initialized_state
        # Create two consultants
        for name in ("Alpha", "Beta"):
            s.save_persona(Persona(
                role_type=RoleType.CONSULTANT, name=name, title=name,
            ))

        errors = []
        def record_n(name, n):
            try:
                for i in range(n):
                    s.record_task_outcome(name, 1, f"{name}_t{i}", "task", True)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=record_n, args=("Alpha", 10)),
            threading.Thread(target=record_n, args=("Beta", 10)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(s.load_consultant_record("Alpha").outcomes) == 10
        assert len(s.load_consultant_record("Beta").outcomes) == 10

    def test_has_record_lock(self, initialized_state):
        import threading
        assert isinstance(initialized_state._record_lock, type(threading.Lock()))
