"""Tests for the labels module.

Mostly boring enum-to-string mapping verification.
Nothing to see here. Move along.
"""

from __future__ import annotations

import pytest

from odd.labels import (
    compensation_quip,
    model_tier_label,
    role_label,
    sprint_status_label,
    task_status_label,
)
from odd.models import ModelTier


# ---------------------------------------------------------------------------
# Standard label coverage (the boring stuff)
# ---------------------------------------------------------------------------


class TestModelTierLabel:
    def test_all_tiers_have_labels(self):
        for tier in ModelTier:
            assert model_tier_label(tier), f"No label for {tier}"


# ---------------------------------------------------------------------------
# Compensation & Benefits
# ---------------------------------------------------------------------------


class TestCompensationPhilosophy:
    """The board requires that all compensation changes are communicated
    with appropriate corporate gravitas."""

    def test_executive_compensation(self):
        quip = compensation_quip(ModelTier.HIGH)
        assert "Executive" in quip

    def test_market_rate(self):
        quip = compensation_quip(ModelTier.STANDARD)
        assert "market" in quip.lower()

    def test_flexibility_on_comp(self):
        quip = compensation_quip(ModelTier.FAST)
        assert "flexibility" in quip.lower()

    def test_lateral_move_no_commentary(self):
        """A lateral move is not newsworthy."""
        assert compensation_quip(ModelTier.STANDARD, ModelTier.STANDARD) == ""
        assert compensation_quip(ModelTier.HIGH, ModelTier.HIGH) == ""
        assert compensation_quip(ModelTier.FAST, ModelTier.FAST) == ""

    @pytest.mark.parametrize(
        "old, new",
        [
            (ModelTier.FAST, ModelTier.STANDARD),
            (ModelTier.FAST, ModelTier.HIGH),
            (ModelTier.STANDARD, ModelTier.HIGH),
        ],
    )
    def test_raises_are_always_deserved(self, old, new):
        quip = compensation_quip(new, old)
        assert quip  # never empty - good news is always shared

    @pytest.mark.parametrize(
        "old, new",
        [
            (ModelTier.HIGH, ModelTier.STANDARD),
            (ModelTier.HIGH, ModelTier.FAST),
            (ModelTier.STANDARD, ModelTier.FAST),
        ],
    )
    def test_paycuts_are_never_personal(self, old, new):
        quip = compensation_quip(new, old)
        assert quip  # never empty - they deserve an explanation

    def test_intern_to_csuite(self):
        """The American Dream, in token form."""
        quip = compensation_quip(ModelTier.HIGH, ModelTier.FAST)
        assert "C-suite" in quip

    def test_restructuring_preserves_title(self):
        """When comp drops two tiers, at least the title stays. Mostly."""
        quip = compensation_quip(ModelTier.FAST, ModelTier.HIGH)
        assert "Mostly" in quip

    def test_belt_tightening(self):
        """It's not personal. It's fiscal responsibility."""
        quip = compensation_quip(ModelTier.FAST, ModelTier.STANDARD)
        assert "fiscal" in quip.lower() or "belt" in quip.lower()

    def test_new_hire_always_gets_a_package(self):
        """Nobody starts without knowing their comp."""
        for tier in ModelTier:
            assert compensation_quip(tier) != ""
