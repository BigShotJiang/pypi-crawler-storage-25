"""Tests for odd.cli - Click commands via CliRunner (no real API calls)."""

import json
from unittest.mock import MagicMock, patch, PropertyMock

import pytest
from click.testing import CliRunner

from odd.cli import main, _load_team
from odd.parsers import parse_consultant_specs
from odd.models import Persona, ProjectConfig, RoleType, Sprint, SprintStatus, SprintTask


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def initialized_project(tmp_path):
    """Create a fully initialized .odd/ directory for commands that need it."""
    odd_dir = tmp_path / ".odd"
    odd_dir.mkdir()
    (odd_dir / "team").mkdir()
    (odd_dir / "sprints").mkdir()
    (odd_dir / "notes").mkdir()
    (odd_dir / "financials").mkdir()

    for role in ["lead_dev", "qa", "recruiter", "secretary"]:
        (odd_dir / "team" / role).mkdir()

    (odd_dir / "team" / "consultants").mkdir()

    config = ProjectConfig(name="TestProject", description="A test project", current_sprint=0)
    (odd_dir / "config.json").write_text(config.model_dump_json(indent=2))

    # Save core team personas
    for role, name, title in [
        ("lead_dev", "Lead Developer", "Lead Developer"),
        ("qa", "Glitch Hunter", "QA Engineer"),
        ("recruiter", "Recruiter", "Technical Recruiter"),
        ("secretary", "Secretary", "Project Secretary"),
    ]:
        persona = Persona(role_type=RoleType(role), name=name, title=title, job_description="Does things")
        (odd_dir / "team" / role / "persona.json").write_text(persona.model_dump_json(indent=2))

    return tmp_path


def _add_consultant(project_path, name="Alice Expert", title="Expert"):
    """Helper to add a consultant to an initialized project."""
    odd_dir = project_path / ".odd"
    consultants_dir = odd_dir / "team" / "consultants"
    slug = name.lower().replace(" ", "_")
    persona_dir = consultants_dir / slug
    persona_dir.mkdir(parents=True, exist_ok=True)
    persona = Persona(
        role_type=RoleType.CONSULTANT, name=name, title=title,
        job_description="Expert JD", resume="Expert resume",
    )
    (persona_dir / "persona.json").write_text(persona.model_dump_json(indent=2))


def _add_sprint(project_path, number=1, goal="Build it", status=SprintStatus.REVIEW):
    """Helper to add a sprint to an initialized project."""
    odd_dir = project_path / ".odd"
    sprint = Sprint(
        number=number, goal=goal,
        tasks=[SprintTask(id=f"s{number}_t1", description="Task 1", assigned_to="Lead Developer")],
        status=status,
    )
    sprint_dir = odd_dir / "sprints" / f"sprint_{number}"
    sprint_dir.mkdir(parents=True, exist_ok=True)
    (sprint_dir / "sprint.json").write_text(sprint.model_dump_json(indent=2))
    # Update config sprint counter
    config_path = odd_dir / "config.json"
    config = ProjectConfig.model_validate_json(config_path.read_text())
    config.current_sprint = number
    config_path.write_text(config.model_dump_json(indent=2))


# ---------------------------------------------------------------------------
# parse_consultant_specs
# ---------------------------------------------------------------------------

class TestParseConsultantSpecs:
    def test_parses_structured_response(self):
        text = (
            "Based on the project, I recommend:\n\n"
            "CONSULTANT: Security Expert\n"
            "JD: Handles pen testing and security audits\n\n"
            "CONSULTANT: UI Designer\n"
            "JD: Designs user interfaces and manages design system\n"
        )
        specs = parse_consultant_specs(text)
        assert len(specs) == 2
        assert specs[0] == ("Security Expert", "Handles pen testing and security audits", "sonnet")
        assert specs[1] == ("UI Designer", "Designs user interfaces and manages design system", "sonnet")

    def test_handles_empty(self):
        assert parse_consultant_specs("No consultants needed") == []

    def test_handles_jd_without_consultant(self):
        text = "JD: orphaned job description"
        assert parse_consultant_specs(text) == []

    def test_handles_consultant_without_jd(self):
        text = "CONSULTANT: Lonely\nSome other text"
        assert parse_consultant_specs(text) == []

    def test_multiple_consultants_in_sequence(self):
        text = "CONSULTANT: A\nJD: JD A\nCONSULTANT: B\nJD: JD B\nCONSULTANT: C\nJD: JD C\n"
        specs = parse_consultant_specs(text)
        assert len(specs) == 3

    def test_case_insensitive(self):
        text = "consultant: Lower\njd: Lower JD\n"
        # The current parser checks line.upper().startswith
        specs = parse_consultant_specs(text)
        assert len(specs) == 1

    def test_parses_model_tier(self):
        text = (
            "CONSULTANT: Data Architect\n"
            "JD: Designs database schemas\n"
            "MODEL: opus - deep reasoning for schema design\n"
        )
        specs = parse_consultant_specs(text)
        assert len(specs) == 1
        assert specs[0] == ("Data Architect", "Designs database schemas", "opus")

    def test_defaults_model_to_sonnet(self):
        text = "CONSULTANT: Dev\nJD: Coding\n"
        specs = parse_consultant_specs(text)
        assert specs[0][2] == "sonnet"

    def test_multiple_with_mixed_models(self):
        text = (
            "CONSULTANT: Architect\n"
            "JD: Architecture\n"
            "MODEL: opus - complex design\n\n"
            "CONSULTANT: Formatter\n"
            "JD: Code formatting\n"
            "MODEL: haiku - simple tasks\n\n"
            "CONSULTANT: Developer\n"
            "JD: Implementation\n"
        )
        specs = parse_consultant_specs(text)
        assert len(specs) == 3
        assert specs[0][2] == "opus"
        assert specs[1][2] == "haiku"
        assert specs[2][2] == "sonnet"  # default

    def test_invalid_model_defaults_to_sonnet(self):
        text = "CONSULTANT: Dev\nJD: Work\nMODEL: gpt4\n"
        specs = parse_consultant_specs(text)
        assert specs[0][2] == "sonnet"


# ---------------------------------------------------------------------------
# _load_team
# ---------------------------------------------------------------------------

class TestLoadTeam:
    def test_loads_core_team(self, initialized_project):
        from odd.state import StateManager
        state = StateManager(initialized_project)
        team = _load_team(state)
        assert "lead_dev" in team
        assert "qa" in team
        assert "recruiter" in team
        assert "secretary" in team

    def test_includes_consultants(self, initialized_project):
        _add_consultant(initialized_project, "Alice Expert", "Expert")
        from odd.state import StateManager
        state = StateManager(initialized_project)
        team = _load_team(state)
        assert "alice_expert" in team
        assert team["alice_expert"].name == "Alice Expert"


# ---------------------------------------------------------------------------
# CLI Commands (no API needed)
# ---------------------------------------------------------------------------

class TestHelpAndBasics:
    def test_main_help(self, runner):
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "ODD" in result.output

    def test_all_commands_listed(self, runner):
        result = runner.invoke(main, ["--help"])
        for cmd in ["init", "sprint", "standup", "team", "hire", "status",
                     "costs", "budget", "fire", "retro", "1on1", "spike",
                     "review", "onboard", "add-backlog", "backlog", "values",
                     "beta-test"]:
            assert cmd in result.output, f"Command '{cmd}' not in help output"


class TestStatusCommand:
    def test_not_initialized(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 1
        assert "odd init" in result.output

    def test_initialized(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "TestProject" in result.output

    def test_status_with_active_sprint(self, runner, initialized_project, monkeypatch):
        _add_sprint(initialized_project, number=1, goal="Build auth")
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "Build auth" in result.output


class TestTeamCommand:
    def test_shows_roster(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["team"])
        assert result.exit_code == 0
        assert "Lead Developer" in result.output
        assert "No consultants" in result.output

    def test_shows_consultants(self, runner, initialized_project, monkeypatch):
        _add_consultant(initialized_project, "Bob DevOps", "DevOps Engineer")
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["team"])
        assert result.exit_code == 0
        assert "Bob DevOps" in result.output


class TestCostsCommand:
    def test_empty_costs(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["costs"])
        assert result.exit_code == 0
        assert "Financial Report" in result.output


class TestBudgetCommand:
    def test_show_no_budget(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["budget"])
        assert result.exit_code == 0
        assert "No budget set" in result.output

    def test_set_budget(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["budget", "--sprint-budget", "10.0", "--total-budget", "100.0"])
        assert result.exit_code == 0
        assert "Budget updated" in result.output
        assert "$10.00" in result.output
        assert "$100.00" in result.output

    def test_set_only_sprint_budget(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["budget", "-s", "5.0"])
        assert result.exit_code == 0
        assert "$5.00" in result.output

    def test_set_only_total_budget(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["budget", "-t", "50.0"])
        assert result.exit_code == 0
        assert "$50.00" in result.output

    def test_show_existing_budget(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        # Set budget first
        runner.invoke(main, ["budget", "-s", "5.0", "-t", "50.0"])
        # Then view it
        result = runner.invoke(main, ["budget"])
        assert result.exit_code == 0
        assert "5.0" in result.output
        assert "50.0" in result.output


class TestBacklogCommands:
    def test_empty_backlog(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["backlog"])
        assert result.exit_code == 0
        assert "empty" in result.output.lower()

    def test_add_and_show(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["add-backlog", "Build auth module"])
        assert result.exit_code == 0
        assert "Added" in result.output

        result = runner.invoke(main, ["backlog"])
        assert result.exit_code == 0
        assert "Build auth module" in result.output

    def test_add_with_priority(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["add-backlog", "-p", "critical", "Fix security bug"])
        assert result.exit_code == 0
        assert "Fix security bug" in result.output

    def test_multiple_items(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        runner.invoke(main, ["add-backlog", "Item A"])
        runner.invoke(main, ["add-backlog", "Item B"])
        runner.invoke(main, ["add-backlog", "-p", "high", "Item C"])

        result = runner.invoke(main, ["backlog"])
        assert "Item A" in result.output
        assert "Item B" in result.output
        assert "Item C" in result.output


class TestReviewCommand:
    def test_no_data(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["review"])
        assert result.exit_code == 0
        assert "No data" in result.output or "Performance Review" in result.output


class TestInitAlreadyInitialized:
    def test_init_when_already_initialized(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        assert "already initialized" in result.output


class TestRetroNoSprint:
    def test_retro_no_sprint(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["retro"])
        assert result.exit_code == 0
        assert "No sprints" in result.output


class TestStandupNoSprint:
    def test_standup_no_sprint(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["standup"])
        assert result.exit_code == 0
        assert "No active sprint" in result.output or "odd sprint" in result.output


class TestFireNoMatch:
    def test_fire_nonexistent(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["fire", "Nobody"])
        assert result.exit_code == 0
        assert "No consultant found" in result.output


# ---------------------------------------------------------------------------
# Commands that require mocked API / Prompt
# ---------------------------------------------------------------------------

class TestInitCommand:
    """Test the full init flow with mocked engine and prompts."""

    @patch("odd.commands.init_cmd.refresh_pricing", return_value={"model": {"input": 1.0, "output": 2.0}})
    @patch("odd.cli.AgentEngine")
    @patch("odd.commands.init_cmd.Prompt.ask")
    def test_full_init_flow(self, mock_ask, mock_engine_cls, mock_pricing, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        # Simulate CEO responses
        mock_ask.side_effect = [
            "MyProject",       # project name
            "y",               # initialize git? yes
            "n",               # customize models? no
            "2",               # CEO style: balanced
            "1",               # review passes: quick
            "n",               # customize budget? no
            "Build a web app", # CEO conversation with lead dev
            "done",            # end conversation
            "done",            # accept proposed values
        ]

        # Mock engine behavior
        mock_engine = MagicMock()
        # conversation().send() handles the lead dev conversation turns
        mock_conv = MagicMock()
        mock_conv.send.side_effect = [
            "Hi CEO! Tell me about the project.",   # lead dev opening
            "Sounds great! Let me think...",         # lead dev response
        ]
        mock_conv.__enter__ = lambda self: mock_conv
        mock_conv.__exit__ = lambda self, *a: False
        mock_engine.conversation.return_value = mock_conv
        mock_engine.invoke.side_effect = [
            "Ship fast\nTest everything",            # proposed values
            "No consultants needed",                 # consultant recommendations (no CONSULTANT: lines)
            "A web application for task management", # project description
        ]
        mock_engine.pop_submissions.return_value = []
        mock_engine_cls.return_value = mock_engine

        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        assert "Organization created" in result.output
        assert "MyProject" in result.output

    @patch("odd.commands.init_cmd.refresh_pricing", return_value={})
    @patch("odd.cli.AgentEngine")
    @patch("odd.commands.init_cmd.Prompt.ask")
    def test_init_with_consultant_recruitment(self, mock_ask, mock_engine_cls, mock_pricing, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        mock_ask.side_effect = [
            "MyProject",
            "y",             # initialize git? yes
            "n",             # customize models? no
            "2",             # CEO style: balanced
            "1",             # review passes: quick
            "n",             # customize budget? no
            "done",          # immediate done (lead dev conversation)
            "done",          # accept proposed values
        ]

        mock_engine = MagicMock()
        mock_conv = MagicMock()
        mock_conv.send.side_effect = [
            "Tell me about the project.",                # opening (immediate done after)
        ]
        mock_conv.__enter__ = lambda self: mock_conv
        mock_conv.__exit__ = lambda self, *a: False
        mock_engine.conversation.return_value = mock_conv
        mock_engine.invoke.side_effect = [
            "Quality first\nShip often",                 # proposed values
            "CONSULTANT: DB Expert\nJD: Database work",  # consultant recs
            "NAME: DB Expert\nTITLE: DBA\nResume...",    # recruiter generates
            "Refined resume with specifics...",          # resume self-refinement
            "A database project",                        # description
        ]
        mock_engine.pop_submissions.return_value = []
        mock_engine_cls.return_value = mock_engine

        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        assert "Recruiting" in result.output or "was just hired" in result.output

    @patch("odd.commands.init_cmd.refresh_pricing", return_value={})
    @patch("odd.cli.AgentEngine")
    @patch("odd.commands.init_cmd.Prompt.ask")
    def test_init_with_model_customization(self, mock_ask, mock_engine_cls, mock_pricing, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        mock_ask.side_effect = [
            "MyProject",
            "y",              # initialize git? yes
            "y",              # customize models? yes
            "haiku",          # lead_dev model
            "sonnet",         # qa model
            "haiku",          # recruiter model
            "haiku",          # secretary model
            "2",              # CEO style: balanced
            "1",              # review passes: quick
            "n",              # customize budget? no
            "done",           # end conversation
            "done",           # accept proposed values
        ]

        mock_engine = MagicMock()
        mock_conv = MagicMock()
        mock_conv.send.side_effect = [
            "Hi!",           # opening (immediate done after)
        ]
        mock_conv.__enter__ = lambda self: mock_conv
        mock_conv.__exit__ = lambda self, *a: False
        mock_engine.conversation.return_value = mock_conv
        mock_engine.invoke.side_effect = [
            "Move fast", "No consultants needed", "Description",
        ]
        mock_engine.pop_submissions.return_value = []
        mock_engine_cls.return_value = mock_engine

        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0


class TestSprintCommand:
    """Test the sprint flow with mocked engine and prompts."""

    @patch("odd.cli._get_engine")
    @patch("odd.cli.sprint_cmds.Prompt.ask")
    def test_sprint_happy_path(self, mock_ask, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        mock_ask.side_effect = [
            "Build user auth",  # CEO goal
        ]

        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "Done"
        mock_get_engine.return_value = mock_engine

        with patch("odd.cli.sprint_cmds.SprintEngine") as mock_se_cls:
            mock_se = MagicMock()
            sprint = Sprint(
                number=1, goal="Build user auth",
                tasks=[SprintTask(id="s1_t1", description="Task", assigned_to="LD")],
                status=SprintStatus.COMPLETE,
            )
            mock_se.plan_roadmap.return_value = None  # single sprint
            mock_se.run_full_sprint.return_value = sprint
            mock_se.engine = mock_engine
            mock_se_cls.return_value = mock_se

            result = runner.invoke(main, ["sprint"])

        assert result.exit_code == 0
        mock_se.run_full_sprint.assert_called_once()

    @patch("odd.cli._get_engine")
    @patch("odd.cli.sprint_cmds.Prompt.ask")
    def test_sprint_budget_exceeded(self, mock_ask, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        from odd.agent import BudgetExceededError

        mock_ask.side_effect = [
            "Build everything",
        ]

        mock_engine = MagicMock()
        mock_get_engine.return_value = mock_engine

        with patch("odd.cli.sprint_cmds.SprintEngine") as mock_se_cls:
            mock_se = MagicMock()
            mock_se.plan_roadmap.return_value = None
            mock_se.run_full_sprint.side_effect = BudgetExceededError("Over budget!")
            mock_se_cls.return_value = mock_se

            result = runner.invoke(main, ["sprint"])

        assert result.exit_code == 0
        assert "BUDGET EXCEEDED" in result.output


class TestHireCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.commands.hire_cmd.recruit_consultant")
    def test_hire_with_description(self, mock_recruit, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        mock_recruit.return_value = Persona(
            role_type=RoleType.CONSULTANT,
            name="New Hire",
            title="Security Expert",
            job_description="Security work",
            resume="NAME: New Hire\nTITLE: Security Expert\nExperienced security pro...",
        )
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["hire", "Security expert with OWASP experience"])
        assert result.exit_code == 0
        assert "New Hire" in result.output
        assert "was just hired" in result.output

    @patch("odd.cli._get_engine")
    @patch("odd.commands.hire_cmd.recruit_consultant")
    @patch("odd.commands.hire_cmd.Prompt.ask")
    def test_hire_interactive_flow(self, mock_ask, mock_recruit, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        mock_ask.side_effect = [
            "I need help with the database",  # CEO describes need
            "done",                            # End conversation
        ]

        mock_engine = MagicMock()
        mock_engine.submissions = []  # Real list so _has_submissions() works
        mock_engine.pop_submissions.return_value = [
            {"tool": "submit_hire_suggestion", "data": {"suggestions": [
                {"description": "Database optimization specialist", "model": "standard"},
            ]}},
        ]
        # conversation().send() handles the interactive loop + JD generation
        mock_conv = MagicMock()
        mock_conv.send.side_effect = [
            "What kind of database work?",       # Lead dev opening question
            "Got it, DB optimization needed.",    # Lead dev follow-up
            "Database optimization specialist",   # Lead dev writes JD
        ]
        mock_conv.__enter__ = lambda self: mock_conv
        mock_conv.__exit__ = lambda self, *a: False
        mock_engine.conversation.return_value = mock_conv
        mock_get_engine.return_value = mock_engine

        mock_recruit.return_value = Persona(
            role_type=RoleType.CONSULTANT,
            name="DB Pro",
            title="Database Expert",
            job_description="DB JD",
            resume="NAME: DB Pro\nTITLE: Database Expert\nResume...",
        )

        result = runner.invoke(main, ["hire"])
        assert result.exit_code == 0
        assert "DB Pro" in result.output

    @patch("odd.cli._get_engine")
    @patch("odd.commands.hire_cmd.Prompt.ask")
    def test_hire_interactive_cancelled(self, mock_ask, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        mock_ask.side_effect = [
            "cancel",  # Cancel immediately
        ]

        mock_engine = MagicMock()
        mock_engine.submissions = []
        mock_conv = MagicMock()
        mock_conv.send.side_effect = [
            "What do you need?",   # Lead dev question
        ]
        mock_conv.__enter__ = lambda self: mock_conv
        mock_conv.__exit__ = lambda self, *a: False
        mock_engine.conversation.return_value = mock_conv
        mock_get_engine.return_value = mock_engine

        result = runner.invoke(main, ["hire"])
        assert result.exit_code == 0
        assert "cancelled" in result.output.lower()


class TestFireCommand:
    def test_fire_with_match_confirmed(self, runner, initialized_project, monkeypatch):
        _add_consultant(initialized_project, "Alice Expert", "Expert")
        monkeypatch.chdir(initialized_project)

        with patch("odd.cli.team_cmds.Prompt.ask", return_value="y"):
            result = runner.invoke(main, ["fire", "Alice"])

        assert result.exit_code == 0
        assert "let go" in result.output.lower() or "Alice" in result.output

    def test_fire_with_match_cancelled(self, runner, initialized_project, monkeypatch):
        _add_consultant(initialized_project, "Alice Expert", "Expert")
        monkeypatch.chdir(initialized_project)

        with patch("odd.cli.team_cmds.Prompt.ask", return_value="n"):
            result = runner.invoke(main, ["fire", "Alice"])

        assert result.exit_code == 0
        assert "Cancelled" in result.output


class TestStandupCommand:
    @patch("odd.cli._get_engine")
    def test_standup_with_sprint(self, mock_get_engine, runner, initialized_project, monkeypatch):
        _add_sprint(initialized_project, number=1, goal="Build it", status=SprintStatus.IN_PROGRESS)
        monkeypatch.chdir(initialized_project)

        mock_engine = MagicMock()
        mock_get_engine.return_value = mock_engine

        with patch("odd.cli.sprint_cmds.SprintEngine") as mock_se_cls:
            mock_se = MagicMock()
            mock_se.run_standup.return_value = "All clear!"
            mock_se_cls.return_value = mock_se

            result = runner.invoke(main, ["standup"])

        assert result.exit_code == 0


class TestRetroCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.cli.misc_cmds.run_retrospective")
    def test_retro_with_sprint(self, mock_retro, mock_get_engine, runner, initialized_project, monkeypatch):
        _add_sprint(initialized_project, number=1, goal="Build it")
        monkeypatch.chdir(initialized_project)

        mock_retro.return_value = "Great sprint!"
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["retro"])
        assert result.exit_code == 0


class TestOneOnOneCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.run_one_on_one")
    def test_1on1_with_valid_agent(self, mock_1on1, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["1on1", "lead"])
        assert result.exit_code == 0
        mock_1on1.assert_called_once()

    def test_1on1_unknown_agent(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["1on1", "nobody_exists"])
        assert result.exit_code == 0
        assert "No team member" in result.output


class TestSpikeCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.cli.misc_cmds.run_spike")
    def test_spike_runs(self, mock_spike, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_spike.return_value = "Use PostgreSQL"
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["spike", "Which database to use?"])
        assert result.exit_code == 0
        mock_spike.assert_called_once()


class TestOnboardCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.generate_onboarding_brief")
    def test_onboard_runs(self, mock_onboard, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_onboard.return_value = "Welcome to the team!"
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["onboard"])
        assert result.exit_code == 0


class TestBetaTestCommand:
    @patch("odd.cli._get_engine")
    @patch("odd.cli.misc_cmds.run_beta_test")
    def test_beta_test_runs(self, mock_beta, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        mock_beta.return_value = "Synthesis: Great product! A few issues..."
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, ["beta-test", "-n", "2"])
        assert result.exit_code == 0
        mock_beta.assert_called_once()


class TestRefreshPricingCommand:
    @patch("odd.cli.config_cmds.refresh_pricing")
    def test_refresh_with_results(self, mock_refresh, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_refresh.return_value = {
            "claude-opus-4-6": {"input": 5.0, "output": 25.0},
        }

        result = runner.invoke(main, ["refresh-pricing"])
        assert result.exit_code == 0
        assert "Pricing updated" in result.output
        assert "$5.0" in result.output

    @patch("odd.cli.config_cmds.refresh_pricing")
    def test_refresh_empty_result(self, mock_refresh, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_refresh.return_value = {}

        result = runner.invoke(main, ["refresh-pricing"])
        assert result.exit_code == 0
        # Empty dict is falsy, so should show "Could not fetch"
        assert "Could not fetch" in result.output


class TestValuesCommand:
    @patch("odd.cli.config_cmds.Prompt.ask")
    def test_add_values(self, mock_ask, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_ask.side_effect = [
            "Ship fast",
            "Test everything",
            "done",
        ]

        result = runner.invoke(main, ["values"])
        assert result.exit_code == 0
        assert "Ship fast" in result.output
        assert "Test everything" in result.output

    @patch("odd.cli.config_cmds.Prompt.ask")
    def test_remove_value(self, mock_ask, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)

        # First add a value
        mock_ask.side_effect = ["Ship fast", "done"]
        runner.invoke(main, ["values"])

        # Then remove it
        mock_ask.side_effect = ["remove 1", "done"]
        result = runner.invoke(main, ["values"])
        assert result.exit_code == 0
        assert "Removed" in result.output

    @patch("odd.cli.config_cmds.Prompt.ask")
    def test_remove_invalid_index(self, mock_ask, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_ask.side_effect = ["remove 99", "done"]
        result = runner.invoke(main, ["values"])
        assert result.exit_code == 0
        assert "Invalid" in result.output

    @patch("odd.cli.config_cmds.Prompt.ask")
    def test_remove_bad_format(self, mock_ask, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_ask.side_effect = ["remove abc", "done"]
        result = runner.invoke(main, ["values"])
        assert result.exit_code == 0
        assert "Usage" in result.output

    @patch("odd.cli.config_cmds.Prompt.ask")
    def test_empty_done(self, mock_ask, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_ask.side_effect = ["done"]
        result = runner.invoke(main, ["values"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# CEO shortcut commands - single-letter access
# ---------------------------------------------------------------------------

class TestCoreShortcuts:
    """Tests for d/v/s/p/b single-letter shortcut commands."""

    @pytest.mark.parametrize("letter,role_key", [
        ("d", "lead_dev"),
        ("v", "qa"),
        ("s", "recruiter"),
        ("p", "secretary"),
    ])
    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.run_one_on_one")
    def test_shortcut_interactive(self, mock_1on1, mock_get_engine, letter, role_key, runner, initialized_project, monkeypatch):
        """Bare letter opens interactive 1:1."""
        monkeypatch.chdir(initialized_project)
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, [letter])
        assert result.exit_code == 0
        mock_1on1.assert_called_once()
        # message kwarg should be None for interactive mode
        call_kwargs = mock_1on1.call_args
        assert call_kwargs.kwargs.get("message") is None

    @pytest.mark.parametrize("letter", ["d", "v", "s", "p"])
    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.run_one_on_one")
    def test_shortcut_one_shot(self, mock_1on1, mock_get_engine, letter, runner, initialized_project, monkeypatch):
        """Letter with message sends one-shot."""
        monkeypatch.chdir(initialized_project)
        mock_get_engine.return_value = MagicMock()

        result = runner.invoke(main, [letter, "do", "the", "thing"])
        assert result.exit_code == 0
        mock_1on1.assert_called_once()
        call_kwargs = mock_1on1.call_args
        assert call_kwargs.kwargs.get("message") == "do the thing"

    def test_b_shows_financial_report(self, runner, initialized_project, monkeypatch):
        """odd b shows Bill's financial report."""
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["b"])
        assert result.exit_code == 0
        assert "Bill the CFO" in result.output


class TestConsultantShortcut:
    """Tests for 'odd c <letter>' consultant shortcut."""

    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.run_one_on_one")
    def test_c_matches_consultant(self, mock_1on1, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_get_engine.return_value = MagicMock()
        _add_consultant(initialized_project, name="Marco Schema", title="DB Expert")

        result = runner.invoke(main, ["c", "m"])
        assert result.exit_code == 0
        mock_1on1.assert_called_once()

    @patch("odd.cli._get_engine")
    @patch("odd.cli.team_cmds.run_one_on_one")
    def test_c_one_shot(self, mock_1on1, mock_get_engine, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        mock_get_engine.return_value = MagicMock()
        _add_consultant(initialized_project, name="Marco Schema", title="DB Expert")

        result = runner.invoke(main, ["c", "m", "review", "this"])
        assert result.exit_code == 0
        call_kwargs = mock_1on1.call_args
        assert call_kwargs.kwargs.get("message") == "review this"

    def test_c_no_consultants(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        result = runner.invoke(main, ["c", "x"])
        assert result.exit_code == 0
        assert "No consultants" in result.output

    def test_c_no_match(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        _add_consultant(initialized_project, name="Marco Schema", title="DB Expert")
        result = runner.invoke(main, ["c", "z"])
        assert result.exit_code == 0
        assert "No consultant" in result.output

    def test_c_ambiguous_match(self, runner, initialized_project, monkeypatch):
        monkeypatch.chdir(initialized_project)
        _add_consultant(initialized_project, name="Marco Schema", title="DB Expert")
        _add_consultant(initialized_project, name="Maya Frontend", title="UI Expert")
        result = runner.invoke(main, ["c", "m"])
        assert result.exit_code == 0
        assert "Multiple" in result.output


# ---------------------------------------------------------------------------
# Not-initialized guard
# ---------------------------------------------------------------------------

class TestRequireInit:
    """Commands that require init should fail gracefully."""

    @pytest.mark.parametrize("cmd", [
        ["status"], ["team"], ["costs"], ["budget"], ["backlog"],
        ["review"], ["standup"], ["retro"], ["onboard"],
        ["fire", "x"], ["spike", "x"], ["1on1", "x"],
        ["add-backlog", "x"], ["hire", "x"],
        ["refresh-pricing"],
        ["d"], ["v"], ["s"], ["p"], ["b"],
        ["c", "x"],
    ])
    def test_commands_require_init(self, runner, tmp_path, monkeypatch, cmd):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, cmd)
        assert result.exit_code == 1
        assert "odd init" in result.output
