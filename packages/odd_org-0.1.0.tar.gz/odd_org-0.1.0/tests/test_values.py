"""Tests for odd.values - company values management."""

import json
from unittest.mock import MagicMock

import pytest

from odd.values import CompanyValues


@pytest.fixture
def cv(tmp_path):
    odd_dir = tmp_path / ".odd"
    odd_dir.mkdir()
    return CompanyValues(odd_dir)


class TestCompanyValues:
    def test_empty_by_default(self, cv):
        assert cv.get_values() == []

    def test_add_value(self, cv):
        cv.add_value("Ship fast")
        assert cv.get_values() == ["Ship fast"]

    def test_add_multiple(self, cv):
        cv.add_value("Ship fast")
        cv.add_value("Test everything")
        cv.add_value("Stay lean")
        assert len(cv.get_values()) == 3

    def test_remove_value(self, cv):
        cv.add_value("A")
        cv.add_value("B")
        cv.add_value("C")
        removed = cv.remove_value(1)
        assert removed == "B"
        assert cv.get_values() == ["A", "C"]

    def test_remove_invalid_index(self, cv):
        cv.add_value("A")
        assert cv.remove_value(5) is None
        assert cv.remove_value(-1) is None

    def test_set_values(self, cv):
        cv.set_values(["X", "Y", "Z"])
        assert cv.get_values() == ["X", "Y", "Z"]

    def test_set_values_overwrites(self, cv):
        cv.add_value("Old")
        cv.set_values(["New"])
        assert cv.get_values() == ["New"]


class TestSystemPromptFragment:
    def test_empty_returns_empty_string(self, cv):
        assert cv.system_prompt_fragment() == ""

    def test_generates_fragment(self, cv):
        cv.add_value("Quality first")
        cv.add_value("Move fast")
        fragment = cv.system_prompt_fragment()
        assert "Company Values" in fragment
        assert "Quality first" in fragment
        assert "Move fast" in fragment
        assert "1." in fragment
        assert "2." in fragment


class TestPersistence:
    def test_values_persist(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()

        cv1 = CompanyValues(odd_dir)
        cv1.add_value("Persist this")

        cv2 = CompanyValues(odd_dir)
        assert cv2.get_values() == ["Persist this"]

    def test_json_written(self, cv):
        cv.add_value("Value")
        assert cv.config_path.exists()


class TestProposeValues:
    """Tests for _propose_values in the init flow."""

    def _make_state(self, tmp_path):
        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        state = MagicMock()
        state.odd_dir = odd_dir
        return state

    @pytest.fixture
    def state(self, tmp_path):
        return self._make_state(tmp_path)

    def test_proposed_values_saved(self, state, monkeypatch):
        """Cody's proposal is parsed and saved when CEO accepts."""
        from odd.commands.init_cmd import _propose_values

        engine = MagicMock()
        engine.invoke.return_value = "Ship fast\nTest everything\nStay lean"
        lead_dev = MagicMock()

        monkeypatch.setattr("odd.commands.init_cmd.Prompt.ask", lambda *a, **kw: "done")

        _propose_values(engine, lead_dev, state, [])

        cv = CompanyValues(state.odd_dir)
        assert cv.get_values() == ["Ship fast", "Test everything", "Stay lean"]

    def test_ceo_can_add_value(self, state, monkeypatch):
        """CEO can add a value before accepting."""
        from odd.commands.init_cmd import _propose_values

        engine = MagicMock()
        engine.invoke.return_value = "Ship fast"
        lead_dev = MagicMock()

        responses = iter(["Be kind to users", "done"])
        monkeypatch.setattr("odd.commands.init_cmd.Prompt.ask", lambda *a, **kw: next(responses))

        _propose_values(engine, lead_dev, state, [])

        cv = CompanyValues(state.odd_dir)
        assert cv.get_values() == ["Ship fast", "Be kind to users"]

    def test_ceo_can_remove_value(self, state, monkeypatch):
        """CEO can remove a proposed value."""
        from odd.commands.init_cmd import _propose_values

        engine = MagicMock()
        engine.invoke.return_value = "Ship fast\nTest everything\nStay lean"
        lead_dev = MagicMock()

        responses = iter(["remove 2", "done"])
        monkeypatch.setattr("odd.commands.init_cmd.Prompt.ask", lambda *a, **kw: next(responses))

        _propose_values(engine, lead_dev, state, [])

        cv = CompanyValues(state.odd_dir)
        assert cv.get_values() == ["Ship fast", "Stay lean"]

    def test_strips_numbering_from_proposal(self, state, monkeypatch):
        """Numbered lists from the LLM are cleaned up."""
        from odd.commands.init_cmd import _propose_values

        engine = MagicMock()
        engine.invoke.return_value = "1. Ship fast\n2. Test everything\n3. Stay lean"
        lead_dev = MagicMock()

        monkeypatch.setattr("odd.commands.init_cmd.Prompt.ask", lambda *a, **kw: "done")

        _propose_values(engine, lead_dev, state, [])

        cv = CompanyValues(state.odd_dir)
        assert cv.get_values() == ["Ship fast", "Test everything", "Stay lean"]
