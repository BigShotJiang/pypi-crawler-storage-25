# ODD - Organization Driven Development; an Executable Metaphor

**We live in odd times**

## The Idea

You don't write code. You don't write specs. You run a company.

ODD organizes AI agents like a real software team:
* Lead Dev
* QA
* Recruiter
* Secretary
* CFO
* Specialist Consultants

They all collaborate through TDD and agile processes to build software. You provide vision and make decisions at sprint boundaries. They do everything else.

This is the next step up the abstraction ladder:

1. **You write code** to solve your problem
2. **You write specs** for an agent to code
3. **You direct a company of agents** and they spec, build, test, and ship.

## Why Organizational Patterns?

Sprints, standups, TDD, code review, retrospectives - these aren't just corporate rituals. They're coordination algorithms refined over decades of real software teams solving real problems. They evolved to handle communication overhead, context switching, uncertainty, and quality control.

AI agents have the same coordination problems. ODD applies the patterns that already work:

- **Strict agent isolation** - each team member is a separate API call with their own persona. No shared memory, no context bleed between roles. The same reason you don't want your QA engineer thinking like your developer.
- **TDD as quality gate** - QA writes tests *before* implementation. Tests passing is a more objective quality signal than code review alone, but you can add code review too.
- **Scope-boxed sprints** - agents work at inhuman speed, so sprints aren't time-boxed. They're batches of work between CEO decision points. You decide when the work is good enough to ship.
- **Consultants as perspectives** - hiring a consultant doesn't fill a capability gap (they're all Claude underneath). It adds a focused lens on a different slice of the problem. Diverse perspectives produce better work.

### Mechanical, Not Magical

Agents in ODD don't chat with each other. There are no multi-turn conversations between LLMs, no "Agent A said X so Agent B responds Y." That's theater.

Instead, coordination is almost entirely mechanical. Agents communicate through artifacts:

- **Git diffs** tell the next agent what changed
- **Test results** (pass/fail, stdout, tracebacks) are the feedback loop
- **Files on disk** are the shared state

Each agent gets a system prompt, the relevant files, and a task. It produces output. That output is evaluated mechanically (tests pass or they don't, diffs apply or they don't). The next agent gets the *result*, not a narrative. This is why organizational patterns work here, they were already designed to coordinate people who can't read each other's minds.

The one exception is adversarial code review. An anonymous reviewer scores the code at the end of a sprint, writes a review file, and your lead dev reads it and fixes issues, looping until the score clears the bar or you move on. Even here, agents don't converse; they pass artifacts through files.

## What It Looks Like

```
ODD - What would you like to do?

  Work
     1. Start a sprint
     2. Go on vacation
     3. Check project status
     4. Run a standup
  People
     5. Talk to a team member
     6. Run a retrospective
  Research
     7. Review the backlog
     8. Research a topic (spike)
     9. Get user feedback (beta test)
  Organization
    10. Set company values
    11. Set budget
    12. Manage the team (hire, fire, review)

    13. Call it a day

CEO> _
```

You pick a number. You talk to your team in plain English. They write real code to real files. You watch it happen in the war room, a live grid showing every agent's status, output, and tool calls. Jump in with a CEO interrupt when you need to course-correct. Or just go on vacation and let them run.

## The Team

| Role | Name | What They Do |
|------|------|-------------|
| Lead Dev | Cody | Architecture, implementation, technical decisions |
| QA | Vera | Writes tests first, validates everything |
| Recruiter | Scout | Finds and hires specialist consultants |
| Secretary | Paige | Standup notes, onboarding docs, retro synthesis |
| CFO | Bill | Tracks token costs, enforces budgets (deterministic, not an LLM) |

Senior roles (Lead Dev, QA) default to Claude Opus. Other agents default to Sonnet. Bill isn't an agent, he's pure accounting logic. You configure model tiers per-role to control quality vs. cost; it's a management decision.

## Install

```bash
pip install odd-org
```

ODD calls the Anthropic API directly. Get an API key from the [Anthropic Console](https://console.anthropic.com/) and set it:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

Then just:

```bash
odd
```

That's it. The menu walks you through everything, including first-time setup.

## Related Research

This is currently far from where I envision it and there is still a lot of testing to do, but I believe I'm on the right track. I've been building this with Opus for a little more than a week and stumbled across a paper yesterday where now I might as well build it in public. CMU researchers published [Effective Strategies for Asynchronous Software Engineering Agents](https://arxiv.org/abs/2603.21489) ([code](https://github.com/JiayiGeng/CAID)), demonstrating that multi-agent coordination with centralized delegation, strict workspace isolation, and test-gated integration outperforms single-agent scaling by 14-27% on software engineering benchmarks.

ODD shares the same core architecture - a central coordinator delegating to isolated agents with TDD as the quality gate. The CAID findings reinforce the approach: agent isolation matters, delegation quality is the bottleneck, and throwing more iterations at a single agent hits a ceiling that structured teamwork breaks through. ODD extends this with specialized roles instead of identical workers, human-in-the-loop decision points at sprint boundaries, and persistent team identity across sessions.

## Development

```bash
git clone https://github.com/ThePoetCoder/ODD.git
cd odd
pip install -e .
pytest
```

For a full list of CLI subcommands, run `odd --help`.

## License

MIT
