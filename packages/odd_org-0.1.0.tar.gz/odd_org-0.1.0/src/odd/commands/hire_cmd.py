"""Implementation of 'odd hire' - consultant recruitment."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from odd.agent import AgentEngine
from odd.config import CONVERSATION_HISTORY_THRESHOLD
from odd.models import Persona
from odd.roles import recruit_consultant
from odd.state import StateManager


console = Console()


def run_hire(
    engine: AgentEngine,
    state: StateManager,
    description: str | None,
    print_cost_footer: Callable[..., Any],
) -> None:
    """Full hire flow: figure out what's needed, recruit the consultant(s)."""
    config = state.load_config()
    recruiter = state.load_persona("recruiter")

    if description is None:
        descriptions = _discover_hire_needs(engine, state, config)
        if not descriptions:
            return  # Cancelled
    else:
        descriptions = [description]

    for i, desc in enumerate(descriptions):
        if len(descriptions) > 1:
            console.print(f"\n[bold]Hiring {i + 1}/{len(descriptions)}...[/bold]")

        consultant = recruit_consultant(engine, recruiter, desc)

        # Save immediately - no approval gate
        state.save_persona(consultant)

        console.print(
            f"\n[bold green]{consultant.name} was just hired "
            f"as the {consultant.title}![/bold green]"
        )

    print_cost_footer(engine.cfo)


def _discover_hire_needs(engine: AgentEngine, state: StateManager, config) -> list[str]:
    """CEO doesn't know what they need - Lead Dev helps figure it out.

    Flow: CEO chats with Cody → Cody calls submit_hire_suggestion when ready
    (or CEO types 'done' to nudge him) → descriptions returned → Scout starts.

    Returns a list of job descriptions (one per hire), or empty if cancelled.
    """
    lead_dev = state.load_persona("lead_dev")
    project_context = f"Project: {config.name}\nDescription: {config.description}"

    console.print(Panel(
        "No worries - let's figure out what you need.\n"
        "Your Lead Dev will help translate your needs into the right hire.",
        style="blue",
    ))

    # Single conversation - chat then submit in the same session.
    # The loop breaks automatically when Cody calls submit_hire_suggestion.
    # The CEO can also type "done" to prompt Cody explicitly, or "cancel".
    with engine.conversation(
        persona=lead_dev,
        project_context=project_context,
        tools=False,
    ) as conv:
        console.print("[bold blue]Lead Developer:[/bold blue]")
        conv.send(
            "The CEO wants to bring on new consultant(s). Have a brief, casual "
            "conversation to understand what they need - what problem they're "
            "trying to solve, what part of the project feels stuck, how many "
            "people they're thinking.\n\n"
            "When you have a clear picture, call the submit_hire_suggestion tool "
            "with your recommendations. Don't wait to be told - submit as soon "
            "as you know what's needed.\n\n"
            "Ask ONE clear question to get started. Keep it approachable - no jargon."
        )

        def _has_submissions() -> bool:
            return any(
                s["tool"] == "submit_hire_suggestion" for s in engine.submissions
            )

        turn_count = 1
        while True:
            # Cody may have already submitted during the previous turn
            if _has_submissions():
                break

            ceo_input = Prompt.ask("\n[bold yellow]CEO[/bold yellow]")
            stripped = ceo_input.lower().strip()
            if stripped == "cancel":
                console.print("[yellow]Hiring cancelled.[/yellow]")
                return []
            if stripped == "done":
                break

            turn_count += 1

            console.print("[bold blue]Lead Developer:[/bold blue]")
            conv.send(ceo_input)
            turn_count += 1

            if turn_count >= CONVERSATION_HISTORY_THRESHOLD:
                console.print("[dim]Type 'done' when ready, or keep talking.[/dim]")

        # If Cody already submitted during conversation, skip the explicit ask
        if not _has_submissions():
            console.print("[bold blue]Lead Developer is writing up the job descriptions...[/bold blue]")
            conv.send(
                "The CEO has approved hiring. Submit your recommendations NOW using "
                "the submit_hire_suggestion tool. For each consultant we discussed, "
                "include a detailed job description covering:\n"
                "- What specific problem they'll solve\n"
                "- What skills/expertise they need\n"
                "- What they'll actually be doing on this project\n\n"
                "Submit ALL recommendations in a single tool call."
            )

    submissions = engine.pop_submissions("submit_hire_suggestion")
    if not submissions:
        console.print("[yellow]No hiring suggestions submitted.[/yellow]")
        return []

    descriptions = _extract_descriptions(submissions)
    if len(descriptions) > 1:
        console.print(f"[bold]{len(descriptions)} positions identified.[/bold]")

    return descriptions


def _extract_descriptions(submissions: list[dict]) -> list[str]:
    """Pull job descriptions out of submit_hire_suggestion submissions."""
    descriptions: list[str] = []
    for sub in submissions:
        for suggestion in sub.get("data", {}).get("suggestions", []):
            desc = suggestion.get("description", "").strip()
            if desc:
                descriptions.append(desc)
    return descriptions
