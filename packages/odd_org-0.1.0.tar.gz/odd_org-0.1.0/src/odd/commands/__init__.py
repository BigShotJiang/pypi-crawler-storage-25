"""CLI command implementations - extracted from cli.py for readability."""
