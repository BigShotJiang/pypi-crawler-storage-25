"""Direct engine - runs agents via the Provider protocol."""

from odd.fallback.runner import DirectRunner

__all__ = ["DirectRunner"]
