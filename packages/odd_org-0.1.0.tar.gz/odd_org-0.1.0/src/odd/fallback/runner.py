"""DirectRunner - the original ODD agentic loop, extracted from AgentEngine.

Uses the Provider protocol to make direct API calls. Full control over the
loop, exact cost tracking. No compaction or session resume.
"""

from __future__ import annotations

import json
from collections import deque
from pathlib import Path
from typing import Any, Callable

from odd.config import (
    DEFAULT_MAX_TOKENS,
    MAX_AGENTIC_ITERATIONS,
    STUCK_DETECTION_THRESHOLD,
    STUCK_OUTPUT_THRESHOLD,
)
from odd.middleware import (
    CONTEXT_WRAP_UP_NOTICE,
    WRAP_UP_NOTICE,
    RunnerMiddleware,
)
from odd.models import Persona
from odd.provider import AgentResponse, Provider, StreamCallback, StreamEventType
from odd.tools import SUBMISSION_TOOL_NAMES
from odd.tracing import log_escalation


class BudgetExceededError(Exception):
    """Raised when a budget limit has been hit."""
    pass


class AgentStuckError(Exception):
    """Raised when an agent repeats the same tool call too many times."""
    pass


class MaxIterationsError(Exception):
    """Raised when the agentic loop exceeds the iteration cap."""
    pass


class AgentKilledError(Exception):
    """Raised when the agent's stream is cancelled (War Room kill)."""
    pass


__all__ = [
    "BudgetExceededError", "AgentStuckError", "MaxIterationsError",
    "AgentKilledError", "DirectRunner",
]


class DirectRunner:
    """Runs agents via the Provider protocol (direct API calls).

    This is the extracted agentic loop that was previously inside
    ``AgentEngine.invoke()``. It handles:

    - The tool-call loop (call model -> execute tools -> repeat)
    - Budget checking (delegates to CFO)
    - Stuck detection (signature + output hash)
    - Escalation preemption
    - Submission interception
    - Streaming
    - Context window guard (rough token estimate)
    """

    def __init__(
        self,
        provider: Provider,
        *,
        escalations: list[dict],
        submissions: list[dict],
        working_dir: Path | None = None,
    ):
        self.provider = provider
        self.escalations = escalations
        self.submissions = submissions
        self.working_dir = working_dir

    def invoke(
        self,
        persona: Persona,
        *,
        system: str,
        messages: list[dict[str, Any]],
        tool_defs: list[dict[str, Any]] | None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        model: str,
        stream: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        middleware: RunnerMiddleware,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> str:
        """Run the agentic loop for a single agent invocation.

        Args:
            persona: The agent's identity (used for tracing/logging).
            system: Fully-built system prompt.
            messages: Conversation messages (history + current user message).
            tool_defs: Tool definitions, or None if tools are disabled.
            max_tokens: Max response tokens per API call.
            model: Model ID string.
            stream: Optional streaming callback.
            cancel_check: Optional callable returning True to abort.
            middleware: Shared middleware for budget, cost, and logging.
            on_tool_result: Optional callback(tool_name, tool_input, result)
                invoked after each tool execution. Used by the War Room to
                surface activity highlights.

        Returns:
            The agent's text response.
        """
        full_response_text: list[str] = []
        iteration = 0
        prev_tool_signature: str | None = None
        repeat_count = 0
        recent_output_hashes: deque[int] = deque(maxlen=STUCK_OUTPUT_THRESHOLD)
        last_stop_reason = ""
        error_msg: str | None = None

        try:
            while True:
                iteration += 1

                if iteration > MAX_AGENTIC_ITERATIONS:
                    self._build_escalation(
                        reason=f"Agent exceeded {MAX_AGENTIC_ITERATIONS} iterations - possible infinite loop",
                        severity="blocker",
                    )
                    raise MaxIterationsError(
                        f"Agent loop exceeded {MAX_AGENTIC_ITERATIONS} iterations"
                    )

                if middleware.winding_down:
                    middleware.wind_down_remaining -= 1
                    if middleware.wind_down_remaining <= 0:
                        break

                # Budget checks (delegated to middleware)
                budget = middleware.check_budget()
                if budget.exceeded:
                    raise BudgetExceededError(budget.warning or "Budget exceeded")
                if budget.phase_exceeded:
                    messages.append({"role": "user", "content": WRAP_UP_NOTICE})

                # Context window guard (delegated to middleware)
                if middleware.check_context_window(model, system, messages):
                    messages.append({"role": "user", "content": CONTEXT_WRAP_UP_NOTICE})

                if stream:
                    response = self._stream_iteration(
                        model=model,
                        system=system,
                        messages=messages,
                        tools=tool_defs,
                        max_tokens=max_tokens,
                        callback=stream,
                    )
                else:
                    response = self.provider.create_message(
                        model=model,
                        system=system,
                        messages=messages,
                        tools=tool_defs,
                        max_tokens=max_tokens,
                    )

                # Record costs (delegated to middleware)
                if response.usage:
                    middleware.record_usage(
                        agent_name=persona.name,
                        model=model,
                        input_tokens=response.usage.input_tokens,
                        output_tokens=response.usage.output_tokens,
                    )

                last_stop_reason = response.stop_reason or ""

                full_response_text.extend(response.text_blocks)

                if response.stop_reason != "tool_use":
                    break

                results, blocker_raised = self._process_tool_calls(
                    persona, response, middleware=middleware,
                    on_tool_result=on_tool_result,
                )
                middleware.add_tool_calls(len(response.tool_calls))

                if cancel_check and cancel_check():
                    raise AgentKilledError(
                        f"Agent '{persona.name}' cancelled via War Room"
                    )

                prev_tool_signature, repeat_count = self._check_stuck_signature(
                    response, prev_tool_signature, repeat_count,
                )
                self._check_stuck_output(results, recent_output_hashes)

                assistant_msg, user_msg = self.provider.wrap_tool_results(
                    response.tool_calls, results,
                    text_blocks=response.text_blocks,
                )
                messages.append(assistant_msg)
                messages.append(user_msg)

                if blocker_raised:
                    break
        except (MaxIterationsError, AgentStuckError, BudgetExceededError, AgentKilledError) as exc:
            error_msg = str(exc)
            raise
        finally:
            middleware.log_invocation(
                agent_name=persona.name,
                role=persona.role_type.value,
                model=model,
                system_prompt_len=len(system),
                user_message=messages[0].get("content", "") if messages else "",
                iterations=iteration,
                stop_reason=last_stop_reason,
                error=error_msg,
            )

        return "\n".join(full_response_text)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_stuck_signature(
        self,
        response: Any,
        prev_signature: str | None,
        repeat_count: int,
    ) -> tuple[str, int]:
        """Detect agents repeating the exact same tool calls."""
        current_signature = json.dumps(
            [(tc.name, json.dumps(tc.input, sort_keys=True))
             for tc in response.tool_calls],
            sort_keys=True,
        )
        if current_signature == prev_signature:
            repeat_count += 1
        else:
            repeat_count = 1
            prev_signature = current_signature

        if repeat_count >= STUCK_DETECTION_THRESHOLD:
            self._build_escalation(
                reason="Agent stuck - repeating the same tool call",
                severity="blocker",
            )
            raise AgentStuckError(
                "Agent is stuck repeating the same tool call"
            )
        return prev_signature, repeat_count

    def _check_stuck_output(
        self,
        results: list[str],
        recent_output_hashes: deque[int],
    ) -> None:
        """Detect agents producing identical tool outputs."""
        recent_output_hashes.append(hash("\n".join(results)))
        if (
            len(recent_output_hashes) == STUCK_OUTPUT_THRESHOLD
            and len(set(recent_output_hashes)) == 1
        ):
            self._build_escalation(
                reason="Agent stuck - producing identical outputs",
                severity="blocker",
            )
            raise AgentStuckError(
                "Agent is stuck - producing identical outputs"
            )

    def _build_escalation(self, reason: str, severity: str) -> None:
        """Create and append an escalation dict."""
        self.escalations.append({
            "reason": reason,
            "severity": severity,
        })

    def _process_tool_calls(
        self,
        persona: Persona,
        response: Any,
        *,
        middleware: RunnerMiddleware,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> tuple[list[str], bool]:
        """Execute tool calls, enforcing escalation preemption."""
        _PREEMPT_TOOLS = {"escalate", "request_command"}
        escalation_raised = any(
            tc.name in _PREEMPT_TOOLS for tc in response.tool_calls
        )
        blocker_raised = any(
            (tc.name == "escalate" and tc.input.get("severity") == "blocker")
            or tc.name == "request_command"
            for tc in response.tool_calls
        )

        results: list[str] = []
        for tc in response.tool_calls:
            if tc.name == "escalate":
                severity = tc.input.get("severity", "heads_up")
                self.escalations.append({
                    "reason": tc.input.get("reason", ""),
                    "severity": severity,
                })
                log_escalation(
                    agent_name=persona.name,
                    reason=tc.input.get("reason", ""),
                    severity=severity,
                    sprint=middleware.current_sprint,
                )
                if severity == "blocker":
                    results.append(
                        "Escalation registered. STOP working on this task - "
                        "wait for CEO direction."
                    )
                elif severity == "needs_decision":
                    results.append(
                        "Escalation registered. Continue with your best "
                        "judgment for now, but the CEO will review."
                    )
                else:
                    results.append(
                        "Heads-up noted. The CEO will be informed. "
                        "Continue your work."
                    )
                if on_tool_result:
                    on_tool_result(tc.name, tc.input, results[-1])
                continue
            if tc.name == "request_command":
                self.escalations.append({
                    "reason": tc.input.get("reason", ""),
                    "severity": "command_request",
                    "command": tc.input.get("command", ""),
                })
                log_escalation(
                    agent_name=persona.name,
                    reason=tc.input.get("reason", ""),
                    severity="command_request",
                    sprint=middleware.current_sprint,
                )
                results.append(
                    "Command request registered. STOP working on this task - "
                    "wait for CEO approval."
                )
                if on_tool_result:
                    on_tool_result(tc.name, tc.input, results[-1])
                continue
            if tc.name in SUBMISSION_TOOL_NAMES:
                self.submissions.append({
                    "tool": tc.name,
                    "data": tc.input,
                })
                if tc.name == "submit_hire_suggestion":
                    count = len(tc.input.get("suggestions", []))
                    noun = "hire" if count == 1 else "hires"
                    results.append(
                        f"{count} {noun} submitted. The CEO will take it "
                        f"from here - Scout is already on the case. "
                        f"You're done with this step."
                    )
                else:
                    results.append("Submission accepted.")
                if on_tool_result:
                    on_tool_result(tc.name, tc.input, results[-1])
                continue
            if escalation_raised and tc.name not in _PREEMPT_TOOLS:
                results.append(
                    "Tool call skipped - escalation raised; other actions in "
                    "this batch are not executed."
                )
                continue
            result = self._execute_tool(tc.name, tc.input, agent_name=persona.name, sprint=middleware.current_sprint)
            results.append(result)
            if on_tool_result:
                on_tool_result(tc.name, tc.input, result)

        if len(results) != len(response.tool_calls):
            raise RuntimeError(
                f"Tool call/result count mismatch: "
                f"{len(response.tool_calls)} calls but {len(results)} results"
            )

        return results, blocker_raised

    def _stream_iteration(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        max_tokens: int,
        callback: StreamCallback,
    ) -> AgentResponse:
        """Run one streaming API call, forwarding events to callback."""
        response: AgentResponse | None = None
        for event in self.provider.stream_message(
            model=model,
            system=system,
            messages=messages,
            tools=tools,
            max_tokens=max_tokens,
        ):
            callback(event)
            if event.event_type == StreamEventType.MESSAGE_STOP:
                response = event.response

        if response is None:
            response = AgentResponse()
        return response

    def _execute_tool(self, tool_name: str, tool_input: dict[str, Any], *, agent_name: str, sprint: int | None = None) -> str:
        """Execute a tool call and return the result as a string."""
        from odd.tools import execute_tool

        return execute_tool(tool_name, tool_input, cwd=self.working_dir, agent_name=agent_name, sprint=sprint)
