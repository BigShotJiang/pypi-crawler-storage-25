"""CFO - Chief Financial Officer.

Not an LLM agent. A deterministic function that tracks every token
spent, calculates costs, enforces budgets, and presents financial
reports with the gravitas of a real CFO.
"""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from odd.config import (
    ACTIVITY_FILE,
    BUDGET_FILE,
    BUDGET_WARNING_THRESHOLD,
    DEFAULT_PHASE_ENVELOPES,
    FINANCIALS_DIR,
    LEDGER_FILE,
    WRAP_UP_THRESHOLD,
    load_pricing,
)

import logging

_logger = logging.getLogger("odd.cfo")


@dataclass
class TokenUsage:
    """A single API call's token usage."""

    agent_name: str
    model: str
    input_tokens: int
    output_tokens: int
    sprint: int | None
    timestamp: str
    input_cost: float = 0.0
    output_cost: float = 0.0
    phase: str | None = None

    @property
    def total_cost(self) -> float:
        return self.input_cost + self.output_cost

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> dict[str, Any]:
        d = {
            "agent_name": self.agent_name,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "input_cost": self.input_cost,
            "output_cost": self.output_cost,
            "sprint": self.sprint,
            "timestamp": self.timestamp,
        }
        if self.phase is not None:
            d["phase"] = self.phase
        return d


@dataclass
class SprintFinancials:
    """Financial summary for a single sprint."""

    sprint_number: int
    total_cost: float
    total_input_tokens: int
    total_output_tokens: int
    calls: int
    by_agent: dict[str, float] = field(default_factory=dict)
    by_model: dict[str, float] = field(default_factory=dict)


class CFO:
    """Tracks costs, enforces budgets, produces financial reports.

    Wraps around the AgentEngine - every API call's token usage flows
    through here.
    """

    def __init__(self, odd_dir: Path):
        self.odd_dir = odd_dir
        self._activity_path = odd_dir / "logs" / ACTIVITY_FILE
        self._legacy_ledger_path = odd_dir / FINANCIALS_DIR / LEDGER_FILE
        self.budget_path = odd_dir / FINANCIALS_DIR / BUDGET_FILE
        self._lock = threading.Lock()
        self._ensure_dirs()
        self._migrate_legacy_ledger()
        self._ledger: list[TokenUsage] = self._load_ledger()
        self._pricing = load_pricing(odd_dir)
        self._session_start = datetime.now(timezone.utc).isoformat()
        self._session_entries: list[TokenUsage] = []

    def _ensure_dirs(self) -> None:
        (self.odd_dir / FINANCIALS_DIR).mkdir(parents=True, exist_ok=True)
        (self.odd_dir / "logs").mkdir(parents=True, exist_ok=True)

    def _migrate_legacy_ledger(self) -> None:
        """Migrate legacy financials/ledger.json into logs/activity.jsonl.

        Tags each entry as ``type: "api_call"`` and appends to the unified
        file, then renames the old ledger to ledger.json.migrated.
        """
        migrated_marker = self._legacy_ledger_path.with_suffix(".json.migrated")
        if not self._legacy_ledger_path.exists() or migrated_marker.exists():
            return

        try:
            text = self._legacy_ledger_path.read_text(encoding="utf-8").strip()
            if not text:
                self._legacy_ledger_path.rename(migrated_marker)
                return

            # Parse legacy format (JSON array or JSONL)
            raw_entries: list[dict[str, Any]] = []
            if text.startswith("["):
                raw_entries = json.loads(text)
            else:
                for line in text.splitlines():
                    line = line.strip()
                    if line:
                        raw_entries.append(json.loads(line))

            # Write to unified activity log with type tag
            if raw_entries:
                with self._activity_path.open("a", encoding="utf-8") as f:
                    for entry in raw_entries:
                        # Map legacy field names to unified format
                        rec = {
                            "type": "api_call",
                            "ts": entry.get("timestamp", ""),
                            "agent": entry.get("agent_name", ""),
                            "model": entry.get("model", ""),
                            "input_tokens": entry.get("input_tokens", 0),
                            "output_tokens": entry.get("output_tokens", 0),
                            "input_cost": entry.get("input_cost", 0.0),
                            "output_cost": entry.get("output_cost", 0.0),
                        }
                        if entry.get("sprint") is not None:
                            rec["sprint"] = entry["sprint"]
                        if entry.get("phase") is not None:
                            rec["phase"] = entry["phase"]
                        f.write(json.dumps(rec) + "\n")

            self._legacy_ledger_path.rename(migrated_marker)
            _logger.info("Migrated %d ledger entries to activity.jsonl", len(raw_entries))
        except Exception:
            _logger.warning("Failed to migrate legacy ledger", exc_info=True)

    def _load_ledger(self) -> list[TokenUsage]:
        """Load cost records from the unified activity log.

        Reads ``type == "api_call"`` records and maps them to TokenUsage.
        """
        if not self._activity_path.exists():
            return []
        text = self._activity_path.read_text(encoding="utf-8").strip()
        if not text:
            return []
        entries: list[TokenUsage] = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("type") != "api_call":
                continue
            entries.append(TokenUsage(
                agent_name=rec.get("agent", ""),
                model=rec.get("model", ""),
                input_tokens=rec.get("input_tokens", 0),
                output_tokens=rec.get("output_tokens", 0),
                input_cost=rec.get("input_cost", 0.0),
                output_cost=rec.get("output_cost", 0.0),
                sprint=rec.get("sprint"),
                timestamp=rec.get("ts", ""),
                phase=rec.get("phase"),
            ))
        return entries

    def record(
        self,
        agent_name: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        sprint: int | None = None,
        phase: str | None = None,
    ) -> TokenUsage:
        """Record token usage from an API call. Thread-safe.

        Updates in-memory ledger only. The caller is responsible for
        persisting the record via ``tracing.log_agent_call()``, which
        writes the unified activity log that CFO reads on next startup.
        """
        pricing = self._pricing.get(model, {"input": 0.0, "output": 0.0})

        usage = TokenUsage(
            agent_name=agent_name,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            input_cost=(input_tokens / 1_000_000) * pricing["input"],
            output_cost=(output_tokens / 1_000_000) * pricing["output"],
            sprint=sprint,
            timestamp=datetime.now(timezone.utc).isoformat(),
            phase=phase,
        )

        with self._lock:
            self._ledger.append(usage)
            self._session_entries.append(usage)
        return usage

    # --- Budget ---

    def set_budget(
        self,
        sprint_budget: float | None = None,
        total_budget: float | None = None,
        session_budget: float | None = None,
        phase_envelopes: dict[str, float] | None = None,
    ) -> None:
        """Set spending limits."""
        budget = self._load_budget()
        if sprint_budget is not None:
            budget["sprint_budget"] = sprint_budget
        if total_budget is not None:
            budget["total_budget"] = total_budget
        if session_budget is not None:
            budget["session_budget"] = session_budget
        if phase_envelopes is not None:
            budget["phase_envelopes"] = phase_envelopes
        self.budget_path.write_text(json.dumps(budget, indent=2), encoding="utf-8")

    def _load_budget(self) -> dict[str, Any]:
        if not self.budget_path.exists():
            return {}
        return json.loads(self.budget_path.read_text(encoding="utf-8"))

    def check_budget(self, sprint: int | None = None) -> tuple[bool, str]:
        """Check if we're within budget. Returns (ok, message). Thread-safe.

        All hard stops are checked first - a warning must never mask an
        exceeded budget in a different tier. When ok is True, the message
        may still contain a warning if spend has crossed the warning
        threshold (default 80%).
        """
        budget = self._load_budget()
        threshold = budget.get("warning_threshold", BUDGET_WARNING_THRESHOLD)

        with self._lock:
            # --- Hard stops first (order: total → sprint → session) ---

            if "total_budget" in budget:
                total_spent = self._total_cost_unlocked()
                limit = budget["total_budget"]
                if total_spent >= limit:
                    return False, (
                        f"BUDGET EXCEEDED: Total spend ${total_spent:.4f} "
                        f"has hit the ${limit:.2f} limit."
                    )

            if sprint is not None and "sprint_budget" in budget:
                sprint_spent = self._sprint_cost_unlocked(sprint)
                limit = budget["sprint_budget"]
                if sprint_spent >= limit:
                    return False, (
                        f"SPRINT BUDGET EXCEEDED: Sprint {sprint} spend ${sprint_spent:.4f} "
                        f"has hit the ${limit:.2f} per-sprint limit."
                    )

            if "session_budget" in budget:
                session_spent = self._session_cost_unlocked()
                limit = budget["session_budget"]
                if session_spent >= limit:
                    return False, (
                        f"SESSION BUDGET EXCEEDED: This session's spend ${session_spent:.4f} "
                        f"has hit the ${limit:.2f} session limit."
                    )

            # --- Warnings (same order - return the first threshold breach) ---

            if "total_budget" in budget:
                total_spent = self._total_cost_unlocked()
                limit = budget["total_budget"]
                if total_spent >= limit * threshold:
                    return True, (
                        f"WARNING: Total spend ${total_spent:.4f} has reached "
                        f"{total_spent / limit * 100:.0f}% of the ${limit:.2f} limit."
                    )

            if sprint is not None and "sprint_budget" in budget:
                sprint_spent = self._sprint_cost_unlocked(sprint)
                limit = budget["sprint_budget"]
                if sprint_spent >= limit * threshold:
                    return True, (
                        f"WARNING: Sprint {sprint} spend ${sprint_spent:.4f} has reached "
                        f"{sprint_spent / limit * 100:.0f}% of the ${limit:.2f} per-sprint limit."
                    )

            if "session_budget" in budget:
                session_spent = self._session_cost_unlocked()
                limit = budget["session_budget"]
                if session_spent >= limit * threshold:
                    return True, (
                        f"WARNING: This session's spend ${session_spent:.4f} has reached "
                        f"{session_spent / limit * 100:.0f}% of the ${limit:.2f} session limit."
                    )

            return True, "Within budget."

    # --- Phase budget envelopes ---

    def _resolve_envelopes(self) -> dict[str, float]:
        """Return the effective phase envelope fractions (defaults + CEO overrides)."""
        envelopes = dict(DEFAULT_PHASE_ENVELOPES)
        budget = self._load_budget()
        overrides = budget.get("phase_envelopes", {})
        envelopes.update(overrides)
        return envelopes

    def _phase_cost_unlocked(self, sprint_number: int, phase: str) -> float:
        """Total cost for a specific phase within a sprint. Caller holds _lock."""
        return sum(
            u.total_cost for u in self._ledger
            if u.sprint == sprint_number and u.phase == phase
        )

    def phase_cost(self, sprint_number: int, phase: str) -> float:
        """Total cost for a specific phase within a sprint."""
        with self._lock:
            return self._phase_cost_unlocked(sprint_number, phase)

    def _overflow_pool_unlocked(self, sprint_number: int) -> float:
        """Unallocated + under-spent budget available as overflow.

        Overflow = sprint_budget * (1 - sum(envelopes)) + sum of under-spent envelopes.
        """
        budget = self._load_budget()
        sprint_budget = budget.get("sprint_budget", 0.0)
        if sprint_budget <= 0:
            return 0.0

        envelopes = self._resolve_envelopes()
        allocated_frac = sum(envelopes.values())
        # Unallocated remainder
        overflow = sprint_budget * max(0.0, 1.0 - allocated_frac)

        # Add under-spent portions from completed phases
        for phase_name, frac in envelopes.items():
            envelope_amount = sprint_budget * frac
            spent = self._phase_cost_unlocked(sprint_number, phase_name)
            if spent < envelope_amount:
                overflow += envelope_amount - spent

        return overflow

    def phase_spend_pct(self, sprint_number: int, phase: str) -> float:
        """Fraction of the phase envelope that has been spent (0.0 to 1.0+).

        Returns 0.0 if there's no sprint budget or the phase has no envelope.
        """
        budget = self._load_budget()
        sprint_budget = budget.get("sprint_budget", 0.0)
        if sprint_budget <= 0:
            return 0.0

        envelopes = self._resolve_envelopes()
        frac = envelopes.get(phase, 0.0)
        if frac <= 0:
            return 0.0

        envelope_amount = sprint_budget * frac
        with self._lock:
            spent = self._phase_cost_unlocked(sprint_number, phase)
        return spent / envelope_amount

    def check_phase_budget(
        self, sprint_number: int, phase: str,
    ) -> tuple[bool, str]:
        """Check spend against the phase envelope. Returns (ok, message).

        - ok=True, message="" -> within budget
        - ok=False, message="PHASE BUDGET:..." -> hit threshold (soft stop)

        The agent is NOT hard-killed; the caller should inject a wind-down signal.
        Overflow pool is considered before triggering soft stop.
        """
        budget = self._load_budget()
        sprint_budget = budget.get("sprint_budget", 0.0)
        if sprint_budget <= 0:
            return True, ""

        envelopes = self._resolve_envelopes()
        frac = envelopes.get(phase, 0.0)
        if frac <= 0:
            return True, ""

        envelope_amount = sprint_budget * frac

        with self._lock:
            spent = self._phase_cost_unlocked(sprint_number, phase)

            if spent >= envelope_amount * WRAP_UP_THRESHOLD:
                # Check overflow pool before triggering soft stop
                overflow = self._overflow_pool_unlocked(sprint_number)
                # Overflow calc includes this phase's own under-spend, which is
                # zero or negative here, so subtract our over-spend from overflow
                overspend = spent - envelope_amount
                effective_overflow = overflow - max(0.0, overspend)
                if effective_overflow <= 0:
                    return False, (
                        f"PHASE BUDGET: {phase} phase has used "
                        f"${spent:.4f} of ${envelope_amount:.2f} envelope "
                        f"({spent / envelope_amount * 100:.0f}%). "
                        f"Wrap up immediately."
                    )

        return True, ""

    def cost_by_phase(self, sprint_number: int) -> dict[str, float]:
        """Cost per phase for a given sprint."""
        with self._lock:
            by_phase: dict[str, float] = {}
            for u in self._ledger:
                if u.sprint == sprint_number and u.phase:
                    by_phase[u.phase] = by_phase.get(u.phase, 0) + u.total_cost
            return by_phase

    # --- Queries ---
    # Public methods acquire _lock. Internal _*_unlocked helpers assume the
    # caller already holds _lock (used by check_budget and other locked paths).

    def _session_cost_unlocked(self) -> float:
        return sum(u.total_cost for u in self._session_entries)

    def session_cost(self) -> float:
        """Total cost incurred in this session (since CFO was instantiated)."""
        with self._lock:
            return self._session_cost_unlocked()

    def session_tokens(self) -> tuple[int, int]:
        """Total tokens used in this session."""
        with self._lock:
            input_t = sum(u.input_tokens for u in self._session_entries)
            output_t = sum(u.output_tokens for u in self._session_entries)
            return input_t, output_t

    def session_cost_by_agent(self) -> dict[str, float]:
        """Cost per agent in the current session."""
        with self._lock:
            by_agent: dict[str, float] = {}
            for u in self._session_entries:
                by_agent[u.agent_name] = by_agent.get(u.agent_name, 0) + u.total_cost
            return by_agent

    def has_session_activity(self) -> bool:
        """Whether any API calls have been recorded this session."""
        with self._lock:
            return bool(self._session_entries)

    def all_sprints(self) -> list[int]:
        """Return sorted list of all sprint numbers with recorded costs."""
        with self._lock:
            return sorted({u.sprint for u in self._ledger if u.sprint is not None})

    def _total_cost_unlocked(self) -> float:
        return sum(u.total_cost for u in self._ledger)

    def total_cost(self) -> float:
        with self._lock:
            return self._total_cost_unlocked()

    def total_tokens(self) -> tuple[int, int]:
        with self._lock:
            input_t = sum(u.input_tokens for u in self._ledger)
            output_t = sum(u.output_tokens for u in self._ledger)
            return input_t, output_t

    def _sprint_cost_unlocked(self, sprint_number: int) -> float:
        return sum(u.total_cost for u in self._ledger if u.sprint == sprint_number)

    def sprint_cost(self, sprint_number: int) -> float:
        with self._lock:
            return self._sprint_cost_unlocked(sprint_number)

    def sprint_financials(self, sprint_number: int) -> SprintFinancials:
        with self._lock:
            entries = [u for u in self._ledger if u.sprint == sprint_number]

            by_agent: dict[str, float] = {}
            by_model: dict[str, float] = {}
            for u in entries:
                by_agent[u.agent_name] = by_agent.get(u.agent_name, 0) + u.total_cost
                by_model[u.model] = by_model.get(u.model, 0) + u.total_cost

            return SprintFinancials(
                sprint_number=sprint_number,
                total_cost=sum(u.total_cost for u in entries),
                total_input_tokens=sum(u.input_tokens for u in entries),
                total_output_tokens=sum(u.output_tokens for u in entries),
                calls=len(entries),
                by_agent=by_agent,
                by_model=by_model,
            )

    def cost_per_sprint_average(self) -> float:
        with self._lock:
            sprints = {u.sprint for u in self._ledger if u.sprint is not None}
            if not sprints:
                return 0.0
            total = self._total_cost_unlocked()
            return total / len(sprints)

    def vacation_feasibility(self, budget: float) -> dict[str, Any]:
        """Bundle financial metrics for vacation planning.

        Returns a dict that can be injected into Cody's prompt so he can
        give a financially-grounded scope assessment.
        """
        avg_cost = self.cost_per_sprint_average()
        sprints = self.all_sprints()
        total_spend = self.total_cost()
        historical_costs = [self.sprint_cost(s) for s in sprints]

        estimated_affordable = int(budget / avg_cost) if avg_cost > 0 else 0

        return {
            "avg_cost_per_sprint": round(avg_cost, 4),
            "sprints_completed": len(sprints),
            "total_project_spend": round(total_spend, 4),
            "vacation_budget": budget,
            "estimated_sprints_affordable": estimated_affordable,
            "historical_sprint_costs": [round(c, 4) for c in historical_costs],
        }

    def cost_by_agent(self) -> dict[str, float]:
        with self._lock:
            by_agent: dict[str, float] = {}
            for u in self._ledger:
                by_agent[u.agent_name] = by_agent.get(u.agent_name, 0) + u.total_cost
            return by_agent

    def cost_by_model(self) -> dict[str, float]:
        with self._lock:
            by_model: dict[str, float] = {}
            for u in self._ledger:
                by_model[u.model] = by_model.get(u.model, 0) + u.total_cost
            return by_model

    # --- Reports ---

    def financial_report(self) -> str:
        """Produce a full financial report - the CFO's presentation."""
        input_t, output_t = self.total_tokens()
        total = self.total_cost()
        budget = self._load_budget()

        lines = [
            "# Financial Report",
            "",
            f"**Total Spend:** ${total:.4f}",
            f"**Total Tokens:** {input_t + output_t:,} ({input_t:,} in / {output_t:,} out)",
            f"**API Calls:** {len(self._ledger)}",
        ]

        if "total_budget" in budget:
            remaining = budget["total_budget"] - total
            lines.append(f"**Budget Remaining:** ${remaining:.4f} of ${budget['total_budget']:.2f}")

        if "sprint_budget" in budget:
            lines.append(f"**Per-Sprint Budget:** ${budget['sprint_budget']:.2f}")

        if "session_budget" in budget:
            session_spent = self.session_cost()
            remaining = budget["session_budget"] - session_spent
            lines.append(
                f"**Session Budget Remaining:** ${remaining:.4f} of ${budget['session_budget']:.2f}"
            )

        # Per-sprint breakdown
        sprints = sorted({u.sprint for u in self._ledger if u.sprint is not None})
        if sprints:
            lines.extend(["", "## Cost by Sprint"])
            for s in sprints:
                cost = self.sprint_cost(s)
                lines.append(f"  Sprint {s}: ${cost:.4f}")
            lines.append(f"  **Average:** ${self.cost_per_sprint_average():.4f}/sprint")

        # Per-agent breakdown
        by_agent = self.cost_by_agent()
        if by_agent:
            lines.extend(["", "## Cost by Agent"])
            for agent, cost in sorted(by_agent.items(), key=lambda x: -x[1]):
                pct = (cost / total * 100) if total > 0 else 0
                lines.append(f"  {agent}: ${cost:.4f} ({pct:.1f}%)")

        # Per-model breakdown
        by_model = self.cost_by_model()
        if by_model:
            lines.extend(["", "## Cost by Model"])
            for model, cost in sorted(by_model.items(), key=lambda x: -x[1]):
                pct = (cost / total * 100) if total > 0 else 0
                lines.append(f"  {model}: ${cost:.4f} ({pct:.1f}%)")

        return "\n".join(lines)

    def cost_footer(self) -> str:
        """One-line cost summary for the current session - shown after commands."""
        if not self._session_entries:
            return ""
        cost = self.session_cost()
        input_t, output_t = self.session_tokens()
        calls = len(self._session_entries)
        return (
            f"💰 This command: ${cost:.4f} | "
            f"{input_t + output_t:,} tokens | "
            f"{calls} API call{'s' if calls != 1 else ''}"
        )

    def sprint_report(self, sprint_number: int) -> str:
        """Financial summary for a single sprint."""
        fin = self.sprint_financials(sprint_number)
        budget = self._load_budget()

        lines = [
            f"# Sprint {sprint_number} - Financial Summary",
            "",
            f"**Cost:** ${fin.total_cost:.4f}",
            f"**Tokens:** {fin.total_input_tokens + fin.total_output_tokens:,} "
            f"({fin.total_input_tokens:,} in / {fin.total_output_tokens:,} out)",
            f"**API Calls:** {fin.calls}",
        ]

        if "sprint_budget" in budget:
            remaining = budget["sprint_budget"] - fin.total_cost
            lines.append(f"**Budget Remaining:** ${remaining:.4f} of ${budget['sprint_budget']:.2f}")

        if fin.by_agent:
            lines.extend(["", "### By Agent"])
            for agent, cost in sorted(fin.by_agent.items(), key=lambda x: -x[1]):
                lines.append(f"  {agent}: ${cost:.4f}")

        # Per-phase breakdown
        by_phase = self.cost_by_phase(sprint_number)
        if by_phase:
            envelopes = self._resolve_envelopes()
            sprint_budget_val = budget.get("sprint_budget", 0.0)
            lines.extend(["", "### By Phase"])
            for phase_name, cost in sorted(by_phase.items(), key=lambda x: -x[1]):
                envelope_frac = envelopes.get(phase_name, 0.0)
                if sprint_budget_val > 0 and envelope_frac > 0:
                    envelope_amt = sprint_budget_val * envelope_frac
                    pct = cost / envelope_amt * 100
                    lines.append(
                        f"  {phase_name}: ${cost:.4f} of ${envelope_amt:.2f} ({pct:.0f}%)"
                    )
                else:
                    lines.append(f"  {phase_name}: ${cost:.4f}")

        return "\n".join(lines)
