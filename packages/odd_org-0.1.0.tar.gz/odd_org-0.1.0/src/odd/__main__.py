"""Allow running as python -m odd."""

import random
import sys

from rich.console import Console


def _run() -> None:
    from odd.cli import CLOSING_REMARKS, main

    try:
        main()
    except KeyboardInterrupt:
        console = Console()
        console.print(f"\n[bold yellow]{random.choice(CLOSING_REMARKS)}[/bold yellow]")
        sys.exit(0)


_run()
