"""Provider protocol - the abstraction boundary between ODD and LLM APIs.

Everything above this (sprint engine, personas, tools, TDD flow) is
provider-agnostic. Everything below (Anthropic SDK, OpenAI HTTP) implements
this interface.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterator, Protocol, runtime_checkable


@dataclass
class ToolCall:
    """A single tool invocation from the model."""

    name: str
    input: dict[str, Any]
    id: str


@dataclass
class Usage:
    """Token counts for a single API call."""

    input_tokens: int
    output_tokens: int


@dataclass
class AgentResponse:
    """Normalized response from any provider."""

    text_blocks: list[str] = field(default_factory=list)
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = "end_turn"  # "tool_use" | "end_turn"
    usage: Usage | None = None


# ---------------------------------------------------------------------------
# Streaming events - emitted by Provider.stream_message()
# ---------------------------------------------------------------------------


class StreamEventType(Enum):
    """Types of events emitted during streaming."""

    TEXT_DELTA = "text_delta"          # Incremental text chunk
    TOOL_USE_START = "tool_use_start"  # Tool call begins (name + id known)
    TOOL_INPUT_DELTA = "tool_input_delta"  # Incremental JSON for tool input
    TOOL_USE_END = "tool_use_end"      # Tool call input is complete
    MESSAGE_STOP = "message_stop"      # Stream finished - final usage available


@dataclass
class StreamEvent:
    """A single event from a streaming response.

    Fields are populated based on event_type:
    - TEXT_DELTA: text is set
    - TOOL_USE_START: tool_name, tool_id are set
    - TOOL_INPUT_DELTA: text is set (partial JSON)
    - TOOL_USE_END: tool_call is set (fully parsed)
    - MESSAGE_STOP: response is set (complete AgentResponse)
    """

    event_type: StreamEventType
    text: str = ""
    tool_name: str = ""
    tool_id: str = ""
    tool_call: ToolCall | None = None
    response: AgentResponse | None = None


# Type alias for the streaming callback the CEO (or sprint engine) provides.
# Called with each StreamEvent as it arrives.  Return value is ignored.
StreamCallback = Callable[[StreamEvent], None]


@runtime_checkable
class Provider(Protocol):
    """Interface that any LLM provider must implement."""

    def create_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> AgentResponse:
        """Send a message and return a normalized response.

        Args:
            model: Raw model ID string (e.g. "claude-opus-4-6").
            system: System prompt.
            messages: Conversation history in provider-neutral format.
            tools: Tool definitions in neutral format (name, description, parameters).
            max_tokens: Maximum response tokens.
        """
        ...

    def stream_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> Iterator[StreamEvent]:
        """Stream a message, yielding events as they arrive.

        The final event is always MESSAGE_STOP with a complete AgentResponse
        in event.response.  Callers can ignore the stream and just consume
        the final response if they only want the result.

        Providers that don't support streaming should fall back to
        create_message() wrapped in a single MESSAGE_STOP event.
        """
        ...

    def wrap_tool_results(
        self,
        tool_calls: list[ToolCall],
        results: list[str],
        text_blocks: list[str] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Build the assistant + user messages for continuing after tool use.

        Args:
            tool_calls: The tool invocations from the model's response.
            results: Execution results, one per tool call.
            text_blocks: Any text the model produced alongside the tool calls.
                         Must be included in the assistant message so the model
                         doesn't "forget" what it said.

        Returns (assistant_message, user_message_with_tool_results).
        """
        ...
