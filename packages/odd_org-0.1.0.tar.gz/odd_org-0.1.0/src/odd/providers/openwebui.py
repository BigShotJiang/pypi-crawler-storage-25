"""Open WebUI provider - connects to a local Open WebUI instance.

Open WebUI exposes an OpenAI-compatible chat completions API, so this is
a thin configuration layer on top of OpenAICompatProvider with sensible
defaults for local usage.

Requires the same ``requests`` dependency: pip install odd-org[openai-compat]
"""

from __future__ import annotations

from odd.providers.openai_compat import OpenAICompatProvider


# Open WebUI model names depend on what the user has loaded. These are
# reasonable defaults for common setups - users should override via config.
OPENWEBUI_MODEL_MAP: dict[str, str] = {
    "high": "llama3.1:70b",
    "standard": "llama3.1:8b",
    "fast": "llama3.1:8b",
}

OPENWEBUI_DEFAULT_BASE_URL = "http://localhost:3000/api"


class OpenWebUIProvider(OpenAICompatProvider):
    """Provider for Open WebUI instances.

    Inherits all behavior from OpenAICompatProvider. The only differences
    are the default base_url and model_map, which target a local Open WebUI
    installation.
    """

    def __init__(
        self,
        *,
        api_key: str = "",
        base_url: str = OPENWEBUI_DEFAULT_BASE_URL,
        model_map: dict[str, str] | None = None,
    ):
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            model_map=model_map or dict(OPENWEBUI_MODEL_MAP),
        )

    def __repr__(self) -> str:
        return f"OpenWebUIProvider(base_url={self.base_url!r})"
