"""Anthropic provider - the default, best-tested path.

Wraps the Anthropic Python SDK behind the Provider protocol.
"""

from __future__ import annotations

import json
import sys
import time
from typing import Any, Iterator

import anthropic

from odd.config import API_MAX_RETRIES, API_RETRY_BASE_DELAY
from odd.provider import (
    AgentResponse,
    StreamEvent,
    StreamEventType,
    ToolCall,
    Usage,
)


# ModelTier.value → Anthropic model ID
ANTHROPIC_MODEL_MAP: dict[str, str] = {
    "high": "claude-opus-4-6",
    "standard": "claude-sonnet-4-6",
    "fast": "claude-haiku-4-5-20251001",
}
# Providers resolve tier strings to concrete model IDs via this map.
# agent.py passes ModelTier.value; the .get(model, model) fallthrough
# in create_message/stream_message allows raw model IDs too.


def _wrap_tools_anthropic(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert neutral tool defs (parameters) to Anthropic format (input_schema)."""
    return [
        {
            "name": t["name"],
            "description": t["description"],
            "input_schema": t["parameters"],
        }
        for t in tools
    ]


class AnthropicProvider:
    """Provider implementation using the Anthropic SDK."""

    def __init__(self, api_key: str | None = None):
        self._api_key = api_key or ""
        self.client = anthropic.Anthropic(api_key=api_key)

    def create_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> AgentResponse:
        # Resolve tier string to model ID, pass through raw IDs
        resolved_model = ANTHROPIC_MODEL_MAP.get(model, model)

        kwargs: dict[str, Any] = {
            "model": resolved_model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }

        if tools:
            kwargs["tools"] = _wrap_tools_anthropic(tools)

        response = self._call_with_retry(**kwargs)

        # Parse into normalized response
        text_blocks = []
        tool_calls = []
        for block in response.content:
            if block.type == "text":
                text_blocks.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCall(name=block.name, input=block.input, id=block.id)
                )

        usage = None
        if response.usage:
            usage = Usage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )

        return AgentResponse(
            text_blocks=text_blocks,
            tool_calls=tool_calls,
            stop_reason=response.stop_reason,
            usage=usage,
        )

    def stream_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> Iterator[StreamEvent]:
        """Stream a response from the Anthropic API, yielding StreamEvents.

        Uses the SDK's streaming context manager.  The final yielded event
        is always MESSAGE_STOP with a fully-assembled AgentResponse.

        Retry is handled by obtaining the stream with retry *before*
        yielding any events, so callers never see partial output from
        a failed attempt.
        """
        resolved_model = ANTHROPIC_MODEL_MAP.get(model, model)

        kwargs: dict[str, Any] = {
            "model": resolved_model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = _wrap_tools_anthropic(tools)

        # Obtain the stream with retry - no events are yielded until we
        # have a successful connection, so the caller never sees partial
        # output from a failed attempt.
        stream_cm = self._stream_with_retry(**kwargs)

        # Accumulators for building the final AgentResponse
        text_blocks: list[str] = []
        current_block_type: str = ""  # "text" or "tool_use"
        current_text = ""
        tool_calls: list[ToolCall] = []
        current_tool_name = ""
        current_tool_id = ""
        current_tool_json = ""
        stop_reason = "end_turn"
        usage: Usage | None = None

        with stream_cm as stream:
            for event in stream:
                etype = getattr(event, "type", "")

                if etype == "content_block_start":
                    block = event.content_block
                    current_block_type = block.type
                    if block.type == "text":
                        current_text = ""
                    elif block.type == "tool_use":
                        current_tool_name = block.name
                        current_tool_id = block.id
                        current_tool_json = ""
                        yield StreamEvent(
                            event_type=StreamEventType.TOOL_USE_START,
                            tool_name=block.name,
                            tool_id=block.id,
                        )

                elif etype == "content_block_delta":
                    delta = event.delta
                    if delta.type == "text_delta":
                        current_text += delta.text
                        yield StreamEvent(
                            event_type=StreamEventType.TEXT_DELTA,
                            text=delta.text,
                        )
                    elif delta.type == "input_json_delta":
                        current_tool_json += delta.partial_json
                        yield StreamEvent(
                            event_type=StreamEventType.TOOL_INPUT_DELTA,
                            text=delta.partial_json,
                        )

                elif etype == "content_block_stop":
                    if current_block_type == "text":
                        text_blocks.append(current_text)
                        current_text = ""
                    elif current_block_type == "tool_use":
                        tool_input = json.loads(current_tool_json) if current_tool_json else {}
                        tc = ToolCall(
                            name=current_tool_name,
                            input=tool_input,
                            id=current_tool_id,
                        )
                        tool_calls.append(tc)
                        yield StreamEvent(
                            event_type=StreamEventType.TOOL_USE_END,
                            tool_call=tc,
                        )
                        current_tool_name = ""
                        current_tool_id = ""
                        current_tool_json = ""
                    current_block_type = ""

                elif etype == "message_stop":
                    pass  # Usage comes from the final message

            # Get final message from stream for usage + stop_reason
            final = stream.get_final_message()
            stop_reason = final.stop_reason or "end_turn"
            if final.usage:
                usage = Usage(
                    input_tokens=final.usage.input_tokens,
                    output_tokens=final.usage.output_tokens,
                )

        # Build complete response and yield the terminal event
        response = AgentResponse(
            text_blocks=text_blocks,
            tool_calls=tool_calls,
            stop_reason=stop_reason,
            usage=usage,
        )
        yield StreamEvent(
            event_type=StreamEventType.MESSAGE_STOP,
            response=response,
        )

    def wrap_tool_results(
        self,
        tool_calls: list[ToolCall],
        results: list[str],
        text_blocks: list[str] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Build Anthropic-format assistant + user messages for tool result continuation."""
        # Reconstruct the assistant content blocks as Anthropic expects them.
        # Include text blocks so the model doesn't "forget" what it said
        # alongside the tool calls.
        assistant_content: list[dict[str, Any]] = []
        if text_blocks:
            for text in text_blocks:
                assistant_content.append({"type": "text", "text": text})
        for tc in tool_calls:
            assistant_content.append(
                {"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.input}
            )

        user_content = [
            {"type": "tool_result", "tool_use_id": tc.id, "content": result}
            for tc, result in zip(tool_calls, results)
        ]

        return (
            {"role": "assistant", "content": assistant_content},
            {"role": "user", "content": user_content},
        )

    def _scrub_key(self, error: BaseException) -> BaseException:
        """Replace API key value in error messages to prevent leakage."""
        key = getattr(self, "_api_key", "")
        if key and len(key) > 3:
            scrubbed = str(error).replace(key, "**********")
            if scrubbed != str(error):
                return type(error)(scrubbed)
        return error

    def _call_with_retry(self, **kwargs: Any) -> Any:
        """Call the API with exponential backoff for transient errors."""
        for attempt in range(API_MAX_RETRIES + 1):
            try:
                return self.client.messages.create(**kwargs)
            except (
                anthropic.APIConnectionError,
                anthropic.RateLimitError,
                anthropic.InternalServerError,
            ):
                if attempt >= API_MAX_RETRIES:
                    raise self._scrub_key(
                        sys.exc_info()[1]  # type: ignore[arg-type]
                    ) from None
                delay = API_RETRY_BASE_DELAY * (2**attempt)
                time.sleep(delay)
            except anthropic.APIError as e:
                raise self._scrub_key(e) from None

    def _stream_with_retry(self, **kwargs: Any) -> Any:
        """Open a streaming context manager with exponential backoff.

        Returns the context manager (not yet entered) so the caller
        can yield from it without mixing retry logic into the generator.
        Connection errors during the *opening* handshake are retried;
        errors that occur mid-stream after events have been yielded
        propagate to the caller since partial output is unrecoverable.
        """
        for attempt in range(API_MAX_RETRIES + 1):
            try:
                # .stream() returns a context manager; entering it
                # performs the HTTP handshake, so we enter + re-wrap
                # to validate the connection before returning.
                return self.client.messages.stream(**kwargs)
            except (
                anthropic.APIConnectionError,
                anthropic.RateLimitError,
                anthropic.InternalServerError,
            ):
                if attempt >= API_MAX_RETRIES:
                    raise self._scrub_key(
                        sys.exc_info()[1]  # type: ignore[arg-type]
                    ) from None
                delay = API_RETRY_BASE_DELAY * (2 ** attempt)
                time.sleep(delay)
            except anthropic.APIError as e:
                raise self._scrub_key(e) from None
