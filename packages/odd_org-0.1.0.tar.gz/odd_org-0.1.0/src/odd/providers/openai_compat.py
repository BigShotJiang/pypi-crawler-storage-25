"""OpenAI-compatible provider - raw HTTP, no SDK dependency.

Talks to any API that implements the OpenAI chat completions interface:
OpenAI, Azure OpenAI, Ollama, LM Studio, vLLM, etc.

Uses `requests` for HTTP. Install with: pip install odd-org[openai-compat]
"""

from __future__ import annotations

import json
import time
from typing import Any, Iterator

import requests

from odd.config import API_MAX_RETRIES, API_RETRY_BASE_DELAY
from odd.provider import AgentResponse, StreamEvent, StreamEventType, ToolCall, Usage


# Model tier → sensible defaults for OpenAI models
# Users will typically override these via config.
OPENAI_MODEL_MAP: dict[str, str] = {
    "high": "gpt-4o",
    "standard": "gpt-4o-mini",
    "fast": "gpt-4o-mini",
}


def _wrap_tools_openai(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert neutral tool defs to OpenAI function-calling format."""
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["parameters"],
            },
        }
        for t in tools
    ]


class OpenAICompatProvider:
    """Provider implementation for OpenAI-compatible APIs via raw HTTP."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        model_map: dict[str, str] | None = None,
    ):
        self._api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model_map = model_map or dict(OPENAI_MODEL_MAP)

    @property
    def api_key(self) -> str:
        return self._api_key

    def __repr__(self) -> str:
        return f"OpenAICompatProvider(base_url={self.base_url!r}, api_key='**********')"

    def create_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> AgentResponse:
        # Resolve tier string to model ID, pass through raw IDs
        resolved_model = self.model_map.get(model, model)

        # Build the messages array - system goes as a message, not a top-level param
        api_messages: list[dict[str, Any]] = [
            {"role": "system", "content": system},
        ]
        # Flatten any packed tool_results sentinels from wrap_tool_results()
        for msg in messages:
            if msg.get("role") == "tool_results":
                api_messages.extend(msg["_tool_messages"])
            else:
                api_messages.append(msg)

        payload: dict[str, Any] = {
            "model": resolved_model,
            "messages": api_messages,
            "max_tokens": max_tokens,
        }

        if tools:
            payload["tools"] = _wrap_tools_openai(tools)

        data = self._call_with_retry(payload)

        # Parse into normalized response
        choice = data["choices"][0]
        message = choice["message"]

        text_blocks: list[str] = []
        if message.get("content"):
            text_blocks.append(message["content"])

        tool_calls: list[ToolCall] = []
        for tc in message.get("tool_calls", []):
            func = tc["function"]
            try:
                args = json.loads(func["arguments"])
            except json.JSONDecodeError:
                args = {"_raw": func["arguments"], "_parse_error": True}
            tool_calls.append(
                ToolCall(
                    name=func["name"],
                    input=args,
                    id=tc["id"],
                )
            )

        # Normalize stop reason: "tool_calls" → "tool_use", "stop" → "end_turn"
        finish_reason = choice.get("finish_reason", "stop")
        if finish_reason == "tool_calls":
            stop_reason = "tool_use"
        else:
            stop_reason = "end_turn"

        usage = None
        if data.get("usage"):
            u = data["usage"]
            usage = Usage(
                input_tokens=u.get("prompt_tokens", 0),
                output_tokens=u.get("completion_tokens", 0),
            )

        return AgentResponse(
            text_blocks=text_blocks,
            tool_calls=tool_calls,
            stop_reason=stop_reason,
            usage=usage,
        )

    def stream_message(
        self,
        *,
        model: str,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 16384,
    ) -> Iterator[StreamEvent]:
        """Stream a response from an OpenAI-compatible API using SSE.

        Falls back to batch create_message if the streaming request fails.
        """
        resolved_model = self.model_map.get(model, model)

        api_messages: list[dict[str, Any]] = [
            {"role": "system", "content": system},
        ]
        for msg in messages:
            if msg.get("role") == "tool_results":
                api_messages.extend(msg["_tool_messages"])
            else:
                api_messages.append(msg)

        payload: dict[str, Any] = {
            "model": resolved_model,
            "messages": api_messages,
            "max_tokens": max_tokens,
            "stream": True,
        }
        if tools:
            payload["tools"] = _wrap_tools_openai(tools)

        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=120, stream=True)
            resp.raise_for_status()
        except (requests.RequestException, requests.HTTPError):
            # Fall back to batch mode if streaming fails
            response = self.create_message(
                model=model, system=system, messages=messages,
                tools=tools, max_tokens=max_tokens,
            )
            for text in response.text_blocks:
                yield StreamEvent(event_type=StreamEventType.TEXT_DELTA, text=text)
            yield StreamEvent(event_type=StreamEventType.MESSAGE_STOP, response=response)
            return

        # Parse SSE events
        text_blocks: list[str] = []
        current_text = ""
        tool_calls_acc: dict[int, dict[str, Any]] = {}  # index → {id, name, arguments}
        finish_reason = "stop"
        prompt_tokens = 0
        completion_tokens = 0

        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                break
            try:
                chunk = json.loads(data_str)
            except json.JSONDecodeError:
                continue

            choice = chunk.get("choices", [{}])[0]
            delta = choice.get("delta", {})
            fr = choice.get("finish_reason")
            if fr:
                finish_reason = fr

            # Text content
            if delta.get("content"):
                current_text += delta["content"]
                yield StreamEvent(event_type=StreamEventType.TEXT_DELTA, text=delta["content"])

            # Tool calls (streamed incrementally)
            for tc_delta in delta.get("tool_calls", []):
                idx = tc_delta.get("index", 0)
                if idx not in tool_calls_acc:
                    tool_calls_acc[idx] = {
                        "id": tc_delta.get("id", ""),
                        "name": tc_delta.get("function", {}).get("name", ""),
                        "arguments": "",
                    }
                    if tool_calls_acc[idx]["name"]:
                        yield StreamEvent(
                            event_type=StreamEventType.TOOL_USE_START,
                            tool_name=tool_calls_acc[idx]["name"],
                            tool_id=tool_calls_acc[idx]["id"],
                        )
                func_delta = tc_delta.get("function", {})
                if func_delta.get("arguments"):
                    tool_calls_acc[idx]["arguments"] += func_delta["arguments"]
                    yield StreamEvent(
                        event_type=StreamEventType.TOOL_INPUT_DELTA,
                        text=func_delta["arguments"],
                    )

            # Usage (often in the final chunk)
            if chunk.get("usage"):
                prompt_tokens = chunk["usage"].get("prompt_tokens", 0)
                completion_tokens = chunk["usage"].get("completion_tokens", 0)

        # Finalize text
        if current_text:
            text_blocks.append(current_text)

        # Finalize tool calls
        parsed_tool_calls: list[ToolCall] = []
        for idx in sorted(tool_calls_acc):
            tc_data = tool_calls_acc[idx]
            try:
                args = json.loads(tc_data["arguments"]) if tc_data["arguments"] else {}
            except json.JSONDecodeError:
                args = {"_raw": tc_data["arguments"], "_parse_error": True}
            tc = ToolCall(name=tc_data["name"], input=args, id=tc_data["id"])
            parsed_tool_calls.append(tc)
            yield StreamEvent(event_type=StreamEventType.TOOL_USE_END, tool_call=tc)

        stop_reason = "tool_use" if finish_reason == "tool_calls" else "end_turn"
        usage = Usage(input_tokens=prompt_tokens, output_tokens=completion_tokens) if (prompt_tokens or completion_tokens) else None

        response = AgentResponse(
            text_blocks=text_blocks,
            tool_calls=parsed_tool_calls,
            stop_reason=stop_reason,
            usage=usage,
        )
        yield StreamEvent(event_type=StreamEventType.MESSAGE_STOP, response=response)

    def wrap_tool_results(
        self,
        tool_calls: list[ToolCall],
        results: list[str],
        text_blocks: list[str] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Build OpenAI-format assistant + user messages for tool result continuation.

        OpenAI expects:
        1. An assistant message with `tool_calls` array
        2. One `tool` message per tool call result (not wrapped in a user message)

        But the Provider protocol returns (assistant_msg, user_msg), so we pack
        all tool results into a single user-role message with content blocks.
        Actually, OpenAI uses role="tool" messages - we pack them as a list of
        content parts in a single user message to match the protocol's return type.

        Note: The agent engine appends both messages to the conversation. For
        OpenAI, the "user_msg" here actually contains tool-role messages that
        we embed as structured content.
        """
        # Assistant message with tool_calls metadata
        assistant_content: list[dict[str, Any]] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {
                    "name": tc.name,
                    "arguments": json.dumps(tc.input),
                },
            }
            for tc in tool_calls
        ]

        # For OpenAI, tool results are separate messages with role="tool".
        # We pack them into the user message slot as a list - the engine
        # appends this as-is, and OpenAI will see the tool role messages.
        # But since the protocol expects exactly 2 dicts, we use a trick:
        # return the tool result messages packed into a single structure.
        tool_result_messages = [
            {
                "role": "tool",
                "tool_call_id": tc.id,
                "content": result,
            }
            for tc, result in zip(tool_calls, results)
        ]

        # Include any text the model produced alongside tool calls
        content = "\n".join(text_blocks) if text_blocks else None

        return (
            {
                "role": "assistant",
                "content": content,
                "tool_calls": assistant_content,
            },
            # Pack multiple tool messages as the "user" slot.
            # The engine appends this as a single message - for OpenAI we need
            # to handle this in create_message by flattening packed tool messages.
            {
                "role": "tool_results",  # sentinel role - flattened before sending
                "_tool_messages": tool_result_messages,
            },
        )

    def _call_with_retry(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST to the chat completions endpoint with exponential backoff."""
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        for attempt in range(API_MAX_RETRIES + 1):
            try:
                resp = requests.post(
                    url,
                    headers=headers,
                    json=payload,
                    timeout=120,
                )
                resp.raise_for_status()
                return resp.json()
            except (requests.ConnectionError, requests.Timeout) as e:
                if attempt >= API_MAX_RETRIES:
                    raise ConnectionError(
                        f"Failed to connect to {self.base_url} after "
                        f"{API_MAX_RETRIES + 1} attempts"
                    ) from e
                delay = API_RETRY_BASE_DELAY * (2 ** attempt)
                time.sleep(delay)
            except requests.HTTPError as e:
                status = e.response.status_code if e.response is not None else 0
                # Retry on rate limit and server errors
                if status in (429, 500, 502, 503) and attempt < API_MAX_RETRIES:
                    delay = API_RETRY_BASE_DELAY * (2 ** attempt)
                    time.sleep(delay)
                    continue
                # Scrub API key from error output before re-raising
                err_str = str(e)
                if self._api_key and len(self._api_key) > 3:
                    err_str = err_str.replace(self._api_key, "**********")
                raise type(e)(err_str) from None

        # Should never reach here, but satisfy the type checker
        raise ConnectionError(f"Failed to connect to {self.base_url}")
