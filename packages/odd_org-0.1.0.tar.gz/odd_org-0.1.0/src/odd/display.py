"""War Room display - live multi-agent monitoring and CEO interaction.

Components:
- AgentOutputStream: thread-safe ring buffer capturing agent output
- WarRoom: Rich Live grid showing all active agents
- OfficeVisit: full-stream focus view with CEO input injection
"""

from __future__ import annotations

import threading
from collections import deque
from enum import Enum
from typing import Any, Callable

from rich.console import Console, ConsoleOptions, Group, RenderableType, RenderResult
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from odd.provider import StreamCallback, StreamEvent, StreamEventType, ToolCall


# ---------------------------------------------------------------------------
# Tool call formatting for War Room display
# ---------------------------------------------------------------------------


def format_tool_summary(tool_call: ToolCall) -> str:
    """Format a tool call as a compact one-liner for CEO display.

    Handles both SDK-style names (Read, Write) and ODD native names
    (read_file, write_file) so the War Room shows useful context
    regardless of which provider/engine is running.

    Examples:
        ↳ Read src/odd/sprint.py
        ↳ Write src/odd/cli.py (245 chars)
        ↳ Edit src/odd/agent.py
        ↳ Bash pytest tests/ -x
        ↳ Search "pattern" in *.py
        ↳ Escalate [blocker] reason text
    """
    name = tool_call.name
    args = tool_call.input

    # --- SDK-style names (Claude Code / MCP) ---
    if name in ("Read", "Write", "Edit", "Glob", "Grep"):
        key_arg = args.get("file_path") or args.get("path") or args.get("pattern", "")
        return f"↳ {name} {key_arg}\n"
    if name == "Bash":
        cmd = args.get("command", "")
        if len(cmd) > 60:
            cmd = cmd[:57] + "..."
        return f"↳ Bash {cmd}\n"

    # --- ODD native tool names ---
    if name == "read_file":
        return f"↳ Read {args.get('path', '?')}\n"
    if name == "write_file":
        path = args.get("path", "?")
        size = len(args.get("content", ""))
        return f"↳ Write {path} ({size} chars)\n"
    if name == "edit_file":
        return f"↳ Edit {args.get('path', '?')}\n"
    if name == "list_directory":
        return f"↳ List {args.get('path', '.')}\n"
    if name == "run_command":
        cmd = args.get("command", "")
        if len(cmd) > 60:
            cmd = cmd[:57] + "..."
        return f"↳ Bash {cmd}\n"
    if name == "escalate":
        severity = args.get("severity", "heads_up")
        reason = args.get("reason", "")
        if len(reason) > 50:
            reason = reason[:47] + "..."
        return f"↳ Escalate [{severity}] {reason}\n"

    # MCP tools or anything else - just show the name
    # Strip mcp__odd__ prefix for readability
    display_name = name.replace("mcp__odd__", "")
    return f"↳ {display_name}\n"


def format_tool_result_line(tool_name: str, tool_input: dict, result: str) -> str:
    """Format an executed tool result as a compact War Room activity line.

    Called after tool execution (not from streaming events) to show the
    CEO what actually happened on disk. Keeps it to one short line.

    Examples:
        ✓ Write src/tests/test_new.py (312 chars)
        ✓ Edit src/odd/cli.py
        ✓ Read src/odd/sprint.py
        ✗ Write ../../evil.txt - blocked
        ✓ Bash pytest tests/ -x (exit 0)
    """
    ok = not result.startswith("Error")
    icon = "✓" if ok else "✗"

    if tool_name == "write_file":
        path = tool_input.get("path", "?")
        size = len(tool_input.get("content", ""))
        suffix = f" ({size} chars)" if ok else f" - {_short_error(result)}"
        return f"{icon} Write {path}{suffix}"
    if tool_name == "read_file":
        path = tool_input.get("path", "?")
        suffix = "" if ok else f" - {_short_error(result)}"
        return f"{icon} Read {path}{suffix}"
    if tool_name == "edit_file":
        path = tool_input.get("path", "?")
        suffix = "" if ok else f" - {_short_error(result)}"
        return f"{icon} Edit {path}{suffix}"
    if tool_name == "list_directory":
        path = tool_input.get("path", ".")
        return f"{icon} List {path}"
    if tool_name == "run_command":
        cmd = tool_input.get("command", "")
        if len(cmd) > 50:
            cmd = cmd[:47] + "..."
        fail = " (FAILED)" if not ok else ""
        return f"{icon} Bash {cmd}{fail}"
    if tool_name == "escalate":
        severity = tool_input.get("severity", "heads_up")
        reason = tool_input.get("reason", "")
        if len(reason) > 40:
            reason = reason[:37] + "..."
        return f"⚠ Escalate [{severity}] {reason}"

    # Fallback for submissions or unknown tools
    display_name = tool_name.replace("mcp__odd__", "")
    return f"{icon} {display_name}"


def _short_error(result: str) -> str:
    """Extract a short error reason from a tool result string."""
    # "Error: Path escapes project root: ../../evil.txt" → "blocked"
    r = result.removeprefix("Error: ")
    if "escapes project root" in r:
        return "blocked"
    if "PermissionError" in r or "not allowed" in r.lower():
        return "blocked"
    if len(r) > 40:
        r = r[:37] + "..."
    return r


# ---------------------------------------------------------------------------
# AgentOutputStream - per-agent output capture (6a)
# ---------------------------------------------------------------------------


class AgentStatus(str, Enum):
    IDLE = "idle"
    WORKING = "working"
    WAITING = "waiting"
    DONE = "done"
    KILLED = "killed"


# Status → display indicator
_STATUS_DOTS: dict[AgentStatus, str] = {
    AgentStatus.WORKING: "[bold green]\u25cf[/]",   # ● working
    AgentStatus.WAITING: "[yellow]\u25cb[/]",        # ○ waiting
    AgentStatus.IDLE: "[dim]\u25cc[/]",              # ◌ idle
    AgentStatus.DONE: "[green]\u2713[/]",            # ✓ done
    AgentStatus.KILLED: "[red]\u2717[/]",            # ✗ killed
}


class AgentOutputStream:
    """Thread-safe ring buffer for capturing an agent's streaming output.

    The ring buffer keeps the last *capacity* lines for the summary view.
    The full log is always available for the Office Visit (focus) view.
    """

    def __init__(self, agent_name: str, capacity: int = 50):
        self.agent_name = agent_name
        self.capacity = capacity
        self._lock = threading.Lock()
        self._ring: deque[str] = deque(maxlen=capacity)
        self._full_log: list[str] = []
        self._status = AgentStatus.IDLE
        self._cancelled = False
        self._partial_line: str = ""  # accumulates until newline

    @property
    def status(self) -> AgentStatus:
        with self._lock:
            return self._status

    @status.setter
    def status(self, value: AgentStatus) -> None:
        with self._lock:
            self._status = value

    @property
    def cancelled(self) -> bool:
        with self._lock:
            return self._cancelled

    def cancel(self) -> None:
        """Request cooperative cancellation."""
        with self._lock:
            self._cancelled = True
            self._status = AgentStatus.KILLED

    def append(self, text: str) -> None:
        """Append streaming text, splitting on newlines into ring buffer lines."""
        with self._lock:
            self._partial_line += text
            while "\n" in self._partial_line:
                line, self._partial_line = self._partial_line.split("\n", 1)
                self._ring.append(line)
                self._full_log.append(line)

    def flush(self) -> None:
        """Flush any partial line into the buffer."""
        with self._lock:
            if self._partial_line:
                self._ring.append(self._partial_line)
                self._full_log.append(self._partial_line)
                self._partial_line = ""

    def tail(self, n: int = 3) -> list[str]:
        """Return the last *n* lines from the ring buffer."""
        with self._lock:
            items = list(self._ring)
            return items[-n:] if len(items) >= n else items

    def full(self) -> list[str]:
        """Return the complete log for focus view."""
        with self._lock:
            return list(self._full_log)

    @property
    def status_dot(self) -> str:
        """Rich-formatted status indicator."""
        return _STATUS_DOTS.get(self.status, "?")

    def as_stream_callback(self) -> StreamCallback:
        """Return a StreamCallback that feeds events into this buffer.

        Usage with agent.invoke():
            stream = AgentOutputStream("Lead Dev")
            engine.invoke(persona, msg, stream=stream.as_stream_callback())

        Handles TEXT_DELTA for thinking/text and TOOL_USE_END for tool
        call summaries (e.g. '↳ Write src/app.py (245 chars)').
        In SDK mode the on_tool_result callback never fires because the
        SDK executes tools internally, so we show tool summaries inline
        from the streaming events instead.
        """

        def _callback(event: StreamEvent) -> None:
            if event.event_type == StreamEventType.TEXT_DELTA:
                self.append(event.text)
            elif event.event_type == StreamEventType.TOOL_USE_END:
                # Flush any partial thinking text, then show the tool summary
                self.flush()
                if event.tool_call:
                    self.append(format_tool_summary(event.tool_call))
            elif event.event_type == StreamEventType.MESSAGE_STOP:
                self.flush()

        return _callback


# ---------------------------------------------------------------------------
# War Room view (6b)
# ---------------------------------------------------------------------------


def _agent_panel(stream: AgentOutputStream, width: int | None = None) -> Panel:
    """Build a Rich Panel for one agent in the War Room grid."""
    lines = stream.tail(3)
    body = Text("\n".join(lines) if lines else "(no output yet)", style="dim")
    title = f"{stream.status_dot} {stream.agent_name}"
    return Panel(
        body,
        title=title,
        title_align="left",
        width=width,
        border_style="green" if stream.status == AgentStatus.WORKING else "dim",
    )


def _collapsed_summary(streams: list[AgentOutputStream]) -> Panel:
    """One-line summary row for done/idle agents."""
    parts = []
    for s in streams:
        parts.append(f"{s.status_dot} {s.agent_name}")
    text = Text("  ".join(parts))
    return Panel(text, title="completed / idle", title_align="left", border_style="dim")


def _build_war_room_layout(streams: list[AgentOutputStream]) -> Group:
    """Build the full War Room renderable from active streams.

    Active agents (working/waiting) get full panels in a grid.
    Done/idle/killed agents collapse into a summary row.
    """
    active = [s for s in streams if s.status in (AgentStatus.WORKING, AgentStatus.WAITING)]
    inactive = [s for s in streams if s.status not in (AgentStatus.WORKING, AgentStatus.WAITING)]

    renderables: list[Any] = []

    if active:
        # Auto-layout: 2 cols for <=6 agents, 3 for 7+
        cols = 3 if len(active) > 6 else 2
        rows: list[list[AgentOutputStream]] = []
        for i in range(0, len(active), cols):
            rows.append(active[i:i + cols])

        for row in rows:
            if len(row) == 1:
                renderables.append(_agent_panel(row[0]))
            else:
                layout = Layout()
                children = []
                for j, s in enumerate(row):
                    child = Layout(name=f"agent_{j}", ratio=1)
                    child.update(_agent_panel(s))
                    children.append(child)
                layout.split_row(*children)
                renderables.append(layout)

    if inactive:
        renderables.append(_collapsed_summary(inactive))

    if not renderables:
        renderables.append(Panel("[dim]No agents active[/dim]", border_style="dim"))

    return Group(*renderables)


class _LiveWarRoomRenderable:
    """Renderable that rebuilds the War Room layout on every Rich refresh.

    Rich's ``Live`` re-renders its renderable each tick, but a static
    ``Group`` built once at start-up would show a frozen snapshot.  By
    implementing ``__rich_console__``, we ensure each tick rebuilds the
    layout from current stream state - picking up new agent output.
    """

    def __init__(self, streams: list[AgentOutputStream]) -> None:
        self.streams = streams

    def __rich_console__(
        self, console: Console, options: ConsoleOptions,
    ) -> RenderResult:
        yield _build_war_room_layout(self.streams)


class WarRoom:
    """Live multi-agent monitoring display.

    Usage:
        war_room = WarRoom(streams)
        war_room.start()
        # ... agents run, streams fill ...
        war_room.stop()

    Keyboard handling (Enter/k/K/q) is wired in Phase 7 when
    integrated with the sprint engine's input loop.
    """

    def __init__(
        self,
        streams: list[AgentOutputStream],
        console: Console | None = None,
        refresh_rate: int = 4,
    ):
        self.streams = streams
        self.console = console or Console()
        self.refresh_rate = refresh_rate
        self._live: Live | None = None
        self._focused: AgentOutputStream | None = None

    def start(self) -> None:
        """Start the Live display."""
        self._live = Live(
            _LiveWarRoomRenderable(self.streams),
            console=self.console,
            refresh_per_second=self.refresh_rate,
            transient=True,
        )
        self._live.start()

    def stop(self) -> None:
        """Stop the Live display."""
        if self._live:
            self._live.stop()
            self._live = None

    def refresh(self) -> None:
        """Force a refresh of the display."""
        if self._live:
            self._live.update(_build_war_room_layout(self.streams))

    def focus(self, stream: AgentOutputStream) -> None:
        """Switch to Office Visit (focus) view for one agent."""
        self._focused = stream

    def unfocus(self) -> None:
        """Return from Office Visit to War Room grid."""
        self._focused = None

    def kill(self, stream: AgentOutputStream) -> None:
        """Request cancellation for one agent."""
        stream.cancel()
        self.refresh()

    def kill_all(self) -> None:
        """Request cancellation for all active agents."""
        for s in self.streams:
            if s.status in (AgentStatus.WORKING, AgentStatus.WAITING):
                s.cancel()
        self.refresh()

    @property
    def is_running(self) -> bool:
        return self._live is not None

    def __enter__(self) -> WarRoom:
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()


# ---------------------------------------------------------------------------
# Office Visit view (6c)
# ---------------------------------------------------------------------------


class OfficeVisit:
    """Full streaming output for a focused agent, with CEO input injection.

    The Office Visit shows the complete log for one agent and allows
    the CEO to inject messages via an input line. Injected messages
    are formatted as ``[CEO interrupt] <message>`` and passed to
    the provided callback.

    Rendering and input are handled by the sprint engine in Phase 7.
    This class provides the data model and message injection API.
    """

    def __init__(
        self,
        stream: AgentOutputStream,
        on_ceo_message: Callable[[str], None] | None = None,
    ):
        self.stream = stream
        self._on_ceo_message = on_ceo_message
        self._ceo_messages: list[str] = []

    def inject(self, message: str) -> None:
        """Inject a CEO message into the agent's context.

        The message is stored and the callback (if any) is invoked
        so the sprint engine can append it to the agent's conversation.
        """
        formatted = f"[CEO interrupt] {message}"
        self._ceo_messages.append(formatted)
        self.stream.append(f"\n>>> {formatted}\n")
        if self._on_ceo_message:
            self._on_ceo_message(formatted)

    @property
    def ceo_messages(self) -> list[str]:
        """All CEO messages injected during this visit."""
        return list(self._ceo_messages)

    def render_log(self) -> Panel:
        """Render the full agent log as a Rich Panel."""
        lines = self.stream.full()
        body = Text("\n".join(lines) if lines else "(no output yet)")
        return Panel(
            body,
            title=f"Office Visit: {self.stream.agent_name}  [dim](Esc to return)[/dim]",
            title_align="left",
            border_style="cyan",
        )
