"""ODD - Organization Driven Development."""

__version__ = "0.1.0"
