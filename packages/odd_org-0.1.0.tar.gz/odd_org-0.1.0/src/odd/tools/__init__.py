"""Tools that agents can use to interact with the filesystem and shell.

Split into submodules:
- definitions: Core tool definitions (read_file, write_file, etc.)
- schemas: Submission tool schemas (submit_sprint_plan, etc.)
- execution: Tool execution engine + file/shell handlers
"""

from odd.tools.definitions import EXPLORE_TOOLS, TOOL_DEFINITIONS, WRITE_NOTES_TOOL
from odd.tools.schemas import (
    SUBMISSION_TOOL_NAMES,
    SUBMIT_CANDIDATE,
    SUBMIT_CODE_REVIEW,
    SUBMIT_CONSULTANT_SPECS,
    SUBMIT_DEPENDENCY_REQUEST,
    SUBMIT_HIRE_SUGGESTION,
    SUBMIT_PHASE_PLAN,
    SUBMIT_ROADMAP,
    SUBMIT_SPRINT_PLAN,
    SUBMIT_TEST_CHANGE_REQUEST,
    SUBMIT_TEST_REVIEW_DECISION,
    SUBMIT_TESTER_SPECS,
)
from odd.tools.execution import execute_tool
from odd.tools.isolation import ALLOWED_COMMANDS

__all__ = [
    # Definitions
    "EXPLORE_TOOLS",
    "TOOL_DEFINITIONS",
    "WRITE_NOTES_TOOL",
    # Schemas
    "SUBMISSION_TOOL_NAMES",
    "SUBMIT_CANDIDATE",
    "SUBMIT_CODE_REVIEW",
    "SUBMIT_CONSULTANT_SPECS",
    "SUBMIT_DEPENDENCY_REQUEST",
    "SUBMIT_HIRE_SUGGESTION",
    "SUBMIT_PHASE_PLAN",
    "SUBMIT_ROADMAP",
    "SUBMIT_SPRINT_PLAN",
    "SUBMIT_TEST_CHANGE_REQUEST",
    "SUBMIT_TEST_REVIEW_DECISION",
    "SUBMIT_TESTER_SPECS",
    # Execution
    "ALLOWED_COMMANDS",
    "execute_tool",
]
