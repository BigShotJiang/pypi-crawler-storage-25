"""Tool execution engine - file ops, shell commands, escalation handling."""

from __future__ import annotations

import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from odd.config import SHELL_COMMAND_TIMEOUT
from odd.tools.isolation import (
    ALLOWED_COMMANDS,
    BLOCKED_COMMANDS,
    GIT_BLOCKED_GLOBAL_FLAGS,
    GIT_BLOCKED_SUBCOMMANDS,
    GIT_WRITE_SUBCOMMANDS,
    check_command_hidden_odd_dirs as _check_command_hidden_odd_dirs_policy,
    check_command_team_access as _check_command_team_access_policy,
    check_command_test_write as _check_command_test_write_policy,
    check_read_access,
    check_test_file_write as _check_test_file_write_policy,
    check_team_path_access as _check_team_path_access_policy,
    check_write_access,
)


def _audit_log(agent: str, tool: str, tool_input: dict[str, Any], result: str, duration_ms: int, exit_code: int | None = None, sprint: int | None = None) -> None:
    """Log a tool invocation to the unified activity log."""
    from odd.tracing import log_tool_use

    log_tool_use(
        agent=agent,
        tool=tool,
        tool_input=tool_input,
        result=result,
        duration_ms=duration_ms,
        exit_code=exit_code,
        sprint=sprint,
    )


# ── Policy wrappers ────────────────────────────────────────────────────
# DirectRunner uses PermissionError exceptions. These thin wrappers
# convert the policy's string-or-None return into raise-or-return.


def _check_team_path_access(path: str, agent_name: str) -> None:
    reason = _check_team_path_access_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_test_file_write(path: str, agent_name: str) -> None:
    reason = _check_test_file_write_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_read_access(path: str, agent_name: str) -> None:
    reason = check_read_access(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_write_access(path: str, agent_name: str) -> None:
    reason = check_write_access(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_team_access(command: str, agent_name: str) -> None:
    reason = _check_command_team_access_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_test_write(command: str, agent_name: str) -> None:
    reason = _check_command_test_write_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_hidden_odd_dirs(command: str, agent_name: str) -> None:
    reason = _check_command_hidden_odd_dirs_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


# Git subcommands where file arguments appear directly in argv.
_GIT_EXPLICIT_FILE_SUBCMDS = {"rm", "mv", "checkout", "restore"}


def _get_git_affected_files(argv: list[str], base: Path) -> list[str] | None:
    """Ask git which files a worktree-modifying command would touch.

    Returns a list of file paths, or **None** if we could not determine the
    affected files (git command failed, ref not found, etc.).  Callers must
    treat None as "unknown - fail closed".
    """
    subcmd = argv[1]

    # For 'git apply': use --stat to list affected files.
    # Also check for symlink creation in the patch (mode 120000).
    if subcmd == "apply":
        # First, reject patches that create symlinks - these bypass our
        # path validation since git would create the symlink directly.
        try:
            check_argv = list(argv) + ["--stat", "--summary"]
            summary_result = subprocess.run(
                check_argv, capture_output=True, text=True,
                timeout=10, cwd=base,
            )
            if summary_result.returncode != 0:
                return None  # couldn't determine
            # --summary shows mode changes; reject any symlink mode (120000)
            for line in summary_result.stdout.splitlines():
                if "120000" in line or "symlink" in line.lower():
                    raise PermissionError(
                        "git apply: patch creates symlinks - blocked to prevent "
                        "path traversal attacks"
                    )
            # --stat output: " path/to/file | 3 +++"
            return [
                line.split("|")[0].strip()
                for line in summary_result.stdout.splitlines()
                if "|" in line and line.strip()
            ]
        except PermissionError:
            raise  # re-raise our own symlink block
        except Exception:
            return None

    # For 'git stash': determine affected files based on the sub-subcommand.
    # Read-only operations (list, show) don't modify the worktree.
    # Write operations (pop, apply, drop, push) need file-level checks.
    if subcmd == "stash":
        # Parse the stash sub-subcommand (e.g. pop, apply, show, list, push)
        stash_subcmd = None
        stash_ref = None
        for arg in argv[2:]:
            if not arg.startswith("-"):
                if stash_subcmd is None:
                    stash_subcmd = arg
                else:
                    stash_ref = arg
                    break
        # Bare 'git stash' is equivalent to 'git stash push'
        if stash_subcmd is None:
            stash_subcmd = "push"
        # Read-only stash operations don't modify files
        if stash_subcmd in ("list", "show"):
            return []
        # drop doesn't modify the worktree
        if stash_subcmd == "drop":
            return []
        # For pop/apply, check the specific stash entry's files
        if stash_subcmd in ("pop", "apply"):
            show_cmd = ["git", "stash", "show", "--name-only"]
            if stash_ref:
                show_cmd.append(stash_ref)
            try:
                result = subprocess.run(
                    show_cmd,
                    capture_output=True, text=True, timeout=10, cwd=base,
                )
                if result.returncode != 0:
                    return None
                return [l.strip() for l in result.stdout.splitlines() if l.strip()]
            except Exception:
                return None
        # For push/create and anything else, check dirty files that would be stashed
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only"],
                capture_output=True, text=True, timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For 'git cherry-pick', 'git revert', 'git merge': diff against HEAD
    if subcmd in ("cherry-pick", "revert", "merge"):
        # Extract the ref (skip flags)
        ref = None
        for arg in argv[2:]:
            if not arg.startswith("-"):
                ref = arg
                break
        if not ref:
            return None  # can't determine without a ref
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD", ref],
                capture_output=True, text=True, timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For 'git reset': diff against the target
    if subcmd == "reset":
        ref = "HEAD"
        for arg in argv[2:]:
            if not arg.startswith("-"):
                ref = arg
                break
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD", ref],
                capture_output=True, text=True, timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For commands with explicit file arguments (checkout, restore, rm, mv):
    # extract non-flag arguments after '--' or all non-flag args after subcmd
    files = []
    past_separator = False
    for arg in argv[2:]:
        if arg == "--":
            past_separator = True
            continue
        if past_separator or not arg.startswith("-"):
            files.append(arg)
    return files



def _extract_git_subcmd(argv: list[str]) -> tuple[str | None, int]:
    """Find the real git subcommand, skipping global flags.

    Returns (subcommand, index) or (None, -1) if no subcommand found.
    Also blocks dangerous global flags like -c.
    """
    i = 1
    while i < len(argv):
        arg = argv[i]
        # Check for blocked global flags
        if arg in GIT_BLOCKED_GLOBAL_FLAGS or any(
            arg.startswith(f"{flag}=") or arg.startswith(f"{flag} ")
            for flag in GIT_BLOCKED_GLOBAL_FLAGS
        ):
            raise PermissionError(
                f"git {arg.split('=')[0]} is not allowed for agents - "
                f"it can be used to execute arbitrary commands via config hooks"
            )
        # Skip known global flags that take a value
        if arg in ("-C", "--git-dir", "--work-tree", "--namespace"):
            i += 2  # skip the flag and its argument
            continue
        # Skip global boolean flags
        if arg.startswith("-") and not arg.startswith("--"):
            # Single-char flags like -p, -P; but -c is caught above
            i += 1
            continue
        if arg.startswith("--"):
            # Long flags like --bare, --no-pager
            i += 1
            continue
        # First non-flag argument is the subcommand
        return arg, i
    return None, -1


def _check_git_command(argv: list[str], agent_name: str, base: Path) -> None:
    """For git commands that modify the worktree, check affected files.

    Uses git's own tools (--stat, diff --name-only) to determine which
    files would be touched, then runs the standard access checks on each.
    Fails closed: if we cannot determine which files are affected, the
    command is blocked rather than allowed unchecked.
    """
    if len(argv) < 2:
        return

    # Extract the real subcommand, blocking dangerous global flags (e.g. -c)
    subcmd, _subcmd_idx = _extract_git_subcmd(argv)
    if subcmd is None:
        return

    # Block dangerous subcommands outright - agents should never use these.
    if subcmd in GIT_BLOCKED_SUBCOMMANDS:
        raise PermissionError(
            f"git {subcmd} is not allowed for agents"
        )

    if subcmd not in GIT_WRITE_SUBCOMMANDS:
        return

    # For 'git add': check the explicit file args for test-file / team access.
    # Broad adds (-A, --all, .) are resolved via git itself so that file-level
    # policy is always enforced - there is no "downstream" check to fall back on.
    if subcmd == "add":
        files = []
        past_separator = False
        is_broad = False
        for arg in argv[2:]:
            if arg == "--":
                past_separator = True
                continue
            if arg in ("-A", "--all", "."):
                is_broad = True
                continue
            if past_separator or not arg.startswith("-"):
                files.append(arg)
        if is_broad:
            # Enumerate what git *would* stage and check each file.
            try:
                result = subprocess.run(
                    ["git", "add", "--dry-run", "-A"],
                    capture_output=True, text=True, timeout=10, cwd=base,
                )
                if result.returncode == 0:
                    # dry-run output: "add 'path/to/file'" per line
                    for line in result.stdout.splitlines():
                        line = line.strip()
                        if line.startswith("add '") and line.endswith("'"):
                            files.append(line[5:-1])
                        elif line.startswith("remove '") and line.endswith("'"):
                            files.append(line[8:-1])
                else:
                    raise PermissionError(
                        "Cannot determine which files 'git add -A' would stage - "
                        "command blocked (fail-closed)."
                    )
            except subprocess.TimeoutExpired:
                raise PermissionError(
                    "Cannot determine which files 'git add -A' would stage - "
                    "command blocked (fail-closed)."
                )
        for path in files:
            _check_team_path_access(path, agent_name)
            _check_test_file_write(path, agent_name)
        return

    # For 'git commit': inspect staged files AND any files that auto-staging
    # flags (-a/--all/--include) would pull in.  Without this, an agent can
    # bypass the index check by committing with -a to auto-stage dirty files.
    if subcmd == "commit":
        # Detect auto-staging flags - must handle combined short flags like
        # -am (which is -a -m combined).  Check if 'a' appears in any short
        # flag cluster, or if --all/--include are present.
        has_auto_stage = any(
            arg == "--all"
            or arg.startswith("--include")
            or (arg.startswith("-") and not arg.startswith("--") and "a" in arg[1:])
            for arg in argv[2:]
        )
        try:
            # Always check the current index
            result = subprocess.run(
                ["git", "diff", "--cached", "--name-only"],
                capture_output=True, text=True, timeout=10, cwd=base,
            )
            if result.returncode != 0:
                raise PermissionError(
                    "Cannot determine staged files for 'git commit' - "
                    "command blocked (fail-closed)."
                )
            staged = [l.strip() for l in result.stdout.splitlines() if l.strip()]

            # If -a/--all, also check modified tracked files (what -a would stage)
            if has_auto_stage:
                dirty_result = subprocess.run(
                    ["git", "diff", "--name-only"],
                    capture_output=True, text=True, timeout=10, cwd=base,
                )
                if dirty_result.returncode != 0:
                    raise PermissionError(
                        "Cannot determine dirty files for 'git commit -a' - "
                        "command blocked (fail-closed)."
                    )
                dirty = [l.strip() for l in dirty_result.stdout.splitlines() if l.strip()]
                staged.extend(dirty)
        except subprocess.TimeoutExpired:
            raise PermissionError(
                "Cannot determine staged files for 'git commit' - "
                "command blocked (fail-closed)."
            )
        for path in staged:
            _check_team_path_access(path, agent_name)
            _check_test_file_write(path, agent_name)
        return

    affected = _get_git_affected_files(argv, base)
    if affected is None:
        raise PermissionError(
            f"Cannot determine which files 'git {subcmd}' would modify - "
            f"command blocked (fail-closed). Verify the ref/arguments are valid."
        )
    for path in affected:
        _check_team_path_access(path, agent_name)
        _check_test_file_write(path, agent_name)


def execute_tool(
    tool_name: str,
    tool_input: dict[str, Any],
    cwd: Path | None = None,
    agent_name: str = "unknown",
    sprint: int | None = None,
) -> str:
    """Execute a tool and return the result string.

    If cwd is provided, file and command tools operate relative to that
    directory instead of the process cwd (used for worktree isolation).
    """
    base = cwd or Path.cwd()
    start = time.monotonic()
    exit_code = None
    try:
        match tool_name:
            case "read_file":
                _check_read_access(tool_input["path"], agent_name)
                result = _read_file(tool_input["path"], base)
            case "write_file":
                _check_write_access(tool_input["path"], agent_name)
                result = _write_file(tool_input["path"], tool_input["content"], base)
            case "edit_file":
                _check_write_access(tool_input["path"], agent_name)
                result = _edit_file(
                    tool_input["path"],
                    tool_input["old_string"],
                    tool_input["new_string"],
                    base,
                )
            case "list_directory":
                path = tool_input.get("path", ".")
                _check_read_access(path, agent_name)
                result = _list_directory(path, base)
            case "run_command":
                cmd_argv = _split_command(tool_input["command"])
                if cmd_argv and Path(cmd_argv[0]).stem.lower() == "git":
                    # Git commands: use structural file-level checks
                    _check_git_command(cmd_argv, agent_name, base)
                # Always run regex-based checks as a fallback layer
                _check_command_team_access(tool_input["command"], agent_name)
                _check_command_test_write(tool_input["command"], agent_name)
                _check_command_hidden_odd_dirs(tool_input["command"], agent_name)
                result = _run_command(tool_input["command"], base)
            case "escalate":
                result = _escalate(tool_input["reason"], tool_input.get("severity", "needs_decision"))
            case "request_command":
                result = (
                    "Command request registered. STOP working on this task - "
                    "wait for CEO approval."
                )
            case _:
                result = f"Error: Unknown tool '{tool_name}'"
        duration_ms = int((time.monotonic() - start) * 1000)
        # Detect exit code from run_command results
        if tool_name == "run_command" and "(command failed)" in result:
            exit_code = 1
        elif tool_name == "run_command":
            exit_code = 0
        _audit_log(agent_name, tool_name, tool_input, result, duration_ms, exit_code, sprint=sprint)
        return result
    except Exception as e:
        duration_ms = int((time.monotonic() - start) * 1000)
        _audit_log(agent_name, tool_name, tool_input, str(e), duration_ms, exit_code=-1, sprint=sprint)
        return f"Error: {e}"


def _validate_path(path: str, base: Path) -> Path:
    """Resolve path and ensure it doesn't escape the project root."""
    p = Path(path)
    if p.is_absolute():
        resolved = p.resolve()
    else:
        resolved = (base / path).resolve()
    if not resolved.is_relative_to(base.resolve()):
        raise PermissionError(f"Path escapes project root: {path}")
    return resolved


def _validate_path_no_symlinks(path: str, base: Path) -> Path:
    """Resolve path, ensure it stays in the project root, and reject symlinks.

    Walks the *unresolved* path components (using lstat via Path.is_symlink)
    so that symlinks are detected before they are followed.  The previous
    implementation checked the *resolved* path - which never contains
    symlinks because .resolve() already followed them.

    Note: There is a narrow TOCTOU gap between this check and the actual
    file I/O.  A concurrent thread could replace a validated path component
    with a symlink after we check but before the caller reads/writes.
    We mitigate this by (a) keeping the check-to-use window as small as
    possible, (b) using O_NOFOLLOW in _write_file_safe, and (c) noting
    that agents don't have fine-grained timing control and symlink creation
    itself goes through this same validation.
    """
    resolved = _validate_path(path, base)

    # Build the unresolved absolute path, then collapse . / .. without
    # following symlinks (os.path.normpath is purely lexical).
    p = Path(path)
    if not p.is_absolute():
        p = base / path
    normalized = Path(os.path.normpath(p))

    # Walk root → leaf; is_symlink() uses lstat so it sees the link itself.
    current = Path(normalized.anchor)
    for part in normalized.parts[1:]:
        current = current / part
        if not current.exists():
            break  # remaining components don't exist yet - no symlinks possible
        if current.is_symlink():
            raise PermissionError(
                f"Symlink detected in path: {current} - symlinks are not allowed "
                f"in file operations to prevent path traversal attacks"
            )
    return resolved


def _read_file(path: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    if not p.exists():
        return f"Error: File '{path}' does not exist."
    if not p.is_file():
        return f"Error: '{path}' is not a file."
    return p.read_text(encoding="utf-8")


def _write_file(path: str, content: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    p.parent.mkdir(parents=True, exist_ok=True)
    _write_file_safe(p, content.encode("utf-8"))
    return f"Successfully wrote {len(content)} characters to '{path}'."


def _write_file_safe(p: Path, content_bytes: bytes) -> None:
    """Write to a file with O_NOFOLLOW TOCTOU mitigation.

    Shared by _write_file and _edit_file to prevent symlink-swap attacks
    between validation and the actual write.
    """
    o_nofollow = getattr(os, "O_NOFOLLOW", 0)
    if o_nofollow:
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | o_nofollow
        try:
            fd = os.open(str(p), flags, 0o644)
        except OSError as exc:
            if exc.errno == 40:  # errno.ELOOP - target is a symlink
                raise PermissionError(
                    f"Symlink detected at write time: {p} - refusing to follow"
                )
            raise
        try:
            os.write(fd, content_bytes)
        finally:
            os.close(fd)
    else:
        p.write_bytes(content_bytes)


def _edit_file(path: str, old_string: str, new_string: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    if not p.exists():
        return f"Error: File '{path}' does not exist."
    content = p.read_text(encoding="utf-8")
    if old_string not in content:
        return f"Error: Could not find the specified string in '{path}'."
    count = content.count(old_string)
    if count > 1:
        return (
            f"Error: Found {count} occurrences of the string in '{path}'. "
            "Please provide a more specific string to replace."
        )
    new_content = content.replace(old_string, new_string, 1)
    # Use O_NOFOLLOW write to prevent TOCTOU symlink-swap attacks
    _write_file_safe(p, new_content.encode("utf-8"))
    return f"Successfully edited '{path}'."


def _list_directory(path: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path(path, b)
    if not p.exists():
        return f"Error: Directory '{path}' does not exist."
    if not p.is_dir():
        return f"Error: '{path}' is not a directory."
    entries = sorted(p.iterdir())
    lines = []
    for entry in entries:
        prefix = "d " if entry.is_dir() else "f "
        lines.append(f"{prefix}{entry.name}")
    return "\n".join(lines) if lines else "(empty directory)"


def _escalate(reason: str, severity: str) -> str:
    """Return the escalation response message."""
    if severity == "blocker":
        return "Escalation registered. STOP working on this task - wait for CEO direction."
    elif severity == "needs_decision":
        return "Escalation registered. Continue with your best judgment for now, but the CEO will review."
    else:
        return "Heads-up noted. The CEO will be informed. Continue your work."


# No restricted commands - interpreters and package managers are fully blocked.
RESTRICTED_COMMANDS: set[str] = set()

# Set via --unsafe-shell CLI flag to bypass the command allowlist.
_unsafe_shell: bool = False


def _validate_command(argv: list[str], base: Path) -> None:
    """Ensure the command executable is on the allowlist.

    Interpreters and package managers are unconditionally blocked - even
    with --unsafe-shell - because they are universal sandbox escapes:
    an agent can write a malicious file and then execute it, bypassing
    every file-level permission check.
    """
    # Strip Windows extensions (.exe, .cmd, .bat) so "python.exe" matches
    # "python" in the block list.  But check the full name first so that
    # names like "py.test" (where .test looks like an extension) are matched.
    raw_name = Path(argv[0]).name.lower()
    exe = raw_name
    # Only strip known Windows executable extensions, not arbitrary dots
    _WIN_EXE_SUFFIXES = {".exe", ".cmd", ".bat", ".com"}
    if any(raw_name.endswith(suffix) for suffix in _WIN_EXE_SUFFIXES):
        exe = Path(raw_name).stem
    # Hard block - never allow, not even with --unsafe-shell
    if exe in BLOCKED_COMMANDS:
        raise PermissionError(
            f"Command not allowed: {exe}. Agents cannot run interpreters or "
            f"package managers directly. Use submit_dependency_request to "
            f"propose new dependencies."
        )
    if _unsafe_shell:
        return
    if exe not in ALLOWED_COMMANDS:
        raise PermissionError(f"Command not allowed: {exe}")


# Env vars whose values are safe to expose or too short/common to redact.
# We only sanitize secret-like variables, not PATH, APPDATA, etc.
_SENSITIVE_ENV_PREFIXES = {"API_KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL"}


def _sanitize_error(error: str) -> str:
    """Strip sensitive env var values from error output before returning to agents.

    Only redacts variables whose names suggest they hold secrets.
    Redacting common vars like PATH or APPDATA would corrupt normal output.
    """
    for key, val in os.environ.items():
        if len(val) <= 3:
            continue
        upper_key = key.upper()
        if any(prefix in upper_key for prefix in _SENSITIVE_ENV_PREFIXES):
            error = error.replace(val, f"${key}")
    return error


def _split_command(command: str) -> list[str]:
    """Split a command string into argv, respecting the current platform.

    On Windows, shlex.split(posix=True) treats backslashes as escape
    characters, mangling paths like ``src\\odd\\cli.py``. We use
    posix=False to keep backslashes literal, then strip the residual
    outer quotes that posix=False preserves on each token.
    """
    if sys.platform == "win32":
        tokens = shlex.split(command, posix=False)
        # posix=False keeps surrounding quotes - strip them so subprocess
        # sees the actual argument value.
        return [t.strip('"').strip("'") for t in tokens]
    return shlex.split(command)


def _run_command(command: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    argv = _split_command(command)
    _validate_command(argv, b)
    result = subprocess.run(
        argv,
        shell=False,
        capture_output=True,
        text=True,
        timeout=SHELL_COMMAND_TIMEOUT,
        cwd=b,
    )
    output = ""
    if result.stdout:
        output += result.stdout
    if result.stderr:
        output += ("\n" if output else "") + _sanitize_error(result.stderr)
    if result.returncode != 0:
        output += f"\n(command failed)"
    return output or "(no output)"
