"""Submission tool schemas - structured output via tool_use.

These are "extra tools" passed to invoke() for specific phases.
The agent calls them to submit structured data instead of free text.
AgentEngine intercepts these calls and stores the data as submissions.
"""

SUBMIT_SPRINT_PLAN = {
    "name": "submit_sprint_plan",
    "description": (
        "Submit the sprint plan as structured data. Use this to deliver your "
        "sprint plan instead of plain text. Each task needs a description and "
        "who it's assigned to."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "description": {
                            "type": "string",
                            "description": "What needs to be done.",
                        },
                        "assigned_to": {
                            "type": "string",
                            "description": "Who should do it (e.g. 'Lead Developer', 'QA', a consultant name).",
                        },
                    },
                    "required": ["description", "assigned_to"],
                },
                "description": "The list of sprint tasks.",
            },
        },
        "required": ["tasks"],
    },
}

SUBMIT_HIRE_SUGGESTION = {
    "name": "submit_hire_suggestion",
    "description": (
        "Submit hiring suggestions as structured data. Use this to recommend "
        "new hires instead of plain text HIRE:/MODEL: format."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "suggestions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "description": {
                            "type": "string",
                            "description": "Specific expertise description for the hire.",
                        },
                        "model": {
                            "type": "string",
                            "enum": ["high", "standard", "fast"],
                            "description": "Model tier based on task complexity.",
                        },
                        "reasoning": {
                            "type": "string",
                            "description": "One-line reasoning for the model choice.",
                        },
                    },
                    "required": ["description", "model"],
                },
                "description": "List of hiring suggestions. Empty array if no hires needed.",
            },
        },
        "required": ["suggestions"],
    },
}

SUBMIT_CANDIDATE = {
    "name": "submit_candidate",
    "description": (
        "Submit the recruited candidate's profile as structured data."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "The candidate's first name (a punny name that winks at their specialty).",
            },
            "title": {
                "type": "string",
                "description": "Professional title.",
            },
            "resume": {
                "type": "string",
                "description": "Full resume/profile text.",
            },
        },
        "required": ["name", "title", "resume"],
    },
}

SUBMIT_CONSULTANT_SPECS = {
    "name": "submit_consultant_specs",
    "description": (
        "Submit consultant recommendations as structured data."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "consultants": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Descriptive name/title for the consultant.",
                        },
                        "job_description": {
                            "type": "string",
                            "description": "What specific expertise and tasks they'd handle.",
                        },
                        "model": {
                            "type": "string",
                            "enum": ["high", "standard", "fast"],
                            "description": "Recommended model tier.",
                        },
                    },
                    "required": ["name", "job_description"],
                },
                "description": "List of recommended consultants.",
            },
        },
        "required": ["consultants"],
    },
}

SUBMIT_ROADMAP = {
    "name": "submit_roadmap",
    "description": (
        "Submit the multi-sprint roadmap as structured data."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "sprints": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "number": {
                            "type": "integer",
                            "description": "Relative sprint number (1, 2, 3...).",
                        },
                        "deliverables": {
                            "type": "string",
                            "description": "What this sprint delivers.",
                        },
                        "is_milestone": {
                            "type": "boolean",
                            "description": "Whether this is a CEO check-in point.",
                        },
                    },
                    "required": ["number", "deliverables"],
                },
                "description": "The planned sprints.",
            },
        },
        "required": ["sprints"],
    },
}

SUBMIT_TESTER_SPECS = {
    "name": "submit_tester_specs",
    "description": (
        "Submit beta tester profiles as structured data."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "testers": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "A realistic first name for the tester.",
                        },
                        "profile": {
                            "type": "string",
                            "description": "Who they are - background, what they'd use the product for.",
                        },
                        "instructions": {
                            "type": "string",
                            "description": "What they should test and how.",
                        },
                    },
                    "required": ["name", "profile", "instructions"],
                },
                "description": "List of beta tester specs.",
            },
        },
        "required": ["testers"],
    },
}

SUBMIT_PHASE_PLAN = {
    "name": "submit_phase_plan",
    "description": (
        "Submit the detailed phase breakdown for the sprint. Each phase "
        "contains tasks that can be worked on independently. Phases execute "
        "in order - earlier phases make way for later ones."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "phases": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "description": {
                            "type": "string",
                            "description": "What this phase accomplishes.",
                        },
                        "task_ids": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "IDs of tasks in this phase (from the sprint plan).",
                        },
                    },
                    "required": ["description", "task_ids"],
                },
                "description": "Ordered list of phases. Phase 1 runs first, phase 2 after, etc.",
            },
        },
        "required": ["phases"],
    },
}

SUBMIT_CODE_REVIEW = {
    "name": "submit_code_review",
    "description": (
        "Submit your code review results. Score the code 1-10 and list "
        "specific findings with severity levels."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "score": {
                "type": "integer",
                "description": "Overall code quality score from 1 (terrible) to 10 (excellent).",
                "minimum": 1,
                "maximum": 10,
            },
            "findings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "severity": {
                            "type": "string",
                            "enum": ["critical", "major", "minor", "style"],
                            "description": "Severity of the finding.",
                        },
                        "description": {
                            "type": "string",
                            "description": "What the issue is and where.",
                        },
                    },
                    "required": ["severity", "description"],
                },
                "description": "List of specific findings. Empty if code is clean.",
            },
            "summary": {
                "type": "string",
                "description": "Brief overall assessment of code quality.",
            },
        },
        "required": ["score", "findings", "summary"],
    },
}

SUBMIT_TEST_CHANGE_REQUEST = {
    "name": "submit_test_change_request",
    "description": (
        "Request a modification to a test file. Only QA (Vera) can modify tests "
        "directly. Use this tool to describe what needs to change and why. "
        "Vera will review your request adversarially and decide whether to apply it."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "test_file": {
                "type": "string",
                "description": "Path to the test file that needs modification.",
            },
            "reason": {
                "type": "string",
                "description": (
                    "Why the test needs to change. Be specific - 'test is wrong' "
                    "is not enough. Explain what the test assumes incorrectly and "
                    "what the correct behavior should be."
                ),
            },
            "proposed_change": {
                "type": "string",
                "description": (
                    "What you want changed. Can be a description or a code snippet. "
                    "Vera will evaluate this independently."
                ),
            },
        },
        "required": ["test_file", "reason", "proposed_change"],
    },
}

SUBMIT_DEPENDENCY_REQUEST = {
    "name": "submit_dependency_request",
    "description": (
        "Request that a dependency be added to the project. You cannot install "
        "dependencies directly - the CEO must approve each one. Provide the "
        "package name, a one-sentence description, and a one-sentence "
        "justification for why this project needs it."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "dependencies": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "package": {
                            "type": "string",
                            "description": "Package name (e.g. 'requests', 'lodash').",
                        },
                        "ecosystem": {
                            "type": "string",
                            "enum": ["pip", "npm"],
                            "description": "Package ecosystem (pip for Python, npm for Node).",
                        },
                        "description": {
                            "type": "string",
                            "description": "One-sentence description of what the package does.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "One-sentence justification for why this project needs it.",
                        },
                    },
                    "required": ["package", "ecosystem", "description", "reason"],
                },
                "description": "List of dependencies to request.",
            },
        },
        "required": ["dependencies"],
    },
}

SUBMIT_TEST_REVIEW_DECISION = {
    "name": "submit_test_review_decision",
    "description": (
        "Submit your verdict on a test change request. As QA, use this to "
        "formally accept or reject a developer's request to modify a test."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "verdict": {
                "type": "string",
                "enum": ["accept", "reject"],
                "description": "Whether to accept or reject the test change request.",
            },
            "reason": {
                "type": "string",
                "description": (
                    "Why you accepted or rejected. Be specific - reference "
                    "the test's intent and whether the proposed change preserves it."
                ),
            },
            "test_file": {
                "type": "string",
                "description": "Path to the test file this decision applies to.",
            },
        },
        "required": ["verdict", "reason", "test_file"],
    },
}

# Set of all submission tool names for quick lookup
SUBMISSION_TOOL_NAMES = {
    "submit_sprint_plan",
    "submit_phase_plan",
    "submit_hire_suggestion",
    "submit_candidate",
    "submit_consultant_specs",
    "submit_roadmap",
    "submit_tester_specs",
    "submit_code_review",
    "submit_test_change_request",
    "submit_dependency_request",
    "submit_test_review_decision",
}
