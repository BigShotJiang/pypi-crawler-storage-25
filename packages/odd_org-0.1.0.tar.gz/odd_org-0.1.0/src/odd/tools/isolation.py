"""Single source of truth for agent file/command access rules.

DirectRunner (tools/execution.py) consults this policy and translates
verdicts into PermissionError.
"""

from __future__ import annotations

import re
from pathlib import Path

from odd.models import _to_slug


# ── Constants ──────────────────────────────────────────────────────────

SECRETARY_NAME = "paige"
QA_SLUG = "vera"

CORE_TEAM_DIR_MAP: dict[str, str] = {
    "cody": "lead_dev",
    "vera": "qa",
    "scout": "recruiter",
    "paige": "secretary",
}

PROTECTED_CONFIG_PATHS = {"config.json", "values.json", "financials/budget.json"}
HIDDEN_ODD_DIRS = {"logs", "notes"}

EXPERIENCE_PATH_RE = re.compile(r"\.odd/team/consultants/[^/]+/ratings\.json")
TEST_PATH_RE = re.compile(r"(^|[/\\\s])tests[/\\]")

ALLOWED_COMMANDS = {
    "git", "ls", "cat", "head", "tail",
    "grep", "find", "mkdir", "cp", "mv", "touch", "echo",
}

BLOCKED_COMMANDS = {
    "python", "python3", "node", "npm", "npx", "uv", "pip", "pip3",
    "pytest", "py.test",
}

GIT_WRITE_SUBCOMMANDS = {
    "checkout", "apply", "reset", "stash", "cherry-pick",
    "revert", "merge", "rm", "mv", "restore", "add", "commit",
}
GIT_BLOCKED_SUBCOMMANDS = {"push", "remote", "config", "clean"}
GIT_BLOCKED_GLOBAL_FLAGS = {"-c", "--exec-path"}


# ── Helpers ────────────────────────────────────────────────────────────

def normalize_path(path: str) -> str:
    """Normalize a file path for isolation checks.

    Collapses ``..`` traversal, replaces backslashes with forward slashes.
    ``posixpath.normpath`` handles the ``..`` collapse without touching the
    filesystem (unlike ``Path.resolve()`` which follows symlinks).
    """
    import posixpath
    return posixpath.normpath(path.replace("\\", "/"))


def agent_slug(agent_name: str) -> str:
    """Canonical agent name → slug, using Unicode-aware normalization."""
    return _to_slug(agent_name)


def agent_team_dirs(agent_name: str) -> list[str]:
    """Return the directory names this agent may access under .odd/team/.

    Core team members get their role-based dir (e.g. Cody → lead_dev).
    Consultants get their name-based dir under consultants/.
    """
    slug = agent_slug(agent_name)
    if slug in CORE_TEAM_DIR_MAP:
        return [CORE_TEAM_DIR_MAP[slug]]
    return [f"consultants/{slug}"]


# ── Individual rules ───────────────────────────────────────────────────
# Each returns None (allowed) or a denial reason string.


def check_team_path_access(path: str, agent_name: str) -> str | None:
    """Enforce persona isolation: agents can only access their own .odd/team/ dir.

    The secretary (Paige) has read access to all agent directories.
    """
    normalized = normalize_path(path)
    if ".odd/team/" not in normalized:
        return None
    slug = agent_slug(agent_name)
    if slug == SECRETARY_NAME:
        return None  # secretary has read access to all
    after_team = normalized.split(".odd/team/", 1)[1]
    allowed_dirs = agent_team_dirs(agent_name)
    for allowed in allowed_dirs:
        if after_team == allowed or after_team.startswith(allowed + "/"):
            return None
    return f"Access denied: {agent_name} cannot access another agent's files"


def check_secretary_write(path: str, agent_name: str) -> str | None:
    """Block the secretary from writing to other agents' .odd/team/ dirs."""
    slug = agent_slug(agent_name)
    if slug != SECRETARY_NAME:
        return None
    normalized = normalize_path(path)
    if ".odd/team/" not in normalized:
        return None
    after_team = normalized.split(".odd/team/", 1)[1]
    allowed = CORE_TEAM_DIR_MAP.get(slug, slug)
    if after_team == allowed or after_team.startswith(allowed + "/"):
        return None
    return "Access denied: secretary has read-only access to other agents' files"


def check_hidden_odd_dir(path: str, agent_name: str) -> str | None:
    """Block agent access to CEO-only directories under .odd/ (logs, notes).

    The secretary (Paige) is allowed to access .odd/notes/ since maintaining
    project documentation is part of her job description. Logs are always
    CEO-only.
    """
    normalized = normalize_path(path)
    if ".odd/" not in normalized:
        return None
    after_odd = normalized.split(".odd/", 1)[1]
    top_dir = after_odd.split("/")[0]
    if top_dir not in HIDDEN_ODD_DIRS:
        return None
    slug = agent_slug(agent_name)
    if slug == SECRETARY_NAME and top_dir == "notes":
        return None
    return f"Access denied: agents cannot access .odd/{top_dir}/ (CEO-only)"


def check_config_write(path: str) -> str | None:
    """Block agent writes to CEO-owned config files under .odd/."""
    normalized = normalize_path(path)
    if ".odd/" in normalized:
        after_odd = normalized.split(".odd/", 1)[1]
        if after_odd in PROTECTED_CONFIG_PATHS:
            return f"Access denied: agents cannot modify .odd/{after_odd} (CEO-owned config)"
    return None


def check_experience_write(path: str) -> str | None:
    """Block agent writes to work experience files (sprint-engine-owned)."""
    normalized = normalize_path(path)
    if EXPERIENCE_PATH_RE.search(normalized):
        return "Access denied: agents cannot modify work experience records"
    return None


def check_test_file_write(path: str, agent_name: str) -> str | None:
    """Block non-QA agents from writing to test files and pytest config.

    Only Vera (QA) can create or modify files under tests/. Other agents
    must use the submit_test_change_request tool to request modifications.
    Also blocks writes to conftest.py at any depth.
    """
    slug = agent_slug(agent_name)
    if slug == QA_SLUG:
        return None
    normalized = normalize_path(path)
    if TEST_PATH_RE.search(normalized):
        return (
            "Access denied: only QA (Vera) can modify test files. "
            "Use the submit_test_change_request tool to request a test change."
        )
    basename = Path(normalized).name.lower()
    if basename == "conftest.py":
        return (
            "Access denied: only QA (Vera) can write conftest.py files. "
            "conftest.py is auto-loaded by pytest and is a code execution vector."
        )
    return None


def check_command_test_write(command: str, agent_name: str) -> str | None:
    """Block shell commands that could modify test files from non-QA agents."""
    slug = agent_slug(agent_name)
    if slug == QA_SLUG:
        return None
    if not TEST_PATH_RE.search(command):
        return None
    read_only = re.match(r"^\s*(cat|head|tail|less|more|grep|rg|diff|wc)\b", command)
    if read_only:
        return None
    return (
        "Access denied: only QA (Vera) can modify test files via shell commands. "
        "Use read_file to read tests, or submit_test_change_request to request changes."
    )


def check_command_hidden_odd_dirs(command: str, agent_name: str) -> str | None:
    """Block shell commands that reference CEO-only .odd/ directories."""
    slug = agent_slug(agent_name)
    for match in re.finditer(r"""['"]*([^\s'"]*\.odd[/\\](logs|notes)[/\\][^\s'"]*)['"]*""", command):
        top_dir = match.group(2)
        if slug == SECRETARY_NAME and top_dir == "notes":
            continue
        return f"Access denied: agents cannot access .odd/{top_dir}/ (CEO-only)"
    return None


def check_command_team_access(command: str, agent_name: str) -> str | None:
    """Check shell commands for .odd/team/ path references that violate isolation."""
    if ".odd" not in command:
        return None
    for match in re.finditer(r"""['"]*([^\s'"]*\.odd[/\\]team[/\\][^\s'"]+)['"]*""", command):
        path = match.group(1).strip("'\"")
        reason = check_team_path_access(path, agent_name)
        if reason:
            return reason
    return None


# ── Composite checks ───────────────────────────────────────────────────
# Convenience methods that run the right set of rules for read vs. write.


def check_read_access(path: str, agent_name: str) -> str | None:
    """All checks for a file read operation."""
    return (
        check_team_path_access(path, agent_name)
        or check_hidden_odd_dir(path, agent_name)
    )


def check_write_access(path: str, agent_name: str) -> str | None:
    """All checks for a file write operation."""
    return (
        check_team_path_access(path, agent_name)
        or check_hidden_odd_dir(path, agent_name)
        or check_config_write(path)
        or check_experience_write(path)
        or check_secretary_write(path, agent_name)
        or check_test_file_write(path, agent_name)
    )
