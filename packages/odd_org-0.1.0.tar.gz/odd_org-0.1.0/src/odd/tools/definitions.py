"""Core tool definitions - the tools every agent gets."""

# Tool for writing goal notes during init conversation.
WRITE_NOTES_TOOL = {
    "name": "write_file",
    "description": (
        "Write content to a file. Use this to maintain .odd/goal.md with "
        "high-level project notes."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the file to write, relative to project root.",
            },
            "content": {
                "type": "string",
                "description": "The content to write to the file.",
            },
        },
        "required": ["path", "content"],
    },
}

# Read-only subset for conversations where the agent should explore
# existing files but not modify anything (e.g. init conversation).
EXPLORE_TOOLS = [
    {
        "name": "read_file",
        "description": "Read the contents of a file at the given path.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read, relative to project root.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "list_directory",
        "description": "List files and directories at the given path.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the directory to list, relative to project root. Defaults to '.'",
                    "default": ".",
                },
            },
        },
    },
]

TOOL_DEFINITIONS = [
    {
        "name": "read_file",
        "description": "Read the contents of a file at the given path.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read, relative to project root.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write content to a file. Creates the file and any parent directories if they don't exist. Overwrites existing content.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write, relative to project root.",
                },
                "content": {
                    "type": "string",
                    "description": "The content to write to the file.",
                },
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "edit_file",
        "description": "Replace a specific string in a file with new content. The old_string must match exactly.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to edit, relative to project root.",
                },
                "old_string": {
                    "type": "string",
                    "description": "The exact string to find and replace.",
                },
                "new_string": {
                    "type": "string",
                    "description": "The string to replace it with.",
                },
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
    {
        "name": "list_directory",
        "description": "List files and directories at the given path.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the directory to list, relative to project root. Defaults to '.'",
                    "default": ".",
                },
            },
        },
    },
    {
        "name": "run_command",
        "description": "Run a shell command and return its output. Use for running tests, installing packages, etc.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute.",
                },
            },
            "required": ["command"],
        },
    },
    {
        "name": "escalate",
        "description": (
            "Escalate an issue to the CEO. Use this when you are blocked, face an "
            "ambiguous requirement, need a decision that's above your pay grade, or "
            "encounter something that could go very wrong without human judgment. "
            "The CEO will be notified and can provide direction."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "What you need from the CEO and why.",
                },
                "severity": {
                    "type": "string",
                    "enum": ["blocker", "needs_decision", "heads_up"],
                    "description": "blocker = can't continue without input. needs_decision = have options but CEO should choose. heads_up = FYI, continuing but CEO should know.",
                },
            },
            "required": ["reason", "severity"],
        },
    },
    {
        "name": "request_command",
        "description": (
            "Request CEO approval to run a command that is outside your normal "
            "permissions (e.g. npm install, pip install, pytest). The CEO will "
            "see the exact command and can approve or deny it. Use this instead "
            "of escalate when the blocker is specifically that you need to run "
            "a command you don't have access to."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The exact shell command to run.",
                },
                "reason": {
                    "type": "string",
                    "description": "Why you need to run this command.",
                },
            },
            "required": ["command", "reason"],
        },
    },
]
