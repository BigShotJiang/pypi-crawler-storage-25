"""Sprint briefing - accumulates mechanical operational context."""

from __future__ import annotations

from odd.models import SprintPhase, SprintTask, TaskStatus, _to_slug


class SprintBriefing:
    """Accumulates mechanical operational context as a sprint progresses.

    This is the structured, sprint-scoped briefing that solves intra-agent
    amnesia (#1) and thin handoffs (#2). Every section is built from real
    outputs (test results, diff stats, task outcomes) - never from agent
    reasoning.

    The briefing is injected into project_context for every subsequent
    agent call within the sprint.
    """

    def __init__(self, sprint_number: int, goal: str):
        self.sprint_number = sprint_number
        self.goal = goal
        self._sections: list[str] = []

    def after_planning(self, tasks: list[SprintTask], phases: list[SprintPhase]) -> None:
        """Capture task list and phase breakdown after planning completes."""
        task_lines = "\n".join(
            f"  - {t.id}: {t.description} (→ {t.assigned_to})"
            for t in tasks
        )
        section = f"### After Planning\n- {len(tasks)} tasks planned:\n{task_lines}"

        if phases:
            phase_lines = "\n".join(
                f"  - Phase {p.number}: {p.description} ({len(p.task_ids)} tasks)"
                for p in phases
            )
            section += f"\n- Phase breakdown:\n{phase_lines}"

        self._sections.append(section)

    def after_qa(self, test_files: list[str], test_names: list[str], baseline_output: str) -> None:
        """Capture QA test context after test writing completes."""
        parts = ["### After QA"]
        if test_files:
            parts.append(f"- Test files: {', '.join(test_files)}")
        if test_names:
            parts.append(f"- {len(test_names)} tests written:")
            for name in test_names:
                parts.append(f"  - {name}")
        if baseline_output:
            # Extract just the summary line (e.g. "3 passed, 2 failed")
            summary = baseline_output.strip().splitlines()[-1] if baseline_output.strip() else ""
            parts.append(f"- Baseline: {summary}")
        self._sections.append("\n".join(parts))

    def after_phase(self, phase_number: int, task_outcomes: list[tuple[str, str, str]], test_summary: str, diff_stat: str) -> None:
        """Capture results after a phase completes.

        Args:
            phase_number: Which phase just finished.
            task_outcomes: List of (task_id, description, status) tuples.
            test_summary: Last line of pytest output (e.g. "8 passed, 2 failed").
            diff_stat: Output of git diff --stat for this phase's changes.
        """
        parts = [f"### After Phase {phase_number}"]
        for tid, desc, status in task_outcomes:
            marker = "✓" if status == TaskStatus.DONE else "✗"
            parts.append(f"  - {marker} {tid}: {desc} ({status})")
        if test_summary:
            parts.append(f"- Tests: {test_summary}")
        if diff_stat:
            parts.append(f"- Changes:\n```\n{diff_stat}\n```")
        self._sections.append("\n".join(parts))

    def after_consultant_task(self, consultant_name: str, task_desc: str, status: str, diff_stat: str) -> None:
        """Capture a consultant's completed work."""
        marker = "✓" if status == TaskStatus.DONE else "✗"
        parts = [f"### Consultant: {consultant_name} - {marker} {task_desc}"]
        if diff_stat:
            parts.append(f"- Changes:\n```\n{diff_stat}\n```")
        self._sections.append("\n".join(parts))

    def render(self) -> str:
        """Render the full briefing for injection into project_context."""
        if not self._sections:
            return ""
        header = f"## Sprint {self.sprint_number} - Operational Briefing"
        return header + "\n\n" + "\n\n".join(self._sections)

    def render_for_agent(self, agent_name: str) -> str:
        """Render a filtered briefing scoped to what this agent should see.

        Includes planning overview and QA context (everyone needs the spec),
        but excludes other consultants' detailed work (diff stats, outcomes).
        This limits information leakage between isolated agents.
        """
        if not self._sections:
            return ""
        filtered = []
        # Use the canonical slug for exact matching - avoids substring collisions
        # (e.g. "Al" matching "Alice") and stays consistent with models._to_slug.
        agent_slug = _to_slug(agent_name)
        for section in self._sections:
            # Always include planning and QA sections - everyone needs the spec
            if section.startswith("### After Planning") or section.startswith("### After QA"):
                filtered.append(section)
            # Include phase summaries (task outcomes + test results)
            elif section.startswith("### After Phase"):
                filtered.append(section)
            # Consultant sections: only include if it's about this agent
            elif section.startswith("### Consultant:"):
                # "### Consultant: Alice Chen - ✓ task desc"
                # Extract the name between "### Consultant: " and the em-dash or
                # end of the first line.  Split on " - " (space-em-dash-space) to
                # avoid breaking on names that contain a plain hyphen or bare em-dash.
                first_line = section.split("\n", 1)[0]
                prefix = "### Consultant:"
                after_prefix = first_line[len(prefix):]
                # Try space-em-dash-space first, then bare em-dash, then take the whole remainder
                if " - " in after_prefix:
                    section_name = after_prefix.split(" - ", 1)[0].strip()
                elif "-" in after_prefix:
                    section_name = after_prefix.split("-", 1)[0].strip()
                else:
                    section_name = after_prefix.strip()
                section_slug = _to_slug(section_name)
                if section_slug == agent_slug:
                    filtered.append(section)
                # Otherwise, omit - don't leak other consultants' diffs
            # Default-deny: unknown section types are omitted rather than
            # included, so new section types don't accidentally leak info.
        if not filtered:
            return ""
        header = f"## Sprint {self.sprint_number} - Operational Briefing"
        return header + "\n\n" + "\n\n".join(filtered)
