"""Vacation mode collaborator.

Owns the autonomous multi-sprint vacation lifecycle: plan, execute sprints
without CEO interaction, handle blockers per policy.  Declares its
dependencies explicitly via __init__ and is independently testable.
"""

from __future__ import annotations

from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.markdown import Markdown

from odd.models import (
    BlockerPolicy,
    CEOInvolvement,
    Roadmap,
    RoleType,
    SprintStatus,
    VacationPlan,
    VacationReport,
    VacationSprintResult,
)
from odd.parsers import parse_roadmap
from odd.tools import SUBMIT_ROADMAP

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.git import GitManager
    from odd.models import Persona, Sprint
    from odd.state import StateManager
    from odd.sprint.planner import SprintPlanner
    from odd.sprint.wrapup import SprintWrapup

from odd.sprint._console import console  # noqa: E402


class VacationPausedError(Exception):
    """Raised when a vacation is paused due to a blocker (PAUSE_VACATION policy)."""


class VacationRunner:
    """Autonomous multi-sprint vacation lifecycle.

    Runs sprints without CEO interaction, handling blockers per the
    chosen policy.  Each dependency is declared explicitly so the
    runner can be tested without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        engine: AgentEngine,
        git: GitManager,
        planner: SprintPlanner,
        wrapup: SprintWrapup,
        build_project_context: Callable[[int], str],
        run_sprint: Callable[[Sprint, dict[str, Persona]], Sprint],
    ):
        self.state = state
        self.engine = engine
        self.git = git
        self.planner = planner
        self.wrapup = wrapup
        self._build_project_context = build_project_context
        self._run_sprint = run_sprint

    # --- Planning ---

    def plan_vacation(
        self,
        lead_dev: Persona,
        ceo_goal: str,
        budget: float,
    ) -> tuple[str, Roadmap | None]:
        """Have Cody scope a vacation plan, informed by CFO financial metrics.

        Returns (cody_response, roadmap_or_none).
        """
        config = self.state.load_config()
        project_context = self._build_project_context(config.current_sprint + 1)

        # Gather CFO metrics for Cody
        cfo = self.engine.cfo
        feasibility = cfo.vacation_feasibility(budget) if cfo else {}

        financials_block = ""
        if feasibility:
            financials_block = (
                f"\n\n--- CFO Financial Brief ---\n"
                f"Sprints completed so far: {feasibility['sprints_completed']}\n"
                f"Average cost per sprint: ${feasibility['avg_cost_per_sprint']:.4f}\n"
                f"Total project spend to date: ${feasibility['total_project_spend']:.4f}\n"
                f"CEO's vacation budget: ${feasibility['vacation_budget']:.2f}\n"
                f"Estimated sprints affordable: {feasibility['estimated_sprints_affordable']}\n"
            )
            if feasibility["historical_sprint_costs"]:
                costs_str = ", ".join(
                    f"${c:.4f}" for c in feasibility["historical_sprint_costs"]
                )
                financials_block += f"Historical sprint costs: [{costs_str}]\n"
            financials_block += "--- End Financial Brief ---\n"

        console.print(Panel("Cody is scoping the vacation plan...", style="blue"))

        sizing = self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"The CEO is going on vacation and wants this accomplished while "
                f"they're away:\n\n{ceo_goal}\n\n"
                f"The vacation budget is ${budget:.2f}.{financials_block}\n\n"
                f"Break this into a concrete multi-sprint roadmap. For each sprint:\n"
                f"- What it delivers (concrete, demo-able deliverables)\n"
                f"- Whether it's a milestone\n\n"
                f"Give your honest feasibility assessment:\n"
                f"- How many sprints will this take?\n"
                f"- Based on the CFO's data, what's your cost estimate?\n"
                f"- Is the budget realistic for what's being asked?\n"
                f"- Any risks or things the CEO should know before leaving?\n\n"
                f"Use the submit_roadmap tool to submit the roadmap.\n\n"
                f"Fallback format (if you can't use the tool):\n"
                f"SPRINTS: <number>\n"
                f"SPRINT 1: <deliverables>\n"
                f"MILESTONE: yes/no\n"
                f"...\n"
            ),
            project_context=project_context,
            tools=True,
            extra_tools=[SUBMIT_ROADMAP],
        )

        # Parse the roadmap
        roadmap_subs = self.engine.pop_submissions("submit_roadmap")
        structured = roadmap_subs[0]["data"] if roadmap_subs else None
        roadmap_sprints = parse_roadmap(
            sizing, config.current_sprint, structured_data=structured,
        )

        roadmap = None
        if roadmap_sprints and len(roadmap_sprints) >= 1:
            roadmap = Roadmap(
                goal=ceo_goal,
                sprints=roadmap_sprints,
                ceo_involvement=CEOInvolvement.BLOCKERS_ONLY,
                status="active",
            )

        return sizing, roadmap

    # --- Single sprint ---

    def run_vacation_sprint(
        self,
        team: dict[str, Persona],
        ceo_goal: str,
        sprint_number: int,
        blocker_policy: BlockerPolicy,
    ) -> Sprint:
        """Run a single sprint autonomously - no CEO interaction.

        Keeps: plan, QA, implementation, code review, changelog, auto-ship,
               retro, backlog sweep.
        Skips: standup display, CEO plan approval, demo, CEO feedback,
               ship/scrap prompt, hiring suggestions.
        """
        config = self.state.load_config()
        lead_dev = team["lead_dev"]
        qa = team["qa"]
        secretary = team["secretary"]

        console.print(Panel(
            f"[bold]Vacation Sprint {sprint_number}[/bold]\n"
            f"Goal: {ceo_goal}",
            style="blue",
        ))

        # --- Plan (auto-approved) ---
        sprint = self.planner.plan_sprint(
            lead_dev=lead_dev, qa=qa,
            ceo_input=ceo_goal, sprint_number=sprint_number,
        )
        self.wrapup.show_running_costs(f"Vacation sprint {sprint_number} - after planning")

        console.print(Panel(
            Markdown(
                f"**Tasks:**\n"
                + "\n".join(f"- {t.description}" for t in sprint.tasks)
            ),
            title=f"Sprint {sprint_number} Plan (auto-approved)",
            style="dim",
        ))

        # --- Git branch ---
        self.git.create_sprint_branch(sprint_number)
        self.state.save_sprint(sprint)

        try:
            # --- Execute (QA + implementation) ---
            sprint = self._run_sprint(sprint, team)
            self.wrapup.show_running_costs(f"Vacation sprint {sprint_number} - after implementation")

            # --- Post-implementation (vacation version) ---
            self._post_implementation_vacation(
                sprint, team, sprint_number, blocker_policy,
            )

            # --- Finalize ---
            sprint.status = SprintStatus.COMPLETE
            self.state.save_sprint(sprint)
            config.current_sprint = sprint_number
            self.state.save_config(config)

        except KeyboardInterrupt:
            sprint.status = SprintStatus.CANCELLED
            self.state.save_sprint(sprint)
            raise

        return sprint

    def _post_implementation_vacation(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        sprint_number: int,
        blocker_policy: BlockerPolicy,
    ) -> None:
        """Vacation post-implementation: review -> changelog -> auto-ship -> retro -> backlog.

        No demo, no CEO feedback, no hiring suggestions.
        """
        lead_dev = team["lead_dev"]
        secretary = team["secretary"]
        project_context = self._build_project_context(sprint_number)

        # --- Code review (mechanical) ---
        self.wrapup.maybe_run_code_review(sprint, lead_dev, sprint_number, project_context)

        # --- Changelog ---
        self.wrapup.write_changelog_entry(sprint)

        # --- Auto-ship (merge branch) ---
        merge_status = self.wrapup.merge_sprint_branch(sprint_number, lead_dev)
        if merge_status == "merged":
            console.print(f"[green]Sprint {sprint_number} shipped.[/green]")
        elif merge_status == "deferred":
            console.print(
                f"[yellow]Sprint {sprint_number} - merge deferred.[/yellow]"
            )

        # --- Retro (internal record) ---
        retro_summary = self.wrapup.run_retro(sprint, secretary)
        console.print(Panel(
            Markdown(retro_summary),
            title=f"Retro - Sprint {sprint_number}",
            style="dim cyan",
        ))

        # --- Backlog sweep ---
        self.wrapup.sweep_to_backlog(sprint)

    # --- Escalation handling ---

    def _handle_vacation_escalation(
        self,
        agent: Persona,
        escalation: dict,
        project_context: str,
        task_description: str,
        blocker_policy: BlockerPolicy,
    ) -> bool:
        """Handle a blocker escalation during vacation per CEO's chosen policy.

        Returns True if the task should continue, False if it should be skipped.
        """
        severity = escalation.get("severity", "heads_up")
        reason = escalation.get("reason", "")

        # heads_up escalations are always just logged
        if severity == "heads_up":
            console.print(Panel(
                f"[dim]{agent.name} - {reason}[/dim]",
                title="Heads Up (vacation)",
                style="dim",
            ))
            return True

        if blocker_policy == BlockerPolicy.DELEGATE_TO_CODY:
            console.print(Panel(
                f"[bold]{agent.name}[/bold] hit a {severity}:\n\n{reason}\n\n"
                f"[dim]Routing to Cody (acting CEO)...[/dim]",
                style="yellow",
            ))

            # Cody makes the call
            lead_dev = self.state.load_persona("lead_dev")
            cody_response = self.engine.invoke(
                persona=agent if agent.role_type == RoleType.LEAD_DEV else lead_dev,
                user_message=(
                    f"You're acting as CEO while they're on vacation. "
                    f"An agent hit a {severity}:\n\n"
                    f"Agent: {agent.name}\n"
                    f"Task: {task_description}\n"
                    f"Issue: {reason}\n\n"
                    f"Make a decision and provide direction. Be decisive - "
                    f"the CEO trusted you to handle this."
                ),
                project_context=project_context,
                tools=False,
            )
            # Feed Cody's decision back to the blocked agent
            self.engine.invoke(
                persona=agent,
                user_message=(
                    f"Cody (acting CEO) responded to your escalation:\n\n"
                    f"{cody_response}\n\n"
                    f"Please continue with your task."
                ),
                project_context=project_context,
            )
            return True

        elif blocker_policy == BlockerPolicy.PARK_AND_SKIP:
            console.print(Panel(
                f"[bold]{agent.name}[/bold] hit a {severity}:\n\n{reason}\n\n"
                f"[yellow]Parking this task (CEO away). Moving on.[/yellow]",
                style="yellow",
            ))
            return False

        elif blocker_policy == BlockerPolicy.PAUSE_VACATION:
            console.print(Panel(
                f"[bold]{agent.name}[/bold] hit a {severity}:\n\n{reason}\n\n"
                f"[red]Pausing vacation - CEO needs to weigh in.[/red]",
                style="red",
            ))
            raise VacationPausedError(reason)

        return True

    # --- Full vacation loop ---

    def run_vacation(
        self,
        team: dict[str, Persona],
        plan: VacationPlan,
    ) -> VacationReport:
        """Run the full vacation - autonomous multi-sprint loop.

        Runs until: all sprints complete, budget exceeded, or paused.
        """
        from odd.agent import BudgetExceededError

        report = VacationReport(
            plan=plan,
            budget_remaining=plan.budget,
        )

        # Save initial state for resume support
        self.state.save_vacation_plan(plan)
        self.state.save_vacation_report(report)

        console.print(Panel(
            f"[bold green]Vacation started![/bold green]\n\n"
            f"Goal: {plan.goal}\n"
            f"Budget: ${plan.budget:.2f}\n"
            f"Sprints planned: {len(plan.roadmap.sprints)}\n"
            f"Blocker policy: {plan.blocker_policy.value.replace('_', ' ').title()}",
            style="bold green",
        ))

        cost_before_vacation = self.engine.cfo.total_cost() if self.engine.cfo else 0.0

        for rs in plan.roadmap.sprints:
            if rs.status == "complete":
                continue  # Already done (resume case)

            # --- Budget check ---
            if self.engine.cfo:
                vacation_spend = self.engine.cfo.total_cost() - cost_before_vacation
                if vacation_spend >= plan.budget:
                    report.stopped_reason = "budget_exceeded"
                    report.total_cost = vacation_spend
                    report.budget_remaining = plan.budget - vacation_spend
                    console.print(Panel(
                        f"[red]Budget exhausted (${vacation_spend:.4f} of "
                        f"${plan.budget:.2f}). Stopping vacation.[/red]",
                        style="red",
                    ))
                    break

            rs.status = "in_progress"
            self.state.save_roadmap(plan.roadmap)

            try:
                sprint = self.run_vacation_sprint(
                    team, rs.deliverables, rs.number, plan.blocker_policy,
                )
                sprint_cost = (
                    self.engine.cfo.sprint_cost(rs.number) if self.engine.cfo else 0.0
                )
                report.sprint_results.append(VacationSprintResult(
                    sprint_number=rs.number,
                    goal=rs.deliverables,
                    status=sprint.status,
                    cost=sprint_cost,
                ))
                rs.status = "complete"

            except BudgetExceededError as e:
                report.sprint_results.append(VacationSprintResult(
                    sprint_number=rs.number,
                    goal=rs.deliverables,
                    status=SprintStatus.CANCELLED,
                    cost=self.engine.cfo.sprint_cost(rs.number) if self.engine.cfo else 0.0,
                    error=f"Budget exceeded: {e}",
                ))
                report.stopped_reason = "budget_exceeded"
                break

            except VacationPausedError as e:
                report.sprint_results.append(VacationSprintResult(
                    sprint_number=rs.number,
                    goal=rs.deliverables,
                    status=SprintStatus.CANCELLED,
                    cost=self.engine.cfo.sprint_cost(rs.number) if self.engine.cfo else 0.0,
                    error=f"Blocker: {e}",
                ))
                report.stopped_reason = "paused"
                break

            except KeyboardInterrupt:
                report.sprint_results.append(VacationSprintResult(
                    sprint_number=rs.number,
                    goal=rs.deliverables,
                    status=SprintStatus.CANCELLED,
                    cost=self.engine.cfo.sprint_cost(rs.number) if self.engine.cfo else 0.0,
                    error="Interrupted by CEO",
                ))
                report.stopped_reason = "paused"
                break

            except Exception as e:
                report.sprint_results.append(VacationSprintResult(
                    sprint_number=rs.number,
                    goal=rs.deliverables,
                    status=SprintStatus.CANCELLED,
                    cost=self.engine.cfo.sprint_cost(rs.number) if self.engine.cfo else 0.0,
                    error=str(e),
                ))
                console.print(Panel(
                    f"[red]Sprint {rs.number} failed: {e}[/red]\n"
                    f"Continuing to next sprint...",
                    style="red",
                ))
                continue

            finally:
                self.state.save_roadmap(plan.roadmap)
                self.state.save_vacation_report(report)

        # --- Final accounting ---
        if self.engine.cfo:
            vacation_spend = self.engine.cfo.total_cost() - cost_before_vacation
            report.total_cost = vacation_spend
            report.budget_remaining = plan.budget - vacation_spend

        # Check if all sprints completed
        all_done = all(rs.status == "complete" for rs in plan.roadmap.sprints)
        if all_done and report.stopped_reason not in ("budget_exceeded", "paused"):
            report.stopped_reason = "complete"
            plan.roadmap.status = "complete"
            self.state.save_roadmap(plan.roadmap)

        # --- Cody writes the vacation summary ---
        lead_dev = team["lead_dev"]
        report.summary = self._write_vacation_summary(lead_dev, report)

        self.state.save_vacation_report(report)
        return report

    def _write_vacation_summary(
        self,
        lead_dev: Persona,
        report: VacationReport,
    ) -> str:
        """Have Cody write a natural-language summary of the vacation."""
        results_block = "\n".join(
            f"- Sprint {r.sprint_number}: {r.goal} - {r.status.value}"
            + (f" (Error: {r.error})" if r.error else "")
            + f" [${r.cost:.4f}]"
            for r in report.sprint_results
        )

        summary = self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"The CEO is back from vacation. Write a concise debrief.\n\n"
                f"Original goal: {report.plan.goal}\n"
                f"Budget: ${report.plan.budget:.2f}\n"
                f"Total spent: ${report.total_cost:.4f}\n"
                f"Stopped because: {report.stopped_reason}\n\n"
                f"Sprint results:\n{results_block}\n\n"
                f"Summarize:\n"
                f"- What was accomplished\n"
                f"- What wasn't finished (if anything) and why\n"
                f"- Key decisions made in their absence\n"
                f"- What needs the CEO's attention now\n\n"
                f"Be honest and direct - the CEO trusts you."
            ),
            project_context=self._build_project_context(
                report.sprint_results[-1].sprint_number if report.sprint_results else 0,
            ),
            tools=False,
        )
        return summary
