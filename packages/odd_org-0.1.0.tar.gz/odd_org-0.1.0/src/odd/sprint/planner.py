"""Sprint planning collaborator.

Owns roadmap, sprint, and phase planning. Declares its dependencies
explicitly via __init__ and is independently testable.
"""

from __future__ import annotations

from typing import Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt

from odd.config import PHASE_TOKEN_DEFAULTS
from odd.models import (
    CEOInvolvement,
    Roadmap,
    Sprint,
    SprintPhase,
    SprintStatus,
)
from odd.parsers import parse_phase_plan, parse_roadmap, parse_tasks
from odd.tools import SUBMIT_PHASE_PLAN, SUBMIT_ROADMAP, SUBMIT_SPRINT_PLAN

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.models import Persona
    from odd.provider import StreamCallback
    from odd.state import StateManager

from odd.sprint._console import console  # noqa: E402


class SprintPlanner:
    """Sprint planning: roadmap scoping, sprint breakdown, phase sequencing.

    Each dependency is declared explicitly so the planner can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        engine: AgentEngine,
        build_project_context: Callable[[int], str],
    ):
        self.state = state
        self.engine = engine
        self._build_project_context = build_project_context

    def plan_roadmap(
        self,
        lead_dev: Persona,
        ceo_goal: str,
    ) -> Roadmap | None:
        """Have Cody size the CEO's ask and propose a multi-sprint roadmap.

        Returns a Roadmap if the ask needs multiple sprints, or None if it
        fits in a single sprint. The roadmap includes CEO involvement preference
        negotiated during the conversation.
        """
        config = self.state.load_config()
        project_context = self._build_project_context(config.current_sprint + 1)

        console.print("[bold blue]Cody - Scope Assessment:[/bold blue]")

        sizing = self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"The CEO wants:\n\n{ceo_goal}\n\n"
                f"Before we start planning, size this. Can we deliver this in a single "
                f"sprint, or does it need to be broken into multiple sprints?\n\n"
                f"If it needs multiple sprints, lay out the roadmap:\n"
                f"- How many sprints total\n"
                f"- What each sprint delivers (concrete, demo-able deliverables)\n"
                f"- Which sprints are milestones (natural check-in points for the CEO)\n\n"
                f"If it needs multiple sprints, use the submit_roadmap tool to submit "
                f"the roadmap. If it fits in one sprint, just explain why.\n\n"
                f"Fallback format (if you can't use the tool):\n"
                f"SPRINTS: <number>\n"
                f"SPRINT 1: <deliverables>\n"
                f"MILESTONE: yes/no\n"
                f"...\n\n"
                f"Be transparent. The CEO needs to see the full picture upfront."
            ),
            project_context=project_context,
            tools=True,
            extra_tools=[SUBMIT_ROADMAP],
        )

        # Check for structured submission, fall back to string parsing
        roadmap_subs = self.engine.pop_submissions("submit_roadmap")
        structured = roadmap_subs[0]["data"] if roadmap_subs else None
        roadmap_sprints = parse_roadmap(sizing, config.current_sprint, structured_data=structured)
        if not roadmap_sprints or len(roadmap_sprints) <= 1:
            return None

        # Ask CEO about involvement level
        console.print(
            f"\n[bold]Cody proposes {len(roadmap_sprints)} sprints.[/bold]\n"
            f"Where do you want to be involved?"
        )
        involvement = Prompt.ask(
            "[bold yellow]CEO[/bold yellow]",
            choices=["every sprint", "milestones", "blockers only"],
            default="every sprint",
        )
        involvement_map = {
            "every sprint": CEOInvolvement.EVERY_SPRINT,
            "milestones": CEOInvolvement.MILESTONES,
            "blockers only": CEOInvolvement.BLOCKERS_ONLY,
        }

        roadmap = Roadmap(
            goal=ceo_goal,
            sprints=roadmap_sprints,
            ceo_involvement=involvement_map[involvement],
        )

        self.state.save_roadmap(roadmap)
        return roadmap

    def _sprint_summary(self, number: int, label: str) -> str:
        """Build a summary of an existing sprint's state."""
        try:
            prev = self.state.load_sprint(number)
        except FileNotFoundError:
            return ""

        lines = [f"\n--- {label} (Sprint {number}) ---"]
        lines.append(f"Goal: {prev.goal}")
        lines.append(f"Status: {prev.status.value}")
        if prev.tasks:
            lines.append("Tasks:")
            for t in prev.tasks:
                lines.append(f"  - [{t.status.value}] {t.description} ({t.assigned_to})")
        if prev.notes:
            lines.append(f"Notes: {prev.notes[:200]}")
        lines.append("---")
        return "\n".join(lines)

    def plan_sprint(
        self,
        lead_dev: Persona,
        qa: Persona,
        ceo_input: str,
        sprint_number: int,
    ) -> Sprint:
        """Planning phase: Lead dev breaks down CEO's requirements into tasks."""
        config = self.state.load_config()
        project_context = self._build_project_context(sprint_number)

        # Include sprint context so the lead dev knows what exists
        # Check both the current sprint number (replanning) and previous sprint
        prev_summary = self._sprint_summary(sprint_number, "Prior attempt at this sprint")
        if not prev_summary and sprint_number > 1:
            prev_summary = self._sprint_summary(sprint_number - 1, "Previous sprint")

        # Lead dev creates the sprint plan
        planning_prompt = (
            f"The CEO has given the following direction for Sprint {sprint_number}:\n\n"
            f"---\n{ceo_input}\n---\n\n"
            f"Break this down into specific, actionable tasks. For each task, specify:\n"
            f"1. A clear description of what needs to be done\n"
            f"2. Who should do it (yourself, a specific consultant by name, or QA)\n\n"
            f"You'll handle most tasks yourself. Only bring in a consultant when a task "
            f"would genuinely benefit from their specialized perspective - they're here "
            f"to see the problem through a different lens than yours, not to fill a "
            f"headcount.\n\n"
            f"Use the submit_sprint_plan tool to submit your plan.\n\n"
            f"Fallback format (if you can't use the tool):\n"
            f"TASK: <description>\n"
            f"ASSIGN: <role>\n\n"
            f"Remember: QA should write tests FIRST for any implementation tasks."
        )
        if prev_summary:
            planning_prompt += f"\n{prev_summary}"

        console.print("[bold blue]Sprint Plan:[/bold blue]")
        plan_response = self.engine.invoke(
            persona=lead_dev,
            user_message=planning_prompt,
            project_context=project_context,
            tools=False,
            extra_tools=[SUBMIT_SPRINT_PLAN],
            max_tokens=PHASE_TOKEN_DEFAULTS["planning"],
            phase="planning",
        )

        # Check for structured submission, fall back to string parsing
        plan_subs = self.engine.pop_submissions("submit_sprint_plan")
        structured = plan_subs[0]["data"] if plan_subs else None
        tasks = parse_tasks(plan_response, sprint_number, structured_data=structured)

        sprint = Sprint(
            number=sprint_number,
            goal=ceo_input,
            tasks=tasks,
            status=SprintStatus.PLANNING,
        )

        # Don't save yet - caller saves after CEO approves the plan.
        return sprint

    def plan_phases(
        self,
        lead_dev: Persona,
        sprint: Sprint,
        stream: StreamCallback | None = None,
        engine: AgentEngine | None = None,
    ) -> Sprint:
        """Detailed phase planning: Cody organizes tasks into sequential phases.

        Each phase contains tasks that are independent of each other.
        Earlier phases make way for later ones. Cody thinks of this as
        planning his work day by day - the parallelism within a phase is
        invisible to him.

        Args:
            engine: Optional engine override for thread safety (e.g. a forked
                    engine used in a worker thread). Defaults to self.engine.
        """
        if len(sprint.tasks) <= 1:
            # Single task - no phase breakdown needed
            sprint.phases = [SprintPhase(
                number=1,
                description="All sprint work",
                task_ids=[t.id for t in sprint.tasks],
            )]
            self.state.save_sprint(sprint)
            return sprint

        project_context = self._build_project_context(sprint.number)

        task_list = "\n".join(
            f"  - {t.id}: {t.description} (assigned to: {t.assigned_to})"
            for t in sprint.tasks
        )

        phase_prompt = (
            f"Here are the tasks for Sprint {sprint.number}:\n\n"
            f"{task_list}\n\n"
            f"Break these into phases where earlier phases make way for later "
            f"ones. Think of each phase as a day of work - what do you need to "
            f"do first so that what comes next has a foundation to build on?\n\n"
            f"Tasks within the same phase should be independent of each other.\n\n"
            f"Use the submit_phase_plan tool to submit your breakdown.\n\n"
            f"Fallback format (if you can't use the tool):\n"
            f"PHASE 1: <what this phase accomplishes>\n"
            f"TASKS: <task_id>, <task_id>\n"
            f"PHASE 2: ...\n"
        )

        eng = engine or self.engine

        console.print(Panel("Cody is planning the execution phases...", style="blue"))
        response = eng.invoke(
            persona=lead_dev,
            user_message=phase_prompt,
            project_context=project_context,
            tools=False,
            extra_tools=[SUBMIT_PHASE_PLAN],
            max_tokens=PHASE_TOKEN_DEFAULTS["phase_planning"],
            stream=stream,
            phase="planning",
        )

        phase_subs = eng.pop_submissions("submit_phase_plan")
        structured = phase_subs[0]["data"] if phase_subs else None
        phases = parse_phase_plan(response, sprint.tasks, structured_data=structured)

        sprint.phases = phases
        self.state.save_sprint(sprint)

        # Show CEO the phase breakdown
        phase_display = "\n\n".join(
            f"**Phase {p.number}**: {p.description} ({len(p.task_ids)} task{'s' if len(p.task_ids) != 1 else ''})"
            for p in phases
        )
        console.print(Panel(
            Markdown(phase_display),
            title="Execution Phases",
            style="blue",
        ))

        return sprint

    def plan_phases_with_engine(
        self,
        engine: AgentEngine,
        lead_dev: Persona,
        sprint: Sprint,
        stream: StreamCallback | None = None,
    ) -> Sprint:
        """Like plan_phases but uses a specific (forked) engine for thread safety."""
        return self.plan_phases(lead_dev, sprint, stream=stream, engine=engine)
