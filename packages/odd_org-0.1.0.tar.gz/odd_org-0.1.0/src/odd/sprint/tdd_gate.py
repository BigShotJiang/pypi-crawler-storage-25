"""TDD quality gate - test/retry loop, escalation handling.

Owns the mechanical TDD cycle: invoke agent → run pytest → retry on failure.
Declares its dependencies explicitly via __init__ and is independently testable.
"""

from __future__ import annotations

import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.prompt import Prompt

from odd.config import PHASE_TOKEN_DEFAULTS, TDD_MAX_RETRIES, TDD_PYTEST_TIMEOUT
from odd.labels import escalation_label, escalation_style
from odd.models import (
    CEOGate,
    CEOStyle,
    RoleType,
    TaskStatus,
)
from odd.tools import SUBMIT_DEPENDENCY_REQUEST, SUBMIT_TEST_CHANGE_REQUEST

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.models import Persona, Sprint, SprintTask
    from odd.provider import StreamCallback
    from odd.state import StateManager

from odd.sprint._console import console, _tprint  # noqa: E402


def _run_approved_command(command: str, cwd: Path | None = None) -> str:
    """Run a CEO-approved command with no allowlist restrictions.

    This bypasses the normal agent command sandbox because the CEO
    has explicitly approved this specific command.
    """
    try:
        if sys.platform == "win32":
            argv = shlex.split(command, posix=False)
            argv = [t.strip('"').strip("'") for t in argv]
        else:
            argv = shlex.split(command)
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=cwd,
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += ("\n" if output else "") + result.stderr
        if result.returncode != 0:
            output += f"\n(exit code {result.returncode})"
        return output or "(no output)"
    except FileNotFoundError:
        return f"Error: command not found: {command}"
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after 120s: {command}"


class TDDGate:
    """Mechanical TDD quality gate.

    Runs the invoke → test → retry loop and handles escalations.
    Each dependency is declared explicitly so the gate can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        gate: Callable[[CEOGate], CEOStyle],
        main_engine: AgentEngine,
    ):
        self.state = state
        self._gate = gate
        self._main_engine = main_engine

    # --- Test runners ---

    def run_tests(self, cwd: Path | None = None) -> tuple[bool, str]:
        """Mechanically run pytest and return (passed, output).

        This is NOT an LLM decision - it's a system-level quality gate.
        """
        base = cwd or self.state.root
        try:
            result = subprocess.run(
                ["pytest", "--tb=short", "-q"],
                capture_output=True,
                text=True,
                timeout=TDD_PYTEST_TIMEOUT,
                cwd=base,
            )
            output = result.stdout
            if result.stderr:
                output += "\n" + result.stderr
            passed = result.returncode == 0
            return passed, output.strip()
        except FileNotFoundError:
            return False, "(pytest not found - install pytest to enable the TDD quality gate)"
        except subprocess.TimeoutExpired:
            return False, f"(pytest timed out after {TDD_PYTEST_TIMEOUT}s)"

    def discover_test_files(self, cwd: Path | None = None) -> list[str]:
        """Find test files in the project so agents know what QA wrote."""
        base = cwd or self.state.root
        tests_dir = base / "tests"
        if not tests_dir.exists():
            return []
        return sorted(
            str(p.relative_to(base))
            for p in tests_dir.rglob("test_*.py")
        )

    def collect_test_names(self, cwd: Path | None = None) -> list[str]:
        """Run pytest --collect-only to get test names without executing them."""
        base = cwd or self.state.root
        try:
            result = subprocess.run(
                ["pytest", "--collect-only", "-q"],
                capture_output=True,
                text=True,
                timeout=TDD_PYTEST_TIMEOUT,
                cwd=base,
            )
            lines = result.stdout.strip().splitlines()
            return [l.strip() for l in lines if "::" in l]
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return []

    def get_max_retries(self) -> int:
        """Get the TDD retry limit from CEO config, falling back to default."""
        try:
            config = self.state.load_config()
            return config.tdd_max_retries
        except Exception:
            return TDD_MAX_RETRIES

    # --- Prompt builders ---

    @staticmethod
    def build_impl_prompt(
        sprint_number: int,
        task_description: str,
        test_context: str,
        notes_path: str,
        agent_name: str,
    ) -> str:
        """Build the standard implementation prompt for a task."""
        agent_slug = agent_name.lower().replace(" ", "_")
        return (
            f"Your task for Sprint {sprint_number}:\n\n"
            f"{task_description}\n\n"
            f"Tests have already been written by QA. Your job is to make them pass."
            f"{test_context}\n\n"
            f"Read the test files to understand what's expected, then implement "
            f"the code to make them pass. The system will verify tests mechanically "
            f"after you finish - you don't need to run pytest yourself, but you can "
            f"if you want to check your work as you go.\n\n"
            f"When you're done, write a brief note about what you did, any "
            f"issues you hit, and anything the team should know to "
            f"{notes_path}/{agent_slug}.md"
        )

    @staticmethod
    def build_fix_prompt(test_output: str, review_feedback: str = "") -> str:
        """Build the TDD retry prompt from test output and optional review feedback."""
        prompt = (
            f"The system ran pytest after your implementation and tests are failing:\n\n"
            f"```\n{test_output[:3000]}\n```\n\n"
        )
        if review_feedback:
            prompt += f"{review_feedback}\n\n"
        prompt += (
            f"Fix the failing tests. Do NOT modify the test files - fix your "
            f"implementation to match what QA specified.\n\n"
            f"If you believe a test is genuinely wrong (not just hard to pass), "
            f"use the submit_test_change_request tool to request a change from QA."
        )
        return prompt

    @staticmethod
    def format_review_feedback(outcomes: list[dict[str, Any]]) -> str:
        """Format test review outcomes into feedback for the implementation agent."""
        if not outcomes:
            return ""
        parts: list[str] = []
        for o in outcomes:
            if o["verdict"] == "accept":
                if o["tests_pass"]:
                    parts.append(
                        f"QA accepted your change request for {o['test_file']} and "
                        f"modified the test. Tests are now passing."
                    )
                else:
                    parts.append(
                        f"QA accepted your change request for {o['test_file']} and "
                        f"modified the test, but tests are still failing. "
                        f"Here's why she accepted: {o['reason']}"
                    )
            else:
                parts.append(
                    f"QA rejected your change request for {o['test_file']}: "
                    f"{o['reason']}. Fix your implementation to match the test."
                )
        return "**Test Review Feedback from QA:**\n" + "\n".join(f"- {p}" for p in parts)

    # --- Escalation handling ---

    def should_surface_escalation(self, severity: str) -> bool:
        """Determine if an escalation should be surfaced to the CEO based on style.

        HANDS_ON: info + needs_decision + blocker (everything)
        BALANCED: needs_decision + blocker
        DELEGATOR: blocker only
        command_request: always surfaced (CEO must approve/deny)
        """
        if severity == "command_request":
            return True
        style = self._gate(CEOGate.ESCALATIONS)
        if style == CEOStyle.HANDS_ON:
            return True
        if style == CEOStyle.BALANCED:
            return severity in ("needs_decision", "blocker")
        # DELEGATOR
        return severity == "blocker"

    def drain_escalations(
        self,
        engine: AgentEngine,
        agent: Persona,
        project_context: str,
        task_description: str,
        interactive: bool,
    ) -> None:
        """Process escalations from the given engine.

        Escalations are filtered by CEO style - non-surfaced ones are
        auto-resolved (silently dropped).

        Interactive: prompts CEO for blockers/decisions via _handle_escalations.
        Non-interactive: displays surfaced escalations, re-queues blocker and
        needs_decision escalations on the engine for post-phase CEO review.
        """
        if interactive:
            self._handle_escalations(agent, project_context, task_description=task_description)
            return

        # Non-interactive (worktree thread): filter, display, keep actionable ones
        all_escs = list(engine.escalations)
        engine.escalations.clear()

        for esc in all_escs:
            if not self.should_surface_escalation(esc["severity"]):
                continue
            _tprint(Panel(
                f"[bold]{agent.name}[/bold] - {escalation_label(esc['severity'])}:\n\n{esc['reason']}",
                title="Escalation",
                style=escalation_style(esc["severity"]),
            ))

        # Re-queue blocker/decision/command_request escalations for main thread
        engine.escalations.extend(
            e for e in all_escs
            if e["severity"] in ("blocker", "needs_decision", "command_request")
            and self.should_surface_escalation(e["severity"])
        )

    def _handle_escalations(
        self,
        agent: Persona,
        project_context: str,
        task_description: str = "",
    ) -> None:
        """Handle any escalations from the last agent invocation.

        Uses the main engine for interactive escalation resolution.
        Filtered by CEO style - non-surfaced escalations are auto-resolved.
        """
        escalations = self._main_engine.get_escalations()
        for esc in escalations:
            if not self.should_surface_escalation(esc["severity"]):
                continue

            console.print(Panel(
                f"[bold]{agent.name}[/bold] - {escalation_label(esc['severity'])}:\n\n{esc['reason']}",
                title="Escalation",
                style=escalation_style(esc["severity"]),
            ))
            if esc["severity"] == "command_request":
                command = esc.get("command", "")
                console.print(f"\n  [bold]Command:[/bold] [cyan]{command}[/cyan]")
                ceo_response = Prompt.ask(
                    "[bold yellow]CEO[/bold yellow] (approve / deny / edit)",
                    default="approve",
                )
                choice = ceo_response.lower().strip()
                if choice == "deny":
                    task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=(
                            f"The CEO denied your request to run: {command}\n\n"
                            f"Find another way to proceed.{task_context}"
                        ),
                        project_context=project_context,
                    )
                else:
                    # "approve" or anything else = treat as the command to run
                    # (typing a different command = edit)
                    cmd_to_run = command if choice in ("approve", "y", "yes", "") else ceo_response
                    output = _run_approved_command(cmd_to_run, self.state.root)
                    console.print(Panel(
                        output[:2000] + ("..." if len(output) > 2000 else ""),
                        title=f"Output: {cmd_to_run}",
                        style="dim",
                    ))
                    task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=(
                            f"The CEO approved and ran your requested command.\n\n"
                            f"$ {cmd_to_run}\n{output}{task_context}\n\n"
                            f"Please continue with your task."
                        ),
                        project_context=project_context,
                    )
            elif esc["severity"] == "blocker":
                ceo_response = Prompt.ask("[bold yellow]CEO[/bold yellow] (blocker - your input needed)")
                task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                self._main_engine.invoke(
                    persona=agent,
                    user_message=f"The CEO responded to your escalation:\n\n{ceo_response}{task_context}\n\nPlease continue with your task.",
                    project_context=project_context,
                )
            elif esc["severity"] == "needs_decision":
                ceo_response = Prompt.ask("[bold yellow]CEO[/bold yellow] (decision needed, or 'skip' to let agent proceed)")
                if ceo_response.lower().strip() != "skip":
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=f"The CEO says:\n\n{ceo_response}",
                        project_context=project_context,
                    )

    # --- Main TDD gate ---

    def execute(
        self,
        engine: AgentEngine,
        agent: Persona,
        task: SprintTask,
        sprint: Sprint,
        impl_prompt: str,
        project_context: str,
        *,
        team: dict[str, Persona] | None = None,
        cwd: Path | None = None,
        stream_cb: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        interactive: bool = True,
        on_test_change_requests: Callable | None = None,
        on_dependency_requests: Callable | None = None,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> None:
        """Shared TDD gate: invoke -> test -> retry loop -> status -> tracking.

        Used by both _run_task (interactive, main branch) and
        _run_task_in_worktree (non-interactive, worktree).

        When interactive=True, team must be provided. Escalations prompt the
        CEO inline, and test-change/dependency requests are routed via the
        provided callbacks.

        When interactive=False, escalations are displayed but blocker/decision
        escalations are re-queued on the engine for post-phase handling.

        Callbacks:
            on_test_change_requests(sprint, team, project_context, cwd=cwd) -> list[dict]
            on_dependency_requests(team, project_context) -> None
        """
        # --- Initial invoke ---
        engine.invoke(
            persona=agent,
            user_message=impl_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
            extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
            stream=stream_cb,
            cancel_check=cancel_check,
            phase="implementation",
            on_tool_result=on_tool_result,
        )

        self.drain_escalations(engine, agent, project_context, task.description, interactive)
        review_feedback = ""
        if interactive and on_test_change_requests and on_dependency_requests:
            outcomes = on_test_change_requests(
                sprint, team, project_context, cwd=cwd,
            )
            review_feedback = self.format_review_feedback(outcomes)
            on_dependency_requests(team, project_context)

        # --- Mechanical TDD gate ---
        passed, test_output = self.run_tests(cwd=cwd)
        max_retries = self.get_max_retries()

        retries = 0
        while not passed and retries < max_retries:
            retries += 1
            if interactive:
                console.print(Panel(
                    f"Tests failing after {agent.name}'s implementation "
                    f"(attempt {retries}/{max_retries})",
                    style="yellow",
                ))
            else:
                _tprint(f"[yellow]  {agent.name}: tests failing, retry {retries}/{max_retries}[/yellow]")

            fix_prompt = self.build_fix_prompt(test_output, review_feedback)
            review_feedback = ""  # Only include once

            engine.invoke(
                persona=agent,
                user_message=fix_prompt,
                project_context=project_context,
                max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
                extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
                stream=stream_cb,
                cancel_check=cancel_check,
                phase="implementation",
                on_tool_result=on_tool_result,
            )

            self.drain_escalations(engine, agent, project_context, task.description, interactive)
            if interactive and on_test_change_requests and on_dependency_requests:
                outcomes = on_test_change_requests(
                    sprint, team, project_context, cwd=cwd,
                )
                review_feedback = self.format_review_feedback(outcomes)
                on_dependency_requests(team, project_context)

            passed, test_output = self.run_tests(cwd=cwd)

        # --- CEO retry extension (interactive only) ---
        if not passed and interactive:
            passed, test_output = self._ceo_retry_extension(
                engine, agent, task, sprint, project_context,
                test_output, review_feedback, max_retries,
                team=team, cwd=cwd, stream_cb=stream_cb, cancel_check=cancel_check,
                on_test_change_requests=on_test_change_requests,
                on_dependency_requests=on_dependency_requests,
                on_tool_result=on_tool_result,
            )

        # --- Status update ---
        if passed:
            task.status = TaskStatus.DONE
            if interactive:
                console.print(f"[green]{agent.name} completed: {task.description} (tests passing)[/green]")
            else:
                _tprint(f"[green]{agent.name} completed: {task.description} (tests passing)[/green]")
        else:
            task.status = TaskStatus.FAILED
            if interactive:
                console.print(f"[red]{agent.name} could not pass tests: {task.description}[/red]")
                engine.escalations.append({
                    "reason": f"Task failed TDD gate after retries: {task.description}",
                    "severity": "heads_up",
                })
            else:
                _tprint(f"[red]{agent.name} could not pass tests: {task.description}[/red]")
                engine.escalations.append({
                    "reason": (
                        f"Task failed TDD gate after {max_retries} retries: "
                        f"{task.description}\n\nLatest output:\n{test_output[:500]}"
                    ),
                    "severity": "needs_decision",
                })

        # Record outcome for consultant reputation tracking
        if agent.role_type == RoleType.CONSULTANT:
            self.state.record_task_outcome(
                name=agent.name,
                sprint_number=sprint.number,
                task_id=task.id,
                task_description=task.description,
                passed=passed,
                retries=retries,
            )

    def _ceo_retry_extension(
        self,
        engine: AgentEngine,
        agent: Persona,
        task: SprintTask,
        sprint: Sprint,
        project_context: str,
        test_output: str,
        review_feedback: str,
        max_retries: int,
        *,
        team: dict[str, Persona] | None = None,
        cwd: Path | None = None,
        stream_cb: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        on_test_change_requests: Callable | None = None,
        on_dependency_requests: Callable | None = None,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> tuple[bool, str]:
        """Prompt CEO for extra retries after the mechanical TDD gate exhausts its limit.

        Returns (passed, test_output) after the extension attempts (or immediately
        if the CEO chooses to fail).
        """
        console.print(Panel(
            f"[bold red]{agent.name}[/bold red] exhausted {max_retries} retries on: "
            f"{task.description}\n\n"
            f"Latest test output:\n[dim]{test_output[:500]}[/dim]",
            title="TDD Gate - Retry Limit Reached",
            style="red",
        ))
        ceo_choice = Prompt.ask(
            "[bold yellow]CEO[/bold yellow]: Keep trying, or mark failed?",
            choices=["retry", "fail"],
            default="fail",
        )
        if ceo_choice != "retry":
            return False, test_output

        try:
            extra = int(Prompt.ask("How many more attempts?", default="2"))
        except ValueError:
            extra = 2
        passed = False
        for _ in range(extra):
            fix_prompt = self.build_fix_prompt(test_output, review_feedback)
            review_feedback = ""
            engine.invoke(
                persona=agent,
                user_message=fix_prompt,
                project_context=project_context,
                max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
                extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
                stream=stream_cb,
                cancel_check=cancel_check,
                phase="implementation",
                on_tool_result=on_tool_result,
            )
            self.drain_escalations(engine, agent, project_context, task.description, True)
            if on_test_change_requests and on_dependency_requests:
                outcomes = on_test_change_requests(
                    sprint, team, project_context, cwd=cwd,
                )
                review_feedback = self.format_review_feedback(outcomes)
                on_dependency_requests(team, project_context)
            passed, test_output = self.run_tests(cwd=cwd)
            if passed:
                break
        return passed, test_output
