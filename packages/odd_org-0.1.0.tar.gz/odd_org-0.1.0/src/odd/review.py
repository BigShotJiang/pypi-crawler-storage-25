"""Code review engine - the prodigy/junior review pattern."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from odd.agent import AgentEngine
from odd.config import (
    CODE_REVIEW_NUDGE_INTERVAL,
    CODE_REVIEW_THRESHOLD,
    MAX_REVIEW_PASSES,
    PHASE_TOKEN_DEFAULTS,
)
from odd.git import GitManager
from odd.models import (
    CEOStyle,
    CodeReview,
    CodeReviewPass,
    Persona,
    RoleType,
    Sprint,
)
from odd.parsers import parse_code_review
from odd.state import StateManager
from odd.tools import SUBMIT_CODE_REVIEW


console = Console()


def should_nudge_review(state: StateManager, sprint_number: int, config=None) -> tuple[bool, str]:
    """Check if Cody should recommend a code review."""
    if config is None:
        config = state.load_config()
    sprints_since = sprint_number - config.last_review_sprint
    if sprints_since >= CODE_REVIEW_NUDGE_INTERVAL:
        return True, (
            f"It's been {sprints_since} sprints since the last code review. "
            f"Technical debt might be piling up - I'd recommend at least a quick pass."
        )
    return False, ""


def offer_code_review(
    state: StateManager,
    sprint_number: int,
    lead_dev: Persona,
    ceo_style: CEOStyle = CEOStyle.BALANCED,
    is_milestone: bool = False,
) -> int:
    """Determine how many review passes to run this sprint.

    Returns 0 (skip) or a positive int (number of passes).

    The CEO sets a default pass count at init (config.review_passes).
    CEO style controls whether they get a chance to adjust:
    - HANDS_ON: always asks CEO to confirm/adjust pass count
    - BALANCED: auto-runs at default; asks on milestones or nudge
    - DELEGATOR: auto-runs silently at default
    """
    config = state.load_config()
    default_passes = config.review_passes
    should_nudge, nudge_msg = should_nudge_review(state, sprint_number, config=config)

    # --- DELEGATOR: run silently at default, bump to 1 on nudge if at 0 ---
    if ceo_style == CEOStyle.DELEGATOR:
        if default_passes == 0 and should_nudge:
            console.print(f"[dim]Auto-running 1-pass review (delegator mode): {nudge_msg}[/dim]")
            return 1
        if default_passes > 0:
            console.print(f"[dim]Running {default_passes}-pass review.[/dim]")
        return default_passes

    # --- BALANCED: auto-run at default; only ask on milestones or nudge ---
    if ceo_style == CEOStyle.BALANCED:
        if not is_milestone and not should_nudge:
            if default_passes > 0:
                console.print(f"[dim]Running {default_passes}-pass review.[/dim]")
            return default_passes

        # Milestone or nudge - give CEO a chance to adjust
        if should_nudge:
            console.print(Panel(
                f"[bold]Cody:[/bold] {nudge_msg}",
                style="blue",
            ))
        suggestion = max(default_passes, 2) if is_milestone else default_passes
        return _ask_pass_count(default=suggestion)

    # --- HANDS_ON: always ask ---
    if should_nudge:
        console.print(Panel(
            f"[bold]Cody:[/bold] {nudge_msg}",
            style="blue",
        ))
    return _ask_pass_count(default=default_passes)


def _ask_pass_count(default: int) -> int:
    """Prompt CEO for review pass count."""
    choice = Prompt.ask(
        f"\nReview passes (0 to skip, max {MAX_REVIEW_PASSES})",
        default=str(default),
    )
    try:
        n = int(choice)
        return min(max(n, 0), MAX_REVIEW_PASSES)
    except ValueError:
        return default


def run_code_review(
    engine: AgentEngine,
    state: StateManager,
    git: GitManager,
    sprint: Sprint,
    lead_dev: Persona,
    passes: int,
    project_context: str,
) -> CodeReview:
    """The prodigy/junior review loop.

    An anonymous prodigy reviews the code, scores it 1-10, writes review.md.
    Cody reads review.md and fixes issues. Loop until score >= threshold
    or max passes reached.
    """
    max_passes = max(passes, 1)
    # Map pass count to a depth label for the record
    if max_passes <= 1:
        depth = "quick"
    elif max_passes <= 2:
        depth = "standard"
    else:
        depth = "thorough"
    review = CodeReview(
        sprint_number=sprint.number,
        depth=depth,
        max_passes=max_passes,
    )

    review_path = f".odd/sprints/sprint_{sprint.number}/review.md"

    # Get the diff for the reviewer to look at
    diff_summary = git.get_sprint_diff_summary(sprint.number)

    for pass_num in range(1, max_passes + 1):
        console.print(Panel(
            f"Code review pass {pass_num}/{max_passes}...",
            style="magenta",
        ))

        # --- Prodigy reviews ---
        review_pass = _prodigy_review(
            engine, sprint, pass_num, diff_summary, review_path, project_context,
        )
        review.passes.append(review_pass)

        console.print(Panel(
            f"Score: [bold]{review_pass.score}/10[/bold]\n"
            f"Findings: {len(review_pass.findings)}",
            title=f"Review Pass {pass_num}",
            style="magenta",
        ))

        # Check if we can stop
        if review_pass.score >= CODE_REVIEW_THRESHOLD and not review_pass.has_critical:
            console.print(f"[green]Code review passed ({review_pass.score}/10).[/green]")
            break

        if pass_num >= max_passes:
            console.print(f"[yellow]Review cap reached. Final score: {review_pass.score}/10.[/yellow]")
            break

        # --- Cody fixes ---
        console.print(Panel("Cody is addressing review findings...", style="blue"))
        engine.invoke(
            persona=lead_dev,
            user_message=(
                f"The code review found issues. Here is the review:\n\n"
                f"Read {review_path} for the full details.\n\n"
                f"Address each finding. Focus on critical and major issues first. "
                f"Run the tests after your fixes to make sure nothing is broken."
            ),
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["code_review_fix"],
            phase="review",
        )
        console.print("[blue]Cody has addressed the review findings.[/blue]")

        # Update diff for next review pass
        diff_summary = git.get_sprint_diff_summary(sprint.number)

    review.final_score = review.passes[-1].score if review.passes else None
    sprint.code_review = review
    state.save_sprint(sprint)
    state.save_code_review(sprint.number, review)

    # Update last review sprint
    config = state.load_config()
    config.last_review_sprint = sprint.number
    state.save_config(config)

    return review


def _prodigy_review(
    engine: AgentEngine,
    sprint: Sprint,
    pass_number: int,
    diff_summary: str,
    review_path: str,
    project_context: str,
) -> CodeReviewPass:
    """A single prodigy review pass - anonymous, disposable, critical."""
    prodigy = Persona(
        role_type=RoleType.CONSULTANT,
        name="Reviewer",
        title="Code Reviewer",
        job_description=(
            "You are a prodigy software developer - quite simply the best in "
            "the business. You have been brought in to review the work of a "
            "junior developer. You are thorough, critical, and miss nothing.\n\n"
            "Review the code for:\n"
            "- Bugs and logic errors\n"
            "- Security vulnerabilities\n"
            "- Performance issues\n"
            "- Code smells and anti-patterns\n"
            "- Error handling gaps\n"
            "- Edge cases not covered\n"
            "- Naming and readability issues\n"
            "- Unnecessary complexity\n"
            "- Missing or misleading comments\n"
            "- Violations of the project's patterns and conventions\n\n"
            "IMPORTANT: Evaluate the code on its merits. Score it 1-10. List "
            "findings by severity (critical, major, minor, style). Do NOT "
            "reference the author's experience level - only discuss the quality "
            "of the work itself.\n\n"
            "Use the submit_code_review tool to submit your review.\n\n"
            "Fallback format (if you can't use the tool):\n"
            "SCORE: <1-10>\n"
            "FINDING: [severity] description\n"
            "...\n\n"
            f"Also write your full review to {review_path} so the team can read it."
        ),
    )

    diff_context = ""
    if diff_summary:
        diff_context = (
            f"\n\nHere is what changed this sprint:\n\n{diff_summary}\n\n"
            f"Read the actual files to review the code in full."
        )

    review_prompt = (
        f"Sprint {sprint.number} goal: {sprint.goal}\n\n"
        f"Review pass {pass_number}. "
        f"{'This is the initial review.' if pass_number == 1 else 'Previous issues should have been fixed. Look again with fresh eyes.'}"
        f"{diff_context}"
    )

    response = engine.invoke(
        persona=prodigy,
        user_message=review_prompt,
        project_context=project_context,
        tools=True,
        extra_tools=[SUBMIT_CODE_REVIEW],
        max_tokens=PHASE_TOKEN_DEFAULTS["code_review"],
        phase="review",
    )

    submissions = engine.pop_submissions("submit_code_review")
    structured = submissions[0]["data"] if submissions else None
    return parse_code_review(response, pass_number, structured_data=structured)
