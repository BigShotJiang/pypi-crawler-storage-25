"""Human-friendly labels for internal enums and codes.

Everything the CEO sees passes through here. No snake_case, no model IDs,
no developer jargon - just plain language.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from odd.models import ModelTier


# --- Model tiers -----------------------------------------------------------

MODEL_TIER_LABELS: dict[str, str] = {
    "HIGH": "Premium (Opus)",
    "STANDARD": "Standard (Sonnet)",
    "FAST": "Fast (Haiku)",
}

# --- Compensation flavor text ------------------------------------------------
# Pure CEO-facing commentary. Agents never see this. It's just funny.

_COMP_PACKAGE: dict[str, str] = {
    "HIGH": "Executive compensation package",
    "STANDARD": "Competitive market-rate salary",
    "FAST": "We appreciate your flexibility on comp",
}

_COMP_UPGRADE: dict[tuple[str, str], str] = {
    # (from, to) -> quip
    ("FAST", "STANDARD"): "The board has approved a market adjustment. You've earned it.",
    ("FAST", "HIGH"): "From intern wages to the C-suite. What a quarter.",
    ("STANDARD", "HIGH"): "You've been doing such great work lately. The raise is effective immediately.",
}

_COMP_DOWNGRADE: dict[tuple[str, str], str] = {
    ("HIGH", "STANDARD"): "Times are tough for the company right now, but keep up the good work.",
    ("HIGH", "FAST"): "We're restructuring. Your title stays the same. Mostly.",
    ("STANDARD", "FAST"): "We're tightening belts across the org. It's not personal, it's fiscal responsibility.",
}

_TIER_RANK = {"FAST": 0, "STANDARD": 1, "HIGH": 2}


def compensation_quip(new_tier: ModelTier, old_tier: ModelTier | None = None) -> str:
    """Return a CEO-facing compensation quip for a tier assignment or change.

    If *old_tier* is None this is a new hire / initial assignment.
    Returns empty string if there's nothing interesting to say.
    """
    if old_tier is None:
        return _COMP_PACKAGE.get(new_tier.name, "")

    if new_tier.name == old_tier.name:
        return ""

    key = (old_tier.name, new_tier.name)
    if _TIER_RANK.get(new_tier.name, 0) > _TIER_RANK.get(old_tier.name, 0):
        return _COMP_UPGRADE.get(key, "A well-deserved raise.")
    return _COMP_DOWNGRADE.get(key, "A temporary adjustment. We're sure they understand.")


def model_tier_label(tier) -> str:
    """Convert a ModelTier enum to a CEO-friendly string like 'Premium (Opus)'."""
    return MODEL_TIER_LABELS.get(tier.name, tier.name)


# --- Sprint status ----------------------------------------------------------

SPRINT_STATUS_LABELS: dict[str, str] = {
    "planning": "Planning",
    "in_progress": "In Progress",
    "review": "Under Review",
    "demo": "Demo",
    "complete": "Complete",
}


def sprint_status_label(status) -> str:
    """Convert a SprintStatus enum to a CEO-friendly string."""
    return SPRINT_STATUS_LABELS.get(status.value, status.value)


# --- Task status ------------------------------------------------------------

TASK_STATUS_LABELS: dict[str, str] = {
    "pending": "Not started",
    "in_progress": "In progress",
    "done": "Done",
    "failed": "Needs attention",
}

TASK_STATUS_ICONS: dict[str, str] = {
    "pending": "○",
    "in_progress": "◔",
    "done": "●",
    "failed": "✗",
}


def task_status_label(status: str) -> str:
    return TASK_STATUS_LABELS.get(status, status)


def task_status_icon(status: str) -> str:
    return TASK_STATUS_ICONS.get(status, "?")


# --- Priority ---------------------------------------------------------------

PRIORITY_LABELS: dict[str, str] = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "nice_to_have": "Nice to Have",
}


def priority_label(priority) -> str:
    """Convert a Priority enum (or string) to a CEO-friendly string."""
    val = priority.value if hasattr(priority, "value") else priority
    return PRIORITY_LABELS.get(val, val)


# --- Escalation severity ---------------------------------------------------

ESCALATION_LABELS: dict[str, str] = {
    "blocker": "\U0001f6a8 Can't continue without you",
    "needs_decision": "\u26a0\ufe0f Your call",
    "heads_up": "\u2139\ufe0f FYI",
    "command_request": "\U0001f510 Requesting elevated access",
}

ESCALATION_STYLES: dict[str, str] = {
    "blocker": "bold red",
    "needs_decision": "yellow",
    "heads_up": "cyan",
    "command_request": "bold magenta",
}


def escalation_label(severity: str) -> str:
    return ESCALATION_LABELS.get(severity, severity)


def escalation_style(severity: str) -> str:
    return ESCALATION_STYLES.get(severity, "yellow")


# --- Role types -------------------------------------------------------------

ROLE_LABELS: dict[str, str] = {
    "lead_dev": "Lead Developer",
    "qa": "QA Engineer",
    "recruiter": "Recruiter",
    "secretary": "Secretary",
    "consultant": "Consultant",
}


def role_label(role) -> str:
    """Convert a RoleType enum (or string) to a CEO-friendly string."""
    val = role.value if hasattr(role, "value") else role
    return ROLE_LABELS.get(val, val)


# --- Model config choices (numbered list for CEO) ---------------------------

MODEL_CONFIG_CHOICES = [
    ("1", "Premium (Opus)", "opus"),
    ("2", "Standard (Sonnet)", "sonnet"),
    ("3", "Fast (Haiku)", "haiku"),
]


def format_model_choices() -> str:
    """Return a formatted string of model choices for display."""
    return "\n".join(f"    {num}. {label}" for num, label, _ in MODEL_CONFIG_CHOICES)


def resolve_model_choice(choice: str) -> str:
    """Resolve a numbered choice or raw name to a model key (opus/sonnet/haiku)."""
    for num, _, key in MODEL_CONFIG_CHOICES:
        if choice == num or choice.lower() == key:
            return key
    return choice.lower()
