"""Health checks for the .odd/ directory.

Detects inconsistencies (empty files, missing personas, broken JSON, orphaned
directories) and repairs what it can.  Called automatically when `odd` launches.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from odd.config import (
    ARCHIVED_DIR_NAME,
    CONFIG_FILE,
    CONSULTANTS_DIR_NAME,
    CORE_TEAM_ROLES,
    JOB_DESCRIPTION_FILE,
    PERSONA_FILE,
    RESUME_FILE,
    SPRINT_FILE,
)


@dataclass
class Issue:
    """A single detected problem."""

    path: Path
    description: str
    repaired: bool = False
    repair_detail: str = ""


@dataclass
class HealthReport:
    """Result of a full health check."""

    issues: list[Issue] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return len(self.issues) == 0

    @property
    def all_repaired(self) -> bool:
        return all(i.repaired for i in self.issues)


def check_and_repair(odd_dir: Path) -> HealthReport:
    """Run all checks and auto-repair what we can. Returns the report."""
    report = HealthReport()

    if not odd_dir.exists() or not (odd_dir / CONFIG_FILE).exists():
        return report  # not initialized, nothing to check

    _check_config(odd_dir, report)
    _check_core_team(odd_dir, report)
    _check_consultants(odd_dir, report)
    _check_sprints(odd_dir, report)
    _check_orphan_dirs(odd_dir, report)

    return report


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def _check_config(odd_dir: Path, report: HealthReport) -> None:
    """Verify config.json is valid."""
    config_path = odd_dir / CONFIG_FILE
    _check_json_file(config_path, report, required=True)


def _check_core_team(odd_dir: Path, report: HealthReport) -> None:
    """Every core role should have a non-empty, parseable persona.json."""
    team_dir = odd_dir / "team"
    if not team_dir.exists():
        return

    for role in CORE_TEAM_ROLES:
        role_dir = team_dir / role
        if not role_dir.exists():
            continue
        persona_path = role_dir / PERSONA_FILE
        _check_persona(persona_path, report, context=f"core team '{role}'")


def _check_consultants(odd_dir: Path, report: HealthReport) -> None:
    """Each consultant dir should have a valid persona.json with resume/JD.

    Broken consultants are auto-removed since they can't function without
    a valid persona.
    """
    consultants_dir = odd_dir / "team" / CONSULTANTS_DIR_NAME
    if not consultants_dir.exists():
        return

    for d in consultants_dir.iterdir():
        if not d.is_dir() or d.name == ARCHIVED_DIR_NAME:
            continue

        persona_path = d / PERSONA_FILE

        # Case 1: directory exists but no persona.json at all
        if not persona_path.exists():
            _report_empty_consultant(d, report, "no persona.json")
            continue

        # Case 2: persona.json exists but is empty
        text = persona_path.read_text(encoding="utf-8").strip()
        if not text:
            _report_empty_consultant(d, report, "empty persona.json")
            continue

        # Case 3: persona.json is corrupt
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            _report_empty_consultant(d, report, "corrupt persona.json")
            continue

        # Case 4: persona.json missing essential fields
        if not data.get("name") or not data.get("role_type"):
            _report_empty_consultant(d, report, "persona.json missing name or role_type")
            continue

        # Case 5: persona parsed but has no JD or resume (incomplete recruit)
        jd = data.get("job_description", "")
        resume = data.get("resume", "")
        if not jd and not resume:
            _report_empty_consultant(d, report, "persona.json has no JD or resume")


def _check_sprints(odd_dir: Path, report: HealthReport) -> None:
    """Each sprint_N dir should have a valid sprint.json."""
    sprints_dir = odd_dir / "sprints"
    if not sprints_dir.exists():
        return

    for d in sorted(sprints_dir.iterdir()):
        if not d.is_dir() or not d.name.startswith("sprint_"):
            continue
        sprint_path = d / SPRINT_FILE
        _check_json_file(sprint_path, report)


def _check_orphan_dirs(odd_dir: Path, report: HealthReport) -> None:
    """Look for unexpected top-level entries in .odd/."""
    expected_top = {"team", "sprints", "notes", "financials", "logs"}
    # Also allow known files
    known_files = {
        CONFIG_FILE, "roadmap.json", "backlog.json", "budget.json",
        "ledger.json", "values.json", "pricing.json",
        "vacation_plan.json", "vacation_report.json", "traces",
    }

    for entry in odd_dir.iterdir():
        if entry.name.startswith("."):
            continue
        if entry.is_dir() and entry.name not in expected_top:
            report.issues.append(Issue(
                path=entry,
                description=f"Unexpected directory '.odd/{entry.name}/'",
            ))
        elif entry.is_file() and entry.name not in known_files:
            report.issues.append(Issue(
                path=entry,
                description=f"Unexpected file '.odd/{entry.name}'",
            ))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _check_json_file(path: Path, report: HealthReport, required: bool = False) -> bool:
    """Check that a JSON file exists and parses. Returns True if healthy."""
    if not path.exists():
        if required:
            report.issues.append(Issue(
                path=path,
                description=f"Required file missing: {path.name}",
            ))
        return False

    text = path.read_text(encoding="utf-8").strip()
    if not text:
        report.issues.append(Issue(
            path=path,
            description=f"File is empty: {path.name}",
        ))
        return False

    try:
        json.loads(text)
        return True
    except json.JSONDecodeError as e:
        report.issues.append(Issue(
            path=path,
            description=f"Invalid JSON in {path.name}: {e}",
        ))
        return False


def _check_persona(path: Path, report: HealthReport, context: str) -> bool:
    """Verify a persona.json is present, non-empty, and valid. Returns True if OK."""
    if not path.exists():
        report.issues.append(Issue(
            path=path,
            description=f"Missing persona.json for {context}",
        ))
        return False

    text = path.read_text(encoding="utf-8").strip()
    if not text:
        report.issues.append(Issue(
            path=path,
            description=f"Empty persona.json for {context}",
        ))
        return False

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        report.issues.append(Issue(
            path=path,
            description=f"Corrupt persona.json for {context}: {e}",
        ))
        return False

    # Must have at minimum a name and role_type
    if not data.get("name") or not data.get("role_type"):
        report.issues.append(Issue(
            path=path,
            description=f"Incomplete persona.json for {context}: missing name or role_type",
        ))
        return False

    return True


def _report_empty_consultant(consultant_dir: Path, report: HealthReport, reason: str) -> None:
    """Report and auto-remove a broken consultant directory."""
    shutil.rmtree(consultant_dir)
    report.issues.append(Issue(
        path=consultant_dir,
        description=f"Broken consultant '{consultant_dir.name}': {reason}",
        repaired=True,
        repair_detail=f"Removed empty directory",
    ))
