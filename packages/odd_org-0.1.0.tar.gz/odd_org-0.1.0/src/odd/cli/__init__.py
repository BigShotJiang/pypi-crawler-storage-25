"""ODD CLI - the CEO's interface to their organization."""

from __future__ import annotations

import random
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Prompt

from odd.agent import AgentEngine, BudgetExceededError  # noqa: F401
from odd.provider import StreamCallback, StreamEvent, StreamEventType
from odd.spinner import ThinkingSpinner
from odd.cfo import CFO
from odd.config import CORE_TEAM_ROLES  # noqa: F401
from odd.menu import interactive_menu
from odd.models import Persona, ProviderConfig
from odd.state import StateManager
from odd.values import CompanyValues


console = Console()

CLOSING_REMARKS = [
    "Have a great evening!",
    "See you tomorrow, boss.",
    "The team's heading out. Have a good night!",
    "Lights off, doors locked. See you next time!",
    "Another productive day. Enjoy your evening!",
    "The office is closing up. Take care!",
    "Clocking out. Don't work too late!",
    "That's a wrap for today. Have a nice evening!",
    "The team says goodnight!",
    "Meeting adjourned. Go enjoy your evening!",
]


class OddGroup(click.Group):
    """Custom group that prints a friendly closing remark on Ctrl+C."""

    def invoke(self, ctx):
        try:
            return super().invoke(ctx)
        except (KeyboardInterrupt, click.Abort):
            console.print(f"\n[bold yellow]{random.choice(CLOSING_REMARKS)}[/bold yellow]")
            ctx.exit(0)


def _get_state() -> StateManager:
    return StateManager(Path.cwd())


def _get_cfo(state: StateManager) -> CFO:
    return CFO(state.odd_dir)


def _get_values(state: StateManager) -> CompanyValues:
    return CompanyValues(state.odd_dir)


def _cody_stream_factory(agent_name: str) -> StreamCallback | None:
    """Stream agent output to console with a thinking spinner.

    Cody (Lead Dev) gets full text streaming. All other agents get a
    spinner so the CEO knows something is happening, but their raw
    output is suppressed (it's consumed programmatically).
    """
    verbose = agent_name == "Cody"

    _SPINNER_MESSAGES = {
        "Scout": "Scout is looking for the perfect candidate...",
    }
    spinner = ThinkingSpinner(agent_name, console, message=_SPINNER_MESSAGES.get(agent_name))
    spinner.start()

    _last_was_text = False

    def _on_event(event: StreamEvent) -> None:
        nonlocal _last_was_text
        if event.event_type == StreamEventType.TEXT_DELTA:
            if verbose:
                spinner.stop()
                console.print(event.text, end="", highlight=False)
                _last_was_text = True
        elif event.event_type == StreamEventType.TOOL_USE_START:
            if verbose:
                spinner.stop()
                prefix = "\n" if _last_was_text else ""
                console.print(
                    f"{prefix}[dim]  ↳ {agent_name} → {event.tool_name}[/dim]",
                    highlight=False,
                )
                _last_was_text = False
        elif event.event_type == StreamEventType.MESSAGE_STOP:
            spinner.stop()
            if verbose:
                console.print()
                _last_was_text = False

    return _on_event


def _get_engine(state: StateManager, sprint: int | None = None) -> AgentEngine:
    from odd.providers import resolve_provider
    from odd.tracing import init_tracing

    init_tracing(state.odd_dir)

    config = state.load_config()
    provider_config = config.provider

    # CLI overrides take precedence over saved config
    cli_debug = False
    ctx = click.get_current_context(silent=True)
    if ctx and ctx.obj:
        cli_debug = ctx.obj.get("debug", False)
        pname = ctx.obj.get("provider_name")
        burl = ctx.obj.get("base_url")
        if pname:
            provider_config = ProviderConfig(
                name=pname,
                api_key_env=_default_api_key_env(pname),
                base_url=burl or provider_config.base_url,
                model_map=provider_config.model_map,
            )
        elif burl:
            provider_config = provider_config.model_copy(update={"base_url": burl})

    provider = resolve_provider(provider_config)
    cfo = _get_cfo(state)
    values = _get_values(state)
    return AgentEngine(
        provider=provider,
        cfo=cfo,
        current_sprint=sprint,
        company_values=values.system_prompt_fragment(),
        default_stream_factory=_cody_stream_factory,
        debug=config.debug or cli_debug,
    )


def _print_cost_footer(cfo: CFO) -> None:
    """Print a one-line cost summary after any command that made API calls."""
    footer = cfo.cost_footer()
    if footer:
        console.print(f"\n[dim]{footer}[/dim]")


def _default_api_key_env(provider_name: str) -> str:
    """Return the conventional env var for a provider."""
    if provider_name == "openai-compat":
        return "OPENAI_API_KEY"
    if provider_name == "openwebui":
        return "OPENWEBUI_API_KEY"
    return "ANTHROPIC_API_KEY"


def _require_init(state: StateManager) -> None:
    if not state.is_initialized():
        console.print("[red]Not an ODD project. Run 'odd init' first.[/red]")
        raise SystemExit(1)


def _load_team(state: StateManager) -> dict[str, Persona]:
    """Load the full team including consultants."""
    team = {}
    for role in CORE_TEAM_ROLES:
        try:
            team[role] = state.load_persona(role)
        except FileNotFoundError:
            pass

    for consultant in state.list_consultants():
        team[consultant.name.lower().replace(" ", "_")] = consultant

    return team


@click.group(cls=OddGroup, invoke_without_command=True)
@click.option("--provider", "provider_name", default=None, help="Provider: anthropic (default), openai-compat, or openwebui")
@click.option("--base-url", default=None, help="Base URL for openai-compat provider")
@click.option("--debug", is_flag=True, default=False, help="Enable debug logging (agent calls, tool executions)")
@click.pass_context
def main(ctx, provider_name: str | None, base_url: str | None, debug: bool):
    """ODD - Organization Driven Development.

    You are the CEO. Your AI team builds what you envision.
    """
    ctx.ensure_object(dict)
    ctx.obj["provider_name"] = provider_name
    ctx.obj["base_url"] = base_url
    ctx.obj["debug"] = debug

    if debug:
        import logging
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            datefmt="%H:%M:%S",
        )
        # Focus on ODD logs, keep third-party quiet
        logging.getLogger("odd").setLevel(logging.DEBUG)
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("anthropic").setLevel(logging.INFO)

    if ctx.invoked_subcommand is None:
        interactive_menu(ctx, main)


@main.command()
def debug():
    """Run ODD in debug mode (same as odd --debug)."""
    import logging

    ctx = click.get_current_context()
    ctx.obj["debug"] = True

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("odd").setLevel(logging.DEBUG)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("anthropic").setLevel(logging.INFO)

    console.print("[bold yellow]Debug mode enabled.[/bold yellow]")
    interactive_menu(ctx, main)


@main.command()
def init():
    """Initialize a new ODD project. The lead dev will have a conversation with you."""
    from odd.commands.init_cmd import run_init

    state = _get_state()
    run_init(state, _get_engine, _get_cfo)


if __name__ == "__main__":
    main()


# Register submodule commands with the main group
from odd.cli import sprint_cmds, team_cmds, config_cmds, misc_cmds, vacation_cmds  # noqa: F401, E402
