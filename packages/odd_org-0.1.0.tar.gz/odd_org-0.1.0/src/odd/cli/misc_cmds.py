"""Miscellaneous CLI commands."""

from __future__ import annotations

import click
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

import odd.cli as _cli
from odd.cli import console, main
from odd.backlog import Backlog, Priority
from odd.config import DEFAULT_BETA_TESTER_COUNT
from odd.labels import priority_label
from odd.processes import (
    generate_performance_review,
    run_beta_test,
    run_retrospective,
    run_spike,
)


@main.command(name="beta-test")
@click.option("--count", "-n", type=int, default=None, help="Number of beta testers (prompted if omitted)")
def beta_test(count: int | None):
    """Get user feedback - Cody picks the testers and runs them."""
    state = _cli._get_state()
    _cli._require_init(state)

    if count is None:
        count = int(Prompt.ask("How many beta testers?", default=str(DEFAULT_BETA_TESTER_COUNT)))

    config = state.load_config()
    engine = _cli._get_engine(state)
    lead_dev = state.load_persona("lead_dev")
    recruiter = state.load_persona("recruiter")

    project_context = f"Project: {config.name}\nDescription: {config.description}"

    synthesis = run_beta_test(engine, state, lead_dev, recruiter, count, project_context)
    console.print(Panel(Markdown(synthesis), title="Beta Test - Synthesis", style="bold green"))
    _cli._print_cost_footer(engine.cfo)


@main.command()
def retro():
    """Run a sprint retrospective - the team reflects and improves."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    if not config.current_sprint:
        console.print("[yellow]No sprints completed yet.[/yellow]")
        return

    engine = _cli._get_engine(state, sprint=config.current_sprint)
    team = _cli._load_team(state)
    sprint = state.load_sprint(config.current_sprint)
    secretary = team["secretary"]

    console.print(Panel(f"[bold]Retrospective - Sprint {sprint.number}[/bold]", style="cyan"))
    summary = run_retrospective(engine, state, sprint, team, secretary)
    console.print(Panel(Markdown(summary), title="Retrospective Summary", style="cyan"))
    _cli._print_cost_footer(engine.cfo)


@main.command()
@click.argument("topic")
def spike(topic: str):
    """Research spike - investigate before committing to build."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    engine = _cli._get_engine(state)
    lead_dev = state.load_persona("lead_dev")

    project_context = f"Project: {config.name}\nDescription: {config.description}"
    console.print("[bold blue]Spike Results:[/bold blue]")
    findings = run_spike(engine, lead_dev, topic, project_context)
    # Streaming shows Cody's output live; no need to re-print
    _cli._print_cost_footer(engine.cfo)


@main.command()
def review():
    """Performance review - ROI analysis of all agents."""
    from odd.cfo import CFO

    state = _cli._get_state()
    _cli._require_init(state)

    cfo = CFO(state.odd_dir)
    report = generate_performance_review(cfo, state)
    console.print(Panel(Markdown(report), title="Performance Review", style="yellow"))


@main.command(name="add-backlog")
@click.argument("description")
@click.option("--priority", "-p", type=click.Choice(["critical", "high", "medium", "low", "nice_to_have"]), default="medium")
def add_backlog(description: str, priority: str):
    """Add an item to the backlog."""
    state = _cli._get_state()
    _cli._require_init(state)

    backlog = Backlog(state.odd_dir)
    p = Priority(priority)
    item = backlog.add(description, priority=p)
    console.print(f"[green]Added to backlog:[/green] {item.id} - {description} [{priority_label(p)}]")


@main.command(name="backlog")
def show_backlog():
    """Show the current backlog."""
    state = _cli._get_state()
    _cli._require_init(state)

    backlog = Backlog(state.odd_dir)
    items = backlog.all_items()

    if not items:
        console.print("[dim]Backlog is empty. Use 'odd add-backlog' to add items.[/dim]")
        return

    console.print(Panel("[bold]Product Backlog[/bold]", style="blue"))

    status_icons = {"open": "○", "in_sprint": "◔", "done": "●", "cut": "✗"}
    priority_colors = {"critical": "red", "high": "yellow", "medium": "white", "low": "dim", "nice_to_have": "dim"}

    for item in items:
        icon = status_icons.get(item.status, "?")
        color = priority_colors.get(item.priority.value, "white")
        sprint_info = f" (Sprint {item.sprint_assigned})" if item.sprint_assigned else ""
        console.print(f"  {icon} [{color}]{item.id}: {item.description} [{priority_label(item.priority)}]{sprint_info}[/{color}]")
