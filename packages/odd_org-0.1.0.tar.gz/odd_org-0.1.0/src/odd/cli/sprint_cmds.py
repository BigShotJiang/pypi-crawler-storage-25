"""Sprint-related CLI commands."""

from __future__ import annotations

import click
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

import odd.cli as _cli
from odd.agent import BudgetExceededError
from odd.cli import console, main
from odd.sprint import SprintEngine
from odd.state import StateManager


def _negotiate_sprint_goal(
    state: StateManager,
    sprint_engine: SprintEngine,
    team: dict,
    sprint_number: int,
) -> tuple[str, int]:
    """Determine the sprint goal via roadmap or CEO input.

    Returns (ceo_goal, sprint_number) - sprint_number may change if a
    roadmap assigns a different number.
    """
    ceo_goal: str | None = None

    if state.has_active_roadmap():
        roadmap = state.load_roadmap()
        next_rm_sprint = None
        for rs in roadmap.sprints:
            if rs.status == "pending":
                next_rm_sprint = rs
                break

        if next_rm_sprint:
            console.print(Panel(
                f"[bold]Active Roadmap[/bold] - Sprint {next_rm_sprint.number} of "
                f"{len(roadmap.sprints)}\n\n"
                f"[bold]Goal:[/bold] {roadmap.goal}\n"
                f"[bold]This sprint:[/bold] {next_rm_sprint.deliverables}",
                style="blue",
            ))

            proceed = Prompt.ask(
                "Continue with roadmap?",
                choices=["y", "n", "abandon"],
                default="y",
            )
            if proceed == "abandon":
                state.clear_roadmap()
                console.print("[yellow]Roadmap abandoned.[/yellow]")
            elif proceed == "y":
                ceo_goal = next_rm_sprint.deliverables
                sprint_number = next_rm_sprint.number
                next_rm_sprint.status = "in_progress"
                state.save_roadmap(roadmap)

    if ceo_goal is None:
        console.print("What should the team focus on?")
        ceo_goal = Prompt.ask("[bold yellow]CEO[/bold yellow]")

        if not state.has_active_roadmap():
            roadmap = sprint_engine.plan_roadmap(team["lead_dev"], ceo_goal)
            if roadmap:
                proceed = Prompt.ask(
                    "\nApprove this roadmap?",
                    choices=["y", "n"],
                    default="y",
                )
                if proceed == "y":
                    first = roadmap.sprints[0]
                    ceo_goal = first.deliverables
                    sprint_number = first.number
                    first.status = "in_progress"
                    state.save_roadmap(roadmap)
                    console.print(f"[green]Roadmap saved. Starting sprint {sprint_number}.[/green]")
                else:
                    console.print("[dim]Proceeding as a single sprint.[/dim]")

    return ceo_goal, sprint_number


def _update_roadmap_after_sprint(state: StateManager, sprint_number: int) -> None:
    """Mark the completed sprint in the roadmap and show what's next."""
    if state.has_active_roadmap():
        roadmap = state.load_roadmap()
        for rs in roadmap.sprints:
            if rs.number == sprint_number:
                rs.status = "complete"
                break

        remaining = [rs for rs in roadmap.sprints if rs.status == "pending"]
        if not remaining:
            roadmap.status = "complete"
            console.print(Panel("[bold green]Roadmap complete![/bold green]", style="green"))
        else:
            next_rs = remaining[0]
            console.print(Panel(
                f"[bold]Next up:[/bold] Sprint {next_rs.number} - {next_rs.deliverables}\n\n"
                f"Run [bold]odd sprint[/bold] to continue.",
                style="blue",
            ))
        state.save_roadmap(roadmap)
    else:
        console.print(Panel(
            f"Sprint {sprint_number} complete! Run [bold]odd sprint[/bold] for the next one.",
            style="green",
        ))


def _check_interrupted_sprint(state: StateManager, sprint_number: int) -> tuple[bool, "Sprint | None"]:
    """Check if the given sprint was interrupted and has a resumable checkpoint."""
    from odd.models import SprintStatus
    try:
        existing = state.load_sprint(sprint_number)
        if (
            existing.checkpoint
            and existing.status in (SprintStatus.IN_PROGRESS, SprintStatus.PLANNING)
        ):
            return True, existing
    except FileNotFoundError:
        pass
    return False, None


@main.command()
@click.option("--number", "-n", type=int, default=None, help="Sprint number (auto-increments if omitted)")
@click.option("--unsafe-shell", is_flag=True, default=False, hidden=True, help="Disable command allowlist (dangerous)")
def sprint(number: int | None, unsafe_shell: bool):
    """Start a new sprint. The CEO sets the goal, Cody runs everything."""
    if unsafe_shell:
        import odd.tools.execution as _tools_exec
        _tools_exec._unsafe_shell = True
        console.print("[bold red]WARNING: --unsafe-shell is active. Command allowlist disabled.[/bold red]")
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    sprint_number = number or config.current_sprint + 1

    # Check for interrupted sprint that can be resumed
    interrupted, existing_sprint = _check_interrupted_sprint(state, sprint_number)
    if interrupted and existing_sprint:
        checkpoint = existing_sprint.checkpoint
        stage_desc = checkpoint.stage if checkpoint else "unknown"
        completed_tasks = len(checkpoint.completed_task_ids) if checkpoint else 0
        total_phases = len(existing_sprint.phases)

        console.print(Panel(
            f"[bold yellow]Sprint {sprint_number} was interrupted[/bold yellow] "
            f"after stage: {stage_desc}\n"
            f"  Completed tasks: {completed_tasks}/{len(existing_sprint.tasks)}\n"
            f"  Phases: {total_phases} total\n"
            f"  Goal: {existing_sprint.goal}\n\n"
            f"  [Resume] Continue from where it stopped\n"
            f"  [Restart] Start sprint {sprint_number} over\n"
            f"  [New] Abandon and start sprint {sprint_number + 1}",
            style="yellow",
        ))

        choice = Prompt.ask(
            "What would you like to do?",
            choices=["resume", "restart", "new"],
            default="resume",
        )

        if choice == "resume":
            engine = _cli._get_engine(state, sprint=sprint_number)
            team = _cli._load_team(state)
            sprint_engine = SprintEngine(engine, state)

            try:
                result = sprint_engine.resume_sprint(existing_sprint, team)
                sprint_engine._post_implementation(result, team, sprint_number)
                result.status = SprintStatus.COMPLETE
                state.save_sprint(result)
                config.current_sprint = sprint_number
                state.save_config(config)
            except BudgetExceededError as e:
                console.print(Panel(f"[bold red]BUDGET EXCEEDED[/bold red]\n\n{e}", style="red"))
                console.print("Adjust your budget with [bold]odd budget[/bold] and retry.")
                return
            except KeyboardInterrupt:
                console.print(Panel(
                    "[bold yellow]Sprint interrupted by CEO.[/bold yellow]\n"
                    f"Progress checkpointed. Run [bold]odd sprint[/bold] to resume.",
                    style="yellow",
                ))
                return

            _update_roadmap_after_sprint(state, sprint_number)
            return

        elif choice == "new":
            sprint_number += 1

    engine = _cli._get_engine(state, sprint=sprint_number)
    team = _cli._load_team(state)
    sprint_engine = SprintEngine(engine, state)

    console.print(Panel(
        f"[bold]Sprint {sprint_number}[/bold]\n"
        f"Project: {config.name}",
        style="bold blue",
    ))

    ceo_goal, sprint_number = _negotiate_sprint_goal(
        state, sprint_engine, team, sprint_number,
    )

    # Rebuild engine if sprint number changed from roadmap
    engine = _cli._get_engine(state, sprint=sprint_number)
    sprint_engine = SprintEngine(engine, state)

    try:
        result = sprint_engine.run_full_sprint(team, ceo_goal, sprint_number)
    except BudgetExceededError as e:
        console.print(Panel(f"[bold red]BUDGET EXCEEDED[/bold red]\n\n{e}", style="red"))
        console.print("Adjust your budget with [bold]odd budget[/bold] and retry.")
        return

    _update_roadmap_after_sprint(state, sprint_number)


@main.command()
def standup():
    """Run a team standup - everyone reports progress."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    engine = _cli._get_engine(state, sprint=config.current_sprint)
    team = _cli._load_team(state)

    sprint_engine = SprintEngine(engine, state)

    try:
        current_sprint = state.load_sprint(config.current_sprint)
    except FileNotFoundError:
        console.print("[yellow]No active sprint. Run 'odd sprint' first.[/yellow]")
        return

    console.print(Panel(f"[bold]Standup - Sprint {current_sprint.number}[/bold]", style="cyan"))
    summary = sprint_engine.run_standup(current_sprint, team, team["secretary"])
    console.print(Panel(Markdown(summary), title="Standup Summary", style="cyan"))
    _cli._print_cost_footer(engine.cfo)


# ---------------------------------------------------------------------------
# replay helpers
# ---------------------------------------------------------------------------


def _format_agent_trace(agent_records: list[dict]) -> tuple[dict[str, dict], int, int, int]:
    """Format agent records to the console and return trace stats.

    Returns (agent_summary, total_input, total_output, total_duration).
    """
    total_input = 0
    total_output = 0
    total_duration = 0
    agent_summary: dict[str, dict] = {}

    for r in agent_records:
        if r.get("type") == "escalation":
            sev = r.get("severity", "unknown")
            style = "red" if sev == "blocker" else "yellow" if sev == "needs_decision" else "dim"
            console.print(
                f"  [{style}]ESCALATION[/{style}] [{style}]{r.get('agent', '?')}[/{style}]: "
                f"{r.get('reason', '?')} [{sev}]"
            )
            continue

        agent = r.get("agent", "?")
        model = r.get("model", "?")
        inp = r.get("input_tokens", 0)
        out = r.get("output_tokens", 0)
        tc = r.get("tool_calls", 0)
        iters = r.get("iterations", 0)
        dur = r.get("duration_ms", 0)
        preview = r.get("user_message_preview", "")[:80]

        total_input += inp
        total_output += out
        total_duration += dur

        if agent not in agent_summary:
            agent_summary[agent] = {"calls": 0, "input": 0, "output": 0, "tools": 0}
        agent_summary[agent]["calls"] += 1
        agent_summary[agent]["input"] += inp
        agent_summary[agent]["output"] += out
        agent_summary[agent]["tools"] += tc

        dur_s = f"{dur / 1000:.1f}s" if dur else "?"
        console.print(
            f"  [bold]{agent}[/bold] ({model}) - "
            f"{inp:,}+{out:,} tokens, {tc} tools, {iters} iters, {dur_s}"
        )
        if preview:
            console.print(f"    [dim]{preview}[/dim]")

        if r.get("error"):
            console.print(f"    [red]ERROR: {r['error']}[/red]")

    return agent_summary, total_input, total_output, total_duration


def _format_tool_trace(tool_records: list[dict]) -> None:
    """Format the tool execution log to the console."""
    console.print(f"\n[bold]Tool Execution Log[/bold] ({len(tool_records)} calls)")
    for r in tool_records:
        agent = r.get("agent", "?")
        tool = r.get("tool", "?")
        dur = r.get("duration_ms", 0)
        exit_code = r.get("exit_code")
        status = "[green]OK[/green]" if exit_code in (None, 0) else f"[red]exit={exit_code}[/red]"
        console.print(f"  {agent} → {tool} ({dur}ms) {status}")


def _print_trace_summary(
    agent_summary: dict[str, dict],
    total_input: int,
    total_output: int,
    total_duration: int,
) -> None:
    """Print the aggregated trace summary."""
    if agent_summary:
        console.print(f"\n[bold]Summary[/bold]")
        for agent, s in sorted(agent_summary.items()):
            console.print(
                f"  {agent}: {s['calls']} calls, "
                f"{s['input']:,}+{s['output']:,} tokens, "
                f"{s['tools']} tool uses"
            )
        console.print(
            f"\n  [bold]Total:[/bold] {total_input:,}+{total_output:,} tokens, "
            f"{total_duration / 1000:.1f}s wall time"
        )


@main.command()
@click.option("--sprint", "-s", type=int, default=None, help="Sprint number (default: latest)")
@click.option("--tools", is_flag=True, default=False, help="Include tool-level audit log")
def replay(sprint: int | None, tools: bool):
    """Replay the trace log - see what every agent did and why.

    Shows agent API calls, tool usage, token costs, and escalations
    from the last sprint (or a specific sprint with --sprint N).
    """
    from odd.tracing import load_sprint_trace

    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    sprint_number = sprint or config.current_sprint

    if not sprint_number:
        console.print("[yellow]No sprints yet. Run 'odd sprint' first.[/yellow]")
        return

    # Load from unified activity log, filtering by record type
    api_records = load_sprint_trace(state.odd_dir, sprint_number, record_type="api_call")
    escalation_records = load_sprint_trace(state.odd_dir, sprint_number, record_type="escalation")
    agent_records = api_records + escalation_records
    # Sort by timestamp so interleaved events display in order
    agent_records.sort(key=lambda r: r.get("ts", ""))
    tool_records = load_sprint_trace(state.odd_dir, sprint_number, record_type="tool_use") if tools else []

    if not agent_records and not tool_records:
        console.print(f"[yellow]No trace logs found for sprint {sprint_number}. Run a sprint with tracing enabled.[/yellow]")
        return

    console.print(Panel(f"[bold]Sprint {sprint_number} - Agent Trace[/bold]", style="cyan"))

    agent_summary, total_input, total_output, total_duration = _format_agent_trace(agent_records)

    if tools and tool_records:
        _format_tool_trace(tool_records)

    _print_trace_summary(agent_summary, total_input, total_output, total_duration)
