"""Team-related CLI commands."""

from __future__ import annotations

import click
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

import odd.cli as _cli
from odd.cli import console, main
from odd.config import CORE_TEAM_ROLES
from odd.labels import model_tier_label
from odd.processes import enrich_context_with_experience, generate_onboarding_brief, run_one_on_one


@main.command()
def team():
    """Show the current team roster."""
    state = _cli._get_state()
    _cli._require_init(state)

    console.print(Panel("[bold]Your Team[/bold]", style="blue"))

    for role in CORE_TEAM_ROLES:
        try:
            persona = state.load_persona(role)
            console.print(f"  • [bold]{persona.name}[/bold] - {persona.title} ({model_tier_label(persona.effective_model())})")
        except FileNotFoundError:
            pass

    consultants = state.list_consultants()
    if consultants:
        console.print("\n  [bold]Consultants:[/bold]")
        for c in consultants:
            record = state.load_consultant_record(c.name)
            console.print(
                f"    • [bold]{c.name}[/bold] - {c.title} "
                f"({model_tier_label(c.effective_model())})"
            )
            if record.outcomes:
                console.print(f"      {record.summary()}")
    else:
        console.print("\n  [dim]No consultants hired yet.[/dim]")


@main.command()
@click.argument("description", required=False, default=None)
def hire(description: str | None):
    """Hire a new consultant.

    If you know exactly what you need, pass a description directly:
        odd hire "DevOps engineer with AWS and Terraform experience"

    Otherwise, just run 'odd hire' and the Lead Dev will help you figure it out.
    """
    from odd.commands.hire_cmd import run_hire

    state = _cli._get_state()
    _cli._require_init(state)
    engine = _cli._get_engine(state)
    run_hire(engine, state, description, _cli._print_cost_footer)


@main.command()
@click.argument("name")
def fire(name: str):
    """Let a consultant go. Their files are archived but they won't be assigned new work."""
    state = _cli._get_state()
    _cli._require_init(state)

    consultants = state.list_consultants()
    match = None
    for c in consultants:
        if c.name.lower() == name.lower() or name.lower() in c.name.lower():
            match = c
            break

    if not match:
        console.print(f"[red]No consultant found matching '{name}'.[/red]")
        console.print("Current consultants:")
        for c in consultants:
            console.print(f"  • {c.name}")
        return

    confirm = Prompt.ask(
        f"Let [bold]{match.name}[/bold] go?",
        choices=["y", "n"],
        default="n",
    )
    if confirm != "y":
        console.print("[dim]Cancelled.[/dim]")
        return

    state.archive_consultant(match.name)
    console.print(f"[yellow]{match.name} has been let go.[/yellow]")
    console.print("[dim]Their files have been archived.[/dim]")


# ---------------------------------------------------------------------------
# CEO shortcut commands - talk to anyone by first letter
# ---------------------------------------------------------------------------

_CORE_SHORTCUTS: dict[str, tuple[str, str]] = {
    "d": ("lead_dev", "Cody - Lead Developer"),
    "v": ("qa", "Vera - QA Engineer"),
    "s": ("recruiter", "Scout - Recruiter"),
    "p": ("secretary", "Paige - Secretary"),
}


def _talk_to_core(role_key: str, label: str, message: tuple[str, ...], model: str | None = None) -> None:
    """Shared logic for single-letter core-team shortcuts."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    engine = _cli._get_engine(state)
    persona = state.load_persona(role_key)

    project_context = f"Project: {config.name}\nSprint: {config.current_sprint}"
    msg = " ".join(message) if message else None
    run_one_on_one(engine, persona, project_context, message=msg, model_override=model)
    _cli._print_cost_footer(engine.cfo)


@main.command(name="d")
@click.argument("message", nargs=-1)
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def talk_cody(message: tuple[str, ...], model: str | None):
    """Talk to Cody (Lead Developer)."""
    _talk_to_core("lead_dev", "Cody", message, model=model)


@main.command(name="v")
@click.argument("message", nargs=-1)
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def talk_vera(message: tuple[str, ...], model: str | None):
    """Talk to Vera (QA Engineer)."""
    _talk_to_core("qa", "Vera", message, model=model)


@main.command(name="s")
@click.argument("message", nargs=-1)
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def talk_scout(message: tuple[str, ...], model: str | None):
    """Talk to Scout (Recruiter)."""
    _talk_to_core("recruiter", "Scout", message, model=model)


@main.command(name="p")
@click.argument("message", nargs=-1)
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def talk_paige(message: tuple[str, ...], model: str | None):
    """Talk to Paige (Secretary)."""
    _talk_to_core("secretary", "Paige", message, model=model)


@main.command(name="b")
@click.argument("message", nargs=-1)
def talk_bill(message: tuple[str, ...]):
    """Talk to Bill (CFO). Shows financial report, or answers a question."""
    state = _cli._get_state()
    _cli._require_init(state)

    cfo = _cli._get_cfo(state)
    report = cfo.financial_report()
    console.print(Panel(Markdown(report), title="Bill the CFO", style="yellow"))


@main.command(name="c")
@click.argument("letter")
@click.argument("message", nargs=-1)
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def talk_consultant(letter: str, message: tuple[str, ...], model: str | None):
    """Talk to a consultant by first letter of their name.

    Example: odd c m "review this schema"
    """
    state = _cli._get_state()
    _cli._require_init(state)

    consultants = state.list_consultants()
    if not consultants:
        console.print("[red]No consultants on the team. Use 'odd hire' first.[/red]")
        return

    # Match by first letter (case-insensitive)
    letter = letter.lower()
    matches = [c for c in consultants if c.name.lower().startswith(letter)]

    if not matches:
        console.print(f"[red]No consultant whose name starts with '{letter}'.[/red]")
        console.print("Current consultants:")
        for c in consultants:
            console.print(f"  [bold]{c.name[0].lower()}[/bold] - {c.name} ({c.title})")
        return

    if len(matches) > 1:
        console.print(f"[yellow]Multiple consultants match '{letter}':[/yellow]")
        for c in matches:
            console.print(f"  • {c.name} ({c.title})")
        console.print("Use more of the name to disambiguate, e.g. 'odd c ma'")
        return

    persona = matches[0]
    config = state.load_config()
    engine = _cli._get_engine(state)
    project_context = f"Project: {config.name}\nSprint: {config.current_sprint}"
    project_context = enrich_context_with_experience(state, persona, project_context)
    msg = " ".join(message) if message else None
    run_one_on_one(engine, persona, project_context, message=msg, model_override=model)
    _cli._print_cost_footer(engine.cfo)


@main.command(name="1on1")
@click.argument("agent_name")
@click.option("--model", "-m", default=None, help="Model override (e.g. claude-sonnet-4-6)")
def one_on_one(agent_name: str, model: str | None):
    """Have a private 1:1 conversation with a team member."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    engine = _cli._get_engine(state)
    team = _cli._load_team(state)

    # Find the agent
    agent = None
    for key, persona in team.items():
        if agent_name.lower() in key.lower() or agent_name.lower() in persona.name.lower():
            agent = persona
            break

    if not agent:
        console.print(f"[red]No team member found matching '{agent_name}'.[/red]")
        console.print("Team members:")
        for key, persona in team.items():
            console.print(f"  • {persona.name} ({key})")
        return

    project_context = f"Project: {config.name}\nSprint: {config.current_sprint}"
    project_context = enrich_context_with_experience(state, agent, project_context)
    run_one_on_one(engine, agent, project_context, model_override=model)
    _cli._print_cost_footer(engine.cfo)


@main.command()
def onboard():
    """Generate an onboarding brief for new team members."""
    state = _cli._get_state()
    _cli._require_init(state)

    engine = _cli._get_engine(state)
    secretary = state.load_persona("secretary")

    console.print("[bold]Secretary is preparing the onboarding brief...[/bold]")
    brief = generate_onboarding_brief(engine, secretary, state)
    console.print(Panel(Markdown(brief), title="Onboarding Brief", style="magenta"))
    console.print("[dim]Onboarding brief saved.[/dim]")
    _cli._print_cost_footer(engine.cfo)
