"""Configuration-related CLI commands."""

from __future__ import annotations

import click
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

import odd.cli as _cli
from odd.cli import console, main
from odd.config import DEFAULT_PHASE_ENVELOPES, MAX_REVIEW_PASSES, refresh_pricing
from odd.labels import (
    priority_label,
    sprint_status_label,
    task_status_icon,
)
from odd.models import CEOGate, CEOStyle

PROVIDER_LABELS = {
    "anthropic": "Anthropic",
    "openai-compat": "OpenAI-compatible",
    "openwebui": "Open WebUI",
}

STYLE_LABELS = {
    CEOStyle.HANDS_ON: "Hands-on",
    CEOStyle.BALANCED: "Balanced",
    CEOStyle.DELEGATOR: "Delegator",
}

STYLE_MAP = {
    "hands-on": CEOStyle.HANDS_ON,
    "balanced": CEOStyle.BALANCED,
    "delegator": CEOStyle.DELEGATOR,
}

GATE_MAP = {g.value.replace("_", "-"): g for g in CEOGate}

GATE_LABELS = {g: g.value.replace("_", " ").title() for g in CEOGate}

STYLE_DESCRIPTIONS = {
    CEOStyle.HANDS_ON: "Hands-on - see everything, approve everything",
    CEOStyle.BALANCED: "Balanced - summaries + milestone check-ins",
    CEOStyle.DELEGATOR: "Delegator - blockers only, team runs autonomously",
}


def _format_style_summary(config) -> str:
    """Format CEO style default + any gate overrides for display."""
    label = STYLE_LABELS.get(config.ceo_style, config.ceo_style.value)
    lines = [f"CEO Style: {label}"]
    for gate, style in config.ceo_overrides.items():
        lines.append(f"  {GATE_LABELS[gate]}: {STYLE_LABELS[style]}")
    return "\n".join(lines)


@main.command()
def status():
    """Show current project status."""
    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()

    provider_label = PROVIDER_LABELS.get(config.provider.name, config.provider.name)
    provider_line = f"Provider: {provider_label}"
    if config.provider.base_url:
        provider_line += f"  |  {config.provider.base_url}"

    console.print(Panel(
        f"[bold]{config.name}[/bold]\n\n"
        f"{config.description}\n\n"
        f"Current Sprint: {config.current_sprint or 'Not started'}\n"
        f"{provider_line}\n"
        f"{_format_style_summary(config)}",
        title="Project Status",
        style="blue",
    ))

    if config.current_sprint:
        try:
            current = state.load_sprint(config.current_sprint)
            console.print(f"\n[bold]Sprint {current.number}[/bold]: {current.goal}")
            console.print(f"Status: {sprint_status_label(current.status)}")
            for task in current.tasks:
                console.print(f"  {task_status_icon(task.status)} {task.description} → {task.assigned_to}")
        except FileNotFoundError:
            pass


@main.group(name="config", invoke_without_command=True)
@click.pass_context
def config_group(ctx):
    """View or change project configuration."""
    if ctx.invoked_subcommand is None:
        state = _cli._get_state()
        _cli._require_init(state)

        config = state.load_config()
        review_label = f"{config.review_passes} pass{'es' if config.review_passes != 1 else ''}" if config.review_passes > 0 else "off"
        provider_label = PROVIDER_LABELS.get(config.provider.name, config.provider.name)

        lines = [
            _format_style_summary(config),
            f"Provider: {provider_label}",
        ]
        if config.provider.base_url:
            lines.append(f"  Endpoint: {config.provider.base_url}")
        if config.provider.model_map:
            maps = ", ".join(f"{k}={v}" for k, v in config.provider.model_map.items())
            lines.append(f"  Models: {maps}")
        lines.append(f"Review Passes: {review_label}")
        lines.append(f"TDD Retries: {config.tdd_max_retries}")

        console.print(Panel("\n".join(lines), title="Configuration", style="blue"))

main.add_command(config_group)


@config_group.command(name="style")
@click.argument("target")
@click.argument("level", required=False)
@click.option("--reset", is_flag=True, help="Clear a gate override (target must be a gate name)")
def config_style(target: str, level: str | None, reset: bool):
    """Set CEO style default or per-gate override.

    \b
    Examples:
      odd config style balanced             # set default
      odd config style war-room hands-on    # override one gate
      odd config style war-room --reset     # clear override
    """
    state = _cli._get_state()
    _cli._require_init(state)
    config = state.load_config()

    # --reset without a gate name is a user error
    if reset and target not in GATE_MAP:
        valid_gates = ", ".join(GATE_MAP)
        raise click.UsageError(f"--reset requires a gate name: {valid_gates}")

    # Target is a gate name → set/reset override
    if target in GATE_MAP:
        gate = GATE_MAP[target]
        if reset:
            config.ceo_overrides.pop(gate, None)
            state.save_config(config)
            console.print(f"[green]{GATE_LABELS[gate]} override cleared (using default: {STYLE_LABELS[config.ceo_style]})[/green]")
            return
        if level is None or level not in STYLE_MAP:
            valid = ", ".join(STYLE_MAP)
            raise click.UsageError(f"Gate override requires a style: {valid}")
        config.ceo_overrides[gate] = STYLE_MAP[level]
        state.save_config(config)
        console.print(f"[green]{GATE_LABELS[gate]}: {STYLE_LABELS[STYLE_MAP[level]]}[/green]")
        return

    # Target is a style name → set default
    if target not in STYLE_MAP:
        valid_styles = ", ".join(STYLE_MAP)
        valid_gates = ", ".join(GATE_MAP)
        raise click.UsageError(
            f"Unknown target '{target}'. Expected a style ({valid_styles}) or gate ({valid_gates})."
        )
    config.ceo_style = STYLE_MAP[target]
    state.save_config(config)
    console.print(f"[green]CEO style set to: {STYLE_DESCRIPTIONS[config.ceo_style]}[/green]")


@config_group.command(name="review")
@click.argument("passes", type=int)
def config_review(passes: int):
    """Set default code review passes per sprint (0 = skip, max 10)."""
    if passes < 0:
        raise click.UsageError("Review passes cannot be negative.")
    if passes > MAX_REVIEW_PASSES:
        raise click.UsageError(f"Maximum review passes is {MAX_REVIEW_PASSES}.")
    state = _cli._get_state()
    _cli._require_init(state)
    config = state.load_config()
    config.review_passes = passes
    state.save_config(config)

    if config.review_passes == 0:
        console.print("[green]Code review disabled (0 passes). Cody will still nudge periodically.[/green]")
    else:
        label = {1: "quick", 2: "standard"}.get(config.review_passes, "thorough")
        console.print(f"[green]Default review: {config.review_passes} pass{'es' if config.review_passes != 1 else ''} ({label})[/green]")


@config_group.command(name="envelopes")
@click.argument("overrides", nargs=-1)
@click.option("--reset", is_flag=True, help="Reset all envelopes to defaults")
def config_envelopes(overrides: tuple[str, ...], reset: bool):
    """View or set phase budget envelopes.

    \b
    Examples:
      odd config envelopes                    # show current
      odd config envelopes qa=0.30 impl=0.55  # override phases
      odd config envelopes --reset            # restore defaults

    Phase names: planning, qa, implementation, review, demo.
    Values are fractions of the sprint budget (must sum to <= 1.0).
    """
    state = _cli._get_state()
    _cli._require_init(state)
    cfo = _cli._get_cfo(state)

    if reset:
        cfo.set_budget(phase_envelopes={})
        console.print("[green]Phase envelopes reset to defaults.[/green]")
        _show_envelopes(cfo)
        return

    if not overrides:
        _show_envelopes(cfo)
        return

    # Parse key=value pairs
    PHASE_ALIASES = {
        "impl": "implementation",
        "implement": "implementation",
        "plan": "planning",
    }
    new_overrides: dict[str, float] = {}
    for item in overrides:
        if "=" not in item:
            raise click.UsageError(f"Expected key=value, got: {item}")
        key, val = item.split("=", 1)
        key = PHASE_ALIASES.get(key.lower(), key.lower())
        if key not in DEFAULT_PHASE_ENVELOPES:
            valid = ", ".join(DEFAULT_PHASE_ENVELOPES)
            raise click.UsageError(f"Unknown phase '{key}'. Valid: {valid}")
        try:
            new_overrides[key] = float(val)
        except ValueError:
            raise click.UsageError(f"Invalid value for {key}: {val}")

    # Merge with existing overrides
    budget_data = cfo._load_budget()
    existing = budget_data.get("phase_envelopes", {})
    existing.update(new_overrides)

    # Validate sum
    effective = dict(DEFAULT_PHASE_ENVELOPES)
    effective.update(existing)
    total = sum(effective.values())
    if total > 1.0:
        raise click.UsageError(
            f"Envelope fractions sum to {total:.2f} (must be <= 1.0). "
            f"Reduce some values."
        )

    cfo.set_budget(phase_envelopes=existing)
    console.print("[green]Phase envelopes updated.[/green]")
    _show_envelopes(cfo)


def _show_envelopes(cfo) -> None:
    """Display effective phase envelopes."""
    envelopes = cfo._resolve_envelopes()
    budget_data = cfo._load_budget()
    sprint_budget = budget_data.get("sprint_budget", 0.0)
    overrides = budget_data.get("phase_envelopes", {})

    lines = []
    total_frac = 0.0
    for phase, frac in envelopes.items():
        total_frac += frac
        marker = " *" if phase in overrides else ""
        if sprint_budget > 0:
            lines.append(f"  {phase}: {frac:.0%} (${sprint_budget * frac:.2f}){marker}")
        else:
            lines.append(f"  {phase}: {frac:.0%}{marker}")

    overflow = max(0.0, 1.0 - total_frac)
    if overflow > 0:
        if sprint_budget > 0:
            lines.append(f"  [overflow]: {overflow:.0%} (${sprint_budget * overflow:.2f})")
        else:
            lines.append(f"  [overflow]: {overflow:.0%}")

    if overrides:
        lines.append("\n  * = CEO override")

    console.print(Panel("\n".join(lines), title="Phase Budget Envelopes", style="yellow"))


@main.command()
def costs():
    """Show the CFO's financial report."""
    state = _cli._get_state()
    _cli._require_init(state)

    cfo = _cli._get_cfo(state)
    report = cfo.financial_report()
    console.print(Panel(Markdown(report), title="Bill the CFO - Financial Report", style="yellow"))


@main.command()
@click.option("--sprint-budget", "-s", type=float, default=None, help="Max spend per sprint (USD)")
@click.option("--total-budget", "-t", type=float, default=None, help="Max total spend (USD)")
@click.option("--session-budget", type=float, default=None, help="Max spend per session (USD)")
def budget(sprint_budget: float | None, total_budget: float | None, session_budget: float | None):
    """Set spending limits. The CFO will enforce them."""
    state = _cli._get_state()
    _cli._require_init(state)

    cfo = _cli._get_cfo(state)

    if sprint_budget is None and total_budget is None and session_budget is None:
        # Show current budget
        budget_data = cfo._load_budget()
        if budget_data:
            lines = [
                f"Sprint budget: ${budget_data.get('sprint_budget', 'No limit')}",
                f"Total budget: ${budget_data.get('total_budget', 'No limit')}",
            ]
            if "session_budget" in budget_data:
                lines.append(f"Session budget: ${budget_data['session_budget']}")
            console.print(Panel("\n".join(lines), title="Current Budget", style="yellow"))
            _show_envelopes(cfo)
        else:
            console.print("[dim]No budget set. Use --sprint-budget or --total-budget to set limits.[/dim]")
        return

    cfo.set_budget(sprint_budget=sprint_budget, total_budget=total_budget, session_budget=session_budget)
    console.print("[green]Budget updated.[/green]")
    if sprint_budget is not None:
        console.print(f"  Per-sprint limit: ${sprint_budget:.2f}")
    if total_budget is not None:
        console.print(f"  Total limit: ${total_budget:.2f}")
    if session_budget is not None:
        console.print(f"  Per-session limit: ${session_budget:.2f}")


@main.command(name="refresh-pricing")
def refresh_pricing_cmd():
    """Fetch the latest model pricing from Anthropic's docs."""
    state = _cli._get_state()
    _cli._require_init(state)

    console.print("[bold]Fetching latest pricing from Anthropic...[/bold]")
    pricing = refresh_pricing(state.odd_dir)

    if pricing:
        console.print("[green]Pricing updated![/green]")
        # Map model IDs to CEO-friendly tier names
        tier_names = {"opus": "Premium (Opus)", "sonnet": "Standard (Sonnet)", "haiku": "Fast (Haiku)"}
        for model, prices in sorted(pricing.items()):
            friendly = next((v for k, v in tier_names.items() if k in model.lower()), model)
            console.print(f"  {friendly}: ${prices['input']}/MTok in, ${prices['output']}/MTok out")
    else:
        console.print("[yellow]Could not fetch pricing. Using cached/default values.[/yellow]")


@main.command(name="values")
def manage_values():
    """Set company values - shared principles for all agents."""
    state = _cli._get_state()
    _cli._require_init(state)

    cv = _cli._get_values(state)
    current = cv.get_values()

    if current:
        console.print(Panel("[bold]Current Company Values[/bold]", style="blue"))
        for i, v in enumerate(current, 1):
            console.print(f"  {i}. {v}")

    console.print("\nAdd a new value (or 'done' to finish, 'remove N' to remove):")

    while True:
        inp = Prompt.ask("[bold yellow]CEO[/bold yellow]")
        if inp.lower().strip() == "done":
            break
        elif inp.lower().startswith("remove "):
            try:
                idx = int(inp.split()[1]) - 1
                removed = cv.remove_value(idx)
                if removed:
                    console.print(f"[yellow]Removed: {removed}[/yellow]")
                else:
                    console.print("[red]Invalid index.[/red]")
            except (ValueError, IndexError):
                console.print("[red]Usage: remove N[/red]")
        else:
            cv.add_value(inp)
            console.print(f"[green]Added: {inp}[/green]")

    final = cv.get_values()
    if final:
        console.print(Panel("[bold]Company Values[/bold]", style="blue"))
        for i, v in enumerate(final, 1):
            console.print(f"  {i}. {v}")
        console.print("\n[dim]These values will guide every agent's decisions.[/dim]")
