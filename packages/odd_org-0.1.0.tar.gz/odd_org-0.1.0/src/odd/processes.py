"""Business processes - beta testing, retrospectives, 1:1s, spikes, reviews, onboarding.

These are higher-level orchestrations that use the agent engine
to simulate real business activities.
"""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from contextlib import contextmanager, nullcontext

from rich.status import Status

from odd.agent import AgentEngine
from odd.cfo import CFO
from odd.config import SONNET_MODEL
from odd.models import Persona, RoleType, Sprint
from odd.parsers import parse_tester_specs
from odd.roles import recruit_consultant
from odd.state import StateManager
from odd.tools import SUBMIT_TESTER_SPECS

# After this many turns, summarize the conversation to reduce input tokens.
_SUMMARIZE_AFTER_TURNS = 8


console = Console()


def _thinking_context(engine: AgentEngine, persona: Persona):
    """Return a Status spinner context, unless the engine already streams this agent.

    When the engine has a stream factory that returns a callback for this
    persona, the stream factory manages its own spinner - so we return a
    no-op context to avoid double spinners.
    """
    if engine.default_stream_factory is not None:
        # Don't *call* the factory here - it has side effects (starts a
        # spinner).  Just knowing a factory exists means the caller already
        # manages its own display, so skip the Status spinner.
        return nullcontext()
    return Status(
        f"[bold cyan]{persona.name} is thinking...[/bold cyan]",
        console=console,
        spinner="dots",
    )


def _multiline_input(prompt_label: str = "[bold yellow]CEO[/bold yellow]") -> str:
    """Read CEO input with backslash-continuation for multiline messages.

    If a line ends with ``\\``, the backslash is stripped and the next line
    is appended (separated by a newline). This lets the CEO compose
    multi-line messages without sending on each Enter.
    """
    lines: list[str] = []
    label = f"\n{prompt_label}" if not lines else f"  {prompt_label}"
    while True:
        line = Prompt.ask(label if not lines else f"  [dim]...[/dim]  ")
        if line.endswith("\\"):
            lines.append(line[:-1])
        else:
            lines.append(line)
            break
    return "\n".join(lines)


def enrich_context_with_experience(state: StateManager, persona: Persona, project_context: str) -> str:
    """Add work experience to project_context for consultant 1:1s."""
    if persona.role_type != RoleType.CONSULTANT:
        return project_context
    record = state.load_consultant_record(persona.name)
    if not record.outcomes:
        return project_context
    return project_context + f"\n\nYour Work Experience:\n{record.experience_summary()}"


# --- Beta Testing ---



def run_beta_test_single(
    engine: AgentEngine,
    state: StateManager,
    recruiter: Persona,
    tester_description: str,
    tester_name: str,
    test_instructions: str,
) -> str:
    """Recruit a single beta tester and have them try the product."""
    beta_jd = (
        f"BETA TESTER ROLE - NOT a developer role.\n\n"
        f"Profile: {tester_description}\n\n"
        f"This person is a potential USER of the product, not a builder. "
        f"They should evaluate the product from a user's perspective: "
        f"Is it intuitive? Does it solve their problem? What's confusing? "
        f"What's missing? What would make them recommend it to others?\n\n"
        f"They should be honest, specific, and think like a real user, "
        f"not a QA engineer."
    )

    tester = recruit_consultant(engine, recruiter, beta_jd, tester_name)
    tester.role_type = RoleType.CONSULTANT
    state.save_persona(tester)

    console.print(f"[green]Beta tester '{tester_name}' recruited![/green]")

    feedback = engine.invoke(
        persona=tester,
        user_message=(
            f"You've been asked to beta test this product. Here are your instructions:\n\n"
            f"{test_instructions}\n\n"
            f"Try it out using the tools available. Then provide your honest feedback:\n"
            f"1. First impressions - what do you notice right away?\n"
            f"2. What works well?\n"
            f"3. What's confusing or frustrating?\n"
            f"4. What's missing that you'd expect?\n"
            f"5. Would you use this? Would you recommend it? Why or why not?\n"
            f"6. Top 3 things you'd change\n\n"
            f"Be specific and give examples. You're a user, not a developer - "
            f"you don't care about the code, you care about the experience."
        ),
    )

    state.archive_consultant(tester_name)
    return feedback


def run_beta_test(
    engine: AgentEngine,
    state: StateManager,
    lead_dev: Persona,
    recruiter: Persona,
    count: int,
    project_context: str,
) -> str:
    """Lead Dev designs beta tester profiles, recruits and runs them all.

    The CEO only provides a count. Cody decides who should test,
    what they should test, and how - based on the project and codebase.
    """
    # Cody designs the tester profiles
    console.print(Panel(
        f"Cody is figuring out who should test this and what they should try...",
        style="blue",
    ))

    plan = engine.invoke(
        persona=lead_dev,
        user_message=(
            f"The CEO wants {count} beta tester(s) to try the product and give feedback.\n\n"
            f"Based on the project and codebase, design {count} distinct tester profiles. "
            f"Each tester should represent a DIFFERENT type of user - vary by experience level, "
            f"use case, or background so we get diverse feedback.\n\n"
            f"Use the submit_tester_specs tool to submit the tester profiles.\n\n"
            f"Fallback format (if you can't use the tool):\n\n"
            f"TESTER: <a realistic first name>\n"
            f"PROFILE: <who they are - their background, what they'd use this product for>\n"
            f"INSTRUCTIONS: <specific things they should try, how to run it, what to look for>\n\n"
            f"Read the codebase to understand what the product does and how to run it, "
            f"so you can write realistic test instructions."
        ),
        project_context=project_context,
        extra_tools=[SUBMIT_TESTER_SPECS],
    )

    # Check for structured submission, fall back to string parsing
    submissions = engine.pop_submissions("submit_tester_specs")
    structured = submissions[0]["data"] if submissions else None
    specs = parse_tester_specs(plan, structured_data=structured)

    if not specs:
        console.print("[red]Could not parse tester specs from Lead Dev. Raw response:[/red]")
        console.print(Panel(Markdown(plan), style="yellow"))
        return plan

    console.print(Panel(Markdown(plan), title="Beta Test Plan", style="blue"))

    # Run each tester
    all_feedback: list[str] = []
    for name, profile, instructions in specs:
        console.print(f"\n[bold]Running beta test: {name}[/bold]")
        feedback = run_beta_test_single(
            engine, state, recruiter, profile, name, instructions,
        )
        all_feedback.append(f"## {name}\n*{profile}*\n\n{feedback}")
        console.print(Panel(Markdown(feedback), title=f"Feedback - {name}", style="green"))

    # Cody synthesizes
    combined = "\n\n---\n\n".join(all_feedback)
    console.print(Panel("Cody is synthesizing the feedback...", style="blue"))

    synthesis = engine.invoke(
        persona=lead_dev,
        user_message=(
            f"Here's the feedback from {len(specs)} beta tester(s):\n\n"
            f"{combined}\n\n"
            f"Synthesize this into a single report for the CEO:\n"
            f"1. **Overall verdict** - how is the product landing?\n"
            f"2. **Common themes** - what did multiple testers agree on?\n"
            f"3. **Divergent opinions** - where did testers disagree?\n"
            f"4. **Top priorities** - ranked list of what to fix/improve next\n"
            f"5. **Backlog suggestions** - specific items to add to the backlog\n\n"
            f"Be direct. The CEO wants actionable takeaways, not a summary of summaries."
        ),
        project_context=project_context,
        tools=False,
    )

    return synthesis


# --- Retrospective ---

def run_retrospective(
    engine: AgentEngine,
    state: StateManager,
    sprint: Sprint,
    team: dict[str, Persona],
    secretary: Persona,
) -> str:
    """Retrospective based on real agent notes from the sprint.

    Agents write notes during the sprint (baked into their task prompts).
    The secretary reads those notes and consolidates into a retro report.
    No fake "reflections" from agents with no memory.
    """
    notes = state.load_sprint_notes(sprint.number)
    from odd.labels import sprint_status_label
    project_context = f"Sprint {sprint.number} goal: {sprint.goal}\nStatus: {sprint_status_label(sprint.status)}"

    if not notes:
        # Fallback: no notes on disk (e.g. old sprints before this feature)
        console.print("[yellow]No agent notes found - running lightweight retro.[/yellow]")
        summary = engine.invoke(
            persona=secretary,
            user_message=(
                f"Sprint {sprint.number} is complete.\n"
                f"Sprint goal: {sprint.goal}\n\n"
                f"No detailed agent notes are available. Write a brief retrospective "
                f"based on the sprint goal and current project state.\n"
                f"Save to .odd/notes/retro_sprint{sprint.number}.md"
            ),
            project_context=project_context,
        )
        return summary

    # Display notes as they're read
    for name, content in notes.items():
        console.print(Panel(Markdown(content), title=f"Notes - {name}", style="cyan"))

    notes_text = "\n\n---\n\n".join(
        f"**{name}:**\n{content}" for name, content in notes.items()
    )

    summary = engine.invoke(
        persona=secretary,
        user_message=(
            f"Sprint {sprint.number} is complete. Here are the notes each team "
            f"member wrote about their work during the sprint:\n\n"
            f"{notes_text}\n\n"
            f"Produce a retrospective report:\n"
            f"1. **Key wins** - what went well\n"
            f"2. **Pain points** - what was difficult or went wrong\n"
            f"3. **Action items** - specific changes for next sprint\n"
            f"4. **Team health** - any concerns about workload, skill gaps, or process\n\n"
            f"Save this to .odd/notes/retro_sprint{sprint.number}.md"
        ),
        project_context=project_context,
    )

    return summary


# --- 1:1 Conversations ---

def _summarize_conversation(
    engine: AgentEngine,
    persona: Persona,
    conversation_history: list[dict],
    project_context: str = "",
    model_override: str | None = None,
) -> list[dict]:
    """Summarize conversation history into a compact context message.

    Called when the conversation exceeds _SUMMARIZE_AFTER_TURNS to keep
    input tokens manageable. Returns a new, shorter history.
    """
    # Build a text representation of the conversation for summarization
    lines: list[str] = []
    for msg in conversation_history:
        role = "CEO" if msg["role"] == "user" else persona.name
        lines.append(f"{role}: {msg['content']}")
    transcript = "\n\n".join(lines)

    summary = engine.invoke(
        persona=persona,
        user_message=(
            "Summarize the following 1:1 conversation so far into a compact "
            "context paragraph. Preserve all key decisions, action items, and "
            "important details. This summary will replace the full history to "
            "keep the conversation efficient.\n\n"
            f"{transcript}"
        ),
        project_context=project_context,
        tools=False,
        model_override=model_override,
    )

    # Replace history with a single assistant message containing the summary
    return [{"role": "assistant", "content": f"[Conversation summary so far]\n{summary}"}]


def run_one_on_one(
    engine: AgentEngine,
    persona: Persona,
    project_context: str = "",
    message: str | None = None,
    model_override: str | None = None,
) -> None:
    """CEO has a private 1:1 conversation with a specific team member.

    If *message* is provided, send it as a one-shot directive and print
    the response (using the persona's default model).  Otherwise, open a
    multi-turn interactive conversation defaulting to Sonnet for cost
    efficiency.

    Args:
        engine: The agent invocation engine.
        persona: The team member to talk to.
        project_context: Shared project state.
        message: If set, one-shot mode - send this and return.
        model_override: If set, use this model instead of the default.
            For multi-turn, defaults to Sonnet if not specified.
            For one-shot, uses the persona's default model if not specified.
    """
    if message:
        # One-shot: CEO already knows what they want - use persona's default model
        with _thinking_context(engine, persona):
            response = engine.invoke(
                persona=persona,
                user_message=message,
                project_context=project_context,
                model_override=model_override,
            )
        console.print(Panel(Markdown(response), title=persona.name, style="magenta"))
        return

    # Multi-turn: default to Sonnet for cost efficiency (unless overridden)
    effective_model = model_override or SONNET_MODEL

    # Interactive multi-turn conversation
    console.print(Panel(
        f"Starting 1:1 with [bold]{persona.name}[/bold]\n"
        f"Type 'done' to end the conversation.",
        style="magenta",
    ))

    with engine.conversation(
        persona=persona,
        project_context=project_context,
        tools=False,
        model_override=effective_model,
    ) as conv:
        # Agent opens the 1:1
        with _thinking_context(engine, persona):
            opening = conv.send(
                "The CEO has scheduled a 1:1 with you. Greet them and ask what "
                "they'd like to discuss. Be open and receptive."
            )
        console.print(Panel(Markdown(opening), title=persona.name, style="magenta"))

        while True:
            ceo_input = _multiline_input()
            if ceo_input.lower().strip() == "done":
                break

            with _thinking_context(engine, persona):
                response = conv.send(ceo_input)
            console.print(Panel(Markdown(response), title=persona.name, style="magenta"))

    console.print(f"[dim]1:1 with {persona.name} ended.[/dim]")


# --- Spike Tasks ---

def run_spike(
    engine: AgentEngine,
    lead_dev: Persona,
    topic: str,
    project_context: str = "",
) -> str:
    """Research spike - investigate before committing to build.

    The lead dev (or a consultant) researches a topic and reports
    findings + recommendation to the CEO.
    """
    console.print(Panel(f"Lead Dev is researching: {topic}", style="blue"))

    findings = engine.invoke(
        persona=lead_dev,
        user_message=(
            f"The CEO wants a research spike on the following topic before we commit "
            f"to building anything:\n\n"
            f"{topic}\n\n"
            f"Investigate thoroughly:\n"
            f"1. What are the options/approaches?\n"
            f"2. What are the tradeoffs of each?\n"
            f"3. What dependencies or risks are involved?\n"
            f"4. Your recommendation and why\n"
            f"5. Estimated complexity (simple / moderate / complex)\n\n"
            f"Be honest about unknowns. This spike informs whether we build this at all."
        ),
        project_context=project_context,
    )

    return findings


# --- Performance Reviews ---

def generate_performance_review(
    cfo: CFO,
    state: StateManager,
) -> str:
    """Generate performance/ROI data for all agents.

    Combines CFO cost data with available quality signals.
    """
    cost_by_agent = cfo.cost_by_agent()
    total_cost = cfo.total_cost()

    if not cost_by_agent:
        return "No data available yet. Complete at least one sprint first."

    lines = [
        "# Performance Review - Agent ROI",
        "",
        f"**Total org spend:** ${total_cost:.4f}",
        "",
        "## Cost per Agent",
    ]

    for agent, cost in sorted(cost_by_agent.items(), key=lambda x: -x[1]):
        pct = (cost / total_cost * 100) if total_cost > 0 else 0
        lines.append(f"  **{agent}**: ${cost:.4f} ({pct:.1f}% of total)")

    # Cost efficiency by model tier
    cost_by_model = cfo.cost_by_model()
    if cost_by_model:
        lines.extend(["", "## Model Tier Efficiency"])
        for model, cost in sorted(cost_by_model.items(), key=lambda x: -x[1]):
            lines.append(f"  {model}: ${cost:.4f}")

    # Sprint trends
    sprints = cfo.all_sprints()
    if len(sprints) > 1:
        lines.extend(["", "## Sprint Cost Trend"])
        for s in sprints:
            sprint_cost = cfo.sprint_cost(s)
            lines.append(f"  Sprint {s}: ${sprint_cost:.4f}")
        avg = cfo.cost_per_sprint_average()
        lines.append(f"  **Average:** ${avg:.4f}/sprint")

    # Consultant track records
    records = state.all_consultant_records()
    consultants_with_history = {n: r for n, r in records.items() if r.outcomes}
    if consultants_with_history:
        lines.extend(["", "## Consultant Track Records"])
        for name, record in sorted(
            consultants_with_history.items(),
            key=lambda x: -x[1].success_rate,
        ):
            cost = cost_by_agent.get(name.lower().replace(" ", "_"), 0.0)
            cost_per_pass = (
                cost / record.tasks_completed if record.tasks_completed else 0.0
            )
            lines.append(f"  **{name}** ({record.tenure} sprint{'s' if record.tenure != 1 else ''}):")
            lines.append(f"    {record.summary()}")
            lines.append(f"    Cost: ${cost:.4f} (${cost_per_pass:.4f}/passing task)")
            # Trend indicator
            trend = record.retry_trend
            if abs(trend) > 0.3:
                direction = "↑ worsening" if trend > 0 else "↓ improving"
                lines.append(f"    Retry trend: {direction} ({trend:+.1f})")

    lines.extend([
        "",
        "## Recommendations",
        "- Consider downgrading agents with high cost but routine tasks to a cheaper model",
        "- Agents with very low usage may not be needed - consider firing",
        "- Compare sprint costs over time to catch runaway spending",
    ])

    # Add consultant-specific recommendations
    for name, record in consultants_with_history.items():
        if record.success_rate == 1.0 and len(record.outcomes) >= 3:
            lines.append(f"- **{name}** has a perfect record - consider keeping on retainer")
        elif record.success_rate < 0.5 and len(record.outcomes) >= 2:
            lines.append(f"- **{name}** has a low success rate - consider firing or reassigning")
        elif record.retry_trend > 1.0 and record.tenure >= 2:
            lines.append(f"- **{name}** retry rate is increasing - performance may be declining")
        if record.first_run_pass_rate < 0.3 and record.total_tasks >= 3:
            lines.append(f"- **{name}** rarely passes first try ({record.first_run_pass_rate * 100:.0f}%) - high rework cost")

    return "\n".join(lines)


# --- Onboarding Briefs ---

def generate_onboarding_brief(
    engine: AgentEngine,
    secretary: Persona,
    state: StateManager,
    target_persona: Persona | None = None,
) -> str:
    """Have the secretary produce an onboarding document for new hires.

    Summarizes the project, team, current state, and key decisions
    so a new consultant can ramp up quickly.

    If target_persona is provided, the brief is also saved to the persona's
    notes directory so it's auto-injected into their system prompt.
    """
    config = state.load_config()

    # Gather existing notes
    notes_dir = state.notes_dir
    existing_notes = ""
    if notes_dir.exists():
        for f in sorted(notes_dir.glob("*.md")):
            content = f.read_text(encoding="utf-8")
            existing_notes += f"\n### {f.stem}\n{content}\n"

    target_context = ""
    if target_persona:
        target_context = (
            f"\n\nThis brief is specifically for {target_persona.name} "
            f"({target_persona.title}). Tailor the priorities and context "
            f"to their specialty."
        )

    brief = engine.invoke(
        persona=secretary,
        user_message=(
            f"A new team member is joining the project. Create a comprehensive "
            f"onboarding brief that covers:\n\n"
            f"1. **Project overview** - What we're building and why\n"
            f"2. **Current state** - What's been done so far (Sprint {config.current_sprint})\n"
            f"3. **Key decisions** - Important choices that were made and why\n"
            f"4. **Codebase overview** - Key files and structure\n"
            f"5. **How we work** - Sprint process, communication norms\n"
            f"6. **Current priorities** - What matters most right now\n\n"
            f"Project: {config.name}\n"
            f"Description: {config.description}\n\n"
            f"Existing notes:\n{existing_notes}\n"
            f"{target_context}\n\n"
            f"Also read the codebase to understand the current structure.\n"
            f"Save the onboarding brief to .odd/notes/onboarding.md"
        ),
    )

    # Also save to the target persona's notes dir for auto-injection
    if target_persona:
        persona_notes = state.get_persona_notes_dir(target_persona)
        (persona_notes / "onboarding.md").write_text(brief, encoding="utf-8")

    return brief
