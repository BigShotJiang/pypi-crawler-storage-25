"""RunnerMiddleware - shared cross-cutting concerns for the execution engine.

DirectRunner composes this class to handle budget checking, cost recording,
and trace logging. The runner is responsible only for the LLM interaction;
the middleware handles everything that wraps around it.
"""

from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from typing import Any

from odd.config import (
    WIND_DOWN_ITERATIONS,
    WRAP_UP_THRESHOLD,
    resolve_context_window,
)
from odd.tracing import log_agent_call


# ---------------------------------------------------------------------------
# Budget status
# ---------------------------------------------------------------------------

@dataclass
class BudgetStatus:
    """Result of a budget check."""
    ok: bool = True
    exceeded: bool = False
    phase_exceeded: bool = False
    warning: str | None = None


# ---------------------------------------------------------------------------
# Notices injected into conversation by DirectRunner.
# ---------------------------------------------------------------------------

WRAP_UP_NOTICE = (
    "BUDGET NOTICE: You have used your allocated budget for this phase. "
    "Wrap up immediately - save any work in progress and stop. "
    "Do NOT start new files or tests. Finish what you're writing and end your turn."
)

CONTEXT_WRAP_UP_NOTICE = (
    "CONTEXT NOTICE: This conversation is approaching the model's context limit. "
    "Wrap up immediately - save any work in progress and stop. "
    "Do NOT start new files or tests. Finish what you're writing and end your turn."
)


# ---------------------------------------------------------------------------
# Token usage result
# ---------------------------------------------------------------------------

@dataclass
class TokenUsage:
    """Cost breakdown returned by record_usage."""
    input_cost: float = 0.0
    output_cost: float = 0.0


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class RunnerMiddleware:
    """Cross-cutting concerns shared by all execution engines.

    Constructed once per invocation by AgentEngine and passed to the runner.
    Both runners call the same methods; the *when* is up to each runner.
    """

    def __init__(
        self,
        cfo: Any | None = None,
        current_sprint: int | None = None,
        phase: str | None = None,
    ):
        self.cfo = cfo
        self.current_sprint = current_sprint
        self.phase = phase

        # Wind-down state (shared across check_budget calls)
        self.winding_down: bool = False
        self.wind_down_remaining: int = 0

        # Context guard state
        self._context_warned: bool = False

        # Accumulated usage for log_invocation
        self._total_input_tokens: int = 0
        self._total_output_tokens: int = 0
        self._total_input_cost: float = 0.0
        self._total_output_cost: float = 0.0
        self._total_tool_calls: int = 0
        self._invoke_start: float = time.monotonic()

    # ------------------------------------------------------------------
    # Budget checking
    # ------------------------------------------------------------------

    def check_budget(self) -> BudgetStatus:
        """Pre-iteration budget check.

        Returns a BudgetStatus indicating whether to continue, warn, or stop.
        Manages wind-down state internally.
        """
        status = BudgetStatus()

        if not self.cfo:
            return status

        # Hard budget check
        ok, msg = self.cfo.check_budget(self.current_sprint)
        if not ok:
            status.ok = False
            status.exceeded = True
            status.warning = msg
            return status

        if msg.startswith("WARNING:"):
            print(f"\n\u26a0 {msg}", file=sys.stderr)
            status.warning = msg

        # Phase envelope check
        if (
            self.phase
            and self.current_sprint is not None
            and not self.winding_down
        ):
            phase_ok, phase_msg = self.cfo.check_phase_budget(
                self.current_sprint, self.phase,
            )
            if not phase_ok:
                self.winding_down = True
                self.wind_down_remaining = WIND_DOWN_ITERATIONS
                status.phase_exceeded = True
                status.warning = phase_msg
                print(f"\n\u26a0 {phase_msg}", file=sys.stderr)

        return status

    # ------------------------------------------------------------------
    # Context window guard
    # ------------------------------------------------------------------

    def check_context_window(
        self, model: str, system: str, messages: list[dict[str, Any]],
    ) -> bool:
        """Check if conversation is approaching context limit.

        Returns True if wind-down was triggered (caller should inject notice).
        Only fires once per invocation.
        """
        if self._context_warned or self.winding_down:
            return False

        estimated_tokens = estimate_tokens(system, messages)
        context_limit = resolve_context_window(model)

        if estimated_tokens >= context_limit * WRAP_UP_THRESHOLD:
            self._context_warned = True
            self.winding_down = True
            self.wind_down_remaining = WIND_DOWN_ITERATIONS
            print(
                f"\n\u26a0 Context window ~{estimated_tokens:,} tokens "
                f"(~{context_limit * WRAP_UP_THRESHOLD:,.0f} limit) - "
                f"winding down",
                file=sys.stderr,
            )
            return True

        return False

    # ------------------------------------------------------------------
    # Cost recording
    # ------------------------------------------------------------------

    def record_usage(
        self,
        agent_name: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> TokenUsage:
        """Record token usage with the CFO and accumulate totals."""
        self._total_input_tokens += input_tokens
        self._total_output_tokens += output_tokens

        if not self.cfo:
            return TokenUsage()

        usage = self.cfo.record(
            agent_name=agent_name,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            sprint=self.current_sprint,
            phase=self.phase,
        )
        self._total_input_cost += usage.input_cost
        self._total_output_cost += usage.output_cost
        return TokenUsage(
            input_cost=usage.input_cost,
            output_cost=usage.output_cost,
        )

    # ------------------------------------------------------------------
    # Trace logging
    # ------------------------------------------------------------------

    def log_invocation(
        self,
        *,
        agent_name: str,
        role: str,
        model: str,
        system_prompt_len: int,
        user_message: str,
        tool_calls: int | None = None,
        iterations: int = 0,
        stop_reason: str = "",
        error: str | None = None,
    ) -> None:
        """Unified trace logging. Call from the runner's finally block."""
        duration_ms = int((time.monotonic() - self._invoke_start) * 1000)
        log_agent_call(
            agent_name=agent_name,
            role=role,
            model=model,
            system_prompt_len=system_prompt_len,
            user_message=user_message,
            input_tokens=self._total_input_tokens,
            output_tokens=self._total_output_tokens,
            input_cost=self._total_input_cost,
            output_cost=self._total_output_cost,
            tool_calls=tool_calls if tool_calls is not None else self._total_tool_calls,
            iterations=iterations,
            stop_reason=stop_reason,
            duration_ms=duration_ms,
            sprint=self.current_sprint,
            phase=self.phase,
            error=error,
        )

    def add_tool_calls(self, count: int) -> None:
        """Increment the tool call counter."""
        self._total_tool_calls += count


# ---------------------------------------------------------------------------
# Utility (moved from DirectRunner)
# ---------------------------------------------------------------------------

def estimate_tokens(system: str, messages: list[dict[str, Any]]) -> int:
    """Rough token estimate: chars / 4."""
    total_chars = len(system)
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        elif isinstance(content, list):
            for block in content:
                total_chars += len(str(block))
    return total_chars // 4
