"""Interactive menu - the CEO's front door.

Extracted from cli.py to keep command definitions separate from
interactive navigation logic.
"""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Prompt

from odd.config import CORE_TEAM_ROLES, DEFAULT_BETA_TESTER_COUNT
from odd.health import check_and_repair
from odd.state import StateManager


console = Console()


def _get_state() -> StateManager:
    return StateManager(Path.cwd())


def _require_init(state: StateManager) -> None:
    if not state.is_initialized():
        console.print("[red]Not an ODD project. Run 'odd init' first.[/red]")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Menu definition
# ---------------------------------------------------------------------------

MENU_OPTIONS = [
    # (label, command_name, category)
    ("Start a sprint", "sprint", "Work"),
    ("Go on vacation", "vacation", "Work"),
    ("Check project status", "status", "Work"),
    ("Run a standup", "standup", "Work"),
    ("Talk to a team member", "1on1", "People"),
    ("Run a retrospective", "retro", "People"),
    ("Review the backlog", "backlog", "Research"),
    ("Research a topic (spike)", "spike", "Research"),
    ("Get user feedback (beta test)", "beta-test", "Research"),
    ("Set company values", "values", "Organization"),
    ("Set budget", "budget", "Organization"),
    ("Manage the team (hire, fire, review)", "_manage_team", "Organization"),
]


# ---------------------------------------------------------------------------
# Menu functions
# ---------------------------------------------------------------------------

def _show_menu() -> str:
    """Print the menu and return the user's choice."""
    console.print("[bold]ODD[/bold] - What would you like to do?\n")

    current_category = None
    for i, (label, _, category) in enumerate(MENU_OPTIONS, 1):
        if category != current_category:
            current_category = category
            console.print(f"  [bold dim]{category}[/bold dim]")
        console.print(f"    [bold]{i:>2}.[/bold] {label}")

    console.print(f"\n    [bold]{len(MENU_OPTIONS) + 1:>2}.[/bold] Call it a day")
    console.print()
    return Prompt.ask("[bold yellow]CEO[/bold yellow]")


def _dispatch(ctx: click.Context, main_group: click.Group, idx: int) -> None:
    """Run the command for a given menu index (1-based)."""
    label, command_name, _ = MENU_OPTIONS[idx - 1]

    # Special composite menus
    if command_name == "_manage_team":
        manage_team_menu(ctx, main_group)
        return

    # Commands that need an argument - prompt for it here
    if command_name == "1on1":
        pick_team_member_and_talk(ctx, main_group)
        return

    if command_name == "spike":
        topic = Prompt.ask("\nWhat topic should the team research?")
        ctx.invoke(main_group.get_command(ctx, "spike"), topic=topic)
        return

    if command_name == "beta-test":
        count = int(Prompt.ask("\nHow many beta testers?", default=str(DEFAULT_BETA_TESTER_COUNT)))
        ctx.invoke(main_group.get_command(ctx, "beta-test"), count=count)
        return

    if command_name == "budget":
        _budget_menu(ctx, main_group)
        return

    # Commands that take no arguments - invoke directly
    cmd = main_group.get_command(ctx, command_name)
    if cmd:
        ctx.invoke(cmd)


def interactive_menu(ctx: click.Context, main_group: click.Group) -> None:
    """Show the numbered CEO menu when 'odd' is run with no subcommand."""
    import random
    from odd.cli import CLOSING_REMARKS

    state = _get_state()

    if not state.is_initialized():
        console.print(
            "[bold blue]Welcome to ODD - Organization Driven Development[/bold blue]\n"
        )
        console.print("No project found. Let's get started.\n")
        ctx.invoke(main_group.get_command(ctx, "init"))
        return

    # Health check - detect and repair inconsistencies
    report = check_and_repair(state.odd_dir)
    if not report.clean:
        for issue in report.issues:
            if issue.repaired:
                console.print(f"  [yellow]Fixed:[/yellow] {issue.description} ({issue.repair_detail})")
            else:
                console.print(f"  [red]Warning:[/red] {issue.description}")
        console.print()

    quit_number = len(MENU_OPTIONS) + 1

    while True:
        choice = _show_menu()

        try:
            idx = int(choice)
        except ValueError:
            console.print("[red]Enter a number from the menu.[/red]\n")
            continue

        if idx == quit_number:
            console.print(f"\n[bold yellow]{random.choice(CLOSING_REMARKS)}[/bold yellow]")
            return

        if idx < 1 or idx > len(MENU_OPTIONS):
            console.print(f"[red]Pick a number between 1 and {quit_number}.[/red]\n")
            continue

        _dispatch(ctx, main_group, idx)
        console.print()  # breathing room before the menu re-appears


def _budget_menu(ctx: click.Context, main_group: click.Group) -> None:
    """Prompt the CEO for budget values, then invoke the budget command."""
    console.print("\n  [bold dim]Set Budget[/bold dim]")
    console.print("  Leave blank to keep current value.\n")

    sprint_raw = Prompt.ask("  Per-sprint limit (USD)", default="")
    total_raw = Prompt.ask("  Total limit (USD)", default="")
    session_raw = Prompt.ask("  Per-session limit (USD)", default="")

    kwargs: dict[str, float | None] = {
        "sprint_budget": float(sprint_raw) if sprint_raw else None,
        "total_budget": float(total_raw) if total_raw else None,
        "session_budget": float(session_raw) if session_raw else None,
    }

    if all(v is None for v in kwargs.values()):
        # Nothing entered - show current budget instead
        ctx.invoke(main_group.get_command(ctx, "budget"))
        return

    ctx.invoke(main_group.get_command(ctx, "budget"), **kwargs)


def manage_team_menu(ctx: click.Context, main_group: click.Group) -> None:
    """Sub-menu for team management."""
    console.print("\n  [bold dim]Manage the Team[/bold dim]")
    console.print("    [bold] 1.[/bold] View the team roster")
    console.print("    [bold] 2.[/bold] Hire a new consultant")
    console.print("    [bold] 3.[/bold] Let a consultant go")
    console.print("    [bold] 4.[/bold] Performance review (ROI)")
    console.print()

    choice = Prompt.ask("[bold yellow]CEO[/bold yellow]")

    try:
        idx = int(choice)
    except ValueError:
        console.print("[red]Enter a number from the menu.[/red]")
        return

    if idx == 1:
        ctx.invoke(main_group.get_command(ctx, "team"))
    elif idx == 2:
        ctx.invoke(main_group.get_command(ctx, "hire"))
    elif idx == 3:
        state = _get_state()
        consultants = state.list_consultants()
        if not consultants:
            console.print("[dim]No consultants on the team.[/dim]")
            return
        console.print("\n  [bold]Consultants:[/bold]")
        for i, c in enumerate(consultants, 1):
            console.print(f"    [bold]{i}.[/bold] {c.name} - {c.title}")
        pick = Prompt.ask("\nWho should we let go? (enter number)")
        try:
            cidx = int(pick) - 1
            if 0 <= cidx < len(consultants):
                ctx.invoke(main_group.get_command(ctx, "fire"), name=consultants[cidx].name)
            else:
                console.print("[red]Invalid selection.[/red]")
        except ValueError:
            console.print("[red]Enter a number.[/red]")
    elif idx == 4:
        ctx.invoke(main_group.get_command(ctx, "review"))
    else:
        console.print("[red]Pick 1–4.[/red]")


def pick_team_member_and_talk(ctx: click.Context, main_group: click.Group) -> None:
    """Let the CEO pick a team member from a numbered list."""
    state = _get_state()
    _require_init(state)

    all_members: list[tuple[str, "Persona"]] = []
    for role in CORE_TEAM_ROLES:
        try:
            p = state.load_persona(role)
            all_members.append((role, p))
        except FileNotFoundError:
            pass

    for c in state.list_consultants():
        all_members.append((c.name.lower().replace(" ", "_"), c))

    console.print("\n  [bold]Who do you want to talk to?[/bold]")
    for i, (_, persona) in enumerate(all_members, 1):
        console.print(f"    [bold]{i}.[/bold] {persona.name} - {persona.title}")

    console.print()
    pick = Prompt.ask("[bold yellow]CEO[/bold yellow]")

    try:
        idx = int(pick) - 1
    except ValueError:
        console.print("[red]Enter a number.[/red]")
        return

    if idx < 0 or idx >= len(all_members):
        console.print("[red]Invalid selection.[/red]")
        return

    _, persona = all_members[idx]
    ctx.invoke(main_group.get_command(ctx, "1on1"), agent_name=persona.name)
