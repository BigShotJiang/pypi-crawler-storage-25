"""Company values - shared principles that guide every agent's decisions.

The CEO sets these during init or anytime. They become a system prompt
fragment injected into EVERY agent invocation, ensuring consistent
decision-making across the entire organization.
"""

from __future__ import annotations

import json
from pathlib import Path

from odd.config import VALUES_CONFIG_FILE


class CompanyValues:
    """Manages the organization's shared values and principles."""

    def __init__(self, odd_dir: Path):
        self.config_path = odd_dir / VALUES_CONFIG_FILE

    def set_values(self, values: list[str]) -> None:
        """Set the company values."""
        data = {"values": values}
        self.config_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def add_value(self, value: str) -> None:
        values = self.get_values()
        values.append(value)
        self.set_values(values)

    def remove_value(self, index: int) -> str | None:
        values = self.get_values()
        if 0 <= index < len(values):
            removed = values.pop(index)
            self.set_values(values)
            return removed
        return None

    def get_values(self) -> list[str]:
        if not self.config_path.exists():
            return []
        data = json.loads(self.config_path.read_text(encoding="utf-8"))
        return data.get("values", [])

    def system_prompt_fragment(self) -> str:
        """Generate the system prompt fragment injected into every agent."""
        values = self.get_values()
        if not values:
            return ""
        lines = ["## Company Values", "These principles guide all your decisions and work:\n"]
        for i, v in enumerate(values, 1):
            lines.append(f"{i}. {v}")
        return "\n".join(lines)

