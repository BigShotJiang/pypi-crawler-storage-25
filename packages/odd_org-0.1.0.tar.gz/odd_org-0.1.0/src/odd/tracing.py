"""Agent observability - structured trace logging for sprint debugging.

Writes JSONL records to .odd/logs/activity.jsonl so the CEO can replay what
happened during a sprint: which agents were called, what tools they used,
what they cost, and why they escalated.

Record types (discriminated by ``type`` field):
- api_call   - one record per AgentEngine.invoke() call (includes cost data)
- tool_use   - one record per tool execution
- escalation - one record per escalation event
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from odd.config import ACTIVITY_FILE

logger = logging.getLogger("odd.tracing")

# Module-level path - set once via init_tracing(), read by log functions.
_logs_dir: Path | None = None


def _activity_path() -> Path | None:
    """Return the path to the unified activity log, or None if not init'd."""
    if _logs_dir is None:
        return None
    return _logs_dir / ACTIVITY_FILE


def init_tracing(odd_dir: Path) -> None:
    """Activate tracing by pointing it at the .odd/ directory."""
    global _logs_dir
    _logs_dir = odd_dir / "logs"
    _logs_dir.mkdir(parents=True, exist_ok=True)

    # Migrate legacy audit.jsonl entries into the unified activity log
    _migrate_legacy_audit(_logs_dir)

    logger.debug("Tracing initialized: %s", _logs_dir)


def log_agent_call(
    *,
    agent_name: str,
    role: str,
    model: str,
    system_prompt_len: int,
    user_message: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    input_cost: float = 0.0,
    output_cost: float = 0.0,
    tool_calls: int = 0,
    iterations: int = 0,
    stop_reason: str = "",
    duration_ms: int = 0,
    sprint: int | None = None,
    phase: str | None = None,
    error: str | None = None,
) -> None:
    """Log a complete agent invocation (one invoke() call)."""
    path = _activity_path()
    if path is None:
        return

    record: dict[str, Any] = {
        "type": "api_call",
        "ts": datetime.now(timezone.utc).isoformat(),
        "agent": agent_name,
        "role": role,
        "model": model,
        "system_prompt_len": system_prompt_len,
        "user_message_preview": user_message[:200],
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "input_cost": input_cost,
        "output_cost": output_cost,
        "tool_calls": tool_calls,
        "iterations": iterations,
        "stop_reason": stop_reason,
        "duration_ms": duration_ms,
    }
    if sprint is not None:
        record["sprint"] = sprint
    if phase is not None:
        record["phase"] = phase
    if error:
        record["error"] = error

    _append(path, record)
    logger.debug(
        "Agent call: %s (%s) model=%s tokens=%d+%d cost=$%.4f tools=%d",
        agent_name, role, model, input_tokens, output_tokens,
        input_cost + output_cost, tool_calls,
    )


def log_escalation(
    *,
    agent_name: str,
    reason: str,
    severity: str,
    sprint: int | None = None,
) -> None:
    """Log an escalation event."""
    path = _activity_path()
    if path is None:
        return

    record: dict[str, Any] = {
        "type": "escalation",
        "ts": datetime.now(timezone.utc).isoformat(),
        "agent": agent_name,
        "reason": reason,
        "severity": severity,
    }
    if sprint is not None:
        record["sprint"] = sprint

    _append(path, record)


def log_tool_use(
    *,
    agent: str,
    tool: str,
    tool_input: dict[str, Any],
    result: str,
    duration_ms: int,
    exit_code: int | None = None,
    sprint: int | None = None,
    blocked: bool = False,
) -> None:
    """Log a single tool execution."""
    path = _activity_path()
    if path is None:
        return

    truncated_result = result[:2000] if len(result) > 2000 else result
    record: dict[str, Any] = {
        "type": "tool_use",
        "ts": datetime.now(timezone.utc).isoformat(),
        "agent": agent,
        "tool": tool,
        "input": tool_input,
        "result": truncated_result,
        "duration_ms": duration_ms,
    }
    if exit_code is not None:
        record["exit_code"] = exit_code
    if sprint is not None:
        record["sprint"] = sprint
    if blocked:
        record["blocked"] = True

    _append(path, record)


def load_trace(
    odd_dir: Path,
    log_name: str = "activity",
    record_type: str | None = None,
) -> list[dict[str, Any]]:
    """Load a trace log. Returns list of records, newest last.

    Args:
        odd_dir: The .odd/ directory.
        log_name: Base name of the JSONL file (without extension).
                  Defaults to "activity" (the unified log).
        record_type: If set, only return records with this ``type`` value
                     (e.g. "api_call", "tool_use", "escalation").
    """
    log_path = odd_dir / "logs" / f"{log_name}.jsonl"
    if not log_path.exists():
        return []
    records = []
    for line in log_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if record_type is not None and rec.get("type") != record_type:
            continue
        records.append(rec)
    return records


def load_sprint_trace(
    odd_dir: Path,
    sprint_number: int,
    log_name: str = "activity",
    record_type: str | None = None,
) -> list[dict[str, Any]]:
    """Load trace records for a specific sprint only."""
    return [
        r for r in load_trace(odd_dir, log_name, record_type=record_type)
        if r.get("sprint") == sprint_number
    ]


def log_stream_event(
    *,
    agent_name: str,
    event_type: str,
    text: str | None = None,
    tool_name: str | None = None,
    tool_id: str | None = None,
    tool_input: dict[str, Any] | None = None,
    stop_reason: str | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
) -> None:
    """Log a single streaming event to the stream debug log.

    Only writes if tracing has been initialized (init_tracing called).
    """
    if _logs_dir is None:
        return

    path = _logs_dir / "stream_debug.jsonl"

    record: dict[str, Any] = {
        "type": "stream_event",
        "ts": datetime.now(timezone.utc).isoformat(),
        "agent": agent_name,
        "event_type": event_type,
    }
    if text is not None:
        record["text"] = text[:500]
    if tool_name is not None:
        record["tool_name"] = tool_name
    if tool_id is not None:
        record["tool_id"] = tool_id
    if tool_input is not None:
        record["tool_input"] = tool_input
    if stop_reason is not None:
        record["stop_reason"] = stop_reason
    if input_tokens is not None:
        record["input_tokens"] = input_tokens
    if output_tokens is not None:
        record["output_tokens"] = output_tokens

    _append(path, record)


def _append(path: Path, record: dict[str, Any]) -> None:
    """Append a JSON record to a JSONL file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def _migrate_legacy_audit(logs_dir: Path) -> None:
    """Migrate legacy audit.jsonl entries into the unified activity log.

    Tags each record with ``type: "tool_use"`` and appends to activity.jsonl,
    then renames the old file to audit.jsonl.migrated.
    """
    old = logs_dir / "audit.jsonl"
    activity = logs_dir / ACTIVITY_FILE
    if not old.exists():
        return
    # Only migrate if the activity file doesn't already exist (first run)
    # or if audit.jsonl still has un-migrated entries.
    # Simple guard: if we already migrated, the .migrated file exists.
    if (logs_dir / "audit.jsonl.migrated").exists():
        return

    try:
        entries = []
        for line in old.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                rec.setdefault("type", "tool_use")
                entries.append(rec)
            except json.JSONDecodeError:
                continue

        if entries:
            with activity.open("a", encoding="utf-8") as f:
                for rec in entries:
                    f.write(json.dumps(rec) + "\n")

        old.rename(logs_dir / "audit.jsonl.migrated")
        logger.info("Migrated %d audit records to activity.jsonl", len(entries))
    except Exception:
        logger.warning("Failed to migrate audit.jsonl", exc_info=True)
