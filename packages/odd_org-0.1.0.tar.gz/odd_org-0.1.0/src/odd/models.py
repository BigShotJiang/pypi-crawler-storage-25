"""Core data models for ODD."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

import unicodedata

from pydantic import BaseModel, Field, model_validator

class ModelTier(str, Enum):
    HIGH = "high"          # thinking roles (was OPUS)
    STANDARD = "standard"  # execution roles (was SONNET)
    FAST = "fast"          # cheap/fast tasks (was HAIKU)

    @classmethod
    def from_name(cls, name: str) -> "ModelTier":
        """Resolve a user-facing model name to a tier.

        Accepts tier values ("high"), enum names ("HIGH"), or provider
        shorthand ("opus"/"sonnet"/"haiku"). Returns STANDARD on unknown input.
        """
        _aliases: dict[str, "ModelTier"] = {
            "opus": cls.HIGH, "sonnet": cls.STANDARD, "haiku": cls.FAST,
        }
        key = name.strip().lower()
        # Try alias first, then enum value, then enum name
        if key in _aliases:
            return _aliases[key]
        try:
            return cls(key)
        except ValueError:
            pass
        try:
            return cls[key.upper()]
        except KeyError:
            return cls.STANDARD


class RoleType(str, Enum):
    LEAD_DEV = "lead_dev"
    QA = "qa"
    RECRUITER = "recruiter"
    SECRETARY = "secretary"
    CONSULTANT = "consultant"


# Sensible defaults: Opus for thinking roles, Sonnet for execution roles
DEFAULT_MODEL_MAP: dict[RoleType, ModelTier] = {
    RoleType.LEAD_DEV: ModelTier.HIGH,
    RoleType.QA: ModelTier.HIGH,
    RoleType.RECRUITER: ModelTier.STANDARD,
    RoleType.SECRETARY: ModelTier.STANDARD,
    RoleType.CONSULTANT: ModelTier.STANDARD,
}


def _to_slug(name: str) -> str:
    """Normalize a name to the slug used in directory paths.

    Applies NFKD Unicode normalization and strips non-ASCII characters
    before slugifying, so that compatibility characters (e.g. Roman
    numeral Ⅴ → V) are collapsed to their ASCII equivalents.
    """
    normalized = unicodedata.normalize("NFKD", name)
    ascii_name = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_name.lower().replace(" ", "_").replace("-", "_")


def _has_non_ascii(name: str) -> bool:
    """Return True if the name contains any non-ASCII characters."""
    try:
        name.encode("ascii")
        return False
    except UnicodeEncodeError:
        return True


# ASCII characters commonly confused with letters in certain fonts.
# Maps confusable char → the letter it impersonates.
_ASCII_CONFUSABLES: dict[str, str] = {
    "0": "o",
    "1": "l",
    "5": "s",
    "8": "b",
    "3": "e",
}


def _has_ascii_confusables(name: str, reserved: set[str]) -> str | None:
    """Check if substituting common ASCII look-alikes produces a reserved slug.

    Returns the colliding reserved slug, or None if no collision.
    For example, "C0dy" → try replacing 0→o → "cody" → collision.
    """
    slug = _to_slug(name)
    # Generate all single-character substitution variants
    chars = list(slug)
    # BFS over substitutions - cap at 256 candidates to prevent
    # combinatorial explosion on pathological names with many confusable chars.
    _MAX_CANDIDATES = 256
    candidates = {slug}
    for i, ch in enumerate(chars):
        if ch in _ASCII_CONFUSABLES:
            new_candidates = set()
            for candidate in candidates:
                replaced = candidate[:i] + _ASCII_CONFUSABLES[ch] + candidate[i + 1:]
                new_candidates.add(replaced)
            candidates |= new_candidates
            if len(candidates) > _MAX_CANDIDATES:
                # Too many confusable characters - reject unconditionally.
                # We can't exhaustively check, so fail closed.
                return "<too_many_confusables>"
    # Check if any variant hits a reserved slug
    for candidate in candidates:
        if candidate in reserved:
            return candidate
    return None


# Names reserved for core team members and the CFO - consultants cannot use these.
RESERVED_SLUGS = {"cody", "vera", "scout", "paige", "bill"}


class Persona(BaseModel):
    """An agent's identity - built from their JD and resume."""

    role_type: RoleType
    name: str
    title: str
    job_description: str = ""
    resume: str = ""
    model: ModelTier | None = None  # None = use default for role
    hire_reason: str = ""  # Why Cody recommended this hire (skill gap)
    hired_sprint: int | None = None  # Which sprint they were hired during

    @model_validator(mode="after")
    def _check_reserved_name(self) -> "Persona":
        """Reject consultants whose slug collides with a core team name.

        Also rejects names with non-ASCII characters to prevent homoglyph
        impersonation (e.g. Cyrillic С looking like Latin C).
        """
        if self.role_type == RoleType.CONSULTANT:
            if _has_non_ascii(self.name):
                raise ValueError(
                    f"Consultant name '{self.name}' contains non-ASCII characters. "
                    f"Names must use ASCII letters only to prevent homoglyph attacks."
                )
            slug = _to_slug(self.name)
            if not slug or not any(c.isalpha() for c in slug):
                raise ValueError(
                    f"Consultant name '{self.name}' must contain ASCII letters"
                )
            if slug in RESERVED_SLUGS:
                raise ValueError(
                    f"Consultant name '{self.name}' (slug: {slug}) conflicts with a "
                    f"reserved core team name. Choose a different name."
                )
            # Check ASCII look-alikes (e.g. "C0dy" with zero → "cody")
            confusable_hit = _has_ascii_confusables(self.name, RESERVED_SLUGS)
            if confusable_hit and confusable_hit != slug:
                if confusable_hit == "<too_many_confusables>":
                    raise ValueError(
                        f"Consultant name '{self.name}' contains too many characters "
                        f"that resemble letters. Choose a clearer name."
                    )
                raise ValueError(
                    f"Consultant name '{self.name}' is visually confusable with "
                    f"reserved name '{confusable_hit}'. Choose a different name."
                )
        return self

    def effective_model(self) -> ModelTier:
        return self.model or DEFAULT_MODEL_MAP[self.role_type]


class TaskOutcome(BaseModel):
    """A single recorded outcome of a consultant completing (or failing) a task."""

    sprint_number: int
    task_id: str
    task_description: str
    passed: bool  # did it clear the TDD gate?
    retries: int = 0  # how many TDD retries were needed


class ConsultantRecord(BaseModel):
    """Lifetime performance record for a consultant."""

    name: str
    outcomes: list[TaskOutcome] = Field(default_factory=list)

    # --- Competence signals ---

    @property
    def tasks_completed(self) -> int:
        return sum(1 for o in self.outcomes if o.passed)

    @property
    def tasks_failed(self) -> int:
        return sum(1 for o in self.outcomes if not o.passed)

    @property
    def success_rate(self) -> float:
        if not self.outcomes:
            return 0.0
        return self.tasks_completed / len(self.outcomes)

    @property
    def first_run_pass_rate(self) -> float:
        """Fraction of tasks that passed on the first try (0 retries)."""
        if not self.outcomes:
            return 0.0
        first_run = sum(1 for o in self.outcomes if o.passed and o.retries == 0)
        return first_run / len(self.outcomes)

    @property
    def self_correction_rate(self) -> float:
        """Of tasks that needed retries, how many eventually passed?"""
        needed_retries = [o for o in self.outcomes if o.retries > 0]
        if not needed_retries:
            return 0.0
        return sum(1 for o in needed_retries if o.passed) / len(needed_retries)

    @property
    def tasks_still_failing(self) -> int:
        """Tasks that never passed - unresolved work."""
        return sum(1 for o in self.outcomes if not o.passed)

    # --- Effort signals ---

    @property
    def avg_retries(self) -> float:
        if not self.outcomes:
            return 0.0
        return sum(o.retries for o in self.outcomes) / len(self.outcomes)

    @property
    def max_retries(self) -> int:
        """Worst-case retries on a single task."""
        if not self.outcomes:
            return 0
        return max(o.retries for o in self.outcomes)

    @property
    def retry_trend(self) -> float:
        """Trend in retries over recent sprints.

        Computes the average of per-sprint retry averages for each half,
        so sprints with more tasks don't dominate the signal.
        Positive = getting worse, negative = improving.
        Returns 0.0 if fewer than 2 sprints of data.
        """
        sprints = sorted(self.sprints_participated)
        if len(sprints) < 2:
            return 0.0
        mid = len(sprints) // 2
        old_sprints = sprints[:mid]
        new_sprints = sprints[mid:]

        def _sprint_avg(sprint_numbers: list[int]) -> float:
            avgs = []
            for s in sprint_numbers:
                tasks = [o for o in self.outcomes if o.sprint_number == s]
                if tasks:
                    avgs.append(sum(o.retries for o in tasks) / len(tasks))
            return sum(avgs) / len(avgs) if avgs else 0.0

        return _sprint_avg(new_sprints) - _sprint_avg(old_sprints)

    # --- Tenure signals ---

    @property
    def sprints_participated(self) -> list[int]:
        """Sorted list of unique sprint numbers this consultant worked in."""
        return sorted({o.sprint_number for o in self.outcomes})

    @property
    def tenure(self) -> int:
        """Number of distinct sprints participated in."""
        return len(self.sprints_participated)

    @property
    def total_tasks(self) -> int:
        return len(self.outcomes)

    # --- Methods ---

    def record(self, outcome: TaskOutcome) -> None:
        self.outcomes.append(outcome)

    def summary(self) -> str:
        """One-line summary for display."""
        if not self.outcomes:
            return "no track record"
        total = len(self.outcomes)
        first_run = self.first_run_pass_rate * 100
        parts = [
            f"{self.tasks_completed}/{total} tasks passed",
            f"{first_run:.0f}% first-run",
        ]
        if self.self_correction_rate > 0:
            parts.append(f"{self.self_correction_rate * 100:.0f}% self-corrected")
        parts.append(f"avg {self.avg_retries:.1f} retries")
        if self.tenure > 1:
            parts.append(f"{self.tenure} sprints")
        return " | ".join(parts)

    def experience_summary(self) -> str:
        """Multi-line summary for inclusion in 1:1 conversation context."""
        if not self.outcomes:
            return "No work experience recorded yet."
        lines = [
            f"Tasks completed: {self.tasks_completed}/{self.total_tasks}",
            f"First-run pass rate: {self.first_run_pass_rate * 100:.0f}%",
        ]
        retried = [o for o in self.outcomes if o.retries > 0]
        if retried:
            lines.append(f"Self-correction rate: {self.self_correction_rate * 100:.0f}%")
        lines.append(f"Average retries: {self.avg_retries:.1f} (max: {self.max_retries})")
        lines.append(f"Sprints participated: {self.tenure}")
        if self.tasks_still_failing:
            lines.append(f"Unresolved tasks: {self.tasks_still_failing}")
        trend = self.retry_trend
        if abs(trend) > 0.3:
            direction = "increasing" if trend > 0 else "decreasing"
            lines.append(f"Retry trend: {direction} ({trend:+.1f})")
        return "\n".join(lines)


class SprintCheckpoint(BaseModel):
    """Records the last successfully completed stage of a sprint.

    Used for resume-after-crash: the sprint engine can skip completed
    stages and pick up from where things left off.
    """

    stage: str  # "planning", "qa", "phase_1", "phase_2", ..., "review"
    completed_at: str  # ISO timestamp
    completed_task_ids: list[str] = Field(default_factory=list)
    test_context: str | None = None  # preserved for resume after QA


class SprintStatus(str, Enum):
    PLANNING = "planning"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    DEMO = "demo"
    COMPLETE = "complete"
    CANCELLED = "cancelled"


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"


class SprintTask(BaseModel):
    """A single task within a sprint."""

    id: str
    description: str
    assigned_to: str  # persona name
    status: TaskStatus = TaskStatus.PENDING
    test_file: str | None = None  # path to test that gates this task


class SprintPhase(BaseModel):
    """A sequential phase within a sprint.

    Tasks within a phase are independent and can execute concurrently.
    Phases execute sequentially - earlier phases make way for later ones.
    """

    number: int
    description: str  # e.g. "Set up the data models and config"
    task_ids: list[str] = Field(default_factory=list)


class CodeReviewPass(BaseModel):
    """A single pass of code review."""

    pass_number: int
    score: int  # 1-10
    findings: list[str] = Field(default_factory=list)
    has_critical: bool = False


class CodeReview(BaseModel):
    """Full code review for a sprint."""

    sprint_number: int
    depth: str  # "quick", "standard", "thorough"
    max_passes: int
    threshold: int = 8
    passes: list[CodeReviewPass] = Field(default_factory=list)
    final_score: int | None = None


class Sprint(BaseModel):
    """A scope-boxed sprint."""

    number: int
    goal: str
    tasks: list[SprintTask] = Field(default_factory=list)
    phases: list[SprintPhase] = Field(default_factory=list)
    status: SprintStatus = SprintStatus.PLANNING
    standup_log: list[dict[str, Any]] = Field(default_factory=list)
    code_review: CodeReview | None = None
    notes: str = ""
    checkpoint: SprintCheckpoint | None = None


class CEOStyle(str, Enum):
    """How hands-on the CEO wants to be."""
    HANDS_ON = "hands_on"
    BALANCED = "balanced"
    DELEGATOR = "delegator"


class CEOGate(str, Enum):
    """Named decision points where CEO style affects behavior."""
    STREAMING = "streaming"          # solo agent output verbosity
    WAR_ROOM = "war_room"            # multi-agent parallel display
    ESCALATIONS = "escalations"      # what severity levels surface to CEO
    PLAN_APPROVAL = "plan_approval"  # whether CEO approves sprint plans
    CODE_REVIEW = "code_review"      # when code reviews are offered
    SHIP_APPROVAL = "ship_approval"  # auto-ship vs CEO prompt
    HIRING = "hiring"                # how hire suggestions are approved


class CEOInvolvement(str, Enum):
    """How often the CEO wants to check in during a roadmap."""
    EVERY_SPRINT = "every_sprint"
    MILESTONES = "milestones"
    BLOCKERS_ONLY = "blockers_only"

    @classmethod
    def from_ceo_style(cls, style: CEOStyle) -> "CEOInvolvement":
        """Derive roadmap involvement level from the project-wide CEO style."""
        return {
            CEOStyle.HANDS_ON: cls.EVERY_SPRINT,
            CEOStyle.BALANCED: cls.MILESTONES,
            CEOStyle.DELEGATOR: cls.BLOCKERS_ONLY,
        }[style]


class RoadmapSprint(BaseModel):
    """A planned sprint within a multi-sprint roadmap."""

    number: int
    deliverables: str
    is_milestone: bool = False  # CEO flagged as a check-in point
    status: str = "pending"  # pending, in_progress, complete, skipped


class Roadmap(BaseModel):
    """A multi-sprint plan created by Cody when the CEO's ask is too big for one sprint."""

    goal: str  # original CEO ask
    sprints: list[RoadmapSprint] = Field(default_factory=list)
    ceo_involvement: CEOInvolvement = CEOInvolvement.EVERY_SPRINT
    status: str = "active"  # active, complete, abandoned


class BlockerPolicy(str, Enum):
    """CEO's chosen policy for blocker escalations during vacation."""
    DELEGATE_TO_CODY = "delegate_to_cody"  # Cody makes the call
    PARK_AND_SKIP = "park_and_skip"        # Log it, skip the task, continue
    PAUSE_VACATION = "pause_vacation"      # Stop the loop, save state for resume


class VacationPlan(BaseModel):
    """The negotiated plan for an autonomous vacation run."""

    goal: str
    budget: float
    roadmap: Roadmap
    estimated_cost: float
    avg_cost_per_sprint: float
    blocker_policy: BlockerPolicy


class VacationSprintResult(BaseModel):
    """Outcome of one sprint during vacation."""

    sprint_number: int
    goal: str
    status: SprintStatus
    cost: float
    error: str | None = None


class VacationReport(BaseModel):
    """What the CEO sees when they come back from vacation."""

    plan: VacationPlan
    sprint_results: list[VacationSprintResult] = Field(default_factory=list)
    total_cost: float = 0.0
    budget_remaining: float = 0.0
    stopped_reason: str = "complete"  # "complete", "budget_exceeded", "paused", "error"
    summary: str = ""


class ProviderConfig(BaseModel):
    """Provider selection and connection settings."""
    model_config = {"extra": "forbid"}

    name: str = "anthropic"  # "anthropic", "openai-compat", or "openwebui"
    api_key_env: str = "ANTHROPIC_API_KEY"  # env var holding the API key
    base_url: str = ""  # only used for openai-compat
    model_map: dict[str, str] = Field(default_factory=dict)  # tier → model ID overrides

    @model_validator(mode="before")
    @classmethod
    def _strip_removed_fields(cls, data: Any) -> Any:
        """Strip fields removed in past versions so old config.json files still load."""
        if isinstance(data, dict):
            data.pop("engine", None)
        return data


class ProjectConfig(BaseModel):
    """Top-level ODD project configuration."""
    model_config = {"extra": "ignore"}

    name: str
    description: str = ""
    model_overrides: dict[RoleType, ModelTier] = Field(default_factory=dict)
    current_sprint: int = 0
    last_review_sprint: int = 0
    provider: ProviderConfig = Field(default_factory=ProviderConfig)
    ceo_style: CEOStyle = CEOStyle.BALANCED
    ceo_overrides: dict[CEOGate, CEOStyle] = Field(default_factory=dict)
    review_passes: int = 1  # default review passes per sprint (0 = skip)
    tdd_max_retries: int = 3  # CEO-configurable TDD retry limit
    phase_envelopes: dict[str, float] = Field(default_factory=dict)  # CEO overrides for phase budget splits
    debug: bool = False  # when True, log all streaming events to .odd/logs/stream_debug.jsonl

    def style_at(self, gate: CEOGate) -> CEOStyle:
        """Resolve effective CEO style for a specific gate."""
        return self.ceo_overrides.get(gate, self.ceo_style)

    def get_model(self, role: RoleType) -> ModelTier:
        return self.model_overrides.get(role, DEFAULT_MODEL_MAP[role])
