"""Core team role definitions and the recruiter pipeline."""

from __future__ import annotations

import logging

from odd.agent import AgentEngine
from odd.config import PHASE_TOKEN_DEFAULTS
from odd.models import ModelTier, Persona, RoleType
from odd.parsers import parse_candidate
from odd.tools import SUBMIT_CANDIDATE

logger = logging.getLogger(__name__)


def create_core_team(model_overrides: dict[RoleType, ModelTier] | None = None) -> dict[str, Persona]:
    """Create the four core team members."""
    overrides = model_overrides or {}

    lead_dev = Persona(
        role_type=RoleType.LEAD_DEV,
        name="Cody",
        title="Lead Developer",
        job_description=(
            "You are the technical lead for this project. You:\n"
            "- Are the CEO's primary point of contact\n"
            "- Make architectural decisions\n"
            "- Delegate specialized work to consultants\n"
            "- Coordinate with QA on test requirements\n"
            "- Write code for core features\n"
            "- Drive sprints forward and report progress"
        ),
        model=overrides.get(RoleType.LEAD_DEV),
    )

    qa = Persona(
        role_type=RoleType.QA,
        name="Vera",
        title="QA Engineer - The Glitch Hunter",
        job_description=(
            "You are the QA engineer. You:\n"
            "- Write tests FIRST, before implementation (TDD)\n"
            "- Think adversarially about edge cases\n"
            "- Verify that implementations pass all tests\n"
            "- Go out of your way to break things\n"
            "- Report bugs with clear reproduction steps\n"
            "- Never let bad code slip through"
        ),
        model=overrides.get(RoleType.QA),
    )

    recruiter = Persona(
        role_type=RoleType.RECRUITER,
        name="Scout",
        title="Technical Recruiter",
        job_description=(
            "You find the perfect specialist for any job. Given a job description, "
            "you craft a detailed resume/profile for the ideal consultant. Your "
            "output directly shapes how an AI agent will approach the project, so be "
            "specific about skills, experience, methodology, and unique perspective."
        ),
        model=overrides.get(RoleType.RECRUITER),
    )

    secretary = Persona(
        role_type=RoleType.SECRETARY,
        name="Paige",
        title="Project Secretary",
        job_description=(
            "You keep the organization running. You:\n"
            "- Take structured notes during standups\n"
            "- Maintain project documentation in .odd/notes/\n"
            "- Track decisions and action items\n"
            "- Organize files and keep things tidy\n"
            "- Flag items needing the CEO's attention\n"
            "- Produce clear progress summaries"
        ),
        model=overrides.get(RoleType.SECRETARY),
    )

    return {
        "lead_dev": lead_dev,
        "qa": qa,
        "recruiter": recruiter,
        "secretary": secretary,
    }


def recruit_consultant(
    engine: AgentEngine,
    recruiter: Persona,
    job_description: str,
    consultant_name: str | None = None,
    model_tier: ModelTier | None = None,
) -> Persona:
    """The recruiter pipeline: JD in → ideal consultant persona out.

    The recruiter receives a job description and produces the perfect
    candidate's resume. That resume becomes the consultant's identity.

    If no name is provided, the recruiter generates one.
    """
    prompt = (
        f"A new consultant position has opened up. Here is the job description:\n\n"
        f"---\n{job_description}\n---\n\n"
        f"Please write a detailed resume/profile for the IDEAL candidate for this "
        f"role. Use the submit_candidate tool to submit the candidate.\n\n"
        f"IMPORTANT - naming tradition: Our team uses names that are playful puns or "
        f"phonetic winks at what the person does. Examples from the core team:\n"
        f"  - Cody the Lead Developer (writes the CODE)\n"
        f"  - Vera the QA engineer (she VERA-fies everything)\n"
        f"  - Scout the Recruiter (SCOUT-s for talent)\n"
        f"  - Paige the Secretary (keeps PAIGEs of notes)\n"
        f"  - Bill the CFO (tracks every BILL)\n"
        f"Give this consultant a first name that follows the same tradition - their "
        f"name should be a real human name that also winks at their specialty.\n\n"
        f"IMPORTANT - voice: Write the resume in FIRST PERSON. This resume becomes "
        f"the consultant's identity - they will read it as 'this is who I am.' Use "
        f"'I built...', 'I specialize in...', 'My approach is...' throughout. Never "
        f"use third person.\n\n"
        f"Include in the resume:\n"
        f"1. Years of experience and key skills\n"
        f"2. Notable past projects or achievements\n"
        f"3. Their technical approach and methodology\n"
        f"4. What unique perspective they bring to problems\n"
        f"5. How they communicate and collaborate\n\n"
        f"Fallback format (if you can't use the tool):\n"
        f"NAME: <their first name>\n"
        f"TITLE: <their professional title>\n"
        f"Then the full resume text.\n\n"
        f"Be specific and detailed - this profile will be used to shape how they "
        f"approach their work on the project."
    )

    resume = engine.invoke(persona=recruiter, user_message=prompt, tools=False, extra_tools=[SUBMIT_CANDIDATE])

    # Check for structured submission, fall back to string parsing
    submissions = engine.pop_submissions("submit_candidate")
    structured = submissions[0]["data"] if submissions else None
    parsed_name, parsed_title, resume_text = parse_candidate(resume, structured_data=structured)

    # Caller-provided name takes precedence
    name = consultant_name or parsed_name
    title = parsed_title

    # Fallback if parsing fails
    if not name:
        name = "Consultant"
    if not title:
        title = name

    persona = Persona(
        role_type=RoleType.CONSULTANT,
        name=name,
        title=title,
        job_description=job_description,
        resume=resume_text,
        model=model_tier,
    )

    # Self-refinement: the consultant polishes their own resume
    persona = _refine_resume(engine, persona)

    return persona


def _refine_resume(engine: AgentEngine, persona: Persona) -> Persona:
    """Have the consultant refine their own resume before 'applying'.

    If refinement fails for any reason, the original persona is returned
    unchanged - this step only improves, never degrades.
    """
    try:
        prompt = (
            f"You are {persona.name}, {persona.title}. You are preparing to apply "
            f"for a new position. Below is a draft of your resume:\n\n"
            f"---\n{persona.resume}\n---\n\n"
            f"Review this resume and rewrite it to be more specific and compelling. "
            f"Replace any vague or generic claims with concrete details - specific "
            f"technologies, measurable outcomes, particular methodologies. A resume "
            f"that says 'experienced with databases' should instead say which "
            f"databases, what scale, what problems were solved.\n\n"
            f"Write in FIRST PERSON throughout - 'I built...', 'I specialize in...'. "
            f"This resume is YOUR identity.\n\n"
            f"Use the submit_candidate tool to submit your improved resume. "
            f"Keep your name and title the same."
        )

        engine.invoke(
            persona=persona,
            user_message=prompt,
            tools=False,
            extra_tools=[SUBMIT_CANDIDATE],
            max_tokens=PHASE_TOKEN_DEFAULTS["resume_refinement"],
        )

        submissions = engine.pop_submissions("submit_candidate")
        refined = submissions[0]["data"] if submissions else None

        if refined and refined.get("resume"):
            return persona.model_copy(update={"resume": refined["resume"]})

    except Exception:
        logger.debug("Resume refinement failed, keeping original", exc_info=True)

    return persona
