"""Thinking spinner - shows animated feedback while waiting for agent responses.

Starts a Rich Status spinner on creation and stops it when the first
content arrives (text or tool use). Safe to call stop() multiple times.
"""

from __future__ import annotations

from rich.console import Console
from rich.status import Status


class ThinkingSpinner:
    """Animated 'thinking...' indicator that auto-stops on first output.

    Usage::

        spinner = ThinkingSpinner("Cody", console)
        spinner.start()
        # ... wait for API response ...
        spinner.stop()   # idempotent, safe to call many times
    """

    def __init__(self, agent_name: str, console: Console, message: str | None = None) -> None:
        self.agent_name = agent_name
        self.console = console
        label = message or f"{agent_name} is thinking..."
        self._status = Status(
            f"[bold cyan]{label}[/bold cyan]",
            console=console,
            spinner="dots",
        )
        self._running = False

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Start the spinner animation."""
        if not self._running:
            self._status.start()
            self._running = True

    def stop(self) -> None:
        """Stop the spinner (idempotent)."""
        if self._running:
            self._status.stop()
            self._running = False
