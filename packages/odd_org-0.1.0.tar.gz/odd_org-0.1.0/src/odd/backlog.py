"""Persistent backlog - work items that live across sprints.

The CEO adds items, the lead dev prioritizes them into sprints.
Items not completed in a sprint carry forward automatically.
"""

from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from odd.config import BACKLOG_FILE, BACKLOG_ITEM_ID_PREFIX


class Priority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NICE_TO_HAVE = "nice_to_have"


class BacklogItem(BaseModel):
    id: str
    description: str
    priority: Priority = Priority.MEDIUM
    added_by: str = "CEO"  # who requested it
    sprint_assigned: int | None = None  # which sprint picked it up
    status: str = "open"  # open, in_sprint, done, cut
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()


class Backlog:
    """Persistent prioritized backlog stored in .odd/backlog.json."""

    def __init__(self, odd_dir: Path):
        self.path = odd_dir / BACKLOG_FILE
        self._items: list[BacklogItem] = self._load()

    def _load(self) -> list[BacklogItem]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BacklogItem(**item) for item in data]

    def _save(self) -> None:
        data = [item.to_dict() for item in self._items]
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def save(self) -> None:
        """Persist current backlog state to disk."""
        self._save()

    def add(self, description: str, priority: Priority = Priority.MEDIUM, added_by: str = "CEO") -> BacklogItem:
        item_id = f"{BACKLOG_ITEM_ID_PREFIX}{len(self._items) + 1}"
        item = BacklogItem(id=item_id, description=description, priority=priority, added_by=added_by)
        self._items.append(item)
        self._save()
        return item

    def assign_to_sprint(self, item_id: str, sprint_number: int) -> None:
        item = self.get(item_id)
        if item:
            item.sprint_assigned = sprint_number
            item.status = "in_sprint"
            self._save()

    def complete(self, item_id: str) -> None:
        item = self.get(item_id)
        if item:
            item.status = "done"
            self._save()

    def cut(self, item_id: str) -> None:
        """Cut an item - decided not to do it."""
        item = self.get(item_id)
        if item:
            item.status = "cut"
            self._save()

    def get(self, item_id: str) -> BacklogItem | None:
        for item in self._items:
            if item.id == item_id:
                return item
        return None

    def open_items(self) -> list[BacklogItem]:
        return [i for i in self._items if i.status == "open"]

    def sprint_items(self, sprint_number: int) -> list[BacklogItem]:
        return [i for i in self._items if i.sprint_assigned == sprint_number]

    def all_items(self) -> list[BacklogItem]:
        return list(self._items)

    def summary_for_agent(self) -> str:
        """Produce a backlog summary for agent context."""
        open_items = self.open_items()
        if not open_items:
            return "Backlog is empty."

        priority_order = [Priority.CRITICAL, Priority.HIGH, Priority.MEDIUM, Priority.LOW, Priority.NICE_TO_HAVE]
        lines = ["Current backlog:"]
        for p in priority_order:
            items = [i for i in open_items if i.priority == p]
            if items:
                lines.append(f"\n  [{p.value.upper()}]")
                for item in items:
                    lines.append(f"    {item.id}: {item.description}")
        return "\n".join(lines)
