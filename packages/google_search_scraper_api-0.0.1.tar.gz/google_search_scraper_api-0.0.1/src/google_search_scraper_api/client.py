import requests


class GoogleSearchScraper:
    BASE_URL = "https://app.scrapingbee.com/api/v1/"

    def __init__(self, api_key: str):
        self.api_key = api_key

    def search(
        self,
        query: str,
        country: str = "us",
        language: str = "en",
        device: str = "desktop",
        start: int = 0,
        premium: bool = False,
    ) -> dict:
        params = {
            "api_key": self.api_key,
            "search": "google",
            "q": query,
            "country_code": country,
            "hl": language,
            "device": device,
            "start": start,
        }

        if premium:
            params["premium"] = "true"

        response = requests.get(self.BASE_URL, params=params)
        response.raise_for_status()
        return response.json()
