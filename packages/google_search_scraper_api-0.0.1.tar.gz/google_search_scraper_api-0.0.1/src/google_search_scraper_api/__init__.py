from .client import GoogleSearchScraper

__all__ = ["GoogleSearchScraper"]
