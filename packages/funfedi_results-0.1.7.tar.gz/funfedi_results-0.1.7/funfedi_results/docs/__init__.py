from pathlib import Path


class DocPaths:
    def __init__(self):
        self.snippets = Path("snippets")
        self.snippets.mkdir(exist_ok=True, parents=True)

    @property
    def codeberg_package_links(self):
        return self.snippets / "packages.md"
