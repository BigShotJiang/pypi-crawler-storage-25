import click

from .formatter import package_download_snippet

from . import DocPaths


@click.command
def doc_cli():
    """Writes the docs snippets"""
    paths = DocPaths()

    with paths.codeberg_package_links.open("w") as f:
        f.write(package_download_snippet())


if __name__ == "__main__":
    doc_cli()
