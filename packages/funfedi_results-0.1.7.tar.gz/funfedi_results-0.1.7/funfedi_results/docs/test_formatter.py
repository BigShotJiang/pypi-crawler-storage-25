from .formatter import package_download_snippet


def test_package_download_snippet():
    result = package_download_snippet()

    assert (
        result
        == """## Packages to download

* [parsing](https://codeberg.org/funfedidev/-/packages/generic/results_funfedi_parsing)
* [parsing_notes](https://codeberg.org/funfedidev/-/packages/generic/results_funfedi_parsing_notes)
* [parsing_events](https://codeberg.org/funfedidev/-/packages/generic/results_funfedi_parsing_events)
* [parsing_polls](https://codeberg.org/funfedidev/-/packages/generic/results_funfedi_parsing_polls)
* [connect](https://codeberg.org/funfedidev/-/packages/generic/results_funfedi_connect)"""
    )
