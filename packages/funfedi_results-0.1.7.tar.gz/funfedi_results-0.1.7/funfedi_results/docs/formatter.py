from funfedi_results.codeberg import (
    CodebergPackageDownloader,
    KnownPackages,
    PackageDescription,
)


def package_download_snippet():
    lines = ["## Packages to download", ""]

    for package in KnownPackages:
        downloader = CodebergPackageDownloader(PackageDescription(package, "0.0.1"))
        lines.append(f"* [{package.name}]({downloader.download_url})")

    return "\n".join(lines)
