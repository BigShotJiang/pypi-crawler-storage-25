import logging
from pathlib import Path
import click

from .latest.__main__ import latest
from .codeberg.__main__ import codeberg
from .docs.__main__ import doc_cli

from .allure import AllureResults
from .display import display_command
from .codeberg import CodebergPackageDownloader, PackageDescription


@click.group
@click.option("--data_dir", default="./data")
@click.option("--verbose", is_flag=True, default=False)
@click.pass_context
def main(ctx: click.Context, data_dir: str, verbose: bool):
    ctx.ensure_object(dict)
    ctx.obj["data_dir"] = Path(data_dir)
    ctx.obj["data_dir"].mkdir(exist_ok=True)

    if verbose:
        logging.basicConfig(level=logging.INFO)


@main.command
@click.option(
    "--package", default="results_funfedi_connect", help="The results to display"
)
@click.option("--package_version", default="0.1.3", help="The version to display")
@click.option(
    "--as_allure_results",
    is_flag=True,
    default=False,
    help="Extracts into the allure-results directory",
)
@click.pass_context
def download(
    ctx: click.Context, package: str, package_version: str, as_allure_results: bool
):
    package_description = PackageDescription(package, package_version)
    downloader = CodebergPackageDownloader(package_description)
    downloader.download_latest(ctx.obj["data_dir"])

    if as_allure_results:
        allure_results = AllureResults()
        file_directory = downloader.target_directory(ctx.obj["data_dir"])
        allure_results.extract(file_directory)


main.add_command(display_command, "display")
main.add_command(latest, "latest")
main.add_command(codeberg, "codeberg")
main.add_command(doc_cli, "docs")

if __name__ == "__main__":
    main()
