from dataclasses import dataclass, field

from funfedi_connect import ImplementedFeature

from . import features_for_result

from .types import ResultDescription


@dataclass
class PassingCount:
    feature: ImplementedFeature
    passed: int = field(default=0)
    failed: int = field(default=0)

    @property
    def total(self):
        return self.passed + self.failed

    def add_pass(self):
        self.passed = self.passed + 1

    def add_fail(self):
        self.failed = self.passed + 1

    def status(self):
        if self.total == 0:
            return ""
        if self.passed == 0:
            return "❌"
        if self.failed == 0:
            return "✅"

        return f"{self.passed}/{self.total}"


def passing_counts(result_description: ResultDescription):
    data = features_for_result(result_description)

    counts = {feature: PassingCount(feature) for feature in ImplementedFeature}

    for feature_result in data:
        for tag in feature_result.tags:
            try:
                feature = ImplementedFeature.from_tag(tag)
                if feature_result.status == "passed":
                    counts[feature].add_pass()
                else:
                    counts[feature].add_fail()
            except Exception:
                ...

    return counts
