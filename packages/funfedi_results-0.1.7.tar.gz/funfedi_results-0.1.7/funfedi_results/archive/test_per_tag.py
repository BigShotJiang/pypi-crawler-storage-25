import os
import pytest


from funfedi_results.codeberg import KnownPackages, PackageDescription
from funfedi_connect import ImplementedFeature

from .per_tag import passing_counts
from .types import ResultDescription


@pytest.mark.skipif(not os.path.exists("data"), reason="No test data")
def test_per_tag():
    package = PackageDescription(KnownPackages.connect, "0.2.0")
    desc = ResultDescription(package, "pleroma", "v2.10.0")

    result = passing_counts(desc)

    assert result[ImplementedFeature.event].total == 0
    assert result[ImplementedFeature.public_timeline].total == 1
    assert result[ImplementedFeature.post].total == 1
    assert result[ImplementedFeature.webfinger].total == 7
