from funfedi_results.archive.types import FeatureResult

from .parse import features_from_result, load_archive

from .types import ResultDescription

__all__ = ["ResultDescription"]


def features_for_result(desc: ResultDescription) -> list[FeatureResult]:
    archive = load_archive(desc)

    return features_from_result(archive)
