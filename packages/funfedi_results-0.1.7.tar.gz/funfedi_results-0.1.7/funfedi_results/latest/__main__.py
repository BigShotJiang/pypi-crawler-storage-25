import json

import click

from funfedi_results.codeberg import CodebergPackageDownloader, PackageDescription


@click.command
@click.option(
    "--package", default="results_funfedi_connect", help="The results to display"
)
@click.option("--package_version", default="0.1.3", help="The version to display")
@click.option("--json", "display_as_json", is_flag=True, default=False)
def latest(package: str, package_version: str, display_as_json):
    package_description = PackageDescription(package, package_version)
    downloader = CodebergPackageDownloader(package_description)

    if display_as_json:
        print(json.dumps(downloader.latest_version_per_app(), indent=2))
    else:
        for name, version in downloader.latest_version_per_app().items():
            print(f"{name + ':':<20}{version}")


if __name__ == "__main__":
    latest()
