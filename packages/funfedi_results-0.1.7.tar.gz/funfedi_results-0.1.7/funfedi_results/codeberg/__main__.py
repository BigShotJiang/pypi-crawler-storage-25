import click

from .package_description import PackageDescription
from .uploader import CodebergUploader


@click.group
@click.pass_context
def codeberg(ctx: click.Context):
    """Commands to interact with the versions posted on codeberg"""
    ctx.ensure_object(dict)
    ctx.obj["uploader"] = CodebergUploader.from_env()


@codeberg.command
@click.pass_context
@click.option(
    "--package", default="results_funfedi_connect", help="The results to display"
)
@click.option("--package_version", default="0.1.3", help="The version to display")
@click.argument("filename")
def delete(ctx: click.Context, package: str, package_version: str, filename: str):
    package_description = PackageDescription(package, package_version)

    ctx.obj["uploader"].delete_file(package_description, filename)


if __name__ == "__main__":
    codeberg()
