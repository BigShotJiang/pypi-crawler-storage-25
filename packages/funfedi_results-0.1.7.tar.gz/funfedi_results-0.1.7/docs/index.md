# funfedi results

tools to work with the results from [funfedi.dev](https://funfedi.dev/)



--8<-- "./snippets/packages.md"


