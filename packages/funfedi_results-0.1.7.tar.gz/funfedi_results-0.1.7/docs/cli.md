::: mkdocs-click
    :module: funfedi_results.__main__
    :command: main
    :prog_name: python -mfunfedi_results
    :depth: 0
    :style: table
