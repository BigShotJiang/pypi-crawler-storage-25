# skrec

This is an alias package for [scikit-rec](https://pypi.org/project/scikit-rec/).

Install scikit-rec directly:

```bash
pip install scikit-rec
```

```python
import skrec
```
