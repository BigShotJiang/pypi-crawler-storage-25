﻿# CapCard.ai

**Machine-verifiable capability cards for the agent economy.**

Agents don't read marketing copy — they parse structured, reproducible, verifiable facts.

CapCard is the infrastructure layer for **Capability Cards**: 
JSON-LD documents that describe what a product actually does, with:
- Quantitative benchmarks and reproducible scripts
- Verification proofs (test counts, Docker hashes, arXiv links)
- Integration hooks

**Monogate v2.1.1** is the canonical reference implementation.

## Status
Early development — April 2026  
Domain: https://capcard.ai

## Quick Start (coming soon)
```bash
pip install capcard
capcard validate examples/monogate-capability-card.json
