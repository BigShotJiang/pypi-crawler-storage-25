"""capcard CLI — verify, init."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .validator import validate_card

_USAGE = """\
capcard — trust infrastructure for the agent economy

Commands:
  capcard verify <path>   Validate a capability_card.json
  capcard init            Scaffold a starter capability_card.json

Options:
  -h, --help              Show this message
"""


def _detect_project() -> dict:
    """Best-effort detection of name/version from pyproject.toml or package.json."""
    here = Path.cwd()

    pyproject = here / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8")
        name, version = None, None
        for line in text.splitlines():
            if line.startswith("name") and "=" in line and name is None:
                name = line.split("=", 1)[1].strip().strip('"').strip("'")
            if line.startswith("version") and "=" in line and version is None:
                version = line.split("=", 1)[1].strip().strip('"').strip("'")
        if name:
            return {"name": name, "version": version or "0.1.0"}

    pkg = here / "package.json"
    if pkg.exists():
        try:
            d = json.loads(pkg.read_text(encoding="utf-8"))
            return {"name": d.get("name", "my-project"), "version": d.get("version", "0.1.0")}
        except json.JSONDecodeError:
            pass

    return {"name": here.name, "version": "0.1.0"}


def _cmd_init() -> None:
    out = Path.cwd() / "capability_card.json"
    if out.exists():
        print(f"capability_card.json already exists at {out}")
        print("Delete it first or edit it directly.")
        sys.exit(1)

    proj = _detect_project()
    name = proj["name"]
    version = proj["version"]
    today = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    card = {
        "capcard_version": "1.0.0",
        "id": f"ai.capcard.{name.replace('-', '_').replace(' ', '_').lower()}",
        "name": name,
        "type": "library",
        "description": f"Describe what {name} does.",
        "version": version,
        "license": "MIT",
        "repository": f"https://github.com/username/{name}",
        "authors": [{"name": "Your Name", "role": "creator"}],
        "capabilities": [
            {
                "id": "my.first.capability",
                "name": "Example Capability",
                "category": "computation",
                "description": "Describe what this capability does and what evidence supports it.",
                "status": "empirically_confirmed",
                "tags": ["example"]
            }
        ],
        "benchmarks": [
            {
                "id": "bench.example",
                "name": "Example Benchmark",
                "capability_ref": "my.first.capability",
                "metric": "accuracy",
                "value": 0.95,
                "unit": "fraction",
                "direction": "higher_is_better",
                "reproducibility": {
                    "command": "pytest tests/ -q",
                    "deterministic": True
                }
            }
        ],
        "verification": {
            "last_verified": today,
            "commit_hash": "UPDATE_AFTER_COMMIT"
        },
        "metadata": {
            "created": today,
            "updated": today,
            "schema_url": "https://capcard.ai/schema/v1/capability_card.schema.json"
        }
    }

    out.write_text(json.dumps(card, indent=2), encoding="utf-8")
    print(f"Created capability_card.json in {Path.cwd()}")
    print()
    print("Next steps:")
    print("  1. Edit the file — fill in your real capabilities and benchmarks")
    print("  2. Set status honestly: proven / empirically_confirmed / experimental / conjecture")
    print("  3. Run: capcard verify capability_card.json")


def _cmd_verify(path: str) -> None:
    report = validate_card(path)
    print(json.dumps(report, indent=2))
    sys.exit(0 if report["valid"] else 1)


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print(_USAGE)
        sys.exit(0)

    cmd = args[0]

    if cmd == "verify":
        if len(args) < 2:
            print("Error: missing path.\n\nUsage: capcard verify <path>", file=sys.stderr)
            sys.exit(2)
        _cmd_verify(args[1])

    elif cmd == "init":
        _cmd_init()

    else:
        print(f"Unknown command: {cmd}\n\n{_USAGE}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
