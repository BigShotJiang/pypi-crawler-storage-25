"""CapCard — machine-readable capability profiles for the agent economy."""

__version__ = "0.1.0"
