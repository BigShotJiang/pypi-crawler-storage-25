"""Card validation: schema check + benchmark reproducibility sanity."""

from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any

try:
    from jsonschema import validate, ValidationError
except ImportError as e:
    raise ImportError("jsonschema is required: pip install jsonschema>=4.0.0") from e

_SCHEMA_PATH = Path(__file__).parent.parent / "schema" / "v1.json"


def _load_schema() -> dict:
    with open(_SCHEMA_PATH, encoding="utf-8") as f:
        return json.load(f)


def _check_reproducibility(benchmarks: list[dict]) -> list[str]:
    """Parse benchmark reproducibility.command fields with shlex (no execution)."""
    errors: list[str] = []
    for bench in benchmarks:
        repro = bench.get("reproducibility") or {}
        cmd = repro.get("command")
        if not cmd:
            continue
        try:
            shlex.split(cmd)
        except ValueError as e:
            errors.append(f"Benchmark '{bench.get('id', '?')}' has unparseable command: {e}")
    return errors


def validate_card(card_path: str) -> dict[str, Any]:
    """Validate a Capability Card. Returns a structured JSON report."""
    path = Path(card_path)
    errors: list[str] = []

    # ── Load ──────────────────────────────────────────────────────────────────
    if not path.exists():
        return {
            "valid": False,
            "card_name": None,
            "version": None,
            "capabilities_count": 0,
            "benchmarks_count": 0,
            "proofs_count": 0,
            "trust_score": None,
            "errors": [f"File not found: {card_path}"],
        }

    try:
        with open(path, encoding="utf-8") as f:
            card = json.load(f)
    except json.JSONDecodeError as e:
        return {
            "valid": False,
            "card_name": None,
            "version": None,
            "capabilities_count": 0,
            "benchmarks_count": 0,
            "proofs_count": 0,
            "trust_score": None,
            "errors": [f"JSON parse error: {e}"],
        }

    # ── Schema validation ─────────────────────────────────────────────────────
    try:
        schema = _load_schema()
        validate(instance=card, schema=schema)
    except ValidationError as e:
        errors.append(f"Schema error: {e.message}")
    except Exception as e:
        errors.append(f"Schema load error: {e}")

    # ── Benchmark reproducibility sanity ──────────────────────────────────────
    benchmarks = card.get("benchmarks", [])
    errors.extend(_check_reproducibility(benchmarks))

    # ── Trust score ───────────────────────────────────────────────────────────
    trust_score = None
    verification = card.get("verification", {})
    if isinstance(verification, dict):
        ts = verification.get("trust_score")
        if isinstance(ts, dict):
            trust_score = ts.get("value")

    return {
        "valid": len(errors) == 0,
        "card_name": card.get("name"),
        "version": card.get("version"),
        "capabilities_count": len(card.get("capabilities", [])),
        "benchmarks_count": len(benchmarks),
        "proofs_count": len(card.get("proofs", [])),
        "trust_score": trust_score,
        "errors": errors,
    }
