from dataclasses import dataclass, field
from typing import Optional, Dict, List
from enum import Enum

class ProviderType(Enum):
    OPENAI = "openai"
    DEEPSEEK = "deepseek"
    DASHSCOPE = "dashscope"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE = "azure"
    MISTRAL = "mistral"
    COHERE = "cohere"
    MOONSHOT = "moonshot"
    UNKNOWN = "unknown"

REASONING_MODEL_PATTERNS = ["o1-", "o3-", "deepseek-reasoner", "deepseek-r1", "qwq-", "claude-3-opus", "gemini-ultra"]

def is_reasoning_model(model):
    if not model:
        return False
    return any(p in model.lower() for p in REASONING_MODEL_PATTERNS)

@dataclass
class ProviderProfile:
    provider: ProviderType
    fast_fail_timeout: float = 1.0
    standard_timeout: float = 7.0
    patient_timeout: float = 25.0
    standard_retries: int = 2
    patient_retries: int = 5
    rpm_limit: Optional[int] = None
    url_patterns: List[str] = field(default_factory=list)
    model_prefixes: List[str] = field(default_factory=list)

PROVIDER_PROFILES = {
    ProviderType.OPENAI: ProviderProfile(ProviderType.OPENAI, 1.0, 5.0, 15.0, 2, 3, 500, ["api.openai.com"], ["gpt-", "o1-", "o3-"]),
    ProviderType.DEEPSEEK: ProviderProfile(ProviderType.DEEPSEEK, 2.0, 10.0, 30.0, 2, 5, 60, ["api.deepseek.com"], ["deepseek-"]),
    ProviderType.DASHSCOPE: ProviderProfile(ProviderType.DASHSCOPE, 2.0, 8.0, 25.0, 2, 4, 120, ["dashscope"], ["qwen-", "qwq-"]),
    ProviderType.UNKNOWN: ProviderProfile(ProviderType.UNKNOWN, 1.0, 7.0, 25.0, 2, 5),
}

def detect_provider(base_url=None, model=None):
    if base_url:
        for pt, pf in PROVIDER_PROFILES.items():
            if pt == ProviderType.UNKNOWN:
                continue
            for p in pf.url_patterns:
                if p in base_url.lower():
                    return pt
    if model:
        for pt, pf in PROVIDER_PROFILES.items():
            if pt == ProviderType.UNKNOWN:
                continue
            for px in pf.model_prefixes:
                if model.lower().startswith(px):
                    return pt
    return ProviderType.UNKNOWN

def get_profile(provider):
    return PROVIDER_PROFILES.get(provider, PROVIDER_PROFILES[ProviderType.UNKNOWN])
