"""
NeuralBridge Diagnoser Module

Free diagnostic tool for AI API errors - The "Trojan Horse" entry point.
Based on V6/V8 diagnostic logic trained on 9000+ real error samples.

Author: NeuralBridge™ / 王桂桂
"""

import re
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum


class DiagnosedFaultType(str, Enum):
    """Fault types supported by the diagnoser."""
    
    # Network Layer
    TIMEOUT = "timeout"
    DNS_FAILURE = "dns_failure"
    CONNECTION_RESET = "connection_reset"
    SSL_ERROR = "ssl_error"
    NETWORK_UNREACHABLE = "network_unreachable"
    PROXY_ERROR = "proxy_error"
    
    # Auth Layer
    AUTH_ERROR = "auth_error"
    API_KEY_EXPIRED = "api_key_expired"
    RATE_LIMIT = "rate_limit"
    QUOTA_EXHAUSTED = "quota_exhausted"
    PERMISSION_DENIED = "permission_denied"
    IP_NOT_AUTHORIZED = "ip_not_authorized"
    REGION_NOT_SUPPORTED = "region_not_supported"
    
    # Request Layer
    INVALID_MODEL = "invalid_model"
    CONTEXT_OVERFLOW = "context_overflow"
    INVALID_PARAMETER = "invalid_parameter"
    EMPTY_BODY = "empty_body"
    REQUEST_TOO_LARGE = "request_too_large"
    INVALID_MESSAGE_FORMAT = "invalid_message_format"
    UNSUPPORTED_PARAMETER = "unsupported_parameter"
    
    # Response Layer
    EMPTY_RESPONSE = "empty_response"
    RESPONSE_TRUNCATED = "response_truncated"
    MALFORMED_RESPONSE = "malformed_response"
    STREAM_INTERRUPTED = "stream_interrupted"
    CONTENT_FILTER = "content_filter"
    ENCODING_ERROR = "encoding_error"
    
    # System Layer
    SERVER_ERROR = "server_error"
    SERVICE_OVERLOADED = "service_overloaded"
    SERVICE_MAINTENANCE = "service_maintenance"
    BAD_GATEWAY = "bad_gateway"
    MODEL_DEPRECATED = "model_deprecated"
    
    # Business Layer
    ACCOUNT_SUSPENDED = "account_suspended"
    CONCURRENCY_LIMIT = "concurrency_limit"
    TOKEN_REFRESH_FAILED = "token_refresh_failed"
    COMPLIANCE_BLOCKED = "compliance_blocked"
    
    # Special
    UNKNOWN = "unknown"
    API_HEALTHY = "api_healthy"


@dataclass
class FixSuggestion:
    """A single fix suggestion."""
    
    action: str           # Short action description
    command: str          # Code/config snippet
    explanation: str      # Why this helps
    priority: int         # 1 = highest


@dataclass
class DiagnosisResult:
    """Complete diagnosis result."""
    
    fault_type: DiagnosedFaultType
    confidence: float           # 0.0 - 1.0
    severity: str               # "critical", "high", "medium", "low"
    root_cause: str             # Plain English explanation
    technical_details: str      # Technical details
    suggestions: List[FixSuggestion]
    category: str               # "network", "auth", "request", "response", "system", "business"
    is_healthy: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "fault_type": self.fault_type.value,
            "confidence": self.confidence,
            "severity": self.severity,
            "root_cause": self.root_cause,
            "technical_details": self.technical_details,
            "suggestions": [asdict(s) for s in self.suggestions],
            "category": self.category,
            "is_healthy": self.is_healthy,
        }


class APIDiagnoser:
    """
    AI API Diagnostic Engine.
    
    Diagnoses API errors and provides actionable fix suggestions.
    Based on 9000+ real error samples from V3/V6/V7/V8 systems.
    
    Usage:
        >>> diagnoser = APIDiagnoser()
        >>> result = diagnoser.diagnose(
        ...     error_message="Rate limit exceeded",
        ...     status_code=429
        ... )
        >>> print(result.root_cause)
        "Your account has hit the rate limit for requests"
    """
    
    # HTTP Status code -> Fault type mapping
    HTTP_STATUS_MAP: Dict[int, DiagnosedFaultType] = {
        400: DiagnosedFaultType.INVALID_PARAMETER,
        401: DiagnosedFaultType.AUTH_ERROR,
        402: DiagnosedFaultType.QUOTA_EXHAUSTED,
        403: DiagnosedFaultType.PERMISSION_DENIED,
        404: DiagnosedFaultType.INVALID_MODEL,
        408: DiagnosedFaultType.TIMEOUT,
        409: DiagnosedFaultType.RATE_LIMIT,
        413: DiagnosedFaultType.REQUEST_TOO_LARGE,
        422: DiagnosedFaultType.INVALID_MODEL,
        429: DiagnosedFaultType.RATE_LIMIT,
        500: DiagnosedFaultType.SERVER_ERROR,
        502: DiagnosedFaultType.BAD_GATEWAY,
        503: DiagnosedFaultType.SERVICE_OVERLOADED,
        504: DiagnosedFaultType.TIMEOUT,
    }
    
    # Error message patterns -> Fault type, confidence multipliers
    PATTERN_MAP: List[Tuple[re.Pattern, DiagnosedFaultType, float]] = [
        # === TIMEOUT ===
        (re.compile(r"timeout|timed out|ConnectTimeoutError|ReadTimeoutError", re.I), 
         DiagnosedFaultType.TIMEOUT, 0.9),
        (re.compile(r"operation timed out|request timeout|connection timeout", re.I), 
         DiagnosedFaultType.TIMEOUT, 0.95),
        
        # === DNS & NETWORK ===
        (re.compile(r"DNS|Name or service not known|getaddrinfo|nxdomain", re.I), 
         DiagnosedFaultType.DNS_FAILURE, 0.95),
        (re.compile(r"Connection reset|ECONNRESET|reset by peer", re.I), 
         DiagnosedFaultType.CONNECTION_RESET, 0.9),
        (re.compile(r"SSL|TLS|CERTIFICATE_VERIFY_FAILED|ssl_error|hostname mismatch", re.I), 
         DiagnosedFaultType.SSL_ERROR, 0.95),
        (re.compile(r"Network is unreachable|No route to host", re.I), 
         DiagnosedFaultType.NETWORK_UNREACHABLE, 0.95),
        (re.compile(r"proxy|Proxy|Connection refused by proxy", re.I), 
         DiagnosedFaultType.PROXY_ERROR, 0.9),
        
        # === AUTH ===
        (re.compile(r"Invalid API key|API key.*invalid|incorrect api key|unauthorized", re.I), 
         DiagnosedFaultType.AUTH_ERROR, 0.95),
        (re.compile(r"api.key.expired|token.*expired|Token has expired", re.I), 
         DiagnosedFaultType.API_KEY_EXPIRED, 0.9),
        (re.compile(r"rate limit|Rate limit|429|Too Many Requests|rpm|tpm|per minute|requests per", re.I), 
         DiagnosedFaultType.RATE_LIMIT, 0.95),
        (re.compile(r"quota|exceeded.*quota|insufficient.*balance|402|credit.*low", re.I), 
         DiagnosedFaultType.QUOTA_EXHAUSTED, 0.9),
        (re.compile(r"permission|Permission denied|403|forbidden|no permission", re.I), 
         DiagnosedFaultType.PERMISSION_DENIED, 0.9),
        (re.compile(r"IP.*not.*authorized|ip whitelist|IP.*not.*allowed", re.I), 
         DiagnosedFaultType.IP_NOT_AUTHORIZED, 0.9),
        (re.compile(r"Country.*not.*supported|region.*not.*supported|geo-restriction", re.I), 
         DiagnosedFaultType.REGION_NOT_SUPPORTED, 0.85),
        
        # === MODEL & REQUEST ===
        (re.compile(r"model.*not.*found|Model not found|model.*not.*exist|does not support.*model", re.I), 
         DiagnosedFaultType.INVALID_MODEL, 0.95),
        (re.compile(r"context.*length|token.*limit|too long|max.*length|string too long", re.I), 
         DiagnosedFaultType.CONTEXT_OVERFLOW, 0.9),
        (re.compile(r"Invalid parameter|invalid.*value|must be between", re.I), 
         DiagnosedFaultType.INVALID_PARAMETER, 0.85),
        (re.compile(r"empty|Missing.*messages|body.*empty|request.*body.*empty", re.I), 
         DiagnosedFaultType.EMPTY_BODY, 0.85),
        (re.compile(r"413|Payload Too Large|Request too large|exceeds.*limit", re.I), 
         DiagnosedFaultType.REQUEST_TOO_LARGE, 0.9),
        (re.compile(r"message.*format|must have.*role|invalid.*message|role.*required", re.I), 
         DiagnosedFaultType.INVALID_MESSAGE_FORMAT, 0.9),
        (re.compile(r"unsupported.*parameter|Unknown parameter|not.*supported", re.I), 
         DiagnosedFaultType.UNSUPPORTED_PARAMETER, 0.85),
        
        # === RESPONSE ===
        (re.compile(r"empty.*response|no.*content|choices.*empty|NoneType.*text", re.I), 
         DiagnosedFaultType.EMPTY_RESPONSE, 0.9),
        (re.compile(r"truncated|MAX_TOKENS|finish_reason.*MAX|cut off|incomplete.*response", re.I), 
         DiagnosedFaultType.RESPONSE_TRUNCATED, 0.9),
        (re.compile(r"JSON.*error|Invalid JSON|malformed|parse.*error|json.*decode", re.I), 
         DiagnosedFaultType.MALFORMED_RESPONSE, 0.9),
        (re.compile(r"stream.*interrupt|disconnected|premature.*close|SSE.*close", re.I), 
         DiagnosedFaultType.STREAM_INTERRUPTED, 0.85),
        (re.compile(r"safety|content.*filter|finish_reason.*SAFETY|harmful.*content|blocked", re.I), 
         DiagnosedFaultType.CONTENT_FILTER, 0.85),
        (re.compile(r"encoding|UnicodeDecodeError|Invalid UTF|utf.*error", re.I), 
         DiagnosedFaultType.ENCODING_ERROR, 0.9),
        
        # === SYSTEM ===
        (re.compile(r"500|Internal.*error|server.*error|internal.*server", re.I), 
         DiagnosedFaultType.SERVER_ERROR, 0.9),
        (re.compile(r"503|Service.*unavailable|overloaded|Too many requests", re.I), 
         DiagnosedFaultType.SERVICE_OVERLOADED, 0.9),
        (re.compile(r"maintenance|under maintenance|scheduled.*downtime", re.I), 
         DiagnosedFaultType.SERVICE_MAINTENANCE, 0.9),
        (re.compile(r"502|Bad Gateway|Gateway.*timeout|upstream.*fail", re.I), 
         DiagnosedFaultType.BAD_GATEWAY, 0.9),
        (re.compile(r"deprecated|model.*deprecated|no longer available|end.*of.*life", re.I), 
         DiagnosedFaultType.MODEL_DEPRECATED, 0.9),
        
        # === BUSINESS ===
        (re.compile(r"account.*suspended|access.*denied|suspended|account.*locked|banned", re.I), 
         DiagnosedFaultType.ACCOUNT_SUSPENDED, 0.9),
        (re.compile(r"concurrent.*limit|too many.*connection|max.*concurrent", re.I), 
         DiagnosedFaultType.CONCURRENCY_LIMIT, 0.85),
        (re.compile(r"token.*refresh|OAuth.*fail|token.*revoked", re.I), 
         DiagnosedFaultType.TOKEN_REFRESH_FAILED, 0.85),
        (re.compile(r"policy.*violation|compliance|not.*supported.*content", re.I), 
         DiagnosedFaultType.COMPLIANCE_BLOCKED, 0.85),
    ]
    
    # Detailed fix suggestions for each fault type
    FIX_SUGGESTIONS: Dict[DiagnosedFaultType, List[Dict[str, str]]] = {
        DiagnosedFaultType.TIMEOUT: [
            {"action": "Increase timeout", "command": 'timeout=120', "explanation": "Set a longer timeout for slow responses"},
            {"action": "Use exponential backoff", "command": 'delay *= 2', "explanation": "Wait longer between retries"},
            {"action": "Check network", "command": 'curl -I <base_url>', "explanation": "Verify network connectivity"},
            {"action": "Reduce request size", "command": 'truncate messages', "explanation": "Smaller requests timeout less often"},
            {"action": "Switch to faster model", "command": 'model="gpt-3.5-turbo"', "explanation": "Faster models respond quicker"},
        ],
        DiagnosedFaultType.DNS_FAILURE: [
            {"action": "Check base URL", "command": 'base_url="https://api.openai.com/v1"', "explanation": "Verify the API endpoint is correct"},
            {"action": "Use IP directly", "command": 'nslookup api.openai.com', "explanation": "Check if DNS resolves correctly"},
            {"action": "Try HTTPS", "command": 'base_url="https://..."', "explanation": "Ensure using HTTPS protocol"},
            {"action": "Check firewall", "command": 'ping api.openai.com', "explanation": "Firewall may be blocking DNS"},
            {"action": "Use VPN", "command": 'Enable VPN', "explanation": "Some regions require VPN for API access"},
        ],
        DiagnosedFaultType.CONNECTION_RESET: [
            {"action": "Retry the request", "command": 'requests.post(..., retries=3)', "explanation": "Connection resets are often temporary"},
            {"action": "Use persistent connections", "command": 'Session()', "explanation": "Reuse connections to reduce resets"},
            {"action": "Add retry delays", "command": 'time.sleep(2)', "explanation": "Wait before retrying"},
            {"action": "Check VPN/proxy", "command": 'Disable VPN', "explanation": "VPNs can cause connection resets"},
            {"action": "Contact support", "command": 'Report to API provider', "explanation": "Persistent resets may indicate server issue"},
        ],
        DiagnosedFaultType.SSL_ERROR: [
            {"action": "Update certificates", "command": 'pip install --upgrade certifi', "explanation": "Update root certificates"},
            {"action": "Specify CA bundle", "command": 'verify="/path/to/cacert.pem"', "explanation": "Use correct CA bundle"},
            {"action": "Check date/time", "command": 'date -s "2024-01-01"', "explanation": "SSL fails if system time is wrong"},
            {"action": "Try HTTP (debug only)", "command": 'verify=False', "explanation": "ONLY for debugging - insecure!"},
            {"action": "Update Python/SSL", "command": 'pip install --upgrade urllib3', "explanation": "Update SSL libraries"},
        ],
        DiagnosedFaultType.NETWORK_UNREACHABLE: [
            {"action": "Check internet", "command": 'ping 8.8.8.8', "explanation": "Verify internet connectivity"},
            {"action": "Check firewall", "command": 'Disable firewall temporarily', "explanation": "Firewall may be blocking all traffic"},
            {"action": "Use VPN", "command": 'Enable VPN', "explanation": "VPN can bypass network restrictions"},
            {"action": "Try different network", "command": 'Switch to mobile hotspot', "explanation": "Corporate networks often block API ports"},
            {"action": "Check proxy settings", "command": 'env | grep -i proxy', "explanation": "Proxy misconfiguration"},
        ],
        DiagnosedFaultType.PROXY_ERROR: [
            {"action": "Check proxy config", "command": 'echo $HTTP_PROXY', "explanation": "Verify proxy environment variables"},
            {"action": "Update proxy auth", "command": 'export HTTP_PROXY="http://user:pass@host:port"', "explanation": "Proxy may need authentication"},
            {"action": "Bypass proxy for API", "command": 'no_proxy="api.openai.com"', "explanation": "Don't use proxy for API calls"},
            {"action": "Whitelist API domains", "command": 'Configure proxy whitelist', "explanation": "Add API domains to proxy whitelist"},
            {"action": "Try without proxy", "command": 'unset HTTP_PROXY', "explanation": "Test if proxy is the issue"},
        ],
        DiagnosedFaultType.AUTH_ERROR: [
            {"action": "Verify API key", "command": 'echo $OPENAI_API_KEY', "explanation": "Check if API key is set correctly"},
            {"action": "Regenerate key", "command": 'Dashboard -> API Keys -> Create', "explanation": "Old key may be revoked"},
            {"action": "Check key format", "command": 'sk-...', "explanation": "Ensure key starts with 'sk-'"},
            {"action": "Use environment variable", "command": 'export OPENAI_API_KEY="sk-..."', "explanation": "Don't hardcode API keys"},
            {"action": "Check organization", "command": 'openai.organization = "org-..."', "explanation": "Include organization header if required"},
        ],
        DiagnosedFaultType.API_KEY_EXPIRED: [
            {"action": "Check expiration", "command": 'Dashboard -> Billing', "explanation": "Check if subscription expired"},
            {"action": "Renew subscription", "command": 'Dashboard -> Plans', "explanation": "Reactivate your account"},
            {"action": "Generate new key", "command": 'Dashboard -> API Keys -> Create', "explanation": "Create a fresh API key"},
            {"action": "Add payment method", "command": 'Dashboard -> Payment', "explanation": "Add credit card to enable API"},
        ],
        DiagnosedFaultType.RATE_LIMIT: [
            {"action": "Wait and retry", "command": 'time.sleep(60)', "explanation": "Wait for rate limit to reset"},
            {"action": "Use exponential backoff", "command": 'delay *= 2; delay = min(delay, 60)', "explanation": "Increase wait time progressively"},
            {"action": "Reduce request rate", "command": 'batch requests', "explanation": "Send fewer requests per minute"},
            {"action": "Upgrade plan", "command": 'Dashboard -> Plans', "explanation": "Higher tiers have higher limits"},
            {"action": "Use rate limiter", "command": 'TokenBucket(60, 60)', "explanation": "Implement client-side rate limiting"},
        ],
        DiagnosedFaultType.QUOTA_EXHAUSTED: [
            {"action": "Check balance", "command": 'Dashboard -> Usage', "explanation": "See remaining credits"},
            {"action": "Add credits", "command": 'Dashboard -> Billing -> Add credits', "explanation": "Purchase more API credits"},
            {"action": "Use cheaper model", "command": 'model="gpt-3.5-turbo"', "explanation": "GPT-4 is 15x more expensive than 3.5"},
            {"action": "Optimize prompts", "command": 'reduce token count', "explanation": "Shorter prompts use fewer tokens"},
            {"action": "Set budget alerts", "command": 'Dashboard -> Usage -> Alerts', "explanation": "Get notified before running out"},
        ],
        DiagnosedFaultType.PERMISSION_DENIED: [
            {"action": "Check API key permissions", "command": 'Dashboard -> API Keys', "explanation": "Key may lack required permissions"},
            {"action": "Request access", "command": 'Dashboard -> Access', "explanation": "Some models require special access"},
            {"action": "Verify account status", "command": 'Dashboard -> Settings', "explanation": "Account may be restricted"},
            {"action": "Contact support", "command": 'Submit ticket', "explanation": "Permission issues may need manual resolution"},
        ],
        DiagnosedFaultType.IP_NOT_AUTHORIZED: [
            {"action": "Add IP to whitelist", "command": 'Dashboard -> Settings -> IP Whitelist', "explanation": "Allow your IP address"},
            {"action": "Disable IP restriction", "command": 'Turn off IP whitelist', "explanation": "Allow access from any IP"},
            {"action": "Use allowed IP", "command": 'Deploy from whitelisted server', "explanation": "Call API from authorized server"},
        ],
        DiagnosedFaultType.REGION_NOT_SUPPORTED: [
            {"action": "Use VPN", "command": 'Connect to supported region', "explanation": "VPN can bypass region restrictions"},
            {"action": "Use alternative API", "command": 'Try DeepSeek/Claude', "explanation": "Different providers have different regions"},
            {"action": "Request region access", "command": 'Contact support', "explanation": "Some regions can be enabled on request"},
        ],
        DiagnosedFaultType.INVALID_MODEL: [
            {"action": "Check model name", "command": 'model="gpt-4"', "explanation": "Verify model identifier is correct"},
            {"action": "Use available model", "command": 'model="gpt-3.5-turbo"', "explanation": "Use a model that exists"},
            {"action": "Check provider docs", "command": 'provider.com/docs/models', "explanation": "Model may be provider-specific"},
            {"action": "List available models", "command": 'GET /models', "explanation": "Check what models are available"},
        ],
        DiagnosedFaultType.CONTEXT_OVERFLOW: [
            {"action": "Truncate input", "command": 'messages = messages[-10:]', "explanation": "Keep only recent messages"},
            {"action": "Summarize history", "command": 'summarize_old_messages()', "explanation": "Reduce context by summarization"},
            {"action": "Use larger model", "command": 'model="gpt-4-32k"', "explanation": "32K context supports more tokens"},
            {"action": "Split conversation", "command": 'Start new conversation', "explanation": "Start fresh to reset context"},
            {"action": "Reduce max_tokens", "command": 'max_tokens=500', "explanation": "Request shorter responses"},
        ],
        DiagnosedFaultType.INVALID_PARAMETER: [
            {"action": "Check parameter names", "command": 'See API docs', "explanation": "Parameter names may be wrong"},
            {"action": "Check parameter types", "command": 'type(value)', "explanation": "Ensure correct data types"},
            {"action": "Check value ranges", "command": 'Docs say: 0.0-2.0', "explanation": "Values must be within valid range"},
            {"action": "Remove extra params", "command": 'Remove unknown params', "explanation": "Only include documented parameters"},
        ],
        DiagnosedFaultType.EMPTY_BODY: [
            {"action": "Add messages", "command": 'messages=[{"role":"user","content":"..."}]', "explanation": "Include at least one message"},
            {"action": "Check JSON format", "command": 'json.dumps(dict)', "explanation": "Ensure valid JSON body"},
            {"action": "Add required fields", "command": 'Include model + messages', "explanation": "Fill all required fields"},
        ],
        DiagnosedFaultType.REQUEST_TOO_LARGE: [
            {"action": "Reduce input size", "command": 'Truncate long text', "explanation": "Request body exceeds limit"},
            {"action": "Split into chunks", "command": 'Process in batches', "explanation": "Split large content"},
            {"action": "Use file upload", "command": 'Use file API', "explanation": "Upload large files via file API"},
            {"action": "Increase limit", "command": 'Contact support', "explanation": "Request higher limit if needed"},
        ],
        DiagnosedFaultType.INVALID_MESSAGE_FORMAT: [
            {"action": "Use correct format", "command": '{"role": "user", "content": "..."}', "explanation": "Messages must be {role, content} dicts"},
            {"action": "Include role", "command": 'role="user"|"assistant"|"system"', "explanation": "Each message needs a role"},
            {"action": "Valid roles only", "command": 'role in ["system","user","assistant"]', "explanation": "Only valid roles allowed"},
        ],
        DiagnosedFaultType.UNSUPPORTED_PARAMETER: [
            {"action": "Remove param", "command": 'del extra_param', "explanation": "Remove unsupported parameter"},
            {"action": "Check docs", "command": 'provider.com/docs', "explanation": "Verify supported parameters"},
            {"action": "Use compatible model", "command": 'Switch model', "explanation": "Some params only work with certain models"},
        ],
        DiagnosedFaultType.EMPTY_RESPONSE: [
            {"action": "Check content filter", "command": 'Rewrite prompt', "explanation": "Content may be filtered"},
            {"action": "Retry request", "command": 'Try again', "explanation": "Empty responses can be transient"},
            {"action": "Check model status", "command": 'provider.com/status', "explanation": "Model may be temporarily down"},
            {"action": "Verify request format", "command": 'Check API docs', "explanation": "Ensure request is valid"},
        ],
        DiagnosedFaultType.RESPONSE_TRUNCATED: [
            {"action": "Increase max_tokens", "command": 'max_tokens=2000', "explanation": "Allow longer responses"},
            {"action": "Request continuation", "command": '"Continue"', "explanation": "Ask model to continue"},
            {"action": "Reduce prompt", "command": 'Shorter prompt', "explanation": "Leave more room for response"},
        ],
        DiagnosedFaultType.MALFORMED_RESPONSE: [
            {"action": "Use JSON mode", "command": 'response_format={"type":"json_object"}', "explanation": "Request structured JSON output"},
            {"action": "Parse carefully", "command": 'try: json.loads() except:', "explanation": "Handle parse errors gracefully"},
            {"action": "Extract from text", "command": 'Extract JSON from response', "explanation": "Response may contain extra text"},
        ],
        DiagnosedFaultType.STREAM_INTERRUPTED: [
            {"action": "Use non-streaming", "command": 'stream=False', "explanation": "Avoid streaming issues"},
            {"action": "Implement reconnection", "command": 'Retry on disconnect', "explanation": "Handle stream interruptions"},
            {"action": "Cache partial responses", "command": 'Save progress', "explanation": "Resume from last chunk"},
        ],
        DiagnosedFaultType.CONTENT_FILTER: [
            {"action": "Rewrite prompt", "command": 'Rephrase content', "explanation": "Remove potentially sensitive content"},
            {"action": "Reduce sensitivity", "command": 'Lower safety settings', "explanation": "If appropriate for use case"},
            {"action": "Split request", "command": 'Process in chunks', "explanation": "Content may trigger filter when long"},
            {"action": "Check policy", "command": 'Read usage policies', "explanation": "Ensure content is allowed"},
        ],
        DiagnosedFaultType.ENCODING_ERROR: [
            {"action": "Set UTF-8 encoding", "command": 'encoding="utf-8"', "explanation": "Always use UTF-8"},
            {"action": "Clean text", "command": 'text.encode("utf-8").decode("utf-8")', "explanation": "Remove invalid characters"},
            {"action": "Handle special chars", "command": 'Replace emojis/symbols', "explanation": "Some APIs don't support special chars"},
        ],
        DiagnosedFaultType.SERVER_ERROR: [
            {"action": "Retry later", "command": 'time.sleep(30); retry()', "explanation": "Server errors are usually temporary"},
            {"action": "Check status page", "command": 'status.openai.com', "explanation": "Check for known outages"},
            {"action": "Use backup provider", "command": 'Switch to alternative API', "explanation": "Have fallback ready"},
            {"action": "Report issue", "command": 'Submit bug report', "explanation": "Help fix persistent issues"},
        ],
        DiagnosedFaultType.SERVICE_OVERLOADED: [
            {"action": "Wait and retry", "command": 'time.sleep(60)', "explanation": "Service is temporarily busy"},
            {"action": "Use exponential backoff", "command": 'delay *= 2', "explanation": "Increase wait time exponentially"},
            {"action": "Check status", "command": 'provider.com/status', "explanation": "See if outage is known"},
            {"action": "Use alternative", "command": 'Try different provider', "explanation": "Have backup provider ready"},
        ],
        DiagnosedFaultType.SERVICE_MAINTENANCE: [
            {"action": "Wait for completion", "command": 'Check status page', "explanation": "Maintenance windows are usually brief"},
            {"action": "Try alternative endpoint", "command": 'Use backup URL', "explanation": "Some APIs have mirror endpoints"},
            {"action": "Schedule request", "command": 'Retry after maintenance', "explanation": "API will be back soon"},
        ],
        DiagnosedFaultType.BAD_GATEWAY: [
            {"action": "Retry request", "command": 'Try again', "explanation": "Bad gateway errors are often transient"},
            {"action": "Check status", "command": 'provider.com/status', "explanation": "Check for known issues"},
            {"action": "Use different endpoint", "command": 'Try alternative base_url', "explanation": "Some endpoints may be down"},
        ],
        DiagnosedFaultType.MODEL_DEPRECATED: [
            {"action": "Migrate to new model", "command": 'model="gpt-4o"', "explanation": "Use the replacement model"},
            {"action": "Check migration guide", "command": 'See docs', "explanation": "Follow official migration path"},
            {"action": "Update code", "command": 'Replace old model name', "explanation": "Change model identifier"},
        ],
        DiagnosedFaultType.ACCOUNT_SUSPENDED: [
            {"action": "Contact support", "command": 'Submit appeal', "explanation": "Suspension may be a mistake"},
            {"action": "Check email", "command": 'See suspension reason', "explanation": "Reason should be in your email"},
            {"action": "Resolve issues", "command": 'Address violations', "explanation": "Fix policy violations if any"},
        ],
        DiagnosedFaultType.CONCURRENCY_LIMIT: [
            {"action": "Reduce parallel requests", "command": 'max_concurrent=5', "explanation": "Send fewer simultaneous requests"},
            {"action": "Use queue", "command": 'Queue requests', "explanation": "Process requests sequentially"},
            {"action": "Request higher limit", "command": 'Contact support', "explanation": "Request increased concurrency"},
        ],
        DiagnosedFaultType.TOKEN_REFRESH_FAILED: [
            {"action": "Re-authenticate", "command": 'Generate new token', "explanation": "OAuth tokens expire periodically"},
            {"action": "Refresh token", "command": 'Use refresh_token', "explanation": "Get a new access token"},
            {"action": "Check token expiry", "command": 'Decode JWT', "explanation": "Token may have expired"},
        ],
        DiagnosedFaultType.COMPLIANCE_BLOCKED: [
            {"action": "Remove violating content", "command": 'Rewrite request', "explanation": "Content violates policy"},
            {"action": "Check policy", "command": 'Read usage policy', "explanation": "Understand what's not allowed"},
            {"action": "Request exception", "command": 'Contact support', "explanation": "Some use cases can be approved"},
        ],
    }
    
    # Fault type metadata
    FAULT_METADATA: Dict[DiagnosedFaultType, Dict[str, str]] = {
        DiagnosedFaultType.TIMEOUT: {
            "category": "network",
            "severity": "high",
            "root_cause": "The API request took too long and was terminated",
            "technical": "Connection/Read timeout exceeded configured limit",
        },
        DiagnosedFaultType.DNS_FAILURE: {
            "category": "network",
            "severity": "critical",
            "root_cause": "Cannot resolve the API domain name",
            "technical": "DNS lookup failed - hostname cannot be resolved",
        },
        DiagnosedFaultType.CONNECTION_RESET: {
            "category": "network",
            "severity": "high",
            "root_cause": "Connection was forcibly closed by the server",
            "technical": "TCP connection reset (ECONNRESET) during handshake or transfer",
        },
        DiagnosedFaultType.SSL_ERROR: {
            "category": "network",
            "severity": "critical",
            "root_cause": "SSL/TLS certificate verification failed",
            "technical": "Certificate mismatch, expired, or untrusted CA",
        },
        DiagnosedFaultType.NETWORK_UNREACHABLE: {
            "category": "network",
            "severity": "critical",
            "root_cause": "Cannot reach the API server at all",
            "technical": "No network route to host - firewall or connectivity issue",
        },
        DiagnosedFaultType.PROXY_ERROR: {
            "category": "network",
            "severity": "medium",
            "root_cause": "Proxy server rejected the connection",
            "technical": "Proxy authentication failed or proxy unreachable",
        },
        DiagnosedFaultType.AUTH_ERROR: {
            "category": "auth",
            "severity": "critical",
            "root_cause": "API key is invalid or missing",
            "technical": "Authentication failed - wrong key, format, or no key provided",
        },
        DiagnosedFaultType.API_KEY_EXPIRED: {
            "category": "auth",
            "severity": "critical",
            "root_cause": "API key or token has expired",
            "technical": "Authentication token validity period ended",
        },
        DiagnosedFaultType.RATE_LIMIT: {
            "category": "auth",
            "severity": "high",
            "root_cause": "Too many requests in a short time",
            "technical": "RPM/TPM limit exceeded - wait before retrying",
        },
        DiagnosedFaultType.QUOTA_EXHAUSTED: {
            "category": "auth",
            "severity": "critical",
            "root_cause": "Account has no more credits or quota",
            "technical": "Monthly/daily quota exhausted or payment failed",
        },
        DiagnosedFaultType.PERMISSION_DENIED: {
            "category": "auth",
            "severity": "high",
            "root_cause": "API key lacks permission for this operation",
            "technical": "403 Forbidden - insufficient scope or permissions",
        },
        DiagnosedFaultType.IP_NOT_AUTHORIZED: {
            "category": "auth",
            "severity": "medium",
            "root_cause": "Your IP address is not whitelisted",
            "technical": "IP whitelist restriction active for this API key",
        },
        DiagnosedFaultType.REGION_NOT_SUPPORTED: {
            "category": "auth",
            "severity": "high",
            "root_cause": "Your region/country is not supported",
            "technical": "Geographic restriction - service not available in your region",
        },
        DiagnosedFaultType.INVALID_MODEL: {
            "category": "request",
            "severity": "high",
            "root_cause": "The specified model doesn't exist or is unavailable",
            "technical": "Model identifier not recognized or access not granted",
        },
        DiagnosedFaultType.CONTEXT_OVERFLOW: {
            "category": "request",
            "severity": "high",
            "root_cause": "Input exceeds model's maximum context length",
            "technical": "Token count > model's context window size",
        },
        DiagnosedFaultType.INVALID_PARAMETER: {
            "category": "request",
            "severity": "medium",
            "root_cause": "One or more request parameters are invalid",
            "technical": "Parameter validation failed - wrong type, value, or missing",
        },
        DiagnosedFaultType.EMPTY_BODY: {
            "category": "request",
            "severity": "medium",
            "root_cause": "Request body is empty or missing required fields",
            "technical": "Empty JSON body or missing required fields like 'messages'",
        },
        DiagnosedFaultType.REQUEST_TOO_LARGE: {
            "category": "request",
            "severity": "medium",
            "root_cause": "Request payload exceeds size limit",
            "technical": "Request body > max allowed size (usually 10-100MB)",
        },
        DiagnosedFaultType.INVALID_MESSAGE_FORMAT: {
            "category": "request",
            "severity": "medium",
            "root_cause": "Messages array has incorrect structure",
            "technical": "Messages must be [{role: str, content: str}, ...]",
        },
        DiagnosedFaultType.UNSUPPORTED_PARAMETER: {
            "category": "request",
            "severity": "low",
            "root_cause": "A parameter in your request is not supported",
            "technical": "Unknown or deprecated parameter provided",
        },
        DiagnosedFaultType.EMPTY_RESPONSE: {
            "category": "response",
            "severity": "high",
            "root_cause": "API returned no content",
            "technical": "Response has no choices - filtered or internal error",
        },
        DiagnosedFaultType.RESPONSE_TRUNCATED: {
            "category": "response",
            "severity": "medium",
            "root_cause": "Response was cut off at max_tokens limit",
            "technical": "finish_reason='length' - ran out of token budget",
        },
        DiagnosedFaultType.MALFORMED_RESPONSE: {
            "category": "response",
            "severity": "medium",
            "root_cause": "API response is not valid JSON or expected format",
            "technical": "JSON parsing failed or missing required fields",
        },
        DiagnosedFaultType.STREAM_INTERRUPTED: {
            "category": "response",
            "severity": "high",
            "root_cause": "Streaming response was interrupted",
            "technical": "Connection closed before receiving complete response",
        },
        DiagnosedFaultType.CONTENT_FILTER: {
            "category": "response",
            "severity": "medium",
            "root_cause": "Content was blocked by safety filters",
            "technical": "finish_reason='content_filter' - policy violation",
        },
        DiagnosedFaultType.ENCODING_ERROR: {
            "category": "response",
            "severity": "low",
            "root_cause": "Response contains invalid character encoding",
            "technical": "UTF-8/encoding mismatch in response text",
        },
        DiagnosedFaultType.SERVER_ERROR: {
            "category": "system",
            "severity": "high",
            "root_cause": "Internal error on the API provider's server",
            "technical": "500 Internal Server Error - provider-side issue",
        },
        DiagnosedFaultType.SERVICE_OVERLOADED: {
            "category": "system",
            "severity": "high",
            "root_cause": "API service is experiencing high load",
            "technical": "503 Service Unavailable - too many requests",
        },
        DiagnosedFaultType.SERVICE_MAINTENANCE: {
            "category": "system",
            "severity": "medium",
            "root_cause": "API service is under scheduled maintenance",
            "technical": "Maintenance window - service temporarily unavailable",
        },
        DiagnosedFaultType.BAD_GATEWAY: {
            "category": "system",
            "severity": "high",
            "root_cause": "Upstream gateway/proxy error",
            "technical": "502/504 Bad Gateway - intermediate server issue",
        },
        DiagnosedFaultType.MODEL_DEPRECATED: {
            "category": "system",
            "severity": "high",
            "root_cause": "The model has been retired or replaced",
            "technical": "Model no longer available - need to migrate",
        },
        DiagnosedFaultType.ACCOUNT_SUSPENDED: {
            "category": "business",
            "severity": "critical",
            "root_cause": "Your account has been suspended",
            "technical": "Access denied - contact support for resolution",
        },
        DiagnosedFaultType.CONCURRENCY_LIMIT: {
            "category": "business",
            "severity": "medium",
            "root_cause": "Too many parallel requests",
            "technical": "Concurrent request limit exceeded",
        },
        DiagnosedFaultType.TOKEN_REFRESH_FAILED: {
            "category": "business",
            "severity": "low",
            "root_cause": "OAuth token refresh failed",
            "technical": "Refresh token invalid or expired",
        },
        DiagnosedFaultType.COMPLIANCE_BLOCKED: {
            "category": "business",
            "severity": "high",
            "root_cause": "Request violates usage policy",
            "technical": "Content or operation not allowed by policy",
        },
    }
    
    def __init__(self) -> None:
        """Initialize the diagnoser."""
        self._pattern_cache = [(p, ft, conf) for p, ft, conf in self.PATTERN_MAP]
    
    def diagnose(
        self,
        error_message: Optional[str] = None,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
        response_headers: Optional[Dict[str, str]] = None,
    ) -> DiagnosisResult:
        """
        Diagnose an API error and return actionable results.
        
        Args:
            error_message: The error message string
            status_code: HTTP status code (if available)
            response_data: Full response JSON (if available)
            response_headers: Response headers (if available)
            
        Returns:
            DiagnosisResult with fault type, confidence, and fix suggestions
            
        Examples:
            >>> diagnoser = APIDiagnoser()
            >>> result = diagnoser.diagnose(
            ...     error_message="Rate limit exceeded",
            ...     status_code=429
            ... )
            >>> print(result.root_cause)
            "Your account has hit the rate limit for requests"
        """
        # Check for healthy response
        if status_code and status_code < 400 and not error_message:
            return self._healthy_result()
        
        # Check for API health check request
        if self._is_health_check(error_message, status_code, response_data):
            return self._healthy_result()
        
        # Extract error message from response data if not provided
        if not error_message and response_data:
            error_message = self._extract_error_message(response_data)
        
        # Detect fault type
        fault_type, confidence = self._detect_fault_type(error_message, status_code)
        
        # If still unknown, try response data analysis
        if fault_type == DiagnosedFaultType.UNKNOWN and response_data:
            fault_type, confidence = self._detect_from_response_data(response_data)
        
        # Get metadata and suggestions
        metadata = self.FAULT_METADATA.get(fault_type, {
            "category": "unknown",
            "severity": "medium",
            "root_cause": "Unknown error occurred",
            "technical": "Could not determine exact cause",
        })
        
        suggestions = self._get_suggestions(fault_type)
        
        # Build result
        return DiagnosisResult(
            fault_type=fault_type,
            confidence=confidence,
            severity=metadata["severity"],
            root_cause=metadata["root_cause"],
            technical_details=metadata["technical"],
            suggestions=suggestions,
            category=metadata["category"],
            is_healthy=False,
        )
    
    def _is_health_check(
        self,
        error_message: Optional[str],
        status_code: Optional[int],
        response_data: Optional[Dict[str, Any]],
    ) -> bool:
        """Check if this is a health check that should return healthy."""
        # Check if response contains valid API data
        if response_data:
            if "choices" in response_data and len(response_data.get("choices", [])) > 0:
                return True
            if "data" in response_data and isinstance(response_data.get("data"), list):
                return True
        
        # Check headers for success indicators
        if status_code and 200 <= status_code < 300:
            return True
        
        return False
    
    def _healthy_result(self) -> DiagnosisResult:
        """Return a healthy diagnosis result."""
        return DiagnosisResult(
            fault_type=DiagnosedFaultType.API_HEALTHY,
            confidence=1.0,
            severity="none",
            root_cause="API is responding correctly",
            technical_details="No errors detected - request was successful",
            suggestions=[],
            category="healthy",
            is_healthy=True,
        )
    
    def _extract_error_message(self, response_data: Dict[str, Any]) -> str:
        """Extract error message from response data."""
        if isinstance(response_data, dict):
            # Standard OpenAI error format
            if "error" in response_data:
                error = response_data["error"]
                if isinstance(error, dict):
                    return error.get("message", error.get("msg", str(error)))
                return str(error)
            
            # Direct message field
            if "message" in response_data:
                return str(response_data["message"])
            
            # Error code + message
            if "code" in response_data and "message" in response_data:
                return f"{response_data['code']}: {response_data['message']}"
        
        return str(response_data)
    
    def _detect_fault_type(
        self,
        error_message: Optional[str],
        status_code: Optional[int],
    ) -> Tuple[DiagnosedFaultType, float]:
        """
        Detect fault type from error message and status code.
        
        Returns:
            Tuple of (fault_type, confidence)
        """
        # Start with status code detection (high confidence when available)
        if status_code:
            status_fault = self.HTTP_STATUS_MAP.get(status_code)
            if status_fault:
                # Check if error message confirms or contradicts
                if error_message:
                    msg_fault, msg_conf = self._match_patterns(error_message)
                    if msg_fault == status_fault:
                        # Confirmed by both - high confidence
                        return status_fault, min(0.95, max(msg_conf, 0.9))
                    elif msg_fault != DiagnosedFaultType.UNKNOWN:
                        # Conflict - trust status code more for auth/network
                        if status_fault in [DiagnosedFaultType.AUTH_ERROR, DiagnosedFaultType.RATE_LIMIT, 
                                           DiagnosedFaultType.QUOTA_EXHAUSTED]:
                            return status_fault, 0.85
                        else:
                            return msg_fault, msg_conf
                    else:
                        return status_fault, 0.85
                else:
                    return status_fault, 0.9
        
        # Match against error message patterns
        if error_message:
            fault_type, confidence = self._match_patterns(error_message)
            if fault_type != DiagnosedFaultType.UNKNOWN:
                return fault_type, confidence
        
        return DiagnosedFaultType.UNKNOWN, 0.3
    
    def _match_patterns(self, message: str) -> Tuple[DiagnosedFaultType, float]:
        """Match error message against known patterns."""
        best_match = DiagnosedFaultType.UNKNOWN
        best_confidence = 0.0
        
        for pattern, fault_type, base_confidence in self._pattern_cache:
            if pattern.search(message):
                if base_confidence > best_confidence:
                    best_match = fault_type
                    best_confidence = base_confidence
        
        return best_match, best_confidence
    
    def _detect_from_response_data(
        self,
        response_data: Dict[str, Any],
    ) -> Tuple[DiagnosedFaultType, float]:
        """Detect fault from response data structure."""
        # Empty response
        if not response_data:
            return DiagnosedFaultType.EMPTY_RESPONSE, 0.7
        
        # Empty choices
        if "choices" in response_data:
            choices = response_data["choices"]
            if not choices or len(choices) == 0:
                # Check for content filter
                if response_data.get("usage") or response_data.get("finish_reason") == "content_filter":
                    return DiagnosedFaultType.CONTENT_FILTER, 0.8
                return DiagnosedFaultType.EMPTY_RESPONSE, 0.85
        
        # Truncated response
        if response_data.get("finish_reason") == "length":
            return DiagnosedFaultType.RESPONSE_TRUNCATED, 0.9
        
        # Content filter
        if response_data.get("finish_reason") == "content_filter":
            return DiagnosedFaultType.CONTENT_FILTER, 0.9
        
        return DiagnosedFaultType.UNKNOWN, 0.3
    
    def _get_suggestions(self, fault_type: DiagnosedFaultType) -> List[FixSuggestion]:
        """Get fix suggestions for a fault type."""
        raw_suggestions = self.FIX_SUGGESTIONS.get(fault_type, [])
        return [
            FixSuggestion(
                action=s["action"],
                command=s["command"],
                explanation=s["explanation"],
                priority=i + 1,
            )
            for i, s in enumerate(raw_suggestions)
        ]


# Convenience function
def diagnose_api_error(
    error_message: Optional[str] = None,
    status_code: Optional[int] = None,
    response_data: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Quick diagnosis function.
    
    Args:
        error_message: Error message string
        status_code: HTTP status code
        response_data: Response JSON data
        
    Returns:
        Dictionary with diagnosis results
        
    Example:
        >>> result = diagnose_api_error(
        ...     error_message="Rate limit exceeded",
        ...     status_code=429
        ... )
        >>> print(result["root_cause"])
        "Your account has hit the rate limit for requests"
    """
    diagnoser = APIDiagnoser()
    result = diagnoser.diagnose(
        error_message=error_message,
        status_code=status_code,
        response_data=response_data,
    )
    return result.to_dict()
