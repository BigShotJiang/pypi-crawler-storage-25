"""
Tests for FlywheelLearner (v0.5.0)

Self-healing flywheel learning engine tests.
"""

import pytest
from datetime import datetime, timedelta
from neuralbridge import FlywheelLearner, FlywheelEngine, LearnedRule


class TestFlywheelLearner:
    """Test cases for FlywheelLearner class."""
    
    def test_create_learner(self):
        """Test learner creation."""
        learner = FlywheelLearner()
        assert learner is not None
        assert learner._min_samples == 3
        assert learner._decay_days == 30
    
    def test_record_single_observation(self):
        """Test recording a single observation."""
        learner = FlywheelLearner()
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.0)
        
        assert learner._total_recordings == 1
        assert len(learner._error_recovery_pairs) == 1
    
    def test_learn_no_rules_insufficient_samples(self):
        """Test that learning doesn't create rules with insufficient samples."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        
        rules = learner.learn()
        assert len(rules) == 0
    
    def test_learn_creates_rule(self):
        """Test that learning creates a rule after sufficient samples."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.0)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.5)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=3.0)
        
        rules = learner.learn()
        assert len(rules) == 1
        assert rules[0].pattern == "rate limit exceeded"
        assert rules[0].success_rate == 1.0
        assert rules[0].sample_count == 3
    
    def test_learn_updates_existing_rule(self):
        """Test that learning updates existing rules."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.0)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.5)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=3.0)
        
        learner.learn()  # First learn
        
        # Add more observations
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.8)
        learner.record("rate limit exceeded", "retry_with_delay", False, latency=5.0)
        
        rules = learner.learn()  # Second learn
        assert len(rules) == 1  # Still one rule
        assert rules[0].sample_count == 5
        assert rules[0].success_rate == 4/5  # 4 successes out of 5
    
    def test_get_learned_rules(self):
        """Test getting learned rules."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("error1", "retry", True)
        learner.record("error1", "retry", True)
        learner.record("error1", "retry", True)
        
        learner.record("error2", "fallback", True)
        learner.record("error2", "fallback", True)
        learner.record("error2", "fallback", True)
        
        learner.learn()
        
        rules = learner.get_learned_rules()
        assert len(rules) == 2
    
    def test_match_rule_exact(self):
        """Test exact rule matching."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        
        learner.learn()
        
        rule = learner.match_rule("rate limit exceeded")
        assert rule is not None
        assert rule.pattern == "rate limit exceeded"
    
    def test_extract_pattern(self):
        """Test error pattern extraction."""
        learner = FlywheelLearner()
        
        # Test model name removal
        pattern1 = learner._extract_pattern("OpenAI model gpt-5 does not exist")
        assert "gpt-5" not in pattern1
        assert "*" in pattern1
        
        # Test number removal
        pattern2 = learner._extract_pattern("Retry after 30 seconds")
        assert "30" not in pattern2
        
        # Test UUID removal
        pattern3 = learner._extract_pattern("Error id 550e8400-e29b-41d4-a716-446655440000")
        assert "550e8400" not in pattern3
    
    def test_prune_low_confidence(self):
        """Test pruning low confidence rules."""
        learner = FlywheelLearner(min_confidence=0.5)
        
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        
        learner.learn()
        
        # Manually reduce confidence
        rule = learner.match_rule("rate limit exceeded")
        rule.confidence = 0.3
        
        pruned = learner.prune()
        assert pruned >= 0  # May or may not prune depending on sample count
    
    def test_export_import_rules(self):
        """Test rule persistence."""
        learner = FlywheelLearner(min_samples=3)
        
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        learner.record("rate limit exceeded", "retry_with_delay", True)
        
        learner.learn()
        
        # Export
        exported = learner.export_rules()
        assert exported["version"] == "1.0"
        assert len(exported["rules"]) == 1
        
        # Import to new learner
        learner2 = FlywheelLearner()
        imported = learner2.import_rules(exported)
        assert imported == 1
        
        rules = learner2.get_learned_rules()
        assert len(rules) == 1
        assert rules[0].pattern == "rate limit exceeded"
    
    def test_get_statistics(self):
        """Test learner statistics."""
        learner = FlywheelLearner()
        
        learner.record("error1", "retry", True)
        learner.record("error1", "retry", True)
        learner.record("error1", "retry", True)
        
        learner.learn()
        
        stats = learner.get_statistics()
        assert "total_recordings" in stats
        assert "active_rules" in stats
        assert stats["total_recordings"] == 3
        assert stats["active_rules"] == 1
    
    def test_reset(self):
        """Test learner reset."""
        learner = FlywheelLearner()
        
        learner.record("error", "retry", True)
        learner.record("error", "retry", True)
        learner.record("error", "retry", True)
        
        learner.learn()
        
        learner.reset()
        
        assert learner._total_recordings == 0
        assert learner._total_learned == 0
        assert len(learner._learned_rules) == 0


class TestFlywheelEngineLearning:
    """Test cases for FlywheelEngine learning integration."""
    
    def test_learning_disabled_by_default(self):
        """Test that learning is disabled by default."""
        engine = FlywheelEngine()
        assert engine._learner_enabled is False
        assert engine.is_learning_enabled() is False
    
    def test_enable_learning_constructor(self):
        """Test enabling learning via constructor."""
        engine = FlywheelEngine(enable_learning=True)
        assert engine.is_learning_enabled() is True
        assert engine._learner is not None
    
    def test_enable_learning_method(self):
        """Test enabling learning via method."""
        engine = FlywheelEngine()
        engine.enable_learning()
        assert engine.is_learning_enabled() is True
    
    def test_disable_learning(self):
        """Test disabling learning."""
        engine = FlywheelEngine(enable_learning=True)
        engine.disable_learning()
        assert engine.is_learning_enabled() is False
    
    def test_get_learned_rules_empty(self):
        """Test getting rules when none exist."""
        engine = FlywheelEngine(enable_learning=True)
        rules = engine.get_learned_rules()
        assert len(rules) == 0
    
    def test_export_rules_empty(self):
        """Test exporting rules when none exist."""
        engine = FlywheelEngine(enable_learning=True)
        exported = engine.export_learned_rules()
        assert exported["rules"] == []
    
    def test_import_rules(self):
        """Test importing rules."""
        engine1 = FlywheelEngine(enable_learning=True)
        
        # Create some rules
        engine1._learner.record("rate limit", "retry", True)
        engine1._learner.record("rate limit", "retry", True)
        engine1._learner.record("rate limit", "retry", True)
        engine1.trigger_learning()
        
        # Export
        exported = engine1.export_learned_rules()
        
        # Import to new engine
        engine2 = FlywheelEngine(enable_learning=True)
        imported = engine2.import_learned_rules(exported)
        
        assert imported == 1
        assert len(engine2.get_learned_rules()) == 1
    
    def test_get_learning_statistics(self):
        """Test getting learning statistics."""
        engine = FlywheelEngine(enable_learning=True)
        stats = engine.get_learning_statistics()
        
        assert "enabled" in stats
        assert stats["enabled"] is True
    
    def test_get_learning_statistics_disabled(self):
        """Test getting stats when learning is disabled."""
        engine = FlywheelEngine(enable_learning=False)
        stats = engine.get_learning_statistics()
        
        assert stats["enabled"] is False


class TestLearnedRule:
    """Test cases for LearnedRule dataclass."""
    
    def test_rule_creation(self):
        """Test creating a learned rule."""
        rule = LearnedRule(
            rule_id="test_rule",
            pattern="test pattern",
            action="retry_with_delay",
            action_params={"delay": 2.0},
        )
        
        assert rule.rule_id == "test_rule"
        assert rule.pattern == "test pattern"
        assert rule.action == "retry_with_delay"
        assert rule.success_rate == 0.0
        assert rule.confidence == 0.0
    
    def test_rule_update_success(self):
        """Test updating rule with success."""
        rule = LearnedRule(
            rule_id="test",
            pattern="test",
            action="retry",
            action_params={},
        )
        
        rule.update_success()
        assert rule.sample_count == 1
        assert rule.success_count == 1
        assert rule.success_rate == 1.0
    
    def test_rule_update_failure(self):
        """Test updating rule with failure."""
        rule = LearnedRule(
            rule_id="test",
            pattern="test",
            action="retry",
            action_params={},
        )
        
        rule.update_failure()
        assert rule.sample_count == 1
        assert rule.success_count == 0
        assert rule.success_rate == 0.0
    
    def test_rule_to_dict(self):
        """Test converting rule to dictionary."""
        rule = LearnedRule(
            rule_id="test",
            pattern="test",
            action="retry",
            action_params={},
        )
        
        d = rule.to_dict()
        assert "rule_id" in d
        assert "created_at" in d
        assert isinstance(d["created_at"], str)
    
    def test_rule_from_dict(self):
        """Test creating rule from dictionary."""
        data = {
            "rule_id": "test",
            "pattern": "test",
            "action": "retry",
            "action_params": {},
            "confidence": 0.5,
            "sample_count": 10,
            "success_count": 8,
            "success_rate": 0.8,
            "created_at": datetime.now().isoformat(),
            "last_used": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        }
        
        rule = LearnedRule.from_dict(data)
        assert rule.rule_id == "test"
        assert rule.success_rate == 0.8


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
