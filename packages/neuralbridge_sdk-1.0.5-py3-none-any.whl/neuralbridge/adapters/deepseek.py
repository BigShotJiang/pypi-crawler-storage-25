"""
NeuralBridge-Lite DeepSeek API Adapter Module

This module provides adapter for DeepSeek API integration.
"""

from typing import Any, Dict, Optional

from ..models import FaultType


class DeepSeekAdapter:
    """
    Adapter for DeepSeek API.

    This adapter handles DeepSeek-specific API quirks and error formats.

    DeepSeek API Reference:
    https://platform.deepseek.com/docs

    Error Codes:
    - 1001: Request timeout
    - 1002: Rate limit exceeded
    - 1003: Invalid model
    - 1004: Authentication failed
    - 1005: Server error

    Example:
        >>> adapter = DeepSeekAdapter()
        >>> config = adapter.get_request_headers(api_key="xxx")
        >>> fault_type = adapter.parse_error_code("1002")
        >>> # fault_type == FaultType.RATE_LIMIT
    """

    BASE_URL = "https://api.deepseek.com"
    API_VERSION = "v1"

    # DeepSeek-specific model mappings
    SUPPORTED_MODELS = {
        "deepseek-chat": "DeepSeek Chat",
        "deepseek-coder": "DeepSeek Coder",
        "deepseek-reasoner": "DeepSeek Reasoner",
    }

    # Error code to fault type mapping
    ERROR_CODE_MAP = {
        "1001": FaultType.TIMEOUT,
        "1002": FaultType.RATE_LIMIT,
        "1003": FaultType.INVALID_MODEL,
        "1004": FaultType.AUTH_ERROR,
        "1005": FaultType.SERVER_ERROR,
    }

    def __init__(self, api_key: Optional[str] = None) -> None:
        """
        Initialize DeepSeekAdapter.

        Args:
            api_key: DeepSeek API key.
        """
        self.api_key = api_key

    def get_base_url(self) -> str:
        """
        Get DeepSeek API base URL.

        Returns:
            Base URL string.
        """
        return self.BASE_URL

    def get_request_headers(
        self,
        api_key: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        """
        Get headers for DeepSeek API requests.

        Args:
            api_key: API key (uses instance key if not provided).
            extra_headers: Additional headers to include.

        Returns:
            Dictionary of request headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key or self.api_key}",
        }

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def parse_error_code(self, error_code: str) -> FaultType:
        """
        Parse DeepSeek error code to fault type.

        Args:
            error_code: DeepSeek error code string.

        Returns:
            Corresponding FaultType.
        """
        return self.ERROR_CODE_MAP.get(
            error_code,
            FaultType.UNKNOWN,
        )

    def format_request(
        self,
        model: str,
        messages: list,
        stream: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Format request payload for DeepSeek API.

        Args:
            model: Model name.
            messages: List of message dictionaries.
            stream: Whether to stream response.
            **kwargs: Additional parameters.

        Returns:
            Formatted request payload.
        """
        payload = {
            "model": model,
            "messages": messages,
            "stream": stream,
        }

        # Add optional parameters
        optional_params = [
            "temperature", "top_p", "max_tokens", "timeout",
            "presence_penalty", "frequency_penalty", "stop",
        ]

        for param in optional_params:
            if param in kwargs:
                payload[param] = kwargs[param]

        return payload

    def parse_response(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse DeepSeek API response.

        Args:
            response_data: Raw response data.

        Returns:
            Parsed response with standardized fields.
        """
        parsed = {
            "id": response_data.get("id"),
            "model": response_data.get("model"),
            "content": None,
            "finish_reason": None,
            "usage": response_data.get("usage"),
        }

        # Extract content from choices
        choices = response_data.get("choices", [])
        if choices:
            first_choice = choices[0]
            message = first_choice.get("message", {})
            parsed["content"] = message.get("content")
            parsed["finish_reason"] = first_choice.get("finish_reason")

        return parsed

    def is_model_supported(self, model: str) -> bool:
        """
        Check if a model is supported.

        Args:
            model: Model name to check.

        Returns:
            True if model is supported.
        """
        return model in self.SUPPORTED_MODELS

    def get_supported_models(self) -> list:
        """
        Get list of supported models.

        Returns:
            List of model names.
        """
        return list(self.SUPPORTED_MODELS.keys())

    def validate_api_key(self, api_key: str) -> bool:
        """
        Validate DeepSeek API key format.

        Args:
            api_key: API key to validate.

        Returns:
            True if key format is valid.
        """
        # DeepSeek API keys typically start with "sk-"
        return bool(api_key and api_key.startswith("sk-"))

    def get_rate_limit_headers(self, response_headers: Dict[str, str]) -> Dict[str, Any]:
        """
        Extract rate limit information from response headers.

        Args:
            response_headers: Response headers dictionary.

        Returns:
            Dictionary with rate limit info.
        """
        return {
            "requests_limit": response_headers.get("x-ratelimit-limit-requests"),
            "requests_remaining": response_headers.get("x-ratelimit-remaining-requests"),
            "tokens_limit": response_headers.get("x-ratelimit-limit-tokens"),
            "tokens_remaining": response_headers.get("x-ratelimit-remaining-tokens"),
            "retry_after": response_headers.get("retry-after"),
        }
