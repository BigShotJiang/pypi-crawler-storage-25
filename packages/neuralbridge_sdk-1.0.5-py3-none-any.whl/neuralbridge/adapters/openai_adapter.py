"""
OpenAI Adapter for NeuralBridge SDK — v1.0.4
Drop-in replacement for openai.OpenAI with self-healing capabilities.

v1.0.4 FIX: Uses model_ref mutable container so heal() can propagate
fallback model changes to the _make_request() closure, which then
updates the actual JSON payload before the HTTP request.
"""

import time
from typing import Any, Dict, List, Optional, Union, Iterator, Callable, TypeVar

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

from ..engine import FlywheelEngine
from ..types import DiagnosisResult, ErrorCategory, RecoveryRecord
from ..jitter import JitterConfig, DEFAULT_JITTER_CONFIG

T = TypeVar('T')


class NeuralBridge:
    """
    NeuralBridge - Self-healing OpenAI API client.
    
    Drop-in replacement for openai.OpenAI with automatic fault diagnosis,
    cascade recovery, and transparent model switching.
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        fallback_models: Optional[List[str]] = None,
        max_retries: int = 3,
        timeout: float = 60.0,
        verbose: bool = False,
        jitter_config: Optional[JitterConfig] = None,
        api_key_refresher: Optional[Callable[[], str]] = None,
        httpx_client: Optional[Any] = None,
        license_key: Optional[str] = None,
        predictive_config: Optional[Any] = None,
        enable_learning: bool = False,
    ):
        if not HTTPX_AVAILABLE:
            raise ImportError("httpx is required. Install with: pip install httpx")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verbose = verbose
        
        self.engine = FlywheelEngine(
            fallback_models=fallback_models,
            max_retries=max_retries,
            verbose=verbose,
            jitter_config=jitter_config,
            api_key_refresher=api_key_refresher,
            predictive_config=predictive_config,
            enable_learning=enable_learning,
            license_key=license_key,
        )
        
        self._httpx_client = httpx_client
    
    def _get_client(self) -> httpx.Client:
        if self._httpx_client is None:
            self._httpx_client = httpx.Client(
                timeout=httpx.Timeout(self.timeout),
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._httpx_client
    
    def _build_url(self, endpoint: str) -> str:
        return f"{self.base_url}/{endpoint.lstrip('/')}"
    
    def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        if not response.is_success:
            metadata = {"status_code": response.status_code}
            if "retry-after" in response.headers:
                metadata["retry_after"] = float(response.headers["retry-after"])
            try:
                error_data = response.json()
                if "error" in error_data:
                    metadata["error_message"] = error_data["error"].get("message", "")
                    metadata["error_type"] = error_data["error"].get("type", "")
            except Exception:
                pass
            error_msg = f"HTTP {response.status_code}: {response.text[:500]}"
            error = HTTPError(error_msg, status_code=response.status_code, metadata=metadata)
            raise error
        return response.json()
    
    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make an HTTP request with automatic healing.
        
        v1.0.4 FIX: Uses model_ref mutable dict so that when heal()
        switches to a fallback model, the _make_request() closure sees
        the updated model name and puts it into the JSON payload.
        """
        # Extract current model from JSON payload
        _current_model = None
        if isinstance(kwargs.get("json"), dict):
            _current_model = kwargs["json"].get("model")
        
        # v1.0.4 FIX #9: Mutable container for model name
        # heal() updates this dict, and _make_request() reads from it
        _model_ref = {"model": _current_model}
        
        def _make_request() -> Dict[str, Any]:
            # Read model from mutable ref (updated by heal's fallback logic)
            if isinstance(kwargs.get("json"), dict):
                kwargs["json"]["model"] = _model_ref["model"]
            client = self._get_client()
            url = self._build_url(endpoint)
            response = client.request(method, url, **kwargs)
            return self._handle_response(response)
        
        # v1.0.4 FIX #8: Don't pass api_key_getter/setter to heal()
        # Those leak into func() kwargs and cause TypeError
        # API key refresh is handled by engine's api_key_refresher callback
        result = self.engine.heal(
            _make_request,
            current_model=_current_model,
            model_ref=_model_ref,
        )
        return result
    
    def chat(self) -> "ChatCompletions":
        return ChatCompletions(self)
    
    def close(self) -> None:
        if self._httpx_client:
            self._httpx_client.close()
            self._httpx_client = None
    
    def __enter__(self) -> "NeuralBridge":
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
    
    @property
    def model_performance(self) -> Dict[str, Any]:
        return {
            model: {
                "total_calls": perf.total_calls,
                "successful_calls": perf.successful_calls,
                "failed_calls": perf.failed_calls,
                "avg_latency": perf.avg_latency,
                "reliability_score": perf.reliability_score,
            }
            for model, perf in self.engine.model_performance.items()
        }
    
    @property
    def health_status(self) -> Dict[str, Any]:
        status = self.engine.get_health_status()
        return {
            "healthy": status.healthy,
            "active_models": status.active_models,
            "degraded_models": status.degraded_models,
            "failed_models": status.failed_models,
            "recommendations": status.recommendations,
        }


class ChatCompletions:
    """Chat completions namespace for NeuralBridge."""
    
    def __init__(self, client: NeuralBridge):
        self._client = client
    
    def create(
        self,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 1.0,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        stop: Optional[Union[str, List[str]]] = None,
        **kwargs
    ) -> Union[Dict[str, Any], Iterator[Dict[str, Any]]]:
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
        }
        if top_p is not None:
            payload["top_p"] = top_p
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop is not None:
            payload["stop"] = stop
        payload.update(kwargs)
        
        if stream:
            return self._stream(payload)
        
        return self._client._request("POST", "/chat/completions", json=payload)
    
    def _stream(self, payload: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
        client = self._client._get_client()
        url = self._client._build_url("/chat/completions")
        with client.stream("POST", url, json=payload) as response:
            if not response.is_success:
                error = HTTPError(f"HTTP {response.status_code}: {response.text[:500]}", status_code=response.status_code)
                raise error
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        import json
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        continue


class HTTPError(Exception):
    """HTTP error with status code and metadata."""
    def __init__(self, message: str, status_code: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.status_code = status_code
        self.metadata = metadata or {}


def create_client(api_key: str, **kwargs) -> NeuralBridge:
    return NeuralBridge(api_key=api_key, **kwargs)
