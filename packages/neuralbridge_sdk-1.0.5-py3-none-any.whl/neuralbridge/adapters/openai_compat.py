"""
NeuralBridge-Lite OpenAI Compatible Adapter Module

This module provides adapter for OpenAI-compatible APIs.
"""

from typing import Any, Dict, List, Optional


class OpenAICompatAdapter:
    """
    Adapter for OpenAI-compatible APIs.

    This adapter provides compatibility with any API that follows
    the OpenAI API format, including DeepSeek, Azure OpenAI, and custom endpoints.

    Features:
    - Standard OpenAI request/response format
    - Configurable base URL
    - Header customization
    - Error handling

    Example:
        >>> adapter = OpenAICompatAdapter(base_url="https://api.deepseek.com/v1")
        >>> payload = adapter.format_request(
        ...     model="deepseek-chat",
        ...     messages=[{"role": "user", "content": "Hello"}]
        ... )
    """

    def __init__(
        self,
        base_url: str = "https://api.openai.com/v1",
        api_key: Optional[str] = None,
    ) -> None:
        """
        Initialize OpenAICompatAdapter.

        Args:
            base_url: Base URL for the API.
            api_key: API key for authentication.
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def get_base_url(self) -> str:
        """
        Get base URL.

        Returns:
            Base URL string.
        """
        return self.base_url

    def get_chat_completions_url(self) -> str:
        """
        Get full URL for chat completions endpoint.

        Returns:
            Full URL string.
        """
        return f"{self.base_url}/chat/completions"

    def get_headers(
        self,
        api_key: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        """
        Get headers for API requests.

        Args:
            api_key: API key (uses instance key if not provided).
            extra_headers: Additional headers to include.

        Returns:
            Dictionary of request headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key or self.api_key}",
        }

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def format_request(
        self,
        model: str,
        messages: List[Dict[str, str]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Format request payload for chat completions.

        Args:
            model: Model name.
            messages: List of message dictionaries.
            stream: Whether to stream response.
            **kwargs: Additional parameters.

        Returns:
            Formatted request payload.
        """
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        if stream:
            payload["stream"] = True

        # Add optional parameters
        optional_params = [
            "temperature", "top_p", "n", "max_tokens",
            "presence_penalty", "frequency_penalty", "stop",
            "user", "response_format", "tools", "tool_choice",
        ]

        for param in optional_params:
            if param in kwargs:
                payload[param] = kwargs[param]

        return payload

    def parse_response(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse API response into standard format.

        Args:
            response_data: Raw response data.

        Returns:
            Parsed response with standardized fields.
        """
        parsed = {
            "id": response_data.get("id"),
            "model": response_data.get("model"),
            "created": response_data.get("created"),
            "content": None,
            "finish_reason": None,
            "usage": response_data.get("usage"),
            "choices": response_data.get("choices", []),
        }

        # Extract content from first choice
        choices = response_data.get("choices", [])
        if choices:
            first_choice = choices[0]
            if isinstance(first_choice, dict):
                message = first_choice.get("message", {})
                parsed["content"] = message.get("content")
                parsed["finish_reason"] = first_choice.get("finish_reason")

        return parsed

    def parse_stream_response(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse streaming response chunk.

        Args:
            chunk: Stream chunk data.

        Returns:
            Parsed chunk with standardized fields.
        """
        parsed = {
            "id": chunk.get("id"),
            "model": chunk.get("model"),
            "delta": None,
            "finish_reason": None,
        }

        choices = chunk.get("choices", [])
        if choices:
            first_choice = choices[0]
            if isinstance(first_choice, dict):
                parsed["delta"] = first_choice.get("delta", {})
                parsed["finish_reason"] = first_choice.get("finish_reason")

        return parsed

    def extract_error_info(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract error information from response.

        Args:
            response_data: Response data (may be error response).

        Returns:
            Dictionary with error information.
        """
        error_info: Dict[str, Any] = {
            "message": None,
            "type": None,
            "code": None,
            "param": None,
        }

        if "error" in response_data:
            error = response_data["error"]
            if isinstance(error, dict):
                error_info["message"] = error.get("message")
                error_info["type"] = error.get("type")
                error_info["code"] = error.get("code")
                error_info["param"] = error.get("param")
            elif isinstance(error, str):
                error_info["message"] = error

        return error_info

    def is_success_response(self, response_data: Dict[str, Any]) -> bool:
        """
        Check if response indicates success.

        Args:
            response_data: Response data to check.

        Returns:
            True if response is successful.
        """
        # Check for error field
        if "error" in response_data:
            return False

        # Check for required fields
        return "choices" in response_data or "id" in response_data
