"""
NeuralBridge Circuit Breaker.

Implements the Circuit Breaker pattern for fault tolerance in AI API calls.
Prevents cascading failures by stopping requests to a failing service.

States:
- CLOSED: Normal operation, requests pass through
- OPEN: Circuit is tripped, requests are blocked
- HALF_OPEN: Testing recovery, limited requests allowed

Usage:
    from neuralbridge import CircuitBreaker, CircuitBreakerConfig
    
    config = CircuitBreakerConfig(
        failure_threshold=5,        # Open after 5 consecutive failures
        recovery_timeout=30.0,       # Wait 30s before testing recovery
        success_threshold=3,         # Close after 3 successes in half-open
    )
    breaker = CircuitBreaker(config=config)
    
    if breaker.can_execute():
        try:
            result = api_call()
            breaker.record_success()
        except Exception:
            breaker.record_failure()
"""

import time
import threading
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Deque, Dict, List, Optional, Tuple


class CircuitState(str, Enum):
    """Circuit breaker states."""
    CLOSED = "closed"       # Normal operation
    OPEN = "open"           # Blocking requests
    HALF_OPEN = "half_open"  # Testing recovery


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker.
    
    Attributes:
        failure_threshold: Number of consecutive failures to trigger open state.
            Default: 5
        recovery_timeout: Seconds to wait before transitioning from OPEN to HALF_OPEN.
            Default: 30.0
        success_threshold: Number of consecutive successes in HALF_OPEN to close.
            Default: 3
        window_size: Sliding window size for tracking failures.
            Default: 100
        half_open_max_calls: Maximum concurrent calls allowed in HALF_OPEN state.
            Default: 1
    """
    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    success_threshold: int = 3
    window_size: int = 100
    half_open_max_calls: int = 1


@dataclass
class CircuitBreakerStats:
    """Statistics for circuit breaker monitoring."""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    rejected_requests: int = 0
    state_transitions: int = 0
    last_state_change_time: float = 0.0
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    current_state: CircuitState = CircuitState.CLOSED
    time_in_closed: float = 0.0
    time_in_open: float = 0.0
    time_in_half_open: float = 0.0
    
    # Sliding window data (not directly user-visible)
    _failure_window: Deque[bool] = field(default_factory=lambda: deque(maxlen=100))
    _success_window: Deque[bool] = field(default_factory=lambda: deque(maxlen=100))


class CircuitOpenError(Exception):
    """Raised when circuit breaker is open and blocking requests."""
    
    def __init__(self, message: Optional[str] = None, retry_after: Optional[float] = None):
        self.retry_after = retry_after
        super().__init__(message or "Circuit breaker is open")


class CircuitBreaker:
    """
    Circuit breaker implementation for fault tolerance.
    
    The circuit breaker monitors failures and trips open when the failure
    threshold is reached. After a recovery timeout, it allows a limited
    number of test requests through (half-open state). If these succeed,
    the circuit closes; if any fail, it opens again.
    
    Attributes:
        config: Circuit breaker configuration
        name: Optional name for this circuit breaker
        
    Example:
        >>> breaker = CircuitBreaker(
        ...     config=CircuitBreakerConfig(failure_threshold=3)
        ... )
        >>> if breaker.can_execute():
        ...     try:
        ...         result = risky_operation()
        ...         breaker.record_success()
        ...     except Exception:
        ...         breaker.record_failure()
    """
    
    def __init__(
        self,
        config: Optional[CircuitBreakerConfig] = None,
        name: Optional[str] = None,
    ):
        """
        Initialize circuit breaker.
        
        Args:
            config: Circuit breaker configuration (uses defaults if not provided)
            name: Optional identifier for this breaker
        """
        self.config = config or CircuitBreakerConfig()
        self.name = name or "default"
        
        # State management
        self._state = CircuitState.CLOSED
        self._lock = threading.RLock()
        
        # Consecutive failure/success counters
        self._consecutive_failures: int = 0
        self._consecutive_successes: int = 0
        
        # Timing
        self._last_failure_time: float = 0.0
        self._last_success_time: float = 0.0
        self._opened_at: float = 0.0
        self._closed_at: float = time.time()
        
        # Half-open state tracking
        self._half_open_calls: int = 0
        
        # Statistics
        self._stats = CircuitBreakerStats()
        
        # Sliding window for failure tracking
        self._failure_window: Deque[Tuple[float, bool]] = deque(maxlen=self.config.window_size)
        self._success_window: Deque[Tuple[float, bool]] = deque(maxlen=self.config.window_size)
    
    @property
    def state(self) -> CircuitState:
        """Get current circuit state (thread-safe)."""
        with self._lock:
            return self._state
    
    def get_state(self) -> CircuitState:
        """
        Get current circuit state.
        
        Returns:
            Current CircuitState
        """
        with self._lock:
            # Check if we should transition from OPEN to HALF_OPEN
            if self._state == CircuitState.OPEN:
                if time.time() - self._opened_at >= self.config.recovery_timeout:
                    self._transition_to(CircuitState.HALF_OPEN)
            return self._state
    
    def can_execute(self) -> bool:
        """
        Check if a request can proceed.
        
        Returns:
            True if request is allowed, False if circuit is blocking
        """
        with self._lock:
            current_time = time.time()
            
            # Check OPEN state - transition to HALF_OPEN if timeout elapsed
            if self._state == CircuitState.OPEN:
                if current_time - self._opened_at >= self.config.recovery_timeout:
                    self._transition_to(CircuitState.HALF_OPEN)
                else:
                    self._stats.rejected_requests += 1
                    return False
            
            # HALF_OPEN - allow limited calls
            if self._state == CircuitState.HALF_OPEN:
                if self._half_open_calls < self.config.half_open_max_calls:
                    self._half_open_calls += 1
                    return True
                else:
                    self._stats.rejected_requests += 1
                    return False
            
            # CLOSED - allow all requests
            return True
    
    def record_success(self) -> None:
        """
        Record a successful request.
        
        In CLOSED state: Reset failure counter, increment success counter
        In HALF_OPEN state: Increment success counter, close if threshold reached
        """
        with self._lock:
            current_time = time.time()
            
            if self._state == CircuitState.CLOSED:
                # Reset failure counter, record success
                self._consecutive_failures = 0
                self._consecutive_successes += 1
                self._last_success_time = current_time
                self._stats.successful_requests += 1
                self._stats.total_requests += 1
                self._success_window.append((current_time, True))
                
                # Track time metrics
                self._stats.time_in_closed += current_time - self._closed_at
                
            elif self._state == CircuitState.HALF_OPEN:
                # Success in half-open - may close the circuit
                self._consecutive_successes += 1
                self._last_success_time = current_time
                self._stats.successful_requests += 1
                self._stats.total_requests += 1
                self._success_window.append((current_time, True))
                
                # Track time metrics
                self._stats.time_in_half_open += current_time - self._opened_at
                
                # Check if we should close
                if self._consecutive_successes >= self.config.success_threshold:
                    self._transition_to(CircuitState.CLOSED)
    
    def record_failure(self) -> None:
        """
        Record a failed request.
        
        In CLOSED state: Increment failure counter, open if threshold reached
        In HALF_OPEN state: Immediately open the circuit
        """
        with self._lock:
            current_time = time.time()
            
            if self._state == CircuitState.CLOSED:
                # Record failure
                self._consecutive_failures += 1
                self._consecutive_successes = 0
                self._last_failure_time = current_time
                self._stats.failed_requests += 1
                self._stats.total_requests += 1
                self._failure_window.append((current_time, True))
                
                # Track time metrics
                self._stats.time_in_closed += current_time - self._closed_at
                
                # Check if we should trip open
                if self._consecutive_failures >= self.config.failure_threshold:
                    self._transition_to(CircuitState.OPEN)
                    
            elif self._state == CircuitState.HALF_OPEN:
                # Any failure in half-open immediately opens the circuit
                self._stats.failed_requests += 1
                self._stats.total_requests += 1
                self._failure_window.append((current_time, True))
                self._stats.consecutive_failures = self._consecutive_failures
                
                # Track time metrics
                self._stats.time_in_half_open += current_time - self._opened_at
                
                self._transition_to(CircuitState.OPEN)
    
    def _transition_to(self, new_state: CircuitState) -> None:
        """
        Transition to a new state.
        
        Args:
            new_state: The state to transition to
        """
        if self._state == new_state:
            return
        
        old_state = self._state
        current_time = time.time()
        
        # Update state
        self._state = new_state
        self._stats.current_state = new_state
        self._stats.state_transitions += 1
        self._stats.last_state_change_time = current_time
        
        # State-specific initialization
        if new_state == CircuitState.OPEN:
            self._opened_at = current_time
            self._consecutive_failures = self.config.failure_threshold  # Keep failure count
            self._consecutive_successes = 0
            self._half_open_calls = 0
            
        elif new_state == CircuitState.HALF_OPEN:
            self._half_open_calls = 0
            self._consecutive_successes = 0
            
        elif new_state == CircuitState.CLOSED:
            self._closed_at = current_time
            self._consecutive_failures = 0
            self._consecutive_successes = 0
            self._half_open_calls = 0
    
    def reset(self) -> None:
        """
        Reset the circuit breaker to closed state.
        
        Clears all statistics and resets counters.
        """
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._stats = CircuitBreakerStats()
            self._failure_window.clear()
            self._success_window.clear()
    
    def get_stats(self) -> Dict:
        """
        Get circuit breaker statistics.
        
        Returns:
            Dictionary containing:
            - state: Current state (closed/open/half_open)
            - total_requests: Total number of requests
            - successful_requests: Number of successful requests
            - failed_requests: Number of failed requests
            - rejected_requests: Number of rejected requests (circuit open)
            - consecutive_failures: Current consecutive failure count
            - consecutive_successes: Current consecutive success count
            - last_failure_time: Unix timestamp of last failure
            - last_success_time: Unix timestamp of last success
            - last_state_change_time: Unix timestamp of last state change
            - state_transitions: Total number of state transitions
            - time_in_closed: Total seconds spent in closed state
            - time_in_open: Total seconds spent in open state
            - time_in_half_open: Total seconds spent in half-open state
            - failure_rate: Current failure rate (0.0-1.0)
            - config: Current configuration
        """
        with self._lock:
            # Calculate failure rate from sliding window
            window_size = len(self._failure_window)
            if window_size > 0:
                failures = sum(1 for _, failed in self._failure_window if failed)
                failure_rate = failures / window_size
            else:
                failure_rate = 0.0
            
            return {
                "state": self._state.value,
                "total_requests": self._stats.total_requests,
                "successful_requests": self._stats.successful_requests,
                "failed_requests": self._stats.failed_requests,
                "rejected_requests": self._stats.rejected_requests,
                "consecutive_failures": self._consecutive_failures,
                "consecutive_successes": self._consecutive_successes,
                "failure_threshold": self.config.failure_threshold,
                "success_threshold": self.config.success_threshold,
                "recovery_timeout": self.config.recovery_timeout,
                "last_failure_time": self._last_failure_time,
                "last_success_time": self._last_success_time,
                "last_state_change_time": self._stats.last_state_change_time,
                "state_transitions": self._stats.state_transitions,
                "time_in_closed": self._stats.time_in_closed,
                "time_in_open": self._stats.time_in_open,
                "time_in_half_open": self._stats.time_in_half_open,
                "failure_rate": failure_rate,
                "window_size": window_size,
            }
    
    def get_failure_rate(self) -> float:
        """
        Get the current failure rate.
        
        Returns:
            Failure rate as a float between 0.0 and 1.0
        """
        with self._lock:
            window_size = len(self._failure_window)
            if window_size == 0:
                return 0.0
            failures = sum(1 for _, failed in self._failure_window if failed)
            return failures / window_size
    
    def is_open(self) -> bool:
        """Check if circuit is currently open."""
        return self.get_state() == CircuitState.OPEN
    
    def is_closed(self) -> bool:
        """Check if circuit is currently closed."""
        return self.get_state() == CircuitState.CLOSED
    
    def is_half_open(self) -> bool:
        """Check if circuit is currently half-open."""
        return self.get_state() == CircuitState.HALF_OPEN
    
    def __repr__(self) -> str:
        state = self.get_state()
        return (
            f"CircuitBreaker(name={self.name!r}, state={state.value}, "
            f"failures={self._consecutive_failures}/{self.config.failure_threshold})"
        )
