"""
NeuralBridge SDK - Exception Classes

This module contains all custom exceptions used by the SDK.
These exceptions are part of the public API and remain as open source.
"""

from typing import Optional, Dict, Any


class NeuralBridgeError(Exception):
    """
    Base exception for all NeuralBridge errors.
    
    All other NeuralBridge exceptions inherit from this class.
    """
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}
    
    def __str__(self) -> str:
        if self.details:
            return f"{self.message} | Details: {self.details}"
        return self.message


class DiagnosisError(NeuralBridgeError):
    """
    Raised when error diagnosis fails.
    
    This may occur when:
    - The error pattern is unrecognizable
    - Insufficient context for diagnosis
    - External diagnosis service is unavailable
    """
    pass


class RecoveryError(NeuralBridgeError):
    """
    Raised when error recovery fails.
    
    This may occur when:
    - All recovery strategies have been exhausted
    - Recovery strategy itself fails
    - Resource limits reached
    """
    pass


class ModelExhaustedError(RecoveryError):
    """
    Raised when all fallback models have failed.
    
    This is the terminal state after cascade recovery has been
    completely exhausted without success.
    """
    
    def __init__(self, models: list, last_error: Optional[Exception] = None):
        self.models = models
        self.last_error = last_error
        message = f"All models exhausted: {models}"
        super().__init__(message, {"models": models, "last_error": str(last_error) if last_error else None})


class PredictionError(NeuralBridgeError):
    """
    Raised when predictive engine encounters an error.
    
    This may occur when:
    - Model training fails
    - Prediction generation fails
    - Insufficient historical data
    """
    pass


class StrategyError(NeuralBridgeError):
    """
    Raised when a recovery strategy encounters an error.
    """
    pass


class RateLimitError(StrategyError):
    """
    Raised when rate limit is hit and cannot be handled.
    """
    
    def __init__(self, retry_after: Optional[int] = None):
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded, retry after {retry_after}s" if retry_after else "Rate limit exceeded",
            {"retry_after": retry_after}
        )


class AuthenticationError(StrategyError):
    """
    Raised when authentication fails.
    
    This may occur when:
    - Invalid API key
    - Expired credentials
    - Insufficient permissions
    """
    pass


class NetworkError(StrategyError):
    """
    Raised when network operations fail.
    """
    pass


class TimeoutError(StrategyError):
    """
    Raised when operations timeout.
    """
    
    def __init__(self, timeout: Optional[float] = None):
        self.timeout = timeout
        super().__init__(
            f"Operation timed out after {timeout}s" if timeout else "Operation timed out",
            {"timeout": timeout}
        )


class ValidationError(NeuralBridgeError):
    """
    Raised when input validation fails.
    """
    pass


class ConfigurationError(NeuralBridgeError):
    """
    Raised when configuration is invalid.
    """
    pass


class CircuitBreakerOpenError(NeuralBridgeError):
    """
    Raised when circuit breaker is open and request is rejected.
    """
    
    def __init__(self, model: str, reason: str = "Circuit breaker is open"):
        self.model = model
        self.reason = reason
        super().__init__(f"Circuit breaker open for {model}: {reason}", {"model": model, "reason": reason})
