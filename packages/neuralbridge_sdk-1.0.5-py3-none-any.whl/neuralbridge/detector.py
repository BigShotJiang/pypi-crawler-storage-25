"""
NeuralBridge-Lite Fault Detector Module

This module provides fault detection capabilities for AI API errors.
The complete fault detection logic is fully open source.

Key Features:
- Automatic fault classification
- Support for multiple error types
- Contextual fault information
"""

import re
import time
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

from .exceptions import FaultDetectionError
from .models import FaultInfo, FaultType


class FaultDetector:
    """
    Fault detector for AI API errors.

    This class provides comprehensive fault detection and classification
    for various types of API errors. The detection logic is fully open source.

    Example:
        >>> detector = FaultDetector()
        >>> fault = detector.detect_from_exception(ValueError("timeout"))
        >>> print(fault.fault_type)
        timeout
    """

    # HTTP status code mappings
    HTTP_STATUS_FAULT_MAP: Dict[int, FaultType] = {
        401: FaultType.AUTH_ERROR,
        403: FaultType.AUTH_ERROR,
        404: FaultType.INVALID_MODEL,
        408: FaultType.TIMEOUT,
        409: FaultType.RATE_LIMIT,
        422: FaultType.INVALID_MODEL,
        429: FaultType.RATE_LIMIT,
        500: FaultType.SERVER_ERROR,
        502: FaultType.SERVER_ERROR,
        503: FaultType.SERVER_ERROR,
        504: FaultType.SERVER_ERROR,
    }

    # Error message patterns for fault type detection
    ERROR_PATTERNS: Dict[FaultType, list] = {
        FaultType.TIMEOUT: [
            r"timeout",
            r"timed out",
            r"timed-out",
            r"connection timeout",
            r"read timeout",
            r"write timeout",
            r"operation timed out",
            r"request timeout",
        ],
        FaultType.RATE_LIMIT: [
            r"rate limit",
            r"rate_limit",
            r"too many requests",
            r"quota exceeded",
            r"exceeded.*limit",
            r"requests per minute",
            r"requests per day",
            r"token limit",
            r"limit exceeded",
        ],
        FaultType.INVALID_MODEL: [
            r"model not found",
            r"model.*not exist",
            r"invalid model",
            r"unknown model",
            r"model.*not available",
            r"does not support",
        ],
        FaultType.SERVER_ERROR: [
            r"internal server error",
            r"server error",
            r"service unavailable",
            r"bad gateway",
            r"gateway timeout",
            r"upstream error",
            r"downstream error",
        ],
        FaultType.AUTH_ERROR: [
            r"invalid api key",
            r"unauthorized",
            r"authentication failed",
            r"invalid token",
            r"access denied",
            r"permission denied",
            r"api key.*invalid",
        ],
        FaultType.NETWORK_ERROR: [
            r"connection refused",
            r"connection reset",
            r"network error",
            r"no route to host",
            r"name resolution failed",
            r"dns.*failed",
        ],
    }

    # DeepSeek-specific error codes
    DEEPSEEK_ERROR_CODES: Dict[str, FaultType] = {
        "1001": FaultType.TIMEOUT,
        "1002": FaultType.RATE_LIMIT,
        "1003": FaultType.INVALID_MODEL,
        "1004": FaultType.AUTH_ERROR,
        "1005": FaultType.SERVER_ERROR,
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize FaultDetector.

        Args:
            config: Optional configuration dictionary.
        """
        self.config = config or {}
        self._compiled_patterns: Dict[FaultType, list] = {}
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        """Compile regex patterns for performance."""
        for fault_type, patterns in self.ERROR_PATTERNS.items():
            self._compiled_patterns[fault_type] = [
                re.compile(pattern, re.IGNORECASE) for pattern in patterns
            ]

    def detect_from_exception(
        self,
        exception: Exception,
        http_status: Optional[int] = None,
    ) -> FaultInfo:
        """
        Detect fault type from an exception.

        Args:
            exception: The exception to analyze.
            http_status: Optional HTTP status code.
            context: Optional context information.

        Returns:
            FaultInfo with detected fault type and details.

        Example:
            >>> detector = FaultDetector()
            >>> fault = detector.detect_from_exception(
            ...     ValueError("Rate limit exceeded"),
            ...     http_status=429
            ... )
            >>> fault.fault_type == FaultType.RATE_LIMIT
            True
        """
        error_message = str(exception)
        fault_type = FaultType.UNKNOWN

        # First, check HTTP status code if available
        if http_status:
            fault_type = self.HTTP_STATUS_FAULT_MAP.get(
                http_status, FaultType.UNKNOWN
            )

        # If not determined by status code, check error message patterns
        if fault_type == FaultType.UNKNOWN:
            fault_type = self._detect_from_message(error_message)

        # Check for timeout in exception type name
        if fault_type == FaultType.UNKNOWN:
            exception_name = type(exception).__name__.lower()
            if "timeout" in exception_name:
                fault_type = FaultType.TIMEOUT
            elif "auth" in exception_name or "permission" in exception_name:
                fault_type = FaultType.AUTH_ERROR

        return FaultInfo(
            fault_type=fault_type,
            timestamp=datetime.now(),
            error_message=error_message,
            http_status=http_status,
            details={
                "exception_type": type(exception).__name__,
                "exception_module": type(exception).__module__,
            },
        )

    def detect_from_response(
        self,
        response_data: Dict[str, Any],
        http_status: Optional[int] = None,
    ) -> Optional[FaultInfo]:
        """
        Detect fault type from API response data.

        Args:
            response_data: The response data dictionary.
            http_status: Optional HTTP status code.

        Returns:
            FaultInfo if fault detected, None otherwise.

        Example:
            >>> detector = FaultDetector()
            >>> response = {"error": {"code": 1002, "message": "Rate limited"}}
            >>> fault = detector.detect_from_response(response, http_status=429)
            >>> fault.fault_type == FaultType.RATE_LIMIT
            True
        """
        # Check if response indicates an error
        if "error" not in response_data and http_status and http_status < 400:
            return None

        error_info = response_data.get("error", {})
        error_message = ""
        error_code = None
        retry_after = None

        # Extract error message
        if isinstance(error_info, dict):
            error_message = error_info.get("message", error_info.get("msg", ""))
            error_code = error_info.get("code")
            retry_after = error_info.get("retry_after")
        elif isinstance(error_info, str):
            error_message = error_info

        # Check for empty body fault
        if not response_data or (not error_message and http_status == 200):
            return FaultInfo(
                fault_type=FaultType.EMPTY_BODY,
                timestamp=datetime.now(),
                error_message="Response body is empty",
                http_status=http_status,
                details=response_data or {},
            )

        # Determine fault type
        fault_type = FaultType.UNKNOWN

        # Check HTTP status first
        if http_status:
            fault_type = self.HTTP_STATUS_FAULT_MAP.get(
                http_status, FaultType.UNKNOWN
            )

        # Check error code for DeepSeek and similar APIs
        if fault_type == FaultType.UNKNOWN and error_code:
            if isinstance(error_code, str) and error_code in self.DEEPSEEK_ERROR_CODES:
                fault_type = self.DEEPSEEK_ERROR_CODES[error_code]
            elif isinstance(error_code, int):
                fault_type = self.DEEPSEEK_ERROR_CODES.get(str(error_code), FaultType.UNKNOWN)

        # Check error message patterns
        if fault_type == FaultType.UNKNOWN and error_message:
            fault_type = self._detect_from_message(error_message)

        return FaultInfo(
            fault_type=fault_type,
            timestamp=datetime.now(),
            error_message=error_message,
            http_status=http_status,
            error_code=str(error_code) if error_code else None,
            retry_after=retry_after,
            details={"raw_response": response_data},
        )

    def detect_from_message(self, message: str) -> FaultInfo:
        """
        Detect fault type from an error message string.

        Args:
            message: The error message to analyze.

        Returns:
            FaultInfo with detected fault type.
        """
        fault_type = self._detect_from_message(message)
        return FaultInfo(
            fault_type=fault_type,
            timestamp=datetime.now(),
            error_message=message,
        )

    def _detect_from_message(self, message: str) -> FaultType:
        """
        Internal method to detect fault type from message.

        Args:
            message: The error message to analyze.

        Returns:
            Detected FaultType.
        """
        for fault_type, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                if pattern.search(message):
                    return fault_type
        return FaultType.UNKNOWN

    def should_retry(self, fault: FaultInfo) -> bool:
        """
        Determine if a detected fault should be retried.

        Args:
            fault: The fault information.

        Returns:
            True if the fault should be retried, False otherwise.
        """
        # Non-retryable fault types
        non_retryable = {
            FaultType.AUTH_ERROR,
            FaultType.INVALID_MODEL,
        }

        if fault.fault_type in non_retryable:
            return False

        # Retryable fault types
        retryable = {
            FaultType.TIMEOUT,
            FaultType.RATE_LIMIT,
            FaultType.SERVER_ERROR,
            FaultType.NETWORK_ERROR,
        }

        if fault.fault_type in retryable:
            return True

        # Check for retry_after header for rate limit
        if fault.retry_after and fault.retry_after > 0:
            return True

        return False

    def get_retry_delay(self, fault: FaultInfo, base_delay: float = 1.0) -> float:
        """
        Calculate recommended retry delay based on fault type.

        Args:
            fault: The fault information.
            base_delay: Base delay in seconds.

        Returns:
            Recommended delay in seconds.
        """
        # Use retry_after if available
        if fault.retry_after and fault.retry_after > 0:
            return fault.retry_after

        # Default delays by fault type
        default_delays = {
            FaultType.TIMEOUT: base_delay * 2,
            FaultType.RATE_LIMIT: base_delay * 4,
            FaultType.SERVER_ERROR: base_delay * 2,
            FaultType.NETWORK_ERROR: base_delay,
        }

        return default_delays.get(fault.fault_type, base_delay)

    def classify_response_quality(
        self,
        response_data: Dict[str, Any],
        expected_fields: Optional[list] = None,
    ) -> Tuple[bool, Optional[str]]:
        """
        Classify the quality of an API response.

        Args:
            response_data: The response data to check.
            expected_fields: List of expected field names.

        Returns:
            Tuple of (is_valid, error_message).
        """
        expected_fields = expected_fields or ["choices", "model", "id"]

        # Check for required fields
        for field in expected_fields:
            if field not in response_data:
                return False, f"Missing required field: {field}"

        # Check for empty choices
        if "choices" in response_data:
            choices = response_data["choices"]
            if not choices or len(choices) == 0:
                return False, "Empty choices array"

        return True, None

    def analyze_fault_pattern(
        self,
        fault_history: list[FaultInfo],
    ) -> Dict[str, Any]:
        """
        Analyze patterns in fault history.

        Args:
            fault_history: List of past faults.

        Returns:
            Dictionary with pattern analysis.
        """
        if not fault_history:
            return {"pattern": "none", "recommendation": "No faults detected"}

        # Count fault types
        fault_counts: Dict[FaultType, int] = {}
        for fault in fault_history:
            fault_counts[fault.fault_type] = fault_counts.get(fault.fault_type, 0) + 1

        # Find most common fault
        most_common = max(fault_counts.items(), key=lambda x: x[1])
        most_common_type, count = most_common

        # Determine pattern
        if most_common_type == FaultType.RATE_LIMIT and count >= 3:
            pattern = "rate_limit_spike"
            recommendation = "Consider implementing rate limiting or backoff"
        elif most_common_type == FaultType.SERVER_ERROR and count >= 3:
            pattern = "service_degradation"
            recommendation = "Consider switching to backup API or waiting for recovery"
        elif most_common_type == FaultType.TIMEOUT and count >= 3:
            pattern = "network_instability"
            recommendation = "Consider increasing timeout or checking network"
        else:
            pattern = "intermittent"
            recommendation = "Monitor closely, may be transient"

        return {
            "pattern": pattern,
            "most_common_fault": most_common_type.value,
            "fault_counts": {k.value: v for k, v in fault_counts.items()},
            "recommendation": recommendation,
            "total_faults": len(fault_history),
        }
