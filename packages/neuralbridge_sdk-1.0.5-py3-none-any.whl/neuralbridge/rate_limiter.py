"""
NeuralBridge Rate Limiter.

Implements a token bucket rate limiter with sliding window support.
Controls the rate of API requests to prevent quota exhaustion.

Features:
- Token bucket algorithm for smooth rate limiting
- Sliding window for accurate rate calculation
- Burst handling for occasional spikes
- Thread-safe operations

Usage:
    from neuralbridge import RateLimiter, RateLimiterConfig
    
    config = RateLimiterConfig(
        max_requests=100,      # 100 requests
        window_seconds=60.0,   # per 60 seconds
        burst_size=10,          # Allow bursts up to 10 requests
    )
    limiter = RateLimiter(config=config)
    
    if limiter.can_proceed():
        limiter.record_request()
        # Make API call
    else:
        wait_time = limiter.wait_if_needed()
        time.sleep(wait_time)
"""

import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional


@dataclass
class RateLimiterConfig:
    """Configuration for rate limiter.
    
    Attributes:
        max_requests: Maximum number of requests allowed in the window.
            Default: 100
        window_seconds: Time window for rate calculation in seconds.
            Default: 60.0
        burst_size: Maximum burst size allowed (tokens in bucket).
            Default: 10
    """
    max_requests: int = 100
    window_seconds: float = 60.0
    burst_size: int = 10


@dataclass
class RateLimiterStats:
    """Statistics for rate limiter monitoring."""
    total_requests: int = 0
    allowed_requests: int = 0
    rejected_requests: int = 0
    tokens_consumed: int = 0
    tokens_refilled: int = 0
    last_request_time: float = 0.0
    last_refill_time: float = 0.0
    longest_wait_time: float = 0.0


class RateLimiter:
    """
    Token bucket rate limiter with sliding window.
    
    Combines token bucket and sliding window algorithms to provide:
    - Smooth rate limiting (token bucket)
    - Accurate window-based rate calculation (sliding window)
    - Burst handling capability
    
    Attributes:
        config: Rate limiter configuration
        
    Example:
        >>> limiter = RateLimiter(
        ...     config=RateLimiterConfig(max_requests=50, window_seconds=60)
        ... )
        >>> if limiter.can_proceed():
        ...     limiter.record_request()
        ...     # Make API call
        ... else:
        ...     time.sleep(limiter.wait_if_needed())
    """
    
    def __init__(
        self,
        config: Optional[RateLimiterConfig] = None,
        name: Optional[str] = None,
    ):
        """
        Initialize rate limiter.
        
        Args:
            config: Rate limiter configuration (uses defaults if not provided)
            name: Optional identifier for this limiter
        """
        self.config = config or RateLimiterConfig()
        self.name = name or "default"
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Token bucket state
        self._tokens: float = float(self.config.burst_size)  # Start with full bucket
        self._last_refill_time: float = time.time()
        
        # Sliding window for rate tracking
        self._window: Deque[float] = deque(maxlen=self.config.max_requests)
        
        # Statistics
        self._stats = RateLimiterStats()
    
    def _refill_tokens(self) -> None:
        """Refill tokens based on elapsed time."""
        current_time = time.time()
        elapsed = current_time - self._last_refill_time
        
        if elapsed <= 0:
            return
        
        # Calculate tokens to add based on rate
        # Rate = max_requests / window_seconds
        rate = self.config.max_requests / self.config.window_seconds
        tokens_to_add = elapsed * rate
        
        # Add tokens, capped at burst_size
        new_tokens = min(self._tokens + tokens_to_add, float(self.config.burst_size))
        
        if new_tokens > self._tokens:
            self._tokens = new_tokens
            self._stats.tokens_refilled += int(new_tokens - self._tokens)
        
        self._last_refill_time = current_time
        self._stats.last_refill_time = current_time
    
    def _prune_window(self) -> None:
        """Remove expired entries from sliding window."""
        current_time = time.time()
        cutoff_time = current_time - self.config.window_seconds
        
        # Remove old entries
        while self._window and self._window[0] < cutoff_time:
            self._window.popleft()
    
    def can_proceed(self) -> bool:
        """
        Check if a request can proceed without rate limiting.
        
        Returns:
            True if request is allowed, False if rate limited
        """
        with self._lock:
            # Prune expired window entries
            self._prune_window()
            
            # Refill tokens
            self._refill_tokens()
            
            # Check if we're within rate limits
            current_count = len(self._window)
            has_capacity = self._tokens >= 1.0
            within_window = current_count < self.config.max_requests
            
            if has_capacity and within_window:
                return True
            
            return False
    
    def record_request(self) -> bool:
        """
        Record a request (must be called after a successful API call).
        
        Returns:
            True if request was recorded, False if rate limited
        """
        with self._lock:
            if not self.can_proceed():
                self._stats.rejected_requests += 1
                return False
            
            current_time = time.time()
            
            # Record in sliding window
            self._window.append(current_time)
            
            # Consume a token
            self._tokens = max(0.0, self._tokens - 1.0)
            
            # Update statistics
            self._stats.total_requests += 1
            self._stats.allowed_requests += 1
            self._stats.tokens_consumed += 1
            self._stats.last_request_time = current_time
            
            return True
    
    def wait_if_needed(self) -> float:
        """
        Calculate how long to wait before a request can proceed.
        
        Returns:
            Number of seconds to wait (0.0 if can proceed immediately)
        """
        with self._lock:
            # Prune expired window entries
            self._prune_window()
            
            # Refill tokens
            self._refill_tokens()
            
            current_time = time.time()
            current_count = len(self._window)
            
            # Calculate wait time based on multiple factors
            wait_times: List[float] = []
            
            # 1. Wait for token availability
            if self._tokens < 1.0:
                # Rate = max_requests / window_seconds
                rate = self.config.max_requests / self.config.window_seconds
                token_wait = (1.0 - self._tokens) / rate
                wait_times.append(token_wait)
            
            # 2. Wait for window slot
            if current_count >= self.config.max_requests:
                oldest_request = self._window[0]
                window_wait = self.config.window_seconds - (current_time - oldest_request)
                wait_times.append(max(0.0, window_wait))
            
            # Return maximum wait time
            wait_time = max(wait_times) if wait_times else 0.0
            
            # Track longest wait
            if wait_time > self._stats.longest_wait_time:
                self._stats.longest_wait_time = wait_time
            
            return wait_time
    
    def get_wait_time(self) -> float:
        """
        Get estimated wait time without recording.
        
        Returns:
            Estimated wait time in seconds
        """
        return self.wait_if_needed()
    
    def reset(self) -> None:
        """
        Reset the rate limiter to initial state.
        
        Clears all statistics and resets token bucket.
        """
        with self._lock:
            self._tokens = float(self.config.burst_size)
            self._last_refill_time = time.time()
            self._window.clear()
            self._stats = RateLimiterStats()
    
    def get_stats(self) -> Dict:
        """
        Get rate limiter statistics.
        
        Returns:
            Dictionary containing:
            - current_tokens: Available tokens in bucket
            - tokens_in_window: Number of tokens used in current window
            - max_requests: Maximum requests allowed per window
            - window_seconds: Window size in seconds
            - burst_size: Maximum burst size
            - total_requests: Total requests recorded
            - allowed_requests: Number of allowed requests
            - rejected_requests: Number of rejected requests
            - current_rate: Current request rate (req/s)
            - limit_rate: Configured rate limit (req/s)
            - utilization: Current utilization (0.0-1.0)
            - longest_wait_time: Longest wait time recorded
            - last_request_time: Timestamp of last request
            - time_until_next_token: Seconds until next token available
        """
        with self._lock:
            self._prune_window()
            self._refill_tokens()
            
            current_time = time.time()
            
            # Calculate current rate
            window_count = len(self._window)
            if window_count >= 2:
                oldest = self._window[0]
                newest = self._window[-1]
                duration = newest - oldest
                if duration > 0:
                    current_rate = window_count / duration
                else:
                    current_rate = float(window_count)
            else:
                current_rate = 0.0
            
            # Time until next token
            if self._tokens < 1.0:
                rate = self.config.max_requests / self.config.window_seconds
                time_until_token = (1.0 - self._tokens) / rate
            else:
                time_until_token = 0.0
            
            # Utilization
            utilization = window_count / self.config.max_requests if self.config.max_requests > 0 else 0.0
            
            return {
                "current_tokens": round(self._tokens, 2),
                "tokens_in_window": window_count,
                "max_requests": self.config.max_requests,
                "window_seconds": self.config.window_seconds,
                "burst_size": self.config.burst_size,
                "total_requests": self._stats.total_requests,
                "allowed_requests": self._stats.allowed_requests,
                "rejected_requests": self._stats.rejected_requests,
                "current_rate": round(current_rate, 2),
                "limit_rate": round(self.config.max_requests / self.config.window_seconds, 2),
                "utilization": round(utilization, 3),
                "longest_wait_time": round(self._stats.longest_wait_time, 3),
                "last_request_time": self._stats.last_request_time,
                "last_refill_time": self._stats.last_refill_time,
                "time_until_next_token": round(time_until_token, 3),
            }
    
    def get_current_usage(self) -> float:
        """
        Get current usage as a percentage (0.0-1.0).
        
        Returns:
            Current utilization ratio
        """
        with self._lock:
            self._prune_window()
            window_count = len(self._window)
            return window_count / self.config.max_requests if self.config.max_requests > 0 else 0.0
    
    def is_limited(self) -> bool:
        """Check if currently rate limited."""
        return not self.can_proceed()
    
    def get_remaining_requests(self) -> int:
        """
        Get number of remaining requests in current window.
        
        Returns:
            Number of requests that can be made immediately
        """
        with self._lock:
            self._prune_window()
            available = self.config.max_requests - len(self._window)
            # Also account for tokens
            available = min(available, int(math.floor(self._tokens)))
            return max(0, available)
    
    def __repr__(self) -> str:
        with self._lock:
            usage = self.get_current_usage()
            tokens = round(self._tokens, 1)
            return (
                f"RateLimiter(name={self.name!r}, "
                f"tokens={tokens}/{self.config.burst_size}, "
                f"usage={usage:.1%})"
            )
