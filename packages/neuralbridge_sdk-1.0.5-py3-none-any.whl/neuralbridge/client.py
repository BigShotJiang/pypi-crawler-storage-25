"""
NeuralBridge-Lite Client Module

This module provides the main NeuralBridgeClient class that integrates
with the OpenAI SDK format for seamless fault recovery.

The client provides:
- OpenAI SDK-compatible interface
- Automatic fault detection
- Configurable recovery strategies
- Async/await support
"""

import asyncio
import uuid
from typing import Any, Callable, Dict, List, Optional, Union

from .adapters.deepseek import DeepSeekAdapter
from .adapters.openai_compat import OpenAICompatAdapter
from .config import Config
from .detector import FaultDetector
from .exceptions import CircuitBreakerOpenError, NeuralBridgeError, RetryExhaustedError
from .models import FaultInfo, FaultType, RecoveryResult, RecoveryStrategyType
from .recovery.base import RecoveryStrategy
from .recovery.circuit import CircuitBreakerStrategy
from .recovery.flywheel import FlywheelRecoveryStrategy
from .recovery.simple import SimpleRetryStrategy


class NeuralBridgeClient:
    """
    NeuralBridge Client - OpenAI SDK Compatible.

    This is the main client class for NeuralBridge. It provides a drop-in
    replacement for the OpenAI SDK client with automatic fault recovery.

    Simply change:
        from openai import OpenAI
        client = OpenAI(api_key="xxx", base_url="https://api.deepseek.com")

    To:
        from neuralbridge import NeuralBridgeClient
        client = NeuralBridgeClient(api_key="xxx", base_url="https://api.deepseek.com")

    Features:
    - OpenAI SDK-compatible interface
    - Automatic fault detection and classification
    - Multiple recovery strategies (simple, circuit breaker, flywheel)
    - Full async/await support
    - Configurable retry behavior

    Example:
        >>> client = NeuralBridgeClient(
        ...     api_key="your-api-key",
        ...     base_url="https://api.deepseek.com"
        ... )
        >>> response = client.chat.completions.create(
        ...     model="deepseek-chat",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )

    Async Example:
        >>> async def main():
        ...     client = NeuralBridgeClient(
        ...         api_key="your-api-key",
        ...         base_url="https://api.deepseek.com"
        ...     )
        ...     response = await client.chat.completions.create(
        ...         model="deepseek-chat",
        ...         messages=[{"role": "user", "content": "Hello!"}]
        ...     )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        config: Optional[Config] = None,
        recovery_strategy: Optional[Union[str, RecoveryStrategy]] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize NeuralBridgeClient.

        Args:
            api_key: API key for the AI service.
            base_url: Base URL for the API endpoint.
            config: Optional configuration object.
            recovery_strategy: Recovery strategy to use (string or object).
                Options: "none", "simple", "circuit_breaker", "flywheel"
                Default: "flywheel"
            **kwargs: Additional keyword arguments.
        """
        self.api_key = api_key or kwargs.get("api_key")
        self.base_url = base_url or kwargs.get("base_url", "https://api.deepseek.com")
        self.config = config or Config()

        # Detect API provider
        self._provider = self._detect_provider()

        # Initialize adapters
        self._init_adapters()

        # Initialize fault detector
        self._detector = FaultDetector()

        # Initialize recovery strategy
        self._recovery_strategy = self._init_recovery_strategy(recovery_strategy)

        # Circuit breaker for when using that strategy
        self._circuit_breaker: Optional[CircuitBreakerStrategy] = None
        if isinstance(self._recovery_strategy, CircuitBreakerStrategy):
            self._circuit_breaker = self._recovery_strategy

        # Request tracking
        self._request_count = 0
        self._fault_count = 0

    def _detect_provider(self) -> str:
        """
        Detect API provider from base URL.

        Returns:
            Provider name (deepseek, openai, or generic).
        """
        if not self.base_url:
            return "generic"

        url_lower = self.base_url.lower()

        if "deepseek" in url_lower:
            return "deepseek"
        elif "openai" in url_lower:
            return "openai"
        else:
            return "generic"

    def _init_adapters(self) -> None:
        """Initialize API adapters based on provider."""
        if self._provider == "deepseek":
            self._adapter = DeepSeekAdapter(api_key=self.api_key)
        else:
            self._adapter = OpenAICompatAdapter(
                base_url=self.base_url,
                api_key=self.api_key,
            )

    def _init_recovery_strategy(
        self,
        strategy: Optional[Union[str, RecoveryStrategy]],
    ) -> RecoveryStrategy:
        """
        Initialize recovery strategy.

        Args:
            strategy: Strategy name or object.

        Returns:
            Initialized recovery strategy.
        """
        if strategy is None:
            strategy = RecoveryStrategyType.FLYWHEEL
        elif isinstance(strategy, str):
            strategy = RecoveryStrategyType(strategy.lower())

        if isinstance(strategy, RecoveryStrategyType):
            return self._create_strategy_from_type(strategy)

        return strategy

    def _create_strategy_from_type(self, strategy_type: RecoveryStrategyType) -> RecoveryStrategy:
        """
        Create recovery strategy from type enum.

        Args:
            strategy_type: Strategy type enum value.

        Returns:
            New recovery strategy instance.
        """
        if strategy_type == RecoveryStrategyType.NONE:
            # Return a no-op strategy
            return SimpleRetryStrategy(config=self.config, max_retries=0)
        elif strategy_type == RecoveryStrategyType.SIMPLE:
            return SimpleRetryStrategy(config=self.config)
        elif strategy_type == RecoveryStrategyType.CIRCUIT_BREAKER:
            return CircuitBreakerStrategy(config=self.config)
        elif strategy_type == RecoveryStrategyType.FLYWHEEL:
            return FlywheelRecoveryStrategy(config=self.config)
        else:
            return FlywheelRecoveryStrategy(config=self.config)

    @property
    def chat(self) -> "ChatCompletions":
        """
        Get chat completions interface.

        Returns:
            ChatCompletions instance for creating chat completions.
        """
        return ChatCompletions(self)

    async def _execute_request(
        self,
        request_func: Callable,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Execute a request with fault recovery.

        Args:
            request_func: Async function to execute.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            Response from request_func.

        Raises:
            RetryExhaustedError: When all retries are exhausted.
        """
        attempt = 0
        max_attempts = self.config.max_retries + 1
        last_error: Optional[Exception] = None

        while attempt < max_attempts:
            attempt += 1

            # Check circuit breaker
            if self._circuit_breaker and not self._circuit_breaker.is_call_allowed():
                raise CircuitBreakerOpenError(
                    message="Circuit breaker is open",
                    failure_count=self._circuit_breaker.failure_count,
                    recovery_timeout=self.config.recovery_timeout,
                )

            try:
                # Execute request
                response = await request_func(*args, **kwargs)

                # Record success in circuit breaker
                if self._circuit_breaker:
                    self._circuit_breaker.record_success()

                # Record success in flywheel if applicable
                if isinstance(self._recovery_strategy, FlywheelRecoveryStrategy):
                    self._recovery_strategy.record_success()

                return response

            except Exception as e:
                last_error = e
                self._request_count += 1

                # Detect fault
                fault = self._detector.detect_from_exception(e)

                # Check if we should retry
                if not self._detector.should_retry(fault):
                    if self.config.raise_on_retry_exhausted:
                        raise RetryExhaustedError(
                            message=f"Non-retryable fault: {fault.fault_type.value}",
                            fault_type=fault.fault_type.value,
                            attempts=attempt,
                            last_error=e,
                        )
                    raise

                # Check if retries exhausted
                if attempt >= max_attempts:
                    if self.config.raise_on_retry_exhausted:
                        raise RetryExhaustedError(
                            message=f"All retries exhausted after {attempt} attempts",
                            fault_type=fault.fault_type.value,
                            attempts=attempt,
                            last_error=e,
                        )
                    raise

                # Attempt recovery
                if self.config.verbose:
                    print(
                        f"[NeuralBridge] Fault detected: {fault.fault_type.value}, "
                        f"attempting recovery..."
                    )

                recovery_result = await self._recovery_strategy.recover(
                    fault,
                    attempt,
                    request_func,
                    *args,
                    **kwargs,
                )

                if not recovery_result.should_retry:
                    if self.config.raise_on_retry_exhausted:
                        raise RetryExhaustedError(
                            message=recovery_result.message or "Recovery failed",
                            fault_type=fault.fault_type.value,
                            attempts=attempt,
                            last_error=e,
                        )
                    raise

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise NeuralBridgeError("Request failed after all retries")

    def set_recovery_strategy(
        self,
        strategy: Union[str, RecoveryStrategy],
    ) -> None:
        """
        Change recovery strategy at runtime.

        Args:
            strategy: New recovery strategy (string or object).
        """
        self._recovery_strategy = self._init_recovery_strategy(strategy)

        if isinstance(self._recovery_strategy, CircuitBreakerStrategy):
            self._circuit_breaker = self._recovery_strategy
        else:
            self._circuit_breaker = None

    def get_metrics(self) -> Dict[str, Any]:
        """
        Get client metrics.

        Returns:
            Dictionary with metrics.
        """
        metrics = {
            "total_requests": self._request_count,
            "fault_count": self._fault_count,
            "recovery_strategy": self._recovery_strategy.name,
            "provider": self._provider,
        }

        if self._circuit_breaker:
            metrics["circuit_breaker_state"] = self._circuit_breaker.get_state_info()

        if isinstance(self._recovery_strategy, FlywheelRecoveryStrategy):
            metrics["flywheel_context"] = self._recovery_strategy.get_flywheel_context()

        return metrics

    def reset(self) -> None:
        """Reset client state."""
        self._request_count = 0
        self._fault_count = 0
        self._recovery_strategy.reset()

        if self._circuit_breaker:
            self._circuit_breaker.reset()


class ChatCompletions:
    """
    Chat Completions interface compatible with OpenAI SDK.

    This class provides the chat.completions.create() method
    compatible with the OpenAI SDK.
    """

    def __init__(self, client: NeuralBridgeClient) -> None:
        """
        Initialize ChatCompletions.

        Args:
            client: Parent NeuralBridgeClient instance.
        """
        self._client = client

    def create(
        self,
        model: str,
        messages: List[Dict[str, str]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """
        Create a chat completion.

        This method is synchronous. Use create_async for async operations.

        Args:
            model: Model name to use.
            messages: List of message dictionaries.
            stream: Whether to stream the response.
            **kwargs: Additional parameters.

        Returns:
            Chat completion response.
        """
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(
            self.create_async(model=model, messages=messages, stream=stream, **kwargs)
        )

    async def create_async(
        self,
        model: str,
        messages: List[Dict[str, str]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """
        Create a chat completion (async version).

        Args:
            model: Model name to use.
            messages: List of message dictionaries.
            stream: Whether to stream the response.
            **kwargs: Additional parameters.

        Returns:
            Chat completion response.
        """
        # Build request payload
        payload = self._client._adapter.format_request(
            model=model,
            messages=messages,
            stream=stream,
            **kwargs,
        )

        # Create request function
        async def make_request() -> Any:
            return await self._do_request(payload)

        # Execute with recovery
        return await self._client._execute_request(make_request)

    async def _do_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the actual HTTP request.

        Args:
            payload: Request payload.

        Returns:
            Response data.
        """
        # Import httpx for actual HTTP requests
        try:
            import httpx
        except ImportError:
            raise NeuralBridgeError(
                "httpx is required for making requests. "
                "Install with: pip install httpx"
            )

        headers = self._client._adapter.get_headers(
            api_key=self._client.api_key,
            extra_headers=self._client.config.extra_headers,
        )

        url = self._client._adapter.get_chat_completions_url()

        async with httpx.AsyncClient(timeout=self._client.config.timeout) as client:
            response = await client.post(url, json=payload, headers=headers)

            if response.status_code >= 400:
                try:
                    error_data = response.json()
                except Exception:
                    error_data = {"error": {"message": response.text}}

                error_info = self._client._adapter.extract_error_info(error_data)
                raise NeuralBridgeError(
                    error_info.get("message") or f"API Error: {response.status_code}",
                    details=error_info,
                )

            return response.json()
