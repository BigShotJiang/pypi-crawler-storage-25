import logging
logger = logging.getLogger("neuralbridge.telemetry")

class TelemetryConfig:
    def __init__(self, enabled=True, service_name="neuralbridge", endpoint=None):
        self.enabled = enabled
        self.service_name = service_name
        self.endpoint = endpoint

class NeuralBridgeTelemetry:
    def __init__(self, config=None):
        self._config = config or TelemetryConfig(enabled=False)
        self._tracer = None
        self._metrics = {"total_requests": 0, "total_errors": 0}
    
    def record_request(self, duration_ms, success, model="", provider="", error_category=""):
        self._metrics["total_requests"] += 1
    
    def get_metrics(self):
        return self._metrics
    
    def is_available(self):
        return self._tracer is not None
