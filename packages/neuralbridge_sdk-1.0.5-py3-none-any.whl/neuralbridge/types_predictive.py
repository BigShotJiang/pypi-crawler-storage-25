

# ========== Predictive Self-Healing Types (v0.4.0) ==========

@dataclass
class PredictiveConfig:
    """
    Configuration for predictive self-healing engine.
    
    Controls when the engine should predict failures and proactively
    switch models before errors occur.
    
    Attributes:
        window_seconds: Statistical window size (default: 300s = 5 minutes)
        latency_threshold_ms: Latency threshold to trigger warning (default: 2000ms)
        error_rate_threshold: Error rate threshold to trigger warning (default: 10%)
        min_samples: Minimum samples needed before prediction (default: 5)
        auto_switch: Automatically switch to healthy model (default: True)
        cooldown_seconds: Cooldown period after switch (default: 60s)
    """
    window_seconds: int = 300
    latency_threshold_ms: float = 2000.0
    error_rate_threshold: float = 0.1
    min_samples: int = 5
    auto_switch: bool = True
    cooldown_seconds: int = 60


@dataclass
class Prediction:
    """
    Result of predictive analysis for a model.
    
    Attributes:
        model: The model being analyzed
        should_switch: Whether the model should be switched
        reason: Reason for the recommendation
        confidence: Confidence score (0.0-1.0) for the prediction
        current_stats: Current statistics for the model
        recommended_model: Recommended replacement model (if any)
    """
    model: str
    should_switch: bool = False
    reason: str = ""
    confidence: float = 0.0
    current_stats: Dict[str, Any] = field(default_factory=dict)
    recommended_model: Optional[str] = None
