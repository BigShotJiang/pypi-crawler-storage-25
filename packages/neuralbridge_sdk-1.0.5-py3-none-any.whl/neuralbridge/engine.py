"""
NeuralBridge Core Engine — v1.0.4
Self-healing decision engine for AI API calls.

v1.0.4 fixes (9 critical bugs):
1. register(name, strategy) — pass name parameter
2. get_for_diagnosis(diagnosis) — not get_strategies(category)
3. can_proceed() — not allow_request()
4. DiagnosisResult(retryable=, suggestion=) — required fields
5. No more suggest_action/execute — simplified strategy path
6. No more RecoveryAction.execute() — removed dead code
7. ModelPerformance.update() — not record_success/failure()
8. No api_key_getter/setter leaking to func() kwargs
9. model_ref mutable container — fallback model reaches HTTP request
"""

import time
import random
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, TypeVar

from .types import (
    DiagnosisResult, ErrorCategory, RecoveryAction, RecoveryRecord,
    CascadeLevel, ModelPerformance, HealthStatus, RequestTrace,
    ModelHealth, RecoveryStats,
)
from .strategies import (
    RecoveryStrategy, RateLimitStrategy, AuthRefreshStrategy,
    ModelFallbackStrategy, NetworkRetryStrategy, StrategyRegistry,
)
from .jitter import JitterConfig, JitterStrategy, DEFAULT_JITTER_CONFIG
from .circuit_breaker import (
    CircuitBreaker, CircuitBreakerConfig, CircuitState, CircuitOpenError,
)
from .rate_limiter import RateLimiter, RateLimiterConfig
from .tiered_timeout import TieredTimeoutManager, TieredTimeoutConfig, TimeoutTier

T = TypeVar('T')


class DiagnosisEngine:
    """Analyzes errors and determines recovery strategy."""
    
    STATUS_CODE_MAP = {
        400: ErrorCategory.VALIDATION_ERROR,
        401: ErrorCategory.AUTH_ERROR,
        403: ErrorCategory.AUTH_ERROR,
        404: ErrorCategory.MODEL_UNAVAILABLE,
        408: ErrorCategory.NETWORK_ERROR,
        429: ErrorCategory.RATE_LIMIT,
        500: ErrorCategory.SERVER_ERROR,
        502: ErrorCategory.SERVER_ERROR,
        503: ErrorCategory.SERVER_ERROR,
        504: ErrorCategory.SERVER_ERROR,
    }
    
    _ERROR_PATTERNS = {
        "dashscope": [
            ("dashscope_rate_limit", ErrorCategory.RATE_LIMIT, [
                "throttling.ratequota", "请求过于频繁", "请求速度超限",
            ], 0.95),
            ("dashscope_auth_error", ErrorCategory.AUTH_ERROR, [
                "invalidparameter", "invalidcredential", "凭证无效", "invalid credential",
            ], 0.9),
            ("dashscope_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "modelnotexists", "模型不存在", "模型不可用",
            ], 0.95),
            ("dashscope_service_unavailable", ErrorCategory.SERVER_ERROR, [
                "serviceunavailable", "服务不可用", "系统错误",
            ], 0.9),
            ("dashscope_quota_exceeded", ErrorCategory.RATE_LIMIT, [
                "quota exceeded", "quota used up", "配额不足", "额度用尽",
            ], 0.95),
        ],
        "openai": [
            ("openai_rate_limit", ErrorCategory.RATE_LIMIT, [
                "openai's api is currently overloaded", "openai api request error",
            ], 0.95),
            ("openai_auth_error", ErrorCategory.AUTH_ERROR, [
                "billing hard limit reached", "billing soft limit", "you exceeded your billing limit",
            ], 0.95),
            ("openai_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "openai gave a 404",
            ], 0.95),
            ("openai_server_error", ErrorCategory.SERVER_ERROR, [
                "openai server error",
            ], 0.95),
        ],
        "deepseek": [
            ("deepseek_rate_limit", ErrorCategory.RATE_LIMIT, [
                "rate limit", "too many requests",
            ], 0.85),
            ("deepseek_auth_error", ErrorCategory.AUTH_ERROR, [
                "invalid api key", "authentication",
            ], 0.85),
            ("deepseek_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "model not found", "does not exist",
            ], 0.85),
        ],
        "network": [
            ("generic_network", ErrorCategory.NETWORK_ERROR, [
                "connection refused", "connection reset", "connection aborted",
                "name resolution", "dns", "ssl", "sslerror", "certificate",
                "socket", "eof", "broken pipe", "read timeout", "connect timeout",
                "connection timeout", "connection error", "network error",
                "network unreachable", "host unreachable",
            ], 0.7),
        ],
        "generic": [
            ("generic_rate_limit", ErrorCategory.RATE_LIMIT, [
                "rate limit", "rate_limit", "too many requests", "throttl",
                "quota exceeded", "slow down", "request limit",
            ], 0.7),
            ("generic_auth", ErrorCategory.AUTH_ERROR, [
                "invalid api key", "unauthorized", "authentication",
                "invalid credentials", "access denied", "forbidden",
            ], 0.7),
            ("generic_model", ErrorCategory.MODEL_UNAVAILABLE, [
                "model not found", "does not exist", "not available",
                "no such model", "model is currently",
            ], 0.7),
            ("generic_server", ErrorCategory.SERVER_ERROR, [
                "internal server error", "server error", "service unavailable",
                "bad gateway", "gateway timeout", "overloaded",
            ], 0.6),
        ],
    }
    
    def diagnose(self, error: Exception) -> DiagnosisResult:
        error_str = str(error).lower()
        platform = self._detect_platform(error_str)
        
        # Try platform-specific patterns first
        if platform and platform in self._ERROR_PATTERNS:
            for sub_cat, category, keywords, confidence in self._ERROR_PATTERNS[platform]:
                for kw in keywords:
                    if kw.lower() in error_str:
                        return DiagnosisResult(
                            category=category,
                            retryable=True,
                            suggestion=f"Try fallback or retry for {sub_cat}",
                            sub_category=sub_cat,
                            confidence=confidence,
                            metadata={"keyword": kw, "platform": platform}
                        )
        
        # Generic patterns
        for sub_cat, category, keywords, confidence in self._ERROR_PATTERNS.get("generic", []):
            for kw in keywords:
                if kw.lower() in error_str:
                    return DiagnosisResult(
                        category=category,
                        retryable=True,
                        suggestion=f"Try fallback or retry for {sub_cat}",
                        sub_category=sub_cat,
                        confidence=confidence * 0.8,
                        metadata={"keyword": kw, "platform": "generic"}
                    )
        
        # Network patterns
        for sub_cat, category, keywords, confidence in self._ERROR_PATTERNS.get("network", []):
            for kw in keywords:
                if kw.lower() in error_str:
                    return DiagnosisResult(
                        category=category,
                        retryable=True,
                        suggestion="Retry with backoff",
                        sub_category=sub_cat,
                        confidence=confidence,
                        metadata={"keyword": kw, "platform": "network"}
                    )
        
        return DiagnosisResult(
            category=ErrorCategory.UNKNOWN,
            retryable=False,
            suggestion="No recovery strategy available",
            sub_category="unclassified",
            confidence=0.3,
            metadata={"error_snippet": error_str[:200]}
        )
    
    def _detect_platform(self, error_str: str) -> Optional[str]:
        for platform in ["dashscope", "openai", "deepseek", "anthropic", "azure", "google"]:
            if platform in error_str:
                return platform
        return None


class FlywheelEngine:
    """
    Self-healing decision engine with cascade recovery.
    
    v1.0.4 fixes:
    - register(name, strategy) with name parameter
    - can_proceed() instead of allow_request()
    - DiagnosisResult with required retryable/suggestion
    - No api_key_getter/setter leaking to func()
    - model_ref mutable container for fallback model propagation
    - Simplified recovery: no get_strategies/suggest_action/execute
    - ModelPerformance.update() instead of record_success/failure()
    """
    
    def __init__(
        self,
        fallback_models: Optional[List[str]] = None,
        max_retries: int = 3,
        verbose: bool = False,
        jitter_config: Optional[JitterConfig] = None,
        api_key_refresher: Optional[Callable[[], str]] = None,
        predictive_config: Optional[Any] = None,
        enable_learning: bool = False,
        license_key: Optional[str] = None,
    ):
        self.fallback_models = fallback_models or []
        self.max_retries = max_retries
        self.verbose = verbose
        self.jitter_config = jitter_config or DEFAULT_JITTER_CONFIG
        self.api_key_refresher = api_key_refresher
        
        # Sub-engines
        self._diagnosis = DiagnosisEngine()
        self._strategy_registry = StrategyRegistry()
        # v1.0.4 FIX #1: register(name, strategy) — pass name parameter
        self._strategy_registry.register("rate_limit", RateLimitStrategy())
        self._strategy_registry.register("auth_refresh", AuthRefreshStrategy(api_key_refresher))
        self._strategy_registry.register("model_fallback", ModelFallbackStrategy(self.fallback_models))
        self._strategy_registry.register("network_retry", NetworkRetryStrategy())
        
        # Circuit breaker
        self._circuit_breaker = CircuitBreaker(CircuitBreakerConfig())
        
        # v1.0.4 FIX #3: RateLimiter uses can_proceed()
        self._rate_limiter = RateLimiter(RateLimiterConfig())
        
        # Tiered timeout
        self._tiered_timeout_manager = TieredTimeoutManager()
        
        # Predictive engine
        self.predictive_engine = None
        self._predictive_enabled = False
        
        # Learning engine
        self._learner = None
        self._learner_enabled = False
        
        # Performance tracking
        self.model_performance: Dict[str, ModelPerformance] = {}
        self.recovery_history: List[RecoveryRecord] = []
        
        # License
        self._license_key = license_key
    
    def heal(
        self,
        func: Callable[..., T],
        current_model: Optional[str] = None,
        model_ref: Optional[Dict[str, str]] = None,
        **kwargs,
    ) -> T:
        """
        Self-healing wrapper.
        
        v1.0.4: 
        - model_ref is a mutable dict {"model": "xxx"} that the adapter's
          _make_request() closure reads from, so fallback model changes
          propagate to the actual HTTP request.
        - No api_key_getter/setter leaked to func() — those are handled
          separately in the adapter.
        """
        if self._circuit_breaker.is_open():
            raise CircuitOpenError("Circuit breaker is open")
        
        # v1.0.4 FIX #3: can_proceed() instead of allow_request()
        if not self._rate_limiter.can_proceed():
            raise Exception("Rate limit exceeded")
        
        current_model = current_model or ""
        attempt = 0
        last_exception = None
        total_duration = 0.0
        
        while attempt <= self.max_retries:
            start_time = time.time()
            try:
                self._rate_limiter.record_request()
                
                # v1.0.4 FIX #9: Update model_ref so adapter closure sees new model
                if model_ref is not None:
                    model_ref["model"] = current_model
                
                result = func()
                
                duration = time.time() - start_time
                total_duration += duration
                self._track_success(current_model, duration)
                self._circuit_breaker.record_success()
                return result
                
            except CircuitOpenError:
                raise
            except Exception as e:
                duration = time.time() - start_time
                total_duration += duration
                last_exception = e
                self._circuit_breaker.record_failure()
                
                # Diagnose
                diagnosis = self._diagnosis.diagnose(e)
                
                # Model fallback for MODEL_UNAVAILABLE
                if diagnosis.category == ErrorCategory.MODEL_UNAVAILABLE and self.fallback_models:
                    next_idx = (self.fallback_models.index(current_model) + 1) if current_model in self.fallback_models else 0
                    if next_idx < len(self.fallback_models):
                        current_model = self.fallback_models[next_idx]
                        if self.verbose:
                            print(f"[NeuralBridge] MODEL_UNAVAILABLE: switching to fallback: {current_model}")
                        attempt += 1
                        continue
                
                # Model fallback for RATE_LIMIT
                if diagnosis.category == ErrorCategory.RATE_LIMIT and self.fallback_models:
                    next_idx = (self.fallback_models.index(current_model) + 1) if current_model in self.fallback_models else 0
                    if next_idx < len(self.fallback_models):
                        current_model = self.fallback_models[next_idx]
                        if self.verbose:
                            print(f"[NeuralBridge] RATE_LIMIT: switching to fallback: {current_model}")
                        attempt += 1
                        continue
                
                # Auth refresh
                if diagnosis.category == ErrorCategory.AUTH_ERROR and self.api_key_refresher:
                    try:
                        new_key = self.api_key_refresher()
                        if self.verbose:
                            print(f"[NeuralBridge] AUTH_ERROR: refreshed API key")
                    except Exception:
                        pass
                
                # Exponential backoff with jitter
                backoff = min(2 ** attempt * 0.5, 30.0)
                jitter = random.uniform(0, backoff * 0.3)
                time.sleep(backoff + jitter)
                attempt += 1
        
        # All retries exhausted — try remaining fallback models
        if self.fallback_models:
            tried_models = {current_model}
            for fb_model in self.fallback_models:
                if fb_model not in tried_models:
                    if self.verbose:
                        print(f"[NeuralBridge] Retries exhausted, trying fallback: {fb_model}")
                    try:
                        if model_ref is not None:
                            model_ref["model"] = fb_model
                        current_model = fb_model
                        result = func()
                        self._track_success(fb_model, time.time() - start_time)
                        self._circuit_breaker.record_success()
                        return result
                    except Exception:
                        tried_models.add(fb_model)
                        continue
        
        self._track_failure(current_model, last_exception, total_duration)
        raise last_exception
    
    def _track_success(self, model: str, duration: float):
        if model not in self.model_performance:
            self.model_performance[model] = ModelPerformance(model=model)
        # v1.0.4 FIX #7: update() instead of record_success()
        self.model_performance[model].update(success=True, latency=duration)
    
    def _track_failure(self, model: str, error: Exception, duration: float):
        if model not in self.model_performance:
            self.model_performance[model] = ModelPerformance(model=model)
        # v1.0.4 FIX #7: update() instead of record_failure()
        self.model_performance[model].update(success=False, latency=duration, error=str(error)[:200])
    
    def get_health_status(self) -> HealthStatus:
        healthy, degraded, failed = [], [], []
        for model, perf in self.model_performance.items():
            if perf.reliability_score >= 0.9:
                healthy.append(model)
            elif perf.reliability_score >= 0.5:
                degraded.append(model)
            else:
                failed.append(model)
        return HealthStatus(
            healthy=len(healthy) == 0 or len(failed) == 0,
            active_models=healthy,
            degraded_models=degraded,
            failed_models=failed,
            recommendations=[f"Avoid {m}" for m in failed] if failed else [],
        )
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            "version": "1.0.4",
            "fallback_models": self.fallback_models,
            "max_retries": self.max_retries,
            "model_performance": {
                m: {"total": p.total_calls, "success_rate": p.success_rate, "avg_latency": p.avg_latency}
                for m, p in self.model_performance.items()
            },
            "circuit_breaker": self._circuit_breaker.get_stats(),
            "rate_limiter": self._rate_limiter.get_stats(),
        }


# Backward compat
NeuralBridgeEngine = FlywheelEngine
