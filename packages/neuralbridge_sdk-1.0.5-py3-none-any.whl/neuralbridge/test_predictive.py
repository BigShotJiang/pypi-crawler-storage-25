"""
Tests for Predictive Self-Healing Engine.

These tests verify the sliding window statistics, trend detection,
and predictive switching functionality.
"""

import time
import unittest
from neuralbridge import (
    FlywheelEngine,
    PredictiveEngine,
    PredictiveConfig,
    Prediction,
)


class TestModelStats(unittest.TestCase):
    """Test ModelStats sliding window calculations."""
    
    def test_empty_stats(self):
        """Test stats with no samples."""
        stats = PredictiveEngine._get_or_create_stats(
            PredictiveEngine(PredictiveConfig()), "test-model"
        )
        self.assertEqual(stats.sample_count, 0)
        self.assertEqual(stats.success_rate, 1.0)
        self.assertEqual(stats.error_rate, 0.0)
        self.assertEqual(stats.avg_latency, 0.0)
    
    def test_success_rate_calculation(self):
        """Test success rate is calculated correctly."""
        engine = PredictiveEngine(PredictiveConfig())
        stats = engine._get_or_create_stats("test")
        
        # 8 successes, 2 failures = 80% success rate
        for _ in range(8):
            stats.add_sample(100, True)
        for _ in range(2):
            stats.add_sample(100, False)
        
        self.assertAlmostEqual(stats.success_rate, 0.8, places=2)
        self.assertAlmostEqual(stats.error_rate, 0.2, places=2)
    
    def test_latency_percentiles(self):
        """Test P95 and P99 latency calculations."""
        engine = PredictiveEngine(PredictiveConfig())
        stats = engine._get_or_create_stats("test")
        
        # Add 100 samples with varying latency
        for i in range(100):
            latency = 100 + i  # 100, 101, 102, ... 199
            stats.add_sample(latency, True)
        
        # P95 should be around 195 (95th percentile of 100-199)
        self.assertGreater(stats.p95_latency, 190)
        self.assertLess(stats.p95_latency, 200)
        
        # P99 should be around 199
        self.assertGreater(stats.p99_latency, 195)
        self.assertLess(stats.p99_latency, 200)
    
    def test_sliding_window_expiry(self):
        """Test old samples are removed from window."""
        config = PredictiveConfig(window_seconds=1)  # 1 second window
        engine = PredictiveEngine(config)
        stats = engine._get_or_create_stats("test")
        
        # Add a sample
        stats.add_sample(100, True)
        self.assertEqual(stats.sample_count, 1)
        
        # Wait for window to expire
        time.sleep(1.1)
        
        # Sample should be pruned
        stats._prune_old_samples()
        self.assertEqual(stats.sample_count, 0)


class TestPredictiveEngine(unittest.TestCase):
    """Test PredictiveEngine functionality."""
    
    def test_record_request(self):
        """Test recording request results."""
        engine = PredictiveEngine(PredictiveConfig())
        
        engine.record_request("model-a", 1500, True)
        engine.record_request("model-a", 2000, True)
        engine.record_request("model-a", 1800, False)
        
        stats = engine.get_model_stats("model-a")
        self.assertEqual(stats["sample_count"], 3)
        self.assertAlmostEqual(stats["success_rate"], 2/3, places=2)
    
    def test_predict_no_data(self):
        """Test prediction with no data returns no switch."""
        engine = PredictiveEngine(PredictiveConfig())
        
        prediction = engine.predict("unknown-model")
        
        self.assertFalse(prediction.should_switch)
        self.assertEqual(prediction.reason, "no_data")
        self.assertEqual(prediction.confidence, 0.0)
    
    def test_predict_insufficient_samples(self):
        """Test prediction with insufficient samples."""
        config = PredictiveConfig(min_samples=10)
        engine = PredictiveEngine(config)
        
        # Only 5 samples, but min_samples is 10
        for _ in range(5):
            engine.record_request("model-a", 100, True)
        
        prediction = engine.predict("model-a")
        
        self.assertFalse(prediction.should_switch)
        self.assertEqual(prediction.reason, "insufficient_samples")
    
    def test_predict_high_error_rate(self):
        """Test prediction triggers on high error rate."""
        config = PredictiveConfig(
            min_samples=5,
            error_rate_threshold=0.3,
        )
        engine = PredictiveEngine(config)
        
        # 70% error rate > 30% threshold
        for _ in range(3):
            engine.record_request("failing-model", 100, True)
        for _ in range(7):
            engine.record_request("failing-model", 100, False)
        
        prediction = engine.predict("failing-model")
        
        self.assertTrue(prediction.should_switch)
        self.assertEqual(prediction.reason, "high_error_rate")
        self.assertGreater(prediction.confidence, 0.0)
    
    def test_predict_high_latency(self):
        """Test prediction triggers on high latency."""
        config = PredictiveConfig(
            min_samples=5,
            latency_threshold_ms=1000,
        )
        engine = PredictiveEngine(config)
        
        # All requests have P95 > 1000ms threshold
        for _ in range(10):
            engine.record_request("slow-model", 2000, True)
        
        prediction = engine.predict("slow-model")
        
        self.assertTrue(prediction.should_switch)
        self.assertEqual(prediction.reason, "high_latency")
    
    def test_predict_healthy_model(self):
        """Test healthy model doesn't trigger switch."""
        config = PredictiveConfig(
            min_samples=5,
            error_rate_threshold=0.1,
            latency_threshold_ms=2000,
        )
        engine = PredictiveEngine(config)
        
        # 100% success, low latency
        for _ in range(10):
            engine.record_request("healthy-model", 500, True)
        
        prediction = engine.predict("healthy-model")
        
        self.assertFalse(prediction.should_switch)
        self.assertEqual(prediction.reason, "healthy")
    
    def test_cooldown_period(self):
        """Test cooldown prevents rapid switching."""
        config = PredictiveConfig(
            min_samples=5,
            cooldown_seconds=5,
        )
        engine = PredictiveEngine(config)
        
        # Set up a failing model
        for _ in range(10):
            engine.record_request("failing-model", 100, False)
        
        # First prediction should switch
        prediction1 = engine.predict("failing-model")
        self.assertTrue(prediction1.should_switch)
        
        # Mark switch occurred
        engine.mark_switch("failing-model")
        
        # Immediate second prediction should be in cooldown
        prediction2 = engine.predict("failing-model")
        self.assertFalse(prediction2.should_switch)
        self.assertEqual(prediction2.reason, "cooldown")
    
    def test_get_recommended_model(self):
        """Test model recommendation picks healthiest."""
        engine = PredictiveEngine(PredictiveConfig(min_samples=2))
        
        # Model A: 50% success
        for _ in range(5):
            engine.record_request("model-a", 500, False)
        for _ in range(5):
            engine.record_request("model-a", 500, True)
        
        # Model B: 100% success, low latency
        for _ in range(10):
            engine.record_request("model-b", 200, True)
        
        recommended = engine.get_recommended_model(
            ["model-a", "model-b"],
            exclude="model-a"
        )
        
        self.assertEqual(recommended, "model-b")
    
    def test_reset(self):
        """Test engine reset clears all state."""
        engine = PredictiveEngine(PredictiveConfig())
        
        engine.record_request("model-a", 100, True)
        engine.record_request("model-b", 100, False)
        engine.mark_switch("model-a")
        
        engine.reset()
        
        self.assertEqual(engine.get_model_stats("model-a")["sample_count"], 0)
        self.assertEqual(engine.get_model_stats("model-b")["sample_count"], 0)


class TestFlywheelEngineIntegration(unittest.TestCase):
    """Test FlywheelEngine integration with PredictiveEngine."""
    
    def test_predictive_config_init(self):
        """Test FlywheelEngine accepts predictive_config."""
        config = PredictiveConfig(
            window_seconds=300,
            latency_threshold_ms=1500,
            error_rate_threshold=0.1,
        )
        
        engine = FlywheelEngine(
            fallback_models=["model-a", "model-b"],
            predictive_config=config,
        )
        
        self.assertTrue(engine._predictive_enabled)
        self.assertIsNotNone(engine.predictive_engine)
    
    def test_predictive_disabled_by_default(self):
        """Test predictive is disabled when no config provided."""
        engine = FlywheelEngine(
            fallback_models=["model-a", "model-b"],
        )
        
        self.assertFalse(engine._predictive_enabled)
        self.assertIsNone(engine.predictive_engine)
    
    def test_enable_predictive_mode(self):
        """Test enable_predictive_mode convenience method."""
        engine = FlywheelEngine(
            fallback_models=["model-a", "model-b"],
        )
        
        config = engine.enable_predictive_mode(
            window="5min",
            latency_threshold=2000,
            error_threshold=0.1,
        )
        
        self.assertTrue(engine._predictive_enabled)
        self.assertEqual(config.window_seconds, 300)
        self.assertEqual(config.latency_threshold_ms, 2000)
    
    def test_get_model_stats_with_predictive(self):
        """Test get_model_stats includes predictive stats."""
        config = PredictiveConfig(min_samples=2)
        engine = FlywheelEngine(
            fallback_models=["model-a"],
            predictive_config=config,
        )
        
        engine.predictive_engine.record_request("model-a", 500, True)
        engine.predictive_engine.record_request("model-a", 600, True)
        
        stats = engine.get_model_stats("model-a")
        
        self.assertIn("sample_count", stats)
        self.assertIn("success_rate", stats)
        self.assertEqual(stats["sample_count"], 2)
    
    def test_predict_model_switch(self):
        """Test predict_model_switch method."""
        config = PredictiveConfig(min_samples=2)
        engine = FlywheelEngine(
            fallback_models=["model-a"],
            predictive_config=config,
        )
        
        # No data yet
        prediction = engine.predict_model_switch("model-a")
        self.assertEqual(prediction.reason, "no_data")
    
    def test_get_predictive_stats(self):
        """Test get_predictive_stats returns all model stats."""
        config = PredictiveConfig()
        engine = FlywheelEngine(
            fallback_models=["model-a", "model-b"],
            predictive_config=config,
        )
        
        engine.predictive_engine.record_request("model-a", 500, True)
        engine.predictive_engine.record_request("model-b", 600, False)
        
        all_stats = engine.get_predictive_stats()
        
        self.assertIn("model-a", all_stats)
        self.assertIn("model-b", all_stats)
    
    def test_reset_clears_predictive(self):
        """Test reset clears predictive engine state."""
        config = PredictiveConfig()
        engine = FlywheelEngine(
            fallback_models=["model-a"],
            predictive_config=config,
        )
        
        engine.predictive_engine.record_request("model-a", 500, True)
        
        engine.reset()
        
        stats = engine.predictive_engine.get_model_stats("model-a")
        self.assertEqual(stats["sample_count"], 0)


class TestEnablePredictiveMode(unittest.TestCase):
    """Test enable_predictive_mode parsing."""
    
    def _parse_window(self, window: str) -> int:
        """Helper to test window parsing."""
        window_map = {
            "1min": 60,
            "5min": 300,
            "10min": 600,
            "30min": 1800,
        }
        return window_map.get(window, 300)
    
    def test_window_parsing(self):
        """Test various window formats."""
        self.assertEqual(self._parse_window("1min"), 60)
        self.assertEqual(self._parse_window("5min"), 300)
        self.assertEqual(self._parse_window("10min"), 600)
        self.assertEqual(self._parse_window("30min"), 1800)
        self.assertEqual(self._parse_window("unknown"), 300)  # default


class TestPrediction(unittest.TestCase):
    """Test Prediction dataclass."""
    
    def test_prediction_fields(self):
        """Test Prediction has all required fields."""
        prediction = Prediction(
            model="test-model",
            should_switch=True,
            reason="high_error_rate",
            confidence=0.85,
            current_stats={"sample_count": 10},
            recommended_model="backup-model",
        )
        
        self.assertEqual(prediction.model, "test-model")
        self.assertTrue(prediction.should_switch)
        self.assertEqual(prediction.reason, "high_error_rate")
        self.assertAlmostEqual(prediction.confidence, 0.85)
        self.assertEqual(prediction.current_stats["sample_count"], 10)
        self.assertEqual(prediction.recommended_model, "backup-model")
    
    def test_prediction_defaults(self):
        """Test Prediction default values."""
        prediction = Prediction(model="test-model")
        
        self.assertFalse(prediction.should_switch)
        self.assertEqual(prediction.reason, "")
        self.assertEqual(prediction.confidence, 0.0)
        self.assertEqual(prediction.current_stats, {})
        self.assertIsNone(prediction.recommended_model)


if __name__ == "__main__":
    unittest.main()
