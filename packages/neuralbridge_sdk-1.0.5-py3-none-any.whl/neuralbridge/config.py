"""
NeuralBridge-Lite Configuration Module

This module provides configuration management for NeuralBridge.
"""

from dataclasses import dataclass, field
from typing import Dict, Optional, Any


@dataclass
class Config:
    """Configuration for NeuralBridge client."""

    # Retry settings
    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True

    # Timeout settings
    timeout: float = 30.0
    connect_timeout: float = 10.0

    # Circuit breaker settings
    failure_threshold: int = 5
    success_threshold: int = 2
    recovery_timeout: float = 60.0

    # Flywheel settings
    enable_flywheel: bool = True
    flywheel_api_key: Optional[str] = None
    flywheel_api_url: str = "https://api.neuralbridge-ai.surge.sh/flywheel"

    # Detection settings
    detect_timeout: bool = True
    detect_rate_limit: bool = True
    detect_invalid_model: bool = True
    detect_empty_body: bool = True
    detect_server_error: bool = True
    detect_auth_error: bool = True

    # General settings
    raise_on_retry_exhausted: bool = True
    log_faults: bool = True
    verbose: bool = False

    # Custom headers
    extra_headers: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert Config to dictionary."""
        return {
            "max_retries": self.max_retries,
            "base_delay": self.base_delay,
            "max_delay": self.max_delay,
            "exponential_base": self.exponential_base,
            "jitter": self.jitter,
            "timeout": self.timeout,
            "connect_timeout": self.connect_timeout,
            "failure_threshold": self.failure_threshold,
            "success_threshold": self.success_threshold,
            "recovery_timeout": self.recovery_timeout,
            "enable_flywheel": self.enable_flywheel,
            "flywheel_api_key": self.flywheel_api_key,
            "flywheel_api_url": self.flywheel_api_url,
            "detect_timeout": self.detect_timeout,
            "detect_rate_limit": self.detect_rate_limit,
            "detect_invalid_model": self.detect_invalid_model,
            "detect_empty_body": self.detect_empty_body,
            "detect_server_error": self.detect_server_error,
            "detect_auth_error": self.detect_auth_error,
            "raise_on_retry_exhausted": self.raise_on_retry_exhausted,
            "log_faults": self.log_faults,
            "verbose": self.verbose,
            "extra_headers": self.extra_headers,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Config":
        """Create Config from dictionary."""
        valid_keys = {
            "max_retries", "base_delay", "max_delay", "exponential_base",
            "jitter", "timeout", "connect_timeout", "failure_threshold",
            "success_threshold", "recovery_timeout", "enable_flywheel",
            "flywheel_api_key", "flywheel_api_url", "detect_timeout",
            "detect_rate_limit", "detect_invalid_model", "detect_empty_body",
            "detect_server_error", "detect_auth_error", "raise_on_retry_exhausted",
            "log_faults", "verbose", "extra_headers"
        }
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered_data)

    def update(self, **kwargs: Any) -> None:
        """Update configuration with new values."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    @classmethod
    def default(cls) -> "Config":
        """Get default configuration."""
        return cls()

    @classmethod
    def production(cls) -> "Config":
        """Get production-optimized configuration."""
        return cls(
            max_retries=5,
            base_delay=2.0,
            max_delay=120.0,
            exponential_base=2.0,
            jitter=True,
            timeout=60.0,
            connect_timeout=20.0,
            failure_threshold=10,
            success_threshold=3,
            recovery_timeout=120.0,
            enable_flywheel=True,
            raise_on_retry_exhausted=True,
            log_faults=True,
            verbose=False,
        )

    @classmethod
    def development(cls) -> "Config":
        """Get development-optimized configuration."""
        return cls(
            max_retries=2,
            base_delay=0.5,
            max_delay=10.0,
            exponential_base=2.0,
            jitter=False,
            timeout=10.0,
            connect_timeout=5.0,
            failure_threshold=3,
            success_threshold=1,
            recovery_timeout=30.0,
            enable_flywheel=False,
            raise_on_retry_exhausted=False,
            log_faults=True,
            verbose=True,
        )
