"""
NeuralBridge Web API

FastAPI service for AI API diagnostics.
Provides REST API endpoint for diagnosing API errors.

Usage:
    uvicorn neuralbridge.web:app --reload --port 8000

Author: NeuralBridge™ / 王桂桂
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from .diagnoser import APIDiagnoser, DiagnosedFaultType


# ========== Request/Response Models ==========

class DiagnoseRequest(BaseModel):
    """Request model for diagnosis endpoint."""
    
    api_key: str = Field(..., description="API key for the service")
    base_url: str = Field(..., description="Base URL of the API (e.g., https://api.openai.com/v1)")
    model: str = Field(..., description="Model to test (e.g., gpt-4, gpt-3.5-turbo)")
    timeout: int = Field(default=30, description="Request timeout in seconds", ge=5, le=120)
    include_request: bool = Field(default=False, description="Include test request results")


class ErrorDiagnoseRequest(BaseModel):
    """Request model for error-only diagnosis."""
    
    error_message: Optional[str] = Field(None, description="Error message string")
    status_code: Optional[int] = Field(None, description="HTTP status code")
    response_data: Optional[Dict[str, Any]] = Field(None, description="Response JSON data")
    response_headers: Optional[Dict[str, str]] = Field(None, description="Response headers")


class DiagnosisResponse(BaseModel):
    """Response model for diagnosis."""
    
    fault_type: str
    confidence: float
    severity: str
    root_cause: str
    technical_details: str
    suggestions: List[Dict[str, Any]]
    category: str
    is_healthy: bool
    timestamp: str


class TestRequestResponse(BaseModel):
    """Response model including test request results."""
    
    diagnosis: DiagnosisResponse
    request_success: bool
    status_code: Optional[int]
    response_body: Optional[Dict[str, Any]]
    response_time_ms: Optional[float]
    error: Optional[str]


# ========== FastAPI App ==========

app = FastAPI(
    title="NeuralBridge Diagnostic API",
    description="""
## NeuralBridge™ - Free AI API Diagnostic Tool

Your API is down? I'll tell you why.

This API provides instant diagnosis for AI API errors. Just submit your 
error information and get actionable fix suggestions in seconds.

### Features:
- 🔍 **Instant Diagnosis** - 10+ fault categories, 53+ specific error types
- 💡 **Actionable Fixes** - 3-5 specific suggestions per error
- 🆓 **100% Free** - No registration required
- ⚡ **Fast** - Diagnose in milliseconds

### Powered by:
- V6/V8 diagnostic intelligence
- 9000+ real error samples
- 53 fault types coverage
- 96-100% diagnosis accuracy

*Author: NeuralBridge™ / 王桂桂*
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ========== Diagnostic Engine ==========

diagnoser = APIDiagnoser()


# Try to import requests for making test requests
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


# ========== API Endpoints ==========

@app.get("/", tags=["Info"])
async def root():
    """Root endpoint with API info."""
    return {
        "name": "NeuralBridge Diagnostic API",
        "version": "1.0.0",
        "tagline": "Your API is down? I'll tell you why.",
        "author": "NeuralBridge™ / 王桂桂",
        "docs": "/docs",
        "endpoints": {
            "POST /diagnose": "Test an API and diagnose any issues",
            "POST /diagnose-error": "Diagnose from existing error message",
            "GET /health": "Health check",
        },
    }


@app.get("/health", tags=["Info"])
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "NeuralBridge Diagnostic API",
        "timestamp": datetime.now().isoformat(),
    }


@app.post("/diagnose", response_model=TestRequestResponse, tags=["Diagnosis"])
async def diagnose_api(request: DiagnoseRequest):
    """
    Test an API endpoint and diagnose any issues.
    
    This endpoint makes a test request to the specified API and provides
    a complete diagnosis if anything goes wrong.
    
    **Note**: Your API key is only used for the test request and is not stored.
    """
    if not HAS_REQUESTS:
        raise HTTPException(
            status_code=500,
            detail="requests library not installed. Install with: pip install requests",
        )
    
    # Make test request
    headers = {
        "Authorization": f"Bearer {request.api_key}",
        "Content-Type": "application/json",
    }
    
    # Build endpoint
    endpoint = request.base_url.rstrip("/")
    if not endpoint.endswith("/chat/completions"):
        endpoint += "/chat/completions"
    
    payload = {
        "model": request.model,
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 10,
    }
    
    start_time = datetime.now()
    
    try:
        response = requests.post(
            endpoint,
            headers=headers,
            json=payload,
            timeout=request.timeout,
        )
        
        response_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        
        try:
            response_data = response.json()
        except Exception:
            response_data = {"raw": response.text[:500]}
        
        # Diagnose
        diagnosis = diagnoser.diagnose(
            error_message=None,
            status_code=response.status_code,
            response_data=response_data,
            response_headers=dict(response.headers),
        )
        
        return TestRequestResponse(
            diagnosis=DiagnosisResponse(
                fault_type=diagnosis.fault_type.value,
                confidence=diagnosis.confidence,
                severity=diagnosis.severity,
                root_cause=diagnosis.root_cause,
                technical_details=diagnosis.technical_details,
                suggestions=[s.__dict__ for s in diagnosis.suggestions],
                category=diagnosis.category,
                is_healthy=diagnosis.is_healthy,
                timestamp=datetime.now().isoformat(),
            ),
            request_success=200 <= response.status_code < 300,
            status_code=response.status_code,
            response_body=response_data if request.include_request else None,
            response_time_ms=round(response_time_ms, 2),
            error=None,
        )
        
    except requests.exceptions.Timeout:
        response_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        diagnosis = diagnoser.diagnose(
            error_message="Connection timed out",
            status_code=408,
        )
        
        return TestRequestResponse(
            diagnosis=DiagnosisResponse(
                fault_type=diagnosis.fault_type.value,
                confidence=diagnosis.confidence,
                severity=diagnosis.severity,
                root_cause=diagnosis.root_cause,
                technical_details=diagnosis.technical_details,
                suggestions=[s.__dict__ for s in diagnosis.suggestions],
                category=diagnosis.category,
                is_healthy=diagnosis.is_healthy,
                timestamp=datetime.now().isoformat(),
            ),
            request_success=False,
            status_code=408,
            response_body=None,
            response_time_ms=round(response_time_ms, 2),
            error="Connection timed out",
        )
        
    except requests.exceptions.ConnectionError as e:
        response_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        error_msg = str(e)
        
        if "Name or service not known" in error_msg:
            diagnosis = diagnoser.diagnose(
                error_message=f"DNS failure: Cannot resolve hostname",
                status_code=None,
            )
        elif "Connection refused" in error_msg:
            diagnosis = diagnoser.diagnose(
                error_message="Connection refused",
                status_code=None,
            )
        elif "Connection reset" in error_msg:
            diagnosis = diagnoser.diagnose(
                error_message="Connection was reset by the server",
                status_code=None,
            )
        else:
            diagnosis = diagnoser.diagnose(
                error_message=error_msg[:200],
                status_code=None,
            )
        
        return TestRequestResponse(
            diagnosis=DiagnosisResponse(
                fault_type=diagnosis.fault_type.value,
                confidence=diagnosis.confidence,
                severity=diagnosis.severity,
                root_cause=diagnosis.root_cause,
                technical_details=diagnosis.technical_details,
                suggestions=[s.__dict__ for s in diagnosis.suggestions],
                category=diagnosis.category,
                is_healthy=diagnosis.is_healthy,
                timestamp=datetime.now().isoformat(),
            ),
            request_success=False,
            status_code=None,
            response_body=None,
            response_time_ms=round(response_time_ms, 2),
            error=error_msg[:200],
        )
        
    except requests.exceptions.SSLError as e:
        response_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        diagnosis = diagnoser.diagnose(
            error_message=f"SSL Error: {str(e)[:100]}",
            status_code=None,
        )
        
        return TestRequestResponse(
            diagnosis=DiagnosisResponse(
                fault_type=diagnosis.fault_type.value,
                confidence=diagnosis.confidence,
                severity=diagnosis.severity,
                root_cause=diagnosis.root_cause,
                technical_details=diagnosis.technical_details,
                suggestions=[s.__dict__ for s in diagnosis.suggestions],
                category=diagnosis.category,
                is_healthy=diagnosis.is_healthy,
                timestamp=datetime.now().isoformat(),
            ),
            request_success=False,
            status_code=None,
            response_body=None,
            response_time_ms=round(response_time_ms, 2),
            error=f"SSL Error: {str(e)[:100]}",
        )


@app.post("/diagnose-error", response_model=DiagnosisResponse, tags=["Diagnosis"])
async def diagnose_error(request: ErrorDiagnoseRequest):
    """
    Diagnose from an existing error message.
    
    Submit your error information (message, status code, response data)
    and get instant diagnosis with fix suggestions.
    """
    diagnosis = diagnoser.diagnose(
        error_message=request.error_message,
        status_code=request.status_code,
        response_data=request.response_data,
        response_headers=request.response_headers,
    )
    
    return DiagnosisResponse(
        fault_type=diagnosis.fault_type.value,
        confidence=diagnosis.confidence,
        severity=diagnosis.severity,
        root_cause=diagnosis.root_cause,
        technical_details=diagnosis.technical_details,
        suggestions=[s.__dict__ for s in diagnosis.suggestions],
        category=diagnosis.category,
        is_healthy=diagnosis.is_healthy,
        timestamp=datetime.now().isoformat(),
    )


@app.get("/fault-types", tags=["Info"])
async def list_fault_types():
    """List all supported fault types."""
    return {
        "fault_types": [ft.value for ft in DiagnosedFaultType],
        "count": len(DiagnosedFaultType),
        "categories": [
            {"name": "network", "faults": ["timeout", "dns_failure", "connection_reset", "ssl_error", "network_unreachable", "proxy_error"]},
            {"name": "auth", "faults": ["auth_error", "api_key_expired", "rate_limit", "quota_exhausted", "permission_denied", "ip_not_authorized", "region_not_supported"]},
            {"name": "request", "faults": ["invalid_model", "context_overflow", "invalid_parameter", "empty_body", "request_too_large", "invalid_message_format", "unsupported_parameter"]},
            {"name": "response", "faults": ["empty_response", "response_truncated", "malformed_response", "stream_interrupted", "content_filter", "encoding_error"]},
            {"name": "system", "faults": ["server_error", "service_overloaded", "service_maintenance", "bad_gateway", "model_deprecated"]},
            {"name": "business", "faults": ["account_suspended", "concurrency_limit", "token_refresh_failed", "compliance_blocked"]},
        ],
    }


# ========== Error Handlers ==========

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "timestamp": datetime.now().isoformat(),
        },
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions."""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "timestamp": datetime.now().isoformat(),
        },
    )


# Entry point for running directly
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
