"""
NeuralBridge-Lite Models Module

This module defines all data models used by NeuralBridge.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class FaultType(str, Enum):
    """Enumeration of fault types that can be detected."""

    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    INVALID_MODEL = "invalid_model"
    EMPTY_BODY = "empty_body"
    SERVER_ERROR = "server_error"
    AUTH_ERROR = "auth_error"
    NETWORK_ERROR = "network_error"
    UNKNOWN = "unknown"


class RecoveryStrategyType(str, Enum):
    """Enumeration of recovery strategy types."""

    NONE = "none"
    SIMPLE = "simple"
    CIRCUIT_BREAKER = "circuit_breaker"
    FLYWHEEL = "flywheel"


class CircuitState(str, Enum):
    """Enumeration of circuit breaker states."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class FaultInfo:
    """Information about a detected fault."""

    fault_type: FaultType
    timestamp: datetime
    error_message: str
    http_status: Optional[int] = None
    retry_after: Optional[float] = None
    error_code: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert FaultInfo to dictionary."""
        return {
            "fault_type": self.fault_type.value,
            "timestamp": self.timestamp.isoformat(),
            "error_message": self.error_message,
            "http_status": self.http_status,
            "retry_after": self.retry_after,
            "error_code": self.error_code,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FaultInfo":
        """Create FaultInfo from dictionary."""
        return cls(
            fault_type=FaultType(data.get("fault_type", "unknown")),
            timestamp=datetime.fromisoformat(data.get("timestamp", datetime.now().isoformat())),
            error_message=data.get("error_message", ""),
            http_status=data.get("http_status"),
            retry_after=data.get("retry_after"),
            error_code=data.get("error_code"),
            details=data.get("details", {}),
        )


@dataclass
class RecoveryResult:
    """Result of a recovery attempt."""

    success: bool
    should_retry: bool
    strategy_used: str
    delay: float = 0.0
    attempt: int = 0
    message: str = ""
    recovered_value: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert RecoveryResult to dictionary."""
        return {
            "success": self.success,
            "should_retry": self.should_retry,
            "strategy_used": self.strategy_used,
            "delay": self.delay,
            "attempt": self.attempt,
            "message": self.message,
        }


@dataclass
class RequestInfo:
    """Information about a request."""

    model: str
    messages: List[Dict[str, Any]]
    base_url: str
    timeout: float = 30.0
    headers: Dict[str, str] = field(default_factory=dict)
    request_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert RequestInfo to dictionary."""
        return {
            "model": self.model,
            "messages": self.messages,
            "base_url": self.base_url,
            "timeout": self.timeout,
            "headers": self.headers,
            "request_id": self.request_id,
        }


@dataclass
class ResponseInfo:
    """Information about a response."""

    content: Optional[str] = None
    model: Optional[str] = None
    finish_reason: Optional[str] = None
    usage: Optional[Dict[str, int]] = None
    response_id: Optional[str] = None
    raw_response: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert ResponseInfo to dictionary."""
        return {
            "content": self.content,
            "model": self.model,
            "finish_reason": self.finish_reason,
            "usage": self.usage,
            "response_id": self.response_id,
        }


@dataclass
class FlywheelContext:
    """Context for flywheel recovery strategy."""

    request_id: str
    model: str
    fault_history: List[FaultInfo] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    last_recovery_attempt: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_fault(self, fault: FaultInfo) -> None:
        """Add a fault to history."""
        self.fault_history.append(fault)
        self.failure_count += 1

    def add_success(self) -> None:
        """Record a successful request."""
        self.success_count += 1

    def to_dict(self) -> Dict[str, Any]:
        """Convert FlywheelContext to dictionary."""
        return {
            "request_id": self.request_id,
            "model": self.model,
            "fault_history": [f.to_dict() for f in self.fault_history],
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "last_recovery_attempt": (
                self.last_recovery_attempt.isoformat()
                if self.last_recovery_attempt
                else None
            ),
            "metadata": self.metadata,
        }


@dataclass
class CircuitBreakerState:
    """State of a circuit breaker."""

    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: Optional[datetime] = None
    last_success_time: Optional[datetime] = None
    opened_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert CircuitBreakerState to dictionary."""
        return {
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "last_failure_time": (
                self.last_failure_time.isoformat()
                if self.last_failure_time
                else None
            ),
            "last_success_time": (
                self.last_success_time.isoformat()
                if self.last_success_time
                else None
            ),
            "opened_at": self.opened_at.isoformat() if self.opened_at else None,
        }


@dataclass
class MetricsInfo:
    """Metrics information for monitoring."""

    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    retried_requests: int = 0
    fault_type_counts: Dict[FaultType, int] = field(default_factory=dict)
    average_retry_attempts: float = 0.0
    circuit_breaker_trips: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert MetricsInfo to dictionary."""
        return {
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "retried_requests": self.retried_requests,
            "fault_type_counts": {k.value: v for k, v in self.fault_type_counts.items()},
            "average_retry_attempts": self.average_retry_attempts,
            "circuit_breaker_trips": self.circuit_breaker_trips,
        }

    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.total_requests == 0:
            return 0.0
        return self.successful_requests / self.total_requests
