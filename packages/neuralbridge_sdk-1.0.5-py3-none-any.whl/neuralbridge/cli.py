#!/usr/bin/env python3
"""
NeuralBridge CLI Tool

Free diagnostic tool for AI API errors - The "Trojan Horse" entry point.
"你的API挂了，我告诉你为什么" - 5秒内诊断任何API问题。

Usage:
    neuralbridge diagnose --api-key KEY --base-url URL --model MODEL
    neuralbridge check --api-key KEY --base-url URL

Author: NeuralBridge™ / 王桂桂
"""

import argparse
import json
import sys
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

# Try to import requests, provide helpful message if missing
try:
    import requests
except ImportError:
    print("Error: 'requests' package required. Install with: pip install requests")
    sys.exit(1)

from .diagnoser import APIDiagnoser, DiagnosedFaultType, DiagnosisResult


# ANSI color codes for terminal output
class Colors:
    """ANSI color codes for terminal output."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"
    
    # Background
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"


def colored(text: str, color: str) -> str:
    """Apply color to text if terminal supports it."""
    if sys.stdout.isatty():
        return f"{color}{text}{Colors.RESET}"
    return text


def print_header(text: str) -> None:
    """Print a section header."""
    print(f"\n{colored('─' * 60, Colors.GRAY)}")
    print(colored(f"  {text}", Colors.BOLD + Colors.CYAN))
    print(colored("─" * 60, Colors.GRAY))


def print_success(text: str) -> None:
    """Print success message."""
    print(colored(f"✓ {text}", Colors.GREEN))


def print_error(text: str) -> None:
    """Print error message."""
    print(colored(f"✗ {text}", Colors.RED))


def print_warning(text: str) -> None:
    """Print warning message."""
    print(colored(f"⚠ {text}", Colors.YELLOW))


def print_info(label: str, value: str) -> None:
    """Print labeled info."""
    print(f"  {colored(label + ':', Colors.GRAY)} {value}")


def print_diagnosis(result: DiagnosisResult) -> None:
    """Print diagnosis result in a nice format."""
    
    # Status indicator
    if result.is_healthy:
        print(f"\n{colored('┌' + '─' * 58 + '┐', Colors.GREEN)}")
        print(colored(f"│  {'✓ API HEALTHY':^56} │", Colors.GREEN + Colors.BOLD))
        print(colored('└' + '─' * 58 + '┘', Colors.GREEN))
        print(f"\n  {colored('Your API is working correctly!', Colors.GREEN)}")
        return
    
    # Fault indicator
    severity_colors = {
        "critical": Colors.BG_RED,
        "high": Colors.RED,
        "medium": Colors.YELLOW,
        "low": Colors.GRAY,
    }
    sev_color = severity_colors.get(result.severity, Colors.GRAY)
    
    print(f"\n{colored('┌' + '─' * 58 + '┐', Colors.RED)}")
    fault_display = f"✗ {result.fault_type.value.upper().replace('_', ' ')}"
    print(colored(f"│  {fault_display:^56} │", Colors.RED + Colors.BOLD))
    print(colored('└' + '─' * 58 + '┘', Colors.RED))
    
    # Severity badge
    sev_text = f"SEVERITY: {result.severity.upper()}"
    conf_text = f"CONFIDENCE: {result.confidence * 100:.0f}%"
    print(f"\n  {colored(sev_text, sev_color)}  |  {colored(conf_text, Colors.CYAN)}")
    
    # Root cause
    print_header("ROOT CAUSE")
    print(f"  {result.root_cause}")
    
    # Technical details
    print_header("TECHNICAL DETAILS")
    print(f"  {result.technical_details}")
    
    # Category
    print_header("CATEGORY")
    print(f"  {colored(result.category.upper(), Colors.MAGENTA)}")
    
    # Fix suggestions
    if result.suggestions:
        print_header("FIX SUGGESTIONS")
        for i, suggestion in enumerate(result.suggestions[:5], 1):
            print(f"\n  {colored(f'{i}. {suggestion.action}', Colors.GREEN + Colors.BOLD)}")
            print(f"     {colored('Command:', Colors.GRAY)} {colored(suggestion.command, Colors.CYAN)}")
            print(f"     {colored('Why:', Colors.GRAY)} {suggestion.explanation}")


def make_test_request(
    api_key: str,
    base_url: str,
    model: str,
    timeout: int = 30,
) -> Dict[str, Any]:
    """
    Make a test request to the API.
    
    Returns:
        Dict with 'success', 'response', 'error', 'status_code'
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    
    # Build endpoint
    endpoint = base_url.rstrip("/")
    if not endpoint.endswith("/chat/completions"):
        endpoint += "/chat/completions"
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 10,
    }
    
    try:
        response = requests.post(
            endpoint,
            headers=headers,
            json=payload,
            timeout=timeout,
        )
        
        try:
            data = response.json()
        except json.JSONDecodeError:
            data = {"raw": response.text[:500]}
        
        return {
            "success": 200 <= response.status_code < 300,
            "response": data,
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "error": None,
        }
        
    except requests.exceptions.Timeout:
        return {
            "success": False,
            "response": None,
            "status_code": None,
            "headers": {},
            "error": "Connection timed out. The server took too long to respond.",
        }
    except requests.exceptions.ConnectionError as e:
        error_str = str(e)
        if "Name or service not known" in error_str:
            return {
                "success": False,
                "response": None,
                "status_code": None,
                "headers": {},
                "error": f"DNS failure: Cannot resolve hostname. Check your base_url.",
            }
        elif "Connection refused" in error_str:
            return {
                "success": False,
                "response": None,
                "status_code": None,
                "headers": {},
                "error": "Connection refused. The server is not accepting connections.",
            }
        elif "Connection reset" in error_str:
            return {
                "success": False,
                "response": None,
                "status_code": None,
                "headers": {},
                "error": "Connection was reset by the server.",
            }
        else:
            return {
                "success": False,
                "response": None,
                "status_code": None,
                "headers": {},
                "error": f"Connection error: {error_str[:200]}",
            }
    except requests.exceptions.SSLError as e:
        return {
            "success": False,
            "response": None,
            "status_code": None,
            "headers": {},
            "error": f"SSL Error: Certificate verification failed. {str(e)[:100]}",
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "response": None,
            "status_code": None,
            "headers": {},
            "error": f"Request failed: {str(e)[:200]}",
        }


def diagnose_command(args: argparse.Namespace) -> int:
    """Run the diagnose command."""
    print(colored("\n🔍 NeuralBridge Diagnostic Tool", Colors.BOLD + Colors.CYAN))
    print(colored("   Your API is down? I'll tell you why.", Colors.GRAY))
    print(f"\n  {colored('Testing:', Colors.GRAY)} {args.base_url}")
    print(f"  {colored('Model:', Colors.GRAY)} {args.model}")
    print(f"  {colored('Timeout:', Colors.GRAY)} {args.timeout}s")
    
    # Make test request
    print(f"\n{colored('▶ Sending test request...', Colors.YELLOW)}")
    start_time = time.time()
    
    result = make_test_request(
        api_key=args.api_key,
        base_url=args.base_url,
        model=args.model,
        timeout=args.timeout,
    )
    
    elapsed = time.time() - start_time
    print(f"  {colored(f'Response time: {elapsed:.2f}s', Colors.GRAY)}")
    
    # Diagnose
    print(f"\n{colored('▶ Running diagnosis...', Colors.YELLOW)}")
    diagnoser = APIDiagnoser()
    
    if result["success"]:
        diagnosis = diagnoser.diagnose(
            error_message=None,
            status_code=result["status_code"],
            response_data=result["response"],
            response_headers=result["headers"],
        )
    elif result["error"]:
        diagnosis = diagnoser.diagnose(
            error_message=result["error"],
            status_code=result["status_code"],
            response_data=result["response"],
            response_headers=result["headers"],
        )
    else:
        diagnosis = diagnoser.diagnose(
            error_message=None,
            status_code=result["status_code"],
            response_data=result["response"],
            response_headers=result["headers"],
        )
    
    # Print results
    print_diagnosis(diagnosis)
    
    # Attribution
    print(f"\n{colored('─' * 60, Colors.GRAY)}")
    print(colored("  NeuralBridge™ - AI API Fault Recovery Engine", Colors.GRAY))
    print(colored("  Diagnoser v1.0 | Powered by V6/V8 Error Intelligence", Colors.GRAY))
    
    # Return appropriate exit code
    return 0 if diagnosis.is_healthy else 1


def check_command(args: argparse.Namespace) -> int:
    """Run the check command - quick API health check."""
    print(colored("\n🏥 NeuralBridge API Health Check", Colors.BOLD + Colors.CYAN))
    
    result = make_test_request(
        api_key=args.api_key,
        base_url=args.base_url,
        model=args.model or "gpt-3.5-turbo",
        timeout=args.timeout or 30,
    )
    
    if result["success"]:
        print_success("API is responding correctly")
        print_info("Status Code", str(result["status_code"]))
        if result["response"]:
            model = result["response"].get("model", "unknown")
            print_info("Model", model)
        return 0
    else:
        print_error("API is not responding")
        if result["error"]:
            print_info("Error", result["error"])
        if result["status_code"]:
            print_info("Status Code", str(result["status_code"]))
        return 1


def diagnose_from_error(args: argparse.Namespace) -> int:
    """Diagnose from an existing error message."""
    print(colored("\n🔍 NeuralBridge Error Diagnoser", Colors.BOLD + Colors.CYAN))
    
    if args.error_file:
        with open(args.error_file, 'r') as f:
            error_message = f.read()
    else:
        error_message = args.error_message
    
    print_info("Error Message", error_message[:200] + "..." if len(error_message) > 200 else error_message)
    if args.status_code:
        print_info("Status Code", str(args.status_code))
    
    diagnoser = APIDiagnoser()
    diagnosis = diagnoser.diagnose(
        error_message=error_message,
        status_code=args.status_code,
    )
    
    print_diagnosis(diagnosis)
    return 0 if diagnosis.is_healthy else 1


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="NeuralBridge - Free AI API Diagnostic Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Diagnose an API endpoint
  neuralbridge diagnose --api-key sk-xxx --base-url https://api.openai.com/v1 --model gpt-4
  
  # Quick health check
  neuralbridge check --api-key sk-xxx --base-url https://api.deepseek.com/v1
  
  # Diagnose from existing error
  neuralbridge diagnose-error "Rate limit exceeded" --status-code 429

Powered by NeuralBridge™ - AI API Fault Recovery Engine
        """,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # diagnose command
    diagnose_parser = subparsers.add_parser(
        "diagnose",
        help="Diagnose an API endpoint",
        description="Test an API and diagnose any issues",
    )
    diagnose_parser.add_argument(
        "--api-key", "-k",
        required=True,
        help="API key for authentication",
    )
    diagnose_parser.add_argument(
        "--base-url", "-b",
        required=True,
        help="Base URL of the API (e.g., https://api.openai.com/v1)",
    )
    diagnose_parser.add_argument(
        "--model", "-m",
        required=True,
        help="Model to test (e.g., gpt-4, gpt-3.5-turbo)",
    )
    diagnose_parser.add_argument(
        "--timeout", "-t",
        type=int,
        default=30,
        help="Request timeout in seconds (default: 30)",
    )
    diagnose_parser.set_defaults(func=diagnose_command)
    
    # check command
    check_parser = subparsers.add_parser(
        "check",
        help="Quick API health check",
        description="Quickly check if an API is responding",
    )
    check_parser.add_argument(
        "--api-key", "-k",
        required=True,
        help="API key for authentication",
    )
    check_parser.add_argument(
        "--base-url", "-b",
        required=True,
        help="Base URL of the API",
    )
    check_parser.add_argument(
        "--model", "-m",
        help="Model to test (default: gpt-3.5-turbo)",
    )
    check_parser.add_argument(
        "--timeout", "-t",
        type=int,
        default=30,
        help="Request timeout in seconds (default: 30)",
    )
    check_parser.set_defaults(func=check_command)
    
    # diagnose-error command
    error_parser = subparsers.add_parser(
        "diagnose-error",
        help="Diagnose from error message",
        description="Analyze an existing error without making a request",
    )
    error_parser.add_argument(
        "error_message",
        nargs="?",
        help="Error message to analyze",
    )
    error_parser.add_argument(
        "--error-file", "-f",
        help="Read error from file",
    )
    error_parser.add_argument(
        "--status-code", "-s",
        type=int,
        help="HTTP status code",
    )
    error_parser.set_defaults(func=diagnose_from_error)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
