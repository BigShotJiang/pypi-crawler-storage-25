"""
NeuralBridge-Lite Flywheel Recovery Strategy Module

This module provides the Flywheel Recovery Strategy interface.

IMPORTANT DESIGN NOTE:
=====================
This is the INTERFACE LAYER ONLY for the NeuralBridge Flywheel Recovery system.
The core flywheel learning engine is NOT open source.

How it works:
1. The interface (this file) is fully open source
2. When enabled, it attempts to call NeuralBridge Cloud API for advanced recovery
3. If Cloud API is unavailable, it gracefully falls back to enhanced retry strategy
4. The actual flywheel learning/prediction logic runs on NeuralBridge Cloud

This design follows the same philosophy as OpenAI:
- Open source: API format, interfaces, SDK
- Closed source: Model weights, training, advanced features

For the Flywheel Recovery, we apply the same principle:
- Open source: Recovery interfaces, fault detection, basic strategies
- Closed source: Flywheel learning, prediction, strategy optimization

For more information about NeuralBridge Cloud and enterprise features:
Website: https://neuralbridge-ai.surge.sh
Contact: wgg234114134@163.com
"""

import asyncio
from datetime import datetime
from typing import Any, Callable, Dict, Optional

from ..config import Config
from ..detector import FaultDetector
from ..exceptions import FlywheelError
from ..models import FaultInfo, FaultType, FlywheelContext, RecoveryResult
from .base import RecoveryStrategy
from .simple import SimpleRetryStrategy


class FlywheelRecoveryStrategy(RecoveryStrategy):
    """
    Flywheel Recovery Strategy - Interface Layer.

    This class provides the open-source interface for NeuralBridge's flywheel
    recovery system. The actual flywheel learning engine runs on NeuralBridge Cloud.

    Features:
    - Interface-compatible with other recovery strategies
    - Automatic fallback to enhanced retry when cloud unavailable
    - Extensible architecture for future enhancements
    - Full async support

    The flywheel recovery system works in three phases:
    1. DETECT: Identify fault patterns
    2. LEARN: (Cloud) Analyze patterns and optimize recovery
    3. RECOVER: Apply learned strategies for faster recovery

    Example:
        >>> strategy = FlywheelRecoveryStrategy(
        ...     flywheel_api_key="your-key",
        ...     enable_cloud=True
        ... )
        >>> result = await strategy.recover(fault, attempt=1)
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        flywheel_api_key: Optional[str] = None,
        flywheel_api_url: Optional[str] = None,
        enable_cloud: bool = True,
        fallback_to_enhanced: bool = True,
    ) -> None:
        """
        Initialize FlywheelRecoveryStrategy.

        Args:
            config: Optional configuration object.
            flywheel_api_key: NeuralBridge Cloud API key.
            flywheel_api_url: NeuralBridge Cloud API URL.
            enable_cloud: Whether to attempt cloud API calls.
            fallback_to_enhanced: Fall back to enhanced retry if cloud fails.
        """
        super().__init__(config)

        self.flywheel_api_key = flywheel_api_key or self.config.flywheel_api_key
        self.flywheel_api_url = flywheel_api_url or self.config.flywheel_api_url
        self.enable_cloud = enable_cloud and self.config.enable_flywheel
        self.fallback_to_enhanced = fallback_to_enhanced

        # Flywheel context for tracking request history
        self._context_stack: Dict[str, FlywheelContext] = {}
        self._current_context: Optional[FlywheelContext] = None

        # Fallback strategy
        self._fallback_strategy = SimpleRetryStrategy(config)

        self._detector = FaultDetector()

    async def recover(
        self,
        fault: FaultInfo,
        attempt: int,
        request_func: Optional[Callable] = None,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Attempt recovery using flywheel strategy.

        This method implements the flywheel recovery interface:
        1. If cloud is enabled, try NeuralBridge Cloud API
        2. If cloud fails or is disabled, use enhanced local fallback

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.
            request_func: Optional function to retry.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult indicating success and next steps.
        """
        # Update context with new fault
        self._update_context(fault)

        # Try cloud API first if enabled
        if self.enable_cloud:
            try:
                result = await self._try_cloud_recovery(fault, attempt)
                if result is not None:
                    return result
            except Exception as e:
                if self.config.verbose:
                    print(f"[NeuralBridge] Cloud recovery failed: {e}, falling back to local")

        # Fall back to enhanced retry strategy
        if self.fallback_to_enhanced:
            return await self._fallback_recover(fault, attempt, request_func, *args, **kwargs)

        # No fallback, signal to stop retrying
        return RecoveryResult(
            success=False,
            should_retry=False,
            strategy_used="FlywheelRecovery",
            attempt=attempt,
            message="Flywheel recovery unavailable and fallback disabled",
        )

    async def _try_cloud_recovery(
        self,
        fault: FaultInfo,
        attempt: int,
    ) -> Optional[RecoveryResult]:
        """
        Attempt recovery via NeuralBridge Cloud API.

        This method calls the NeuralBridge Cloud API for advanced flywheel recovery.
        The actual flywheel learning happens on the cloud - this is just the interface.

        NOTE: This is a placeholder implementation. In production, this would
        make actual HTTP calls to NeuralBridge Cloud.

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.

        Returns:
            RecoveryResult if cloud call succeeds, None otherwise.
        """
        if not self.flywheel_api_key:
            return None

        # Cloud recovery would be implemented here
        # Example (pseudo-code):
        #
        # async with aiohttp.ClientSession() as session:
        #     async with session.post(
        #         f"{self.flywheel_api_url}/recover",
        #         json={
        #             "fault": fault.to_dict(),
        #             "context": self._current_context.to_dict() if self._current_context else {},
        #             "attempt": attempt,
        #         },
        #         headers={"Authorization": f"Bearer {self.flywheel_api_key}"}
        #     ) as response:
        #         data = await response.json()
        #         return RecoveryResult(
        #             success=data["success"],
        #             should_retry=data["should_retry"],
        #             strategy_used="FlywheelCloud",
        #             delay=data.get("delay", 0),
        #             attempt=attempt,
        #         )

        # For now, return None to trigger fallback
        # In production, this would make actual API calls
        return None

    async def _fallback_recover(
        self,
        fault: FaultInfo,
        attempt: int,
        request_func: Optional[Callable] = None,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Enhanced fallback recovery using learned patterns.

        This is an improved version of simple retry that incorporates
        flywheel-learned patterns (when available from cloud context).

        Features:
        - Adaptive delay based on fault type history
        - Context-aware retry logic
        - Prevents patterns known to fail

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.
            request_func: Optional function to retry.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult with enhanced recovery info.
        """
        # Calculate delay with flywheel-enhanced logic
        delay = self._calculate_flywheel_delay(fault, attempt)

        if self.config.verbose:
            print(
                f"[NeuralBridge] Flywheel fallback recovery "
                f"(attempt {attempt}): {fault.fault_type.value}, "
                f"delay={delay:.2f}s"
            )

        # Wait before retry
        await asyncio.sleep(delay)

        # Execute request if function provided
        recovered_value = None
        if request_func:
            try:
                recovered_value = await request_func(*args, **kwargs)
                return RecoveryResult(
                    success=True,
                    should_retry=False,
                    strategy_used="FlywheelFallback",
                    delay=delay,
                    attempt=attempt,
                    recovered_value=recovered_value,
                )
            except Exception:
                # Will continue to next retry
                pass

        # Determine if we should continue retrying
        should_retry = self._should_flywheel_retry(fault, attempt)

        return RecoveryResult(
            success=False,
            should_retry=should_retry,
            strategy_used="FlywheelFallback",
            delay=delay,
            attempt=attempt,
            message=f"Flywheel retry {attempt}" if should_retry else "Flywheel retries exhausted",
        )

    def _calculate_flywheel_delay(self, fault: FaultInfo, attempt: int) -> float:
        """
        Calculate delay with flywheel-enhanced logic.

        Uses context-aware delay calculation that considers:
        - Base delay from config
        - Fault-specific delays
        - Historical patterns (from cloud context)
        - Adaptive adjustment based on failure count

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.

        Returns:
            Calculated delay in seconds.
        """
        base_delay = self.config.base_delay
        max_delay = self.config.max_delay

        # Get fault-specific delay
        fault_delay = self._detector.get_retry_delay(fault, base_delay)

        # Apply exponential backoff
        exponential_delay = base_delay * (self.config.exponential_base ** (attempt - 1))

        # Use the greater of fault delay or exponential
        delay = max(fault_delay, exponential_delay)

        # Apply flywheel context adjustments if available
        if self._current_context and self._current_context.failure_count > 0:
            # Increase delay if we've had multiple failures
            failure_multiplier = 1 + (self._current_context.failure_count * 0.1)
            delay *= failure_multiplier

        # Cap at max_delay
        delay = min(delay, max_delay)

        # Add jitter
        if self.config.jitter:
            import random
            delay += delay * random.uniform(0, 0.2)

        return delay

    def _should_flywheel_retry(self, fault: FaultInfo, attempt: int) -> bool:
        """
        Determine if flywheel retry should be attempted.

        Considers:
        - Attempt count vs max retries
        - Fault retryability
        - Context history

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.

        Returns:
            True if retry should be attempted.
        """
        # Check attempt limit
        if attempt >= self.config.max_retries:
            return False

        # Check if fault is retryable
        return self._detector.should_retry(fault)

    def _update_context(self, fault: FaultInfo) -> None:
        """
        Update flywheel context with new fault.

        Maintains a history of faults for pattern analysis.

        Args:
            fault: The fault to record.
        """
        # Get or create current context
        request_id = f"req_{datetime.now().timestamp()}"

        if self._current_context is None:
            self._current_context = FlywheelContext(
                request_id=request_id,
                model=fault.details.get("model", "unknown"),
            )

        # Add fault to history
        self._current_context.add_fault(fault)
        self._current_context.last_recovery_attempt = datetime.now()

        # Store in stack for later analysis
        self._context_stack[request_id] = self._current_context

        # Keep only recent contexts (limit to 100)
        if len(self._context_stack) > 100:
            oldest_key = next(iter(self._context_stack))
            del self._context_stack[oldest_key]

    def record_success(self, request_id: Optional[str] = None) -> None:
        """
        Record a successful request in flywheel context.

        Call this after a successful API call.

        Args:
            request_id: Optional specific request ID to record.
        """
        if self._current_context:
            self._current_context.add_success()

    def get_flywheel_context(self) -> Optional[Dict[str, Any]]:
        """
        Get current flywheel context for debugging/analysis.

        Returns:
            Dictionary with flywheel context information.
        """
        if not self._current_context:
            return None

        return self._current_context.to_dict()

    def analyze_patterns(self) -> Dict[str, Any]:
        """
        Analyze fault patterns from flywheel context.

        Returns:
            Dictionary with pattern analysis results.
        """
        if not self._current_context:
            return {"pattern": "none", "message": "No context available"}

        # Use detector to analyze fault history
        return self._detector.analyze_fault_pattern(self._current_context.fault_history)

    def reset(self) -> None:
        """Reset flywheel context."""
        self._context_stack.clear()
        self._current_context = None

    def export_context(self) -> Dict[str, Any]:
        """
        Export flywheel context for debugging or analysis.

        Returns:
            Dictionary with all context data.
        """
        return {
            "current_context": self._current_context.to_dict() if self._current_context else None,
            "context_stack_size": len(self._context_stack),
            "patterns": self.analyze_patterns(),
        }

    @property
    def name(self) -> str:
        """Get the name of the recovery strategy."""
        return "FlywheelRecovery"

    @property
    def is_cloud_enabled(self) -> bool:
        """Check if cloud recovery is enabled."""
        return self.enable_cloud and bool(self.flywheel_api_key)


# =============================================================================
# NeuralBridge Cloud Integration Note
# =============================================================================
#
# The flywheel recovery system consists of:
#
# OPEN SOURCE (this package):
# - Fault detection and classification
# - Recovery strategy interfaces
# - Basic retry and circuit breaker implementations
# - Flywheel context management
# - Cloud API interface layer
#
# CLOSED SOURCE (NeuralBridge Cloud):
# - Flywheel learning algorithms
# - Pattern recognition and prediction
# - Dynamic strategy optimization
# - Cross-fault correlation analysis
# - Recovery success prediction
#
# To learn more about NeuralBridge Cloud and enterprise features:
# Website: https://neuralbridge-ai.surge.sh
# Contact: wgg234114134@163.com
#
# =============================================================================
