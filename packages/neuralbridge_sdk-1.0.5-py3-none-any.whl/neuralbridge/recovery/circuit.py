"""
NeuralBridge-Lite Circuit Breaker Strategy Module

This module provides the circuit breaker pattern for fault recovery.
This is a fully open-source implementation.

The circuit breaker pattern prevents cascading failures by stopping
requests when a service is experiencing issues.
"""

import asyncio
import time
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional

from ..config import Config
from ..detector import FaultDetector
from ..exceptions import CircuitBreakerOpenError
from ..models import CircuitBreakerState, CircuitState, FaultInfo, RecoveryResult
from .base import RecoveryStrategy


class CircuitBreakerStrategy(RecoveryStrategy):
    """
    Circuit breaker pattern implementation.

    The circuit breaker monitors failures and "opens" when a threshold
    is reached, immediately failing requests without attempting the API.
    This prevents cascading failures and allows the service time to recover.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Circuit is tripped, requests fail immediately
    - HALF_OPEN: Testing if service has recovered

    Example:
        >>> breaker = CircuitBreakerStrategy(failure_threshold=5, recovery_timeout=60)
        >>> result = await breaker.recover(fault, attempt=1)
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        failure_threshold: Optional[int] = None,
        success_threshold: Optional[int] = None,
        recovery_timeout: Optional[float] = None,
        half_open_max_calls: int = 3,
    ) -> None:
        """
        Initialize CircuitBreakerStrategy.

        Args:
            config: Optional configuration object.
            failure_threshold: Number of failures before opening circuit.
            success_threshold: Number of successes in half-open before closing.
            recovery_timeout: Seconds to wait before attempting recovery.
            half_open_max_calls: Max calls allowed in half-open state.
        """
        super().__init__(config)

        self.failure_threshold = failure_threshold or self.config.failure_threshold
        self.success_threshold = success_threshold or self.config.success_threshold
        self.recovery_timeout = recovery_timeout or self.config.recovery_timeout
        self.half_open_max_calls = half_open_max_calls

        # Internal state
        self._state = CircuitBreakerState(state=CircuitState.CLOSED)
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: Optional[datetime] = None
        self._last_success_time: Optional[datetime] = None
        self._opened_at: Optional[datetime] = None
        self._half_open_calls = 0

        self._detector = FaultDetector()
        self._lock = asyncio.Lock()

    async def recover(
        self,
        fault: FaultInfo,
        attempt: int,
        request_func: Optional[Callable] = None,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Handle recovery with circuit breaker logic.

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.
            request_func: Optional function to retry.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult indicating success and next steps.
        """
        async with self._lock:
            # Check if we should transition from OPEN to HALF_OPEN
            if self._state.state == CircuitState.OPEN:
                if self._should_attempt_recovery():
                    self._transition_to_half_open()
                else:
                    raise CircuitBreakerOpenError(
                        message="Circuit breaker is open",
                        failure_count=self._failure_count,
                        recovery_timeout=self.recovery_timeout,
                    )

            # Record the failure
            self._record_failure()

            # Check if we should open the circuit
            if self._failure_count >= self.failure_threshold:
                self._open_circuit()
                return RecoveryResult(
                    success=False,
                    should_retry=False,
                    strategy_used="CircuitBreaker",
                    attempt=attempt,
                    message=f"Circuit opened after {self._failure_count} failures",
                )

            # In HALF_OPEN state, check if we've exceeded call limit
            if self._state.state == CircuitState.HALF_OPEN:
                if self._half_open_calls >= self.half_open_max_calls:
                    return RecoveryResult(
                        success=False,
                        should_retry=False,
                        strategy_used="CircuitBreaker",
                        attempt=attempt,
                        message="Half-open call limit reached",
                    )
                self._half_open_calls += 1

            # Calculate delay for retry
            delay = self._detector.get_retry_delay(fault, self.config.base_delay)

            return RecoveryResult(
                success=False,
                should_retry=True,
                strategy_used="CircuitBreaker",
                delay=delay,
                attempt=attempt,
                message=f"Attempt {attempt}, circuit state: {self._state.state.value}",
            )

    def _should_attempt_recovery(self) -> bool:
        """Check if enough time has passed to attempt recovery."""
        if self._opened_at is None:
            return True

        elapsed = (datetime.now() - self._opened_at).total_seconds()
        return elapsed >= self.recovery_timeout

    def _transition_to_half_open(self) -> None:
        """Transition circuit to half-open state."""
        self._state.state = CircuitState.HALF_OPEN
        self._half_open_calls = 0
        self._success_count = 0

        if self.config.verbose:
            print("[NeuralBridge] Circuit breaker: CLOSED -> HALF_OPEN")

    def _open_circuit(self) -> None:
        """Open the circuit breaker."""
        self._state.state = CircuitState.OPEN
        self._opened_at = datetime.now()

        if self.config.verbose:
            print(
                f"[NeuralBridge] Circuit breaker: OPEN "
                f"(threshold: {self.failure_threshold})"
            )

    def _record_failure(self) -> None:
        """Record a failure."""
        self._failure_count += 1
        self._last_failure_time = datetime.now()

    def record_success(self) -> None:
        """
        Record a successful request.

        Call this after a successful API call to update circuit state.
        """
        self._last_success_time = datetime.now()

        if self._state.state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.success_threshold:
                self._close_circuit()
        elif self._state.state == CircuitState.CLOSED:
            # Reset failure count on success
            self._failure_count = max(0, self._failure_count - 1)

    def _close_circuit(self) -> None:
        """Close the circuit breaker."""
        self._state.state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._opened_at = None
        self._half_open_calls = 0

        if self.config.verbose:
            print("[NeuralBridge] Circuit breaker: HALF_OPEN -> CLOSED")

    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        return self._state.state

    @property
    def failure_count(self) -> int:
        """Get current failure count."""
        return self._failure_count

    def get_state_info(self) -> Dict[str, Any]:
        """
        Get detailed state information.

        Returns:
            Dictionary with current circuit breaker state.
        """
        return {
            "state": self._state.state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "failure_threshold": self.failure_threshold,
            "success_threshold": self.success_threshold,
            "recovery_timeout": self.recovery_timeout,
            "opened_at": self._opened_at.isoformat() if self._opened_at else None,
            "last_failure_time": (
                self._last_failure_time.isoformat() if self._last_failure_time else None
            ),
            "last_success_time": (
                self._last_success_time.isoformat() if self._last_success_time else None
            ),
        }

    def reset(self) -> None:
        """Reset circuit breaker to initial closed state."""
        self._state = CircuitBreakerState(state=CircuitState.CLOSED)
        self._failure_count = 0
        self._success_count = 0
        self._opened_at = None
        self._half_open_calls = 0

    def is_call_allowed(self) -> bool:
        """
        Check if a call is allowed through the circuit.

        Returns:
            True if call is allowed, False otherwise.
        """
        if self._state.state == CircuitState.CLOSED:
            return True

        if self._state.state == CircuitState.OPEN:
            return self._should_attempt_recovery()

        if self._state.state == CircuitState.HALF_OPEN:
            return self._half_open_calls < self.half_open_max_calls

        return False

    async def __aenter__(self) -> "CircuitBreakerStrategy":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        if exc_type is not None:
            self._record_failure()
        else:
            self.record_success()
