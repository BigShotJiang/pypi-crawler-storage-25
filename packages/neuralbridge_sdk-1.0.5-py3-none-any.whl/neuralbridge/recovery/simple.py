"""
NeuralBridge-Lite Simple Retry Strategy Module

This module provides a simple exponential backoff retry strategy.
This is a fully open-source implementation.
"""

import asyncio
import random
from typing import Any, Callable, Optional

from ..config import Config
from ..detector import FaultDetector
from ..models import FaultInfo, RecoveryResult
from .base import RecoveryStrategy


class SimpleRetryStrategy(RecoveryStrategy):
    """
    Simple retry strategy with exponential backoff.

    This strategy implements basic retry logic with configurable exponential
    backoff. It is suitable for most common fault scenarios.

    Features:
    - Exponential backoff with configurable base
    - Optional jitter to prevent thundering herd
    - Configurable max retries and delays
    - Works with any callable

    Example:
        >>> strategy = SimpleRetryStrategy(max_retries=3, base_delay=1.0)
        >>> result = await strategy.recover(fault, attempt=1)
        >>> print(result.delay)  # Delay in seconds
        2.0
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        max_retries: Optional[int] = None,
        base_delay: Optional[float] = None,
        max_delay: Optional[float] = None,
        exponential_base: Optional[float] = None,
        jitter: Optional[bool] = None,
    ) -> None:
        """
        Initialize SimpleRetryStrategy.

        Args:
            config: Optional configuration object.
            max_retries: Maximum number of retry attempts.
            base_delay: Base delay in seconds.
            max_delay: Maximum delay in seconds.
            exponential_base: Base for exponential calculation.
            jitter: Whether to add random jitter to delays.
        """
        super().__init__(config)

        self.max_retries = max_retries or self.config.max_retries
        self.base_delay = base_delay or self.config.base_delay
        self.max_delay = max_delay or self.config.max_delay
        self.exponential_base = exponential_base or self.config.exponential_base
        self.jitter = jitter if jitter is not None else self.config.jitter

        self._retry_count = 0
        self._detector = FaultDetector()

    async def recover(
        self,
        fault: FaultInfo,
        attempt: int,
        request_func: Optional[Callable] = None,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Execute retry with exponential backoff.

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number (1-indexed).
            request_func: Optional function to retry the request.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult indicating success and next steps.
        """
        self._retry_count += 1

        # Calculate delay with exponential backoff
        delay = self._calculate_delay(fault, attempt)

        # Log the retry attempt
        if self.config.verbose:
            print(
                f"[NeuralBridge] Retry {attempt}/{self.max_retries} "
                f"for {fault.fault_type.value} after {delay:.2f}s"
            )

        # Wait before retry
        await asyncio.sleep(delay)

        # Check if we should retry
        should_retry = self._should_retry(fault, attempt)

        if not should_retry:
            return RecoveryResult(
                success=False,
                should_retry=False,
                strategy_used="SimpleRetry",
                delay=delay,
                attempt=attempt,
                message=f"Max retries ({self.max_retries}) exhausted for {fault.fault_type.value}",
            )

        # If request_func provided, execute it
        recovered_value = None
        if request_func:
            try:
                recovered_value = await request_func(*args, **kwargs)
                return RecoveryResult(
                    success=True,
                    should_retry=False,
                    strategy_used="SimpleRetry",
                    delay=delay,
                    attempt=attempt,
                    recovered_value=recovered_value,
                )
            except Exception as e:
                # Will continue to next retry or give up
                pass

        return RecoveryResult(
            success=attempt < self.max_retries,
            should_retry=should_retry and attempt < self.max_retries,
            strategy_used="SimpleRetry",
            delay=delay,
            attempt=attempt,
            message=f"Scheduled retry {attempt + 1}" if should_retry else "Retries exhausted",
        )

    def _calculate_delay(self, fault: FaultInfo, attempt: int) -> float:
        """
        Calculate delay for current attempt.

        Uses exponential backoff formula: base_delay * (exponential_base ^ attempt)

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.

        Returns:
            Delay in seconds.
        """
        # Check for retry_after from rate limit response
        if fault.retry_after and fault.retry_after > 0:
            return min(fault.retry_after, self.max_delay)

        # Use fault-specific delay if available
        fault_delay = self._detector.get_retry_delay(fault, self.base_delay)
        if fault_delay > 0:
            base = fault_delay
        else:
            # Exponential backoff
            base = self.base_delay * (self.exponential_base ** (attempt - 1))

        # Cap at max_delay
        delay = min(base, self.max_delay)

        # Add jitter to prevent thundering herd
        if self.jitter:
            # Add random jitter of 0-25% of delay
            jitter_amount = delay * random.uniform(0, 0.25)
            delay += jitter_amount

        return delay

    def _should_retry(self, fault: FaultInfo, attempt: int) -> bool:
        """
        Determine if retry should be attempted.

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number.

        Returns:
            True if retry should be attempted.
        """
        # Check if we have retries left
        if attempt >= self.max_retries:
            return False

        # Check if fault is retryable
        return self._detector.should_retry(fault)

    def reset(self) -> None:
        """Reset retry counter."""
        self._retry_count = 0

    @property
    def retry_count(self) -> int:
        """Get current retry count."""
        return self._retry_count
