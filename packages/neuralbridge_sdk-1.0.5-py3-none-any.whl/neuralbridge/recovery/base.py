"""
NeuralBridge-Lite Recovery Base Module

This module defines the base class for all recovery strategies.
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Optional

from ..config import Config
from ..exceptions import RetryExhaustedError
from ..models import FaultInfo, RecoveryResult


class RecoveryStrategy(ABC):
    """
    Abstract base class for all recovery strategies.

    This class defines the interface that all recovery strategies must implement.
    Recovery strategies handle the actual recovery logic when faults are detected.

    Example:
        >>> class MyStrategy(RecoveryStrategy):
        ...     async def recover(self, fault, attempt):
        ...         return RecoveryResult(success=True, should_retry=False, strategy_used="my")
    """

    def __init__(self, config: Optional[Config] = None) -> None:
        """
        Initialize RecoveryStrategy.

        Args:
            config: Optional configuration object.
        """
        self.config = config or Config()

    @abstractmethod
    async def recover(
        self,
        fault: FaultInfo,
        attempt: int,
        request_func: Optional[Callable] = None,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Attempt to recover from a fault.

        This method must be implemented by all concrete strategies.

        Args:
            fault: Information about the detected fault.
            attempt: Current attempt number (1-indexed).
            request_func: Optional function to retry the request.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult indicating success and next steps.
        """
        pass

    async def execute_with_recovery(
        self,
        request_func: Callable,
        *args: Any,
        **kwargs: Any,
    ) -> RecoveryResult:
        """
        Execute a request function with automatic recovery.

        This is a helper method that wraps a request function with
        the recovery strategy.

        Args:
            request_func: The request function to execute.
            *args: Positional arguments for request_func.
            **kwargs: Keyword arguments for request_func.

        Returns:
            RecoveryResult with the final result.
        """
        attempt = 0
        max_attempts = self.config.max_retries + 1

        while attempt < max_attempts:
            attempt += 1
            try:
                result = await request_func(*args, **kwargs)
                return RecoveryResult(
                    success=True,
                    should_retry=False,
                    strategy_used=self.__class__.__name__,
                    attempt=attempt,
                    recovered_value=result,
                )
            except Exception as e:
                from ..detector import FaultDetector

                detector = FaultDetector()
                fault = detector.detect_from_exception(e)

                if not detector.should_retry(fault) or attempt >= max_attempts:
                    return RecoveryResult(
                        success=False,
                        should_retry=False,
                        strategy_used=self.__class__.__name__,
                        attempt=attempt,
                        message=f"Recovery failed: {str(e)}",
                    )

                recovery_result = await self.recover(fault, attempt, request_func, *args, **kwargs)
                if not recovery_result.should_retry:
                    return recovery_result

        return RecoveryResult(
            success=False,
            should_retry=False,
            strategy_used=self.__class__.__name__,
            attempt=attempt,
            message="Max retries exhausted",
        )

    def reset(self) -> None:
        """Reset the strategy state. Override in subclasses if needed."""
        pass

    @property
    def name(self) -> str:
        """Get the name of the recovery strategy."""
        return self.__class__.__name__
