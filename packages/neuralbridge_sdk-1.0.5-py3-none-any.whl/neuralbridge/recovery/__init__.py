"""
NeuralBridge-Lite Recovery Module

This module provides various recovery strategies for handling AI API faults.

Available Strategies:
- SimpleRetryStrategy: Basic exponential backoff retry
- CircuitBreakerStrategy: Circuit breaker pattern
- FlywheelRecoveryStrategy: Advanced flywheel recovery (cloud interface)

Example:
    >>> from neuralbridge.recovery import SimpleRetryStrategy
    >>> strategy = SimpleRetryStrategy(max_retries=3)
"""

from .base import RecoveryStrategy
from .circuit import CircuitBreakerStrategy
from .flywheel import FlywheelRecoveryStrategy
from .simple import SimpleRetryStrategy

__all__ = [
    "RecoveryStrategy",
    "SimpleRetryStrategy",
    "CircuitBreakerStrategy",
    "FlywheelRecoveryStrategy",
]
