"""
NeuralBridge SDK - Protected Module Loader

This module handles importing compiled (.pyd/.so) modules.
It provides a fallback mechanism for development and testing.

Usage:
    from neuralbridge.load_protected import import_protected_module
    
    # Try to import compiled module, fallback to .py source
    engine = import_protected_module("neuralbridge.engine")
"""

import os
import sys
import importlib
import importlib.util
from pathlib import Path
from typing import Optional, Any


def get_compiled_extension() -> str:
    """
    Get the platform-specific compiled extension.
    
    Returns:
        - '.pyd' on Windows
        - '.so' on Linux
        - '.dylib' on macOS
    """
    import platform
    
    system = platform.system()
    if system == 'Windows':
        return '.pyd'
    elif system == 'Darwin':
        return '.dylib'
    else:
        return '.so'


def find_module_path(module_name: str) -> Optional[Path]:
    """
    Find the module path for a given module name.
    
    Args:
        module_name: Full module path (e.g., 'neuralbridge.engine')
    
    Returns:
        Path to the module file (.py, .pyc, .pyd/.so) or None
    """
    # Convert module name to file path
    parts = module_name.split('.')
    
    # Search in sys.path
    for path in sys.path:
        if not path:
            continue
        
        base = Path(path)
        candidate = base / '/'.join(parts[:-1]) / parts[-1]
        
        # Check various extensions
        for ext in ['.pyd', '.so', '.dylib', '.py']:
            compiled = candidate.with_suffix(ext)
            if compiled.exists():
                return compiled
            
            # Also check in package directories
            py_file = base / '/'.join(parts) + '.py'
            if py_file.exists():
                return py_file
    
    return None


def import_protected_module(module_name: str) -> Any:
    """
    Import a module that may be either compiled (.pyd/.so) or source (.py).
    
    Priority:
    1. Compiled extension (.pyd/.so/.dylib)
    2. Python source (.py)
    3. Package __init__.py
    
    Args:
        module_name: Full module path (e.g., 'neuralbridge.engine')
    
    Returns:
        The imported module
    
    Raises:
        ImportError: If module cannot be found
    """
    # First, try standard import (works for both source and compiled)
    try:
        return importlib.import_module(module_name)
    except ImportError:
        pass
    
    # Try importing from compiled extension
    ext = get_compiled_extension()
    parts = module_name.split('.')
    
    # Search in package location
    for path in sys.path:
        base = Path(path)
        
        # Check if it's in a package
        if len(parts) > 1:
            package_path = base / '/'.join(parts[:-1])
            module_file = package_path / f"{parts[-1]}{ext}"
            
            if module_file.exists():
                # Load compiled extension
                spec = importlib.util.spec_from_file_location(
                    module_name, 
                    module_file
                )
                if spec and spec.loader:
                    return importlib.util.module_from_spec(spec)
                    # module = spec.loader.create_module(spec)
                    # sys.modules[module_name] = module
                    # spec.loader.exec_module(module)
                    # return module
        else:
            # Top-level module
            module_file = base / f"{parts[0]}{ext}"
            if module_file.exists():
                spec = importlib.util.spec_from_file_location(
                    module_name,
                    module_file
                )
                if spec and spec.loader:
                    return importlib.util.module_from_spec(spec)
    
    raise ImportError(f"Cannot find module: {module_name}")


def is_compiled(module_name: str) -> bool:
    """
    Check if a module is compiled (.pyd/.so) or source (.py).
    
    Args:
        module_name: Full module path
    
    Returns:
        True if module is compiled, False if source or not found
    """
    ext = get_compiled_extension()
    parts = module_name.split('.')
    
    for path in sys.path:
        base = Path(path)
        
        if len(parts) > 1:
            package_path = base / '/'.join(parts[:-1])
            module_file = package_path / f"{parts[-1]}{ext}"
        else:
            module_file = base / f"{parts[0]}{ext}"
        
        if module_file.exists():
            return True
    
    return False


def verify_protection(module_names: list) -> dict:
    """
    Verify that specified modules are properly protected (compiled).
    
    Args:
        module_names: List of module names to verify
    
    Returns:
        Dict mapping module name to protection status
    """
    results = {}
    
    for name in module_names:
        is_prot = is_compiled(name)
        results[name] = {
            'compiled': is_prot,
            'source_hidden': is_prot,  # If compiled, source is hidden
            'path': str(find_module_path(name)) if find_module_path(name) else None,
        }
    
    return results


# =============================================================================
# Stub Modules for Compiled Extensions
# =============================================================================
# These stubs allow import statements to work even when the compiled
# extension hasn't been built yet. They delegate to the actual implementation.

# When building, the stubs are replaced by the compiled modules.
# Users don't need to change their import statements.

def create_stub_module(module_name: str, public_api: list) -> str:
    """
    Generate a stub module that imports from the protected module.
    
    This is used during development when the compiled module
    hasn't been built yet.
    
    Args:
        module_name: Full module path
        public_api: List of public API members to export
    
    Returns:
        Stub module source code
    """
    module_file = module_name.split('.')[-1]
    module_path = module_name.replace('.', '/')
    
    stub = f'''"""
Stub module for {module_name}.

This module is auto-generated. Do not edit manually.

For production, use the compiled .pyd/.so file which contains
the actual implementation.
"""

# Try to import from compiled module first
try:
    from {module_path} import (
        {', '.join(public_api)}
    )
except ImportError:
    # Fallback to source (development only)
    import warnings
    warnings.warn(
        "{module_name} is not compiled. "
        "Running from source for development. "
        "Run 'python build_protected.py build_ext --inplace' to compile.",
        RuntimeWarning,
        stacklevel=2
    )
    # Import from source as fallback
    exec("from {module_path}_src import *")
'''
    return stub


if __name__ == '__main__':
    # Test protection verification
    test_modules = [
        'neuralbridge.engine',
        'neuralbridge.predictive',
        'neuralbridge.strategies',
        'neuralbridge.types',
    ]
    
    print("NeuralBridge SDK - Protection Status")
    print("=" * 50)
    
    results = verify_protection(test_modules)
    
    for name, status in results.items():
        status_icon = "🔒" if status['compiled'] else "📄"
        print(f"{status_icon} {name}:")
        print(f"   Compiled: {status['compiled']}")
        print(f"   Source hidden: {status['source_hidden']}")
        if status['path']:
            print(f"   Path: {status['path']}")
        print()
