# PhysicsOS 架构说明

本文档说明 PhysicsOS 当前代码库的总体架构、核心设计逻辑、主要模块职责、运行时数据流，以及系统扩展边界。

PhysicsOS 的定位不是一个单纯的求解器封装器，而是一个 AI-native 的 CAE 工作空间。系统把用户的物理问题、几何/材料输入、推导、代码生成、执行、验证、报告和云端 runner 对接都落到可审计的 case 目录中。它的核心思路是：由 DeepAgents 负责交互、规划和子任务委派，由 PhysicsOS 提供确定性的领域工具、数据契约、文件布局、验证规则和 runner 集成。

## 1. 总体设计目标

PhysicsOS 围绕几个目标组织代码：

1. 可审计

   每个工程问题都创建或复用一个 `cases/<case_id>/` 工作区。问题描述、开放问题、几何嵌入、材料预处理、TAPS 推导、生成代码、验证证据、报告和事件日志都写入文件，而不是只保存在对话上下文里。

2. TAPS-first

   默认主线是论文式 TAPS 工作流：先准备 analysis files 和 reference context，再生成 TAPS derivation prompt，随后写 case-local kernel，最后按 Fig. 7 风格执行验证链。TAPS 在这里是可检查的推导与代码生成路线，不是一个隐藏的内置黑箱求解器。

3. 工具确定性

   LLM/agent 只负责理解、编排和写作。凡是结构解析、路径转换、几何采样、材料标准化、赝势索引、验证检查、runner 调用等需要确定性的部分，都由 `physicsos.tools` 和 `physicsos.backends` 中的 Python 函数完成。

4. 数据契约优先

   `physicsos.schemas` 中的 Pydantic 模型定义公共输入输出契约。工具输出通常返回 `ArtifactRef`、结构化报告或严格模型，便于 agent、CLI、测试和云端 runner 共同消费。

5. 本地优先，云端可选

   本地工作流围绕仓库或 `PHYSICSOS_WORKSPACE` 展开。云端 runner 通过 `physicsos.cloud` 和 `runners/foamvm` 接入 OpenFOAM/mesh conversion 等外部执行能力，但不是主流程的必要条件。

## 2. 一屏架构

```text
用户请求 / 本地文件 / 几何 / 材料 / 结构文件
        |
        v
physicsos CLI
  - 启动 DeepAgents TUI 或单次请求
  - 处理 auth/account/paths/runner/geometry/pseudopotentials 本地命令
        |
        v
DeepAgents 主 agent
  - PhysicsOS system prompt
  - case workspace bridge tools
  - declarative subagents
        |
        v
PhysicsOS 子 agent 层
  - analysis-file-agent
  - geometry-embedding-agent
  - materials-preprocess-agent
  - KS-DFT/TAPS derivation/implementation/verification agents
  - TAPS derivation/implementation/verification/postprocess agents
  - knowledge-agent
        |
        v
确定性 tools/backends/schemas
  - case/context/reference tools
  - geometry/materials/pseudopotential tools
  - TAPS/KS-DFT tools
  - verification/postprocess/knowledge tools
  - surrogate and solver registries
        |
        v
case-local artifacts
  cases/<case_id>/
    problem/
    geometry/
    materials/
    pseudopotentials/
    references/
    context/
    taps/
    verification/
    report/
    manifest.json
    execution_plan.md
    events.jsonl
        |
        v
本地执行或云 runner
  - case-local Python kernel
  - verification chain
  - foamvm/E2B/OpenFOAM mesh conversion or solver job
```

## 3. 代码库分层

### 3.1 包入口和运行配置

主要文件：

- `physicsos/cli.py`
- `physicsos/config.py`
- `physicsos/paths.py`
- `physicsos/events.py`
- `pyproject.toml`

`pyproject.toml` 定义 Python 包名、版本、依赖和命令入口：

```text
physicsos = "physicsos.cli:main"
```

`physicsos.cli` 是统一入口。它有两类模式：

1. Agent 模式

   当用户直接运行 `physicsos`，或传入非本地命令参数时，CLI 会启动 PhysicsOS 定制后的 DeepAgents CLI/TUI 或单次 agent 请求。它会注入 PhysicsOS system prompt、子 agent 配置、workspace path patch、UTF-8 shell patch、banner patch 等。

2. 本地命令模式

   `LOCAL_COMMANDS` 包括：

   - `auth`
   - `account`
   - `paths`
   - `runner`
   - `geometry`
   - `pseudopotentials`
   - `pp`
   - `legacy-repl`

   这些命令不依赖 agent 推理，直接调用本地配置、云端 API、几何标签或赝势工具。

`physicsos.config` 管理运行时路径和配置。默认配置包括模型、云 runner、搜索、存储、赝势库、UI 和 core agent 参数。环境变量会覆盖配置文件，例如：

- `PHYSICSOS_HOME`
- `PHYSICSOS_WORKSPACE`
- `PHYSICSOS_CONFIG`
- `PHYSICSOS_OPENAI_API_KEY`
- `PHYSICSOS_OPENAI_BASE_URL`
- `PHYSICSOS_OPENAI_MODEL`
- `PHYSICSOS_ACCESS_TOKEN`

`physicsos.paths` 解决一个关键设计问题：agent 面向 `/workspace/...` 这样的稳定路径，而本地系统可能是 Windows 路径、POSIX 路径或相对路径。核心函数包括：

- `to_agent_path`
- `from_agent_path`
- `resolve_workspace_path`

这让工具输出可以统一给 agent 展示 `/workspace/cases/...`，同时在本地安全地解析成真实文件路径。

`physicsos.events` 提供事件模型、事件日志、渲染器和工具 wrapper。事件既可以写入 `sessions/events-*.jsonl`，也可以通过 LangGraph stream writer 发给上层 UI。事件类型覆盖 workflow、agent、tool、artifact、memory、failure 等生命周期。

### 3.2 Agent 编排层

主要文件：

- `physicsos/agents/main.py`
- `physicsos/agents/runtime.py`
- `physicsos/agents/prompts.py`
- `physicsos/agents/subagents.py`
- `physicsos/agents/openai_compatible.py`
- `physicsos/agents/structured.py`

Agent 层的职责是编排，不直接实现物理算法。

`create_physicsos_agent` 是创建 DeepAgents 主 agent 的入口。它把以下对象交给 `deepagents.create_deep_agent`：

- model
- `DEEPAGENTS_MAIN_BRIDGE_TOOLS`
- `SUBAGENTS`
- `PHYSICSOS_SYSTEM_PROMPT`
- runtime kwargs

主 agent 的工具面很小，默认只暴露 case/context 相关 bridge tools。这是刻意设计：主 agent 负责创建 workspace、维护执行计划、构建上下文和委派子 agent，不把所有领域工具直接堆到主 agent 工具面上。

`DeepAgentsRuntimeConfig` 控制：

- 是否启用 filesystem backend
- 是否启用 LangGraph memory store
- 是否启用 checkpointer
- 是否对 full solver、HPC、删除类工具启用 interrupt
- runtime 名称和额外参数

filesystem backend 采用 DeepAgents 的 `CompositeBackend`，把 `/cases/`、`/datasets/`、`/models/`、`/reports/`、`/scratch/` 映射到不同后端。这样 agent 能使用 DeepAgents 的文件工具维护 case artifact。

`prompts.py` 是系统行为的核心规范。它定义：

- PhysicsOS 主系统提示词
- analysis 文件 agent 提示词
- geometry embedding agent 提示词
- materials preprocess agent 提示词
- KS-DFT 分析、推导、实现、验证 agent 提示词
- TAPS 推导、实现、验证、后处理 agent 提示词

这些提示词明确规定了默认 workflow、必须读取/写入的 case 文件、不能跳过的验证证据，以及哪些行为要 fail closed。

`subagents.py` 把每个子 agent 的名称、描述、system prompt 和工具组绑定起来。子 agent 不是随意创建的角色，而是围绕 PhysicsOS 的工作流阶段固定划分：

- `analysis-file-agent`
- `geometry-embedding-agent`
- `materials-preprocess-agent`
- `ks-dft-analysis-agent`
- `ks-dft-taps-derivation-agent`
- `ks-dft-taps-implementation-agent`
- `ks-dft-verification-agent`
- `taps-derivation-agent`
- `taps-implementation-agent`
- `verification-agent`
- `postprocess-agent`
- `knowledge-agent`

`openai_compatible.py` 从 PhysicsOS 配置和环境变量创建 LangChain `ChatOpenAI` 对象，用于 OpenAI-compatible endpoint。`structured.py` 提供结构化 core-agent 调用和重试机制，要求 LLM 返回匹配 Pydantic schema 的 JSON，并把每次尝试写入 scratch artifacts。

### 3.3 数据契约层

主要目录：

- `physicsos/schemas/`

该目录是系统的公共数据模型层。所有模块共享这些 Pydantic 契约，避免工具间传递不透明 dict。

关键模型包括：

- `StrictBaseModel`
- `ArtifactRef`
- `Provenance`
- `RuntimeStats`
- `ComputeBudget`
- `UserIntent`
- `ParameterSpec`
- `TargetSpec`
- `PhysicsProblem`
- `GeometrySpec`
- `GeometryMeshContract`
- `MaterialSpec`
- `MaterialsPreprocessResultSpec`
- TAPS、KS-DFT、solver、surrogate、verification 相关模型

`StrictBaseModel` 使用 `extra="forbid"`，因此工具输入输出不会默默接受多余字段。这让 agent 生成结构化输入时更容易暴露错误，也让测试可以更明确地检查契约变化。

`ArtifactRef` 是系统中最重要的轻量引用模型之一。工具一般不把大文件内容直接塞进返回值，而是返回：

```text
uri, kind, format, checksum, description
```

这让 agent 能看到 artifact 的位置和语义，同时把真实文件留在 case workspace。

### 3.4 工具层

主要目录：

- `physicsos/tools/`

工具层是 PhysicsOS 的确定性能力集合。每个工具通常都有：

- Pydantic input model
- Pydantic output model
- 文件副作用
- `ArtifactRef` 输出
- warnings/errors 字段

工具按领域拆分：

- `case_tools.py`

  创建 case workspace、维护 execution plan、加载 TAPS references、构建 context window、构建 derivation prompt。

- `geometry_embedding_tools.py`

  处理 STL 或简单自然语言 primitive，生成 Gmsh distance-field manifest、background grid、SDF、occupancy、boundary samples、normals、cut cells、geometry handoff notes。

- `geometry_tools.py`

  更通用的几何导入、修复、标签、mesh contract、mesh semantics gate、boundary labeling、mesh conversion job 准备与提交。

- `materials_tools.py`

  使用 `pymatgen`、`spglib`、`seekpath` 做结构解析、标准化、对称性、倒格矢、k-mesh、不可约 k 点、高对称路径、supercell、molecule/cluster context、KS-DFT material context。

- `pseudopotential_tools.py`

  索引本地 VASP PAW/PBE POTCAR 库，提取 metadata/hash/provenance，选择元素对应赝势，并验证 local potential/nonlocal projector artifacts。设计上不复制、不重新分发 POTCAR 内容。

- `ks_dft_taps_tools.py`

  准备 KS-DFT-TAPS kernel scaffold、Gamma-only reference、multi-k integration policy、band/DOS preflight、LRDM SCF acceleration plan、XC policy、task assumptions。

- `ks_dft_verification_tools.py`

  检查电荷守恒、轨道正交归一、SCF residual、Poisson residual、rank/grid/k-point convergence、Hamiltonian evidence、band/DOS provenance、materials artifact usage、molecular context evidence。

- `taps_tools.py`

  评估 TAPS 支持度、几何可分性、总结推导、构造 TAPS problem、准备 backend bundle、生成 runtime extension、compile/static check/review/execute case-local kernel、估计 residual。

- `verification_chain_tools.py`

  对应论文 Fig. 7 风格：生成 exact solution code、执行 exact solution code、生成 convergence code、执行 convergence code、绘图。

- `verification_tools.py`

  更通用的 physics residual、边界条件、守恒律、slice validation、不确定性和 OOD 检查。

- `knowledge_tools.py`

  管理本地知识库、arXiv/search/deepsearch/ingest/context assembly。

- `memory_tools.py`

  case memory 的追加、读取、搜索和结果存储。

- `catalog_tools.py`

  对外列出 operator templates、solver backends、verification rules、postprocess templates，并推荐 runtime stack。

- `postprocess_tools.py`

  KPI 提取、可视化规划、报告生成。

`tools/registry.py` 是工具编排表。它把工具分成若干 group，并定义：

- `DEEPAGENTS_MAIN_BRIDGE_TOOLS`
- `PHYSICSOS_WORKFLOW_NODE_CAPABILITIES`
- `DEEPAGENTS_SUBAGENT_TOOL_GROUPS`

这个 registry 是 agent 工具权限边界。比如主 agent 只拿 case tools，而 `materials-preprocess-agent` 才拿 materials 和 pseudopotential tools，`ks-dft-verification-agent` 才拿 KS-DFT verification tools。

### 3.5 Backend 层

主要目录：

- `physicsos/backends/`

Backend 层不是 agent 编排层，而是领域能力、注册表和推理 runtime 的底座。

主要职责：

- solver backend registry
- operator templates
- verification rules
- surrogate model registry/catalog/adapters/inference/runtime
- local knowledge SQLite FTS
- native simple solver，例如 `heat_1d.py`
- geometry mesh helper

`physics_registry.py` 定义 operator、solver backend、verification rule、postprocess template 等目录。它把 `taps` 标为 paper-style derivation-to-kernel route，也记录 OpenFOAM、SU2、FEniCSx、MFEM、Quantum ESPRESSO、CP2K、LAMMPS、Cantera 等外部 backend 的能力状态和角色。

`knowledge_base.py` 使用 SQLite，并在可用时创建 FTS5 表。文档被切块后写入 `sources` 和 `chunks`，搜索时优先用 FTS，失败后降级到 LIKE 查询。

`surrogate_runtime.py` 根据 `PhysicsProblem` 和 surrogate registry 给模型打分、路由，并在 checkpoint 可用时运行 checkpoint surrogate；否则返回 scaffold result。

### 3.6 Case artifact 层

Case workspace 是 PhysicsOS 的事实中心。`create_case_workspace` 会创建：

```text
cases/<case_id>/
  problem/
  geometry/
  references/
  context/
  taps/
  verification/
    plots/
  report/
    figures/
  manifest.json
  execution_plan.md
  events.jsonl
```

不同路线还会创建：

```text
cases/<case_id>/
  materials/
  pseudopotentials/
  verification/ks_dft/
```

`manifest.json` 记录 case schema、case id、创建时间、用户请求、stage order、current stage 和 route。

`execution_plan.md` 是给 agent 和用户看的阶段清单。阶段固定为：

1. `ANALYSIS_FILES`
2. `GEOMETRY_EMBEDDING`
3. `CONTEXT_REFERENCES`
4. `CONTEXT_WINDOW`
5. `TAPS_DERIVATION`
6. `CODE_IMPLEMENTATION`
7. `FIG7_VERIFICATION`
8. `REVISION_OR_REPORT`

`events.jsonl` 是 case-local append-only 事件日志。各工具可通过 `_append_event` 记录 artifact 生成和状态变化。

这个设计有两个重要效果：

- 对话上下文丢失时，系统仍能从 case artifact 恢复工作状态。
- 任何推导、假设、代码和验证结果都可以被用户或测试检查。

### 3.7 知识和 reference 层

主要目录和文件：

- `docs/knowledge_seed/`
- `docs/knowledge_seed/references/`
- `scripts/seed_computational_physics_knowledge.py`
- `scripts/build_knowledge_base.py`
- `physicsos/backends/knowledge_base.py`
- `physicsos/tools/knowledge_tools.py`

PhysicsOS 的 TAPS 路线依赖本地 reference，而不是让模型凭空回忆论文细节。默认 TAPS references 包括：

- `taps_template_eq5.md`
- `taps_matrix_definitions.md`
- `taps_cot_outline.md`
- `taps_verification_workflow.md`
- `ibm_ife_geometry_embedding.md`

KS-DFT references 包括：

- `materials_tool_contract.md`
- `ks_dft_formula_notes.md`
- `ks_tensor_basis_notes.md`
- `chefsi_notes.md`
- `lrdm_scf_notes.md`

`load_taps_case_references` 会把这些 reference 复制到 case 的 `references/` 下。`build_paper_context_window` 会把 analysis files、工具输出、reference、geometry/materials notes 等压缩成 `context/context_window.md`，供 derivation/implementation/verification agent 读取。

### 3.8 云 runner 层

主要目录：

- `physicsos/cloud/`
- `runners/foamvm/`

Python 侧：

- `physicsos.cloud.config` 读取和保存 runner URL/token。
- `physicsos.cloud.auth` 实现 device-code login，并把 access token 写入 PhysicsOS config。
- `physicsos.cloud.foamvm_client` 调用 runner API，包括提交 job、查询状态、事件、artifact、下载单个或全部 artifact。

Next.js runner 侧：

- `runners/foamvm/app/api/physicsos/jobs/route.ts`
- `runners/foamvm/lib/physicsos-openfoam-runner.ts`
- `runners/foamvm/supabase/schema.sql`

`/api/physicsos/jobs` 是 PhysicsOS 集成应使用的结构化 endpoint。它接收两类 manifest：

1. `physicsos.full_solver_job.v1`

   当前主要用于 OpenFOAM job。runner 在 E2B sandbox 中写入 case files、执行 OpenFOAM 命令、收集输出 artifact 并以 base64 返回。

2. `physicsos.mesh_conversion_job.v1`

   用于 mesh conversion。OpenFOAM 路线调用 `gmshToFoam`，SU2/FEniCSx 路线优先使用 `meshio`。

runner 子项目本身还保留 Supabase Auth、run token、run consumption、run events、storage artifacts 等 Web app 能力。PhysicsOS CLI 的结构化 runner endpoint 和原始 prompt-based CFD UI 是分开的。

## 4. 核心运行数据流

### 4.1 默认 TAPS 工作流

默认 TAPS route 的逻辑是：

```text
用户提出 PDE/CAE 请求
  -> create_case_workspace
  -> analysis-file-agent 写 problem_statement/problem.json/open_questions
  -> 如有 STL/CAD/几何描述，geometry-embedding-agent 写 geometry artifacts
  -> load_taps_case_references
  -> build_paper_context_window
  -> taps-derivation-agent 写 derivation_prompt/derivation/implementation_notes
  -> taps-implementation-agent 写 taps/kernel.py 和 execution artifacts
  -> verification-agent 生成并执行 exact/convergence/plot/report
  -> postprocess-agent 写最终报告
```

这条路线强调“先推导、再实现、再验证”。系统提示词明确要求不要直接跳到最终矩阵或代码，也不要把 Gmsh 当 PDE solver。

### 4.2 几何嵌入工作流

几何模块把 STL/CAD 或简单生成几何转换成 TAPS 可用的 immersed-boundary/IFE 上下文：

```text
source STL 或 primitive description
  -> import_stl_geometry 或 generate_primitive_geometry
  -> stl_summary.json
  -> gmsh distance field manifest
  -> background_grid
  -> sdf/occupancy/boundary_samples/normals/cut_cells
  -> sdf_quality.json
  -> embedding.json
  -> geometry_embedding.md
  -> taps_geometry_handoff.md
```

几何模块只准备系数、边界和采样证据，不负责求解 PDE。

### 4.3 材料和 KS-DFT-TAPS 工作流

材料路线先把结构文件变成确定性 artifact：

```text
CIF/POSCAR/JSON/XYZ
  -> parse material or molecular structure
  -> validate/standardize/reduce/analyze symmetry
  -> reciprocal lattice
  -> kmesh and irreducible kpoints
  -> seekpath or pymatgen high-symmetry path
  -> materials/ks_dft_material_context.md/json
```

如果使用赝势：

```text
local VASP PAW/PBE root
  -> metadata-only POTCAR index
  -> select pseudopotentials for species
  -> pseudopotential context
  -> optional local potential/projector contract validation
```

随后 KS-DFT 子 agent 执行：

```text
materials context
  -> ks-dft-analysis-agent 写 problem artifacts
  -> ks-dft-taps-derivation-agent 写 KS matrix/tensor/SCF/CheFSI/LRDM 推导
  -> ks-dft-taps-implementation-agent 写 case-local kernel 和 runtime metadata
  -> ks-dft-verification-agent 检查 charge/orthonormality/SCF/Poisson/Hamiltonian/band-DOS provenance
```

设计边界是：当前路线不调用 QE、VASP、CP2K 或 ELSI；不会把 VASP PAW metadata 当作完整 Hamiltonian；缺失 local/nonlocal/PAW contract 时必须明确降级或失败。

### 4.4 云端 OpenFOAM/mesh conversion 工作流

本地工具或 CLI 先准备 manifest：

```text
case artifacts
  -> runner manifest
  -> physicsos runner submit manifest.json
  -> FoamVMClient POST /api/physicsos/jobs
  -> Next.js runner validates manifest
  -> E2B sandbox runs command
  -> artifacts collected
  -> CLI status/logs/artifacts/download
```

OpenFOAM runner 是外部执行面。PhysicsOS 主系统仍要求对 runner 输出做独立 artifact 检查和验证，而不是仅凭 backend 日志接受结果。

## 5. 目录职责

```text
physicsos/
  agents/          DeepAgents 集成、提示词、子 agent、结构化 agent
  backends/        solver/surrogate/knowledge/registry/runtime 基础能力
  cloud/           foamvm runner auth/config/client
  schemas/         Pydantic 公共数据契约
  tools/           case、几何、材料、赝势、TAPS、验证、知识、后处理工具
  cli.py           包命令入口
  config.py        配置和运行时路径
  events.py        事件模型和日志
  paths.py         /workspace 与本地路径互转

docs/
  knowledge_seed/  本地知识种子和 reference 文档

examples/
  示例工作流和 smoke scripts

runners/foamvm/
  Next.js + E2B + Supabase 云 runner 子项目

scripts/
  知识库构建、模型权重下载等维护脚本

tests/
  单元测试和集成行为测试

cases/
  case-local 工作区和产物

data/
  knowledge SQLite、case memory 等运行数据

configs/
  surrogate 等示例配置

models/
  本地模型/权重说明或占位

scratch/
  临时结构化 agent 尝试、运行中间文件等

sessions/
  agent/session/event 运行记录
```

## 6. 关键设计边界

### 6.1 Agent 不等于 solver

Agent 可以写推导、生成代码、调用工具和整理报告，但确定性检查和物理证据必须落到 artifact。系统通过 prompts、tools registry 和 verification tools 把这个边界制度化。

### 6.2 Gmsh 是几何预处理，不是默认 PDE 求解器

几何工具可以使用 Gmsh distance field、mesh export 和 mesh conversion，但默认 TAPS route 要把几何作为 `phi(x)`、`chi(x)`、boundary samples、cut cells 等项进入推导，而不是把 PDE 求解交给 Gmsh。

### 6.3 赝势索引只存 metadata

`pseudopotential_tools.py` 明确只索引 POTCAR metadata、hash、路径和 provenance，不复制 POTCAR 内容。生成 kernel 时也不能临时解析 POTCAR 来绕过 contract。

### 6.4 KS-DFT route fail closed

KS-DFT 子系统需要明确材料 artifact、赝势 contract、XC policy、task assumptions、multi-k policy 和 Hamiltonian evidence。缺少证据时应输出开放问题、prototype 标记或失败，而不是假装已实现生产级 DFT。

### 6.5 `/workspace` 是 agent-facing 路径协议

无论本地真实路径是 Windows 还是 POSIX，agent 和 artifact URI 优先使用 `/workspace/...`。CLI 对 DeepAgents shell 做路径翻译，工具内部再使用 `resolve_workspace_path` 解析。

### 6.6 云 runner 是受控外部能力

`physicsos.cloud` 使用 bearer token 调用 runner。`runners/foamvm` 中的 API 会验证 `PHYSICSOS_RUNNER_TOKEN`，E2B sandbox 负责隔离执行。runner 结果应作为 artifact 回流到 case，再经过验证逻辑判断可信度。

## 7. 扩展方式

### 7.1 添加新领域工具

推荐步骤：

1. 在 `physicsos/schemas/` 中定义或复用输入输出契约。
2. 在 `physicsos/tools/<domain>_tools.py` 中实现确定性函数。
3. 返回 `ArtifactRef` 和结构化 warnings/errors。
4. 在 `physicsos/tools/registry.py` 中加入合适工具组。
5. 如需要 agent 使用，在 `prompts.py` 和 `subagents.py` 中更新对应角色说明。
6. 为工具副作用、契约和关键失败模式添加测试。

### 7.2 添加新 solver backend

推荐步骤：

1. 在 `physicsos/backends/physics_registry.py` 增加 backend entry。
2. 定义支持范围、能力状态、命令、runner 要求和验证方法。
3. 如需远程执行，定义 runner manifest schema 和 client 方法。
4. 在 tools 层准备 manifest 生成、提交和 artifact 检查。
5. 在 verification 层增加 backend-specific 证据检查。

### 7.3 添加新 case stage

当前 stage order 是工具和 prompt 共同依赖的审计协议。新增阶段时必须同步修改：

- `CASE_STAGE_ORDER`
- `PHYSICSOS_SYSTEM_PROMPT`
- 对应子 agent prompt
- execution plan 更新逻辑
- 测试期望

如果只是新增 artifact，不应轻易新增 stage。

### 7.4 添加新云 runner

推荐保持与 foamvm 类似的分层：

1. Python `cloud/<runner>_client.py` 只处理认证、HTTP、状态和 artifact 下载。
2. tools 层负责生成结构化 manifest。
3. runner 服务负责 sandbox 执行和 artifact 收集。
4. case verification 层负责接受或拒绝结果。

## 8. 系统的核心不变量

PhysicsOS 的实现应持续维护以下不变量：

- 每个用户问题都应该能映射到一个 case workspace。
- 关键中间结果必须以 artifact 存在，而不是只存在于消息历史。
- 推导、实现和验证必须在文件系统中可追踪。
- 工具输入输出必须符合 Pydantic 契约。
- agent-facing path 使用 `/workspace/...`。
- 材料、几何、赝势和求解器结果不能由 LLM 凭空补全。
- TAPS route 必须保留 paper-style 推导和验证证据。
- 云 runner 输出不能绕过本地验证。
- 对缺失物理数据、缺失 contract 或未覆盖能力要明确失败、降级或提出开放问题。

## 9. 当前架构总结

PhysicsOS 当前是一个“agent 编排 + 确定性工具 + case artifact + 可选云 runner”的系统。

主 agent 和子 agent 决定工作顺序、读写文档和委派任务；`tools/` 和 `backends/` 负责可重复的领域操作；`schemas/` 约束跨模块数据；`cases/` 保留审计证据；`runners/foamvm` 提供外部 sandbox 执行能力。整个架构的中心不是某个单一 solver，而是从问题理解到推导、实现、执行、验证、报告的可检查工程链路。
