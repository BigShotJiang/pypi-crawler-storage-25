import os
import platform
import shutil
import subprocess
import psutil
from pathlib import Path

def discover_capabilities():
    return {
        "job_managers": _identify_job_managers(),
        "software_stacks": _identify_software_stacks(),
        "storage_systems": _identify_storage_systems(),
        "parallel_environments": _identify_parallel_envs(),
        "hardware": _discover_hardware(),
        "labels": _get_site_labels()
    }

import os
import shutil

def _identify_job_managers():
    """
    Detects job/resource managers using both binary presence 
    and environment variable fingerprints.
    """
    managers = {}

    # 1. SLURM
    if shutil.which("srun") or "SLURM_JOB_ID" in os.environ:
        managers["slurm"] = {"detected": True, "cli": ["sbatch", "srun", "salloc", "scancel"]}

    # 2. FLUX
    if shutil.which("flux") or "FLUX_URI" in os.environ:
        managers["flux"] = {"detected": True, "cli": ["flux"]}

    # 3. Kubernetes
    if shutil.which("kubectl") or os.path.exists("/var/run/secrets/kubernetes.io"):
        managers["kubernetes"] = {"detected": True, "cli": ["kubectl"]}

    # 4. LSF (IBM Spectrum LSF)
    if shutil.which("bsub") or "LSF_ENVDIR" in os.environ:
        managers["lsf"] = {"detected": True, "cli": ["bsub", "bjobs", "bkill"]}

    # 5. HTCondor
    if shutil.which("condor_submit") or "_CONDOR_JOB_AD" in os.environ:
        managers["htcondor"] = {"detected": True, "cli": ["condor_submit", "condor_q", "condor_rm"]}

    # 6. OAR
    if shutil.which("oarsub") or "OAR_JOB_ID" in os.environ:
        managers["oar"] = {"detected": True, "cli": ["oarsub", "oarstat", "oardel"]}

    # 7. Disambiguation for qsub-based systems (PBS, Torque, Cobalt)
    if shutil.which("qsub") or "PBS_JOBID" in os.environ or "COBALT_JOBID" in os.environ:
        if "COBALT_JOBID" in os.environ or shutil.which("cqsub"):
            managers["cobalt"] = {"detected": True, "cli": ["qsub", "qstat", "qdel", "cqsub"]}
        elif "PBS_JOBID" in os.environ or shutil.which("qstat"):
            # If PBS is detected, we check for torque-specific things, else assume OpenPBS
            if os.path.exists("/etc/torque"):
                managers["torque"] = {"detected": True, "cli": ["qsub", "qstat", "qdel"]}
            else:
                managers["pbs"] = {"detected": True, "cli": ["qsub", "qstat", "qdel"]}

    # 8. Moab (Often sits on top of Torque/PBS)
    if shutil.which("msub") or "MOABJOBID" in os.environ:
        managers["moab"] = {"detected": True, "cli": ["msub", "mjobctl", "showq"]}

    return managers

def _identify_software_stacks():
    """Detects package managers and environment controllers."""
    stacks = {}

    # Modules (Lmod/TCL)
    if "LMOD_CMD" in os.environ:
        stacks["lmod"] = {"version": os.environ.get("LMOD_VERSION")}
    elif "MODULESHOME" in os.environ:
        stacks["tcl_modules"] = {"path": os.environ.get("MODULESHOME")}

    # Spack
    if os.environ.get("SPACK_ROOT") or shutil.which("spack"):
        stacks["spack"] = {"root": os.environ.get("SPACK_ROOT")}

    # Conda/Mamba
    if "CONDA_EXE" in os.environ or shutil.which("conda"):
        stacks["conda"] = {"prefix": os.environ.get("CONDA_PREFIX")}

    return stacks

def _identify_storage_systems():
    """
    Detects high-performance filesystems. 
    LAMMPS performance is often tied to I/O (checkpointing/restarts).
    """
    storage = {"lustre": False, "gpfs": False, "nfs": False}
    
    try:
        # Check /proc/mounts for filesystem types
        with open("/proc/mounts", "r") as f:
            mounts = f.read()
            if "lustre" in mounts: storage["lustre"] = True
            if "gpfs" in mounts or "mmfs" in mounts: storage["gpfs"] = True
            if "nfs" in mounts: storage["nfs"] = True
    except: 
        pass

    return storage

def _identify_parallel_envs():
    """Detects MPI implementations and parallel libraries."""
    envs = {}
    
    # MPI check
    mpi_launchers = ["mpirun", "mpiexec", "srun"]
    for launcher in mpi_launchers:
        path = shutil.which(launcher)
        if path:
            envs["mpi"] = {"launcher": launcher, "path": path}
            break
            
    # Look for specific MPI flavors in environment
    if "OMPI_COMM_WORLD_SIZE" in os.environ: envs["mpi_flavor"] = "OpenMPI"
    elif "I_MPI_ROOT" in os.environ: envs["mpi_flavor"] = "IntelMPI"

    return envs

def _discover_hardware():
    # Detect Architecture (x86_64, aarch64, etc.)
    hw = {
        "arch": platform.machine(),
        "cpu_count": psutil.cpu_count(logical=False),
        "mem_total_gb": round(psutil.virtual_memory().total / (1024**3), 2)
    }

    # Interconnects: IB (Infiniband), OPA (Omni-Path), RoCE
    hw["interconnect"] = "ethernet"
    if os.path.exists("/sys/class/infiniband"):
        hw["interconnect"] = "infiniband"
    elif os.path.exists("/sys/class/hfi1"):
        hw["interconnect"] = "omni-path"

    # Accelerators (NVIDIA/AMD)
    hw["gpus"] = {"count": 0, "type": None}
    if shutil.which("nvidia-smi"):
        hw["gpus"]["type"] = "nvidia"
    elif shutil.which("rocm-smi"):
        hw["gpus"]["type"] = "amd"

    return hw

def _get_site_labels():
    """Site-specific metadata (tier, local name)."""
    return {
        "hostname": platform.node(),
        "os_release": platform.release(),
        "cluster_name": os.environ.get("CLUSTER_NAME", "unknown_cluster")
    }