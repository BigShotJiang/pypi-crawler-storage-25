"""Test suite for WAuth."""
