# aws.api_gateway_auth_required

Detects whether each `aws_api_gateway_method` (REST API v1) and
`aws_apigatewayv2_route` (HTTP/WebSocket API v2) declares a non-NONE
authorization mode. Auth on routes IS the intended-state enforcement
and the privilege boundary at the API edge.

Per DECISIONS 2026-05-10 "Tier 2 #3 design: VPC isolation, route auth,
WAF attachment", this is detector γ of the Tier 2 #3 batch. Library's
**first detector** evidencing both KSI-CNA-EIS and KSI-CNA-DFP — both
KSIs were previously uncovered.

## What it proves

- **KSI-CNA-EIS (Enforcing Intended State).** Each API Gateway route
  in scope has a declared authorization mode. Coverage is `partial` —
  the IaC layer evidences the declaration; runtime enforcement
  correctness is out of scope.
- **KSI-CNA-DFP (Defining Functionality and Privileges).** The
  per-route auth declaration IS the privilege boundary at the API
  edge.
- **AC-3 (Access Enforcement) + AC-6 (Least Privilege).** The
  IaC-layer half of the access-enforcement primitive on the API
  surface.

## What it does NOT prove

- **Authorizer correctness at runtime.** A `COGNITO_USER_POOLS` mode
  doesn't prove the user pool has appropriate group rules; a
  `CUSTOM` mode doesn't prove the Lambda authorizer rejects bad
  tokens.
- **The authorized principals have appropriately-scoped permissions.**
  That's IAM detector territory — `aws.mfa_required_on_iam_policies`,
  `aws.iam_admin_policy_usage`, etc.
- **The public-by-design route case is not a gap.** Per the
  DECISIONS entry, the detector emits `auth_none` unconditionally;
  the Gap Agent reasons about whether intentional-public routes
  (health endpoints, public webhooks) are gaps from broader prompt
  context.

## Patterns recognized

| Resource type | Field | `auth_state` |
|---|---|---|
| `aws_api_gateway_method` (v1) | `authorization` ∈ {`AWS_IAM`, `CUSTOM`, `COGNITO_USER_POOLS`} | `auth_required` |
| `aws_api_gateway_method` (v1) | `authorization = "NONE"` or omitted | `auth_none` (gap) |
| `aws_apigatewayv2_route` (v2) | `authorization_type` ∈ {`AWS_IAM`, `CUSTOM`, `JWT`} | `auth_required` |
| `aws_apigatewayv2_route` (v2) | `authorization_type = "NONE"` or omitted | `auth_none` (gap) |
| Either | field uses Terraform interpolation | `unverifiable` |

The auth field defaults to `NONE` in both v1 and v2 when omitted,
which is why the detector treats omission as `auth_none` (the gap)
rather than skipping the resource.

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-CNA-EIS | partial | Per-route auth-mode declaration |
| KSI-CNA-DFP | partial | Privilege boundary at the API edge |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| AC-3 | infrastructure | partial |
| AC-6 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_api_gateway_method" "get_users_authed" {
  rest_api_id   = "api-id-placeholder"
  resource_id   = "resource-id-placeholder"
  http_method   = "GET"
  authorization = "AWS_IAM"
}

resource "aws_api_gateway_method" "get_health_public" {
  rest_api_id   = "api-id-placeholder"
  resource_id   = "resource-id-placeholder"
  http_method   = "GET"
  authorization = "NONE"
}
```

Output (two Evidence records):

```json
[
  {
    "content": {
      "resource_type": "aws_api_gateway_method",
      "resource_name": "get_users_authed",
      "route_label": "GET get_users_authed",
      "auth_state": "auth_required",
      "pattern": "rest_api_v1_method_auth",
      "auth_mode": "AWS_IAM",
      "detail": "route=GET get_users_authed; authorization=AWS_IAM"
    }
  },
  {
    "content": {
      "resource_type": "aws_api_gateway_method",
      "resource_name": "get_health_public",
      "route_label": "GET get_health_public",
      "auth_state": "auth_none",
      "pattern": "rest_api_v1_method_auth",
      "auth_mode": "NONE",
      "gap": "aws_api_gateway_method 'GET get_health_public' has authorization='NONE'; the route is publicly invokable. Compliance reviewers consistently ask about route-level auth on API edges. If this route is intentionally public (health endpoint, public webhook), the reviewer should annotate the gap as accepted."
    }
  }
]
```

## Fixtures

- `fixtures/should_match/v1_method_iam_auth.tf` — REST v1 method with
  `authorization = "AWS_IAM"` (positive: `auth_required`).
- `fixtures/should_match/v2_route_jwt_auth.tf` — HTTP v2 route with
  `authorization_type = "JWT"` (positive).
- `fixtures/should_not_match/v1_method_none_auth.tf` — REST v1 method
  with `authorization = "NONE"` (negative-evidence case).
