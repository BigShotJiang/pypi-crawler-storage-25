# Mixed API Gateway posture, expanded across revisions to exercise
# the Tier 2 #1, #2, and #3 APIGW-side detectors.
#
#   Tier 2 #1: aws.api_gateway_tls_min_version (custom-domain TLS floor)
#   Tier 2 #2: aws.api_gateway_access_logging (per-stage access_log_settings)
#   Tier 2 #3: aws.api_gateway_auth_required (per-route auth mode),
#              aws.api_gateway_waf_attached (per-stage WAF assoc)
#
# Custom domains (TLS-floor posture):
#   - public_api_v1     -- REST v1 custom domain on TLS_1_2 (positive)
#   - legacy_api_v1     -- REST v1 custom domain with security_policy
#                          omitted; AWS provider defaults to TLS_1_0
#                          (negative -- the legacy gap).
#   - public_api_v2     -- HTTP v2 custom domain (positive: v2 only
#                          supports TLS_1_2).
#
# Stages (access-logging + WAF posture):
#   - public_api_v1_prod_stage      -- WITH access_log_settings AND
#                                      WAF association (positive on
#                                      both stage-level detectors).
#   - public_api_v1_staging_stage   -- WITHOUT access_log_settings AND
#                                      WITHOUT WAF (negative on both).
#   - public_api_v2_default_stage   -- WITH access_log_settings; no
#                                      WAF (mixed: positive on logging,
#                                      negative on WAF).
#
# Routes (rev 3 -- auth_required posture):
#   - get_users    -- REST v1 method, authorization = "AWS_IAM" (positive)
#   - get_health   -- REST v1 method, authorization = "NONE" (negative)
#   - post_orders  -- HTTP v2 route, authorization_type = "JWT" (positive)

resource "aws_api_gateway_domain_name" "public_api_v1" {
  domain_name              = "api.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/api-cert"
  security_policy          = "TLS_1_2"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_domain_name" "legacy_api_v1" {
  domain_name              = "legacy.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/legacy-cert"
  # security_policy omitted; AWS provider defaults to TLS_1_0 -- the gap.

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_apigatewayv2_domain_name" "public_api_v2" {
  domain_name = "v2.serverless-mixed.example.com"

  domain_name_configuration {
    certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/v2-cert"
    endpoint_type   = "REGIONAL"
    security_policy = "TLS_1_2"
  }
}

# --- Stages (access-logging from rev 2) ---

resource "aws_cloudwatch_log_group" "api_access_logs" {
  name              = "/aws/apigateway/serverless-mixed"
  retention_in_days = 365
}

resource "aws_api_gateway_stage" "public_api_v1_prod_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-prod-id-placeholder"
  stage_name    = "prod"

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.resourcePath $context.status $context.responseLength"
  }
}

resource "aws_api_gateway_stage" "public_api_v1_staging_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-staging-id-placeholder"
  stage_name    = "staging"
  # No access_log_settings block -- the request-path audit trail gap.
  # Also no WAF association in rev 3.
}

resource "aws_apigatewayv2_stage" "public_api_v2_default_stage" {
  api_id      = "v2-api-id-placeholder"
  name        = "$default"
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.routeKey $context.status"
  }
}

# --- Routes (rev 3 -- auth_required posture) ---

resource "aws_api_gateway_method" "get_users" {
  rest_api_id   = "rest-api-public-id-placeholder"
  resource_id   = "users-resource-id-placeholder"
  http_method   = "GET"
  authorization = "AWS_IAM"
}

resource "aws_api_gateway_method" "get_health" {
  rest_api_id   = "rest-api-public-id-placeholder"
  resource_id   = "health-resource-id-placeholder"
  http_method   = "GET"
  authorization = "NONE"
  # Public health endpoint -- the auth gap. May be intentional;
  # the Gap Agent reasons from broader prompt context.
}

resource "aws_apigatewayv2_route" "post_orders" {
  api_id             = "v2-api-id-placeholder"
  route_key          = "POST /orders"
  authorization_type = "JWT"
  authorizer_id      = "jwt-authorizer-id-placeholder"
}

# --- WAF (rev 3 -- L7 protection posture) ---

resource "aws_wafv2_web_acl" "api_protection" {
  name  = "serverless-mixed-api-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "serverless-mixed-api-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "protect_prod" {
  resource_arn = aws_api_gateway_stage.public_api_v1_prod_stage.arn
  web_acl_arn  = aws_wafv2_web_acl.api_protection.arn
}

# Deliberately NO association for public_api_v1_staging_stage (negative
# on waf_attached) and NO association for public_api_v2_default_stage
# (mixed: positive on access_logging, negative on waf_attached).
