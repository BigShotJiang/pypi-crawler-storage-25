"""Business logic for ve task init command."""
# Subsystem: docs/subsystems/cross_repo_operations - Cross-repository operations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from git_utils import get_github_org_repo, is_git_repository
from template_system import TaskContext, render_template, render_to_directory


@dataclass
class TaskInitResult:
    """Result of a successful task init."""

    config_path: Path
    external_repo: str
    projects: list[str]
    created_files: list[str] = field(default_factory=list)


def _resolve_repo_path(cwd: Path, repo_ref: str) -> Path | None:
    """Resolve a repo reference to a filesystem path.

    Args:
        cwd: Task directory containing repositories
        repo_ref: Either org/repo format or plain directory name

    Returns:
        Path to the directory if found, None otherwise.
    """
    # If it's org/repo format, extract repo name
    if "/" in repo_ref:
        parts = repo_ref.split("/")
        if len(parts) == 2:
            org, repo = parts
            # Try just repo name first
            simple_path = cwd / repo
            if simple_path.exists() and simple_path.is_dir():
                return simple_path
            # Try nested org/repo
            nested_path = cwd / org / repo
            if nested_path.exists() and nested_path.is_dir():
                return nested_path
            return None

    # Plain directory name
    path = cwd / repo_ref
    if path.exists() and path.is_dir():
        return path
    return None


def _resolve_to_org_repo(cwd: Path, repo_ref: str) -> str:
    """Resolve a repo reference to org/repo format from its git remote.

    Args:
        cwd: Task directory containing repositories
        repo_ref: Either org/repo format or plain directory name

    Returns:
        The org/repo string extracted from the git remote URL

    Raises:
        ValueError: If directory doesn't exist, is not a git repo,
            or has no origin remote configured
    """
    path = _resolve_repo_path(cwd, repo_ref)
    if path is None:
        raise ValueError(f"Directory '{repo_ref}' does not exist")

    return get_github_org_repo(path)


class TaskInit:
    """Initialize a task directory for cross-repository work."""

    def __init__(self, cwd: Path, external: str, projects: list[str]):
        """Create a TaskInit.

        Args:
            cwd: Current working directory where .ve-task.yaml will be created
            external: External chunk repository (org/repo format or plain directory name)
            projects: List of participating projects (org/repo format or plain directory names)
        """
        self.cwd = cwd
        self.external = external
        self.projects = projects
        # Resolved values are populated during validate()
        self._resolved_external: str | None = None
        self._resolved_projects: list[str] | None = None

    def validate(self) -> list[str]:
        """Validate the task init configuration.

        Resolves local directory names to org/repo format from git remotes.

        Returns:
            List of validation error messages, empty if valid.
        """
        errors: list[str] = []

        # Check 1: .ve-task.yaml already exists
        if (self.cwd / ".ve-task.yaml").exists():
            errors.append("Task directory already exists (found .ve-task.yaml)")
            return errors

        # Check 2: No projects specified
        if not self.projects:
            errors.append("At least one --project is required")
            return errors

        # Check 3: Validate and resolve external directory
        external_errors, resolved_external = self._validate_and_resolve(self.external)
        errors.extend(external_errors)
        self._resolved_external = resolved_external

        # Check 4: Validate and resolve each project directory
        resolved_projects = []
        for project in self.projects:
            project_errors, resolved_project = self._validate_and_resolve(project)
            errors.extend(project_errors)
            resolved_projects.append(resolved_project)
        self._resolved_projects = resolved_projects

        return errors

    def _validate_and_resolve(self, repo_ref: str) -> tuple[list[str], str | None]:
        """Validate a directory and resolve it to org/repo format.

        Args:
            repo_ref: Repository reference (org/repo format or plain name)

        Returns:
            Tuple of (error messages, resolved org/repo or None if errors)
        """
        errors: list[str] = []
        path = _resolve_repo_path(self.cwd, repo_ref)

        # Check if directory exists
        if path is None:
            errors.append(f"Directory '{repo_ref}' does not exist")
            return errors, None

        # Check if it's a git repository
        if not is_git_repository(path):
            errors.append(f"Directory '{repo_ref}' is not a git repository")
            return errors, None

        # Check if VE-initialized (docs/chunks/ exists)
        if not (path / "docs" / "chunks").exists():
            errors.append(
                f"Directory '{repo_ref}' is not a Vibe Engineer project (missing docs/chunks/)"
            )
            return errors, None

        # Try to resolve to org/repo from git remote
        try:
            org_repo = get_github_org_repo(path)
            return errors, org_repo
        except ValueError as e:
            # Provide clear error message with original input
            error_msg = str(e)
            if "no origin remote" in error_msg.lower():
                errors.append(f"Directory '{repo_ref}' has no origin remote configured")
            elif "not a github url" in error_msg.lower():
                errors.append(
                    f"Directory '{repo_ref}' remote is not a GitHub URL"
                )
            else:
                errors.append(f"Directory '{repo_ref}': {error_msg}")
            return errors, None

    # Chunk: docs/chunks/agentskills_migration - AGENTS.md as canonical, CLAUDE.md as symlink
    def _render_agents_md(self) -> list[str]:
        """Render the task AGENTS.md template to task root.

        Creates AGENTS.md as the canonical file and a CLAUDE.md symlink
        for backwards compatibility with Claude Code.

        Returns:
            List of created file paths (relative to task root).
        """
        created = []

        # Render to AGENTS.md
        agents_file = self.cwd / "AGENTS.md"
        task_context = TaskContext(
            external_artifact_repo=self.external,
            projects=self.projects,
        )
        rendered = render_template(
            "task", "AGENTS.md.jinja2", **task_context.as_dict()
        )
        agents_file.write_text(rendered)
        created.append("AGENTS.md")

        # Create CLAUDE.md symlink for backwards compatibility
        claude_file = self.cwd / "CLAUDE.md"
        if not claude_file.exists():
            claude_file.symlink_to("AGENTS.md")

        return created

    # Chunk: docs/chunks/agentskills_migration - Skills rendered to .agents/skills/ with symlinks
    def _render_skills(self) -> list[str]:
        """Render skill templates to .agents/skills/ with task context.

        Creates per-file symlinks in .claude/commands/ for backwards compatibility.

        Returns:
            List of created file paths (relative to task root).
        """
        created = []
        skills_dir = self.cwd / ".agents" / "skills"
        commands_dir = self.cwd / ".claude" / "commands"

        task_context = TaskContext(
            external_artifact_repo=self.external,
            projects=self.projects,
        )
        render_result = render_to_directory(
            "commands", skills_dir, skill_layout=True, **task_context.as_dict()
        )

        # Map paths to relative strings
        for path in render_result.created:
            skill_name = path.parent.name
            created.append(f".agents/skills/{skill_name}/SKILL.md")

        # Create .claude/commands/ symlinks for backwards compatibility
        commands_dir.mkdir(parents=True, exist_ok=True)
        for skill_subdir in sorted(skills_dir.iterdir()):
            if not skill_subdir.is_dir():
                continue
            skill_md = skill_subdir / "SKILL.md"
            if not skill_md.exists():
                continue
            skill_name = skill_subdir.name
            link_path = commands_dir / f"{skill_name}.md"
            relative_target = Path("..") / ".." / ".agents" / "skills" / skill_name / "SKILL.md"
            if not link_path.exists():
                link_path.symlink_to(relative_target)

        return created

    def execute(self) -> TaskInitResult:
        """Create the .ve-task.yaml file and scaffolding.

        Should only be called if validate() returns an empty list.

        Returns:
            TaskInitResult with path and configuration details.
        """
        created_files = []

        # Create .ve-task.yaml
        config_path = self.cwd / ".ve-task.yaml"

        # Use resolved values from validate()
        external_repo = self._resolved_external or self.external
        projects = self._resolved_projects or self.projects

        config_data = {
            "external_artifact_repo": external_repo,
            "projects": projects,
        }

        with open(config_path, "w") as f:
            yaml.dump(config_data, f, default_flow_style=False)
        created_files.append(".ve-task.yaml")

        # Render AGENTS.md (with CLAUDE.md symlink)
        created_files.extend(self._render_agents_md())

        # Render skill templates (with .claude/commands/ symlinks)
        created_files.extend(self._render_skills())

        return TaskInitResult(
            config_path=config_path,
            external_repo=external_repo,
            projects=projects,
            created_files=created_files,
        )
