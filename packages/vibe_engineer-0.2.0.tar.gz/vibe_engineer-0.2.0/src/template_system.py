"""Template system module - unified Jinja2 template rendering."""
# Subsystem: docs/subsystems/template_system - Template rendering system
# Subsystem: docs/subsystems/template_system - Unified template rendering
# Chunk: docs/chunks/template_unified_module - Core template system implementation

import pathlib
from dataclasses import dataclass, field

import jinja2
import yaml

from constants import template_dir


# Subsystem: docs/subsystems/cluster_analysis - Chunk naming and clustering
# Subsystem: docs/subsystems/template_system - Unified template rendering
# Chunk: docs/chunks/template_lang_agnostic - Simplified config (removed is_ve_source_repo)
# Chunk: docs/chunks/cluster_subsystem_prompt - cluster_subsystem_threshold configuration field
@dataclass
class VeConfig:
    """VE project configuration loaded from .ve-config.yaml.

    Attributes:
        cluster_subsystem_threshold: Threshold for warning about large prefix
            clusters. When creating a chunk that would be the Nth chunk in a
            cluster (where N >= threshold), a warning is emitted suggesting
            the user consider documenting a subsystem.
    """

    cluster_subsystem_threshold: int = 5  # Default: warn at 5th chunk in cluster

    def as_dict(self) -> dict:
        """Return config as dict suitable for Jinja2 rendering."""
        return {
            "cluster_subsystem_threshold": self.cluster_subsystem_threshold,
        }


# Subsystem: docs/subsystems/template_system - Unified template rendering
# Chunk: docs/chunks/template_lang_agnostic - Config loader (no is_ve_source_repo)
# Chunk: docs/chunks/cluster_subsystem_prompt - Load cluster_subsystem_threshold from config
def load_ve_config(project_dir: pathlib.Path) -> VeConfig:
    """Load .ve-config.yaml from project root.

    Args:
        project_dir: Path to the project root directory.

    Returns:
        VeConfig with values from the config file, or defaults if file is absent.
    """
    config_path = project_dir / ".ve-config.yaml"
    if not config_path.exists():
        return VeConfig()

    with open(config_path) as f:
        data = yaml.safe_load(f) or {}

    return VeConfig(
        cluster_subsystem_threshold=data.get("cluster_subsystem_threshold", 5),
    )


# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class RenderResult:
    """Result of template rendering to a directory.

    Tracks the outcome of rendering templates, categorizing files by
    whether they were created, skipped (existed and not overwritten),
    or overwritten (existed and replaced).
    """

    created: list[pathlib.Path] = field(default_factory=list)
    skipped: list[pathlib.Path] = field(default_factory=list)
    overwritten: list[pathlib.Path] = field(default_factory=list)


# Subsystem: docs/subsystems/template_system - Unified template rendering
# Chunk: docs/chunks/artifact_pattern_consolidation - Base class for active artifact contexts
@dataclass
class ActiveArtifact:
    """Base class for active artifact contexts in template rendering.

    Captures the common properties shared across all workflow artifact types
    (chunk, narrative, subsystem, investigation). Subclasses add artifact-specific
    path properties.
    """

    short_name: str
    id: str
    _project_dir: pathlib.Path

    @property
    def artifact_dir(self) -> pathlib.Path:
        """Return path to this artifact's directory.

        Subclasses override _artifact_type_dir to customize the directory name.
        """
        return self._project_dir / "docs" / self._artifact_type_dir / self.id

    @property
    def _artifact_type_dir(self) -> str:
        """Return the artifact type directory name (e.g., 'chunks', 'narratives').

        Subclasses override this to specify their directory.
        """
        raise NotImplementedError("Subclasses must implement _artifact_type_dir")


# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class ActiveChunk(ActiveArtifact):
    """Represents an active chunk context for template rendering."""

    @property
    def _artifact_type_dir(self) -> str:
        return "chunks"

    @property
    def goal_path(self) -> pathlib.Path:
        """Return path to this chunk's GOAL.md file."""
        return self.artifact_dir / "GOAL.md"

    @property
    def plan_path(self) -> pathlib.Path:
        """Return path to this chunk's PLAN.md file."""
        return self.artifact_dir / "PLAN.md"


# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class ActiveNarrative(ActiveArtifact):
    """Represents an active narrative context for template rendering."""

    @property
    def _artifact_type_dir(self) -> str:
        return "narratives"

    @property
    def overview_path(self) -> pathlib.Path:
        """Return path to this narrative's OVERVIEW.md file."""
        return self.artifact_dir / "OVERVIEW.md"


# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class ActiveSubsystem(ActiveArtifact):
    """Represents an active subsystem context for template rendering."""

    @property
    def _artifact_type_dir(self) -> str:
        return "subsystems"

    @property
    def overview_path(self) -> pathlib.Path:
        """Return path to this subsystem's OVERVIEW.md file."""
        return self.artifact_dir / "OVERVIEW.md"


# Subsystem: docs/subsystems/workflow_artifacts - Workflow artifact lifecycle
# Chunk: docs/chunks/investigation_commands - Template context for investigation rendering
@dataclass
class ActiveInvestigation(ActiveArtifact):
    """Represents an active investigation context for template rendering."""

    @property
    def _artifact_type_dir(self) -> str:
        return "investigations"

    @property
    def overview_path(self) -> pathlib.Path:
        """Return path to this investigation's OVERVIEW.md file."""
        return self.artifact_dir / "OVERVIEW.md"


# Migration context for templates
@dataclass
class ActiveMigration:
    """Represents an active migration context for template rendering."""

    migration_type: str
    source_type: str  # "chunks" or "code_only"
    _project_dir: pathlib.Path

    @property
    def migration_path(self) -> pathlib.Path:
        """Return path to this migration's MIGRATION.md file."""
        return self._project_dir / "docs" / "migrations" / self.migration_type / "MIGRATION.md"

    @property
    def migration_dir(self) -> pathlib.Path:
        """Return path to this migration's directory."""
        return self._project_dir / "docs" / "migrations" / self.migration_type


# Subsystem: docs/subsystems/cross_repo_operations - Cross-repository operations
# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class TaskContext:
    """Holds task-level context for template rendering.

    Used when rendering templates in a task directory context, where artifacts
    are created in an external repo and implementation spans multiple projects.
    """

    external_artifact_repo: str
    projects: list[str]
    task_context: bool = True  # Flag for conditional blocks in templates

    def as_dict(self) -> dict:
        """Return context as dict suitable for Jinja2 rendering."""
        return {
            "external_artifact_repo": self.external_artifact_repo,
            "projects": self.projects,
            "task_context": self.task_context,
        }


# Subsystem: docs/subsystems/template_system - Unified template rendering
@dataclass
class TemplateContext:
    """Holds project-level context for template rendering.

    Only one active artifact (chunk, narrative, subsystem, investigation, or migration) can be set at a time.
    """

    active_chunk: ActiveChunk | None = None
    active_narrative: ActiveNarrative | None = None
    active_subsystem: ActiveSubsystem | None = None
    active_investigation: ActiveInvestigation | None = None
    active_migration: ActiveMigration | None = None

    def __post_init__(self):
        count = sum(
            1
            for x in [self.active_chunk, self.active_narrative, self.active_subsystem, self.active_investigation, self.active_migration]
            if x is not None
        )
        if count > 1:
            raise ValueError("Only one active artifact allowed")

    def as_dict(self) -> dict:
        """Return context as dict suitable for Jinja2 rendering."""
        return {"project": self}


# Subsystem: docs/subsystems/template_system - Unified template rendering
def list_templates(collection: str) -> list[str]:
    """List template files in a collection (excludes partials/ and hidden files).

    Args:
        collection: Name of the template collection (e.g., "chunk", "narrative").

    Returns:
        List of template filenames. Empty list if collection doesn't exist.
    """
    collection_dir = template_dir / collection
    if not collection_dir.exists():
        return []
    return [
        f.name
        for f in collection_dir.iterdir()
        if f.is_file() and not f.name.startswith(".")
    ]


# Cache for Jinja2 environments per collection
_environments: dict[str, jinja2.Environment] = {}


# Subsystem: docs/subsystems/template_system - Unified template rendering
def get_environment(collection: str) -> jinja2.Environment:
    """Get or create a Jinja2 Environment for a template collection.

    The Environment is configured with a FileSystemLoader pointing to the
    collection directory, allowing templates to include files from the
    same collection (e.g., partials/).

    Args:
        collection: Name of the template collection (e.g., "chunk", "narrative").

    Returns:
        Jinja2 Environment configured for the collection.
    """
    if collection not in _environments:
        collection_dir = template_dir / collection
        loader = jinja2.FileSystemLoader(str(collection_dir))
        _environments[collection] = jinja2.Environment(loader=loader)
    return _environments[collection]


# Subsystem: docs/subsystems/template_system - Unified template rendering
def render_template(
    collection: str,
    template_name: str,
    context: TemplateContext | None = None,
    **kwargs,
) -> str:
    """Render a template from a collection with the given context.

    Args:
        collection: Name of the template collection (e.g., "chunk", "narrative").
        template_name: Name of the template file within the collection.
        context: Optional TemplateContext providing project-level context.
        **kwargs: Additional variables to pass to the template.

    Returns:
        Rendered template content as a string.

    Raises:
        jinja2.TemplateNotFound: If the template doesn't exist.
    """
    env = get_environment(collection)
    template = env.get_template(template_name)

    render_context = {}
    if context:
        render_context.update(context.as_dict())
    render_context.update(kwargs)

    return template.render(**render_context)


# Subsystem: docs/subsystems/template_system - Unified template rendering
# Chunk: docs/chunks/agentskills_migration - Added skill_layout parameter for agentskills.io directory structure
def render_to_directory(
    collection: str,
    dest_dir: pathlib.Path,
    context: TemplateContext | None = None,
    overwrite: bool = False,
    skill_layout: bool = False,
    **kwargs,
) -> RenderResult:
    """Render all templates in a collection to a destination directory.

    Files with .jinja2 suffix will have that suffix stripped in the output.
    Files in partials/ subdirectories are excluded (they're meant to be included).

    When skill_layout=True, each template renders to dest_dir/<name>/SKILL.md
    instead of dest_dir/<name>.md, following the agentskills.io directory spec.

    Args:
        collection: Name of the template collection (e.g., "chunk", "narrative").
        dest_dir: Destination directory for rendered files.
        context: Optional TemplateContext providing project-level context.
        overwrite: If True, replace existing files; if False, skip them.
        skill_layout: If True, render to <name>/SKILL.md subdirectories.
        **kwargs: Additional variables to pass to each template.

    Returns:
        RenderResult with created, skipped, and overwritten file paths.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    result = RenderResult()

    for template_name in list_templates(collection):
        # Strip .jinja2 suffix for output filename
        output_name = template_name
        if output_name.endswith(".jinja2"):
            output_name = output_name[:-7]  # Remove ".jinja2"

        if skill_layout:
            # agentskills.io layout: <name>/SKILL.md
            # Strip .md to get the skill name (e.g., "chunk-create.md" -> "chunk-create")
            skill_name = output_name
            if skill_name.endswith(".md"):
                skill_name = skill_name[:-3]
            skill_dir = dest_dir / skill_name
            skill_dir.mkdir(parents=True, exist_ok=True)
            output_path = skill_dir / "SKILL.md"
        else:
            output_path = dest_dir / output_name

        if output_path.exists():
            if overwrite:
                rendered = render_template(collection, template_name, context, **kwargs)
                output_path.write_text(rendered)
                result.overwritten.append(output_path)
            else:
                result.skipped.append(output_path)
        else:
            rendered = render_template(collection, template_name, context, **kwargs)
            output_path.write_text(rendered)
            result.created.append(output_path)

    return result
