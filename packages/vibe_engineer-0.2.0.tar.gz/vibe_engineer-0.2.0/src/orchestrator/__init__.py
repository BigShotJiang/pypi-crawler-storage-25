# Subsystem: docs/subsystems/orchestrator - Parallel agent orchestration
# Chunk: docs/chunks/orch_foundation - Core orchestrator package and exports
# Chunk: docs/chunks/orch_scheduling - Package exports for scheduling layer components
"""Orchestrator package for parallel agent work management."""

from orchestrator.models import (
    AgentResult,
    OrchestratorConfig,
    OrchestratorState,
    WorkUnit,
    WorkUnitPhase,
    WorkUnitStatus,
)
# Chunk: docs/chunks/optimistic_locking - Export StaleWriteError for optimistic locking
from orchestrator.state import StateStore, StaleWriteError, get_default_db_path
from orchestrator.daemon import (
    DaemonError,
    start_daemon,
    stop_daemon,
    is_daemon_running,
    get_daemon_status,
    get_pid_path,
    get_socket_path,
    get_log_path,
)
from orchestrator.client import (
    OrchestratorClient,
    OrchestratorClientError,
    DaemonNotRunningError,
    create_client,
)
from orchestrator.api import create_app
from orchestrator.worktree import (
    WorktreeError,
    WorktreeManager,
)
from orchestrator.agent import (
    AgentRunner,
    AgentRunnerError,
    PHASE_SKILL_FILES,
)
from orchestrator.scheduler import (
    Scheduler,
    SchedulerError,
    create_scheduler,
)
# Chunk: docs/chunks/orch_cli_extract - Dependency resolution functions extracted from CLI layer
from orchestrator.dependencies import (
    topological_sort_chunks,
    read_chunk_dependencies,
    validate_external_dependencies,
)

__all__ = [
    # Models
    "AgentResult",
    "OrchestratorConfig",
    "OrchestratorState",
    "WorkUnit",
    "WorkUnitPhase",
    "WorkUnitStatus",
    # State
    "StateStore",
    "StaleWriteError",
    "get_default_db_path",
    # Daemon
    "DaemonError",
    "start_daemon",
    "stop_daemon",
    "is_daemon_running",
    "get_daemon_status",
    "get_pid_path",
    "get_socket_path",
    "get_log_path",
    # Client
    "OrchestratorClient",
    "OrchestratorClientError",
    "DaemonNotRunningError",
    "create_client",
    # API
    "create_app",
    # Worktree
    "WorktreeError",
    "WorktreeManager",
    # Agent
    "AgentRunner",
    "AgentRunnerError",
    "PHASE_SKILL_FILES",
    # Scheduler
    "Scheduler",
    "SchedulerError",
    "create_scheduler",
    # Dependencies
    "topological_sort_chunks",
    "read_chunk_dependencies",
    "validate_external_dependencies",
]
