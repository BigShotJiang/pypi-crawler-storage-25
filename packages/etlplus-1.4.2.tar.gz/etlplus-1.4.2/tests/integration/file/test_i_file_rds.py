"""
:mod:`tests.integration.file.test_i_file_rds` module.

Integration smoke tests for :mod:`etlplus.file.rds`.
"""

from __future__ import annotations

from etlplus.file import rds as mod

from .conftest import SmokeRoundtripModuleContract

# SECTION: PRAGMAS ========================================================== #

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

# SECTION: TESTS ============================================================ #


class TestRds(SmokeRoundtripModuleContract):
    """Integration smoke tests for :mod:`etlplus.file.rds`."""

    module = mod
