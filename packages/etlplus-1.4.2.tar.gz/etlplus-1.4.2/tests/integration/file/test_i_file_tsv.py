"""
:mod:`tests.integration.file.test_i_file_tsv` module.

Integration smoke tests for :mod:`etlplus.file.tsv`.
"""

from __future__ import annotations

from etlplus.file import tsv as mod

from .conftest import SmokeRoundtripModuleContract

# SECTION: PRAGMAS ========================================================== #

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

# SECTION: TESTS ============================================================ #


class TestTsv(SmokeRoundtripModuleContract):
    """Integration smoke tests for :mod:`etlplus.file.tsv`."""

    module = mod
