CMD = """\
bioconvert {params.command} {input} {output} --verbosity ERROR --force {params.method} >{log} 2>&1
"""
