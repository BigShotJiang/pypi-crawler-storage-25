"""OpenClaw installation auto-discovery.

Loads scan-point path definitions from
``clawaudit/data/openclaw_layout.yaml`` and resolves them at runtime.

Core interface:
    ``files_for(check_id)``  — returns categorized file paths for a check
    ``state_dir``            — OpenClaw state directory
    ``workspace_dir``        — workspace directory
    ``version``              — detected OpenClaw version
"""

import os
import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import yaml

# ---------------------------------------------------------------------------
# Schema loading
# ---------------------------------------------------------------------------

_LAYOUT_PATH = Path(__file__).resolve().parent.parent / "data" / "openclaw_layout.yaml"
_PKG_DIR = Path(__file__).resolve().parent.parent

def _load_layout() -> Dict[str, Any]:
    """Load openclaw_layout.yaml once at import time."""
    return yaml.safe_load(_LAYOUT_PATH.read_text(encoding="utf-8"))

_LAYOUT: Dict[str, Any] = _load_layout()

# Derived from schema — runtime config lives under "runtime" key
_RUNTIME: Dict[str, Any] = _LAYOUT.get("runtime", {})
CONFIG_FILE_NAMES: List[str] = _RUNTIME.get("config_file_names", [])

# Build check_id → rule lookup from rules list
_RULES_BY_ID: Dict[str, Dict[str, Any]] = {
    rule["id"]: rule for rule in _LAYOUT.get("rules", []) if "id" in rule
}

BINARY_EXTS: Set[str] = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp",
    ".zip", ".gz", ".tar", ".bin", ".woff", ".woff2",
}

# ---------------------------------------------------------------------------
# Discovery class
# ---------------------------------------------------------------------------


class OpenClawDiscovery:
    """Discover OpenClaw installation paths and resolve scan-point files.

    Path definitions for each check ID live in
    ``clawaudit/data/openclaw_layout.yaml`` under the ``checks:`` section.
    """

    def __init__(self, explicit_path: Optional[str] = None):
        self.explicit_path = explicit_path
        self._discovered = False
        self._state_dir: Optional[Path] = None
        self._config_files: List[Path] = []
        self._version: Optional[str] = None
        self._layout = _LAYOUT

    # ------------------------------------------------------------------
    # Core properties
    # ------------------------------------------------------------------

    @property
    def state_dir(self) -> Optional[Path]:
        if not self._discovered:
            self._discover()
        return self._state_dir

    @property
    def config_files(self) -> List[Path]:
        if not self._discovered:
            self._discover()
        return self._config_files

    @property
    def version(self) -> Optional[str]:
        if self._version is None:
            self._detect_version()
        return self._version

    @property
    def workspace_dir(self) -> Optional[Path]:
        """Workspace directory (supports agents.defaults.workspace config)."""
        if hasattr(self, "_workspace_dir_cache"):
            return self._workspace_dir_cache

        result = None

        # Check config for custom workspace path
        ws_cfg = _RUNTIME.get("workspace", {})
        config_key = ws_cfg.get("config_key")
        if config_key:
            keys = config_key.split(".")
            for f in self.config_files:
                if f.suffix != ".json":
                    continue
                try:
                    config = self.read_config(f)
                except Exception:
                    continue
                val = config
                for k in keys:
                    if not isinstance(val, dict):
                        val = None
                        break
                    val = val.get(k)
                if val and isinstance(val, str):
                    expanded = Path(os.path.expanduser(val))
                    if expanded.is_dir():
                        result = expanded
                        break

        # Fallback: state_dir/workspace
        if result is None and self.state_dir:
            default_ws = self.state_dir / "workspace"
            if default_ws.is_dir():
                result = default_ws

        self._workspace_dir_cache = result
        return result

    # ------------------------------------------------------------------
    # files_for() — yaml-driven path resolution
    # ------------------------------------------------------------------

    def files_for(self, check_id: str) -> Dict[str, Any]:
        """Resolve file paths for *check_id* from yaml ``rules:`` section.

        Returns a dict with:
        - ``"match"``: list of resolved match entries, each containing
          ``type``, ``paths`` (List[Path]), and optionally ``keypaths``,
          ``patterns``, ``name``.
        - Metadata fields (``remediation``, ``thresholds``, etc.) are
          passed through as-is.
        """
        rule = _RULES_BY_ID.get(check_id)
        if not rule:
            return {}

        result: Dict[str, Any] = {}
        vars_ = self._template_vars()

        # Resolve match entries
        match_defs = rule.get("match", [])
        resolved_match: List[Dict[str, Any]] = []
        for m in match_defs:
            entry: Dict[str, Any] = {"type": m.get("type", "text")}
            if "name" in m:
                entry["name"] = m["name"]
            if "keypaths" in m:
                entry["keypaths"] = m["keypaths"]
            if "patterns" in m:
                entry["patterns"] = m["patterns"]
            # Resolve glob paths
            raw_paths = m.get("paths", [])
            if raw_paths and isinstance(raw_paths[0], str) and raw_paths[0].endswith("/"):
                entry["paths"] = self._resolve_dirs(raw_paths, vars_)
            else:
                entry["paths"] = self._resolve_files(raw_paths, vars_)
            resolved_match.append(entry)
        result["match"] = resolved_match

        # Pass through metadata (remediation, thresholds, weak_values, etc.)
        for key, val in rule.items():
            if key not in ("id", "info", "match"):
                if key == "system_critical_files":
                    result[key] = self._resolve_system_critical(val)
                else:
                    result[key] = val
        return result

    def _template_vars(self) -> Dict[str, str]:
        """Build variable substitution context."""
        state = str(self.state_dir) if self.state_dir else ""
        workspace = str(self.workspace_dir) if self.workspace_dir else ""
        return {
            "state_dir": state,
            "workspace": workspace,
            "pkg_dir": str(_PKG_DIR),
        }

    def _resolve_files(self, patterns: List[str], vars_: Dict[str, str]) -> List[Path]:
        """Resolve file patterns to existing file paths."""
        files: List[Path] = []
        seen: Set[Path] = set()
        for pat in patterns:
            # Skip patterns with unresolved variables (e.g. state_dir is None)
            if any(f"{{{k}}}" in pat and not v for k, v in vars_.items()):
                continue
            expanded = os.path.expanduser(self._subst(pat, vars_))
            if not expanded:
                continue
            if "*" in expanded:
                # Split at first glob segment to get base dir + glob pattern
                p = Path(expanded)
                parts = p.parts
                base_parts = []
                glob_parts = []
                hit_glob = False
                for part in parts:
                    if hit_glob or "*" in part:
                        hit_glob = True
                        glob_parts.append(part)
                    else:
                        base_parts.append(part)
                base = Path(*base_parts) if base_parts else Path(".")
                glob_pat = str(Path(*glob_parts)) if glob_parts else "*"
                if not base.is_dir():
                    continue
                for f in base.glob(glob_pat):
                    if f.is_file() and f.suffix not in BINARY_EXTS:
                        resolved = f.resolve()
                        if ".git" not in f.parts and resolved not in seen:
                            seen.add(resolved)
                            files.append(f)
            else:
                p = Path(expanded)
                if p.is_file():
                    files.append(p)
        return files

    def _resolve_dirs(
        self, patterns: List[str], vars_: Dict[str, str]
    ) -> List[Path]:
        """Resolve directory patterns to existing directory paths."""
        dirs: List[Path] = []
        for pat in patterns:
            if any(f"{{{k}}}" in pat and not v for k, v in vars_.items()):
                continue
            expanded = os.path.expanduser(self._subst(pat, vars_))
            if not expanded:
                continue
            p = Path(expanded.rstrip("/"))
            if p not in dirs:
                dirs.append(p)
        return dirs

    def _resolve_system_critical(
        self, entries: List[Dict]
    ) -> List[Tuple[Path, str, int, str]]:
        """Resolve system_critical_files structured entries."""
        result = []
        for entry in entries:
            path = Path(os.path.expanduser(entry["path"]))
            result.append((
                path,
                entry["check"],
                int(entry["bad_bits"]),
                entry["fix"],
            ))
        return result

    @staticmethod
    def _subst(template: str, vars_: Dict[str, str]) -> str:
        """Substitute {var} placeholders in a path template."""
        result = template
        for key, val in vars_.items():
            result = result.replace("{" + key + "}", val)
        return result

    # ------------------------------------------------------------------
    # Version compatibility
    # ------------------------------------------------------------------

    def check_version_compatibility(self) -> Optional[str]:
        """Compare detected OpenClaw version against schema bounds.

        Returns a warning string if out of range, else ``None``.
        """
        ver = self.version
        if not ver:
            return None

        from packaging.version import Version, InvalidVersion
        supported = _RUNTIME.get("supported_versions", {})
        min_ver = supported.get("min")
        max_ver = supported.get("max")

        try:
            current = Version(ver)
        except InvalidVersion:
            return None

        warnings = []
        if min_ver:
            try:
                if current < Version(min_ver):
                    warnings.append(
                        f"OpenClaw {ver} is below minimum supported version {min_ver}"
                    )
            except InvalidVersion:
                pass
        if max_ver and not max_ver.endswith(".x"):
            try:
                if current > Version(max_ver):
                    warnings.append(
                        f"OpenClaw {ver} exceeds maximum supported version {max_ver}"
                    )
            except InvalidVersion:
                pass

        return "; ".join(warnings) if warnings else None

    # ------------------------------------------------------------------
    # Internals — discovery
    # ------------------------------------------------------------------

    def _candidate_dirs(self) -> List[Path]:
        """Return candidate directories in priority order (driven by schema)."""
        dirs: List[Path] = []

        if self.explicit_path:
            dirs.append(Path(self.explicit_path))
            return dirs

        # Environment variables from runtime config
        state_cfg = _RUNTIME.get("state_dir", {})
        # Primary env var
        primary_env = state_cfg.get("env")
        if primary_env:
            val = os.environ.get(primary_env)
            if val:
                dirs.append(Path(os.path.expanduser(val)))
        # Legacy env vars
        for var in state_cfg.get("legacy_env", []):
            val = os.environ.get(var)
            if val:
                dirs.append(Path(os.path.expanduser(val)))

        # Default state directory
        default_dir = state_cfg.get("default", "~/.openclaw")
        dirs.append(Path(os.path.expanduser(default_dir)))

        # Legacy aliases
        for alias in state_cfg.get("legacy_aliases", []):
            dirs.append(Path(os.path.expanduser(alias)))

        # System-wide locations
        dirs.extend([
            Path("/opt/openclaw"),
            Path("/etc/openclaw"),
            Path.cwd(),
        ])

        return dirs

    def _discover(self) -> None:
        """Run discovery and populate state_dir, config_files, config_dirs."""
        seen: set = set()

        for d in self._candidate_dirs():
            if not d.exists() or not d.is_dir():
                continue
            real = d.resolve()
            if real in seen:
                continue
            seen.add(real)

            found_any = False
            for name in CONFIG_FILE_NAMES:
                f = d / name
                if f.is_file():
                    self._config_files.append(f)
                    found_any = True

            if found_any:
                if self._state_dir is None:
                    self._state_dir = d

        self._discovered = True

    def _detect_version(self) -> None:
        """Try to detect OpenClaw version."""
        import re

        # Method 1: openclaw --version
        try:
            result = subprocess.run(
                ["openclaw", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                match = re.search(r"(\d+\.\d+\.\d+(?:-\d+)?)", result.stdout)
                if match:
                    self._version = match.group(1)
                    return
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Method 2: package.json in state dir
        if self.state_dir:
            pkg_json = self.state_dir / "package.json"
            if pkg_json.is_file():
                try:
                    data = json.loads(pkg_json.read_text())
                    self._version = data.get("version")
                    return
                except (json.JSONDecodeError, OSError):
                    pass

    def _get_extra_dirs(self, kind: str) -> List[Path]:
        """Read extra directories from config (e.g. skills.load.extraDirs)."""
        config_key = (_RUNTIME
                      .get("extra_dirs", {})
                      .get(kind))
        if not config_key:
            return []

        keys = config_key.split(".")
        for f in self.config_files:
            if f.suffix != ".json":
                continue
            try:
                config = self.read_config(f)
            except Exception:
                continue
            val = config
            for k in keys:
                if not isinstance(val, dict):
                    val = None
                    break
                val = val.get(k)
            if isinstance(val, list):
                return [
                    Path(os.path.expanduser(p))
                    for p in val
                    if isinstance(p, str)
                ]
        return []

    # ------------------------------------------------------------------
    # Config utilities
    # ------------------------------------------------------------------

    def read_config(self, path: Path) -> Dict[str, Any]:
        """Read and parse a config file (JSON or YAML)."""
        text = path.read_text(encoding="utf-8", errors="ignore")

        if path.suffix == ".json":
            return json.loads(text)

        if path.suffix in (".yaml", ".yml"):
            try:
                return yaml.safe_load(text) or {}
            except Exception:
                return {}

        # .env -> key=value
        if path.name == ".env":
            result: Dict[str, Any] = {}
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, _, v = line.partition("=")
                    result[k.strip()] = v.strip().strip("'\"")
            return result

        return {}

