# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ClusterConfigurationsSpec:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'packages': 'list[ClusterConfigurationsSpecPackages]'
    }

    attribute_map = {
        'packages': 'packages'
    }

    def __init__(self, packages=None):
        r"""ClusterConfigurationsSpec

        The model defined in huaweicloud sdk

        :param packages: 组件配置项列表
        :type packages: list[:class:`huaweicloudsdkcce.v3.ClusterConfigurationsSpecPackages`]
        """
        
        

        self._packages = None
        self.discriminator = None

        self.packages = packages

    @property
    def packages(self):
        r"""Gets the packages of this ClusterConfigurationsSpec.

        组件配置项列表

        :return: The packages of this ClusterConfigurationsSpec.
        :rtype: list[:class:`huaweicloudsdkcce.v3.ClusterConfigurationsSpecPackages`]
        """
        return self._packages

    @packages.setter
    def packages(self, packages):
        r"""Sets the packages of this ClusterConfigurationsSpec.

        组件配置项列表

        :param packages: The packages of this ClusterConfigurationsSpec.
        :type packages: list[:class:`huaweicloudsdkcce.v3.ClusterConfigurationsSpecPackages`]
        """
        self._packages = packages

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ClusterConfigurationsSpec):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
