"""Models for conversation-related data structures."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from codemie_sdk.models.assistant import ContextType


class Conversation(BaseModel):
    """
    Model for conversation summary data as returned from the list endpoint.
    """

    id: str
    name: str
    folder: str | None
    pinned: bool
    date: str
    assistant_ids: list[str]
    initial_assistant_id: str | None


class Mark(BaseModel):
    """Model for conversation review/mark data."""

    mark: str
    rating: int
    comments: str
    date: datetime
    operator: Operator | None = None


class Operator(BaseModel):
    """Represents an operator involved in marking a conversation."""

    user_id: str
    name: str


class Thought(BaseModel):
    """Model for reasoning or tool-invocation within a message's history."""

    id: str
    parent_id: str | None
    metadata: dict
    in_progress: bool
    input_text: str | None
    message: str | None
    author_type: str
    author_name: str
    output_format: str | None
    error: bool | None
    children: list[str]


class HistoryMark(BaseModel):
    """Model for conversation history review/mark data."""

    mark: str
    rating: int
    comments: str | None
    date: datetime


class HistoryItem(BaseModel):
    """Represents an individual message within a conversation's history."""

    role: str
    message: str
    historyIndex: int
    date: datetime
    responseTime: float | None = None
    inputTokens: int | None = None
    outputTokens: int | None = None
    cacheCreationInputTokens: int | None = None
    cacheReadInputTokens: int | None = None
    moneySpent: float | None = None
    userMark: HistoryMark | None = None
    operatorMark: HistoryMark | None = None
    messageRaw: str | None = None
    fileNames: list[str]
    assistantId: str | None = None
    thoughts: list[Thought] | None = Field(default_factory=list)
    workflowExecutionRef: str | bool | None = None
    executionId: str | None = None


class ContextItem(BaseModel):
    """Represents contextual settings for conversation."""

    context_type: ContextType | None
    name: str


class ToolItem(BaseModel):
    """Represents a tool used by an assistant, including configuration and description."""

    name: str
    label: str | None
    settings_config: bool | None
    description: str | None = None
    user_description: str | None


class AssistantDataItem(BaseModel):
    """Model represents details for an assistant included in a conversation."""

    assistant_id: str
    assistant_name: str
    assistant_icon: str | None
    assistant_type: str | None
    context: list[ContextItem | str] | None = None
    tools: list[ToolItem] | None = None
    conversation_starters: list[str] = []


class ConversationDetailsData(BaseModel):
    """Extended details about a conversation's configuration and context."""

    llm_model: str | None
    context: list[ContextItem]
    app_name: str | None
    repo_name: str | None
    index_type: str | None


class AssistantDetailsData(BaseModel):
    """Extended details about an assistant included in a conversation."""

    assistant_id: str
    assistant_name: str
    assistant_icon: str | None
    assistant_type: str | None
    context: list[ContextItem | str]
    tools: list[ToolItem]
    conversation_starters: list[str]


class ConversationCreateRequest(BaseModel):
    """Model for creating a new conversation."""

    initial_assistant_id: str | None = None
    folder: str | None = None
    mcp_server_single_usage: bool | None = False
    is_workflow_conversation: bool | None = Field(
        default=None, serialization_alias="is_workflow"
    )


class ConversationDetails(BaseModel):
    """Summary information for a user conversation as returned from list endpoints."""

    id: str
    date: datetime
    update_date: datetime
    conversation_id: str
    conversation_name: str
    llm_model: str | None
    folder: str | None
    pinned: bool
    history: list[HistoryItem]
    user_id: str
    user_name: str
    assistant_ids: list[str]
    assistant_data: list[AssistantDataItem]
    initial_assistant_id: str
    final_user_mark: Mark | None
    final_operator_mark: Mark | None
    project: str | None
    conversation_details: ConversationDetailsData | None
    assistant_details: AssistantDetailsData | None
    user_abilities: list[str] | None
    is_folder_migrated: bool
    is_workflow_conversation: bool | None = None
    category: str | None
    mcp_server_single_usage: bool | None = False


class ConversationShareRequest(BaseModel):
    """Model for creating share conversation request."""

    chat_id: str


class ConversationShareResponse(BaseModel):
    """Model for conversation share response."""

    share_id: str
    token: str
    created_at: str
    access_count: int


class SharedConversationResponse(BaseModel):
    """Model for shared conversation details response."""

    conversation: ConversationDetails
    shared_by: str
    created_at: str
    access_count: int


class BaseResponse(BaseModel):
    """Generic base response model with message field."""

    message: str


class UpdateConversationRequest(BaseModel):
    """Model for updating an existing conversation."""

    name: str | None = None
    folder: str | None = None
    pinned: bool | None = None


class ConversationFolder(BaseModel):
    """Model for conversation folder metadata."""

    id: str
    user_id: str
    folder_name: str
    date: str
    update_date: str
    user_abilities: list[str]


class UpdateConversationFolderRequest(BaseModel):
    """Model for creating or updating a folder name."""

    folder: str


class UpdateHistoryByIndexRequest(BaseModel):
    """Model for updating message content in conversation history by index."""

    messageIndex: int
    message: str


class UpsertHistoryRequest(BaseModel):
    """Model for upserting conversation history."""

    history: list[HistoryItem]
    assistant_id: str | None = None
    folder: str | None = None


class UpsertHistoryResponse(BaseModel):
    """Response model for conversation history upsert operation."""

    conversation_id: str
    new_messages: int
    total_messages: int
    created: bool
