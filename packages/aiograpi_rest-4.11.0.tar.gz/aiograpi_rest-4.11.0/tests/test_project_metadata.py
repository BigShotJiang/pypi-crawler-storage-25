import json
import os
import re
import subprocess
import sys
import tomllib
from importlib.metadata import PackageNotFoundError
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
NODE24_ACTION_VERSIONS = {
    "actions/checkout": "v6.0.2",
    "actions/setup-python": "v6.2.0",
    "docker/build-push-action": "v7.1.0",
    "docker/login-action": "v4.1.0",
    "docker/metadata-action": "v6.0.0",
    "docker/setup-buildx-action": "v4.0.0",
    "docker/setup-qemu-action": "v4.0.0",
    "softprops/action-gh-release": "v3.0.0",
}


def project_version() -> str:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    return pyproject["project"]["version"]


def test_pyproject_replaces_requirements_txt():
    assert not (ROOT / "requirements.txt").exists()
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    deps = pyproject["project"]["dependencies"]
    assert "aiograpi==0.9.7" in deps
    assert pyproject["project"]["requires-python"] == ">=3.13"
    assert pyproject["project"]["name"] == "aiograpi-rest"
    assert re.fullmatch(r"\d+\.\d+\.\d+", pyproject["project"]["version"])
    assert pyproject["project"]["urls"]["Repository"] == "https://github.com/subzeroid/aiograpi-rest"


def test_fastapi_project_uses_package_layout():
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    assert "py-modules" not in pyproject["tool"]["setuptools"]
    assert pyproject["tool"]["setuptools"]["packages"]["find"]["include"] == ["aiograpi_rest*"]
    assert (ROOT / "aiograpi_rest" / "main.py").exists()
    assert (ROOT / "aiograpi_rest" / "routers" / "auth.py").exists()
    assert not (ROOT / "main.py").exists()
    assert not (ROOT / "routers").exists()


def test_repository_does_not_track_legacy_platform_artifacts():
    for path in ("Procfile", "app.json", "runtime.txt", "logo.png"):
        assert not (ROOT / path).exists()
    assert not (ROOT / "docs" / "superpowers").exists()


def test_markdown_files_match_current_project_identity():
    docs = [
        ROOT / "README.md",
        ROOT / "docs" / "index.md",
        ROOT / "docs" / "getting-started.md",
        ROOT / "docs" / "api.md",
        ROOT / "docs" / "client-generation.md",
        ROOT / "golang" / "README.md",
        ROOT / "swift" / "README.md",
        ROOT / "examples" / "README.md",
        ROOT / ".github" / "ISSUE_TEMPLATE" / "bug_report.md",
        ROOT / ".github" / "ISSUE_TEMPLATE" / "feature_request.md",
    ]
    combined = "\n".join(path.read_text() for path in docs)
    assert "uvicorn main:app" not in combined
    assert "Instagrapi SaaS" not in combined
    assert "Python version [e.g. 3.8.3]" not in combined
    assert "instagrapi version [e.g. 1.9.3" not in combined
    assert "moveipy version" not in combined
    assert "imagemagick version" not in combined
    assert "required for photo upload" not in combined
    assert "minimal example clients" in combined
    assert "not generated SDKs" in combined
    assert "typescript-fetch" in combined
    assert "swift5" in combined
    assert "cpp-restsdk" in combined
    assert "csharp" in combined
    assert "erlang-client" in combined
    assert "elixir" in combined
    assert "nim" in combined
    assert "haskell-http-client" in combined
    assert "clojure" in combined
    assert "julia-client" in combined
    assert "kotlin" in combined
    assert "scala-sttp4" in combined
    assert "ocaml" in combined
    assert "crystal" in combined
    assert "rust" in combined
    assert "objc" in combined
    assert "perl" in combined
    assert "lua" in combined
    assert "php" in combined
    assert "postman-collection" in combined
    assert "D, Common Lisp, Pascal, or Visual Basic" in combined
    assert "X-Session-ID" in combined
    assert "aiograpi_rest.main:app" in combined
    assert "client-generation.md" in (ROOT / "mkdocs.yml").read_text()


def test_swift_example_uses_current_rest_session_flow():
    swift_client = (ROOT / "swift" / "client.swift").read_text()

    assert "AIOGRAPI_REST_BASE_URL" in swift_client
    assert "AIOGRAPI_REST_SESSIONID" in swift_client
    assert "AIOGRAPI_REST_USERNAME" in swift_client
    assert "AIOGRAPI_REST_PASSWORD" in swift_client
    assert "AIOGRAPI_REST_USER_ID" in swift_client
    assert "X-Session-ID" in swift_client
    assert '"/health"' in swift_client
    assert '"/deps"' in swift_client
    assert '"/auth/login"' in swift_client
    assert '"/user/about"' in swift_client
    assert "pk_from_code" not in swift_client


def test_go_example_uses_current_rest_session_flow():
    go_client = (ROOT / "golang" / "client.go").read_text()
    go_mod = (ROOT / "golang" / "go.mod").read_text()

    assert "AIOGRAPI_REST_BASE_URL" in go_client
    assert "AIOGRAPI_REST_SESSIONID" in go_client
    assert "AIOGRAPI_REST_USERNAME" in go_client
    assert "AIOGRAPI_REST_PASSWORD" in go_client
    assert "AIOGRAPI_REST_USER_ID" in go_client
    assert "X-Session-ID" in go_client
    assert '"/health"' in go_client
    assert '"/deps"' in go_client
    assert '"/auth/login"' in go_client
    assert '"/user/about"' in go_client
    assert "sessionid" not in go_client
    assert "pkFromCode" not in go_client
    assert "github.com/go-resty/resty" not in go_client
    assert "github.com/go-resty/resty" not in go_mod
    assert not (ROOT / "golang" / "go.sum").exists()


def test_openapi_client_generation_smoke_check_is_configured():
    config = json.loads((ROOT / "openapitools.json").read_text())
    assert config["generator-cli"]["version"] == "7.22.0"

    script = (ROOT / "scripts" / "check_client_generation.py").read_text()
    assert "scripts/export_openapi.py" in script
    assert "openapitools/openapi-generator-cli:v" in script
    assert "AIOGRAPI_REST_OPENAPI_GENERATOR_BACKEND" in script
    for generator in ("python", "typescript-fetch", "go", "swift5"):
        assert generator in script
    assert "--skip-validate-spec" in script
    assert "AuthLoginResponse" in script
    assert "AuthLoginBySessionIdResponse" in script
    assert "ResponsePostauthlogin" in script
    assert '"validate"' in script

    workflow = yaml.load((ROOT / ".github" / "workflows" / "clients.yml").read_text(), Loader=yaml.BaseLoader)
    assert workflow["name"] == "Client Generation"
    assert workflow["env"]["FORCE_JAVASCRIPT_ACTIONS_TO_NODE24"] == "true"
    assert workflow["jobs"]["smoke"]["timeout-minutes"] == "20"

    steps = workflow["jobs"]["smoke"]["steps"]
    assert any(step.get("uses") == "actions/checkout@v6.0.2" for step in steps)
    assert any(step.get("uses") == "actions/setup-python@v6.2.0" for step in steps)
    run_commands = "\n".join(step.get("run", "") for step in steps)
    assert "pip install -e ." in run_commands
    assert "python scripts/check_client_generation.py" in run_commands


def test_client_generation_docker_command_maps_temp_paths(tmp_path):
    import scripts.check_client_generation as script

    openapi = tmp_path / "openapi.json"
    output = tmp_path / "clients" / "python"

    command = script.openapi_generator_command(
        ["generate", "-i", str(openapi), "-g", "python", "-o", str(output)],
        backend="docker",
        temp=tmp_path,
    )

    assert command[:6] == [
        "docker",
        "run",
        "--rm",
        "-v",
        f"{tmp_path}:/local",
        "openapitools/openapi-generator-cli:v7.22.0",
    ]
    assert "/local/openapi.json" in command
    assert "/local/clients/python" in command
    assert str(openapi) not in command
    assert str(output) not in command


def test_client_generation_falls_back_to_docker_when_npx_fails(monkeypatch, tmp_path, capsys):
    import scripts.check_client_generation as script

    commands = []

    def fake_run(command, cwd=script.ROOT, **kwargs):
        commands.append(command)
        if command[0] == "npx":
            raise subprocess.CalledProcessError(1, command, output="TypeError: e is not a constructor")

    def fake_which(name):
        if name in {"npx", "docker"}:
            return f"/usr/bin/{name}"
        return None

    monkeypatch.setattr(script, "run", fake_run)
    monkeypatch.setattr(script.shutil, "which", fake_which)
    monkeypatch.setattr(script, "validate_generated_names", lambda generator, output: None)

    script.run_smoke_with_fallback(
        openapi=tmp_path / "openapi.json",
        output_root=tmp_path / "clients",
        temp=tmp_path,
        backend="auto",
    )

    assert commands[0][:3] == ["npx", "--yes", "@openapitools/openapi-generator-cli"]
    assert any(command[0] == "docker" for command in commands)
    assert "falling back to Docker" in capsys.readouterr().out


def test_client_generation_target_selection_and_command_failures(monkeypatch, tmp_path, capsys):
    import scripts.check_client_generation as script

    monkeypatch.setenv("AIOGRAPI_REST_CLIENT_GENERATORS", "python, go")
    assert list(script.selected_targets()) == ["python", "go"]

    monkeypatch.setenv("AIOGRAPI_REST_CLIENT_GENERATORS", "python, nope")
    with pytest.raises(SystemExit, match="Unknown client generator"):
        script.selected_targets()

    calls = []

    class Completed:
        returncode = 0
        stdout = "ok\n"

    def fake_success(command, **kwargs):
        calls.append((command, kwargs["env"]["PYTHONPATH"]))
        return Completed()

    monkeypatch.setattr(script.subprocess, "run", fake_success)
    script.run(["tool"], cwd=tmp_path)
    assert calls[0][0] == ["tool"]
    assert str(ROOT) in calls[0][1]

    class Failed:
        returncode = 2
        stdout = "failed\n"

    monkeypatch.setattr(script.subprocess, "run", lambda *args, **kwargs: Failed())
    with pytest.raises(subprocess.CalledProcessError) as printed:
        script.run(["bad"], cwd=tmp_path)
    assert printed.value.output == "failed\n"
    assert "failed" in capsys.readouterr().out

    with pytest.raises(subprocess.CalledProcessError):
        script.run(["bad"], cwd=tmp_path, print_on_error=False)
    assert "failed" not in capsys.readouterr().out


def test_client_generation_backend_validation_and_explicit_paths(monkeypatch, tmp_path):
    import scripts.check_client_generation as script

    with pytest.raises(ValueError, match="Unknown OpenAPI Generator backend"):
        script.openapi_generator_command(["version"], backend="bad", temp=tmp_path)

    monkeypatch.setattr(script.shutil, "which", lambda name: None)
    with pytest.raises(SystemExit, match="docker is required"):
        script._require_backend("docker")

    calls = []
    monkeypatch.setattr(script, "smoke_generate_clients", lambda *args: calls.append(args))
    script.run_smoke_with_fallback(tmp_path / "openapi.json", tmp_path / "clients", tmp_path, "docker")
    assert calls[-1][-1] == "docker"

    with pytest.raises(SystemExit, match="must be one of"):
        script.run_smoke_with_fallback(tmp_path / "openapi.json", tmp_path / "clients", tmp_path, "bad")

    monkeypatch.setattr(script.shutil, "which", lambda name: "/usr/bin/docker" if name == "docker" else None)
    script.run_smoke_with_fallback(tmp_path / "openapi.json", tmp_path / "clients", tmp_path, "auto")
    assert calls[-1][-1] == "docker"

    def fake_smoke(openapi, output_root, temp, backend, **kwargs):
        calls.append((openapi, output_root, temp, backend, kwargs))
        if backend == "npx":
            raise subprocess.CalledProcessError(1, ["npx"], output="")

    monkeypatch.setattr(script, "smoke_generate_clients", fake_smoke)
    monkeypatch.setattr(script.shutil, "which", lambda name: "/usr/bin/npx" if name == "npx" else None)
    with pytest.raises(subprocess.CalledProcessError):
        script.run_smoke_with_fallback(tmp_path / "openapi.json", tmp_path / "clients", tmp_path, "auto")


def test_client_generation_fallback_removes_partial_output(monkeypatch, tmp_path):
    import scripts.check_client_generation as script

    commands = []
    output_root = tmp_path / "clients"
    output_root.mkdir()
    (output_root / "partial.txt").write_text("partial")

    def fake_run(command, cwd=script.ROOT, **kwargs):
        commands.append(command)
        if command[0] == "npx":
            raise subprocess.CalledProcessError(1, command, output="")

    monkeypatch.setattr(script, "run", fake_run)
    monkeypatch.setattr(script.shutil, "which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr(script, "validate_generated_names", lambda generator, output: None)

    script.run_smoke_with_fallback(tmp_path / "openapi.json", output_root, tmp_path, "auto")

    assert not output_root.exists()
    assert any(command[0] == "docker" for command in commands)


def test_client_generation_validates_generated_names(tmp_path):
    import scripts.check_client_generation as script

    missing = tmp_path / "missing"
    missing.mkdir()
    with pytest.raises(SystemExit, match="did not generate expected file"):
        script.validate_generated_names("python", missing)

    output = tmp_path / "python"
    for relative in script.GENERATED_NAME_CHECKS["python"]:
        path = output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("class AuthLoginResponse: pass")
    (output / "safe.bin").write_text("ResponsePostauthlogin")
    script.validate_generated_names("python", output)

    bad_path = tmp_path / "bad-path"
    for relative in script.GENERATED_NAME_CHECKS["python"]:
        path = bad_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("")
    (bad_path / "ResponsePostauthlogin.py").write_text("")
    with pytest.raises(SystemExit, match="unstable file name"):
        script.validate_generated_names("python", bad_path)

    bad_text = tmp_path / "bad-text"
    for relative in script.GENERATED_NAME_CHECKS["python"]:
        path = bad_text / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("")
    (bad_text / "stable.py").write_text("ResponsePostauthlogin")
    with pytest.raises(SystemExit, match="unstable model name"):
        script.validate_generated_names("python", bad_text)


def test_client_generation_main_exports_schema_and_uses_backend(monkeypatch, tmp_path):
    import scripts.check_client_generation as script

    class FakeTemporaryDirectory:
        def __init__(self, prefix):
            self.prefix = prefix

        def __enter__(self):
            return str(tmp_path)

        def __exit__(self, exc_type, exc, traceback):
            return False

    run_calls = []
    smoke_calls = []
    monkeypatch.setattr(script.tempfile, "TemporaryDirectory", FakeTemporaryDirectory)
    monkeypatch.setattr(script, "run", lambda command: run_calls.append(command))
    monkeypatch.setattr(
        script,
        "run_smoke_with_fallback",
        lambda openapi, output_root, temp, backend: smoke_calls.append((openapi, output_root, temp, backend)),
    )
    monkeypatch.setenv("AIOGRAPI_REST_OPENAPI_GENERATOR_BACKEND", "docker")

    script.main()

    assert run_calls == [[sys.executable, "scripts/export_openapi.py", str(tmp_path / "openapi.json")]]
    assert smoke_calls == [(tmp_path / "openapi.json", tmp_path / "clients", tmp_path, "docker")]


def test_quickstart_examples_cover_login_sessionid_and_user_about():
    examples = {
        "curl": ROOT / "examples" / "curl" / "user-about.sh",
        "python": ROOT / "examples" / "python" / "user_about.py",
        "typescript": ROOT / "examples" / "typescript" / "user-about.ts",
    }
    for path in examples.values():
        assert path.exists(), path

    combined = "\n".join(path.read_text() for path in examples.values())
    assert "AIOGRAPI_REST_BASE_URL" in combined
    assert "AIOGRAPI_REST_SESSIONID" in combined
    assert "AIOGRAPI_REST_USERNAME" in combined
    assert "AIOGRAPI_REST_PASSWORD" in combined
    assert "/auth/login" in combined
    assert "/auth/login/by/sessionid" in combined
    assert "/user/about" in combined
    assert "X-Session-ID" in combined

    readme = (ROOT / "README.md").read_text()
    getting_started = (ROOT / "docs" / "getting-started.md").read_text()
    client_generation = (ROOT / "docs" / "client-generation.md").read_text()
    for document in (readme, getting_started, client_generation):
        assert "examples/curl/user-about.sh" in document
        assert "examples/python/user_about.py" in document
        assert "examples/typescript/user-about.ts" in document


def test_license_has_current_owner_and_year_range():
    license_text = (ROOT / "LICENSE").read_text()
    assert "MIT License" in license_text
    assert "Copyright (c) 2023-2026 subzeroid" in license_text


def test_app_version_is_single_sourced_from_pyproject():
    import aiograpi_rest.main as main

    version = project_version()
    assert main.APP_VERSION == version
    assert main._app_version() == version
    assert 'APP_VERSION = "' not in (ROOT / "aiograpi_rest" / "main.py").read_text()
    assert "Current API version: `" not in (ROOT / "README.md").read_text()


def test_project_version_can_be_read_from_explicit_pyproject(tmp_path):
    import aiograpi_rest.main as main

    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text('[project]\nname = "aiograpi-rest"\nversion = "9.8.7"\n')

    assert main._project_version(pyproject) == "9.8.7"
    assert main._project_version(tmp_path / "missing.toml") is None


def test_app_version_falls_back_to_distribution_metadata(monkeypatch):
    import aiograpi_rest.main as main

    monkeypatch.setattr(main, "_project_version", lambda: None)
    monkeypatch.setattr(main, "package_version", lambda name: "9.9.9")

    assert main._app_version() == "9.9.9"


def test_app_version_returns_unknown_when_metadata_is_missing(monkeypatch):
    import aiograpi_rest.main as main

    def missing_version(name):
        raise PackageNotFoundError(name)

    monkeypatch.setattr(main, "_project_version", lambda: None)
    monkeypatch.setattr(main, "package_version", missing_version)

    assert main._app_version() == "0+unknown"


def test_dockerfile_uses_python_313_and_pyproject_install():
    dockerfile = (ROOT / "Dockerfile").read_text()
    assert "FROM python:3.13-slim" in dockerfile
    assert "APP_VERSION" not in dockerfile
    assert "requirements.txt" not in dockerfile
    assert "pip install ." in dockerfile
    assert "pip install \".[test,docs]\"" in dockerfile
    assert "apt-get install" not in dockerfile
    assert "ffmpeg" not in dockerfile
    assert "gcc" not in dockerfile
    assert "ARG GIT_SHA=" in dockerfile
    assert "ARG BUILD_TIME=" in dockerfile
    assert "ENV GIT_SHA=${GIT_SHA}" in dockerfile
    assert "ENV BUILD_TIME=${BUILD_TIME}" in dockerfile
    assert 'CMD ["uvicorn", "aiograpi_rest.main:app"' in dockerfile
    assert "org.opencontainers.image.source=\"https://github.com/subzeroid/aiograpi-rest\"" in dockerfile
    assert "chown -R aiograpi:aiograpi /app" in dockerfile
    assert "USER aiograpi" in dockerfile
    assert "HEALTHCHECK" in dockerfile
    assert "http://127.0.0.1:8000/health" in dockerfile


def test_compose_runs_api_service_on_8000():
    compose = yaml.safe_load((ROOT / "docker-compose.yml").read_text())
    assert compose["name"] == "aiograpi-rest"
    api = compose["services"]["api"]
    assert api["build"] == {"context": ".", "target": "runtime"}
    assert "8000:8000" in api["ports"]
    test = compose["services"]["test"]
    assert test["build"] == {"context": ".", "target": "test"}
    assert test["profiles"] == ["test"]


def test_release_workflow_publishes_packages_images_and_artifacts():
    assert not (ROOT / ".github" / "workflows" / "docker.yml").exists()
    workflow = yaml.load((ROOT / ".github" / "workflows" / "release.yml").read_text(), Loader=yaml.BaseLoader)
    assert workflow["name"] == "Release"
    assert workflow["env"]["FORCE_JAVASCRIPT_ACTIONS_TO_NODE24"] == "true"
    assert workflow["on"]["push"]["tags"] == ["[0-9]+.[0-9]+.[0-9]+", "v[0-9]+.[0-9]+.[0-9]+"]
    assert workflow["env"]["DOCKERHUB_IMAGE"] == "subzeroid/aiograpi-rest"
    assert workflow["env"]["GHCR_IMAGE"] == "ghcr.io/subzeroid/aiograpi-rest"
    assert workflow["jobs"]["publish"]["permissions"] == {
        "contents": "write",
        "id-token": "write",
        "packages": "write",
    }

    steps = workflow["jobs"]["publish"]["steps"]
    run_commands = "\n".join(step.get("run", "") for step in steps)
    assert "ruff check ." in run_commands
    assert "python scripts/generate_aiograpi_coverage.py --check" in run_commands
    assert "pytest --cov=. --cov-report=term-missing --cov-fail-under=100" in run_commands
    assert "mkdocs build --strict" in run_commands
    assert "python scripts/export_openapi.py release/openapi.json" in run_commands
    assert "python -m build" in run_commands

    dockerhub_login = next(step for step in steps if step.get("name") == "Log in to Docker Hub")
    assert dockerhub_login["uses"] == "docker/login-action@v4.1.0"
    assert dockerhub_login["with"]["username"] == "subzeroid"

    ghcr_login = next(step for step in steps if step.get("name") == "Log in to GitHub Container Registry")
    assert ghcr_login["uses"] == "docker/login-action@v4.1.0"
    assert ghcr_login["with"]["registry"] == "ghcr.io"

    assert any(step.get("uses") == "docker/build-push-action@v7.1.0" for step in steps)

    metadata_step = next(step for step in steps if step.get("uses") == "docker/metadata-action@v6.0.0")
    assert "${{ env.DOCKERHUB_IMAGE }}" in metadata_step["with"]["images"]
    assert "${{ env.GHCR_IMAGE }}" in metadata_step["with"]["images"]

    build_step = next(step for step in steps if step.get("uses") == "docker/build-push-action@v7.1.0")
    assert build_step["with"]["target"] == "runtime"
    assert build_step["with"]["platforms"] == "linux/amd64,linux/arm64"
    assert build_step["with"]["push"] == "true"
    assert build_step["with"]["provenance"] == "false"
    assert "APP_VERSION" not in build_step["with"].get("build-args", "")
    assert "GIT_SHA=${{ github.sha }}" in build_step["with"]["build-args"]
    assert "BUILD_TIME=${{ steps.build_time.outputs.value }}" in build_step["with"]["build-args"]

    pypi_step = next(step for step in steps if step.get("uses") == "pypa/gh-action-pypi-publish@release/v1")
    assert "with" not in pypi_step

    release_step = next(step for step in steps if step.get("uses") == "softprops/action-gh-release@v3.0.0")
    assert "release/openapi.json" in release_step["with"]["files"]
    assert "dist/*.whl" in release_step["with"]["files"]
    assert "dist/*.tar.gz" in release_step["with"]["files"]


def test_release_workflow_verifies_published_artifacts():
    workflow = yaml.load((ROOT / ".github" / "workflows" / "release.yml").read_text(), Loader=yaml.BaseLoader)
    assert workflow["jobs"]["publish"]["outputs"]["tag"] == "${{ github.ref_name }}"
    assert workflow["jobs"]["publish"]["outputs"]["version"] == "${{ steps.version.outputs.value }}"

    steps = workflow["jobs"]["publish"]["steps"]
    version_step = next(step for step in steps if step.get("name") == "Normalize release version")
    assert version_step["id"] == "version"
    assert "GITHUB_REF_NAME#v" in version_step["run"]

    verify = workflow["jobs"]["verify"]
    assert verify["needs"] == "publish"
    assert verify["env"]["RELEASE_TAG"] == "${{ needs.publish.outputs.tag }}"
    assert verify["env"]["VERSION"] == "${{ needs.publish.outputs.version }}"
    assert verify["permissions"] == {"contents": "read"}

    run_commands = "\n".join(step.get("run", "") for step in verify["steps"])
    assert "https://pypi.org/pypi/aiograpi-rest/json" in run_commands
    assert 'docker buildx imagetools inspect "$DOCKERHUB_IMAGE:$VERSION"' in run_commands
    assert 'docker buildx imagetools inspect "$GHCR_IMAGE:$VERSION"' in run_commands
    assert 'gh release view "$RELEASE_TAG"' in run_commands
    assert 'os.environ["VERSION"]' in run_commands
    assert "docker run --pull always" in run_commands
    assert "http://127.0.0.1:18080/health" in run_commands
    assert "http://127.0.0.1:18080/build" in run_commands


def test_live_tests_workflow_runs_nightly_against_real_session_flow():
    workflow = yaml.load((ROOT / ".github" / "workflows" / "live-tests.yml").read_text(), Loader=yaml.BaseLoader)

    assert workflow["name"] == "Live Tests"
    assert workflow["env"]["FORCE_JAVASCRIPT_ACTIONS_TO_NODE24"] == "true"
    assert workflow["on"]["workflow_dispatch"] == {}
    assert workflow["on"]["schedule"] == [{"cron": "17 3 * * *"}]

    job = workflow["jobs"]["live"]
    assert job["if"] == "github.repository == 'subzeroid/aiograpi-rest'"
    assert job["timeout-minutes"] == "30"
    assert job["env"]["TEST_ACCOUNTS_URL"] == "${{ secrets.TEST_ACCOUNTS_URL }}"
    assert job["env"]["TEST_ACCOUNTS_COUNT"] == "25"
    assert job["env"]["LIVE_ACCOUNT_TIMEOUT"] == "90"
    assert job["env"]["LIVE_PAGINATION_ACCOUNTS_COUNT"] == "5"
    assert job["env"]["LIVE_PAGINATION_TIMEOUT"] == "180"
    assert job["env"]["LIVE_STORY_ACCOUNTS_COUNT"] == "5"
    assert job["env"]["LIVE_STORY_TIMEOUT"] == "240"
    assert job["env"]["LIVE_API_BASE_URL"] == "http://127.0.0.1:8000"

    steps = job["steps"]
    assert any(step.get("uses") == "actions/checkout@v6.0.2" for step in steps)
    assert any(step.get("uses") == "actions/setup-python@v6.2.0" for step in steps)

    run_commands = "\n".join(step.get("run", "") for step in steps)
    assert "docker compose up -d api" in run_commands
    assert "curl -fsS http://127.0.0.1:8000/health" in run_commands
    assert "pytest tests/live -m live -o addopts='' -v" in run_commands
    assert "::notice::TEST_ACCOUNTS_URL is not configured; skipping live tests." in run_commands
    assert "docker compose logs api" in run_commands


def test_live_tests_cover_published_image_and_paginated_read_lists():
    workflow = yaml.load((ROOT / ".github" / "workflows" / "live-tests.yml").read_text(), Loader=yaml.BaseLoader)
    live_smoke = (ROOT / "tests" / "live" / "test_live_smoke.py").read_text()
    http_smoke = (ROOT / "tests" / "live" / "test_live_http_smoke.py").read_text()
    readme = (ROOT / "README.md").read_text()

    run_commands = "\n".join(
        step.get("run", "")
        for job in workflow["jobs"].values()
        for step in job.get("steps", [])
    )
    assert "docker rm -f aiograpi-rest-live >/dev/null 2>&1 || true" in run_commands
    assert "docker run --pull always" in run_commands
    assert "subzeroid/aiograpi-rest:latest" in run_commands
    assert 'TEST_ACCOUNTS_COUNT: "5"' in (ROOT / ".github" / "workflows" / "live-tests.yml").read_text()
    assert "pytest tests/live/test_live_http_smoke.py -m live -o addopts='' -v" in run_commands

    for endpoint in (
        "/user/posts",
        "/user/reels",
        "/user/videos",
        "/user/followers",
        "/user/following",
        "/hashtag/media/top",
        "/hashtag/media/recent",
        "/location/media/top",
        "/location/media/recent",
        "/media/comments",
        "/direct/inbox",
        "/story/archive",
        "/story/viewers",
    ):
        assert endpoint in live_smoke

    for endpoint in (
        "/user/posts",
        "/media/comments",
        "/hashtag/media/top",
        "/direct/inbox",
        "/story/upload",
        "/story/download",
        "/user/stories",
    ):
        assert endpoint in http_smoke

    assert "published Docker image" in readme
    assert "paginated read-list routes" in readme


def test_workflows_opt_into_node24_actions():
    for path in sorted((ROOT / ".github" / "workflows").glob("*.yml")):
        workflow = yaml.load(path.read_text(), Loader=yaml.BaseLoader)
        assert workflow.get("env", {}).get("FORCE_JAVASCRIPT_ACTIONS_TO_NODE24") == "true", path.name


def test_workflows_use_node24_native_action_versions():
    for path in sorted((ROOT / ".github" / "workflows").glob("*.yml")):
        workflow = yaml.load(path.read_text(), Loader=yaml.BaseLoader)
        for job in workflow["jobs"].values():
            for step in job.get("steps", []):
                uses = step.get("uses", "")
                action, separator, version = uses.partition("@")
                if action in NODE24_ACTION_VERSIONS:
                    assert separator == "@", uses
                    assert version == NODE24_ACTION_VERSIONS[action], uses


def test_export_openapi_script_writes_artifact(tmp_path):
    from scripts import export_openapi

    output = export_openapi.export_openapi(tmp_path / "nested" / "openapi.json")

    data = json.loads(output.read_text())
    assert data["info"]["title"] == "aiograpi-rest"
    assert data["info"]["version"] == project_version()
    assert data["openapi"] == "3.0.3"


def test_openapi_schema_uses_generator_friendly_names_and_nullable(tmp_path):
    from scripts import export_openapi

    data = json.loads(export_openapi.export_openapi(tmp_path / "openapi.json").read_text())
    schemas = data["components"]["schemas"]

    assert "AuthLoginRequest" in schemas
    assert "AuthLoginResponse" in schemas
    assert "AuthLoginBySessionIdResponse" in schemas
    assert "Response_Postauthlogin" not in schemas
    assert "Response_Postauthloginbysessionid" not in schemas
    assert not any(name.startswith("Body_") for name in schemas)
    assert not any(name.startswith("Response_") for name in schemas)

    login_response = data["paths"]["/auth/login"]["post"]["responses"]["200"]["content"]["application/json"]["schema"]
    assert login_response == {"$ref": "#/components/schemas/AuthLoginResponse"}

    rendered = json.dumps(data)
    assert '"type": "null"' not in rendered
    assert "contentMediaType" not in rendered
    assert "contentEncoding" not in rendered
    assert "OpenAPI 3.0.3 compatibility" in (ROOT / "docs" / "client-generation.md").read_text()


def test_openapi_normalizers_handle_edge_cases():
    import aiograpi_rest.main as main

    path_level_parameters = {"components": {"schemas": {}}, "paths": {"/x": {"parameters": [], "get": {"responses": {}}}}}
    main._extract_inline_response_schemas(path_level_parameters)
    assert path_level_parameters["components"]["schemas"] == {}

    single_type = {"type": ["string", "null"], "contentMediaType": "text/plain"}
    main._convert_nullable_schemas_to_openapi_30(single_type)
    assert single_type == {"type": "string", "nullable": True}

    multiple_types = {"type": ["string", "integer", "null"], "contentEncoding": "base64"}
    main._convert_nullable_schemas_to_openapi_30(multiple_types)
    assert multiple_types == {"type": ["string", "integer"], "nullable": True}


def test_export_openapi_main_writes_artifact(tmp_path):
    from scripts import export_openapi

    output = tmp_path / "openapi.json"
    export_openapi.main([str(output)])

    assert json.loads(output.read_text())["info"]["version"] == project_version()


def test_export_openapi_script_runs_as_file(tmp_path):
    output = tmp_path / "openapi.json"
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)

    result = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "export_openapi.py"), str(output)],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
    )

    assert result.returncode == 0, result.stderr
    assert json.loads(output.read_text())["openapi"] == "3.0.3"


def test_export_openapi_script_requires_output_argument():
    from scripts import export_openapi

    with pytest.raises(SystemExit, match="Usage: export_openapi.py OUTPUT"):
        export_openapi.main([])


def test_readme_documents_rename_reason():
    readme = (ROOT / "README.md").read_text()
    assert readme.startswith("# aiograpi-rest")
    assert "Renamed from `instagrapi-rest` to `aiograpi-rest` in v1.0.0" in readme
    assert "`aiograpi-rest` starts its own semver line at `1.0.0`" in readme
    assert "the service is now powered by `aiograpi`" in readme
    assert "docker run --rm -p 8000:8000 subzeroid/aiograpi-rest" in readme
    assert "docker run -p 8000:8000 ghcr.io/subzeroid/aiograpi-rest" in readme
    assert "PyPI and GitHub Release artifacts are published from the same tag workflow" in readme


def test_quickstart_documents_real_session_flow():
    readme = (ROOT / "README.md").read_text()
    getting_started = (ROOT / "docs" / "getting-started.md").read_text()
    for document in (readme, getting_started):
        assert "docker run --rm -p 8000:8000 subzeroid/aiograpi-rest" in document
        assert "SESSIONID=$(curl -fsS -X POST http://localhost:8000/auth/login" in document
        assert "POST /auth/login/by/sessionid" in document
        assert "Authorize" in document
        assert 'curl "http://localhost:8000/user/about?user_id=25025320"' in document
        assert '-H "X-Session-ID: $SESSIONID"' in document


def test_github_docs_are_configured():
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    assert "mkdocs-material>=9.6,<10" in pyproject["project"]["optional-dependencies"]["docs"]

    mkdocs = yaml.safe_load((ROOT / "mkdocs.yml").read_text())
    assert mkdocs["site_name"] == "aiograpi-rest Documentation"
    assert mkdocs["repo_name"] == "subzeroid/aiograpi-rest"
    assert "aiograpi-coverage.md" in str(mkdocs["nav"])

    docs_workflow = (ROOT / ".github" / "workflows" / "docs.yml").read_text()
    assert "python scripts/generate_aiograpi_coverage.py --check" in docs_workflow
    assert "mkdocs build --strict" in docs_workflow
    assert "mkdocs gh-deploy --force" in docs_workflow
