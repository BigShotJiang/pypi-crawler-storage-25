#!/usr/bin/env python3
import argparse
import csv
import os
import sys
from datetime import datetime
from itertools import islice
from pathlib import Path

from .core import (
    DbTableLoader,
    FileTableLoader,
    RowColumnStrategy,
    RowCountStrategy,
    ValidationService,
)
from .dvg_report import write_html_report

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_CONFIG = str(PROJECT_ROOT / "database_config.ini")


def _build_validation_service() -> ValidationService:
    return ValidationService(
        rowcount_strategy=RowCountStrategy(comparator=compare_rowcount),
        rowcol_strategy=RowColumnStrategy(comparator=compare_row_col),
    )


def parse_args():
    parser = argparse.ArgumentParser(
        description="Data Validation Gini CLI (dvg): compare source and target files."
    )
    parser.add_argument(
        "--file-type",
        required=True,
        choices=["EXCEL", "DB"],
        help="Input file type. Use EXCEL for .csv/.xlsx/.xlsm/.xltx files, DB for database tables.",
    )
    parser.add_argument("--src-path", required=False, help="Path to source file (EXCEL mode).")
    parser.add_argument("--tgt-path", required=False, help="Path to target file (EXCEL mode).")
    parser.add_argument(
        "--validation-type",
        required=True,
        help="Validation mode: ROWCOUNT, ROW_COL_VALIDATION, or both (e.g., 'ROWCOUNT,ROW_COL_VALIDATION')",
    )
    parser.add_argument(
        "--html-output",
        required=False,
        help="Optional HTML report path. Supports <datetime> token.",
    )
    parser.add_argument(
        "--src-sheet",
        required=False,
        help="Optional source sheet name for Excel input.",
    )
    parser.add_argument(
        "--tgt-sheet",
        required=False,
        help="Optional target sheet name for Excel input.",
    )
    parser.add_argument(
        "--sheet-mapping",
        required=False,
        help="Optional Excel sheet mapping, e.g. 'SRC1:TGT1,SRC2:TGT2'.",
    )
    parser.add_argument(
        "--chunk-size",
        required=False,
        type=int,
        default=1000,
        help="Number of data rows to process per chunk while loading files (default: 1000).",
    )
    # ------ DB-mode arguments (only used when --file-type DB) ------
    parser.add_argument(
        "--src-db",
        required=False,
        help="Source database alias as defined in database_config.ini (e.g. postgresql).",
    )
    parser.add_argument(
        "--tgt-db",
        required=False,
        help="Target database alias as defined in database_config.ini (e.g. mysql).",
    )
    parser.add_argument(
        "--src-table",
        required=False,
        help="Source table name (DB mode).",
    )
    parser.add_argument(
        "--tgt-table",
        required=False,
        help="Target table name (DB mode, defaults to --src-table).",
    )
    parser.add_argument(
        "--db-config",
        required=False,
        default=DEFAULT_DB_CONFIG,
        help="Path to database_config.ini (default: project root).",
    )
    return parser.parse_args()


def normalize_cell(value):
    if value is None:
        return ""
    return str(value)


def trim_trailing_empty(values):
    result = list(values)
    while result and result[-1] == "":
        result.pop()
    return result


def iter_chunks(iterator, chunk_size):
    while True:
        chunk = list(islice(iterator, chunk_size))
        if not chunk:
            break
        yield chunk


def _compute_total_chunks(total_rows, chunk_size):
    if total_rows <= 0:
        return 0
    return (total_rows + chunk_size - 1) // chunk_size


def _count_csv_data_rows(path):
    with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        # Exclude header from data row counts.
        return max(sum(1 for _ in reader) - 1, 0)


def _print_chunk_start(progress_label, total_chunks, chunk_size):
    print(
        f"[LOAD][{progress_label}] chunk-size={chunk_size}, "
        f"total-chunks={total_chunks}"
    )


def _print_chunk_progress(progress_label, chunk_num, total_chunks, chunk_len):
    print(
        f"[LOAD][{progress_label}] processing chunk "
        f"{chunk_num}/{total_chunks} ({chunk_len} row(s))"
    )


def _print_chunk_complete(progress_label, total_rows, total_chunks):
    print(
        f"[LOAD][{progress_label}] completed "
        f"{total_rows} row(s) across {total_chunks} chunk(s)"
    )


def load_csv(path, chunk_size=1000, progress_label="CSV"):
    total_rows = _count_csv_data_rows(path)
    total_chunks = _compute_total_chunks(total_rows, chunk_size)
    _print_chunk_start(progress_label, total_chunks, chunk_size)

    with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        header_row = next(reader, None)
        if header_row is None:
            _print_chunk_complete(progress_label, 0, 0)
            return [], []

        header = trim_trailing_empty([normalize_cell(v) for v in header_row])
        rows = []
        for chunk_idx, chunk in enumerate(iter_chunks(reader, chunk_size), start=1):
            _print_chunk_progress(progress_label, chunk_idx, total_chunks, len(chunk))
            rows.extend(
                trim_trailing_empty([normalize_cell(v) for v in row]) for row in chunk
            )

    _print_chunk_complete(progress_label, len(rows), total_chunks)
    return header, rows


def load_excel(path, sheet_name=None, chunk_size=1000, progress_label="EXCEL"):
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("FAILED")
        print("Reason: openpyxl is required for .xlsx/.xlsm/.xltx files. Install it with: pip install openpyxl")
        sys.exit(1)

    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb.active
        if sheet_name:
            if sheet_name not in wb.sheetnames:
                print("FAILED")
                print(f"Reason: Sheet '{sheet_name}' not found in file: {path}")
                sys.exit(1)
            ws = wb[sheet_name]

        max_row = getattr(ws, "max_row", 0) or 0
        total_rows = max(max_row - 1, 0)
        total_chunks = _compute_total_chunks(total_rows, chunk_size)
        _print_chunk_start(progress_label, total_chunks, chunk_size)

        row_iter = iter(ws.iter_rows(values_only=True))
        header_row = next(row_iter, None)
        if header_row is None:
            _print_chunk_complete(progress_label, 0, 0)
            return [], []

        header = trim_trailing_empty([normalize_cell(v) for v in header_row])
        rows = []
        for chunk_idx, chunk in enumerate(iter_chunks(row_iter, chunk_size), start=1):
            _print_chunk_progress(progress_label, chunk_idx, total_chunks, len(chunk))
            rows.extend(
                trim_trailing_empty([normalize_cell(v) for v in row]) for row in chunk
            )

        _print_chunk_complete(progress_label, len(rows), total_chunks)
        return header, rows
    finally:
        wb.close()


def load_table(path, sheet_name=None, chunk_size=1000, progress_label=None):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        if sheet_name:
            print("FAILED")
            print(f"Reason: --src-sheet/--tgt-sheet requires Excel input, got CSV: {path}")
            sys.exit(1)
        label = progress_label or f"CSV:{os.path.basename(path)}"
        return load_csv(path, chunk_size=chunk_size, progress_label=label)
    if ext in {".xlsx", ".xlsm", ".xltx"}:
        label = progress_label or f"XLSX:{sheet_name or '<active>'}"
        try:
            return load_excel(
                path,
                sheet_name=sheet_name,
                chunk_size=chunk_size,
                progress_label=label,
            )
        except TypeError:
            # Backward-compatible path for test monkeypatches that don't accept chunk_size.
            return load_excel(path, sheet_name=sheet_name)
    print("FAILED")
    print(f"Reason: Unsupported file extension '{ext}'. Supported: .csv, .xlsx, .xlsm, .xltx")
    sys.exit(1)


def is_excel_path(path):
    return os.path.splitext(path)[1].lower() in {".xlsx", ".xlsm", ".xltx"}


def parse_sheet_mapping(mapping_text):
    pairs = []
    for token in (mapping_text or "").split(","):
        item = token.strip()
        if not item:
            continue
        if ":" not in item:
            print("FAILED")
            print(
                "Reason: Invalid --sheet-mapping format. Use 'SRC1:TGT1,SRC2:TGT2'."
            )
            sys.exit(1)
        src_sheet, tgt_sheet = item.split(":", 1)
        src_sheet = src_sheet.strip()
        tgt_sheet = tgt_sheet.strip()
        if not src_sheet or not tgt_sheet:
            print("FAILED")
            print(
                "Reason: Invalid --sheet-mapping pair. Both source and target sheet names are required."
            )
            sys.exit(1)
        pairs.append((src_sheet, tgt_sheet))

    if not pairs:
        print("FAILED")
        print("Reason: --sheet-mapping is empty. Use format 'SRC1:TGT1,SRC2:TGT2'.")
        sys.exit(1)

    return pairs


def compare_rowcount(src_rows, tgt_rows):
    src_count = len(src_rows)
    tgt_count = len(tgt_rows)
    passed = src_count == tgt_count
    if passed:
        reason = f"Row counts match: src={src_count}, tgt={tgt_count}."
    else:
        reason = f"Row count mismatch: src={src_count}, tgt={tgt_count}."
    return passed, reason, []


def _values_are_equal(src_val, tgt_val):
    """
    Compare two cell values for equality.
    
    If both values parse as floats, compare numerically (handles decimal precision).
    Otherwise, compare as strings. This ensures 130522.40 == 130522.4 numerically.
    """
    src_str = str(src_val).strip()
    tgt_str = str(tgt_val).strip()
    
    # Try numeric comparison first
    try:
        src_float = float(src_str)
        tgt_float = float(tgt_str)
        return src_float == tgt_float
    except (ValueError, TypeError):
        # Fall back to string comparison if parsing fails
        return src_str == tgt_str


def compare_row_col(src_header, src_rows, tgt_header, tgt_rows):
    mismatches = []

    def classify_mismatch(src_val, tgt_val):
        src_blank = str(src_val).strip() == ""
        tgt_blank = str(tgt_val).strip() == ""
        if (not src_blank) and tgt_blank:
            return "SRC_ONLY", "Source-only value (target missing or blank)"
        if src_blank and (not tgt_blank):
            return "TGT_ONLY", "Target-only value (source missing or blank)"
        return "CELL", "Cell value mismatch"

    def build_row_map(header, rows):
        preferred_keys = ["employee_id", "id", "emp_id", "record_id", "pk"]
        lowered = [str(h).strip().lower() for h in header]

        key_idx = None
        for candidate in preferred_keys:
            if candidate in lowered:
                key_idx = lowered.index(candidate)
                break

        # Fallback to first column if no standard key column is present.
        if key_idx is None and header:
            key_idx = 0

        row_map = {}
        if key_idx is None:
            return row_map, key_idx

        for row_idx, row in enumerate(rows):
            key_val = row[key_idx] if key_idx < len(row) else ""
            key_text = str(key_val).strip()
            if key_text == "":
                # Deterministic fallback key for blank ID values.
                key_text = f"__row_{row_idx + 2}"
            row_map[key_text] = (row_idx, row)

        return row_map, key_idx

    if len(src_header) != len(tgt_header):
        mismatches.append(
            {
                "type": "HEADER_LENGTH",
                "row": 1,
                "column": "<HEADER>",
                "src": str(len(src_header)),
                "tgt": str(len(tgt_header)),
                "reason": "Header column count mismatch",
            }
        )

    header_limit = max(len(src_header), len(tgt_header))
    for col_idx in range(header_limit):
        src_col = src_header[col_idx] if col_idx < len(src_header) else ""
        tgt_col = tgt_header[col_idx] if col_idx < len(tgt_header) else ""
        if src_col != tgt_col:
            mismatches.append(
                {
                    "type": "HEADER_NAME",
                    "row": 1,
                    "column": f"col_{col_idx + 1}",
                    "src": src_col,
                    "tgt": tgt_col,
                    "reason": "Header name mismatch",
                }
            )

    if len(src_rows) != len(tgt_rows):
        mismatches.append(
            {
                "type": "ROWCOUNT",
                "row": 0,
                "column": "<ROWCOUNT>",
                "src": str(len(src_rows)),
                "tgt": str(len(tgt_rows)),
                "reason": "Data row count mismatch",
            }
        )

    src_map, _ = build_row_map(src_header, src_rows)
    tgt_map, _ = build_row_map(tgt_header, tgt_rows)

    all_keys = sorted(set(src_map.keys()) | set(tgt_map.keys()))

    for key in all_keys:
        src_entry = src_map.get(key)
        tgt_entry = tgt_map.get(key)

        src_row_idx = src_entry[0] if src_entry else None
        tgt_row_idx = tgt_entry[0] if tgt_entry else None
        src_row = src_entry[1] if src_entry else []
        tgt_row = tgt_entry[1] if tgt_entry else []

        display_row = (src_row_idx if src_row_idx is not None else tgt_row_idx) + 2
        col_limit = max(len(src_header), len(tgt_header), len(src_row), len(tgt_row))

        for col_idx in range(col_limit):
            src_val = src_row[col_idx] if col_idx < len(src_row) else ""
            tgt_val = tgt_row[col_idx] if col_idx < len(tgt_row) else ""
            if _values_are_equal(src_val, tgt_val):
                continue

            if col_idx < len(src_header):
                col_name = src_header[col_idx]
            elif col_idx < len(tgt_header):
                col_name = tgt_header[col_idx]
            else:
                col_name = f"col_{col_idx + 1}"

            mismatch_type, mismatch_reason = classify_mismatch(src_val, tgt_val)
            mismatches.append(
                {
                    "type": mismatch_type,
                    "row": display_row,
                    "column": col_name,
                    "src": src_val,
                    "tgt": tgt_val,
                    "reason": mismatch_reason,
                }
            )

    passed = len(mismatches) == 0
    if passed:
        reason = "All rows and columns match."
    else:
        reason = f"Found {len(mismatches)} mismatch(es) across headers/rows/columns."
    return passed, reason, mismatches


def resolve_output_path(path):
    if not path:
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved = path.replace("<datetime>", ts).replace("<datetime<", ts)
    resolved = os.path.normpath(resolved)
    out_dir = os.path.dirname(resolved)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    return resolved


def _run_db_validation(args) -> None:
    """Handle the DB file-type branch of main()."""
    try:
        # Keep legacy import behavior so existing tests and external monkeypatches
        # that target "dvg_db" continue to work.
        import dvg_db  # type: ignore
    except ImportError:
        from . import dvg_db

    chunk_size = getattr(args, "chunk_size", 1000)

    for flag, name in (("--src-db", args.src_db), ("--tgt-db", args.tgt_db), ("--src-table", args.src_table)):
        if not name:
            print("FAILED")
            print(f"Reason: {flag} is required when --file-type DB is used.")
            sys.exit(1)

    tgt_table = args.tgt_table or args.src_table
    db_config = args.db_config

    # Parse validation types.
    validation_types_raw = args.validation_type.split(",")
    validation_types = [vt.strip().upper() for vt in validation_types_raw]
    supported = {"ROWCOUNT", "ROW_COL_VALIDATION"}
    for vt in validation_types:
        if vt not in supported:
            print("FAILED")
            print(f"Reason: Unsupported validation type '{vt}'. Supported: ROWCOUNT, ROW_COL_VALIDATION")
            sys.exit(1)

    db_loader = DbTableLoader(load_db_table_func=dvg_db.load_db_table)
    try:
        src_dataset = db_loader.load(
            db_alias=args.src_db,
            table_name=args.src_table,
            config_path=db_config,
            chunk_size=chunk_size,
            progress_label=f"SRC:{args.src_db}:{args.src_table}",
        )
        tgt_dataset = db_loader.load(
            db_alias=args.tgt_db,
            table_name=tgt_table,
            config_path=db_config,
            chunk_size=chunk_size,
            progress_label=f"TGT:{args.tgt_db}:{tgt_table}",
        )
    except Exception as exc:
        print("FAILED")
        print(f"Reason: Database load error – {exc}")
        sys.exit(1)

    label = f"{args.src_db}.{args.src_table}->{args.tgt_db}.{tgt_table}"
    service = _build_validation_service()
    bundle = service.validate_many(
        pairs=[(label, src_dataset, tgt_dataset)],
        validation_types=validation_types,
        tag_mismatch_reasons=False,
    )

    all_passed = bundle.passed
    all_mismatches = bundle.mismatches
    reason = bundle.reason
    print("PASSED" if all_passed else "FAILED")
    print(f"Reason: {reason}")

    if not all_passed and all_mismatches:
        preview = all_mismatches[:10]
        print("Mismatch preview (first 10):")
        for item in preview:
            print(
                f"  - type={item['type']} row={item['row']} column={item['column']} "
                f"src='{item['src']}' tgt='{item['tgt']}' reason='{item['reason']}'"
            )

    if args.html_output:
        out_path = resolve_output_path(args.html_output)
        src_label = f"{args.src_db}:{args.src_table}"
        tgt_label = f"{args.tgt_db}:{tgt_table}"
        write_html_report(
            path=out_path,
            passed=all_passed,
            summary=reason,
            src_path=src_label,
            tgt_path=tgt_label,
            validation_type=args.validation_type,
            mismatches=all_mismatches,
            src_rows_count=bundle.src_rows_count,
            tgt_rows_count=bundle.tgt_rows_count,
        )
        print(f"HTML report: {out_path}")

    sys.exit(0 if all_passed else 1)


def main():
    args = parse_args()
    chunk_size = getattr(args, "chunk_size", 1000)

    if chunk_size <= 0:
        print("FAILED")
        print("Reason: --chunk-size must be a positive integer.")
        sys.exit(1)

    # ---- DB mode – delegate entirely ----
    if getattr(args, "file_type", "") == "DB":
        _run_db_validation(args)

    if not os.path.exists(args.src_path or ""):
        if not args.src_path:
            print("FAILED")
            print("Reason: --src-path is required when --file-type EXCEL is used.")
            sys.exit(1)
        print("FAILED")
        print(f"Reason: Source file not found: {args.src_path}")
        sys.exit(1)
    if not os.path.exists(args.tgt_path or ""):
        if not args.tgt_path:
            print("FAILED")
            print("Reason: --tgt-path is required when --file-type EXCEL is used.")
            sys.exit(1)
        print("FAILED")
        print(f"Reason: Target file not found: {args.tgt_path}")
        sys.exit(1)

    if args.sheet_mapping and (not is_excel_path(args.src_path) or not is_excel_path(args.tgt_path)):
        print("FAILED")
        print("Reason: --sheet-mapping is supported only for Excel files (.xlsx/.xlsm/.xltx).")
        sys.exit(1)

    if args.sheet_mapping:
        sheet_pairs = parse_sheet_mapping(args.sheet_mapping)
    else:
        sheet_pairs = [(args.src_sheet, args.tgt_sheet)]

    # Parse validation types (support comma-separated values)
    validation_types_raw = args.validation_type.split(",")
    validation_types = [vt.strip().upper() for vt in validation_types_raw]
    
    # Validate that all requested types are supported
    supported = {"ROWCOUNT", "ROW_COL_VALIDATION"}
    for vt in validation_types:
        if vt not in supported:
            print("FAILED")
            print(f"Reason: Unsupported validation type '{vt}'. Supported: ROWCOUNT, ROW_COL_VALIDATION")
            sys.exit(1)

    file_loader = FileTableLoader(load_table_func=load_table)
    service = _build_validation_service()
    pairs = []

    for src_sheet_name, tgt_sheet_name in sheet_pairs:
        src_dataset = file_loader.load(
            args.src_path,
            sheet_name=src_sheet_name,
            chunk_size=chunk_size,
            progress_label=f"SRC:{src_sheet_name or '<active>'}",
        )
        tgt_dataset = file_loader.load(
            args.tgt_path,
            sheet_name=tgt_sheet_name,
            chunk_size=chunk_size,
            progress_label=f"TGT:{tgt_sheet_name or '<active>'}",
        )

        if src_sheet_name or tgt_sheet_name:
            sheet_label = f"{src_sheet_name or '<active>'}->{tgt_sheet_name or '<active>'}"
        else:
            sheet_label = "<active_sheet>"

        pairs.append((sheet_label, src_dataset, tgt_dataset))

    bundle = service.validate_many(
        pairs=pairs,
        validation_types=validation_types,
        tag_mismatch_reasons=True,
    )

    passed = bundle.passed
    reason = bundle.reason
    all_mismatches = bundle.mismatches

    print("PASSED" if passed else "FAILED")
    print(f"Reason: {reason}")

    if not passed and all_mismatches:
        preview = all_mismatches[:10]
        print("Mismatch preview (first 10):")
        for item in preview:
            print(
                f"  - type={item['type']} row={item['row']} column={item['column']} "
                f"src='{item['src']}' tgt='{item['tgt']}' reason='{item['reason']}'"
            )

    if args.html_output:
        out_path = resolve_output_path(args.html_output)
        write_html_report(
            path=out_path,
            passed=passed,
            summary=reason,
            src_path=args.src_path,
            tgt_path=args.tgt_path,
            validation_type=args.validation_type,
            mismatches=all_mismatches,
            src_rows_count=bundle.src_rows_count,
            tgt_rows_count=bundle.tgt_rows_count,
        )
        print(f"HTML report: {out_path}")

    sys.exit(0 if passed else 1)


if __name__ == "__main__":  # pragma: no cover
    main()
