#!/usr/bin/env python3
"""MCP server for Data Validation Gini."""

import csv
import html
import random
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from . import data_corruptor, dvg
from .file_stores import JsonFileStore

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - handled by packaging dependency
    raise RuntimeError(
        "The 'mcp' package is required to run the MCP server. Install project dependencies first."
    ) from exc


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = PROJECT_ROOT / "output"
DEFAULT_CHUNK_SIZE = 1000
DEFAULT_SAMPLE_ROWS = 5
DEFAULT_REPORT_GLOB = "report_*.html"

mcp = FastMCP("data-validation-gini")


def _python_command(script_name: str) -> list[str]:
    return [sys.executable, str(PROJECT_ROOT / script_name)]


def _run_subprocess(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
        check=False,
    )


def _default_report_path() -> str:
    return dvg.resolve_output_path(str(OUTPUT_DIR / "report_<datetime>.html"))


def _extract_line(pattern: str, text: str) -> str | None:
    match = re.search(pattern, text, flags=re.MULTILINE)
    if not match:
        return None
    return html.unescape(match.group(1).strip())


def _extract_validation_summary(stdout: str) -> dict[str, Any]:
    status = _extract_line(r"^(PASSED|FAILED)$", stdout) or "UNKNOWN"
    reason = _extract_line(r"^Reason:\s*(.+)$", stdout) or ""
    report_path = _extract_line(r"^HTML report:\s*(.+)$", stdout)

    mismatch_preview = []
    for line in stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("- type="):
            mismatch_preview.append(stripped)

    return {
        "status": status,
        "reason": reason,
        "report_path": report_path,
        "mismatch_preview": mismatch_preview,
    }


def _preview_csv(path: Path, sample_rows: int, chunk_size: int) -> dict[str, Any]:
    with path.open(mode="r", encoding="utf-8-sig", newline="") as file_handle:
        reader = csv.reader(file_handle)
        header_row = next(reader, None)
        if header_row is None:
            return {
                "ok": True,
                "file_type": "csv",
                "path": str(path),
                "header": [],
                "sample_rows": [],
                "row_count_estimate": 0,
            }

        header = dvg.trim_trailing_empty([dvg.normalize_cell(value) for value in header_row])
        rows = []
        for chunk in dvg.iter_chunks(reader, chunk_size):
            for row in chunk:
                rows.append(dvg.trim_trailing_empty([dvg.normalize_cell(value) for value in row]))
                if len(rows) >= sample_rows:
                    break
            if len(rows) >= sample_rows:
                break

    return {
        "ok": True,
        "file_type": "csv",
        "path": str(path),
        "header": header,
        "sample_rows": rows,
        "row_count_estimate": None,
    }


def _preview_excel(path: Path, sample_rows: int, chunk_size: int, sheet_name: str | None) -> dict[str, Any]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:  # pragma: no cover - dependency is declared
        return {
            "ok": False,
            "error": "openpyxl is required to preview Excel files.",
            "details": str(exc),
        }

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        sheet_names = list(workbook.sheetnames)
        worksheet = workbook.active
        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                return {
                    "ok": False,
                    "error": f"Sheet '{sheet_name}' not found in file.",
                    "sheet_names": sheet_names,
                    "path": str(path),
                }
            worksheet = workbook[sheet_name]

        row_iterator = iter(worksheet.iter_rows(values_only=True))
        header_row = next(row_iterator, None)
        if header_row is None:
            return {
                "ok": True,
                "file_type": "excel",
                "path": str(path),
                "sheet_names": sheet_names,
                "sheet_name": worksheet.title,
                "header": [],
                "sample_rows": [],
                "row_count_estimate": 0,
            }

        header = dvg.trim_trailing_empty([dvg.normalize_cell(value) for value in header_row])
        rows = []
        for chunk in dvg.iter_chunks(row_iterator, chunk_size):
            for row in chunk:
                rows.append(dvg.trim_trailing_empty([dvg.normalize_cell(value) for value in row]))
                if len(rows) >= sample_rows:
                    break
            if len(rows) >= sample_rows:
                break

        max_row = getattr(worksheet, "max_row", 0) or 0
        row_count_estimate = max(max_row - 1, 0)
        return {
            "ok": True,
            "file_type": "excel",
            "path": str(path),
            "sheet_names": sheet_names,
            "sheet_name": worksheet.title,
            "header": header,
            "sample_rows": rows,
            "row_count_estimate": row_count_estimate,
        }
    finally:
        workbook.close()


def _find_latest_report() -> Path | None:
    report_dir = OUTPUT_DIR
    if not report_dir.exists():
        return None

    candidates = sorted(
        report_dir.glob(DEFAULT_REPORT_GLOB),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def _extract_report_metrics(html_text: str) -> dict[str, str]:
    labels = [
        "SRC Count",
        "TGT Count",
        "PASSED",
        "FAILED",
        "Pass Rate",
        "Failed Rate",
        "SRC Only",
        "TGT Only",
    ]
    metrics: dict[str, str] = {}
    for label in labels:
        match = re.search(
            rf"{re.escape(label)}</div><div class=\"kpi-value\">([^<]+)</div>",
            html_text,
            flags=re.MULTILINE,
        )
        metrics[label] = match.group(1).strip() if match else "NOT_FOUND"
    return metrics


def _extract_report_metadata(html_text: str) -> dict[str, str]:
    return {
        "status": _extract_line(r"status-pill\">(PASSED|FAILED)", html_text) or "UNKNOWN",
        "validation_type": _extract_line(r"<strong>Validation Type:</strong>\s*([^<]+)", html_text) or "",
        "generated": _extract_line(r"<strong>Generated:</strong>\s*([^<]+)", html_text) or "",
        "source": _extract_line(r"<strong>Source:</strong>\s*([^<]+)", html_text) or "",
        "target": _extract_line(r"<strong>Target:</strong>\s*([^<]+)", html_text) or "",
        "summary": _extract_line(r"<strong>Summary:</strong>\s*([^<]+)", html_text) or "",
    }


@mcp.tool()
def run_validation(
    src_path: str,
    tgt_path: str,
    validation_type: str,
    file_type: str = "EXCEL",
    html_output: str | None = None,
    src_sheet: str | None = None,
    tgt_sheet: str | None = None,
    sheet_mapping: str | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> dict[str, Any]:
    """Run the DVG validation CLI and return a structured result."""

    if chunk_size <= 0:
        return {"ok": False, "error": "chunk_size must be a positive integer."}

    report_path = dvg.resolve_output_path(html_output) if html_output else _default_report_path()
    command = _python_command("dvg.py") + [
        "--file-type",
        file_type,
        "--src-path",
        src_path,
        "--tgt-path",
        tgt_path,
        "--validation-type",
        validation_type,
        "--chunk-size",
        str(chunk_size),
        "--html-output",
        report_path,
    ]

    if src_sheet:
        command.extend(["--src-sheet", src_sheet])
    if tgt_sheet:
        command.extend(["--tgt-sheet", tgt_sheet])
    if sheet_mapping:
        command.extend(["--sheet-mapping", sheet_mapping])

    completed = _run_subprocess(command)
    parsed = _extract_validation_summary(completed.stdout)

    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "command": command,
        "report_path": parsed["report_path"] or report_path,
        "status": parsed["status"],
        "reason": parsed["reason"],
        "mismatch_preview": parsed["mismatch_preview"],
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


@mcp.tool()
def preview_input(
    path: str,
    sample_rows: int = DEFAULT_SAMPLE_ROWS,
    sheet_name: str | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> dict[str, Any]:
    """Preview a CSV or Excel file without loading the full dataset."""

    if sample_rows < 0:
        return {"ok": False, "error": "sample_rows must be zero or greater."}
    if chunk_size <= 0:
        return {"ok": False, "error": "chunk_size must be a positive integer."}

    file_path = Path(path)
    if not file_path.exists():
        return {"ok": False, "error": f"File not found: {path}"}

    suffix = file_path.suffix.lower()
    if suffix == ".csv":
        return _preview_csv(file_path, sample_rows=sample_rows, chunk_size=chunk_size)
    if suffix in {".xlsx", ".xlsm", ".xltx"}:
        return _preview_excel(file_path, sample_rows=sample_rows, chunk_size=chunk_size, sheet_name=sheet_name)

    return {
        "ok": False,
        "error": f"Unsupported file extension '{suffix}'. Supported: .csv, .xlsx, .xlsm, .xltx",
    }


@mcp.tool()
def mutate_data(
    input: str,
    output: str,
    column: str,
    percentage: float = 5.0,
    type: str = "typo",
    value: float = 1.0,
) -> dict[str, Any]:
    """Create a corrupted CSV copy using the same mutation rules as the CLI helper."""

    input_path = Path(input)
    if not input_path.exists():
        return {"ok": False, "error": f"Input file not found: {input}"}
    if not 0 <= percentage <= 100:
        return {"ok": False, "error": "percentage must be between 0 and 100."}

    try:
        with input_path.open(mode="r", newline="", encoding="utf-8") as file_handle:
            reader = list(csv.reader(file_handle))
    except FileNotFoundError:
        return {"ok": False, "error": f"Input file not found: {input}"}

    if not reader:
        return {"ok": False, "error": "The input CSV file is empty."}

    header = reader[0]
    rows = reader[1:]

    if column not in header:
        return {
            "ok": False,
            "error": f"Column '{column}' not found in the CSV header.",
            "available_columns": header,
        }

    total_rows = len(rows)
    if total_rows == 0:
        return {"ok": False, "error": "The input CSV file has no data rows to mutate."}

    mutation_count = int(round((percentage / 100.0) * total_rows))
    if mutation_count == 0 and percentage > 0:
        mutation_count = 1
    mutation_count = min(mutation_count, total_rows)

    target_row_indices = set(random.sample(range(total_rows), mutation_count))
    col_idx = header.index(column)

    for row_idx in range(total_rows):
        if row_idx in target_row_indices:
            rows[row_idx][col_idx] = data_corruptor.inject_variation(rows[row_idx][col_idx], type, value)

    output_path = Path(output)
    if output_path.parent and not output_path.parent.exists():
        output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open(mode="w", newline="", encoding="utf-8") as file_handle:
        writer = csv.writer(file_handle)
        writer.writerow(header)
        writer.writerows(rows)

    return {
        "ok": True,
        "input": str(input_path),
        "output": str(output_path),
        "column": column,
        "percentage": percentage,
        "type": type,
        "value": value,
        "mutated_rows": mutation_count,
        "total_rows": total_rows,
    }


@mcp.tool()
def get_last_report(path: str | None = None) -> dict[str, Any]:
    """Return the latest HTML report summary or parse a specific report file."""

    report_path = Path(path) if path else _find_latest_report()
    if report_path is None:
        return {"ok": False, "error": "No HTML reports were found in the output directory."}

    if not report_path.exists():
        return {"ok": False, "error": f"Report file not found: {report_path}"}

    html_text = report_path.read_text(encoding="utf-8")
    metrics = _extract_report_metrics(html_text)
    metadata = _extract_report_metadata(html_text)

    return {
        "ok": True,
        "path": str(report_path),
        "metrics": metrics,
        "metadata": metadata,
    }


@mcp.tool()
def read_json_file(path: str) -> dict[str, Any]:
    """Read a JSON file and return parsed content."""

    json_path = Path(path)
    store = JsonFileStore(json_path)
    try:
        data = store.read()
    except FileNotFoundError:
        return {"ok": False, "error": f"JSON file not found: {json_path}"}
    except Exception as exc:
        return {"ok": False, "error": f"Failed to read JSON file: {exc}"}

    return {"ok": True, "path": str(json_path), "data": data}


@mcp.tool()
def write_json_file(path: str, data: Any, indent: int = 2) -> dict[str, Any]:
    """Write structured content to a JSON file."""

    if indent < 0:
        return {"ok": False, "error": "indent must be zero or greater."}

    json_path = Path(path)
    store = JsonFileStore(json_path)
    try:
        store.write(data, indent=indent)
    except Exception as exc:
        return {"ok": False, "error": f"Failed to write JSON file: {exc}"}

    return {"ok": True, "path": str(json_path)}


def main() -> None:
    """Run the MCP server over stdio."""

    mcp.run()


@mcp.tool()
def run_db_validation(
    src_db: str,
    tgt_db: str,
    table_name: str,
    validation_type: str,
    tgt_table: str | None = None,
    html_output: str | None = None,
    db_config: str | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> dict[str, Any]:
    """Compare a table between two configured databases and return a structured result.

    Parameters
    ----------
    src_db:          Source database alias from database_config.ini (e.g. ``postgresql``).
    tgt_db:          Target database alias (e.g. ``mysql``, ``sqlite``).
    table_name:      Table to compare (used as both source and target unless *tgt_table* differs).
    validation_type: ``ROWCOUNT``, ``ROW_COL_VALIDATION``, or ``ROWCOUNT,ROW_COL_VALIDATION``.
    tgt_table:       Override target table name when it differs from *table_name*.
    html_output:     Optional path for the HTML report (supports ``<datetime>`` token).
    db_config:       Path to ``database_config.ini``; defaults to the project-root copy.
    chunk_size:      Rows fetched per batch from the database.
    """
    if chunk_size <= 0:
        return {"ok": False, "error": "chunk_size must be a positive integer."}

    resolved_tgt_table = tgt_table or table_name
    report_path = dvg.resolve_output_path(html_output) if html_output else _default_report_path()

    command = (
        _python_command("dvg.py")
        + ["--file-type", "DB"]
        + ["--src-db", src_db]
        + ["--tgt-db", tgt_db]
        + ["--src-table", table_name]
        + ["--tgt-table", resolved_tgt_table]
        + ["--validation-type", validation_type]
        + ["--chunk-size", str(chunk_size)]
        + ["--html-output", report_path]
    )
    if db_config:
        command.extend(["--db-config", db_config])

    completed = _run_subprocess(command)
    parsed = _extract_validation_summary(completed.stdout)

    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "command": command,
        "src_db": src_db,
        "tgt_db": tgt_db,
        "src_table": table_name,
        "tgt_table": resolved_tgt_table,
        "report_path": parsed["report_path"] or report_path,
        "status": parsed["status"],
        "reason": parsed["reason"],
        "mismatch_preview": parsed["mismatch_preview"],
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


@mcp.tool()
def list_db_tables_tool(
    db_alias: str,
    db_config: str | None = None,
) -> dict[str, Any]:
    """List all user tables in a configured database.

    Parameters
    ----------
    db_alias:  Database alias from ``database_config.ini`` (e.g. ``postgresql``).
    db_config: Optional path to ``database_config.ini``.
    """
    try:
        from . import dvg_db
        tables = dvg_db.list_db_tables(db_alias, config_path=db_config or None)
        return {"ok": True, "db_alias": db_alias, "tables": tables}
    except Exception as exc:
        return {"ok": False, "db_alias": db_alias, "error": str(exc)}


if __name__ == "__main__":  # pragma: no cover
    main()
