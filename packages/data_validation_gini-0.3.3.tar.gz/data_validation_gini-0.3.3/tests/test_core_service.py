from data_validation_gini.core import (
    Dataset,
    DbTableLoader,
    FileTableLoader,
    RowColumnStrategy,
    RowCountStrategy,
    ValidationService,
)


def test_file_table_loader_with_fallback_typeerror():
    def loader(path, sheet_name=None):
        return ["id"], [["1"]]

    file_loader = FileTableLoader(load_table_func=loader)
    dataset = file_loader.load("a.csv", sheet_name="s1", chunk_size=5, progress_label="SRC")
    assert dataset.header == ["id"]
    assert dataset.rows == [["1"]]


def test_db_table_loader():
    def db_loader(db_alias, table_name, config_path, chunk_size, progress_label):
        assert db_alias == "pg"
        assert table_name == "employees"
        return ["id"], [["1"], ["2"]]

    loader = DbTableLoader(load_db_table_func=db_loader)
    dataset = loader.load("pg", "employees", "cfg.ini", 1000, "SRC")
    assert dataset.header == ["id"]
    assert len(dataset.rows) == 2


def test_validation_service_validate_many_with_and_without_tagging():
    def rowcount_cmp(src_rows, tgt_rows):
        return False, "rowcount mismatch", []

    def rowcol_cmp(src_header, src_rows, tgt_header, tgt_rows):
        return False, "rowcol mismatch", [
            {
                "type": "CELL",
                "row": 2,
                "column": "name",
                "src": "A",
                "tgt": "B",
                "reason": "Cell value mismatch",
            }
        ]

    service = ValidationService(
        rowcount_strategy=RowCountStrategy(comparator=rowcount_cmp),
        rowcol_strategy=RowColumnStrategy(comparator=rowcol_cmp),
    )

    src = Dataset(header=["id", "name"], rows=[["1", "A"]])
    tgt = Dataset(header=["id", "name"], rows=[["1", "B"]])

    tagged = service.validate_many(
        pairs=[("sheet1", src, tgt)],
        validation_types=["ROWCOUNT", "ROW_COL_VALIDATION"],
        tag_mismatch_reasons=True,
    )
    assert tagged.passed is False
    assert "[sheet1][ROWCOUNT]" in tagged.reason
    assert tagged.mismatches[0]["reason"].startswith("[sheet1]")

    untagged = service.validate_many(
        pairs=[("pair1", src, tgt)],
        validation_types=["ROW_COL_VALIDATION"],
        tag_mismatch_reasons=False,
    )
    assert untagged.mismatches[0]["reason"] == "Cell value mismatch"


def test_validation_service_row_counts_aggregation():
    service = ValidationService(
        rowcount_strategy=RowCountStrategy(comparator=lambda s, t: (True, "ok", [])),
        rowcol_strategy=RowColumnStrategy(comparator=lambda sh, sr, th, tr: (True, "ok", [])),
    )

    a_src = Dataset(header=["id"], rows=[["1"], ["2"]])
    a_tgt = Dataset(header=["id"], rows=[["1"]])
    b_src = Dataset(header=["id"], rows=[["9"]])
    b_tgt = Dataset(header=["id"], rows=[["9"], ["10"]])

    result = service.validate_many(
        pairs=[("a", a_src, a_tgt), ("b", b_src, b_tgt)],
        validation_types=["ROWCOUNT"],
        tag_mismatch_reasons=False,
    )

    assert result.passed is True
    assert result.src_rows_count == 3
    assert result.tgt_rows_count == 3
