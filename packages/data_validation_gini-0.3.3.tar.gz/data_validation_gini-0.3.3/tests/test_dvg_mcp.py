import csv
from pathlib import Path
import subprocess
import sys
import types

import pytest

import data_validation_gini.dvg_mcp as dvg_mcp


def test_preview_input_csv(tmp_path):
    csv_path = tmp_path / "sample.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as file_handle:
        writer = csv.writer(file_handle)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])
        writer.writerow(["2", "Bob"])

    result = dvg_mcp.preview_input(str(csv_path), sample_rows=1)
    assert result["ok"] is True
    assert result["file_type"] == "csv"
    assert result["header"] == ["id", "name"]
    assert result["sample_rows"] == [["1", "Alice"]]


def test_preview_input_excel(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    worksheet.title = "employees"
    worksheet.append(["id", "name"])
    worksheet.append([1, "Alice"])

    path = tmp_path / "sample.xlsx"
    workbook.save(path)
    workbook.close()

    result = dvg_mcp.preview_input(str(path), sample_rows=1, sheet_name="employees")
    assert result["ok"] is True
    assert result["file_type"] == "excel"
    assert result["sheet_name"] == "employees"
    assert result["header"] == ["id", "name"]
    assert result["sample_rows"] == [["1", "Alice"]]


def test_run_validation_builds_default_report_path(monkeypatch):
    captured = {}

    def fake_run(command):
        captured["command"] = command
        return subprocess.CompletedProcess(
            command,
            0,
            stdout=(
                "PASSED\n"
                "Reason: All rows and columns match.\n"
                "HTML report: C:/tmp/report.html\n"
            ),
            stderr="",
        )

    monkeypatch.setattr(dvg_mcp, "_run_subprocess", fake_run)

    result = dvg_mcp.run_validation(
        src_path="inputs/a.csv",
        tgt_path="outputs/b.csv",
        validation_type="ROWCOUNT",
        chunk_size=500,
    )

    assert result["ok"] is True
    assert result["status"] == "PASSED"
    assert result["report_path"] == "C:/tmp/report.html"
    assert "--chunk-size" in captured["command"]


def test_mutate_data_creates_output(tmp_path):
    input_path = tmp_path / "input.csv"
    with input_path.open("w", encoding="utf-8", newline="") as file_handle:
        writer = csv.writer(file_handle)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])
        writer.writerow(["2", "Bob"])

    output_path = tmp_path / "mutated.csv"
    result = dvg_mcp.mutate_data(
        input=str(input_path),
        output=str(output_path),
        column="name",
        percentage=100.0,
        type="case_swap",
    )

    assert result["ok"] is True
    assert output_path.exists()
    text = output_path.read_text(encoding="utf-8")
    assert "ALICE" in text or "aLICE" in text


def test_get_last_report(tmp_path, monkeypatch):
    report_dir = tmp_path / "output"
    report_dir.mkdir()
    latest = report_dir / "report_20260516_102318.html"
    latest.write_text(
        """
        <html>
        <body>
          <span class="status-pill">FAILED</span>
          <section><div class="kpi-label">SRC Count</div><div class="kpi-value">2</div></section>
          <section><div class="kpi-label">TGT Count</div><div class="kpi-value">3</div></section>
          <section><div class="kpi-label">PASSED</div><div class="kpi-value">1</div></section>
          <section><div class="kpi-label">FAILED</div><div class="kpi-value">2</div></section>
          <section><div class="kpi-label">Pass Rate</div><div class="kpi-value">50.00%</div></section>
          <section><div class="kpi-label">Failed Rate</div><div class="kpi-value">50.00%</div></section>
          <section><div class="kpi-label">SRC Only</div><div class="kpi-value">1</div></section>
          <section><div class="kpi-label">TGT Only</div><div class="kpi-value">1</div></section>
          <p><strong>Validation Type:</strong> ROWCOUNT</p>
          <p><strong>Summary:</strong> example summary</p>
        </body>
        </html>
        """,
        encoding="utf-8",
    )

    monkeypatch.setattr(dvg_mcp, "OUTPUT_DIR", report_dir)

    result = dvg_mcp.get_last_report()
    assert result["ok"] is True
    assert result["metadata"]["status"] == "FAILED"
    assert result["metrics"]["SRC Count"] == "2"
    assert result["metrics"]["TGT Count"] == "3"
    assert result["metadata"]["summary"] == "example summary"


def test_read_json_file_and_write_json_file(tmp_path):
    json_path = tmp_path / "result.json"

    write_result = dvg_mcp.write_json_file(
        path=str(json_path),
        data={"status": "ok", "count": 2},
        indent=2,
    )
    assert write_result["ok"] is True

    read_result = dvg_mcp.read_json_file(str(json_path))
    assert read_result["ok"] is True
    assert read_result["data"]["status"] == "ok"
    assert read_result["data"]["count"] == 2


def test_read_json_file_missing(tmp_path):
    result = dvg_mcp.read_json_file(str(tmp_path / "missing.json"))
    assert result["ok"] is False
    assert "not found" in result["error"].lower()


def test_write_json_file_invalid_indent(tmp_path):
    result = dvg_mcp.write_json_file(
        path=str(tmp_path / "bad.json"),
        data={"a": 1},
        indent=-1,
    )
    assert result["ok"] is False
    assert "indent" in result["error"].lower()


def test_extract_helpers_and_find_latest_report(tmp_path, monkeypatch):
    assert dvg_mcp._extract_line(r"^x:(.+)$", "x:ok") == "ok"
    assert dvg_mcp._extract_line(r"^z:(.+)$", "x:ok") is None

    parsed = dvg_mcp._extract_validation_summary(
        "FAILED\nReason: bad\n- type=CELL row=2\nHTML report: a.html\n"
    )
    assert parsed["status"] == "FAILED"
    assert parsed["report_path"] == "a.html"
    assert parsed["mismatch_preview"]

    report_dir = tmp_path / "output"
    monkeypatch.setattr(dvg_mcp, "OUTPUT_DIR", report_dir)
    assert dvg_mcp._find_latest_report() is None

    report_dir.mkdir()
    a = report_dir / "report_1.html"
    b = report_dir / "report_2.html"
    a.write_text("a", encoding="utf-8")
    b.write_text("b", encoding="utf-8")
    assert dvg_mcp._find_latest_report() is not None


def test_preview_input_error_paths(tmp_path):
    assert dvg_mcp.preview_input("x", sample_rows=-1)["ok"] is False
    assert dvg_mcp.preview_input("x", chunk_size=0)["ok"] is False
    assert dvg_mcp.preview_input(str(tmp_path / "missing.csv"))["ok"] is False

    bad = tmp_path / "bad.txt"
    bad.write_text("x", encoding="utf-8")
    unsupported = dvg_mcp.preview_input(str(bad))
    assert unsupported["ok"] is False
    assert "unsupported" in unsupported["error"].lower()


def test_preview_excel_import_error(monkeypatch, tmp_path):
    xlsx = tmp_path / "a.xlsx"
    xlsx.write_text("dummy", encoding="utf-8")

    real_import = __import__

    def fake_import(name, *args, **kwargs):
        if name == "openpyxl":
            raise ImportError("no openpyxl")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)
    result = dvg_mcp._preview_excel(xlsx, sample_rows=1, chunk_size=1, sheet_name=None)
    assert result["ok"] is False
    assert "openpyxl" in result["error"]


def test_mutate_data_error_paths(tmp_path, monkeypatch):
    assert dvg_mcp.mutate_data("missing.csv", "out.csv", "name")["ok"] is False

    in_path = tmp_path / "in.csv"
    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])

    assert dvg_mcp.mutate_data(str(in_path), "out.csv", "name", percentage=-1)["ok"] is False

    no_rows = dvg_mcp.mutate_data(str(in_path), str(tmp_path / "o.csv"), "name", percentage=0)
    assert no_rows["ok"] is False
    assert "no data rows" in no_rows["error"].lower()

    # Cover csv read FileNotFoundError branch by faking open behavior.
    monkeypatch.setattr(Path, "exists", lambda self: True)

    def raise_fn(*args, **kwargs):
        raise FileNotFoundError("boom")

    monkeypatch.setattr(Path, "open", raise_fn)
    result = dvg_mcp.mutate_data("a.csv", "b.csv", "name")
    assert result["ok"] is False


def test_mutate_data_empty_csv_and_missing_column(tmp_path):
    empty_csv = tmp_path / "empty.csv"
    empty_csv.write_text("", encoding="utf-8")
    empty_result = dvg_mcp.mutate_data(str(empty_csv), str(tmp_path / "o1.csv"), "name")
    assert empty_result["ok"] is False
    assert "empty" in empty_result["error"].lower()

    csv_path = tmp_path / "data.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])

    missing_col = dvg_mcp.mutate_data(str(csv_path), str(tmp_path / "o2.csv"), "email")
    assert missing_col["ok"] is False
    assert "not found" in missing_col["error"].lower()
    assert missing_col["available_columns"] == ["id", "name"]


def test_get_last_report_error_paths(tmp_path):
    missing = dvg_mcp.get_last_report(str(tmp_path / "missing.html"))
    assert missing["ok"] is False


def test_json_tool_exception_paths(monkeypatch, tmp_path):
    json_path = tmp_path / "x.json"

    class BadStore:
        def __init__(self, path):
            self.path = path

        def read(self):
            raise ValueError("bad read")

        def write(self, data, indent=2):
            raise ValueError("bad write")

    monkeypatch.setattr(dvg_mcp, "JsonFileStore", BadStore)

    read_result = dvg_mcp.read_json_file(str(json_path))
    assert read_result["ok"] is False
    assert "failed to read" in read_result["error"].lower()

    write_result = dvg_mcp.write_json_file(str(json_path), {"a": 1})
    assert write_result["ok"] is False
    assert "failed to write" in write_result["error"].lower()


def test_run_validation_and_db_validation_error_inputs():
    assert dvg_mcp.run_validation("a", "b", "ROWCOUNT", chunk_size=0)["ok"] is False
    assert dvg_mcp.run_db_validation("s", "t", "tbl", "ROWCOUNT", chunk_size=0)["ok"] is False


def test_run_db_validation_db_config_and_result(monkeypatch):
    def fake_run(command):
        return subprocess.CompletedProcess(
            command,
            1,
            stdout="FAILED\nReason: db fail\n",
            stderr="err",
        )

    monkeypatch.setattr(dvg_mcp, "_run_subprocess", fake_run)

    result = dvg_mcp.run_db_validation(
        src_db="pg",
        tgt_db="my",
        table_name="employees",
        validation_type="ROWCOUNT",
        db_config="custom.ini",
    )
    assert result["ok"] is False
    assert "--db-config" in result["command"]


def test_list_db_tables_tool_error_and_main(monkeypatch):
    import data_validation_gini.dvg_db as dvg_db_module

    monkeypatch.setattr(
        dvg_db_module,
        "list_db_tables",
        lambda *args, **kwargs: (_ for _ in ()).throw(Exception("boom")),
    )

    result = dvg_mcp.list_db_tables_tool("pg")
    assert result["ok"] is False

    called = {"ok": False}
    monkeypatch.setattr(dvg_mcp.mcp, "run", lambda: called.update({"ok": True}))
    dvg_mcp.main()
    assert called["ok"] is True


def test_run_subprocess_helper_executes_command():
    completed = dvg_mcp._run_subprocess([sys.executable, "-c", "print('ok')"])
    assert completed.returncode == 0
    assert "ok" in completed.stdout


def test_preview_csv_empty_file_direct(tmp_path):
    csv_path = tmp_path / "empty.csv"
    csv_path.write_text("", encoding="utf-8")

    result = dvg_mcp._preview_csv(csv_path, sample_rows=3, chunk_size=2)
    assert result["ok"] is True
    assert result["header"] == []
    assert result["row_count_estimate"] == 0


def test_preview_excel_sheet_not_found_and_empty_sheet(monkeypatch, tmp_path):
    class EmptySheet:
        title = "Sheet1"
        max_row = 0

        def iter_rows(self, values_only=True):
            return iter(())

    class FakeWorkbook:
        def __init__(self):
            self.sheetnames = ["Sheet1"]
            self.active = EmptySheet()

        def __getitem__(self, name):
            return self.active

        def close(self):
            return None

    fake_module = types.SimpleNamespace(load_workbook=lambda *args, **kwargs: FakeWorkbook())
    monkeypatch.setitem(sys.modules, "openpyxl", fake_module)

    xlsx = tmp_path / "file.xlsx"
    xlsx.write_text("x", encoding="utf-8")

    missing = dvg_mcp._preview_excel(xlsx, sample_rows=1, chunk_size=1, sheet_name="Nope")
    assert missing["ok"] is False
    assert "not found" in missing["error"].lower()

    empty = dvg_mcp._preview_excel(xlsx, sample_rows=1, chunk_size=1, sheet_name=None)
    assert empty["ok"] is True
    assert empty["header"] == []


def test_run_validation_optional_sheet_flags(monkeypatch):
    captured = {}

    def fake_run(command):
        captured["command"] = command
        return subprocess.CompletedProcess(command, 0, stdout="PASSED\nReason: ok\n", stderr="")

    monkeypatch.setattr(dvg_mcp, "_run_subprocess", fake_run)

    result = dvg_mcp.run_validation(
        src_path="a.csv",
        tgt_path="b.csv",
        validation_type="ROWCOUNT",
        src_sheet="s1",
        tgt_sheet="t1",
        sheet_mapping="s1:t1",
    )
    assert result["ok"] is True
    assert "--src-sheet" in captured["command"]
    assert "--tgt-sheet" in captured["command"]
    assert "--sheet-mapping" in captured["command"]


def test_mutate_data_success_fallback_count_and_output_dir(tmp_path):
    in_path = tmp_path / "in.csv"
    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])

    out_path = tmp_path / "nested" / "out.csv"
    result = dvg_mcp.mutate_data(
        input=str(in_path),
        output=str(out_path),
        column="name",
        percentage=0.1,
        type="case_swap",
    )
    assert result["ok"] is True
    assert result["mutated_rows"] == 1
    assert out_path.exists()


def test_get_last_report_no_reports(tmp_path, monkeypatch):
    monkeypatch.setattr(dvg_mcp, "OUTPUT_DIR", tmp_path / "no_reports")
    result = dvg_mcp.get_last_report()
    assert result["ok"] is False


def test_list_db_tables_tool_success(monkeypatch):
    import data_validation_gini.dvg_db as dvg_db_module

    monkeypatch.setattr(dvg_db_module, "list_db_tables", lambda *args, **kwargs: ["a", "b"])
    result = dvg_mcp.list_db_tables_tool("pg")
    assert result["ok"] is True
    assert result["tables"] == ["a", "b"]
