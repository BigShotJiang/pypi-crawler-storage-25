import csv
import runpy
import subprocess
import sys
from argparse import Namespace
from pathlib import Path

import pytest

import data_validation_gini.data_corruptor as data_corruptor


def test_parse_arguments(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "data_corruptor.py",
            "-i",
            "in.csv",
            "-o",
            "out.csv",
            "-c",
            "name",
            "-t",
            "typo",
            "-p",
            "10",
            "-v",
            "2",
        ],
    )
    args = data_corruptor.parse_arguments()
    assert args.input == "in.csv"
    assert args.output == "out.csv"
    assert args.column == "name"
    assert args.type == "typo"
    assert args.percentage == 10.0
    assert args.value == 2.0


def test_inject_variation_branches(monkeypatch):
    assert data_corruptor.inject_variation("", "nullify", 1) == ""
    assert data_corruptor.inject_variation("NULL", "nullify", 1) == "NULL"

    assert data_corruptor.inject_variation("Hello", "nullify", 1) == ""
    assert data_corruptor.inject_variation("AbC", "case_swap", 1) == "aBc"

    assert data_corruptor.inject_variation("10", "numeric_shift", 2) == "12"
    assert data_corruptor.inject_variation("10.25", "numeric_shift", 1.5) == "11.75"
    assert data_corruptor.inject_variation("abc", "numeric_shift", 1).endswith("_SHIFT_ERR")

    assert data_corruptor.inject_variation("2024-01-01", "date_shift", 2) == "2024-01-03"
    assert data_corruptor.inject_variation("2024-01-01 00:00:00", "date_shift", 1) == "2024-01-02 00:00:00"
    assert data_corruptor.inject_variation("not-a-date", "date_shift", 2).endswith("_DATE_ERR")

    assert data_corruptor.inject_variation("Z", "typo", 1) == "ZX"

    monkeypatch.setattr(data_corruptor.random, "randint", lambda a, b: 1)
    monkeypatch.setattr(data_corruptor.random, "choice", lambda s: "Q")
    assert data_corruptor.inject_variation("Abc", "typo", 1) == "AQc"

    assert data_corruptor.inject_variation("abc", "unknown", 1) == "abc"


def test_main_invalid_percentage(monkeypatch, capsys):
    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input="in.csv",
            output="out.csv",
            column="name",
            percentage=101.0,
            type="typo",
            value=1.0,
        ),
    )

    with pytest.raises(SystemExit) as ex:
        data_corruptor.main()
    assert ex.value.code == 1
    assert "Percentage must be between 0 and 100" in capsys.readouterr().out


def test_main_file_not_found(monkeypatch, capsys):
    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input="missing.csv",
            output="out.csv",
            column="name",
            percentage=5.0,
            type="typo",
            value=1.0,
        ),
    )

    with pytest.raises(SystemExit) as ex:
        data_corruptor.main()
    assert ex.value.code == 1
    assert "not found" in capsys.readouterr().out


def test_main_empty_file(monkeypatch, tmp_path, capsys):
    in_path = tmp_path / "in.csv"
    in_path.write_text("", encoding="utf-8")

    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input=str(in_path),
            output=str(tmp_path / "out.csv"),
            column="name",
            percentage=5.0,
            type="typo",
            value=1.0,
        ),
    )

    with pytest.raises(SystemExit) as ex:
        data_corruptor.main()
    assert ex.value.code == 1
    assert "input CSV file is empty" in capsys.readouterr().out


def test_main_missing_column(monkeypatch, tmp_path, capsys):
    in_path = tmp_path / "in.csv"
    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "alice"])

    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input=str(in_path),
            output=str(tmp_path / "out.csv"),
            column="email",
            percentage=5.0,
            type="typo",
            value=1.0,
        ),
    )

    with pytest.raises(SystemExit) as ex:
        data_corruptor.main()
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "Column 'email' not found" in out
    assert "Available columns" in out


def test_main_success(monkeypatch, tmp_path, capsys):
    in_path = tmp_path / "in.csv"
    out_path = tmp_path / "out.csv"

    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])
        writer.writerow(["2", "Bob"])

    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input=str(in_path),
            output=str(out_path),
            column="name",
            percentage=100.0,
            type="nullify",
            value=1.0,
        ),
    )

    data_corruptor.main()

    assert out_path.exists()
    with out_path.open("r", encoding="utf-8", newline="") as fh:
        rows = list(csv.reader(fh))
    assert rows[1][1] == ""
    assert rows[2][1] == ""
    assert "Success: Saved modified file" in capsys.readouterr().out


def test_main_mutation_count_fallback_to_one(monkeypatch, tmp_path):
    in_path = tmp_path / "in.csv"
    out_path = tmp_path / "out.csv"

    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])

    monkeypatch.setattr(
        data_corruptor,
        "parse_arguments",
        lambda: Namespace(
            input=str(in_path),
            output=str(out_path),
            column="name",
            percentage=0.1,
            type="nullify",
            value=1.0,
        ),
    )

    data_corruptor.main()

    with out_path.open("r", encoding="utf-8", newline="") as fh:
        rows = list(csv.reader(fh))
    assert rows[1][1] == ""


def test_module_main_entrypoint(tmp_path, monkeypatch):
    root = str(Path(__file__).resolve().parents[1])
    in_path = tmp_path / "in.csv"
    out_path = tmp_path / "out.csv"

    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])

    cmd = [
        sys.executable,
        "-m",
        "data_validation_gini.data_corruptor",
        "-i",
        str(in_path),
        "-o",
        str(out_path),
        "-c",
        "name",
        "-t",
        "nullify",
        "-p",
        "100",
    ]

    completed = subprocess.run(
        cmd,
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert completed.returncode == 0
    assert out_path.exists()


def test_main_guard_via_run_path(tmp_path, monkeypatch):
    """Execute module as a script to cover the __main__ guard line."""
    in_path = tmp_path / "in.csv"
    out_path = tmp_path / "out.csv"

    with in_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name"])
        writer.writerow(["1", "Alice"])

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "data_corruptor.py",
            "-i",
            str(in_path),
            "-o",
            str(out_path),
            "-c",
            "name",
            "-t",
            "nullify",
            "-p",
            "100",
        ],
    )

    module_path = Path(__file__).resolve().parents[1] / "src" / "data_validation_gini" / "data_corruptor.py"
    runpy.run_path(str(module_path), run_name="__main__")

    assert out_path.exists()
