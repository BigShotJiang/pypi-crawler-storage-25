import csv
import builtins
import sys
from argparse import Namespace

import pytest

import data_validation_gini.dvg as dvg


def test_parse_args(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "dvg.py",
            "--file-type",
            "EXCEL",
            "--src-path",
            "inputs/a.csv",
            "--tgt-path",
            "outputs/b.csv",
            "--validation-type",
            "ROWCOUNT",
            "--html-output",
            "output/report.html",
            "--src-sheet",
            "employees",
            "--tgt-sheet",
            "employees",
            "--sheet-mapping",
            "employees:employees",
        ],
    )
    args = dvg.parse_args()
    assert args.file_type == "EXCEL"
    assert args.src_sheet == "employees"
    assert args.tgt_sheet == "employees"
    assert args.sheet_mapping == "employees:employees"
    assert args.chunk_size == 1000


def test_parse_args_custom_chunk_size(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "dvg.py",
            "--file-type",
            "EXCEL",
            "--src-path",
            "inputs/a.csv",
            "--tgt-path",
            "outputs/b.csv",
            "--validation-type",
            "ROWCOUNT",
            "--chunk-size",
            "2500",
        ],
    )
    args = dvg.parse_args()
    assert args.chunk_size == 2500


def test_normalize_and_trim_helpers():
    assert dvg.normalize_cell(None) == ""
    assert dvg.normalize_cell(123) == "123"
    assert dvg.trim_trailing_empty(["a", "", ""]) == ["a"]
    assert dvg._compute_total_chunks(0, 1000) == 0
    assert dvg._compute_total_chunks(1001, 1000) == 2


def test_load_csv_with_data_and_empty_file(tmp_path, capsys):
    populated = tmp_path / "sample.csv"
    with populated.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["id", "name", "", ""])
        writer.writerow(["1", "Alice", "", ""])

    header, rows = dvg.load_csv(str(populated), progress_label="CSV:sample.csv")
    assert header == ["id", "name"]
    assert rows == [["1", "Alice"]]
    out = capsys.readouterr().out
    assert "[LOAD][CSV:sample.csv]" in out
    assert "total-chunks=1" in out
    assert "processing chunk 1/1" in out

    empty = tmp_path / "empty.csv"
    empty.write_text("", encoding="utf-8")
    header2, rows2 = dvg.load_csv(str(empty), progress_label="CSV:empty.csv")
    assert header2 == []
    assert rows2 == []
    out2 = capsys.readouterr().out
    assert "[LOAD][CSV:empty.csv]" in out2
    assert "total-chunks=0" in out2
    assert "completed 0 row(s) across 0 chunk(s)" in out2


def test_load_excel_default_and_named_sheet(tmp_path, capsys):
    openpyxl = pytest.importorskip("openpyxl")
    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = "employees"
    ws1.append(["id", "name"])
    ws1.append([1, "Alice"])
    ws2 = wb.create_sheet("departments")
    ws2.append(["id", "dept"])
    ws2.append([11, "IT"])

    path = tmp_path / "book.xlsx"
    wb.save(path)
    wb.close()

    h1, r1 = dvg.load_excel(str(path))
    assert h1 == ["id", "name"]
    assert r1 == [["1", "Alice"]]
    out = capsys.readouterr().out
    assert "[LOAD][EXCEL]" in out
    assert "processing chunk 1/1" in out

    h2, r2 = dvg.load_excel(str(path), sheet_name="departments")
    assert h2 == ["id", "dept"]
    assert r2 == [["11", "IT"]]


def test_load_excel_missing_sheet_exits(tmp_path, capsys):
    openpyxl = pytest.importorskip("openpyxl")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "employees"
    ws.append(["id"])
    path = tmp_path / "book.xlsx"
    wb.save(path)
    wb.close()

    with pytest.raises(SystemExit) as ex:
        dvg.load_excel(str(path), sheet_name="missing")

    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "Sheet 'missing' not found" in out


def test_load_excel_import_error(monkeypatch, tmp_path, capsys):
    path = tmp_path / "book.xlsx"
    path.write_text("not really xlsx", encoding="utf-8")

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "openpyxl":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    with pytest.raises(SystemExit) as ex:
        dvg.load_excel(str(path))
    assert ex.value.code == 1
    assert "openpyxl is required" in capsys.readouterr().out


def test_load_excel_empty_raw_returns_empty(monkeypatch):
    class FakeSheet:
        def iter_rows(self, values_only=True):
            return []

    class FakeWorkbook:
        sheetnames = ["employees"]
        active = FakeSheet()

        def __getitem__(self, name):
            return self.active

        def close(self):
            return None

    monkeypatch.setitem(sys.modules, "openpyxl", object())
    monkeypatch.setattr(dvg, "load_excel", dvg.load_excel)

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "openpyxl":
            class FakeModule:
                @staticmethod
                def load_workbook(path, read_only=True, data_only=True):
                    return FakeWorkbook()

            return FakeModule()
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    header, rows = dvg.load_excel("ignored.xlsx")
    assert header == []
    assert rows == []


def test_load_table_csv_sheet_name_disallowed_and_unsupported_extension(tmp_path, capsys):
    csv_path = tmp_path / "a.csv"
    csv_path.write_text("id\n1\n", encoding="utf-8")

    with pytest.raises(SystemExit):
        dvg.load_table(str(csv_path), sheet_name="employees")

    txt_path = tmp_path / "a.txt"
    txt_path.write_text("hello", encoding="utf-8")
    with pytest.raises(SystemExit):
        dvg.load_table(str(txt_path))

    out = capsys.readouterr().out
    assert "requires Excel input" in out
    assert "Unsupported file extension" in out


def test_load_table_csv_without_sheet(tmp_path):
    csv_path = tmp_path / "ok.csv"
    csv_path.write_text("id,name\n1,Alice\n", encoding="utf-8")
    header, rows = dvg.load_table(str(csv_path))
    assert header == ["id", "name"]
    assert rows == [["1", "Alice"]]


def test_load_table_excel_branch(monkeypatch):
    monkeypatch.setattr(dvg, "load_excel", lambda path, sheet_name=None: (["id"], [["1"]]))
    header, rows = dvg.load_table("book.xlsx", sheet_name="employees")
    assert header == ["id"]
    assert rows == [["1"]]


def test_is_excel_path_and_parse_sheet_mapping(capsys):
    assert dvg.is_excel_path("a.xlsx") is True
    assert dvg.is_excel_path("a.xlsm") is True
    assert dvg.is_excel_path("a.xltx") is True
    assert dvg.is_excel_path("a.csv") is False

    assert dvg.parse_sheet_mapping("s1:t1, s2:t2") == [("s1", "t1"), ("s2", "t2")]
    assert dvg.parse_sheet_mapping("s1:t1, , s2:t2") == [("s1", "t1"), ("s2", "t2")]

    with pytest.raises(SystemExit):
        dvg.parse_sheet_mapping("s1")
    with pytest.raises(SystemExit):
        dvg.parse_sheet_mapping("s1:")
    with pytest.raises(SystemExit):
        dvg.parse_sheet_mapping("   ")

    out = capsys.readouterr().out
    assert "Invalid --sheet-mapping format" in out
    assert "Invalid --sheet-mapping pair" in out
    assert "--sheet-mapping is empty" in out


def test_compare_rowcount_pass_and_fail():
    passed, reason, mismatches = dvg.compare_rowcount([[1]], [[2]])
    assert passed is True
    assert "Row counts match" in reason
    assert mismatches == []

    passed2, reason2, _ = dvg.compare_rowcount([[1]], [[2], [3]])
    assert passed2 is False
    assert "Row count mismatch" in reason2


def test_compare_row_col_mismatch_types_and_header_conditions():
    src_header = ["employee_id", "name", "extra_src"]
    tgt_header = ["employee_id", "fullname"]
    src_rows = [
        ["1", "Alice", "x"],
        ["2", "", ""],
        ["", "Ghost", "g"],
    ]
    tgt_rows = [
        ["1", "Alicia"],
        ["3", "Bob", "y"],
        ["", "Ghost", ""],
    ]

    passed, reason, mismatches = dvg.compare_row_col(src_header, src_rows, tgt_header, tgt_rows)
    assert passed is False
    assert "Found" in reason
    types = {m["type"] for m in mismatches}
    assert "HEADER_LENGTH" in types
    assert "HEADER_NAME" in types
    assert "CELL" in types
    assert "SRC_ONLY" in types
    assert "TGT_ONLY" in types


def test_compare_row_col_rowcount_and_empty_headers_path():
    passed, _, mismatches = dvg.compare_row_col(["id"], [["1"]], ["id"], [["1"], ["2"]])
    assert passed is False
    assert any(m["type"] == "ROWCOUNT" for m in mismatches)

    passed2, reason2, mismatches2 = dvg.compare_row_col([], [["A"]], [], [["B"]])
    assert passed2 is True
    assert reason2 == "All rows and columns match."
    assert mismatches2 == []


def test_compare_row_col_pass_and_fallback_col_name():
    passed, reason, mismatches = dvg.compare_row_col(["id"], [["1"]], ["id"], [["1"]])
    assert passed is True
    assert reason == "All rows and columns match."
    assert mismatches == []

    passed2, _, mismatches2 = dvg.compare_row_col(["id"], [["1", "A"]], ["id"], [["1", "B"]])
    assert passed2 is False
    assert mismatches2[0]["column"].startswith("col_")


def test_compare_row_col_tgt_header_column_name_and_key_fallback_branch():
    passed, _, mismatches = dvg.compare_row_col(["id"], [["1"]], ["id", "name"], [["1", "Neo"]])
    assert passed is False
    assert any(item["column"] == "name" for item in mismatches)

    # Header without preferred key name uses first column fallback for key mapping.
    passed2, _, mismatches2 = dvg.compare_row_col(["key"], [["1"]], ["key"], [["2"]])
    assert passed2 is False
    assert mismatches2[0]["type"] in {"SRC_ONLY", "TGT_ONLY", "CELL"}


def test_resolve_output_path(tmp_path):
    assert dvg.resolve_output_path(None) is None

    out = dvg.resolve_output_path(str(tmp_path / "out_<datetime>.html"))
    assert out.endswith(".html")
    assert "<datetime>" not in out

    out2 = dvg.resolve_output_path(str(tmp_path / "out_<datetime<.html"))
    assert "<datetime<" not in out2


def test_main_error_paths(monkeypatch, capsys):
    args = Namespace(
        src_path="missing_src.csv",
        tgt_path="missing_tgt.csv",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    assert "Source file not found" in capsys.readouterr().out

    args2 = Namespace(
        src_path="src.csv",
        tgt_path="missing_tgt.csv",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args2)
    monkeypatch.setattr(dvg.os.path, "exists", lambda p: p == "src.csv")

    with pytest.raises(SystemExit) as ex2:
        dvg.main()
    assert ex2.value.code == 1
    assert "Target file not found" in capsys.readouterr().out


def test_main_sheet_mapping_requires_excel(monkeypatch, capsys):
    args = Namespace(
        src_path="src.csv",
        tgt_path="tgt.csv",
        sheet_mapping="a:b",
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)
    monkeypatch.setattr(dvg.os.path, "exists", lambda _: True)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    assert "supported only for Excel files" in capsys.readouterr().out


def test_main_invalid_chunk_size(monkeypatch, capsys):
    args = Namespace(
        src_path="src.csv",
        tgt_path="tgt.csv",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
        chunk_size=0,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    assert "--chunk-size must be a positive integer" in capsys.readouterr().out


def test_main_invalid_validation_type(monkeypatch, capsys):
    args = Namespace(
        src_path="src.xlsx",
        tgt_path="tgt.xlsx",
        sheet_mapping=None,
        src_sheet="s",
        tgt_sheet="t",
        validation_type="BAD",
        html_output=None,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)
    monkeypatch.setattr(dvg.os.path, "exists", lambda _: True)

    def fake_load_table(path, sheet_name=None):
        return ["id"], [["1"]]

    monkeypatch.setattr(dvg, "load_table", fake_load_table)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    assert "Unsupported validation type" in capsys.readouterr().out


def test_main_success_no_html_output(monkeypatch, capsys):
    args = Namespace(
        src_path="src.xlsx",
        tgt_path="tgt.xlsx",
        sheet_mapping=None,
        src_sheet="employees",
        tgt_sheet="employees",
        validation_type="ROWCOUNT",
        html_output=None,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)
    monkeypatch.setattr(dvg.os.path, "exists", lambda _: True)

    monkeypatch.setattr(dvg, "load_table", lambda *_, **__: (["id"], [["1"], ["2"]]))

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 0
    assert "PASSED" in capsys.readouterr().out


def test_main_sheet_mapping_with_html_output_and_mismatch_preview(monkeypatch, capsys):
    args = Namespace(
        src_path="src.xlsx",
        tgt_path="tgt.xlsx",
        sheet_mapping="employees:employees,departments:departments",
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT,ROW_COL_VALIDATION",
        html_output="output/report_<datetime>.html",
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)
    monkeypatch.setattr(dvg.os.path, "exists", lambda _: True)
    monkeypatch.setattr(dvg, "is_excel_path", lambda _: True)
    monkeypatch.setattr(
        dvg,
        "parse_sheet_mapping",
        lambda _: [("employees", "employees"), ("departments", "departments")],
    )

    load_calls = []

    def fake_load_table(path, sheet_name=None):
        load_calls.append((path, sheet_name))
        if sheet_name == "employees":
            return ["id"], [["1"], ["2"]]
        return ["id"], [["10"]]

    monkeypatch.setattr(dvg, "load_table", fake_load_table)

    monkeypatch.setattr(dvg, "compare_rowcount", lambda s, t: (True, "rowcount ok", []))

    mismatch = {
        "type": "CELL",
        "row": 2,
        "column": "name",
        "src": "A",
        "tgt": "B",
        "reason": "Cell value mismatch",
    }
    monkeypatch.setattr(dvg, "compare_row_col", lambda *_, **__: (False, "rowcol bad", [mismatch]))
    monkeypatch.setattr(dvg, "resolve_output_path", lambda _: "output/report_test.html")

    called = {}

    def fake_write_html_report(**kwargs):
        called.update(kwargs)

    monkeypatch.setattr(dvg, "write_html_report", fake_write_html_report)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1

    out = capsys.readouterr().out
    assert "FAILED" in out
    assert "Mismatch preview" in out
    assert "employees->employees" in out

    assert len(load_calls) == 4
    assert called["path"] == "output/report_test.html"
    assert called["src_rows_count"] == 3
    assert called["tgt_rows_count"] == 3


def test_main_active_sheet_label_and_rowcount_mismatch_tagging(monkeypatch):
    args = Namespace(
        src_path="src.xlsx",
        tgt_path="tgt.xlsx",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output="output/report_<datetime>.html",
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)
    monkeypatch.setattr(dvg.os.path, "exists", lambda _: True)
    monkeypatch.setattr(dvg, "load_table", lambda *_, **__: (["id"], [["1"]]))

    rc_item = {
        "type": "ROWCOUNT",
        "row": 0,
        "column": "<ROWCOUNT>",
        "src": "1",
        "tgt": "2",
        "reason": "Data row count mismatch",
    }
    monkeypatch.setattr(dvg, "compare_rowcount", lambda s, t: (False, "rc bad", [rc_item]))
    monkeypatch.setattr(dvg, "resolve_output_path", lambda _: "output/active_report.html")

    captured = {}
    monkeypatch.setattr(dvg, "write_html_report", lambda **kwargs: captured.update(kwargs))

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    assert captured["mismatches"][0]["reason"].startswith("[<active_sheet>]")


# ============================================================================
# Tests for numeric comparison and DB validation path
# ============================================================================

def test_values_are_equal_numeric_decimals():
    """Test numeric comparison with varying decimal places."""
    assert dvg._values_are_equal("130522.40", "130522.4") is True
    assert dvg._values_are_equal("100.00", "100") is True
    assert dvg._values_are_equal("99.9", "99.90") is True
    assert dvg._values_are_equal("0", "0.0") is True
    assert dvg._values_are_equal("-5.5", "-5.50") is True


def test_values_are_equal_numeric_mismatch():
    """Test that different numeric values are not equal."""
    assert dvg._values_are_equal("123.456", "123.457") is False
    assert dvg._values_are_equal("100", "101") is False
    assert dvg._values_are_equal("1.0", "2.0") is False


def test_values_are_equal_string_comparison():
    """Test string comparison when not numeric."""
    assert dvg._values_are_equal("abc", "abc") is True
    assert dvg._values_are_equal("abc", "abd") is False
    assert dvg._values_are_equal("", "") is True
    assert dvg._values_are_equal("   ", "   ") is True


def test_values_are_equal_whitespace_handling():
    """Test whitespace trimming before comparison."""
    assert dvg._values_are_equal("  hello  ", "hello") is True
    assert dvg._values_are_equal("  123.45  ", "123.45") is True
    assert dvg._values_are_equal("  ", "") is True


def test_values_are_equal_mixed_types():
    """Test comparison with non-string types."""
    assert dvg._values_are_equal(123, "123") is True
    assert dvg._values_are_equal(123.45, "123.45") is True
    # None converts to string "None", which does not equal ""
    assert dvg._values_are_equal(None, "") is False
    # But empty string equals empty string
    assert dvg._values_are_equal("", "") is True


def test_run_db_validation_missing_src_db_flag(monkeypatch, capsys):
    """Test that _run_db_validation fails if --src-db is missing."""
    args = Namespace(
        src_db=None,
        tgt_db="mysql",
        src_table="employees",
        tgt_table=None,
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    assert "--src-db is required" in capsys.readouterr().out


def test_run_db_validation_missing_tgt_db_flag(monkeypatch, capsys):
    """Test that _run_db_validation fails if --tgt-db is missing."""
    args = Namespace(
        src_db="postgresql",
        tgt_db=None,
        src_table="employees",
        tgt_table=None,
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    assert "--tgt-db is required" in capsys.readouterr().out


def test_run_db_validation_missing_src_table_flag(monkeypatch, capsys):
    """Test that _run_db_validation fails if --src-table is missing."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table=None,
        tgt_table=None,
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    assert "--src-table is required" in capsys.readouterr().out


def test_run_db_validation_unsupported_validation_type(monkeypatch, capsys):
    """Test that _run_db_validation fails for unsupported validation types."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table=None,
        validation_type="INVALID_TYPE",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    assert "Unsupported validation type" in capsys.readouterr().out


def test_run_db_validation_database_load_error(monkeypatch, capsys):
    """Test that _run_db_validation handles database connection errors."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table=None,
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    # Mock the dvg_db module before _run_db_validation is called
    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (_ for _ in ()).throw(Exception("Connection refused"))

    # Insert into sys.modules so the import inside _run_db_validation finds it
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    assert "Database load error" in capsys.readouterr().out


def test_run_db_validation_rowcount_success(monkeypatch, capsys):
    """Test successful DB validation with ROWCOUNT only."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id", "name"], [["1", "Alice"], ["2", "Bob"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 0
    out = capsys.readouterr().out
    assert "PASSED" in out
    assert "[ROWCOUNT]" in out


def test_run_db_validation_row_col_validation_success(monkeypatch, capsys):
    """Test successful DB validation with ROW_COL_VALIDATION."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROW_COL_VALIDATION",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id", "name"], [["1", "Alice"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 0
    out = capsys.readouterr().out
    assert "PASSED" in out
    assert "[ROW_COL_VALIDATION]" in out


def test_run_db_validation_rowcount_failure(monkeypatch, capsys):
    """Test DB validation failure due to rowcount mismatch."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")

    call_count = [0]

    def fake_load(*_, **kwargs):
        # Return different row counts for src and tgt
        call_count[0] += 1
        if call_count[0] == 1:  # First call (src)
            return ["id"], [["1"], ["2"], ["3"]]
        else:  # Second call (tgt)
            return ["id"], [["1"], ["2"]]

    mock_dvg_db.load_db_table = fake_load
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "FAILED" in out
    assert "Row count mismatch" in out


def test_run_db_validation_with_html_output(monkeypatch, capsys, tmp_path):
    """Test DB validation with HTML output."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=str(tmp_path / "report_<datetime>.html"),
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id"], [["1"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 0
    out = capsys.readouterr().out
    assert "HTML report" in out


def test_main_db_mode_calls_run_db_validation(monkeypatch, capsys):
    """Test that main() delegates to _run_db_validation for DB mode."""
    args = Namespace(
        file_type="DB",
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table=None,
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id"], [["1"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 0
    out = capsys.readouterr().out
    assert "PASSED" in out


def test_run_db_validation_row_col_failure_with_mismatches(monkeypatch, capsys):
    """Test DB validation failure with ROW_COL_VALIDATION that produces mismatches preview."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT,ROW_COL_VALIDATION",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id", "name"], [["1", "Alice"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    # Mock compare_row_col to return mismatches
    original_compare = dvg.compare_row_col
    mismatch = {
        "type": "CELL",
        "row": 2,
        "column": "name",
        "src": "Alice",
        "tgt": "Bob",
        "reason": "Cell value mismatch",
    }
    monkeypatch.setattr(dvg, "compare_row_col", lambda *_, **__: (False, "rowcol failed", [mismatch]))

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "FAILED" in out
    assert "Mismatch preview" in out
    assert "Cell value mismatch" in out


def test_run_db_validation_html_output_on_failure(monkeypatch, capsys, tmp_path):
    """Test DB validation HTML output is created even on failure."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT,ROW_COL_VALIDATION",
        db_config="database_config.ini",
        html_output=str(tmp_path / "report_<datetime>.html"),
        chunk_size=1000,
    )

    import sys
    import types

    mock_dvg_db = types.ModuleType("dvg_db")
    mock_dvg_db.load_db_table = lambda *_, **__: (["id"], [["1"]])
    monkeypatch.setitem(sys.modules, "dvg_db", mock_dvg_db)

    # Mock comparison to fail
    monkeypatch.setattr(dvg, "compare_rowcount", lambda *_, **__: (False, "rowcount failed", []))

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "FAILED" in out
    assert "HTML report" in out


def test_run_db_validation_uses_package_fallback_import(monkeypatch):
    """Cover fallback path when top-level dvg_db import is unavailable."""
    args = Namespace(
        src_db="postgresql",
        tgt_db="mysql",
        src_table="employees",
        tgt_table="employees",
        validation_type="ROWCOUNT",
        db_config="database_config.ini",
        html_output=None,
        chunk_size=1000,
    )

    import builtins
    import data_validation_gini.dvg_db as pkg_dvg_db

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "dvg_db":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    monkeypatch.setattr(
        pkg_dvg_db,
        "load_db_table",
        lambda *_, **__: (["id"], [["1"]]),
    )

    with pytest.raises(SystemExit) as ex:
        dvg._run_db_validation(args)
    assert ex.value.code == 0


def test_main_tgt_path_not_found(monkeypatch, capsys):
    """Test main() error handling when target file doesn't exist."""
    args = Namespace(
        file_type="EXCEL",
        src_path="src.csv",
        tgt_path="missing_tgt.csv",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
        chunk_size=1000,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    def file_exists(path):
        # Only src.csv exists
        return path == "src.csv"

    monkeypatch.setattr(dvg.os.path, "exists", file_exists)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "Target file not found" in out


def test_main_src_path_missing_flag(monkeypatch, capsys):
    """Test main() when --src-path is not provided in EXCEL mode."""
    args = Namespace(
        file_type="EXCEL",
        src_path=None,
        tgt_path="tgt.csv",
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
        chunk_size=1000,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "--src-path is required" in out


def test_main_tgt_path_missing_flag(monkeypatch, capsys):
    """Test main() when --tgt-path is not provided in EXCEL mode."""
    args = Namespace(
        file_type="EXCEL",
        src_path="src.csv",
        tgt_path=None,
        sheet_mapping=None,
        src_sheet=None,
        tgt_sheet=None,
        validation_type="ROWCOUNT",
        html_output=None,
        chunk_size=1000,
    )
    monkeypatch.setattr(dvg, "parse_args", lambda: args)

    def file_exists(path):
        # src.csv exists, but tgt_path is None
        return path == "src.csv"

    monkeypatch.setattr(dvg.os.path, "exists", file_exists)

    with pytest.raises(SystemExit) as ex:
        dvg.main()
    assert ex.value.code == 1
    out = capsys.readouterr().out
    assert "--tgt-path is required" in out
