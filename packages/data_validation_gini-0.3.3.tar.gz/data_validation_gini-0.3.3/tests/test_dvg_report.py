import data_validation_gini.dvg_report as dvg_report


def test_safe_int_and_normalize():
    assert dvg_report._safe_int("5") == 5
    assert dvg_report._safe_int("abc") == 0

    assert dvg_report._normalize_column_name("full name") == "full_name"
    assert dvg_report._normalize_column_name("", fallback="x") == "x"


def test_column_pair_for_mismatch():
    header_item = {"type": "HEADER_NAME", "column": "col_1", "src": "first name", "tgt": "first_name"}
    assert dvg_report._column_pair_for_mismatch(header_item) == ("src_first_name", "tgt_first_name")

    cell_item = {"type": "CELL", "column": "email"}
    assert dvg_report._column_pair_for_mismatch(cell_item) == ("src_email", "tgt_email")


def test_group_mismatches_and_metrics():
    mismatches = [
        {"type": "CELL", "row": 2, "column": "email", "src": "a@x", "tgt": "b@x", "reason": "Cell value mismatch"},
        {"type": "CELL", "row": 2, "column": "email", "src": "a@x", "tgt": "b@x", "reason": "Cell value mismatch"},
        {"type": "SRC_ONLY", "row": 3, "column": "id", "src": "3", "tgt": "", "reason": "Source-only value (target missing or blank)"},
        {"type": "TGT_ONLY", "row": 4, "column": "id", "src": "", "tgt": "4", "reason": "Target-only value (source missing or blank)"},
        {"type": "CELL", "row": 1, "column": "header", "src": "A", "tgt": "B", "reason": "Header name mismatch"},
    ]

    grouped = dvg_report._group_mismatches(mismatches)
    assert len(grouped) == 4

    metrics = dvg_report.build_report_metrics(10, 12, mismatches)
    assert metrics["src_count"] == 10
    assert metrics["tgt_count"] == 12
    assert metrics["failed"] == 3
    assert metrics["passed"] == 9
    assert metrics["src_only"] == 1
    assert metrics["tgt_only"] == 1

    zero_metrics = dvg_report.build_report_metrics(0, 0, [])
    assert zero_metrics["pass_rate"] == 100.0
    assert zero_metrics["failed_rate"] == 0.0


def test_render_mismatch_rows_and_empty_case():
    assert "No mismatches" in dvg_report._render_mismatch_rows([])

    mismatches = [
        {"type": "CELL", "row": 2, "column": "email", "src": "a<1>", "tgt": "b&2", "reason": "Cell value mismatch"},
        {"type": "SRC_ONLY", "row": 3, "column": "department id", "src": "11", "tgt": "", "reason": "Source-only value (target missing or blank)"},
        {"type": "TGT_ONLY", "row": 4, "column": "department id", "src": "", "tgt": "12", "reason": "Target-only value (source missing or blank)"},
    ]

    html_rows = dvg_report._render_mismatch_rows(mismatches)
    assert "<td>CELL</td>" in html_rows
    assert "email" in html_rows
    assert "a&lt;1&gt;" in html_rows
    assert "b&amp;2" in html_rows
    assert "<td>—</td>" in html_rows


def test_generate_html_report_and_write(tmp_path):
    mismatches = [
        {"type": "CELL", "row": 2, "column": "email", "src": "a", "tgt": "b", "reason": "Cell value mismatch"},
    ]
    metrics = dvg_report.build_report_metrics(2, 2, mismatches)

    html_passed = dvg_report.generate_html_report(
        passed=True,
        summary="all good",
        src_path="src.csv",
        tgt_path="tgt.csv",
        validation_type="ROWCOUNT",
        mismatches=[],
        metrics=metrics,
    )
    assert 'status-pill">PASSED' in html_passed
    assert "kpi-card success" in html_passed

    html_failed = dvg_report.generate_html_report(
        passed=False,
        summary="bad",
        src_path="src.csv",
        tgt_path="tgt.csv",
        validation_type="ROW_COL_VALIDATION",
        mismatches=mismatches,
        metrics=metrics,
    )
    assert 'status-pill">FAILED' in html_failed
    assert "Mismatch Details" in html_failed

    out_file = tmp_path / "report.html"
    dvg_report.write_html_report(
        path=str(out_file),
        passed=False,
        summary="bad",
        src_path="src.csv",
        tgt_path="tgt.csv",
        validation_type="ROW_COL_VALIDATION",
        mismatches=mismatches,
        src_rows_count=2,
        tgt_rows_count=2,
    )

    written = out_file.read_text(encoding="utf-8")
    assert "DVG Data Validation Report" in written
    assert "Filter mismatching columns" in written
