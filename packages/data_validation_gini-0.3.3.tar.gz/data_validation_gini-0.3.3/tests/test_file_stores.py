import configparser

import pytest

from data_validation_gini.file_stores import IniConfigStore, JsonFileStore


def test_ini_config_store_read_write_and_section(tmp_path):
    ini_path = tmp_path / "database_config.ini"
    store = IniConfigStore(ini_path)

    config = configparser.ConfigParser()
    config["postgresql"] = {
        "engine": "postgresql",
        "host": "localhost",
        "port": "5432",
    }
    store.write(config)

    loaded = store.read()
    assert loaded["postgresql"]["engine"] == "postgresql"

    section = store.read_section("postgresql")
    assert section["host"] == "localhost"


def test_ini_config_store_missing_file_and_section(tmp_path):
    missing = IniConfigStore(tmp_path / "missing.ini")
    with pytest.raises(FileNotFoundError):
        missing.read()

    ini_path = tmp_path / "config.ini"
    store = IniConfigStore(ini_path)
    cfg = configparser.ConfigParser()
    cfg["sqlite"] = {"engine": "sqlite"}
    store.write(cfg)

    with pytest.raises(ValueError):
        store.read_section("postgresql")


def test_json_file_store_read_write(tmp_path):
    json_path = tmp_path / "summary.json"
    store = JsonFileStore(json_path)

    payload = {"ok": True, "count": 3, "items": ["a", "b"]}
    store.write(payload)
    loaded = store.read()

    assert loaded == payload


def test_json_file_store_default_and_missing(tmp_path):
    json_path = tmp_path / "missing.json"
    store = JsonFileStore(json_path)

    assert store.read(default={"ok": False}) == {"ok": False}

    with pytest.raises(FileNotFoundError):
        store.read()
