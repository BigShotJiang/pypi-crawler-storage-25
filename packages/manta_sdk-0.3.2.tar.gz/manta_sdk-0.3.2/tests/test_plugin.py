"""
Unit tests for MantaPlugin — the programmatic pytest result collector.

Tests verify:
  - report.duration is used for timing (not perf_counter)
  - passed / failed / skipped phases map correctly to RunStatus
  - only "call" phase reports are captured (not setup/teardown)
  - build_result() produces correct aggregation
  - end-to-end: plugin.main([...], plugins=[plugin]) collects real pytest results
"""

from __future__ import annotations

import textwrap
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock
from uuid import UUID, uuid4

import pytest

from manta_sdk.models import RunStatus
from manta_sdk.plugin import MantaPlugin

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_report(
    nodeid: str = "test_foo.py::test_bar",
    when: str = "call",
    outcome: str = "passed",
    duration: float = 0.123,
    capstdout: str = "",
    longrepr: Any = None,
) -> MagicMock:
    """Construct a fake pytest.TestReport with only the fields MantaPlugin reads."""
    report = MagicMock(spec=pytest.TestReport)
    report.nodeid = nodeid
    report.when = when
    report.passed = outcome == "passed"
    report.failed = outcome == "failed"
    report.skipped = outcome == "skipped"
    report.duration = duration
    report.capstdout = capstdout
    report.longrepr = longrepr
    return report


def _record(plugin: MantaPlugin, report: MagicMock) -> None:
    """Simulate pytest calling pytest_runtest_logreport."""
    gen = plugin.pytest_runtest_logreport(report)
    next(gen)  # run up to yield
    try:
        next(gen)
    except StopIteration:
        pass


# ---------------------------------------------------------------------------
# Phase filtering
# ---------------------------------------------------------------------------


class TestPhaseFiltering:
    def test_setup_phase_ignored(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(when="setup", outcome="passed"))
        assert plugin._results == []

    def test_teardown_phase_ignored(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(when="teardown", outcome="passed"))
        assert plugin._results == []

    def test_call_phase_captured(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(when="call", outcome="passed"))
        assert len(plugin._results) == 1


# ---------------------------------------------------------------------------
# Status mapping
# ---------------------------------------------------------------------------


class TestStatusMapping:
    def test_passed_maps_to_passed(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="passed"))
        assert plugin._results[0].status == RunStatus.PASSED

    def test_failed_maps_to_failed(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="failed", longrepr="AssertionError"))
        assert plugin._results[0].status == RunStatus.FAILED

    def test_skipped_maps_to_error(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="skipped", longrepr="skip reason"))
        assert plugin._results[0].status == RunStatus.ERROR

    def test_failed_captures_longrepr_as_error_message(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="failed", longrepr="line 42: assert False"))
        assert plugin._results[0].error_message == "line 42: assert False"

    def test_passed_has_no_error_message(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="passed"))
        assert plugin._results[0].error_message is None


# ---------------------------------------------------------------------------
# Timing — uses report.duration, not perf_counter
# ---------------------------------------------------------------------------


class TestTiming:
    def test_duration_ms_derived_from_report_duration(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(duration=1.5))
        assert plugin._results[0].duration_ms == 1500

    def test_sub_millisecond_duration_rounds_to_zero(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(duration=0.0004))
        assert plugin._results[0].duration_ms == 0

    def test_zero_duration_produces_zero_ms(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(duration=0.0))
        assert plugin._results[0].duration_ms == 0


# ---------------------------------------------------------------------------
# stdout capture
# ---------------------------------------------------------------------------


class TestStdoutCapture:
    def test_stdout_is_captured(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(capstdout="hello world"))
        assert plugin._results[0].stdout == "hello world"

    def test_empty_stdout_is_empty_string(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(capstdout=""))
        assert plugin._results[0].stdout == ""

    def test_none_capstdout_becomes_empty_string(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(capstdout=None))
        assert plugin._results[0].stdout == ""


# ---------------------------------------------------------------------------
# build_result aggregation
# ---------------------------------------------------------------------------


class TestBuildResult:
    def test_all_passed_produces_passed_status(self) -> None:
        plugin = MantaPlugin(uuid4())
        for _ in range(3):
            _record(plugin, _make_report(outcome="passed"))
        result = plugin.build_result()
        assert result.status == RunStatus.PASSED
        assert result.passed == 3
        assert result.failed == 0
        assert result.total_tests == 3

    def test_any_failure_produces_failed_status(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="passed"))
        _record(plugin, _make_report(outcome="failed"))
        result = plugin.build_result()
        assert result.status == RunStatus.FAILED
        assert result.passed == 1
        assert result.failed == 1

    def test_no_tests_produces_error_status(self) -> None:
        plugin = MantaPlugin(uuid4())
        result = plugin.build_result()
        assert result.status == RunStatus.ERROR
        assert result.total_tests == 0

    def test_duration_ms_is_sum_of_individual(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(duration=0.1))
        _record(plugin, _make_report(duration=0.2))
        result = plugin.build_result()
        assert result.duration_ms == 300

    def test_run_id_preserved_in_result(self) -> None:
        run_id = UUID("12345678-1234-5678-1234-567812345678")
        plugin = MantaPlugin(run_id)
        _record(plugin, _make_report(outcome="passed"))
        result = plugin.build_result()
        assert result.run_id == run_id

    def test_test_cases_list_contains_all_results(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(nodeid="test_a.py::test_one", outcome="passed"))
        _record(plugin, _make_report(nodeid="test_a.py::test_two", outcome="failed"))
        result = plugin.build_result()
        names = [tc.name for tc in result.test_cases]
        assert "test_a.py::test_one" in names
        assert "test_a.py::test_two" in names

    def test_errors_counted_separately(self) -> None:
        plugin = MantaPlugin(uuid4())
        _record(plugin, _make_report(outcome="passed"))
        _record(plugin, _make_report(outcome="skipped"))
        result = plugin.build_result()
        assert result.errors == 1
        assert result.failed == 0


# ---------------------------------------------------------------------------
# End-to-end: real pytest invocation via plugin
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_real_passing_tests_collected(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test_simple.py"
        test_file.write_text(
            textwrap.dedent("""\
                def test_one():
                    assert 1 + 1 == 2

                def test_two():
                    assert "manta".startswith("m")
            """)
        )

        plugin = MantaPlugin(uuid4())
        exit_code = pytest.main([str(tmp_path), "-v", "--tb=short"], plugins=[plugin])

        assert exit_code == 0
        result = plugin.build_result()
        assert result.status == RunStatus.PASSED
        assert result.passed == 2
        assert result.total_tests == 2

    def test_real_failing_test_collected(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test_fail.py"
        test_file.write_text(
            textwrap.dedent("""\
                def test_always_fails():
                    assert False, "intentional failure"
            """)
        )

        plugin = MantaPlugin(uuid4())
        exit_code = pytest.main([str(tmp_path), "-v", "--tb=short"], plugins=[plugin])

        assert exit_code != 0
        result = plugin.build_result()
        assert result.status == RunStatus.FAILED
        assert result.failed == 1
        assert result.passed == 0

    def test_mixed_results_collected(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test_mixed.py"
        test_file.write_text(
            textwrap.dedent("""\
                def test_pass():
                    assert True

                def test_fail():
                    assert False
            """)
        )

        plugin = MantaPlugin(uuid4())
        pytest.main([str(tmp_path), "-v", "--tb=short"], plugins=[plugin])

        result = plugin.build_result()
        assert result.total_tests == 2
        assert result.passed == 1
        assert result.failed == 1

    def test_duration_ms_is_positive_for_real_tests(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test_timing.py"
        test_file.write_text("def test_something(): pass\n")

        plugin = MantaPlugin(uuid4())
        pytest.main([str(tmp_path)], plugins=[plugin])

        assert plugin._results[0].duration_ms >= 0
