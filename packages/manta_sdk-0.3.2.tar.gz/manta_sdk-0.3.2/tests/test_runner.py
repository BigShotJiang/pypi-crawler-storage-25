"""
Unit tests for BaseRunner lifecycle.

Verifies the execution engine's core contract:
  setup → execute → teardown (always, even on exception)

These tests protect the interface that all generated TestSDK modules depend on.
"""

from manta_sdk.models import RunContext, RunResult, RunStatus, TestCaseResult
from manta_sdk.runner import BaseRunner

# ---------------------------------------------------------------------------
# Helpers — concrete runner implementations for testing
# ---------------------------------------------------------------------------


def _ctx(**kwargs) -> RunContext:
    return RunContext(team_id="test-team", test_files=[], **kwargs)


class _TrackingRunner(BaseRunner):
    """Records which lifecycle hooks were called and in what order."""

    def __init__(self) -> None:
        self.calls: list[str] = []

    async def setup(self, ctx: RunContext) -> None:
        self.calls.append("setup")

    async def execute(self, ctx: RunContext) -> RunResult:
        self.calls.append("execute")
        return RunResult(run_id=ctx.run_id, status=RunStatus.PASSED, total_tests=1, passed=1)

    async def teardown(self, ctx: RunContext, result: RunResult) -> None:
        self.calls.append("teardown")


class _ExplodingRunner(BaseRunner):
    """execute() raises — teardown must still be called."""

    def __init__(self) -> None:
        self.teardown_called = False

    async def execute(self, ctx: RunContext) -> RunResult:
        msg = "boom"
        raise RuntimeError(msg)

    async def teardown(self, ctx: RunContext, result: RunResult) -> None:
        self.teardown_called = True


class _MinimalRunner(BaseRunner):
    """Only execute() implemented — setup/teardown use default no-ops."""

    async def execute(self, ctx: RunContext) -> RunResult:
        return RunResult(
            run_id=ctx.run_id,
            status=RunStatus.PASSED,
            total_tests=3,
            passed=3,
            test_cases=[
                TestCaseResult(name=f"test_{i}", status=RunStatus.PASSED, duration_ms=i * 10) for i in range(3)
            ],
        )


# ---------------------------------------------------------------------------
# Lifecycle ordering
# ---------------------------------------------------------------------------


class TestBaseRunnerLifecycle:
    async def test_setup_called_before_execute(self) -> None:
        runner = _TrackingRunner()
        await runner.run(_ctx())
        assert runner.calls.index("setup") < runner.calls.index("execute")

    async def test_execute_called_before_teardown(self) -> None:
        runner = _TrackingRunner()
        await runner.run(_ctx())
        assert runner.calls.index("execute") < runner.calls.index("teardown")

    async def test_all_three_hooks_called(self) -> None:
        runner = _TrackingRunner()
        await runner.run(_ctx())
        assert runner.calls == ["setup", "execute", "teardown"]

    async def test_teardown_called_even_when_execute_raises(self) -> None:
        runner = _ExplodingRunner()
        result = await runner.run(_ctx())
        assert runner.teardown_called is True
        assert result.status == RunStatus.ERROR

    async def test_exception_in_execute_produces_error_result(self) -> None:
        runner = _ExplodingRunner()
        result = await runner.run(_ctx())
        assert result.status == RunStatus.ERROR
        assert result.exit_code == 1

    async def test_run_returns_execute_result_on_success(self) -> None:
        runner = _TrackingRunner()
        ctx = _ctx()
        result = await runner.run(ctx)
        assert result.status == RunStatus.PASSED
        assert result.run_id == ctx.run_id

    async def test_minimal_runner_only_requires_execute(self) -> None:
        """Runners that only implement execute() are valid."""
        runner = _MinimalRunner()
        result = await runner.run(_ctx())
        assert result.status == RunStatus.PASSED
        assert result.total_tests == 3

    async def test_error_result_preserves_run_id(self) -> None:
        """The RunResult from an exception must carry the original run_id."""
        runner = _ExplodingRunner()
        ctx = _ctx()
        result = await runner.run(ctx)
        assert result.run_id == ctx.run_id

    async def test_run_result_test_cases_preserved(self) -> None:
        runner = _MinimalRunner()
        result = await runner.run(_ctx())
        assert len(result.test_cases) == 3
        assert all(tc.status == RunStatus.PASSED for tc in result.test_cases)
