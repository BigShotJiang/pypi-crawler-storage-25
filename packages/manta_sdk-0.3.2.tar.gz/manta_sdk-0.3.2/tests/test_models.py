"""
Unit tests for manta_sdk.models.

Tests the core data contracts between the Manta engine and custom runners.
"""

from uuid import UUID

from manta_sdk.models import RunContext, RunResult, RunStatus, TestCaseResult


class TestRunStatus:
    def test_all_expected_statuses_exist(self) -> None:
        statuses = {s.value for s in RunStatus}
        assert statuses == {"running", "passed", "failed", "error", "cancelled"}

    def test_is_str_enum(self) -> None:
        assert RunStatus.PASSED == "passed"


class TestRunContext:
    def test_default_run_id_is_uuid(self) -> None:
        ctx = RunContext(team_id="team-1", test_files=["/tests/test_foo.py"])
        assert isinstance(ctx.run_id, UUID)

    def test_default_env_is_empty_dict(self) -> None:
        ctx = RunContext(team_id="team-1", test_files=[])
        assert ctx.env == {}

    def test_default_timeout_is_one_hour(self) -> None:
        ctx = RunContext(team_id="team-1", test_files=[])
        assert ctx.timeout_seconds == 3600

    def test_custom_env_is_stored(self) -> None:
        ctx = RunContext(
            team_id="team-1",
            test_files=[],
            env={"FOO": "bar"},
        )
        assert ctx.env["FOO"] == "bar"


class TestRunResult:
    def test_default_counts_are_zero(self) -> None:
        result = RunResult(run_id=RunContext(team_id="t", test_files=[]).run_id, status=RunStatus.PASSED)
        assert result.total_tests == 0
        assert result.passed == 0
        assert result.failed == 0

    def test_test_cases_default_to_empty_list(self) -> None:
        result = RunResult(run_id=RunContext(team_id="t", test_files=[]).run_id, status=RunStatus.PASSED)
        assert result.test_cases == []


class TestTestCaseResult:
    def test_minimal_construction(self) -> None:
        tc = TestCaseResult(
            name="test_something",
            status=RunStatus.PASSED,
            duration_ms=42,
        )
        assert tc.error_message is None
        assert tc.stdout == ""

    def test_failed_case_stores_error_message(self) -> None:
        tc = TestCaseResult(
            name="test_explodes",
            status=RunStatus.FAILED,
            duration_ms=10,
            error_message="AssertionError: expected 1, got 2",
        )
        assert "AssertionError" in tc.error_message  # type: ignore[operator]
