"""
Manta SDK — pytest fixture helpers for generated test runners.

Provides ``make_sut_files_fixture`` for the ``github_repo`` SUT profile.
The returned fixture exposes SUT source files as on-disk paths and gives
a clear diagnostic when a test accesses a non-existent filename key.
"""

from __future__ import annotations

from pathlib import Path
from collections.abc import Iterator

import pytest


class SutFiles:
    """
    Dict-like container mapping SUT filenames → on-disk ``Path`` objects.

    Behaves like a plain ``dict[str, Path]`` for iteration, membership
    checks, and value access, but raises a descriptive ``KeyError`` that
    lists all available filenames when a missing key is accessed.

    This prevents the silent ``KeyError: 'some-binary'`` that occurs when
    AI-generated tests reference a filename that does not exist in the SUT.
    """

    def __init__(self, files: dict[str, Path]) -> None:
        self._files = files

    def __getitem__(self, key: str) -> Path:
        if key not in self._files:
            available = sorted(self._files.keys())
            raise KeyError(
                f"{key!r} is not a valid sut_files key.\n"
                f"Available filenames: {available}\n"
                f"Use one of these exact strings as the sut_files key."
            )
        return self._files[key]

    def __contains__(self, key: object) -> bool:
        return key in self._files

    def __iter__(self) -> Iterator[str]:
        return iter(self._files)

    def __len__(self) -> int:
        return len(self._files)

    def keys(self):  # noqa: ANN201
        return self._files.keys()

    def values(self):  # noqa: ANN201
        return self._files.values()

    def items(self):  # noqa: ANN201
        return self._files.items()

    def __repr__(self) -> str:
        return f"SutFiles({sorted(self._files.keys())})"


def make_sut_files_fixture(sources: dict[str, str]):  # noqa: ANN201
    """
    Return a session-scoped pytest fixture that writes SUT source files to disk.

    Usage in a generated ``conftest.py``::

        from manta_sdk.fixtures import make_sut_files_fixture

        _SUT_SOURCES: dict[str, str] = {"bank_account.py": "...", ...}
        sut_files = make_sut_files_fixture(_SUT_SOURCES)

    The fixture yields a :class:`SutFiles` instance.  Tests access individual
    files by their exact filename::

        def test_something(self, sut_files: SutFiles) -> None:
            result = subprocess.run(["python", str(sut_files["bank_account.py"]), ...])

    Args:
        sources: Mapping of ``filename → source code`` embedded at wheel-build time.

    Returns:
        A session-scoped pytest fixture function named ``sut_files``.
    """

    @pytest.fixture(scope="session")
    def sut_files(tmp_path_factory: pytest.TempPathFactory) -> SutFiles:
        """Write every SUT source file to a temp directory once per session."""
        src_dir = tmp_path_factory.mktemp("sut")
        files: dict[str, Path] = {}
        for filename, source in sources.items():
            p = src_dir / filename
            p.write_text(source, encoding="utf-8")
            files[filename] = p
        return SutFiles(files)

    return sut_files
