# manta-sdk

> Public extensible test runner SDK for the [Manta](https://github.com/EranYonai/manta) platform.

[![PyPI version](https://img.shields.io/pypi/v/manta-sdk)](https://pypi.org/project/manta-sdk/)
[![Python 3.12+](https://img.shields.io/pypi/pyversions/manta-sdk)](https://pypi.org/project/manta-sdk/)
[![License: Apache 2.0](https://img.shields.io/pypi/l/manta-sdk)](https://github.com/EranYonai/manta-sdk/blob/main/LICENSE)

Implement your own test runner by subclassing `BaseRunner`. The Manta execution
engine calls your runner, collects the result, and feeds it into the analytics
pipeline automatically.

## Installation

```bash
uv add manta-sdk
# or
pip install manta-sdk
```

## Quick start

```python
from manta_sdk import BaseRunner, RunContext, RunResult, RunStatus

class MyPytestRunner(BaseRunner):

    async def setup(self, ctx: RunContext) -> None:
        # Install dependencies, configure environment, etc.
        ...

    async def execute(self, ctx: RunContext) -> RunResult:
        # Run pytest programmatically against ctx.test_files
        ...
        return RunResult(run_id=ctx.run_id, status=RunStatus.PASSED, ...)

    async def teardown(self, ctx: RunContext, result: RunResult) -> None:
        # Upload Allure reports, clean up temp files, etc.
        ...
```

## Publishing to PyPI

### Get a PyPI API token - Dev instructions

1. Log in at [pypi.org](https://pypi.org)
2. Go to **Account Settings → API tokens → Add API token**
3. For the **first publish** of a new project, set scope to **"Entire account"** — project-scoped tokens only work after the project already exists on PyPI
4. After the first upload, you can create a narrower **project-scoped** token (`manta-sdk`) and delete the account-wide one
5. Copy the token (shown once) and add it to your shell profile (`~/.zshrc` or `~/.bashrc`):

```bash
export UV_PUBLISH_TOKEN=pypi-...
```

Then reload: `source ~/.zshrc`

### Publish

```bash
# Build
uv build

# Publish (reads UV_PUBLISH_TOKEN from environment)
uv publish --token $UV_PUBLISH_TOKEN
```

Or pass the token directly:

```bash
uv publish --token $UV_PUBLISH_TOKEN dist/manta_sdk-<version>*
```

## License

Apache 2.0 — see [LICENSE](LICENSE).
