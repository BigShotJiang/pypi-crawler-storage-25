"""Entry point for `python -m energyscope_mcp` and `energyscope-mcp` CLI."""
from energyscope_mcp.server import mcp


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
