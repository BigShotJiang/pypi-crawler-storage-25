"""Typed exceptions raised by the EnergyScope MCP client.

Importable for batch / risk scripts that need machine-readable error contracts:

    from energyscope_mcp.errors import AlignmentError
    try:
        spread("PET.RWTC.D", "NG.RNGWHHD.D")
    except AlignmentError as e:
        page_data_team(e.series, e.lag_days)

Each exception carries structured attributes in addition to a human-readable
message so consumers don't have to parse strings — strings drift across
releases, attributes don't.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Optional


class EnergyScopeError(Exception):
    """Base class for typed energyscope-mcp errors."""
    error_code: Optional[str] = None


class AlignmentError(EnergyScopeError, ValueError):
    """Raised when a cross-series tool with strict_align refuses to compute
    on a freshness-mismatched series set.

    Attributes:
        series:         all series IDs that were requested
        lag_days:       per-series staleness in days vs the freshest input
                        (the lagging series itself shows lag_days[sid] == 0)
        latest_common:  the date the call WOULD have aligned to (min of max periods)
        message:        human-readable form for logs / error rendering
    """
    error_code = "E_STALE_SERIES"

    def __init__(self, message: str, series=None, lag_days=None,
                 latest_common=None):
        super().__init__(message)
        self.message = message
        self.series = list(series or [])
        self.lag_days = dict(lag_days or {})
        # Accept ISO string or date and normalise to date.
        if isinstance(latest_common, str):
            try:
                self.latest_common: Optional[date] = datetime.strptime(
                    latest_common[:10], "%Y-%m-%d").date()
            except ValueError:
                self.latest_common = None
        else:
            self.latest_common = latest_common

    def __repr__(self) -> str:
        return (f"AlignmentError(latest_common={self.latest_common!s}, "
                f"lag_days={self.lag_days!r})")
