"""EnergyScope MCP Server — AI agent tools for energy market data and analytics."""
__version__ = "2.10.8"

from .errors import AlignmentError, EnergyScopeError

__all__ = ["AlignmentError", "EnergyScopeError", "__version__"]
