# energyscope-mcp

MCP server for AI agents to search, forecast, and analyse energy market data via EnergyScope.

17 tools: search 1.4M series, multi-factor XGBoost forecasts, Prophet, ARIMA, Theta, breakpoint detection, correlation, volatility, cointegration, and more.

## Quick Start

```bash
# No install needed — uvx runs it directly
claude mcp add energyscope -- uvx energyscope-mcp

# Set your server and API key
export ENERGYSCOPE_SERVER=grpc+tls://data.energyscope.io:443
export ENERGYSCOPE_API_KEY=your-api-key
```

Then ask Claude: *"What's the latest WTI price and has there been a regime change?"*

## Tools

**Data (6):** search, get_data, latest, browse, datasets, health

**Analytics (11):** forecast, arima, prophet, theta, breakpoints, stats, volatility, correlation, unit_root, cointegration

## Cross-series alignment

Cross-series tools (`forecast`, `spread`, `crack_spread`, `correlation`,
`rolling_correlation`, `cointegration`, `var`, `lpirf`, `elastic_net`,
`midas`, `correlate_all`, `changes`) auto-truncate every input series to
the freshest common date and emit a `⚠ ALIGNMENT:` banner explaining what
was dropped — no more silently regressing yesterday's stale predictor onto
today's fresh target.

For batch / risk scripts that should hard-fail on freshness mismatch:

```python
import os; os.environ["ENERGYSCOPE_STRICT_ALIGN"] = "1"
from energyscope_mcp import AlignmentError
try:
    spread("PET.RWTC.D", "NG.RNGWHHD.D")
except AlignmentError as e:
    page_data_team(e.series, e.lag_days)  # e.latest_common, e.error_code also available
```

Full reference: [docs/cross-series-alignment.md](docs/cross-series-alignment.md)

## Links

- Website: https://energyscope.io
- AI Integration: https://energyscope.io/ai
- Excel Add-in: https://energyscope.io/excel
- Forecasting: https://energyscope.io/forecast
- Sign up: https://energyscope.io/signup
