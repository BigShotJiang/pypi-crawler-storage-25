"""Atomic release helper for energyscope-mcp.

Bumps the three places that must stay in sync during a client release:
  1. pyproject.toml            - version = "X.Y.Z"
  2. src/energyscope_mcp/__init__.py - __version__ = "X.Y.Z"
  3. /opt/energyscope/data/mcp_releases.json on MS-02:
       - latest field
       - new entry at the top of releases list with title + changes

Usage:
  python bump_release.py 2.9.3 "title of release" "change 1" "change 2" ...
  python bump_release.py 2.9.3 --file release_notes.txt   # first line = title, rest = changes

After running, run `python -m build` then `python -m twine upload dist/energyscope_mcp-X.Y.Z*`
to actually publish. This script only updates version metadata; it does not build or upload.

Safety:
  - Refuses to run if version is not strictly greater than current pyproject.toml version
  - Refuses to run if ssh to ms02 fails
  - Dry-run mode: --dry
"""
import json
import re
import subprocess
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent
PYPROJECT = REPO_ROOT / "pyproject.toml"
INIT = REPO_ROOT / "src" / "energyscope_mcp" / "__init__.py"
MS02_RELEASES = "/opt/energyscope/data/mcp_releases.json"


def read_current_version():
    """Read the version from pyproject.toml."""
    text = PYPROJECT.read_text(encoding="utf-8")
    m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.M)
    if not m:
        raise RuntimeError("could not find version in pyproject.toml")
    return m.group(1)


def version_tuple(v):
    return tuple(int(x) for x in v.split(".") if x.isdigit())


def bump_pyproject(new_version, dry=False):
    text = PYPROJECT.read_text(encoding="utf-8")
    new_text = re.sub(
        r'^version\s*=\s*"[^"]+"',
        f'version = "{new_version}"',
        text,
        count=1,
        flags=re.M,
    )
    if new_text == text:
        raise RuntimeError("pyproject.toml version not bumped - regex failed")
    if not dry:
        PYPROJECT.write_text(new_text, encoding="utf-8")
    print(f"  [ok] pyproject.toml -> {new_version}")


def bump_init(new_version, dry=False):
    text = INIT.read_text(encoding="utf-8")
    new_text = re.sub(
        r'^__version__\s*=\s*"[^"]+"',
        f'__version__ = "{new_version}"',
        text,
        count=1,
        flags=re.M,
    )
    if new_text == text:
        raise RuntimeError("__init__.py __version__ not bumped - regex failed")
    if not dry:
        INIT.write_text(new_text, encoding="utf-8")
    print(f"  [ok] __init__.py -> {new_version}")


def bump_mcp_releases(new_version, title, changes, date_iso, dry=False):
    """Update /opt/energyscope/data/mcp_releases.json on MS-02 via ssh."""
    # Build a small Python snippet that reads the file, updates latest,
    # prepends a release entry, and writes it back. Run via ssh.
    entry = {
        "version": new_version,
        "date": date_iso,
        "title": title,
        "changes": list(changes),
    }
    payload = json.dumps({"new_version": new_version, "entry": entry})

    remote_script = f'''
import json, sys
payload = json.loads("""{payload}"""  )
path = "{MS02_RELEASES}"
d = json.load(open(path, encoding="utf-8"))
d["latest"] = payload["new_version"]
releases = d.get("releases", [])
# Skip if a release with this version already exists (idempotent re-runs)
already = any(r.get("version") == payload["new_version"] for r in releases)
if not already:
    releases.insert(0, payload["entry"])
    d["releases"] = releases
json.dump(d, open(path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("ok latest=", d["latest"], "releases=", len(d["releases"]), "inserted=", not already)
'''

    if dry:
        print(f"  [dry] (dry) would update {MS02_RELEASES} on ms02 with latest={new_version}")
        return

    result = subprocess.run(
        ["ssh", "ms02", "/opt/energyscope/dagster-env/bin/python", "-c", remote_script],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"ssh update failed:\nstdout: {result.stdout}\nstderr: {result.stderr}"
        )
    print(f"  [ok] ms02:{MS02_RELEASES} -> {result.stdout.strip()}")


def main():
    args = sys.argv[1:]
    dry = False
    if "--dry" in args:
        dry = True
        args.remove("--dry")

    if len(args) < 2:
        print(__doc__)
        sys.exit(1)

    new_version = args[0]
    if not re.match(r"^\d+\.\d+\.\d+$", new_version):
        print(f"version must be X.Y.Z, got {new_version!r}", file=sys.stderr)
        sys.exit(1)

    # Parse title + changes from remaining args or --file
    if args[1] == "--file":
        if len(args) < 3:
            print("--file requires a path", file=sys.stderr)
            sys.exit(1)
        fpath = Path(args[2])
        lines = [l.rstrip() for l in fpath.read_text(encoding="utf-8").splitlines() if l.strip()]
        if not lines:
            print(f"{fpath} is empty", file=sys.stderr)
            sys.exit(1)
        title = lines[0]
        changes = lines[1:]
    else:
        title = args[1]
        changes = args[2:]

    if not changes:
        print("at least one change entry required", file=sys.stderr)
        sys.exit(1)

    current = read_current_version()
    if version_tuple(new_version) <= version_tuple(current):
        print(
            f"refusing to bump - current {current} is not strictly less than {new_version}",
            file=sys.stderr,
        )
        sys.exit(1)

    import datetime as dt
    date_iso = dt.date.today().isoformat()

    print(f"bumping {current} -> {new_version}  ({'dry' if dry else 'live'})")
    print(f"title: {title}")
    print(f"changes: {len(changes)} entries")
    print(f"date: {date_iso}")
    print()

    bump_pyproject(new_version, dry=dry)
    bump_init(new_version, dry=dry)
    bump_mcp_releases(new_version, title, changes, date_iso, dry=dry)

    print()
    if dry:
        print("DRY RUN complete - no files changed")
    else:
        print("Done. Next:")
        print(f"  cd {REPO_ROOT}")
        print(f"  rm -rf dist && python -m build")
        print(f"  python -m twine upload --username __token__ \\")
        print(f"    --password \"$(cat '/c/Users/dl/OneDrive/Claude/EnergyScope/PyPI/PyPI token.txt')\" \\")
        print(f"    dist/energyscope_mcp-{new_version}*")


if __name__ == "__main__":
    main()
