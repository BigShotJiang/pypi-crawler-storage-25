# Cross-series alignment behaviour

A one-pager for analysts and operators using EnergyScope's cross-series tools
(`forecast`, `spread`, `crack_spread`, `correlation`, `rolling_correlation`,
`cointegration`, `var`, `lpirf`, `elastic_net`, `midas`, `correlate_all`,
`changes`).

## TL;DR

When you run a cross-series tool on series with different freshness windows,
EnergyScope **automatically truncates every series to the freshest common
date** so you never silently regress yesterday's stale predictor onto today's
fresh target. You'll see a banner explaining what was dropped, or — in
strict mode — an error refusing to compute.

## (a) The two banner types

### `⚠ ALIGNMENT: ...` — at the top of cross-series results

Means: the input series had different end dates and the tool truncated
everything to the freshest common date. Compute proceeded, but on the
truncated window. Example:

```
⚠ ALIGNMENT: Computed through 2026-03-16 to align series — PET.RWTC.D
dropped 14 trailing rows (was through 2026-03-30).
```

Read this as: WTI was fresh through 03-30 but NG only through 03-16, so
WTI's last 14 trading days were dropped. The result is honest about what
window it covers.

### `⚠ NOTE: ...` — somewhere in the result body

Means: a non-alignment caveat about the compute itself. Common examples:
single-predictor importance is trivially 1.0; a predictor was forward-filled
from a lower frequency; a univariate fallback fired because predictors
collapsed; an ARIMA fit failed and was substituted. These are content
warnings, not freshness warnings. Both can appear on the same result.

## (b) When truncate vs strict fires

| Behaviour | When |
|---|---|
| **Truncate (default)** | Any cross-series call where input series have different `max(period)`. Tool computes on the aligned window and emits the `⚠ ALIGNMENT:` banner. |
| **Strict refusal** | Same condition, but `strict_align: true` was set on the request, OR the env var `ENERGYSCOPE_STRICT_ALIGN=1` was set when the MCP / Python client was launched. The tool refuses with a typed error and emits no result. |

Use truncate for exploratory work. Use strict for batch jobs / risk scripts /
overnight pipelines where a freshness mismatch should page someone, not
silently produce numbers.

## (c) Catching `AlignmentError` in Python

```python
from energyscope_mcp import AlignmentError       # re-exported at package root
from energyscope_mcp.errors import AlignmentError # also direct
import os

os.environ["ENERGYSCOPE_STRICT_ALIGN"] = "1"     # opt the whole session in

try:
    result = spread("PET.RWTC.D", "NG.RNGWHHD.D")
except AlignmentError as e:
    print(e.message)             # human-readable
    print(e.series)              # ['PET.RWTC.D', 'NG.RNGWHHD.D']
    print(e.lag_days)            # {'PET.RWTC.D': 14, 'NG.RNGWHHD.D': 0}
    print(e.latest_common)       # datetime.date(2026, 3, 16)
    print(e.error_code)          # 'E_STALE_SERIES'
    page_data_team(e.series, e.lag_days)
```

`AlignmentError` is a subclass of both `ValueError` and `EnergyScopeError`,
so legacy `except ValueError` keeps catching it, and you can catch the whole
EnergyScope error family with `except EnergyScopeError`.

## (d) Wire-format error codes

The Flight server returns structured JSON for these failures so non-Python
clients (Dagster, Streamlit, Excel via Power Query, ad-hoc bash) can branch
on `error_code` rather than parsing `error` strings — strings drift,
codes don't.

| `error_code` | Meaning | Extra fields |
|---|---|---|
| `E_STALE_SERIES` | `strict_align` requested but input series freshness mismatched | `series` (list), `lag_days` (dict series→days), `latest_common` (YYYY-MM-DD) |

When no `error_code` is set, the response is a normal compute result.

## Version stamping

Every cross-series response carries a `server_version` field, and the MCP
layer appends a `[versions: server=YYYY.MM.DD-rN mcp=X.Y.Z]` footer. If you
save a print or screenshot, you can answer "which build produced this" from
the artifact alone — important across mid-day server hot-deploys.

## Future: per-series freshness thresholds

Today the staleness threshold (used by `latest()`) is a single rule per
frequency: D > 7d, W > 14d, M > 60d, Q > 182d, A > 730d. Real desks need
per-series overrides — WTI front-month is stale at minutes; STEO monthlies
are fresh for 30d by definition. This is parked as a future ticket.
