from __future__ import annotations

from functools import lru_cache
from pathlib import Path


DEFAULT_PROMPT = "Describe the image in a brief and concise manner."
SYSTEM_INSTRUCTION = """
You are a helpful assistant that can analyze images and provide detailed explanations of their content.

Examine the image provided and describe its contents in brief, including all relevant context or information that can be inferred from the image. Keep the description concise and to the point, focusing on the most important aspects of the image. If image looks like a logo, try to identify the brand or company it represents. If image is a chart or graph, summarize the key insights it conveys. If image contains text, transcribe the text and include it in your description.

DO NOT give a long and detailed explanation, just a brief single summary in continuous paragraph, not in a structured format of what the image contains.
""".strip()


class ImageAnalyzer:
    def __init__(
        self,
        image: bytes | str,
        inference: str,
        model: str = None,
        prompt: str = None or DEFAULT_PROMPT,
        mime_type: str = "image/png",
        max_output_tokens: int = 1024,
        temperature: float = 0.6,
    ) -> None:
        """
        Initialize the ImageAnalyzer.

        Args:
            image: The image to analyze.
            inference: The inference engine to use.
            model: The model to use.
            prompt: The prompt to use.
            mime_type: The MIME type of the image.
            max_output_tokens: The maximum number of output tokens.
            temperature: The temperature for the inference engine.
        """
        self.image = image
        self.inference = inference
        self.model = model
        self.prompt = prompt
        self.mime_type = mime_type
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.system_instruction = SYSTEM_INSTRUCTION

    def analyze_image(self) -> str:
        return self.model_factory()

    def model_factory(self) -> str:
        if self.inference=="gemini":
            return GoogleGemini(
                image_bytes=self._resolve_image_bytes(),
                prompt=self.prompt,
                model_name=self.model or "gemini-3-flash-preview",
                mime_type=self.mime_type,
                max_output_tokens=self.max_output_tokens,
                temperature=self.temperature,
            ).analyze_image()

        if self.inference=="hf_transformers":
            return HuggingFaceImageAnalyzer(
                image_bytes=self._resolve_image_bytes(),
                prompt=self.prompt,
                model_name=self.model or "Qwen/Qwen3.5-0.8B",
                mime_type=self.mime_type,
                max_output_tokens=self.max_output_tokens,
                temperature=self.temperature,
            ).analyze_image()
        
        if self.inference=="groq_ai":
            return groq_ai(
                image_bytes=self._resolve_image_bytes(),
                prompt=self.prompt,
                model_name=self.model or "meta-llama/llama-4-scout-17b-16e-instruct",
                mime_type=self.mime_type,
                max_output_tokens=self.max_output_tokens,
                temperature=self.temperature,
            ).analyze_image()

        raise ValueError(
            "Unsupported model type. Please specify 'gemini', 'hf_transformers' or 'groq_ai' in the inference argument."
        )

    def _resolve_image_bytes(self) -> bytes:
        if isinstance(self.image, bytes):
            return self.image

        if isinstance(self.image, str):
            return Path(self.image).read_bytes()

        raise TypeError("image must be image bytes or a file path string.")


class GoogleGemini:
    def __init__(
        self,
        image_bytes: bytes,
        prompt: str = None,
        model_name: str = None,
        mime_type: str = None,
        max_output_tokens: int = None,
        temperature: float = None,
    ) -> None:
        self.image_bytes = image_bytes
        self.prompt = prompt or DEFAULT_PROMPT
        self.model_name = model_name
        self.mime_type = mime_type
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.system_instruction = SYSTEM_INSTRUCTION

    def analyze_image(self) -> str:
        try:
            from google import genai
            from google.genai import types
        except ImportError as exc:
            raise ImportError(
                "google-genai package not found, please install it with `pip install google-genai`"
            )
        
        client = genai.Client()
        response = client.models.generate_content(
            model=self.model_name,
            contents=[
                types.Part.from_bytes(data=self.image_bytes, mime_type=self.mime_type),
                self.prompt,
            ],
            config=types.GenerateContentConfig(
                max_output_tokens=self.max_output_tokens,
                system_instruction=self.system_instruction,
                temperature=self.temperature,
            ),
        )

        return (response.text or "").strip()


class HuggingFaceImageAnalyzer:
    def __init__(
        self,
        image_bytes: bytes,
        prompt: str = None,
        model_name: str = None,
        mime_type: str = None,
        max_output_tokens: int = None,
        temperature: float = None,
    ) -> None:
        self.image_bytes = image_bytes
        self.prompt = prompt or DEFAULT_PROMPT
        self.model_name = model_name
        self.mime_type = mime_type
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.system_instruction = SYSTEM_INSTRUCTION

    @classmethod
    @lru_cache(maxsize=None)
    def _load_model(cls, model_name: str):
        try:
            from transformers import AutoModelForImageTextToText, AutoProcessor
            import torch
        except ImportError as exc:
            raise ImportError(
                """
                Install transformers and torch.\n
                ```
                uv add transformers torch
                ```
                """
            ) from exc

        processor = AutoProcessor.from_pretrained(model_name, dtype="auto")
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = AutoModelForImageTextToText.from_pretrained(model_name, dtype="auto").to(device)

        if getattr(processor.tokenizer, "pad_token_id", None) is None:
            processor.tokenizer.pad_token_id = processor.tokenizer.eos_token_id

        model.generation_config.pad_token_id = processor.tokenizer.eos_token_id

        return processor, model

    def analyze_image(self) -> str:
        try:
            from io import BytesIO
            from PIL import Image
            import torchvision
        except ImportError as exc:
            raise ImportError(
                """
                Install torchvision.\n
                ```
                uv add torchvision
                ```
                """
            ) from exc

        processor, model = self._load_model(self.model_name)

        image = Image.open(BytesIO(self.image_bytes)).convert("RGB")

        messages = [
            {"role": "system", "content": self.system_instruction},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": self.prompt},
                    {
                        "type": "image",
                        "image": image,
                        "mime_type": self.mime_type,
                    },
                ],
            },
        ]

        inputs = processor.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)

        outputs = model.generate(
            **inputs,
            max_new_tokens=self.max_output_tokens,
            do_sample=True,
            temperature=self.temperature,
        )

        text = processor.decode(
            outputs[0][inputs["input_ids"].shape[-1]:],
            skip_special_tokens=True,
        )
        return text.strip()
    
class groq_ai:
    def __init__(
        self,
        image_bytes: bytes,
        prompt: str = None,
        model_name: str = None,
        mime_type: str = None,
        max_output_tokens: int = None,
        temperature: float = None,
    ) -> None:
        self.image_bytes = image_bytes
        self.prompt = prompt or DEFAULT_PROMPT
        self.model_name = model_name
        self.mime_type = mime_type
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.system_instruction = SYSTEM_INSTRUCTION

    def analyze_image(self) -> str:
        try:
            import groq
            import base64
        except ImportError as exc:
            raise ImportError(
                """
                Install groq.\n
                ```
                uv add groq
                ```
                """
            ) from exc

        client = groq.Client()
        base64_image = base64.b64encode(self.image_bytes).decode('utf-8')
        response = client.chat.completions.create(
            messages = [
                {"role": "system", "content": self.system_instruction},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": self.prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{self.mime_type};base64,{base64_image}"},
                        },
                    ],
                },
            ],
            model = self.model_name,
            max_tokens = self.max_output_tokens,
            temperature = self.temperature,
        )

        return (response.choices[0].message.content or "").strip()