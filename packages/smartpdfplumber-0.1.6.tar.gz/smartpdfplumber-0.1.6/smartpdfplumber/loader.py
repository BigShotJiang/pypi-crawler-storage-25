import pathlib
from io import BufferedReader, BytesIO
from typing import Iterator, Union
from langchain_community.document_loaders.blob_loaders import Blob
from langchain_core.documents import Document
from smartpdfplumber.parser.pdf_parser import SmartPDFPlumberParser

class SmartPDFLoader:
    def __init__(self, path_or_fp: Union[str, pathlib.Path, BufferedReader, BytesIO], **parser_kwargs):
        self.path_or_fp = path_or_fp
        self.parser = SmartPDFPlumberParser(**parser_kwargs)

    def lazy_load(self) -> Iterator[Document]:
        """Lazily load documents from the PDF file."""
        if isinstance(self.path_or_fp, (str, pathlib.Path)):
            blob = Blob.from_path(str(self.path_or_fp))
        else:
            blob = Blob.from_data(self.path_or_fp.read())
        yield from self.parser.lazy_parse(blob)

    def load(self) -> list:
        """Load all documents from the PDF file."""
        return list(self.lazy_load())