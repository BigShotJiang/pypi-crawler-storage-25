from typing import (
    Any,
    Iterator,
    Mapping,
    Optional,
)
from io import BytesIO
import hashlib
import pdfplumber
from langchain_community.document_loaders.blob_loaders import Blob
from langchain_core.documents import Document
from langchain_community.document_loaders.parsers import PDFPlumberParser
from smartpdfplumber.vision.image_analyzer import ImageAnalyzer


class SmartPDFPlumberParser(PDFPlumberParser):
    """Parse `PDF` with `PDFPlumber`."""

    def __init__(
        self,
        text_kwargs: Optional[Mapping[str, Any]] = None,
        dedupe: bool = False,
        describe_image: bool = False,
        inference: str = None,
        model: str = None,
        **kwargs,
    ) -> None:
        """Initialize the parser.

        Args:
            text_kwargs: Keyword arguments to pass to ``pdfplumber.Page.extract_text()``
            dedupe: Avoiding the error of duplicate characters if `dedupe=True`.
            describe_image: Describe the image in the PDF and include the description in the page content - `describe_image={gemini: api key}`.
            inference: The inference engine to use for image analysis.
            model: The model to use for image analysis.
        """
        self.text_kwargs = text_kwargs or {}
        self.dedupe = dedupe
        self.describe_image = describe_image
        self.inference = inference
        self.model = model
        self.kwargs = kwargs

        if self.describe_image and not self.inference:
            raise ValueError("Inference engine must be provided for image description.")

    def lazy_parse(self, blob: Blob) -> Iterator[Document]:
        """Lazily parse the blob."""
        with blob.as_bytes_io() as file_path:
            # Compute SHA256 hash of the file
            file_hash = hashlib.sha256(blob.as_bytes()).hexdigest()
            
            doc = pdfplumber.open(file_path)  # open document

            yield from [
                Document(
                    page_content=(
                        self.described_image_from_page(page)
                        if self.describe_image
                        else self._process_page_content(page)
                    ),
                    metadata=dict(
                        {
                            "source": blob.source,
                            "file_path": blob.source,
                            "page": page.page_number - 1,
                            "total_pages": len(doc.pages),
                            "file_hash": file_hash,
                        },
                        **{
                            k: doc.metadata[k]
                            for k in doc.metadata
                            if type(doc.metadata[k]) in [str, int]
                        },
                    ),
                )
                for page in doc.pages
            ]

    def _process_page_content(self, page: pdfplumber.page.Page) -> str:
        """Process the page content based on dedupe."""
        text = ""
        if self.dedupe:
            text = page.dedupe_chars().extract_text(**self.text_kwargs) or ""
        else:
            text = page.extract_text(**self.text_kwargs) or ""
        return text.replace("\n", " ")

    def described_image_from_page(self, page: pdfplumber.page.Page) -> str:
        """Rebuild page content with inline image descriptions."""
        combined_elements = []

        for word in page.extract_words() or []:
            combined_elements.append({**word, "type": "text"})

        for image in page.images or []:
            combined_elements.append({**image, "type": "image"})

        combined_elements.sort(key=lambda x: (x["top"], x["x0"]))

        page_content = ""
        for element in combined_elements:
            if element["type"] == "text":
                page_content += element["text"] + " "
                continue

            image_bbox = (
                element["x0"],
                element["top"],
                element["x1"],
                element["bottom"],
            )
            img_obj = page.within_bbox(image_bbox).to_image(resolution=300, antialias=True)
            description = self._image_analysis(img_obj.original)
            if description:
                page_content += f"\n[IMAGE_CONTEXT: {description}]\n"

        return page_content.replace("\n", " ").strip()
    
    def _image_analysis(self, image) -> str:
        """Analyze the image and return a string representation."""

        buffer = BytesIO()
        image.save(buffer, format="PNG")

        analyzer = ImageAnalyzer(
            image=buffer.getvalue(),
            inference=self.inference,
            model=self.model,
            **self.kwargs,
        )
        return analyzer.analyze_image() or ""
        