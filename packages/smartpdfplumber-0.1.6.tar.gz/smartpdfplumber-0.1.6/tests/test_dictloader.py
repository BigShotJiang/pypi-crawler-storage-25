from langchain_community.document_loaders import DirectoryLoader
from smartpdfplumber.loader import SmartPDFLoader


'''
Throughput - 0.181818182s per page without image description 

The throughput mentioned above is static but with image description enabled, the throughput can vary significantly based on the complexity of the images and the performance of the inference engine. In general, you can expect a significant increase in processing time per page when image description is enabled, especially if the PDF contains many images or complex visuals. The exact throughput will depend on factors such as the size and number of images, the efficiency of the image analysis model, and the computational resources available.
'''


def test_smartpdfloader():
    loader = DirectoryLoader("./assets", glob="*.pdf", exclude="images", loader_cls=SmartPDFLoader, loader_kwargs={"dedupe": True, "describe_image": False, "inference": "hf_transformers"})

    docs = loader.load()
    for doc in docs:
        print("--- Document ---")
        # print(doc.page_content[:100])
        print(doc.metadata)