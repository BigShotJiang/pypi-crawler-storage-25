from smartpdfplumber.loader import SmartPDFLoader

def test_smartpdfloader():
    # Test with a file path
    loader = SmartPDFLoader("assets/sample.pdf", dedupe=True, describe_image=True, inference="hf_transformers")
    docs = loader.load()
    print(docs[0].page_content[:100])

    # Test with a file-like object
    # with open("assets/sample.pdf", "rb") as f:
    #     loader = SmartPDFLoader(f, dedupe=True, describe_image=True, inference="hf_transformers")
    #     docs = loader.load()
    #     return docs[0].page_content[:100]