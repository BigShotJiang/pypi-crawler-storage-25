"""
matcha.cli — Command-line interface.

Copyright (c) 2025 Keeya Labs. All rights reserved.

Usage:
    matcha run torchrun --standalone --nproc_per_node=1 train_gpt.py
    matcha wrap -p python train_gpt.py
    matcha monitor
"""

import argparse
import subprocess
import sys
import re
import time
import signal
import os
from typing import Optional

from ._engine import _Collector
from ._output import Printer

_PATTERNS = [
    re.compile(r"step\s+(\d+)", re.IGNORECASE),
    re.compile(r"step:\s*(\d+)", re.IGNORECASE),
    re.compile(r"iter\s+(\d+)", re.IGNORECASE),
    re.compile(r"iteration\s+(\d+)", re.IGNORECASE),
    re.compile(r"\[(\d+)/\d+\]"),
    re.compile(r"training\s+step\s+(\d+)", re.IGNORECASE),
]


def _detect(line: str) -> Optional[int]:
    if "warmup" in line.lower():
        return None
    for p in _PATTERNS:
        m = p.search(line)
        if m:
            return int(m.group(1))
    return None


def _run(args):
    """Run a command, pass through all output, append energy summary at the end."""
    c = _Collector(_idx=args.gpu, _iv=args.interval)
    c.start()

    proc = subprocess.Popen(
        args.command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )

    orig = signal.signal(signal.SIGINT, lambda s, f: proc.send_signal(signal.SIGINT))

    try:
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()

        proc.wait()
    finally:
        signal.signal(signal.SIGINT, orig)
        s = c.stop()

        print(
            f"matcha_energy total:{s.total_energy_j:.0f}J ({s.energy_wh:.2f}Wh) "
            f"duration:{s.total_duration_s:.1f}s avg_power:{s.avg_power_w:.0f}W "
            f"peak_power:{s.peak_power_w:.0f}W samples:{s.total_samples}"
        )

    return proc.returncode


def _wrap(args):
    """Run a command, intercept stdout for step detection, show energy per step."""
    c = _Collector(_idx=args.gpu, _iv=args.interval)
    c.start()

    pr = Printer()
    pr.header(c.gpu_name, c.power_limit_w, args.interval)

    print(f"  \033[2mrunning:\033[0m  {' '.join(args.command)}")
    print()
    print(
        f"  \033[2m{'step':>6}  {'energy':>10}  {'time':>8}  "
        f"{'avg W':>7}  {'peak W':>7}  {'power'}\033[0m"
    )
    print(f"  \033[38;5;245m{'─' * 52}\033[0m")

    last: Optional[int] = None
    active = False

    proc = subprocess.Popen(
        args.command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )

    orig = signal.signal(signal.SIGINT, lambda s, f: proc.send_signal(signal.SIGINT))

    try:
        for line in proc.stdout:
            line = line.rstrip("\n")
            det = _detect(line)

            if det is not None:
                if active and last is not None:
                    pr.step(c.mark_end(last))
                c.mark_start()
                active = True
                last = det

            if args.passthrough:
                print(f"  \033[2m│\033[0m {line}")

        if active and last is not None:
            pr.step(c.mark_end(last))

        proc.wait()
    finally:
        signal.signal(signal.SIGINT, orig)
        pr.summary(c.stop())

    return proc.returncode


def _monitor(args):
    """Monitor GPU power continuously without running a command."""
    c = _Collector(_idx=args.gpu, _iv=args.interval)
    c.start()

    pr = Printer()
    pr.header(c.gpu_name, c.power_limit_w, args.interval)

    print(f"  \033[2mmonitoring gpu {args.gpu} — press Ctrl+C to stop\033[0m\n")

    try:
        step = 0
        c.mark_start()
        while True:
            time.sleep(args.window)
            pr.step(c.mark_end(step))
            step += 1
            c.mark_start()
    except KeyboardInterrupt:
        pass
    finally:
        pr.summary(c.stop())


def main():
    parser = argparse.ArgumentParser(
        prog="matcha",
        description="⚡ matcha — GPU energy metering for AI training",
    )
    sub = parser.add_subparsers(dest="cmd")

    rp = sub.add_parser("run", help="Run a command and report total GPU energy at the end")
    rp.add_argument("--gpu", type=int, default=0)
    rp.add_argument("--interval", type=int, default=100, help="Sampling interval ms")
    rp.add_argument("command", nargs=argparse.REMAINDER)

    wp = sub.add_parser("wrap", help="Wrap a training script and meter energy per step")
    wp.add_argument("--gpu", type=int, default=0)
    wp.add_argument("--interval", type=int, default=100, help="Sampling interval ms")
    wp.add_argument("-p", "--passthrough", action="store_true", help="Show script output")
    wp.add_argument("command", nargs=argparse.REMAINDER)

    mp = sub.add_parser("monitor", help="Monitor GPU power continuously")
    mp.add_argument("--gpu", type=int, default=0)
    mp.add_argument("--interval", type=int, default=100)
    mp.add_argument("--window", type=float, default=1.0, help="Report window seconds")

    args = parser.parse_args()

    if args.cmd == "run":
        if not args.command:
            rp.error("Usage: matcha run torchrun train_gpt.py")
        if args.command[0] == "--":
            args.command = args.command[1:]
        sys.exit(_run(args))
    elif args.cmd == "wrap":
        if not args.command:
            wp.error("Usage: matcha wrap python train.py")
        if args.command[0] == "--":
            args.command = args.command[1:]
        sys.exit(_wrap(args))
    elif args.cmd == "monitor":
        _monitor(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
