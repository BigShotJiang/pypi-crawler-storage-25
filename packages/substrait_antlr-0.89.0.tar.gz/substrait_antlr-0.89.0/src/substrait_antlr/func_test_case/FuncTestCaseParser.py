# Generated from FuncTestCaseParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,125,698,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,2,60,7,60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,
        65,2,66,7,66,2,67,7,67,2,68,7,68,2,69,7,69,2,70,7,70,2,71,7,71,2,
        72,7,72,2,73,7,73,2,74,7,74,2,75,7,75,2,76,7,76,2,77,7,77,1,0,1,
        0,4,0,159,8,0,11,0,12,0,160,1,0,1,0,1,1,1,1,1,1,5,1,168,8,1,10,1,
        12,1,171,9,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,4,1,4,1,4,
        1,4,1,4,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,198,8,6,1,6,
        1,6,1,6,1,7,3,7,204,8,7,1,7,4,7,207,8,7,11,7,12,7,208,1,7,3,7,212,
        8,7,1,7,4,7,215,8,7,11,7,12,7,216,3,7,219,8,7,1,8,1,8,1,8,5,8,224,
        8,8,10,8,12,8,227,9,8,1,9,1,9,3,9,231,8,9,1,10,1,10,1,10,1,10,1,
        10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,
        10,1,10,1,10,3,10,253,8,10,1,11,1,11,1,11,1,11,1,11,3,11,260,8,11,
        1,11,1,11,1,11,1,12,1,12,1,12,1,12,3,12,269,8,12,1,12,1,12,1,12,
        1,12,1,12,1,12,3,12,277,8,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,
        3,12,286,8,12,1,13,1,13,1,13,1,13,1,13,1,13,5,13,294,8,13,10,13,
        12,13,297,9,13,1,13,1,13,1,13,1,13,1,14,1,14,1,14,1,14,5,14,307,
        8,14,10,14,12,14,310,9,14,3,14,312,8,14,1,14,1,14,1,15,1,15,1,15,
        1,15,1,16,1,16,1,16,1,16,5,16,324,8,16,10,16,12,16,327,9,16,3,16,
        329,8,16,1,16,1,16,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,
        1,17,1,17,3,17,344,8,17,1,18,1,18,1,18,5,18,349,8,18,10,18,12,18,
        352,9,18,1,19,1,19,1,19,5,19,357,8,19,10,19,12,19,360,9,19,1,20,
        1,20,1,20,1,20,3,20,366,8,20,1,21,1,21,1,21,1,21,3,21,372,8,21,1,
        22,1,22,1,22,3,22,377,8,22,1,23,1,23,1,24,1,24,1,24,1,24,1,25,1,
        25,1,25,1,25,1,26,1,26,1,26,1,26,1,27,1,27,1,27,1,27,1,28,1,28,1,
        28,1,28,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,31,1,31,1,31,1,
        31,1,32,1,32,1,32,1,32,1,33,1,33,1,33,1,33,1,34,1,34,1,34,1,34,1,
        35,1,35,1,35,1,35,1,36,1,36,1,36,1,36,1,37,1,37,1,37,1,37,1,38,1,
        38,1,38,1,38,1,39,1,39,1,39,1,39,1,40,1,40,1,40,1,40,1,41,1,41,1,
        41,1,41,1,42,1,42,1,42,1,42,1,43,1,43,1,43,1,43,5,43,461,8,43,10,
        43,12,43,464,9,43,3,43,466,8,43,1,43,1,43,1,44,1,44,3,44,472,8,44,
        1,45,1,45,1,45,1,45,1,45,1,45,1,46,1,46,1,46,1,46,1,46,4,46,485,
        8,46,11,46,12,46,486,1,46,3,46,490,8,46,1,47,1,47,1,47,1,47,1,47,
        1,48,1,48,3,48,499,8,48,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,
        1,49,3,49,510,8,49,1,49,1,49,1,49,3,49,515,8,49,3,49,517,8,49,1,
        50,1,50,3,50,521,8,50,1,51,1,51,3,51,525,8,51,1,52,1,52,3,52,529,
        8,52,1,53,1,53,3,53,533,8,53,1,54,1,54,3,54,537,8,54,1,55,1,55,3,
        55,541,8,55,1,56,1,56,3,56,545,8,56,1,57,1,57,3,57,549,8,57,1,57,
        1,57,1,57,1,57,3,57,555,8,57,1,58,1,58,3,58,559,8,58,1,58,1,58,1,
        58,1,58,3,58,565,8,58,1,59,1,59,3,59,569,8,59,1,59,1,59,1,59,1,59,
        1,60,1,60,3,60,577,8,60,1,60,1,60,1,60,1,60,1,61,1,61,3,61,585,8,
        61,1,61,1,61,1,61,1,61,1,62,1,62,3,62,593,8,62,1,62,1,62,1,62,1,
        62,1,62,1,62,3,62,601,8,62,1,63,1,63,3,63,605,8,63,1,63,1,63,1,63,
        1,63,1,64,1,64,3,64,613,8,64,1,64,1,64,1,64,1,64,1,65,1,65,3,65,
        621,8,65,1,65,1,65,1,65,1,65,1,66,1,66,3,66,629,8,66,1,66,1,66,1,
        66,1,66,1,67,1,67,3,67,637,8,67,1,67,1,67,1,67,1,67,1,67,1,67,1,
        68,1,68,1,68,1,68,1,68,5,68,650,8,68,10,68,12,68,653,9,68,1,68,1,
        68,3,68,657,8,68,1,69,1,69,1,69,1,69,1,69,1,69,1,69,1,69,1,69,1,
        69,1,69,3,69,670,8,69,1,70,1,70,1,71,1,71,1,72,1,72,1,72,1,72,1,
        73,1,73,1,74,1,74,1,75,1,75,1,75,5,75,687,8,75,10,75,12,75,690,9,
        75,1,76,1,76,1,77,1,77,3,77,696,8,77,1,77,0,0,78,0,2,4,6,8,10,12,
        14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,
        58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,
        102,104,106,108,110,112,114,116,118,120,122,124,126,128,130,132,
        134,136,138,140,142,144,146,148,150,152,154,0,21,1,0,3,4,2,0,19,
        19,27,27,2,0,56,56,82,82,2,0,63,63,83,83,2,0,64,64,84,84,1,0,57,
        60,1,0,61,62,2,0,66,66,85,85,2,0,67,67,86,86,2,0,68,68,87,87,2,0,
        74,74,92,92,2,0,75,75,93,93,2,0,76,76,94,94,2,0,70,70,88,88,2,0,
        71,71,89,89,2,0,72,72,90,90,2,0,73,73,91,91,1,0,11,12,3,0,13,14,
        22,23,124,124,5,0,15,21,24,24,28,28,46,46,124,124,2,0,24,24,119,
        120,725,0,156,1,0,0,0,2,164,1,0,0,0,4,172,1,0,0,0,6,177,1,0,0,0,
        8,182,1,0,0,0,10,187,1,0,0,0,12,189,1,0,0,0,14,218,1,0,0,0,16,220,
        1,0,0,0,18,230,1,0,0,0,20,252,1,0,0,0,22,254,1,0,0,0,24,285,1,0,
        0,0,26,287,1,0,0,0,28,302,1,0,0,0,30,315,1,0,0,0,32,319,1,0,0,0,
        34,343,1,0,0,0,36,345,1,0,0,0,38,353,1,0,0,0,40,365,1,0,0,0,42,371,
        1,0,0,0,44,376,1,0,0,0,46,378,1,0,0,0,48,380,1,0,0,0,50,384,1,0,
        0,0,52,388,1,0,0,0,54,392,1,0,0,0,56,396,1,0,0,0,58,400,1,0,0,0,
        60,404,1,0,0,0,62,408,1,0,0,0,64,412,1,0,0,0,66,416,1,0,0,0,68,420,
        1,0,0,0,70,424,1,0,0,0,72,428,1,0,0,0,74,432,1,0,0,0,76,436,1,0,
        0,0,78,440,1,0,0,0,80,444,1,0,0,0,82,448,1,0,0,0,84,452,1,0,0,0,
        86,456,1,0,0,0,88,471,1,0,0,0,90,473,1,0,0,0,92,489,1,0,0,0,94,491,
        1,0,0,0,96,498,1,0,0,0,98,516,1,0,0,0,100,518,1,0,0,0,102,522,1,
        0,0,0,104,526,1,0,0,0,106,530,1,0,0,0,108,534,1,0,0,0,110,538,1,
        0,0,0,112,542,1,0,0,0,114,546,1,0,0,0,116,556,1,0,0,0,118,566,1,
        0,0,0,120,574,1,0,0,0,122,582,1,0,0,0,124,590,1,0,0,0,126,602,1,
        0,0,0,128,610,1,0,0,0,130,618,1,0,0,0,132,626,1,0,0,0,134,634,1,
        0,0,0,136,656,1,0,0,0,138,669,1,0,0,0,140,671,1,0,0,0,142,673,1,
        0,0,0,144,675,1,0,0,0,146,679,1,0,0,0,148,681,1,0,0,0,150,683,1,
        0,0,0,152,691,1,0,0,0,154,695,1,0,0,0,156,158,3,2,1,0,157,159,3,
        14,7,0,158,157,1,0,0,0,159,160,1,0,0,0,160,158,1,0,0,0,160,161,1,
        0,0,0,161,162,1,0,0,0,162,163,5,0,0,1,163,1,1,0,0,0,164,165,3,4,
        2,0,165,169,3,6,3,0,166,168,3,8,4,0,167,166,1,0,0,0,168,171,1,0,
        0,0,169,167,1,0,0,0,169,170,1,0,0,0,170,3,1,0,0,0,171,169,1,0,0,
        0,172,173,5,2,0,0,173,174,7,0,0,0,174,175,5,115,0,0,175,176,5,8,
        0,0,176,5,1,0,0,0,177,178,5,2,0,0,178,179,5,5,0,0,179,180,5,115,
        0,0,180,181,5,7,0,0,181,7,1,0,0,0,182,183,5,2,0,0,183,184,5,6,0,
        0,184,185,5,115,0,0,185,186,5,7,0,0,186,9,1,0,0,0,187,188,5,9,0,
        0,188,11,1,0,0,0,189,190,3,154,77,0,190,191,5,110,0,0,191,192,3,
        16,8,0,192,197,5,111,0,0,193,194,5,112,0,0,194,195,3,150,75,0,195,
        196,5,113,0,0,196,198,1,0,0,0,197,193,1,0,0,0,197,198,1,0,0,0,198,
        199,1,0,0,0,199,200,5,103,0,0,200,201,3,18,9,0,201,13,1,0,0,0,202,
        204,3,10,5,0,203,202,1,0,0,0,203,204,1,0,0,0,204,206,1,0,0,0,205,
        207,3,12,6,0,206,205,1,0,0,0,207,208,1,0,0,0,208,206,1,0,0,0,208,
        209,1,0,0,0,209,219,1,0,0,0,210,212,3,10,5,0,211,210,1,0,0,0,211,
        212,1,0,0,0,212,214,1,0,0,0,213,215,3,22,11,0,214,213,1,0,0,0,215,
        216,1,0,0,0,216,214,1,0,0,0,216,217,1,0,0,0,217,219,1,0,0,0,218,
        203,1,0,0,0,218,211,1,0,0,0,219,15,1,0,0,0,220,225,3,20,10,0,221,
        222,5,114,0,0,222,224,3,20,10,0,223,221,1,0,0,0,224,227,1,0,0,0,
        225,223,1,0,0,0,225,226,1,0,0,0,226,17,1,0,0,0,227,225,1,0,0,0,228,
        231,3,20,10,0,229,231,3,142,71,0,230,228,1,0,0,0,230,229,1,0,0,0,
        231,19,1,0,0,0,232,253,3,48,24,0,233,253,3,84,42,0,234,253,3,50,
        25,0,235,253,3,52,26,0,236,253,3,56,28,0,237,253,3,58,29,0,238,253,
        3,54,27,0,239,253,3,60,30,0,240,253,3,62,31,0,241,253,3,64,32,0,
        242,253,3,66,33,0,243,253,3,68,34,0,244,253,3,70,35,0,245,253,3,
        72,36,0,246,253,3,74,37,0,247,253,3,76,38,0,248,253,3,78,39,0,249,
        253,3,80,40,0,250,253,3,82,41,0,251,253,5,124,0,0,252,232,1,0,0,
        0,252,233,1,0,0,0,252,234,1,0,0,0,252,235,1,0,0,0,252,236,1,0,0,
        0,252,237,1,0,0,0,252,238,1,0,0,0,252,239,1,0,0,0,252,240,1,0,0,
        0,252,241,1,0,0,0,252,242,1,0,0,0,252,243,1,0,0,0,252,244,1,0,0,
        0,252,245,1,0,0,0,252,246,1,0,0,0,252,247,1,0,0,0,252,248,1,0,0,
        0,252,249,1,0,0,0,252,250,1,0,0,0,252,251,1,0,0,0,253,21,1,0,0,0,
        254,259,3,24,12,0,255,256,5,112,0,0,256,257,3,150,75,0,257,258,5,
        113,0,0,258,260,1,0,0,0,259,255,1,0,0,0,259,260,1,0,0,0,260,261,
        1,0,0,0,261,262,5,103,0,0,262,263,3,18,9,0,263,23,1,0,0,0,264,265,
        3,26,13,0,265,266,3,154,77,0,266,268,5,110,0,0,267,269,3,36,18,0,
        268,267,1,0,0,0,268,269,1,0,0,0,269,270,1,0,0,0,270,271,5,111,0,
        0,271,286,1,0,0,0,272,273,3,28,14,0,273,274,3,154,77,0,274,276,5,
        110,0,0,275,277,3,38,19,0,276,275,1,0,0,0,276,277,1,0,0,0,277,278,
        1,0,0,0,278,279,5,111,0,0,279,286,1,0,0,0,280,281,3,154,77,0,281,
        282,5,110,0,0,282,283,3,30,15,0,283,284,5,111,0,0,284,286,1,0,0,
        0,285,264,1,0,0,0,285,272,1,0,0,0,285,280,1,0,0,0,286,25,1,0,0,0,
        287,288,5,10,0,0,288,289,5,124,0,0,289,290,5,110,0,0,290,295,3,96,
        48,0,291,292,5,114,0,0,292,294,3,96,48,0,293,291,1,0,0,0,294,297,
        1,0,0,0,295,293,1,0,0,0,295,296,1,0,0,0,296,298,1,0,0,0,297,295,
        1,0,0,0,298,299,5,111,0,0,299,300,5,103,0,0,300,301,3,28,14,0,301,
        27,1,0,0,0,302,311,5,110,0,0,303,308,3,32,16,0,304,305,5,114,0,0,
        305,307,3,32,16,0,306,304,1,0,0,0,307,310,1,0,0,0,308,306,1,0,0,
        0,308,309,1,0,0,0,309,312,1,0,0,0,310,308,1,0,0,0,311,303,1,0,0,
        0,311,312,1,0,0,0,312,313,1,0,0,0,313,314,5,111,0,0,314,29,1,0,0,
        0,315,316,3,32,16,0,316,317,5,97,0,0,317,318,3,96,48,0,318,31,1,
        0,0,0,319,328,5,110,0,0,320,325,3,34,17,0,321,322,5,114,0,0,322,
        324,3,34,17,0,323,321,1,0,0,0,324,327,1,0,0,0,325,323,1,0,0,0,325,
        326,1,0,0,0,326,329,1,0,0,0,327,325,1,0,0,0,328,320,1,0,0,0,328,
        329,1,0,0,0,329,330,1,0,0,0,330,331,5,111,0,0,331,33,1,0,0,0,332,
        344,5,46,0,0,333,344,3,44,22,0,334,344,5,28,0,0,335,344,5,47,0,0,
        336,344,5,32,0,0,337,344,5,31,0,0,338,344,5,30,0,0,339,344,5,29,
        0,0,340,344,5,43,0,0,341,344,5,44,0,0,342,344,5,45,0,0,343,332,1,
        0,0,0,343,333,1,0,0,0,343,334,1,0,0,0,343,335,1,0,0,0,343,336,1,
        0,0,0,343,337,1,0,0,0,343,338,1,0,0,0,343,339,1,0,0,0,343,340,1,
        0,0,0,343,341,1,0,0,0,343,342,1,0,0,0,344,35,1,0,0,0,345,350,3,40,
        20,0,346,347,5,114,0,0,347,349,3,40,20,0,348,346,1,0,0,0,349,352,
        1,0,0,0,350,348,1,0,0,0,350,351,1,0,0,0,351,37,1,0,0,0,352,350,1,
        0,0,0,353,358,3,42,21,0,354,355,5,114,0,0,355,357,3,42,21,0,356,
        354,1,0,0,0,357,360,1,0,0,0,358,356,1,0,0,0,358,359,1,0,0,0,359,
        39,1,0,0,0,360,358,1,0,0,0,361,362,5,124,0,0,362,363,5,118,0,0,363,
        366,5,49,0,0,364,366,3,20,10,0,365,361,1,0,0,0,365,364,1,0,0,0,366,
        41,1,0,0,0,367,368,5,49,0,0,368,369,5,97,0,0,369,372,3,96,48,0,370,
        372,3,20,10,0,371,367,1,0,0,0,371,370,1,0,0,0,372,43,1,0,0,0,373,
        377,5,26,0,0,374,377,5,25,0,0,375,377,3,46,23,0,376,373,1,0,0,0,
        376,374,1,0,0,0,376,375,1,0,0,0,377,45,1,0,0,0,378,379,7,1,0,0,379,
        47,1,0,0,0,380,381,5,46,0,0,381,382,5,97,0,0,382,383,3,96,48,0,383,
        49,1,0,0,0,384,385,5,25,0,0,385,386,5,97,0,0,386,387,3,106,53,0,
        387,51,1,0,0,0,388,389,3,44,22,0,389,390,5,97,0,0,390,391,3,108,
        54,0,391,53,1,0,0,0,392,393,3,44,22,0,393,394,5,97,0,0,394,395,3,
        124,62,0,395,55,1,0,0,0,396,397,5,28,0,0,397,398,5,97,0,0,398,399,
        3,100,50,0,399,57,1,0,0,0,400,401,5,47,0,0,401,402,5,97,0,0,402,
        403,3,102,51,0,403,59,1,0,0,0,404,405,5,32,0,0,405,406,5,97,0,0,
        406,407,3,110,55,0,407,61,1,0,0,0,408,409,5,43,0,0,409,410,5,97,
        0,0,410,411,3,112,56,0,411,63,1,0,0,0,412,413,5,44,0,0,413,414,5,
        97,0,0,414,415,3,114,57,0,415,65,1,0,0,0,416,417,5,45,0,0,417,418,
        5,97,0,0,418,419,3,116,58,0,419,67,1,0,0,0,420,421,5,47,0,0,421,
        422,5,97,0,0,422,423,3,118,59,0,423,69,1,0,0,0,424,425,5,47,0,0,
        425,426,5,97,0,0,426,427,3,120,60,0,427,71,1,0,0,0,428,429,5,47,
        0,0,429,430,5,97,0,0,430,431,3,122,61,0,431,73,1,0,0,0,432,433,5,
        31,0,0,433,434,5,97,0,0,434,435,3,126,63,0,435,75,1,0,0,0,436,437,
        5,30,0,0,437,438,5,97,0,0,438,439,3,128,64,0,439,77,1,0,0,0,440,
        441,5,29,0,0,441,442,5,97,0,0,442,443,3,130,65,0,443,79,1,0,0,0,
        444,445,3,86,43,0,445,446,5,97,0,0,446,447,3,132,66,0,447,81,1,0,
        0,0,448,449,3,90,45,0,449,450,5,97,0,0,450,451,3,134,67,0,451,83,
        1,0,0,0,452,453,5,124,0,0,453,454,5,97,0,0,454,455,5,48,0,0,455,
        85,1,0,0,0,456,465,5,112,0,0,457,462,3,88,44,0,458,459,5,114,0,0,
        459,461,3,88,44,0,460,458,1,0,0,0,461,464,1,0,0,0,462,460,1,0,0,
        0,462,463,1,0,0,0,463,466,1,0,0,0,464,462,1,0,0,0,465,457,1,0,0,
        0,465,466,1,0,0,0,466,467,1,0,0,0,467,468,5,113,0,0,468,87,1,0,0,
        0,469,472,3,34,17,0,470,472,3,86,43,0,471,469,1,0,0,0,471,470,1,
        0,0,0,472,89,1,0,0,0,473,474,5,110,0,0,474,475,3,92,46,0,475,476,
        5,122,0,0,476,477,3,94,47,0,477,478,5,111,0,0,478,91,1,0,0,0,479,
        490,5,124,0,0,480,481,5,110,0,0,481,484,5,124,0,0,482,483,5,114,
        0,0,483,485,5,124,0,0,484,482,1,0,0,0,485,486,1,0,0,0,486,484,1,
        0,0,0,486,487,1,0,0,0,487,488,1,0,0,0,488,490,5,111,0,0,489,479,
        1,0,0,0,489,480,1,0,0,0,490,93,1,0,0,0,491,492,3,154,77,0,492,493,
        5,110,0,0,493,494,3,16,8,0,494,495,5,111,0,0,495,95,1,0,0,0,496,
        499,3,98,49,0,497,499,3,138,69,0,498,496,1,0,0,0,498,497,1,0,0,0,
        499,97,1,0,0,0,500,517,3,100,50,0,501,517,3,106,53,0,502,517,3,108,
        54,0,503,517,3,102,51,0,504,517,3,104,52,0,505,517,3,110,55,0,506,
        517,3,112,56,0,507,509,5,69,0,0,508,510,5,116,0,0,509,508,1,0,0,
        0,509,510,1,0,0,0,510,517,1,0,0,0,511,512,5,81,0,0,512,514,5,124,
        0,0,513,515,5,116,0,0,514,513,1,0,0,0,514,515,1,0,0,0,515,517,1,
        0,0,0,516,500,1,0,0,0,516,501,1,0,0,0,516,502,1,0,0,0,516,503,1,
        0,0,0,516,504,1,0,0,0,516,505,1,0,0,0,516,506,1,0,0,0,516,507,1,
        0,0,0,516,511,1,0,0,0,517,99,1,0,0,0,518,520,7,2,0,0,519,521,5,116,
        0,0,520,519,1,0,0,0,520,521,1,0,0,0,521,101,1,0,0,0,522,524,7,3,
        0,0,523,525,5,116,0,0,524,523,1,0,0,0,524,525,1,0,0,0,525,103,1,
        0,0,0,526,528,7,4,0,0,527,529,5,116,0,0,528,527,1,0,0,0,528,529,
        1,0,0,0,529,105,1,0,0,0,530,532,7,5,0,0,531,533,5,116,0,0,532,531,
        1,0,0,0,532,533,1,0,0,0,533,107,1,0,0,0,534,536,7,6,0,0,535,537,
        5,116,0,0,536,535,1,0,0,0,536,537,1,0,0,0,537,109,1,0,0,0,538,540,
        5,65,0,0,539,541,5,116,0,0,540,539,1,0,0,0,540,541,1,0,0,0,541,111,
        1,0,0,0,542,544,7,7,0,0,543,545,5,116,0,0,544,543,1,0,0,0,544,545,
        1,0,0,0,545,113,1,0,0,0,546,548,7,8,0,0,547,549,5,116,0,0,548,547,
        1,0,0,0,548,549,1,0,0,0,549,554,1,0,0,0,550,551,5,41,0,0,551,552,
        3,140,70,0,552,553,5,42,0,0,553,555,1,0,0,0,554,550,1,0,0,0,554,
        555,1,0,0,0,555,115,1,0,0,0,556,558,7,9,0,0,557,559,5,116,0,0,558,
        557,1,0,0,0,558,559,1,0,0,0,559,564,1,0,0,0,560,561,5,41,0,0,561,
        562,3,140,70,0,562,563,5,42,0,0,563,565,1,0,0,0,564,560,1,0,0,0,
        564,565,1,0,0,0,565,117,1,0,0,0,566,568,7,10,0,0,567,569,5,116,0,
        0,568,567,1,0,0,0,568,569,1,0,0,0,569,570,1,0,0,0,570,571,5,41,0,
        0,571,572,3,140,70,0,572,573,5,42,0,0,573,119,1,0,0,0,574,576,7,
        11,0,0,575,577,5,116,0,0,576,575,1,0,0,0,576,577,1,0,0,0,577,578,
        1,0,0,0,578,579,5,41,0,0,579,580,3,140,70,0,580,581,5,42,0,0,581,
        121,1,0,0,0,582,584,7,12,0,0,583,585,5,116,0,0,584,583,1,0,0,0,584,
        585,1,0,0,0,585,586,1,0,0,0,586,587,5,41,0,0,587,588,3,140,70,0,
        588,589,5,42,0,0,589,123,1,0,0,0,590,592,7,13,0,0,591,593,5,116,
        0,0,592,591,1,0,0,0,592,593,1,0,0,0,593,600,1,0,0,0,594,595,5,41,
        0,0,595,596,3,140,70,0,596,597,5,114,0,0,597,598,3,140,70,0,598,
        599,5,42,0,0,599,601,1,0,0,0,600,594,1,0,0,0,600,601,1,0,0,0,601,
        125,1,0,0,0,602,604,7,14,0,0,603,605,5,116,0,0,604,603,1,0,0,0,604,
        605,1,0,0,0,605,606,1,0,0,0,606,607,5,41,0,0,607,608,3,140,70,0,
        608,609,5,42,0,0,609,127,1,0,0,0,610,612,7,15,0,0,611,613,5,116,
        0,0,612,611,1,0,0,0,612,613,1,0,0,0,613,614,1,0,0,0,614,615,5,41,
        0,0,615,616,3,140,70,0,616,617,5,42,0,0,617,129,1,0,0,0,618,620,
        7,16,0,0,619,621,5,116,0,0,620,619,1,0,0,0,620,621,1,0,0,0,621,622,
        1,0,0,0,622,623,5,41,0,0,623,624,3,140,70,0,624,625,5,42,0,0,625,
        131,1,0,0,0,626,628,5,79,0,0,627,629,5,116,0,0,628,627,1,0,0,0,628,
        629,1,0,0,0,629,630,1,0,0,0,630,631,5,41,0,0,631,632,3,96,48,0,632,
        633,5,42,0,0,633,133,1,0,0,0,634,636,5,55,0,0,635,637,5,116,0,0,
        636,635,1,0,0,0,636,637,1,0,0,0,637,638,1,0,0,0,638,639,5,41,0,0,
        639,640,3,136,68,0,640,641,5,122,0,0,641,642,3,96,48,0,642,643,5,
        42,0,0,643,135,1,0,0,0,644,657,3,96,48,0,645,646,5,110,0,0,646,651,
        3,96,48,0,647,648,5,114,0,0,648,650,3,96,48,0,649,647,1,0,0,0,650,
        653,1,0,0,0,651,649,1,0,0,0,651,652,1,0,0,0,652,654,1,0,0,0,653,
        651,1,0,0,0,654,655,5,111,0,0,655,657,1,0,0,0,656,644,1,0,0,0,656,
        645,1,0,0,0,657,137,1,0,0,0,658,670,3,118,59,0,659,670,3,120,60,
        0,660,670,3,122,61,0,661,670,3,124,62,0,662,670,3,114,57,0,663,670,
        3,116,58,0,664,670,3,126,63,0,665,670,3,128,64,0,666,670,3,130,65,
        0,667,670,3,132,66,0,668,670,3,134,67,0,669,658,1,0,0,0,669,659,
        1,0,0,0,669,660,1,0,0,0,669,661,1,0,0,0,669,662,1,0,0,0,669,663,
        1,0,0,0,669,664,1,0,0,0,669,665,1,0,0,0,669,666,1,0,0,0,669,667,
        1,0,0,0,669,668,1,0,0,0,670,139,1,0,0,0,671,672,5,25,0,0,672,141,
        1,0,0,0,673,674,7,17,0,0,674,143,1,0,0,0,675,676,3,146,73,0,676,
        677,5,115,0,0,677,678,3,148,74,0,678,145,1,0,0,0,679,680,7,18,0,
        0,680,147,1,0,0,0,681,682,7,19,0,0,682,149,1,0,0,0,683,688,3,144,
        72,0,684,685,5,114,0,0,685,687,3,144,72,0,686,684,1,0,0,0,687,690,
        1,0,0,0,688,686,1,0,0,0,688,689,1,0,0,0,689,151,1,0,0,0,690,688,
        1,0,0,0,691,692,7,20,0,0,692,153,1,0,0,0,693,696,3,152,76,0,694,
        696,5,124,0,0,695,693,1,0,0,0,695,694,1,0,0,0,696,155,1,0,0,0,61,
        160,169,197,203,208,211,216,218,225,230,252,259,268,276,285,295,
        308,311,325,328,343,350,358,365,371,376,462,465,471,486,489,498,
        509,514,516,520,524,528,532,536,540,544,548,554,558,564,568,576,
        584,592,600,604,612,620,628,636,651,656,669,688,695
    ]

class FuncTestCaseParser ( Parser ):

    grammarFileName = "FuncTestCaseParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "'###'", "'SUBSTRAIT_SCALAR_TEST'", 
                     "'SUBSTRAIT_AGGREGATE_TEST'", "'SUBSTRAIT_INCLUDE'", 
                     "'SUBSTRAIT_DEPENDENCY'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'DEFINE'", "'<!ERROR>'", "'<!UNDEFINED>'", 
                     "'OVERFLOW'", "'ROUNDING'", "'ERROR'", "'SATURATE'", 
                     "'SILENT'", "'TIE_TO_EVEN'", "'NAN'", "'ACCEPT_NULLS'", 
                     "'IGNORE_NULLS'", "'NULL_HANDLING'", "'SPACES_ONLY'", 
                     "'TRUNCATE'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'P'", "'T'", "'Y'", "'M'", "'D'", "'H'", 
                     "'S'", "'F'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'null'", "<INVALID>", "'enum'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'IF'", "'THEN'", 
                     "'ELSE'", "'FUNC'", "'BOOLEAN'", "'I8'", "'I16'", "'I32'", 
                     "'I64'", "'FP32'", "'FP64'", "'STRING'", "'BINARY'", 
                     "'DATE'", "'INTERVAL_YEAR'", "'INTERVAL_DAY'", "'INTERVAL_COMPOUND'", 
                     "'UUID'", "'DECIMAL'", "'PRECISION_TIME'", "'PRECISION_TIMESTAMP'", 
                     "'PRECISION_TIMESTAMP_TZ'", "'FIXEDCHAR'", "'VARCHAR'", 
                     "'FIXEDBINARY'", "'STRUCT'", "'NSTRUCT'", "'LIST'", 
                     "'MAP'", "'U!'", "'BOOL'", "'STR'", "'VBIN'", "'IYEAR'", 
                     "'IDAY'", "'ICOMPOUND'", "'DEC'", "'PT'", "'PTS'", 
                     "'PTSTZ'", "'FCHAR'", "'VCHAR'", "'FBIN'", "'ANY'", 
                     "<INVALID>", "'::'", "'+'", "'-'", "'*'", "'/'", "'%'", 
                     "'='", "'!='", "'>='", "'<='", "'>'", "'<'", "'!'", 
                     "'('", "')'", "'['", "']'", "','", "':'", "'?'", "'#'", 
                     "'.'", "'AND'", "'OR'", "':='", "'->'" ]

    symbolicNames = [ "<INVALID>", "Whitespace", "TripleHash", "SubstraitScalarTest", 
                      "SubstraitAggregateTest", "SubstraitInclude", "SubstraitDependency", 
                      "ExtensionUrn", "FormatVersion", "DescriptionLine", 
                      "Define", "ErrorResult", "UndefineResult", "Overflow", 
                      "Rounding", "Error", "Saturate", "Silent", "TieToEven", 
                      "NaN", "AcceptNulls", "IgnoreNulls", "NullHandling", 
                      "SpacesOnly", "Truncate", "IntegerLiteral", "DecimalLiteral", 
                      "FloatLiteral", "BooleanLiteral", "TimestampTzLiteral", 
                      "TimestampLiteral", "TimeLiteral", "DateLiteral", 
                      "PeriodPrefix", "TimePrefix", "YearSuffix", "MSuffix", 
                      "DaySuffix", "HourSuffix", "SecondSuffix", "FractionalSecondSuffix", 
                      "OAngleBracket", "CAngleBracket", "IntervalYearLiteral", 
                      "IntervalDayLiteral", "IntervalCompoundLiteral", "NullLiteral", 
                      "StringLiteral", "EnumType", "ColumnName", "LineComment", 
                      "BlockComment", "If", "Then", "Else", "Func", "Boolean", 
                      "I8", "I16", "I32", "I64", "FP32", "FP64", "String", 
                      "Binary", "Date", "Interval_Year", "Interval_Day", 
                      "Interval_Compound", "UUID", "Decimal", "Precision_Time", 
                      "Precision_Timestamp", "Precision_Timestamp_TZ", "FixedChar", 
                      "VarChar", "FixedBinary", "Struct", "NStruct", "List", 
                      "Map", "UserDefined", "Bool", "Str", "VBin", "IYear", 
                      "IDay", "ICompound", "Dec", "PT", "PTs", "PTsTZ", 
                      "FChar", "VChar", "FBin", "Any", "AnyVar", "DoubleColon", 
                      "Plus", "Minus", "Asterisk", "ForwardSlash", "Percent", 
                      "Eq", "Ne", "Gte", "Lte", "Gt", "Lt", "Bang", "OParen", 
                      "CParen", "OBracket", "CBracket", "Comma", "Colon", 
                      "QMark", "Hash", "Dot", "And", "Or", "Assign", "Arrow", 
                      "Number", "Identifier", "Newline" ]

    RULE_doc = 0
    RULE_header = 1
    RULE_version = 2
    RULE_include = 3
    RULE_dependency = 4
    RULE_testGroupDescription = 5
    RULE_testCase = 6
    RULE_testGroup = 7
    RULE_arguments = 8
    RULE_result = 9
    RULE_argument = 10
    RULE_aggFuncTestCase = 11
    RULE_aggFuncCall = 12
    RULE_tableData = 13
    RULE_tableRows = 14
    RULE_dataColumn = 15
    RULE_columnValues = 16
    RULE_literal = 17
    RULE_qualifiedAggregateFuncArgs = 18
    RULE_aggregateFuncArgs = 19
    RULE_qualifiedAggregateFuncArg = 20
    RULE_aggregateFuncArg = 21
    RULE_numericLiteral = 22
    RULE_floatLiteral = 23
    RULE_nullArg = 24
    RULE_intArg = 25
    RULE_floatArg = 26
    RULE_decimalArg = 27
    RULE_booleanArg = 28
    RULE_stringArg = 29
    RULE_dateArg = 30
    RULE_intervalYearArg = 31
    RULE_intervalDayArg = 32
    RULE_intervalCompoundArg = 33
    RULE_fixedCharArg = 34
    RULE_varCharArg = 35
    RULE_fixedBinaryArg = 36
    RULE_precisionTimeArg = 37
    RULE_precisionTimestampArg = 38
    RULE_precisionTimestampTZArg = 39
    RULE_listArg = 40
    RULE_lambdaArg = 41
    RULE_enumArg = 42
    RULE_literalList = 43
    RULE_listElement = 44
    RULE_literalLambda = 45
    RULE_lambdaParameters = 46
    RULE_lambdaBody = 47
    RULE_dataType = 48
    RULE_scalarType = 49
    RULE_booleanType = 50
    RULE_stringType = 51
    RULE_binaryType = 52
    RULE_intType = 53
    RULE_floatType = 54
    RULE_dateType = 55
    RULE_intervalYearType = 56
    RULE_intervalDayType = 57
    RULE_intervalCompoundType = 58
    RULE_fixedCharType = 59
    RULE_varCharType = 60
    RULE_fixedBinaryType = 61
    RULE_decimalType = 62
    RULE_precisionTimeType = 63
    RULE_precisionTimestampType = 64
    RULE_precisionTimestampTZType = 65
    RULE_listType = 66
    RULE_funcType = 67
    RULE_funcParameters = 68
    RULE_parameterizedType = 69
    RULE_numericParameter = 70
    RULE_substraitError = 71
    RULE_funcOption = 72
    RULE_optionName = 73
    RULE_optionValue = 74
    RULE_funcOptions = 75
    RULE_nonReserved = 76
    RULE_identifier = 77

    ruleNames =  [ "doc", "header", "version", "include", "dependency", 
                   "testGroupDescription", "testCase", "testGroup", "arguments", 
                   "result", "argument", "aggFuncTestCase", "aggFuncCall", 
                   "tableData", "tableRows", "dataColumn", "columnValues", 
                   "literal", "qualifiedAggregateFuncArgs", "aggregateFuncArgs", 
                   "qualifiedAggregateFuncArg", "aggregateFuncArg", "numericLiteral", 
                   "floatLiteral", "nullArg", "intArg", "floatArg", "decimalArg", 
                   "booleanArg", "stringArg", "dateArg", "intervalYearArg", 
                   "intervalDayArg", "intervalCompoundArg", "fixedCharArg", 
                   "varCharArg", "fixedBinaryArg", "precisionTimeArg", "precisionTimestampArg", 
                   "precisionTimestampTZArg", "listArg", "lambdaArg", "enumArg", 
                   "literalList", "listElement", "literalLambda", "lambdaParameters", 
                   "lambdaBody", "dataType", "scalarType", "booleanType", 
                   "stringType", "binaryType", "intType", "floatType", "dateType", 
                   "intervalYearType", "intervalDayType", "intervalCompoundType", 
                   "fixedCharType", "varCharType", "fixedBinaryType", "decimalType", 
                   "precisionTimeType", "precisionTimestampType", "precisionTimestampTZType", 
                   "listType", "funcType", "funcParameters", "parameterizedType", 
                   "numericParameter", "substraitError", "funcOption", "optionName", 
                   "optionValue", "funcOptions", "nonReserved", "identifier" ]

    EOF = Token.EOF
    Whitespace=1
    TripleHash=2
    SubstraitScalarTest=3
    SubstraitAggregateTest=4
    SubstraitInclude=5
    SubstraitDependency=6
    ExtensionUrn=7
    FormatVersion=8
    DescriptionLine=9
    Define=10
    ErrorResult=11
    UndefineResult=12
    Overflow=13
    Rounding=14
    Error=15
    Saturate=16
    Silent=17
    TieToEven=18
    NaN=19
    AcceptNulls=20
    IgnoreNulls=21
    NullHandling=22
    SpacesOnly=23
    Truncate=24
    IntegerLiteral=25
    DecimalLiteral=26
    FloatLiteral=27
    BooleanLiteral=28
    TimestampTzLiteral=29
    TimestampLiteral=30
    TimeLiteral=31
    DateLiteral=32
    PeriodPrefix=33
    TimePrefix=34
    YearSuffix=35
    MSuffix=36
    DaySuffix=37
    HourSuffix=38
    SecondSuffix=39
    FractionalSecondSuffix=40
    OAngleBracket=41
    CAngleBracket=42
    IntervalYearLiteral=43
    IntervalDayLiteral=44
    IntervalCompoundLiteral=45
    NullLiteral=46
    StringLiteral=47
    EnumType=48
    ColumnName=49
    LineComment=50
    BlockComment=51
    If=52
    Then=53
    Else=54
    Func=55
    Boolean=56
    I8=57
    I16=58
    I32=59
    I64=60
    FP32=61
    FP64=62
    String=63
    Binary=64
    Date=65
    Interval_Year=66
    Interval_Day=67
    Interval_Compound=68
    UUID=69
    Decimal=70
    Precision_Time=71
    Precision_Timestamp=72
    Precision_Timestamp_TZ=73
    FixedChar=74
    VarChar=75
    FixedBinary=76
    Struct=77
    NStruct=78
    List=79
    Map=80
    UserDefined=81
    Bool=82
    Str=83
    VBin=84
    IYear=85
    IDay=86
    ICompound=87
    Dec=88
    PT=89
    PTs=90
    PTsTZ=91
    FChar=92
    VChar=93
    FBin=94
    Any=95
    AnyVar=96
    DoubleColon=97
    Plus=98
    Minus=99
    Asterisk=100
    ForwardSlash=101
    Percent=102
    Eq=103
    Ne=104
    Gte=105
    Lte=106
    Gt=107
    Lt=108
    Bang=109
    OParen=110
    CParen=111
    OBracket=112
    CBracket=113
    Comma=114
    Colon=115
    QMark=116
    Hash=117
    Dot=118
    And=119
    Or=120
    Assign=121
    Arrow=122
    Number=123
    Identifier=124
    Newline=125

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class DocContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def header(self):
            return self.getTypedRuleContext(FuncTestCaseParser.HeaderContext,0)


        def EOF(self):
            return self.getToken(FuncTestCaseParser.EOF, 0)

        def testGroup(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.TestGroupContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.TestGroupContext,i)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_doc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDoc" ):
                listener.enterDoc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDoc" ):
                listener.exitDoc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDoc" ):
                return visitor.visitDoc(self)
            else:
                return visitor.visitChildren(self)




    def doc(self):

        localctx = FuncTestCaseParser.DocContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_doc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.header()
            self.state = 158 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 157
                self.testGroup()
                self.state = 160 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 16778752) != 0) or ((((_la - 110)) & ~0x3f) == 0 and ((1 << (_la - 110)) & 17921) != 0)):
                    break

            self.state = 162
            self.match(FuncTestCaseParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class HeaderContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def version(self):
            return self.getTypedRuleContext(FuncTestCaseParser.VersionContext,0)


        def include(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IncludeContext,0)


        def dependency(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.DependencyContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.DependencyContext,i)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHeader" ):
                listener.enterHeader(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHeader" ):
                listener.exitHeader(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitHeader" ):
                return visitor.visitHeader(self)
            else:
                return visitor.visitChildren(self)




    def header(self):

        localctx = FuncTestCaseParser.HeaderContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_header)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 164
            self.version()
            self.state = 165
            self.include()
            self.state = 169
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==2:
                self.state = 166
                self.dependency()
                self.state = 171
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VersionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TripleHash(self):
            return self.getToken(FuncTestCaseParser.TripleHash, 0)

        def Colon(self):
            return self.getToken(FuncTestCaseParser.Colon, 0)

        def FormatVersion(self):
            return self.getToken(FuncTestCaseParser.FormatVersion, 0)

        def SubstraitScalarTest(self):
            return self.getToken(FuncTestCaseParser.SubstraitScalarTest, 0)

        def SubstraitAggregateTest(self):
            return self.getToken(FuncTestCaseParser.SubstraitAggregateTest, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVersion" ):
                listener.enterVersion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVersion" ):
                listener.exitVersion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVersion" ):
                return visitor.visitVersion(self)
            else:
                return visitor.visitChildren(self)




    def version(self):

        localctx = FuncTestCaseParser.VersionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_version)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.match(FuncTestCaseParser.TripleHash)
            self.state = 173
            _la = self._input.LA(1)
            if not(_la==3 or _la==4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 174
            self.match(FuncTestCaseParser.Colon)
            self.state = 175
            self.match(FuncTestCaseParser.FormatVersion)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TripleHash(self):
            return self.getToken(FuncTestCaseParser.TripleHash, 0)

        def SubstraitInclude(self):
            return self.getToken(FuncTestCaseParser.SubstraitInclude, 0)

        def Colon(self):
            return self.getToken(FuncTestCaseParser.Colon, 0)

        def ExtensionUrn(self):
            return self.getToken(FuncTestCaseParser.ExtensionUrn, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_include

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInclude" ):
                listener.enterInclude(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInclude" ):
                listener.exitInclude(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInclude" ):
                return visitor.visitInclude(self)
            else:
                return visitor.visitChildren(self)




    def include(self):

        localctx = FuncTestCaseParser.IncludeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_include)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(FuncTestCaseParser.TripleHash)
            self.state = 178
            self.match(FuncTestCaseParser.SubstraitInclude)
            self.state = 179
            self.match(FuncTestCaseParser.Colon)
            self.state = 180
            self.match(FuncTestCaseParser.ExtensionUrn)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DependencyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TripleHash(self):
            return self.getToken(FuncTestCaseParser.TripleHash, 0)

        def SubstraitDependency(self):
            return self.getToken(FuncTestCaseParser.SubstraitDependency, 0)

        def Colon(self):
            return self.getToken(FuncTestCaseParser.Colon, 0)

        def ExtensionUrn(self):
            return self.getToken(FuncTestCaseParser.ExtensionUrn, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_dependency

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDependency" ):
                listener.enterDependency(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDependency" ):
                listener.exitDependency(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDependency" ):
                return visitor.visitDependency(self)
            else:
                return visitor.visitChildren(self)




    def dependency(self):

        localctx = FuncTestCaseParser.DependencyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_dependency)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self.match(FuncTestCaseParser.TripleHash)
            self.state = 183
            self.match(FuncTestCaseParser.SubstraitDependency)
            self.state = 184
            self.match(FuncTestCaseParser.Colon)
            self.state = 185
            self.match(FuncTestCaseParser.ExtensionUrn)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TestGroupDescriptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DescriptionLine(self):
            return self.getToken(FuncTestCaseParser.DescriptionLine, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_testGroupDescription

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTestGroupDescription" ):
                listener.enterTestGroupDescription(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTestGroupDescription" ):
                listener.exitTestGroupDescription(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTestGroupDescription" ):
                return visitor.visitTestGroupDescription(self)
            else:
                return visitor.visitChildren(self)




    def testGroupDescription(self):

        localctx = FuncTestCaseParser.TestGroupDescriptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_testGroupDescription)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.match(FuncTestCaseParser.DescriptionLine)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TestCaseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.functionName = None # IdentifierContext

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def arguments(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ArgumentsContext,0)


        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def Eq(self):
            return self.getToken(FuncTestCaseParser.Eq, 0)

        def result(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ResultContext,0)


        def identifier(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IdentifierContext,0)


        def OBracket(self):
            return self.getToken(FuncTestCaseParser.OBracket, 0)

        def funcOptions(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FuncOptionsContext,0)


        def CBracket(self):
            return self.getToken(FuncTestCaseParser.CBracket, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_testCase

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTestCase" ):
                listener.enterTestCase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTestCase" ):
                listener.exitTestCase(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTestCase" ):
                return visitor.visitTestCase(self)
            else:
                return visitor.visitChildren(self)




    def testCase(self):

        localctx = FuncTestCaseParser.TestCaseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_testCase)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            localctx.functionName = self.identifier()
            self.state = 190
            self.match(FuncTestCaseParser.OParen)
            self.state = 191
            self.arguments()
            self.state = 192
            self.match(FuncTestCaseParser.CParen)
            self.state = 197
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==112:
                self.state = 193
                self.match(FuncTestCaseParser.OBracket)
                self.state = 194
                self.funcOptions()
                self.state = 195
                self.match(FuncTestCaseParser.CBracket)


            self.state = 199
            self.match(FuncTestCaseParser.Eq)
            self.state = 200
            self.result()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TestGroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_testGroup

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ScalarFuncTestGroupContext(TestGroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.TestGroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def testGroupDescription(self):
            return self.getTypedRuleContext(FuncTestCaseParser.TestGroupDescriptionContext,0)

        def testCase(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.TestCaseContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.TestCaseContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScalarFuncTestGroup" ):
                listener.enterScalarFuncTestGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScalarFuncTestGroup" ):
                listener.exitScalarFuncTestGroup(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScalarFuncTestGroup" ):
                return visitor.visitScalarFuncTestGroup(self)
            else:
                return visitor.visitChildren(self)


    class AggregateFuncTestGroupContext(TestGroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.TestGroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def testGroupDescription(self):
            return self.getTypedRuleContext(FuncTestCaseParser.TestGroupDescriptionContext,0)

        def aggFuncTestCase(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.AggFuncTestCaseContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.AggFuncTestCaseContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFuncTestGroup" ):
                listener.enterAggregateFuncTestGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFuncTestGroup" ):
                listener.exitAggregateFuncTestGroup(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAggregateFuncTestGroup" ):
                return visitor.visitAggregateFuncTestGroup(self)
            else:
                return visitor.visitChildren(self)



    def testGroup(self):

        localctx = FuncTestCaseParser.TestGroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_testGroup)
        self._la = 0 # Token type
        try:
            self.state = 218
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                localctx = FuncTestCaseParser.ScalarFuncTestGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 203
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 202
                    self.testGroupDescription()


                self.state = 206 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 205
                        self.testCase()

                    else:
                        raise NoViableAltException(self)
                    self.state = 208 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

                pass

            elif la_ == 2:
                localctx = FuncTestCaseParser.AggregateFuncTestGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 211
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 210
                    self.testGroupDescription()


                self.state = 214 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 213
                        self.aggFuncTestCase()

                    else:
                        raise NoViableAltException(self)
                    self.state = 216 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def argument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.ArgumentContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.ArgumentContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_arguments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArguments" ):
                listener.enterArguments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArguments" ):
                listener.exitArguments(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArguments" ):
                return visitor.visitArguments(self)
            else:
                return visitor.visitChildren(self)




    def arguments(self):

        localctx = FuncTestCaseParser.ArgumentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_arguments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.argument()
            self.state = 225
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==114:
                self.state = 221
                self.match(FuncTestCaseParser.Comma)
                self.state = 222
                self.argument()
                self.state = 227
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ResultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def argument(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ArgumentContext,0)


        def substraitError(self):
            return self.getTypedRuleContext(FuncTestCaseParser.SubstraitErrorContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_result

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterResult" ):
                listener.enterResult(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitResult" ):
                listener.exitResult(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitResult" ):
                return visitor.visitResult(self)
            else:
                return visitor.visitChildren(self)




    def result(self):

        localctx = FuncTestCaseParser.ResultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_result)
        try:
            self.state = 230
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19, 25, 26, 27, 28, 29, 30, 31, 32, 43, 44, 45, 46, 47, 110, 112, 124]:
                self.enterOuterAlt(localctx, 1)
                self.state = 228
                self.argument()
                pass
            elif token in [11, 12]:
                self.enterOuterAlt(localctx, 2)
                self.state = 229
                self.substraitError()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def nullArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NullArgContext,0)


        def enumArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.EnumArgContext,0)


        def intArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntArgContext,0)


        def floatArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FloatArgContext,0)


        def booleanArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.BooleanArgContext,0)


        def stringArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.StringArgContext,0)


        def decimalArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DecimalArgContext,0)


        def dateArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DateArgContext,0)


        def intervalYearArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalYearArgContext,0)


        def intervalDayArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalDayArgContext,0)


        def intervalCompoundArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalCompoundArgContext,0)


        def fixedCharArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedCharArgContext,0)


        def varCharArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.VarCharArgContext,0)


        def fixedBinaryArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedBinaryArgContext,0)


        def precisionTimeArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimeArgContext,0)


        def precisionTimestampArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampArgContext,0)


        def precisionTimestampTZArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampTZArgContext,0)


        def listArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ListArgContext,0)


        def lambdaArg(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LambdaArgContext,0)


        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_argument

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgument" ):
                listener.enterArgument(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgument" ):
                listener.exitArgument(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgument" ):
                return visitor.visitArgument(self)
            else:
                return visitor.visitChildren(self)




    def argument(self):

        localctx = FuncTestCaseParser.ArgumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_argument)
        try:
            self.state = 252
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 232
                self.nullArg()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 233
                self.enumArg()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 234
                self.intArg()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 235
                self.floatArg()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 236
                self.booleanArg()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 237
                self.stringArg()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 238
                self.decimalArg()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 239
                self.dateArg()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 240
                self.intervalYearArg()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 241
                self.intervalDayArg()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 242
                self.intervalCompoundArg()
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 243
                self.fixedCharArg()
                pass

            elif la_ == 13:
                self.enterOuterAlt(localctx, 13)
                self.state = 244
                self.varCharArg()
                pass

            elif la_ == 14:
                self.enterOuterAlt(localctx, 14)
                self.state = 245
                self.fixedBinaryArg()
                pass

            elif la_ == 15:
                self.enterOuterAlt(localctx, 15)
                self.state = 246
                self.precisionTimeArg()
                pass

            elif la_ == 16:
                self.enterOuterAlt(localctx, 16)
                self.state = 247
                self.precisionTimestampArg()
                pass

            elif la_ == 17:
                self.enterOuterAlt(localctx, 17)
                self.state = 248
                self.precisionTimestampTZArg()
                pass

            elif la_ == 18:
                self.enterOuterAlt(localctx, 18)
                self.state = 249
                self.listArg()
                pass

            elif la_ == 19:
                self.enterOuterAlt(localctx, 19)
                self.state = 250
                self.lambdaArg()
                pass

            elif la_ == 20:
                self.enterOuterAlt(localctx, 20)
                self.state = 251
                self.match(FuncTestCaseParser.Identifier)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggFuncTestCaseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def aggFuncCall(self):
            return self.getTypedRuleContext(FuncTestCaseParser.AggFuncCallContext,0)


        def Eq(self):
            return self.getToken(FuncTestCaseParser.Eq, 0)

        def result(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ResultContext,0)


        def OBracket(self):
            return self.getToken(FuncTestCaseParser.OBracket, 0)

        def funcOptions(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FuncOptionsContext,0)


        def CBracket(self):
            return self.getToken(FuncTestCaseParser.CBracket, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_aggFuncTestCase

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggFuncTestCase" ):
                listener.enterAggFuncTestCase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggFuncTestCase" ):
                listener.exitAggFuncTestCase(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAggFuncTestCase" ):
                return visitor.visitAggFuncTestCase(self)
            else:
                return visitor.visitChildren(self)




    def aggFuncTestCase(self):

        localctx = FuncTestCaseParser.AggFuncTestCaseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_aggFuncTestCase)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 254
            self.aggFuncCall()
            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==112:
                self.state = 255
                self.match(FuncTestCaseParser.OBracket)
                self.state = 256
                self.funcOptions()
                self.state = 257
                self.match(FuncTestCaseParser.CBracket)


            self.state = 261
            self.match(FuncTestCaseParser.Eq)
            self.state = 262
            self.result()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggFuncCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_aggFuncCall

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SingleArgAggregateFuncCallContext(AggFuncCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.AggFuncCallContext
            super().__init__(parser)
            self.functName = None # IdentifierContext
            self.copyFrom(ctx)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)
        def dataColumn(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataColumnContext,0)

        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)
        def identifier(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IdentifierContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingleArgAggregateFuncCall" ):
                listener.enterSingleArgAggregateFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingleArgAggregateFuncCall" ):
                listener.exitSingleArgAggregateFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSingleArgAggregateFuncCall" ):
                return visitor.visitSingleArgAggregateFuncCall(self)
            else:
                return visitor.visitChildren(self)


    class MultiArgAggregateFuncCallContext(AggFuncCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.AggFuncCallContext
            super().__init__(parser)
            self.funcName = None # IdentifierContext
            self.copyFrom(ctx)

        def tableData(self):
            return self.getTypedRuleContext(FuncTestCaseParser.TableDataContext,0)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)
        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)
        def identifier(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IdentifierContext,0)

        def qualifiedAggregateFuncArgs(self):
            return self.getTypedRuleContext(FuncTestCaseParser.QualifiedAggregateFuncArgsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiArgAggregateFuncCall" ):
                listener.enterMultiArgAggregateFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiArgAggregateFuncCall" ):
                listener.exitMultiArgAggregateFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiArgAggregateFuncCall" ):
                return visitor.visitMultiArgAggregateFuncCall(self)
            else:
                return visitor.visitChildren(self)


    class CompactAggregateFuncCallContext(AggFuncCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.AggFuncCallContext
            super().__init__(parser)
            self.functName = None # IdentifierContext
            self.copyFrom(ctx)

        def tableRows(self):
            return self.getTypedRuleContext(FuncTestCaseParser.TableRowsContext,0)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)
        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)
        def identifier(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IdentifierContext,0)

        def aggregateFuncArgs(self):
            return self.getTypedRuleContext(FuncTestCaseParser.AggregateFuncArgsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompactAggregateFuncCall" ):
                listener.enterCompactAggregateFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompactAggregateFuncCall" ):
                listener.exitCompactAggregateFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompactAggregateFuncCall" ):
                return visitor.visitCompactAggregateFuncCall(self)
            else:
                return visitor.visitChildren(self)



    def aggFuncCall(self):

        localctx = FuncTestCaseParser.AggFuncCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_aggFuncCall)
        self._la = 0 # Token type
        try:
            self.state = 285
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10]:
                localctx = FuncTestCaseParser.MultiArgAggregateFuncCallContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 264
                self.tableData()
                self.state = 265
                localctx.funcName = self.identifier()
                self.state = 266
                self.match(FuncTestCaseParser.OParen)
                self.state = 268
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 272687440592896) != 0) or ((((_la - 110)) & ~0x3f) == 0 and ((1 << (_la - 110)) & 16389) != 0):
                    self.state = 267
                    self.qualifiedAggregateFuncArgs()


                self.state = 270
                self.match(FuncTestCaseParser.CParen)
                pass
            elif token in [110]:
                localctx = FuncTestCaseParser.CompactAggregateFuncCallContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 272
                self.tableRows()
                self.state = 273
                localctx.functName = self.identifier()
                self.state = 274
                self.match(FuncTestCaseParser.OParen)
                self.state = 276
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 835637394014208) != 0) or ((((_la - 110)) & ~0x3f) == 0 and ((1 << (_la - 110)) & 16389) != 0):
                    self.state = 275
                    self.aggregateFuncArgs()


                self.state = 278
                self.match(FuncTestCaseParser.CParen)
                pass
            elif token in [24, 119, 120, 124]:
                localctx = FuncTestCaseParser.SingleArgAggregateFuncCallContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 280
                localctx.functName = self.identifier()
                self.state = 281
                self.match(FuncTestCaseParser.OParen)
                self.state = 282
                self.dataColumn()
                self.state = 283
                self.match(FuncTestCaseParser.CParen)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TableDataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.tableName = None # Token

        def Define(self):
            return self.getToken(FuncTestCaseParser.Define, 0)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def dataType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.DataTypeContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,i)


        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def Eq(self):
            return self.getToken(FuncTestCaseParser.Eq, 0)

        def tableRows(self):
            return self.getTypedRuleContext(FuncTestCaseParser.TableRowsContext,0)


        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_tableData

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTableData" ):
                listener.enterTableData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTableData" ):
                listener.exitTableData(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTableData" ):
                return visitor.visitTableData(self)
            else:
                return visitor.visitChildren(self)




    def tableData(self):

        localctx = FuncTestCaseParser.TableDataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_tableData)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 287
            self.match(FuncTestCaseParser.Define)
            self.state = 288
            localctx.tableName = self.match(FuncTestCaseParser.Identifier)
            self.state = 289
            self.match(FuncTestCaseParser.OParen)
            self.state = 290
            self.dataType()
            self.state = 295
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==114:
                self.state = 291
                self.match(FuncTestCaseParser.Comma)
                self.state = 292
                self.dataType()
                self.state = 297
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 298
            self.match(FuncTestCaseParser.CParen)
            self.state = 299
            self.match(FuncTestCaseParser.Eq)
            self.state = 300
            self.tableRows()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TableRowsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def columnValues(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.ColumnValuesContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.ColumnValuesContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_tableRows

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTableRows" ):
                listener.enterTableRows(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTableRows" ):
                listener.exitTableRows(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTableRows" ):
                return visitor.visitTableRows(self)
            else:
                return visitor.visitChildren(self)




    def tableRows(self):

        localctx = FuncTestCaseParser.TableRowsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_tableRows)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(FuncTestCaseParser.OParen)
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==110:
                self.state = 303
                self.columnValues()
                self.state = 308
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==114:
                    self.state = 304
                    self.match(FuncTestCaseParser.Comma)
                    self.state = 305
                    self.columnValues()
                    self.state = 310
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 313
            self.match(FuncTestCaseParser.CParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DataColumnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def columnValues(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ColumnValuesContext,0)


        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_dataColumn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDataColumn" ):
                listener.enterDataColumn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDataColumn" ):
                listener.exitDataColumn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDataColumn" ):
                return visitor.visitDataColumn(self)
            else:
                return visitor.visitChildren(self)




    def dataColumn(self):

        localctx = FuncTestCaseParser.DataColumnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_dataColumn)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.columnValues()
            self.state = 316
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 317
            self.dataType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ColumnValuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def literal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.LiteralContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.LiteralContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_columnValues

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumnValues" ):
                listener.enterColumnValues(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumnValues" ):
                listener.exitColumnValues(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumnValues" ):
                return visitor.visitColumnValues(self)
            else:
                return visitor.visitChildren(self)




    def columnValues(self):

        localctx = FuncTestCaseParser.ColumnValuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_columnValues)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 319
            self.match(FuncTestCaseParser.OParen)
            self.state = 328
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 272687440592896) != 0):
                self.state = 320
                self.literal()
                self.state = 325
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==114:
                    self.state = 321
                    self.match(FuncTestCaseParser.Comma)
                    self.state = 322
                    self.literal()
                    self.state = 327
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 330
            self.match(FuncTestCaseParser.CParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NullLiteral(self):
            return self.getToken(FuncTestCaseParser.NullLiteral, 0)

        def numericLiteral(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericLiteralContext,0)


        def BooleanLiteral(self):
            return self.getToken(FuncTestCaseParser.BooleanLiteral, 0)

        def StringLiteral(self):
            return self.getToken(FuncTestCaseParser.StringLiteral, 0)

        def DateLiteral(self):
            return self.getToken(FuncTestCaseParser.DateLiteral, 0)

        def TimeLiteral(self):
            return self.getToken(FuncTestCaseParser.TimeLiteral, 0)

        def TimestampLiteral(self):
            return self.getToken(FuncTestCaseParser.TimestampLiteral, 0)

        def TimestampTzLiteral(self):
            return self.getToken(FuncTestCaseParser.TimestampTzLiteral, 0)

        def IntervalYearLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalYearLiteral, 0)

        def IntervalDayLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalDayLiteral, 0)

        def IntervalCompoundLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalCompoundLiteral, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_literal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteral" ):
                listener.enterLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteral" ):
                listener.exitLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteral" ):
                return visitor.visitLiteral(self)
            else:
                return visitor.visitChildren(self)




    def literal(self):

        localctx = FuncTestCaseParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_literal)
        try:
            self.state = 343
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [46]:
                self.enterOuterAlt(localctx, 1)
                self.state = 332
                self.match(FuncTestCaseParser.NullLiteral)
                pass
            elif token in [19, 25, 26, 27]:
                self.enterOuterAlt(localctx, 2)
                self.state = 333
                self.numericLiteral()
                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 3)
                self.state = 334
                self.match(FuncTestCaseParser.BooleanLiteral)
                pass
            elif token in [47]:
                self.enterOuterAlt(localctx, 4)
                self.state = 335
                self.match(FuncTestCaseParser.StringLiteral)
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 5)
                self.state = 336
                self.match(FuncTestCaseParser.DateLiteral)
                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 6)
                self.state = 337
                self.match(FuncTestCaseParser.TimeLiteral)
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 7)
                self.state = 338
                self.match(FuncTestCaseParser.TimestampLiteral)
                pass
            elif token in [29]:
                self.enterOuterAlt(localctx, 8)
                self.state = 339
                self.match(FuncTestCaseParser.TimestampTzLiteral)
                pass
            elif token in [43]:
                self.enterOuterAlt(localctx, 9)
                self.state = 340
                self.match(FuncTestCaseParser.IntervalYearLiteral)
                pass
            elif token in [44]:
                self.enterOuterAlt(localctx, 10)
                self.state = 341
                self.match(FuncTestCaseParser.IntervalDayLiteral)
                pass
            elif token in [45]:
                self.enterOuterAlt(localctx, 11)
                self.state = 342
                self.match(FuncTestCaseParser.IntervalCompoundLiteral)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedAggregateFuncArgsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedAggregateFuncArg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.QualifiedAggregateFuncArgContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.QualifiedAggregateFuncArgContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_qualifiedAggregateFuncArgs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedAggregateFuncArgs" ):
                listener.enterQualifiedAggregateFuncArgs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedAggregateFuncArgs" ):
                listener.exitQualifiedAggregateFuncArgs(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQualifiedAggregateFuncArgs" ):
                return visitor.visitQualifiedAggregateFuncArgs(self)
            else:
                return visitor.visitChildren(self)




    def qualifiedAggregateFuncArgs(self):

        localctx = FuncTestCaseParser.QualifiedAggregateFuncArgsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_qualifiedAggregateFuncArgs)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 345
            self.qualifiedAggregateFuncArg()
            self.state = 350
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==114:
                self.state = 346
                self.match(FuncTestCaseParser.Comma)
                self.state = 347
                self.qualifiedAggregateFuncArg()
                self.state = 352
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggregateFuncArgsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def aggregateFuncArg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.AggregateFuncArgContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.AggregateFuncArgContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_aggregateFuncArgs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFuncArgs" ):
                listener.enterAggregateFuncArgs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFuncArgs" ):
                listener.exitAggregateFuncArgs(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAggregateFuncArgs" ):
                return visitor.visitAggregateFuncArgs(self)
            else:
                return visitor.visitChildren(self)




    def aggregateFuncArgs(self):

        localctx = FuncTestCaseParser.AggregateFuncArgsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_aggregateFuncArgs)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 353
            self.aggregateFuncArg()
            self.state = 358
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==114:
                self.state = 354
                self.match(FuncTestCaseParser.Comma)
                self.state = 355
                self.aggregateFuncArg()
                self.state = 360
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedAggregateFuncArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.tableName = None # Token

        def Dot(self):
            return self.getToken(FuncTestCaseParser.Dot, 0)

        def ColumnName(self):
            return self.getToken(FuncTestCaseParser.ColumnName, 0)

        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def argument(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ArgumentContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_qualifiedAggregateFuncArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedAggregateFuncArg" ):
                listener.enterQualifiedAggregateFuncArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedAggregateFuncArg" ):
                listener.exitQualifiedAggregateFuncArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQualifiedAggregateFuncArg" ):
                return visitor.visitQualifiedAggregateFuncArg(self)
            else:
                return visitor.visitChildren(self)




    def qualifiedAggregateFuncArg(self):

        localctx = FuncTestCaseParser.QualifiedAggregateFuncArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_qualifiedAggregateFuncArg)
        try:
            self.state = 365
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 361
                localctx.tableName = self.match(FuncTestCaseParser.Identifier)
                self.state = 362
                self.match(FuncTestCaseParser.Dot)
                self.state = 363
                self.match(FuncTestCaseParser.ColumnName)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 364
                self.argument()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggregateFuncArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ColumnName(self):
            return self.getToken(FuncTestCaseParser.ColumnName, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)


        def argument(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ArgumentContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_aggregateFuncArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFuncArg" ):
                listener.enterAggregateFuncArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFuncArg" ):
                listener.exitAggregateFuncArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAggregateFuncArg" ):
                return visitor.visitAggregateFuncArg(self)
            else:
                return visitor.visitChildren(self)




    def aggregateFuncArg(self):

        localctx = FuncTestCaseParser.AggregateFuncArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_aggregateFuncArg)
        try:
            self.state = 371
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [49]:
                self.enterOuterAlt(localctx, 1)
                self.state = 367
                self.match(FuncTestCaseParser.ColumnName)
                self.state = 368
                self.match(FuncTestCaseParser.DoubleColon)
                self.state = 369
                self.dataType()
                pass
            elif token in [19, 25, 26, 27, 28, 29, 30, 31, 32, 43, 44, 45, 46, 47, 110, 112, 124]:
                self.enterOuterAlt(localctx, 2)
                self.state = 370
                self.argument()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumericLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DecimalLiteral(self):
            return self.getToken(FuncTestCaseParser.DecimalLiteral, 0)

        def IntegerLiteral(self):
            return self.getToken(FuncTestCaseParser.IntegerLiteral, 0)

        def floatLiteral(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FloatLiteralContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_numericLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumericLiteral" ):
                listener.enterNumericLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumericLiteral" ):
                listener.exitNumericLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumericLiteral" ):
                return visitor.visitNumericLiteral(self)
            else:
                return visitor.visitChildren(self)




    def numericLiteral(self):

        localctx = FuncTestCaseParser.NumericLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_numericLiteral)
        try:
            self.state = 376
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [26]:
                self.enterOuterAlt(localctx, 1)
                self.state = 373
                self.match(FuncTestCaseParser.DecimalLiteral)
                pass
            elif token in [25]:
                self.enterOuterAlt(localctx, 2)
                self.state = 374
                self.match(FuncTestCaseParser.IntegerLiteral)
                pass
            elif token in [19, 27]:
                self.enterOuterAlt(localctx, 3)
                self.state = 375
                self.floatLiteral()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FloatLiteral(self):
            return self.getToken(FuncTestCaseParser.FloatLiteral, 0)

        def NaN(self):
            return self.getToken(FuncTestCaseParser.NaN, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_floatLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatLiteral" ):
                listener.enterFloatLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatLiteral" ):
                listener.exitFloatLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatLiteral" ):
                return visitor.visitFloatLiteral(self)
            else:
                return visitor.visitChildren(self)




    def floatLiteral(self):

        localctx = FuncTestCaseParser.FloatLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_floatLiteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 378
            _la = self._input.LA(1)
            if not(_la==19 or _la==27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NullArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NullLiteral(self):
            return self.getToken(FuncTestCaseParser.NullLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_nullArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNullArg" ):
                listener.enterNullArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNullArg" ):
                listener.exitNullArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNullArg" ):
                return visitor.visitNullArg(self)
            else:
                return visitor.visitChildren(self)




    def nullArg(self):

        localctx = FuncTestCaseParser.NullArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_nullArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 380
            self.match(FuncTestCaseParser.NullLiteral)
            self.state = 381
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 382
            self.dataType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IntegerLiteral(self):
            return self.getToken(FuncTestCaseParser.IntegerLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def intType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntArg" ):
                listener.enterIntArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntArg" ):
                listener.exitIntArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntArg" ):
                return visitor.visitIntArg(self)
            else:
                return visitor.visitChildren(self)




    def intArg(self):

        localctx = FuncTestCaseParser.IntArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_intArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 384
            self.match(FuncTestCaseParser.IntegerLiteral)
            self.state = 385
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 386
            self.intType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def numericLiteral(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericLiteralContext,0)


        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def floatType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FloatTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_floatArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatArg" ):
                listener.enterFloatArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatArg" ):
                listener.exitFloatArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatArg" ):
                return visitor.visitFloatArg(self)
            else:
                return visitor.visitChildren(self)




    def floatArg(self):

        localctx = FuncTestCaseParser.FloatArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_floatArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 388
            self.numericLiteral()
            self.state = 389
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 390
            self.floatType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DecimalArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def numericLiteral(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericLiteralContext,0)


        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def decimalType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DecimalTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_decimalArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecimalArg" ):
                listener.enterDecimalArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecimalArg" ):
                listener.exitDecimalArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDecimalArg" ):
                return visitor.visitDecimalArg(self)
            else:
                return visitor.visitChildren(self)




    def decimalArg(self):

        localctx = FuncTestCaseParser.DecimalArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_decimalArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 392
            self.numericLiteral()
            self.state = 393
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 394
            self.decimalType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BooleanLiteral(self):
            return self.getToken(FuncTestCaseParser.BooleanLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def booleanType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.BooleanTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_booleanArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanArg" ):
                listener.enterBooleanArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanArg" ):
                listener.exitBooleanArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBooleanArg" ):
                return visitor.visitBooleanArg(self)
            else:
                return visitor.visitChildren(self)




    def booleanArg(self):

        localctx = FuncTestCaseParser.BooleanArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_booleanArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 396
            self.match(FuncTestCaseParser.BooleanLiteral)
            self.state = 397
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 398
            self.booleanType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def StringLiteral(self):
            return self.getToken(FuncTestCaseParser.StringLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def stringType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.StringTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_stringArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringArg" ):
                listener.enterStringArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringArg" ):
                listener.exitStringArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringArg" ):
                return visitor.visitStringArg(self)
            else:
                return visitor.visitChildren(self)




    def stringArg(self):

        localctx = FuncTestCaseParser.StringArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_stringArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 400
            self.match(FuncTestCaseParser.StringLiteral)
            self.state = 401
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 402
            self.stringType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DateArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DateLiteral(self):
            return self.getToken(FuncTestCaseParser.DateLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def dateType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DateTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_dateArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateArg" ):
                listener.enterDateArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateArg" ):
                listener.exitDateArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDateArg" ):
                return visitor.visitDateArg(self)
            else:
                return visitor.visitChildren(self)




    def dateArg(self):

        localctx = FuncTestCaseParser.DateArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_dateArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            self.match(FuncTestCaseParser.DateLiteral)
            self.state = 405
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 406
            self.dateType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalYearArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IntervalYearLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalYearLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def intervalYearType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalYearTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalYearArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalYearArg" ):
                listener.enterIntervalYearArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalYearArg" ):
                listener.exitIntervalYearArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalYearArg" ):
                return visitor.visitIntervalYearArg(self)
            else:
                return visitor.visitChildren(self)




    def intervalYearArg(self):

        localctx = FuncTestCaseParser.IntervalYearArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_intervalYearArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 408
            self.match(FuncTestCaseParser.IntervalYearLiteral)
            self.state = 409
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 410
            self.intervalYearType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalDayArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IntervalDayLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalDayLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def intervalDayType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalDayTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalDayArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalDayArg" ):
                listener.enterIntervalDayArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalDayArg" ):
                listener.exitIntervalDayArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalDayArg" ):
                return visitor.visitIntervalDayArg(self)
            else:
                return visitor.visitChildren(self)




    def intervalDayArg(self):

        localctx = FuncTestCaseParser.IntervalDayArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_intervalDayArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self.match(FuncTestCaseParser.IntervalDayLiteral)
            self.state = 413
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 414
            self.intervalDayType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalCompoundArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IntervalCompoundLiteral(self):
            return self.getToken(FuncTestCaseParser.IntervalCompoundLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def intervalCompoundType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalCompoundTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalCompoundArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalCompoundArg" ):
                listener.enterIntervalCompoundArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalCompoundArg" ):
                listener.exitIntervalCompoundArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalCompoundArg" ):
                return visitor.visitIntervalCompoundArg(self)
            else:
                return visitor.visitChildren(self)




    def intervalCompoundArg(self):

        localctx = FuncTestCaseParser.IntervalCompoundArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_intervalCompoundArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 416
            self.match(FuncTestCaseParser.IntervalCompoundLiteral)
            self.state = 417
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 418
            self.intervalCompoundType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FixedCharArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def StringLiteral(self):
            return self.getToken(FuncTestCaseParser.StringLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def fixedCharType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedCharTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_fixedCharArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixedCharArg" ):
                listener.enterFixedCharArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixedCharArg" ):
                listener.exitFixedCharArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFixedCharArg" ):
                return visitor.visitFixedCharArg(self)
            else:
                return visitor.visitChildren(self)




    def fixedCharArg(self):

        localctx = FuncTestCaseParser.FixedCharArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_fixedCharArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 420
            self.match(FuncTestCaseParser.StringLiteral)
            self.state = 421
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 422
            self.fixedCharType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarCharArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def StringLiteral(self):
            return self.getToken(FuncTestCaseParser.StringLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def varCharType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.VarCharTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_varCharArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarCharArg" ):
                listener.enterVarCharArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarCharArg" ):
                listener.exitVarCharArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarCharArg" ):
                return visitor.visitVarCharArg(self)
            else:
                return visitor.visitChildren(self)




    def varCharArg(self):

        localctx = FuncTestCaseParser.VarCharArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_varCharArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 424
            self.match(FuncTestCaseParser.StringLiteral)
            self.state = 425
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 426
            self.varCharType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FixedBinaryArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def StringLiteral(self):
            return self.getToken(FuncTestCaseParser.StringLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def fixedBinaryType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedBinaryTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_fixedBinaryArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixedBinaryArg" ):
                listener.enterFixedBinaryArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixedBinaryArg" ):
                listener.exitFixedBinaryArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFixedBinaryArg" ):
                return visitor.visitFixedBinaryArg(self)
            else:
                return visitor.visitChildren(self)




    def fixedBinaryArg(self):

        localctx = FuncTestCaseParser.FixedBinaryArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_fixedBinaryArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 428
            self.match(FuncTestCaseParser.StringLiteral)
            self.state = 429
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 430
            self.fixedBinaryType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimeArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TimeLiteral(self):
            return self.getToken(FuncTestCaseParser.TimeLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def precisionTimeType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimeTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimeArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimeArg" ):
                listener.enterPrecisionTimeArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimeArg" ):
                listener.exitPrecisionTimeArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimeArg" ):
                return visitor.visitPrecisionTimeArg(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimeArg(self):

        localctx = FuncTestCaseParser.PrecisionTimeArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_precisionTimeArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 432
            self.match(FuncTestCaseParser.TimeLiteral)
            self.state = 433
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 434
            self.precisionTimeType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimestampArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TimestampLiteral(self):
            return self.getToken(FuncTestCaseParser.TimestampLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def precisionTimestampType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimestampArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimestampArg" ):
                listener.enterPrecisionTimestampArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimestampArg" ):
                listener.exitPrecisionTimestampArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimestampArg" ):
                return visitor.visitPrecisionTimestampArg(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimestampArg(self):

        localctx = FuncTestCaseParser.PrecisionTimestampArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_precisionTimestampArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 436
            self.match(FuncTestCaseParser.TimestampLiteral)
            self.state = 437
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 438
            self.precisionTimestampType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimestampTZArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TimestampTzLiteral(self):
            return self.getToken(FuncTestCaseParser.TimestampTzLiteral, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def precisionTimestampTZType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampTZTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimestampTZArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimestampTZArg" ):
                listener.enterPrecisionTimestampTZArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimestampTZArg" ):
                listener.exitPrecisionTimestampTZArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimestampTZArg" ):
                return visitor.visitPrecisionTimestampTZArg(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimestampTZArg(self):

        localctx = FuncTestCaseParser.PrecisionTimestampTZArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_precisionTimestampTZArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 440
            self.match(FuncTestCaseParser.TimestampTzLiteral)
            self.state = 441
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 442
            self.precisionTimestampTZType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def literalList(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LiteralListContext,0)


        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def listType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ListTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_listArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListArg" ):
                listener.enterListArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListArg" ):
                listener.exitListArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListArg" ):
                return visitor.visitListArg(self)
            else:
                return visitor.visitChildren(self)




    def listArg(self):

        localctx = FuncTestCaseParser.ListArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_listArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 444
            self.literalList()
            self.state = 445
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 446
            self.listType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LambdaArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def literalLambda(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LiteralLambdaContext,0)


        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def funcType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FuncTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_lambdaArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLambdaArg" ):
                listener.enterLambdaArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLambdaArg" ):
                listener.exitLambdaArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLambdaArg" ):
                return visitor.visitLambdaArg(self)
            else:
                return visitor.visitChildren(self)




    def lambdaArg(self):

        localctx = FuncTestCaseParser.LambdaArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_lambdaArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.literalLambda()
            self.state = 449
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 450
            self.funcType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def DoubleColon(self):
            return self.getToken(FuncTestCaseParser.DoubleColon, 0)

        def EnumType(self):
            return self.getToken(FuncTestCaseParser.EnumType, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_enumArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumArg" ):
                listener.enterEnumArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumArg" ):
                listener.exitEnumArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumArg" ):
                return visitor.visitEnumArg(self)
            else:
                return visitor.visitChildren(self)




    def enumArg(self):

        localctx = FuncTestCaseParser.EnumArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_enumArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 452
            self.match(FuncTestCaseParser.Identifier)
            self.state = 453
            self.match(FuncTestCaseParser.DoubleColon)
            self.state = 454
            self.match(FuncTestCaseParser.EnumType)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OBracket(self):
            return self.getToken(FuncTestCaseParser.OBracket, 0)

        def CBracket(self):
            return self.getToken(FuncTestCaseParser.CBracket, 0)

        def listElement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.ListElementContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.ListElementContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_literalList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralList" ):
                listener.enterLiteralList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralList" ):
                listener.exitLiteralList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralList" ):
                return visitor.visitLiteralList(self)
            else:
                return visitor.visitChildren(self)




    def literalList(self):

        localctx = FuncTestCaseParser.LiteralListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_literalList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 456
            self.match(FuncTestCaseParser.OBracket)
            self.state = 465
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 272687440592896) != 0) or _la==112:
                self.state = 457
                self.listElement()
                self.state = 462
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==114:
                    self.state = 458
                    self.match(FuncTestCaseParser.Comma)
                    self.state = 459
                    self.listElement()
                    self.state = 464
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 467
            self.match(FuncTestCaseParser.CBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def literal(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LiteralContext,0)


        def literalList(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LiteralListContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_listElement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListElement" ):
                listener.enterListElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListElement" ):
                listener.exitListElement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListElement" ):
                return visitor.visitListElement(self)
            else:
                return visitor.visitChildren(self)




    def listElement(self):

        localctx = FuncTestCaseParser.ListElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_listElement)
        try:
            self.state = 471
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19, 25, 26, 27, 28, 29, 30, 31, 32, 43, 44, 45, 46, 47]:
                self.enterOuterAlt(localctx, 1)
                self.state = 469
                self.literal()
                pass
            elif token in [112]:
                self.enterOuterAlt(localctx, 2)
                self.state = 470
                self.literalList()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralLambdaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def lambdaParameters(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LambdaParametersContext,0)


        def Arrow(self):
            return self.getToken(FuncTestCaseParser.Arrow, 0)

        def lambdaBody(self):
            return self.getTypedRuleContext(FuncTestCaseParser.LambdaBodyContext,0)


        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_literalLambda

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralLambda" ):
                listener.enterLiteralLambda(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralLambda" ):
                listener.exitLiteralLambda(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralLambda" ):
                return visitor.visitLiteralLambda(self)
            else:
                return visitor.visitChildren(self)




    def literalLambda(self):

        localctx = FuncTestCaseParser.LiteralLambdaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_literalLambda)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 473
            self.match(FuncTestCaseParser.OParen)
            self.state = 474
            self.lambdaParameters()
            self.state = 475
            self.match(FuncTestCaseParser.Arrow)
            self.state = 476
            self.lambdaBody()
            self.state = 477
            self.match(FuncTestCaseParser.CParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LambdaParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_lambdaParameters

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TupleParamsContext(LambdaParametersContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.LambdaParametersContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)
        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Identifier)
            else:
                return self.getToken(FuncTestCaseParser.Identifier, i)
        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)
        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTupleParams" ):
                listener.enterTupleParams(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTupleParams" ):
                listener.exitTupleParams(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTupleParams" ):
                return visitor.visitTupleParams(self)
            else:
                return visitor.visitChildren(self)


    class SingleParamContext(LambdaParametersContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.LambdaParametersContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingleParam" ):
                listener.enterSingleParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingleParam" ):
                listener.exitSingleParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSingleParam" ):
                return visitor.visitSingleParam(self)
            else:
                return visitor.visitChildren(self)



    def lambdaParameters(self):

        localctx = FuncTestCaseParser.LambdaParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_lambdaParameters)
        self._la = 0 # Token type
        try:
            self.state = 489
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [124]:
                localctx = FuncTestCaseParser.SingleParamContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 479
                self.match(FuncTestCaseParser.Identifier)
                pass
            elif token in [110]:
                localctx = FuncTestCaseParser.TupleParamsContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 480
                self.match(FuncTestCaseParser.OParen)
                self.state = 481
                self.match(FuncTestCaseParser.Identifier)
                self.state = 484 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 482
                    self.match(FuncTestCaseParser.Comma)
                    self.state = 483
                    self.match(FuncTestCaseParser.Identifier)
                    self.state = 486 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==114):
                        break

                self.state = 488
                self.match(FuncTestCaseParser.CParen)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LambdaBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IdentifierContext,0)


        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)

        def arguments(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ArgumentsContext,0)


        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_lambdaBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLambdaBody" ):
                listener.enterLambdaBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLambdaBody" ):
                listener.exitLambdaBody(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLambdaBody" ):
                return visitor.visitLambdaBody(self)
            else:
                return visitor.visitChildren(self)




    def lambdaBody(self):

        localctx = FuncTestCaseParser.LambdaBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_lambdaBody)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 491
            self.identifier()
            self.state = 492
            self.match(FuncTestCaseParser.OParen)
            self.state = 493
            self.arguments()
            self.state = 494
            self.match(FuncTestCaseParser.CParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DataTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scalarType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ScalarTypeContext,0)


        def parameterizedType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ParameterizedTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_dataType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDataType" ):
                listener.enterDataType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDataType" ):
                listener.exitDataType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDataType" ):
                return visitor.visitDataType(self)
            else:
                return visitor.visitChildren(self)




    def dataType(self):

        localctx = FuncTestCaseParser.DataTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_dataType)
        try:
            self.state = 498
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 69, 81, 82, 83, 84, 85]:
                self.enterOuterAlt(localctx, 1)
                self.state = 496
                self.scalarType()
                pass
            elif token in [55, 67, 68, 70, 71, 72, 73, 74, 75, 76, 79, 86, 87, 88, 89, 90, 91, 92, 93, 94]:
                self.enterOuterAlt(localctx, 2)
                self.state = 497
                self.parameterizedType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScalarTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_scalarType

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class DateContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def dateType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DateTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDate" ):
                listener.enterDate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDate" ):
                listener.exitDate(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDate" ):
                return visitor.visitDate(self)
            else:
                return visitor.visitChildren(self)


    class BooleanContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def booleanType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.BooleanTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolean" ):
                listener.enterBoolean(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolean" ):
                listener.exitBoolean(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolean" ):
                return visitor.visitBoolean(self)
            else:
                return visitor.visitChildren(self)


    class StringContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def stringType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.StringTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)


    class BinaryContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def binaryType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.BinaryTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBinary" ):
                listener.enterBinary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBinary" ):
                listener.exitBinary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinary" ):
                return visitor.visitBinary(self)
            else:
                return visitor.visitChildren(self)


    class UserDefinedContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.isnull = None # Token
            self.copyFrom(ctx)

        def UserDefined(self):
            return self.getToken(FuncTestCaseParser.UserDefined, 0)
        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)
        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUserDefined" ):
                listener.enterUserDefined(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUserDefined" ):
                listener.exitUserDefined(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUserDefined" ):
                return visitor.visitUserDefined(self)
            else:
                return visitor.visitChildren(self)


    class FloatContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def floatType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FloatTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloat" ):
                listener.enterFloat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloat" ):
                listener.exitFloat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloat" ):
                return visitor.visitFloat(self)
            else:
                return visitor.visitChildren(self)


    class IntervalYearContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def intervalYearType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalYearTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalYear" ):
                listener.enterIntervalYear(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalYear" ):
                listener.exitIntervalYear(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalYear" ):
                return visitor.visitIntervalYear(self)
            else:
                return visitor.visitChildren(self)


    class UuidContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.isnull = None # Token
            self.copyFrom(ctx)

        def UUID(self):
            return self.getToken(FuncTestCaseParser.UUID, 0)
        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUuid" ):
                listener.enterUuid(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUuid" ):
                listener.exitUuid(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUuid" ):
                return visitor.visitUuid(self)
            else:
                return visitor.visitChildren(self)


    class IntContext(ScalarTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ScalarTypeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def intType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInt" ):
                listener.enterInt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInt" ):
                listener.exitInt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInt" ):
                return visitor.visitInt(self)
            else:
                return visitor.visitChildren(self)



    def scalarType(self):

        localctx = FuncTestCaseParser.ScalarTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_scalarType)
        self._la = 0 # Token type
        try:
            self.state = 516
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [56, 82]:
                localctx = FuncTestCaseParser.BooleanContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 500
                self.booleanType()
                pass
            elif token in [57, 58, 59, 60]:
                localctx = FuncTestCaseParser.IntContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 501
                self.intType()
                pass
            elif token in [61, 62]:
                localctx = FuncTestCaseParser.FloatContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 502
                self.floatType()
                pass
            elif token in [63, 83]:
                localctx = FuncTestCaseParser.StringContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 503
                self.stringType()
                pass
            elif token in [64, 84]:
                localctx = FuncTestCaseParser.BinaryContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 504
                self.binaryType()
                pass
            elif token in [65]:
                localctx = FuncTestCaseParser.DateContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 505
                self.dateType()
                pass
            elif token in [66, 85]:
                localctx = FuncTestCaseParser.IntervalYearContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 506
                self.intervalYearType()
                pass
            elif token in [69]:
                localctx = FuncTestCaseParser.UuidContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 507
                self.match(FuncTestCaseParser.UUID)
                self.state = 509
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==116:
                    self.state = 508
                    localctx.isnull = self.match(FuncTestCaseParser.QMark)


                pass
            elif token in [81]:
                localctx = FuncTestCaseParser.UserDefinedContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 511
                self.match(FuncTestCaseParser.UserDefined)
                self.state = 512
                self.match(FuncTestCaseParser.Identifier)
                self.state = 514
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==116:
                    self.state = 513
                    localctx.isnull = self.match(FuncTestCaseParser.QMark)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def Bool(self):
            return self.getToken(FuncTestCaseParser.Bool, 0)

        def Boolean(self):
            return self.getToken(FuncTestCaseParser.Boolean, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_booleanType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanType" ):
                listener.enterBooleanType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanType" ):
                listener.exitBooleanType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBooleanType" ):
                return visitor.visitBooleanType(self)
            else:
                return visitor.visitChildren(self)




    def booleanType(self):

        localctx = FuncTestCaseParser.BooleanTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_booleanType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 518
            _la = self._input.LA(1)
            if not(_la==56 or _la==82):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 520
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 519
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def Str(self):
            return self.getToken(FuncTestCaseParser.Str, 0)

        def String(self):
            return self.getToken(FuncTestCaseParser.String, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_stringType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringType" ):
                listener.enterStringType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringType" ):
                listener.exitStringType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringType" ):
                return visitor.visitStringType(self)
            else:
                return visitor.visitChildren(self)




    def stringType(self):

        localctx = FuncTestCaseParser.StringTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_stringType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 522
            _la = self._input.LA(1)
            if not(_la==63 or _la==83):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 524
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 523
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BinaryTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def Binary(self):
            return self.getToken(FuncTestCaseParser.Binary, 0)

        def VBin(self):
            return self.getToken(FuncTestCaseParser.VBin, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_binaryType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBinaryType" ):
                listener.enterBinaryType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBinaryType" ):
                listener.exitBinaryType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinaryType" ):
                return visitor.visitBinaryType(self)
            else:
                return visitor.visitChildren(self)




    def binaryType(self):

        localctx = FuncTestCaseParser.BinaryTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_binaryType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 526
            _la = self._input.LA(1)
            if not(_la==64 or _la==84):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 528
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 527
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def I8(self):
            return self.getToken(FuncTestCaseParser.I8, 0)

        def I16(self):
            return self.getToken(FuncTestCaseParser.I16, 0)

        def I32(self):
            return self.getToken(FuncTestCaseParser.I32, 0)

        def I64(self):
            return self.getToken(FuncTestCaseParser.I64, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntType" ):
                listener.enterIntType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntType" ):
                listener.exitIntType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntType" ):
                return visitor.visitIntType(self)
            else:
                return visitor.visitChildren(self)




    def intType(self):

        localctx = FuncTestCaseParser.IntTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_intType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 530
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2161727821137838080) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 532
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 531
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def FP32(self):
            return self.getToken(FuncTestCaseParser.FP32, 0)

        def FP64(self):
            return self.getToken(FuncTestCaseParser.FP64, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_floatType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatType" ):
                listener.enterFloatType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatType" ):
                listener.exitFloatType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatType" ):
                return visitor.visitFloatType(self)
            else:
                return visitor.visitChildren(self)




    def floatType(self):

        localctx = FuncTestCaseParser.FloatTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_floatType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 534
            _la = self._input.LA(1)
            if not(_la==61 or _la==62):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 536
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 535
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DateTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def Date(self):
            return self.getToken(FuncTestCaseParser.Date, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_dateType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateType" ):
                listener.enterDateType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateType" ):
                listener.exitDateType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDateType" ):
                return visitor.visitDateType(self)
            else:
                return visitor.visitChildren(self)




    def dateType(self):

        localctx = FuncTestCaseParser.DateTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_dateType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 538
            self.match(FuncTestCaseParser.Date)
            self.state = 540
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 539
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalYearTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token

        def IYear(self):
            return self.getToken(FuncTestCaseParser.IYear, 0)

        def Interval_Year(self):
            return self.getToken(FuncTestCaseParser.Interval_Year, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalYearType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalYearType" ):
                listener.enterIntervalYearType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalYearType" ):
                listener.exitIntervalYearType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalYearType" ):
                return visitor.visitIntervalYearType(self)
            else:
                return visitor.visitChildren(self)




    def intervalYearType(self):

        localctx = FuncTestCaseParser.IntervalYearTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_intervalYearType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 542
            _la = self._input.LA(1)
            if not(_la==66 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 544
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 543
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalDayTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.len_ = None # NumericParameterContext

        def IDay(self):
            return self.getToken(FuncTestCaseParser.IDay, 0)

        def Interval_Day(self):
            return self.getToken(FuncTestCaseParser.Interval_Day, 0)

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalDayType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalDayType" ):
                listener.enterIntervalDayType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalDayType" ):
                listener.exitIntervalDayType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalDayType" ):
                return visitor.visitIntervalDayType(self)
            else:
                return visitor.visitChildren(self)




    def intervalDayType(self):

        localctx = FuncTestCaseParser.IntervalDayTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_intervalDayType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 546
            _la = self._input.LA(1)
            if not(_la==67 or _la==86):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 548
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 547
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 554
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41:
                self.state = 550
                self.match(FuncTestCaseParser.OAngleBracket)
                self.state = 551
                localctx.len_ = self.numericParameter()
                self.state = 552
                self.match(FuncTestCaseParser.CAngleBracket)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalCompoundTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.len_ = None # NumericParameterContext

        def ICompound(self):
            return self.getToken(FuncTestCaseParser.ICompound, 0)

        def Interval_Compound(self):
            return self.getToken(FuncTestCaseParser.Interval_Compound, 0)

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_intervalCompoundType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalCompoundType" ):
                listener.enterIntervalCompoundType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalCompoundType" ):
                listener.exitIntervalCompoundType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalCompoundType" ):
                return visitor.visitIntervalCompoundType(self)
            else:
                return visitor.visitChildren(self)




    def intervalCompoundType(self):

        localctx = FuncTestCaseParser.IntervalCompoundTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_intervalCompoundType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 556
            _la = self._input.LA(1)
            if not(_la==68 or _la==87):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 558
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 557
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 564
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41:
                self.state = 560
                self.match(FuncTestCaseParser.OAngleBracket)
                self.state = 561
                localctx.len_ = self.numericParameter()
                self.state = 562
                self.match(FuncTestCaseParser.CAngleBracket)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FixedCharTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.len_ = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def FChar(self):
            return self.getToken(FuncTestCaseParser.FChar, 0)

        def FixedChar(self):
            return self.getToken(FuncTestCaseParser.FixedChar, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_fixedCharType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixedCharType" ):
                listener.enterFixedCharType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixedCharType" ):
                listener.exitFixedCharType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFixedCharType" ):
                return visitor.visitFixedCharType(self)
            else:
                return visitor.visitChildren(self)




    def fixedCharType(self):

        localctx = FuncTestCaseParser.FixedCharTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_fixedCharType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 566
            _la = self._input.LA(1)
            if not(_la==74 or _la==92):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 568
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 567
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 570
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 571
            localctx.len_ = self.numericParameter()
            self.state = 572
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarCharTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.len_ = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def VChar(self):
            return self.getToken(FuncTestCaseParser.VChar, 0)

        def VarChar(self):
            return self.getToken(FuncTestCaseParser.VarChar, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_varCharType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarCharType" ):
                listener.enterVarCharType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarCharType" ):
                listener.exitVarCharType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarCharType" ):
                return visitor.visitVarCharType(self)
            else:
                return visitor.visitChildren(self)




    def varCharType(self):

        localctx = FuncTestCaseParser.VarCharTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_varCharType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 574
            _la = self._input.LA(1)
            if not(_la==75 or _la==93):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 576
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 575
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 578
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 579
            localctx.len_ = self.numericParameter()
            self.state = 580
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FixedBinaryTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.len_ = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def FBin(self):
            return self.getToken(FuncTestCaseParser.FBin, 0)

        def FixedBinary(self):
            return self.getToken(FuncTestCaseParser.FixedBinary, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_fixedBinaryType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixedBinaryType" ):
                listener.enterFixedBinaryType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixedBinaryType" ):
                listener.exitFixedBinaryType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFixedBinaryType" ):
                return visitor.visitFixedBinaryType(self)
            else:
                return visitor.visitChildren(self)




    def fixedBinaryType(self):

        localctx = FuncTestCaseParser.FixedBinaryTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 122, self.RULE_fixedBinaryType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 582
            _la = self._input.LA(1)
            if not(_la==76 or _la==94):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 584
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 583
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 586
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 587
            localctx.len_ = self.numericParameter()
            self.state = 588
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DecimalTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.precision = None # NumericParameterContext
            self.scale = None # NumericParameterContext

        def Dec(self):
            return self.getToken(FuncTestCaseParser.Dec, 0)

        def Decimal(self):
            return self.getToken(FuncTestCaseParser.Decimal, 0)

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def Comma(self):
            return self.getToken(FuncTestCaseParser.Comma, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def numericParameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.NumericParameterContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,i)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_decimalType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecimalType" ):
                listener.enterDecimalType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecimalType" ):
                listener.exitDecimalType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDecimalType" ):
                return visitor.visitDecimalType(self)
            else:
                return visitor.visitChildren(self)




    def decimalType(self):

        localctx = FuncTestCaseParser.DecimalTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 124, self.RULE_decimalType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 590
            _la = self._input.LA(1)
            if not(_la==70 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 592
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 591
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 600
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41:
                self.state = 594
                self.match(FuncTestCaseParser.OAngleBracket)
                self.state = 595
                localctx.precision = self.numericParameter()
                self.state = 596
                self.match(FuncTestCaseParser.Comma)
                self.state = 597
                localctx.scale = self.numericParameter()
                self.state = 598
                self.match(FuncTestCaseParser.CAngleBracket)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimeTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.precision = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def PT(self):
            return self.getToken(FuncTestCaseParser.PT, 0)

        def Precision_Time(self):
            return self.getToken(FuncTestCaseParser.Precision_Time, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimeType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimeType" ):
                listener.enterPrecisionTimeType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimeType" ):
                listener.exitPrecisionTimeType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimeType" ):
                return visitor.visitPrecisionTimeType(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimeType(self):

        localctx = FuncTestCaseParser.PrecisionTimeTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 126, self.RULE_precisionTimeType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 602
            _la = self._input.LA(1)
            if not(_la==71 or _la==89):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 604
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 603
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 606
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 607
            localctx.precision = self.numericParameter()
            self.state = 608
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimestampTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.precision = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def PTs(self):
            return self.getToken(FuncTestCaseParser.PTs, 0)

        def Precision_Timestamp(self):
            return self.getToken(FuncTestCaseParser.Precision_Timestamp, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimestampType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimestampType" ):
                listener.enterPrecisionTimestampType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimestampType" ):
                listener.exitPrecisionTimestampType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimestampType" ):
                return visitor.visitPrecisionTimestampType(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimestampType(self):

        localctx = FuncTestCaseParser.PrecisionTimestampTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 128, self.RULE_precisionTimestampType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 610
            _la = self._input.LA(1)
            if not(_la==72 or _la==90):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 612
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 611
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 614
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 615
            localctx.precision = self.numericParameter()
            self.state = 616
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrecisionTimestampTZTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.precision = None # NumericParameterContext

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def PTsTZ(self):
            return self.getToken(FuncTestCaseParser.PTsTZ, 0)

        def Precision_Timestamp_TZ(self):
            return self.getToken(FuncTestCaseParser.Precision_Timestamp_TZ, 0)

        def numericParameter(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NumericParameterContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_precisionTimestampTZType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecisionTimestampTZType" ):
                listener.enterPrecisionTimestampTZType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecisionTimestampTZType" ):
                listener.exitPrecisionTimestampTZType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrecisionTimestampTZType" ):
                return visitor.visitPrecisionTimestampTZType(self)
            else:
                return visitor.visitChildren(self)




    def precisionTimestampTZType(self):

        localctx = FuncTestCaseParser.PrecisionTimestampTZTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 130, self.RULE_precisionTimestampTZType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 618
            _la = self._input.LA(1)
            if not(_la==73 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 620
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 619
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 622
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 623
            localctx.precision = self.numericParameter()
            self.state = 624
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_listType

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ListContext(ListTypeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.ListTypeContext
            super().__init__(parser)
            self.isnull = None # Token
            self.elemType = None # DataTypeContext
            self.copyFrom(ctx)

        def List(self):
            return self.getToken(FuncTestCaseParser.List, 0)
        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)
        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)
        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)

        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList" ):
                listener.enterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList" ):
                listener.exitList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitList" ):
                return visitor.visitList(self)
            else:
                return visitor.visitChildren(self)



    def listType(self):

        localctx = FuncTestCaseParser.ListTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 132, self.RULE_listType)
        self._la = 0 # Token type
        try:
            localctx = FuncTestCaseParser.ListContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 626
            self.match(FuncTestCaseParser.List)
            self.state = 628
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 627
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 630
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 631
            localctx.elemType = self.dataType()
            self.state = 632
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.isnull = None # Token
            self.params = None # FuncParametersContext
            self.returnType = None # DataTypeContext

        def Func(self):
            return self.getToken(FuncTestCaseParser.Func, 0)

        def OAngleBracket(self):
            return self.getToken(FuncTestCaseParser.OAngleBracket, 0)

        def Arrow(self):
            return self.getToken(FuncTestCaseParser.Arrow, 0)

        def CAngleBracket(self):
            return self.getToken(FuncTestCaseParser.CAngleBracket, 0)

        def funcParameters(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FuncParametersContext,0)


        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)


        def QMark(self):
            return self.getToken(FuncTestCaseParser.QMark, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_funcType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncType" ):
                listener.enterFuncType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncType" ):
                listener.exitFuncType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncType" ):
                return visitor.visitFuncType(self)
            else:
                return visitor.visitChildren(self)




    def funcType(self):

        localctx = FuncTestCaseParser.FuncTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 134, self.RULE_funcType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 634
            self.match(FuncTestCaseParser.Func)
            self.state = 636
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==116:
                self.state = 635
                localctx.isnull = self.match(FuncTestCaseParser.QMark)


            self.state = 638
            self.match(FuncTestCaseParser.OAngleBracket)
            self.state = 639
            localctx.params = self.funcParameters()
            self.state = 640
            self.match(FuncTestCaseParser.Arrow)
            self.state = 641
            localctx.returnType = self.dataType()
            self.state = 642
            self.match(FuncTestCaseParser.CAngleBracket)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_funcParameters

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SingleFuncParamContext(FuncParametersContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.FuncParametersContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def dataType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingleFuncParam" ):
                listener.enterSingleFuncParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingleFuncParam" ):
                listener.exitSingleFuncParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSingleFuncParam" ):
                return visitor.visitSingleFuncParam(self)
            else:
                return visitor.visitChildren(self)


    class FuncParamsWithParensContext(FuncParametersContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.FuncParametersContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OParen(self):
            return self.getToken(FuncTestCaseParser.OParen, 0)
        def dataType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.DataTypeContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.DataTypeContext,i)

        def CParen(self):
            return self.getToken(FuncTestCaseParser.CParen, 0)
        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncParamsWithParens" ):
                listener.enterFuncParamsWithParens(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncParamsWithParens" ):
                listener.exitFuncParamsWithParens(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncParamsWithParens" ):
                return visitor.visitFuncParamsWithParens(self)
            else:
                return visitor.visitChildren(self)



    def funcParameters(self):

        localctx = FuncTestCaseParser.FuncParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 136, self.RULE_funcParameters)
        self._la = 0 # Token type
        try:
            self.state = 656
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94]:
                localctx = FuncTestCaseParser.SingleFuncParamContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 644
                self.dataType()
                pass
            elif token in [110]:
                localctx = FuncTestCaseParser.FuncParamsWithParensContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 645
                self.match(FuncTestCaseParser.OParen)
                self.state = 646
                self.dataType()
                self.state = 651
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==114:
                    self.state = 647
                    self.match(FuncTestCaseParser.Comma)
                    self.state = 648
                    self.dataType()
                    self.state = 653
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 654
                self.match(FuncTestCaseParser.CParen)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterizedTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixedCharType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedCharTypeContext,0)


        def varCharType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.VarCharTypeContext,0)


        def fixedBinaryType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FixedBinaryTypeContext,0)


        def decimalType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.DecimalTypeContext,0)


        def intervalDayType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalDayTypeContext,0)


        def intervalCompoundType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.IntervalCompoundTypeContext,0)


        def precisionTimeType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimeTypeContext,0)


        def precisionTimestampType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampTypeContext,0)


        def precisionTimestampTZType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.PrecisionTimestampTZTypeContext,0)


        def listType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.ListTypeContext,0)


        def funcType(self):
            return self.getTypedRuleContext(FuncTestCaseParser.FuncTypeContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_parameterizedType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameterizedType" ):
                listener.enterParameterizedType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameterizedType" ):
                listener.exitParameterizedType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameterizedType" ):
                return visitor.visitParameterizedType(self)
            else:
                return visitor.visitChildren(self)




    def parameterizedType(self):

        localctx = FuncTestCaseParser.ParameterizedTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 138, self.RULE_parameterizedType)
        try:
            self.state = 669
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [74, 92]:
                self.enterOuterAlt(localctx, 1)
                self.state = 658
                self.fixedCharType()
                pass
            elif token in [75, 93]:
                self.enterOuterAlt(localctx, 2)
                self.state = 659
                self.varCharType()
                pass
            elif token in [76, 94]:
                self.enterOuterAlt(localctx, 3)
                self.state = 660
                self.fixedBinaryType()
                pass
            elif token in [70, 88]:
                self.enterOuterAlt(localctx, 4)
                self.state = 661
                self.decimalType()
                pass
            elif token in [67, 86]:
                self.enterOuterAlt(localctx, 5)
                self.state = 662
                self.intervalDayType()
                pass
            elif token in [68, 87]:
                self.enterOuterAlt(localctx, 6)
                self.state = 663
                self.intervalCompoundType()
                pass
            elif token in [71, 89]:
                self.enterOuterAlt(localctx, 7)
                self.state = 664
                self.precisionTimeType()
                pass
            elif token in [72, 90]:
                self.enterOuterAlt(localctx, 8)
                self.state = 665
                self.precisionTimestampType()
                pass
            elif token in [73, 91]:
                self.enterOuterAlt(localctx, 9)
                self.state = 666
                self.precisionTimestampTZType()
                pass
            elif token in [79]:
                self.enterOuterAlt(localctx, 10)
                self.state = 667
                self.listType()
                pass
            elif token in [55]:
                self.enterOuterAlt(localctx, 11)
                self.state = 668
                self.funcType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumericParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_numericParameter

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class IntegerLiteralContext(NumericParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a FuncTestCaseParser.NumericParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IntegerLiteral(self):
            return self.getToken(FuncTestCaseParser.IntegerLiteral, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntegerLiteral" ):
                listener.enterIntegerLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntegerLiteral" ):
                listener.exitIntegerLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntegerLiteral" ):
                return visitor.visitIntegerLiteral(self)
            else:
                return visitor.visitChildren(self)



    def numericParameter(self):

        localctx = FuncTestCaseParser.NumericParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 140, self.RULE_numericParameter)
        try:
            localctx = FuncTestCaseParser.IntegerLiteralContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 671
            self.match(FuncTestCaseParser.IntegerLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SubstraitErrorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ErrorResult(self):
            return self.getToken(FuncTestCaseParser.ErrorResult, 0)

        def UndefineResult(self):
            return self.getToken(FuncTestCaseParser.UndefineResult, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_substraitError

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubstraitError" ):
                listener.enterSubstraitError(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubstraitError" ):
                listener.exitSubstraitError(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubstraitError" ):
                return visitor.visitSubstraitError(self)
            else:
                return visitor.visitChildren(self)




    def substraitError(self):

        localctx = FuncTestCaseParser.SubstraitErrorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 142, self.RULE_substraitError)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 673
            _la = self._input.LA(1)
            if not(_la==11 or _la==12):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncOptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionName(self):
            return self.getTypedRuleContext(FuncTestCaseParser.OptionNameContext,0)


        def Colon(self):
            return self.getToken(FuncTestCaseParser.Colon, 0)

        def optionValue(self):
            return self.getTypedRuleContext(FuncTestCaseParser.OptionValueContext,0)


        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_funcOption

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncOption" ):
                listener.enterFuncOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncOption" ):
                listener.exitFuncOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncOption" ):
                return visitor.visitFuncOption(self)
            else:
                return visitor.visitChildren(self)




    def funcOption(self):

        localctx = FuncTestCaseParser.FuncOptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 144, self.RULE_funcOption)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 675
            self.optionName()
            self.state = 676
            self.match(FuncTestCaseParser.Colon)
            self.state = 677
            self.optionValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Overflow(self):
            return self.getToken(FuncTestCaseParser.Overflow, 0)

        def Rounding(self):
            return self.getToken(FuncTestCaseParser.Rounding, 0)

        def NullHandling(self):
            return self.getToken(FuncTestCaseParser.NullHandling, 0)

        def SpacesOnly(self):
            return self.getToken(FuncTestCaseParser.SpacesOnly, 0)

        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_optionName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionName" ):
                listener.enterOptionName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionName" ):
                listener.exitOptionName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionName" ):
                return visitor.visitOptionName(self)
            else:
                return visitor.visitChildren(self)




    def optionName(self):

        localctx = FuncTestCaseParser.OptionNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 146, self.RULE_optionName)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 679
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 12607488) != 0) or _la==124):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Error(self):
            return self.getToken(FuncTestCaseParser.Error, 0)

        def Saturate(self):
            return self.getToken(FuncTestCaseParser.Saturate, 0)

        def Silent(self):
            return self.getToken(FuncTestCaseParser.Silent, 0)

        def TieToEven(self):
            return self.getToken(FuncTestCaseParser.TieToEven, 0)

        def NaN(self):
            return self.getToken(FuncTestCaseParser.NaN, 0)

        def Truncate(self):
            return self.getToken(FuncTestCaseParser.Truncate, 0)

        def AcceptNulls(self):
            return self.getToken(FuncTestCaseParser.AcceptNulls, 0)

        def IgnoreNulls(self):
            return self.getToken(FuncTestCaseParser.IgnoreNulls, 0)

        def BooleanLiteral(self):
            return self.getToken(FuncTestCaseParser.BooleanLiteral, 0)

        def NullLiteral(self):
            return self.getToken(FuncTestCaseParser.NullLiteral, 0)

        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_optionValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionValue" ):
                listener.enterOptionValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionValue" ):
                listener.exitOptionValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionValue" ):
                return visitor.visitOptionValue(self)
            else:
                return visitor.visitChildren(self)




    def optionValue(self):

        localctx = FuncTestCaseParser.OptionValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 148, self.RULE_optionValue)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 681
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 70369033551872) != 0) or _la==124):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncOptionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def funcOption(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FuncTestCaseParser.FuncOptionContext)
            else:
                return self.getTypedRuleContext(FuncTestCaseParser.FuncOptionContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(FuncTestCaseParser.Comma)
            else:
                return self.getToken(FuncTestCaseParser.Comma, i)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_funcOptions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncOptions" ):
                listener.enterFuncOptions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncOptions" ):
                listener.exitFuncOptions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncOptions" ):
                return visitor.visitFuncOptions(self)
            else:
                return visitor.visitChildren(self)




    def funcOptions(self):

        localctx = FuncTestCaseParser.FuncOptionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 150, self.RULE_funcOptions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 683
            self.funcOption()
            self.state = 688
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==114:
                self.state = 684
                self.match(FuncTestCaseParser.Comma)
                self.state = 685
                self.funcOption()
                self.state = 690
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NonReservedContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def And(self):
            return self.getToken(FuncTestCaseParser.And, 0)

        def Or(self):
            return self.getToken(FuncTestCaseParser.Or, 0)

        def Truncate(self):
            return self.getToken(FuncTestCaseParser.Truncate, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_nonReserved

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNonReserved" ):
                listener.enterNonReserved(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNonReserved" ):
                listener.exitNonReserved(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNonReserved" ):
                return visitor.visitNonReserved(self)
            else:
                return visitor.visitChildren(self)




    def nonReserved(self):

        localctx = FuncTestCaseParser.NonReservedContext(self, self._ctx, self.state)
        self.enterRule(localctx, 152, self.RULE_nonReserved)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 691
            _la = self._input.LA(1)
            if not(_la==24 or _la==119 or _la==120):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def nonReserved(self):
            return self.getTypedRuleContext(FuncTestCaseParser.NonReservedContext,0)


        def Identifier(self):
            return self.getToken(FuncTestCaseParser.Identifier, 0)

        def getRuleIndex(self):
            return FuncTestCaseParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier" ):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def identifier(self):

        localctx = FuncTestCaseParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 154, self.RULE_identifier)
        try:
            self.state = 695
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [24, 119, 120]:
                self.enterOuterAlt(localctx, 1)
                self.state = 693
                self.nonReserved()
                pass
            elif token in [124]:
                self.enterOuterAlt(localctx, 2)
                self.state = 694
                self.match(FuncTestCaseParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





