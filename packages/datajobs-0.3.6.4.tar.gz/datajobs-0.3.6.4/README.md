# datajobs

A Python ETL framework with Business Rule Validator for Databricks and PostgreSQL.

## 🚀 Features

- SQL Template and Snippet Injection
- Dynamic Rule Processing
- Config-driven ETL Execution
- PostgreSQL & Databricks support

## Create new build
- update version in setup.py
- in terminal 
python -m build
python -m twine upload -u __token__ -p "token ID" dist/*

## 📦 Installation

```bash
pip install datajobs


