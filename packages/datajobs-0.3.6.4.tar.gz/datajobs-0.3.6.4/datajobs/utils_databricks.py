import logging
import os
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def is_databricks():
    return "DATABRICKS_RUNTIME_VERSION" in os.environ


def split_queries(query: str):
    """Safe SQL splitter"""
    return [q.strip() for q in query.strip().split(";") if q.strip()]


def execute_run_databricks(query, retrieve_result=False, load_data=False):
    try:
        server_hostname = os.getenv("DATABRICKS_SERVER_HOSTNAME")
        http_path = os.getenv("DATABRICKS_HTTP_PATH")
        access_token = os.getenv("DATABRICKS_ACCESS_TOKEN")
        compute_mode = os.getenv("DATAJOBS_COMPUTE_MODE", "auto").lower()
        # auto = spark inside Databricks, warehouse outside

        has_external_creds = server_hostname and http_path and access_token

        # ✅ CASE 1: SQL Warehouse via HTTP path
        # - Always used outside Databricks (if creds present)
        # - Used inside Databricks only if DATAJOBS_COMPUTE_MODE=warehouse
        use_warehouse = has_external_creds and (
            not is_databricks() or compute_mode == "warehouse"
        )

        if use_warehouse:
            from databricks import sql as databricks_sql
            logger.info("Using SQL Warehouse (HTTP path)")
            conn = databricks_sql.connect(
                server_hostname=server_hostname,
                http_path=http_path,
                access_token=access_token
            )
            cursor = conn.cursor()
            if retrieve_result:
                cursor.execute(query)
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                result = [columns] + [list(row) for row in rows]
                logger.info(f"Rows fetched: {len(rows)}")
                cursor.close()
                conn.close()
                return result if rows else []
            elif load_data:
                return conn
            else:
                for q in split_queries(query):
                    try:
                        cursor.execute(q)
                    except Exception as e:
                        logger.error(f"Error executing query: {q}")
                        logger.exception(e)
                        cursor.close()
                        conn.close()
                        raise Exception(f"Databricks SQL failed: {str(e)}")
                cursor.close()
                conn.close()
                return None

        # ✅ CASE 2: Active Spark session (cluster or serverless compute)
        elif is_databricks():
            logger.info("Using active Spark session (cluster/serverless compute)")
            spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
            if retrieve_result:
                df = spark.sql(query)
                if df is None or len(df.columns) == 0:
                    logger.warning("Empty DataFrame returned")
                    return []
                rows = df.collect()
                result = [df.columns] + [list(row) for row in rows]
                logger.info(f"Rows fetched: {len(rows)}")
                return result if rows else []
            else:
                for q in split_queries(query):
                    try:
                        spark.sql(q)
                    except Exception as e:
                        logger.error(f"Error executing query: {q}")
                        logger.exception(e)
                        raise Exception(f"Databricks Spark SQL failed: {str(e)}")
                return None

        else:
            raise ValueError(
                "Databricks connection details not found and not running inside Databricks."
            )

    except Exception as e:
        logger.error("Error occurred while executing query on Databricks")
        logger.exception(e)
        raise