"""
OpenTelemetry bootstrap for the PUVINoise SDK (telemetry-only by default).

Sends telemetry to the platform. When PUVINOISE_BASE_URL, PUVINOISE_API_KEY,
and PUVINOISE_AGENT_ID are set, the SDK auto-starts GET /api/agent-control polling (Fix & Upgrade /
deploy commands) unless PUVINOISE_CONTROL_AUTO_START=0.

If bootstrap() is never called, importing the package (or this module) still starts the control
worker when the same env is present (fail-safe); see ensure_control_worker_started().

Set PUVINOISE_SDK_TELEMETRY_ONLY=0 for legacy behavior (default span persist dir + optional automation).
"""

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider, SpanLimits
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
import atexit
import logging
import os
import threading
import time
from datetime import datetime, timezone

from puvinoise.env_keys import (
    env_var,
    get_api_key,
    get_agent_id,
    get_agent_name,
    get_deploy_env,
    get_platform_url,
    get_tenant_id,
    get_trace_endpoint,
    normalize_environment_aliases,
)
from puvinoise.reliable_export import ReliableSpanExporter
from puvinoise.runtime_metadata import collect_runtime_metadata, get_runtime_metadata
from puvinoise.sdk_mode import sdk_telemetry_only

logger = logging.getLogger(__name__)


def build_resource_attributes():
    """
    Core OTEL resource attributes from env (Step 7 — version tags on every span).
    Prefer setting PUVINOISE_AGENT_VERSION, PUVINOISE_DEPLOY_LABEL, PUVINOISE_TENANTID from the platform.
    """
    try:
        from puvinoise import __version__ as _pv
        _sdk_fallback = str(_pv)
    except Exception:
        _sdk_fallback = "0.0.0"
    normalize_environment_aliases()
    _sdk_env = (env_var("PUVINOISE_SDK_VERSION") or "").strip()
    tid = (get_tenant_id() or "").strip()
    if tid.lower() == "your-tenant-id":
        tid = ""
    return {
        "service.name": env_var("PUVINOISE_AGENT_NAME") or "unknown-agent",
        "agent.id": env_var("PUVINOISE_AGENT_ID") or "",  # empty string until bootstrap() validates
        "agent.version": (env_var("PUVINOISE_AGENT_VERSION") or "0.1.0").strip() or "0.1.0",
        "deploy.label": (env_var("PUVINOISE_DEPLOY_LABEL") or "current").strip()[:64] or "current",
        "sdk.version": _sdk_env or _sdk_fallback,
        "tenant.id": tid,
        "deploy.env": (env_var("PUVINOISE_DEPLOY_ENV") or "development").strip() or "development",
    }


def build_resource():
    """OTEL Resource using :func:`build_resource_attributes` (Step 7)."""
    return Resource.create(build_resource_attributes())


_initialized = False
_provider = None
_reliable_exporter = None  # for flush_persisted at exit
_control_worker = None  # AgentControlWorker when control is enabled
_config_poller = None  # GET /api/agent/config poller when pull-based config is enabled
_runtime_beacon_thread = None
_runtime_beacon_stop = None

# True after bootstrap() is entered (telemetry init path); fail-safe control worker skips if set.
_BOOTSTRAP_CALLED = False
# True when ensure_control_worker_started() started the worker (bootstrap was never invoked).
_control_worker_bootstrapped_via_failsafe = False

def _validate_control_plane_config(control_api_url: str, agent_id: str) -> None:
    """
    Log misconfiguration: OTLP ports in control URL, or human-readable name used instead of platform agent id.
    """
    u = (control_api_url or "").strip().lower()
    if ":4318" in u:
        logger.error(
            "Invalid control API URL: use the platform HTTP origin (PUVINOISE_BASE_URL), not a collector port",
        )
    aid = (agent_id or "").strip()
    if not aid:
        return
    if aid.startswith("agt_"):
        return
    if len(aid) == 24 and all(c in "0123456789abcdefABCDEF" for c in aid):
        return
    logger.warning("Agent ID should be PUVINOISE_AGENT_ID (stable agt_*), not display name")


def _normalize_http_api_base(url: str) -> str:
    """Strip trailing slash and optional /api — control paths are /api/agent-control/... under origin."""
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def _derive_control_api_base_url() -> str:
    """
    Base URL for GET /api/agent-control (HTTP API only).

    Never derive from the trace export URL — that mixes telemetry and control planes.
    Uses ``PUVINOISE_BASE_URL`` only.
    """
    normalize_environment_aliases()
    base = (get_platform_url() or "").strip()
    if base:
        return _normalize_http_api_base(base)
    return ""


def _control_auto_start_enabled() -> bool:
    """Legacy: explicit PUVINOISE_CONTROL_AUTO_START=1 with non-telemetry-only SDK."""
    v = os.environ.get("PUVINOISE_CONTROL_AUTO_START", "0").strip().lower()
    return v in ("1", "true", "yes")


def control_worker_auto_started() -> bool:
    """True if the control worker was started via ensure_control_worker_started() (fail-safe), not bootstrap()."""
    return _control_worker_bootstrapped_via_failsafe


def ensure_control_worker_started() -> None:
    """
    Fail-safe: ensure AgentControlWorker is running even if bootstrap() was not called.

    When PUVINOISE_BASE_URL, PUVINOISE_AGENT_ID, and PUVINOISE_API_KEY are set, starts polling GET /api/agent-control.
    Respects opt-out PUVINOISE_CONTROL_AUTO_START=0|false|no (same as OOB bootstrap).
    No-op if bootstrap() already ran (it owns control worker startup) or a worker is already running.
    Skipped when SDK control loop (control_loop.py) is enabled.
    """
    global _control_worker_bootstrapped_via_failsafe

    if _BOOTSTRAP_CALLED:
        return

    try:
        from puvinoise.control_loop import sdk_control_loop_enabled

        if sdk_control_loop_enabled():
            return
    except Exception:
        pass

    if not _env_oob_auto_start_control():
        return

    platform_url = (get_platform_url() or "").strip()
    agent_id = get_agent_id()
    api_key = get_api_key()

    if not platform_url or not agent_id or not api_key:
        return

    if getattr(ensure_control_worker_started, "_started", False):
        return

    if _control_worker is not None:
        try:
            th = getattr(_control_worker, "_thread", None)
            if th is not None and th.is_alive():
                return
        except Exception:
            pass

    try:
        logger.warning(
            "bootstrap() not called — auto-starting control worker (fail-safe mode)",
        )
        start_agent_control_worker(
            agent_id=agent_id,
            control_api_url=platform_url,
            api_key=api_key,
        )
        if _control_worker is not None:
            ensure_control_worker_started._started = True
            _control_worker_bootstrapped_via_failsafe = True
    except Exception as e:
        logger.warning("Failed to auto-start control worker (fail-safe): %s", e)


def _env_oob_auto_start_control() -> bool:
    """
    Out-of-the-box control polling when platform URL + API key + agent id are set (no manual start).
    Opt-out: PUVINOISE_CONTROL_AUTO_START=0|false|no
    Requires: PUVINOISE_BASE_URL, PUVINOISE_API_KEY, PUVINOISE_AGENT_ID.
    """
    explicit = os.environ.get("PUVINOISE_CONTROL_AUTO_START", "").strip().lower()
    if explicit in ("0", "false", "no"):
        return False
    if not (get_platform_url() or "").strip():
        return False
    key = get_api_key()
    if not key:
        return False
    aid = get_agent_id()
    return bool(aid)


def _resolve_span_persist_dir():
    """
    None = no span files on disk (default when PUVINOISE_SDK_TELEMETRY_ONLY is on).
    Explicit PUVINOISE_SPAN_PERSIST_DIR always enables persistence for that path.
    """
    explicit = (os.environ.get("PUVINOISE_SPAN_PERSIST_DIR") or "").strip()
    if explicit:
        return explicit
    if sdk_telemetry_only():
        return None
    return os.path.join(os.path.expanduser("~"), ".puvinoise", "span_queue")


def _agent_config_poll_enabled() -> bool:
    v = os.environ.get("PUVINOISE_AGENT_CONFIG_POLL", "0").strip().lower()
    return v in ("1", "true", "yes")


def _auto_instrument_enabled() -> bool:
    v = os.environ.get("PUVINOISE_AUTO_INSTRUMENT", "1").strip().lower()
    return v in ("1", "true", "yes", "on")


def _ensure_local_bootstrap_paths() -> None:
    """
    Ensure runtime apply has concrete local targets for persisted bootstrap updates.
    This is critical for remote-managed agents: pulled env/wrapper config must be
    written on disk so config changes survive process restarts.
    """
    workdir = (os.environ.get("PUVINOISE_AGENT_WORKDIR") or "").strip() or os.getcwd()
    try:
        workdir = os.path.abspath(workdir)
    except Exception:
        workdir = os.getcwd()

    # Persisted env + pid file for remote control (optional explicit paths).
    # Prefer the branded `.env.puvinoise`; fall back to legacy `.env` only if
    # the branded file doesn't exist and the legacy one does. Callers that
    # explicitly set PUVINOISE_ENV_FILE keep full control.
    if "PUVINOISE_ENV_FILE" not in os.environ:
        branded = os.path.join(workdir, ".env.puvinoise")
        legacy = os.path.join(workdir, ".env")
        if os.path.isfile(branded):
            os.environ["PUVINOISE_ENV_FILE"] = branded
        elif os.path.isfile(legacy):
            os.environ["PUVINOISE_ENV_FILE"] = legacy
        else:
            os.environ["PUVINOISE_ENV_FILE"] = branded  # canonical target for future writes
    os.environ.setdefault("PUVINOISE_AGENT_PID_FILE", os.path.join(workdir, ".puvinoise_agent.pid"))


def _runtime_beacon_enabled() -> bool:
    """
    SDK/runtime operational beacon:
    emits periodic runtime telemetry from SDK layer.
    Default is OFF to avoid synthetic traces when the customer agent is idle.
    Set PUVINOISE_SDK_RUNTIME_BEACON=1 to opt in.
    """
    v = os.environ.get("PUVINOISE_SDK_RUNTIME_BEACON", "0").strip().lower()
    return v in ("1", "true", "yes", "on")


def _start_runtime_beacon(service_name: str, agent_id: str, sdk_version: str) -> None:
    global _runtime_beacon_thread, _runtime_beacon_stop
    if not _runtime_beacon_enabled():
        return
    if _runtime_beacon_thread is not None and _runtime_beacon_thread.is_alive():
        return

    stop = threading.Event()
    _runtime_beacon_stop = stop
    interval = max(15.0, float(os.environ.get("PUVINOISE_SDK_RUNTIME_BEACON_INTERVAL_SEC", "20") or "20"))
    beacon_tracer = trace.get_tracer("puvinoise.sdk.runtime")

    def _runner():
        while not stop.is_set():
            try:
                with beacon_tracer.start_as_current_span("sdk.runtime.beacon") as span:
                    if service_name:
                        span.set_attribute("agent.name", service_name)
                    if agent_id:
                        span.set_attribute("agent.id", agent_id)
                    tenant_id = (get_tenant_id() or "").strip()
                    if tenant_id:
                        # Required by backend tenant filters (Jaeger fallback + analytics queries).
                        span.set_attribute("tenant.id", tenant_id)
                    span.set_attribute("puvinoise.sdk.version", str(sdk_version or ""))
                    span.set_attribute("puvinoise.runtime.beacon", True)
                    span.set_attribute("puvinoise.control.worker.running", bool(_control_worker is not None))
                    span.set_attribute("puvinoise.config.poller.running", bool(_config_poller is not None))
                try:
                    from puvinoise.decision_telemetry import (
                        flush_decision_events,
                        record_agent_state_transition,
                    )

                    record_agent_state_transition("running", "running", "sdk_runtime_beacon")
                    flush_decision_events(timeout_seconds=1.0)
                except Exception:
                    pass
            except Exception:
                # Never break customer runtime because of SDK beacon.
                pass
            stop.wait(interval)

    _runtime_beacon_thread = threading.Thread(
        target=_runner,
        daemon=True,
        name="puvinoise-runtime-beacon",
    )
    _runtime_beacon_thread.start()


def _emit_agent_startup_span(agent_id: str, tenant_id: str, restart_cause: str) -> None:
    try:
        startup_tracer = trace.get_tracer("puvinoise.sdk.startup")
        with startup_tracer.start_as_current_span("agent.startup") as span:
            span.set_attribute("agent.id", str(agent_id or "").strip())
            span.set_attribute("agent.version", os.getenv("AGENT_VERSION", "unknown"))
            span.set_attribute("agent.pid", int(os.getpid()))
            span.set_attribute("agent.startup_time", datetime.now(timezone.utc).isoformat())
            span.set_attribute("agent.restart_cause", str(restart_cause or "cold_start"))
            if tenant_id:
                span.set_attribute("puvi.tenant_id", tenant_id)
                # Keep tenant.id for existing backend filtering.
                span.set_attribute("tenant.id", tenant_id)
    except Exception as exc:
        logger.debug("agent startup span emit failed: %s", exc)


def _resolve_span_limits():
    """
    Raise OTEL attribute limits so custom tags like scenario metadata are not dropped.
    Defaults are intentionally conservative and can truncate/drop attributes under heavy tagging.
    """
    count_limit = int(
        os.getenv("PUVINOISE_SPAN_ATTRIBUTE_COUNT_LIMIT")
        or os.getenv("OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT")
        or "512"
    )
    value_len_limit = int(
        os.getenv("PUVINOISE_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT")
        or os.getenv("OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT")
        or "2048"
    )
    return SpanLimits(
        max_span_attributes=max(128, count_limit),
        max_attribute_length=max(256, value_len_limit),
    )


def _create_otlp_exporter(
    endpoint: str,
    headers: dict | None,
    compression: bool,
    timeout: int = 30,
    sdk_version: str = "0.0.0",
):
    # Ensure headers is a dict and always advertise SDK version
    hdrs: dict = dict(headers or {})
    hdrs["X-Sdk-Version"] = str(sdk_version)
    kwargs = {"endpoint": endpoint, "timeout": timeout, "headers": hdrs}
    if compression:
        try:
            from opentelemetry.exporter.otlp.proto.http import Compression
            kwargs["compression"] = Compression.Gzip
        except ImportError:
            pass
    return OTLPSpanExporter(**kwargs)


def init(
    api_key: str = None,
    agent_name: str = None,
    endpoint: str = None,
    tenant_id: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
):
    """
    One-line init for minimal integration. Sets env from config and calls bootstrap.

    Example::
        puvinoise.init(api_key="…", agent_name="research-agent")
        agent = puvinoise.wrapAgent(my_agent)

    agent_id is NOT accepted as a parameter. It is the single source of truth and MUST be
    set exclusively via the PUVINOISE_AGENT_ID environment variable, injected by `puvinoise run`
    from the agent state file (.puvinoise/agent_<id>.json). This ensures exactly one source
    of identity across the pipeline.

    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        When set, starts the agent control worker in the background after telemetry init.
    """
    normalize_environment_aliases()
    if api_key:
        os.environ["PUVINOISE_API_KEY"] = str(api_key).strip()
    if agent_name:
        os.environ["PUVINOISE_AGENT_NAME"] = str(agent_name).strip()
    if endpoint:
        ep = str(endpoint).rstrip("/")
        if ep.endswith("/v1/traces"):
            base = ep[: -len("/v1/traces")].rstrip("/")
            if base:
                os.environ["PUVINOISE_BASE_URL"] = base

    # Resolve tenant_id: explicit param → state file fallback → already-set env var.
    # This ensures PUVINOISE_TENANTID is always populated before bootstrap() reads it,
    # even when init() is called without an explicit tenant_id (e.g. after the PRELOAD_SNIPPET
    # path or direct SDK usage without the CLI wrapper).
    _resolved_tenant_id = (str(tenant_id).strip() if tenant_id else "")
    if not _resolved_tenant_id:
        try:
            from puvinoise.agent_autoregister import resolve_tenant_id as _resolve_tid
            _resolved_tenant_id = _resolve_tid()
        except Exception:
            pass
    if not _resolved_tenant_id:
        # Last resort: honour whatever is already in env (e.g. set by puvinoise-bind legacy path).
        _resolved_tenant_id = os.environ.get("PUVINOISE_TENANTID", "").strip()
    if _resolved_tenant_id:
        os.environ["PUVINOISE_TENANTID"] = _resolved_tenant_id
    elif os.environ.get("PUVINOISE_API_KEY", "").strip():
        # api_key is present but tenant_id cannot be resolved — behaviour pipeline is degraded.
        logger.warning(
            "init(): tenant_id not resolved from state files or env — "
            "behaviour pipeline attribution will be disabled. "
            "Ensure POST /api/agent-register returns agent.tenantId."
        )

    # ── Debug: confirm resolved identity before any further init ─────────────
    # Emitted at INFO so it appears in default logging without requiring DEBUG.
    _dbg_aid = os.environ.get("PUVINOISE_AGENT_ID", "").strip()
    _dbg_eid = os.environ.get("PUVINOISE_ENV_ID", "").strip()
    _dbg_key = os.environ.get("PUVINOISE_API_KEY", "").strip()
    _dbg_masked_key = (
        ("***" + _dbg_key[-4:]) if len(_dbg_key) > 4 else ("****" if _dbg_key else "<missing>")
    )
    _dbg_behaviour_ok = bool(_resolved_tenant_id and _dbg_aid and _dbg_eid)
    logger.info(
        "[puvinoise] init() identity loaded — "
        "agent_id=%s  tenant_id=%s  env_id=%s  api_key=%s  behaviour_pipeline=%s",
        _dbg_aid or "<missing>",
        _resolved_tenant_id or "<missing>",
        _dbg_eid or "<missing>",
        _dbg_masked_key,
        "ENABLED" if _dbg_behaviour_ok else "DISABLED",
    )

    # ── Mandatory state file validation (Contract v1.0, §4) ──────────────────
    # Run before bootstrap() so an invalid state is caught before any telemetry
    # is configured.  Both checks raise RuntimeError on contract violation.
    # Files that don't exist yet are skipped (first-run / direct-SDK paths).
    try:
        from pathlib import Path as _Path
        from puvinoise.agent_state import (
            validate_agent_state as _validate_agent,
            validate_env_state as _validate_env,
            get_agent_state_dir as _get_state_dir,
            get_env_state_path as _get_env_path,
            ENV_STATE_FILENAME as _ENV_STATE_FILENAME,
            AGENT_STATE_GLOB as _AGENT_STATE_GLOB,
        )
        _cwd = _Path.cwd()
        _state_dir = _get_state_dir(_cwd)
        _env_path = _get_env_path(_cwd)

        # Validate env.json if it exists.
        if _env_path.is_file():
            try:
                _validate_env(_cwd)
            except ValueError as _ve:
                raise RuntimeError(
                    f"PUVINoise init() aborted — env.json failed contract validation:\n"
                    f"  {_ve}\n"
                    "  Fix: delete .puvinoise/env.json and re-run 'puvinoise-bind --env-only'."
                ) from _ve

        # Validate agent_<id>.json if it exists.
        _has_agent_file = _state_dir.is_dir() and any(_state_dir.glob(_AGENT_STATE_GLOB))
        if _has_agent_file:
            try:
                _validate_agent(_cwd)
            except (ValueError, RuntimeError) as _ve:
                raise RuntimeError(
                    f"PUVINoise init() aborted — agent_<id>.json failed contract validation:\n"
                    f"  {_ve}\n"
                    "  Fix: delete .puvinoise/ and re-run 'puvinoise run' to re-register."
                ) from _ve
    except RuntimeError:
        raise  # re-raise contract violations as-is
    except Exception as _val_exc:
        # Validation infrastructure error — log and continue (never block SDK from starting).
        logger.warning("init(): state file validation skipped due to unexpected error: %s", _val_exc)

    # Optional: auto-load platform config (bootstrap .env) before initializing tracing.
    # Uses agentDeployVersion for PUVINOISE_DEPLOY_VERSION, never touches SDK version.
    config_url = (get_platform_url() or "").strip()
    if config_url and not os.environ.get("PUVINOISE_CONFIG_LOADED"):
        try:
            from puvinoise.config_loader import load_platform_config as _load

            _load(
                api_key=api_key or get_api_key() or "",
                agent_id=agent_name or get_agent_name() or "",
                platform_url=config_url,
                fail_silently=True,
            )
            os.environ["PUVINOISE_CONFIG_LOADED"] = "1"
        except Exception as _e:
            logger.warning("Auto config load failed (non-fatal): %s", _e)

    tracer = bootstrap(
        service_name=agent_name,
        otlp_endpoint=endpoint,
        console_export=console_export,
        batch_config=batch_config,
        compression=compression,
        control_config=control_config,
    )

    # ── Phase E: runtime-driven SDK auto-registration ─────────────────────
    # Automatically POST /api/agent-register with proof-of-SDK markers.
    # Fails gracefully (logs + returns None) when env_id is missing or the
    # backend rejects — never crashes the host agent process.
    # Opt out: PUVINOISE_AUTOREGISTER=0
    #
    # Fix 1 (double-registration guard): import the module object rather than
    # individual names so calls go through the same module globals that hold
    # _REGISTERED_IN_PROCESS and _ATEXIT_REGISTERED.  If the sitecustomize
    # path (via `puvinoise run`) already ran auto_register_from_env(), the
    # module-level flag is already True and the second call is a no-op.
    try:
        from puvinoise import agent_autoregister as _ar
        _ar.auto_register_from_env(
            agent_name=agent_name,
        )
        if os.environ.get("PUVINOISE_AUTO_HEARTBEAT", "1").strip() not in ("0", "false", "no"):
            try:
                _hb_interval = int(os.environ.get("PUVINOISE_HEARTBEAT_INTERVAL", "15"))
            except ValueError:
                _hb_interval = 15
            _ar.start_heartbeat_loop(interval_seconds=_hb_interval)
    except Exception as _auto_exc:  # noqa: BLE001
        logger.warning("auto-register setup skipped: %s", _auto_exc)

    try:
        from puvinoise.control_loop import sdk_control_loop_enabled, start_control_loop

        if sdk_control_loop_enabled():
            try:
                _ctl_interval = float(os.environ.get("PUVINOISE_CONTROL_LOOP_INTERVAL", "10"))
            except ValueError:
                _ctl_interval = 10.0
            _eid = (os.environ.get("PUVINOISE_ENV_ID") or "").strip()
            _aid = (get_agent_id() or "").strip()
            start_control_loop(
                agent_id=_aid or None,
                env_id=_eid or None,
                interval_seconds=max(2.0, _ctl_interval),
            )
    except Exception as _ctl_exc:  # noqa: BLE001
        logger.debug("SDK control loop not started (non-fatal): %s", _ctl_exc)

    return tracer


def bootstrap(
    service_name: str = None,
    otlp_endpoint: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
    restart_cause: str = "cold_start",
):
    """
    Initialize OpenTelemetry tracing for the agent, then optionally start the agent control worker.

    Tuned for high-frequency telemetry (e.g. every second per agent):
    batching every 1s, optional gzip compression, retry-capable export.

    Reads env: PUVINOISE_BASE_URL (SDK derives telemetry export from this origin), PUVINOISE_AGENT_NAME, PUVINOISE_AGENT_ID,
    PUVINOISE_TENANTID, PUVINOISE_API_KEY; optional deployment metadata:
    PUVINOISE_DEPLOY_ENV, PUVINOISE_DEPLOY_VERSION, PUVINOISE_REGION, PUVINOISE_SDK_LANGUAGE, PUVINOISE_SDK_VERSION
    (SDK auto-detects language/version if unset for backward compatibility).

    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        Starts control worker in background; failures do not crash the SDK.

    If control_config includes controlApiUrl, the control worker starts.

    Out-of-the-box: when PUVINOISE_BASE_URL, PUVINOISE_API_KEY, and PUVINOISE_AGENT_ID are set,
    the control worker auto-starts (GET /api/agent-control). Opt-out with PUVINOISE_CONTROL_AUTO_START=0.

    Legacy env-based auto-start (non-telemetry-only): PUVINOISE_CONTROL_AUTO_START=1 and derived URLs.
    """
    global _initialized, _provider, _BOOTSTRAP_CALLED

    _BOOTSTRAP_CALLED = True
    normalize_environment_aliases()
    _ensure_local_bootstrap_paths()

    env_agent_name = get_agent_name()
    name = (service_name or env_agent_name or "").strip()
    if not name:
        raise ValueError(
            "Agent name must be set via service_name argument or PUVINOISE_AGENT_NAME environment variable"
        )

    if _initialized:
        logger.info("Tracer already initialized for service: %s", name)
        return trace.get_tracer(name)

    endpoint = (otlp_endpoint or get_trace_endpoint() or "").strip()
    if not endpoint:
        raise ValueError(
            "PUVINOISE_BASE_URL must be set to your platform HTTP origin (e.g. https://app.example.com)"
        )
    if not endpoint.endswith("/v1/traces"):
        endpoint = endpoint.rstrip("/") + "/v1/traces"

    access_key = (get_api_key() or "").strip()
    headers: dict = {}
    if access_key:
        headers["Authorization"] = f"Bearer {access_key}"

    otlp_headers = {
        "X-Api-Key": access_key,
        "X-Organization-Id": (
            os.environ.get("PUVINOISE_ORGANIZATION_ID")
            or get_tenant_id()
            or ""
        ),
        "X-Project-Id": os.environ.get("PUVINOISE_PROJECT_ID", ""),
        "X-Environment": (
            os.environ.get("PUVINOISE_ENVIRONMENT")
            or get_deploy_env()
            or ""
        ),
    }
    # Merge any Authorization header into OTLP headers as well
    if access_key:
        otlp_headers.setdefault("Authorization", f"Bearer {access_key}")

    import warnings as _warnings
    if not otlp_headers["X-Organization-Id"]:
        if access_key:
            # API key already carries tenant context for trace routing — no action needed.
            # Log at debug level only so startup output stays clean.
            import logging as _logging
            _logging.getLogger(__name__).debug(
                "PUVINoise: PUVINOISE_TENANTID not set, but PUVINOISE_API_KEY is present — "
                "tenant routing is handled via the API key. Set PUVINOISE_TENANTID if you "
                "want explicit X-Organization-Id headers on OTLP spans."
            )
        else:
            _warnings.warn(
                "PUVINoise: PUVINOISE_TENANTID not set — set this to your tenant ID for multi-tenant routing",
                RuntimeWarning,
            )

    try:
        from puvinoise.routing import get_version as _get_routed_version
        _v = _get_routed_version()
        if _v:
            headers["X-Agent-Version"] = _v
            _existing = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")
            if "x-agent-version" not in _existing.lower():
                os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = (
                    (_existing + "," if _existing else "") + f"x-agent-version={_v}"
                )
    except Exception:
        pass

    # Real tenant ID from env (matches backend tenantId). Reject placeholder.
    tenant_id = (
        get_tenant_id()
        or ""
    ).strip()
    if tenant_id.lower() == "your-tenant-id":
        tenant_id = ""

    try:
        from puvinoise import __version__ as _sdk_version
        sdk_version = str(_sdk_version)
    except Exception:
        sdk_version = "0.0.0"
    puvi_agent_id = (get_agent_id() or "").strip()
    # STRICT ENFORCEMENT: PUVINOISE_AGENT_ID is required.
    # The normalizer DROPS every trace whose agent.run span lacks the agent.id tag.
    # Fail here at bootstrap so the error is caught at process startup, not silently at ingest time.
    if not puvi_agent_id:
        raise ValueError(
            "PUVINOISE_AGENT_ID is not set. "
            "Register your agent on the PUVINoise platform to get an agt_xxx ID. "
            "When using `puvinoise run`, the runtime injects PUVINOISE_AGENT_ID automatically "
            "from .puvinoise/agent_<id>.json — run 'puvinoise-bind' first if this file is missing. "
            "Without this, every trace will be DROPPED by the normalizer with REJECT.missing_agent_id."
        )
    collect_runtime_metadata(agent_id=puvi_agent_id, agent_name=name)
    runtime_meta = get_runtime_metadata()
    _agent_ver = (
        env_var("PUVINOISE_AGENT_VERSION").strip()
        or (runtime_meta.get("deploy_version") or "").strip()
        or env_var("PUVINOISE_DEPLOY_VERSION").strip()
        or "0.1.0"
    )
    _deploy_label = (env_var("PUVINOISE_DEPLOY_LABEL") or "current").strip()[:64]
    resource_attrs = build_resource_attributes()
    resource_attrs["service.name"] = name
    resource_attrs["agent.version"] = _agent_ver
    resource_attrs["deploy.label"] = _deploy_label
    if tenant_id:
        resource_attrs["tenant.id"] = tenant_id
    resource_attrs["service.version"] = sdk_version
    resource_attrs["deployment.environment"] = runtime_meta.get("deploy_env") or os.getenv(
        "DEPLOYMENT_ENV", "production"
    )
    resource_attrs["puvinoise.sdk.version"] = sdk_version
    resource_attrs["puvinoise.telemetry.schema"] = "v2"
    resource_attrs["agent.name"] = name
    resource_attrs["deployment.label"] = _deploy_label
    resource_attrs["puvinoise.sdk_language"] = runtime_meta.get("sdk_language", "")
    resource_attrs["puvinoise.deploy_version"] = runtime_meta.get("deploy_version", "")
    resource_attrs["puvinoise.runtime"] = runtime_meta.get("runtime", "")
    resource_attrs["puvinoise.host"] = runtime_meta.get("host", "")
    resource_attrs["puvinoise.region"] = runtime_meta.get("region", "")
    resource_attrs["puvinoise.instance_id"] = runtime_meta.get("instance_id", "")
    # puvi_agent_id is validated non-empty above — always stamp agent.id unconditionally.
    resource_attrs["agent.id"] = puvi_agent_id
    resource_attrs["puvinoise.agent_id"] = puvi_agent_id
    _sdk_env = env_var("PUVINOISE_SDK_VERSION").strip()
    if _sdk_env:
        resource_attrs["sdk.version"] = _sdk_env
    elif sdk_version:
        resource_attrs["sdk.version"] = sdk_version
    resource = Resource.create(resource_attrs)

    provider = TracerProvider(resource=resource, span_limits=_resolve_span_limits())
    trace.set_tracer_provider(provider)

    default_batch_config = {
        "schedule_delay_millis": 1000,
        "max_export_batch_size": 128,
        "export_timeout_millis": 30000,
        "max_queue_size": 4096,
    }

    if batch_config:
        default_batch_config.update(batch_config)

    try:
        otlp_exporter = _create_otlp_exporter(
            endpoint=endpoint,
          headers=otlp_headers,
            compression=compression,
            timeout=default_batch_config.get("export_timeout_millis", 30000) // 1000,
            sdk_version=sdk_version,
        )
        persist_dir = _resolve_span_persist_dir()
        reliable_exporter = ReliableSpanExporter(
            otlp_exporter,
            persist_dir=persist_dir,
        )
        global _reliable_exporter
        _reliable_exporter = reliable_exporter
        provider.add_span_processor(
            BatchSpanProcessor(reliable_exporter, **default_batch_config)
        )
        # Replay any spans persisted from previous runs (e.g. API was down)
        replayed = reliable_exporter.flush_persisted()
        if replayed:
            logger.info("Replayed %s persisted spans from previous run", replayed)
        logger.info("Telemetry exporter configured (reliable): %s", endpoint)
    except Exception as e:
        logger.error("Failed to configure telemetry exporter: %s", e)
        console_export = True

    if console_export:
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(
            BatchSpanProcessor(console_exporter, **default_batch_config)
        )
        logger.info("Console exporter configured for debugging")

    _initialized = True
    _provider = provider

    atexit.register(_atexit_flush)

    # Optional: reliable buffer for decision events (HTTP ingest with persistence)
    try:
        from puvinoise.telemetry_buffer import init_decision_buffer_from_env
        if init_decision_buffer_from_env() is not None:
            logger.info("Decision telemetry buffer enabled (ingest URL); events will be persisted if API is unavailable")
    except Exception as e:
        logger.debug("Decision buffer not configured: %s", e)

    logger.info("OpenTelemetry initialized for service: %s", name)

    if _auto_instrument_enabled():
        try:
            from puvinoise.hooks import enable_auto_instrumentation
            out = enable_auto_instrumentation()
            patched = out.get("patched") if isinstance(out, dict) else None
            if isinstance(patched, list) and patched:
                logger.info("Auto-instrumented provider SDK hooks: %s", ", ".join(str(p) for p in patched))
        except Exception as e:
            logger.debug("Auto instrumentation skipped: %s", e)

    # ── Framework auto-detection + instrumentation ───────────────────────
    # Runtime-based, framework-agnostic behavior intelligence.
    # 1. Detect which agent frameworks (LangChain, LangGraph, CrewAI, etc.)
    #    are present using importlib.util.find_spec() — no import side-effects.
    # 2. Apply dynamic monkey-patches for detected frameworks.
    # 3. Always enable the behavior-based fallback tracer (LLM→tool→LLM
    #    pattern detection) so unknown frameworks are still captured.
    # 4. Fold framework metadata into the registration payload via env vars.
    _fw_detection = None
    try:
        from puvinoise.framework_detection import detect_all, sync_framework_env_from_runtime

        _fw_detection = detect_all()
        sync_framework_env_from_runtime()

        _fw_meta = {
            "framework": env_var("PUVINOISE_FRAMEWORK"),
            "detection_mode": env_var("PUVINOISE_DETECTION_MODE"),
        }
        found = [d["label"] for d in _fw_detection.get("details", []) if d.get("present")]
        if found:
            logger.info(
                "Framework detection: installed=%s (runtime primary=%s, mode=%s)",
                found,
                _fw_meta.get("framework"),
                _fw_meta.get("detection_mode"),
            )
        else:
            logger.info(
                "Framework detection: no known frameworks installed — runtime primary=%s, detection_mode=%s",
                _fw_meta.get("framework"),
                _fw_meta.get("detection_mode"),
            )
    except Exception as _fw_exc:  # noqa: BLE001
        logger.debug("Framework detection skipped: %s", _fw_exc)

    try:
        from puvinoise.framework_detection import sync_framework_env_from_runtime
        from puvinoise.framework_instrumentation import apply_instrumentation

        _fw_result = apply_instrumentation(_fw_detection)
        sync_framework_env_from_runtime()
        _fw_patched = _fw_result.get("patched", [])
        if _fw_patched:
            logger.info("Framework instrumentation: patched %s", _fw_patched)
    except Exception as _fi_exc:  # noqa: BLE001
        logger.debug("Framework instrumentation skipped: %s", _fi_exc)

    control_agent_id = (control_config.get("agentId") if control_config else None) or puvi_agent_id
    if control_config and control_config.get("controlApiUrl") and control_agent_id:
        start_agent_control_worker(
            agent_id=control_agent_id,
            control_api_url=control_config["controlApiUrl"],
            polling_interval=control_config.get("pollingInterval"),
            api_key=control_config.get("apiKey"),
            lifecycle_hooks=control_config.get("lifecycleHooks"),
        )
    elif _env_oob_auto_start_control():
        # Fix & Upgrade / deployments: poll GET /api/agent-control when platform env is complete (no extra flags).
        oob_base = _normalize_http_api_base((get_platform_url() or "").strip())
        oob_agent = get_agent_id()
        if oob_base and oob_agent:
            start_agent_control_worker(
                agent_id=oob_agent,
                control_api_url=oob_base,
                polling_interval=control_config.get("pollingInterval") if control_config else None,
                api_key=control_config.get("apiKey") if control_config else None,
                lifecycle_hooks=control_config.get("lifecycleHooks") if control_config else None,
            )
    elif _control_auto_start_enabled() and not sdk_telemetry_only():
        # Legacy: derive base from several env vars; agent id may fall back to agent display name.
        auto_base = _derive_control_api_base_url()
        auto_agent = (
            (control_agent_id or "").strip()
            or get_agent_name()
        )
        if auto_base and auto_agent:
            start_agent_control_worker(
                agent_id=auto_agent,
                control_api_url=auto_base,
                polling_interval=control_config.get("pollingInterval") if control_config else None,
                api_key=control_config.get("apiKey") if control_config else None,
                lifecycle_hooks=control_config.get("lifecycleHooks") if control_config else None,
            )

    if _agent_config_poll_enabled() and not sdk_telemetry_only():
        poll_base = _derive_control_api_base_url()
        poll_agent = (control_agent_id or "").strip() or get_agent_name()
        if poll_base and poll_agent:
            start_agent_config_poller(
                agent_id=poll_agent,
                base_url=poll_base,
                api_key=(control_config.get("apiKey") if control_config else None)
                or get_api_key(),
                environment=(get_deploy_env() or "").strip() or None,
            )

    _start_runtime_beacon(name, puvi_agent_id, sdk_version)
    effective_restart_cause = (
        (restart_cause or "").strip()
        or (os.environ.get("PUVINOISE_RESTART_CAUSE", "") or "").strip()
        or "cold_start"
    )
    _emit_agent_startup_span(puvi_agent_id, tenant_id, effective_restart_cause)
    os.environ["PUVINOISE_RESTART_CAUSE"] = "cold_start"
    return trace.get_tracer(name)


def get_control_worker():
    """Return the active agent control worker, or None if control is not enabled or failed to start."""
    return _control_worker


def get_agent_config_poller():
    """Return the GET /api/agent/config poller, or None if not started."""
    return _config_poller


def start_agent_config_poller(
    agent_id: str,
    base_url: str,
    *,
    api_key: str | None = None,
    environment: str | None = None,
    interval_seconds: float | None = None,
    on_change=None,
):
    """
    Poll GET /api/agent/config for desired version (pull-based). Set PUVINOISE_AGENT_CONFIG_POLL=1 to auto-start from bootstrap.
    """
    global _config_poller
    try:
        from puvinoise.agent_config_poller import AgentConfigPoller, default_on_desired_version_change

        base = _normalize_http_api_base(base_url or "")
        if not base or not (agent_id or "").strip():
            return
        interval = float(interval_seconds) if interval_seconds is not None else float(
            os.environ.get("PUVINOISE_AGENT_CONFIG_POLL_INTERVAL", "30") or 30
        )
        interval = max(5.0, interval)
        cb = on_change if on_change is not None else default_on_desired_version_change
        _config_poller = AgentConfigPoller(
            base_url=base,
            agent_id=agent_id.strip(),
            api_key=(api_key or get_api_key() or "").strip() or None,
            environment=environment,
            interval_seconds=interval,
            on_change=cb,
        )
        _config_poller.start()
        logger.info(
            "Agent config poller started (GET /api/agent/config) agent_id=%s interval=%.1fs",
            agent_id,
            interval,
        )
    except Exception as e:
        logger.warning("Agent config poller failed to start (SDK continues): %s", e)
        _config_poller = None


def _control_poll_via_heartbeat_enabled() -> bool:
    """When True, GET /api/agent-control is driven by the autoregister heartbeat loop (no separate thread)."""
    v = os.environ.get("PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT", "").strip().lower()
    return v in ("1", "true", "yes", "on")


def start_agent_control_worker(
    agent_id: str,
    control_api_url: str,
    polling_interval: float = None,
    api_key: str = None,
    lifecycle_hooks: dict = None,
):
    """
    Start the agent control worker: background poll thread by default, or heartbeat-driven when
    PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT=1 (poll_once each autoregister heartbeat tick).
    Skipped when PUVINOISE_SDK_CONTROL_LOOP=1 (default): control_loop.py polls /api/agents/.../control-queue instead.
    Failures (import, constructor, start) are logged and do not raise.
    """
    global _control_worker
    try:
        try:
            from puvinoise.control_loop import sdk_control_loop_enabled

            if sdk_control_loop_enabled():
                logger.debug(
                    "Skipping threaded AgentControlWorker — SDK control loop (control_loop.py) is enabled",
                )
                return
        except Exception:
            pass
        if _control_worker is not None:
            try:
                th = getattr(_control_worker, "_thread", None)
                if th is not None and th.is_alive():
                    logger.debug(
                        "Agent control worker already running; skipping duplicate start",
                    )
                    return
                hb = getattr(_control_worker, "_poll_via_heartbeat", False)
                stop_ev = getattr(_control_worker, "_stop", None)
                if hb and stop_ev is not None and not stop_ev.is_set():
                    logger.debug(
                        "Agent control worker already registered (heartbeat-driven); skipping duplicate start",
                    )
                    return
            except Exception:
                pass
        from puvinoise.agent_runtime import AgentControlWorker, DEFAULT_POLL_INTERVAL_SEC
        base_url = _normalize_http_api_base(control_api_url or "")
        if not base_url or not (agent_id or "").strip():
            return
        _validate_control_plane_config(base_url, agent_id)
        interval = float(polling_interval) if polling_interval is not None else DEFAULT_POLL_INTERVAL_SEC
        interval = max(0.5, interval)
        poll_via_hb = _control_poll_via_heartbeat_enabled()
        if poll_via_hb:
            hb_off = os.environ.get("PUVINOISE_AUTO_HEARTBEAT", "1").strip().lower() in (
                "0",
                "false",
                "no",
            )
            if hb_off:
                logger.warning(
                    "PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT=1 but PUVINOISE_AUTO_HEARTBEAT is off — "
                    "control commands will not be polled until heartbeat runs or you start a thread worker",
                )
        _control_worker = AgentControlWorker(
            agent_id=agent_id.strip(),
            base_url=base_url,
            poll_interval_seconds=interval,
            api_key=(api_key or get_api_key() or "").strip() or None,
            lifecycle_hooks=lifecycle_hooks,
        )
        _control_worker.start(poll_via_heartbeat=poll_via_hb)
        logger.debug(
            "Agent control worker agent_id=%s control_api_url=%s polling_interval=%.1fs via_heartbeat=%s",
            agent_id,
            base_url,
            interval,
            poll_via_hb,
        )
    except Exception as e:
        logger.warning("Agent control worker failed to start (SDK continues): %s", e)
        _control_worker = None


def _atexit_flush():
    """Auto-flush on interpreter exit; replay persisted spans and decision buffer so telemetry is never lost."""
    try:
        if _provider is not None:
            _provider.force_flush(timeout_millis=5000)
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
        try:
            from puvinoise.telemetry_buffer import get_decision_buffer
            buf = get_decision_buffer()
            if buf is not None:
                buf.flush(timeout_sec=5.0)
        except Exception:
            pass
    except Exception:
        pass


def shutdown():
    """
    Gracefully shutdown the tracer provider and stop the agent control worker.
    Call this when your application is terminating to ensure all spans are exported.
    Replays any persisted span batches before shutdown.
    """
    global _provider, _reliable_exporter, _control_worker, _config_poller, _runtime_beacon_thread, _runtime_beacon_stop
    if _runtime_beacon_stop is not None:
        try:
            _runtime_beacon_stop.set()
        except Exception:
            pass
    _runtime_beacon_stop = None
    _runtime_beacon_thread = None
    if _config_poller is not None:
        try:
            _config_poller.stop()
            logger.debug("Agent config poller stopped")
        except Exception as e:
            logger.debug("Error stopping config poller: %s", e)
        _config_poller = None
    try:
        from puvinoise.control_loop import stop_control_loop

        stop_control_loop()
    except Exception:
        pass
    if _control_worker is not None:
        try:
            _control_worker.stop()
            logger.debug("Agent control worker stopped")
        except Exception as e:
            logger.debug("Error stopping control worker: %s", e)
        _control_worker = None
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
            _reliable_exporter.shutdown()
        provider.shutdown()
        logger.info("OpenTelemetry tracer provider shut down successfully")
    _provider = None
    _reliable_exporter = None


def force_flush(timeout_millis: int = 30000):
    """
    Force flush all pending spans.

    Args:
        timeout_millis: Maximum time to wait for flush in milliseconds
    """
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        success = provider.force_flush(timeout_millis)
        if success:
            logger.info("Successfully flushed all pending spans")
        else:
            logger.warning("Flush timed out or failed")
        return success
    return False


def is_initialized() -> bool:
    """Check if the tracer has been initialized."""
    return _initialized


# Fail-safe when this module is imported without loading package __init__ (e.g. from puvinoise.bootstrap import bootstrap).
try:
    ensure_control_worker_started()
except Exception:
    pass
