"""
Canonical PUVINoise runtime environment (PUVINOISE_* only).

Core connection (document these in .env):
  * ``PUVINOISE_BASE_URL`` — HTTP origin for the control plane (registration, config, control APIs).
  * ``PUVINOISE_API_KEY`` — Agent API key (same credential the platform issues for the agent).
  * ``PUVINOISE_AGENT_NAME`` — Logical agent name.
  * ``PUVINOISE_AGENT_ID`` — Stable agent id (e.g. agt_*) assigned at registration.

Trace export URL resolution (first match wins):

1. ``OTEL_EXPORTER_OTLP_TRACES_ENDPOINT`` — full OTLP HTTP traces URL (…/v1/traces).
2. ``OTEL_EXPORTER_OTLP_ENDPOINT`` — OTLP base; ``/v1/traces`` is appended if missing.
3. ``PUVINOISE_BASE_URL`` + ``/v1/traces`` (recommended for most agents).

Optional debug / TestAgent helpers (all ``PUVINOISE_*``):

  * ``PUVINOISE_DEBUG`` — verbose scenario logging in TestAgent shared helpers.
  * ``PUVINOISE_COST_PER_1M_INPUT_USD`` / ``PUVINOISE_COST_PER_1M_OUTPUT_USD`` — override token pricing for cost estimates.

Legacy names ``PUVI_DEBUG`` and ``PUVI_COST_*`` are copied into the ``PUVINOISE_*`` keys once at
process startup (see :func:`normalize_environment_aliases`).
"""

from __future__ import annotations

import os

_normalized = False

# Deprecated — migrated into PUVINOISE_* by normalize_environment_aliases()
_LEGACY_ENV_ALIASES = (
    ("PUVI_DEBUG", "PUVINOISE_DEBUG"),
    ("PUVI_COST_PER_1M_INPUT_USD", "PUVINOISE_COST_PER_1M_INPUT_USD"),
    ("PUVI_COST_PER_1M_OUTPUT_USD", "PUVINOISE_COST_PER_1M_OUTPUT_USD"),
)


def normalize_environment_aliases() -> None:
    """Copy legacy ``PUVI_*`` keys into canonical ``PUVINOISE_*`` when the new key is unset."""
    global _normalized
    if _normalized:
        return
    for old, new in _LEGACY_ENV_ALIASES:
        ov = (os.environ.get(old) or "").strip()
        if ov and not (os.environ.get(new) or "").strip():
            os.environ[new] = ov
    _normalized = True


def _ensure_normalized() -> None:
    normalize_environment_aliases()


def get_base_url() -> str:
    """HTTP API origin for control plane (no trailing slash)."""
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")


def get_trace_endpoint() -> str:
    """
    OTLP HTTP traces export URL.

    Honors standard OpenTelemetry env vars when set, else derives from ``PUVINOISE_BASE_URL``.
    """
    _ensure_normalized()
    traces = (os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT") or "").strip().rstrip("/")
    if traces:
        return traces if traces.endswith("/v1/traces") else f"{traces}/v1/traces"
    otel_base = (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").strip().rstrip("/")
    if otel_base:
        if otel_base.endswith("/v1/traces"):
            return otel_base
        return f"{otel_base}/v1/traces"
    base = get_base_url()
    if not base:
        return ""
    return f"{base}/v1/traces"


def get_api_key() -> str:
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_API_KEY") or "").strip()


def get_agent_name() -> str:
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_AGENT_NAME") or "").strip()


def get_agent_id() -> str:
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_AGENT_ID") or "").strip()


def get_tenant_id() -> str:
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_TENANTID") or "").strip()


def get_deploy_env() -> str:
    _ensure_normalized()
    return (os.environ.get("PUVINOISE_DEPLOY_ENV") or "").strip()


def env_var(name: str) -> str:
    """Read a single env var after normalization (trimmed)."""
    _ensure_normalized()
    return (os.environ.get(name) or "").strip()
