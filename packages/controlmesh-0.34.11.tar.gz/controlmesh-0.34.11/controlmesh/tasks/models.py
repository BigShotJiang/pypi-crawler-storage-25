"""Data models for the background task system."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from controlmesh.messenger.address import ChatRef, TopicRef


@dataclass(frozen=True, slots=True)
class TaskBindingSnapshot:
    """Assistant-slot binding captured at task creation time."""

    slot: str
    assistant: str
    command: str
    config_authority: str = "native"
    config_paths: tuple[str, ...] = ()
    config_digests: dict[str, str] = field(default_factory=dict)
    workunit: str = ""
    mode: str = ""
    background: bool = True

    def to_dict(self) -> dict[str, object]:
        return {
            "slot": self.slot,
            "assistant": self.assistant,
            "command": self.command,
            "config_authority": self.config_authority,
            "config_paths": list(self.config_paths),
            "config_digests": dict(self.config_digests),
            "workunit": self.workunit,
            "mode": self.mode,
            "background": self.background,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any] | None) -> TaskBindingSnapshot | None:
        if not isinstance(raw, dict):
            return None
        return cls(
            slot=str(raw.get("slot") or ""),
            assistant=str(raw.get("assistant") or ""),
            command=str(raw.get("command") or ""),
            config_authority=str(raw.get("config_authority") or "native"),
            config_paths=tuple(str(item) for item in (raw.get("config_paths") or [])),
            config_digests={
                str(key): str(value)
                for key, value in dict(raw.get("config_digests") or {}).items()
            },
            workunit=str(raw.get("workunit") or ""),
            mode=str(raw.get("mode") or ""),
            background=bool(raw.get("background", True)),
        )


@dataclass(slots=True)
class TaskSubmit:
    """Input for creating a background task."""

    chat_id: ChatRef
    prompt: str
    message_id: int
    thread_id: TopicRef
    parent_agent: str
    transport: str = "tg"
    name: str = ""
    slot_override: str = ""
    provider_override: str = ""
    model_override: str = ""
    thinking_override: str = ""
    topology: str = ""
    route: str = ""
    workunit_kind: str = ""
    command: str = ""
    target: str = ""
    evidence: str = ""
    required_capabilities: list[str] = field(default_factory=list)
    worker_runtime_writeback: bool = False
    worker_business_permissions: list[str] = field(default_factory=list)
    evaluator: str = ""
    route_slot: str = ""
    route_candidate_summary: str = ""
    plan_id: str = ""
    plan_markdown: str = ""
    plan_phases: list[dict[str, Any]] = field(default_factory=list)
    phase_id: str = ""
    phase_title: str = ""
    phase_metadata: dict[str, Any] = field(default_factory=dict)
    repo_root: str = ""
    expected_repo: str = ""
    expected_remote: str = ""
    expected_branch: str = ""
    tool_use_id: str = ""
    external_task: bool = False
    idempotency_key: str = ""


@dataclass(slots=True)
class TaskEntry:
    """Persisted task metadata."""

    task_id: str
    chat_id: ChatRef
    parent_agent: str
    name: str
    prompt_preview: str
    binding: TaskBindingSnapshot | None = None
    provider: str = ""
    model: str = ""
    status: str = "running"  # running | done | failed | cancelled | waiting | detached | recovering | stale
    transport: str = "tg"
    topology: str = ""
    session_id: str = ""
    created_at: float = field(default_factory=time.time)
    completed_at: float = 0.0
    elapsed_seconds: float = 0.0
    error: str = ""
    result_preview: str = ""
    question_count: int = 0
    num_turns: int = 0
    last_question: str = ""
    original_prompt: str = ""
    thinking: str = ""
    route: str = ""
    workunit_kind: str = ""
    route_reason: str = ""
    required_capabilities: list[str] = field(default_factory=list)
    worker_runtime_writeback: bool = False
    worker_business_permissions: list[str] = field(default_factory=list)
    evaluator: str = ""
    route_slot: str = ""
    route_candidate_summary: str = ""
    command: str = ""
    target: str = ""
    evidence: str = ""
    plan_id: str = ""
    phase_id: str = ""
    phase_title: str = ""
    phase_metadata: dict[str, Any] = field(default_factory=dict)
    repo_root: str = ""
    expected_repo: str = ""
    expected_remote: str = ""
    expected_branch: str = ""
    tool_use_id: str = ""
    tool_name: str = ""
    external_task: bool = False
    idempotency_key: str = ""
    tool_result_created_at: float = 0.0
    tool_result_enqueued_at: float = 0.0
    tool_result_delivered_at: float = 0.0
    tool_result_consumed_at: float = 0.0
    tasks_dir: str = ""  # Agent's tasks directory (for per-agent folder resolution)
    thread_id: TopicRef = None  # Forum topic ID (for routing results back to topic)

    def to_dict(self) -> dict[str, object]:
        d: dict[str, object] = {
            "task_id": self.task_id,
            "chat_id": self.chat_id,
            "parent_agent": self.parent_agent,
            "name": self.name,
            "prompt_preview": self.prompt_preview,
            "binding": self.binding.to_dict() if self.binding is not None else None,
            "provider": self.provider,
            "model": self.model,
            "transport": self.transport,
            "topology": self.topology,
            "status": self.status,
            "session_id": self.session_id,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "elapsed_seconds": self.elapsed_seconds,
            "error": self.error,
            "result_preview": self.result_preview,
            "question_count": self.question_count,
            "num_turns": self.num_turns,
            "last_question": self.last_question,
            "thinking": self.thinking,
            "route": self.route,
            "workunit_kind": self.workunit_kind,
            "route_reason": self.route_reason,
            "required_capabilities": list(self.required_capabilities),
            "worker_runtime_writeback": self.worker_runtime_writeback,
            "worker_business_permissions": list(self.worker_business_permissions),
            "evaluator": self.evaluator,
            "route_slot": self.route_slot,
            "route_candidate_summary": self.route_candidate_summary,
            "command": self.command,
            "target": self.target,
            "evidence": self.evidence,
            "plan_id": self.plan_id,
            "phase_id": self.phase_id,
            "phase_title": self.phase_title,
            "phase_metadata": dict(self.phase_metadata),
            "repo_root": self.repo_root,
            "expected_repo": self.expected_repo,
            "expected_remote": self.expected_remote,
            "expected_branch": self.expected_branch,
            "tool_use_id": self.tool_use_id,
            "tool_name": self.tool_name,
            "external_task": self.external_task,
            "idempotency_key": self.idempotency_key,
            "tool_result_created_at": self.tool_result_created_at,
            "tool_result_enqueued_at": self.tool_result_enqueued_at,
            "tool_result_delivered_at": self.tool_result_delivered_at,
            "tool_result_consumed_at": self.tool_result_consumed_at,
            "tasks_dir": self.tasks_dir,
        }
        if self.thread_id is not None:
            d["thread_id"] = self.thread_id
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TaskEntry:
        return cls(
            task_id=d["task_id"],
            chat_id=d["chat_id"],
            parent_agent=d.get("parent_agent", "main"),
            name=d.get("name", ""),
            prompt_preview=d.get("prompt_preview", ""),
            binding=TaskBindingSnapshot.from_dict(d.get("binding")),
            provider=d.get("provider", ""),
            model=d.get("model", ""),
            transport=d.get("transport", "tg"),
            topology=d.get("topology", ""),
            status=d.get("status", "running"),
            session_id=d.get("session_id", ""),
            created_at=d.get("created_at", 0.0),
            completed_at=d.get("completed_at", 0.0),
            elapsed_seconds=d.get("elapsed_seconds", 0.0),
            error=d.get("error", ""),
            result_preview=d.get("result_preview", ""),
            question_count=d.get("question_count", 0),
            num_turns=d.get("num_turns", 0),
            last_question=d.get("last_question", ""),
            thinking=d.get("thinking", ""),
            route=d.get("route", ""),
            workunit_kind=d.get("workunit_kind", ""),
            route_reason=d.get("route_reason", ""),
            required_capabilities=list(d.get("required_capabilities") or []),
            worker_runtime_writeback=bool(d.get("worker_runtime_writeback", False)),
            worker_business_permissions=list(d.get("worker_business_permissions") or []),
            evaluator=d.get("evaluator", ""),
            route_slot=d.get("route_slot", ""),
            route_candidate_summary=d.get("route_candidate_summary", ""),
            command=d.get("command", ""),
            target=d.get("target", ""),
            evidence=d.get("evidence", ""),
            plan_id=d.get("plan_id", ""),
            phase_id=d.get("phase_id", ""),
            phase_title=d.get("phase_title", ""),
            phase_metadata=dict(d.get("phase_metadata") or {}),
            repo_root=d.get("repo_root", ""),
            expected_repo=d.get("expected_repo", ""),
            expected_remote=d.get("expected_remote", ""),
            expected_branch=d.get("expected_branch", ""),
            tool_use_id=d.get("tool_use_id", ""),
            tool_name=d.get("tool_name", ""),
            external_task=bool(d.get("external_task", False)),
            idempotency_key=d.get("idempotency_key", ""),
            tool_result_created_at=d.get("tool_result_created_at", 0.0),
            tool_result_enqueued_at=d.get("tool_result_enqueued_at", 0.0),
            tool_result_delivered_at=d.get("tool_result_delivered_at", 0.0),
            tool_result_consumed_at=d.get("tool_result_consumed_at", 0.0),
            tasks_dir=d.get("tasks_dir", ""),
            thread_id=d.get("thread_id"),
        )


@dataclass(slots=True)
class TaskInFlight:
    """In-memory tracking for a running task."""

    entry: TaskEntry
    asyncio_task: asyncio.Task[None] | None = field(default=None, repr=False)
    has_pending_question: bool = False


@dataclass(frozen=True, slots=True)
class EvaluationFinding:
    """Structured evaluator finding surfaced to the controller."""

    severity: str
    title: str
    recommendation: str = ""


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    """Structured evaluator output for controller-facing workflow review."""

    score: int
    decision: str
    summary: str
    failure_kind: str = ""
    max_severity: str = "info"
    findings: tuple[EvaluationFinding, ...] = ()
    artifact_path: str = ""


@dataclass(slots=True)
class TaskResult:
    """Outcome delivered to parent agent after task completion."""

    task_id: str
    chat_id: ChatRef
    parent_agent: str
    name: str
    prompt_preview: str
    result_text: str
    status: str  # "done" | "failed" | "cancelled" | "timeout"
    elapsed_seconds: float
    provider: str
    model: str
    delivery_text: str = ""
    output_policy: str = "summarized_only"
    transport: str = "tg"
    session_id: str = ""
    error: str = ""
    failure_kind: str = ""
    task_folder: str = ""
    original_prompt: str = ""
    thread_id: TopicRef = None
    repo_root: str = ""
    tool_use_id: str = ""
    inject_to_parent_session: bool = True
    evaluation: EvaluationResult | None = None
    artifact_protocol_status: str = ""
    warnings: tuple[str, ...] = ()
