import os
import subprocess
import sys


def test_doctest():
    root = os.path.normpath(f'{__file__}/../../')
    subprocess.run(f'pip install --upgrade swig', shell=1, check=1)
    subprocess.run(f'{sys.executable} -m doctest {root}/pipcl.py', shell=1, check=1)
