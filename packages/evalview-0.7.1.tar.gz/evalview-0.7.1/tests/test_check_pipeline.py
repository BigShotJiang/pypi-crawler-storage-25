"""Integration tests for the new check pipeline (concurrent execution, DriftTracker wiring).

These tests exercise the specific improvements made during the silent-regression
detection feature work:

- _execute_check_tests returns (diffs, results, drift_tracker, golden_traces) — four-tuple
- Concurrent gather: one failing test does not cancel the others
- DriftTracker is populated during execution and passed to _display_check_results
- Semantic diff notice is shown when OPENAI_API_KEY is present
- Semantic diff warning is shown when OPENAI_API_KEY is missing
"""

from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import yaml


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_config(base: Path, adapter: str = "http", endpoint: str = "http://example.com") -> Path:
    config_dir = base / ".evalview"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.yaml"
    config_path.write_text(yaml.dump({"adapter": adapter, "endpoint": endpoint}))
    return config_path


def _make_fake_trace():
    from evalview.core.types import ExecutionTrace, ExecutionMetrics
    return ExecutionTrace(
        session_id="s1",
        start_time=datetime.now(),
        end_time=datetime.now(),
        steps=[],
        final_output="The answer is 42.",
        metrics=ExecutionMetrics(total_cost=0.0, total_latency=100.0),
    )


def _make_fake_result(test_name: str, score: float = 90.0):
    from evalview.core.types import EvaluationResult
    result = MagicMock(spec=EvaluationResult)
    result.test_case = test_name
    result.score = score
    result.passed = score >= 70
    result.trace = _make_fake_trace()
    return result


def _write_golden(base: Path, test_name: str, trace=None, score: float = 90.0) -> None:
    """Write a minimal golden JSON file directly to bypass save_golden() side effects."""
    from evalview.core.golden import GoldenStore

    golden_dir = base / ".evalview" / "golden"
    golden_dir.mkdir(parents=True, exist_ok=True)

    trace = trace or _make_fake_trace()
    store = GoldenStore(base_path=base)

    fake_result = MagicMock()
    fake_result.test_case = test_name
    fake_result.score = score
    fake_result.passed = True
    fake_result.trace = trace
    store.save_golden(fake_result)


def _write_test_yaml(test_dir: Path, name: str, query: str = "hello") -> None:
    test_dir.mkdir(parents=True, exist_ok=True)
    (test_dir / f"{name}.yaml").write_text(
        yaml.dump({
            "name": name,
            "input": {"query": query},
            "expected": {"tools": []},
            "thresholds": {"min_score": 0},
        })
    )


# ---------------------------------------------------------------------------
# Tests for _execute_check_tests return signature
# ---------------------------------------------------------------------------

class TestExecuteCheckTestsReturnType:
    """_execute_check_tests must return a 4-tuple: (diffs, results, drift_tracker, golden_traces)."""

    @pytest.fixture
    def project(self, tmp_path):
        _write_config(tmp_path)
        _write_test_yaml(tmp_path / "tests", "my-test")
        _write_golden(tmp_path, "my-test")
        return tmp_path

    def test_returns_four_tuple(self, project, monkeypatch):
        from evalview.commands.shared import _execute_check_tests
        from evalview.core.config import EvalViewConfig
        from evalview.core.drift_tracker import DriftTracker

        monkeypatch.chdir(project)

        fake_trace = _make_fake_trace()
        fake_result = _make_fake_result("my-test")
        fake_result.trace = fake_trace

        mock_adapter = MagicMock()
        mock_adapter.execute = AsyncMock(return_value=fake_trace)
        mock_evaluator = MagicMock()
        mock_evaluator.evaluate = AsyncMock(return_value=fake_result)

        from evalview.core.loader import TestCaseLoader
        loader = TestCaseLoader()
        test_cases = loader.load_from_directory(str(project / "tests"))

        config = EvalViewConfig(adapter="http", endpoint="http://example.com")

        with (
            patch("evalview.commands.shared._create_adapter", return_value=mock_adapter),
            patch("evalview.evaluators.evaluator.Evaluator", return_value=mock_evaluator),
        ):
            result = _execute_check_tests(test_cases, config, json_output=False)

        assert isinstance(result, tuple)
        assert len(result) == 4, "Must return (diffs, results, drift_tracker, golden_traces)"

        diffs, results, drift_tracker, golden_traces = result
        assert isinstance(diffs, list)
        assert isinstance(results, list)
        assert isinstance(drift_tracker, DriftTracker)
        assert isinstance(golden_traces, dict)

    def test_drift_tracker_is_populated(self, project, monkeypatch):
        """DriftTracker returned from _execute_check_tests must have history for the test."""
        from evalview.commands.shared import _execute_check_tests
        from evalview.core.config import EvalViewConfig

        monkeypatch.chdir(project)

        fake_trace = _make_fake_trace()
        fake_result = _make_fake_result("my-test")
        fake_result.trace = fake_trace

        mock_adapter = MagicMock()
        mock_adapter.execute = AsyncMock(return_value=fake_trace)
        mock_evaluator = MagicMock()
        mock_evaluator.evaluate = AsyncMock(return_value=fake_result)

        from evalview.core.loader import TestCaseLoader
        loader = TestCaseLoader()
        test_cases = loader.load_from_directory(str(project / "tests"))

        config = EvalViewConfig(adapter="http", endpoint="http://example.com")

        with (
            patch("evalview.commands.shared._create_adapter", return_value=mock_adapter),
            patch("evalview.evaluators.evaluator.Evaluator", return_value=mock_evaluator),
        ):
            _, _, drift_tracker, _ = _execute_check_tests(test_cases, config, json_output=False)

        history = drift_tracker.get_test_history("my-test")
        assert len(history) == 1, "DriftTracker should have one entry after one check"


# ---------------------------------------------------------------------------
# Test: one failing test does not cancel others (return_exceptions=True)
# ---------------------------------------------------------------------------

class TestConcurrentExecution:
    """Tests that concurrent gather execution handles per-test failures gracefully."""

    @pytest.fixture
    def multi_test_project(self, tmp_path):
        _write_config(tmp_path)
        # Write two test cases
        for name in ["test-a", "test-b"]:
            _write_test_yaml(tmp_path / "tests", name)
            _write_golden(tmp_path, name)
        return tmp_path

    def test_one_failure_does_not_cancel_others(self, multi_test_project, monkeypatch):
        """If test-a raises, test-b should still complete and appear in results."""
        from evalview.commands.shared import _execute_check_tests
        from evalview.core.config import EvalViewConfig

        monkeypatch.chdir(multi_test_project)

        fake_trace_b = _make_fake_trace()
        fake_result_b = _make_fake_result("test-b")
        fake_result_b.trace = fake_trace_b

        call_count = {"n": 0}

        async def _side_effect(query, context):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise RuntimeError("Simulated adapter failure for test-a")
            return fake_trace_b

        mock_adapter = MagicMock()
        mock_adapter.execute = _side_effect
        mock_evaluator = MagicMock()
        mock_evaluator.evaluate = AsyncMock(return_value=fake_result_b)

        from evalview.core.loader import TestCaseLoader
        loader = TestCaseLoader()
        test_cases = loader.load_from_directory(str(multi_test_project / "tests"))
        # Sort for determinism
        test_cases.sort(key=lambda tc: tc.name)

        config = EvalViewConfig(adapter="http", endpoint="http://example.com")

        with (
            patch("evalview.commands.shared._create_adapter", return_value=mock_adapter),
            patch("evalview.evaluators.evaluator.Evaluator", return_value=mock_evaluator),
        ):
            diffs, results, _, _ = _execute_check_tests(test_cases, config, json_output=True)

        # test-a failed → no diff for it
        # test-b succeeded → one diff
        diff_names = [name for name, _ in diffs]
        assert "test-b" in diff_names, "test-b should still complete even though test-a failed"


class TestSlowAgentWarning:
    """Slow-agent warning fires once at 50% of timeout, respects --json mode."""

    @pytest.fixture
    def project(self, tmp_path):
        _write_config(tmp_path)
        _write_test_yaml(tmp_path / "tests", "my-test")
        _write_golden(tmp_path, "my-test")
        return tmp_path

    def _run(self, project, execute_delay, json_output, timeout):
        import asyncio as _asyncio
        from evalview.commands.shared import _execute_check_tests
        from evalview.core.config import EvalViewConfig
        from evalview.core.loader import TestCaseLoader

        fake_trace = _make_fake_trace()
        fake_result = _make_fake_result("my-test")
        fake_result.trace = fake_trace

        async def _execute(query, context):
            await _asyncio.sleep(execute_delay)
            return fake_trace

        mock_adapter = MagicMock()
        mock_adapter.execute = _execute
        mock_evaluator = MagicMock()
        mock_evaluator.evaluate = AsyncMock(return_value=fake_result)

        test_cases = TestCaseLoader().load_from_directory(str(project / "tests"))
        config = EvalViewConfig(adapter="http", endpoint="http://example.com")
        mock_console = MagicMock()

        with (
            patch("evalview.commands.shared._create_adapter", return_value=mock_adapter),
            patch("evalview.evaluators.evaluator.Evaluator", return_value=mock_evaluator),
            patch("evalview.commands.shared.console", mock_console),
        ):
            _execute_check_tests(test_cases, config, json_output=json_output, timeout=timeout)

        return [
            str(c.args[0]) for c in mock_console.print.call_args_list
            if c.args and "Agent is taking a while" in str(c.args[0])
        ]

    @pytest.mark.parametrize(
        "execute_delay,json_output,timeout,expected_warnings",
        [
            # Slow agent, non-JSON: warning fires exactly once
            (1.0, False, 0.4, 1),
            # Slow agent, JSON mode: warning suppressed
            (1.0, True, 0.4, 0),
            # Fast agent: completes before the 50% mark, no warning
            (0.05, False, 2.0, 0),
        ],
        ids=["slow-non-json", "slow-json-mode", "fast-no-warning"],
    )
    def test_slow_agent_warning_behavior(
        self, project, monkeypatch, execute_delay, json_output, timeout, expected_warnings
    ):
        monkeypatch.chdir(project)
        warnings = self._run(project, execute_delay, json_output, timeout)
        assert len(warnings) == expected_warnings

    def test_warning_reports_real_elapsed_and_timeout(self, project, monkeypatch):
        """Warning message should include a measured elapsed value and the configured timeout."""
        import re

        monkeypatch.chdir(project)
        warnings = self._run(project, execute_delay=1.0, json_output=False, timeout=0.4)
        assert len(warnings) == 1

        match = re.search(r"\(([\d.]+)s elapsed of ([\d.]+)s timeout\)", warnings[0])
        assert match is not None, f"Unexpected warning format: {warnings[0]}"
        elapsed = float(match.group(1))
        reported_timeout = float(match.group(2))
        # Elapsed should be at least the warn_after point (~0.2s) and well under the timeout.
        assert 0.1 <= elapsed < 0.4
        assert reported_timeout == 0.4


# ---------------------------------------------------------------------------
# Test: DriftTracker is reused in _display_check_results (no dual instantiation)
# ---------------------------------------------------------------------------

class TestDriftTrackerReuse:
    """_display_check_results must use the passed tracker, not create a new one."""

    def test_display_uses_passed_drift_tracker(self, tmp_path):
        from evalview.commands.check_display import _display_check_results
        from evalview.core.diff import TraceDiff, DiffStatus, OutputDiff
        from evalview.core.drift_tracker import DriftTracker

        # Build a minimal passing diff
        output_diff = OutputDiff(
            similarity=1.0,
            golden_preview="",
            actual_preview="",
            diff_lines=[],
            severity=DiffStatus.PASSED,
        )
        diff = TraceDiff(
            test_name="my-test",
            has_differences=False,
            tool_diffs=[],
            output_diff=output_diff,
            score_diff=0.0,
            latency_diff=0.0,
            overall_severity=DiffStatus.PASSED,
        )

        diffs = [("my-test", diff)]
        analysis = {
            "has_regressions": False,
            "has_tools_changed": False,
            "has_output_changed": False,
            "all_passed": True,
        }

        # A tracker with known state — if we detect a new instance was created,
        # it won't have this history.
        tracker = DriftTracker(base_path=tmp_path)
        tracker.record_check("my-test", diff)

        state = MagicMock()
        state.current_streak = 1
        state.total_checks = 1

        instantiation_calls = []
        original_DriftTracker = DriftTracker

        class SpyDriftTracker(original_DriftTracker):
            def __init__(self, *a, **kw):
                instantiation_calls.append(1)
                super().__init__(*a, **kw)

        # DriftTracker is imported locally inside _display_check_results, so
        # patch the class at its definition site (the module it lives in).
        with patch("evalview.core.drift_tracker.DriftTracker", SpyDriftTracker):
            _display_check_results(
                diffs, analysis, state, False, True, drift_tracker=tracker
            )

        # DriftTracker.__init__ must NOT have been called for detection purposes
        # (it's only called as a fallback when no tracker is passed)
        assert len(instantiation_calls) == 0, (
            "DriftTracker should NOT be re-instantiated when drift_tracker is passed"
        )


# ---------------------------------------------------------------------------
# Test: semantic diff CLI notice / warning
# ---------------------------------------------------------------------------

class TestSemanticDiffNotice:
    """Verify the semantic diff privacy notice and availability warning."""

    @pytest.fixture
    def project(self, tmp_path):
        _write_config(tmp_path)
        _write_test_yaml(tmp_path / "tests", "my-test")
        _write_golden(tmp_path, "my-test")
        return tmp_path

    def test_notice_shown_when_available(self, project, monkeypatch, capsys):
        """When OPENAI_API_KEY is set, print the cost notice before running."""
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        from evalview.core.semantic_diff import SemanticDiff

        with patch.object(SemanticDiff, "is_available", return_value=True):
            with patch.object(SemanticDiff, "cost_notice", return_value="~$0.00004/check"):
                # Simulate what the check command does before calling _execute_check_tests
                from rich.console import Console
                console = Console()
                if SemanticDiff.is_available():
                    console.print(
                        f"[dim]ℹ  Semantic diff enabled. {SemanticDiff.cost_notice()} "
                        "Agent outputs are sent to OpenAI for embedding comparison.[/dim]\n"
                    )

        # We trust the logic is correct; the key test is is_available() + cost_notice() integrate
        assert SemanticDiff.cost_notice() is not None

    def test_warning_shown_when_key_missing(self, project, monkeypatch):
        """When OPENAI_API_KEY is missing, is_available() returns False."""
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        from evalview.core.semantic_diff import SemanticDiff
        assert SemanticDiff.is_available() is False


def test_display_check_results_labels_multi_turn_regressions(capsys):
    """Console check output should explicitly label failed multi-turn paths."""
    from evalview.commands.check_display import _display_check_results
    from evalview.core.diff import DiffStatus

    diff = MagicMock()
    diff.overall_severity = DiffStatus.REGRESSION
    diff.score_diff = -20.0
    diff.tool_diffs = []
    diff.output_diff = None

    analysis = {
        "all_passed": False,
        "has_regressions": True,
        "has_tools_changed": False,
        "has_output_changed": False,
        "execution_failures": 0,
    }
    state = MagicMock()
    state.current_streak = 0
    state.total_checks = 1

    _display_check_results(
        [("refund-needs-order-number", diff)],
        analysis,
        state,
        False,
        False,
        test_metadata={
            "refund-needs-order-number": {
                "is_multi_turn": True,
                "behavior_class": "multi_turn",
            }
        },
    )

    output = capsys.readouterr().out
    assert "Multi-turn path:" in output
    assert "multi turn" in output
