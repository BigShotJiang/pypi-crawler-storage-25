"""CLI entry point for EvalView — thin orchestrator that wires command modules."""
import sys as _sys

# Windows terminals default to cp1252, which can't encode Unicode box-drawing
# characters and emojis used by Rich. Reconfigure stdout/stderr to UTF-8 with
# errors='replace' so unrenderable characters become '?' instead of crashing.
if _sys.platform == "win32":
    try:
        if hasattr(_sys.stdout, "reconfigure"):
            _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(_sys.stderr, "reconfigure"):
            _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from importlib.metadata import version as _pkg_version, PackageNotFoundError

try:
    _EVALVIEW_VERSION = _pkg_version("evalview")
except PackageNotFoundError:
    _EVALVIEW_VERSION = "dev"

import click

from evalview.commands.shared import console
from evalview.telemetry.config import (
    should_show_first_run_notice,
    mark_first_run_notice_shown,
)
from evalview.version_check import get_update_notice

# ── Command modules ──────────────────────────────────────────────────────────
from evalview.commands.run import run
from evalview.commands.listing_cmd import list_cmd, adapters, report, view, connect, validate_adapter, record
from evalview.commands.skill_cmd import skill
from evalview.commands.capture_cmd import capture
from evalview.commands.init_cmd import init
from evalview.commands.add_cmd import add
from evalview.commands.demo_cmd import demo
from evalview.commands.judge_cmd import judge
from evalview.commands.expand_cmd import expand
from evalview.commands.generate_cmd import generate
from evalview.commands.trends_cmd import trends
from evalview.commands.golden_cmd import golden
from evalview.commands.telemetry_cmd import telemetry
from evalview.commands.ci_cmd import ci
from evalview.commands.gym_cmd import gym
from evalview.commands.cloud_cmd import login, logout, whoami
from evalview.commands.hooks_cmd import install_hooks, uninstall_hooks
from evalview.commands.import_cmd import import_logs
from evalview.commands.snapshot_cmd import snapshot
from evalview.commands.check_cmd import check, replay
from evalview.commands.simulate_cmd import simulate
from evalview.commands.replay_trace_cmd import replay_trace
from evalview.commands.model_check_cmd import model_check
from evalview.commands.monitor_cmd import monitor
from evalview.commands.autopr_cmd import autopr
from evalview.commands.benchmark_cmd import benchmark_cmd
from evalview.commands.mcp_cmd import mcp
from evalview.commands.validate_cmd import validate
from evalview.commands.visual_cmd import inspect_cmd, visualize_cmd, compare_cmd
from evalview.commands.chat_cmd import chat, trace_cmd
from evalview.commands.traces_cmd import traces
from evalview.commands.baseline_cmd import baseline
from evalview.commands.feedback_cmd import feedback
from evalview.commands.quarantine_cmd import quarantine
from evalview.commands.openclaw_cmd import openclaw
from evalview.commands.watch_cmd import watch
from evalview.commands.badge_cmd import badge
from evalview.commands.log_cmd import log_cmd
from evalview.commands.since_cmd import since_cmd
from evalview.commands.progress_cmd import progress_cmd
from evalview.commands.drift_cmd import drift_cmd
from evalview.commands.slack_digest_cmd import slack_digest_cmd
from evalview.commands.diff_cmd import diff_cmd


class OrderedGroup(click.Group):
    """Group that renders subcommands in workflow-ordered sections.

    Click's default Group lists commands alphabetically, which buries the
    happy-path commands among 50+ specialized ones. This subclass renders
    a curated set of named sections and skips hidden commands.
    """

    SECTIONS: list[tuple[str, list[str]]] = [
        ("Start", ["demo", "init"]),
        ("Regression Gating", ["snapshot", "check", "model-check", "replay"]),
        ("Triage", ["since", "progress", "drift"]),
        ("Production", ["watch", "monitor", "autopr"]),
        ("Evaluation", ["run", "report", "generate", "judge", "expand",
                        "golden", "compare", "benchmark", "simulate"]),
        ("Capture & Import", ["capture", "import", "record", "connect", "adapters"]),
        ("Inspect & Visualize", ["view", "visualize", "trace", "traces",
                                 "baseline", "trends"]),
        ("CI/CD", ["ci", "validate", "badge", "install-hooks", "uninstall-hooks"]),
        ("Integrations", ["mcp", "skill", "gym", "chat"]),
        ("Account", ["login", "logout", "whoami", "telemetry", "feedback"]),
    ]

    def list_commands(self, ctx: click.Context) -> list[str]:
        ordered: list[str] = []
        seen: set[str] = set()
        for _, names in self.SECTIONS:
            for name in names:
                if name in self.commands and name not in seen:
                    ordered.append(name)
                    seen.add(name)
        for name in sorted(self.commands):
            if name in seen:
                continue
            if self.commands[name].hidden:
                continue
            ordered.append(name)
        return ordered

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        rendered: set[str] = set()
        for section_title, names in self.SECTIONS:
            rows: list[tuple[str, str]] = []
            for name in names:
                cmd = self.commands.get(name)
                if cmd is None or cmd.hidden:
                    continue
                rows.append((name, cmd.get_short_help_str(limit=60)))
                rendered.add(name)
            if rows:
                with formatter.section(section_title):
                    formatter.write_dl(rows)

        leftover: list[tuple[str, str]] = []
        for name in sorted(self.commands):
            if name in rendered:
                continue
            cmd = self.commands[name]
            if cmd.hidden:
                continue
            leftover.append((name, cmd.get_short_help_str(limit=60)))
        if leftover:
            with formatter.section("Other"):
                formatter.write_dl(leftover)


@click.group(cls=OrderedGroup, context_settings={"allow_interspersed_args": False})
@click.version_option(version=_EVALVIEW_VERSION)
@click.pass_context
def main(ctx: click.Context) -> None:
    """EvalView — Regression testing and evaluation for AI agents.

    New here? Start with `evalview demo` or `evalview init`.
    Run `evalview <command> --help` for details on any command.
    """
    # Show first-run telemetry notice (once only)
    if should_show_first_run_notice():
        if ctx.invoked_subcommand not in ("telemetry",):
            console.print()
            console.print("[dim]╭──────────────────────────────────────────────────────────────╮[/dim]")
            console.print("[dim]│[/dim] EvalView collects anonymous usage data to improve the tool. [dim]│[/dim]")
            console.print("[dim]│[/dim] No personal info or test content is collected.              [dim]│[/dim]")
            console.print("[dim]│[/dim] Disable with: [cyan]evalview telemetry off[/cyan]                      [dim]│[/dim]")
            console.print("[dim]╰──────────────────────────────────────────────────────────────╯[/dim]")
            console.print()
            mark_first_run_notice_shown()

    if ctx.invoked_subcommand not in (None, "telemetry"):
        notice = get_update_notice(_EVALVIEW_VERSION)
        if notice:
            console.print(f"[dim]{notice}[/dim]\n")


# ── Register commands ────────────────────────────────────────────────────────
main.add_command(run)
main.add_command(list_cmd, name="list")
main.add_command(adapters)
main.add_command(report)
main.add_command(view)
main.add_command(connect)
main.add_command(validate_adapter, name="validate-adapter")
main.add_command(validate)
main.add_command(record)
main.add_command(skill)
main.add_command(capture)
main.add_command(init)
main.add_command(add)
main.add_command(demo)
main.add_command(judge)
main.add_command(expand)
main.add_command(generate)
main.add_command(trends)
main.add_command(golden)
main.add_command(telemetry)
main.add_command(ci)
main.add_command(gym)
main.add_command(login)
main.add_command(logout)
main.add_command(whoami)
main.add_command(install_hooks, name="install-hooks")
main.add_command(uninstall_hooks, name="uninstall-hooks")
main.add_command(import_logs, name="import")
main.add_command(snapshot)
main.add_command(check)
main.add_command(simulate)
main.add_command(model_check, name="model-check")
main.add_command(replay)
main.add_command(replay_trace, name="replay-trace")
main.add_command(benchmark_cmd, name="benchmark")
main.add_command(mcp)
main.add_command(inspect_cmd, name="inspect")
main.add_command(visualize_cmd, name="visualize")
main.add_command(compare_cmd, name="compare")
main.add_command(chat)
main.add_command(trace_cmd, name="trace")
main.add_command(traces)
main.add_command(baseline)
main.add_command(monitor)
main.add_command(autopr)
main.add_command(feedback)
main.add_command(openclaw)
main.add_command(watch)
main.add_command(badge)
main.add_command(quarantine)
main.add_command(log_cmd, name="log")
main.add_command(since_cmd, name="since")
main.add_command(progress_cmd, name="progress")
main.add_command(drift_cmd, name="drift")
main.add_command(slack_digest_cmd, name="slack-digest")
main.add_command(diff_cmd, name="diff")


if __name__ == "__main__":
    main()
