from mydot.repository import Repository
from mydot.console import console

__version__ = "0.9.2"
__all__ = ["Repository", "console"]
