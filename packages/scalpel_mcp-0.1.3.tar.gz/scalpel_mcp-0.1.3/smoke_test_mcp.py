"""Smoke test Scalpel edit operations without using the MCP protocol."""
from __future__ import annotations

import os
import sys
import tempfile
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from scalpel.core import edit_class_method, edit_function_body, measure_edit
from scalpel.measure import blast_radius, patch_locality, token_cost
from scalpel.types import EditResult, format_result


SAMPLE_SOURCE = """
import os

class AuthService:
    def validate_token(self, token: str) -> bool:
        return False

    def refresh_token(self, token: str) -> str:
        return token

def standalone_helper(x: int) -> int:
    return x
"""


def large_body() -> str:
    lines = [
        "total = 0",
        "for index in range(250):",
        "    total += x + index",
        "if total < 0:",
        "    return 0",
        "return total",
    ]
    return "\n".join(lines)


def metric(value: float | int | None) -> str:
    if value is None:
        return "None"
    if isinstance(value, float):
        return f"{value:.2f}"
    return str(value)


def print_row(name: str, result: EditResult) -> None:
    print(
        f"{name} | success={result.success} | "
        f"blast_radius={metric(result.blast_radius)} | "
        f"patch_locality={metric(result.patch_locality)} | "
        f"token_cost={metric(result.token_cost)}"
    )


def make_temp_python_file() -> Path:
    fd, filename = tempfile.mkstemp(suffix=".py", prefix="smoke_mcp_", dir=ROOT)
    os.close(fd)
    path = Path(filename)
    path.write_text(textwrap.dedent(SAMPLE_SOURCE).lstrip(), encoding="utf-8")
    return path


def metric_helpers_available(source: str) -> bool:
    return (
        blast_radius(source, source) == 0.0
        and patch_locality("", len(source.splitlines())) == 1.0
        and token_cost(source, "") > 0
    )


def run() -> bool:
    failures: list[str] = []
    path = make_temp_python_file()

    try:
        results: list[tuple[str, EditResult]] = [
            (
                "standalone_helper",
                edit_function_body(str(path), "standalone_helper", "return x + 1"),
            ),
            (
                "AuthService.validate_token",
                edit_class_method(
                    str(path),
                    "AuthService",
                    "validate_token",
                    "if not token:\n    return False\nreturn token.startswith('valid-')",
                ),
            ),
            (
                "AuthService.refresh_token",
                edit_class_method(
                    str(path),
                    "AuthService",
                    "refresh_token",
                    "return f'{token}:refreshed'",
                ),
            ),
        ]

        before_measure = path.read_text(encoding="utf-8")
        results.append(
            (
                "measure_edit standalone_helper large body",
                measure_edit(str(path), "standalone_helper", large_body()),
            )
        )
        after_measure = path.read_text(encoding="utf-8")

        for name, result in results:
            print_row(name, result)
            if not result.success:
                failures.append(f"{name}: {format_result(result)}")

        if after_measure != before_measure:
            failures.append("measure_edit modified the file during dry run")

        if not metric_helpers_available(after_measure):
            failures.append("metric helper sanity check failed")
    finally:
        path.unlink(missing_ok=True)

    if failures:
        print("FAIL")
        for failure in failures:
            print(f"  {failure}")
        return False

    print("PASS")
    return True


def main() -> int:
    return 0 if run() else 1


if __name__ == "__main__":
    raise SystemExit(main())
