"""Verify edit_function_body on plain, async, and decorated functions."""
from __future__ import annotations

import os
import sys
import tempfile
import textwrap
from pathlib import Path

import libcst as cst

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from scalpel.core import edit_function_body
from scalpel.types import EditResult


SOURCE = """\
def marker(fn):
    return fn


def plain_function(value):
    return value + 1


async def async_function(value):
    return value + 2


@marker
def decorated_function(value):
    return value + 3
"""


EDITS = {
    "plain_function": "return value * 10",
    "async_function": "return value * 20",
    "decorated_function": "return value * 30",
}


def diff_line_count(result: EditResult) -> int:
    return len(result.diff.splitlines())


def file_syntax_valid(path: Path) -> bool:
    try:
        cst.parse_module(path.read_text(encoding="utf-8"))
    except cst.ParserSyntaxError:
        return False
    return True


def print_result(function_name: str, result: EditResult, syntax_valid: bool) -> None:
    error = result.error or ""
    print(
        f"{function_name} | {result.success} | {syntax_valid} | "
        f"{diff_line_count(result)} | {error}"
    )


def run() -> bool:
    results: list[EditResult] = []
    fd, target_name = tempfile.mkstemp(suffix=".py", prefix="verify_edits_", dir=ROOT)
    os.close(fd)
    target = Path(target_name)

    try:
        target.write_text(textwrap.dedent(SOURCE), encoding="utf-8")

        for function_name, new_body in EDITS.items():
            result = edit_function_body(str(target), function_name, new_body)
            syntax_valid = result.syntax_valid and file_syntax_valid(target)
            print_result(function_name, result, syntax_valid)
            results.append(result)
    finally:
        target.unlink(missing_ok=True)

    assert all(result.success for result in results)
    return True


def main() -> int:
    try:
        run()
    except Exception as exc:
        print(f"FAIL: {exc}")
        return 1

    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
