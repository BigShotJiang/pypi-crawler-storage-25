# -*- coding: utf-8 -*-

"""
Provides common elements for different projects. Unlike `core-mixins`, this
project requires external dependencies.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version


try:
    __version__ = version("core-extensions")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
]
