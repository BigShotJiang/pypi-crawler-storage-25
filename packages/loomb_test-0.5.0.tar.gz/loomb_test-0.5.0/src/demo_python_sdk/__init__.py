__version__ = "0.5.0"
MAGIC_NUMBER = 111


def get_magic_number() -> int:
    return MAGIC_NUMBER
