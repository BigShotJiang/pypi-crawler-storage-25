# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from runwayml import RunwayML, AsyncRunwayML
from tests.utils import assert_matches_type
from runwayml.types import (
    RealtimeSessionCreateResponse,
    RealtimeSessionRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestRealtimeSessions:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: RunwayML) -> None:
        realtime_session = client.realtime_sessions.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        )
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: RunwayML) -> None:
        realtime_session = client.realtime_sessions.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
            max_duration=10,
            personality="x",
            start_script="x",
            tools=[
                {
                    "description": "x",
                    "name": "name",
                    "type": "client_event",
                    "parameters": [
                        {
                            "description": "x",
                            "name": "name",
                            "type": "string",
                            "enum": ["string"],
                            "required": True,
                        }
                    ],
                }
            ],
        )
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: RunwayML) -> None:
        response = client.realtime_sessions.with_raw_response.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = response.parse()
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: RunwayML) -> None:
        with client.realtime_sessions.with_streaming_response.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = response.parse()
            assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: RunwayML) -> None:
        realtime_session = client.realtime_sessions.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: RunwayML) -> None:
        response = client.realtime_sessions.with_raw_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = response.parse()
        assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: RunwayML) -> None:
        with client.realtime_sessions.with_streaming_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = response.parse()
            assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: RunwayML) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.realtime_sessions.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_delete(self, client: RunwayML) -> None:
        realtime_session = client.realtime_sessions.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert realtime_session is None

    @parametrize
    def test_raw_response_delete(self, client: RunwayML) -> None:
        response = client.realtime_sessions.with_raw_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = response.parse()
        assert realtime_session is None

    @parametrize
    def test_streaming_response_delete(self, client: RunwayML) -> None:
        with client.realtime_sessions.with_streaming_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = response.parse()
            assert realtime_session is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: RunwayML) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.realtime_sessions.with_raw_response.delete(
                "",
            )


class TestAsyncRealtimeSessions:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncRunwayML) -> None:
        realtime_session = await async_client.realtime_sessions.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        )
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncRunwayML) -> None:
        realtime_session = await async_client.realtime_sessions.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
            max_duration=10,
            personality="x",
            start_script="x",
            tools=[
                {
                    "description": "x",
                    "name": "name",
                    "type": "client_event",
                    "parameters": [
                        {
                            "description": "x",
                            "name": "name",
                            "type": "string",
                            "enum": ["string"],
                            "required": True,
                        }
                    ],
                }
            ],
        )
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncRunwayML) -> None:
        response = await async_client.realtime_sessions.with_raw_response.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = await response.parse()
        assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncRunwayML) -> None:
        async with async_client.realtime_sessions.with_streaming_response.create(
            avatar={
                "preset_id": "game-character",
                "type": "runway-preset",
            },
            model="gwm1_avatars",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = await response.parse()
            assert_matches_type(RealtimeSessionCreateResponse, realtime_session, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncRunwayML) -> None:
        realtime_session = await async_client.realtime_sessions.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncRunwayML) -> None:
        response = await async_client.realtime_sessions.with_raw_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = await response.parse()
        assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncRunwayML) -> None:
        async with async_client.realtime_sessions.with_streaming_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = await response.parse()
            assert_matches_type(RealtimeSessionRetrieveResponse, realtime_session, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncRunwayML) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.realtime_sessions.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncRunwayML) -> None:
        realtime_session = await async_client.realtime_sessions.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert realtime_session is None

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncRunwayML) -> None:
        response = await async_client.realtime_sessions.with_raw_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        realtime_session = await response.parse()
        assert realtime_session is None

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncRunwayML) -> None:
        async with async_client.realtime_sessions.with_streaming_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            realtime_session = await response.parse()
            assert realtime_session is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncRunwayML) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.realtime_sessions.with_raw_response.delete(
                "",
            )
