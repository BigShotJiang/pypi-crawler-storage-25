"""Hard-cap enforcement with server-authoritative tier verification.

Design (v0.3.0):

    1. Every write call (set_entity, write_event, set_state, set_reference)
       calls _check_write_allowed(proposed_delta_bytes).
    2. Three fast paths skip the server call:
       a) tier in PAID_TIERS (locally cached, refreshed weekly)
       b) db_size + delta would still be well under the cap
       c) we have a recent cached server result that says we're under-cap
    3. The slow path (only fires at the cap boundary) hits the server endpoint
       POST /api/plugin/check-write with current_size + proposed_delta. The
       server is the authoritative source for tier — credentials.json
       tampering is detected here because the server looks up the real tier
       from sibyl_plugin.accounts.
    4. Server response is cached for 7 days. After that, the next write at the
       cap forces a refresh. Users who go offline keep working under the
       cached result; if their cached tier says paid, they keep their grant
       for up to a week.
    5. Offline at the cap boundary with NO cache: hard block with a clear
       error pointing at the upgrade URL.

The local-first promise is preserved: no memory content ever crosses the
network. Only (account_id, current_size_bytes, proposed_delta_bytes) is sent
to the check-write endpoint.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .exceptions import SibylMemoryError

# ----------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------

FREE_TIER_CAP_BYTES = 2 * 1024 * 1024  # 2 MB
GRACE_PERIOD_SECONDS = 7 * 24 * 60 * 60  # 7 days
PAID_TIERS = frozenset({"sync", "team", "lifetime", "stake", "enterprise"})

DEFAULT_CHECK_WRITE_URL = "https://api.sibyllabs.org/api/plugin/check-write"
DEFAULT_UPGRADE_URL = "https://docs.sibyllabs.org/memory/tiers"
DEFAULT_CACHE_PATH = "~/.sibyl-memory/tier_cache.json"

# Network timeout for the check-write call. Short to keep latency tolerable
# on the user's first write at the cap.
HTTP_TIMEOUT_SECONDS = 4.0


# ----------------------------------------------------------------------
# Exceptions
# ----------------------------------------------------------------------

class CapExceededError(SibylMemoryError):
    """Raised when a free-tier user tries to write past the 2 MB cap.

    Carries the upgrade URL so callers (CLIs, IDEs, agent frameworks) can
    render a clean upgrade prompt.
    """

    code = "CAP_EXCEEDED"
    recovery = (
        "Upgrade to remove the 2 MB cap. See "
        "https://docs.sibyllabs.org/memory/tiers for options "
        "(Sibyl Stake / Sync / Lifetime / Enterprise)."
    )

    def __init__(
        self,
        message: str,
        *,
        current_size: int,
        cap: int,
        proposed_delta: int = 0,
        upgrade_url: str = DEFAULT_UPGRADE_URL,
    ) -> None:
        super().__init__(message)
        self.current_size = current_size
        self.cap = cap
        self.proposed_delta = proposed_delta
        self.upgrade_url = upgrade_url


class TierVerificationError(SibylMemoryError):
    """Raised when the SDK can't verify the user's tier and has no cached
    grace period to fall back on (offline at the cap with no recent
    successful check)."""

    code = "TIER_VERIFY_FAILED"
    recovery = (
        "Connect to the internet so the SDK can verify your account, or "
        "stay under the 2 MB free-tier cap until you're online."
    )


# ----------------------------------------------------------------------
# Cache
# ----------------------------------------------------------------------

@dataclass
class TierCacheEntry:
    """A single tier-check result cached on disk."""
    account_id: str
    tier: str
    checked_at: float          # epoch seconds when we got the result
    cap_bytes: int | None      # None = uncapped (paid)
    last_known_size: int = 0   # the size we reported when we made the check
    grace_seconds: int = GRACE_PERIOD_SECONDS

    @property
    def expires_at(self) -> float:
        return self.checked_at + self.grace_seconds

    @property
    def is_fresh(self) -> bool:
        return time.time() < self.expires_at


class TierCache:
    """File-backed tier cache. Mode 0600. Single entry per file."""

    def __init__(self, path: str | Path = DEFAULT_CACHE_PATH) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)

    def load(self) -> TierCacheEntry | None:
        if not self.path.exists():
            return None
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return TierCacheEntry(
                account_id=raw["account_id"],
                tier=raw["tier"],
                checked_at=float(raw["checked_at"]),
                cap_bytes=raw.get("cap_bytes"),
                last_known_size=int(raw.get("last_known_size", 0)),
                grace_seconds=int(raw.get("grace_seconds", GRACE_PERIOD_SECONDS)),
            )
        except (OSError, KeyError, ValueError, json.JSONDecodeError):
            return None  # corrupted cache, treat as missing

    def store(self, entry: TierCacheEntry) -> None:
        payload = {
            "account_id": entry.account_id,
            "tier": entry.tier,
            "checked_at": entry.checked_at,
            "cap_bytes": entry.cap_bytes,
            "last_known_size": entry.last_known_size,
            "grace_seconds": entry.grace_seconds,
        }
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(self.path)

    def clear(self) -> None:
        if self.path.exists():
            self.path.unlink()


# ----------------------------------------------------------------------
# Server check
# ----------------------------------------------------------------------

def _default_check_write_fn(
    url: str,
    payload: dict[str, Any],
    timeout: float = HTTP_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Default network transport for the check-write call.

    Pure stdlib (urllib) to keep the SDK zero-dependency. If the call
    fails (timeout, network error, non-2xx), raises TierVerificationError.
    Callers can pass in a custom fn for testing or for using their own
    HTTP client.
    """
    import urllib.request
    import urllib.error
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "sibyl-memory-client/0.3.0",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        # Try to parse error JSON for clean upgrade URL
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {}
        return {
            "ok": False,
            "error": body.get("error") or f"http_{e.code}",
            "tier": body.get("tier") or "free",
            "upgrade_url": body.get("upgrade_url") or DEFAULT_UPGRADE_URL,
        }
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise TierVerificationError(
            f"Could not reach Sibyl Labs to verify your account: {e}",
        )


# ----------------------------------------------------------------------
# Cap gate
# ----------------------------------------------------------------------

class CapGate:
    """Orchestrates the cap check across the SDK write paths.

    Args:
        account_id: the account_id from credentials.json (None for
            unactivated users; the gate behaves as free tier with no
            server check capability)
        session_token: bearer token sent with the check-write call
        db_size_fn: callable returning the current SQLite db size in bytes
        local_tier_hint: initial tier from credentials.json (advisory; the
            server's answer always wins when we have one)
        cache: TierCache instance (defaults to ~/.sibyl-memory/tier_cache.json)
        check_url: full URL to the check-write endpoint
        check_fn: pluggable transport (default: stdlib urllib)
    """

    def __init__(
        self,
        *,
        account_id: str | None,
        session_token: str | None,
        db_size_fn: Callable[[], int],
        local_tier_hint: str = "free",
        cache: TierCache | None = None,
        check_url: str = DEFAULT_CHECK_WRITE_URL,
        check_fn: Callable[..., dict[str, Any]] | None = None,
        cap_bytes: int = FREE_TIER_CAP_BYTES,
    ) -> None:
        self.account_id = account_id
        self.session_token = session_token
        self._db_size_fn = db_size_fn
        self._local_hint = local_tier_hint
        self._cache = cache if cache is not None else TierCache()
        self._check_url = check_url
        self._check_fn = check_fn or _default_check_write_fn
        self._cap = cap_bytes

    # ------------------------------------------------------------------
    # Public entry point — called by every write path
    # ------------------------------------------------------------------
    def check(self, proposed_delta_bytes: int = 0) -> None:
        """Verify that the proposed write is permitted. Raises
        CapExceededError if not."""
        # Fast path 1: locally hinted as paid AND we have a fresh cache
        # that agrees → allow without network.
        cached = self._cache.load()
        if cached and cached.is_fresh and cached.account_id == self.account_id:
            if cached.cap_bytes is None:
                # Cached as paid (uncapped) within grace window — allow
                return
            # Cached as free with a cap. Enforce locally.
            new_size = self._db_size_fn() + proposed_delta_bytes
            if new_size <= cached.cap_bytes:
                return
            # Over the cached cap. Try to refresh (user may have upgraded).
            return self._refresh_and_check(proposed_delta_bytes)

        # No fresh cache. Use the credentials.json hint as a fast path
        # for the "obviously under cap" case to avoid a server call for
        # every brand-new user's first writes.
        current = self._db_size_fn()
        new_size = current + proposed_delta_bytes
        if self._local_hint in PAID_TIERS:
            # Credentials say paid; verify with server then cache the result.
            # If user genuinely paid: server confirms, we cache, done. If
            # credentials are tampered: server says free, we cache, enforce.
            return self._refresh_and_check(proposed_delta_bytes)
        if new_size <= self._cap:
            # Free + under cap. Trust the credentials hint, no server call.
            return
        # Free + at/past cap → must call server.
        return self._refresh_and_check(proposed_delta_bytes)

    # ------------------------------------------------------------------
    # Network refresh
    # ------------------------------------------------------------------
    def _refresh_and_check(self, proposed_delta_bytes: int) -> None:
        if not self.account_id or not self.session_token:
            # Pre-activation user trying to write past the cap. They never
            # had a binding; we can't verify a tier they don't have.
            current = self._db_size_fn()
            new_size = current + proposed_delta_bytes
            if new_size <= self._cap:
                return
            raise CapExceededError(
                "You're at the 2 MB free-tier cap and your account isn't "
                "activated. Run `sibyl init` to activate, or stay under "
                "the cap.",
                current_size=current,
                cap=self._cap,
                proposed_delta=proposed_delta_bytes,
            )

        current = self._db_size_fn()
        payload = {
            "account_id": self.account_id,
            "session_token": self.session_token,
            "current_size_bytes": current,
            "proposed_delta_bytes": proposed_delta_bytes,
        }

        try:
            resp = self._check_fn(self._check_url, payload)
        except TierVerificationError:
            # Offline. Fall back to the most recent cache if we have one,
            # even if technically expired (within an extended grace window
            # of double the normal period — i.e., 14 days for tier=free).
            cached = self._cache.load()
            if cached and cached.account_id == self.account_id:
                age = time.time() - cached.checked_at
                if age < 2 * GRACE_PERIOD_SECONDS:
                    # Honor the cached result a bit longer for honest
                    # offline users.
                    if cached.cap_bytes is None:
                        return
                    new_size = current + proposed_delta_bytes
                    if new_size <= cached.cap_bytes:
                        return
            raise  # re-raise TierVerificationError; SDK will surface to caller

        # Got a response. Update the cache.
        ok = bool(resp.get("ok"))
        tier = resp.get("tier", "free")
        cap_bytes = resp.get("cap_bytes") if "cap_bytes" in resp else (
            None if tier in PAID_TIERS else self._cap
        )
        entry = TierCacheEntry(
            account_id=self.account_id,
            tier=tier,
            checked_at=time.time(),
            cap_bytes=cap_bytes,
            last_known_size=current,
        )
        self._cache.store(entry)

        if ok:
            return  # server permitted the write
        # Server rejected — typically free tier over cap.
        raise CapExceededError(
            f"Your {tier} tier doesn't permit this write. "
            f"Current memory size: {current / 1024:.1f} KB. "
            f"Cap: {(cap_bytes or self._cap) / 1024:.1f} KB.",
            current_size=current,
            cap=cap_bytes or self._cap,
            proposed_delta=proposed_delta_bytes,
            upgrade_url=resp.get("upgrade_url", DEFAULT_UPGRADE_URL),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def invalidate_cache(self) -> None:
        """Forget any cached tier result. Next write at the cap will refetch."""
        self._cache.clear()

    def current_cap(self) -> int | None:
        """Return the current effective cap. None = uncapped."""
        cached = self._cache.load()
        if cached and cached.is_fresh:
            return cached.cap_bytes
        if self._local_hint in PAID_TIERS:
            return None
        return self._cap
