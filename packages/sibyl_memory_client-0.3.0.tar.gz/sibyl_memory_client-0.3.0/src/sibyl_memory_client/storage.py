"""SQLite storage layer for sibyl-memory-client.

Opens a per-tenant local SQLite database, applies the canonical schema, and
exposes a connection helper plus low-level row IO. Thread-local connection
pool keeps things simple for v1; we revisit if/when concurrent agent
workloads emerge.

Design notes:
- WAL mode for concurrent reads + single writer (default for v1, matches
  the local-first single-agent workload).
- foreign_keys = ON enforced at connection time.
- Schema applied on first open; idempotent via CREATE IF NOT EXISTS.
- ISO 8601 UTC timestamps everywhere (`strftime('%Y-%m-%dT%H:%M:%fZ','now')`).
- All JSON validated at write time via sqlite json_valid() CHECK constraints.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator
from uuid import uuid4

from .exceptions import SchemaError, StorageError

_SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def _utc_now_iso() -> str:
    """Return current UTC time in ISO 8601 microsecond-precision format.

    Higher precision than the schema's millisecond default (`%f` in
    SQLite's strftime) reduces ts collisions when multiple writes land in
    the same millisecond. Microsecond-precision strings sort correctly
    lexically since the format is fixed-width."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def new_id() -> str:
    """Generate a fresh UUID v4 string for primary keys."""
    return str(uuid4())


def dumps(payload: Any) -> str:
    """Canonical JSON serialization for body / payload fields.
    sort_keys=False (preserve insertion order — matters for downstream diff).
    separators tight to keep DB rows compact."""
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)


def loads(blob: str | None) -> Any:
    """Inverse of dumps(). Returns None for None input (matches nullable
    JSONB column semantics)."""
    if blob is None:
        return None
    return json.loads(blob)


class Storage:
    """SQLite connection wrapper with schema bootstrap + transaction helpers."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path).expanduser().resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # Per-instance thread-local cache (avoids leaking connections across
        # Storage instances pointing at different files).
        self._tls = threading.local()
        # Bootstrap schema on first open (idempotent)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        """Open a fresh connection. Callers should prefer connection() context
        manager for proper cleanup."""
        try:
            conn = sqlite3.connect(
                str(self.db_path),
                isolation_level=None,  # autocommit; we manage transactions explicitly
                check_same_thread=False,
                detect_types=0,
            )
        except sqlite3.Error as e:
            raise StorageError(
                f"Could not open SQLite at {self.db_path}: {e}",
                recovery="Check disk space, file permissions, and that no other process holds an exclusive lock.",
            ) from e

        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")  # safe with WAL, faster than FULL
        conn.execute("PRAGMA busy_timeout = 5000")  # 5s before SQLITE_BUSY
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        """Context manager that yields a per-instance, thread-local connection.
        Connection stays open across calls for performance; cleanup happens at
        Storage.close() or at process exit."""
        conn = getattr(self._tls, "conn", None)
        if conn is None:
            conn = self._connect()
            self._tls.conn = conn
        try:
            yield conn
        except sqlite3.Error as e:
            raise StorageError(
                f"SQLite error: {e}",
                recovery="See exception cause; consider checking schema version and disk health.",
            ) from e

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Atomic transaction. Rolls back on exception, commits on clean exit."""
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except Exception:
                conn.execute("ROLLBACK")
                raise
            else:
                conn.execute("COMMIT")

    def _ensure_schema(self) -> None:
        """Apply the canonical schema. Idempotent — safe to call on every open."""
        if not _SCHEMA_PATH.exists():
            raise SchemaError(
                f"Schema file missing at {_SCHEMA_PATH}",
                recovery="The package install is corrupted. Reinstall sibyl-memory-client.",
            )
        sql = _SCHEMA_PATH.read_text(encoding="utf-8")
        with self.connection() as conn:
            try:
                conn.executescript(sql)
            except sqlite3.Error as e:
                raise SchemaError(
                    f"Failed to apply schema: {e}",
                    recovery="Check sqlite3 version (need 3.38+ for json_valid). On older systems, upgrade.",
                ) from e

    def schema_version(self) -> int | None:
        """Return current schema version, or None if uninitialized."""
        with self.connection() as conn:
            row = conn.execute(
                "SELECT MAX(version) AS v FROM sibyl_memory_schema_version"
            ).fetchone()
            return row["v"] if row else None

    def close(self) -> None:
        """Close the thread-local connection (mainly for tests / shutdown)."""
        conn = getattr(self._tls, "conn", None)
        if conn is not None:
            conn.close()
            self._tls.conn = None
