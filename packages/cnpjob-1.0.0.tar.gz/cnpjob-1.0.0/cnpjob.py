import requests

class CNPJob:
    """
    CNPJob SDK — Python
    
    Exemplo de uso:
    client = CNPJob('sua_api_key')
    data = client.lookup('00.000.000/0001-91')
    """
    def __init__(self, api_key, base_url='https://api.cnpjob.com.br/api'):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json'
        })

    def _request(self, method, path, **kwargs):
        url = f"{self.base_url}{path}"
        response = self.session.request(method, url, **kwargs)
        
        if not response.ok:
            try:
                error_msg = response.json().get('error', 'Erro desconhecido')
            except:
                error_msg = f"HTTP {response.status_code}"
            raise Exception(error_msg)
            
        return response.json()

    def lookup(self, cnpj):
        clean_cnpj = "".join(filter(str.isdigit, cnpj))
        return self._request('GET', f'/cnpj/{clean_cnpj}')

    def batch(self, cnpjs):
        return self._request('POST', '/cnpj/batch', json={'cnpjs': cnpjs})

    def validate(self, cnpj):
        clean_cnpj = "".join(filter(str.isdigit, cnpj))
        return self._request('GET', f'/cnpj/validate/{clean_cnpj}')
