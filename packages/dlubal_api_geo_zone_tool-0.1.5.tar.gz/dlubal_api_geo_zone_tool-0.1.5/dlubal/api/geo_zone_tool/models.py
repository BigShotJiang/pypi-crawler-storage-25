from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GeoLocation:
    altitude: str
    latitude: str
    longitude: str
    display_name: str | None = None
    street: str | None = None
    zip: str | None = None
    city: str | None = None
    country: str | None = None
    state: str | None = None
    country_code: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "GeoLocation":
        return GeoLocation(
            altitude=str(data.get("altitude", "")),
            latitude=str(data.get("latitude", "")),
            longitude=str(data.get("longitude", "")),
            display_name=data.get("displayName"),
            street=data.get("street"),
            zip=data.get("zip"),
            city=data.get("city"),
            country=data.get("country"),
            state=data.get("state"),
            country_code=data.get("countryCode"),
        )


@dataclass(frozen=True)
class GeoLocations:
    locations: list[GeoLocation]


@dataclass(frozen=True)
class UserData:
    email: str
    clicks: int

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "UserData":
        return UserData(
            email=str(data.get("email", "")),
            clicks=int(data.get("clicks", 0)),
        )


@dataclass(frozen=True)
class LoadZoneLayerShortType:
    id: int
    name: str | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadZoneLayerShortType":
        return LoadZoneLayerShortType(
            id=int(data.get("id", 0)),
            name=data.get("name") or data.get("layerName"),
        )


@dataclass(frozen=True)
class StandardType:
    id: int
    name: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "StandardType":
        return StandardType(
            id=int(data.get("id", 0)),
            name=str(data.get("name", "")),
        )


@dataclass(frozen=True)
class AnnexType:
    id: int
    name: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "AnnexType":
        return AnnexType(
            id=int(data.get("id", 0)),
            name=str(data.get("name", "")),
        )


@dataclass(frozen=True)
class AnnexPublicType:
    id: int
    name: str
    actual: bool
    layers: list[LoadZoneLayerShortType]

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "AnnexPublicType":
        return AnnexPublicType(
            id=int(data.get("id", 0)),
            name=str(data.get("name", "")),
            actual=bool(data.get("actual", False)),
            layers=[
                LoadZoneLayerShortType.from_dict(item)
                for item in data.get("layers", [])
            ],
        )


@dataclass(frozen=True)
class LoadZoneStandardItemType:
    standard: StandardType
    annex: AnnexPublicType
    load_zone_id: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadZoneStandardItemType":
        return LoadZoneStandardItemType(
            standard=StandardType.from_dict(data.get("standard") or {}),
            annex=AnnexPublicType.from_dict(data.get("annex") or {}),
            load_zone_id=str(data.get("loadzoneId", "")),
        )


@dataclass(frozen=True)
class LoadZoneStandardTypeGroupType:
    name: str
    load_zones: list[LoadZoneStandardItemType]

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadZoneStandardTypeGroupType":
        return LoadZoneStandardTypeGroupType(
            name=str(data.get("name", "")),
            load_zones=[
                LoadZoneStandardItemType.from_dict(item)
                for item in data.get("loadzones", [])
            ],
        )


@dataclass(frozen=True)
class LoadZoneStandardsResponseType:
    country: str
    country_code: str
    type_groups: list[LoadZoneStandardTypeGroupType]

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadZoneStandardsResponseType":
        return LoadZoneStandardsResponseType(
            country=str(data.get("country", "")),
            country_code=str(data.get("countryCode", "")),
            type_groups=[
                LoadZoneStandardTypeGroupType.from_dict(item)
                for item in data.get("typeGroups", [])
            ],
        )


@dataclass(frozen=True)
class CharacteristicsZoneType:
    value: str
    id: int | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsZoneType":
        return CharacteristicsZoneType(
            id=int(data["id"]) if data.get("id") is not None else None,
            value=str(data.get("value", "")),
        )


@dataclass(frozen=True)
class CharacteristicsVariableType:
    name: str
    calculated_value: str | None
    name_html: str
    units_html: str
    description: str
    decimal_places: int
    sequence: int

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsVariableType":
        return CharacteristicsVariableType(
            name=str(data.get("name", "")),
            calculated_value=data.get("calculatedValue"),
            name_html=str(data.get("nameHtml", "")),
            units_html=str(data.get("unitsHtml", "")),
            description=str(data.get("description", "")),
            decimal_places=int(data.get("decimalPlaces", 0)),
            sequence=int(data.get("sequence", 0)),
        )


@dataclass(frozen=True)
class CharacteristicsLayerType:
    id: int
    zone: CharacteristicsZoneType
    characteristics: list[CharacteristicsVariableType]
    loadzone_id: str | None = None
    standard: StandardType | None = None
    annex: AnnexType | None = None
    layer_id: int | None = None
    notes: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsLayerType":
        layer_id = data.get("id", data.get("layerId", 0))
        standard_data = data.get("standard")
        annex_data = data.get("annex")
        return CharacteristicsLayerType(
            id=int(layer_id),
            zone=CharacteristicsZoneType.from_dict(data.get("zone") or {}),
            characteristics=[
                CharacteristicsVariableType.from_dict(item)
                for item in data.get("characteristics", [])
            ],
            loadzone_id=(
                str(data.get("loadzoneId", ""))
                if data.get("loadzoneId") is not None
                else None
            ),
            standard=(
                StandardType.from_dict(standard_data) if standard_data else None
            ),
            annex=AnnexType.from_dict(annex_data) if annex_data else None,
            layer_id=int(data["layerId"]) if data.get("layerId") is not None else None,
            notes=data.get("notes"),
        )


@dataclass(frozen=True)
class CharacteristicsLoadzoneType2:
    standard: str
    annex: str
    zone_characteristics: CharacteristicsLayerType
    loadzone_id: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsLoadzoneType2":
        return CharacteristicsLoadzoneType2(
            standard=str(data.get("standard", "")),
            annex=str(data.get("annex", "")),
            zone_characteristics=CharacteristicsLayerType.from_dict(
                data.get("zoneCharacteristics") or {}
            ),
            loadzone_id=(
                str(data.get("loadzoneId", ""))
                if data.get("loadzoneId") is not None
                else None
            ),
        )


@dataclass(frozen=True)
class CharacteristicsResponseMiaType:
    code: str
    message: str | None
    geo_location: GeoLocation | None
    characteristics: list[CharacteristicsLoadzoneType2]
    no_liability: str | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsResponseMiaType":
        geo = data.get("geoLocation")
        return CharacteristicsResponseMiaType(
            code=str(data.get("code", "")),
            message=data.get("message"),
            geo_location=GeoLocation.from_dict(geo) if geo else None,
            characteristics=[
                CharacteristicsLoadzoneType2.from_dict(item)
                for item in data.get("characteristics", [])
            ],
            no_liability=data.get("noLiability"),
        )


@dataclass(frozen=True)
class SpectrumType:
    periods: list[float]
    ordinates: list[float]
    warning: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "SpectrumType":
        return SpectrumType(
            periods=[float(v) for v in data.get("periods") or []],
            ordinates=[float(v) for v in data.get("ordinates") or []],
            warning=data.get("warning"),
        )


@dataclass(frozen=True)
class Asce722UnderlyingDataType:
    pgauh: float | None
    pgauh_warning: str | None
    pga84th: float | None
    pga84th_warning: str | None
    risk_targeted_spectrum: SpectrumType | None
    eighty_fourth_spectrum: SpectrumType | None
    dll_spectrum: SpectrumType | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Asce722UnderlyingDataType":
        return Asce722UnderlyingDataType(
            pgauh=float(data["pgauh"]) if data.get("pgauh") is not None else None,
            pgauh_warning=data.get("pgauhWarning"),
            pga84th=(
                float(data["pga84th"]) if data.get("pga84th") is not None else None
            ),
            pga84th_warning=data.get("pga84thWarning"),
            risk_targeted_spectrum=(
                SpectrumType.from_dict(data["riskTargetedSpectrum"])
                if data.get("riskTargetedSpectrum")
                else None
            ),
            eighty_fourth_spectrum=(
                SpectrumType.from_dict(data["eightyFourthSpectrum"])
                if data.get("eightyFourthSpectrum")
                else None
            ),
            dll_spectrum=(
                SpectrumType.from_dict(data["dllSpectrum"])
                if data.get("dllSpectrum")
                else None
            ),
        )


@dataclass(frozen=True)
class Asce722MetadataType:
    model_version: str | None
    vs30: float | None
    science_base_url: str | None
    spatial_interpolation_method: str | None
    pgad_floor: float | None
    pgad_percentile_factor: float | None
    sad_floor: SpectrumType | None
    sad_percentile_factor: SpectrumType | None
    max_direction_factor: SpectrumType | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Asce722MetadataType":
        return Asce722MetadataType(
            model_version=data.get("modelVersion"),
            vs30=float(data["vs30"]) if data.get("vs30") is not None else None,
            science_base_url=data.get("scienceBaseUrl"),
            spatial_interpolation_method=data.get("spatialInterpolationMethod"),
            pgad_floor=float(data["pgadFloor"]) if data.get("pgadFloor") is not None else None,
            pgad_percentile_factor=(
                float(data["pgadPercentileFactor"])
                if data.get("pgadPercentileFactor") is not None
                else None
            ),
            sad_floor=(
                SpectrumType.from_dict(data["sadFloor"]) if data.get("sadFloor") else None
            ),
            sad_percentile_factor=(
                SpectrumType.from_dict(data["sadPercentileFactor"])
                if data.get("sadPercentileFactor")
                else None
            ),
            max_direction_factor=(
                SpectrumType.from_dict(data["maxDirectionFactor"])
                if data.get("maxDirectionFactor")
                else None
            ),
        )


@dataclass(frozen=True)
class Asce722DataType:
    pgam: float | None
    sms: float | None
    sm1: float | None
    sds: float | None
    sd1: float | None
    sdc: str | None
    ss: float | None
    s1: float | None
    ts: float | None
    t0: float | None
    tl: float | None
    cv: float | None
    multi_period_design_spectrum: SpectrumType | None
    multi_period_mc_er_spectrum: SpectrumType | None
    two_period_design_spectrum: SpectrumType | None
    two_period_mc_er_spectrum: SpectrumType | None
    vertical_design_spectrum: SpectrumType | None
    vertical_mc_er_spectrum: SpectrumType | None
    underlying_data: Asce722UnderlyingDataType | None
    metadata: Asce722MetadataType | None

    @staticmethod
    def _float(data: dict[str, Any], key: str) -> float | None:
        v = data.get(key)
        return float(v) if v is not None else None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Asce722DataType":
        _f = Asce722DataType._float
        return Asce722DataType(
            pgam=_f(data, "pgam"),
            sms=_f(data, "sms"),
            sm1=_f(data, "sm1"),
            sds=_f(data, "sds"),
            sd1=_f(data, "sd1"),
            sdc=data.get("sdc"),
            ss=_f(data, "ss"),
            s1=_f(data, "s1"),
            ts=_f(data, "ts"),
            t0=_f(data, "t0"),
            tl=_f(data, "tl"),
            cv=_f(data, "cv"),
            multi_period_design_spectrum=(
                SpectrumType.from_dict(data["multiPeriodDesignSpectrum"])
                if data.get("multiPeriodDesignSpectrum")
                else None
            ),
            multi_period_mc_er_spectrum=(
                SpectrumType.from_dict(data["multiPeriodMcErSpectrum"])
                if data.get("multiPeriodMcErSpectrum")
                else None
            ),
            two_period_design_spectrum=(
                SpectrumType.from_dict(data["twoPeriodDesignSpectrum"])
                if data.get("twoPeriodDesignSpectrum")
                else None
            ),
            two_period_mc_er_spectrum=(
                SpectrumType.from_dict(data["twoPeriodMcErSpectrum"])
                if data.get("twoPeriodMcErSpectrum")
                else None
            ),
            vertical_design_spectrum=(
                SpectrumType.from_dict(data["verticalDesignSpectrum"])
                if data.get("verticalDesignSpectrum")
                else None
            ),
            vertical_mc_er_spectrum=(
                SpectrumType.from_dict(data["verticalMcErSpectrum"])
                if data.get("verticalMcErSpectrum")
                else None
            ),
            underlying_data=(
                Asce722UnderlyingDataType.from_dict(data["underlyingData"])
                if data.get("underlyingData")
                else None
            ),
            metadata=(
                Asce722MetadataType.from_dict(data["metadata"])
                if data.get("metadata")
                else None
            ),
        )


@dataclass(frozen=True)
class Asce722ResponseType:
    code: str
    message: str | None
    reference_document: str | None
    data: Asce722DataType | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Asce722ResponseType":
        asce_data = data.get("data")
        return Asce722ResponseType(
            code=str(data.get("code", "")),
            message=data.get("message"),
            reference_document=data.get("referenceDocument"),
            data=Asce722DataType.from_dict(asce_data) if asce_data else None,
        )


@dataclass(frozen=True)
class Screenshot:
    screenshot: str


@dataclass(frozen=True)
class PdfResultType:
    name: str
    pdf: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "PdfResultType":
        return PdfResultType(
            name=str(data.get("name", "")),
            pdf=str(data.get("pdf", "")),
        )


@dataclass(frozen=True)
class PdfProgressType:
    message: str
    current_step: int
    steps: int
    pdf_result: PdfResultType | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "PdfProgressType":
        pdf_result = data.get("pdfResult")
        return PdfProgressType(
            message=str(data.get("message", "")),
            current_step=int(data.get("currentStep", 0)),
            steps=int(data.get("steps", 0)),
            pdf_result=PdfResultType.from_dict(pdf_result) if pdf_result else None,
        )
