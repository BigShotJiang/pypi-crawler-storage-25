from datetime import datetime, timezone
from threading import Lock
from typing import Any

import base64
import hashlib
import json
import logging
import math
import os
import secrets
import time

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from matriosha.core.binary_protocol import decode_envelope, envelope_from_json
from matriosha.core.interpreter import decode_semantic_content
from matriosha.core.managed.auth import (
    DATA_KEY_LEN,
    _unwrap_local_blob,
    _wrap_data_key_locally,
    generate_salt,
)

logger = logging.getLogger(__name__)

app = FastAPI()

AGENTS_PER_PACK = 3
BYTES_PER_GB = 1024**3
STORAGE_GB_PER_PACK = 3
VECTOR_DIM = 384
ACTIVE_SUBSCRIPTION_STATUSES = {"active", "trialing"}
MANAGED_CANDIDATE_LIMIT_MIN = 50
MANAGED_CANDIDATE_LIMIT_MAX = 200
MANAGED_CANDIDATE_LIMIT_SCALE_BASE = 1000


def _scaled_managed_candidate_limit(
    memory_count: int, *, minimum: int = MANAGED_CANDIDATE_LIMIT_MIN
) -> int:
    count = max(int(memory_count), 0)
    if count <= MANAGED_CANDIDATE_LIMIT_SCALE_BASE:
        return minimum
    scaled = math.ceil(minimum * math.sqrt(count / MANAGED_CANDIDATE_LIMIT_SCALE_BASE))
    return min(MANAGED_CANDIDATE_LIMIT_MAX, max(minimum, scaled))


_OTP_RATE_LIMIT_WINDOW_SECONDS = int(os.getenv("OTP_RATE_LIMIT_WINDOW_SECONDS", "300"))
_OTP_RATE_LIMIT_START_MAX = int(os.getenv("OTP_RATE_LIMIT_START_MAX", "6"))
_OTP_RATE_LIMIT_VERIFY_MAX = int(os.getenv("OTP_RATE_LIMIT_VERIFY_MAX", "10"))
_otp_rate_limit_state: dict[str, list[float]] = {}
_otp_rate_limit_lock = Lock()

cors_origins = [
    origin.strip() for origin in os.getenv("CORS_ALLOWED_ORIGINS", "").split(",") if origin.strip()
]
if not cors_origins:
    cors_origins = ["https://matriosha.ai", "https://app.matriosha.ai"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Admin-Token"],
)

# Required billing environment variables for managed mode routes:
# - STRIPE_PRICE_ID_BASE: Stripe recurring price id for the base €9/month plan.
# - STRIPE_SUCCESS_URL: Redirect URL after successful Stripe checkout.
# - STRIPE_CANCEL_URL: Redirect URL after canceled Stripe checkout.
# Existing required Stripe env vars:
# - STRIPE_SECRET_KEY
# - STRIPE_WEBHOOK_SECRET


class OtpStartRequest(BaseModel):
    email: str


class OtpVerifyRequest(BaseModel):
    email: str
    code: str


class RefreshRequest(BaseModel):
    refresh_token: str


class VaultCustodyRequest(BaseModel):
    action: str
    kdf_salt_b64: str | None = None
    wrapped_key_b64: str | None = None
    managed_custody_data_key_b64: str | None = None
    algo: str | None = None


class BillingCheckoutRequest(BaseModel):
    plan: str = "eur_monthly"
    quantity: int = 1


class BillingQuantityUpdateRequest(BaseModel):
    quantity: int = Field(ge=1)


class ManagedMemoryCreateRequest(BaseModel):
    envelope: dict[str, Any]
    payload_b64: str
    embedding: list[float] | None = None
    metadata_hashes: list[str] | None = None


class ManagedMemoryBulkCreateRequest(BaseModel):
    items: list[ManagedMemoryCreateRequest] = Field(
        default_factory=list, min_length=1, max_length=100
    )


class ManagedSearchRequest(BaseModel):
    query: str | None = None
    embedding: list[float] | None = None
    limit: int | None = Field(default=None, ge=1, le=200)
    k: int | None = Field(default=None, ge=1, le=200)
    tags: list[str] | None = None
    search_keywords: list[str] | None = None
    metadata_hashes: list[str] | None = None
    candidate_only: bool = False


class ManagedAgentRecallRequest(BaseModel):
    memory_ids: list[str]
    k: int | None = Field(default=5, ge=1, le=200)
    managed_passphrase: str | None = None


class ManagedAgentTokenCreateRequest(BaseModel):
    name: str
    scope: str = "write"
    expires_at: str | None = None
    managed_passphrase: str | None = None


class ManagedAgentConnectRequest(BaseModel):
    name: str
    agent_kind: str = "desktop"


def _normalize_email(email: str) -> str:
    normalized = email.strip().lower()
    if not normalized or "@" not in normalized or "." not in normalized.rsplit("@", 1)[-1]:
        raise HTTPException(status_code=400, detail="valid email is required")
    return normalized


def _apply_otp_rate_limit(*, bucket: str, key: str, max_attempts: int) -> None:
    now = time.time()
    rate_key = f"{bucket}:{key}"
    with _otp_rate_limit_lock:
        history = _otp_rate_limit_state.get(rate_key, [])
        history = [ts for ts in history if now - ts <= _OTP_RATE_LIMIT_WINDOW_SECONDS]
        if len(history) >= max_attempts:
            retry_after = max(1, int(_OTP_RATE_LIMIT_WINDOW_SECONDS - (now - history[0])))
            raise HTTPException(
                status_code=429,
                detail=(f"too many {bucket} attempts. retry in about {retry_after} seconds"),
                headers={"Retry-After": str(retry_after)},
            )
        history.append(now)
        _otp_rate_limit_state[rate_key] = history


def _bytea_to_bytes(value) -> bytes:
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, str):
        if value.startswith("\\x"):
            return bytes.fromhex(value[2:])
        return value.encode("utf-8")
    raise HTTPException(status_code=500, detail="stored key material has unsupported shape")


def _vault_key_secret_name(user_id: str) -> str:
    return f"matriosha/vault-keys/{user_id}"


def _vault_secret_payload(
    *,
    kdf_salt_b64: str,
    wrapped_key_b64: str,
    managed_custody_data_key_b64: str | None = None,
) -> str:
    payload = {
        "kdf_salt_b64": kdf_salt_b64,
        "wrapped_key_b64": wrapped_key_b64,
    }
    if managed_custody_data_key_b64:
        payload["managed_custody_data_key_b64"] = managed_custody_data_key_b64
    return json.dumps(payload, separators=(",", ":"))


def _read_vault_secret_payload(db: Any, secret_name: str) -> dict[str, Any]:
    result = db.rpc("matriosha_vault_read_key_secret", {"secret_name": secret_name}).execute()
    raw = getattr(result, "data", None)
    if not isinstance(raw, str) or not raw:
        raise HTTPException(status_code=404, detail="managed vault secret not found")
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=500, detail="managed vault secret payload is invalid"
        ) from exc
    if not isinstance(payload, dict):
        raise HTTPException(
            status_code=500, detail="managed vault secret payload has invalid shape"
        )
    return payload


def _upsert_vault_secret_payload(db: Any, *, secret_name: str, payload: str) -> None:
    db.rpc(
        "matriosha_vault_upsert_key_secret",
        {
            "secret_name": secret_name,
            "secret_payload": payload,
        },
    ).execute()


def _require_env(name: str, *, purpose: str) -> str:
    value = os.getenv(name)
    if value:
        return value
    raise HTTPException(
        status_code=503,
        detail=f"{name} is not configured. {purpose}",
    )


def require_admin_token(x_admin_token: str | None = Header(default=None)) -> None:
    expected = os.getenv("ADMIN_DIAGNOSTICS_TOKEN") or os.getenv("ADMIN_TOKEN")
    if not expected:
        raise HTTPException(status_code=503, detail="admin diagnostics token not configured")
    if x_admin_token != expected:
        raise HTTPException(status_code=404, detail="not found")


def _create_supabase_client(url: str, key: str):
    from supabase import create_client

    try:
        from supabase import ClientOptions

        return create_client(
            url,
            key,
            options=ClientOptions(
                postgrest_client_timeout=10,
                storage_client_timeout=10,
                schema="public",
            ),
        )
    except (ImportError, TypeError):
        return create_client(url, key)


def _supabase_anon_client():
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_ANON_KEY")
    if not url or not key:
        raise HTTPException(status_code=503, detail="supabase auth is not configured")
    return _create_supabase_client(url, key)


def _supabase_service_client():
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
    if not url or not key:
        raise HTTPException(status_code=503, detail="supabase service role is not configured")
    return _create_supabase_client(url, key)


def _ensure_public_user(user_id: str) -> None:
    db = _supabase_service_client()
    db.table("users").upsert({"id": user_id}, on_conflict="id").execute()


def _bearer_token(authorization: str | None) -> str:
    if not authorization:
        raise HTTPException(status_code=401, detail="missing authorization header")
    scheme, _, token = authorization.partition(" ")
    token = token.strip()
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=401, detail="invalid authorization header")
    return token


def _get_authenticated_user(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    token = _bearer_token(authorization)
    client = _supabase_anon_client()
    try:
        result = client.auth.get_user(token)
    except Exception as exc:
        raise HTTPException(
            status_code=401, detail=f"invalid session: {exc.__class__.__name__}"
        ) from exc

    user = getattr(result, "user", None)
    if not user:
        raise HTTPException(status_code=401, detail="invalid session")

    user_id = getattr(user, "id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="invalid session")

    user_id = str(user_id)
    _ensure_public_user(user_id)
    return {
        "user_id": user_id,
        "email": getattr(user, "email", None),
        "aud": getattr(user, "aud", None),
        "role": getattr(user, "role", None),
    }


def _quantity_to_agent_quota(quantity: int | None) -> int:
    try:
        q = int(quantity or 1)
    except Exception:
        q = 1
    if q <= 0:
        q = 1
    return AGENTS_PER_PACK * q


def _quantity_to_storage_cap_bytes(quantity: int | None) -> int:
    try:
        q = int(quantity or 1)
    except Exception:
        q = 1
    if q <= 0:
        q = 1
    return STORAGE_GB_PER_PACK * BYTES_PER_GB * q


def _storage_quota_gb_from_bytes(storage_cap_bytes: int | None) -> float:
    cap = int(storage_cap_bytes or 0)
    if cap <= 0:
        return 0.0
    return round(cap / BYTES_PER_GB, 2)


def _timestamp_to_iso(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    return None


def _parse_datetime(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    return None


def _is_subscription_access_active(status: str, cancel_at: Any) -> bool:
    normalized = _normalize_subscription_status(status)
    cancel_at_dt = _parse_datetime(cancel_at)
    now = datetime.now(timezone.utc)

    if normalized in ACTIVE_SUBSCRIPTION_STATUSES:
        if cancel_at_dt and cancel_at_dt <= now:
            return False
        return True

    if normalized == "canceled" and cancel_at_dt and cancel_at_dt > now:
        return True

    return False


def _get_subscription_row_for_user(user_id: str) -> dict[str, Any] | None:
    db = _supabase_service_client()
    result = db.table("subscriptions").select("*").eq("user_id", user_id).limit(1).execute()
    rows = getattr(result, "data", None) or []
    if not rows:
        return None

    row = rows[0]
    status = _normalize_subscription_status(row.get("status"))
    cancel_at_dt = _parse_datetime(row.get("cancel_at"))
    if (
        status in ACTIVE_SUBSCRIPTION_STATUSES
        and cancel_at_dt
        and cancel_at_dt <= datetime.now(timezone.utc)
    ):
        db.table("subscriptions").update(
            {
                "status": "canceled",
                "updated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            }
        ).eq("user_id", user_id).execute()
        row["status"] = "canceled"
    return row


def _normalize_subscription_status(status: Any) -> str:
    value = str(status or "inactive").strip().lower()
    return value or "inactive"


def _subscription_row_to_entitlement(user_id: str, row: dict[str, Any] | None) -> dict[str, Any]:
    if not row:
        return {
            "user_id": user_id,
            "status": "inactive",
            "plan": "eur_monthly",
            "agent_quota": 0,
            "storage_cap_bytes": 0,
            "storage_used_bytes": 0,
            "storage_quota_gb": 0.0,
            "current_period_end": None,
            "cancel_at": None,
            "cancel_at_period_end": False,
            "stripe_customer_id": None,
            "stripe_subscription_id": None,
            "stripe_subscription_item_id": None,
            "is_active": False,
        }

    storage_cap_bytes = int(row.get("storage_cap_bytes") or 0)
    status = _normalize_subscription_status(row.get("status"))
    cancel_at = _timestamp_to_iso(row.get("cancel_at"))
    return {
        "user_id": user_id,
        "status": status,
        "plan": row.get("plan_code") or "eur_monthly",
        "agent_quota": int(row.get("agent_quota") or 0),
        "storage_cap_bytes": storage_cap_bytes,
        "storage_used_bytes": _safe_int(row.get("storage_used_bytes"), 0),
        "storage_quota_gb": _storage_quota_gb_from_bytes(storage_cap_bytes),
        "current_period_end": _timestamp_to_iso(row.get("current_period_end")),
        "cancel_at": cancel_at,
        "cancel_at_period_end": bool(cancel_at),
        "stripe_customer_id": row.get("stripe_customer_id"),
        "stripe_subscription_id": row.get("stripe_subscription_id"),
        "stripe_subscription_item_id": row.get("stripe_subscription_item_id"),
        "is_active": _is_subscription_access_active(status, cancel_at),
    }


def get_subscription_entitlement(
    auth_user: dict[str, Any] = Depends(_get_authenticated_user),
) -> dict[str, Any]:
    row = _get_subscription_row_for_user(auth_user["user_id"])
    entitlement = _subscription_row_to_entitlement(auth_user["user_id"], row)
    entitlement["email"] = auth_user.get("email")
    entitlement["aud"] = auth_user.get("aud")
    entitlement["role"] = auth_user.get("role")
    return entitlement


def require_active_subscription(
    entitlement: dict[str, Any] = Depends(get_subscription_entitlement),
) -> dict[str, Any]:
    if not bool(entitlement.get("is_active")):
        raise HTTPException(
            status_code=403,
            detail="Managed mode requires an active subscription. Run 'matriosha billing subscribe' to get started.",
        )
    return entitlement


def _get_active_subscription_entitlement_for_user(user_id: str) -> dict[str, Any]:
    row = _get_subscription_row_for_user(user_id)
    entitlement = _subscription_row_to_entitlement(user_id, row)
    if not bool(entitlement.get("is_active")):
        raise HTTPException(
            status_code=403,
            detail="Managed mode requires an active subscription. Run 'matriosha billing subscribe' to get started.",
        )
    return entitlement


def _get_agent_token_context(token: str) -> dict[str, Any]:
    if not token.startswith("mt_"):
        raise HTTPException(status_code=401, detail="invalid agent token")

    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    db = _supabase_service_client()
    result = db.table("agent_tokens").select("*").eq("token_hash", token_hash).limit(1).execute()
    rows = getattr(result, "data", None) or []
    if not rows:
        raise HTTPException(status_code=401, detail="invalid agent token")

    row = rows[0]
    if bool(row.get("revoked") or row.get("revoked_at")):
        raise HTTPException(status_code=401, detail="agent token revoked")

    expires_at = row.get("expires_at")
    if expires_at:
        expires_at_dt = _parse_datetime(expires_at)
        if expires_at_dt and expires_at_dt <= datetime.now(timezone.utc):
            raise HTTPException(status_code=401, detail="agent token expired")

    user_id = str(row.get("user_id") or "").strip()
    if not user_id:
        raise HTTPException(status_code=401, detail="agent token has no owner")

    try:
        db.table("agent_tokens").update(
            {"last_used": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}
        ).eq("id", row.get("id")).execute()
    except Exception:
        # Token usage telemetry should never break a valid request.
        pass

    return {
        "kind": "agent",
        "agent_token_id": row.get("id"),
        "agent_token_hash": token_hash,
        "agent_plaintext_token": token,
        "user_id": user_id,
        "scope": _normalize_scope(row.get("scope") or "write"),
        "name": row.get("name") or "agent",
    }


def require_active_managed_actor(
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    token = _bearer_token(authorization)

    if token.startswith("mt_"):
        actor = _get_agent_token_context(token)
        entitlement = _get_active_subscription_entitlement_for_user(actor["user_id"])
        entitlement["auth_kind"] = "agent"
        entitlement["agent_token_id"] = actor.get("agent_token_id")
        entitlement["agent_token_hash"] = actor.get("agent_token_hash")
        entitlement["agent_plaintext_token"] = actor.get("agent_plaintext_token")
        entitlement["agent_scope"] = actor.get("scope") or "write"
        entitlement["agent_name"] = actor.get("name")
        return entitlement

    auth_user = _get_authenticated_user(authorization)
    entitlement = _get_active_subscription_entitlement_for_user(auth_user["user_id"])
    entitlement["email"] = auth_user.get("email")
    entitlement["aud"] = auth_user.get("aud")
    entitlement["role"] = auth_user.get("role")
    entitlement["auth_kind"] = "user"
    return entitlement


def _require_agent_scope(entitlement: dict[str, Any], allowed_scopes: set[str]) -> None:
    if entitlement.get("auth_kind") != "agent":
        return

    scope = _normalize_scope(entitlement.get("agent_scope") or "write")
    if scope not in allowed_scopes:
        raise HTTPException(
            status_code=403, detail=f"agent token scope '{scope}' cannot perform this operation"
        )


def _require_active_subscription_for_user(user_id: str) -> None:
    row = _get_subscription_row_for_user(user_id)
    status = _normalize_subscription_status(row.get("status") if row else "inactive")
    cancel_at = row.get("cancel_at") if row else None
    if not _is_subscription_access_active(status, cancel_at):
        raise HTTPException(
            status_code=403,
            detail="Managed mode requires an active subscription. Run 'matriosha billing subscribe' to get started.",
        )


def _get_stripe_module():
    import stripe

    stripe.api_key = _require_env(
        "STRIPE_SECRET_KEY",
        purpose="Set your Stripe secret key to enable billing and webhook processing.",
    )
    return stripe


def _stripe_object_to_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value

    to_dict_recursive = getattr(value, "to_dict_recursive", None)
    if callable(to_dict_recursive):
        try:
            data = to_dict_recursive()
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    try:
        data = dict(value)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    return {}


def _subscription_item_from_subscription(subscription: dict[str, Any]) -> dict[str, Any] | None:
    items = (
        (((subscription.get("items") or {}).get("data")) or [])
        if isinstance(subscription.get("items"), dict)
        else []
    )
    first_item = items[0] if items else None
    return first_item if isinstance(first_item, dict) else None


def _extract_user_id_from_subscription_object(subscription: dict[str, Any]) -> str | None:
    metadata = subscription.get("metadata") if isinstance(subscription, dict) else None
    if isinstance(metadata, dict):
        for key in ("user_id", "userId", "matriosha_user_id"):
            value = metadata.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()

    return None


def _find_user_id_by_stripe_refs(
    *, stripe_customer_id: str | None, stripe_subscription_id: str | None
) -> str | None:
    db = _supabase_service_client()
    if stripe_subscription_id:
        result = (
            db.table("subscriptions")
            .select("user_id")
            .eq("stripe_subscription_id", stripe_subscription_id)
            .limit(1)
            .execute()
        )
        rows = getattr(result, "data", None) or []
        if rows:
            return str(rows[0].get("user_id"))

    if stripe_customer_id:
        result = (
            db.table("subscriptions")
            .select("user_id")
            .eq("stripe_customer_id", stripe_customer_id)
            .limit(1)
            .execute()
        )
        rows = getattr(result, "data", None) or []
        if rows:
            return str(rows[0].get("user_id"))

    return None


def _upsert_subscription_snapshot_from_stripe(
    subscription: dict[str, Any], *, override_status: str | None = None
) -> bool:
    if not isinstance(subscription, dict):
        return False

    stripe_subscription_id = subscription.get("id")
    stripe_customer_id = subscription.get("customer")

    user_id = _extract_user_id_from_subscription_object(
        subscription
    ) or _find_user_id_by_stripe_refs(
        stripe_customer_id=str(stripe_customer_id) if stripe_customer_id else None,
        stripe_subscription_id=str(stripe_subscription_id) if stripe_subscription_id else None,
    )
    if not user_id:
        return False

    items = (
        (((subscription.get("items") or {}).get("data")) or [])
        if isinstance(subscription.get("items"), dict)
        else []
    )
    first_item = items[0] if items else {}
    quantity = first_item.get("quantity") if isinstance(first_item, dict) else 1
    price = first_item.get("price") if isinstance(first_item, dict) else {}

    agent_quota = _quantity_to_agent_quota(quantity)
    storage_cap_bytes = _quantity_to_storage_cap_bytes(quantity)

    cancel_at_period_end = bool(subscription.get("cancel_at_period_end"))
    cancel_at_source = subscription.get("cancel_at")
    if cancel_at_period_end and cancel_at_source is None:
        cancel_at_source = subscription.get("current_period_end")
    cancel_at = _timestamp_to_iso(cancel_at_source)

    status = _normalize_subscription_status(override_status or subscription.get("status"))
    if cancel_at_period_end and status == "canceled":
        status = "active"
    current_period_end = _timestamp_to_iso(subscription.get("current_period_end"))

    row = {
        "user_id": user_id,
        "status": status,
        "current_period_end": current_period_end,
        "cancel_at": cancel_at,
        "stripe_customer_id": str(stripe_customer_id) if stripe_customer_id else None,
        "stripe_subscription_id": str(stripe_subscription_id) if stripe_subscription_id else None,
        "stripe_subscription_item_id": (
            first_item.get("id") if isinstance(first_item, dict) else None
        ),
        "plan_code": "eur_monthly",
        "unit_price_cents": int((price or {}).get("unit_amount") or 900),
        "agent_quota": agent_quota,
        "storage_cap_bytes": storage_cap_bytes,
    }

    _ensure_public_user(user_id)
    db = _supabase_service_client()
    db.table("subscriptions").upsert(row, on_conflict="user_id").execute()
    return True


def _update_subscription_status_by_refs(
    *, status: str, stripe_customer_id: str | None, stripe_subscription_id: str | None
) -> bool:
    user_id = _find_user_id_by_stripe_refs(
        stripe_customer_id=stripe_customer_id,
        stripe_subscription_id=stripe_subscription_id,
    )
    if not user_id:
        return False

    db = _supabase_service_client()
    db.table("subscriptions").update({"status": _normalize_subscription_status(status)}).eq(
        "user_id", user_id
    ).execute()
    return True


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _bytes_to_gb(value: int) -> float:
    return float(value) / float(BYTES_PER_GB)


def _format_storage_used_vs_cap(used_bytes: int, cap_bytes: int) -> str:
    return f"{_bytes_to_gb(used_bytes):.2f}/{_bytes_to_gb(cap_bytes):.2f} GB"


def _normalize_scope(scope: str) -> str:
    normalized = str(scope or "write").strip().lower()
    if normalized not in {"read", "write", "admin"}:
        raise HTTPException(status_code=400, detail="scope must be one of: read, write, admin")
    return normalized


def _extract_tags(envelope: dict[str, Any]) -> list[str]:
    tags = envelope.get("tags")
    if not isinstance(tags, list):
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in tags:
        if not isinstance(item, str):
            continue
        cleaned = item.strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        normalized.append(cleaned)
    return normalized


def _validate_embedding(embedding: list[float] | None) -> list[float] | None:
    if embedding is None:
        return None
    if len(embedding) != VECTOR_DIM:
        raise HTTPException(
            status_code=400, detail=f"embedding must contain exactly {VECTOR_DIM} float values"
        )

    normalized: list[float] = []
    for value in embedding:
        try:
            normalized.append(float(value))
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=400, detail="embedding must be a numeric float array"
            ) from exc
    return normalized


def _normalize_search_token(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip().lower()
    if not cleaned:
        return None
    return cleaned[:128]


def _metadata_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _safe_memory_metadata(envelope: dict[str, Any]) -> dict[str, Any]:
    allowed = {
        "memory_id",
        "mode",
        "encoding",
        "hash_algo",
        "merkle_root",
        "vector_dim",
        "created_at",
        "source",
        "filename",
        "mime_type",
        "content_kind",
        "plaintext_bytes",
    }
    safe: dict[str, Any] = {}
    for key in allowed:
        value = envelope.get(key)
        if value is None:
            continue
        if isinstance(value, (str, int, float, bool)):
            safe[key] = value
    tags = _extract_tags(envelope)
    if tags:
        safe["tags"] = tags
    return safe


def _search_keywords_from_envelope(envelope: dict[str, Any], tags: list[str]) -> list[str]:
    raw: list[Any] = list(tags)
    for key in ("filename", "mime_type", "content_kind", "source"):
        raw.append(envelope.get(key))

    filename = envelope.get("filename")
    if isinstance(filename, str) and "." in filename:
        raw.append(filename.rsplit(".", 1)[-1])

    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw:
        token = _normalize_search_token(item)
        if token is None or token in seen:
            continue
        seen.add(token)
        normalized.append(token)
    return normalized


def _metadata_hashes_from_keywords(keywords: list[str]) -> list[str]:
    return [_metadata_hash(keyword) for keyword in keywords]


def _clean_metadata_hashes(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str):
            continue
        cleaned = value.strip()
        if not cleaned or cleaned in seen:
            continue
        normalized.append(cleaned)
        seen.add(cleaned)
    return normalized


MANAGED_AGENT_RECALL_MAX_K = 5


def _managed_agent_recall_k(k: int | None) -> int:
    try:
        value = int(k or MANAGED_AGENT_RECALL_MAX_K)
    except Exception:
        value = MANAGED_AGENT_RECALL_MAX_K
    return max(1, min(value, MANAGED_AGENT_RECALL_MAX_K))


def _limited_unique_memory_ids(memory_ids: list[str], k: int) -> list[str]:
    selected: list[str] = []
    seen: set[str] = set()

    for raw_id in memory_ids:
        memory_id = str(raw_id or "").strip()
        if not memory_id or memory_id in seen:
            continue

        seen.add(memory_id)
        selected.append(memory_id)

        if len(selected) >= k:
            break

    return selected


def _managed_data_key_from_passphrase(
    *,
    db: Any,
    user_id: str,
    managed_passphrase: str,
) -> bytes:
    if not isinstance(managed_passphrase, str) or not managed_passphrase:
        raise HTTPException(status_code=400, detail="managed_passphrase is required")

    result = (
        db.table("vault_keys")
        .select("vault_secret_name,algo")
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    if not rows:
        raise HTTPException(status_code=404, detail="managed vault key not found")

    row = rows[0]
    secret_name = row.get("vault_secret_name")
    if not isinstance(secret_name, str) or not secret_name:
        raise HTTPException(status_code=500, detail="managed vault key secret name missing")

    payload = _read_vault_secret_payload(db, secret_name)
    kdf_salt_b64 = payload.get("kdf_salt_b64")
    wrapped_key_b64 = payload.get("wrapped_key_b64")
    if not isinstance(kdf_salt_b64, str) or not isinstance(wrapped_key_b64, str):
        raise HTTPException(status_code=500, detail="managed vault secret missing key material")

    try:
        salt = base64.b64decode(kdf_salt_b64, validate=True)
        wrapped_blob = base64.b64decode(wrapped_key_b64, validate=True)
        return _unwrap_local_blob(wrapped_blob, managed_passphrase, salt)
    except Exception as exc:
        raise HTTPException(status_code=403, detail="unable to recover managed data key") from exc


def _managed_data_key_from_custody(*, db: Any, user_id: str) -> bytes:
    result = (
        db.table("vault_keys")
        .select("vault_secret_name,algo")
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    if not rows:
        raise HTTPException(status_code=404, detail="managed vault key not found")

    row = rows[0]
    secret_name = row.get("vault_secret_name")
    if not isinstance(secret_name, str) or not secret_name:
        raise HTTPException(status_code=500, detail="managed vault key secret name missing")

    payload = _read_vault_secret_payload(db, secret_name)
    custody_b64 = payload.get("managed_custody_data_key_b64")
    if not isinstance(custody_b64, str) or not custody_b64:
        raise HTTPException(status_code=409, detail="managed custody data key not provisioned")

    try:
        data_key = base64.b64decode(custody_b64, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail="managed custody data key is invalid") from exc

    if len(data_key) != DATA_KEY_LEN:
        raise HTTPException(status_code=500, detail="managed custody data key has invalid size")
    return data_key


def _wrap_data_key_for_agent_token(data_key: bytes, plaintext_token: str) -> tuple[str, str]:
    if not isinstance(plaintext_token, str) or not plaintext_token:
        raise HTTPException(status_code=500, detail="agent token missing for key wrapping")
    if len(data_key) != DATA_KEY_LEN:
        raise HTTPException(status_code=500, detail="managed data key has invalid size")

    salt = generate_salt(16)
    wrapped_blob = _wrap_data_key_locally(data_key, plaintext_token, salt)
    return (
        base64.b64encode(salt).decode("ascii"),
        base64.b64encode(wrapped_blob).decode("ascii"),
    )


def _managed_data_key_from_agent_token(
    *,
    db: Any,
    user_id: str,
    token_hash: str,
    plaintext_token: str,
) -> bytes:
    result = (
        db.table("agent_tokens")
        .select("agent_kdf_salt_b64,agent_wrapped_data_key_b64")
        .eq("user_id", user_id)
        .eq("token_hash", token_hash)
        .is_("revoked_at", "null")
        .limit(1)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    if not rows:
        raise HTTPException(status_code=403, detail="agent token not found")

    row = rows[0]
    salt_b64 = row.get("agent_kdf_salt_b64")
    wrapped_b64 = row.get("agent_wrapped_data_key_b64")

    if (
        not isinstance(salt_b64, str)
        or not isinstance(wrapped_b64, str)
        or not salt_b64
        or not wrapped_b64
    ):
        raise HTTPException(
            status_code=403,
            detail="agent token is not provisioned for recall",
        )

    try:
        salt = base64.b64decode(salt_b64, validate=True)
        wrapped_blob = base64.b64decode(wrapped_b64, validate=True)
        return _unwrap_local_blob(wrapped_blob, plaintext_token, salt)
    except Exception as exc:
        raise HTTPException(status_code=403, detail="unable to recover agent data key") from exc


def _decoded_payload_size_bytes(payload_b64: str) -> int:
    if not isinstance(payload_b64, str) or not payload_b64.strip():
        raise HTTPException(status_code=400, detail="payload_b64 is required")
    try:
        decoded = base64.b64decode(payload_b64, validate=True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="payload_b64 must be valid base64") from exc
    return len(decoded)


def _recompute_storage_usage_bytes(user_id: str) -> int:
    db = _supabase_service_client()
    total = 0
    offset = 0
    page_size = 500

    while True:
        result = (
            db.table("memories")
            .select("payload_b64")
            .eq("user_id", user_id)
            .range(offset, offset + page_size - 1)
            .execute()
        )
        rows = getattr(result, "data", None) or []
        if not rows:
            break

        for row in rows:
            payload_b64 = row.get("payload_b64") or ""
            try:
                total += len(base64.b64decode(payload_b64, validate=True))
            except Exception:
                # Corrupt rows should not crash quota calculations.
                continue

        if len(rows) < page_size:
            break
        offset += page_size

    return total


def _sync_quota_usage_for_user(user_id: str, *, storage_used_bytes: int | None = None) -> int:
    used = _safe_int(storage_used_bytes, default=-1)
    if used < 0:
        used = _recompute_storage_usage_bytes(user_id)

    db = _supabase_service_client()
    quota_row = {
        "user_id": user_id,
        "storage_used_bytes": used,
        "raw_storage_bytes": used,
        "compressed_storage_bytes": 0,
        "index_storage_bytes": 0,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }

    db.table("quota_usage").upsert(quota_row, on_conflict="user_id").execute()
    db.table("subscriptions").update(
        {"storage_used_bytes": used, "updated_at": datetime.now(timezone.utc).isoformat()}
    ).eq("user_id", user_id).execute()
    return used


def _increment_quota_usage_for_user(user_id: str, *, delta_bytes: int) -> int:
    delta = max(_safe_int(delta_bytes, 0), 0)
    if delta <= 0:
        row = _get_subscription_row_for_user(user_id)
        return _safe_int(row.get("storage_used_bytes") if row else 0, 0)

    db = _supabase_service_client()
    result = db.rpc(
        "increment_storage_usage", {"p_user_id": user_id, "p_delta_bytes": delta}
    ).execute()
    data = getattr(result, "data", None)
    if isinstance(data, int):
        return data
    if isinstance(data, str):
        return _safe_int(data, 0)
    if isinstance(data, list) and data:
        return _safe_int(data[0], 0)
    return 0


def _count_active_agent_tokens(user_id: str) -> int:
    db = _supabase_service_client()
    try:
        result = (
            db.table("agent_tokens")
            .select("id", count="exact")
            .eq("user_id", user_id)
            .is_("revoked_at", "null")
            .execute()
        )
    except Exception:
        result = (
            db.table("agent_tokens").select("id", count="exact").eq("user_id", user_id).execute()
        )
    return _safe_int(getattr(result, "count", None), 0)


def _count_connected_agents(user_id: str) -> int:
    db = _supabase_service_client()
    try:
        result = db.table("agents").select("id", count="exact").eq("user_id", user_id).execute()
    except Exception:
        return 0
    return _safe_int(getattr(result, "count", None), 0)


def _resolve_agent_in_use(user_id: str) -> int:
    token_count = _count_active_agent_tokens(user_id)
    connected_agents = _count_connected_agents(user_id)
    # Defensive posture against abuse: enforce whichever count is higher.
    return max(token_count, connected_agents)


def _build_quota_status(
    entitlement: dict[str, Any], *, recompute_storage: bool = True
) -> dict[str, Any]:
    user_id = entitlement["user_id"]
    storage_cap_bytes = _safe_int(entitlement.get("storage_cap_bytes"), 0)
    if storage_cap_bytes <= 0:
        storage_cap_bytes = int(float(entitlement.get("storage_quota_gb") or 0) * BYTES_PER_GB)
    if recompute_storage:
        storage_used_bytes = _sync_quota_usage_for_user(user_id)
    else:
        storage_used_bytes = _safe_int(entitlement.get("storage_used_bytes"), 0)
    pct = (
        (float(storage_used_bytes) / float(storage_cap_bytes) * 100.0)
        if storage_cap_bytes > 0
        else 0.0
    )

    agent_quota = _safe_int(entitlement.get("agent_quota"), 0)
    agent_in_use = _resolve_agent_in_use(user_id)

    warnings: list[str] = []
    if storage_cap_bytes > 0 and pct >= 80.0:
        warnings.append(
            "Storage usage is above 80%. Run 'matriosha memory compress' or upgrade with 'matriosha billing upgrade'."
        )

    return {
        "status": "ok",
        "operation": "quota.status",
        "storage_used_bytes": storage_used_bytes,
        "storage_cap_bytes": storage_cap_bytes,
        "storage_used_percent": round(pct, 2),
        "agent_quota": agent_quota,
        "agent_in_use": agent_in_use,
        "agent_available": max(0, agent_quota - agent_in_use),
        "warnings": warnings,
    }


def _enforce_storage_quota_before_upload(
    entitlement: dict[str, Any], *, payload_size_bytes: int
) -> dict[str, Any]:
    snapshot = _build_quota_status(entitlement, recompute_storage=False)
    storage_cap_bytes = snapshot["storage_cap_bytes"]
    storage_used_bytes = snapshot["storage_used_bytes"]

    if storage_cap_bytes <= 0:
        raise HTTPException(
            status_code=413,
            detail="Storage quota exceeded (0.00/0.00 GB used). Upgrade your plan with 'matriosha billing upgrade'",
        )

    projected_used = storage_used_bytes + max(payload_size_bytes, 0)
    if projected_used > storage_cap_bytes:
        raise HTTPException(
            status_code=413,
            detail=(
                f"Storage quota exceeded ({_format_storage_used_vs_cap(storage_used_bytes, storage_cap_bytes)} used). "
                "Upgrade your plan with 'matriosha billing upgrade'"
            ),
        )

    return snapshot


def _enforce_agent_quota(entitlement: dict[str, Any]) -> dict[str, Any]:
    snapshot = _build_quota_status(entitlement, recompute_storage=False)
    if snapshot["agent_quota"] > 0 and snapshot["agent_in_use"] >= snapshot["agent_quota"]:
        raise HTTPException(
            status_code=403,
            detail=(
                f"Agent limit reached ({snapshot['agent_in_use']}/{snapshot['agent_quota']} agents). "
                "Upgrade for more agents."
            ),
        )
    return snapshot


def _memory_not_found_error() -> HTTPException:
    return HTTPException(status_code=404, detail="Memory not found or access denied")


def _vector_from_db(value: Any) -> list[float] | None:
    if isinstance(value, list):
        try:
            return [float(x) for x in value]
        except (TypeError, ValueError):
            return None

    if isinstance(value, str):
        text = value.strip()
        if text.startswith("[") and text.endswith("]"):
            body = text[1:-1].strip()
            if not body:
                return []
            parts = [p.strip() for p in body.split(",")]
            try:
                return [float(p) for p in parts]
            except (TypeError, ValueError):
                return None
    return None


def _cosine_similarity(left: list[float], right: list[float]) -> float:
    if len(left) != len(right) or not left:
        return -1.0

    dot = 0.0
    left_norm = 0.0
    right_norm = 0.0
    for lval, rval in zip(left, right):
        dot += lval * rval
        left_norm += lval * lval
        right_norm += rval * rval

    if left_norm <= 0.0 or right_norm <= 0.0:
        return -1.0
    return dot / ((left_norm**0.5) * (right_norm**0.5))


@app.post("/managed/auth/otp/start")
def managed_auth_otp_start(req: OtpStartRequest, request: Request):
    email = _normalize_email(req.email)
    ip = request.client.host if request.client and request.client.host else "unknown"
    _apply_otp_rate_limit(bucket="otp_start", key=email, max_attempts=_OTP_RATE_LIMIT_START_MAX)
    _apply_otp_rate_limit(bucket="otp_start_ip", key=ip, max_attempts=_OTP_RATE_LIMIT_START_MAX * 3)

    client = _supabase_anon_client()
    try:
        result = client.auth.sign_in_with_otp(
            {
                "email": email,
                "options": {
                    "should_create_user": True,
                },
            }
        )
    except Exception as exc:
        status = int(getattr(exc, "status", 400) or 400)
        message = str(exc) or exc.__class__.__name__
        error_code = str(getattr(exc, "code", "") or "")
        detail = f"could not send login code: {message}"
        if error_code:
            detail = f"{detail} ({error_code})"
        raise HTTPException(status_code=status, detail=detail) from exc

    return {
        "status": "ok",
        "message": "login code sent",
        "message_id": getattr(result, "message_id", None),
    }


@app.post("/managed/auth/otp/verify")
def managed_auth_otp_verify(req: OtpVerifyRequest, request: Request):
    code = req.code.strip().replace(" ", "")
    if not code:
        raise HTTPException(status_code=400, detail="code is required")

    email = _normalize_email(req.email)
    ip = request.client.host if request.client and request.client.host else "unknown"
    _apply_otp_rate_limit(bucket="otp_verify", key=email, max_attempts=_OTP_RATE_LIMIT_VERIFY_MAX)
    _apply_otp_rate_limit(
        bucket="otp_verify_ip", key=ip, max_attempts=_OTP_RATE_LIMIT_VERIFY_MAX * 3
    )

    client = _supabase_anon_client()
    try:
        result = client.auth.verify_otp(
            {
                "email": email,
                "token": code,
                "type": "email",
            }
        )
    except Exception as exc:
        status = int(getattr(exc, "status", 401) or 401)
        message = str(exc) or exc.__class__.__name__
        error_code = str(getattr(exc, "code", "") or "")
        detail = f"invalid or expired login code: {message}"
        if error_code:
            detail = f"{detail} ({error_code})"
        raise HTTPException(status_code=status, detail=detail) from exc

    session = getattr(result, "session", None)
    user = getattr(result, "user", None)
    access_token = getattr(session, "access_token", None) if session else None
    refresh_token = getattr(session, "refresh_token", None) if session else None
    expires_in = getattr(session, "expires_in", None) if session else None
    token_type = getattr(session, "token_type", None) if session else "bearer"

    if not access_token:
        raise HTTPException(status_code=401, detail="login verification did not return a session")

    user_id = getattr(user, "id", None) if user else None
    if user_id:
        _ensure_public_user(str(user_id))

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_in": expires_in,
        "token_type": token_type or "bearer",
        "scope": "openid profile email offline_access",
        "user": {
            "id": getattr(user, "id", None) if user else None,
            "email": getattr(user, "email", None) if user else _normalize_email(req.email),
        },
    }


@app.post("/managed/auth/refresh")
def managed_auth_refresh(req: RefreshRequest):
    refresh_token = req.refresh_token.strip()
    if not refresh_token:
        raise HTTPException(status_code=400, detail="refresh_token is required")

    client = _supabase_anon_client()
    try:
        result = client.auth.refresh_session(refresh_token)
    except Exception as exc:
        message = str(exc) or exc.__class__.__name__
        raise HTTPException(
            status_code=401,
            detail=f"invalid or expired refresh token: {message}",
        ) from exc

    session = getattr(result, "session", None)
    user = getattr(result, "user", None)
    access_token = getattr(session, "access_token", None) if session else None
    rotated_refresh = getattr(session, "refresh_token", None) if session else None
    expires_in = getattr(session, "expires_in", None) if session else None
    token_type = getattr(session, "token_type", None) if session else "bearer"

    if not access_token:
        raise HTTPException(status_code=401, detail="token refresh did not return an access token")

    return {
        "access_token": access_token,
        "refresh_token": rotated_refresh or refresh_token,
        "expires_in": expires_in,
        "token_type": token_type or "bearer",
        "scope": "openid profile email offline_access",
        "user": {
            "id": getattr(user, "id", None) if user else None,
            "email": getattr(user, "email", None) if user else None,
        },
    }


@app.post("/managed/auth/logout")
def managed_auth_logout(authorization: str | None = Header(default=None)):
    token = _bearer_token(authorization)
    client = _supabase_anon_client()
    try:
        client.auth.sign_out(token)
    except Exception:
        # Best-effort logout for this session token.
        pass
    return {"status": "ok"}


@app.get("/managed/whoami")
def managed_whoami(entitlement: dict[str, Any] = Depends(require_active_subscription)):
    return {
        "user_id": entitlement["user_id"],
        "id": entitlement["user_id"],
        "email": entitlement.get("email"),
        "aud": entitlement.get("aud"),
        "role": entitlement.get("role"),
        "subscription_status": entitlement["status"],
        "agent_quota": entitlement["agent_quota"],
        "storage_quota_gb": entitlement["storage_quota_gb"],
    }


@app.post("/functions/v1/vault-custody")
def vault_custody(
    req: VaultCustodyRequest, entitlement: dict[str, Any] = Depends(require_active_subscription)
):
    user_id = entitlement["user_id"]
    db = _supabase_service_client()

    if req.action == "fetch":
        result = (
            db.table("vault_keys")
            .select("vault_secret_name,algo")
            .eq("user_id", user_id)
            .limit(1)
            .execute()
        )
        rows = getattr(result, "data", None) or []
        if not rows:
            raise HTTPException(status_code=404, detail="managed vault key not found")

        row = rows[0]
        secret_name = row.get("vault_secret_name")
        if not isinstance(secret_name, str) or not secret_name:
            raise HTTPException(status_code=500, detail="managed vault key secret name missing")

        payload = _read_vault_secret_payload(db, secret_name)
        kdf_salt_b64 = payload.get("kdf_salt_b64")
        wrapped_key_b64 = payload.get("wrapped_key_b64")
        if not isinstance(kdf_salt_b64, str) or not isinstance(wrapped_key_b64, str):
            raise HTTPException(status_code=500, detail="managed vault secret missing key material")

        return {
            "kdf_salt_b64": kdf_salt_b64,
            "wrapped_key_b64": wrapped_key_b64,
            "managed_custody_data_key_b64": payload.get("managed_custody_data_key_b64"),
            "algo": row.get("algo") or "aes-gcm",
        }

    if req.action == "upsert":
        if not req.kdf_salt_b64 or not req.wrapped_key_b64:
            raise HTTPException(
                status_code=400, detail="kdf_salt_b64 and wrapped_key_b64 are required"
            )
        try:
            base64.b64decode(req.kdf_salt_b64, validate=True)
            base64.b64decode(req.wrapped_key_b64, validate=True)
            if req.managed_custody_data_key_b64:
                custody_key = base64.b64decode(req.managed_custody_data_key_b64, validate=True)
                if len(custody_key) != DATA_KEY_LEN:
                    raise ValueError("managed custody data key has invalid size")
        except Exception as exc:
            raise HTTPException(status_code=400, detail="invalid base64 key material") from exc

        secret_name = _vault_key_secret_name(user_id)
        secret_payload = _vault_secret_payload(
            kdf_salt_b64=req.kdf_salt_b64,
            wrapped_key_b64=req.wrapped_key_b64,
            managed_custody_data_key_b64=req.managed_custody_data_key_b64,
        )
        _upsert_vault_secret_payload(db, secret_name=secret_name, payload=secret_payload)

        row = {
            "user_id": user_id,
            "vault_secret_name": secret_name,
            "algo": req.algo or "aes-gcm",
        }
        db.table("vault_keys").upsert(row, on_conflict="user_id").execute()
        return {"status": "ok"}

    raise HTTPException(status_code=400, detail="unsupported vault custody action")


@app.post("/managed/billing/checkout")
def managed_billing_checkout(
    req: BillingCheckoutRequest, entitlement: dict[str, Any] = Depends(get_subscription_entitlement)
):
    if req.plan != "eur_monthly":
        raise HTTPException(
            status_code=400, detail="Only the eur_monthly plan is currently supported."
        )
    if req.quantity <= 0:
        raise HTTPException(status_code=400, detail="quantity must be a positive integer")
    if bool(entitlement.get("is_active")) and entitlement.get("stripe_subscription_id"):
        raise HTTPException(
            status_code=409,
            detail="An active subscription already exists for this user. Use billing upgrade or the billing portal instead.",
        )

    stripe = _get_stripe_module()
    price_id = _require_env(
        "STRIPE_PRICE_ID_BASE",
        purpose="Set the Stripe base price ID in Cloud Run to enable checkout.",
    )
    success_url = _require_env(
        "STRIPE_SUCCESS_URL",
        purpose="Set STRIPE_SUCCESS_URL (e.g. https://matriosha.in/billing/success).",
    )
    cancel_url = _require_env(
        "STRIPE_CANCEL_URL",
        purpose="Set STRIPE_CANCEL_URL (e.g. https://matriosha.in/billing/cancel).",
    )

    checkout_payload: dict[str, Any] = {
        "mode": "subscription",
        "line_items": [{"price": price_id, "quantity": req.quantity}],
        "success_url": success_url,
        "cancel_url": cancel_url,
        "allow_promotion_codes": True,
        "client_reference_id": entitlement["user_id"],
        "metadata": {
            "user_id": entitlement["user_id"],
            "plan": req.plan,
        },
        "subscription_data": {
            "metadata": {
                "user_id": entitlement["user_id"],
                "plan": req.plan,
            }
        },
    }

    if entitlement.get("stripe_customer_id"):
        checkout_payload["customer"] = entitlement["stripe_customer_id"]
    elif entitlement.get("email"):
        checkout_payload["customer_email"] = entitlement["email"]

    try:
        session = stripe.checkout.Session.create(**checkout_payload)
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not create Stripe checkout session ({exc.__class__.__name__}).",
        ) from exc

    return {
        "status": "pending",
        "checkout_url": getattr(session, "url", None),
        "session_id": getattr(session, "id", None),
    }


def _billing_status_response(entitlement: dict[str, Any]) -> dict[str, Any]:
    quota = _build_quota_status(entitlement)
    return {
        "status": entitlement["status"],
        "plan": entitlement["plan"],
        "plan_code": entitlement["plan"],
        "agent_quota": entitlement["agent_quota"],
        "agent_in_use": quota["agent_in_use"],
        "storage_cap_bytes": entitlement["storage_cap_bytes"],
        "storage_used_bytes": quota["storage_used_bytes"],
        "storage_used_percent": quota["storage_used_percent"],
        "storage_quota_gb": entitlement["storage_quota_gb"],
        "current_period_end": entitlement["current_period_end"],
        "cancel_at": entitlement.get("cancel_at"),
        "cancel_at_period_end": bool(entitlement.get("cancel_at")),
        "is_active": bool(entitlement.get("is_active")),
        "stripe_customer_id": entitlement.get("stripe_customer_id"),
        "stripe_subscription_id": entitlement.get("stripe_subscription_id"),
        "stripe_subscription_item_id": entitlement.get("stripe_subscription_item_id"),
        "warnings": quota["warnings"],
    }


@app.get("/managed/billing/status")
def managed_billing_status(entitlement: dict[str, Any] = Depends(get_subscription_entitlement)):
    return _billing_status_response(entitlement)


def _cancel_subscription_at_period_end(entitlement: dict[str, Any]) -> dict[str, Any]:
    stripe_subscription_id = entitlement.get("stripe_subscription_id")
    if not stripe_subscription_id:
        raise HTTPException(
            status_code=400, detail="No active Stripe subscription found for this user"
        )

    stripe = _get_stripe_module()
    try:
        updated = stripe.Subscription.modify(
            stripe_subscription_id,
            cancel_at_period_end=True,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not cancel subscription ({exc.__class__.__name__})",
        ) from exc

    updated_dict = _stripe_object_to_dict(updated)
    current_period_end = _timestamp_to_iso(
        updated_dict.get("current_period_end") or getattr(updated, "current_period_end", None)
    )
    cancel_at = _timestamp_to_iso(updated_dict.get("cancel_at")) or current_period_end

    try:
        db = _supabase_service_client()
        db.table("subscriptions").update(
            {
                "status": "active",
                "cancel_at": cancel_at,
                "current_period_end": current_period_end,
                "updated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            }
        ).eq("user_id", entitlement["user_id"]).execute()
    except Exception:
        # Stripe is source-of-truth; DB sync will be corrected by webhook.
        pass

    return {
        "status": "active",
        "cancel_at_period_end": True,
        "cancel_at": cancel_at,
        "current_period_end": current_period_end,
        "effective_date": cancel_at,
    }


@app.post("/managed/billing/cancel")
def managed_billing_cancel(entitlement: dict[str, Any] = Depends(get_subscription_entitlement)):
    return _cancel_subscription_at_period_end(entitlement)


@app.post("/managed/subscription/cancel")
def managed_subscription_cancel(
    entitlement: dict[str, Any] = Depends(get_subscription_entitlement),
):
    # Backward-compatible alias for older clients.
    return _cancel_subscription_at_period_end(entitlement)


@app.post("/managed/billing/upgrade")
def managed_billing_upgrade(
    req: BillingQuantityUpdateRequest,
    entitlement: dict[str, Any] = Depends(get_subscription_entitlement),
):
    stripe_subscription_id = entitlement.get("stripe_subscription_id")
    if not stripe_subscription_id:
        raise HTTPException(status_code=400, detail="No Stripe subscription found for this user")

    stripe = _get_stripe_module()
    try:
        subscription = stripe.Subscription.retrieve(stripe_subscription_id)
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not fetch Stripe subscription ({exc.__class__.__name__})",
        ) from exc

    subscription_dict = _stripe_object_to_dict(subscription)
    current_item = _subscription_item_from_subscription(subscription_dict)
    if not current_item:
        raise HTTPException(status_code=400, detail="Stripe subscription has no billable items")

    current_quantity = _safe_int(current_item.get("quantity"), 1)
    if req.quantity <= current_quantity:
        raise HTTPException(
            status_code=400,
            detail=f"upgrade quantity must be greater than current quantity ({current_quantity})",
        )

    subscription_item_id = str(
        current_item.get("id") or entitlement.get("stripe_subscription_item_id") or ""
    ).strip()
    if not subscription_item_id:
        raise HTTPException(status_code=400, detail="Stripe subscription item id is missing")

    try:
        stripe.SubscriptionItem.modify(
            subscription_item_id,
            quantity=req.quantity,
            proration_behavior="create_prorations",
        )
        updated_subscription = stripe.Subscription.retrieve(stripe_subscription_id)
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not update Stripe subscription quantity ({exc.__class__.__name__})",
        ) from exc

    _upsert_subscription_snapshot_from_stripe(_stripe_object_to_dict(updated_subscription))
    refreshed_row = _get_subscription_row_for_user(entitlement["user_id"])
    refreshed_entitlement = _subscription_row_to_entitlement(entitlement["user_id"], refreshed_row)
    response = _billing_status_response(refreshed_entitlement)
    response["previous_quantity"] = current_quantity
    response["quantity"] = req.quantity
    return response


@app.post("/managed/billing/downgrade")
def managed_billing_downgrade(
    req: BillingQuantityUpdateRequest,
    entitlement: dict[str, Any] = Depends(get_subscription_entitlement),
):
    stripe_subscription_id = entitlement.get("stripe_subscription_id")
    if not stripe_subscription_id:
        raise HTTPException(status_code=400, detail="No Stripe subscription found for this user")

    stripe = _get_stripe_module()
    try:
        subscription = stripe.Subscription.retrieve(stripe_subscription_id)
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not fetch Stripe subscription ({exc.__class__.__name__})",
        ) from exc

    subscription_dict = _stripe_object_to_dict(subscription)
    current_item = _subscription_item_from_subscription(subscription_dict)
    if not current_item:
        raise HTTPException(status_code=400, detail="Stripe subscription has no billable items")

    current_quantity = _safe_int(current_item.get("quantity"), 1)
    if req.quantity >= current_quantity:
        raise HTTPException(
            status_code=400,
            detail=f"downgrade quantity must be less than current quantity ({current_quantity})",
        )

    subscription_item_id = str(
        current_item.get("id") or entitlement.get("stripe_subscription_item_id") or ""
    ).strip()
    if not subscription_item_id:
        raise HTTPException(status_code=400, detail="Stripe subscription item id is missing")

    try:
        stripe.SubscriptionItem.modify(
            subscription_item_id,
            quantity=req.quantity,
            proration_behavior="create_prorations",
        )
        updated_subscription = stripe.Subscription.retrieve(stripe_subscription_id)
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not update Stripe subscription quantity ({exc.__class__.__name__})",
        ) from exc

    _upsert_subscription_snapshot_from_stripe(_stripe_object_to_dict(updated_subscription))
    refreshed_row = _get_subscription_row_for_user(entitlement["user_id"])
    refreshed_entitlement = _subscription_row_to_entitlement(entitlement["user_id"], refreshed_row)
    response = _billing_status_response(refreshed_entitlement)
    response["previous_quantity"] = current_quantity
    response["quantity"] = req.quantity
    return response


@app.post("/managed/billing/portal")
def managed_billing_portal(entitlement: dict[str, Any] = Depends(get_subscription_entitlement)):
    if not entitlement.get("stripe_customer_id"):
        raise HTTPException(
            status_code=400,
            detail="No billing customer found yet. Run 'matriosha billing subscribe' first.",
        )

    stripe = _get_stripe_module()
    return_url = _require_env(
        "STRIPE_SUCCESS_URL",
        purpose="Set STRIPE_SUCCESS_URL so users can return from the billing portal.",
    )

    try:
        portal = stripe.billing_portal.Session.create(
            customer=entitlement["stripe_customer_id"],
            return_url=return_url,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Could not create billing portal session ({exc.__class__.__name__}).",
        ) from exc

    return {
        "portal_url": getattr(portal, "url", None),
    }


@app.get("/managed/subscription")
def managed_subscription_status(
    entitlement: dict[str, Any] = Depends(get_subscription_entitlement),
):
    return managed_billing_status(entitlement)


@app.get("/managed/quota/status")
def managed_quota_status(entitlement: dict[str, Any] = Depends(require_active_managed_actor)):
    _require_agent_scope(entitlement, {"read", "write"})
    return _build_quota_status(entitlement)


@app.post("/managed/memories")
def managed_memories_create(
    req: ManagedMemoryCreateRequest,
    entitlement: dict[str, Any] = Depends(require_active_managed_actor),
):
    _require_agent_scope(entitlement, {"write"})
    user_id = entitlement["user_id"]
    payload_size_bytes = _decoded_payload_size_bytes(req.payload_b64)
    _enforce_storage_quota_before_upload(entitlement, payload_size_bytes=payload_size_bytes)

    envelope = dict(req.envelope or {})
    if req.embedding is not None:
        raise HTTPException(
            status_code=400, detail="Managed embeddings are disabled; use local retrieval"
        )
    tags = _extract_tags(envelope)
    safe_metadata = _safe_memory_metadata(envelope)
    search_keywords = _search_keywords_from_envelope(envelope, tags)
    # Zero-knowledge search metadata must be generated client-side using keyed HMAC tokens.
    # Never derive managed search hashes server-side from plaintext keywords.
    metadata_hashes = req.metadata_hashes or []

    db = _supabase_service_client()
    memory_row = {
        "user_id": user_id,
        "envelope": envelope,
        "payload_b64": req.payload_b64,
        "tags": tags,
        "safe_metadata": safe_metadata,
        "search_keywords": search_keywords,
        "metadata_hashes": metadata_hashes,
    }

    insert_result = db.table("memories").insert(memory_row).execute()
    inserted_rows = getattr(insert_result, "data", None) or []
    if not inserted_rows:
        raise HTTPException(status_code=500, detail="Could not store memory. Please retry.")

    memory_id = str(inserted_rows[0].get("id") or "").strip()
    if not memory_id:
        raise HTTPException(status_code=500, detail="Managed backend did not return memory id")

    _increment_quota_usage_for_user(user_id, delta_bytes=payload_size_bytes)
    return {"id": memory_id, "memory_id": memory_id}


@app.post("/managed/memories/bulk")
def managed_memories_bulk_create(
    req: ManagedMemoryBulkCreateRequest,
    entitlement: dict[str, Any] = Depends(require_active_managed_actor),
):
    _require_agent_scope(entitlement, {"write"})
    user_id = entitlement["user_id"]
    items = list(req.items or [])
    if not items:
        raise HTTPException(status_code=400, detail="bulk upload requires at least one item")

    total_payload_size_bytes = sum(_decoded_payload_size_bytes(item.payload_b64) for item in items)
    _enforce_storage_quota_before_upload(entitlement, payload_size_bytes=total_payload_size_bytes)

    db = _supabase_service_client()
    memory_rows: list[dict[str, Any]] = []
    for item in items:
        envelope = dict(item.envelope or {})
        if item.embedding is not None:
            raise HTTPException(
                status_code=400, detail="Managed embeddings are disabled; use local retrieval"
            )
        tags = _extract_tags(envelope)
        safe_metadata = _safe_memory_metadata(envelope)
        search_keywords = _search_keywords_from_envelope(envelope, tags)
        # Zero-knowledge search metadata must be generated client-side using keyed HMAC tokens.
        # Never derive managed search hashes server-side from plaintext keywords.
        metadata_hashes = item.metadata_hashes or []

        memory_rows.append(
            {
                "user_id": user_id,
                "envelope": envelope,
                "payload_b64": item.payload_b64,
                "tags": tags,
                "safe_metadata": safe_metadata,
                "search_keywords": search_keywords,
                "metadata_hashes": metadata_hashes,
            }
        )
    insert_result = db.table("memories").insert(memory_rows).execute()
    inserted_rows = getattr(insert_result, "data", None) or []
    if len(inserted_rows) != len(memory_rows):
        raise HTTPException(status_code=500, detail="Could not store all memories. Please retry.")

    response_items: list[dict[str, str]] = []

    for row in inserted_rows:
        memory_id = str(row.get("id") or "").strip()
        if not memory_id:
            raise HTTPException(status_code=500, detail="Managed backend did not return memory id")
        response_items.append({"id": memory_id, "memory_id": memory_id})
    _increment_quota_usage_for_user(user_id, delta_bytes=total_payload_size_bytes)
    return {"items": response_items}


@app.get("/managed/memories")
def managed_memories_list(
    tag: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
    entitlement: dict[str, Any] = Depends(require_active_managed_actor),
):
    _require_agent_scope(entitlement, {"read", "write"})
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    result = (
        db.table("memories")
        .select(
            "id,envelope,payload_b64,created_at,tags,safe_metadata,search_keywords,metadata_hashes"
        )
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .limit(limit)
        .execute()
    )
    rows = getattr(result, "data", None) or []

    filtered: list[dict[str, Any]] = []
    wanted_tag = tag.strip() if isinstance(tag, str) else None
    for row in rows:
        if wanted_tag:
            row_tags = (
                row.get("tags")
                if isinstance(row.get("tags"), list)
                else _extract_tags(row.get("envelope") or {})
            )
            if wanted_tag not in row_tags:
                continue

        filtered.append(
            {
                "id": row.get("id"),
                "memory_id": row.get("id"),
                "envelope": row.get("envelope") or {},
                "payload_b64": row.get("payload_b64") or "",
                "created_at": row.get("created_at"),
                "tags": row.get("tags") or [],
                "safe_metadata": row.get("safe_metadata") or {},
                "search_keywords": row.get("search_keywords") or [],
                "metadata_hashes": row.get("metadata_hashes") or [],
            }
        )

    return {"items": filtered, "memories": filtered}


@app.get("/managed/memories/{memory_id}")
def managed_memories_fetch(
    memory_id: str, entitlement: dict[str, Any] = Depends(require_active_managed_actor)
):
    _require_agent_scope(entitlement, {"read", "write"})
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    result = (
        db.table("memories")
        .select("id,envelope,payload_b64,tags,safe_metadata,search_keywords,metadata_hashes")
        .eq("id", memory_id)
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    if not rows:
        raise _memory_not_found_error()

    row = rows[0]
    return {
        "id": row.get("id"),
        "memory_id": row.get("id"),
        "envelope": row.get("envelope") or {},
        "payload_b64": row.get("payload_b64") or "",
        "tags": row.get("tags") or [],
        "safe_metadata": row.get("safe_metadata") or {},
        "search_keywords": row.get("search_keywords") or [],
        "metadata_hashes": row.get("metadata_hashes") or [],
    }


@app.delete("/managed/memories/{memory_id}")
def managed_memories_delete(
    memory_id: str, entitlement: dict[str, Any] = Depends(require_active_managed_actor)
):
    _require_agent_scope(entitlement, {"write"})
    user_id = entitlement["user_id"]
    db = _supabase_service_client()

    lookup = (
        db.table("memories")
        .select("id")
        .eq("id", memory_id)
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(lookup, "data", None) or []
    if not rows:
        raise _memory_not_found_error()

    db.table("memories").delete().eq("id", memory_id).eq("user_id", user_id).execute()
    _sync_quota_usage_for_user(user_id)
    return {"deleted": True, "ok": True}


@app.post("/managed/search")
def managed_search(
    req: ManagedSearchRequest, entitlement: dict[str, Any] = Depends(require_active_managed_actor)
):
    _require_agent_scope(entitlement, {"read", "write"})
    user_id = entitlement["user_id"]

    requested_hashes = _clean_metadata_hashes(req.metadata_hashes)
    if not requested_hashes:
        raise HTTPException(
            status_code=400,
            detail="metadata_hashes are required for zero-knowledge managed search",
        )

    # Managed search is only a coarse encrypted-candidate fetch for local decrypt/rerank.
    # The server must not receive plaintext queries and must not decrypt memories.
    limit = max(1, min(int(req.limit or 50), 50))
    db = _supabase_service_client()

    result = (
        db.table("memories")
        .select("id,envelope,payload_b64,tags,safe_metadata,metadata_hashes,created_at")
        .eq("user_id", user_id)
        .overlaps("metadata_hashes", requested_hashes)
        .limit(limit)
        .execute()
    )
    rows = getattr(result, "data", None) or []

    def _match_score(row: dict[str, Any]) -> int:
        row_hashes = set(_clean_metadata_hashes(row.get("metadata_hashes") or []))
        return sum(1 for value in requested_hashes if value in row_hashes)

    ordered_rows = sorted(
        rows,
        key=lambda row: (_match_score(row), str(row.get("created_at") or "")),
        reverse=True,
    )[:limit]

    items = [
        {
            "id": row.get("id"),
            "memory_id": row.get("id"),
            "envelope": row.get("envelope") or {},
            "payload_b64": row.get("payload_b64") or "",
            "tags": row.get("tags") or [],
            "safe_metadata": row.get("safe_metadata") or {},
            "metadata_hashes": row.get("metadata_hashes") or [],
            "score": _match_score(row),
        }
        for row in ordered_rows
    ]

    return {
        "items": items,
        "memories": items,
        "limit": limit,
    }


@app.post("/managed/agent/recall")
def managed_agent_recall(
    req: ManagedAgentRecallRequest,
    entitlement: dict[str, Any] = Depends(require_active_managed_actor),
):
    _require_agent_scope(entitlement, {"read", "write"})
    user_id = entitlement["user_id"]

    k = _managed_agent_recall_k(req.k)
    memory_ids = _limited_unique_memory_ids(req.memory_ids, k)
    if not memory_ids:
        raise HTTPException(status_code=400, detail="memory_ids are required")

    db = _supabase_service_client()
    token_hash = str(entitlement.get("agent_token_hash") or "").strip()
    plaintext_token = str(entitlement.get("agent_plaintext_token") or "").strip()

    if entitlement.get("auth_kind") == "agent" and token_hash and plaintext_token:
        data_key = _managed_data_key_from_agent_token(
            db=db,
            user_id=user_id,
            token_hash=token_hash,
            plaintext_token=plaintext_token,
        )
    elif req.managed_passphrase:
        data_key = _managed_data_key_from_passphrase(
            db=db,
            user_id=user_id,
            managed_passphrase=req.managed_passphrase,
        )
    else:
        data_key = _managed_data_key_from_custody(db=db, user_id=user_id)

    result = (
        db.table("memories")
        .select("id,envelope,payload_b64,tags,safe_metadata")
        .eq("user_id", user_id)
        .in_("id", memory_ids)
        .execute()
    )
    rows = getattr(result, "data", None) or []

    rows_by_id = {str(row.get("id") or ""): row for row in rows}
    ordered_rows = [rows_by_id[memory_id] for memory_id in memory_ids if memory_id in rows_by_id]

    items: list[dict[str, Any]] = []

    for row in ordered_rows:
        memory_id = str(row.get("id") or "")
        envelope_data = row.get("envelope") or {}
        payload_b64 = str(row.get("payload_b64") or "")

        try:
            env_json = (
                envelope_data if isinstance(envelope_data, str) else json.dumps(envelope_data)
            )
            env = envelope_from_json(env_json)

            plaintext = decode_envelope(env, payload_b64.encode("ascii"), data_key)

            semantic = decode_semantic_content(
                plaintext,
                metadata={
                    "filename": getattr(env, "filename", None),
                    "mime_type": getattr(env, "mime_type", None),
                    "content_kind": getattr(env, "content_kind", None),
                    "tags": list(getattr(env, "tags", []) or []),
                },
            )
        except Exception as exc:
            raise HTTPException(
                status_code=403,
                detail=f"memory {memory_id} could not be decrypted or interpreted",
            ) from exc

        items.append(
            {
                "memory_id": memory_id,
                "id": memory_id,
                "text": semantic.get("text", ""),
                "preview": semantic.get("preview", ""),
                "semantic": semantic,
                "safe_metadata": row.get("safe_metadata") or {},
                "tags": row.get("tags") or [],
            }
        )

    return {
        "k": k,
        "items": items,
        "memories": items,
    }


@app.post("/managed/agent-tokens")
def managed_agent_tokens_create(
    req: ManagedAgentTokenCreateRequest,
    entitlement: dict[str, Any] = Depends(require_active_subscription),
):
    user_id = entitlement["user_id"]
    _enforce_agent_quota(entitlement)

    name = str(req.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")

    scope = _normalize_scope(req.scope)
    plaintext_token = f"mt_{secrets.token_urlsafe(32)}"
    token_hash = hashlib.sha256(plaintext_token.encode("utf-8")).hexdigest()

    db = _supabase_service_client()
    data_key: bytes | None = None
    if req.managed_passphrase:
        data_key = _managed_data_key_from_passphrase(
            db=db,
            user_id=user_id,
            managed_passphrase=req.managed_passphrase,
        )
    else:
        try:
            data_key = _managed_data_key_from_custody(db=db, user_id=user_id)
        except HTTPException as exc:
            if exc.status_code not in {404, 409}:
                raise
            data_key = None

    agent_key_fields: dict[str, str] = {}
    if data_key is not None:
        salt_b64, wrapped_key_b64 = _wrap_data_key_for_agent_token(data_key, plaintext_token)
        agent_key_fields = {
            "agent_kdf_salt_b64": salt_b64,
            "agent_wrapped_data_key_b64": wrapped_key_b64,
        }

    base_row = {
        "user_id": user_id,
        "token_hash": token_hash,
        "name": name,
    }
    full_row = (
        base_row
        | {
            "scope": scope,
            "expires_at": req.expires_at,
        }
        | agent_key_fields
    )

    insert_result = None
    try:
        insert_result = db.table("agent_tokens").insert(full_row).execute()
    except Exception as exc:
        if agent_key_fields:
            raise
        if "column" in str(exc).lower() and (
            "scope" in str(exc).lower() or "expires_at" in str(exc).lower()
        ):
            insert_result = db.table("agent_tokens").insert(base_row).execute()
        else:
            raise

    rows = getattr(insert_result, "data", None) or []
    token_id = str(rows[0].get("id") if rows else "").strip()
    if not token_id:
        lookup = (
            db.table("agent_tokens")
            .select("id")
            .eq("user_id", user_id)
            .eq("token_hash", token_hash)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        lookup_rows = getattr(lookup, "data", None) or []
        if lookup_rows:
            token_id = str(lookup_rows[0].get("id") or "")

    if not token_id:
        raise HTTPException(status_code=500, detail="Could not create agent token. Please retry.")

    return {
        "id": token_id,
        "token_id": token_id,
        "name": name,
        "scope": scope,
        "expires_at": req.expires_at,
        "token": plaintext_token,
        "token_plaintext": plaintext_token,
    }


@app.get("/managed/agent-tokens")
def managed_agent_tokens_list(entitlement: dict[str, Any] = Depends(require_active_subscription)):
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    result = (
        db.table("agent_tokens")
        .select("*")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .execute()
    )
    rows = getattr(result, "data", None) or []

    items: list[dict[str, Any]] = []
    for row in rows:
        revoked = bool(row.get("revoked") or row.get("revoked_at"))
        items.append(
            {
                "id": row.get("id"),
                "name": row.get("name") or "token",
                "scope": row.get("scope") or "write",
                "created_at": row.get("created_at"),
                "last_used": row.get("last_used"),
                "expires_at": row.get("expires_at"),
                "revoked": revoked,
            }
        )

    return {"items": items, "tokens": items}


@app.delete("/managed/agent-tokens/{token_id}")
def managed_agent_tokens_delete(
    token_id: str, entitlement: dict[str, Any] = Depends(require_active_subscription)
):
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    lookup = (
        db.table("agent_tokens")
        .select("id")
        .eq("id", token_id)
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(lookup, "data", None) or []
    if not rows:
        raise HTTPException(status_code=404, detail="Agent token not found or access denied")

    db.table("agent_tokens").delete().eq("id", token_id).eq("user_id", user_id).execute()
    return {"deleted": True, "ok": True}


@app.post("/agents/connect")
def managed_agents_connect(
    req: ManagedAgentConnectRequest,
    entitlement: dict[str, Any] = Depends(require_active_managed_actor),
):
    if entitlement.get("auth_kind") != "agent":
        raise HTTPException(status_code=401, detail="agent token required")

    _require_agent_scope(entitlement, {"write", "admin"})
    _enforce_agent_quota(entitlement)

    name = str(req.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")

    agent_kind = str(req.agent_kind or "desktop").strip().lower()
    if agent_kind not in {"desktop", "server", "ci"}:
        raise HTTPException(status_code=400, detail="agent_kind must be desktop, server, or ci")

    user_id = entitlement["user_id"]
    token_id = entitlement.get("agent_token_id")
    fingerprint = hashlib.sha256(f"{token_id}:{name}:{agent_kind}".encode("utf-8")).hexdigest()[:24]
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    db = _supabase_service_client()
    row = {
        "user_id": user_id,
        "token_id": token_id,
        "name": name,
        "agent_kind": agent_kind,
        "fingerprint": fingerprint,
        "last_seen": now,
    }

    existing = (
        db.table("agents")
        .select("*")
        .eq("user_id", user_id)
        .eq("token_id", token_id)
        .limit(1)
        .execute()
    )
    existing_rows = getattr(existing, "data", None) or []
    if existing_rows:
        agent_id = existing_rows[0].get("id")
        result = db.table("agents").update(row).eq("id", agent_id).execute()
    else:
        result = db.table("agents").insert(row).execute()

    rows = getattr(result, "data", None) or existing_rows
    agent = rows[0] if rows else {}
    agent_id = str(agent.get("id") or "").strip()
    if not agent_id:
        lookup = (
            db.table("agents")
            .select("*")
            .eq("user_id", user_id)
            .eq("token_id", token_id)
            .limit(1)
            .execute()
        )
        lookup_rows = getattr(lookup, "data", None) or []
        agent = lookup_rows[0] if lookup_rows else {}
        agent_id = str(agent.get("id") or "").strip()

    if not agent_id:
        raise HTTPException(status_code=500, detail="Could not connect agent. Please retry.")

    return {
        "id": agent_id,
        "agent_id": agent_id,
        "fingerprint": agent.get("fingerprint") or fingerprint,
        "name": agent.get("name") or name,
        "agent_kind": agent.get("agent_kind") or agent_kind,
        "connected_at": agent.get("connected_at"),
        "last_seen": agent.get("last_seen") or now,
    }


@app.get("/agents")
def managed_agents_list(entitlement: dict[str, Any] = Depends(require_active_subscription)):
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    result = (
        db.table("agents")
        .select("*")
        .eq("user_id", user_id)
        .order("connected_at", desc=True)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    return {"items": rows, "agents": rows}


@app.delete("/agents/{agent_id}")
def managed_agents_delete(
    agent_id: str,
    entitlement: dict[str, Any] = Depends(require_active_subscription),
):
    user_id = entitlement["user_id"]
    db = _supabase_service_client()
    lookup = (
        db.table("agents").select("id").eq("id", agent_id).eq("user_id", user_id).limit(1).execute()
    )
    rows = getattr(lookup, "data", None) or []
    if not rows:
        raise HTTPException(status_code=404, detail="Agent not found or access denied")

    db.table("agents").delete().eq("id", agent_id).eq("user_id", user_id).execute()
    return {"deleted": True, "ok": True}


@app.post("/webhooks/stripe")
async def stripe_webhook(
    request: Request, stripe_signature: str | None = Header(default=None, alias="Stripe-Signature")
):

    webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET")
    if not webhook_secret:
        raise HTTPException(
            status_code=503,
            detail="STRIPE_WEBHOOK_SECRET is not configured. Add it to process Stripe webhooks.",
        )

    payload = await request.body()

    try:
        import stripe

        event = stripe.Webhook.construct_event(
            payload=payload,
            sig_header=stripe_signature,
            secret=webhook_secret,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid Stripe webhook payload.") from exc
    except Exception as exc:
        if exc.__class__.__name__ == "SignatureVerificationError":
            raise HTTPException(
                status_code=400, detail="Invalid Stripe webhook signature."
            ) from exc
        raise HTTPException(status_code=400, detail="Invalid Stripe webhook signature.") from exc

    event_id = str(event.get("id") or "").strip()
    event_type = str(event.get("type") or "").strip()
    if not event_id or not event_type:
        raise HTTPException(status_code=400, detail="Stripe event is missing required identifiers.")

    db = _supabase_service_client()
    event_record = {
        "event_id": event_id,
        "event_type": event_type,
        "stripe_data": {
            "object_id": ((event.get("data") or {}).get("object") or {}).get("id"),
            "object": ((event.get("data") or {}).get("object") or {}).get("object"),
        },
    }

    try:
        db.table("stripe_webhook_events").insert(event_record).execute()
    except Exception as exc:
        lower = str(exc).lower()
        if (
            "duplicate" in lower
            or "unique" in lower
            or "uq_stripe_webhook_events_event_id" in lower
        ):
            return {"status": "ok", "processed": False, "idempotent": True}
        raise HTTPException(status_code=500, detail="Could not persist webhook event.") from exc

    handled_events = {
        "customer.subscription.created",
        "customer.subscription.updated",
        "customer.subscription.deleted",
        "invoice.payment_succeeded",
        "invoice.payment_failed",
    }

    if event_type not in handled_events:
        return {"status": "ok", "processed": True, "handled": False}

    stripe_object = ((event.get("data") or {}).get("object")) or {}
    processed = False

    if event_type == "customer.subscription.created":
        processed = _upsert_subscription_snapshot_from_stripe(stripe_object)

    elif event_type == "customer.subscription.updated":
        override_status = "active" if bool(stripe_object.get("cancel_at_period_end")) else None
        processed = _upsert_subscription_snapshot_from_stripe(
            stripe_object, override_status=override_status
        )

    elif event_type == "customer.subscription.deleted":
        processed = _upsert_subscription_snapshot_from_stripe(
            stripe_object, override_status="canceled"
        )
        if not processed:
            processed = _update_subscription_status_by_refs(
                status="canceled",
                stripe_customer_id=str(stripe_object.get("customer") or "") or None,
                stripe_subscription_id=str(stripe_object.get("id") or "") or None,
            )

    elif event_type in {"invoice.payment_succeeded", "invoice.payment_failed"}:
        stripe = _get_stripe_module()
        stripe_subscription_id = str(stripe_object.get("subscription") or "").strip() or None
        stripe_customer_id = str(stripe_object.get("customer") or "").strip() or None

        if stripe_subscription_id:
            try:
                subscription = stripe.Subscription.retrieve(stripe_subscription_id)
            except Exception as exc:
                raise HTTPException(
                    status_code=502,
                    detail=f"Could not fetch Stripe subscription ({exc.__class__.__name__}).",
                ) from exc

            override_status = "past_due" if event_type == "invoice.payment_failed" else None
            processed = _upsert_subscription_snapshot_from_stripe(
                _stripe_object_to_dict(subscription),
                override_status=override_status,
            )

        if not processed:
            fallback_status = "past_due" if event_type == "invoice.payment_failed" else "active"
            processed = _update_subscription_status_by_refs(
                status=fallback_status,
                stripe_customer_id=stripe_customer_id,
                stripe_subscription_id=stripe_subscription_id,
            )

    try:
        stripe_data_value = event_record.get("stripe_data")
        stripe_data: dict[str, object] = (
            stripe_data_value if isinstance(stripe_data_value, dict) else {}
        )
        db.table("stripe_webhook_events").update(
            {"stripe_data": {**stripe_data, "processed": bool(processed)}}
        ).eq("event_id", event_id).execute()
    except Exception:
        # Non-blocking metadata update; original event is already journaled.
        pass

    return {"status": "ok", "processed": True, "updated_subscription": bool(processed)}


@app.get("/")
def read_root():
    return {"status": "Matriosha API is running"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/health/secrets")
def health_secrets(_: None = Depends(require_admin_token)):
    names = [
        "SUPABASE_URL",
        "SUPABASE_ANON_KEY",
        "SUPABASE_SERVICE_ROLE_KEY",
        "SUPABASE_JWT_SECRET",
        "SUPABASE_PASSWORD",
        "STRIPE_PUBLISHABLE_KEY",
        "STRIPE_SECRET_KEY",
        "STRIPE_WEBHOOK_SECRET",
        "STRIPE_PRICE_ID_BASE",
        "STRIPE_SUCCESS_URL",
        "STRIPE_CANCEL_URL",
        "GCP_PROJECT_ID",
        "ADMIN_DIAGNOSTICS_TOKEN",
        "ADMIN_TOKEN",
    ]

    return {
        "status": "ok",
        "env": {
            name: {
                "present": bool(os.getenv(name)),
                "length": len(os.getenv(name, "")),
            }
            for name in names
        },
    }


@app.get("/health/deps")
def health_deps(_: None = Depends(require_admin_token)):
    deps: dict[str, dict[str, object]] = {}
    for name in ["supabase", "stripe", "httpx"]:
        try:
            __import__(name)
            deps[name] = {"available": True}
        except Exception as exc:
            deps[name] = {
                "available": False,
                "error": exc.__class__.__name__,
            }

    return {"status": "ok", "deps": deps}


@app.get("/health/supabase")
def health_supabase(_: None = Depends(require_admin_token)):
    try:
        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_ANON_KEY")

        if not url or not key:
            return {"status": "error", "provider": "supabase", "error": "missing_env"}

        client = _create_supabase_client(url, key)
        result = client.auth.admin.list_users(page=1, per_page=1)

        return {
            "status": "ok",
            "provider": "supabase",
            "result_type": type(result).__name__,
        }

    except Exception as exc:
        logger.exception("Supabase health check failed")
        return {
            "status": "error",
            "provider": "supabase",
            "error": exc.__class__.__name__,
            "message": "internal_error",
        }


@app.get("/health/stripe")
def health_stripe(_: None = Depends(require_admin_token)):
    try:
        import httpx

        key = os.getenv("STRIPE_SECRET_KEY")
        if not key:
            return {"status": "error", "provider": "stripe", "error": "missing_env"}

        with httpx.Client(timeout=10.0) as client:
            response = client.get(
                "https://api.stripe.com/v1/account",
                headers={"Authorization": f"Bearer {key}"},
            )

        if response.status_code >= 400:
            try:
                data = response.json()
            except Exception:
                data = {}
            err = data.get("error", {}) if isinstance(data, dict) else {}
            return {
                "status": "error",
                "provider": "stripe",
                "http_status": response.status_code,
                "stripe_error_type": err.get("type"),
                "stripe_error_code": err.get("code"),
                "message": str(err.get("message") or response.text)[:300],
            }

        data = response.json()
        return {
            "status": "ok",
            "provider": "stripe",
            "account_id": data.get("id"),
            "livemode": data.get("livemode"),
            "charges_enabled": data.get("charges_enabled"),
            "payouts_enabled": data.get("payouts_enabled"),
        }

    except Exception as exc:
        logger.exception("Stripe health check failed")
        return {
            "status": "error",
            "provider": "stripe",
            "error": exc.__class__.__name__,
            "message": "internal_error",
        }


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
