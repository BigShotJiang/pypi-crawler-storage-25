"""`matriosha memory search` command."""

from __future__ import annotations

import asyncio
import json
import math
import os
from collections.abc import Iterable
from typing import cast

import typer

from .common import (
    AuthError,
    EXIT_AUTH,
    EXIT_INTEGRITY,
    EXIT_UNKNOWN,
    EXIT_USAGE,
    IntegrityError,
    InvalidInput,
    LocalStore,
    ManagedBackupError,
    Table,
    Vault,
    VaultIntegrityError,
    _SEMANTIC_SEARCH_TEXT_LIMIT,
    _decode_with_corruption_handling,
    _emit_error,
    _is_missing_vault_error,
    _preview_plaintext,
    _require_managed_session_for_memory,
    _resolve_passphrase,
    _semantic_from_plaintext,
    _short,
    get_active_profile,
    get_default_embedder,
    load_config,
    make_console,
    resolve_output,
)
from matriosha.cli.commands.memory.index import build_missing_local_vectors
from matriosha.core.binary_protocol import envelope_from_json
from matriosha.core.vectors import LocalVectorIndex  # noqa: F401 - compatibility for tests/monkeypatching
from matriosha.core.local_vectors import get_local_vector_index
from matriosha.core.managed.client import ManagedClient, resolve_managed_endpoint
from matriosha.core.retrieval_ranking import hybrid_retrieval_score
from matriosha.core.search_terms import extract_search_terms, keyed_search_tokens


DEFAULT_LOCAL_CANDIDATE_LIMIT = 50
MAX_LOCAL_CANDIDATE_LIMIT = 200
CANDIDATE_LIMIT_SCALE_BASE = 1000


def _scaled_candidate_limit(
    memory_count: int, *, minimum: int = DEFAULT_LOCAL_CANDIDATE_LIMIT
) -> int:
    """Return a sublinear candidate pool size as the vault grows."""

    count = max(int(memory_count), 0)
    if count <= CANDIDATE_LIMIT_SCALE_BASE:
        return minimum
    scaled = math.ceil(minimum * math.sqrt(count / CANDIDATE_LIMIT_SCALE_BASE))
    return min(MAX_LOCAL_CANDIDATE_LIMIT, max(minimum, scaled))


def _cosine_score(left: Iterable[float], right: Iterable[float]) -> float:
    left_values = [float(value) for value in left]
    right_values = [float(value) for value in right]
    numerator = sum(a * b for a, b in zip(left_values, right_values))
    left_norm = sum(a * a for a in left_values) ** 0.5
    right_norm = sum(b * b for b in right_values) ** 0.5
    if left_norm == 0.0 or right_norm == 0.0:
        return 0.0
    return numerator / (left_norm * right_norm)


def _rerank_text_from_row(row: dict[str, object]) -> str:
    semantic = row.get("semantic")
    if isinstance(semantic, dict):
        for key in ("text", "preview"):
            value = semantic.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    preview = row.get("preview")
    return str(preview or "").strip()


def _search_format_bytes(n: int) -> str:
    value = float(n)
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            if unit == "bytes":
                return f"{int(value):,} bytes"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{n:,} bytes"


def register(app: typer.Typer) -> None:
    @app.command("search")
    def search(
        ctx: typer.Context,
        query: str = typer.Argument(..., help="Semantic query to search memories."),
        k: int = typer.Option(
            10, "--k", min=1, help="Maximum number of nearest memories to retrieve."
        ),
        threshold: float = typer.Option(
            0.0, "--threshold", help="Minimum cosine score to include."
        ),
        tag: str | None = typer.Option(
            None, "--tag", help="Filter results by tag after ANN search."
        ),
        json_output_flag: bool = typer.Option(
            False, "--json", help="Show JSON output for scripts and automation."
        ),
    ) -> None:
        """Search saved memories by meaning."""

        output = resolve_output(ctx, json_flag=json_output_flag)
        gctx = output.ctx
        json_output = gctx.json_output
        console = make_console()

        try:
            if threshold < -1.0 or threshold > 1.0:
                raise InvalidInput("--threshold must be between -1.0 and 1.0")

            cfg = load_config()
            profile = get_active_profile(cfg, gctx.profile)

            store = LocalStore(profile.name)
            vault = None
            embedder = get_default_embedder()
            query_vec = embedder.embed(query)
            candidate_ids = None
            if tag is not None:
                candidate_ids = {
                    memory_id
                    for memory_id, meta in store.index_metadata().items()
                    if tag in cast(list[str], meta.get("tags", []))
                }

            memory_count = len(store.index_metadata())
            local_candidate_limit = max(k, _scaled_candidate_limit(memory_count))

            if profile.mode == "managed":
                _require_managed_session_for_memory(
                    profile,
                    json_output=json_output,
                    plain=gctx.plain,
                    console=console,
                )

                vault = Vault.unlock(
                    profile.name,
                    _resolve_passphrase(
                        profile_name=profile.name,
                        profile_mode=profile.mode,
                        json_output=json_output,
                    ),
                )
                store = LocalStore(profile.name, data_key=vault.data_key)
                build_missing_local_vectors(
                    profile_name=profile.name,
                    profile_mode=profile.mode,
                    data_key=vault.data_key,
                    limit=250,
                )
                index = get_local_vector_index(profile.name, data_key=vault.data_key)
                candidates: list[tuple[str, float, dict[str, object]]] = [
                    (memory_id, score, {})
                    for memory_id, score in index.search(
                        query_vec,
                        k=local_candidate_limit,
                        candidate_ids=candidate_ids,
                    )
                ]

                if not candidates and profile.mode == "managed":
                    if vault is None:
                        vault = Vault.unlock(
                            profile.name,
                            _resolve_passphrase(
                                profile_name=profile.name,
                                profile_mode=profile.mode,
                                json_output=json_output,
                            ),
                        )
                    search_terms = extract_search_terms(query, tag)
                    metadata_hashes = keyed_search_tokens(search_terms, vault.data_key)
                    if metadata_hashes:
                        token = _require_managed_session_for_memory(
                            profile,
                            json_output=json_output,
                            plain=gctx.plain,
                            console=console,
                        )
                        endpoint = resolve_managed_endpoint(
                            getattr(profile, "managed_endpoint", None),
                            os.getenv("MATRIOSHA_MANAGED_ENDPOINT"),
                        )

                        async def _managed_candidates() -> list[dict[str, object]]:
                            async with ManagedClient(
                                token=str(token), base_url=endpoint, managed_mode=False
                            ) as client:
                                return await client.search_candidates(metadata_hashes, limit=50)

                        try:
                            managed_items = asyncio.run(_managed_candidates())
                        except Exception:  # noqa: BLE001
                            managed_items = []

                        for item in managed_items:
                            memory_id = str(item.get("memory_id") or item.get("id") or "")
                            if not memory_id:
                                continue
                            candidates.append((memory_id, 1.0, item))

                if not candidates:
                    if json_output:
                        output.json(
                            {
                                "status": "ok",
                                "operation": "memory.search",
                                "data": {
                                    "query": query,
                                    "k": k,
                                    "threshold": threshold,
                                    "tag": tag,
                                    "results": [],
                                },
                                "error": None,
                            }
                        )
                        raise typer.Exit(code=0)

                    if gctx.plain:
                        typer.echo("no matching memories found")
                        raise typer.Exit(code=0)

                    console.print(f'Found [bold]0[/bold] memories for "[cyan]{query}[/cyan]"')
                    if profile.mode == "managed":
                        console.print(
                            "No local vector matches found. If this is a new device, run: "
                            f"[bold]matriosha --profile {profile.name} vault pull[/bold]"
                        )
                    else:
                        console.print(
                            f'Nothing matched. Save one with: [bold]matriosha --profile {profile.name} memory remember "your note"[/bold]'
                        )
                    raise typer.Exit(code=0)

                if vault is None:
                    vault = Vault.unlock(
                        profile.name,
                        _resolve_passphrase(
                            profile_name=profile.name,
                            profile_mode=profile.mode,
                            json_output=json_output,
                        ),
                    )
            else:
                vault = Vault.unlock(
                    profile.name,
                    _resolve_passphrase(
                        profile_name=profile.name,
                        profile_mode=profile.mode,
                        json_output=json_output,
                    ),
                )
                existing_envelopes = store.list(limit=1)
                if not existing_envelopes:
                    if json_output:
                        output.json(
                            {
                                "status": "ok",
                                "operation": "memory.search",
                                "data": {
                                    "query": query,
                                    "k": k,
                                    "threshold": threshold,
                                    "tag": tag,
                                    "results": [],
                                },
                                "error": None,
                            }
                        )
                        raise typer.Exit(code=0)

                    if gctx.plain:
                        typer.echo("no matching memories found")
                        raise typer.Exit(code=0)

                    console.print(f'Found [bold]0[/bold] memories for "[cyan]{query}[/cyan]"')
                    console.print(
                        f'Nothing to search yet. Save one with: [bold]matriosha --profile {profile.name} memory remember "your note"[/bold]'
                    )
                    raise typer.Exit(code=0)

                build_missing_local_vectors(
                    profile_name=profile.name,
                    profile_mode=profile.mode,
                    data_key=vault.data_key,
                    limit=250,
                )
                index = get_local_vector_index(profile.name, data_key=vault.data_key)
                candidates = [
                    (memory_id, score, {})
                    for memory_id, score in index.search(
                        query_vec, k=k, candidate_ids=candidate_ids
                    )
                ]

            rows: list[dict[str, object]] = []
            for memory_id, score, managed_item in candidates:
                if not memory_id or score < threshold:
                    continue

                try:
                    if managed_item:
                        env_data = (
                            managed_item.get("envelope")
                            or managed_item.get("metadata")
                            or managed_item
                        )
                        b64_payload_text = str(
                            managed_item.get("payload_b64") or managed_item.get("payload") or ""
                        )
                        b64_payload = b64_payload_text.encode("ascii")
                        env_json = env_data if isinstance(env_data, str) else json.dumps(env_data)
                        env = envelope_from_json(env_json)
                    else:
                        env, b64_payload_bytes = store.get(memory_id)
                        b64_payload = (
                            b64_payload_bytes
                            if isinstance(b64_payload_bytes, bytes)
                            else str(b64_payload_bytes).encode("ascii")
                        )
                except (FileNotFoundError, ValueError):
                    continue

                if tag is not None and tag not in env.tags:
                    continue

                if vault is None:
                    vault = Vault.unlock(
                        profile.name,
                        _resolve_passphrase(
                            profile_name=profile.name,
                            profile_mode=profile.mode,
                            json_output=json_output,
                        ),
                    )

                plaintext, integrity_warning, restored_from_backup = (
                    _decode_with_corruption_handling(
                        env=env,
                        b64_payload=b64_payload,
                        key=vault.data_key,
                        profile_mode=profile.mode,
                        memory_id=memory_id,
                        store=store,
                    )
                )

                if plaintext is not None:
                    semantic = _semantic_from_plaintext(
                        plaintext=plaintext,
                        envelope_tags=env.tags,
                        memory_id=memory_id,
                        text_limit=_SEMANTIC_SEARCH_TEXT_LIMIT,
                        filename=getattr(env, "filename", None),
                        mime_type=getattr(env, "mime_type", None),
                        content_kind=getattr(env, "content_kind", None),
                    )
                    filename = getattr(env, "filename", None)
                    mime_type = getattr(env, "mime_type", None)
                    content_kind = getattr(env, "content_kind", None)
                    plaintext_bytes = getattr(env, "plaintext_bytes", None) or len(plaintext)

                    if content_kind == "binary" or filename:
                        preview_parts = []
                        if filename:
                            preview_parts.append(f"File: {filename}")
                        if mime_type:
                            preview_parts.append(f"Type: {mime_type}")
                        preview_parts.append(f"Size: {_search_format_bytes(int(plaintext_bytes))}")
                        preview = "\n".join(preview_parts)
                        semantic = {
                            "kind": content_kind or "file",
                            "filename": filename,
                            "mime_type": mime_type,
                            "preview": preview,
                            "metadata": {
                                "input_bytes": int(plaintext_bytes),
                                "blocks": len(getattr(env, "merkle_leaves", []) or []),
                            },
                            "warnings": list(cast(list[str], semantic.get("warnings") or [])),
                        }
                    else:
                        preview = str(semantic.get("preview") or "")[:80] or _preview_plaintext(
                            plaintext, max_chars=80
                        )
                else:
                    plaintext_bytes = getattr(env, "plaintext_bytes", None) or 0
                    preview = "Unavailable: encrypted memory failed integrity checks"
                    semantic = {
                        "kind": "corrupted",
                        "filename": getattr(env, "filename", None),
                        "mime_type": getattr(env, "mime_type", None),
                        "preview": preview,
                        "metadata": {
                            "input_bytes": int(plaintext_bytes),
                            "blocks": len(getattr(env, "merkle_leaves", []) or []),
                        },
                        "warnings": [],
                    }

                if integrity_warning:
                    semantic_warnings = list(cast(list[str], semantic.get("warnings") or []))
                    semantic_warnings.append(integrity_warning)
                    semantic["warnings"] = semantic_warnings

                rows.append(
                    {
                        "rank": len(rows) + 1,
                        "memory_id": memory_id,
                        "score": score,
                        "tags": env.tags,
                        "created_at": env.created_at,
                        "preview": preview,
                        "semantic": semantic,
                        "integrity_warning": integrity_warning,
                        "restored_from_backup": restored_from_backup,
                    }
                )

            # Zero-knowledge local reranking: after candidates are fetched and decrypted locally,
            # recompute semantic scores over local plaintext-derived previews only.
            reranked_rows: list[dict[str, object]] = []
            for row in rows:
                rerank_text = _rerank_text_from_row(row)
                if not rerank_text:
                    reranked_rows.append(row)
                    continue
                try:
                    local_score = _cosine_score(query_vec, embedder.embed(rerank_text))
                    row["initial_score"] = row["score"]
                    row["semantic_score"] = round(float(local_score), 6)
                    row["score"] = hybrid_retrieval_score(
                        query=query,
                        candidate_text=rerank_text,
                        semantic_score=float(local_score),
                    )
                except Exception:  # noqa: BLE001
                    row["rerank_warning"] = (
                        "local rerank unavailable; initial candidate score retained"
                    )
                reranked_rows.append(row)

            rows = sorted(
                reranked_rows,
                key=lambda row: float(cast(float | int, row.get("score", 0.0))),
                reverse=True,
            )[:k]
            for rank, row in enumerate(rows, start=1):
                row["rank"] = rank

            if json_output:
                payload = {
                    "status": "ok",
                    "operation": "memory.search",
                    "data": {
                        "query": query,
                        "k": k,
                        "threshold": threshold,
                        "tag": tag,
                        "results": [
                            {
                                "memory_id": row["memory_id"],
                                "score": row["score"],
                                "tags": row["tags"],
                                "created_at": row["created_at"],
                                "preview": row["preview"],
                                "semantic": row["semantic"],
                                "integrity_warning": row["integrity_warning"],
                                "restored_from_backup": row["restored_from_backup"],
                            }
                            for row in rows
                        ],
                    },
                    "error": None,
                }
                output.json(payload)
                raise typer.Exit(code=0)

            if gctx.plain:
                for row in rows:
                    row_tags = cast(list[str], row["tags"])
                    tags_str = ",".join(row_tags) if row_tags else "-"
                    typer.echo(
                        f"{row['rank']}\t{row['memory_id']}\t{float(cast(float | int | str, row['score'])):.4f}\t{row['created_at']}\t"
                        f"{tags_str}\t{row['preview']}"
                    )
                if not rows:
                    typer.echo("no matching memories found")
                raise typer.Exit(code=0)

            result_word = "memory" if len(rows) == 1 else "memories"
            console.print(
                f'Found [bold]{len(rows)}[/bold] {result_word} for "[cyan]{query}[/cyan]"'
            )

            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("#", justify="right", width=3)
            table.add_column("Memory", max_width=20, overflow="ellipsis")
            table.add_column("Match", justify="right", width=7)
            table.add_column("When", max_width=19, overflow="ellipsis")
            table.add_column("Tags", max_width=22, overflow="ellipsis")
            table.add_column("Preview", ratio=1, overflow="fold")

            for row in rows:
                table.add_row(
                    str(row["rank"]),
                    _short(str(row["memory_id"]), head=8, tail=6),
                    f"{max(0.0, min(1.0, float(cast(float | int | str, row['score'])))) * 100:.0f}%",
                    str(row["created_at"]).replace("T", " ").replace("Z", " UTC").split(".")[0],
                    " ".join(f"#{t}" for t in cast(list[str], row["tags"])) if row["tags"] else "-",
                    str(row["preview"]),
                )

            console.print(table)
            if rows:
                first_id = str(rows[0]["memory_id"])
                console.print(
                    f"Recall top result: [bold]matriosha --profile {profile.name} memory recall {first_id}[/bold]"
                )
            raise typer.Exit(code=0)

        except InvalidInput as exc:
            _emit_error(
                title="Invalid search input",
                category="VAL",
                stable_code="VAL-005",
                exit_code=EXIT_USAGE,
                fix="provide a query, valid threshold range, and valid tag filters",
                debug=f"detail={exc}",
                json_output=json_output,
                plain=gctx.plain,
                console=console,
            )
            raise typer.Exit(code=EXIT_USAGE)
        except AuthError as exc:
            if _is_missing_vault_error(exc):
                _emit_error(
                    title="Vault not initialized",
                    category="AUTH",
                    stable_code="AUTH-001",
                    exit_code=EXIT_AUTH,
                    fix="Run: matriosha vault init",
                    debug=f"profile={profile.name} provider=local_vault missing_vault",
                    json_output=json_output,
                    plain=gctx.plain,
                    console=console,
                )
                raise typer.Exit(code=EXIT_AUTH) from None
            _emit_error(
                title="Vault unlock failed",
                category="AUTH",
                stable_code="AUTH-002",
                exit_code=EXIT_AUTH,
                fix="Use the correct vault passphrase and try again.",
                debug="provider=local_vault profile_auth_failed",
                json_output=json_output,
                plain=gctx.plain,
                console=console,
            )
            raise typer.Exit(code=EXIT_AUTH)
        except IntegrityError:
            _emit_error(
                title="Memory integrity verification failed",
                category="SYS",
                stable_code="SYS-011",
                exit_code=EXIT_INTEGRITY,
                fix="run `matriosha vault verify --deep` to inspect corrupted entries",
                debug="phase=memory.search preview_decode_failed",
                json_output=json_output,
                plain=gctx.plain,
                console=console,
            )
            raise typer.Exit(code=EXIT_INTEGRITY)
        except ManagedBackupError as exc:
            _emit_error(
                title="Managed backup restore failed",
                category="STORE",
                stable_code="STORE-009",
                exit_code=EXIT_UNKNOWN,
                fix="verify managed credentials/network and retry search",
                debug=f"backup_error={type(exc).__name__}",
                json_output=json_output,
                plain=gctx.plain,
                console=console,
            )
            raise typer.Exit(code=EXIT_UNKNOWN)
        except (VaultIntegrityError, OSError, ValueError) as exc:
            if _is_missing_vault_error(exc):
                _emit_error(
                    title="Vault not initialized",
                    category="AUTH",
                    stable_code="AUTH-001",
                    exit_code=EXIT_AUTH,
                    fix="Run: matriosha vault init",
                    debug=f"profile={profile.name} provider=local_vault missing_vault",
                    json_output=json_output,
                    plain=gctx.plain,
                    console=console,
                )
                raise typer.Exit(code=EXIT_AUTH)

            _emit_error(
                title="Local storage operation failed",
                category="STORE",
                stable_code="STORE-005",
                exit_code=EXIT_UNKNOWN,
                fix="check local memory files and vector index, then retry",
                debug=f"os_error={type(exc).__name__}",
                json_output=json_output,
                plain=gctx.plain,
                console=console,
            )
            raise typer.Exit(code=EXIT_UNKNOWN)
