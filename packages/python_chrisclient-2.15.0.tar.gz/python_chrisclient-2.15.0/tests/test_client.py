
import json
from random import randint
from unittest import TestCase
from unittest import mock

from chrisclient import client


class ClientTests(TestCase):

    def setUp(self):
        self.chris_url = "http://localhost:8000/api/v1/"
        self.username = "cube"
        self.password = "cube1234"
        self.client = client.Client(self.chris_url, self.username, self.password)
        resp = self.client.get_plugins({'name_exact': "pl-dircopy"})
        self.fs_plg_id = resp['data'][0]['id']

    def test_get_feed_by_id(self):
        """
        Test whether the get_feed_by_id method can get a feed representation from CUBE.
        """
        response = self.client.get_feed_by_id(1)
        self.assertEqual(response['id'], 1)

    def test_get_plugin_by_id(self):
        """
        Test whether the get_plugin_by_id method can get a plugin representation from CUBE.
        """
        response = self.client.get_plugin_by_id(1)
        self.assertEqual(response['id'], 1)

    def test_get_plugin_by_id_unauthenticated(self):
        """
        Test whether the get_plugin_by_id method can get a plugin representation from CUBE
        for unauthenticated users.
        """
        cl = client.Client(self.chris_url)
        response = cl.get_plugin_by_id(1)
        self.assertEqual(response['id'], 1)

    def test_get_plugin_parameters(self):
        """
        Test whether the get_plugin_parameters method can get the list of all plugin parameter
        representations for the given plugin from CUBE.
        """
        plugin_id = self.fs_plg_id
        response = self.client.get_plugin_parameters(plugin_id,
                                                     {'limit': 50, 'offset': 0})
        self.assertEqual(response['data'][0]['name'], "dir")

    def test_get_plugin_parameters_unauthenticated(self):
        """
        Test whether the get_plugin_parameters method can get the list of all plugin parameter
        representations for the given plugin from CUBE for unauthenticated users.
        """
        cl = client.Client(self.chris_url)
        plugin_id = self.fs_plg_id
        response = cl.get_plugin_parameters(plugin_id, {'limit': 50, 'offset': 0})
        self.assertEqual(response['data'][0]['name'], "dir")

    def test_get_plugins_with_no_args(self):
        """
        Test whether the get_plugins method can get the list of all plugin representations
        from CUBE.
        """
        response = self.client.get_plugins()
        self.assertGreater(len(response['data']), 1)

    def test_get_plugins_with_no_args_unauthenticated(self):
        """
        Test whether the get_plugins method can get the list of all plugin representations
        from CUBE for unauthenticated users.
        """
        cl = client.Client(self.chris_url)
        response = cl.get_plugins()
        self.assertGreater(len(response['data']), 1)

    def test_get_plugins_with_search_args(self):
        """
        Test whether the get_plugins method can get a list of plugin representations
        from CUBE given query search parameters.
        """
        response = self.client.get_plugins({'name_exact': "pl-dircopy"})
        self.assertEqual(response['data'][0]['name'], "pl-dircopy")

    def test_create_plugin_instance(self):
        """
        Test whether create_plugin_instance method can create a new plugin instance
        through the REST API.
        """
        plugin_id = self.fs_plg_id
        data = {
            'title': 'Test plugin instance',
            'dir': 'home/' + self.username + '/uploads'
        }
        response = self.client.create_plugin_instance(plugin_id, data)
        self.assertEqual(response['title'], data['title'])

    def test_get_pipeline_by_id(self):
        """
        Test whether the get_pipeline_by_id method can get a pipeline representation from
        CUBE.
        """
        response = self.client.get_pipeline_by_id(2)
        self.assertEqual(response['id'], 2)

    def test_get_pipeline_default_parameters(self):
        """
        Test whether the get_pipeline_default_parameters method can get the list of all
        pipeline parameter representations for the given pipeline from CUBE.
        """
        pipeline_id = 2
        response = self.client.get_pipeline_default_parameters(pipeline_id,
                                                               {'limit': 50, 'offset': 0})
        self.assertEqual(response['total'], 18)
        first_param = response['data'][0]
        self.assertIn('plugin_piping_id', first_param)
        self.assertIn('previous_plugin_piping_id', first_param)
        self.assertIn('plugin_piping_title', first_param)
        self.assertIn('plugin_piping_cpu_limit', first_param)
        self.assertIn('plugin_piping_memory_limit', first_param)
        self.assertIn('plugin_piping_gpu_limit', first_param)
        self.assertIn('plugin_piping_number_of_workers', first_param)

    def test_get_pipeline_default_parameters_unauthenticated(self):
        """
        Test whether the get_pipeline_default_parameters method can get the list of all
        pipeline parameter representations for the given pipeline from CUBE for
        unauthenticated users.
        """
        cl = client.Client(self.chris_url)
        pipeline_id = 2
        response = cl.get_pipeline_default_parameters(pipeline_id,
                                                      {'limit': 50, 'offset': 0})
        self.assertEqual(response['total'], 18)

    def test_create_workflow(self):
        """
        Test whether create_workflow method can create a new workflow through the REST
        API.
        """
        pipeline_id = 2
        nodes = [
            {"piping_id": 3, "compute_resource_name": "host",
             "plugin_parameter_defaults": [{"name": "prefix", "default": "test"},
                                           {"name": "dummyInt", "default": 3}]},
            {"piping_id": 4, "compute_resource_name": "host"},
            {"piping_id": 5, "compute_resource_name": "host"}
        ]
        data = {
            'title': 'Workflow1',
            'previous_plugin_inst_id': 1,
            'nodes_info': json.dumps(nodes)
        }
        response = self.client.create_workflow(pipeline_id, data)
        workflow_title = response['title']
        self.assertEqual(workflow_title, data['title'])
        workflow_id = response['id']
        response = self.client.get_workflow_plugin_instances(workflow_id, data)
        self.assertEqual(response['total'], 3)

    def test_compute_workflow_nodes_info(self):
        """
        Test whether the compute_workflow_nodes_info method correctly builds a
        nodes_info structure from a pipeline's default parameters.
        """
        pipeline_id = 2
        response = self.client.get_pipeline_default_parameters(
            pipeline_id, {'limit': 50, 'offset': 0})
        default_params = response['data']

        nodes_info = self.client.compute_workflow_nodes_info(default_params)

        expected_piping_ids = {p['plugin_piping_id'] for p in default_params}
        self.assertEqual(len(nodes_info), len(expected_piping_ids))
        for node in nodes_info:
            self.assertIn('piping_id', node)
            self.assertIn('previous_piping_id', node)
            self.assertEqual(node['compute_resource_name'], 'host')
            self.assertIn('title', node)
            self.assertIn('cpu_limit', node)
            self.assertIn('memory_limit', node)
            self.assertIn('gpu_limit', node)
            self.assertIn('number_of_workers', node)
            if 'plugin_parameter_defaults' in node:
                for param in node['plugin_parameter_defaults']:
                    self.assertIsNone(param['default'])

    def test_get_user(self):
        """
        Test whether the get_user method can get a user representation from CUBE.
        """
        response = self.client.get_user()
        self.assertEqual(response['username'], 'cube')

    def test_create_user(self):
        """
        Test whether static create_user method can create a new user account
        through the REST API.
        """
        username = f'cube{randint(1000,9000)}'
        password = f'{username}1234'
        email = f'{username}@gmail.com'
        response = client.Client.create_user('http://localhost:8000/api/v1/users/',
                                             username, password, email)
        self.assertEqual(response['username'], username)

    def test_get_pacs_by_id(self):
        """
        Test whether the get_pacs_by_id method can get a pacs representation from CUBE.
        """
        response = self.client.get_pacs_by_id(1)
        self.assertEqual(response['id'], 1)

    def test_get_pacs_query_by_id(self):
        """
        Test whether the get_pacs_query_by_id method can get a pacs query representation
        from CUBE.
        """
        response = self.client.get_pacs_query_by_id(1)
        self.assertEqual(response['id'], 1)

    def test_create_pacs_query(self):
        """
        Test whether the create_pacs_query method can create a new PACS query
        through the REST API.
        """
        pacs_id = 1
        data = {
            'title': f'TestQuery{randint(1000,9000)}',
            'query': '{"SeriesInstanceUID": "1.3.12"}'
        }
        response = self.client.create_pacs_query(pacs_id, data)
        self.assertEqual(response['title'], data['title'])

    def test_create_pacs_retrieve(self):
        """
        Test whether the create_pacs_retrieve method can create a new PACS retrieve
        through the REST API.
        """
        query_id = 1
        response = self.client.create_pacs_retrieve(query_id)
        self.assertEqual(response['pacs_query_id'], 1)


class ClientWithTokenTests(ClientTests):

    def setUp(self):
        super().setUp()

        self.token = client.Client.get_auth_token(self.chris_url + 'auth-token/',
                                                  self.username, self.password)
        self.client = client.Client(url=self.chris_url, token=self.token)
