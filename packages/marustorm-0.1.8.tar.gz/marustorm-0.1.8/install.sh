#!/usr/bin/env bash
# MaruStorm One-Line Installer
# Supports: macOS, Linux (x86_64, aarch64)
# Usage: curl -fsSL https://raw.githubusercontent.com/claudianus/marustorm/main/install.sh | bash

set -euo pipefail

REPO="claudianus/marustorm"
PKG="marustorm"
MIN_PYTHON="3.12"
PYTHON_VERSION="3.13"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

info() { printf "${BLUE}[info]${NC} %s\n" "$*"; }
ok()   { printf "${GREEN}[ok]${NC}   %s\n" "$*"; }
warn() { printf "${YELLOW}[warn]${NC}  %s\n" "$*"; }
err()  { printf "${RED}[err]${NC}  %s\n" "$*" >&2; }
step() { printf "\n${BOLD}${CYAN}▶ %s${NC}\n" "$*"; }

banner() {
    cat <<'EOF'
   __  ___           __                  __
  /  |/  /__ ___ _  / /  ___  ___  ____ / /_
 / /|_/ / -_) _ `/ / _ \/ _ \/ _ \/ __// __/
/_/  /_/\__/\_,_/ /_.__/\___/\___/_/   \__/
EOF
    echo ""
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

python_meets_requirement() {
    local py="$1"
    if ! command_exists "$py"; then
        return 1
    fi
    local ver
    ver="$($py -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)"
    if [ -z "$ver" ]; then
        return 1
    fi
    # Simple version compare: 3.13 >= 3.12
    if [ "$(printf '%s\n' "$MIN_PYTHON" "$ver" | sort -V | head -n1)" = "$MIN_PYTHON" ]; then
        return 0
    fi
    return 1
}

install_uv() {
    step "Installing uv (fast Python package manager)"
    if command_exists uv; then
        ok "uv already installed: $(uv --version 2>/dev/null | head -1)"
        return 0
    fi

    info "Downloading uv installer..."
    curl -fsSL https://astral.sh/uv/install.sh | sh

    # Try to source the updated PATH
    if [ -f "$HOME/.local/bin/env" ]; then
        # shellcheck source=/dev/null
        . "$HOME/.local/bin/env"
    elif [ -f "$HOME/.cargo/env" ]; then
        # shellcheck source=/dev/null
        . "$HOME/.cargo/env"
    fi

    # Check again
    if ! command_exists uv; then
        export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
    fi

    if command_exists uv; then
        ok "uv installed: $(uv --version 2>/dev/null | head -1)"
    else
        err "uv installation failed. Please install manually: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    fi
}

ensure_python() {
    step "Checking Python version"

    # Check system Python first
    if python_meets_requirement python3; then
        ok "System Python $(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")') meets requirement (>=$MIN_PYTHON)"
        return 0
    fi

    if python_meets_requirement python; then
        ok "System Python $(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")') meets requirement (>=$MIN_PYTHON)"
        return 0
    fi

    warn "System Python is too old (< $MIN_PYTHON)"
    info "Installing Python $PYTHON_VERSION via uv..."
    uv python install "$PYTHON_VERSION"
    ok "Python $PYTHON_VERSION installed via uv"
}

install_marustorm() {
    step "Installing MaruStorm"

    if command_exists marustorm; then
        local current
        current="$(marustorm --version 2>/dev/null | sed 's/.*version //')"
        info "MaruStorm already installed: v$current"
        info "Upgrading to latest version..."
    fi

    # Determine the Python to use
    local py_arg=""
    if uv python find "$PYTHON_VERSION" >/dev/null 2>&1; then
        py_arg="--python $(uv python find "$PYTHON_VERSION")"
    elif uv python find "$MIN_PYTHON" >/dev/null 2>&1; then
        py_arg="--python $(uv python find "$MIN_PYTHON")"
    elif python_meets_requirement python3; then
        py_arg="--python python3"
    elif python_meets_requirement python; then
        py_arg="--python python"
    fi

    # shellcheck disable=SC2086
    uv tool install --force "$PKG" $py_arg

    if ! command_exists marustorm; then
        # Try adding uv tool bin to PATH
        export PATH="$(uv tool dir)/bin:$PATH"
    fi

    if command_exists marustorm; then
        local version
        version="$(marustorm --version 2>/dev/null | sed 's/.*version //')"
        ok "MaruStorm v$version installed successfully"
    else
        err "MaruStorm installation failed"
        exit 1
    fi
}

init_workspace() {
    step "Initializing workspace"
    local ws
    ws="${MARUSTORM_WS:-$HOME/marustorm-notes}"

    if [ -d "$ws/.marustorm" ] || [ -d "$ws/inbox" ]; then
        info "Workspace already exists at $ws"
    else
        info "Creating workspace at $ws..."
        mkdir -p "$ws"
        marustorm init --notes-dir "$ws"
    fi

    ok "Workspace ready: $ws"
}

print_next_steps() {
    echo ""
    echo -e "${GREEN}${BOLD}✓ MaruStorm is ready!${NC}"
    echo ""
    echo -e "${BOLD}Quick start:${NC}"
    echo "  marustorm           # Launch TUI"
    echo "  ms                  # Short alias"
    echo ""
    echo -e "${BOLD}Create your first note:${NC}"
    echo "  marustorm new \"My First Idea\""
    echo ""
    echo -e "${BOLD}Workspace:${NC}"
    echo "  ~/marustorm-notes"
    echo ""
    echo -e "${BOLD}Help:${NC}"
    echo "  Press ? inside the TUI for all commands"
    echo "  marustorm --help"
    echo ""
}

main() {
    banner
    info "Detected OS: $(uname -s) | Arch: $(uname -m)"

    install_uv
    ensure_python
    install_marustorm
    init_workspace
    print_next_steps
}

main "$@"
