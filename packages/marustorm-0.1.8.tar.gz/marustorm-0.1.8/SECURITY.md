# Security Policy / 보안 정책

## Reporting a Vulnerability / 취약점 신고

If you discover a security vulnerability in MaruStorm, please report it privately.
MaruStorm에서 보안 취약점을 발견하셨다면 비공개로 신고해 주세요.

### How to Report / 신고 방법

- **Email**: claudianus@engineer.com
- **GitHub Security Advisories**: [Create a private advisory](https://github.com/claudianus/marustorm/security/advisories/new)

### What to Include / 포함할 내용

- Description of the vulnerability / 취약점 설명
- Steps to reproduce / 재현 방법
- Potential impact / 잠재적 영향
- Suggested fix (if any) / 제안하는 수정 (있는 경우)

### Response Time / 응답 시간

- Acknowledgment within 48 hours / 48시간 내 확인
- Initial assessment within 7 days / 7일 내 초기 평가
- Fix release as soon as possible / 가능한 한 빨리 수정 릴리스

## Supported Versions / 지원 버전

| Version | Supported |
|---------|-----------|
| 0.1.x   | ✅ Yes |
| < 0.1.0 | ❌ No |

## Security Best Practices / 보안 모범 사례

- Never commit API keys to git / API 키를 git에 커밋하지 마세요
- Use fine-grained GitHub PATs / 세분화된 GitHub PAT를 사용하세요
- Keep dependencies updated / 의존성을 최신 상태로 유지하세요
