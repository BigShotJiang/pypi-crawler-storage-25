from __future__ import annotations
from typing import Any

def is_notification_message(*args: Any, **kwargs: Any) -> bool:
    return False
