from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class NotificationEvent:
    title: str = ""
    message: str = ""
    data: dict[str, Any] | None = None


class NotificationManager:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass

    async def send(self, event: NotificationEvent) -> None:
        pass


class NotificationView:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass


def build_notification_message(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def extract_notification_ids(*args: Any, **kwargs: Any) -> list[str]:
    return []


def to_wire_notification(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def is_notification_message(*args: Any, **kwargs: Any) -> bool:
    return False
