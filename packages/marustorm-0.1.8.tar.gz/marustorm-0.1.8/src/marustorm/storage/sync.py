from __future__ import annotations

import asyncio
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from loguru import logger

from marustorm.storage.github import GitHubSync


@dataclass
class SyncItem:
    id: int
    operation: str
    path: str
    content: str | None
    sha: str | None
    retries: int
    created_at: str


class SyncEngine:
    def __init__(self, queue_db: Path, github: GitHubSync | None = None) -> None:
        self.github = github
        self.queue_db = queue_db
        self._ensure_table()
        self._lock = asyncio.Lock()

    def _ensure_table(self) -> None:
        with sqlite3.connect(str(self.queue_db)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sync_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation TEXT NOT NULL,
                    path TEXT NOT NULL,
                    content TEXT,
                    sha TEXT,
                    retries INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    async def enqueue(
        self, operation: str, path: str, content: str | None = None, sha: str | None = None
    ) -> None:
        async with self._lock:
            with sqlite3.connect(str(self.queue_db)) as conn:
                conn.execute(
                    "INSERT INTO sync_queue (operation, path, content, sha) VALUES (?, ?, ?, ?)",
                    (operation, path, content, sha),
                )
                conn.commit()

    def _dequeue_all(self) -> list[SyncItem]:
        with sqlite3.connect(str(self.queue_db)) as conn:
            cur = conn.execute(
                "SELECT id, operation, path, content, sha, retries, created_at FROM sync_queue ORDER BY id"
            )
            rows = cur.fetchall()
            return [SyncItem(*row) for row in rows]

    def _remove(self, item_id: int) -> None:
        with sqlite3.connect(str(self.queue_db)) as conn:
            conn.execute("DELETE FROM sync_queue WHERE id = ?", (item_id,))
            conn.commit()

    def _increment_retries(self, item_id: int) -> None:
        with sqlite3.connect(str(self.queue_db)) as conn:
            conn.execute(
                "UPDATE sync_queue SET retries = retries + 1 WHERE id = ?", (item_id,)
            )
            conn.commit()

    async def sync(self) -> dict[str, Any]:
        if not self.github:
            return {"status": "no_github", "synced": 0, "failed": 0}

        items = self._dequeue_all()
        synced = 0
        failed = 0
        for item in items:
            if item.retries >= 5:
                logger.warning(f"Sync item {item.id} exceeded max retries, dropping")
                self._remove(item.id)
                failed += 1
                continue

            try:
                if item.operation == "create" or item.operation == "update":
                    # Get current sha if not provided
                    sha = item.sha
                    if not sha:
                        existing = await self.github.get_file(item.path)
                        if existing:
                            sha = existing.get("sha")
                    content_bytes = (item.content or "").encode("utf-8")
                    await self.github.put_file(
                        item.path,
                        content_bytes,
                        f"[marustorm] {item.operation}: {item.path}",
                    )
                    if result:
                        self._remove(item.id)
                        synced += 1
                    else:
                        self._increment_retries(item.id)
                        failed += 1
                elif item.operation == "delete":
                    await self.github.delete_file(
                        item.path, f"[marustorm] delete: {item.path}"
                    )
                    self._remove(item.id)
                    synced += 1
                else:
                    self._remove(item.id)
            except Exception as e:
                logger.warning(f"Sync failed for {item.path}: {e}")
                self._increment_retries(item.id)
                failed += 1

            # Exponential backoff between items
            await asyncio.sleep(min(2 ** item.retries, 30))

        return {"status": "ok", "synced": synced, "failed": failed}

    async def sync_one(self, operation: str, path: str, content: str | None = None) -> dict[str, Any]:
        await self.enqueue(operation, path, content)
        return await self.sync()
