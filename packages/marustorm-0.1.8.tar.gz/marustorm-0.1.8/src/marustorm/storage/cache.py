from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from loguru import logger


class DiskCache:
    """Simple JSON disk cache for research results and API responses."""

    def __init__(self, cache_dir: Path) -> None:
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _key_path(self, key: str) -> Path:
        hashed = hashlib.sha256(key.encode()).hexdigest()[:16]
        return self.cache_dir / f"{hashed}.json"

    def get(self, key: str) -> Any | None:
        path = self._key_path(key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.warning(f"Cache read error for {key}: {e}")
            return None

    def set(self, key: str, value: Any) -> None:
        path = self._key_path(key)
        try:
            path.write_text(json.dumps(value, ensure_ascii=False, default=str), encoding="utf-8")
        except Exception as e:
            logger.warning(f"Cache write error for {key}: {e}")

    def delete(self, key: str) -> None:
        path = self._key_path(key)
        if path.exists():
            path.unlink()

    def clear(self) -> None:
        for p in self.cache_dir.glob("*.json"):
            p.unlink()
        logger.info("Cache cleared")
