from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any

import httpx
from loguru import logger


class GitHubSync:
    """Async GitHub sync client using httpx + Contents API."""

    def __init__(
        self,
        repo: str,
        token: str,
        branch: str = "main",
        base_url: str = "https://api.github.com",
    ) -> None:
        self.repo = repo
        self.token = token
        self.branch = branch
        self.base_url = base_url.rstrip("/")
        self._client: httpx.AsyncClient | None = None

    def _client_sync(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers={
                    "Authorization": f"token {self.token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                timeout=30.0,
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}/repos/{self.repo}/contents/{path}"
        params = {"ref": self.branch}
        if method.upper() == "GET":
            resp = await self._client_sync().get(url, params=params)
        elif method.upper() == "PUT":
            resp = await self._client_sync().put(url, params=params, **kwargs)
        elif method.upper() == "DELETE":
            resp = await self._client_sync().delete(url, params=params, **kwargs)
        else:
            raise ValueError(f"Unsupported method: {method}")
        if resp.status_code >= 400:
            raise RuntimeError(f"GitHub API {method} {path}: {resp.status_code} {resp.text}")
        if resp.status_code == 204:
            return {}
        return resp.json()

    async def get_file(self, path: str) -> bytes | None:
        """Fetch file contents from GitHub. Returns None if not found."""
        try:
            data = await self._request("GET", path)
            if isinstance(data, list):
                return None
            content = data.get("content", "")
            return base64.b64decode(content.replace("\n", ""))
        except RuntimeError as e:
            if "404" in str(e):
                return None
            raise

    async def put_file(self, path: str, content: bytes, message: str = "Update via MaruStorm") -> None:
        """Upload or update a file on GitHub."""
        encoded = base64.b64encode(content).decode()
        payload: dict[str, Any] = {
            "message": message,
            "content": encoded,
            "branch": self.branch,
        }
        # check if file exists to get sha
        try:
            existing = await self._request("GET", path)
            if isinstance(existing, dict) and "sha" in existing:
                payload["sha"] = existing["sha"]
        except RuntimeError as e:
            if "404" not in str(e):
                raise
        await self._request("PUT", path, json=payload)

    async def delete_file(self, path: str, message: str = "Delete via MaruStorm") -> None:
        existing = await self._request("GET", path)
        if isinstance(existing, dict) and "sha" in existing:
            payload = {
                "message": message,
                "sha": existing["sha"],
                "branch": self.branch,
            }
            await self._request("DELETE", path, json=payload)

    async def list_dir(self, path: str = "") -> list[dict[str, Any]]:
        """List files in a directory. Returns list of file metadata dicts."""
        data = await self._request("GET", path)
        if isinstance(data, list):
            return data
        return []

    async def push_notes(self, local_root: Path, remote_prefix: str = "notes") -> list[str]:
        """Push all .md files under local_root to GitHub. Returns list of pushed paths."""
        pushed: list[str] = []
        for p in sorted(local_root.rglob("*.md")):
            rel = p.relative_to(local_root).as_posix()
            remote_path = f"{remote_prefix}/{rel}" if remote_prefix else rel
            content = p.read_bytes()
            await self.put_file(remote_path, content, message=f"Sync {rel}")
            pushed.append(remote_path)
            logger.info("Pushed {path} to GitHub", path=remote_path)
        return pushed

    async def pull_notes(self, local_root: Path, remote_prefix: str = "notes") -> list[str]:
        """Pull all files from GitHub remote_prefix into local_root."""
        pulled: list[str] = []
        items = await self.list_dir(remote_prefix)
        for item in items:
            if item.get("type") == "file":
                remote_path = item["path"]
                rel = remote_path[len(remote_prefix) + 1 :] if remote_prefix else remote_path
                local_path = local_root / rel
                local_path.parent.mkdir(parents=True, exist_ok=True)
                content = await self.get_file(remote_path)
                if content is not None:
                    local_path.write_bytes(content)
                    pulled.append(rel)
                    logger.info("Pulled {path} from GitHub", path=remote_path)
            elif item.get("type") == "dir":
                sub_pulled = await self.pull_notes(local_root, item["path"])
                pulled.extend(sub_pulled)
        return pulled
