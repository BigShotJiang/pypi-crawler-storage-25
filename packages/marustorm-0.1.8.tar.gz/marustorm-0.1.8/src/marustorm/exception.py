from __future__ import annotations


class MaruStormException(Exception):
    """Base exception class for MaruStorm CLI."""

    pass


class ConfigError(MaruStormException, ValueError):
    """Configuration error."""

    pass


class AgentSpecError(MaruStormException, ValueError):
    """Agent specification error."""

    pass


class InvalidToolError(MaruStormException, ValueError):
    """Invalid tool error."""

    pass


class SystemPromptTemplateError(MaruStormException, ValueError):
    """System prompt template error."""

    pass


class MCPConfigError(MaruStormException, ValueError):
    """MCP config error."""

    pass


class MCPRuntimeError(MaruStormException, RuntimeError):
    """MCP runtime error."""

    pass
