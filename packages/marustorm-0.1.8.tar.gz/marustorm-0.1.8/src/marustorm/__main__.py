from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence
from pathlib import Path


def _prog_name() -> str:
    return Path(sys.argv[0]).name or "marustorm"


def main(argv: Sequence[str] | None = None) -> int | str | None:
    from marustorm.utils.proxy import normalize_proxy_env

    normalize_proxy_env()
    args = list(sys.argv[1:] if argv is None else argv)

    if len(args) == 1 and args[0] in {"--version", "-V"}:
        from marustorm.constant import get_version

        print(f"marustorm, version {get_version()}")
        return 0

    parser = argparse.ArgumentParser(
        prog="marustorm",
        description="MaruStorm - Brainstorm, Research, Write",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  marustorm                    Launch the TUI
  marustorm init               Initialize workspace
  marustorm new "My Idea"      Create a new note
  marustorm search "AI"        Search notes
  marustorm research "Rust"    Research a topic
  marustorm graph              Show note graph stats
  marustorm sync               Sync with GitHub
        """,
    )
    parser.add_argument("--notes-dir", default=None, help="Notes directory (default: auto-detect)")
    parser.add_argument("--no-telemetry", action="store_true", help="Disable anonymous telemetry")
    parser.add_argument("--dry-run", action="store_true", help="Show what would happen without executing")

    subparsers = parser.add_subparsers(dest="command")

    # init
    init_parser = subparsers.add_parser("init", help="Initialize config and note structure")
    init_parser.add_argument("--notes-dir", default=None, help="Notes directory")

    # sync
    sync_parser = subparsers.add_parser("sync", help="Sync notes with GitHub")

    # tui
    tui_parser = subparsers.add_parser("tui", help="Launch the TUI (default)")
    tui_parser.add_argument("--notes-dir", default=None, help="Notes directory")

    # new
    new_parser = subparsers.add_parser("new", help="Create a new note")
    new_parser.add_argument("title", help="Note title")
    new_parser.add_argument("--folder", default="inbox", help="Folder (default: inbox)")
    new_parser.add_argument("--tags", default="", help="Comma-separated tags")

    # search
    search_parser = subparsers.add_parser("search", help="Search notes")
    search_parser.add_argument("query", help="Search query")
    search_parser.add_argument("--limit", type=int, default=10, help="Max results")

    # research
    research_parser = subparsers.add_parser("research", help="Research a topic")
    research_parser.add_argument("query", help="Research query")

    # graph
    graph_parser = subparsers.add_parser("graph", help="Show note graph stats")

    parsed = parser.parse_args(args)

    # Handle global flags
    if parsed.no_telemetry:
        import os
        os.environ["MARUSTORM_TELEMETRY"] = "0"
        print("Telemetry disabled")
        if not parsed.command:
            return 0

    if parsed.dry_run:
        print("[dry-run] Commands will be simulated, not executed.")

    notes_dir = parsed.notes_dir

    if parsed.command == "init":
        if parsed.dry_run:
            print(f"[dry-run] Would initialize config and note structure at {notes_dir or Path.cwd()}")
            return 0
        return _init_config(parsed.notes_dir)
    elif parsed.command == "sync":
        if parsed.dry_run:
            print("[dry-run] Would sync notes with GitHub")
            return 0
        return _sync_notes()
    elif parsed.command == "tui" or parsed.command is None:
        if parsed.dry_run:
            print(f"[dry-run] Would launch TUI at {notes_dir or Path.cwd()}")
            return 0
        return _run_tui(notes_dir)
    elif parsed.command == "new":
        if parsed.dry_run:
            print(f"[dry-run] Would create note: {parsed.title} in {parsed.folder}")
            return 0
        return _new_note(parsed.title, parsed.folder, parsed.tags)
    elif parsed.command == "search":
        if parsed.dry_run:
            print(f"[dry-run] Would search for: {parsed.query}")
            return 0
        return _search_notes(parsed.query, parsed.limit)
    elif parsed.command == "research":
        if parsed.dry_run:
            print(f"[dry-run] Would research: {parsed.query}")
            return 0
        return _research(parsed.query)
    elif parsed.command == "graph":
        if parsed.dry_run:
            print("[dry-run] Would show note graph stats")
            return 0
        return _graph_stats()
    else:
        return _run_tui(notes_dir)


def _init_config(notes_dir: str | None = None) -> int:
    from pathlib import Path

    config_dir = Path.home() / ".marustorm"
    config_dir.mkdir(exist_ok=True)
    config_file = config_dir / "config.toml"

    if not config_file.exists():
        config_file.write_text(
            "# MaruStorm Configuration\n\n"
            'default_model = ""\n'
            "default_thinking = false\n"
            "default_yolo = false\n"
            'theme = "dark"\n\n'
            '[providers.openai]\n'
            'type = "openai"\n'
            'base_url = "https://api.openai.com/v1"\n'
            'api_key = "sk-YOUR-API-KEY-HERE"\n\n'
            "[models.gpt4o]\n"
            'provider = "openai"\n'
            'model = "gpt-4o"\n'
            "max_context_size = 128000\n\n"
            "[storage]\n"
            'notes_dir = "~/Notes"\n'
            'github_repo = ""\n'
            'github_branch = "main"\n'
            "auto_sync = false\n"
            "sync_interval_s = 300\n",
            encoding="utf-8",
        )
        print(f"Config initialized at {config_file}")
        print("Please edit the file to add your API keys:")
        print(f"  nano {config_file}")
    else:
        print(f"Config already exists at {config_file}")

    note_root = Path(notes_dir) if notes_dir else Path.cwd()
    for sub in ("inbox", "projects", "daily", "templates", "assets"):
        (note_root / sub).mkdir(exist_ok=True)
    (note_root / ".marustorm").mkdir(exist_ok=True)
    print(f"Note structure ready at {note_root}")
    return 0


def _sync_notes() -> int:
    import asyncio

    from marustorm.config import load_config
    from marustorm.notes.manager import NoteManager
    from marustorm.storage.github import GitHubSync

    config = load_config()
    note_root = Path.cwd()
    note_manager = NoteManager(note_root)

    token = config.storage.github_pat
    repo = config.storage.github_repo
    if not token or not repo:
        print("GitHub token/repo not configured. Run `marustorm init` first.")
        return 1

    github = GitHubSync(
        repo=repo,
        token=token.get_secret_value() if hasattr(token, "get_secret_value") else str(token),
        branch=config.storage.github_branch,
    )

    async def do_sync() -> None:
        try:
            pushed = await github.push_notes(note_manager.root)
            print(f"Synced {len(pushed)} files to {repo}")
        finally:
            await github.close()

    asyncio.run(do_sync())
    return 0


def _run_tui(notes_dir: str | None = None) -> int:
    from pathlib import Path

    from marustorm.tui.app import MaruStormApp

    note_root = Path(notes_dir) if notes_dir else Path.cwd()
    for p in [Path.cwd(), Path.home() / "marustorm-notes"]:
        if (p / ".marustorm").exists() or (p / "inbox").exists():
            note_root = p
            break

    note_root.mkdir(parents=True, exist_ok=True)
    for sub in ("inbox", "projects", "daily", "templates", "assets"):
        (note_root / sub).mkdir(exist_ok=True)
    (note_root / ".marustorm").mkdir(exist_ok=True)

    app = MaruStormApp(note_root=note_root)
    app.run()
    return 0


def _new_note(title: str, folder: str, tags_str: str) -> int:
    from datetime import datetime, timezone

    from marustorm.config import load_config
    from marustorm.notes.manager import NoteManager
    from marustorm.notes.parser import NoteFrontmatter

    config = load_config()
    note_root = Path.cwd()
    nm = NoteManager(note_root)

    slug = title.lower().replace(" ", "_").replace("/", "_")[:50] or "untitled"
    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    rel = f"{folder}/{date}_{slug}.md"
    tags = [t.strip() for t in tags_str.split(",") if t.strip()]
    fm = NoteFrontmatter(tags=tags)
    note = nm.create(rel, content=f"# {title}\n\n", frontmatter=fm)
    print(f"Created: {rel}")
    print(f"  Title: {note.title}")
    print(f"  Tags: {tags}")
    return 0


def _search_notes(query: str, limit: int) -> int:
    from marustorm.notes.manager import NoteManager
    from marustorm.search.index import NoteIndex

    note_root = Path.cwd()
    nm = NoteManager(note_root)
    idx = NoteIndex()

    for rel in nm.list_notes():
        note = nm.read(rel)
        if note:
            idx.add_note(note)

    hits = idx.search(query, limit=limit)
    if not hits:
        print(f"No results for '{query}'")
        return 0

    print(f"Results for '{query}':")
    for hit in hits:
        print(f"  [{hit.score:.2f}] {hit.title} ({hit.path})")
        print(f"    {hit.snippet[:120]}...")
    return 0


def _research(query: str) -> int:
    import asyncio

    from marustorm.research.engine import MaruStormResearchEngine

    async def do_research() -> None:
        engine = MaruStormResearchEngine()
        result = await engine.research_for_note(query)
        print(f"Research: {result.query}")
        print()
        print(result.summary)
        if result.sources:
            print()
            print("Sources:")
            for s in result.sources:
                print(f"  [{s.id}] {s.title}: {s.url}")

    asyncio.run(do_research())
    return 0


def _graph_stats() -> int:
    from marustorm.notes.graph import NoteGraph
    from marustorm.notes.manager import NoteManager

    note_root = Path.cwd()
    nm = NoteManager(note_root)
    graph = NoteGraph()

    notes = []
    for rel in nm.list_notes():
        note = nm.read(rel)
        if note:
            notes.append(note)

    graph.build(notes)
    print(f"Notes: {len(graph.nodes)}")
    print(f"Edges: {len(graph.edges)}")
    print(f"Tags: {len(graph._tag_index)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
