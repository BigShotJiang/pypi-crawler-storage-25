from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from loguru import logger

from marustorm.config import Config
from marustorm.notes.manager import NoteManager
from marustorm.notes.parser import Note, NoteFrontmatter
from marustorm.research.engine import MaruStormResearchEngine
from marustorm.notes.graph import NoteGraph


@dataclass
class SwarmResult:
    writer_draft: str = ""
    researcher_findings: str = ""
    critic_feedback: str = ""
    synthesis: str = ""
    sources: list[dict[str, Any]] = field(default_factory=list)


class BrainEngine:
    """Central orchestrator for MaruStorm brainstorming workflows."""

    def __init__(
        self,
        note_manager: NoteManager | None = None,
        research_engine: MaruStormResearchEngine | None = None,
        llm_client: Any | None = None,
        config: Config | None = None,
    ) -> None:
        self.notes = note_manager
        self.research = research_engine
        self.llm = llm_client
        self.config = config
        self.graph = NoteGraph()
        self._message_callbacks: list[Callable[[str, str], None]] = []
        if self.notes:
            self._rebuild_graph()

    def on_message(self, callback: Callable[[Any], None]) -> None:
        """Register a callback for messages. The TUI expects msg objects with .role and .content."""
        # Wrap to adapt from (role, content) to the msg object pattern
        def adapter(role: str, content: str) -> None:
            class Msg:
                pass
            msg = Msg()
            msg.role = role
            msg.content = content
            msg.thinking = ""
            callback(msg)
        self._message_callbacks.append(adapter)

    def _emit(self, role: str, content: str) -> None:
        for cb in self._message_callbacks:
            try:
                cb(role, content)
            except Exception as e:
                logger.warning(f"Message callback error: {e}")

    def _rebuild_graph(self) -> None:
        if not self.notes:
            return
        all_notes: list[Note] = []
        for rel in self.notes.list_notes():
            note = self.notes.read(rel)
            if note:
                all_notes.append(note)
        self.graph.build(all_notes)

    async def run(self, user_input: str, context_note: Note | None = None) -> str:
        """Main entry: interpret user input and route to appropriate handler."""
        user_input = user_input.strip()
        if user_input.startswith("/"):
            return await self.execute_slash(user_input, context_note)
        return await self.chat(user_input, context_note)

    async def chat(self, message: str, context_note: Note | None = None) -> str:
        """Simple chat with optional note context. Emits messages for TUI."""
        self._emit("user", message)
        if self.llm is None:
            reply = "[No LLM configured. Add a provider in ~/.config/marustorm/config.toml]"
            self._emit("assistant", reply)
            return reply
        system = (
            "You are MaruStorm, a brainstorming assistant. "
            "Be concise, creative, and ask clarifying questions when needed."
        )
        if context_note:
            system += f"\n\nCurrent note:\n{context_note.body[:2000]}"
        try:
            resp = await self.llm.chat(system=system, user=message)
            reply = str(resp)
            self._emit("assistant", reply)
            return reply
        except Exception as e:
            logger.error("Chat error: {e}", e=e)
            reply = f"[Error: {e}]"
            self._emit("assistant", reply)
            return reply

    async def execute_slash(self, command: str, context_note: Note | None = None) -> str:
        """Execute slash commands."""
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        handlers: dict[str, Any] = {
            "/research": self._cmd_research,
            "/swarm": self._cmd_swarm,
            "/save": self._cmd_save,
            "/new": self._cmd_new,
            "/tags": self._cmd_tags,
            "/graph": self._cmd_graph,
            "/help": self._cmd_help,
        }
        handler = handlers.get(cmd, self._cmd_unknown)
        if asyncio.iscoroutinefunction(handler):
            return await handler(arg, context_note)
        return handler(arg, context_note)

    async def _cmd_research(self, query: str, context_note: Note | None = None) -> str:
        if self.research is None:
            return "[Research engine not available]"
        note_ctx = context_note.body[:1500] if context_note else ""
        result = await self.research.research_for_note(query, note_ctx)
        lines = [f"## Research: {result.query}", "", result.summary, "", "### Sources"]
        for s in result.sources:
            lines.append(f"[{s.id}] [{s.title}]({s.url})")
        reply = "\n".join(lines)
        self._emit("assistant", reply)
        return reply

    async def _cmd_swarm(self, topic: str, context_note: Note | None = None) -> str:
        if self.llm is None:
            return "[No LLM configured for swarm]"
        return await self.spawn_swarm(topic, context_note)

    def _cmd_save(self, arg: str, context_note: Note | None = None) -> str:
        if context_note is None or self.notes is None:
            return "[No note to save]"
        rel = context_note.path.relative_to(self.notes.root).as_posix()
        self.notes.write(rel, context_note)
        return f"Saved: {rel}"

    def _cmd_new(self, title: str, _context_note: Note | None = None) -> str:
        if self.notes is None:
            return "[No note manager]"
        from datetime import datetime, timezone
        slug = title.lower().replace(" ", "_").replace("/", "_")[:50] or "untitled"
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        rel = f"inbox/{date}_{slug}.md"
        content = f"# {title}\n\n"
        fm = NoteFrontmatter(tags=["inbox"])
        self.notes.create(rel, content=content, frontmatter=fm)
        return f"Created: {rel}"

    def _cmd_tags(self, tag: str, _context_note: Note | None = None) -> str:
        if self.notes is None:
            return "[No note manager]"
        if not tag:
            all_tags: set[str] = set()
            for rel in self.notes.list_notes():
                note = self.notes.read(rel)
                if note:
                    all_tags.update(note.frontmatter.tags)
            return "Tags: " + ", ".join(sorted(all_tags))
        results = self.notes.search_by_tag(tag)
        lines = [f"Notes tagged '{tag}':"]
        for note in results:
            lines.append(f"- {note.title} ({note.path.name})")
        return "\n".join(lines) if results else f"No notes tagged '{tag}'"

    def _cmd_graph(self, nid: str, _context_note: Note | None = None) -> str:
        if not nid:
            return f"Graph: {len(self.graph.nodes)} nodes, {len(self.graph.edges)} edges"
        neighbors = self.graph.neighbors(nid)
        lines = [f"Neighbors of {nid}:"]
        for n in neighbors:
            lines.append(f"- {n.title} ({n.id})")
        return "\n".join(lines) if neighbors else f"No neighbors for {nid}"

    def _cmd_help(self, _arg: str, _context_note: Note | None = None) -> str:
        return (
            "Commands:\n"
            "  /research <query>  - Deep research\n"
            "  /swarm <topic>     - Spawn writing swarm\n"
            "  /save              - Save current note\n"
            "  /new <title>       - Create new note\n"
            "  /tags [tag]        - List tags or notes by tag\n"
            "  /graph [id]        - Show graph info\n"
            "  /help              - Show this help"
        )

    def _cmd_unknown(self, arg: str, _context_note: Note | None = None) -> str:
        return "Unknown command. Try /help"

    async def spawn_swarm(self, topic: str, context_note: Note | None = None) -> str:
        """Spawn Writer/Researcher/Critic/Synthesizer in parallel."""
        if self.llm is None:
            return "[No LLM configured]"

        note_ctx = context_note.body[:1500] if context_note else ""
        research_ctx = ""
        if self.research:
            try:
                res = await self.research.research_for_note(topic, note_ctx)
                research_ctx = res.summary + "\n\n" + "\n".join(
                    f"[{s.id}] {s.title}: {s.url}" for s in res.sources
                )
            except Exception as e:
                logger.warning("Swarm research failed: {e}", e=e)

        async def writer() -> str:
            prompt = (
                f"Topic: {topic}\n\n"
                f"Research:\n{research_ctx}\n\n"
                f"Note context:\n{note_ctx}\n\n"
                "Write a concise draft covering the topic. Include citations [1], [2] where applicable."
            )
            return await self.llm.chat(system="You are a writer.", user=prompt)

        async def researcher() -> str:
            prompt = (
                f"Topic: {topic}\n\n"
                f"Research:\n{research_ctx}\n\n"
                "Identify 3-5 gaps or missing angles in the research. Be specific."
            )
            return await self.llm.chat(system="You are a researcher finding gaps.", user=prompt)

        async def critic() -> str:
            prompt = (
                f"Topic: {topic}\n\n"
                f"Research:\n{research_ctx}\n\n"
                "Critique the research: what assumptions are unstated? What could be wrong?"
            )
            return await self.llm.chat(system="You are a skeptic critic.", user=prompt)

        draft, gaps, critique = await asyncio.gather(writer(), researcher(), critic())

        async def synthesizer() -> str:
            prompt = (
                f"Topic: {topic}\n\n"
                f"Draft:\n{draft}\n\n"
                f"Gaps found:\n{gaps}\n\n"
                f"Critique:\n{critique}\n\n"
                "Synthesize a final version that addresses the gaps and critique."
            )
            return await self.llm.chat(system="You are a synthesizer.", user=prompt)

        final = await synthesizer()
        result = (
            f"## Swarm Result: {topic}\n\n"
            f"### Draft\n{draft}\n\n"
            f"### Gaps\n{gaps}\n\n"
            f"### Critique\n{critique}\n\n"
            f"### Synthesis\n{final}"
        )
        self._emit("assistant", result)
        return result

    def handle_intent(self, intent: str, note: Note | None = None) -> str:
        """Synchronous intent handler for simple actions."""
        if intent == "rebuild_graph":
            self._rebuild_graph()
            return f"Graph rebuilt: {len(self.graph.nodes)} nodes"
        return f"Unknown intent: {intent}"
