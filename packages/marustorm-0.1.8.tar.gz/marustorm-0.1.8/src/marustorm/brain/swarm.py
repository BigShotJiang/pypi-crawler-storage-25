from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable

from loguru import logger

from marustorm.config import Config


try:
    import kosong
    from kosong.message import Message
    from kosong.tooling.simple import SimpleToolset
    _KOSONG_OK = True
except Exception:
    _KOSONG_OK = False
    kosong = None  # type: ignore[assignment]
    Message = None  # type: ignore[assignment,misc]
    SimpleToolset = None  # type: ignore[assignment,misc]


@dataclass
class SwarmTask:
    id: str
    section: str
    status: str = "pending"  # pending, running, done, error
    draft: str = ""
    cost_usd: float = 0.0
    tokens: int = 0


@dataclass
class SwarmResult:
    final_document: str = ""
    sections: list[SwarmTask] = field(default_factory=list)
    review: str = ""
    total_cost: float = 0.0
    total_tokens: int = 0


class SwarmOrchestrator:
    """Parallel writing swarm using subagents."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.provider = None
        self.max_concurrent = 5
        self.budget_usd = 1.0
        self.spent_usd = 0.0
        self._callbacks: list[Callable[[SwarmTask], None]] = []
        self._init_provider()

    def _init_provider(self) -> None:
        if not _KOSONG_OK:
            logger.warning("kosong not available; swarm will use fallback")
            return
        try:
            from marustorm.llm import create_llm
            self.provider = create_llm(self.config)
        except Exception as e:
            logger.warning(f"Failed to create LLM provider for swarm: {e}")
            self.provider = None

    def on_update(self, callback: Callable[[SwarmTask], None]) -> None:
        self._callbacks.append(callback)

    def _emit(self, task: SwarmTask) -> None:
        for cb in self._callbacks:
            try:
                cb(task)
            except Exception as e:
                logger.warning(f"Swarm callback error: {e}")

    async def _writer_agent(self, topic: str, section: str, task: SwarmTask) -> None:
        task.status = "running"
        self._emit(task)

        prompt = f"""Write the following section for a document about "{topic}":

Section: {section}

Requirements:
- Write in Markdown
- Be thorough but concise
- Include specific details and examples where relevant
- Do not include a section header (just the body text)

Write the section now:"""

        if self.provider is None or not _KOSONG_OK:
            task.draft = f"[Swarm writer placeholder for section: {section}]"
            task.status = "done"
            self._emit(task)
            return

        try:
            result = await kosong.generate(
                chat_provider=self.provider,
                system_prompt="You are a professional technical writer.",
                toolset=SimpleToolset(),
                history=[Message(role="user", content=prompt)],
            )
            task.draft = result.message.content or ""
            task.status = "done"
            task.tokens = result.usage.total_tokens if result.usage else 0
            task.cost_usd = (task.tokens / 1000) * 0.0015
            self.spent_usd += task.cost_usd
        except Exception as e:
            logger.warning(f"Writer agent failed for {section}: {e}")
            task.draft = f"[Error generating section: {e}]"
            task.status = "error"

        self._emit(task)

    async def _critic_agent(self, drafts: list[str], topic: str) -> str:
        combined = "\n\n---\n\n".join(
            f"Section {i+1}:\n{d}" for i, d in enumerate(drafts)
        )
        prompt = f"""Review the following document about "{topic}":

{combined}

Provide a brief critique focusing on:
1. Logical flow between sections
2. Missing information
3. Inconsistencies
4. Suggestions for improvement

Keep it concise (under 300 words)."""

        if self.provider is None or not _KOSONG_OK:
            return "[Critic placeholder - kosong not available]"

        try:
            result = await kosong.generate(
                chat_provider=self.provider,
                system_prompt="You are a critical editor.",
                toolset=SimpleToolset(),
                history=[Message(role="user", content=prompt)],
            )
            return result.message.content or ""
        except Exception as e:
            logger.warning(f"Critic agent failed: {e}")
            return f"[Review error: {e}]"

    async def _synthesizer_agent(self, drafts: list[str], review: str, topic: str) -> str:
        combined = "\n\n---\n\n".join(
            f"## Section {i+1}\n\n{d}" for i, d in enumerate(drafts)
        )
        prompt = f"""Synthesize the following sections into a single coherent document about "{topic}":

{combined}

Editor's review:
{review}

Requirements:
- Add a main title (H1)
- Ensure smooth transitions between sections
- Fix any inconsistencies noted in the review
- Return the complete document in Markdown

Synthesize now:"""

        if self.provider is None or not _KOSONG_OK:
            return f"# {topic}\n\n" + "\n\n".join(drafts)

        try:
            result = await kosong.generate(
                chat_provider=self.provider,
                system_prompt="You are a senior editor who assembles polished documents.",
                toolset=SimpleToolset(),
                history=[Message(role="user", content=prompt)],
            )
            return result.message.content or ""
        except Exception as e:
            logger.warning(f"Synthesizer agent failed: {e}")
            return f"[Synthesis error: {e}]"

    async def write_document(self, topic: str, outline: list[str]) -> SwarmResult:
        self.spent_usd = 0.0
        tasks = [
            SwarmTask(id=f"writer-{i}", section=sec)
            for i, sec in enumerate(outline)
        ]
        result = SwarmResult(sections=tasks)

        # Phase 1: Writers (parallel, with concurrency limit)
        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def _run_writer(task: SwarmTask) -> None:
            async with semaphore:
                if self.spent_usd >= self.budget_usd:
                    task.status = "error"
                    task.draft = "[Budget exceeded]"
                    self._emit(task)
                    return
                await self._writer_agent(topic, task.section, task)

        await asyncio.gather(*[_run_writer(t) for t in tasks])

        # Phase 2: Critic
        drafts = [t.draft for t in tasks if t.status == "done"]
        result.review = await self._critic_agent(drafts, topic)

        # Phase 3: Synthesizer
        result.final_document = await self._synthesizer_agent(drafts, result.review, topic)

        result.total_cost = self.spent_usd
        result.total_tokens = sum(t.tokens for t in tasks)
        return result
