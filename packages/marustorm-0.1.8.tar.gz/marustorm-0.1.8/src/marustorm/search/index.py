from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger

from marustorm.notes.parser import Note


@dataclass
class SearchHit:
    path: str
    title: str
    snippet: str
    score: float


def _levenshtein(a: str, b: str) -> int:
    """Compute Levenshtein distance between two strings."""
    if len(a) < len(b):
        return _levenshtein(b, a)
    if len(b) == 0:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(
                min(
                    prev[j + 1] + 1,
                    curr[j] + 1,
                    prev[j] + (0 if ca == cb else 1),
                )
            )
        prev = curr
    return prev[-1]


def _fuzzy_match(query: str, text: str, max_distance: int = 2) -> bool:
    """Check if query fuzzy-matches anywhere in text."""
    query = query.lower()
    text = text.lower()
    if query in text:
        return True
    q_len = len(query)
    if q_len <= 3:
        return query in text
    # Sliding window fuzzy match for longer queries
    for i in range(len(text) - q_len + 1):
        window = text[i : i + q_len]
        if _levenshtein(query, window) <= max_distance:
            return True
    return False


def _score_match(query_tokens: list[str], text: str, title: str) -> float:
    """Score a document against query tokens. Higher is better."""
    text_lower = text.lower()
    title_lower = title.lower()
    score = 0.0

    for token in query_tokens:
        t = token.lower()
        # Exact title match is highest priority
        if t in title_lower:
            score += 10.0
        # Fuzzy title match
        elif _fuzzy_match(t, title_lower):
            score += 6.0
        # Exact body match
        elif t in text_lower:
            score += 3.0
        # Fuzzy body match
        elif _fuzzy_match(t, text_lower):
            score += 1.5

    # Boost for consecutive token matches
    query_str = " ".join(query_tokens).lower()
    if query_str in title_lower:
        score += 15.0
    elif query_str in text_lower:
        score += 5.0

    return score


class NoteIndex:
    """Fuzzy inverted-index search over notes."""

    def __init__(self) -> None:
        self._index: dict[str, set[str]] = {}
        self._docs: dict[str, str] = {}
        self._titles: dict[str, str] = {}

    def _tokenize(self, text: str) -> list[str]:
        return re.findall(r"[a-zA-Z0-9\uac00-\ud7af]+", text.lower())

    def add_note(self, note: Note) -> None:
        rel = note.path.as_posix()
        text = f"{note.title} {note.body} {' '.join(note.frontmatter.tags)}"
        self._docs[rel] = text
        self._titles[rel] = note.title
        for token in self._tokenize(text):
            self._index.setdefault(token, set()).add(rel)

    def remove_note(self, rel_path: str) -> None:
        self._docs.pop(rel_path, None)
        self._titles.pop(rel_path, None)
        for token_set in self._index.values():
            token_set.discard(rel_path)

    def search(self, query: str, limit: int = 10) -> list[SearchHit]:
        query = query.strip()
        if not query:
            return []

        query_tokens = self._tokenize(query)

        # Gather candidate docs from inverted index
        candidates: set[str] = set()
        for token in query_tokens:
            candidates.update(self._index.get(token, set()))

        # Also include all docs for fuzzy fallback when few candidates
        if len(candidates) < limit:
            candidates.update(self._docs.keys())

        scores: dict[str, float] = {}
        for rel in candidates:
            text = self._docs.get(rel, "")
            title = self._titles.get(rel, rel)
            score = _score_match(query_tokens, text, title)
            if score > 0:
                # Normalize by doc length to avoid long docs dominating
                doc_len = max(len(self._tokenize(text)), 1)
                scores[rel] = score / (doc_len ** 0.3)

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:limit]
        results: list[SearchHit] = []
        for rel, score in ranked:
            text = self._docs.get(rel, "")
            # Find best snippet around query
            snippet = text[:200]
            query_str = " ".join(query_tokens)
            idx = text.lower().find(query_str)
            if idx < 0:
                for token in query_tokens:
                    idx = text.lower().find(token)
                    if idx >= 0:
                        break
            if idx >= 0:
                start = max(0, idx - 60)
                end = min(len(text), idx + 140)
                snippet = text[start:end]
            results.append(SearchHit(path=rel, title=self._titles.get(rel, rel), snippet=snippet, score=score))
        return results

    def rebuild(self, notes: list[Note]) -> None:
        self._index.clear()
        self._docs.clear()
        self._titles.clear()
        for note in notes:
            self.add_note(note)
        logger.info("Search index rebuilt: {n} notes", n=len(notes))

    def save(self, path: Path) -> None:
        import json
        data = {
            "index": {k: list(v) for k, v in self._index.items()},
            "docs": self._docs,
            "titles": self._titles,
        }
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    def load(self, path: Path) -> None:
        import json
        if not path.exists():
            return
        data = json.loads(path.read_text(encoding="utf-8"))
        self._index = {k: set(v) for k, v in data.get("index", {}).items()}
        self._docs = data.get("docs", {})
        self._titles = data.get("titles", {})
