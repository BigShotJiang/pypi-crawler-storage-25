"""MaruStorm session runner."""

from marustorm.web.runner.process import MaruStormRunner

__all__ = ["MaruStormRunner"]
