from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, ListItem, ListView, Static

from marustorm.search.index import NoteIndex, SearchHit


class SearchScreen(ModalScreen[str | None]):
    """Modal search screen for finding notes."""

    DEFAULT_CSS = """
    SearchScreen {
        align: center middle;
    }
    SearchScreen > Vertical {
        width: 80;
        height: 30;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }
    SearchScreen #search-title {
        height: auto;
        content-align: center middle;
        text-style: bold;
    }
    SearchScreen Input {
        margin: 1 0;
    }
    SearchScreen ListView {
        height: 1fr;
        border: solid $primary-darken-2;
        background: $surface-darken-1;
    }
    SearchScreen ListItem {
        height: auto;
        padding: 0 1;
    }
    SearchScreen #search-meta {
        height: auto;
        color: $text-disabled;
    }
    SearchScreen #search-buttons {
        height: auto;
        align: right middle;
    }
    """

    def __init__(self, index: NoteIndex, **kwargs) -> None:
        super().__init__(**kwargs)
        self.index = index
        self._hits: list[SearchHit] = []

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("🔍 Search Notes", id="search-title")
            yield Input(placeholder="Type to search...", id="search-input")
            yield ListView(id="search-results")
            yield Static("0 results", id="search-meta")
            with Horizontal(id="search-buttons"):
                yield Button("Open (Enter)", id="open-btn", variant="primary")
                yield Button("Cancel (Esc)", id="cancel-btn")

    def on_mount(self) -> None:
        self.query_one("#search-input", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        query = event.value.strip()
        results = self.index.search(query, limit=20) if query else []
        self._hits = results
        list_view = self.query_one("#search-results", ListView)
        list_view.clear()
        for hit in results:
            snippet = hit.snippet.replace("\n", " ")[:80]
            label = f"[bold]{hit.title}[/bold]  [dim]{snippet}...[/dim]"
            list_view.append(ListItem(Label(label)))
        self.query_one("#search-meta", Static).update(
            f"{len(results)} result{'s' if len(results) != 1 else ''}"
        )

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._select_current()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        idx = event.list_view.index
        if 0 <= idx < len(self._hits):
            self.dismiss(self._hits[idx].path)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "open-btn":
            self._select_current()
        elif event.button.id == "cancel-btn":
            self.dismiss(None)

    def _select_current(self) -> None:
        list_view = self.query_one("#search-results", ListView)
        idx = list_view.index
        if 0 <= idx < len(self._hits):
            self.dismiss(self._hits[idx].path)
        elif self._hits:
            self.dismiss(self._hits[0].path)
        else:
            self.dismiss(None)

    def on_key(self, event) -> None:
        if event.key == "escape":
            self.dismiss(None)
