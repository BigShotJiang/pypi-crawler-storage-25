from __future__ import annotations

from textual.containers import Container
from textual.reactive import reactive
from textual.widgets import RichLog, Static


class ResearchPanel(Container):
    """Real-time research progress panel."""

    DEFAULT_CSS = """
    ResearchPanel {
        width: 100%;
        height: 100%;
        border: solid $primary;
        background: $surface;
    }
    ResearchPanel RichLog {
        height: 1fr;
        border: none;
        background: transparent;
    }
    """

    active: reactive[bool] = reactive(False)

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.border_title = "🔍 Research"

    def compose(self) -> None:
        yield RichLog(id="research-log", highlight=True, markup=True)
        yield Static("", id="research-status")

    def log(self, message: str) -> None:
        self.query_one("#research-log", RichLog).write(message)

    def set_status(self, text: str) -> None:
        self.query_one("#research-status", Static).update(text)

    def clear(self) -> None:
        self.query_one("#research-log", RichLog).clear()
