from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, Static


HELP_TEXT = """
[b]MaruStorm — Key Bindings & Commands[/b]

[yellow]Global Keys[/yellow]
  Ctrl+N  — New note
  Ctrl+S  — Save current note
  Ctrl+F  — Search notes
  Ctrl+R  — Toggle research panel
  Ctrl+W  — Toggle swarm panel
  Ctrl+G  — Toggle graph view
  Ctrl+L  — Toggle AI panel
  Ctrl+T  — Toggle thinking panel
  Esc     — Focus mode (hide sidebars)
  Ctrl+Q  — Quit

[yellow]Slash Commands[/yellow] (type in input bar)
  /brainstorm <topic>  — Start brainstorming
  /research <query>    — Deep research
  /swarm <topic>       — Spawn writing swarm
  /summarize           — Summarize current note
  /expand              — Expand current note ideas
  /connect             — Find related notes
  /template <name>     — Insert template
  /tag                 — Show tag suggestions
  /save                — Save current note
  /new <title>         — Create new note
  /tags [tag]          — List tags or search by tag
  /graph [id]          — Show note graph
  /help                — Show this help

[yellow]Tips[/yellow]
  • Start typing to search — results update live
  • The AI panel streams responses in real time
  • Research results appear in the research panel
  • Swarm writing saves results to projects/swarm/
"""


class HelpScreen(ModalScreen[None]):
    """Modal help screen showing bindings and commands."""

    DEFAULT_CSS = """
    HelpScreen {
        align: center middle;
    }
    HelpScreen > Vertical {
        width: 70;
        height: 35;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }
    HelpScreen Static {
        height: 1fr;
        border: none;
        background: transparent;
    }
    HelpScreen Label {
        height: auto;
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("❓ MaruStorm Help")
            yield Static(HELP_TEXT, id="help-content")

    def on_key(self, event) -> None:
        if event.key in ("escape", "q", "h"):
            self.dismiss(None)
