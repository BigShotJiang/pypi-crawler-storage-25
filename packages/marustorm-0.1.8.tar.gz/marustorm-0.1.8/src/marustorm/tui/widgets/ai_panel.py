from __future__ import annotations

from typing import Any

from textual.containers import Container
from textual.reactive import reactive
from textual.widgets import RichLog, Static


class AIPanel(Container):
    """AI chat panel with streaming support."""

    DEFAULT_CSS = """
    AIPanel {
        width: 35%;
        height: 100%;
        border: solid $primary;
        background: $surface;
    }
    AIPanel RichLog {
        height: 1fr;
        border: none;
        background: transparent;
    }
    AIPanel #thinking-indicator {
        height: auto;
        color: $text-accent;
        background: transparent;
    }
    """

    thinking: reactive[bool] = reactive(False)

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "🤖 AI"

    def compose(self) -> ComposeResult:
        yield RichLog(id="ai-log", highlight=True, markup=True)
        yield Static("", id="thinking-indicator")

    def add_message(self, role: str, content: str) -> None:
        log = self.query_one("#ai-log", RichLog)
        if role == "user":
            log.write(f"[bold cyan]> {content}[/bold cyan]")
        elif role == "assistant":
            log.write(f"[bold green]🤖 {content}[/bold green]")
        elif role == "thinking":
            log.write(f"[dim]💭 {content}[/dim]")
        elif role == "system":
            log.write(f"[dim]{content}[/dim]")
        else:
            log.write(content)

    def watch_thinking(self, thinking: bool) -> None:
        indicator = self.query_one("#thinking-indicator", Static)
        if thinking:
            indicator.update("[bold yellow]🤔 Thinking...[/bold yellow]")
        else:
            indicator.update("")
