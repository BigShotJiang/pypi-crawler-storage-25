from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static


WELCOME_TEXT = """
[b]Welcome to MaruStorm![/b]

Your personal AI-powered brainstorming workspace.

[yellow]Quick Start[/yellow]
  1. Press [b]Ctrl+N[/b] to create your first note
  2. Type in the editor — auto-save is on (2s debounce)
  3. Press [b]Ctrl+F[/b] to search your notes
  4. Press [b]Ctrl+P[/b] for markdown preview
  5. Type [b]/help[/b] in the AI input for all commands

[yellow]Slash Commands[/yellow]
  /brainstorm <topic>  — AI brainstorming session
  /research <query>    — Deep research with citations
  /swarm <topic>       — Parallel writing agents
  /summarize           — Summarize current note
  /expand              — Expand current note ideas
  /connect             — Find related notes
  /template <name>     — Insert a template

[yellow]Tips[/yellow]
  • Notes are saved as Markdown files in your workspace
  • Press [b]?[/b] anytime to see the full help
  • The ghost text (💡) suggests completions — Tab to accept
  • Focus mode (Esc) hides sidebars for distraction-free writing
"""


class WelcomeScreen(ModalScreen[None]):
    """Welcome screen shown on first launch or when no notes exist."""

    DEFAULT_CSS = """
    WelcomeScreen {
        align: center middle;
    }
    WelcomeScreen > Vertical {
        width: 70;
        height: 32;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }
    WelcomeScreen Static {
        height: 1fr;
        border: none;
        background: transparent;
    }
    WelcomeScreen Label {
        height: auto;
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }
    WelcomeScreen Button {
        margin: 1 0;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("🌩️ Welcome to MaruStorm")
            yield Static(WELCOME_TEXT, id="welcome-content")
            yield Button("Start Writing (Ctrl+N)", id="start-btn", variant="primary")
            yield Button("Dismiss (Esc)", id="dismiss-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "start-btn":
            self.dismiss(None)
            # Trigger new note action via app
            if self.app:
                self.app.action_new_note()
        else:
            self.dismiss(None)

    def on_key(self, event) -> None:
        if event.key == "escape":
            self.dismiss(None)
