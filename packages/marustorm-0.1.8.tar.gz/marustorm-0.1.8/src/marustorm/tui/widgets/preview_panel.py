from __future__ import annotations

from textual.containers import Container
from textual.reactive import reactive
from textual.widgets import Markdown, Static


class PreviewPanel(Container):
    """Markdown preview panel that renders the current note."""

    DEFAULT_CSS = """
    PreviewPanel {
        width: 100%;
        height: 100%;
        border: solid $primary;
        background: $surface;
    }
    PreviewPanel Markdown {
        height: 1fr;
        border: none;
        background: transparent;
        padding: 0 1;
    }
    PreviewPanel #preview-hint {
        height: auto;
        color: $text-disabled;
        background: transparent;
        padding: 0 1;
    }
    """

    visible: reactive[bool] = reactive(False)

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.border_title = "👁 Preview"
        self.display = False

    def compose(self) -> None:
        yield Markdown("", id="preview-md")
        yield Static("[dim]Press Ctrl+P to toggle preview[/dim]", id="preview-hint")

    def render_note(self, content: str) -> None:
        md = self.query_one("#preview-md", Markdown)
        md.update(content)
