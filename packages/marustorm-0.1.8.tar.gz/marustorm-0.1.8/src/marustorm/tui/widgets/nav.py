from __future__ import annotations

from pathlib import Path
from typing import Any

from textual.widgets import DirectoryTree


class NoteNav(DirectoryTree):
    """Directory tree widget for navigating notes."""

    DEFAULT_CSS = """
    NoteNav {
        width: 25%;
        height: 100%;
        border: solid $primary;
        background: $surface;
    }
    """

    def __init__(self, path: Path, **kwargs: Any) -> None:
        super().__init__(path=path, **kwargs)
        self.border_title = "📂 Notes"
