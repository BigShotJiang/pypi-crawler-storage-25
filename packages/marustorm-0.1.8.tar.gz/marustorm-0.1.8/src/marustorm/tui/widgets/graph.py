from __future__ import annotations

import math

from textual.containers import Container
from textual.widgets import Static


class GraphView(Container):
    """Note relationship graph rendered as ASCII art."""

    DEFAULT_CSS = """
    GraphView {
        width: 100%;
        height: 100%;
        background: $surface-darken-1;
        padding: 1;
    }
    GraphView Static {
        height: 1fr;
        content-align: center middle;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.border_title = "🕸 Graph"
        self._graph_nodes: dict = {}
        self._graph_edges: list = []

    def compose(self):
        yield Static("", id="graph-canvas")

    def on_mount(self) -> None:
        self._draw_sample()

    def _draw_sample(self) -> None:
        self.query_one("#graph-canvas", Static).update(
            "[dim]Graph view ready. Toggle with Ctrl+G to see your note connections.[/dim]"
        )

    def refresh_graph(self, nodes: dict, edges: list) -> None:
        self._graph_nodes = nodes
        self._graph_edges = edges
        if not nodes:
            self.query_one("#graph-canvas", Static).update(
                "[dim]No notes yet. Create some notes to see the graph![/dim]"
            )
            return

        lines: list[str] = []
        node_list = list(nodes.values())
        n = len(node_list)

        # Simple circular layout rendered as text
        radius = min(15, n * 2)
        grid_h = radius * 2 + 3
        grid_w = radius * 4 + 5
        grid = [[" " for _ in range(grid_w)] for _ in range(grid_h)]
        cx, cy = grid_w // 2, grid_h // 2

        # Draw edges first
        for edge in edges:
            src_idx = next((i for i, node in enumerate(node_list) if node.id == edge.source), -1)
            tgt_idx = next((i for i, node in enumerate(node_list) if node.id == edge.target), -1)
            if src_idx < 0 or tgt_idx < 0:
                continue
            a1 = 2 * math.pi * src_idx / n - math.pi / 2
            a2 = 2 * math.pi * tgt_idx / n - math.pi / 2
            x1 = int(cx + radius * 1.5 * math.cos(a1))
            y1 = int(cy + radius * math.sin(a1))
            x2 = int(cx + radius * 1.5 * math.cos(a2))
            y2 = int(cy + radius * math.sin(a2))
            # Simple Bresenham-ish line
            steps = max(abs(x2 - x1), abs(y2 - y1), 1)
            for t in range(steps + 1):
                px = int(x1 + (x2 - x1) * t / steps)
                py = int(y1 + (y2 - y1) * t / steps)
                if 0 <= px < grid_w and 0 <= py < grid_h:
                    if grid[py][px] == " ":
                        grid[py][px] = "·"

        # Draw nodes
        for i, node in enumerate(node_list):
            angle = 2 * math.pi * i / n - math.pi / 2
            x = int(cx + radius * 1.5 * math.cos(angle))
            y = int(cy + radius * math.sin(angle))
            label = node.title[:8] if node.title else node.id[:8]
            if 0 <= x < grid_w and 0 <= y < grid_h:
                grid[y][x] = "●"
                # Try to place label above/below
                ly = max(0, min(grid_h - 1, y - 1))
                if sum(1 for c in grid[ly] if c != " ") < 3:
                    for j, ch in enumerate(label):
                        if x + j < grid_w:
                            grid[ly][x + j] = ch

        lines.append(f"[bold cyan]Notes: {len(node_list)}  Connections: {len(edges)}[/bold cyan]")
        lines.append("")
        for row in grid:
            lines.append("".join(row))
        lines.append("")
        lines.append("[dim]● note  · connection[/dim]")

        self.query_one("#graph-canvas", Static).update("\n".join(lines))
