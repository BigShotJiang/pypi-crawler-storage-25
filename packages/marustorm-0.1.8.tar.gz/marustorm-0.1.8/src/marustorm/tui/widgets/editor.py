from __future__ import annotations

from typing import Any, Callable

from textual.app import ComposeResult
from textual.containers import Container
from textual.reactive import reactive
from textual.widgets import Static, TextArea

from marustorm.notes.parser import Note


class NoteEditor(Container):
    """Markdown editor with ghost text support, auto-save, and word count."""

    DEFAULT_CSS = """
    NoteEditor {
        width: 1fr;
        height: 1fr;
        border: solid $primary;
        background: $surface-darken-1;
    }
    NoteEditor TextArea {
        height: 1fr;
        border: none;
    }
    NoteEditor #status-bar {
        dock: bottom;
        height: auto;
        color: $text-disabled;
        background: $surface-darken-2;
        padding: 0 1;
    }
    NoteEditor #ghost-layer {
        dock: bottom;
        height: auto;
        color: $text-disabled;
        background: transparent;
        padding: 0 1;
    }
    """

    note: reactive[Note | None] = reactive(None)

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.border_title = "✏️ Editor"
        self._ghost_callback: Callable[[str], None] | None = None
        self._accept_ghost_callback: Callable[[], None] | None = None
        self._autosave_callback: Callable[[str], None] | None = None
        self._autosave_timer: Any = None
        self._dirty: bool = False

    def compose(self) -> ComposeResult:
        yield TextArea(id="editor-textarea", classes="editor")
        yield Static("", id="ghost-layer")
        yield Static("0 words | 0 lines | saved", id="status-bar")

    def watch_note(self, note: Note | None) -> None:
        textarea = self.query_one("#editor-textarea", TextArea)
        if note:
            textarea.text = note.content
            self.border_title = f"✏️ {note.title}"
        else:
            textarea.text = ""
            self.border_title = "✏️ Editor"
        self.clear_ghost()
        self._update_status()
        self._dirty = False

    def get_text(self) -> str:
        return self.query_one("#editor-textarea", TextArea).text

    def set_ghost(self, text: str) -> None:
        self.query_one("#ghost-layer", Static).update(f"[dim]💡 {text}[/dim]  [dim](Tab to accept, Esc to dismiss)[/dim]")

    def clear_ghost(self) -> None:
        self.query_one("#ghost-layer", Static).update("")

    def accept_ghost(self) -> None:
        ghost = self.query_one("#ghost-layer", Static)
        raw = ghost.renderable.plain if hasattr(ghost.renderable, "plain") else str(ghost.renderable)
        # Extract just the suggestion text (remove the hint)
        if "(Tab to accept" in raw:
            raw = raw.split("(Tab to accept")[0].strip()
        if raw.startswith("💡"):
            raw = raw[1:].strip()
        if raw:
            textarea = self.query_one("#editor-textarea", TextArea)
            textarea.text = textarea.text + raw
            self.clear_ghost()
            if self._accept_ghost_callback:
                self._accept_ghost_callback()

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Trigger ghost text generation and auto-save after typing pauses."""
        text = event.text_area.text
        self._dirty = True
        self._update_status()
        if self._ghost_callback:
            ghost = self.query_one("#ghost-layer", Static)
            if len(text) > 20 and not ghost.renderable:
                self._ghost_callback(text)
        # Debounced auto-save
        if self._autosave_timer:
            self._autosave_timer.stop()
        self._autosave_timer = self.set_timer(2.0, self._do_autosave)

    def _do_autosave(self) -> None:
        if self._dirty and self._autosave_callback:
            text = self.get_text()
            self._autosave_callback(text)
            self._dirty = False
            self._update_status()

    def _update_status(self) -> None:
        text = self.get_text()
        words = len(text.split()) if text else 0
        lines = text.count("\n") + 1 if text else 0
        status = "unsaved" if self._dirty else "saved"
        self.query_one("#status-bar", Static).update(
            f"{words} words | {lines} lines | {status}"
        )

    def mark_saved(self) -> None:
        self._dirty = False
        self._update_status()

    def on_key(self, event) -> None:
        if event.key == "tab":
            ghost = self.query_one("#ghost-layer", Static)
            if ghost.renderable:
                event.prevent_default()
                event.stop()
                self.accept_ghost()
        elif event.key == "escape":
            self.clear_ghost()

    def register_ghost_callback(self, callback: Callable[[str], None]) -> None:
        self._ghost_callback = callback

    def register_accept_callback(self, callback: Callable[[], None]) -> None:
        self._accept_ghost_callback = callback

    def register_autosave_callback(self, callback: Callable[[str], None]) -> None:
        self._autosave_callback = callback
