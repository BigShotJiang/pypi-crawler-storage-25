from __future__ import annotations

from textual.containers import Container
from textual.reactive import reactive
from textual.widgets import RichLog, Static


class ThinkingPanel(Container):
    """AI thinking process visualization."""

    DEFAULT_CSS = """
    ThinkingPanel {
        width: 100%;
        height: 100%;
        border: solid $text-accent;
        background: $surface;
    }
    ThinkingPanel RichLog {
        height: 1fr;
        border: none;
        background: transparent;
        color: $text-disabled;
    }
    """

    visible: reactive[bool] = reactive(False)

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.border_title = "💭 Thinking"
        self.display = False

    def compose(self) -> None:
        yield RichLog(id="thinking-log", highlight=True, markup=True)
        yield Static("[dim]Press Ctrl+T to toggle[/dim]", id="thinking-hint")

    def add_thought(self, text: str) -> None:
        self.query_one("#thinking-log", RichLog).write(text)

    def clear(self) -> None:
        self.query_one("#thinking-log", RichLog).clear()
