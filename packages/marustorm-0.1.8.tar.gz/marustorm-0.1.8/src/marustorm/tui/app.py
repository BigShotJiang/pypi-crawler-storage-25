from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, Static

from marustorm.brain.engine import BrainEngine
from marustorm.brain.swarm import SwarmOrchestrator
from marustorm.config import load_config
from marustorm.notes.manager import NoteManager
from marustorm.notes.parser import Note, NoteFrontmatter
from marustorm.search.index import NoteIndex
from marustorm.tui.widgets.ai_panel import AIPanel
from marustorm.tui.widgets.editor import NoteEditor
from marustorm.tui.widgets.graph import GraphView
from marustorm.tui.widgets.help_screen import HelpScreen
from marustorm.tui.widgets.nav import NoteNav
from marustorm.tui.widgets.preview_panel import PreviewPanel
from marustorm.tui.widgets.research_panel import ResearchPanel
from marustorm.tui.widgets.search_screen import SearchScreen
from marustorm.tui.widgets.thinking_panel import ThinkingPanel
from marustorm.tui.widgets.welcome_screen import WelcomeScreen


class MaruStormApp(App):
    """Main TUI application for MaruStorm."""

    CSS_PATH = Path(__file__).with_suffix(".tcss")

    BINDINGS = [
        ("ctrl+n", "new_note", "New Note"),
        ("ctrl+s", "save_note", "Save"),
        ("ctrl+r", "toggle_research", "Research"),
        ("ctrl+w", "toggle_swarm", "Swarm"),
        ("ctrl+g", "toggle_graph", "Graph"),
        ("ctrl+l", "toggle_ai", "AI Panel"),
        ("ctrl+t", "toggle_thinking", "Thinking"),
        ("ctrl+f", "search", "Search"),
        ("ctrl+q", "quit", "Quit"),
        ("escape", "focus_mode", "Focus"),
        ("ctrl+p", "toggle_preview", "Preview"),
        ("?", "help", "Help"),
        ("f2", "rename_note", "Rename"),
        ("delete", "delete_note", "Delete"),
    ]

    def __init__(self, note_root: Path, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.note_root = note_root
        self.note_manager = NoteManager(note_root)
        self.current_note: Note | None = None
        self.config = load_config()
        self.brain = BrainEngine(note_manager=self.note_manager, config=self.config)
        self.brain.on_message(self._on_brain_message)
        self.search_index = NoteIndex()
        try:
            self.swarm = SwarmOrchestrator(self.config)
            self.swarm.on_update(self._on_swarm_update)
        except Exception:
            self.swarm = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main-layout"):
            yield NoteNav(self.note_root)
            with Vertical(id="editor-pane"):
                yield NoteEditor()
                yield GraphView(id="graph-view")
                yield PreviewPanel(id="preview-panel")
                yield ResearchPanel()
                yield ThinkingPanel()
            yield AIPanel()
        yield Input(placeholder="Ask AI or type /command...  Press ? for help", id="ai-input")
        yield Footer()

    def on_mount(self) -> None:
        self.title = "MaruStorm"
        self.sub_title = "Brainstorm . Research . Write"
        self.query_one(ResearchPanel).display = False
        self.query_one(ThinkingPanel).display = False
        self.query_one(GraphView, GraphView).display = False
        self.query_one(PreviewPanel, PreviewPanel).display = False
        self._rebuild_search_index()
        self._rebuild_graph()
        self.query_one(NoteEditor).register_ghost_callback(self._on_ghost_request)
        self.query_one(NoteEditor).register_accept_callback(self._on_ghost_accept)
        self.query_one(NoteEditor).register_autosave_callback(self._on_autosave)
        note_count = len(list(self.note_manager.list_notes()))
        self.sub_title = f"Brainstorm . Research . Write  —  {note_count} notes"
        if note_count == 0:
            self.push_screen(WelcomeScreen())

    def _rebuild_search_index(self) -> None:
        notes: list[Note] = []
        for rel in self.note_manager.list_notes():
            note = self.note_manager.read(rel)
            if note:
                notes.append(note)
        self.search_index.rebuild(notes)

    def _rebuild_graph(self) -> None:
        self.brain.handle_intent("rebuild_graph", self.current_note)

    def _on_brain_message(self, msg: Any) -> None:
        panel = self.query_one(AIPanel)
        panel.add_message(msg.role, msg.content)
        if getattr(msg, "thinking", ""):
            self.query_one(ThinkingPanel).add_thought(msg.thinking)
        # Route research output to ResearchPanel when active
        if getattr(msg, "role", "") == "assistant" and getattr(msg, "_research", False):
            rp = self.query_one(ResearchPanel)
            rp.log(msg.content)
            rp.set_status("Research complete")

    def _on_swarm_update(self, task: Any) -> None:
        panel = self.query_one(AIPanel)
        status = "done" if getattr(task, "status", "") == "done" else "running"
        emoji = "✅" if status == "done" else "⏳"
        panel.add_message("system", f"{emoji} {getattr(task, 'section', 'task')}: {status}")

    def on_directory_tree_file_selected(self, event: Any) -> None:
        path = event.path
        if path.suffix == ".md":
            rel = path.relative_to(self.note_root).as_posix()
            note = self.note_manager.read(rel)
            if note:
                self.current_note = note
                self.query_one(NoteEditor).note = note
                self.query_one(PreviewPanel, PreviewPanel).render_note(note.content)
                self.query_one(AIPanel).add_message("system", f"Loaded: {note.title}")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "ai-input":
            text = event.value.strip()
            if not text:
                return
            event.input.value = ""
            self._handle_ai_input(text)

    def _handle_ai_input(self, text: str) -> None:
        if text.startswith("/"):
            self._handle_slash(text)
        else:
            panel = self.query_one(AIPanel)
            panel.add_message("user", text)
            panel.thinking = True
            asyncio.create_task(self._brain_chat(text))

    async def _brain_chat(self, text: str) -> None:
        await self.brain.chat(text, self.current_note)
        panel = self.query_one(AIPanel)
        panel.thinking = False

    def _handle_slash(self, text: str) -> None:
        parts = text[1:].split(maxsplit=1)
        cmd = parts[0] if parts else ""
        arg = parts[1] if len(parts) > 1 else ""
        panel = self.query_one(AIPanel)

        if cmd == "brainstorm":
            panel.add_message("system", "Starting brainstorming session...")
            asyncio.create_task(self._brain_chat("Let's brainstorm about: " + arg))
        elif cmd == "research":
            panel.add_message("system", f"Researching: {arg}...")
            rp = self.query_one(ResearchPanel)
            rp.display = True
            rp.clear()
            rp.set_status(f"Researching: {arg}...")
            rp.log(f"Query: {arg}")
            asyncio.create_task(self._run_research(arg))
        elif cmd == "swarm":
            topic = arg or "Untitled Document"
            panel.add_message("system", f"Swarm Write: {topic}")
            asyncio.create_task(self._run_swarm(topic))
        elif cmd == "summarize":
            if self.current_note:
                content = self.current_note.content
                panel.add_message("system", "Summarizing current note...")
                asyncio.create_task(self._brain_chat("Summarize this note:\n\n" + content))
            else:
                panel.add_message("system", "No note loaded")
        elif cmd == "expand":
            if self.current_note:
                content = self.current_note.content
                panel.add_message("system", "Expanding ideas...")
                asyncio.create_task(self._brain_chat("Expand on these ideas:\n\n" + content))
            else:
                panel.add_message("system", "No note loaded")
        elif cmd == "connect":
            if self.current_note:
                nid = self.current_note.frontmatter.id or self.current_note.path.stem
                neighbors = self.brain.graph.neighbors(nid)
                if neighbors:
                    lines = [f"Related to [b]{self.current_note.title}[/b]:"]
                    for n in neighbors:
                        lines.append(f"  • {n.title} ([dim]{n.path}[/dim])")
                    panel.add_message("system", "\n".join(lines))
                else:
                    panel.add_message("system", "No related notes found. Try adding tags or wiki-links.")
            else:
                panel.add_message("system", "No note loaded")
        elif cmd == "template":
            from marustorm.notes.templates import get_template, list_templates
            if not arg:
                templates = list_templates()
                panel.add_message("system", "Available templates:\n  " + "\n  ".join(templates))
                return
            tmpl = get_template(arg, title="New Note")
            if self.current_note:
                editor = self.query_one(NoteEditor)
                current = editor.get_text()
                new_text = current + "\n\n" + tmpl
                editor.query_one("#editor-textarea", type(None)).text = new_text
                panel.add_message("system", f"Template applied: {arg}")
            else:
                panel.add_message("system", "No note loaded")
        elif cmd == "tag":
            if self.current_note:
                tags = self.current_note.frontmatter.tags
                panel.add_message("system", f"Current tags: {', '.join(tags) if tags else 'none'}")
            else:
                panel.add_message("system", "Tag suggestions: #idea, #research, #todo, #draft, #reference")
        elif cmd == "help":
            self.push_screen(HelpScreen())
        elif cmd == "save":
            self.action_save_note()
        elif cmd == "new":
            title = arg or "Untitled"
            self._create_note_with_title(title)
        elif cmd == "tags":
            asyncio.create_task(self.brain.execute_slash(f"/tags {arg}", self.current_note))
        elif cmd == "graph":
            self.action_toggle_graph()
        else:
            panel.add_message("system", f"Unknown command: /{cmd}. Type /help for available commands.")

    async def _run_research(self, query: str) -> None:
        rp = self.query_one(ResearchPanel)
        try:
            result = await self.brain.execute_slash(f"/research {query}", self.current_note)
            rp.log(result)
            rp.set_status("Research complete ✓")
        except Exception as e:
            rp.log(f"[red]Research failed: {e}[/red]")
            rp.set_status("Research failed ✗")

    async def _run_swarm(self, topic: str) -> None:
        if self.swarm is None:
            self.query_one(AIPanel).add_message("system", "Swarm not available (LLM not configured)")
            return
        outline = ["Overview", "Key Features", "Architecture", "User Flow", "Technical Stack"]
        try:
            result = await self.swarm.write_document(topic, outline)
            panel = self.query_one(AIPanel)
            panel.add_message("system", f"Swarm complete! Cost: ${result.total_cost:.4f}, Tokens: {result.total_tokens}")
            if result.final_document:
                panel.add_message("assistant", result.final_document[:500] + "...")
                ts = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")
                rel = f"projects/swarm/{ts}_{topic.replace(' ', '_')}.md"
                self.note_manager.create(rel, content=result.final_document)
                self.query_one(NoteNav).reload()
                self._rebuild_search_index()
                self.notify(f"Swarm result saved: {rel}")
        except Exception as e:
            self.query_one(AIPanel).add_message("system", f"Swarm error: {e}")

    def _create_note_with_title(self, title: str) -> None:
        slug = title.lower().replace(" ", "_").replace("/", "_")[:50] or "untitled"
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        rel = f"inbox/{date}_{slug}.md"
        content = f"# {title}\n\n"
        fm = NoteFrontmatter(tags=["inbox"])
        note = self.note_manager.create(rel, content=content, frontmatter=fm)
        self.current_note = note
        self.query_one(NoteEditor).note = note
        self.query_one(NoteNav).reload()
        self._rebuild_search_index()
        self.notify(f"Created: {rel}")

    def action_new_note(self) -> None:
        self._create_note_with_title("Scatter")
        self.sub_title = f"Brainstorm . Research . Write  —  {len(list(self.note_manager.list_notes()))} notes"

    def action_save_note(self) -> None:
        if self.current_note:
            editor = self.query_one(NoteEditor)
            text = editor.get_text()
            self.current_note.content = text
            self.current_note.frontmatter.updated = datetime.now(timezone.utc).isoformat()
            rel = self.current_note.path.relative_to(self.note_root).as_posix()
            self.note_manager.write(rel, self.current_note)
            self._rebuild_search_index()
            self.query_one(PreviewPanel, PreviewPanel).render_note(text)
            self.notify("Saved")
        else:
            self.notify("No note to save", severity="warning")

    def action_delete_note(self) -> None:
        if self.current_note:
            rel = self.current_note.path.relative_to(self.note_root).as_posix()
            self.note_manager.delete(rel)
            self.current_note = None
            self.query_one(NoteEditor).note = None
            self.query_one(NoteNav).reload()
            self._rebuild_search_index()
            note_count = len(list(self.note_manager.list_notes()))
            self.sub_title = f"Brainstorm . Research . Write  —  {note_count} notes"
            self.notify(f"Deleted: {rel}")
        else:
            self.notify("No note to delete", severity="warning")

    def action_rename_note(self) -> None:
        if self.current_note:
            rel = self.current_note.path.relative_to(self.note_root).as_posix()
            # For now, just notify — full rename would need an input dialog
            self.notify(f"Current path: {rel} — use /new to create a copy with a new name", severity="warning")
        else:
            self.notify("No note to rename", severity="warning")

    def _on_ghost_request(self, text: str) -> None:
        """Request AI ghost text completion."""
        if self.brain.llm is None:
            return
        editor = self.query_one(NoteEditor)
        lines = text.splitlines()
        if lines and lines[-1].startswith("# "):
            editor.set_ghost("\nStart with the main idea...")
        elif len(text) > 100 and text.endswith("."):
            editor.set_ghost(" Next, consider...")

    def _on_ghost_accept(self) -> None:
        """Ghost text was accepted — save the note."""
        if self.current_note:
            self.action_save_note()

    def _on_autosave(self, text: str) -> None:
        """Auto-save callback from editor."""
        if self.current_note:
            self.current_note.content = text
            self.current_note.frontmatter.updated = datetime.now(timezone.utc).isoformat()
            rel = self.current_note.path.relative_to(self.note_root).as_posix()
            self.note_manager.write(rel, self.current_note)
            self.query_one(NoteEditor).mark_saved()
            self.query_one(PreviewPanel, PreviewPanel).render_note(text)
            self._rebuild_search_index()

    def action_search(self) -> None:
        def on_result(path: str | None) -> None:
            if path and self.note_manager:
                note = self.note_manager.read(path)
                if note:
                    self.current_note = note
                    self.query_one(NoteEditor).note = note
                    self.query_one(AIPanel).add_message("system", f"Found: {note.title}")

        self.push_screen(SearchScreen(self.search_index), callback=on_result)

    def action_help(self) -> None:
        self.push_screen(HelpScreen())

    def action_toggle_ai(self) -> None:
        panel = self.query_one(AIPanel)
        panel.display = not panel.display

    def action_toggle_research(self) -> None:
        panel = self.query_one(ResearchPanel)
        panel.display = not panel.display

    def action_toggle_thinking(self) -> None:
        panel = self.query_one(ThinkingPanel)
        panel.display = not panel.display

    def action_toggle_graph(self) -> None:
        graph = self.query_one(GraphView)
        editor = self.query_one(NoteEditor)
        preview = self.query_one(PreviewPanel, PreviewPanel)
        if graph.display:
            graph.display = False
            editor.display = True
            self.notify("Graph view hidden")
        else:
            graph.display = True
            editor.display = False
            preview.display = False
            graph.refresh_graph(self.brain.graph.nodes, self.brain.graph.edges)
            self.notify(f"Graph: {len(self.brain.graph.nodes)} nodes, {len(self.brain.graph.edges)} edges")

    def action_toggle_preview(self) -> None:
        preview = self.query_one(PreviewPanel, PreviewPanel)
        editor = self.query_one(NoteEditor)
        graph = self.query_one(GraphView)
        if preview.display:
            preview.display = False
            editor.display = True
            self.notify("Preview hidden")
        else:
            preview.display = True
            editor.display = False
            graph.display = False
            if self.current_note:
                preview.render_note(self.current_note.content)
            self.notify("Preview mode")

    def action_toggle_swarm(self) -> None:
        self.query_one(AIPanel).add_message("system", "Swarm mode ready. Use /swarm <topic> to start.")

    def action_focus_mode(self) -> None:
        nav = self.query_one(NoteNav)
        ai = self.query_one(AIPanel)
        nav.display = not nav.display
        ai.display = not ai.display
        self.notify("Focus mode" + (" ON" if not nav.display else " OFF"))

    def action_quit(self) -> None:
        self.exit()


# Backwards compat for import
MaruCLI = MaruStormApp
