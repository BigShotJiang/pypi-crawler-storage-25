# Market Research Skill

## Goal
Research a market, competitor landscape, and opportunities.

## Workflow
1. Define market scope
2. Research competitors
3. Identify trends
4. Synthesize findings

## Output Format
```markdown
# Market Research: {topic}

## Market Size
- TAM: 
- SAM: 
- SOM: 

## Competitors
| Company | Strength | Weakness |

## Trends
- 

## Opportunities
- 

## Sources
- [1] ...
```
