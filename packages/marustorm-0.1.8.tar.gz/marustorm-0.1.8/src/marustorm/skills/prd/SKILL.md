# PRD Skill

## Goal
Write a Product Requirements Document from a brief description.

## Workflow
1. Extract goals and non-goals
2. Define user stories
3. Sketch technical architecture
4. Define milestones

## Output Format
```markdown
# PRD: {title}

## Overview
{overview}

## Goals
- 

## Non-Goals
- 

## User Stories
- As a ..., I want ... so that ...

## Technical Architecture
- 

## Milestones
- 
```
