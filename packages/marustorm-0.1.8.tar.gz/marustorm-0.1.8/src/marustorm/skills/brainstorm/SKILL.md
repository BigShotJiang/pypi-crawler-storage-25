# Brainstorm Skill

## Goal
Generate creative ideas and organize them into actionable clusters.

## Workflow
1. Scatter raw ideas
2. Cluster by theme
3. Prioritize by impact/effort
4. Output as structured markdown

## Output Format
```markdown
# Brainstorm: {topic}

## Ideas
- [ ] Idea 1
- [ ] Idea 2

## Clusters
### Cluster A
- Idea 1
- Idea 3

## Priority Matrix
| Idea | Impact | Effort | Priority |
```
