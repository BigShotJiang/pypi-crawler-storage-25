# Daily Memo Skill

## Goal
Generate a daily reflection memo from scattered thoughts.

## Workflow
1. Collect scattered notes from today
2. Summarize key events
3. Identify blockers and wins
4. Plan tomorrow

## Output Format
```markdown
# Daily Memo: {date}

## Wins
- 

## Blockers
- 

## Learnings
- 

## Tomorrow's Focus
- 
```
