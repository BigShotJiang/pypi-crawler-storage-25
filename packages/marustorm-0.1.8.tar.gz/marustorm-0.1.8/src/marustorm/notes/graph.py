from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from marustorm.notes.parser import Note, parse_note


@dataclass
class GraphNode:
    id: str
    title: str
    path: str
    tags: set[str] = field(default_factory=set)
    links: set[str] = field(default_factory=set)


@dataclass
class GraphEdge:
    source: str
    target: str
    relation: str = "links"


class NoteGraph:
    """In-memory graph of notes built from tags and wiki-links."""

    def __init__(self) -> None:
        self.nodes: dict[str, GraphNode] = {}
        self.edges: list[GraphEdge] = []
        self._tag_index: dict[str, set[str]] = {}

    def index_note(self, note: Note) -> GraphNode:
        nid = note.frontmatter.id or note.path.stem
        node = GraphNode(
            id=nid,
            title=note.title,
            path=note.path.as_posix(),
            tags=set(note.frontmatter.tags),
            links=set(note.frontmatter.links),
        )
        self.nodes[nid] = node
        # index tags
        for tag in node.tags:
            self._tag_index.setdefault(tag, set()).add(nid)
        return node

    def build(self, notes: list[Note]) -> None:
        self.nodes.clear()
        self.edges.clear()
        self._tag_index.clear()
        for note in notes:
            self.index_note(note)
        # build edges from explicit links
        for nid, node in self.nodes.items():
            for target_id in node.links:
                if target_id in self.nodes:
                    self.edges.append(GraphEdge(nid, target_id, "links"))
        # build edges from shared tags
        for tag, nids in self._tag_index.items():
            if len(nids) > 1:
                nids_list = sorted(nids)
                for i in range(len(nids_list)):
                    for j in range(i + 1, len(nids_list)):
                        self.edges.append(GraphEdge(nids_list[i], nids_list[j], f"tag:{tag}"))

    def neighbors(self, nid: str) -> list[GraphNode]:
        result: list[GraphNode] = []
        seen = set()
        for edge in self.edges:
            if edge.source == nid and edge.target not in seen:
                seen.add(edge.target)
                result.append(self.nodes[edge.target])
            elif edge.target == nid and edge.source not in seen:
                seen.add(edge.source)
                result.append(self.nodes[edge.source])
        return result

    def by_tag(self, tag: str) -> list[GraphNode]:
        return [self.nodes[nid] for nid in self._tag_index.get(tag, []) if nid in self.nodes]

    def save(self, path: Path) -> None:
        data = {
            "nodes": [
                {
                    "id": n.id,
                    "title": n.title,
                    "path": n.path,
                    "tags": sorted(n.tags),
                    "links": sorted(n.links),
                }
                for n in self.nodes.values()
            ],
            "edges": [
                {"source": e.source, "target": e.target, "relation": e.relation}
                for e in self.edges
            ],
        }
        path.write_text(yaml.dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")

    def load(self, path: Path) -> None:
        if not path.exists():
            return
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        self.nodes.clear()
        self.edges.clear()
        self._tag_index.clear()
        for n in data.get("nodes", []):
            node = GraphNode(
                id=n["id"],
                title=n["title"],
                path=n["path"],
                tags=set(n.get("tags", [])),
                links=set(n.get("links", [])),
            )
            self.nodes[node.id] = node
            for tag in node.tags:
                self._tag_index.setdefault(tag, set()).add(node.id)
        for e in data.get("edges", []):
            self.edges.append(GraphEdge(e["source"], e["target"], e.get("relation", "links")))
