from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from loguru import logger

from marustorm.notes.parser import Note, NoteFrontmatter, parse_note, render_note
from marustorm.notes.templates import get_template


class NoteManager:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        for sub in ("inbox", "projects", "daily", "templates", "assets"):
            (self.root / sub).mkdir(exist_ok=True)
        (self.root / ".marustorm").mkdir(exist_ok=True)

    def _resolve(self, rel_path: str) -> Path:
        p = self.root / rel_path
        if not p.resolve().is_relative_to(self.root.resolve()):
            raise ValueError(f"Path {rel_path} escapes root")
        return p

    def read(self, rel_path: str) -> Note | None:
        path = self._resolve(rel_path)
        if not path.exists():
            return None
        try:
            text = path.read_text(encoding="utf-8")
            return parse_note(path, text)
        except Exception as e:
            logger.warning(f"Failed to read note {rel_path}: {e}")
            return None

    def write(self, rel_path: str, note: Note) -> None:
        path = self._resolve(rel_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        text = render_note(note)
        path.write_text(text, encoding="utf-8")

    def create(self, rel_path: str, content: str = "", frontmatter: NoteFrontmatter | None = None) -> Note:
        from datetime import datetime, timezone
        import uuid
        path = self._resolve(rel_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fm = frontmatter or NoteFrontmatter()
        if not fm.id:
            fm.id = f"marustorm_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
        if not fm.created:
            fm.created = datetime.now(timezone.utc).isoformat()
        note = Note(path=path, frontmatter=fm, content=content)
        self.write(rel_path, note)
        return note

    def delete(self, rel_path: str) -> bool:
        path = self._resolve(rel_path)
        if path.exists():
            path.unlink()
            return True
        return False

    def list_notes(self, folder: str = "") -> list[str]:
        base = self.root / folder if folder else self.root
        notes: list[str] = []
        for p in sorted(base.rglob("*.md")):
            rel = p.relative_to(self.root).as_posix()
            if ".marustorm/" not in rel:
                notes.append(rel)
        return notes

    def search_by_tag(self, tag: str) -> list[Note]:
        results: list[Note] = []
        for rel in self.list_notes():
            note = self.read(rel)
            if note and tag in note.frontmatter.tags:
                results.append(note)
        return results
