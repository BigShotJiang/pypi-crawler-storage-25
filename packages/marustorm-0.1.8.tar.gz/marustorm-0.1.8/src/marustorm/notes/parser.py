from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml


@dataclass
class NoteSource:
    id: int
    url: str
    title: str
    fetched: str = ""


@dataclass
class NoteFrontmatter:
    id: str = ""
    created: str = ""
    updated: str = ""
    tags: list[str] = field(default_factory=list)
    mood: str = ""
    ai_summary: str = ""
    links: list[str] = field(default_factory=list)
    vibe_session: str = ""
    sources: list[NoteSource] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoteFrontmatter:
        sources = [
            NoteSource(**s) if isinstance(s, dict) else s
            for s in data.pop("sources", [])
        ]
        return cls(sources=sources, **{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def to_dict(self) -> dict[str, Any]:
        data = {
            "id": self.id,
            "created": self.created,
            "updated": self.updated,
            "tags": self.tags,
            "mood": self.mood,
            "ai_summary": self.ai_summary,
            "links": self.links,
            "vibe_session": self.vibe_session,
        }
        if self.sources:
            data["sources"] = [
                {"id": s.id, "url": s.url, "title": s.title, "fetched": s.fetched}
                for s in self.sources
            ]
        return {k: v for k, v in data.items() if v}


@dataclass
class Note:
    path: Path
    frontmatter: NoteFrontmatter
    content: str

    @property
    def title(self) -> str:
        lines = self.content.strip().split("\n")
        for line in lines:
            if line.startswith("# "):
                return line[2:].strip()
        return self.path.stem

    @property
    def body(self) -> str:
        lines = self.content.strip().split("\n")
        result: list[str] = []
        in_frontmatter = False
        for line in lines:
            if line.strip() == "---":
                in_frontmatter = not in_frontmatter
                continue
            if in_frontmatter:
                continue
            result.append(line)
        return "\n".join(result).strip()


FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n(.*)$", re.DOTALL)


def parse_note(path: Path, text: str) -> Note:
    match = FRONTMATTER_RE.match(text)
    if match:
        fm_raw = match.group(1)
        content = match.group(2)
        try:
            fm_data = yaml.safe_load(fm_raw) or {}
        except yaml.YAMLError:
            fm_data = {}
        frontmatter = NoteFrontmatter.from_dict(fm_data)
    else:
        frontmatter = NoteFrontmatter()
        content = text
    return Note(path=path, frontmatter=frontmatter, content=text)


def render_note(note: Note) -> str:
    fm = note.frontmatter.to_dict()
    if not fm:
        return note.content
    fm_yaml = yaml.dump(fm, sort_keys=False, allow_unicode=True, default_flow_style=False)
    body = note.body
    return f"---\n{fm_yaml}---\n\n{body}\n"
