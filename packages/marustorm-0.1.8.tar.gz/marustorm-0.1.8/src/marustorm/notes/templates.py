from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any


TEMPLATES: dict[str, str] = {
    "brainstorm": """# Brainstorm Session

## Ideas
- 

## Questions
- 

## Next Steps
- 
""",
    "prd": """# PRD: {title}

## Overview
{overview}

## Goals
- 

## Non-Goals
- 

## User Stories
- 

## Technical Architecture
- 

## Milestones
- 
""",
    "daily": """# Daily Log: {date}

## Morning
- 

## Afternoon
- 

## Evening
- 

## Tomorrow's Focus
- 
""",
    "default": """# {title}


""",
    "bug": """# Bug Report: {title}

## Summary
Brief description of the bug.

## Steps to Reproduce
1. 
2. 
3. 

## Expected Behavior

## Actual Behavior

## Environment
- OS: 
- Version: 
- Browser: 

## Screenshots / Logs

## Possible Fix

""",
    "feature": """# Feature Spec: {title}

## Problem
What problem does this solve?

## Solution
How does this feature solve it?

## User Flow
1. 
2. 
3. 

## UI/UX Notes

## API Changes

## Open Questions
- 

## Acceptance Criteria
- [ ] 
- [ ] 
""",
    "api": """# API Design: {title}

## Endpoint

```
METHOD /path
```

## Request
```json
{
}
```

## Response
```json
{
}
```

## Errors
| Code | Description |
|------|-------------|
| 400  | Bad Request |

## Notes

""",
    "decision": """# ADR: {title}

## Context
What is the issue we're deciding?

## Decision
What did we decide?

## Consequences
### Positive
- 

### Negative
- 

## Alternatives Considered
- 

## Date
{date}
""",
    "retro": """# Retro: {title}

## What Went Well
- 

## What Could Improve
- 

## Action Items
- [ ] 
- [ ] 

## Kudos
- 
""",
    "interview": """# Interview Notes: {title}

## Candidate
- Name: 
- Role: 
- Date: {date}

## Questions & Answers
1. 

## Assessment
### Strengths
- 

### Concerns
- 

### Recommendation

""",
    "prompt": """# Prompt Engineering: {title}

## Goal
What should the AI do?

## System Prompt
```
```

## User Prompt Template
```
```

## Variables
- `{var}`: description

## Examples
### Input

### Expected Output

## Iterations
### v1

### v2

""",
    "swarm": """# Swarm Output: {title}

## Topic
{title}

## Draft

## Gaps Found

## Critique

## Synthesis

## Sources
- 
""",
}


def get_template(name: str, **kwargs: Any) -> str:
    tmpl = TEMPLATES.get(name, TEMPLATES["default"])
    kwargs.setdefault("title", "Untitled")
    kwargs.setdefault("overview", "")
    kwargs.setdefault("date", datetime.now(timezone.utc).strftime("%Y-%m-%d"))
    return tmpl.format(**kwargs)


def list_templates() -> list[str]:
    """List all available template names."""
    return sorted(TEMPLATES.keys())
