from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger

from marustorm.notes.parser import NoteSource


@dataclass
class ResearchResult:
    query: str
    summary: str
    sources: list[NoteSource]
    raw_results: list[dict[str, Any]] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.raw_results is None:
            self.raw_results = []


class MaruStormResearchEngine:
    """Wraps maru-deep-pro-search for deep research integration.
    Falls back to LLM-based research when deep search is unavailable."""

    def __init__(
        self,
        knowledge_store_path: str | Path | None = None,
        llm_client: Any | None = None,
    ) -> None:
        self.knowledge_store_path = Path(knowledge_store_path) if knowledge_store_path else None
        self.llm = llm_client
        self._researcher = None
        self._initialized = False

    async def _init_researcher(self) -> Any:
        if self._initialized:
            return self._researcher
        try:
            from deep_researcher import DeepResearcher
            self._researcher = DeepResearcher(
                store_path=str(self.knowledge_store_path) if self.knowledge_store_path else None,
            )
            self._initialized = True
            logger.info("DeepResearcher initialized")
        except ImportError:
            logger.warning("maru-deep-pro-search not installed; research will use fallback")
            self._researcher = None
            self._initialized = True
        return self._researcher

    async def research_for_note(
        self,
        query: str,
        note_context: str = "",
        max_sources: int = 5,
    ) -> ResearchResult:
        """Research a topic and return structured results with citations."""
        researcher = await self._init_researcher()
        full_query = query
        if note_context:
            full_query = f"Context:\n{note_context}\n\nResearch query:\n{query}"

        if researcher is not None:
            try:
                raw = await researcher.research(full_query, max_results=max_sources * 2)
                sources = [
                    NoteSource(
                        id=i + 1,
                        url=r.get("url", ""),
                        title=r.get("title", "Untitled"),
                        fetched=r.get("content", "")[:500],
                    )
                    for i, r in enumerate(raw[:max_sources])
                    if r.get("url")
                ]
                summary = await researcher.summarize(raw, query)
                return ResearchResult(
                    query=query,
                    summary=summary,
                    sources=sources,
                    raw_results=raw,
                )
            except Exception as e:
                logger.error("DeepResearcher failed: {e}", e=e)

        # Fallback: use LLM for research summary if available
        if self.llm is not None:
            try:
                system = (
                    "You are a research assistant. Provide a concise, well-structured "
                    "research summary with key points, relevant concepts, and practical takeaways."
                )
                prompt = f"Research topic: {query}"
                if note_context:
                    prompt += f"\n\nNote context:\n{note_context}"
                summary = await self.llm.chat(system=system, user=prompt)
                return ResearchResult(
                    query=query,
                    summary=str(summary),
                    sources=[
                        NoteSource(
                            id=1,
                            url="",
                            title="LLM-generated summary (deep search unavailable)",
                            fetched="",
                        )
                    ],
                )
            except Exception as e:
                logger.warning("LLM research fallback failed: {e}", e=e)

        # Final fallback: placeholder
        return ResearchResult(
            query=query,
            summary=f"Research for '{query}' (deep search unavailable). Configure an LLM or install maru-deep-pro-search for better results.",
            sources=[],
        )

    async def smart_fetch(self, url: str) -> str:
        """Fetch and clean content from a URL."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                text = resp.text
                # Very basic HTML strip
                try:
                    from bs4 import BeautifulSoup
                    soup = BeautifulSoup(text, "html.parser")
                    for script in soup(["script", "style"]):
                        script.decompose()
                    return soup.get_text(separator="\n", strip=True)[:8000]
                except ImportError:
                    return text[:8000]
        except Exception as e:
            logger.warning("smart_fetch failed for {url}: {e}", url=url, e=e)
            return f"[Failed to fetch {url}: {e}]"

    def expand_query(self, query: str, note_context: str = "") -> list[str]:
        """Generate related search queries to broaden research coverage."""
        expanded = [query]
        # Simple heuristic expansions
        if "how to" not in query.lower():
            expanded.append(f"how to {query}")
        if "best" not in query.lower():
            expanded.append(f"best {query}")
        if note_context:
            expanded.append(f"{query} {note_context[:100]}")
        return expanded[:5]
