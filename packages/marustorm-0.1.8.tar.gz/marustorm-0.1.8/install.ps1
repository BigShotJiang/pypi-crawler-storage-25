# MaruStorm One-Line Installer for Windows
# Usage: irm https://raw.githubusercontent.com/claudianus/marustorm/main/install.ps1 | iex

$ErrorActionPreference = "Stop"

$Repo = "claudianus/marustorm"
$Pkg = "marustorm"
$MinPython = "3.12"
$PythonVersion = "3.13"

function Write-Info { param($msg) Write-Host "[info] $msg" -ForegroundColor Cyan }
function Write-Ok   { param($msg) Write-Host "[ok]   $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "[warn] $msg" -ForegroundColor Yellow }
function Write-Err  { param($msg) Write-Host "[err]  $msg" -ForegroundColor Red }
function Write-Step { param($msg) Write-Host "`n▶ $msg" -ForegroundColor Cyan -Bold }

function Show-Banner {
    Write-Host @"
   __  ___           __                  __
  /  |/  /__ ___ _  / /  ___  ___  ____ / /_
 / /|_/ / -_) _ `` / _ \/ _ \/ _ \/ __// __/
/_/  /_/\__/\_,_/ /_.__/\___/\___/_/   \__/
"@ -ForegroundColor Cyan
}

function Test-Command { param($cmd)
    return [bool](Get-Command -Name $cmd -ErrorAction SilentlyContinue)
}

function Test-PythonVersion { param($py)
    if (-not (Test-Command $py)) { return $false }
    try {
        $ver = & $py -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ([version]$ver -ge [version]$MinPython) { return $true }
    } catch {}
    return $false
}

function Install-Uv {
    Write-Step "Installing uv (fast Python package manager)"
    if (Test-Command uv) {
        Write-Ok "uv already installed: $(& uv --version)"
        return
    }
    Write-Info "Downloading uv installer..."
    powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
    $env:Path = "$env:LOCALAPPDATA\Programs\uv;$env:Path"
    if (Test-Command uv) {
        Write-Ok "uv installed: $(& uv --version)"
    } else {
        Write-Err "uv installation failed. Install manually from https://docs.astral.sh/uv/"
        exit 1
    }
}

function Ensure-Python {
    Write-Step "Checking Python version"
    if (Test-PythonVersion "python") {
        $ver = & python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
        Write-Ok "System Python $ver meets requirement (>=$MinPython)"
        return
    }
    if (Test-PythonVersion "python3") {
        $ver = & python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
        Write-Ok "System Python $ver meets requirement (>=$MinPython)"
        return
    }
    Write-Warn "System Python is too old (< $MinPython)"
    Write-Info "Installing Python $PythonVersion via uv..."
    & uv python install $PythonVersion
    Write-Ok "Python $PythonVersion installed via uv"
}

function Install-Marustorm {
    Write-Step "Installing MaruStorm"
    $existing = $null
    if (Test-Command marustorm) {
        $existing = (& marustorm --version) -replace '.*version ',''
        Write-Info "MaruStorm already installed: v$existing"
        Write-Info "Upgrading to latest..."
    }

    $py = $null
    try { $py = & uv python find $PythonVersion 2>$null } catch {}
    if (-not $py) { try { $py = & uv python find $MinPython 2>$null } catch {} }
    if (-not $py -and (Test-PythonVersion "python3")) { $py = "python3" }
    if (-not $py -and (Test-PythonVersion "python")) { $py = "python" }

    if ($py) {
        & uv tool install --force $Pkg --python $py
    } else {
        & uv tool install --force $Pkg
    }

    $env:Path = "$(& uv tool dir)\bin;$env:Path"
    if (Test-Command marustorm) {
        $ver = (& marustorm --version) -replace '.*version ',''
        Write-Ok "MaruStorm v$ver installed successfully"
    } else {
        Write-Err "MaruStorm installation failed"
        exit 1
    }
}

function Initialize-Workspace {
    Write-Step "Initializing workspace"
    $ws = if ($env:MARUSTORM_WS) { $env:MARUSTORM_WS } else { "$env:USERPROFILE\marustorm-notes" }
    if (Test-Path "$ws\.marustorm" -or Test-Path "$ws\inbox") {
        Write-Info "Workspace already exists at $ws"
    } else {
        New-Item -ItemType Directory -Force -Path $ws | Out-Null
        & marustorm init --notes-dir $ws
    }
    Write-Ok "Workspace ready: $ws"
}

function Show-NextSteps {
    Write-Host "`n" -NoNewline
    Write-Host "✓ MaruStorm is ready!" -ForegroundColor Green -Bold
    Write-Host ""
    Write-Host "Quick start:" -Bold
    Write-Host "  marustorm           # Launch TUI"
    Write-Host "  ms                  # Short alias"
    Write-Host ""
    Write-Host "Create your first note:" -Bold
    Write-Host "  marustorm new 'My First Idea'"
    Write-Host ""
    Write-Host "Workspace:" -Bold
    Write-Host "  $env:USERPROFILE\marustorm-notes"
    Write-Host ""
    Write-Host "Help:" -Bold
    Write-Host "  Press ? inside the TUI for all commands"
    Write-Host "  marustorm --help"
    Write-Host ""
}

Show-Banner
Write-Info "Detected OS: Windows"
Install-Uv
Ensure-Python
Install-Marustorm
Initialize-Workspace
Show-NextSteps
