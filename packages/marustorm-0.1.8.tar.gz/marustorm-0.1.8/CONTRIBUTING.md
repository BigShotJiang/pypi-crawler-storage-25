# Contributing to MaruStorm / MaruStorm에 기여하기

Thank you for your interest in contributing to MaruStorm!
MaruStorm에 기여에 관심을 가져 주셔서 감사합니다!

---

## 🇺🇸 English

### Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOURNAME/marustorm.git`
3. Install in development mode: `pip install -e ".[dev]"`
4. Create a branch: `git checkout -b feature/your-feature`

### Development Workflow

```bash
# Run tests
pytest tests/test_*.py -v

# Format code
ruff check src/marustorm tests
ruff format src/marustorm tests

# Type check
pyright src/marustorm
```

### Pull Request Guidelines

- All tests must pass
- Code should be formatted with `ruff`
- Add tests for new features
- Update documentation if needed
- Keep commits atomic and well-described

### Reporting Issues

Use GitHub Issues with the appropriate template:
- 🐛 Bug Report
- ✨ Feature Request

---

## 🇰🇷 한국어

### 시작하기

1. 레포지토리를 fork합니다
2. fork를 클론합니다: `git clone https://github.com/YOURNAME/marustorm.git`
3. 개발 모드로 설치합니다: `pip install -e ".[dev]"`
4. 브랜치를 만듭니다: `git checkout -b feature/your-feature`

### 개발 워크플로우

```bash
# 테스트 실행
pytest tests/test_*.py -v

# 코드 포맷팅
ruff check src/marustorm tests
ruff format src/marustorm tests

# 타입 체크
pyright src/marustorm
```

### Pull Request 가이드라인

- 모든 테스트가 통과해야 합니다
- 코드는 `ruff`로 포맷팅되어야 합니다
- 새 기능에는 테스트를 추가하세요
- 필요하면 문서를 업데이트하세요
- 커밋은 원자적이고 잘 설명되어야 합니다

### 이슈 신고

GitHub Issues를 사용하세요. 적절한 템플릿을 선택하세요:
- 🐛 버그 리포트
- ✨ 기능 제안

---

## Code of Conduct / 행동 강령

Be respectful, constructive, and inclusive.
서로를 존중하고, 건설적으로, 포용적으로 대해주세요.
