# Installation / 설치

## Requirements / 요구사항

- Python 3.12 or higher / Python 3.12 이상
- A Unicode-capable terminal / 유니코드를 지원하는 터미널

## From PyPI / PyPI에서 설치

```bash
pip install marustorm
```

## From Source / 소스에서 설치

```bash
git clone https://github.com/claudianus/marustorm.git
cd marustorm
pip install -e ".[dev]"
```

## Optional Dependencies / 선택적 의존성

```bash
# Deep research support / 딥 리서치 지원
pip install "marustorm[research]"

# Development tools / 개발 도구
pip install "marustorm[dev]"
```

## Verify Installation / 설치 확인

```bash
marustorm --version
```

Expected output / 예상 출력:
```
marustorm, version 0.1.0
```
