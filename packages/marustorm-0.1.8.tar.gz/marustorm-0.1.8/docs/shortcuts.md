# Keyboard Shortcuts / 키보드 단축키

## TUI Shortcuts / TUI 단축키

| Key | Action | 동작 |
|-----|--------|------|
| `Ctrl+N` | New Note | 새 노트 |
| `Ctrl+S` | Save Note | 저장 |
| `Ctrl+R` | Toggle Research Panel | 연구 패널 토글 |
| `Ctrl+W` | Spawn Swarm | 스웜 실행 |
| `Ctrl+G` | Toggle Graph | 그래프 토글 |
| `Ctrl+L` | Toggle AI Panel | AI 패널 토글 |
| `Ctrl+T` | Toggle Thinking Panel | Thinking 패널 토글 |
| `Ctrl+F` | Search | 검색 |
| `Ctrl+Q` | Quit | 종료 |
| `Esc` | Focus Mode | 포커스 모드 |

## CLI Commands / CLI 명령어

```bash
marustorm init              # Initialize config and notes structure
marustorm tui               # Launch TUI (default)
marustorm new "Title"       # Create a new note
marustorm search "query"    # Search notes
marustorm research "topic"  # Research a topic
marustorm graph             # Show graph statistics
marustorm sync              # Sync with GitHub
marustorm --version         # Show version
```
