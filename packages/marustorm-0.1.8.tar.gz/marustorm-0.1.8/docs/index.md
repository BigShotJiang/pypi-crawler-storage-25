---
layout: default
title: MaruStorm Documentation
---

# ⛈️ MaruStorm Documentation

Welcome to the MaruStorm documentation. This site provides detailed guides for using and contributing to MaruStorm.

MaruStorm에 오신 것을 환영합니다. 이 문서는 MaruStorm 사용 및 기여에 대한 상세 가이드를 제공합니다.

---

## Quick Links / 빠른 링크

- [Installation Guide](installation) — 설치 가이드
- [Configuration Guide](configuration) — 설정 가이드
- [Keyboard Shortcuts](shortcuts) — 키보드 단축키
- [Contributing Guide](contributing) — 기여 가이드

---

## What is MaruStorm? / MaruStorm이란?

MaruStorm is a terminal-native, AI-powered brainstorming and note-weaving engine.

MaruStorm은 터미널 기반 AI 브레인스토밍 및 노트 짜임 엔진입니다.

### Features / 기능

| Feature | Description | 기능 | 설명 |
|---------|-------------|------|------|
| Markdown Editor | YAML frontmatter, inline citations | 마크다운 에디터 | YAML 프론트매터, 인라인 인용 |
| Deep Research | AI researches before answering | 딥 리서치 | AI가 답변 전에 연구 |
| Swarm Writing | 4 parallel agents | 스웜 라이팅 | 4개 병렬 에이전트 |
| Graph View | Connected knowledge graph | 그래프 뷰 | 연결된 지식 그래프 |
| GitHub Sync | Zero-server-cost sync | GitHub 동기화 | 서버 비용 0 동기화 |

---

## Installation / 설치

```bash
pip install marustorm
```

---

## Getting Started / 시작하기

```bash
marustorm init
marustorm
```

Press `Ctrl+Q` to quit the TUI. / TUI를 종료하려면 `Ctrl+Q`를 누르세요.

---

*Documentation is a work in progress. Contributions welcome!*
*문서는 지속적으로 개선되고 있습니다. 기여를 환영합니다!*
