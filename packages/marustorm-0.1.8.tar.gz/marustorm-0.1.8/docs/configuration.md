# Configuration / 설정

## Config File Location / 설정 파일 위치

```
~/.marustorm/config.toml
```

## Example Configuration / 예시 설정

```toml
# ~/.marustorm/config.toml

# Default model to use / 기본 모델
default_model = "gpt4o"

# Default thinking mode / 기본 thinking 모드
default_thinking = false

# Default auto-approve mode / 기본 자동 승인 모드
default_yolo = false

# Theme: dark or light / 테마: dark 또는 light
theme = "dark"

[storage]
# Local notes directory / 로컬 노트 디렉토리
notes_dir = "~/Notes"

# GitHub repo for sync (owner/repo) / 동기화용 GitHub 레포
github_repo = "yourname/notes"

# GitHub branch / GitHub 브랜치
github_branch = "main"

# Auto-sync on save / 저장 시 자동 동기화
auto_sync = false

# Sync interval in seconds / 동기화 간격 (초)
sync_interval_s = 300

[providers.openai]
type = "openai"
base_url = "https://api.openai.com/v1"
api_key = "sk-YOUR-API-KEY"

[models.gpt4o]
provider = "openai"
model = "gpt-4o"
max_context_size = 128000
```

## Environment Variables / 환경 변수

| Variable | Description | 설명 |
|----------|-------------|------|
| `MARUSTORM_CONFIG` | Path to config file | 설정 파일 경로 |
| `MARUSTORM_NOTES_DIR` | Override notes directory | 노트 디렉토리 재정의 |
