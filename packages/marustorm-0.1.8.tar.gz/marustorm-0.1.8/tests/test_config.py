from __future__ import annotations

from marustorm.config import Config, StorageConfig, get_default_config, load_config_from_string


def test_default_config():
    cfg = get_default_config()
    assert isinstance(cfg, Config)
    assert cfg.storage.notes_dir == "~/Notes"
    assert cfg.storage.auto_sync is False


def test_storage_config():
    s = StorageConfig(notes_dir="/tmp/notes", github_repo="user/repo", auto_sync=True)
    assert s.notes_dir == "/tmp/notes"
    assert s.github_repo == "user/repo"
    assert s.auto_sync is True


def test_load_config_from_string():
    toml = """
default_model = ""
theme = "dark"

[storage]
notes_dir = "~/Notes"
github_repo = "test/repo"
auto_sync = true
"""
    cfg = load_config_from_string(toml)
    assert cfg.theme == "dark"
    assert cfg.storage.github_repo == "test/repo"
    assert cfg.storage.auto_sync is True
