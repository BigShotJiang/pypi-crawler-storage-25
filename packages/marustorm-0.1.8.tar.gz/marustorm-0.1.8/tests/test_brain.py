from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from marustorm.brain.engine import BrainEngine
from marustorm.notes.manager import NoteManager
from marustorm.notes.parser import NoteFrontmatter


@pytest.fixture
def brain():
    with tempfile.TemporaryDirectory() as tmp:
        nm = NoteManager(Path(tmp))
        engine = BrainEngine(note_manager=nm)
        yield engine


def test_brain_handle_intent(brain):
    result = brain.handle_intent("rebuild_graph")
    assert "Graph rebuilt" in result
    assert "0 nodes" in result or "1 nodes" in result


def test_brain_slash_help(brain):
    result = brain._cmd_help("", None)
    assert "/research" in result
    assert "/swarm" in result


def test_brain_slash_new(brain):
    result = brain._cmd_new("My Idea", None)
    assert "Created:" in result
    assert "my_idea" in result


def test_brain_slash_tags(brain):
    brain.notes.create("a.md", frontmatter=NoteFrontmatter(tags=["idea"]))
    result = brain._cmd_tags("", None)
    assert "idea" in result
