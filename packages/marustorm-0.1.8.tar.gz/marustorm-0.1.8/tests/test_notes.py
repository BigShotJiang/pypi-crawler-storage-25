from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from marustorm.notes.manager import NoteManager
from marustorm.notes.parser import NoteFrontmatter, parse_note, render_note
from marustorm.notes.graph import NoteGraph
from marustorm.search.index import NoteIndex


@pytest.fixture
def note_manager():
    with tempfile.TemporaryDirectory() as tmp:
        yield NoteManager(Path(tmp))


def test_create_note(note_manager):
    note = note_manager.create("test.md", content="# Hello\n\nWorld", frontmatter=NoteFrontmatter(tags=["test"]))
    assert note.title == "Hello"
    assert "test" in note.frontmatter.tags
    assert note_manager.root.joinpath("test.md").exists()


def test_read_note(note_manager):
    note_manager.create("test.md", content="# Title\n\nBody", frontmatter=NoteFrontmatter())
    read = note_manager.read("test.md")
    assert read is not None
    assert read.title == "Title"
    assert "Body" in read.body


def test_list_notes(note_manager):
    note_manager.create("a.md", content="# A")
    note_manager.create("b.md", content="# B")
    notes = note_manager.list_notes()
    assert len(notes) == 2
    assert "a.md" in notes
    assert "b.md" in notes


def test_search_by_tag(note_manager):
    note_manager.create("a.md", content="# A", frontmatter=NoteFrontmatter(tags=["idea"]))
    note_manager.create("b.md", content="# B", frontmatter=NoteFrontmatter(tags=["todo"]))
    results = note_manager.search_by_tag("idea")
    assert len(results) == 1
    assert results[0].title == "A"


def test_parse_render_roundtrip():
    text = "---\nid: xyz\ntags:\n  - test\n---\n\n# Hello\n\nWorld\n"
    note = parse_note(Path("test.md"), text)
    assert note.frontmatter.id == "xyz"
    assert note.title == "Hello"
    rendered = render_note(note)
    assert "---" in rendered
    assert "xyz" in rendered


def test_graph_build(note_manager):
    note_manager.create("a.md", content="# A", frontmatter=NoteFrontmatter(tags=["shared"], links=["b"]))
    note_manager.create("b.md", content="# B", frontmatter=NoteFrontmatter(tags=["shared"]))
    graph = NoteGraph()
    notes = [note_manager.read("a.md"), note_manager.read("b.md")]
    notes = [n for n in notes if n]
    graph.build(notes)
    assert len(graph.nodes) == 2
    assert len(graph.edges) >= 1


def test_search_index(note_manager):
    note_manager.create("a.md", content="# Python Guide\n\nLearn python programming")
    note_manager.create("b.md", content="# Rust Guide\n\nLearn rust programming")
    idx = NoteIndex()
    for rel in note_manager.list_notes():
        note = note_manager.read(rel)
        if note:
            idx.add_note(note)
    hits = idx.search("python")
    assert len(hits) == 1
    assert hits[0].title == "Python Guide"


def test_fuzzy_search(note_manager):
    note_manager.create("a.md", content="# Python Guide\n\nLearn python programming")
    note_manager.create("b.md", content="# Rust Guide\n\nLearn rust programming")
    note_manager.create("c.md", content="# TypeScript Tips\n\nTypeScript best practices")
    idx = NoteIndex()
    for rel in note_manager.list_notes():
        note = note_manager.read(rel)
        if note:
            idx.add_note(note)
    # Fuzzy match: "pthon" should match "python"
    hits = idx.search("pthon")
    assert len(hits) >= 1
    assert hits[0].title == "Python Guide"
    # Partial match: "rust prog" should match Rust Guide
    hits = idx.search("rust prog")
    assert len(hits) >= 1
    assert any(h.title == "Rust Guide" for h in hits)
    # Title boost: "typescript" should rank TypeScript first
    hits = idx.search("typescript")
    assert hits[0].title == "TypeScript Tips"
