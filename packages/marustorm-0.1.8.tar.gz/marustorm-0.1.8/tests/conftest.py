"""Test configuration and fixtures for MaruStorm."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Generator

import pytest

from marustorm.config import Config, get_default_config


@pytest.fixture
def config() -> Config:
    """Create a default Config instance."""
    return get_default_config()


@pytest.fixture
def temp_notes_dir() -> Generator[Path]:
    """Create a temporary notes directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)
