from django.conf import settings

if not settings.configured:
    settings.configure(
        DEFAULT_CHARSET='utf-8',
        SECRET_KEY='test',
        USE_I18N=True,
    )

import django

django.setup()

from django.db import models
from django.test import SimpleTestCase

from smartdjango import Code, Error, Params, Validator, ValidatorErrors


@Error.register
class ParamsHookErrors:
    MEMBER_ROLE_INVALID = Error('Invalid member role', code=Code.BadRequest)
    MEMBER_ROLE_RESERVED = Error('Reserved member role', code=Code.BadRequest)


class MemberNorm:
    calls = []

    @classmethod
    def role(cls, value):
        cls.calls.append(value)
        normalized = str(value or '').strip().lower()
        if normalized not in Member.AVAILABLE_ROLES:
            raise ParamsHookErrors.MEMBER_ROLE_INVALID
        return normalized


class MemberVldt:
    calls = []

    @classmethod
    def role(cls, value):
        cls.calls.append(value)
        if value == 'owner':
            raise ParamsHookErrors.MEMBER_ROLE_RESERVED


class Member(models.Model):
    AVAILABLE_ROLES = {'admin', 'owner', 'longer'}

    role = models.CharField(max_length=5, null=True, default=' Admin ')

    norm = MemberNorm
    vldt = MemberVldt

    class Meta:
        app_label = 'tests'


class MemberParams(metaclass=Params):
    model_class = Member


class ProfileNormalizer:
    calls = []

    @classmethod
    def role(cls, value):
        cls.calls.append(value)
        return str(value).strip().lower()


class ProfileValidator:
    calls = []

    @classmethod
    def role(cls, value):
        cls.calls.append(value)
        if value != 'admin':
            raise ParamsHookErrors.MEMBER_ROLE_INVALID


class Profile(models.Model):
    role = models.CharField(max_length=20)

    normalizers = ProfileNormalizer
    validators = ProfileValidator

    class Meta:
        app_label = 'tests'


class ProfileParams(metaclass=Params):
    model_class = Profile


class EmptyHooksModel(models.Model):
    role = models.CharField(max_length=20)

    class Meta:
        app_label = 'tests'


class EmptyHooksParams(metaclass=Params):
    model_class = EmptyHooksModel


class ConflictingNorm:
    @staticmethod
    def role(value):
        return value


class ConflictingNormalizer:
    @staticmethod
    def role(value):
        return value


class ConflictingModel(models.Model):
    role = models.CharField(max_length=20)

    norm = ConflictingNorm
    normalizers = ConflictingNormalizer

    class Meta:
        app_label = 'tests'


class ConflictingParams(metaclass=Params):
    model_class = ConflictingModel


class ParamsNormVldtTests(SimpleTestCase):
    def setUp(self):
        super().setUp()
        MemberNorm.calls.clear()
        MemberVldt.calls.clear()
        ProfileNormalizer.calls.clear()
        ProfileValidator.calls.clear()

    def test_default_value_flows_through_norm_before_field_validation(self):
        cleaned = MemberParams.role.clean(Validator.unset())

        self.assertEqual(cleaned, 'admin')
        self.assertEqual(MemberNorm.calls, [' Admin '])
        self.assertEqual(MemberVldt.calls, ['admin'])

    def test_vldt_receives_normalized_value(self):
        with self.assertRaises(Error) as context:
            MemberParams.role.clean(' Owner ')

        self.assertEqual(context.exception.identifier, ParamsHookErrors.MEMBER_ROLE_RESERVED.identifier)
        self.assertEqual(MemberNorm.calls, [' Owner '])
        self.assertEqual(MemberVldt.calls, ['owner'])

    def test_field_validation_runs_before_vldt(self):
        with self.assertRaises(Error) as context:
            MemberParams.role.clean(' Longer ')

        self.assertEqual(context.exception.identifier, ValidatorErrors.NOT_VALID.identifier)
        self.assertEqual(MemberNorm.calls, [' Longer '])
        self.assertEqual(MemberVldt.calls, [])

    def test_null_short_circuits_norm_and_vldt(self):
        cleaned = MemberParams.role.clean(None)

        self.assertIsNone(cleaned)
        self.assertEqual(MemberNorm.calls, [])
        self.assertEqual(MemberVldt.calls, [])

    def test_plural_full_names_normalizers_and_validators_are_supported(self):
        cleaned = ProfileParams.role.clean(' Admin ')

        self.assertEqual(cleaned, 'admin')
        self.assertEqual(ProfileNormalizer.calls, [' Admin '])
        self.assertEqual(ProfileValidator.calls, ['admin'])

    def test_missing_hook_attributes_are_skipped(self):
        cleaned = EmptyHooksParams.role.clean('admin')

        self.assertEqual(cleaned, 'admin')

    def test_conflicting_alias_and_full_name_raise_error(self):
        with self.assertRaises(AttributeError) as context:
            ConflictingParams.role

        self.assertIn('Conflicting params hook sources', str(context.exception))
