from django.conf import settings

if not settings.configured:
    settings.configure(
        DEFAULT_CHARSET='utf-8',
        SECRET_KEY='test',
        USE_I18N=True,
    )

import django

django.setup()

from django.test import SimpleTestCase
from django.utils.translation import gettext_lazy as _

from smartdjango.code import Code
from smartdjango.error import Error
from smartdjango.middleware import APIPacker
from smartdjango.utils import io


class ErrorI18NTests(SimpleTestCase):
    def test_error_call_formats_lazy_messages(self):
        error = Error(
            _('Hello {name}'),
            code=Code.BadRequest,
            user_message=_('Welcome {name}'),
        )

        rendered = error(name='World', details=_('Translated detail'))

        self.assertEqual(rendered.message, 'Hello World')
        self.assertEqual(rendered.user_message, 'Welcome World')
        self.assertEqual(rendered.details, ['Translated detail'])

    def test_error_json_resolves_lazy_messages(self):
        error = Error(_('Bad request'), code=Code.BadRequest, user_message=_('Visible message'))

        payload = error.json()

        self.assertEqual(payload['message'], 'Bad request')
        self.assertEqual(payload['user_message'], 'Visible message')

    def test_api_packer_serializes_lazy_values(self):
        response = APIPacker.pack(Error(_('Translated error'), code=Code.BadRequest))

        self.assertEqual(
            response.content.decode(),
            '{"message": "Translated error", "code": 400, "details": [], "user_message": "Translated error", "identifier": null, "body": null}',
        )

    def test_json_dumps_supports_lazy_values(self):
        payload = io.json_dumps({'message': _('Translated body')}, indent=False)

        self.assertEqual(payload, '{"message": "Translated body"}')
