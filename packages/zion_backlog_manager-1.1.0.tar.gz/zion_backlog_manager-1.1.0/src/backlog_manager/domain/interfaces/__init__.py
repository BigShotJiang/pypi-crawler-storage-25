"""Domain interfaces (Protocols)."""
