"""Infrastructure layer - Implementacoes concretas."""
