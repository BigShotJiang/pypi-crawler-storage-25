# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html)
{
    "name": "Model Read Only",
    "category": "Tools",
    "version": "14.0.3.0.3",
    "license": "AGPL-3",
    "author": "Ilyas, ooops404, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/server-tools",
    "maintainers": ["ilyasProgrammer"],
    "depends": ["base"],
    "data": [
        "security/ir.model.access.csv",
        "views/views.xml",
    ],
}
