"""webots-mcp-kit package."""

__all__ = ["__version__"]

__version__ = "2.5.0"
