"""OCR backend for scanned/image regions, powered by Google Gemini.

Requires ``google-genai`` and a ``GEMINI_API_KEY`` in the environment or a
``.env`` file (loaded via ``python-dotenv`` if installed). The Gemini prompt
emits the pipeline's native RAG ``---`` block format directly, so no
post-processing is needed.
"""

from __future__ import annotations

import io

import fitz

# Whitespace-trim defaults applied before each OCR call to shrink the image
# sent to Gemini. Pixels with a grayscale value at or above ``TRIM_THRESHOLD``
# are treated as background; ``TRIM_PADDING_PT`` is the safety margin added
# back to the content bbox in PDF points (1 pt = 1/72 inch).
TRIM_THRESHOLD = 250
TRIM_PADDING_PT = 12.0
TRIM_SAMPLE_DPI = 50

# Default Gemini model used for OCR. Override via ``gemini_model`` kwarg.
DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite-preview"

# DPI used to render each OCR region before sending to Gemini.
DEFAULT_OCR_DPI = 300

# Prompt for Gemini OCR that emits the pipeline's native RAG block format
# for tables (no Markdown pipes) and strips footnotes/headers/page numbers.
_GEMINI_OCR_PROMPT = """You are an expert OCR system specialized in extracting complex official Arabic documents, including legal, technical, and administrative records. Extract all Arabic text exactly as it appears without translating or summarizing. Do not auto-correct spelling.

CRITICAL TABLE INSTRUCTIONS:
Format tables as plain text where each row is on a single line, and columns are explicitly separated by a pipe character ( | ). Do not use Markdown table syntax (no `|---|---|` header dividers).
If a cell is empty, preserve the structure by using consecutive pipes (e.g., ` | | `). Replace any line breaks within a cell with a space so that every row stays strictly on one line.
Example output:
Column 1 Header | Column 2 Header | Column 3 Header
Row 1 Data 1 | Row 1 Data 2 | Row 1 Data 3
Row 2 Data 1 | | Row 2 Data 3

TABLE ROW STRUCTURE (MANDATORY):
1. ROW CONTINUITY: A single logical row is one horizontal band in the source. Its text may wrap across 2+ visual lines (especially long Arabic descriptions). Merge all wrapped lines belonging to the same band into ONE pipe-separated output row. NEVER emit the description on its own line separate from the row's number/identifier.
2. COLUMN ALIGNMENT WITH HEADER: The header row defines the meaning of each column position. Every data row must place each value under the SAME column position as the header — e.g., if the header is "الرقم | البند | النقط", then a data row must be "07 | description text | 6", NOT " | | 07". A bare number on its own with two empty cells is almost always wrong; it means you split the row.
3. CONSISTENT CELL COUNT: Every data row must have exactly the same number of pipe-separated cells as the header. Pad with empty cells (` | `) only for cells that are genuinely blank in the source.
4. SANITY CHECK: Before outputting a row like ` | | X`, ask whether the description for that row appears on the next line. If yes, merge them: `X | description | points`.

EXCLUSIONS:
Strictly ignore and DO NOT extract any footnotes at the bottom of the page. You must also ignore and remove any superscript footnote markers (e.g., ¹, ², ³) embedded within the main text. Ignore all page headers, page numbers, and stamps. Only extract the core body content.

REPEATING HEADERS AND PAGE NUMBERS:
The top of each page often contains a repeating masthead or running header (e.g., "الجريدة الرسمية عدد XXXX", issue date, logos, or decorative rule lines). The bottom often contains a standalone page number (digits, sometimes wrapped like "-12-" or "(12)"). These elements are NOT body content. Skip them completely even if the geometric crop did not fully remove them. If the very first visible line is clearly a running masthead and not body prose, drop it. If the very last visible line is just a number, drop it.

CONTEXTUAL CORRECTION (NARROW):
If a word is clearly an OCR misread that produces a non-word or breaks the surrounding sentence, correct it to the obviously intended Arabic word based on context. Apply this only when the correction is unambiguous — one and only one right answer. Never paraphrase, modernize, reorder, or change legal/administrative terminology. When in doubt, keep the original characters as seen."""


def trim_to_content(
    page: fitz.Page,
    rect: fitz.Rect,
    *,
    threshold: int = TRIM_THRESHOLD,
    padding_pt: float = TRIM_PADDING_PT,
    sample_dpi: int = TRIM_SAMPLE_DPI,
) -> fitz.Rect:
    """Return a sub-rect of *rect* that excludes near-white margins.

    Renders *rect* at ``sample_dpi``, treats any pixel below ``threshold`` as
    content, and maps the content bbox back to PDF coordinates with a
    ``padding_pt`` safety margin (in PDF points). Returns *rect* unchanged if
    the area is entirely blank.
    """
    import numpy as np

    pix = page.get_pixmap(clip=rect, dpi=sample_dpi, colorspace=fitz.csGRAY)
    px_w, px_h = pix.width, pix.height
    if px_w == 0 or px_h == 0:
        return fitz.Rect(rect)

    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(px_h, px_w)
    mask = arr < threshold
    rows = np.flatnonzero(mask.any(axis=1))
    if rows.size == 0:
        return fitz.Rect(rect)
    cols = np.flatnonzero(mask.any(axis=0))

    y0_px, y1_px = int(rows[0]), int(rows[-1]) + 1
    x0_px, x1_px = int(cols[0]), int(cols[-1]) + 1

    rect_w, rect_h = rect.width, rect.height
    return fitz.Rect(
        max(rect.x0, rect.x0 + x0_px / px_w * rect_w - padding_pt),
        max(rect.y0, rect.y0 + y0_px / px_h * rect_h - padding_pt),
        min(rect.x1, rect.x0 + x1_px / px_w * rect_w + padding_pt),
        min(rect.y1, rect.y0 + y1_px / px_h * rect_h + padding_pt),
    )


def gemini_available() -> bool:
    """Return True if the google-genai library is installed."""
    try:
        from google import genai  # noqa: F401

        return True
    except ImportError:
        return False


def load_gemini_api_key() -> str | None:
    """Return the Gemini API key, loading .env first if python-dotenv is present."""
    import os

    if not os.environ.get("GEMINI_API_KEY"):
        try:
            from dotenv import find_dotenv, load_dotenv

            load_dotenv(find_dotenv(usecwd=True))
        except ImportError:
            pass
    return os.environ.get("GEMINI_API_KEY")


def run_ocr(
    page: fitz.Page,
    regions: list[fitz.Rect],
    *,
    model: str = DEFAULT_GEMINI_MODEL,
    trim_whitespace: bool = True,
    dpi: int = DEFAULT_OCR_DPI,
) -> list[tuple[float, str]]:
    """Run Gemini OCR on specific image regions of a page.

    Args:
        page: PyMuPDF page.
        regions: Image regions to OCR.
        model: Gemini model id (default: ``DEFAULT_GEMINI_MODEL``).
        trim_whitespace: Crop near-white margins off each region before
            rendering, to reduce the image size sent to Gemini.
        dpi: Resolution for the rendered region (default: ``DEFAULT_OCR_DPI``).

    Returns extracted text tuples keyed by region y-top.
    """
    if not gemini_available():
        raise RuntimeError(
            "OCR requested but 'google-genai' is not installed. "
            "Install with: pip install google-genai python-dotenv"
        )

    from google import genai
    from PIL import Image

    api_key = load_gemini_api_key()
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not set. Add it to your .env or environment."
        )

    client = genai.Client(api_key=api_key)
    results: list[tuple[float, str]] = []

    for idx, region in enumerate(regions):
        clip = trim_to_content(page, region) if trim_whitespace else region
        pix = page.get_pixmap(clip=clip, dpi=dpi)

        img = Image.open(io.BytesIO(pix.tobytes("png")))

        try:
            response = client.models.generate_content(
                model=model,
                contents=[_GEMINI_OCR_PROMPT, img],
            )

            text = (response.text or "").strip()

            if not text and response.candidates:
                candidate = response.candidates[0]
                # If there's a reason other than STOP (like RECITATION, SAFETY)
                if candidate.finish_reason and candidate.finish_reason.name != "STOP":
                    reason = candidate.finish_reason.name
                    text = f"[Gemini OCR blocked: {reason}]"

            if text:
                results.append((region.y0, text))
        except Exception as exc:
            raise RuntimeError(f"Gemini OCR failed for region: {exc}") from exc

    return results
