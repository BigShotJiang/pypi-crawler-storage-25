//! `RunPipeline` command handler.
//!
//! This is the canonical pipeline execution path. Both `zymi run` and
//! `zymi serve` dispatch [`crate::commands::RunPipeline`] commands at this
//! handler via a [`Runtime`]. The body is the same loop that used to live
//! in `engine::run_pipeline_for_request`, with three differences:
//!
//! 1. All infrastructure (store, bus, provider, contracts, orchestrator,
//!    approval handler) comes from the [`Runtime`] instead of being built
//!    inline.
//! 2. Approved tool calls go through [`crate::runtime::ActionExecutor`]
//!    instead of calling `execute_builtin_tool` directly. The engine no
//!    longer owns built-in tool details.
//! 3. The `correlation_id` and `stream_id` come from the command, so a
//!    `PipelineRequested` event delivered cross-process can be answered on
//!    the same stream the requester used.
//!
//! The deprecated `engine::run_pipeline*` entrypoints are now thin wrappers
//! that build a `Runtime` and call this function. New callers should
//! construct a `Runtime` once per project and dispatch
//! [`crate::commands::RunPipeline`] directly.

use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Instant;

use uuid::Uuid;

use crate::commands::RunPipeline;
use crate::config::pipeline::{PipelineOutput, PipelineStepKind};
use crate::config::when_expr;
use crate::config::AgentConfig;
use crate::engine::tools::{new_memory_store, MemoryStore};
use crate::esaa::orchestrator::{ApprovalContext, Orchestrator, OrchestratorResult};
use crate::events::bus::EventBus;
use crate::events::store::EventStore;
use crate::events::{Event, EventKind, OutputResolutionVia};
use crate::llm::{ChatRequest, ChatResponse, LlmProvider};
use crate::runtime::context_builder::{ContextBuilder, ContextConfig};
use crate::runtime::context_window::approx_chars;
use crate::runtime::ToolCatalog;
use crate::runtime::{ActionContext, ActionExecutor, Runtime};
use crate::types::Message;

/// Result of a single pipeline step execution.
#[derive(Debug, Clone)]
pub struct StepResult {
    pub step_id: String,
    pub agent_name: String,
    pub output: String,
    pub iterations: usize,
    pub success: bool,
}

/// Result of the full pipeline execution.
#[derive(Debug)]
pub struct PipelineResult {
    pub pipeline_name: String,
    pub step_results: HashMap<String, StepResult>,
    pub final_output: Option<String>,
    pub success: bool,
}

/// Execute a [`RunPipeline`] command against the given runtime.
pub async fn handle(rt: &Runtime, cmd: RunPipeline) -> Result<PipelineResult, String> {
    let workspace = rt.workspace();

    let pipeline = workspace
        .pipelines
        .get(&cmd.pipeline_name)
        .ok_or_else(|| {
            let available: Vec<&str> =
                workspace.pipelines.keys().map(|s| s.as_str()).collect();
            format!(
                "pipeline '{}' not found. Available: {}",
                cmd.pipeline_name,
                if available.is_empty() {
                    "(none)".to_string()
                } else {
                    available.join(", ")
                }
            )
        })?
        .clone();

    let plan = crate::config::build_execution_plan(&pipeline)
        .map_err(|e| format!("failed to build execution plan: {e}"))?;

    let memory = new_memory_store(Arc::clone(rt.bus()));
    let is_local_cli_run = cmd.stream_id.is_none();
    let resume = cmd.resume.clone();
    let is_resume = resume.is_some();
    let stream_id = cmd
        .stream_id
        .clone()
        .unwrap_or_else(|| format!("pipeline-{}-{}", pipeline.name, Uuid::new_v4()));
    let correlation_id = cmd.correlation_id;

    // For local CLI runs, emit a `PipelineRequested` marker so `zymi runs`
    // / `zymi observe` can identify the run the same way as cross-process
    // runs (which already receive one from the event router). Resume runs
    // have their PipelineRequested + WorkflowStarted + frozen-step bootstrap
    // emitted by the resume orchestrator before dispatch (ADR-0018).
    if is_local_cli_run {
        emit_event(
            rt.bus(),
            &stream_id,
            correlation_id,
            EventKind::PipelineRequested {
                pipeline: pipeline.name.clone(),
                inputs: cmd.inputs.clone(),
            },
        )
        .await;
    }

    if !is_resume {
        emit_event(
            rt.bus(),
            &stream_id,
            correlation_id,
            EventKind::WorkflowStarted {
                user_message: format!("pipeline: {}", pipeline.name),
                node_count: plan.step_count(),
            },
        )
        .await;
    }

    if is_local_cli_run {
        println!(
            "  Execution plan: {} steps, {} levels\n",
            plan.step_count(),
            plan.levels.len()
        );
    }

    let mut step_outputs: HashMap<String, String> = HashMap::new();
    let mut all_results: HashMap<String, StepResult> = HashMap::new();
    let mut overall_success = true;
    // ADR-0027: first deterministic-tool-step failure halts the pipeline.
    let mut halt: Option<String> = None;
    // ADR-0028: steps that did not run (when=false or ancestor_skipped).
    let mut skipped: HashSet<String> = HashSet::new();

    if let Some(ctx) = &resume {
        for (step_id, output) in &ctx.frozen_outputs {
            step_outputs.insert(step_id.clone(), output.clone());
            let label = pipeline
                .steps
                .iter()
                .find(|s| &s.id == step_id)
                .map(|s| match &s.kind {
                    PipelineStepKind::Agent { agent, .. } => agent.clone(),
                    PipelineStepKind::Tool { tool, .. } => format!("tool:{tool}"),
                })
                .unwrap_or_default();
            all_results.insert(
                step_id.clone(),
                StepResult {
                    step_id: step_id.clone(),
                    agent_name: label,
                    output: output.clone(),
                    iterations: 0,
                    success: true,
                },
            );
        }
    }

    for (level_idx, level) in plan.levels.iter().enumerate() {
        let level_names: Vec<&str> = level.iter().map(|s| s.as_str()).collect();
        if is_local_cli_run {
            if level.len() == 1 {
                println!("  Level {}: {}", level_idx + 1, level_names[0]);
            } else {
                println!(
                    "  Level {} (parallel): {}",
                    level_idx + 1,
                    level_names.join(", ")
                );
            }
        }

        let mut handles = Vec::new();

        for step_id in level {
            if let Some(ctx) = &resume {
                if ctx.frozen_step_ids.contains(step_id) {
                    if is_local_cli_run {
                        println!("    [{step_id}] frozen (resumed from parent)");
                    }
                    continue;
                }
            }

            let step = pipeline
                .steps
                .iter()
                .find(|s| &s.id == step_id)
                .ok_or_else(|| format!("step '{step_id}' not found in pipeline config"))?;

            // ADR-0028: conditional edges. Cascade-skip first (any skipped
            // ancestor poisons this step), then evaluate `when:` if present.
            if step.depends_on.iter().any(|d| skipped.contains(d)) {
                if is_local_cli_run {
                    println!("    [{step_id}] skipped (ancestor_skipped)");
                }
                emit_event(
                    rt.bus(),
                    &stream_id,
                    correlation_id,
                    EventKind::StepSkipped {
                        step_id: step_id.clone(),
                        reason: "ancestor_skipped".to_string(),
                    },
                )
                .await;
                skipped.insert(step_id.clone());
                continue;
            }
            if let Some(expr_src) = step.when.as_deref() {
                let resolved = resolve_str_template(expr_src, &cmd.inputs, &step_outputs);
                let truthy = match when_expr::evaluate(&resolved) {
                    Ok(v) => v,
                    Err(e) => {
                        // Treat eval error as a hard pipeline failure — the
                        // config validator catches syntax at load time, so an
                        // error here means template substitution produced
                        // something the parser can't handle. Fail-fast to
                        // surface the bad shape immediately (ADR-0027 spirit).
                        return Err(format!(
                            "step '{step_id}' when-expression eval failed after substitution: {e} (resolved: {resolved:?})"
                        ));
                    }
                };
                if !truthy {
                    if is_local_cli_run {
                        println!("    [{step_id}] skipped (when=false)");
                    }
                    emit_event(
                        rt.bus(),
                        &stream_id,
                        correlation_id,
                        EventKind::StepSkipped {
                            step_id: step_id.clone(),
                            reason: "when=false".to_string(),
                        },
                    )
                    .await;
                    skipped.insert(step_id.clone());
                    continue;
                }
            }

            let provider = Arc::clone(rt.provider());
            let orchestrator = Arc::clone(rt.orchestrator());
            let bus = Arc::clone(rt.bus());
            let store = Arc::clone(rt.store());
            let action_executor = Arc::clone(rt.action_executor());
            let tool_catalog = Arc::clone(rt.tool_catalog());
            let memory = memory.clone();
            let stream_id_clone = stream_id.clone();
            let project_root = rt.project_root().to_path_buf();
            let defaults = workspace.project.defaults.clone();
            // ADR-0022 §"Resolution order": pipeline override beats the
            // runtime-wide default, which itself is the project default
            // resolved at CLI startup.
            let approval_channel = crate::approval::resolve_channel(
                pipeline.approval_channel.as_deref(),
                rt.approval_channel(),
            );
            let approval_timeout = rt.approval_timeout();
            let context_config: ContextConfig = workspace
                .project
                .runtime
                .as_ref()
                .map(|r| r.context.clone().into())
                .unwrap_or_default();

            let step_id_owned = step_id.clone();

            match &step.kind {
                PipelineStepKind::Agent { agent: agent_name, task: raw_task } => {
                    let agent = workspace
                        .agents
                        .get(agent_name)
                        .ok_or_else(|| {
                            format!("agent '{agent_name}' not found for step '{step_id}'")
                        })?
                        .clone();
                    let task = resolve_task_template(raw_task, &cmd.inputs, &step_outputs);
                    let context = build_step_context(step_id, &step.depends_on, &step_outputs);

                    handles.push(tokio::spawn(async move {
                        run_agent_step(
                            &step_id_owned,
                            &agent,
                            &task,
                            &context,
                            Arc::clone(&provider),
                            &orchestrator,
                            Arc::clone(&bus),
                            &store,
                            action_executor.as_ref(),
                            &tool_catalog,
                            &memory,
                            &stream_id_clone,
                            correlation_id,
                            &project_root,
                            defaults.max_iterations,
                            approval_channel,
                            approval_timeout,
                            context_config,
                            is_resume,
                        )
                        .await
                    }));
                }
                PipelineStepKind::Tool { tool, args } => {
                    let tool_name = tool.clone();
                    let resolved_args =
                        resolve_args_value(args, &cmd.inputs, &step_outputs);

                    handles.push(tokio::spawn(async move {
                        run_tool_step(
                            &step_id_owned,
                            &tool_name,
                            resolved_args,
                            Arc::clone(&bus),
                            &orchestrator,
                            action_executor.as_ref(),
                            &tool_catalog,
                            &memory,
                            &stream_id_clone,
                            correlation_id,
                            &project_root,
                            approval_channel,
                            approval_timeout,
                            is_resume,
                        )
                        .await
                    }));
                }
            }
        }

        for handle in handles {
            let result = handle
                .await
                .map_err(|e| format!("step task panicked: {e}"))??;

            if is_local_cli_run {
                println!(
                    "    [{}] {} ({} iterations)",
                    result.step_id,
                    if result.success { "done" } else { "FAILED" },
                    result.iterations
                );
            }

            if !result.success {
                overall_success = false;
                // ADR-0027: deterministic tool steps fail-fast.
                let is_tool_step = pipeline
                    .steps
                    .iter()
                    .find(|s| s.id == result.step_id)
                    .map(|s| matches!(s.kind, PipelineStepKind::Tool { .. }))
                    .unwrap_or(false);
                if is_tool_step && halt.is_none() {
                    halt = Some(format!(
                        "deterministic tool step '{}' failed: {}",
                        result.step_id, result.output
                    ));
                }
            }

            step_outputs.insert(result.step_id.clone(), result.output.clone());
            all_results.insert(result.step_id.clone(), result);
        }

        if is_local_cli_run {
            println!();
        }

        if halt.is_some() {
            break;
        }
    }

    // ADR-0028 / ADR-0029: resolve the declared `output:` against the
    // skipped set. The legacy `step:` shape hard-fails when its single
    // terminal was skipped; the `any_of:` shape walks the list and picks
    // the first surviving step, hard-failing only if every candidate was
    // skipped. Halt set here lets the existing PipelineCompleted /
    // ResponseReady gating below stay untouched.
    let resolution = resolve_final_output(pipeline.output.as_ref(), &step_outputs, &skipped);
    if let Some(reason) = &resolution.halt {
        if halt.is_none() {
            overall_success = false;
            halt = Some(reason.clone());
        }
    }

    let final_output = resolution.output.clone().or_else(|| {
        plan.levels
            .last()
            .and_then(|level| level.last())
            .and_then(|step_id| step_outputs.get(step_id).cloned())
    });

    emit_event(
        rt.bus(),
        &stream_id,
        correlation_id,
        EventKind::WorkflowCompleted {
            success: overall_success,
        },
    )
    .await;

    if let Some((chosen_step, via)) = resolution.chosen.clone() {
        emit_event(
            rt.bus(),
            &stream_id,
            correlation_id,
            EventKind::OutputResolved { chosen_step, via },
        )
        .await;
    }

    // ADR-0021: declarative `outputs:` (e.g. http_post) subscribe to
    // `ResponseReady`. Translate a successful pipeline's final output into
    // that shape so connector-driven chat loops (Telegram, Slack, …) round-
    // trip without extra glue. Internal state tracking uses
    // `PipelineCompleted` / `WorkflowCompleted`; `ResponseReady` is purely
    // the external contract.
    if overall_success {
        if let Some(content) = final_output.as_deref() {
            emit_event(
                rt.bus(),
                &stream_id,
                correlation_id,
                EventKind::ResponseReady {
                    conversation_id: stream_id.clone(),
                    content: content.to_string(),
                },
            )
            .await;
        }
    }

    // Matching PipelineCompleted for the local CLI marker above. The serve
    // path publishes its own PipelineCompleted at the event router level, so
    // we skip it here to avoid duplicate completions on the same stream.
    // Resume runs are launched directly from CLI (no router), so we emit the
    // completion envelope here as well (ADR-0018).
    if is_local_cli_run || is_resume {
        emit_event(
            rt.bus(),
            &stream_id,
            correlation_id,
            EventKind::PipelineCompleted {
                pipeline: pipeline.name.clone(),
                success: overall_success,
                final_output: final_output.clone(),
                error: halt.clone(),
            },
        )
        .await;
    }

    // Close the persistent shell session for this stream (ADR-0015 §3).
    rt.shell_pool()
        .close_session(&stream_id, "workflow_end")
        .await;

    if let Some(reason) = halt {
        return Err(reason);
    }

    Ok(PipelineResult {
        pipeline_name: pipeline.name.clone(),
        step_results: all_results,
        final_output,
        success: overall_success,
    })
}

/// Run a single agent step: LLM loop with tool calls.
///
/// Context is built from the event store on each iteration via
/// [`ContextBuilder`] (ADR-0016 §4/§6). There is no in-memory
/// `Vec<Message>` — the event log is the source of truth.
#[allow(clippy::too_many_arguments)]
async fn run_agent_step(
    step_id: &str,
    agent: &AgentConfig,
    task: &str,
    context: &str,
    provider: Arc<dyn LlmProvider>,
    orchestrator: &Orchestrator,
    bus: Arc<EventBus>,
    store: &Arc<dyn EventStore>,
    action_executor: &dyn ActionExecutor,
    tool_catalog: &ToolCatalog,
    memory: &MemoryStore,
    stream_id: &str,
    correlation_id: Uuid,
    project_root: &std::path::Path,
    default_max_iterations: usize,
    approval_channel: Option<String>,
    approval_timeout: std::time::Duration,
    context_config: ContextConfig,
    // `true` when this step is being re-executed inside a `zymi resume`
    // fork (i.e. the parent's `ResumeContext` is in effect). Tools marked
    // `no_resume: true` in the catalog are shadowed in this mode: the
    // tool body is not invoked, the orchestrator is skipped, and a
    // synthetic `ToolCallCompleted{replayed: true}` is emitted instead.
    is_resume_reexec: bool,
) -> Result<StepResult, String> {
    let max_iterations = agent.max_iterations.unwrap_or(default_max_iterations);
    let tool_defs = tool_catalog.definitions_for_agent(&agent.tools);

    // Per-step sub-stream isolates this step's LLM/tool events from other
    // parallel steps on the same pipeline stream (ADR-0016 §6).
    let step_stream_id = format!("{stream_id}:step:{step_id}");

    let system_prompt = agent
        .system_prompt
        .clone()
        .unwrap_or_else(|| format!("You are the '{}' agent.", agent.name));

    let user_msg = if context.is_empty() {
        task.to_string()
    } else {
        format!("{task}\n\n---\nContext from previous steps:\n{context}")
    };

    // The ContextBuilder reads from the event store and reconstructs the
    // conversation on every iteration — no mutable Vec<Message>.
    let context_builder = ContextBuilder::new(
        Arc::clone(store),
        memory.clone(),
        step_stream_id.clone(),
        system_prompt,
        user_msg,
        context_config,
    )
    .with_compaction(Arc::clone(&provider), Arc::clone(&bus));

    // Reborrow for the rest of the function (emit_event expects &EventBus).
    let bus: &EventBus = &bus;

    // Workflow-level event on the pipeline stream.
    emit_event(
        bus,
        stream_id,
        correlation_id,
        EventKind::WorkflowNodeStarted {
            node_id: step_id.to_string(),
            description: format!("agent={}, task=\"{}\"", agent.name, truncate(task, 80)),
        },
    )
    .await;

    let mut iteration = 0;
    let mut final_output = String::new();

    loop {
        iteration += 1;
        if iteration > max_iterations {
            let success = !final_output.is_empty();
            let output = if final_output.is_empty() {
                format!("[max iterations ({max_iterations}) reached without final answer]")
            } else {
                final_output
            };
            return Ok(StepResult {
                step_id: step_id.to_string(),
                agent_name: agent.name.clone(),
                output,
                iterations: iteration - 1,
                success,
            });
        }

        // Build context from the event store (ADR-0016 §4).
        // Includes prefix (Layer A), memory snapshot (Layer B), and
        // observation-masked tail (Layer C).
        let messages = context_builder
            .build()
            .await
            .map_err(|e| format!("[{step_id}] context build failed: {e}"))?;

        emit_event(
            bus,
            &step_stream_id,
            correlation_id,
            EventKind::LlmCallStarted {
                iteration,
                message_count: messages.len(),
                approx_context_chars: approx_chars(&messages),
            },
        )
        .await;

        let request = ChatRequest {
            messages,
            tools: tool_defs.clone(),
            temperature: Some(0.7),
            max_tokens: Some(4096),
        };

        let response: ChatResponse = provider
            .chat_completion(&request)
            .await
            .map_err(|e| format!("[{step_id}] LLM call failed: {e}"))?;

        match &response.message {
            Message::Assistant {
                content,
                tool_calls,
            } => {
                let has_tool_calls = !tool_calls.is_empty();

                // Enriched event: stores the full response_message (ADR-0016 §1a).
                // The next iteration's context_builder.build() reads it back.
                emit_event(
                    bus,
                    &step_stream_id,
                    correlation_id,
                    EventKind::LlmCallCompleted {
                        response_message: Some(response.message.clone()),
                        has_tool_calls,
                        usage: Some(response.usage.clone()),
                        content_preview: content.as_ref().map(|c| truncate(c, 100).to_string()),
                    },
                )
                .await;

                if !has_tool_calls {
                    final_output = content.clone().unwrap_or_default();

                    emit_event(
                        bus,
                        stream_id,
                        correlation_id,
                        EventKind::WorkflowNodeCompleted {
                            node_id: step_id.to_string(),
                            success: true,
                        },
                    )
                    .await;

                    return Ok(StepResult {
                        step_id: step_id.to_string(),
                        agent_name: agent.name.clone(),
                        output: final_output,
                        iterations: iteration,
                        success: true,
                    });
                }

                // No messages.push(response.message) — the LlmCallCompleted
                // event IS the record. The next build() reads it back.

                for tc in tool_calls {
                    let start = Instant::now();

                    emit_event(
                        bus,
                        &step_stream_id,
                        correlation_id,
                        EventKind::ToolCallRequested {
                            tool_name: tc.name.clone(),
                            arguments: truncate(&tc.arguments, 200).to_string(),
                            call_id: tc.id.clone(),
                        },
                    )
                    .await;

                    // Shadow side-effects on `zymi resume` re-execution:
                    // skip the orchestrator (no approvals fired) and the
                    // action executor entirely, return a synthetic
                    // placeholder so the LLM's next turn still sees a
                    // well-formed (tool_use → tool_result) pairing.
                    let shadow = is_resume_reexec && tool_catalog.no_resume(&tc.name);
                    let (tool_result, is_error) = if shadow {
                        let payload = serde_json::json!({
                            "ok": true,
                            "replayed": true,
                            "note": format!(
                                "side-effect skipped during resume — tool '{}' is marked no_resume",
                                tc.name
                            ),
                        });
                        (payload.to_string(), false)
                    } else {
                        let intention = tool_catalog.intention(&tc.name, &tc.arguments);
                        let verdict = orchestrator
                            .process_intention(
                                &intention,
                                stream_id,
                                correlation_id,
                                crate::esaa::orchestrator::ApprovalContext {
                                    channel: approval_channel.as_deref(),
                                    timeout: approval_timeout,
                                },
                            )
                            .await;

                        let result = match verdict {
                            OrchestratorResult::Approved => {
                                let ctx = ActionContext {
                                    project_root,
                                    memory,
                                    stream_id,
                                    correlation_id,
                                };
                                match action_executor.execute(&tc.name, &tc.arguments, &ctx).await {
                                    Ok(output) => output,
                                    Err(e) => format!("[tool error] {e}"),
                                }
                            }
                            OrchestratorResult::Denied { reason } => {
                                format!("[denied by policy] {reason}")
                            }
                            OrchestratorResult::HumanRejected => "[rejected by human]".to_string(),
                            OrchestratorResult::NoApprovalHandler => {
                                "[requires approval but no approval handler configured]".to_string()
                            }
                        };
                        let err = result.starts_with("[tool error]")
                            || result.starts_with("[denied")
                            || result.starts_with("[rejected")
                            || result.starts_with("[requires approval");
                        (result, err)
                    };

                    let duration_ms = start.elapsed().as_millis() as u64;

                    // Enriched event: stores full tool result (ADR-0016 §1a).
                    // The next build() reads it back as a ToolResult message.
                    emit_event(
                        bus,
                        &step_stream_id,
                        correlation_id,
                        EventKind::ToolCallCompleted {
                            call_id: tc.id.clone(),
                            result: tool_result.clone(),
                            result_preview: truncate(&tool_result, 200).to_string(),
                            is_error,
                            duration_ms,
                            replayed: shadow,
                        },
                    )
                    .await;

                    // No messages.push(ToolResult) — the event IS the record.
                }
            }
            _ => {
                return Err(format!("[{step_id}] unexpected message type from LLM"));
            }
        }
    }
}

/// Run a deterministic tool step (ADR-0024).
///
/// No LLM hop. The catalog is dispatched with templated args; approvals and
/// audit events flow through the same surface as agent-issued tool calls.
#[allow(clippy::too_many_arguments)]
async fn run_tool_step(
    step_id: &str,
    tool_name: &str,
    args: serde_json::Value,
    bus: Arc<EventBus>,
    orchestrator: &Orchestrator,
    action_executor: &dyn ActionExecutor,
    tool_catalog: &ToolCatalog,
    memory: &MemoryStore,
    stream_id: &str,
    correlation_id: Uuid,
    project_root: &std::path::Path,
    approval_channel: Option<String>,
    approval_timeout: std::time::Duration,
    // See `run_agent_step::is_resume_reexec`. When a deterministic tool
    // step's tool is marked `no_resume`, the tool body is skipped and a
    // `ToolCallCompleted{replayed: true}` placeholder is recorded so
    // downstream steps that read this step's output get a stable shape.
    is_resume_reexec: bool,
) -> Result<StepResult, String> {
    let bus_ref: &EventBus = &bus;
    let step_stream_id = format!("{stream_id}:step:{step_id}");

    emit_event(
        bus_ref,
        stream_id,
        correlation_id,
        EventKind::WorkflowNodeStarted {
            node_id: step_id.to_string(),
            description: format!("tool={tool_name}"),
        },
    )
    .await;

    let args_json = serde_json::to_string(&args)
        .map_err(|e| format!("[{step_id}] failed to serialize args: {e}"))?;

    let call_id = Uuid::new_v4().to_string();
    emit_event(
        bus_ref,
        &step_stream_id,
        correlation_id,
        EventKind::ToolCallRequested {
            tool_name: tool_name.to_string(),
            arguments: truncate(&args_json, 200).to_string(),
            call_id: call_id.clone(),
        },
    )
    .await;

    let shadow = is_resume_reexec && tool_catalog.no_resume(tool_name);

    let start = Instant::now();
    let (tool_result, is_error) = if shadow {
        let payload = serde_json::json!({
            "ok": true,
            "replayed": true,
            "note": format!(
                "side-effect skipped during resume — tool '{}' is marked no_resume",
                tool_name
            ),
        });
        (payload.to_string(), false)
    } else {
        let intention = tool_catalog.intention(tool_name, &args_json);
        let verdict = orchestrator
            .process_intention(
                &intention,
                stream_id,
                correlation_id,
                ApprovalContext {
                    channel: approval_channel.as_deref(),
                    timeout: approval_timeout,
                },
            )
            .await;

        let result = match verdict {
            OrchestratorResult::Approved => {
                let ctx = ActionContext {
                    project_root,
                    memory,
                    stream_id,
                    correlation_id,
                };
                match action_executor.execute(tool_name, &args_json, &ctx).await {
                    Ok(out) => out,
                    Err(e) => format!("[tool error] {e}"),
                }
            }
            OrchestratorResult::Denied { reason } => format!("[denied by policy] {reason}"),
            OrchestratorResult::HumanRejected => "[rejected by human]".to_string(),
            OrchestratorResult::NoApprovalHandler => {
                "[requires approval but no approval handler configured]".to_string()
            }
        };
        let err = result.starts_with("[tool error]")
            || result.starts_with("[denied")
            || result.starts_with("[rejected")
            || result.starts_with("[requires approval");
        (result, err)
    };

    let duration_ms = start.elapsed().as_millis() as u64;

    emit_event(
        bus_ref,
        &step_stream_id,
        correlation_id,
        EventKind::ToolCallCompleted {
            call_id,
            result: tool_result.clone(),
            result_preview: truncate(&tool_result, 200).to_string(),
            is_error,
            duration_ms,
            replayed: shadow,
        },
    )
    .await;

    emit_event(
        bus_ref,
        stream_id,
        correlation_id,
        EventKind::WorkflowNodeCompleted {
            node_id: step_id.to_string(),
            success: !is_error,
        },
    )
    .await;

    Ok(StepResult {
        step_id: step_id.to_string(),
        agent_name: format!("tool:{tool_name}"),
        output: tool_result,
        iterations: 1,
        success: !is_error,
    })
}

/// Walk a YAML value tree, resolving `${inputs.*}` and `${steps.<id>.output}`
/// on string leaves, then convert to JSON for catalog dispatch (ADR-0024).
///
/// `${env.*}` is already resolved at parse time by `template::resolve_templates`.
fn resolve_args_value(
    value: &serde_yml::Value,
    inputs: &HashMap<String, String>,
    step_outputs: &HashMap<String, String>,
) -> serde_json::Value {
    match value {
        serde_yml::Value::Null => serde_json::Value::Null,
        serde_yml::Value::Bool(b) => serde_json::Value::Bool(*b),
        serde_yml::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                serde_json::Value::from(i)
            } else if let Some(u) = n.as_u64() {
                serde_json::Value::from(u)
            } else if let Some(f) = n.as_f64() {
                serde_json::Number::from_f64(f)
                    .map(serde_json::Value::Number)
                    .unwrap_or(serde_json::Value::Null)
            } else {
                serde_json::Value::Null
            }
        }
        serde_yml::Value::String(s) => {
            serde_json::Value::String(resolve_str_template(s, inputs, step_outputs))
        }
        serde_yml::Value::Sequence(seq) => serde_json::Value::Array(
            seq.iter()
                .map(|v| resolve_args_value(v, inputs, step_outputs))
                .collect(),
        ),
        serde_yml::Value::Mapping(map) => {
            let mut obj = serde_json::Map::with_capacity(map.len());
            for (k, val) in map {
                let key = match k {
                    serde_yml::Value::String(s) => s.clone(),
                    other => serde_yml::to_string(other).unwrap_or_default().trim().into(),
                };
                obj.insert(key, resolve_args_value(val, inputs, step_outputs));
            }
            serde_json::Value::Object(obj)
        }
        serde_yml::Value::Tagged(t) => resolve_args_value(&t.value, inputs, step_outputs),
    }
}

fn resolve_str_template(
    s: &str,
    inputs: &HashMap<String, String>,
    step_outputs: &HashMap<String, String>,
) -> String {
    let mut out = s.to_string();
    for (k, v) in inputs {
        out = out.replace(&format!("${{inputs.{k}}}"), v);
    }
    for (k, v) in step_outputs {
        out = out.replace(&format!("${{steps.{k}.output}}"), v);
    }
    out
}

/// Resolve `${inputs.*}` and `${steps.<id>.output}` in a task template.
fn resolve_task_template(
    task: &str,
    inputs: &HashMap<String, String>,
    step_outputs: &HashMap<String, String>,
) -> String {
    let mut result = task.to_string();

    for (key, value) in inputs {
        result = result.replace(&format!("${{inputs.{key}}}"), value);
    }

    for (step_id, output) in step_outputs {
        result = result.replace(
            &format!("${{steps.{step_id}.output}}"),
            truncate(output, 2000),
        );
    }

    result
}

/// Build context string from dependency step outputs.
fn build_step_context(
    _step_id: &str,
    depends_on: &[String],
    step_outputs: &HashMap<String, String>,
) -> String {
    if depends_on.is_empty() {
        return String::new();
    }

    let mut context = String::new();
    for dep in depends_on {
        if let Some(output) = step_outputs.get(dep) {
            context.push_str(&format!("## Output from step '{dep}':\n{output}\n\n"));
        }
    }
    context
}

fn truncate(s: &str, max: usize) -> &str {
    if s.len() <= max {
        s
    } else {
        let end = s.floor_char_boundary(max);
        &s[..end]
    }
}

/// Outcome of resolving `pipeline.output` against the live step state.
///
/// ADR-0029: a `step:` declaration hard-fails on skip; `any_of:` walks in
/// declared order and picks the first surviving entry, hard-failing only
/// when every candidate is skipped. The legacy "fallback to last-plan-level
/// step" branch is left to the caller so this function stays a pure
/// function of the declared `output:` and the runtime state.
#[derive(Debug, Default, Clone)]
pub(crate) struct OutputResolution {
    /// Final output content, if a winner was found.
    pub output: Option<String>,
    /// `(chosen_step, via)` to emit as `OutputResolved`. `None` when no
    /// `output:` was declared or resolution failed.
    pub chosen: Option<(String, OutputResolutionVia)>,
    /// Halt reason when resolution failed (every `any_of:` skipped, or the
    /// declared `step:` skipped). Caller sets `overall_success = false`.
    pub halt: Option<String>,
}

pub(crate) fn resolve_final_output(
    output: Option<&PipelineOutput>,
    step_outputs: &HashMap<String, String>,
    skipped: &HashSet<String>,
) -> OutputResolution {
    let Some(output) = output else {
        return OutputResolution::default();
    };
    match output {
        PipelineOutput::Step(s) => {
            if skipped.contains(&s.step) {
                return OutputResolution {
                    output: None,
                    chosen: None,
                    halt: Some(format!("output step '{}' was skipped", s.step)),
                };
            }
            OutputResolution {
                output: step_outputs.get(&s.step).cloned(),
                chosen: Some((s.step.clone(), OutputResolutionVia::Step)),
                halt: None,
            }
        }
        PipelineOutput::AnyOf(a) => {
            let mut skipped_prefix: Vec<String> = Vec::new();
            for id in &a.any_of {
                if skipped.contains(id) {
                    skipped_prefix.push(id.clone());
                    continue;
                }
                return OutputResolution {
                    output: step_outputs.get(id).cloned(),
                    chosen: Some((
                        id.clone(),
                        OutputResolutionVia::AnyOf {
                            skipped: skipped_prefix,
                        },
                    )),
                    halt: None,
                };
            }
            OutputResolution {
                output: None,
                chosen: None,
                halt: Some(format!(
                    "all any_of outputs were skipped: [{}]",
                    a.any_of.join(", ")
                )),
            }
        }
    }
}

async fn emit_event(bus: &EventBus, stream_id: &str, correlation_id: Uuid, kind: EventKind) {
    let event = Event::new(stream_id.to_string(), kind, "engine".into())
        .with_correlation(correlation_id);
    if let Err(e) = bus.publish(event).await {
        log::warn!("Engine failed to emit event: {e}");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolve_template_inputs() {
        let mut inputs = HashMap::new();
        inputs.insert("query".into(), "rust async".into());

        let result =
            resolve_task_template("Search for: ${inputs.query}", &inputs, &HashMap::new());
        assert_eq!(result, "Search for: rust async");
    }

    #[test]
    fn resolve_template_step_outputs() {
        let mut outputs = HashMap::new();
        outputs.insert("search".into(), "found 10 results".into());

        let result = resolve_task_template(
            "Summarize: ${steps.search.output}",
            &HashMap::new(),
            &outputs,
        );
        assert_eq!(result, "Summarize: found 10 results");
    }

    #[test]
    fn build_context_empty_deps() {
        let ctx = build_step_context("s1", &[], &HashMap::new());
        assert!(ctx.is_empty());
    }

    #[test]
    fn build_context_with_deps() {
        let mut outputs = HashMap::new();
        outputs.insert("search".into(), "results here".into());

        let ctx = build_step_context("summarize", &["search".into()], &outputs);
        assert!(ctx.contains("Output from step 'search'"));
        assert!(ctx.contains("results here"));
    }

    #[test]
    fn catalog_intention_shell() {
        let catalog = ToolCatalog::builtin_only();
        let intention = catalog.intention("execute_shell_command", r#"{"command":"ls"}"#);
        assert_eq!(intention.tag(), "execute_shell_command");
    }

    #[test]
    fn catalog_intention_custom() {
        let catalog = ToolCatalog::builtin_only();
        let intention = catalog.intention("my_custom_tool", r#"{"arg":"val"}"#);
        assert_eq!(intention.tag(), "call_custom_tool");
    }

    #[test]
    fn resolve_args_value_walks_strings() {
        let yaml: serde_yml::Value = serde_yml::from_str(
            r#"
repo: "${inputs.repo}"
ref: "main"
nested:
  - "${steps.fetch.output}"
  - 42
flag: true
"#,
        )
        .unwrap();

        let mut inputs = HashMap::new();
        inputs.insert("repo".into(), "https://x/y".into());
        let mut outputs = HashMap::new();
        outputs.insert("fetch".into(), "abc123".into());

        let json = resolve_args_value(&yaml, &inputs, &outputs);
        assert_eq!(json["repo"], serde_json::json!("https://x/y"));
        assert_eq!(json["ref"], serde_json::json!("main"));
        assert_eq!(json["nested"][0], serde_json::json!("abc123"));
        assert_eq!(json["nested"][1], serde_json::json!(42));
        assert_eq!(json["flag"], serde_json::json!(true));
    }

    // ADR-0029: output resolution
    use crate::config::pipeline::{AnyOfOutput, PipelineOutput, StepOutput};

    fn outputs_with(pairs: &[(&str, &str)]) -> HashMap<String, String> {
        pairs
            .iter()
            .map(|(k, v)| ((*k).to_string(), (*v).to_string()))
            .collect()
    }

    fn skip_set(ids: &[&str]) -> HashSet<String> {
        ids.iter().map(|s| (*s).to_string()).collect()
    }

    #[test]
    fn resolve_step_form_backcompat() {
        let out = PipelineOutput::Step(StepOutput {
            step: "writeup".into(),
        });
        let r = resolve_final_output(
            Some(&out),
            &outputs_with(&[("writeup", "the answer")]),
            &skip_set(&[]),
        );
        assert_eq!(r.output.as_deref(), Some("the answer"));
        assert!(r.halt.is_none());
        assert_eq!(
            r.chosen,
            Some(("writeup".to_string(), OutputResolutionVia::Step))
        );
    }

    #[test]
    fn resolve_step_form_skipped_halts() {
        let out = PipelineOutput::Step(StepOutput {
            step: "writeup".into(),
        });
        let r = resolve_final_output(Some(&out), &HashMap::new(), &skip_set(&["writeup"]));
        assert!(r.output.is_none());
        assert!(r.chosen.is_none());
        assert_eq!(r.halt.as_deref(), Some("output step 'writeup' was skipped"));
    }

    #[test]
    fn resolve_any_of_picks_first_surviving() {
        let out = PipelineOutput::AnyOf(AnyOfOutput {
            any_of: vec!["smalltalk".into(), "knowledge".into()],
        });
        let r = resolve_final_output(
            Some(&out),
            &outputs_with(&[("knowledge", "rag answer")]),
            &skip_set(&["smalltalk"]),
        );
        assert_eq!(r.output.as_deref(), Some("rag answer"));
        assert!(r.halt.is_none());
        assert_eq!(
            r.chosen,
            Some((
                "knowledge".to_string(),
                OutputResolutionVia::AnyOf {
                    skipped: vec!["smalltalk".into()],
                }
            ))
        );
    }

    #[test]
    fn resolve_any_of_first_entry_wins_no_skipped_prefix() {
        let out = PipelineOutput::AnyOf(AnyOfOutput {
            any_of: vec!["smalltalk".into(), "knowledge".into()],
        });
        let r = resolve_final_output(
            Some(&out),
            &outputs_with(&[("smalltalk", "hi there")]),
            &skip_set(&["knowledge"]),
        );
        assert_eq!(r.output.as_deref(), Some("hi there"));
        assert_eq!(
            r.chosen,
            Some((
                "smalltalk".to_string(),
                OutputResolutionVia::AnyOf { skipped: vec![] }
            ))
        );
    }

    #[test]
    fn resolve_any_of_all_skipped_fails() {
        let out = PipelineOutput::AnyOf(AnyOfOutput {
            any_of: vec!["smalltalk".into(), "knowledge".into()],
        });
        let r = resolve_final_output(
            Some(&out),
            &HashMap::new(),
            &skip_set(&["smalltalk", "knowledge"]),
        );
        assert!(r.output.is_none());
        assert!(r.chosen.is_none());
        assert!(r
            .halt
            .as_deref()
            .unwrap()
            .contains("all any_of outputs were skipped"));
    }

    #[test]
    fn resolve_none_declared_returns_empty() {
        let r = resolve_final_output(None, &HashMap::new(), &HashSet::new());
        assert!(r.output.is_none());
        assert!(r.halt.is_none());
        assert!(r.chosen.is_none());
    }

    #[test]
    fn pipeline_output_untagged_step_form_parses() {
        let yaml = "step: writeup\n";
        let out: PipelineOutput = serde_yml::from_str(yaml).unwrap();
        assert!(matches!(out, PipelineOutput::Step(s) if s.step == "writeup"));
    }

    #[test]
    fn pipeline_output_untagged_any_of_form_parses() {
        let yaml = "any_of:\n  - smalltalk\n  - knowledge\n";
        let out: PipelineOutput = serde_yml::from_str(yaml).unwrap();
        match out {
            PipelineOutput::AnyOf(a) => {
                assert_eq!(a.any_of, vec!["smalltalk".to_string(), "knowledge".into()]);
            }
            _ => panic!("expected AnyOf"),
        }
    }

    #[test]
    fn pipeline_output_rejects_both_keys() {
        let yaml = "step: a\nany_of: [b]\n";
        let err = serde_yml::from_str::<PipelineOutput>(yaml).unwrap_err();
        let msg = err.to_string();
        assert!(msg.contains("both"), "unexpected error: {msg}");
    }

    #[test]
    fn pipeline_output_rejects_empty_mapping() {
        let yaml = "other: foo\n";
        let err = serde_yml::from_str::<PipelineOutput>(yaml).unwrap_err();
        let msg = err.to_string();
        assert!(
            msg.contains("step:") && msg.contains("any_of:"),
            "unexpected error: {msg}"
        );
    }
}
