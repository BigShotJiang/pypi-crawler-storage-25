# ML Learning Notes
Generated from LearnIt board.

---

# [general] Criterion

Binary Classification (0/1): BCEWithLogitsLoss
MultiClass Classification: CrossEnthropyLoss

---

# [general] LSTM return for Classification

out = out[:, -1, :]

---

# [general] Transpose, Solve SHAPE MISSMATCH

x.shape = (batch, seq, features)
x = x.transpose(1, 2)
(batch, channels, seq)
Schimba pozitia 1 cu 2, incepem numarat de la 0

---

# [general] FineTune Whole Model/Head

for param in resnet.parameters():
    param.requires_grad = True/False
for param in resnet.fc.parameters():
    param.requires_grad = True

---

# [resnet] Resnet Training

model = resnet18(pretrained=True)
in_f = model.fc.in_features
model.fc = nn.Sequential(
    nn.Linear(in_f, 256),   # reduc dimensiunea features
    nn.ReLU(),              # non-linearity
    nn.Dropout(0.5),        # anti-overfitting
    nn.Linear(256, 1)       # output final (binary)
)
--------
model.fc = nn.Linear(in_f, num_classes)   # multiclass
---------
model.fc = nn.Linear(in_f, 1)   # binary
---------
model.fc = nn.Identity() # embeddings

---

# [general] Model preds/probs

outputs = model(x)
preds = outputs.argmax(dim=1)      # clasa finala (0...C-1)
probs = torch.softmax(outputs, dim=1)  # probabilitati pe fiecare clasa

---

# [resnet] Unfreeze another layer Resnet

for param in model.parameters():
    param.requires_grad = False
for param in model.layer4.parameters():
    param.requires_grad = True
for param in model.fc.parameters():
    param.requires_grad = True

optimizer = optim.Adam([
    {'params': model.layer4.parameters(), 'lr': 1e-4},
    {'params': model.fc.parameters(), 'lr': 1e-3}
])

---

# [resnet] Get Embeddings ResNet

encoder = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
encoder.fc = nn.Identity()
encoder.eval()
encoder = encoder.to(device)

catalog_embeddings = []
for img in catalog:
    with torch.no_grad():
        img = img.to(device)
        emb = encoder(img)
        catalog_embeddings.append(emb.cpu())

catalog_embeddings = torch.cat(catalog_embeddings)

---

# [output] Cosine Similarity Embeddings

catalog_norm = catalog_embeddings / catalog_embeddings.norm(dim=1, keepdim=True)
test_norm = test_embeddings / test_embeddings.norm(dim=1, keepdim=True)
scores = test_norm @ catalog_norm.T
best_indices = scores.argmax(dim=1)

---

# [nlp] Embeddings

embeddings_index = {}
with open('glove.6B.200d.txt', encoding='utf-8') as f:
    for line in f:
        values = line.split()
        word = values[0]
        vector = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = vector
Prima valoare e cuvantul, dupa sunt valorile, deci faci un dict cu key word si values de la word in dreapta.

---

# [nlp] Embeddings PART 2

def sentence_embedding(tokens, embeddings_index, emedding_dim=200):
    vectors = [embeddings_index[word] for word in tokens if word in embeddings_index]
    if len(vectors) == 0:
        return np.zeros(emedding_dim)
    return np.mean(vectors, axis=0)
Pentru fiecare word din tokens, daca e in embeddings, il pui ca key in embeddings ca sa iei vector. Altfel umplii cu 0*dim

---

# [general] Load given Model/Weights

model = torch.load("model.pth")
model.eval()
--------------
model = MyModel()
model.load_state_dict(torch.load("weights.pth"))
model.eval()

---

# [lstm] Multi-Label And LSTM

[1, 0, 1, 1],
[0, 0, 0, 0],
[0, 0, 0, 0],
criterion = nn.BCEWithLogitsLoss()
def forward(self,x):
        emb = self.emb(x)
        lstm, _ = self.lstm(emb)
        lstm = lstm.max(dim=1)[0] !!!
        out = self.fc(lstm)
        return out

---

# [lstm] BILSTM

class BILSTM(nn.Module):
    def __init__(self):
        super().__init__()
        self.emb = nn.Embedding(VOCAB_SIZE, 128)
        self.lstm = nn.LSTM(128,128, bidirectional=True, batch_first=True, num_layers=2, dropout=0.3)
        self.fc = nn.Linear(256,4)
    def forward(self,x):
        emb = self.emb(x)
        lstm, _ = self.lstm(emb)
        lstm = lstm.max(dim=1)[0]
        out = self.fc(lstm)
        return out

---

# [nlp] Word2Index

from collections import Counter
all_words = [w for comment in train_toknes for w in comment if w != "<PAD>"]
freq = Counter(all_words)
VOCAB_SIZE = 40000
most_commong = freq.most_common(VOCAB_SIZE)
word2index = {"<PAD>":0, "<UNK>":1}
for i,(word,_) in enumerate(most_commong):
    word2index[word] = i+1
def encode(token_list):
    return [word2index.get(w,1)for w in token_list]
X_train = [encode(t) for t in train_toknes]

---

# [nlp] Padding

for i in range(len(train_toknes)):
    if len(train_toknes[i]) > PADDING:
        train_toknes[i] = train_toknes[i][:PADDING]
    else:
        for j in range(PADDING - len(train_toknes[i])):
            train_toknes[i].append("<PAD>")

---

# [general] Unsupervised learning on Images

Kmeans on RESNET Embeddings, silhouete score pe 100 iteratii de Kmeans, intr-un for, creste, si apoi aflu cati centroizi am, SAU t-SNE

---

# [general] Class Imbalance(WEIGHTS)

Iau labeluri, apoi sklearn.compuste_weights si in CrossEntropyLos pune class weight

---

# [nlp] NLTK

text_cleaning: stop_words, lemmatizer

---

# [vision] Imread -> PIL IMAGE

img = Image.fromarray(ndarray/opencv_image)

---

# [important] Pune optimizer.zero_grad()

Pune optimizer.zero_grad() mereu!!!!!

---

# [vision] Crop, fit while keeping aspect ratio

def preprocess_symbol_pil(img_pil, out_size=48, pad=4):
    img = np.array(img_pil.convert("L"))

    _, binary = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    ys, xs = np.where(binary > 0) #aici iei toti pixeli care sunt elementul
    x1, x2 = xs.min(), xs.max()
    y1, y2 = ys.min(), ys.max()
    crop = binary[y1:y2+1, x1:x2+1]

    h, w = crop.shape
    size = max(h, w) + 2 * pad
    canvas = np.zeros((size, size), dtype=np.uint8)
    y_off = (size - h) // 2
    x_off = (size - w) // 2
    canvas[y_off:y_off+h, x_off:x_off+w] = crop
    canvas = cv2.resize(canvas, (out_size, out_size), interpolation=cv2.INTER_AREA)

    return Image.fromarray(canvas)

---

# [general] Save model on best Epoch

if loss<decoy:
        decoy = loss
        torch.save(model.state_dict(), "model.pth")
model = Model()
model.load_state_dict(torch.load("model.pth"))
model = model.to(device)
model.eval()

---

# [vision] ConnectedComponentsWithStats(For symbol in image separation)

all_sequences = []

for i in range(len(test)):
    path = os.path.join("./starting_kit/", test['datapointID'][i])
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)

    _, binary = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary, connectivity=8)

    boxes = []
    for t in range(1, num_labels): #gaseste in docs
        x = stats[t, cv2.CC_STAT_LEFT]
        y = stats[t, cv2.CC_STAT_TOP]
        w = stats[t, cv2.CC_STAT_WIDTH]
        h = stats[t, cv2.CC_STAT_HEIGHT]
        area = stats[t, cv2.CC_STAT_AREA]
        if area > 20:
            boxes.append((x, y, w, h))

    boxes = sorted(boxes, key=lambda b: b[0]) #sorteaza de la stanga la dreapta

    sequence = []
    for (x, y, w, h) in boxes:
        crop = img[y:y+h, x:x+w]
        crop_pil = Image.fromarray(crop)
        crop_pil = preprocess_symbol_pil(crop_pil, out_size=48, pad=4)
        sequence.append(crop_pil)

    all_sequences.append(sequence)

---

# [unet] UNET getitem

def __getitem__(self, index):
        img = Image.open(f"./train/images/img_{index+1:03d}.png")
        mask = Image.open(f"./train/masks/mask_{index+1:03d}.png")
        img = self.img_tf(img)
        mask = self.mask_tf(mask)
        mask = np.array(mask, dtype=np.int64)
        mask_bin = (mask > 1).astype(np.float32)
        mask_bin = torch.tensor(mask_bin).unsqueeze(0)
        return img, mask_bin

---

# [unet] UNET Pred mask loop

index = 0
model.eval()
with torch.no_grad():
    for img in test_loader:
        img = img.to(device)
        output = model(img)
        for j in range(output.shape[0]):
            mask = (torch.sigmoid(output[j]) > 0.5).float()*255
            mask = mask.squeeze(0).cpu().byte()
            pil_img = to_pil_image(mask)
            pil_img.save(f"preds/img_{index+1:03d}.png")
            index += 1

---

# [important] CUM IAU PREDICTIILE

#Binary
criterion = BCEWithLogLits()
output = model(img)
pred = (torch.sigmoid(output) > 0.5).float()

#Multiclass
criterion = CrossEnthropyLoss()
output = model(img)
pred = output.argmax(dim=1)

---

# [audio] Spectogram

spectograme = []
for i in range(len(train)):
    waveform, sr = torchaudio.load(f"./audio/S_{i:05d}.wav")
    melspec = T.MelSpectrogram(
        sample_rate=sr,
        n_mels=128,
        n_fft=1024,
        hop_length=512
    )(waveform)
    mel_spec_db = T.AmplitudeToDB()(melspec)
    spectograme.append(mel_spec_db)

---

# [audio] SpecToImage(FOR RESNET)

def spec_to_image(spec):
    if spec.dim() == 2:
        spec = spec.unsqueeze(0)
    spec = F.interpolate(spec.unsqueeze(0), size=(224, 224), mode='bilinear').squeeze(0)
    spec = spec.repeat(3, 1, 1)
    from torchvision import transforms
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
    spec = normalize(spec)
    return spec

---

# [audio] GetDistance, Pad

def get_dist(vect1, vect2):
    v1, v2 = np.array(vect1), np.array(vect2)
    return 1-(v1 @ v2)/(np.linalg.norm(v1)*np.linalg.norm(v2) + 1e-10)
---------------------------------
def pad_segment(segment, target_len):
    segment = np.array(segment)
    if len(segment) < target_len:
        pad =np.zeros((target_len-len(segment), segment.shape[1]))
        segment = np.vstack([segment,pad])
    else:
        segment = segment[:target_len]
    return segment

---

# [audio] PreprocessAudioSegmentation

def preproc_audio(wav_path, target_len=50):
    sr, data_init = wavfile.read(wav_path)
    f, t, Sxx = signal.spectrogram(data_init, sr, nperseg=1024, noverlap=500)
    Sxx = 10 * np.log10(Sxx + 1e-10)

    data = Sxx.T
    noise_base = np.mean(data[0:10], axis=0)

    dists = []
    for i in range(len(data)):
        dists.append(get_dist(data[i], noise_base))

    dists = np.array(dists)
    dists_smooth = gaussian_filter1d(dists.astype(float), sigma=4)
    thresh = dists_smooth.min() + 0.1

    curated_data = []
    temp = []

    for i in range(len(dists)):
        if dists_smooth[i] > thresh:
            temp.append(Sxx.T[i])
        else:
            if temp and len(temp) > 10:
                padd = pad_segment(temp, target_len)
                curated_data.append(padd)
            temp = []

    if temp and len(temp) > 10:
        padd = pad_segment(temp, target_len)
        curated_data.append(padd)

    return np.array(curated_data)

---
