"""Cron scheduler — local scheduled tasks for System R CLI.

Three schedule types (inspired by OpenClaw's cron system):
  at    — one-shot ISO 8601 timestamp
  every — fixed interval in seconds
  cron  — 5-field cron expression with timezone

Jobs persist to ~/.systemr/cron/jobs.json, surviving restarts.
Each job fires a ChatRequest to agents.systemr.ai in an isolated session.
Retry with exponential backoff for transient failures.

No bare print() — logging via structlog.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

import structlog

from neo.config import SYSTEMR_HOME, ensure_systemr_home

logger = structlog.get_logger(module="cron")

CRON_DIR = SYSTEMR_HOME / "cron"
JOBS_FILE = CRON_DIR / "jobs.json"
RUNS_DIR = CRON_DIR / "runs"

# Retry settings
MAX_RETRY_ATTEMPTS: int = 3
RETRY_BACKOFF_SECONDS: list[float] = [30.0, 60.0, 300.0]


class ScheduleKind(Enum):
    """Type of schedule."""

    AT = "at"  # One-shot ISO 8601 timestamp
    EVERY = "every"  # Fixed interval in seconds
    CRON = "cron"  # 5-field cron expression


@dataclass
class Schedule:
    """Job schedule definition.

    Attributes:
        kind: Schedule type (at, every, cron).
        at: ISO 8601 timestamp for one-shot jobs.
        every_seconds: Interval in seconds for recurring jobs.
        expr: Cron expression (5-field) for cron jobs.
        tz: IANA timezone for cron expressions (default: local).
    """

    kind: ScheduleKind
    at: str | None = None
    every_seconds: float | None = None
    expr: str | None = None
    tz: str | None = None


@dataclass
class CronJob:
    """A scheduled job definition.

    Attributes:
        id: Unique job identifier.
        name: Human-readable name.
        schedule: When to run.
        message: Prompt to send to the backend.
        model: Optional model override for this job.
        enabled: Whether the job is active.
        delete_after_run: Auto-delete one-shot jobs after success.
        created_at: ISO 8601 creation timestamp.
        last_run_at: ISO 8601 timestamp of last execution.
        run_count: Total times executed.
        error_count: Consecutive error count.
    """

    id: str = ""
    name: str = ""
    schedule: Schedule = field(default_factory=lambda: Schedule(kind=ScheduleKind.AT))
    message: str = ""
    model: str | None = None
    enabled: bool = True
    delete_after_run: bool = False
    created_at: str = ""
    last_run_at: str | None = None
    run_count: int = 0
    error_count: int = 0

    def __post_init__(self) -> None:
        """Set defaults for new jobs."""
        if not self.id:
            self.id = f"job_{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()


@dataclass
class RunRecord:
    """Record of a single job execution.

    Attributes:
        job_id: Which job ran.
        run_at: ISO 8601 timestamp.
        status: ok, error, or skipped.
        message: Error message if failed.
        duration_seconds: How long the run took.
    """

    job_id: str
    run_at: str = ""
    status: str = "ok"
    message: str = ""
    duration_seconds: float = 0.0

    def __post_init__(self) -> None:
        if not self.run_at:
            self.run_at = datetime.now(timezone.utc).isoformat()


def _ensure_cron_dirs() -> None:
    """Create cron directories if they don't exist."""
    ensure_systemr_home()
    CRON_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    RUNS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def _serialize_schedule(s: Schedule) -> dict[str, Any]:
    """Serialize a Schedule to JSON-safe dict."""
    return {
        "kind": s.kind.value,
        "at": s.at,
        "every_seconds": s.every_seconds,
        "expr": s.expr,
        "tz": s.tz,
    }


def _deserialize_schedule(d: dict[str, Any]) -> Schedule:
    """Deserialize a Schedule from JSON dict."""
    return Schedule(
        kind=ScheduleKind(d.get("kind", "at")),
        at=d.get("at"),
        every_seconds=d.get("every_seconds"),
        expr=d.get("expr"),
        tz=d.get("tz"),
    )


def load_jobs() -> list[CronJob]:
    """Load all cron jobs from disk.

    Returns:
        List of CronJob instances.
    """
    if not JOBS_FILE.exists():
        return []

    try:
        data = json.loads(JOBS_FILE.read_text())
        jobs = []
        for item in data:
            schedule = _deserialize_schedule(item.pop("schedule", {}))
            job = CronJob(**item, schedule=schedule)
            jobs.append(job)
        return jobs
    except (json.JSONDecodeError, TypeError, KeyError) as exc:
        logger.warning("cron_jobs_parse_error", error=str(exc))
        return []


def save_jobs(jobs: list[CronJob]) -> None:
    """Persist all cron jobs to disk.

    Args:
        jobs: List of CronJob instances.
    """
    _ensure_cron_dirs()
    data = []
    for job in jobs:
        item = {
            "id": job.id,
            "name": job.name,
            "schedule": _serialize_schedule(job.schedule),
            "message": job.message,
            "model": job.model,
            "enabled": job.enabled,
            "delete_after_run": job.delete_after_run,
            "created_at": job.created_at,
            "last_run_at": job.last_run_at,
            "run_count": job.run_count,
            "error_count": job.error_count,
        }
        data.append(item)

    JOBS_FILE.write_text(json.dumps(data, indent=2))
    logger.info("cron_jobs_saved", count=len(jobs))


def add_job(
    name: str,
    message: str,
    schedule: Schedule,
    model: str | None = None,
    delete_after_run: bool = False,
) -> CronJob:
    """Create and persist a new cron job.

    Args:
        name: Human-readable job name.
        message: Prompt to send when job fires.
        schedule: When to run.
        model: Optional model override.
        delete_after_run: Auto-delete one-shot jobs after success.

    Returns:
        The created CronJob.
    """
    job = CronJob(
        name=name,
        message=message,
        schedule=schedule,
        model=model,
        delete_after_run=delete_after_run,
    )
    jobs = load_jobs()
    jobs.append(job)
    save_jobs(jobs)
    logger.info("cron_job_added", id=job.id, name=name, kind=schedule.kind.value)
    return job


def remove_job(job_id: str) -> bool:
    """Remove a job by ID.

    Args:
        job_id: Job identifier.

    Returns:
        True if removed, False if not found.
    """
    jobs = load_jobs()
    original_count = len(jobs)
    jobs = [j for j in jobs if j.id != job_id]
    if len(jobs) == original_count:
        return False
    save_jobs(jobs)
    logger.info("cron_job_removed", id=job_id)
    return True


def get_job(job_id: str) -> CronJob | None:
    """Get a job by ID.

    Args:
        job_id: Job identifier.

    Returns:
        CronJob if found, None otherwise.
    """
    for job in load_jobs():
        if job.id == job_id:
            return job
    return None


def record_run(run: RunRecord) -> None:
    """Append a run record to the job's run history.

    Args:
        run: The RunRecord to persist.
    """
    _ensure_cron_dirs()
    run_file = RUNS_DIR / f"{run.job_id}.jsonl"
    line = json.dumps({
        "run_at": run.run_at,
        "status": run.status,
        "message": run.message,
        "duration_seconds": run.duration_seconds,
    })
    with open(run_file, "a") as f:
        f.write(line + "\n")


def get_runs(job_id: str, limit: int = 20) -> list[dict[str, Any]]:
    """Get recent run history for a job.

    Args:
        job_id: Job identifier.
        limit: Maximum records to return.

    Returns:
        List of run record dicts, newest first.
    """
    run_file = RUNS_DIR / f"{job_id}.jsonl"
    if not run_file.exists():
        return []

    try:
        lines = run_file.read_text().strip().splitlines()
        runs = [json.loads(line) for line in lines[-limit:]]
        runs.reverse()
        return runs
    except (json.JSONDecodeError, TypeError):
        return []


def is_due(job: CronJob) -> bool:
    """Check if a job is due to run now.

    For 'at' jobs: due if current time >= scheduled time.
    For 'every' jobs: due if interval elapsed since last run.
    For 'cron' jobs: simplified check (full cron parsing deferred).

    Args:
        job: The job to check.

    Returns:
        True if the job should run now.
    """
    if not job.enabled:
        return False

    now = time.time()

    if job.schedule.kind == ScheduleKind.AT:
        if not job.schedule.at:
            return False
        try:
            target = datetime.fromisoformat(job.schedule.at).timestamp()
            return now >= target
        except ValueError:
            return False

    if job.schedule.kind == ScheduleKind.EVERY:
        if not job.schedule.every_seconds:
            return False
        if job.last_run_at is None:
            return True
        try:
            last = datetime.fromisoformat(job.last_run_at).timestamp()
            return now >= last + job.schedule.every_seconds
        except ValueError:
            return True

    # CRON expression — requires external library for full parsing.
    # For now, treat as always due (will be refined with croner equiv).
    if job.schedule.kind == ScheduleKind.CRON:
        if job.last_run_at is None:
            return True
        try:
            last = datetime.fromisoformat(job.last_run_at).timestamp()
            return now >= last + 60  # Minimum 1 minute between cron runs
        except ValueError:
            return True

    return False
