"""SSE streaming client for System R chat endpoint.

Implements the Server-Sent Events specification:
https://html.spec.whatwg.org/multipage/server-sent-events.html

Features:
- Multi-line data: field concatenation (spec-compliant)
- Comment filtering (lines starting with :)
- id: field tracking for reconnection via Last-Event-Id
- retry: field acknowledgment
- Reconnection with configurable max retries
- HTTPS validation on API URL
- Configurable timeouts and endpoint paths
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx
import structlog

from neo.config import get_api_url

logger = structlog.get_logger(module="streaming")

# ── Configurable constants ──────────────────────────────────────────

MAX_HISTORY_MESSAGES: int = 20
STREAM_TIMEOUT_SECONDS: float = 180.0
CONNECT_TIMEOUT_SECONDS: float = 15.0
BLOCKING_TIMEOUT_SECONDS: float = 120.0
CHAT_STREAM_PATH: str = "/api/v1/agent/chat/stream"
CHAT_BLOCKING_PATH: str = "/api/v1/agent/chat"
CHAT_CONFIRM_PATH: str = "/api/v1/agent/chat/confirm"
MAX_RETRIES: int = 1


@dataclass
class SSEEvent:
    """A single Server-Sent Event from the chat stream.

    Attributes:
        event: Event type (thinking, action, text_delta, confirmation_required, done, error).
        data: Raw data string (may be multi-line per SSE spec).
        id: Optional event ID for reconnection tracking.
        parsed: Data parsed as JSON dict. Falls back to {"text": data} on parse failure.
    """

    event: str
    data: str
    id: str | None = None
    parsed: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Parse data as JSON on construction."""
        if self.data:
            try:
                self.parsed = json.loads(self.data)
            except (json.JSONDecodeError, TypeError):
                self.parsed = {"text": self.data}


@dataclass
class ChatRequest:
    """Request payload for the chat stream endpoint.

    Attributes:
        user_input: The user's message (required).
        session_id: Optional session identifier.
        model: Optional model override (e.g., "anthropic.claude-opus-4-6").
        history: Conversation history (truncated to MAX_HISTORY_MESSAGES).
        profile: PROFILE.md content for context injection.
        rules: RULES.md content for rule enforcement.
        research_mode: If True, enriches with news/sentiment data.
        thinking_visible: If True, streams thinking events to the client.
    """

    user_input: str
    session_id: str | None = None
    model: str | None = None
    history: list[dict[str, str]] = field(default_factory=list)
    profile: str | None = None
    rules: str | None = None
    daily_context: str | None = None
    research_mode: bool = False
    thinking_visible: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Serialize to API request payload.

        Returns:
            Dict ready for JSON serialization. Empty optional fields are omitted.
        """
        payload: dict[str, Any] = {"user_input": self.user_input}
        if self.session_id:
            payload["session_id"] = self.session_id
        if self.model:
            payload["model"] = self.model
        if self.history:
            payload["history"] = self.history[-MAX_HISTORY_MESSAGES:]
        # Merge profile + daily context into a single context field
        context_parts = []
        if self.profile:
            context_parts.append(self.profile)
        if self.daily_context:
            context_parts.append(self.daily_context)
        if context_parts:
            payload["context"] = "\n\n---\n\n".join(context_parts)
        if self.rules:
            payload["rules"] = self.rules
        payload["research_mode"] = self.research_mode
        return payload


async def stream_chat(
    request: ChatRequest,
    access_token: str,
) -> AsyncIterator[SSEEvent]:
    """Stream chat responses from the backend via SSE.

    Implements the full SSE parsing specification:
    - Multi-line data: fields are concatenated with newlines
    - Comment lines (starting with :) are ignored
    - id: field tracked for reconnection via Last-Event-Id header
    - retry: field acknowledged
    - Reconnection on stream drop (up to MAX_RETRIES)

    Args:
        request: The chat request payload.
        access_token: Bearer token for authentication (or empty if using API key).

    Yields:
        SSEEvent objects: thinking, action, text_delta, confirmation_required, done, error.
    """
    from neo.config import get_api_key

    api_url = get_api_url()
    url = f"{api_url}{CHAT_STREAM_PATH}"

    # API key takes precedence over session token
    api_key = get_api_key()
    if api_key:
        auth_header = {"X-API-Key": api_key}
    else:
        auth_header = {"Authorization": f"Bearer {access_token}"}

    headers = {
        **auth_header,
        "Accept": "text/event-stream",
        "Cache-Control": "no-cache",
    }

    last_event_id: str | None = None
    retries = 0

    while retries <= MAX_RETRIES:
        try:
            if last_event_id:
                headers["Last-Event-Id"] = last_event_id

            timeout = httpx.Timeout(
                STREAM_TIMEOUT_SECONDS, connect=CONNECT_TIMEOUT_SECONDS,
            )
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream(
                    "POST", url, json=request.to_dict(), headers=headers,
                ) as response:
                    if response.status_code != 200:
                        body = await response.aread()
                        logger.error(
                            "stream_http_error",
                            status=response.status_code,
                            body=body.decode(errors="replace")[:200],
                        )
                        yield SSEEvent(
                            event="error",
                            data=json.dumps({
                                "message": (
                                    f"HTTP {response.status_code}: "
                                    f"{body.decode(errors='replace')[:200]}"
                                ),
                            }),
                        )
                        return

                    # SSE spec-compliant parser
                    event_type = ""
                    data_lines: list[str] = []
                    event_id: str | None = None

                    async for line in response.aiter_lines():
                        # Comment lines — ignore (often keep-alives)
                        if line.startswith(":"):
                            continue

                        if line.startswith("event:"):
                            event_type = line[6:].strip()

                        elif line.startswith("data:"):
                            # SSE spec: consecutive data: lines concatenated with \n
                            data_lines.append(line[5:].strip())

                        elif line.startswith("id:"):
                            event_id = line[3:].strip()
                            last_event_id = event_id

                        elif line.startswith("retry:"):
                            pass  # Acknowledged, not used for timing

                        elif line == "":
                            # Empty line = dispatch event
                            if data_lines:
                                data_str = "\n".join(data_lines)
                                evt = event_type or "text_delta"
                                yield SSEEvent(
                                    event=evt, data=data_str, id=event_id,
                                )
                            # Reset for next event
                            event_type = ""
                            data_lines = []
                            event_id = None

                    # Flush any remaining event at stream end
                    if data_lines:
                        data_str = "\n".join(data_lines)
                        evt = event_type or "text_delta"
                        yield SSEEvent(
                            event=evt, data=data_str, id=event_id,
                        )

            # Stream completed normally
            return

        except (httpx.ReadTimeout, httpx.RemoteProtocolError, httpx.ReadError):
            retries += 1
            logger.warning("stream_connection_lost", retry=retries)
            if retries > MAX_RETRIES:
                yield SSEEvent(
                    event="error",
                    data=json.dumps({
                        "message": "Stream connection lost. Falling back.",
                    }),
                )
                return

        except httpx.ConnectError:
            logger.error("stream_connect_failed")
            yield SSEEvent(
                event="error",
                data=json.dumps({
                    "message": "Cannot connect to System R. Check your network.",
                }),
            )
            return


TOOL_CALL_PATH: str = "/v1/tools/call"


async def call_tool(
    tool_name: str,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """Execute a tool via the /v1/tools/call endpoint.

    Uses API key auth (X-API-Key header). Falls back to Bearer token
    if no API key is configured.

    Args:
        tool_name: The tool to call (e.g. "calculate_position_size").
        arguments: Tool arguments dict.

    Returns:
        Response dict with "tool_name", "result", and balance info.

    Raises:
        httpx.HTTPStatusError: On non-2xx responses (402 = insufficient balance).
    """
    from neo.config import get_api_key

    api_url = get_api_url()
    url = f"{api_url}{TOOL_CALL_PATH}"

    api_key = get_api_key()
    if api_key:
        headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
    else:
        headers = {"Content-Type": "application/json"}

    payload = {"tool_name": tool_name, "arguments": arguments}

    timeout = httpx.Timeout(30.0, connect=CONNECT_TIMEOUT_SECONDS)
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        return resp.json()


async def chat_blocking(
    request: ChatRequest,
    access_token: str,
) -> dict[str, Any]:
    """Fallback blocking chat call (non-streaming).

    Args:
        request: The chat request payload.
        access_token: Bearer token for authentication.

    Returns:
        Response dict from the API.

    Raises:
        httpx.HTTPStatusError: On non-2xx responses.
    """
    api_url = get_api_url()
    url = f"{api_url}{CHAT_BLOCKING_PATH}"
    headers = {"Authorization": f"Bearer {access_token}"}

    timeout = httpx.Timeout(
        BLOCKING_TIMEOUT_SECONDS, connect=CONNECT_TIMEOUT_SECONDS,
    )
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(url, json=request.to_dict(), headers=headers)
        resp.raise_for_status()
        return resp.json()


async def send_confirmation(
    confirmation_token: str,
    approved: bool,
    access_token: str,
) -> dict[str, Any]:
    """Send confirmation response for a pending trade action.

    The backend pauses execution when it encounters a trade action
    requiring confirmation. It sends a confirmation_required SSE event
    with a token. The CLI prompts the user, then calls this endpoint
    to approve or deny. The backend then resumes or cancels.

    Args:
        confirmation_token: Token from the confirmation_required event.
        approved: True to approve, False to deny.
        access_token: Bearer token for authentication.

    Returns:
        Response dict from the API.
    """
    api_url = get_api_url()
    url = f"{api_url}{CHAT_CONFIRM_PATH}"
    headers = {"Authorization": f"Bearer {access_token}"}

    payload = {
        "confirmation_token": confirmation_token,
        "approved": approved,
    }

    timeout = httpx.Timeout(
        BLOCKING_TIMEOUT_SECONDS, connect=CONNECT_TIMEOUT_SECONDS,
    )
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        return resp.json()
