"""Chat message renderer — System R streaming conversation display.

Green left-border for assistant responses (┃), no box panels.
Thinking and tool status use spinners and check marks.
No double rendering — text deltas collected, rendered once on done.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Union

from neo.display.theme import (
    GREEN,
    GREEN_DIM,
    DIM,
    MUTED,
    GRAY,
    WHITE,
    RED,
    AMBER,
    console,
)

ICON_THINKING = "◐"
ICON_SUCCESS = "✓"
ICON_ERROR = "✗"

_LOW_BALANCE_THRESHOLD: Decimal = Decimal("50")


def render_user_message(text: str) -> None:
    """Render user input echo. Skipped — prompt_toolkit already shows it."""
    pass  # No-op: avoids double echo


def render_assistant_message(text: str) -> None:
    """Render a complete System R response with green left border.

    Args:
        text: The full response text (may contain markdown).
    """
    if not text.strip():
        return
    console.print()
    for line in text.split("\n"):
        console.print(f"  [{GREEN}]┃[/] {line}")
    console.print(f"  [{GREEN}]┃[/]")
    console.print()


def render_thinking(text: str = "Thinking...") -> None:
    """Show a thinking/processing step.

    Args:
        text: Description of current processing step.
    """
    console.print(f"  [{DIM}]{ICON_THINKING} {text}[/]", end="\r")


def render_action(
    tool_name: str,
    status: str = "running",
    result: str = "",
) -> None:
    """Show a tool call with status.

    Args:
        tool_name: Name of the tool being called.
        status: One of "running", "done", "error", "pending".
        result: Optional result or cost string.
    """
    if status == "done" or status == "complete":
        suffix = f"  [{DIM}]{result}[/]" if result else ""
        console.print(f"  [{GREEN}]{ICON_SUCCESS} {tool_name}[/]{suffix}")
    elif status == "error":
        suffix = f"  [{RED}]{result}[/]" if result else ""
        console.print(f"  [{RED}]{ICON_ERROR} {tool_name}[/]{suffix}")
    elif status == "pending":
        suffix = f"  [{AMBER}]{result}[/]" if result else ""
        console.print(f"  [{AMBER}]! {tool_name}[/]{suffix}")
    else:
        # Running — use carriage return so it gets overwritten by done/error
        console.print(f"  [{DIM}]{ICON_THINKING} {tool_name}...[/]")


def render_error(message: str) -> None:
    """Show an error message.

    Args:
        message: The error message text.
    """
    console.print(f"  [{RED}]{ICON_ERROR} {message}[/]")


def render_credits(
    credits_used: Union[Decimal, float, None] = None,
    balance: Union[Decimal, float, None] = None,
) -> None:
    """Show credit usage after a response.

    Args:
        credits_used: Credits consumed by this response.
        balance: Remaining credit balance.
    """
    parts: list[str] = []
    if credits_used is not None:
        parts.append(f"${float(credits_used):.3f}")
    if balance is not None:
        bal = Decimal(str(balance)) if not isinstance(balance, Decimal) else balance
        if bal < _LOW_BALANCE_THRESHOLD:
            parts.append(f"[{AMBER}]balance: ${float(balance):.2f}[/]")
        else:
            parts.append(f"balance: ${float(balance):.2f}")
    if parts:
        console.print(f"  [{DIM}]{' · '.join(parts)}[/]")
