"""Rich table helpers — dark, precise, institutional tables.

System R brand: green accent on dark background. Labels in green,
values in white. Matches DESIGN.md §4.3 typography rules.
"""

from __future__ import annotations

from typing import Any

from rich.table import Table

from neo.display.theme import GREEN, GREEN_DIM, DIM, console


def kv_table(title: str, data: dict[str, Any], *, value_style: str = f"bold {GREEN}") -> None:
    """Print a key-value table — labels in green, values in white."""
    table = Table(
        title=f"[bold {GREEN}]{title}[/]",
        show_header=False,
        border_style=DIM,
        padding=(0, 2),
        title_justify="left",
    )
    table.add_column("Key", style=GREEN_DIM, min_width=18)
    table.add_column("Value", style=value_style)
    for key, value in data.items():
        table.add_row(key, str(value))
    console.print(table)
    console.print()


def data_table(
    title: str,
    columns: list[tuple[str, str]],  # (name, style)
    rows: list[list[str]],
) -> None:
    """Print a data table with brand-styled columns."""
    table = Table(
        title=f"[bold {GREEN}]{title}[/]",
        border_style=DIM,
        padding=(0, 1),
        title_justify="left",
        row_styles=[f"{GREEN_DIM}", ""],  # alternating subtle rows
    )
    for col_name, col_style in columns:
        # Default to green if no style specified
        style = col_style if col_style else GREEN
        table.add_column(col_name, style=style, header_style=f"bold {GREEN}")
    for row in rows:
        table.add_row(*row)
    console.print(table)
    console.print()
