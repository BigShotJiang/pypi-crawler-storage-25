"""Client-side tool pre-routing.

Detects tool-invocable requests in natural language and extracts
parameters for direct /v1/tools/call execution. Returns None if
the input is conversational (should go to chat stream instead).

This mirrors Claude Code's approach: parse intent locally, execute
tools directly, only use LLM for genuinely conversational requests.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

import structlog

logger = structlog.get_logger(module="tool_router")


@dataclass
class ToolMatch:
    """A matched tool with extracted parameters."""

    tool_name: str
    arguments: dict[str, Any]
    description: str  # Human-readable description for display


# Patterns: each maps keywords to a tool + parameter extraction function
# Ordered by specificity (most specific first)

def _extract_position_size(text: str) -> dict[str, Any] | None:
    """Extract position sizing parameters from natural language."""
    args: dict[str, Any] = {}

    # Symbol
    sym = re.search(r'\b([A-Z]{1,5})\b', text)
    if sym:
        args["symbol"] = sym.group(1)

    # Equity
    eq = re.search(r'(?:equity|account|portfolio)\s*\$?\s*([\d,]+(?:\.\d+)?)', text, re.I)
    if eq:
        args["equity"] = eq.group(1).replace(",", "")

    # Risk %
    rk = re.search(r'(?:risk)\s*(\d+(?:\.\d+)?)\s*%', text, re.I)
    if rk:
        args["risk_pct"] = rk.group(1)

    # Entry price
    entry = re.search(r'(?:entry|at|price)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if entry:
        args["entry_price"] = entry.group(1)

    # Stop price
    stop = re.search(r'(?:stop|sl)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if stop:
        args["stop_price"] = stop.group(1)

    # Direction
    if re.search(r'\bshort\b', text, re.I):
        args["direction"] = "short"
    elif re.search(r'\blong\b', text, re.I):
        args["direction"] = "long"

    # Need at least symbol + equity to be useful
    if "symbol" in args and "equity" in args:
        return args
    return None


def _extract_risk_check(text: str) -> dict[str, Any] | None:
    """Extract risk check parameters."""
    args: dict[str, Any] = {}

    sym = re.search(r'\b([A-Z]{1,5})\b', text)
    if sym:
        args["symbol"] = sym.group(1)

    entry = re.search(r'(?:entry|at|price)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if entry:
        args["entry_price"] = entry.group(1)

    stop = re.search(r'(?:stop|sl)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if stop:
        args["stop_price"] = stop.group(1)

    eq = re.search(r'(?:equity|account|portfolio)\s*\$?\s*([\d,]+(?:\.\d+)?)', text, re.I)
    if eq:
        args["equity"] = eq.group(1).replace(",", "")

    if re.search(r'\bshort\b', text, re.I):
        args["direction"] = "short"
    else:
        args["direction"] = "long"

    if "symbol" in args and "entry_price" in args and "stop_price" in args:
        return args
    return None


def _extract_pre_trade_gate(text: str) -> dict[str, Any] | None:
    """Extract pre-trade gate parameters."""
    args: dict[str, Any] = {}

    sym = re.search(r'\b([A-Z]{1,5})\b', text)
    if sym:
        args["symbol"] = sym.group(1)

    entry = re.search(r'(?:entry|at|price)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if entry:
        args["entry_price"] = entry.group(1)

    stop = re.search(r'(?:stop|sl)\s*\$?\s*(\d+(?:\.\d+)?)', text, re.I)
    if stop:
        args["stop_price"] = stop.group(1)

    eq = re.search(r'(?:equity|account|portfolio)\s*\$?\s*([\d,]+(?:\.\d+)?)', text, re.I)
    if eq:
        args["equity"] = eq.group(1).replace(",", "")

    if re.search(r'\bshort\b', text, re.I):
        args["direction"] = "short"
    else:
        args["direction"] = "long"

    if "symbol" in args and "entry_price" in args and "stop_price" in args and "equity" in args:
        return args
    return None


# Tool routing table: keyword patterns → (tool_name, extractor, description)
TOOL_PATTERNS: list[tuple[re.Pattern, str, Any, str]] = [
    (
        re.compile(r'\b(?:pre.?trade.?gate|gate|ptg)\b', re.I),
        "pre_trade_gate",
        _extract_pre_trade_gate,
        "Pre-trade gate check",
    ),
    (
        re.compile(r'\b(?:position.?siz|size.?position|how.?many.?shares|size)\b', re.I),
        "calculate_position_size",
        _extract_position_size,
        "Position size calculation",
    ),
    (
        re.compile(r'\b(?:risk.?check|check.?risk|risk.?valid|validate.?risk)\b', re.I),
        "check_trade_risk",
        _extract_risk_check,
        "Risk validation",
    ),
]


def match_tool(user_input: str) -> ToolMatch | None:
    """Try to match user input to a direct tool call.

    Returns a ToolMatch if the input clearly maps to a tool with
    sufficient parameters. Returns None if the input is conversational
    or lacks required parameters (should go to chat stream).

    Args:
        user_input: Raw user message from the chat prompt.

    Returns:
        ToolMatch with tool_name, arguments, and description, or None.
    """
    for pattern, tool_name, extractor, description in TOOL_PATTERNS:
        if pattern.search(user_input):
            args = extractor(user_input)
            if args:
                logger.info(
                    "tool_matched",
                    tool=tool_name,
                    arg_count=len(args),
                )
                return ToolMatch(
                    tool_name=tool_name,
                    arguments=args,
                    description=description,
                )
    return None
