"""Session credit tracking — per-response and per-session cost tracking.

All credit values use Decimal to prevent floating-point accumulation errors
over long trading sessions.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from neo.types import to_decimal

LOW_BALANCE_THRESHOLD = Decimal("50")


@dataclass
class SessionCredits:
    """Track credit usage across a chat session.

    All financial accumulators use Decimal. The summary() method
    returns values suitable for display.

    Attributes:
        total_credits: Accumulated credits used this session.
        tools_called: Number of tool calls observed.
        trades_placed: Number of trade actions executed.
        messages_sent: Number of messages sent.
        start_time: Unix timestamp when session started.
        last_balance: Most recent balance from API.
        low_balance_warned: Whether low balance warning was shown.
    """

    total_credits: Decimal = field(default_factory=lambda: Decimal("0"))
    tools_called: int = 0
    trades_placed: int = 0
    messages_sent: int = 0
    start_time: float = field(default_factory=time.time)
    last_balance: Decimal | None = None
    low_balance_warned: bool = False

    def add_response(
        self,
        credits_used: Decimal | float | None = None,
        balance: Decimal | float | None = None,
        tools: int = 0,
        trade: bool = False,
    ) -> None:
        """Record a response's credit usage.

        Args:
            credits_used: Credits consumed by this response.
            balance: Remaining balance reported by API.
            tools: Number of tools called in this response.
            trade: Whether this response involved a trade action.
        """
        self.messages_sent += 1
        if credits_used is not None:
            self.total_credits += to_decimal(credits_used)
        if balance is not None:
            self.last_balance = to_decimal(balance)
        self.tools_called += tools
        if trade:
            self.trades_placed += 1

    @property
    def duration_minutes(self) -> int:
        """Return session duration in minutes."""
        return int((time.time() - self.start_time) / 60)

    @property
    def is_low_balance(self) -> bool:
        """Check if balance is below the warning threshold.

        Returns:
            True if balance is known and below LOW_BALANCE_THRESHOLD.
        """
        if self.last_balance is None:
            return False
        return self.last_balance < LOW_BALANCE_THRESHOLD

    def summary(self) -> dict[str, Any]:
        """Return a summary dict for display.

        Returns:
            Dict with credits_used, tools_called, trades_placed,
            messages, duration_min, and balance.
        """
        return {
            "credits_used": float(self.total_credits),
            "tools_called": self.tools_called,
            "trades_placed": self.trades_placed,
            "messages": self.messages_sent,
            "duration_min": self.duration_minutes,
            "balance": float(self.last_balance) if self.last_balance is not None else None,
        }
