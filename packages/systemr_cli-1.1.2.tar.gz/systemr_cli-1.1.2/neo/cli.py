"""System R CLI — main entry point.

Shows the home screen when invoked without subcommands.
Initializes the local directory structure on first run.
Checks for updates on launch (non-blocking).
"""

from __future__ import annotations

import click

from neo import __version__
from neo.commands.auth_commands import balance, link_wallet, login, logout, pay, register, verify, whoami
from neo.commands.chat_commands import chat
from neo.commands.cron_commands import cron
from neo.commands.doctor_command import doctor
from neo.commands.eval_commands import eval
from neo.commands.journal_commands import journal
from neo.commands.plan_commands import plan
from neo.commands.risk_commands import risk
from neo.commands.scan_commands import scan
from neo.commands.size_commands import size
from neo.display.theme import (
    WHITE,
    GRAY,
    DIM,
    MUTED,
    GREEN,
    RED,
    ICON_CONNECTED,
    ICON_DISCONNECTED,
    console,
    print_banner,
    print_separator,
)


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="systemr")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """System R — trading operating system in your terminal."""
    ctx.ensure_object(dict)

    # Configure logging (suppress INFO from terminal, only WARN+ to stderr)
    from neo.logging import configure_logging
    configure_logging(debug=False)

    # Initialize local directory on first run
    from neo.profile import init_all
    init_all()

    # Load saved permission profile
    from neo.confirmation import load_profile_from_config
    load_profile_from_config()

    if ctx.invoked_subcommand is None:
        _show_home_and_chat(ctx)


def _show_home_and_chat(ctx: click.Context) -> None:
    """Home screen — if connected, drop straight into chat. Like Claude Code."""
    from neo.auth import AuthManager
    from neo.config import get_api_key

    api_key = get_api_key()
    auth = AuthManager()
    token = auth.get_token()

    if api_key or token:
        # Connected — print banner then drop into chat (chat skips its own banner)
        print_banner()
        console.print(f"  [{GREEN}]● connected[/]")
        ctx.ensure_object(dict)
        ctx.obj["banner_shown"] = True
        ctx.invoke(chat)
    else:
        # Not connected — show setup instructions
        print_banner()
        console.print(
            f"  [{WHITE}]Get started:[/]"
        )
        console.print()
        console.print(
            f"    [{GREEN}]1.[/] [{GRAY}]Get your API key at[/] [{GREEN}]app.systemr.ai[/]"
        )
        console.print(
            f"    [{GREEN}]2.[/] [{GRAY}]Run:[/] [{DIM}]systemr configure --api-key YOUR_KEY[/]"
        )
        console.print(
            f"    [{GREEN}]3.[/] [{GRAY}]Run:[/] [{DIM}]systemr chat[/]"
        )
        console.print()


# ── Command registration ────────────────────────────────────────────

# Auth & Billing
cli.add_command(register)
cli.add_command(login)
cli.add_command(verify)
cli.add_command(pay)
cli.add_command(balance)
cli.add_command(link_wallet)
cli.add_command(logout)
cli.add_command(whoami)

# Trading commands
cli.add_command(size)
cli.add_command(risk)
cli.add_command(eval)
cli.add_command(scan)
cli.add_command(plan)

# Local
cli.add_command(journal)

# Interactive
cli.add_command(chat)

# Automation
cli.add_command(cron)

# Diagnostics
cli.add_command(doctor)


# Configure
@click.command()
@click.option("--api-key", "api_key", default=None, help="API key from app.systemr.ai")
def configure(api_key: str | None) -> None:
    """Configure System R CLI with your API key."""
    from neo.config import load_config, save_config, get_api_key
    from neo.display.theme import print_success, print_info, print_error

    if api_key:
        if not api_key.startswith("sr_agent_"):
            print_error("Invalid API key format. Keys start with sr_agent_")
            raise SystemExit(1)
        config = load_config()
        config["api_key"] = api_key
        save_config(config)
        print_success(f"API key saved. Hint: ...{api_key[-8:]}")
        console.print(f"  [{GRAY}]Run `systemr chat` to start.[/]")
    else:
        existing = get_api_key()
        if existing:
            print_info(f"API key configured: ...{existing[-8:]}")
        else:
            console.print(f"  [{WHITE}]No API key configured.[/]")
            console.print()
            console.print(f"  [{GRAY}]Get your key from[/] [{GREEN}]app.systemr.ai/dashboard[/]")
            console.print(f"  [{GRAY}]Then run:[/] [{DIM}]systemr configure --api-key sr_agent_...[/]")
        console.print()


cli.add_command(configure)


# Setup
@click.command()
def setup() -> None:
    """Run the profile setup wizard."""
    from neo.display.theme import print_success, print_info
    from neo.profile import (
        profile_exists, save_profile, save_rules, save_standing_order, init_all,
    )

    init_all()
    print_banner()

    if profile_exists():
        print_info("Profile already exists. Answers will overwrite it.")

    console.print(f"  [{WHITE}]Welcome. Let's set up your profile.[/]")
    console.print()

    name = click.prompt(click.style("  Your name", fg="white"))
    while not name.strip() or len(name.strip()) < 2:
        print_error("Name must be at least 2 characters.")
        name = click.prompt(click.style("  Your name", fg="white"))

    style = click.prompt(click.style("  Trading style (e.g. momentum, swing, scalp)", fg="white"))
    timeframe = click.prompt(click.style("  Timeframe (e.g. daily, 4h, 1h)", fg="white"))

    risk_pct = click.prompt(
        click.style("  Max risk per trade (%)", fg="white"),
        type=click.FloatRange(0.1, 10.0),
        default=1.0,
    )
    daily_loss = click.prompt(
        click.style("  Max daily loss (%)", fg="white"),
        type=click.FloatRange(0.5, 20.0),
        default=3.0,
    )
    max_pos = click.prompt(
        click.style("  Max open positions", fg="white"),
        type=click.IntRange(1, 100),
        default=5,
    )
    broker = click.prompt(click.style("  Primary broker", fg="white"))

    console.print()
    console.print(f"  [{GRAY}]Any hard rules? (comma-separated, or Enter to skip)[/]")
    rules_input = click.prompt(
        click.style("  Rules", fg="white"), default="", show_default=False,
    )
    hard_rules = [r.strip() for r in rules_input.split(",") if r.strip()]

    experience = click.prompt(
        click.style("  Experience level", fg="white"),
        type=click.Choice(["beginner", "intermediate", "advanced"]),
    )

    console.print()
    print_separator()
    console.print()

    save_profile(
        name=name, style=style, timeframe=timeframe,
        experience=experience, risk_pct=risk_pct,
        daily_loss_pct=daily_loss, max_positions=max_pos, broker=broker,
    )
    print_success("Profile saved to ~/.systemr/PROFILE.md")

    if hard_rules:
        save_rules(hard_rules=hard_rules, soft_rules=[])
        print_success("Rules saved to ~/.systemr/RULES.md")

    # Standing orders (optional)
    console.print()
    console.print(f"  [{GRAY}]Standing orders give your agent authority to act within boundaries.[/]")
    console.print(f"  [{DIM}]Example: 'Every morning, scan watchlist for setups. Report only, no trades.'[/]")
    add_orders = click.confirm(
        click.style("  Add a standing order?", fg="white"), default=False,
    )
    if add_orders:
        order_name = click.prompt(click.style("  Order name", fg="white"))
        order_action = click.prompt(click.style("  What should it do?", fg="white"))
        order_trigger = click.prompt(
            click.style("  When? (e.g., 'Daily at 7AM', 'On trade close')", fg="white"),
        )
        save_standing_order(
            name=order_name,
            scope=order_action,
            trigger=order_trigger,
            approval="Report only — do NOT execute trades without confirmation",
            escalation="Alert if unable to complete",
            action=order_action,
        )
        print_success(f"Standing order '{order_name}' saved to RULES.md")

    console.print()
    console.print(
        f"  [{WHITE}]You're ready. Run `systemr chat` to start.[/]"
    )
    console.print()


cli.add_command(setup)
