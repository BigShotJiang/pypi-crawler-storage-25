"""NeoClient — async HTTP client with session auth and auto-refresh."""

from __future__ import annotations

from typing import Any

import httpx

from neo.auth import AuthManager
from neo.config import get_api_key, get_api_url


class NeoClient:
    """Authenticated async HTTP client for System R API."""

    def __init__(self, auth: AuthManager) -> None:
        self._auth = auth
        self._base_url = get_api_url()

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        """Make an authenticated API request. Retries once on 401."""
        headers = self._auth_headers()
        async with httpx.AsyncClient(base_url=self._base_url) as client:
            resp = await client.request(
                method, path, json=json, params=params, headers=headers, timeout=timeout,
            )
            # Auto-refresh on 401
            if resp.status_code == 401:
                token = self._auth.get_token()
                if token is None:
                    raise AuthRequired()
                headers = self._auth_headers()
                resp = await client.request(
                    method, path, json=json, params=params, headers=headers, timeout=timeout,
                )
            resp.raise_for_status()
            return resp.json()

    async def get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return await self.request("POST", path, **kwargs)

    def _auth_headers(self) -> dict[str, str]:
        # API key takes precedence (from app.systemr.ai dashboard)
        api_key = get_api_key()
        if api_key:
            return {"X-API-Key": api_key}
        # Fall back to session token (from systemr login)
        token = self._auth.get_token()
        if token is None:
            raise AuthRequired()
        return {"Authorization": f"Bearer {token.access_token}"}


class AuthRequired(Exception):
    """Raised when a request requires auth but no valid token exists."""

    def __init__(self) -> None:
        super().__init__("Not authenticated. Run `systemr login` first.")
