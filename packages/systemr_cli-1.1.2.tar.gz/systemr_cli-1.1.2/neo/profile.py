"""Trader profile, rules, and memory management.

Implements the Claude Code memory pattern for trading:
- PROFILE.md: trader identity, risk params, broker (auto-loaded every session)
- RULES.md: hard/soft trading rules (auto-enforced by risk engine)
- memory/MEMORY.md: index + individual memory files (lessons, notes)

All financial values in profiles use string representation to avoid
float contamination — they are parsed to Decimal by consumers.
"""

from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
from typing import Optional

import structlog

from neo.config import (
    PROFILE_FILE,
    RULES_FILE,
    MEMORY_DIR,
    MEMORY_INDEX,
    ensure_systemr_home,
)

logger = structlog.get_logger(module="profile")

# ── Templates ───────────────────────────────────────────────────────

DEFAULT_PROFILE = """\
# Trader Profile

## Identity
- Name: {name}
- Style: {style}
- Timeframe: {timeframe}
- Experience: {experience}

## Risk Parameters
- Max risk per trade: {risk_pct}%
- Max daily loss: {daily_loss_pct}%
- Max open positions: {max_positions}
- Max sector exposure: 30%

## Broker
- Primary: {broker}

## Preferences
- Default model: (auto — best available)
- Research mode: on
- Thinking display: visible
"""

DEFAULT_RULES = """\
# Trading Rules

## Hard Rules (NEVER override — System R will refuse violations)
{hard_rules}

## Soft Rules (warn but allow override)
{soft_rules}
"""

DEFAULT_MEMORY_INDEX = """\
# Trading Memory

<!-- System R auto-manages this index. Each entry links to a memory file. -->
"""


# ── Read operations ─────────────────────────────────────────────────

def profile_exists() -> bool:
    """Check if a trader profile has been created.

    Returns:
        True if PROFILE.md exists.
    """
    return PROFILE_FILE.exists()


def load_profile() -> str:
    """Load the trader profile as a string for LLM context injection.

    Returns:
        PROFILE.md content, or empty string if not found.
    """
    if not PROFILE_FILE.exists():
        return ""
    return PROFILE_FILE.read_text()


def load_rules() -> str:
    """Load trading rules as a string for LLM context injection.

    Returns:
        RULES.md content, or empty string if not found.
    """
    if not RULES_FILE.exists():
        return ""
    return RULES_FILE.read_text()


def load_memory_index() -> str:
    """Load the memory index for LLM context injection.

    Returns:
        MEMORY.md content, or empty string if not found.
    """
    if not MEMORY_INDEX.exists():
        return ""
    return MEMORY_INDEX.read_text()


# ── Write operations ────────────────────────────────────────────────

def save_profile(
    name: str,
    style: str,
    timeframe: str,
    experience: str,
    risk_pct: str,
    daily_loss_pct: str,
    max_positions: int,
    broker: str,
) -> Path:
    """Create the trader profile from onboarding answers.

    Risk values are stored as strings to avoid float contamination.
    Consumers parse them to Decimal when needed.

    Args:
        name: Trader's name.
        style: Trading style description.
        timeframe: Typical holding period.
        experience: Skill level.
        risk_pct: Max risk per trade as string (e.g., "2").
        daily_loss_pct: Max daily loss as string (e.g., "5").
        max_positions: Max concurrent positions.
        broker: Primary broker name.

    Returns:
        Path to the created PROFILE.md.
    """
    ensure_systemr_home()
    content = DEFAULT_PROFILE.format(
        name=name,
        style=style,
        timeframe=timeframe,
        experience=experience,
        risk_pct=risk_pct,
        daily_loss_pct=daily_loss_pct,
        max_positions=max_positions,
        broker=broker,
    )
    PROFILE_FILE.write_text(content)
    logger.info("profile_saved", path=str(PROFILE_FILE))
    return PROFILE_FILE


def save_rules(hard_rules: list[str], soft_rules: list[str]) -> Path:
    """Create the trading rules file.

    Args:
        hard_rules: List of hard rules (never overridable).
        soft_rules: List of soft rules (warn but allow override).

    Returns:
        Path to the created RULES.md.
    """
    ensure_systemr_home()
    hard = "\n".join(f"- {r}" for r in hard_rules) if hard_rules else "- (none set)"
    soft = "\n".join(f"- {r}" for r in soft_rules) if soft_rules else "- (none set)"
    content = DEFAULT_RULES.format(hard_rules=hard, soft_rules=soft)
    RULES_FILE.write_text(content)
    logger.info("rules_saved", path=str(RULES_FILE), hard=len(hard_rules), soft=len(soft_rules))
    return RULES_FILE


def init_memory() -> Path:
    """Initialize the memory directory and index file.

    Returns:
        Path to the MEMORY.md index file.
    """
    ensure_systemr_home()
    if not MEMORY_INDEX.exists():
        MEMORY_INDEX.write_text(DEFAULT_MEMORY_INDEX)
        logger.info("memory_initialized", path=str(MEMORY_INDEX))
    return MEMORY_INDEX


def save_memory(filename: str, content: str, description: str) -> Path:
    """Save a memory file and update the index.

    Args:
        filename: Name of the memory file (e.g., "tsla_notes.md").
        content: Full markdown content of the memory.
        description: One-line description for the index entry.

    Returns:
        Path to the saved memory file.
    """
    ensure_systemr_home()
    filepath = MEMORY_DIR / filename
    filepath.write_text(content)

    # Append to index if not already there
    index_text = MEMORY_INDEX.read_text() if MEMORY_INDEX.exists() else DEFAULT_MEMORY_INDEX
    if filename not in index_text:
        entry = f"- [{description}]({filename})\n"
        index_text += entry
        MEMORY_INDEX.write_text(index_text)

    logger.info("memory_saved", filename=filename, description=description[:50])
    return filepath


def init_all() -> None:
    """Initialize the full ~/.systemr/ directory structure.

    Creates SYSTEMR_HOME, memory/, sessions/, and MEMORY.md index.
    """
    ensure_systemr_home()
    init_memory()


# ── Auto-memory triggers ────────────────────────────────────────────

# ── Standing orders ────────────────────────────────────────────────

STANDING_ORDER_TEMPLATE = """\
### {name}
- **Scope**: {scope}
- **Trigger**: {trigger}
- **Approval**: {approval}
- **Escalation**: {escalation}
- **Action**: {action}
"""


def load_standing_orders() -> str:
    """Load standing orders from RULES.md.

    Standing orders are sections in RULES.md under '## Standing Orders'.
    They define programs the agent can execute autonomously within boundaries.

    Returns:
        Standing orders text, or empty string if none defined.
    """
    rules = load_rules()
    if not rules:
        return ""

    # Extract standing orders section
    marker = "## Standing Orders"
    if marker not in rules:
        return ""

    idx = rules.index(marker)
    return rules[idx:]


def save_standing_order(
    name: str,
    scope: str,
    trigger: str,
    approval: str,
    escalation: str,
    action: str,
) -> None:
    """Append a standing order to RULES.md.

    Args:
        name: Order name (e.g., "Morning Scan").
        scope: What the agent is authorized to do.
        trigger: When it fires (schedule, event, condition).
        approval: What requires human sign-off.
        escalation: When to ask for help.
        action: What to execute.
    """
    ensure_systemr_home()
    if not RULES_FILE.exists():
        RULES_FILE.write_text("# Trading Rules\n\n## Standing Orders\n")

    content = RULES_FILE.read_text()
    if "## Standing Orders" not in content:
        content += "\n\n## Standing Orders\n"

    order = STANDING_ORDER_TEMPLATE.format(
        name=name, scope=scope, trigger=trigger,
        approval=approval, escalation=escalation, action=action,
    )
    content += "\n" + order
    RULES_FILE.write_text(content)
    logger.info("standing_order_saved", name=name, trigger=trigger)


# ── Daily trading log ──────────────────────────────────────────────

def _daily_log_path(for_date: Optional[date] = None) -> Path:
    """Return path for a daily trading log file.

    Args:
        for_date: Date for the log. Defaults to today.

    Returns:
        Path to ~/.systemr/memory/YYYY-MM-DD.md
    """
    d = for_date or date.today()
    return MEMORY_DIR / f"{d.isoformat()}.md"


def append_daily_log(entry: str, category: str = "note") -> Path:
    """Append an entry to today's daily trading log.

    Creates the file if it doesn't exist. Each entry is timestamped
    and categorized for easy scanning.

    Args:
        entry: The text to log.
        category: Entry category (trade, violation, lesson, note, flush).

    Returns:
        Path to the daily log file.
    """
    ensure_systemr_home()
    filepath = _daily_log_path()
    now = datetime.now()

    if not filepath.exists():
        header = f"# Trading Log — {date.today().isoformat()}\n\n"
        filepath.write_text(header)

    line = f"- **{now.strftime('%H:%M')}** [{category}] {entry}\n"
    with open(filepath, "a") as f:
        f.write(line)

    logger.info("daily_log_appended", category=category, entry=entry[:50])
    return filepath


def load_daily_context() -> str:
    """Load today's and yesterday's daily logs for LLM context injection.

    Matches the OpenClaw pattern: load current + previous day to give
    the model awareness of recent trading activity.

    Returns:
        Combined log content, or empty string if no logs exist.
    """
    from datetime import timedelta
    parts = []

    today = date.today()
    yesterday = today - timedelta(days=1)

    for d in (yesterday, today):
        filepath = _daily_log_path(d)
        if filepath.exists():
            parts.append(filepath.read_text())

    return "\n".join(parts)


def search_memory(query: str, max_results: int = 10) -> list[dict[str, str]]:
    """Search across all memory files for matching text.

    Simple case-insensitive text search over ~/.systemr/memory/*.md.
    Returns matching lines with file context.

    Args:
        query: Search text.
        max_results: Maximum results to return.

    Returns:
        List of dicts with 'file', 'line', 'content' keys.
    """
    if not MEMORY_DIR.exists():
        return []

    query_lower = query.lower()
    results: list[dict[str, str]] = []

    for filepath in sorted(MEMORY_DIR.glob("*.md"), reverse=True):
        try:
            text = filepath.read_text()
            for i, line in enumerate(text.splitlines(), 1):
                if query_lower in line.lower():
                    results.append({
                        "file": filepath.name,
                        "line": str(i),
                        "content": line.strip(),
                    })
                    if len(results) >= max_results:
                        return results
        except Exception:
            continue

    return results


# ── Auto-memory triggers ────────────────────────────────────────────

def auto_save_trade_lesson(
    symbol: str,
    r_multiple: str,
    direction: str,
    entry: str,
    exit_price: str,
    notes: str = "",
) -> Path | None:
    """Auto-save a memory after a significant losing trade.

    Only saves for losses where R < -1.0 to avoid memory bloat.
    All financial values accepted as strings (Decimal-safe).

    Args:
        symbol: Ticker symbol.
        r_multiple: R-multiple as string (e.g., "-2.30").
        direction: "long" or "short".
        entry: Entry price as string.
        exit_price: Exit price as string.
        notes: Optional notes about the trade.

    Returns:
        Path to saved memory file, or None if R >= -1.0.
    """
    from decimal import Decimal
    r_val = Decimal(str(r_multiple))
    if r_val >= Decimal("-1"):
        return None

    today = date.today().isoformat()
    filename = f"lesson_{symbol.lower()}_{today}.md"
    content = (
        f"# Trade Lesson — {symbol.upper()} ({today})\n\n"
        f"- Direction: {direction}\n"
        f"- Entry: ${entry}\n"
        f"- Exit: ${exit_price}\n"
        f"- R-Multiple: {r_multiple}R\n"
        f"\n## What happened\n{notes or '(no notes)'}\n"
        f"\n## Lesson\nReview this trade. What could have been done differently?\n"
    )
    logger.info("auto_save_trade_lesson", symbol=symbol, r_multiple=r_multiple)
    append_daily_log(
        f"{symbol} {direction} {r_multiple}R — entry ${entry} exit ${exit_price}",
        category="lesson",
    )
    return save_memory(filename, content, f"{symbol} loss {r_multiple}R — {today}")


def auto_save_rule_violation(rule: str, action_attempted: str) -> Path:
    """Auto-save when System R blocks a rule violation.

    Args:
        rule: The rule that was violated.
        action_attempted: Description of what was blocked.

    Returns:
        Path to the saved memory file.
    """
    today = date.today().isoformat()
    filename = f"blocked_{today}.md"

    filepath = MEMORY_DIR / filename
    if filepath.exists():
        existing = filepath.read_text()
        existing += f"\n- **{action_attempted}** blocked by: {rule}\n"
        filepath.write_text(existing)
    else:
        content = (
            f"# Rule Violations Blocked — {today}\n\n"
            f"- **{action_attempted}** blocked by: {rule}\n"
        )
        save_memory(filename, content, f"Blocked violations — {today}")

    logger.info("auto_save_rule_violation", rule=rule, action=action_attempted)
    append_daily_log(f"BLOCKED: {action_attempted} — {rule}", category="violation")
    return filepath


def auto_save_explicit(user_text: str, context: str = "") -> Path:
    """Save when trader says 'remember this' — explicit memory request.

    Args:
        user_text: What the trader wants remembered.
        context: Optional conversation context.

    Returns:
        Path to the saved memory file.
    """
    now = datetime.now()
    filename = f"note_{now.strftime('%Y%m%d_%H%M%S')}.md"
    content = (
        f"# Note — {now.strftime('%Y-%m-%d %H:%M')}\n\n"
        f"{user_text}\n"
    )
    if context:
        content += f"\n## Context\n{context}\n"

    logger.info("auto_save_explicit", text=user_text[:50])
    return save_memory(filename, content, user_text[:60])
