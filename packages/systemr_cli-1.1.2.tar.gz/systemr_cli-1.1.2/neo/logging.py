"""Structured logging for System R CLI.

All production logging goes through structlog. The Rich console
is used for user-facing display only — not for logging.

Usage:
    from neo.logging import get_logger
    logger = get_logger()
    logger.info("trade_executed", symbol="TSLA", shares=160)
"""

from __future__ import annotations

import logging
import sys

import structlog


def configure_logging(*, debug: bool = False) -> None:
    """Configure structlog for the CLI.

    In production mode (debug=False), logs go to stderr at WARNING level
    to keep stdout clean for the user. In debug mode, logs go to stderr
    at DEBUG level with full console rendering.

    Args:
        debug: If True, log at DEBUG level with full tracebacks.
               If False, log at WARNING level, JSON format, stderr only.
    """
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.dev.ConsoleRenderer() if debug else structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.DEBUG if debug else logging.WARNING,
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(**initial_context: str) -> structlog.stdlib.BoundLogger:
    """Get a bound structlog logger.

    Args:
        **initial_context: Key-value pairs to bind to every log entry.

    Returns:
        A bound structlog logger instance.
    """
    return structlog.get_logger(**initial_context)
