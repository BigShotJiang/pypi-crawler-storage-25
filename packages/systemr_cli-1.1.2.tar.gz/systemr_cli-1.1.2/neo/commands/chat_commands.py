"""Chat command — interactive streaming conversation with System R.

Integrates: streaming, credits, confirmation protocol, hooks,
profile context, session resume, context compaction.

All financial values use Decimal. Logging via structlog.
No bare print() — user display via Rich console.
"""

from __future__ import annotations

import asyncio
import json

import click
import httpx
import structlog
from prompt_toolkit import PromptSession
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.history import FileHistory

from neo.auth import AuthManager
from neo.config import SYSTEMR_HOME, SESSIONS_DIR, ensure_systemr_home
from neo.confirmation import (
    PERMISSION_PROFILES,
    PermissionLevel,
    get_active_profile,
    get_permission_level,
    set_active_profile,
)
from neo.credits import SessionCredits
from neo.display.chat_renderer import (
    render_assistant_message,
    render_action,
    render_credits,
    render_error,
    render_thinking,
    render_user_message,
)
from neo.display.theme import (
    AMBER,
    DIM,
    GRAY,
    GREEN,
    GREEN_DIM,
    MUTED,
    WHITE,
    ICON_ERROR,
    ICON_SUCCESS,
    ICON_THINKING,
    console,
    print_banner,
    print_error,
    print_info,
    print_separator,
    print_success,
)
from neo.hooks import HookEvent, fire_hook
from neo.profile import (
    append_daily_log,
    auto_save_explicit,
    auto_save_rule_violation,
    load_daily_context,
    load_profile,
    load_rules,
    load_standing_orders,
    profile_exists,
    search_memory,
)
from neo.model_failover import FailoverChain, load_failover_chain
from neo.store import LocalStore
from neo.tool_router import match_tool
from neo.streaming import (
    ChatRequest,
    SSEEvent,
    call_tool,
    chat_blocking,
    send_confirmation,
    stream_chat,
)

logger = structlog.get_logger(module="chat")

# Context compaction settings
COMPACTION_THRESHOLD: int = 30
COMPACTION_KEEP_RECENT: int = 10

# Valid model names accepted by the backend
VALID_MODELS = [
    "claude-opus-4-6", "claude-sonnet-4-6",
    "claude-opus-4-5", "claude-sonnet-4-5",
    "claude-haiku-4-5", "claude-sonnet-4",
    "gpt-5.2", "gpt-5.1", "gpt-4.1",
    "gpt-4.1-mini", "gpt-4.1-nano",
    "gpt-4o", "gpt-4o-mini",
    "o4-mini", "o3", "o3-mini",
]

# Slash commands handled locally
LOCAL_COMMANDS: dict[str, str] = {
    "/help": "Show available commands",
    "/morning": "Morning briefing (4 parallel agents)",
    "/eod": "End of day review + journal",
    "/plan": "Plan today's trades",
    "/portfolio": "Show open positions",
    "/risk": "Show risk dashboard",
    "/credits": "Show session credit usage",
    "/remember": "Save a memory (e.g., /remember TSLA support at $192)",
    "/clear": "Clear conversation history",
    "/model": "Show or switch model",
    "/fast": "Switch to fast model (Haiku)",
    "/deep": "Switch to deep model (Opus)",
    "/profile": "Show trader profile",
    "/rules": "Show trading rules",
    "/memory": "Search memory (e.g., /memory TSLA)",
    "/permissions": "View or switch safety profile (paper/standard/experienced)",
    "/sessions": "List recent chat sessions",
    "/cron": "Manage scheduled tasks (add/list/remove)",
    "/q": "Exit",
}


async def _pipe_mode(token, user_input: str, model_name: str | None, research: bool, json_output: bool) -> None:
    """Non-interactive: send one message, collect full response, print, exit."""
    from neo.streaming import ChatRequest, stream_chat

    profile_text = load_profile() if profile_exists() else None
    rules_text = load_rules()

    request = ChatRequest(
        user_input=user_input,
        model=model_name,
        research_mode=research,
        profile=profile_text,
        rules=rules_text,
    )

    text_parts: list[str] = []
    tools_used: list[str] = []

    async for event in stream_chat(token.access_token, request):
        if event.event == "text_delta" and event.data:
            text_parts.append(event.data.get("text", ""))
        elif event.event == "action" and event.data:
            tools_used.append(event.data.get("tool", ""))

    full_text = "".join(text_parts)

    if json_output:
        import json as _json
        print(_json.dumps({
            "response": full_text,
            "tools_used": tools_used,
            "model": model_name,
        }))
    else:
        print(full_text)


@click.command()
@click.option("--model", "model_name", default=None, help="LLM model to use")
@click.option("--research", is_flag=True, default=False, help="Enable research mode")
@click.option(
    "--continue-session", "resume", is_flag=True, default=False,
    help="Resume last session",
)
@click.option("--pipe", "pipe_input", default=None, help="Non-interactive: send one message, print response, exit")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output as JSON (use with --pipe)")
@click.pass_context
def chat(ctx: click.Context, model_name: str | None, research: bool, resume: bool, pipe_input: str | None, json_output: bool) -> None:
    """Start an interactive chat session with System R."""
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not authenticated. Run `systemr login` first.")
        raise SystemExit(1)

    if pipe_input is not None:
        asyncio.run(_pipe_mode(token, pipe_input, model_name, research, json_output))
        return

    # Profile is optional — don't show warning, it just enriches context

    ensure_systemr_home()
    store = LocalStore()

    # Auto-prune old sessions (>30 days, silent, once per session start)
    try:
        pruned = store.prune_sessions(days=30)
        if pruned:
            logger.info("sessions_auto_pruned", count=pruned)
    except Exception:
        pass

    # Session resume or new
    messages: list[dict[str, str]] = []
    if resume:
        messages, db_session_id = _try_resume_session(store)
        if messages:
            print_info(f"Resumed session with {len(messages)} messages.")
        else:
            db_session_id = store.create_chat_session()
    else:
        db_session_id = store.create_chat_session()

    from neo.config import get_api_key
    from neo.display.theme import print_prompt_bar

    # Only print banner if not already shown by _show_home_and_chat
    banner_shown = (ctx.obj or {}).get("banner_shown", False)
    if not banner_shown:
        print_banner()
        console.print(f"  [{GREEN}]● connected[/]")

    # Session state
    failover = load_failover_chain()
    if model_name:
        failover.pinned_model = model_name
    current_model = model_name
    credits = SessionCredits()
    history_file = SYSTEMR_HOME / "chat_history"
    loop = asyncio.new_event_loop()

    prompt_session: PromptSession[str] = PromptSession(
        history=FileHistory(str(history_file)),
        auto_suggest=AutoSuggestFromHistory(),
    )

    # Broker state (will be dynamic when broker connection is implemented)
    connected_broker: str | None = None
    display_model = current_model or "sonnet"

    # Fire session start hook
    fire_hook(HookEvent.PRE_SESSION, context={"model": model_name})
    logger.info("session_started", model=model_name, resume=resume)

    try:
        while True:
            # Status bar as prompt_toolkit bottom_toolbar (visible while typing)
            def _toolbar():
                broker_str = (
                    f"● {connected_broker}" if connected_broker
                    else "○ broker not connected"
                )
                return f" ● {display_model}  │  {broker_str}  │  /help commands"

            print_separator()
            try:
                user_input = prompt_session.prompt(
                    "  ❯ ",
                    bottom_toolbar=_toolbar,
                ).strip()
            except (EOFError, KeyboardInterrupt):
                console.print()
                console.print(f"  [{DIM}]Session closed.[/]")
                break

            if not user_input:
                continue

            # Handle slash commands
            if user_input.startswith("/"):
                result = _handle_slash_command(
                    user_input, messages, current_model,
                    access_token=token.access_token, credits=credits,
                )
                if result == "exit":
                    console.print(f"\n  [{GREEN_DIM}]Session closed.[/]")
                    break
                if result == "clear":
                    messages.clear()
                    print_success("Conversation cleared.")
                    continue
                if result is not None:
                    if result.startswith("model:"):
                        current_model = result.split(":", 1)[1]
                        failover.pinned_model = current_model
                        print_success(f"Model: {current_model}")
                    continue

            store.add_chat_message(db_session_id, "user", user_input)
            messages.append({"role": "user", "content": user_input})

            # Tool pre-routing: detect tool-invocable requests and execute directly
            tool_match = match_tool(user_input)
            if tool_match:
                render_action(tool_match.tool_name, status="running", result="")
                try:
                    tool_result = loop.run_until_complete(
                        call_tool(tool_match.tool_name, tool_match.arguments)
                    )
                    result_data = tool_result.get("result", {})
                    cost = tool_result.get("cost_usdc") or (
                        result_data.get("cost_usdc", "") if isinstance(result_data, dict) else ""
                    )
                    render_action(
                        tool_match.tool_name, status="done",
                        result=f"${cost}" if cost else "done",
                    )

                    # Display results
                    if isinstance(result_data, dict):
                        display_items: list[str] = []
                        for k, v in result_data.items():
                            if k in ("cost_usdc",):
                                continue
                            if v is not None and str(v).strip():
                                display_items.append(f"  [{GRAY}]{k}:[/] [{WHITE}]{v}[/]")
                        if display_items:
                            console.print()
                            for item in display_items[:15]:
                                console.print(item)
                            console.print()

                    credits.add_response(credits_used=cost, tools=1)
                    reply = f"Tool {tool_match.tool_name} executed. Result: {json.dumps(result_data)[:200]}"
                    store.add_chat_message(db_session_id, "assistant", reply)
                    messages.append({"role": "assistant", "content": reply})

                except Exception as tool_err:
                    err_msg = str(tool_err)
                    if "402" in err_msg:
                        render_error("Insufficient credits. Run `systemr pay` to add credits.")
                    elif "401" in err_msg or "403" in err_msg:
                        render_error("Auth required. Run `systemr configure --api-key`.")
                    else:
                        render_error(f"Tool failed: {err_msg[:80]}")
                    reply = ""

                continue  # Skip chat stream — tool handled it

            # Compact if over threshold
            if len(messages) > COMPACTION_THRESHOLD:
                messages = _compact_history(messages)
                logger.info("context_compacted", messages=len(messages))

            # Build request with profile + rules + standing orders + daily context
            # Only send model if user explicitly chose one (via --model or /model)
            # Backend handles default model selection via REASONING_MODEL env var
            effective_model = current_model  # None = let backend decide
            rules_text = load_rules() or ""
            standing = load_standing_orders()
            if standing and standing not in rules_text:
                rules_text = rules_text + "\n\n" + standing if rules_text else standing
            request = ChatRequest(
                user_input=user_input,
                session_id=str(db_session_id),
                model=effective_model,
                history=messages,
                profile=load_profile() or None,
                rules=rules_text or None,
                daily_context=load_daily_context() or None,
                research_mode=research,
            )

            try:
                reply = loop.run_until_complete(
                    _do_chat(request, token.access_token, credits)
                )
            except Exception as exc:
                # On failure, retry once with no model override (let backend decide)
                if effective_model:
                    logger.info("model_failover_retry", from_model=effective_model)
                    request.model = None
                    try:
                        reply = loop.run_until_complete(
                            _do_chat(request, token.access_token, credits)
                        )
                    except Exception as exc2:
                        render_error("Something went wrong. Try again or run `systemr doctor`.")
                        logger.error("chat_failover_error", error=str(exc2))
                        fire_hook(HookEvent.ERROR, context={"message": str(exc2)})
                        reply = ""
                else:
                    render_error("Something went wrong. Try again or run `systemr doctor`.")
                    logger.error("chat_error", error=str(exc))
                    fire_hook(HookEvent.ERROR, context={"message": str(exc)})
                    reply = ""

            if reply:
                store.add_chat_message(db_session_id, "assistant", reply)
                messages.append({"role": "assistant", "content": reply})

    finally:
        loop.close()
        _save_session(db_session_id, messages)
        fire_hook(HookEvent.POST_SESSION, context=credits.summary())
        logger.info("session_ended", **credits.summary())

        # Show session summary if there was activity
        if credits.messages_sent > 0:
            console.print()
            console.print(f"  [{GRAY}]Session summary[/]")
            s = credits.summary()
            console.print(f"    [{WHITE}]{s['credits_used']:.1f}[/] [{DIM}]credits[/]   "  # type: ignore[str-format]
                          f"[{WHITE}]{s['tools_called']}[/] [{DIM}]tools[/]   "
                          f"[{WHITE}]{s['duration_min']}m[/] [{DIM}]duration[/]")
            console.print()


async def _do_chat(
    request: ChatRequest,
    access_token: str,
    credits: SessionCredits,
) -> str:
    """Execute chat with streaming. Falls back to blocking on failure.

    Handles SSE events: thinking, action, confirmation_required,
    text_delta, done, error. Fires hooks on trade and error events.

    Args:
        request: The chat request payload.
        access_token: Bearer token.
        credits: Session credit tracker.

    Returns:
        The collected assistant response text.
    """
    collected_text = ""
    tool_count = 0
    has_trade = False

    try:
        async for event in stream_chat(request, access_token):
            if event.event == "thinking":
                text = event.parsed.get("text", event.parsed.get("content", ""))
                if text:
                    render_thinking(text[:80])

            elif event.event == "action":
                tool = event.parsed.get("action", event.parsed.get("tool", event.parsed.get("name", "")))
                params = event.parsed.get("parameters", event.parsed.get("args", {}))
                tool_count += 1

                # Fire BEFORE_TOOL_CALL hook — can inspect/log tool calls
                if tool:
                    fire_hook(HookEvent.BEFORE_TOOL_CALL, context={
                        "tool": tool, "args": params,
                    })
                    render_action(tool, status="running", result="")

                # Auto-execute the tool via /v1/tools/call
                if tool and params:
                    try:
                        tool_result = await call_tool(tool, params)
                        result_data = tool_result.get("result", {})
                        cost = tool_result.get("cost_usdc") or result_data.get("cost_usdc", "")
                        render_action(tool, status="done", result=f"${cost}" if cost else "done")

                        # Display key results
                        if isinstance(result_data, dict):
                            display_items: list[str] = []
                            for k, v in result_data.items():
                                if k in ("cost_usdc",):
                                    continue
                                if v is not None and str(v).strip():
                                    display_items.append(f"  [{GRAY}]{k}:[/] [{WHITE}]{v}[/]")
                            if display_items:
                                console.print()
                                for item in display_items[:12]:
                                    console.print(item)
                                console.print()

                        # Track balance from tool response
                        tool_balance = tool_result.get("balance")
                        if tool_balance is not None:
                            credits.add_response(
                                credits_used=cost, balance=tool_balance, tools=0,
                            )

                    except Exception as tool_err:
                        err_msg = str(tool_err)
                        if "402" in err_msg:
                            render_action(tool, status="error", result="insufficient credits")
                        elif "401" in err_msg or "403" in err_msg:
                            render_action(tool, status="error", result="auth required — run systemr configure --api-key")
                        else:
                            render_action(tool, status="error", result=str(tool_err)[:60])
                elif tool:
                    render_action(tool, status="done", result="")

                if tool in (
                    "place_order", "cancel_order", "modify_order",
                    "close_position", "kill_switch", "close_all_positions",
                ):
                    has_trade = True

            elif event.event == "confirmation_required":
                approved = await _handle_confirmation(event, access_token)
                if approved:
                    fire_hook(HookEvent.PRE_TRADE, context=event.parsed)
                else:
                    tool = event.parsed.get("tool", "unknown")
                    auto_save_rule_violation(
                        rule="User denied confirmation",
                        action_attempted=f"{tool}: {event.parsed.get('description', '')}",
                    )
                    fire_hook(HookEvent.RULE_VIOLATION, context={
                        "tool": tool, "reason": "user_denied",
                    })

            elif event.event == "text_delta":
                text = event.parsed.get("text", event.parsed.get("delta", event.data))
                if text and text != "null":
                    collected_text += text

            elif event.event == "done":
                if collected_text.strip():
                    render_assistant_message(collected_text.strip())
                else:
                    full = event.parsed.get(
                        "response", event.parsed.get("content", ""),
                    )
                    if full:
                        collected_text = full
                        render_assistant_message(full)

                credits_used = event.parsed.get("credits_used")
                balance = event.parsed.get("balance")
                credits.add_response(
                    credits_used=credits_used, balance=balance,
                    tools=tool_count, trade=has_trade,
                )
                render_credits(credits_used, balance)

                if has_trade:
                    append_daily_log(
                        collected_text.strip()[:120] if collected_text else "Trade executed",
                        category="trade",
                    )
                    fire_hook(HookEvent.POST_TRADE, context={"credits_used": credits_used})
                if credits.is_low_balance and not credits.low_balance_warned:
                    credits.low_balance_warned = True
                    console.print(
                        f"\n  [{AMBER}]! Credits low: "
                        f"{float(credits.last_balance):.1f} OSR. "  # type: ignore[arg-type]
                        f"Top up at systemr.ai/credits[/]"
                    )
                    fire_hook(HookEvent.LOW_BALANCE, context={
                        "balance": float(credits.last_balance),  # type: ignore[arg-type]
                    })

            elif event.event == "error":
                raw = event.parsed.get("message", event.parsed.get("error", event.data))
                msg = str(raw)
                # Simplify common backend errors for users
                if "Classification backend unavailable" in msg:
                    msg = "AI model temporarily unavailable. Try again in a moment."
                elif "AccessDeniedException" in msg:
                    msg = "AI model access error. Contact support."
                elif "ThrottlingException" in msg:
                    msg = "Rate limited by AI provider. Wait a moment and try again."
                elif len(msg) > 120:
                    msg = msg[:120] + "..."
                render_error(msg)
                fire_hook(HookEvent.ERROR, context={"message": msg})

    except httpx.ConnectError:
        render_error("Cannot connect to System R. Check your internet connection.")
        fire_hook(HookEvent.ERROR, context={"message": "connection_failed"})
    except httpx.ReadTimeout:
        render_error("Response timed out. Try again or use a simpler query.")
        fire_hook(HookEvent.ERROR, context={"message": "read_timeout"})
    except Exception:
        # Fall back to blocking
        try:
            result = await chat_blocking(request, access_token)
            reply = result.get("response", result.get("content", result.get("message", "")))
            if reply:
                collected_text = reply
                render_assistant_message(reply)
                credits.add_response(tools=1)
        except httpx.ConnectError:
            render_error("Cannot connect to System R. Check your internet connection.")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 401:
                render_error("Session expired. Run `systemr login` or `systemr configure --api-key`.")
            elif exc.response.status_code == 402:
                render_error("Insufficient credits. Run `systemr pay` to add credits.")
            elif exc.response.status_code == 429:
                render_error("Rate limited. Wait a moment and try again.")
            else:
                render_error(f"Server error ({exc.response.status_code}). Try again.")
        except Exception as exc:
            render_error("Something went wrong. Try again or run `systemr doctor` to check.")
            logger.error("chat_fallback_error", error=str(exc))
            fire_hook(HookEvent.ERROR, context={"message": str(exc)})

    return collected_text


async def _handle_confirmation(event: SSEEvent, access_token: str) -> bool:
    """Handle a confirmation_required event with real user prompt.

    Args:
        event: The SSE event with tool details and confirmation token.
        access_token: Bearer token for sending confirmation back.

    Returns:
        True if user approved, False if denied.
    """
    from neo.confirmation import confirm_trade, confirm_kill_switch
    from neo.types import to_decimal

    tool = event.parsed.get("tool", "unknown")
    token = event.parsed.get("confirmation_token", "")
    details = event.parsed.get("details", {})
    description = event.parsed.get("description", f"Execute {tool}?")
    perm = get_permission_level(tool)

    approved = False

    if perm == PermissionLevel.DOUBLE_CONFIRM:
        positions = details.get("positions", [])
        approved = confirm_kill_switch(positions)
    elif perm == PermissionLevel.CONFIRM:
        if all(k in details for k in ("symbol", "entry", "stop", "shares")):
            approved = confirm_trade(
                symbol=details["symbol"],
                direction=details.get("direction", "long"),
                entry=to_decimal(details["entry"]),
                stop=to_decimal(details["stop"]),
                shares=int(details["shares"]),
                risk_amount=to_decimal(details.get("risk_amount", 0)),
                risk_pct=to_decimal(details.get("risk_pct", 0)),
                target=to_decimal(details["target"]) if details.get("target") else None,
                rr_ratio=to_decimal(details["rr_ratio"]) if details.get("rr_ratio") else None,
                position_value=(
                    to_decimal(details["position_value"])
                    if details.get("position_value") else None
                ),
            )
        else:
            try:
                response = click.prompt(
                    click.style(f"  {description} [y/n]", fg="white"),
                    type=click.Choice(["y", "n"], case_sensitive=False),
                    show_choices=False,
                )
                approved = response.lower() == "y"
            except (click.Abort, EOFError):
                approved = False
    else:
        approved = True

    if token:
        try:
            await send_confirmation(token, approved, access_token)
        except Exception:
            logger.warning("confirmation_send_failed", token=token[:10])

    logger.info("confirmation_result", tool=tool, approved=approved)
    return approved


def _handle_slash_command(
    cmd: str,
    messages: list[dict[str, str]],
    current_model: str | None,
    access_token: str | None = None,
    credits: SessionCredits | None = None,
) -> str | None:
    """Handle local slash commands.

    Returns:
        "exit" to end session, "clear" to clear history,
        "model:X" to change model, "" for handled commands,
        None if command should be passed to LLM.
    """
    parts = cmd.strip().split(maxsplit=1)
    command = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    if command in ("/q", "/quit", "/exit"):
        return "exit"
    if command == "/clear":
        return "clear"

    if command == "/help":
        console.print()
        console.print(f"  [{GRAY}]commands[/]")
        for name, desc in LOCAL_COMMANDS.items():
            console.print(f"    [{WHITE}]{name:<12}[/] [{DIM}]{desc}[/]")
        console.print()
        return ""

    if command in ("/morning", "/eod", "/plan") and access_token:
        result_text = _run_agent_command(command, access_token, current_model)
        if result_text:
            messages.append({"role": "assistant", "content": result_text})
        return ""

    if command in ("/portfolio", "/risk") and access_token:
        prompts = {
            "/portfolio": "Show my current portfolio positions with P&L.",
            "/risk": (
                "Show my current risk exposure: total risk %, daily limit usage, "
                "positions count vs max, and remaining risk budget."
            ),
        }
        _run_focused_query(prompts[command], access_token, current_model, messages)
        return ""

    if command == "/credits" and credits:
        s = credits.summary()
        console.print()
        console.print(f"  [{GRAY}]Session credits[/]")
        console.print(f"    [{WHITE}]{s['credits_used']:.1f}[/] [{DIM}]credits used[/]")  # type: ignore[str-format]
        console.print(f"    [{WHITE}]{s['tools_called']}[/] [{DIM}]tools called[/]")
        console.print(f"    [{WHITE}]{s['trades_placed']}[/] [{DIM}]trades placed[/]")
        console.print(f"    [{WHITE}]{s['duration_min']}m[/] [{DIM}]duration[/]")
        if s["balance"] is not None:
            console.print(f"    [{WHITE}]{s['balance']:.1f}[/] [{DIM}]OSR remaining[/]")  # type: ignore[str-format]
        console.print()
        return ""

    if command == "/sessions":
        sub = arg.split(maxsplit=1) if arg else []
        sub_cmd = sub[0] if sub else "list"
        sub_arg = sub[1] if len(sub) > 1 else ""
        _store = LocalStore()

        if sub_cmd == "export" and sub_arg:
            try:
                export = _store.export_session(int(sub_arg))
                if export:
                    import json
                    output_file = SESSIONS_DIR / f"export_{sub_arg}.json"
                    output_file.write_text(json.dumps(export, indent=2))
                    print_success(f"Exported session {sub_arg} to {output_file}")
                else:
                    print_error(f"Session {sub_arg} not found")
            except ValueError:
                print_error("Usage: /sessions export <id>")
        elif sub_cmd == "prune":
            pruned = _store.prune_sessions(days=30)
            if pruned:
                print_success(f"Pruned {pruned} sessions older than 30 days")
            else:
                console.print(f"  [{DIM}]No sessions to prune.[/]")
        else:
            sessions = _store.list_sessions(limit=15)
            if sessions:
                console.print()
                console.print(f"  [{GRAY}]Recent sessions ({len(sessions)})[/]")
                for s in sessions:
                    msg_count = s.get("message_count", 0)
                    created = s.get("created_at", "")[:10]
                    title = s.get("title") or f"Session #{s['id']}"
                    console.print(
                        f"    [{WHITE}]{s['id']:<6}[/] [{DIM}]{created}[/]  "
                        f"[{WHITE}]{title:<20}[/] [{DIM}]{msg_count} msgs[/]"
                    )
                console.print(f"  [{DIM}]Commands: /sessions export <id>, /sessions prune[/]")
                console.print()
            else:
                console.print(f"  [{DIM}]No sessions yet.[/]")
        return ""

    if command == "/cron":
        from neo.cron import Schedule, ScheduleKind, add_job, load_jobs, remove_job
        sub = arg.split(maxsplit=1) if arg else []
        sub_cmd = sub[0] if sub else "list"
        sub_arg = sub[1] if len(sub) > 1 else ""

        if sub_cmd == "list":
            jobs = load_jobs()
            if jobs:
                console.print()
                console.print(f"  [{GRAY}]Scheduled tasks ({len(jobs)})[/]")
                for j in jobs:
                    status = f"[{GREEN}]on[/]" if j.enabled else f"[{DIM}]off[/]"
                    console.print(
                        f"    {status} [{WHITE}]{j.name:<20}[/] "
                        f"[{DIM}]{j.schedule.kind.value}[/]  "
                        f"[{DIM}]{j.id}[/]"
                    )
                console.print()
            else:
                console.print(f"  [{DIM}]No scheduled tasks. Use /cron add <name> | <message>[/]")
        elif sub_cmd == "add" and sub_arg:
            parts = sub_arg.split("|", 1)
            name = parts[0].strip()
            message = parts[1].strip() if len(parts) > 1 else name
            job = add_job(name, message, Schedule(kind=ScheduleKind.EVERY, every_seconds=3600))
            print_success(f"Created: {job.name} ({job.id}) — runs every 1h")
        elif sub_cmd == "remove" and sub_arg:
            if remove_job(sub_arg.strip()):
                print_success(f"Removed job {sub_arg.strip()}")
            else:
                print_error(f"Job not found: {sub_arg.strip()}")
        else:
            console.print(f"  [{DIM}]Usage: /cron list, /cron add <name> | <message>, /cron remove <id>[/]")
        return ""

    if command == "/permissions":
        if arg and arg in PERMISSION_PROFILES:
            set_active_profile(arg)
            print_success(f"Permission profile: {arg}")
        else:
            current = get_active_profile()
            console.print()
            console.print(f"  [{GRAY}]Permission profile:[/] [{WHITE}]{current}[/]")
            console.print(f"    [{DIM}]paper       — all trades require DOUBLE_CONFIRM[/]")
            console.print(f"    [{DIM}]standard    — default safety tiers[/]")
            console.print(f"    [{DIM}]experienced — stop/target adjustments auto-approved[/]")
            console.print(f"  [{DIM}]Switch: /permissions paper[/]")
            console.print()
        return ""

    if command == "/memory" and arg:
        results = search_memory(arg, max_results=10)
        if results:
            console.print()
            console.print(f"  [{GRAY}]Memory search: {arg}[/]")
            for r in results:
                console.print(f"    [{DIM}]{r['file']}:{r['line']}[/]  [{WHITE}]{r['content'][:80]}[/]")
            console.print()
        else:
            console.print(f"  [{DIM}]No results for '{arg}'[/]")
        return ""

    if command == "/remember" and arg:
        auto_save_explicit(arg)
        print_success(f"Saved to memory: {arg[:50]}")
        return ""

    if command == "/model":
        if arg:
            return f"model:{arg}"
        console.print(f"  [{GRAY}]Current model:[/] [{WHITE}]{current_model or 'default'}[/]")
        return ""
    if command == "/fast":
        return "model:anthropic.claude-haiku-4-5-20251001"
    if command == "/deep":
        return "model:anthropic.claude-opus-4-6"

    if command == "/profile":
        profile = load_profile()
        if profile:
            console.print()
            console.print(profile)
        else:
            print_info("No profile. Run `systemr setup` to create one.")
        return ""

    if command == "/rules":
        rules = load_rules()
        if rules:
            console.print()
            console.print(rules)
        else:
            print_info("No rules set. Run `systemr setup` to add them.")
        return ""

    # Unknown — pass to LLM
    return None


def _run_agent_command(
    command: str, access_token: str, model: str | None,
) -> str:
    """Execute a multi-agent slash command. Returns combined result text."""
    from neo.orchestrator import (
        run_eod_review,
        run_morning_briefing,
        run_trade_plan,
    )
    from rich.markdown import Markdown
    from rich.panel import Panel

    profile = load_profile() or None
    rules = load_rules() or None

    agent_states: dict[str, str] = {}

    def on_start(name: str) -> None:
        agent_states[name] = "running"
        _render_agent_status(agent_states)

    def on_complete(name: str, success: bool) -> None:
        agent_states[name] = "done" if success else "error"
        _render_agent_status(agent_states)

    titles = {"/morning": "MORNING BRIEFING", "/eod": "END OF DAY REVIEW", "/plan": "TRADE PLAN"}
    runners = {"/morning": run_morning_briefing, "/eod": run_eod_review, "/plan": run_trade_plan}

    console.print()
    console.print(f"  [{WHITE}]{titles[command]}[/]")
    print_separator()

    results = asyncio.run(runners[command](
        access_token=access_token, model=model,
        profile=profile, rules=rules,
        on_start=on_start, on_complete=on_complete,
    ))

    console.print()
    combined = ""
    for r in results:
        if r.success and r.content:
            # Show agent result with cost stats
            duration_str = f"{r.duration_seconds:.1f}s" if r.duration_seconds else ""
            credits_str = f"{r.credits_used}" if r.credits_used else ""
            tools_str = f"{r.tools_called} tools" if r.tools_called else ""
            stats_parts = [s for s in (duration_str, credits_str, tools_str) if s]
            subtitle = f"[{DIM}]{' · '.join(stats_parts)}[/]" if stats_parts else ""

            console.print(Panel(
                Markdown(r.content),
                title=f"[bold {GREEN}]{r.agent_name}[/]",
                subtitle=subtitle,
                border_style=MUTED, padding=(1, 2),
            ))
            combined += f"\n## {r.agent_name}\n{r.content}\n"
        elif r.error:
            render_error(f"{r.agent_name}: {r.error}")

    # Show aggregate stats
    total_duration = sum(r.duration_seconds for r in results)
    total_credits = sum(r.credits_used for r in results)
    total_tools = sum(r.tools_called for r in results)
    if total_duration > 0:
        console.print(
            f"  [{DIM}]{len(results)} agents · "
            f"{total_duration:.1f}s total · "
            f"{total_credits} credits · "
            f"{total_tools} tools[/]"
        )
    console.print()
    return combined


def _render_agent_status(states: dict[str, str]) -> None:
    """Show parallel agent status line."""
    parts = []
    for name, status in states.items():
        if status == "running":
            parts.append(f"[{GREEN_DIM}]{ICON_THINKING}[/] [{GRAY}]{name}[/]")
        elif status == "done":
            parts.append(f"[{GREEN}]{ICON_SUCCESS}[/] [{GRAY}]{name}[/]")
        else:
            parts.append(f"[{DIM}]{ICON_ERROR}[/] [{GRAY}]{name}[/]")
    if parts:
        console.print(f"  {'  '.join(parts)}")


def _run_focused_query(
    prompt: str, access_token: str, model: str | None,
    messages: list[dict[str, str]],
) -> None:
    """Run a single focused query for /portfolio, /risk, etc."""
    request = ChatRequest(
        user_input=prompt, model=model,
        profile=load_profile() or None, rules=load_rules() or None,
    )
    try:
        result = asyncio.run(chat_blocking(request, access_token))
        reply = result.get("response", result.get("content", result.get("message", "")))
        if reply:
            render_assistant_message(reply)
            messages.append({"role": "assistant", "content": reply})
    except Exception as exc:
        render_error(f"Query failed: {exc}")


def _compact_history(messages: list[dict[str, str]]) -> list[dict[str, str]]:
    """Compact old messages to save context window.

    Before dropping old messages, flushes key context to the daily trading
    log (OpenClaw pattern: auto-flush before compaction). Then keeps a
    summary of older messages + the most recent N messages.

    Args:
        messages: Full message history.

    Returns:
        Compacted message list.
    """
    if len(messages) <= COMPACTION_KEEP_RECENT:
        return messages

    old_messages = messages[:-COMPACTION_KEEP_RECENT]
    recent = messages[-COMPACTION_KEEP_RECENT:]

    # Fire COMPACT_BEFORE hook
    fire_hook(HookEvent.COMPACT_BEFORE, context={"messages_dropping": len(old_messages)})

    # Auto-flush: extract key context from messages being dropped
    _flush_before_compaction(old_messages)

    # Build a richer summary from old messages
    summary_parts = []
    for msg in old_messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        # Prioritize trade-related and decision content
        if len(content) > 200:
            content = content[:200] + "..."
        summary_parts.append(f"[{role}]: {content}")

    # Keep last 10 for the summary text, but capture all context
    summary_text = "\n".join(summary_parts[-10:])
    summary = (
        "[CONVERSATION SUMMARY — older messages compacted]\n"
        "Key context from earlier in this session:\n"
        + summary_text
    )
    return [{"role": "assistant", "content": summary}, *recent]


def _flush_before_compaction(old_messages: list[dict[str, str]]) -> None:
    """Save important context from messages being dropped to daily log.

    Extracts trade-related content, decisions, and tool results from
    the old messages before they are lost during compaction. One flush
    per compaction cycle.

    Args:
        old_messages: Messages about to be dropped from context.
    """
    trade_keywords = (
        "bought", "sold", "entry", "exit", "stop", "target", "position",
        "order", "filled", "closed", "profit", "loss", "R-multiple",
    )
    flushed_items = []

    for msg in old_messages:
        content = msg.get("content", "")
        content_lower = content.lower()
        # Flush assistant messages that mention trades or decisions
        if msg.get("role") == "assistant" and any(kw in content_lower for kw in trade_keywords):
            # Take first 200 chars of trade-relevant messages
            flushed_items.append(content[:200])

    if flushed_items:
        flush_text = " | ".join(flushed_items[:5])  # Cap at 5 items
        append_daily_log(
            f"[compaction flush] {flush_text}",
            category="flush",
        )
        logger.info("compaction_flush", items=len(flushed_items))


def _try_resume_session(store: LocalStore) -> tuple[list[dict[str, str]], int]:
    """Try to resume the most recent chat session.

    Args:
        store: The local store instance.

    Returns:
        Tuple of (messages, session_id). Messages empty if no session found.
    """
    try:
        session_file = SESSIONS_DIR / "last_session.json"
        if session_file.exists():
            data = json.loads(session_file.read_text())
            return data.get("messages", []), data.get("session_id", store.create_chat_session())
    except Exception:
        pass
    return [], store.create_chat_session()


def _save_session(session_id: int, messages: list[dict[str, str]]) -> None:
    """Save session to disk for resume.

    Args:
        session_id: The database session ID.
        messages: Conversation messages (last 50 kept).
    """
    try:
        ensure_systemr_home()
        session_file = SESSIONS_DIR / "last_session.json"
        session_file.write_text(json.dumps({
            "session_id": session_id,
            "messages": messages[-50:],
        }, indent=2))
    except Exception:
        pass
