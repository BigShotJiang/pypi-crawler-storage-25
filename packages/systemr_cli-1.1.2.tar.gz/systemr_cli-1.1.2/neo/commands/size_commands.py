"""Position sizing command — neo size."""

from __future__ import annotations

import asyncio

import click

from neo.auth import AuthManager
from neo.client import AuthRequired, NeoClient
from neo.display.formatters import fmt_price, fmt_pct, fmt_qty, fmt_risk
from neo.display.tables import kv_table
from neo.display.theme import GREEN_DIM, console, print_error


@click.command()
@click.option("--equity", required=True, type=float, help="Account equity ($)")
@click.option("--entry", required=True, type=float, help="Entry price")
@click.option("--stop", required=True, type=float, help="Stop loss price")
@click.option("--direction", type=click.Choice(["long", "short"]), default="long", help="Trade direction")
@click.option("--risk-pct", type=float, default=1.0, help="Risk per trade (%, default 1.0)")
def size(equity: float, entry: float, stop: float, direction: str, risk_pct: float) -> None:
    """Calculate position size for a trade."""
    auth = AuthManager()
    client = NeoClient(auth)

    payload = {
        "equity": equity,
        "entry_price": entry,
        "stop_price": stop,
        "direction": direction,
        "risk_percent": risk_pct,
    }

    try:
        with console.status(f"[{GREEN_DIM}]Computing...[/]"):
            result = asyncio.run(client.post("/v1/sizing/calculate", json=payload))
    except AuthRequired:
        print_error("Not authenticated. Run `neo login` first.")
        raise SystemExit(1)
    except Exception as e:
        print_error(f"Sizing failed: {e}")
        raise SystemExit(1)

    risk_per_share = abs(entry - stop)
    risk_amount = result.get("risk_amount", equity * risk_pct / 100)
    shares = result.get("shares", int(risk_amount / risk_per_share) if risk_per_share else 0)
    position_value = result.get("position_value", shares * entry)

    kv_table("POSITION SIZE", {
        "Direction": direction.upper(),
        "Entry": fmt_price(entry),
        "Stop": fmt_price(stop),
        "Risk/Share": fmt_price(risk_per_share),
        "Risk Amount": fmt_risk(risk_amount),
        "Risk %": fmt_pct(risk_pct),
        "Shares": fmt_qty(shares),
        "Position Value": fmt_price(position_value),
        "% of Equity": fmt_pct(position_value / equity * 100 if equity else 0),
    })
