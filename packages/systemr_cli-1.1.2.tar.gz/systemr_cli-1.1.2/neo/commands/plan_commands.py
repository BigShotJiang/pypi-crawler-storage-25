"""Plan command — redirects to chat for trade plan generation."""

from __future__ import annotations

import click

from neo.display.theme import console, GRAY, GREEN, WHITE


@click.command()
@click.option("--ticker", required=True, help="Ticker symbol")
@click.option("--equity", required=True, type=float, help="Account equity ($)")
@click.option("--risk-pct", type=float, default=1.0, help="Risk per trade (%)")
@click.option("--direction", type=click.Choice(["long", "short"]), default=None, help="Direction")
def plan(ticker: str, equity: float, risk_pct: float, direction: str | None) -> None:
    """Generate a complete trade plan for a ticker."""
    dir_str = f" {direction}" if direction else ""
    prompt = f"Build a{dir_str} trade plan for {ticker.upper()}, equity ${equity:,.0f}, risk {risk_pct}%"

    console.print()
    console.print(f"  [{WHITE}]Use chat for trade plans:[/]")
    console.print()
    console.print(f"  [{GREEN}]systemr chat --pipe \"{prompt}\"[/]")
    console.print()
    console.print(f"  [{GRAY}]Or start an interactive session:[/]")
    console.print(f"  [{GREEN}]systemr chat[/]  [{GRAY}]then describe your trade[/]")
    console.print()
