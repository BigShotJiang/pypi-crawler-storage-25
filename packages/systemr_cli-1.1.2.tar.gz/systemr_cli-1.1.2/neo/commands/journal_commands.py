"""Journal commands — local trade journal (SQLite)."""

from __future__ import annotations

import csv
import io
import json

import click

from neo.display.formatters import direction_style, fmt_price, fmt_qty, fmt_r
from neo.display.tables import data_table, kv_table
from neo.display.theme import console, print_error, print_success
from neo.store import LocalStore


@click.group()
def journal() -> None:
    """Local trade journal — stored on your machine."""
    pass


@journal.command()
@click.option("--symbol", required=True, help="Ticker symbol")
@click.option("--entry", required=True, type=float, help="Entry price")
@click.option("--stop", required=True, type=float, help="Stop loss price")
@click.option("--direction", type=click.Choice(["long", "short"]), default="long")
@click.option("--qty", required=True, type=int, help="Number of shares")
@click.option("--date", default=None, help="Entry date (YYYY-MM-DD, default today)")
@click.option("--notes", default=None, help="Trade notes")
@click.option("--tags", default=None, help="Comma-separated tags")
def add(symbol: str, entry: float, stop: float, direction: str, qty: int, date: str | None, notes: str | None, tags: str | None) -> None:
    """Add a trade to the journal."""
    store = LocalStore()
    trade_id = store.add_trade(
        symbol=symbol,
        direction=direction,
        entry_price=entry,
        stop_price=stop,
        quantity=qty,
        entry_date=date,
        notes=notes,
        tags=tags,
    )
    print_success(f"Trade #{trade_id} added — {symbol.upper()} {direction.upper()} {qty} @ {fmt_price(entry)}")


@journal.command("list")
@click.option("--symbol", default=None, help="Filter by symbol")
@click.option("--limit", default=20, type=int, help="Max trades to show")
def list_trades(symbol: str | None, limit: int) -> None:
    """List recent trades."""
    store = LocalStore()
    trades = store.list_trades(limit=limit, symbol=symbol)
    if not trades:
        console.print("[neo.dim]No trades found.[/]")
        return

    rows = []
    for t in trades:
        r_str = fmt_r(t["r_multiple"]) if t["r_multiple"] is not None else "—"
        dir_style = direction_style(t["direction"])
        rows.append([
            str(t["id"]),
            t["entry_date"][:10],
            t["symbol"],
            f"[{dir_style}]{t['direction'].upper()}[/]",
            fmt_price(t["entry_price"]),
            fmt_price(t["stop_price"]),
            fmt_qty(t["quantity"]),
            r_str,
        ])

    data_table(
        "TRADE JOURNAL",
        [
            ("#", "dim"),
            ("Date", ""),
            ("Symbol", "bold"),
            ("Dir", ""),
            ("Entry", ""),
            ("Stop", ""),
            ("Qty", ""),
            ("R", ""),
        ],
        rows,
    )


@journal.command()
@click.argument("trade_id", type=int)
def show(trade_id: int) -> None:
    """Show details of a specific trade."""
    store = LocalStore()
    t = store.get_trade(trade_id)
    if not t:
        print_error(f"Trade #{trade_id} not found.")
        raise SystemExit(1)

    data = {
        "Symbol": t["symbol"],
        "Direction": t["direction"].upper(),
        "Entry": fmt_price(t["entry_price"]),
        "Stop": fmt_price(t["stop_price"]),
        "Quantity": fmt_qty(t["quantity"]),
        "Entry Date": t["entry_date"],
    }
    if t["exit_price"] is not None:
        data["Exit"] = fmt_price(t["exit_price"])
    if t["exit_date"]:
        data["Exit Date"] = t["exit_date"]
    if t["r_multiple"] is not None:
        data["R-Multiple"] = fmt_r(t["r_multiple"])
    if t["notes"]:
        data["Notes"] = t["notes"]
    if t["tags"]:
        data["Tags"] = t["tags"]

    kv_table(f"TRADE #{trade_id}", data)


@journal.command()
@click.argument("trade_id", type=int)
@click.option("--exit-price", type=float, help="Exit price")
@click.option("--exit-date", type=str, help="Exit date (YYYY-MM-DD)")
@click.option("--r-multiple", type=float, help="R-multiple result")
@click.option("--notes", type=str, help="Update notes")
@click.option("--tags", type=str, help="Update tags")
def edit(trade_id: int, exit_price: float | None, exit_date: str | None, r_multiple: float | None, notes: str | None, tags: str | None) -> None:
    """Edit a trade in the journal."""
    store = LocalStore()
    updated = store.update_trade(
        trade_id,
        exit_price=exit_price,
        exit_date=exit_date,
        r_multiple=r_multiple,
        notes=notes,
        tags=tags,
    )
    if updated:
        print_success(f"Trade #{trade_id} updated.")
        # Auto-save lesson for significant losses (R < -1)
        if r_multiple is not None and r_multiple < -1.0:
            trade = store.get_trade(trade_id)
            if trade:
                from neo.profile import auto_save_trade_lesson
                auto_save_trade_lesson(
                    symbol=str(trade["symbol"]),
                    r_multiple=str(r_multiple),
                    direction=str(trade["direction"]),
                    entry=str(trade["entry_price"]),
                    exit_price=str(exit_price or trade.get("exit_price", 0)),
                    notes=notes or str(trade.get("notes", "")),
                )
                print_success("Lesson auto-saved to memory.")
    else:
        print_error(f"Trade #{trade_id} not found or no changes.")


@journal.command()
@click.argument("trade_id", type=int)
@click.confirmation_option(prompt="Are you sure you want to delete this trade?")
def delete(trade_id: int) -> None:
    """Delete a trade from the journal."""
    store = LocalStore()
    if store.delete_trade(trade_id):
        print_success(f"Trade #{trade_id} deleted.")
    else:
        print_error(f"Trade #{trade_id} not found.")


@journal.command()
@click.option("--format", "fmt", type=click.Choice(["csv", "json"]), default="csv", help="Export format")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file (default: stdout)")
def export(fmt: str, output: str | None) -> None:
    """Export all trades."""
    store = LocalStore()
    trades = store.export_trades()
    if not trades:
        console.print("[neo.dim]No trades to export.[/]")
        return

    if fmt == "json":
        text = json.dumps(trades, indent=2)
    else:
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=trades[0].keys())
        writer.writeheader()
        writer.writerows(trades)
        text = buf.getvalue()

    if output:
        with open(output, "w") as f:
            f.write(text)
        print_success(f"Exported {len(trades)} trades to {output}")
    else:
        console.print(text)
