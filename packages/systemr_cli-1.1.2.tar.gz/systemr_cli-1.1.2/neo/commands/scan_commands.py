"""Scan command — redirects to chat for full analysis."""

from __future__ import annotations

import click

from neo.display.theme import console, GRAY, GREEN, WHITE


@click.command()
@click.argument("symbol")
def scan(symbol: str) -> None:
    """Scan a symbol for trading signals."""
    console.print()
    console.print(f"  [{WHITE}]Use chat for full analysis:[/]")
    console.print()
    console.print(f"  [{GREEN}]systemr chat --pipe \"Scan {symbol.upper()} for trading signals\"[/]")
    console.print()
    console.print(f"  [{GRAY}]Or start an interactive session:[/]")
    console.print(f"  [{GREEN}]systemr chat[/]  [{GRAY}]then type: scan {symbol.upper()}[/]")
    console.print()
