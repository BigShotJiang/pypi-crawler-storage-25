# System R CLI

Trading operating system in your terminal. Like Claude Code, but for trading.

Type natural language. System R runs the full stack — 55 institutional-grade tools, 25 broker adapters, risk engine, G-Score — all from your terminal.

## Install

```bash
pip install systemr-cli
```

Or from source:

```bash
git clone https://github.com/System-R-AI/systemr-neo.git
cd systemr-neo
pip install -e .
```

Requires Python 3.11+.

## Quick Start

```bash
# Set up your profile
systemr setup

# Connect to System R
systemr login

# Start chatting
systemr chat
```

That's it. Type in plain English:

```
you > buy TSLA 2% risk
```

System R will size the position, check risk, show you the trade card, and ask for confirmation before executing.

## Commands

### Trading
| Command | Description |
|---------|-------------|
| `systemr chat` | Interactive conversation with System R |
| `systemr size` | Position sizing (G-formula) |
| `systemr risk` | Pre-trade risk validation |
| `systemr eval` | System performance analysis (G-Score) |
| `systemr scan` | Market scanner |
| `systemr plan` | Trade planning |

### Local
| Command | Description |
|---------|-------------|
| `systemr journal` | Trade journal (add/list/show/edit/export) |
| `systemr cron` | Scheduled tasks (add/list/remove/run) |
| `systemr doctor` | Health check and diagnostics |
| `systemr setup` | Profile and rules wizard |

### Auth
| Command | Description |
|---------|-------------|
| `systemr login` | Connect to System R |
| `systemr logout` | Disconnect |
| `systemr whoami` | Show current session |

## Chat Commands

Inside `systemr chat`, use slash commands:

| Command | Action |
|---------|--------|
| `/morning` | Morning briefing (4 parallel agents) |
| `/eod` | End of day review + journal |
| `/plan` | Plan today's trades |
| `/portfolio` | Show open positions |
| `/risk` | Risk dashboard |
| `/memory <query>` | Search past memories |
| `/sessions` | List recent sessions |
| `/cron` | Manage scheduled tasks |
| `/permissions` | View/switch safety profile |
| `/remember <text>` | Save a memory |
| `/model <name>` | Switch LLM model |
| `/credits` | Session credit usage |
| `/help` | All commands |

## Safety

Three-tier confirmation protocol:

- **AUTO** — Read-only actions (quotes, analysis, calculations)
- **CONFIRM** — Trade actions (place/cancel/modify order) — show details, y/n
- **DOUBLE_CONFIRM** — Destructive actions (kill switch) — type "KILL"

Permission profiles: `paper` (max safety), `standard` (default), `experienced` (relaxed stops).

## Architecture

```
~/.systemr/
  PROFILE.md          # Trader identity, risk params
  RULES.md            # Hard/soft rules + standing orders
  auth.json           # API credentials (chmod 600)
  config.json         # Settings, model config
  journal.db          # SQLite trade journal
  memory/
    MEMORY.md         # Index
    YYYY-MM-DD.md     # Daily trading logs
    *.md              # Lessons, notes, violations
  sessions/
    last_session.json # Resume state
  cron/
    jobs.json         # Scheduled tasks
    runs/             # Run history (JSONL)
```

All data stays on your machine. The backend (`agents.systemr.ai`) processes requests — your profile, rules, and journal never leave your disk.

## Backend

System R CLI connects to `agents.systemr.ai`:

- 55 MCP tools (sizing, risk, intelligence, planning, behavioral)
- 25 broker/exchange adapters
- 187 domain services
- Per-agent encryption (AES-128-CBC)
- Multi-model LLM via AWS Bedrock (Claude, GPT, Nova)
- Compute credit billing (USDC, SOL, OSR)

## Development

```bash
git clone https://github.com/System-R-AI/systemr-neo.git
cd systemr-neo
pip install -e ".[dev]"
pytest
```

### Rules

- Decimal for all money — never float
- structlog only — zero `print()`
- Additive-only — never remove/rename
- Tests for every module

### Stats

- 33 source files, ~8,800 lines
- 206 tests passing
- Zero bare `print()` statements
- Python 3.11+

## Links

- [systemr.ai](https://systemr.ai) — Documentation
- [agents.systemr.ai](https://agents.systemr.ai) — API
- [app.systemr.ai](https://app.systemr.ai) — Portal

Built by [Ashim Nandi](https://ashimnandi.com) and Shannon at [System R AI](https://systemr.ai).
