"""Tests for neo.commands.doctor_command — health check diagnostics."""

from click.testing import CliRunner

from neo.commands.doctor_command import doctor


class TestDoctor:
    """Doctor command health checks."""

    def test_doctor_runs(self, monkeypatch: object) -> None:
        """Doctor command completes without crashing."""
        # Mock httpx to avoid real network calls
        class MockResponse:
            status_code = 200
            def json(self) -> dict:
                return {"balance": "100.00"}

        monkeypatch.setattr("neo.commands.doctor_command.AuthManager", lambda: type(
            "MockAuth", (), {"get_token": lambda self: None}
        )())

        import httpx
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: MockResponse())

        runner = CliRunner()
        result = runner.invoke(doctor)
        assert result.exit_code in (0, 1, 2)  # Any valid exit code
        # Should contain at least some check output
        assert "Python version" in result.output or "SYSTEM R" in result.output

    def test_doctor_checks_python_version(self) -> None:
        """Python version check should pass on 3.11+."""
        import sys
        assert sys.version_info >= (3, 11)

    def test_doctor_no_crash_without_auth(self, tmp_path: object, monkeypatch: object) -> None:
        """Doctor should not crash when not authenticated."""
        monkeypatch.setattr("neo.commands.doctor_command.SYSTEMR_HOME", tmp_path)
        monkeypatch.setattr("neo.commands.doctor_command.PROFILE_FILE", tmp_path / "PROFILE.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.commands.doctor_command.RULES_FILE", tmp_path / "RULES.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.commands.doctor_command.DB_FILE", tmp_path / "journal.db")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.commands.doctor_command.MEMORY_DIR", tmp_path / "memory")  # type: ignore[arg-type]

        # Mock auth to return None (not logged in)
        monkeypatch.setattr("neo.commands.doctor_command.AuthManager", lambda: type(
            "MockAuth", (), {"get_token": lambda self: None}
        )())

        # Mock httpx for API check
        class MockResponse:
            status_code = 200

        import httpx
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: MockResponse())

        runner = CliRunner()
        result = runner.invoke(doctor)
        # Should complete (exit 1 due to auth error, but no crash)
        assert result.exit_code in (0, 1, 2)
