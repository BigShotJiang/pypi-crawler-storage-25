"""Tests for neo.config."""

import os
from pathlib import Path

from neo.config import get_api_url, DEFAULT_API_URL, STAGING_API_URL


def test_default_api_url():
    os.environ.pop("NEO_API_URL", None)
    assert get_api_url() == DEFAULT_API_URL


def test_custom_api_url(monkeypatch):
    monkeypatch.setenv("NEO_API_URL", "http://localhost:8000")
    assert get_api_url() == "http://localhost:8000"
