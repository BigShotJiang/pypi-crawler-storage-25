"""Tests for neo.orchestrator — multi-agent parallel execution."""

import inspect

from neo.orchestrator import (
    SubAgent,
    AgentResult,
    PORTFOLIO_SCANNER,
    MARKET_ANALYST,
    RISK_CALCULATOR,
    WATCHLIST_SCANNER,
    STRATEGY_ANALYST,
    JOURNAL_WRITER,
    TRADE_PLANNER,
    run_morning_briefing,
    run_eod_review,
    run_trade_plan,
)
from neo.streaming import ChatRequest


class TestSubAgent:
    """Verify sub-agent data and request building."""

    def test_to_request(self) -> None:
        agent = SubAgent(name="Test Agent", prompt="Analyze portfolio")
        req = agent.to_request(
            model="claude-sonnet",
            profile="# Profile\nRisk: 2%",
        )
        assert isinstance(req, ChatRequest)
        assert req.user_input == "Analyze portfolio"
        assert req.model == "claude-sonnet"
        assert req.profile == "# Profile\nRisk: 2%"
        assert req.research_mode is True

    def test_to_request_minimal(self) -> None:
        agent = SubAgent(name="Minimal", prompt="hello")
        req = agent.to_request()
        assert req.user_input == "hello"
        assert req.model is None
        assert req.profile is None


class TestAgentResult:
    """Verify result data."""

    def test_success(self) -> None:
        r = AgentResult(agent_name="Scanner", success=True, content="All good")
        assert r.success
        assert r.content == "All good"
        assert r.error is None

    def test_failure(self) -> None:
        r = AgentResult(agent_name="Analyst", success=False, content="", error="timeout")
        assert not r.success
        assert r.error == "timeout"


class TestPredefinedAgents:
    """Verify all 7 pre-defined agents are properly configured."""

    def test_all_have_prompts(self) -> None:
        agents = [
            PORTFOLIO_SCANNER, MARKET_ANALYST, RISK_CALCULATOR,
            WATCHLIST_SCANNER, STRATEGY_ANALYST, JOURNAL_WRITER, TRADE_PLANNER,
        ]
        for agent in agents:
            assert agent.name, "Agent missing name"
            assert agent.prompt, f"Agent {agent.name} missing prompt"
            assert len(agent.prompt) > 20, f"Agent {agent.name} prompt too short"

    def test_seven_agents(self) -> None:
        agents = [
            PORTFOLIO_SCANNER, MARKET_ANALYST, RISK_CALCULATOR,
            WATCHLIST_SCANNER, STRATEGY_ANALYST, JOURNAL_WRITER, TRADE_PLANNER,
        ]
        assert len(agents) == 7
        names = [a.name for a in agents]
        assert len(set(names)) == 7  # all unique


class TestRoutineComposition:
    """Verify routines use the correct agents."""

    def test_morning_uses_4_agents(self) -> None:
        src = inspect.getsource(run_morning_briefing)
        assert "PORTFOLIO_SCANNER" in src
        assert "MARKET_ANALYST" in src
        assert "RISK_CALCULATOR" in src
        assert "WATCHLIST_SCANNER" in src

    def test_eod_uses_2_agents(self) -> None:
        src = inspect.getsource(run_eod_review)
        assert "STRATEGY_ANALYST" in src
        assert "JOURNAL_WRITER" in src

    def test_trade_plan_uses_3_agents(self) -> None:
        src = inspect.getsource(run_trade_plan)
        assert "MARKET_ANALYST" in src
        assert "RISK_CALCULATOR" in src
        assert "TRADE_PLANNER" in src

    def test_no_structlog_event_conflict(self) -> None:
        """Logger calls must not use 'event' as kwarg (structlog reserves it)."""
        src = inspect.getsource(inspect.getmodule(run_morning_briefing))  # type: ignore[arg-type]
        # "event=" should only appear in type hints or comments, not in logger calls
        lines = src.split("\n")
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("logger.") and "event=" in stripped:
                assert False, f"Line {i}: logger call uses 'event=' kwarg — use 'hook_event=' instead"
