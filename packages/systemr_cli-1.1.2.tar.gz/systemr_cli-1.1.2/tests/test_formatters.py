"""Tests for neo.display.formatters."""

from neo.display.formatters import fmt_price, fmt_qty, fmt_pct, fmt_r, fmt_risk


def test_fmt_price():
    assert fmt_price(182.50) == "$182.50"
    assert fmt_price(1234567.89) == "$1,234,567.89"


def test_fmt_qty():
    assert fmt_qty(100) == "100"
    assert fmt_qty(1234) == "1,234"
    assert fmt_qty(100.0) == "100"


def test_fmt_pct():
    assert fmt_pct(1.5) == "1.5%"
    assert fmt_pct(99.99, decimals=2) == "99.99%"


def test_fmt_r():
    assert fmt_r(1.5) == "+1.50R"
    assert fmt_r(-1.0) == "-1.00R"
    assert fmt_r(0) == "0.00R"


def test_fmt_risk():
    assert fmt_risk(500.0) == "$500.00"
