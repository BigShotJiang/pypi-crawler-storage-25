"""Tests for neo.cron — cron scheduler with persistence."""

import json
from datetime import datetime, timezone, timedelta

from neo.cron import (
    CronJob,
    RunRecord,
    Schedule,
    ScheduleKind,
    add_job,
    get_job,
    get_runs,
    is_due,
    load_jobs,
    record_run,
    remove_job,
    save_jobs,
)


class TestCronJob:
    """CronJob dataclass basics."""

    def test_auto_generates_id(self) -> None:
        job = CronJob(name="Test", message="hello")
        assert job.id.startswith("job_")
        assert len(job.id) > 4

    def test_auto_generates_created_at(self) -> None:
        job = CronJob(name="Test", message="hello")
        assert job.created_at != ""

    def test_default_enabled(self) -> None:
        job = CronJob(name="Test", message="hello")
        assert job.enabled is True


class TestSchedule:
    """Schedule types."""

    def test_at_schedule(self) -> None:
        s = Schedule(kind=ScheduleKind.AT, at="2026-04-01T09:00:00Z")
        assert s.kind == ScheduleKind.AT
        assert s.at is not None

    def test_every_schedule(self) -> None:
        s = Schedule(kind=ScheduleKind.EVERY, every_seconds=300)
        assert s.every_seconds == 300

    def test_cron_schedule(self) -> None:
        s = Schedule(kind=ScheduleKind.CRON, expr="0 7 * * 1-5", tz="America/New_York")
        assert s.expr == "0 7 * * 1-5"
        assert s.tz == "America/New_York"


class TestJobPersistence:
    """Save/load jobs to disk."""

    def test_save_and_load(self, tmp_path: object, monkeypatch: object) -> None:
        cron_dir = tmp_path / "cron"  # type: ignore[operator]
        cron_dir.mkdir()
        monkeypatch.setattr("neo.cron.CRON_DIR", cron_dir)
        monkeypatch.setattr("neo.cron.JOBS_FILE", cron_dir / "jobs.json")
        monkeypatch.setattr("neo.cron.RUNS_DIR", cron_dir / "runs")
        monkeypatch.setattr("neo.cron.ensure_systemr_home", lambda: None)

        job = CronJob(
            name="Morning scan",
            message="Run morning briefing",
            schedule=Schedule(kind=ScheduleKind.CRON, expr="0 7 * * 1-5"),
        )
        save_jobs([job])

        loaded = load_jobs()
        assert len(loaded) == 1
        assert loaded[0].name == "Morning scan"
        assert loaded[0].schedule.kind == ScheduleKind.CRON
        assert loaded[0].schedule.expr == "0 7 * * 1-5"

    def test_load_empty(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.cron.JOBS_FILE", tmp_path / "nope.json")  # type: ignore[arg-type]
        assert load_jobs() == []

    def test_add_and_remove(self, tmp_path: object, monkeypatch: object) -> None:
        cron_dir = tmp_path / "cron"  # type: ignore[operator]
        cron_dir.mkdir()
        (cron_dir / "runs").mkdir()
        monkeypatch.setattr("neo.cron.CRON_DIR", cron_dir)
        monkeypatch.setattr("neo.cron.JOBS_FILE", cron_dir / "jobs.json")
        monkeypatch.setattr("neo.cron.RUNS_DIR", cron_dir / "runs")
        monkeypatch.setattr("neo.cron.ensure_systemr_home", lambda: None)

        job = add_job("Test", "hello", Schedule(kind=ScheduleKind.AT, at="2026-04-01T09:00:00Z"))
        assert get_job(job.id) is not None

        removed = remove_job(job.id)
        assert removed is True
        assert get_job(job.id) is None

    def test_remove_nonexistent(self, tmp_path: object, monkeypatch: object) -> None:
        cron_dir = tmp_path / "cron"  # type: ignore[operator]
        cron_dir.mkdir()
        (cron_dir / "runs").mkdir()
        monkeypatch.setattr("neo.cron.CRON_DIR", cron_dir)
        monkeypatch.setattr("neo.cron.JOBS_FILE", cron_dir / "jobs.json")
        monkeypatch.setattr("neo.cron.RUNS_DIR", cron_dir / "runs")
        monkeypatch.setattr("neo.cron.ensure_systemr_home", lambda: None)

        save_jobs([])
        assert remove_job("nonexistent") is False


class TestRunRecords:
    """Run history tracking."""

    def test_record_and_get_runs(self, tmp_path: object, monkeypatch: object) -> None:
        runs_dir = tmp_path / "runs"  # type: ignore[operator]
        runs_dir.mkdir()
        monkeypatch.setattr("neo.cron.RUNS_DIR", runs_dir)
        monkeypatch.setattr("neo.cron.CRON_DIR", tmp_path)
        monkeypatch.setattr("neo.cron.ensure_systemr_home", lambda: None)

        record_run(RunRecord(job_id="job_123", status="ok", duration_seconds=2.5))
        record_run(RunRecord(job_id="job_123", status="error", message="timeout"))

        runs = get_runs("job_123")
        assert len(runs) == 2
        assert runs[0]["status"] == "error"  # Newest first
        assert runs[1]["status"] == "ok"

    def test_get_runs_empty(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.cron.RUNS_DIR", tmp_path)
        assert get_runs("nonexistent") == []


class TestIsDue:
    """Schedule checking."""

    def test_at_job_due(self) -> None:
        past = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        job = CronJob(
            name="Past",
            message="hello",
            schedule=Schedule(kind=ScheduleKind.AT, at=past),
        )
        assert is_due(job) is True

    def test_at_job_not_due(self) -> None:
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        job = CronJob(
            name="Future",
            message="hello",
            schedule=Schedule(kind=ScheduleKind.AT, at=future),
        )
        assert is_due(job) is False

    def test_disabled_job_not_due(self) -> None:
        past = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        job = CronJob(
            name="Disabled",
            message="hello",
            schedule=Schedule(kind=ScheduleKind.AT, at=past),
            enabled=False,
        )
        assert is_due(job) is False

    def test_every_job_first_run(self) -> None:
        job = CronJob(
            name="Interval",
            message="hello",
            schedule=Schedule(kind=ScheduleKind.EVERY, every_seconds=300),
        )
        assert is_due(job) is True

    def test_every_job_not_yet(self) -> None:
        now = datetime.now(timezone.utc).isoformat()
        job = CronJob(
            name="Interval",
            message="hello",
            schedule=Schedule(kind=ScheduleKind.EVERY, every_seconds=3600),
            last_run_at=now,
        )
        assert is_due(job) is False
