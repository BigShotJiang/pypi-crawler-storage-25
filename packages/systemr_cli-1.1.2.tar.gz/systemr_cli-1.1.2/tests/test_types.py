"""Tests for neo.types — Decimal-based financial types."""

from decimal import Decimal, InvalidOperation

import pytest

from neo.types import (
    Price,
    RiskAmount,
    Quantity,
    Percentage,
    to_decimal,
    round_price,
    round_risk,
    round_pct,
    round_r,
)


class TestTypeAliases:
    """Verify type aliases resolve to correct base types."""

    def test_price_is_decimal(self) -> None:
        p = Price("198.50")
        assert isinstance(p, Decimal)
        assert p == Decimal("198.50")

    def test_risk_amount_is_decimal(self) -> None:
        r = RiskAmount("1046.80")
        assert isinstance(r, Decimal)

    def test_percentage_is_decimal(self) -> None:
        pct = Percentage("1.97")
        assert isinstance(pct, Decimal)

    def test_quantity_is_int(self) -> None:
        q = Quantity(160)
        assert isinstance(q, int)
        assert q == 160


class TestToDecimal:
    """Verify safe conversion from all numeric types."""

    def test_from_string(self) -> None:
        assert to_decimal("198.50") == Decimal("198.50")

    def test_from_int(self) -> None:
        assert to_decimal(100) == Decimal("100")

    def test_from_float(self) -> None:
        # Float 0.1 must not produce 0.1000000000000000055511151231257827021181583404541015625
        result = to_decimal(0.1)
        assert result == Decimal("0.1")

    def test_from_float_avoids_repr_error(self) -> None:
        # This is the key test — Decimal(0.1) != Decimal("0.1")
        # Our to_decimal must handle this correctly via str conversion
        result = to_decimal(198.5)
        assert result == Decimal("198.5")

    def test_from_decimal_passthrough(self) -> None:
        d = Decimal("42.00")
        assert to_decimal(d) is d  # Same object, no copy

    def test_invalid_raises(self) -> None:
        with pytest.raises(InvalidOperation):
            to_decimal("not_a_number")


class TestRounding:
    """Verify financial rounding rules."""

    def test_round_price_standard(self) -> None:
        assert round_price(Decimal("198.555")) == Decimal("198.56")

    def test_round_price_exact(self) -> None:
        assert round_price(Decimal("198.50")) == Decimal("198.50")

    def test_round_price_half_up(self) -> None:
        # ROUND_HALF_UP: 0.005 rounds to 0.01
        assert round_price(Decimal("100.005")) == Decimal("100.01")

    def test_round_risk(self) -> None:
        assert round_risk(Decimal("1046.8049")) == Decimal("1046.80")

    def test_round_pct(self) -> None:
        assert round_pct(Decimal("1.975")) == Decimal("1.98")

    def test_round_r(self) -> None:
        assert round_r(Decimal("2.305")) == Decimal("2.31")
        assert round_r(Decimal("-1.004")) == Decimal("-1.00")


class TestDecimalArithmetic:
    """Verify Decimal arithmetic works for trading calculations."""

    def test_position_sizing(self) -> None:
        """Core position sizing: shares = risk_amount / risk_per_share."""
        equity = Price("52340.00")
        risk_pct = Percentage("2")
        entry = Price("198.50")
        stop = Price("192.00")

        risk_amount = round_risk(equity * risk_pct / Decimal("100"))
        risk_per_share = entry - stop
        shares = int(risk_amount / risk_per_share)

        assert risk_amount == Decimal("1046.80")
        assert risk_per_share == Decimal("6.50")
        assert shares == 161  # 1046.80 / 6.50 = 161.04...

    def test_no_float_contamination(self) -> None:
        """Mixing Decimal with float should raise TypeError."""
        price = Price("198.50")
        with pytest.raises(TypeError):
            _ = price + 1.5  # type: ignore[operator]
