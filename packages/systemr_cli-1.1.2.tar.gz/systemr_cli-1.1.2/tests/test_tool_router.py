"""Tests for neo.tool_router — client-side tool pre-routing."""

from neo.tool_router import match_tool


class TestMatchTool:
    """Verify tool pattern matching and parameter extraction."""

    def test_position_size_natural(self) -> None:
        m = match_tool("Size a position for AAPL, equity 100000, risk 1%, entry 185.50, stop 180")
        assert m is not None
        assert m.tool_name == "calculate_position_size"
        assert m.arguments["symbol"] == "AAPL"
        assert m.arguments["equity"] == "100000"
        assert m.arguments["risk_pct"] == "1"
        assert m.arguments["entry_price"] == "185.50"
        assert m.arguments["stop_price"] == "180"

    def test_position_size_minimal(self) -> None:
        m = match_tool("size TSLA equity $50,000")
        assert m is not None
        assert m.tool_name == "calculate_position_size"
        assert m.arguments["symbol"] == "TSLA"
        assert m.arguments["equity"] == "50000"

    def test_risk_check(self) -> None:
        m = match_tool("check risk on MSFT long at 420, stop 410, equity 200000")
        assert m is not None
        assert m.tool_name == "check_trade_risk"
        assert m.arguments["symbol"] == "MSFT"
        assert m.arguments["entry_price"] == "420"
        assert m.arguments["stop_price"] == "410"

    def test_pre_trade_gate(self) -> None:
        m = match_tool("pre-trade gate NVDA long entry 130 stop 125 equity 75000")
        assert m is not None
        assert m.tool_name == "pre_trade_gate"
        assert m.arguments["symbol"] == "NVDA"

    def test_gate_shorthand(self) -> None:
        m = match_tool("gate AAPL at 185 stop 180 equity 100000")
        assert m is not None
        assert m.tool_name == "pre_trade_gate"

    def test_conversational_returns_none(self) -> None:
        assert match_tool("how can you help me with trading") is None

    def test_insufficient_params_returns_none(self) -> None:
        assert match_tool("size AAPL") is None  # No equity

    def test_short_direction(self) -> None:
        m = match_tool("size short TSLA equity 100000 entry 250 stop 260")
        assert m is not None
        assert m.arguments.get("direction") == "short"

    def test_no_match_generic(self) -> None:
        assert match_tool("what's the weather today") is None
        assert match_tool("tell me about bybit") is None
