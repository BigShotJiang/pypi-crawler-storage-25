"""Tests for chat_commands helper functions."""

import json

from neo.commands.chat_commands import (
    _compact_history,
    _save_session,
    _try_resume_session,
    _handle_slash_command,
    COMPACTION_KEEP_RECENT,
    LOCAL_COMMANDS,
)
from neo.store import LocalStore


class TestCompactHistory:
    """Verify context compaction logic."""

    def test_short_history_unchanged(self) -> None:
        msgs = [{"role": "user", "content": f"msg {i}"} for i in range(5)]
        result = _compact_history(msgs)
        assert len(result) == 5

    def test_long_history_compacted(self) -> None:
        msgs = [{"role": "user", "content": f"msg {i}"} for i in range(40)]
        result = _compact_history(msgs)
        assert len(result) == COMPACTION_KEEP_RECENT + 1
        assert "CONVERSATION SUMMARY" in result[0]["content"]
        assert result[-1]["content"] == "msg 39"

    def test_keeps_recent_messages(self) -> None:
        msgs = [{"role": "user", "content": f"msg {i}"} for i in range(35)]
        result = _compact_history(msgs)
        recent = result[1:]
        assert len(recent) == COMPACTION_KEEP_RECENT
        assert recent[-1]["content"] == "msg 34"


class TestSessionPersistence:
    """Verify session save/resume."""

    def test_save_and_resume(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.commands.chat_commands.SESSIONS_DIR", tmp_path)  # type: ignore[arg-type]
        monkeypatch.setattr("neo.commands.chat_commands.ensure_systemr_home", lambda: None)

        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
        ]
        _save_session(42, messages)

        session_file = tmp_path / "last_session.json"  # type: ignore[operator]
        assert session_file.exists()
        data = json.loads(session_file.read_text())
        assert data["session_id"] == 42
        assert len(data["messages"]) == 2

    def test_resume_no_session(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.commands.chat_commands.SESSIONS_DIR", tmp_path)  # type: ignore[arg-type]
        monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

        store = LocalStore()
        messages, _ = _try_resume_session(store)
        assert messages == []

    def test_resume_with_session(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.commands.chat_commands.SESSIONS_DIR", tmp_path)  # type: ignore[arg-type]
        monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

        session_file = tmp_path / "last_session.json"  # type: ignore[operator]
        session_file.write_text(json.dumps({
            "session_id": 99,
            "messages": [{"role": "user", "content": "previous"}],
        }))

        store = LocalStore()
        messages, session_id = _try_resume_session(store)
        assert len(messages) == 1
        assert messages[0]["content"] == "previous"
        assert session_id == 99


class TestSlashCommands:
    """Verify slash command handling."""

    def test_exit_commands(self) -> None:
        for cmd in ("/q", "/quit", "/exit"):
            assert _handle_slash_command(cmd, [], None) == "exit"

    def test_clear(self) -> None:
        assert _handle_slash_command("/clear", [], None) == "clear"

    def test_help_returns_empty(self) -> None:
        assert _handle_slash_command("/help", [], None) == ""

    def test_fast_sets_haiku(self) -> None:
        result = _handle_slash_command("/fast", [], None)
        assert result is not None
        assert result.startswith("model:")
        assert "haiku" in result

    def test_deep_sets_opus(self) -> None:
        result = _handle_slash_command("/deep", [], None)
        assert result is not None
        assert result.startswith("model:")
        assert "opus" in result

    def test_model_show(self) -> None:
        result = _handle_slash_command("/model", [], "claude-sonnet")
        assert result == ""

    def test_model_set(self) -> None:
        result = _handle_slash_command("/model claude-opus-4-6", [], None)
        assert result == "model:claude-opus-4-6"

    def test_unknown_passthrough(self) -> None:
        result = _handle_slash_command("/gibberish", [], None)
        assert result is None

    def test_permissions_show(self) -> None:
        result = _handle_slash_command("/permissions", [], None)
        assert result == ""

    def test_permissions_set(self) -> None:
        result = _handle_slash_command("/permissions paper", [], None)
        assert result == ""
        # Reset to standard
        _handle_slash_command("/permissions standard", [], None)

    def test_memory_search(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        (memory_dir / "notes.md").write_text("TSLA support at $192\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.commands.chat_commands.search_memory",
                            lambda q, **kw: [{"file": "notes.md", "line": "1", "content": "TSLA support at $192"}])
        result = _handle_slash_command("/memory TSLA", [], None)
        assert result == ""

    def test_cron_list_empty(self, tmp_path: object, monkeypatch: object) -> None:
        from pathlib import Path
        monkeypatch.setattr("neo.cron.JOBS_FILE", tmp_path / "nonexistent_cron.json")  # type: ignore[arg-type]
        result = _handle_slash_command("/cron list", [], None)
        assert result == ""

    def test_all_commands_documented(self) -> None:
        expected = {
            "/help", "/clear", "/q", "/model", "/fast", "/deep",
            "/profile", "/rules", "/morning", "/eod", "/plan",
            "/credits", "/remember", "/portfolio", "/risk",
            "/memory", "/permissions", "/cron",
        }
        assert expected.issubset(set(LOCAL_COMMANDS.keys()))
