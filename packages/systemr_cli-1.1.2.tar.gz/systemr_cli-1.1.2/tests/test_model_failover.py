"""Tests for neo.model_failover — model failover chain with cooldowns."""

import time

from neo.model_failover import (
    DEFAULT_COOLDOWN_SECONDS,
    FailoverChain,
    ModelCooldown,
    load_failover_chain,
)


class TestModelCooldown:
    """Per-model cooldown tracking."""

    def test_initial_state_is_available(self) -> None:
        cd = ModelCooldown(model="claude")
        assert cd.is_cooled_down

    def test_failure_sets_cooldown(self) -> None:
        cd = ModelCooldown(model="claude")
        cd.record_failure()
        assert not cd.is_cooled_down
        assert cd.error_count == 1

    def test_success_resets_cooldown(self) -> None:
        cd = ModelCooldown(model="claude")
        cd.record_failure()
        cd.record_success()
        assert cd.is_cooled_down
        assert cd.error_count == 0

    def test_exponential_backoff(self) -> None:
        cd = ModelCooldown(model="claude")
        cd.record_failure()  # 60s
        first_cooldown = cd.cooldown_until - cd.failed_at
        cd.record_failure()  # 120s
        second_cooldown = cd.cooldown_until - cd.failed_at
        assert second_cooldown > first_cooldown

    def test_cooldown_capped_at_max(self) -> None:
        cd = ModelCooldown(model="claude")
        for _ in range(20):  # Many failures
            cd.record_failure()
        actual_cooldown = cd.cooldown_until - cd.failed_at
        assert actual_cooldown <= 900.0  # MAX_COOLDOWN_SECONDS


class TestFailoverChain:
    """Model selection with fallback."""

    def test_returns_primary_when_healthy(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt", "haiku"])
        assert chain.get_model() == "claude"

    def test_returns_pinned_model(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt"])
        chain.pinned_model = "gpt"
        assert chain.get_model() == "gpt"

    def test_failover_on_primary_cooldown(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt", "haiku"])
        chain.on_failure("claude")
        model = chain.get_model()
        assert model == "gpt"

    def test_failover_cascades(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt", "haiku"])
        chain.on_failure("claude")
        chain.on_failure("gpt")
        model = chain.get_model()
        assert model == "haiku"

    def test_all_failed_returns_primary(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt"])
        chain.on_failure("claude")
        chain.on_failure("gpt")
        model = chain.get_model()
        # Should still return primary as best effort
        assert model == "claude"

    def test_success_pins_model(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt"])
        chain.on_failure("claude")
        chain.on_success("gpt")
        assert chain.pinned_model == "gpt"
        assert chain.get_model() == "gpt"

    def test_failure_unpins_model(self) -> None:
        chain = FailoverChain(primary="claude", fallbacks=["gpt"])
        chain.pinned_model = "claude"
        chain.on_failure("claude")
        assert chain.pinned_model is None


class TestLoadFailoverChain:
    """Configuration loading."""

    def test_load_with_config(self, tmp_path: object, monkeypatch: object) -> None:
        import json
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        config_file.write_text(json.dumps({
            "model": {
                "primary": "anthropic.claude-opus-4-6",
                "fallbacks": ["anthropic.claude-sonnet-4-6"],
            }
        }))
        monkeypatch.setattr("neo.model_failover.CONFIG_FILE", config_file)

        chain = load_failover_chain()
        assert chain.primary == "anthropic.claude-opus-4-6"
        assert "anthropic.claude-sonnet-4-6" in chain.fallbacks

    def test_load_without_config(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.model_failover.CONFIG_FILE", tmp_path / "nope.json")  # type: ignore[arg-type]

        chain = load_failover_chain()
        assert chain.primary != ""  # Should have a default
        assert isinstance(chain.fallbacks, list)
