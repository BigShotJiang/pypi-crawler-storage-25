"""Tests for neo.auth."""

import json
import time
from pathlib import Path

from neo.auth import AuthManager, AuthToken


def test_auth_token_expired():
    token = AuthToken("abc", None, "test@test.com", time.time() - 100)
    assert token.is_expired()


def test_auth_token_valid():
    token = AuthToken("abc", None, "test@test.com", time.time() + 3600)
    assert not token.is_expired()


def test_auth_token_roundtrip():
    token = AuthToken("abc", "refresh123", "test@test.com", 1700000000.0)
    d = token.to_dict()
    restored = AuthToken.from_dict(d)
    assert restored.access_token == token.access_token
    assert restored.refresh_token == token.refresh_token
    assert restored.email == token.email
    assert restored.expires_at == token.expires_at


def test_auth_manager_save_load(tmp_path, monkeypatch):
    auth_file = tmp_path / "auth.json"
    monkeypatch.setattr("neo.auth.AUTH_FILE", auth_file)
    monkeypatch.setattr("neo.auth.ensure_neo_home", lambda: None)

    mgr = AuthManager()
    token = AuthToken("tok123", "ref456", "user@example.com", time.time() + 3600)
    mgr.save(token)

    assert auth_file.exists()
    # Verify permissions (0600)
    assert oct(auth_file.stat().st_mode)[-3:] == "600"

    mgr2 = AuthManager()
    monkeypatch.setattr("neo.auth.AUTH_FILE", auth_file)
    loaded = mgr2.load()
    assert loaded is not None
    assert loaded.email == "user@example.com"


def test_auth_manager_clear(tmp_path, monkeypatch):
    auth_file = tmp_path / "auth.json"
    auth_file.write_text("{}")
    monkeypatch.setattr("neo.auth.AUTH_FILE", auth_file)

    mgr = AuthManager()
    mgr.clear()
    assert not auth_file.exists()
