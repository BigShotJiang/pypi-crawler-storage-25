"""Tests for neo.streaming — SSE client and chat request."""


from neo.streaming import (
    SSEEvent,
    ChatRequest,
    MAX_HISTORY_MESSAGES,
    STREAM_TIMEOUT_SECONDS,
    CHAT_STREAM_PATH,
    CHAT_BLOCKING_PATH,
    CHAT_CONFIRM_PATH,
    TOOL_CALL_PATH,
)


class TestSSEEvent:
    """Verify SSE event parsing."""

    def test_parses_json(self) -> None:
        event = SSEEvent(event="text_delta", data='{"text": "hello"}')
        assert event.parsed["text"] == "hello"

    def test_handles_invalid_json(self) -> None:
        event = SSEEvent(event="text_delta", data="not json")
        assert event.parsed["text"] == "not json"

    def test_handles_empty_data(self) -> None:
        event = SSEEvent(event="done", data="")
        assert event.parsed == {}

    def test_with_id(self) -> None:
        event = SSEEvent(event="text_delta", data='{"text": "hi"}', id="evt-42")
        assert event.id == "evt-42"
        assert event.parsed["text"] == "hi"

    def test_multiline_data_pre_joined(self) -> None:
        """Multi-line data should be kept as-is when pre-joined."""
        data = '{"text": "line1\\nline2"}'
        event = SSEEvent(event="text_delta", data=data)
        assert "line1" in event.parsed["text"]

    def test_confirmation_required_event(self) -> None:
        """confirmation_required events should parse tool and token."""
        data = '{"tool": "place_order", "confirmation_token": "tok-123", "details": {}}'
        event = SSEEvent(event="confirmation_required", data=data)
        assert event.parsed["tool"] == "place_order"
        assert event.parsed["confirmation_token"] == "tok-123"


class TestChatRequest:
    """Verify request serialization."""

    def test_minimal(self) -> None:
        req = ChatRequest(user_input="buy TSLA")
        d = req.to_dict()
        assert d["user_input"] == "buy TSLA"
        assert d["research_mode"] is False
        assert "model" not in d
        assert "history" not in d
        assert "session_id" not in d

    def test_full(self) -> None:
        req = ChatRequest(
            user_input="buy TSLA 2% risk",
            session_id="sess-123",
            model="claude-sonnet",
            history=[
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
            ],
            profile="# Trader Profile\n...",
            rules="# Trading Rules\n...",
            research_mode=True,
        )
        d = req.to_dict()
        assert d["user_input"] == "buy TSLA 2% risk"
        assert d["session_id"] == "sess-123"
        assert d["model"] == "claude-sonnet"
        assert len(d["history"]) == 2
        assert d["context"] == "# Trader Profile\n..."
        assert d["rules"] == "# Trading Rules\n..."
        assert d["research_mode"] is True

    def test_truncates_history(self) -> None:
        """History should be limited to MAX_HISTORY_MESSAGES."""
        long_history = [{"role": "user", "content": f"msg {i}"} for i in range(30)]
        req = ChatRequest(user_input="latest", history=long_history)
        d = req.to_dict()
        assert len(d["history"]) == MAX_HISTORY_MESSAGES
        assert d["history"][0]["content"] == f"msg {30 - MAX_HISTORY_MESSAGES}"
        assert d["history"][-1]["content"] == "msg 29"

    def test_no_empty_fields(self) -> None:
        """None profile/rules should not be sent."""
        req = ChatRequest(user_input="test", profile=None, rules=None)
        d = req.to_dict()
        assert "context" not in d
        assert "rules" not in d

    def test_daily_context_merges_with_profile(self) -> None:
        """daily_context should merge with profile into context field."""
        req = ChatRequest(
            user_input="test",
            profile="# Profile",
            daily_context="# Trading Log — 2026-03-27",
        )
        d = req.to_dict()
        assert "# Profile" in d["context"]
        assert "# Trading Log" in d["context"]
        assert "---" in d["context"]  # Separator

    def test_daily_context_alone(self) -> None:
        """daily_context without profile should still appear in context."""
        req = ChatRequest(user_input="test", daily_context="# Today's log")
        d = req.to_dict()
        assert d["context"] == "# Today's log"

    def test_daily_context_none_no_context(self) -> None:
        """No profile and no daily_context means no context field."""
        req = ChatRequest(user_input="test")
        d = req.to_dict()
        assert "context" not in d


class TestConstants:
    """Verify configurable constants are defined and reasonable."""

    def test_values(self) -> None:
        assert MAX_HISTORY_MESSAGES == 20
        assert STREAM_TIMEOUT_SECONDS > 0
        assert CHAT_STREAM_PATH.startswith("/")
        assert CHAT_BLOCKING_PATH.startswith("/")
        assert CHAT_CONFIRM_PATH.startswith("/")
        assert TOOL_CALL_PATH == "/v1/tools/call"
