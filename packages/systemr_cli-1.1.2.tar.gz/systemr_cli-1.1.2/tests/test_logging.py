"""Tests for neo.logging — structured logging configuration."""

from neo.logging import configure_logging, get_logger


def test_configure_logging_debug():
    """Debug mode should configure without error."""
    configure_logging(debug=True)
    log = get_logger(module="test")
    # Should not raise
    log.info("test_event", key="value")


def test_configure_logging_production():
    """Production mode should configure without error."""
    configure_logging(debug=False)
    log = get_logger(module="test")
    log.info("test_event", key="value")


def test_get_logger_with_context():
    """Logger should accept initial context."""
    configure_logging(debug=True)
    log = get_logger(component="auth", version="0.1.0")
    # Should not raise
    log.info("context_test")
