"""Tests for neo.hooks — event automation system."""

import json

from neo.hooks import (
    HookEvent,
    fire_hook,
    register_hook,
    list_hooks,
)


class TestFireHook:
    """Verify hook execution."""

    def test_no_config(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", tmp_path / "config.json")  # type: ignore[arg-type]
        outputs = fire_hook(HookEvent.PRE_TRADE)
        assert outputs == []

    def test_executes_command(self, tmp_path: object, monkeypatch: object) -> None:
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        config_file.write_text(json.dumps({
            "hooks": {
                "PreTrade": [{"command": "echo 'hook fired'"}],
            },
        }))
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", config_file)

        outputs = fire_hook(HookEvent.PRE_TRADE)
        assert len(outputs) == 1
        assert "hook fired" in outputs[0]

    def test_passes_context(self, tmp_path: object, monkeypatch: object) -> None:
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        config_file.write_text(json.dumps({
            "hooks": {
                "PostTrade": [{"command": "echo $SYSTEMR_HOOK_CONTEXT"}],
            },
        }))
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", config_file)

        outputs = fire_hook(HookEvent.POST_TRADE, context={"symbol": "TSLA"})
        assert len(outputs) == 1
        assert "TSLA" in outputs[0]

    def test_timeout_doesnt_block(self, tmp_path: object, monkeypatch: object) -> None:
        """Hooks that hang should timeout without blocking."""
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        config_file.write_text(json.dumps({
            "hooks": {
                "Error": [{"command": "sleep 20"}],
            },
        }))
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", config_file)
        monkeypatch.setattr("neo.hooks._HOOK_TIMEOUT_SECONDS", 1)

        outputs = fire_hook(HookEvent.ERROR)
        assert outputs == []

    def test_empty_command_skipped(self, tmp_path: object, monkeypatch: object) -> None:
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        config_file.write_text(json.dumps({
            "hooks": {
                "PreSession": [{"command": ""}],
            },
        }))
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", config_file)

        outputs = fire_hook(HookEvent.PRE_SESSION)
        assert outputs == []


class TestRegisterAndList:
    """Verify hook registration and listing."""

    def test_register_and_list(self, tmp_path: object, monkeypatch: object) -> None:
        config_file = tmp_path / "config.json"  # type: ignore[operator]
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", config_file)

        register_hook(HookEvent.POST_TRADE, "echo 'trade done'")
        register_hook(HookEvent.PRE_SESSION, "echo 'starting'")

        hooks = list_hooks()
        assert "PostTrade" in hooks
        assert len(hooks["PostTrade"]) == 1
        assert hooks["PostTrade"][0]["command"] == "echo 'trade done'"
        assert "PreSession" in hooks

    def test_list_empty(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.hooks.CONFIG_FILE", tmp_path / "config.json")  # type: ignore[arg-type]
        hooks = list_hooks()
        assert hooks == {}


class TestHookEvents:
    """Verify all event types are valid."""

    def test_all_events_have_string_values(self) -> None:
        for event in HookEvent:
            assert isinstance(event.value, str)
            assert len(event.value) > 0

    def test_event_types_count(self) -> None:
        # 8 original + 2 new (BEFORE_TOOL_CALL, COMPACT_BEFORE)
        assert len(HookEvent) == 10
