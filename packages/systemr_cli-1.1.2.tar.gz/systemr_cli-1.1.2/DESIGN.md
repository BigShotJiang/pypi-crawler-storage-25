# System R CLI — Design Document

> The trading operating system in your terminal.
> One command. One conversation. Full control.

**Version:** 1.0
**Date:** 2026-03-27
**Authors:** Ashim Nandi (Founder), Shannon (Co-Founder)
**Status:** APPROVED — Build starts now

---

## 1. Vision

System R CLI is a terminal-native trading operating system modeled after Claude Code.
A trader installs it, types `systemr`, and talks to their portfolio. No code.
No dashboards. No complexity. Just a conversation backed by 55 institutional-grade
trading tools, 25 broker connections, and a risk engine that never sleeps.

The same backend that powers agents.systemr.ai — now with a human face.

---

## 2. Design Principles

These are non-negotiable. Derived from System R's build protocol.

1. **Capital preservation first.** Every action touching money requires explicit confirmation.
   No auto-execution. Ever.
2. **Mathematical integrity.** `decimal.Decimal` for all financial values. Never float.
3. **Radical honesty.** System R shows its thinking. No black boxes. The trader sees
   every step, every tool call, every risk check.
4. **User sovereignty.** The trader sets the rules. System R enforces them.
   It will refuse a trade that violates the trader's own rules, even if explicitly asked.
5. **Model agnosticism.** Claude, GPT, or any qualified model via Bedrock.
   System R's value is the domain layer, not the LLM.
6. **Local-first data.** Profiles, memory, journal, conversation history — all stored
   as local files on the trader's machine. No cloud lock-in.
7. **Additive-only builds.** Never remove or rename existing working code.
   New features extend, they don't replace.

---

## 3. Architecture

```
┌─────────────────────────────────────────────────────┐
│                    TRADER                            │
│                      │                              │
│                 types message                        │
│                      │                              │
│                      ▼                              │
│  ┌─────────────────────────────────────────────┐    │
│  │            SYSTEM R CLI                      │    │
│  │                                              │    │
│  │  Terminal UI (Rich + Textual)                 │    │
│  │  ├── Chat loop (streaming render)            │    │
│  │  ├── Trade confirmation flow                 │    │
│  │  ├── Slash command router                    │    │
│  │  ├── Keyboard shortcut handler               │    │
│  │  └── Rich card renderer                      │    │
│  │                                              │    │
│  │  Local Storage (~/.systemr/)                  │    │
│  │  ├── PROFILE.md (auto-loaded)                │    │
│  │  ├── memory/ (MEMORY.md index + files)       │    │
│  │  ├── journal/ (trade journal, SQLite)        │    │
│  │  ├── sessions/ (conversation history)        │    │
│  │  └── config.json (broker keys, preferences)  │    │
│  └──────────────────┬──────────────────────────┘    │
│                      │                              │
│              POST /api/v1/agent/chat/stream          │
│                      │                              │
│                      ▼                              │
│  ┌─────────────────────────────────────────────┐    │
│  │         agents.systemr.ai (Backend)          │    │
│  │                                              │    │
│  │  AgentOrchestrator                           │    │
│  │  ├── BedrockLLMAdapter (Claude/GPT/Nova)     │    │
│  │  ├── NEO Constitution (system prompt)        │    │
│  │  ├── IntentRouter (classify → route)         │    │
│  │  ├── ToolRegistry (55 MCP tools)             │    │
│  │  ├── 25 Broker Adapters                      │    │
│  │  ├── Risk Engine (Iron Fist)                 │    │
│  │  └── Memory + Behavioral Analysis            │    │
│  └─────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────┘
```

### 3.1 The Agentic Loop

The core of System R CLI. Not request/response — a loop that thinks, acts,
observes, and iterates until the task is complete.

```
User message
    │
    ▼
Backend receives message + history + profile context
    │
    ▼
Claude (via Bedrock) with 55 tool definitions
    │
    ├── Decides which tools to call
    │   (e.g., get_quote → get_account → calculate_position_size → pre_trade_risk_check)
    │
    ├── Executes tools, feeds results back to Claude
    │
    ├── Claude may call MORE tools based on results
    │   (e.g., risk check fails → reduce size → re-check)
    │
    └── Claude formulates human response
        │
        ▼
    Streamed back to CLI via SSE
        │
        ▼
    CLI renders: thinking steps → tool calls → final response → confirmation if needed
```

### 3.2 Multi-Agent Orchestration

For complex tasks, the main agent spawns focused sub-agents in parallel.
Each sub-agent gets a subset of tools and a focused system prompt.

```
"start my day"
    │
    Main Agent decides: spawn 4 sub-agents
    │
    ├── Portfolio Agent    (tools: positions, balance, exposure)
    ├── Market Agent       (tools: quotes, sectors, macro, news)
    ├── Risk Agent         (tools: risk metrics, correlation, drawdown)
    └── Watchlist Agent    (tools: quotes, technicals, regime detection)
    │
    All run via asyncio.gather — parallel Bedrock calls
    │
    Main Agent synthesizes results into morning briefing
```

Sub-agent roster:

| Agent | Tools Subset | Trigger |
|---|---|---|
| Portfolio Scanner | positions, balance, exposure | /morning, portfolio questions |
| Market Analyst | quotes, sectors, macro, calendar | /morning, market questions |
| Risk Calculator | risk metrics, correlation, drawdown, Monte Carlo | Pre-trade, /risk |
| Watchlist Scanner | quotes, technicals, regime detection | /scan, setup hunting |
| Trade Executor | position sizing, pre-trade check, order placement | Trade execution |
| Journal Writer | journal CRUD, trade logging | Post-trade |
| Strategy Analyst | backtest, performance stats, win rate | /eod, strategy questions |

---

## 4. CLI Aesthetics & Branding

### 4.1 Brand Identity in Terminal

The CLI inherits System R's established design language.
Dark. Precise. Institutional. Green accent on black.

**NOT** a "fun" trading app. This is a professional operating system.

### 4.2 Color Palette

All colors from the canonical System R theme (`#3ECF8E` green family).

```python
# Brand colors — canonical, do not modify
SR_GREEN       = "#3ECF8E"    # Primary accent — success, active, emphasis
SR_GREEN_DIM   = "#34B87A"    # Secondary accent — labels, borders
SR_BG          = "#09090B"    # Terminal background
SR_WHITE       = "#F5F5F5"    # Primary text — values, data, emphasis
SR_GRAY        = "#A1A1AA"    # Secondary text — labels, descriptions
SR_DIM         = "#52525B"    # Tertiary text — timestamps, hints
SR_MUTED       = "#3F3F46"    # Borders, separators, disabled
SR_RED         = "#EF4444"    # Errors, losses, short positions
SR_AMBER       = "#F59E0B"    # Warnings, caution states
SR_BLUE        = "#3B82F6"    # Info, neutral indicators
```

### 4.3 Typography Rules

- **Terminal monospace** — no custom fonts, use the trader's terminal font
- **Numbers are sacred** — always right-aligned, always formatted:
  - Prices: `$1,234.56` (comma-separated, 2 decimal)
  - Percentages: `+2.34%` or `-1.20%` (signed, 2 decimal)
  - R-multiples: `+2.30R` (signed, 2 decimal, suffixed)
  - Risk amounts: `$1,046.00` (full precision)
  - Quantities: `1,200` (comma-separated, no decimal)
- **Green for positive, red for negative** — universal, no exceptions
- **Labels in gray, values in white** — consistent hierarchy
- **UPPERCASE for section headers** — `PORTFOLIO`, `RISK`, `TRADE READY`

### 4.4 Layout Patterns

**Banner (shown on launch):**
```
  SYSTEM R
  Trading operating system

  ● connected  ashim@systemr.ai        $52,340
```

Minimal. Name. Description. Status. Balance. Nothing else.

**Chat messages:**

User input:
```
  you > buy TSLA 2% risk
```

System R thinking (streaming, visible):
```
  ◐ Checking TSLA price...
  ◐ Reading account balance...
  ◐ Calculating position size...
  ◐ Running pre-trade risk check...  ✓
```

System R response (Rich Panel):
```
  ┌─ SYSTEM R ─────────────────────────────────────┐
  │                                                 │
  │  TSLA @ $198.50                                 │
  │                                                 │
  │  Position:  160 shares × $198.50 = $31,760.00   │
  │  Risk:      $1,046.80 (1.97%)                   │
  │  Stop:      $192.00                             │
  │  Target:    $215.00 (+8.3%)                     │
  │  R:R:       1 : 2.5                             │
  │                                                 │
  └─────────────────────────────────────────────────┘

  Place this trade? [y/n]
```

**Diff view (trade modifications):**
```
  ┌─ MODIFICATION ──────────────────────────────────┐
  │  TSLA Long — 160 shares                         │
  │                                                  │
  │  Stop:    $192.00  →  $195.00                    │
  │  Risk:    $1,046   →  $560                       │
  │  R:R:     1:2.3    →  1:3.8                      │
  │                                                  │
  │  [confirm]  [cancel]                             │
  └──────────────────────────────────────────────────┘
```

**Status bar (persistent, bottom of screen):**
```
  AAPL +1.2%  ·  MSFT +0.4%  ·  P&L +$340  ·  Risk 3.2%/6%  ·  12.4 credits
```

**Separators:**
```
  ────────────────────────────────────────────────
```
48 thin dashes in `SR_MUTED`. No box drawing. Clean.

### 4.5 Indicators

| State | Display |
|---|---|
| Thinking/loading | `◐` spinning + `SR_GREEN_DIM` text |
| Success | `✓` in `SR_GREEN` |
| Error | `✗` in `SR_RED` |
| Warning | `!` in `SR_AMBER` |
| Info | `●` in `SR_BLUE` |
| Connected | `●` in `SR_GREEN` + `connected` |
| Disconnected | `○` in `SR_RED` + `not connected` |

---

## 5. Feature Specification

### 5.1 Core — P0 (Sessions 1-3)

#### 5.1.1 Chat Loop with Streaming

The primary interface. User types, System R responds via SSE stream.

- Connect to `POST /api/v1/agent/chat/stream`
- Render SSE events in real-time:
  - `thinking` → show thinking indicator with step text
  - `action` → show tool being called (e.g., "Checking TSLA price...")
  - `text_delta` → stream response text character by character
  - `done` → finalize response, check if confirmation needed
  - `error` → display error in red, suggest recovery
- Maintain conversation history locally (last 20 messages sent with each request)
- Support `research_mode: true` for market-enriched responses
- Multi-model: pass `model` field, support switching via `/model`

#### 5.1.2 Agentic Tool Execution

Claude decides which of 55 tools to call. The backend executes them.
The CLI shows each step as it happens:

```
  ◐ get_quote(symbol="TSLA")                    ✓  $198.50
  ◐ get_account_balance()                        ✓  $52,340
  ◐ calculate_position_size(risk_pct=0.02, ...)  ✓  160 shares
  ◐ pre_trade_risk_check(...)                    ✓  PASS
```

Each tool call visible. Each result shown. Radical honesty.

#### 5.1.3 Trade Confirmation Flow

**Mandatory for any action that touches money.**

Confirmation levels:

| Action | Level | Display |
|---|---|---|
| Place order | CONFIRM | Full trade card + `[y/n]` |
| Cancel order | CONFIRM | Order details + `[y/n]` |
| Modify order | CONFIRM | Diff view + `[confirm/cancel]` |
| Connect broker | CONFIRM | Broker name + credential prompt |
| Kill switch | DOUBLE CONFIRM | Warning + `type KILL to confirm` |
| Read-only (quotes, analysis) | AUTO | No confirmation needed |
| Calculations (sizing, risk) | AUTO | No confirmation needed |

Kill switch double confirmation:
```
  ⚠  KILL SWITCH — This will close ALL open positions.

  Open positions:
    AAPL  160 shares  +$240
    MSFT   80 shares  +$100
    TSLA  120 shares  -$52

  Type KILL to confirm:
```

#### 5.1.4 Multi-Agent (Parallel Execution)

Backend spawns parallel Bedrock calls via `asyncio.gather`.
CLI shows all agents working simultaneously:

```
  ◐ Portfolio Scanner...    ✓
  ◐ Market Analyst...       ✓
  ◐ Risk Calculator...      ◐ running
  ◐ Watchlist Scanner...    ✓
```

Results synthesized by main agent into unified response.

### 5.2 Interface — P1 (Sessions 4-6)

#### 5.2.1 Terminal UI (Rich + Textual)

Built with Python `Rich` for rendering and `Textual` for the TUI framework.
Matches 90%+ of Claude Code's visual quality.

Components:
- **Chat panel** — scrollable message history with rich cards
- **Input bar** — bottom of screen, prompt-toolkit with history + autocomplete
- **Status bar** — persistent bottom line with portfolio state + credits
- **Trade cards** — Rich Panels with formatted data (see §4.4)
- **Progress indicators** — spinners for thinking, checkmarks for complete
- **Tables** — kv-tables for single items, data-tables for lists

#### 5.2.2 Slash Commands

| Command | Description | Agent Spawned |
|---|---|---|
| `/morning` | Full morning briefing | Portfolio + Market + Risk + Watchlist |
| `/eod` | End of day review + journal | Strategy Analyst + Journal Writer |
| `/portfolio` | Current positions + P&L | Portfolio Scanner |
| `/risk` | Risk exposure dashboard | Risk Calculator |
| `/scan [SYMBOL]` | Scan for setups | Watchlist Scanner |
| `/plan` | Plan today's trades | Market + Risk → Plan |
| `/journal` | Open trade journal | Local (no agent) |
| `/connect` | Connect/switch broker | Interactive flow |
| `/kill` | Emergency close all | Trade Executor (double confirm) |
| `/replay TRADE_ID` | Replay past trade analysis | Strategy Analyst |
| `/credits` | Show compute credits | Local (token-status endpoint) |
| `/model [MODEL]` | Switch LLM model | Local config change |
| `/fast` | Switch to fast model (Haiku) | Local config change |
| `/deep` | Switch to deep model (Opus) | Local config change |
| `/export` | Export journal to CSV/JSON | Local |
| `/clear` | Clear conversation | Local |
| `/help` | Show all commands | Local |

#### 5.2.3 Extended Thinking Display

When System R reasons through a complex request, the thinking is visible:

```
  thinking...

  The trader wants to buy TSLA with 2% risk. I need to:
  1. Get the current TSLA price
  2. Check their account balance
  3. They didn't specify a stop loss — I'll use the nearest
     technical support level from price_structure analysis
  4. Calculate position size with the G formula
  5. Run pre-trade risk check against their portfolio
```

Displayed in `SR_DIM` color. Collapsible after response completes.
Maps to the `thinking` SSE event from the backend.

#### 5.2.4 Keyboard Shortcuts

| Key | Action |
|---|---|
| `Ctrl+K` | Command palette (fuzzy search all commands) |
| `Ctrl+P` | Quick portfolio view |
| `Ctrl+R` | Risk dashboard |
| `Ctrl+X` | Kill switch (with double confirm) |
| `Escape` | Cancel current operation / close panel |
| `↑` / `↓` | Navigate message history |
| `Tab` | Autocomplete ticker symbols |
| `Ctrl+C` | Interrupt current stream |
| `Ctrl+D` | Exit System R |

### 5.3 Persistence — P1 (Session 7)

#### 5.3.1 Local File Structure

```
~/.systemr/
├── config.json              # Broker connections, preferences, model choice
├── auth.json                # Auth tokens (chmod 600)
├── PROFILE.md               # Auto-loaded every session
├── RULES.md                 # Trading rules (auto-enforced)
├── memory/
│   ├── MEMORY.md            # Index file — auto-loaded
│   ├── trading_rules.md     # "Never risk more than 2%"
│   ├── tsla_notes.md        # "Support at $192, broke out at $200"
│   └── lessons.md           # "Wait for confirmation candle on NVDA"
├── journal/
│   └── journal.db           # SQLite — trades, sessions, messages
└── sessions/
    ├── 2026-03-27_morning.json
    └── 2026-03-27_afternoon.json
```

#### 5.3.2 PROFILE.md (Auto-loaded)

Created on first run via conversational onboarding. Auto-loaded every session.
System R reads this before every LLM call and injects it as context.

```markdown
# Trader Profile

## Identity
- Name: Ashim
- Style: Momentum swing trading
- Timeframe: 2-5 day holds
- Experience: Advanced

## Risk Parameters
- Max risk per trade: 2%
- Max daily loss: 5%
- Max open positions: 5
- Max sector exposure: 30%

## Rules (ENFORCED — System R will refuse violations)
- No earnings plays
- No Friday overnight holds
- No averaging down on losers
- Always use stop losses

## Broker
- Primary: Alpaca
- Account: $52,340 (last synced 2026-03-27)

## Preferences
- Default model: claude-sonnet
- Research mode: on
- Thinking display: visible
- Credit alerts: below 50 OSR
```

#### 5.3.3 MEMORY.md (Claude Code Pattern)

Same architecture as Claude Code's memory system.
Index file auto-loaded. Individual memory files referenced by topic.

```markdown
# Trading Memory

- [TSLA patterns](tsla_notes.md) — support levels, breakout behavior, position history
- [Risk lessons](lessons.md) — learned from past trades, what to avoid
- [Sector notes](sectors.md) — current sector rotation thesis
- [Earnings calendar](earnings.md) — upcoming dates for watchlist
```

System R writes memories automatically after significant events:
- After a trade closes: saves outcome + lesson if R < -1
- After a rule violation attempt: saves what was blocked and why
- After a notable market event: saves context for future reference
- When the trader explicitly says "remember this"

#### 5.3.4 RULES.md (Auto-enforced)

The trader's rules, enforced by System R at the pre-trade gate.
If a trade violates any rule, System R refuses and explains why.

```markdown
# Trading Rules

## Hard Rules (NEVER override)
- Max 2% risk per trade
- Max 5% daily loss — kill switch triggers automatically
- Always set a stop loss before entry
- No position larger than 20% of account

## Soft Rules (warn but allow override)
- Prefer R:R above 1:2
- Reduce size by 50% on Fridays
- No new positions 30 min before close
```

### 5.4 Polish — P1 (Session 8)

#### 5.4.1 Installation

Three methods, widest to narrowest audience:

```bash
# Method 1: pip (developers)
pip install systemr-cli

# Method 2: brew (Mac users)
brew install systemr

# Method 3: one-liner (everyone)
curl -fsSL https://systemr.ai/install.sh | sh
```

The brew formula and install script package Python in a standalone bundle
(via PyInstaller or shiv) so the end user does not need Python installed.

Entry point: `systemr` command.

#### 5.4.2 First Run Experience

```
  SYSTEM R
  Trading operating system

  Welcome. Let's set up your profile.

  What's your trading style?
  (e.g., day trading, swing trading, position trading)
> swing trading, momentum setups, 2-5 day holds

  What's your risk tolerance per trade?
  (e.g., 1%, 2%, 3% of account)
> 2%

  What broker do you use?
  (e.g., Alpaca, Interactive Brokers, Schwab)
> alpaca

  Enter your Alpaca API key: ********
  Enter your Alpaca secret key: ********

  ● Connected. Account: $52,340 | Buying Power: $104,680

  Any hard rules I should enforce?
  (e.g., no earnings plays, always use stops)
> no earnings, no friday overnight, always use stops

  ✓ Profile saved to ~/.systemr/PROFILE.md
  ✓ Rules saved to ~/.systemr/RULES.md
  ✓ Broker connected and verified

  You're ready. Type anything to start, or /help for commands.
>
```

Conversational. No forms. No config files to edit manually.
Everything saved as readable markdown the trader can inspect and modify.

#### 5.4.3 Credit Tracking

Every response includes credit cost. Session totals tracked.

```
  ┌─ Session ─────────────────────────────┐
  │  Credits used:   12.4 OSR             │
  │  Tools called:   47                   │
  │  Trades placed:  3                    │
  │  Duration:       1h 23m              │
  │  Balance:        487.6 OSR remaining  │
  └───────────────────────────────────────┘
```

Low balance warning:
```
  ! Credits low: 23.1 OSR remaining.
    Top up at systemr.ai/credits
```

#### 5.4.4 Auto-Update Check

On launch, check PyPI for latest version. Non-blocking.

```
  System R v1.1.0 available (you have v1.0.0)
  Run: pip install --upgrade systemr-cli
```

---

## 6. Backend Changes Required

The existing backend at agents.systemr.ai already has almost everything.
Minimal changes needed:

### 6.1 Chat Endpoint Enhancements

The existing `POST /api/v1/agent/chat/stream` is the primary endpoint.
Changes needed:

1. **Profile injection** — Accept a `profile` field in the request body.
   The CLI sends the trader's PROFILE.md content. Backend injects it
   into the system prompt alongside the NEO Constitution.

2. **Rules injection** — Accept a `rules` field. Backend adds rules
   to the pre-trade validation layer so the risk engine enforces them,
   not just the LLM.

3. **Tool visibility events** — The SSE `action` events should include
   tool name + arguments + result summary so the CLI can render each step.

4. **Multi-agent endpoint** — New `POST /api/v1/agent/orchestrate` that
   accepts a list of sub-agent tasks, runs them via `asyncio.gather`,
   and streams results as they complete.

### 6.2 New Request Schema

```python
class CLIChatRequest(BaseModel):
    user_input: str
    session_id: Optional[str]
    model: Optional[str]
    history: Optional[List[Dict[str, str]]]  # last 20 messages
    profile: Optional[str]                    # PROFILE.md content
    rules: Optional[str]                      # RULES.md content
    research_mode: bool = False
    thinking_visible: bool = True             # stream thinking events
```

### 6.3 Auth for CLI

The CLI uses the existing `/api/auth/login` endpoint.
Token stored at `~/.systemr/auth.json` (chmod 600).
Auto-refresh on expiry via `/api/auth/refresh`.

---

## 7. Technology Stack

| Layer | Technology | Rationale |
|---|---|---|
| Language | Python 3.11+ | Same as backend, existing NEO code, Rich/Textual ecosystem |
| TUI framework | Textual | Full terminal app framework, built on Rich, active development |
| Rich rendering | Rich | Markdown, panels, tables, progress, syntax highlighting |
| Input handling | prompt-toolkit | History, autocomplete, key bindings, vi/emacs modes |
| HTTP client | httpx | Async, streaming SSE support, already a dependency |
| CLI framework | Click | Already used in NEO, group/subcommand pattern |
| Local storage | SQLite (stdlib) | Already used for journal, zero dependencies |
| Memory files | Markdown | Human-readable, editable, same as Claude Code |
| Package | Hatchling | Already used in NEO, modern Python packaging |
| Linter | Ruff | Already configured in NEO |
| Tests | pytest + pytest-asyncio | Already configured in NEO |

---

## 8. Build Plan

8 sessions. Each session = Ashim + Shannon working 2-4 hours.

### Session 1: Foundation
- [ ] Rename package: `neo-trader` → `systemr-cli`, command: `neo` → `systemr`
- [ ] Update `~/.neo/` → `~/.systemr/` directory structure
- [ ] Create PROFILE.md + RULES.md + MEMORY.md scaffolding
- [ ] Write the System R CLI system prompt (trading-specific, extends NEO Constitution)
- [ ] Update theme.py with full brand palette (§4.2)
- [ ] First-run onboarding flow (conversational profile setup)

### Session 2: Chat + Streaming
- [ ] Wire chat loop to `POST /api/v1/agent/chat/stream`
- [ ] SSE event parser (thinking, action, text_delta, done, error)
- [ ] Streaming text renderer (character-by-character display)
- [ ] Tool call visibility (show each tool as it executes)
- [ ] Conversation history management (local, send last 20 with each request)
- [ ] Multi-model support (pass model field, /model /fast /deep commands)
- [ ] Backend: add profile + rules fields to chat request schema

### Session 3: Multi-Agent + Research
- [ ] Backend: `/api/v1/agent/orchestrate` endpoint for parallel sub-agents
- [ ] Sub-agent definitions (7 agents with tool subsets)
- [ ] `/morning` command (spawns 4 agents, synthesizes briefing)
- [ ] Research mode integration (news/sentiment enrichment)
- [ ] Web search/fetch capability for real-time information

### Session 4: Terminal UI — Part 1
- [ ] Textual app shell (main screen layout)
- [ ] Chat panel with scrollable history
- [ ] Input bar with prompt-toolkit (history, autocomplete)
- [ ] Status bar (portfolio state, credits, connection)
- [ ] Rich card renderer (trade cards, portfolio cards, risk cards)

### Session 5: Terminal UI — Part 2
- [ ] Extended thinking display (collapsible thinking blocks)
- [ ] Diff view for trade modifications
- [ ] Table renderers (portfolio table, P&L table, risk matrix)
- [ ] Keyboard shortcuts (Ctrl+K palette, Ctrl+P portfolio, etc.)
- [ ] Ticker symbol autocomplete in input
- [ ] TradingView-style mini charts in terminal (if Textual supports)

### Session 6: Commands + Safety
- [ ] Slash command router (all commands from §5.2.2)
- [ ] Trade confirmation flow (single confirm + double confirm)
- [ ] Tool approval UI (show what's about to happen)
- [ ] `/plan` mode (pre-market planning flow)
- [ ] `/eod` review (end-of-day analysis + journal auto-entry)
- [ ] `/kill` with double confirmation
- [ ] Rule enforcement (RULES.md parsed, violations blocked)

### Session 7: Memory + Credits
- [ ] PROFILE.md auto-load on every session
- [ ] MEMORY.md index + individual memory files
- [ ] Auto-memory writes (post-trade lessons, blocked violations, notable events)
- [ ] "Remember this" explicit memory saves
- [ ] Credit tracking (per-response cost, session totals)
- [ ] `/credits` command with balance display
- [ ] Low-balance warnings

### Session 8: Polish + Ship
- [ ] First-run experience (full onboarding flow)
- [ ] Auto-update check on launch
- [ ] Error handling (network failures, auth expiry, rate limits)
- [ ] PyPI package (`pip install systemr-cli`)
- [ ] Brew formula (standalone binary via PyInstaller)
- [ ] Install script (`curl -fsSL systemr.ai/install.sh | sh`)
- [ ] README.md with full documentation
- [ ] 22+ existing tests updated + new tests for all features

---

## 9. Permission Model

Modeled after Claude Code. Trust through transparency.

| Category | Actions | Behavior |
|---|---|---|
| **READ** | Quotes, portfolio view, P&L, analysis, risk metrics | Auto-execute, no confirmation |
| **CALCULATE** | Position sizing, risk math, backtest, statistics | Auto-execute, no confirmation |
| **WRITE** | Journal entries, memory saves, profile updates | Auto-execute, local only |
| **TRADE** | Place order, cancel order, modify order | **ALWAYS CONFIRM** — show full details |
| **CONNECT** | Broker credentials, API keys | **ALWAYS CONFIRM** — sensitive data |
| **DESTROY** | Kill switch, close all positions | **DOUBLE CONFIRM** — type to confirm |

---

## 10. What This Is Not

- **Not a chatbot.** It's an operating system with a conversational interface.
- **Not a trading bot.** It doesn't trade autonomously. The human decides.
- **Not financial advice.** System R sizes, validates, and executes. It does not recommend.
- **Not a dashboard.** No charts-for-the-sake-of-charts. Data appears when relevant.
- **Not cloud-dependent for personal data.** Profile, memory, journal — all local.

---

## 11. Success Metrics

| Metric | Target (v1.0) |
|---|---|
| Install to first trade | < 5 minutes |
| Time to get morning briefing | < 10 seconds |
| Trade execution (message to filled) | < 30 seconds |
| Commands available | 15+ slash commands |
| Tool integrations | 55 MCP tools, 25 brokers |
| Test coverage | 80%+ |
| Package size | < 50 MB (standalone) |

---

## 12. Future (Post v1.0)

These are NOT in the 8-session build. They come after v1.0 ships.

| Feature | Priority | Description |
|---|---|---|
| Hooks system | P2 | Pre/post trade automation (auto-journal, auto-notify) |
| Custom skills | P2 | Trader-defined slash commands (save a routine, replay it) |
| MCP client | P2 | Connect to external MCP servers (TradingView, news, on-chain) |
| Background monitoring | P2 | Price alerts, stop monitoring, portfolio watch |
| Notifications | P2 | Desktop notifications for alerts and fills |
| Web app (neo.systemr.ai) | P2 | Codex-style browser interface, same backend |
| Desktop app (Electron) | P3 | Wrapper around web app |
| Mobile app | P3 | iOS/Android |
| Broker plugin | P3 | System R inside TradingView, inside Alpaca |
| Voice input | P3 | Speech-to-text via existing `/api/agent/voice/transcribe` |

---

*Built by Ashim Nandi and Shannon. System R AI.*
*Co-Authored-By: Shannon <shannon@systemr.ai>*
