#!/usr/bin/env python3
"""System R MCP stdio proxy.

Bridges OpenClaw's stdio MCP transport to System R's HTTP API.
OpenClaw sends JSON-RPC over stdin, this script translates to
HTTP calls against agents.systemr.ai and returns results on stdout.

Usage (in openclaw.json):
{
  "mcpServers": {
    "systemr": {
      "command": "python3",
      "args": ["path/to/mcp_stdio_proxy.py"],
      "env": {
        "SYSTEMR_API_KEY": "${SYSTEMR_API_KEY}"
      }
    }
  }
}
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

import httpx

API_URL = os.environ.get("SYSTEMR_API_URL", "https://agents.systemr.ai")
API_KEY = os.environ.get("SYSTEMR_API_KEY", "")

TOOLS_ENDPOINT = f"{API_URL}/v1/tools/call"
HEALTH_ENDPOINT = f"{API_URL}/v1/health"


def handle_request(request: dict[str, Any]) -> dict[str, Any]:
    """Handle a JSON-RPC request from OpenClaw.

    Supported methods:
    - initialize: Return server capabilities
    - tools/list: Return available tools
    - tools/call: Execute a tool via System R API

    Args:
        request: JSON-RPC request dict.

    Returns:
        JSON-RPC response dict.
    """
    method = request.get("method", "")
    req_id = request.get("id")

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {
                    "name": "systemr-trading",
                    "version": "1.0.0",
                },
            },
        }

    if method == "notifications/initialized":
        return {}  # No response needed for notifications

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": _get_tool_list()},
        }

    if method == "tools/call":
        params = request.get("params", {})
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})
        return _call_tool(req_id, tool_name, arguments)

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def _get_tool_list() -> list[dict[str, Any]]:
    """Fetch available tools from System R API.

    Returns:
        List of MCP tool definitions.
    """
    try:
        resp = httpx.get(
            f"{API_URL}/.well-known/mcp/server-card.json",
            headers={"X-API-Key": API_KEY},
            timeout=10.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("tools", [])
    except Exception:
        pass

    # Fallback: return core tools hardcoded
    return [
        {
            "name": "calculate_position_size",
            "description": "Calculate optimal position size using the G formula",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "equity": {"type": "number", "description": "Account equity in dollars"},
                    "entry_price": {"type": "number", "description": "Entry price"},
                    "stop_price": {"type": "number", "description": "Stop loss price"},
                    "risk_percent": {"type": "number", "description": "Risk per trade (%)"},
                },
                "required": ["equity", "entry_price", "stop_price"],
            },
        },
        {
            "name": "check_trade_risk",
            "description": "Validate trade risk via Iron Fist pre-trade gate",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string", "description": "Ticker symbol"},
                    "entry_price": {"type": "number"},
                    "stop_price": {"type": "number"},
                    "quantity": {"type": "integer"},
                    "equity": {"type": "number"},
                },
                "required": ["symbol", "entry_price", "stop_price", "quantity", "equity"],
            },
        },
        {
            "name": "evaluate_performance",
            "description": "Evaluate trading performance from R-multiples",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "r_multiples": {
                        "type": "array",
                        "items": {"type": "number"},
                        "description": "List of R-multiple results",
                    },
                },
                "required": ["r_multiples"],
            },
        },
        {
            "name": "pre_trade_gate",
            "description": "Complete pre-trade validation: risk, sizing, correlation, limits",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "entry_price": {"type": "number"},
                    "stop_price": {"type": "number"},
                    "quantity": {"type": "integer"},
                    "equity": {"type": "number"},
                    "direction": {"type": "string", "enum": ["long", "short"]},
                },
                "required": ["symbol", "entry_price", "stop_price", "quantity", "equity"],
            },
        },
    ]


def _call_tool(
    req_id: Any, tool_name: str, arguments: dict[str, Any],
) -> dict[str, Any]:
    """Call a System R tool via the REST API.

    Args:
        req_id: JSON-RPC request ID.
        tool_name: Name of the tool to call.
        arguments: Tool arguments.

    Returns:
        JSON-RPC response with tool result.
    """
    try:
        resp = httpx.post(
            TOOLS_ENDPOINT,
            json={"tool_name": tool_name, "arguments": arguments},
            headers={"X-API-Key": API_KEY},
            timeout=30.0,
        )
        if resp.status_code == 200:
            result = resp.json()
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [
                        {"type": "text", "text": json.dumps(result, indent=2)},
                    ],
                },
            }
        else:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [
                        {"type": "text", "text": f"Error: HTTP {resp.status_code}"},
                    ],
                    "isError": True,
                },
            }
    except Exception as exc:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": f"Error: {exc}"}],
                "isError": True,
            },
        }


def main() -> None:
    """Main stdio loop — reads JSON-RPC from stdin, writes responses to stdout."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = handle_request(request)
            if response:  # Skip empty responses (notifications)
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()
        except json.JSONDecodeError:
            error_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error"},
            }
            sys.stdout.write(json.dumps(error_resp) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
