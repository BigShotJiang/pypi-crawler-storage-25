---
name: systemr-trading
description: "System R AI — institutional-grade trading operating system. 55 MCP tools for position sizing, risk validation, pre-trade gates, drawdown analysis, Monte Carlo simulation, Kelly criterion, regime detection, and 25 broker connections. Use when the user needs to size a trade, check risk, analyze a portfolio, plan entries, or connect to a broker."
version: 1.0.0
user-invocable: true
metadata:
  openclaw:
    requires:
      env:
        - SYSTEMR_API_KEY
      bins:
        - python3
    primaryEnv: SYSTEMR_API_KEY
    homepage: https://systemr.ai
    os:
      - macos
      - linux
---

# System R Trading Operations

You are connected to System R AI — a trading operating system with 55 institutional-grade tools and 25 broker connections.

## When to Use This Skill

Activate when the user asks about:
- Position sizing ("how many shares", "size a trade", "G formula")
- Risk management ("check risk", "risk validation", "pre-trade gate")
- Portfolio analysis ("drawdown", "exposure", "correlation")
- Trade planning ("entry", "stop", "target", "R:R")
- Performance evaluation ("win rate", "R-multiples", "G-Score")
- Market scanning ("scan TSLA", "find setups")
- Broker operations ("connect Alpaca", "place order")

## Tool Categories

### Core (4 tools)
- `calculate_position_size` — G-formula position sizing
- `check_trade_risk` — Iron Fist pre-trade validation
- `evaluate_performance` — R-multiple evaluation with G-Score
- `get_pricing` — Tool pricing info

### Risk & Analysis (18 tools)
- `drawdown_analysis` — max drawdown, recovery analysis
- `monte_carlo_simulation` — probability-based projections
- `kelly_criterion` — optimal bet sizing
- `correlation_matrix` — position correlation
- `regime_detection` — market regime identification
- `variance_killers` — outlier detection
- `confidence_intervals` — statistical confidence
- And 11 more analysis tools

### Intelligence (11 tools)
- `technical_indicators` — standard TA indicators
- `price_structure` — support/resistance levels
- `trend_structure` — trend analysis
- `pattern_detection` — chart pattern recognition
- `options_greeks` — options pricing/greeks
- And 6 more intelligence tools

### Planning (4 tools)
- `options_plan_builder` — options strategy planning
- `futures_plan_builder` — futures strategy planning
- `options_position_sizing` — options-specific sizing
- `futures_position_sizing` — futures-specific sizing

### Compound (2 tools)
- `pre_trade_gate` — complete pre-trade validation
- `assess_trading_system` — full system assessment

### Behavioral (7 tools)
- `get_trading_biases` — detect behavioral biases
- `predict_trajectory` — performance trajectory
- `detect_anomalies` — anomaly detection
- `cluster_trades` — trade clustering
- And 3 more behavioral tools

## Supported Brokers (25)

Interactive Brokers, Charles Schwab, Alpaca, Tradier, TradeStation, Robinhood, E*Trade, Fidelity, Webull, Binance, Coinbase, Kraken, Bybit, OKX, Bitfinex, KuCoin, Gate.io, Hyperliquid, dYdX, Polymarket, Kalshi, Nadex, PredictIt, Manifold Markets, Metaculus.

## Pricing

Pay-per-call. No subscriptions. $0.002 to $2.00 per tool call.
Accepts: USDC, USDT, SOL, PYUSD, OSR.

## Important Rules

1. ALWAYS confirm before placing any trade order — show the full trade details and ask for explicit y/n approval
2. NEVER auto-execute trades without user confirmation
3. Use Decimal precision for all financial values — never approximate
4. When the user asks to "size a trade", call `calculate_position_size` with their account equity, entry price, stop price, and risk percentage
5. When the user says "check risk" or "is this trade safe", call `pre_trade_gate` with the full trade parameters
6. Default risk per trade to 2% unless the user specifies otherwise

## Getting Started

The user needs a System R API key from https://agents.systemr.ai. Set it as the `SYSTEMR_API_KEY` environment variable.

## Links

- Platform: https://agents.systemr.ai
- Documentation: https://docs.systemr.ai
- Python SDK: `pip install systemr`
- GitHub: https://github.com/System-R-AI
