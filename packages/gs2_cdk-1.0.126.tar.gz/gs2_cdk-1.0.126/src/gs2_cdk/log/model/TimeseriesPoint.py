# Copyright 2016- Game Server Services, Inc. or its affiliates. All Rights
# Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
#  http://www.apache.org/licenses/LICENSE-2.0
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.
from __future__ import annotations
from typing import *
from .TimeseriesValue import TimeseriesValue
from .options.TimeseriesPointOptions import TimeseriesPointOptions


class TimeseriesPoint:
    timestamp: int
    values: Optional[List[TimeseriesValue]] = None

    def __init__(
        self,
        timestamp: int,
        options: Optional[TimeseriesPointOptions] = TimeseriesPointOptions(),
    ):
        self.timestamp = timestamp
        self.values = options.values if options.values else None

    def properties(
        self,
    ) -> Dict[str, Any]:
        properties: Dict[str, Any] = {}

        if self.timestamp is not None:
            properties["timestamp"] = self.timestamp
        if self.values is not None:
            properties["values"] = [
                v.properties(
                )
                for v in self.values
            ]

        return properties
