"""Core analysis primitives."""
