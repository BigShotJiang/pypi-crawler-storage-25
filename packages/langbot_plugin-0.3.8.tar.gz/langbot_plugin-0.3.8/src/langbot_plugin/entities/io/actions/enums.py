from __future__ import annotations

from enum import Enum


class ActionType(Enum):
    pass


class CommonAction(ActionType):
    """The common action."""

    PING = "__ping"
    HEARTBEAT = "__heartbeat"
    FILE_CHUNK = "__file_chunk"


class PluginToRuntimeAction(ActionType):
    """The action from plugin to runtime."""

    REGISTER_PLUGIN = "register_plugin"

    # ========== APIs for plugin code ==========

    """Query-based APIs"""
    REPLY_MESSAGE = "reply_message"
    GET_BOT_UUID = "get_bot_uuid"
    SET_QUERY_VAR = "set_query_var"
    GET_QUERY_VAR = "get_query_var"
    GET_QUERY_VARS = "get_query_vars"
    CREATE_NEW_CONVERSATION = "create_new_conversation"

    """LangBot APIs"""
    GET_LANGBOT_VERSION = "get_langbot_version"

    GET_BOTS = "get_bots"
    GET_BOT_INFO = "get_bot_info"
    SEND_MESSAGE = "send_message"

    GET_LLM_MODELS = "get_llm_models"
    # GET_LLM_MODEL_INFO = "get_llm_model_info"
    INVOKE_LLM = "invoke_llm"
    # INVOKE_LLM_STREAMING = "invoke_llm_streaming"

    SET_PLUGIN_STORAGE = "set_plugin_storage"
    GET_PLUGIN_STORAGE = "get_plugin_storage"
    GET_PLUGIN_STORAGE_KEYS = "get_plugin_storage_keys"
    DELETE_PLUGIN_STORAGE = "delete_plugin_storage"

    SET_WORKSPACE_STORAGE = "set_workspace_storage"
    GET_WORKSPACE_STORAGE = "get_workspace_storage"
    GET_WORKSPACE_STORAGE_KEYS = "get_workspace_storage_keys"
    DELETE_WORKSPACE_STORAGE = "delete_workspace_storage"

    GET_CONFIG_FILE = "get_config_file"

    LIST_PLUGINS_MANIFEST = "list_plugins_manifest"
    LIST_COMMANDS = "list_commands"
    LIST_TOOLS = "list_tools"
    GET_TOOL_DETAIL = "get_tool_detail"
    CALL_TOOL = "call_tool"

    INVOKE_EMBEDDING = "invoke_embedding"
    VECTOR_UPSERT = "vector_upsert"
    VECTOR_SEARCH = "vector_search"
    VECTOR_DELETE = "vector_delete"
    VECTOR_LIST = "vector_list"
    GET_KNOWLEDEGE_FILE_STREAM = "get_knowledge_file_stream"

    LIST_PARSERS = "list_parsers"
    INVOKE_PARSER = "invoke_parser"

    """Knowledge Base APIs (global, unrestricted)"""
    LIST_KNOWLEDGE_BASES = "list_knowledge_bases"
    RETRIEVE_KNOWLEDGE = "retrieve_knowledge"

    """Knowledge Base Query APIs (query-based, pipeline-scoped)"""
    LIST_PIPELINE_KNOWLEDGE_BASES = "list_pipeline_knowledge_bases"
    RETRIEVE_KNOWLEDGE_BASE = "retrieve_knowledge_base"


class RuntimeToPluginAction(ActionType):
    """The action from runtime to plugin."""

    INITIALIZE_PLUGIN = "initialize_plugin"
    GET_PLUGIN_CONTAINER = "get_plugin_container"
    GET_PLUGIN_ICON = "get_plugin_icon"
    GET_PLUGIN_README = "get_plugin_readme"
    GET_PLUGIN_ASSETS_FILE = "get_plugin_assets_file"
    EMIT_EVENT = "emit_event"
    CALL_TOOL = "call_tool"
    EXECUTE_COMMAND = "execute_command"
    SHUTDOWN = "shutdown"

    RETRIEVE_KNOWLEDGE = "retrieve_knowledge"
    INGEST_DOCUMENT = "ingest_document"
    DELETE_DOCUMENT = "delete_document"
    ON_KB_CREATE = "on_kb_create"
    ON_KB_DELETE = "on_kb_delete"
    GET_RAG_CAPABILITIES = "get_rag_capabilities"

    PARSE_DOCUMENT = "parse_document"


class LangBotToRuntimeAction(ActionType):
    """The action from langbot to runtime."""

    LIST_PLUGINS = "list_plugins"
    GET_PLUGIN_INFO = "get_plugin_info"
    GET_PLUGIN_ICON = "get_plugin_icon"
    GET_PLUGIN_README = "get_plugin_readme"
    GET_PLUGIN_ASSETS_FILE = "get_plugin_assets_file"
    INSTALL_PLUGIN = "install_plugin"
    RESTART_PLUGIN = "restart_plugin"
    DELETE_PLUGIN = "delete_plugin"
    UPGRADE_PLUGIN = "upgrade_plugin"
    EMIT_EVENT = "emit_event"
    LIST_TOOLS = "list_tools"
    CALL_TOOL = "call_tool"
    LIST_COMMANDS = "list_commands"
    EXECUTE_COMMAND = "execute_command"

    # RAG actions
    RETRIEVE_KNOWLEDGE = "retrieve_knowledge"

    # Knowledge Engine actions (LangBot -> Runtime -> Plugin)
    LIST_KNOWLEDGE_ENGINES = "list_knowledge_engines"
    RAG_INGEST_DOCUMENT = "rag_ingest_document"
    RAG_DELETE_DOCUMENT = "rag_delete_document"
    RAG_ON_KB_CREATE = "rag_on_kb_create"
    RAG_ON_KB_DELETE = "rag_on_kb_delete"
    GET_RAG_CREATION_SETTINGS_SCHEMA = "get_rag_creation_settings_schema"
    GET_RAG_RETRIEVAL_SETTINGS_SCHEMA = "get_rag_retrieval_settings_schema"

    # Parser actions (LangBot -> Runtime -> Plugin)
    LIST_PARSERS = "list_parsers"
    PARSE_DOCUMENT = "parse_document"

    # Debug info
    GET_DEBUG_INFO = "get_debug_info"


class RuntimeToLangBotAction(ActionType):
    """The action from runtime to langbot."""

    INITIALIZE_PLUGIN_SETTINGS = "initialize_plugin_settings"
    GET_PLUGIN_SETTINGS = "get_plugin_settings"

    SET_BINARY_STORAGE = "set_binary_storage"
    GET_BINARY_STORAGE = "get_binary_storage"
    GET_BINARY_STORAGE_KEYS = "get_binary_storage_keys"
    DELETE_BINARY_STORAGE = "delete_binary_storage"

    GET_CONFIG_FILE = "get_config_file"
