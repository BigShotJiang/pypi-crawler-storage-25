"""Tests for SyncLink protocol."""
import pytest
from synclink_protocol import SyncPacket, PacketType, SyncSession, FrameEncoder, FrameDecoder
from synclink_protocol.framing import FLAG, ESCAPE, XOR


class TestPacket:
    def test_serialize_deserialize(self):
        pkt = SyncPacket(sync_id=42, pkt_type=PacketType.TILE_BATCH, payload=b"hello tiles")
        data = pkt.serialize()
        restored = SyncPacket.deserialize(data)
        assert restored.sync_id == 42
        assert restored.pkt_type == PacketType.TILE_BATCH
        assert restored.payload == b"hello tiles"

    def test_size_limit(self):
        with pytest.raises(ValueError, match="too large"):
            SyncPacket(payload=b"x" * 2000).serialize()

    def test_text_round_trip(self):
        pkt = SyncPacket.from_text(1, PacketType.COMMAND, "scan fleet")
        assert pkt.to_text() == "scan fleet"

    def test_types(self):
        assert PacketType.HEARTBEAT == 0x20
        assert PacketType.TILE_BATCH == 0x10
        assert PacketType.ERROR == 0xFF


class TestSession:
    def test_heartbeat(self):
        session = SyncSession("s1", "edge-1", is_cloud=True)
        hb = session.create_heartbeat()
        assert hb.pkt_type == PacketType.HEARTBEAT

    def test_handle_heartbeat(self):
        cloud = SyncSession("s1", "edge-1", is_cloud=True)
        edge = SyncSession("s1", "cloud", is_cloud=False)
        hb = edge.create_heartbeat()
        response = cloud.handle_packet(hb)
        assert response.pkt_type == PacketType.HEARTBEAT_ACK

    def test_tile_batch(self):
        session = SyncSession("s1", "edge-1")
        pkt = session.create_tile_batch('[{"domain":"test"}]')
        assert pkt.pkt_type == PacketType.TILE_BATCH
        assert session.tiles_sent == 1

    def test_stats(self):
        session = SyncSession("s1", "edge-1")
        session.create_heartbeat()
        stats = session.stats()
        assert stats["tiles_sent"] == 0


class TestFraming:
    def test_encode_decode(self):
        pkt = SyncPacket(sync_id=1, pkt_type=PacketType.HEARTBEAT, payload=b"ping")
        frame = FrameEncoder.encode(pkt)
        assert frame[0] == FLAG
        assert frame[-1] == FLAG
        restored = FrameEncoder.decode_frame(frame)
        assert restored is not None
        assert restored.sync_id == 1
        assert restored.payload == b"ping"

    def test_byte_stuffing(self):
        """Payload containing FLAG bytes should be escaped."""
        pkt = SyncPacket(sync_id=1, pkt_type=PacketType.HEARTBEAT, payload=bytes([FLAG, 0x41]))
        frame = FrameEncoder.encode(pkt)
        # Inner FLAG should be escaped
        assert frame.count(bytes([FLAG])) == 2  # only start and end
        restored = FrameEncoder.decode_frame(frame)
        assert restored.payload == bytes([FLAG, 0x41])

    def test_stream_decoder(self):
        pkt = SyncPacket(sync_id=1, pkt_type=PacketType.HEARTBEAT, payload=b"ping")
        frame = FrameEncoder.encode(pkt)
        decoder = FrameDecoder()
        packets = decoder.feed(frame)
        assert len(packets) == 1
        assert packets[0].payload == b"ping"

    def test_stream_split(self):
        """Frame split across multiple feed() calls."""
        pkt = SyncPacket(sync_id=1, pkt_type=PacketType.HEARTBEAT, payload=b"ping")
        frame = FrameEncoder.encode(pkt)
        decoder = FrameDecoder()
        p1 = decoder.feed(frame[:5])
        assert len(p1) == 0
        p2 = decoder.feed(frame[5:])
        assert len(p2) == 1
