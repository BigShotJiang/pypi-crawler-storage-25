"""Frame encoder/decoder — byte-stuffing for stream-based transport."""
from .packet import SyncPacket

FLAG = 0x7E  # Frame delimiter
ESCAPE = 0x7D  # Escape character
XOR = 0x20  # XOR value for escaping


class FrameEncoder:
    """Encode packets into framed byte streams (HDLC-like)."""

    @staticmethod
    def encode(packet: SyncPacket) -> bytes:
        """Encode a packet with start/end flags and byte-stuffing."""
        raw = packet.serialize()
        stuffed = FrameEncoder._stuff(raw)
        return bytes([FLAG]) + stuffed + bytes([FLAG])

    @staticmethod
    def _stuff(data: bytes) -> bytes:
        result = bytearray()
        for b in data:
            if b == FLAG or b == ESCAPE:
                result.append(ESCAPE)
                result.append(b ^ XOR)
            else:
                result.append(b)
        return bytes(result)

    @staticmethod
    def decode_frame(data: bytes) -> SyncPacket | None:
        """Decode a single frame from stuffed data (between flags)."""
        if len(data) < 2 or data[0] != FLAG or data[-1] != FLAG:
            return None
        unstuffed = FrameEncoder._unstuff(data[1:-1])
        if not unstuffed:
            return None
        return SyncPacket.deserialize(unstuffed)

    @staticmethod
    def _unstuff(data: bytes) -> bytes:
        result = bytearray()
        i = 0
        while i < len(data):
            if data[i] == ESCAPE and i + 1 < len(data):
                result.append(data[i + 1] ^ XOR)
                i += 2
            else:
                result.append(data[i])
                i += 1
        return bytes(result)


class FrameDecoder:
    """Stateful frame decoder for stream-based transport."""

    def __init__(self):
        self._buffer = bytearray()
        self._in_frame = False

    def feed(self, data: bytes) -> list[SyncPacket]:
        """Feed bytes and return any complete packets."""
        packets = []
        for b in data:
            if b == FLAG:
                if self._in_frame and len(self._buffer) > 0:
                    unstuffed = FrameEncoder._unstuff(bytes(self._buffer))
                    if unstuffed:
                        try:
                            packets.append(SyncPacket.deserialize(unstuffed))
                        except Exception:
                            pass
                    self._buffer.clear()
                    self._in_frame = False
                else:
                    self._in_frame = True
                    self._buffer.clear()
            elif self._in_frame:
                self._buffer.append(b)
        return packets
