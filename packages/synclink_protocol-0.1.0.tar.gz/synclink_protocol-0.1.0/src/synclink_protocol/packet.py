"""SyncLink packet — binary format for edge-cloud communication.
Header: 8 bytes
  sync_id (2B uint16) | type (1B) | payload_len (2B uint16) | timestamp (4B uint32) | reserved (3B)
Max payload: 1016 bytes. Total max: 1024 bytes.
"""
import struct
import time
import zlib
from dataclasses import dataclass
from enum import IntEnum
from typing import Optional

HEADER_FORMAT = "!H B H I 3s"  # 12 bytes
HEADER_SIZE = 12
MAX_PAYLOAD = 1012
MAGIC = 0x5954  # 'SYNC' marker


class PacketType(IntEnum):
    SYNC_REQUEST = 0x01
    SYNC_ACK = 0x02
    TILE_BATCH = 0x10
    TILE_ACK = 0x11
    HEARTBEAT = 0x20
    HEARTBEAT_ACK = 0x21
    COMMAND = 0x30
    COMMAND_RESPONSE = 0x31
    ERROR = 0xFF


@dataclass
class SyncPacket:
    sync_id: int = 0
    pkt_type: PacketType = PacketType.HEARTBEAT
    timestamp: int = 0
    payload: bytes = b""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = int(time.time())

    def serialize(self) -> bytes:
        if len(self.payload) > MAX_PAYLOAD:
            raise ValueError(f"Payload too large: {len(self.payload)} > {MAX_PAYLOAD}")
        header = struct.pack(
            HEADER_FORMAT,
            self.sync_id, self.pkt_type, len(self.payload), self.timestamp, b"\x00\x00\x00",
        )
        return header + self.payload

    @classmethod
    def deserialize(cls, data: bytes) -> "SyncPacket":
        if len(data) < HEADER_SIZE:
            raise ValueError(f"Too short: {len(data)} < {HEADER_SIZE}")
        sync_id, pkt_type, payload_len, timestamp, _ = struct.unpack(HEADER_FORMAT, data[:HEADER_SIZE])
        payload = data[HEADER_SIZE:HEADER_SIZE + payload_len]
        if len(payload) != payload_len:
            raise ValueError(f"Payload mismatch: {len(payload)} != {payload_len}")
        return cls(
            sync_id=sync_id,
            pkt_type=PacketType(pkt_type),
            timestamp=timestamp,
            payload=payload,
        )

    @property
    def size(self) -> int:
        return HEADER_SIZE + len(self.payload)

    def to_text(self) -> str:
        """Decode payload as UTF-8 text."""
        return self.payload.decode("utf-8", errors="replace")

    @classmethod
    def from_text(cls, sync_id: int, pkt_type: PacketType, text: str) -> "SyncPacket":
        return cls(sync_id=sync_id, pkt_type=pkt_type, payload=text.encode("utf-8"))

    def __repr__(self):
        return f"SyncPacket(id={self.sync_id}, type={self.pkt_type.name}, {self.size}B)"
