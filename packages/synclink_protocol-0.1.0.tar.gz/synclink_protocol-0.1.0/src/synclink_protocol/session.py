"""Sync session — manage a sync session between edge and cloud."""
import time
from dataclasses import dataclass, field
from .packet import SyncPacket, PacketType


@dataclass
class SyncSession:
    session_id: str
    peer_id: str
    is_cloud: bool = True  # True=cloud side, False=edge side
    last_sync: float = 0.0
    tiles_sent: int = 0
    tiles_received: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    errors: int = 0
    _sync_counter: int = 0

    def next_sync_id(self) -> int:
        self._sync_counter += 1
        return self._sync_counter

    def create_heartbeat(self) -> SyncPacket:
        return SyncPacket(
            sync_id=self.next_sync_id(),
            pkt_type=PacketType.HEARTBEAT,
            payload=f"{self.peer_id}:{self.session_id}".encode(),
        )

    def create_tile_batch(self, tiles_json: str) -> SyncPacket:
        """Send a batch of tiles (JSON-encoded)."""
        self.tiles_sent += 1
        pkt = SyncPacket.from_text(
            self.next_sync_id(), PacketType.TILE_BATCH, tiles_json,
        )
        self.bytes_sent += pkt.size
        self.last_sync = time.time()
        return pkt

    def create_command(self, command: str) -> SyncPacket:
        return SyncPacket.from_text(
            self.next_sync_id(), PacketType.COMMAND, command,
        )

    def handle_packet(self, packet: SyncPacket) -> SyncPacket | None:
        """Handle an incoming packet and return a response if needed."""
        self.bytes_received += packet.size

        if packet.pkt_type == PacketType.HEARTBEAT:
            self.last_sync = time.time()
            return SyncPacket(
                sync_id=packet.sync_id,
                pkt_type=PacketType.HEARTBEAT_ACK,
                payload=b"OK",
            )
        elif packet.pkt_type == PacketType.TILE_BATCH:
            self.tiles_received += 1
            self.last_sync = time.time()
            return SyncPacket(
                sync_id=packet.sync_id,
                pkt_type=PacketType.TILE_ACK,
                payload=str(self.tiles_received).encode(),
            )
        elif packet.pkt_type == PacketType.COMMAND:
            return SyncPacket.from_text(
                self.next_sync_id(), PacketType.COMMAND_RESPONSE, "ACK",
            )
        elif packet.pkt_type == PacketType.ERROR:
            self.errors += 1
            return None
        return None

    @property
    def latency_estimate_ms(self) -> float:
        if not self.last_sync:
            return 0.0
        return (time.time() - self.last_sync) * 1000

    def stats(self) -> dict:
        return {
            "session_id": self.session_id,
            "peer": self.peer_id,
            "role": "cloud" if self.is_cloud else "edge",
            "tiles_sent": self.tiles_sent,
            "tiles_received": self.tiles_received,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
            "errors": self.errors,
            "last_sync": self.last_sync,
        }
