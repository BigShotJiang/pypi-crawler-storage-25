# PyKernel

A hackable Python REPL with first-class command support.

## Install

```bash
pip install pykernel
```

## Usage

```bash
pykernel
# or
python -m pykernel
```

Type `/help` to see all commands.

## Commands

| Command | Description |
|---|---|
| `/help` | List all commands |
| `/vars` | List variables in the namespace |
| `/run <file>` | Execute a Python file |
| `/sh <cmd>` | Run a shell command |
| `/snip` | Manage code snippets |
| `/timeit <expr>` | Time an expression |

## Plugins

Drop a `.py` file with a `register(registry)` function into `~/.pykernel/plugins/`:

```python
def register(reg):
    @reg.command("hello", help="Say hello")
    def cmd_hello(ctx, *args):
        ctx.print("Hello!")
```

## Config

Edit `~/.pykernel/config.toml`:

```toml
[kernel]
prompt = ">>> "
theme  = "dark"   # dark | light | none
```
