"""
Shell commands — run system commands, navigate dirs, etc.

/sh   <cmd>    — run a shell command (output captured into _)
/cd   <dir>    — change working directory
/pwd           — print working directory
/ls   [dir]    — list directory contents
"""

import os, subprocess, shlex, pathlib
from pykernel.core.registry import CommandRegistry


def register(reg: CommandRegistry):

    # ── /sh ───────────────────────────────────────────────────────────────────

    @reg.command("sh", aliases=["!"],
                 help="Run a shell command; output stored in `_out`",
                 usage="/sh <shell command>",
                 category="Shell")
    def cmd_sh(ctx, *args):
        p   = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /sh <command>"))
            return
        cmd = " ".join(args)
        try:
            result = subprocess.run(
                cmd, shell=True, text=True,
                capture_output=True
            )
            out = result.stdout
            err = result.stderr
            if out:
                ctx.print(out, end="")
            if err:
                ctx.print(p.warning(err), end="")
            if result.returncode != 0:
                ctx.print(p.dim(f"  exit code: {result.returncode}"))
            # inject result into namespace
            ctx.set_var("_out",     out)
            ctx.set_var("_err",     err)
            ctx.set_var("_retcode", result.returncode)
        except Exception as e:
            ctx.print(p.error(str(e)))

    # ── /cd ───────────────────────────────────────────────────────────────────

    @reg.command("cd",
                 help="Change the current working directory",
                 usage="/cd <path>",
                 category="Shell")
    def cmd_cd(ctx, *args):
        p    = ctx.paint
        dest = pathlib.Path(args[0]).expanduser() if args else pathlib.Path.home()
        try:
            os.chdir(dest)
            ctx.print(p.info(f"  → {os.getcwd()}"))
        except FileNotFoundError:
            ctx.print(p.error(f"Directory not found: {dest}"))
        except PermissionError:
            ctx.print(p.error(f"Permission denied: {dest}"))

    # ── /pwd ──────────────────────────────────────────────────────────────────

    @reg.command("pwd",
                 help="Print the current working directory",
                 usage="/pwd",
                 category="Shell")
    def cmd_pwd(ctx, *args):
        ctx.print(ctx.paint.info(f"  {os.getcwd()}"))

    # ── /ls ───────────────────────────────────────────────────────────────────

    @reg.command("ls",
                 help="List directory contents",
                 usage="/ls [path]",
                 category="Shell")
    def cmd_ls(ctx, *args):
        p    = ctx.paint
        path = pathlib.Path(args[0]).expanduser() if args else pathlib.Path(".")
        try:
            entries = sorted(path.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
        except (FileNotFoundError, PermissionError) as e:
            ctx.print(p.error(str(e)))
            return

        ctx.print()
        for entry in entries:
            if entry.is_dir():
                ctx.print(p.accent(f"  📁 {entry.name}/"))
            else:
                size = entry.stat().st_size
                size_s = (
                    f"{size / 1_048_576:.1f} MB" if size > 1_048_576
                    else f"{size / 1_024:.1f} KB" if size > 1_024
                    else f"{size} B"
                )
                ctx.print(f"  📄 {entry.name:<40} {p.dim(size_s)}")
        ctx.print()
