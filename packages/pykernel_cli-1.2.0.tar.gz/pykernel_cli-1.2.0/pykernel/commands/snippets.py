"""
Snippet commands — save and replay named code snippets.

Snippets are stored as .py files in ~/.pykernel/snippets/.

/snip save  <name>   — save the last history entry as a snippet
/snip write <name>   — open $EDITOR to write a snippet from scratch
/snip list           — list all saved snippets
/snip show  <name>   — print a snippet's source
/snip run   <name>   — execute a snippet in the kernel namespace
/snip edit  <name>   — open a saved snippet in $EDITOR
/snip del   <name>   — delete a snippet
"""

import os, pathlib, subprocess, tempfile, traceback
from pykernel.core.registry import CommandRegistry

SNIPPETS_DIR = pathlib.Path.home() / ".pykernel" / "snippets"


def _ensure_dir():
    SNIPPETS_DIR.mkdir(parents=True, exist_ok=True)


def _path(name: str) -> pathlib.Path:
    # sanitise: allow only alphanumerics, dashes, underscores
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    return SNIPPETS_DIR / f"{safe}.py"


def _editor() -> str:
    return os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"


def _open_in_editor(fpath: pathlib.Path, initial: str = "") -> bool:
    """Write initial content, open editor, return True if saved non-empty."""
    if not fpath.exists():
        fpath.write_text(initial)
    ret = subprocess.call([_editor(), str(fpath)])
    return ret == 0 and fpath.exists() and fpath.stat().st_size > 0


# ─────────────────────────────────────────────────────────────────────────────

def register(reg: CommandRegistry):

    # ── /snip ─────────────────────────────────────────────────────────────────

    @reg.command("snip", aliases=["snippet"],
                 help="Manage code snippets  (save / list / show / run / edit / del)",
                 usage="/snip <subcommand> [name]",
                 category="Snippets")
    def cmd_snip(ctx, *args):
        p = ctx.paint
        if not args:
            _print_usage(ctx)
            return

        sub  = args[0].lower()
        rest = args[1:]

        dispatch = {
            "save":  _save,
            "write": _write,
            "list":  _list,
            "ls":    _list,
            "show":  _show,
            "cat":   _show,
            "run":   _run,
            "exec":  _run,
            "edit":  _edit,
            "del":   _delete,
            "rm":    _delete,
            "delete":_delete,
        }

        fn = dispatch.get(sub)
        if fn is None:
            ctx.print(p.error(f"Unknown subcommand: '{sub}'"))
            _print_usage(ctx)
            return

        fn(ctx, *rest)

    # ── subcommand helpers ────────────────────────────────────────────────────

    def _print_usage(ctx):
        p = ctx.paint
        rows = [
            ("save  <name>",  "Save last history entry as a snippet"),
            ("write <name>",  "Create a new snippet in $EDITOR"),
            ("list",          "List all saved snippets"),
            ("show  <name>",  "Print a snippet's source"),
            ("run   <name>",  "Execute a snippet in the kernel namespace"),
            ("edit  <name>",  "Open a saved snippet in $EDITOR"),
            ("del   <name>",  "Delete a snippet"),
        ]
        ctx.print()
        ctx.print(p.header("  Snippet subcommands"))
        ctx.print(p.table(rows, headers=["Subcommand", "Description"]))
        ctx.print()

    # ── save ──────────────────────────────────────────────────────────────────

    def _save(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip save <name>"))
            return

        name = args[0]
        # find last non-/snip history entry
        source = None
        for entry in reversed(ctx.history):
            if not entry.strip().startswith("/snip"):
                source = entry
                break

        if not source:
            ctx.print(p.warning("  ⚠  No suitable history entry found to save."))
            return

        _ensure_dir()
        fpath = _path(name)
        existed = fpath.exists()
        fpath.write_text(source.rstrip() + "\n")
        verb = "Updated" if existed else "Saved"
        ctx.print(p.success(f"  ✓  {verb} snippet '{name}'  →  {fpath}"))

    # ── write ─────────────────────────────────────────────────────────────────

    def _write(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip write <name>"))
            return

        name  = args[0]
        _ensure_dir()
        fpath = _path(name)

        if fpath.exists():
            ctx.print(p.warning(f"  ⚠  '{name}' already exists — use /snip edit to modify it."))
            return

        ctx.print(p.dim(f"  Opening {_editor()} …"))
        ok = _open_in_editor(fpath, initial=f"# snippet: {name}\n")
        if ok:
            ctx.print(p.success(f"  ✓  Snippet '{name}' saved  →  {fpath}"))
        else:
            if fpath.exists() and fpath.stat().st_size == 0:
                fpath.unlink()
            ctx.print(p.warning("  ⚠  Snippet discarded (empty or editor error)."))

    # ── list ──────────────────────────────────────────────────────────────────

    def _list(ctx, *args):
        p = ctx.paint
        _ensure_dir()
        files = sorted(SNIPPETS_DIR.glob("*.py"))

        if not files:
            ctx.print(p.dim("  (no snippets saved yet — try /snip save <name>)"))
            return

        rows = []
        for f in files:
            name  = f.stem
            lines = f.read_text().splitlines()
            size  = f.stat().st_size
            # first non-comment, non-blank line as preview
            preview = next(
                (l.strip() for l in lines if l.strip() and not l.strip().startswith("#")),
                "(empty)"
            )[:60]
            rows.append((name, f"{len(lines)} lines", f"{size} B", preview))

        ctx.print()
        ctx.print(p.table(rows, headers=["Name", "Lines", "Size", "Preview"]))
        ctx.print()

    # ── show ──────────────────────────────────────────────────────────────────

    def _show(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip show <name>"))
            return

        fpath = _path(args[0])
        if not fpath.exists():
            ctx.print(p.error(f"Snippet '{args[0]}' not found."))
            return

        source = fpath.read_text()
        ctx.print()
        ctx.print(p.header(f"  {args[0]}  ({fpath.name})"))
        ctx.print(p.code(source))

    # ── run ───────────────────────────────────────────────────────────────────

    def _run(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip run <name>"))
            return

        fpath = _path(args[0])
        if not fpath.exists():
            ctx.print(p.error(f"Snippet '{args[0]}' not found."))
            return

        source = fpath.read_text()
        ctx.print(p.dim(f"  Running snippet '{args[0]}' …"))
        try:
            exec(compile(source, str(fpath), "exec"), ctx.env)
            ctx.print(p.success(f"  ✓  Done."))
        except SystemExit:
            raise
        except Exception:
            lines   = traceback.format_exc().splitlines()
            cleaned = [l for l in lines if str(fpath) in l or not l.strip().startswith('File "')]
            ctx.print(p.error("\n".join(cleaned or lines)))

    # ── edit ──────────────────────────────────────────────────────────────────

    def _edit(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip edit <name>"))
            return

        name  = args[0]
        fpath = _path(name)
        if not fpath.exists():
            ctx.print(p.warning(f"  ⚠  '{name}' doesn't exist — use /snip write to create it."))
            return

        ctx.print(p.dim(f"  Opening {_editor()} …"))
        _open_in_editor(fpath)
        ctx.print(p.success(f"  ✓  Snippet '{name}' updated."))

    # ── delete ────────────────────────────────────────────────────────────────

    def _delete(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /snip del <name>"))
            return

        for name in args:
            fpath = _path(name)
            if fpath.exists():
                fpath.unlink()
                ctx.print(p.success(f"  ✓  Deleted snippet '{name}'"))
            else:
                ctx.print(p.warning(f"  ⚠  Snippet '{name}' not found."))
