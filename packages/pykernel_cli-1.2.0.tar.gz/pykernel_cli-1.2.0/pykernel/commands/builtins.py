"""
Built-in commands — always available.

/help   [command]      — list all commands or describe one
/exit   | /quit        — exit the kernel
/clear                 — clear the screen
/history  [n]          — show last n inputs (default 20)
/run   <file.py>       — execute a Python file inside the kernel
/reset                 — clear the execution namespace
/alias <new> <target>  — create an alias for an existing command
/commands              — list all commands (alias for /help)
"""

import os, pathlib, traceback
from pykernel.core.registry import CommandRegistry


def register(reg: CommandRegistry):

    # ── /help ─────────────────────────────────────────────────────────────────

    @reg.command("help", aliases=["?", "commands"],
                 help="List commands or show help for a specific command",
                 usage="/help [command]",
                 category="Core")
    def cmd_help(ctx, *args):
        p = ctx.paint
        if args:
            name = args[0].lstrip("/")
            cmd  = ctx.registry.resolve(name)
            if cmd is None:
                ctx.print(p.error(f"No command: /{name}"))
                return
            ctx.print(p.header(f"  /{cmd.name}"))
            if cmd.aliases:
                ctx.print(p.dim(f"  Aliases : " + ", ".join(f"/{a}" for a in cmd.aliases)))
            ctx.print(p.dim(f"  Usage   : {cmd.usage}"))
            ctx.print(f"  {cmd.help}")
            return

        by_cat = ctx.registry.by_category()
        ctx.print()
        for cat, cmds in sorted(by_cat.items()):
            ctx.print(p.header(f" {cat}"))
            rows = [(f"/{c.name}", ", ".join(f"/{a}" for a in c.aliases), c.help)
                    for c in cmds]
            ctx.print(p.table(rows, headers=["Command", "Aliases", "Description"]))
            ctx.print()
        ctx.print(p.dim("  Tip: type /help <command> for detailed usage."))
        ctx.print()

    # ── /exit ─────────────────────────────────────────────────────────────────

    @reg.command("exit", aliases=["quit", "q"],
                 help="Exit the kernel",
                 usage="/exit",
                 category="Core")
    def cmd_exit(ctx, *args):
        ctx.print(ctx.paint.dim("  Goodbye."))
        raise SystemExit(0)    

    # ── /clear ────────────────────────────────────────────────────────────────

    @reg.command("clear", aliases=["cls"],
                 help="Clear the terminal screen",
                 usage="/clear",
                 category="Core")
    def cmd_clear(ctx, *args):
        os.system("clear" if os.name != "nt" else "cls")

    # ── /history ──────────────────────────────────────────────────────────────

    @reg.command("history", aliases=["hist"],
                 help="Show recent input history",
                 usage="/history [n]",
                 category="Core")
    def cmd_history(ctx, *args):
        p   = ctx.paint
        n   = int(args[0]) if args and args[0].isdigit() else 20
        items = ctx.history[-(n):]
        if not items:
            ctx.print(p.dim("  (no history yet)"))
            return
        ctx.print()
        for i, entry in enumerate(items, start=max(1, len(ctx.history) - n + 1)):
            prefix = p.dim(f"  {i:>4} │ ")
            # truncate long entries
            snippet = entry.replace("\n", "⏎ ")[:80]
            ctx.print(prefix + snippet)
        ctx.print()

    # ── /run ──────────────────────────────────────────────────────────────────

    @reg.command("run",
                 help="Execute a Python file in the kernel namespace",
                 usage="/run <path/to/file.py>",
                 category="Core")
    def cmd_run(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /run <path/to/file.py>"))
            return
        fpath = pathlib.Path(args[0]).expanduser()
        if not fpath.exists():
            ctx.print(p.error(f"File not found: {fpath}"))
            return
        try:
            source = fpath.read_text()
            exec(compile(source, str(fpath), "exec"), ctx.env)
            ctx.print(p.success(f"  ✓  Ran {fpath.name}"))
        except Exception:
            ctx.print(p.error(traceback.format_exc()))

    # ── /reset ────────────────────────────────────────────────────────────────

    @reg.command("reset",
                 help="Clear all variables from the kernel namespace",
                 usage="/reset",
                 category="Core")
    def cmd_reset(ctx, *args):
        kept = {"__name__", "__builtins__"}
        for k in list(ctx.env.keys()):
            if k not in kept:
                del ctx.env[k]
        ctx.print(ctx.paint.success("  ✓  Namespace cleared."))

    # ── /alias ────────────────────────────────────────────────────────────────

    @reg.command("alias",
                 help="Create an alias for an existing command  (/alias hi greet)",
                 usage="/alias <new_name> <existing_command>",
                 category="Core")
    def cmd_alias(ctx, *args):
        p = ctx.paint
        if len(args) < 2:
            ctx.print(p.error("Usage: /alias <new_name> <existing_command>"))
            return
        new_name, target = args[0].lstrip("/"), args[1].lstrip("/")
        cmd = ctx.registry.resolve(target)
        if cmd is None:
            ctx.print(p.error(f"No command: /{target}"))
            return
        ctx.registry._alias[new_name] = cmd.name
        ctx.print(p.success(f"  ✓  /{new_name} → /{cmd.name}"))
