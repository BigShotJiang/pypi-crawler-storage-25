"""
REPL — the read-eval-print loop engine.

Input lines that start with '/' are dispatched to the command registry.
Everything else is compiled and exec'd in the shared namespace.

Multi-line input is accumulated until the block is syntactically complete
(same heuristic as CPython's interactive shell).
"""

from __future__ import annotations

import ast, code, sys, traceback, atexit, pathlib
try:
    import readline
except ImportError:
    try:
        import pyreadline3 as readline
    except ImportError:
        readline = None
from typing import Optional

from pykernel.core.config   import Config
from pykernel.core.context  import Context
from pykernel.core.painter  import Painter
from pykernel.core.registry import CommandRegistry

VERSION = "1.0.0"

# ── readline completion ───────────────────────────────────────────────────────

class _Completer:
    def __init__(self, env: dict, registry: CommandRegistry):
        self._env      = env
        self._registry = registry
        self._matches: list[str] = []

    def complete(self, text: str, state: int) -> Optional[str]:
        if state == 0:
            if text.startswith("/"):
                prefix = text[1:]
                self._matches = [
                    f"/{n}" for n in self._registry.names()
                    if n.startswith(prefix)
                ]
            else:
                import rlcompleter
                self._matches = [
                    m for m in rlcompleter.Completer(self._env).global_matches(text) or []
                ]
        return self._matches[state] if state < len(self._matches) else None


# ── REPL ─────────────────────────────────────────────────────────────────────

class REPL:
    COMMAND_PREFIX = "/"

    def __init__(self, registry: CommandRegistry, cfg: Config):
        self.registry = registry
        self.cfg      = cfg
        self.paint    = Painter(theme=cfg.theme, color_map=cfg.colors)

        # shared execution namespace
        self.env: dict = {
            "__name__":    "__kernel__",
            "__builtins__": __builtins__,
        }

        self.history: list[str] = []
        self._buffer: list[str] = []          # multi-line accumulator

        self._setup_readline()

    # ── readline / history ────────────────────────────────────────────────────

    def _setup_readline(self):
        if readline is None:
            return
        hfile = self.cfg.history_file
        hfile.parent.mkdir(parents=True, exist_ok=True)

        try:
            readline.read_history_file(str(hfile))
        except FileNotFoundError:
            pass

        readline.set_history_length(self.cfg.history_size)
        atexit.register(readline.write_history_file, str(hfile))

        completer = _Completer(self.env, self.registry)
        readline.set_completer(completer.complete)
        readline.set_completer_delims(" \t\n`!@#$%^&*()-=+[{]}\\|;:'\",<>?")
        readline.parse_and_bind("tab: complete")

    # ── prompt display ────────────────────────────────────────────────────────

    def _prompt(self) -> str:
        p = self.cfg.prompt2 if self._buffer else self.cfg.prompt
        return self.paint.prompt(p)

    # ── command dispatch ──────────────────────────────────────────────────────

    def _dispatch_command(self, line: str):
        parts   = line[len(self.COMMAND_PREFIX):].split()
        if not parts:
            return
        name, args = parts[0], parts[1:]

        cmd = self.registry.resolve(name)
        if cmd is None:
            self.paint_error(f"Unknown command: /{name}  (try /help)")
            return

        ctx = Context(
            env=self.env,
            paint=self.paint,
            registry=self.registry,
            cfg=self.cfg,
            history=self.history,
        )
        try:
            cmd.invoke(ctx, *args)
        except SystemExit:
            raise
        except Exception:
            self.paint_error(f"Error in /{name}:\n" + traceback.format_exc())

    # ── code execution ────────────────────────────────────────────────────────

    def _is_complete(self, source: str) -> tuple[bool, bool]:
        """
        Returns (complete, invalid).
        Mirrors CPython codeop behaviour.
        """
        try:
            tree = compile(source, "<input>", "exec", ast.PyCF_ONLY_AST)
            return True, False
        except SyntaxError as e:
            if e.msg in ("unexpected EOF while parsing",
                         "EOF while scanning triple-quoted string literal",
                         "expected an indented block"):
                return False, False         # incomplete — keep reading
            return True, True               # real error

    def _exec(self, source: str):
        try:
            # try eval first (so expressions print their value)
            try:
                code_obj = compile(source, "<input>", "eval")
                result   = eval(code_obj, self.env)
                if result is not None:
                    print(self.paint.result(repr(result)))
                return
            except SyntaxError:
                pass

            # fall back to exec
            code_obj = compile(source, "<input>", "exec")
            exec(code_obj, self.env)

        except SystemExit:
            raise
        except Exception:
            lines = traceback.format_exc().splitlines()
            # trim noisy internal frames
            cleaned = [l for l in lines if "<string>" in l or not l.strip().startswith('File "')]
            print(self.paint.error("\n".join(cleaned or lines)))

    # ── helpers ───────────────────────────────────────────────────────────────

    def paint_error(self, msg: str):
        print(self.paint.error(f"✗  {msg}"))

    def paint_info(self, msg: str):
        print(self.paint.info(f"   {msg}"))

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self):
        if self.cfg.banner:
            print(self.paint.banner(VERSION))

        while True:
            try:
                line = input(self._prompt())
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print()
                self._buffer.clear()
                continue

            # ── command? ──────────────────────────────────────────────────────
            stripped = line.strip()
            if stripped.startswith(self.COMMAND_PREFIX) and not self._buffer:
                self.history.append(stripped)
                self._dispatch_command(stripped)
                continue

            # ── accumulate multi-line ─────────────────────────────────────────
            self._buffer.append(line)
            source = "\n".join(self._buffer)

            complete, invalid = self._is_complete(source)

            if not complete:
                continue   # keep reading

            # ── flush & execute ───────────────────────────────────────────────
            self.history.append(source)
            self._buffer.clear()
            if stripped:
                self._exec(source)
