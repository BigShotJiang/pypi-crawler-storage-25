"""
Context — the object every command receives as its first argument.

It provides:
  ctx.env        — the shared Python namespace (locals/globals for exec)
  ctx.print()    — themed print
  ctx.paint      — Painter instance
  ctx.registry   — CommandRegistry
  ctx.cfg        — Config
  ctx.history    — list of past inputs (most recent last)
  ctx.set_var()  — inject a name into the exec namespace
  ctx.get_var()  — retrieve from the exec namespace
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pykernel.core.config   import Config
    from pykernel.core.painter  import Painter
    from pykernel.core.registry import CommandRegistry


class Context:
    def __init__(
        self,
        env:      dict,
        paint:    "Painter",
        registry: "CommandRegistry",
        cfg:      "Config",
        history:  list[str],
    ):
        self.env      = env
        self.paint    = paint
        self.registry = registry
        self.cfg      = cfg
        self.history  = history

    # ── convenience ──────────────────────────────────────────────────────────

    def print(self, *args, **kwargs):
        """Print to stdout (wrapper so commands don't need to import print)."""
        print(*args, **kwargs)

    def set_var(self, name: str, value: Any):
        """Inject a variable into the kernel's exec namespace."""
        self.env[name] = value

    def get_var(self, name: str, default: Any = None) -> Any:
        """Retrieve a variable from the kernel's exec namespace."""
        return self.env.get(name, default)

    def has_var(self, name: str) -> bool:
        return name in self.env

    def delete_var(self, name: str) -> bool:
        if name in self.env:
            del self.env[name]
            return True
        return False

    def namespace_vars(self) -> dict:
        """Return user-visible variables (excludes dunders)."""
        return {k: v for k, v in self.env.items() if not k.startswith("__")}
