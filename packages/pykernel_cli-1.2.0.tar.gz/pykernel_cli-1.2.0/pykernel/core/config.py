"""
Config — loads ~/.pykernel/config.toml (or defaults).

Supported keys
--------------
[kernel]
prompt        = "@> "
prompt2       = "... "
history_file  = "~/.pykernel/history"
history_size  = 2000
banner        = true
theme         = "light"          # dark | light | none

[kernel.colors]
prompt   = "green"
error    = "red"
info     = "cyan"
warning  = "yellow"
result   = "white"
"""

import os, pathlib

try:
    import tomllib                          # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib            # pip install tomli
    except ImportError:
        tomllib = None                      # fall back to defaults


DEFAULTS: dict = {
    "kernel": {
        "prompt":       "@> ",
        "prompt2":      "... ",
        "history_file": "~/.pykernel/history",
        "history_size": 2000,
        "banner":       True,
        "theme":        "light",
        "colors": {
            "prompt":  "green",
            "error":   "red",
            "info":    "cyan",
            "warning": "yellow",
            "result":  "white",
        },
    }
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    """Thin wrapper around the merged config dict."""

    CONFIG_DIR  = pathlib.Path.home() / ".pykernel"
    CONFIG_FILE = CONFIG_DIR / "config.toml"

    def __init__(self):
        raw = {}
        if tomllib and self.CONFIG_FILE.exists():
            with open(self.CONFIG_FILE, "rb") as f:
                raw = tomllib.load(f)
        self._data = _deep_merge(DEFAULTS, raw)
        self._ensure_dirs()

    # ── helpers ─────────────────────────────────────────────────────────────

    def _ensure_dirs(self):
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self.plugin_dir.mkdir(parents=True, exist_ok=True)

    def _k(self, *keys):
        node = self._data
        for k in keys:
            node = node.get(k, {})
        return node

    # ── public properties ────────────────────────────────────────────────────

    @property
    def prompt(self)        -> str:  return self._k("kernel", "prompt")
    @property
    def prompt2(self)       -> str:  return self._k("kernel", "prompt2")
    @property
    def history_file(self)  -> pathlib.Path:
        return pathlib.Path(os.path.expanduser(self._k("kernel", "history_file")))
    @property
    def history_size(self)  -> int:  return self._k("kernel", "history_size")
    @property
    def banner(self)        -> bool: return bool(self._k("kernel", "banner"))
    @property
    def theme(self)         -> str:  return self._k("kernel", "theme")
    @property
    def colors(self)        -> dict: return self._k("kernel", "colors")
    @property
    def plugin_dir(self)    -> pathlib.Path:
        return self.CONFIG_DIR / "plugins"

    def color(self, name: str) -> str:
        return self.colors.get(name, "white")

    def get(self, *keys, default=None):
        node = self._data
        for k in keys:
            if not isinstance(node, dict):
                return default
            node = node.get(k, {})
        return node if node != {} else default
