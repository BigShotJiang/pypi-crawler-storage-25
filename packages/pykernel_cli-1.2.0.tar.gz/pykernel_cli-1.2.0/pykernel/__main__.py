from pykernel.kernel import main
main()
