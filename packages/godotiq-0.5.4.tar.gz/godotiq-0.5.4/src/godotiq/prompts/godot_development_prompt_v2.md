# Deprecated GodotIQ Prompt

This file is kept only as a compatibility marker for old planning notes.

The active MCP prompt and installed `GODOTIQ_RULES.md` source is:

```text
src/godotiq/prompts/godot_development.md
```

Do not add agent workflow instructions here. Update `godot_development.md`
instead.

Compatibility markers for older tests and references:

- MANDATORY: Final QA lives in `godot_development.md`.
- Efficiency Rules live in `godot_development.md`.
- Screenshots are expensive and visual-only; use them only when visual
  inspection is required and structured text tools are insufficient.
