"""Curated catalog of downloadable models for local inference.

Supports two backends:
- GGUF: Direct HuggingFace downloads for llama.cpp inference
- Ollama: Models pulled via `ollama pull` command

Auto-update: On startup, clients fetch gs://sage-ai-models/catalog.json
for the latest models. Falls back to the hardcoded catalog below.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class CatalogModel:
    """A downloadable model entry."""

    name: str  # Short CLI name (e.g. "gemma3-4b")
    display_name: str  # Human-readable name
    filename: str  # GGUF filename (empty for Ollama models)
    url: str  # Direct download URL (empty for Ollama models)
    size_gb: float  # Approximate file size in GB (0 for cloud-only)
    params: str  # Parameter count (e.g. "4B")
    family: str  # Model family (e.g. "Gemma")
    description: str  # Short description
    backend: str = "gguf"  # "gguf" or "ollama"
    tags: tuple[str, ...] = ()  # Capability tags (tools, thinking, vision, etc.)
    category: str = "general"  # coding, reasoning, general, vision, small, embedding
    default: bool = False  # Whether this is a default-install model


# ── GCS public bucket (primary) + HuggingFace (fallback) ──

GCS_BUCKET = "https://storage.googleapis.com/sage-ai-models/gguf"

def _gcs_url(filename: str) -> str:
    return f"{GCS_BUCKET}/{filename}"

def _hf_url(repo: str, filename: str) -> str:
    return f"https://huggingface.co/{repo}/resolve/main/{filename}"


# ── Model Catalog (all verified accessible without auth) ───

MODEL_CATALOG: list[CatalogModel] = [
    # ── Meta Llama ──────────────────────────────────────────
    CatalogModel(
        name="llama3.2-1b",
        display_name="Llama 3.2 1B",
        filename="Llama-3.2-1B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Llama-3.2-1B-Instruct-Q4_K_M.gguf"),
        size_gb=0.8,
        params="1B",
        family="Llama",
        description="Meta's tiny Llama — fast, good for simple coding",
    ),
    CatalogModel(
        name="llama3.2-3b",
        display_name="Llama 3.2 3B",
        filename="Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Llama-3.2-3B-Instruct-Q4_K_M.gguf"),
        size_gb=2.0,
        params="3B",
        family="Llama",
        description="Meta Llama 3.2 3B — solid coding ability",
        default=True,
    ),
    CatalogModel(
        name="llama3.1-8b",
        display_name="Llama 3.1 8B",
        filename="Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"),
        size_gb=4.9,
        params="8B",
        family="Llama",
        description="Meta Llama 3.1 8B — strong general + coding",
    ),
    # ── Alibaba Qwen (Coder) ───────────────────────────────
    CatalogModel(
        name="qwen2.5-coder-1.5b",
        display_name="Qwen 2.5 Coder 1.5B",
        filename="Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.5B",
        family="Qwen",
        description="Alibaba's coding model — best code quality for its size",
    ),
    CatalogModel(
        name="qwen2.5-coder-3b",
        display_name="Qwen 2.5 Coder 3B",
        filename="Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf"),
        size_gb=2.0,
        params="3B",
        family="Qwen",
        description="Qwen Coder 3B — excellent code generation",
    ),
    CatalogModel(
        name="qwen2.5-coder-7b",
        display_name="Qwen 2.5 Coder 7B",
        filename="Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="Qwen",
        description="Qwen Coder 7B — top-tier coding, rivals GPT-3.5",
        default=True,
    ),
    CatalogModel(
        name="qwen2.5-7b",
        display_name="Qwen 2.5 7B",
        filename="Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("Qwen2.5-7B-Instruct-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="Qwen",
        description="Qwen 2.5 7B — strong general-purpose + reasoning",
    ),
    # ── DeepSeek ────────────────────────────────────────────
    CatalogModel(
        name="deepseek-r1-1.5b",
        display_name="DeepSeek R1 Distill Qwen 1.5B",
        filename="DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf",
        url=_gcs_url("DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.5B",
        family="DeepSeek",
        description="DeepSeek R1 reasoning distilled into tiny model",
    ),
    CatalogModel(
        name="deepseek-r1-7b",
        display_name="DeepSeek R1 Distill Qwen 7B",
        filename="DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf",
        url=_gcs_url("DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="DeepSeek",
        description="DeepSeek R1 reasoning — strong chain-of-thought",
        default=True,
    ),
    # ── Mistral ─────────────────────────────────────────────
    CatalogModel(
        name="mistral-7b",
        display_name="Mistral 7B Instruct v0.3",
        filename="Mistral-7B-Instruct-v0.3-Q4_K_M.gguf",
        url=_gcs_url("Mistral-7B-Instruct-v0.3-Q4_K_M.gguf"),
        size_gb=4.4,
        params="7B",
        family="Mistral",
        description="Mistral 7B v0.3 — fast, strong general model",
    ),
    # ── Google CodeGemma ────────────────────────────────────
    CatalogModel(
        name="codegemma-7b",
        display_name="CodeGemma 7B Instruct",
        filename="codegemma-7b-it-Q4_K_M.gguf",
        url=_gcs_url("codegemma-7b-it-Q4_K_M.gguf"),
        size_gb=5.0,
        params="7B",
        family="Gemma",
        description="Google CodeGemma — specifically trained for code tasks",
    ),
    # ── TinyLlama (ultra-fast) ──────────────────────────────
    CatalogModel(
        name="tinyllama-1.1b",
        display_name="TinyLlama 1.1B Chat",
        filename="tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        url=_gcs_url("tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"),
        size_gb=0.7,
        params="1.1B",
        family="TinyLlama",
        description="Ultra-fast tiny model — good for quick tasks",
    ),
    # ── HuggingFace SmolLM2 ────────────────────────────────
    CatalogModel(
        name="smollm2-1.7b",
        display_name="SmolLM2 1.7B Instruct",
        filename="SmolLM2-1.7B-Instruct-Q4_K_M.gguf",
        url=_gcs_url("SmolLM2-1.7B-Instruct-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.7B",
        family="SmolLM",
        description="HuggingFace SmolLM2 — small but surprisingly capable",
    ),
    # ── 01.AI Yi Coder ─────────────────────────────────────
    CatalogModel(
        name="yi-coder-1.5b",
        display_name="Yi Coder 1.5B Chat",
        filename="Yi-Coder-1.5B-Chat-Q4_K_M.gguf",
        url=_gcs_url("Yi-Coder-1.5B-Chat-Q4_K_M.gguf"),
        size_gb=1.0,
        params="1.5B",
        family="Yi",
        description="01.AI Yi Coder — tiny but code-focused",
    ),

    # ══════════════════════════════════════════════════════════
    # Ollama Models — pulled via `ollama pull <name>`
    # Install Ollama from https://ollama.com then use these.
    # ══════════════════════════════════════════════════════════

    # ── Coding models ──────────────────────────────────────
    CatalogModel(name="ollama:qwen2.5-coder", display_name="Qwen 2.5 Coder", filename="", url="", size_gb=0, params="0.5b-32b", family="Qwen", description="Code-specific Qwen with strong code generation and fixing", backend="ollama", tags=("tools",), category="coding"),
    CatalogModel(name="ollama:qwen3-coder", display_name="Qwen 3 Coder", filename="", url="", size_gb=0, params="30b-480b", family="Qwen", description="Performant long-context model for agentic and coding tasks", backend="ollama", tags=("tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:qwen3-coder-next", display_name="Qwen 3 Coder Next", filename="", url="", size_gb=0, params="cloud", family="Qwen", description="Coding-focused model for agentic coding workflows", backend="ollama", tags=("tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:devstral", display_name="Devstral", filename="", url="", size_gb=0, params="24b", family="Mistral", description="Best open source model for coding agents", backend="ollama", tags=("tools",), category="coding"),
    CatalogModel(name="ollama:devstral-small-2", display_name="Devstral Small 2", filename="", url="", size_gb=0, params="24b", family="Mistral", description="Excels at tool use to explore codebases and edit files", backend="ollama", tags=("vision", "tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:devstral-2", display_name="Devstral 2", filename="", url="", size_gb=0, params="123b", family="Mistral", description="123B model for powering software engineering agents", backend="ollama", tags=("tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:codestral", display_name="Codestral", filename="", url="", size_gb=0, params="22b", family="Mistral", description="Mistral AI's code model for code generation", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:codegemma", display_name="CodeGemma", filename="", url="", size_gb=0, params="2b-7b", family="Gemma", description="Google's models for code tasks", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:starcoder2", display_name="StarCoder 2", filename="", url="", size_gb=0, params="3b-15b", family="StarCoder", description="Transparently trained open code LLMs", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:yi-coder", display_name="Yi Coder", filename="", url="", size_gb=0, params="1.5b-9b", family="Yi", description="State-of-the-art code models under 10B parameters", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:deepcoder", display_name="DeepCoder", filename="", url="", size_gb=0, params="1.5b-14b", family="DeepSeek", description="Fully open-source 14B coder at O3-mini level", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:glm-5.1", display_name="GLM 5.1", filename="", url="", size_gb=0, params="cloud", family="GLM", description="Next-gen flagship for agentic engineering with strong coding", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:minimax-m2.7", display_name="MiniMax M2.7", filename="", url="", size_gb=0, params="cloud", family="MiniMax", description="Coding, agentic workflows, and productivity", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:minimax-m2.5", display_name="MiniMax M2.5", filename="", url="", size_gb=0, params="cloud", family="MiniMax", description="Exceptional multilingual capabilities for code engineering", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:minimax-m2", display_name="MiniMax M2", filename="", url="", size_gb=0, params="cloud", family="MiniMax", description="High-efficiency model for coding and agentic workflows", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:minimax-m2.1", display_name="MiniMax M2.1", filename="", url="", size_gb=0, params="cloud", family="MiniMax", description="Exceptional multilingual capabilities for code engineering", backend="ollama", tags=("tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:glm-4.7", display_name="GLM 4.7", filename="", url="", size_gb=0, params="cloud", family="GLM", description="Advanced agentic, reasoning and coding capabilities", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:glm-4.6", display_name="GLM 4.6", filename="", url="", size_gb=0, params="cloud", family="GLM", description="Advanced agentic, reasoning and coding", backend="ollama", tags=("tools", "thinking", "cloud"), category="coding"),
    CatalogModel(name="ollama:rnj-1", display_name="Rnj-1", filename="", url="", size_gb=0, params="8b", family="Essential AI", description="Dense models optimized for code and STEM", backend="ollama", tags=("tools", "cloud"), category="coding"),
    CatalogModel(name="ollama:codellama", display_name="Code Llama", filename="", url="", size_gb=0, params="7b-70b", family="Meta", description="Large language model for code generation", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:deepseek-coder", display_name="DeepSeek Coder", filename="", url="", size_gb=0, params="1.3b-33b", family="DeepSeek", description="Coding model trained on 2 trillion code tokens", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:deepseek-coder-v2", display_name="DeepSeek Coder V2", filename="", url="", size_gb=0, params="16b-236b", family="DeepSeek", description="MoE code model comparable to GPT4-Turbo in code tasks", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:opencoder", display_name="OpenCoder", filename="", url="", size_gb=0, params="1.5b-8b", family="OpenCoder", description="Open and reproducible code LLM", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:codeqwen", display_name="CodeQwen", filename="", url="", size_gb=0, params="7b", family="Qwen", description="Code model pretrained on large amount of code data", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:codegeex4", display_name="CodeGeeX 4", filename="", url="", size_gb=0, params="9b", family="GLM", description="Versatile model for AI software development", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:wizardcoder", display_name="WizardCoder", filename="", url="", size_gb=0, params="33b", family="WizardLM", description="State-of-the-art code generation model", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:stable-code", display_name="Stable Code", filename="", url="", size_gb=0, params="3b", family="Stability", description="Coding model on par with Code Llama 7B at half the size", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:magicoder", display_name="Magicoder", filename="", url="", size_gb=0, params="7b", family="Magicoder", description="7B model trained on 75K synthetic instruction data", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:dolphincoder", display_name="DolphinCoder", filename="", url="", size_gb=0, params="7b-15b", family="Dolphin", description="Uncensored model for coding based on StarCoder2", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:starcoder", display_name="StarCoder", filename="", url="", size_gb=0, params="1b-15b", family="StarCoder", description="Code generation trained on 80+ programming languages", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:sqlcoder", display_name="SQLCoder", filename="", url="", size_gb=0, params="7b-15b", family="SQLCoder", description="Text-to-SQL model fine-tuned on StarCoder", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:codebooga", display_name="CodeBooga", filename="", url="", size_gb=0, params="34b", family="CodeBooga", description="High-performing code instruct model", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:phind-codellama", display_name="Phind CodeLlama", filename="", url="", size_gb=0, params="34b", family="Phind", description="Code generation model based on Code Llama", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:codeup", display_name="CodeUp", filename="", url="", size_gb=0, params="13b", family="CodeUp", description="Code generation model based on Llama2", backend="ollama", tags=(), category="coding"),

    # ── Reasoning / thinking models ────────────────────────
    CatalogModel(name="ollama:deepseek-r1", display_name="DeepSeek R1", filename="", url="", size_gb=0, params="1.5b-671b", family="DeepSeek", description="Open reasoning models approaching O3 and Gemini 2.5 Pro", backend="ollama", tags=("tools", "thinking"), category="reasoning"),
    CatalogModel(name="ollama:qwq", display_name="QwQ", filename="", url="", size_gb=0, params="32b", family="Qwen", description="Reasoning model of the Qwen series", backend="ollama", tags=("tools",), category="reasoning"),
    CatalogModel(name="ollama:phi4-reasoning", display_name="Phi 4 Reasoning", filename="", url="", size_gb=0, params="14b", family="Microsoft", description="Open-weight reasoning models rivaling larger models", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:phi4-mini-reasoning", display_name="Phi 4 Mini Reasoning", filename="", url="", size_gb=0, params="3.8b", family="Microsoft", description="Lightweight reasoning model", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:magistral", display_name="Magistral", filename="", url="", size_gb=0, params="24b", family="Mistral", description="Small, efficient reasoning model", backend="ollama", tags=("tools", "thinking"), category="reasoning"),
    CatalogModel(name="ollama:exaone-deep", display_name="EXAONE Deep", filename="", url="", size_gb=0, params="2.4b-32b", family="LG AI", description="Superior reasoning in math and coding", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:nemotron-cascade-2", display_name="Nemotron Cascade 2", filename="", url="", size_gb=0, params="30b", family="NVIDIA", description="30B MoE with 3B active for strong reasoning", backend="ollama", tags=("tools", "thinking"), category="reasoning"),
    CatalogModel(name="ollama:nemotron-3-super", display_name="Nemotron 3 Super", filename="", url="", size_gb=0, params="120b", family="NVIDIA", description="120B MoE with 12B active for complex multi-agent apps", backend="ollama", tags=("tools", "thinking", "cloud"), category="reasoning"),
    CatalogModel(name="ollama:deepseek-v3.2", display_name="DeepSeek V3.2", filename="", url="", size_gb=0, params="cloud", family="DeepSeek", description="High efficiency with superior reasoning and agent performance", backend="ollama", tags=("tools", "thinking", "cloud"), category="reasoning"),
    CatalogModel(name="ollama:glm-5", display_name="GLM 5", filename="", url="", size_gb=0, params="744b (40b active)", family="GLM", description="Strong reasoning and agentic model", backend="ollama", tags=("tools", "thinking", "cloud"), category="reasoning"),
    CatalogModel(name="ollama:deepscaler", display_name="DeepScaler", filename="", url="", size_gb=0, params="1.5b", family="DeepSeek", description="Surpasses o1-preview with just 1.5B parameters on math", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:openthinker", display_name="OpenThinker", filename="", url="", size_gb=0, params="7b-32b", family="OpenThinker", description="Open-source reasoning model distilled from DeepSeek-R1", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:smallthinker", display_name="SmallThinker", filename="", url="", size_gb=0, params="3b", family="Qwen", description="Small reasoning model fine-tuned from Qwen 2.5 3B", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:marco-o1", display_name="Marco-O1", filename="", url="", size_gb=0, params="7b", family="Alibaba", description="Open large reasoning model for real-world solutions", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:r1-1776", display_name="R1-1776", filename="", url="", size_gb=0, params="70b-671b", family="Perplexity", description="DeepSeek-R1 post-trained for unbiased, factual information", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:deepseek-v3.1", display_name="DeepSeek V3.1", filename="", url="", size_gb=0, params="671b", family="DeepSeek", description="Hybrid model supporting thinking and non-thinking modes", backend="ollama", tags=("tools", "thinking", "cloud"), category="reasoning"),

    # ── General purpose models ─────────────────────────────
    CatalogModel(name="ollama:qwen3.5", display_name="Qwen 3.5", filename="", url="", size_gb=0, params="0.8b-122b", family="Qwen", description="Exceptional utility and performance across all sizes", backend="ollama", tags=("vision", "tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:qwen3", display_name="Qwen 3", filename="", url="", size_gb=0, params="0.6b-235b", family="Qwen", description="Latest generation Qwen with dense and MoE models", backend="ollama", tags=("tools", "thinking"), category="general"),
    CatalogModel(name="ollama:gemma4", display_name="Gemma 4", filename="", url="", size_gb=0, params="e2b-31b", family="Google", description="Frontier-level for reasoning, agentic workflows, coding", backend="ollama", tags=("vision", "tools", "thinking", "audio"), category="general"),
    CatalogModel(name="ollama:gemma3", display_name="Gemma 3", filename="", url="", size_gb=0, params="270m-27b", family="Google", description="Most capable Google model on a single GPU", backend="ollama", tags=("vision", "cloud"), category="general"),
    CatalogModel(name="ollama:gemma2", display_name="Gemma 2", filename="", url="", size_gb=0, params="2b-27b", family="Google", description="Google Gemma 2 — high-performing and efficient", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama3.2", display_name="Llama 3.2", filename="", url="", size_gb=0, params="1b-3b", family="Meta", description="Meta's small Llama models", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:llama3.1", display_name="Llama 3.1", filename="", url="", size_gb=0, params="8b-405b", family="Meta", description="State-of-the-art model from Meta", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:llama3.3", display_name="Llama 3.3", filename="", url="", size_gb=0, params="70b", family="Meta", description="70B with performance comparable to 405B", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:llama3", display_name="Llama 3", filename="", url="", size_gb=0, params="8b-70b", family="Meta", description="Meta's most capable openly available LLM", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama4", display_name="Llama 4", filename="", url="", size_gb=0, params="16x17b-128x17b", family="Meta", description="Meta's latest multimodal models", backend="ollama", tags=("vision", "tools"), category="general"),
    CatalogModel(name="ollama:mistral", display_name="Mistral 7B", filename="", url="", size_gb=0, params="7b", family="Mistral", description="Mistral's 7B model updated to v0.3", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:mistral-small", display_name="Mistral Small", filename="", url="", size_gb=0, params="22b-24b", family="Mistral", description="Benchmark in the small LLM category below 70B", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:mistral-small3.2", display_name="Mistral Small 3.2", filename="", url="", size_gb=0, params="24b", family="Mistral", description="Improved function calling and instruction following", backend="ollama", tags=("vision", "tools"), category="general"),
    CatalogModel(name="ollama:mistral-small3.1", display_name="Mistral Small 3.1", filename="", url="", size_gb=0, params="24b", family="Mistral", description="State-of-the-art vision and 128k context", backend="ollama", tags=("vision", "tools"), category="general"),
    CatalogModel(name="ollama:mistral-nemo", display_name="Mistral Nemo", filename="", url="", size_gb=0, params="12b", family="Mistral", description="12B with 128k context, built with NVIDIA", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:mistral-large", display_name="Mistral Large", filename="", url="", size_gb=0, params="123b", family="Mistral", description="Flagship model with 128k context and dozens of languages", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:mistral-large-3", display_name="Mistral Large 3", filename="", url="", size_gb=0, params="cloud", family="Mistral", description="General-purpose multimodal MoE for enterprise workloads", backend="ollama", tags=("vision", "tools", "cloud"), category="general"),
    CatalogModel(name="ollama:phi4", display_name="Phi 4", filename="", url="", size_gb=0, params="14b", family="Microsoft", description="State-of-the-art open model from Microsoft", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:phi4-mini", display_name="Phi 4 Mini", filename="", url="", size_gb=0, params="3.8b", family="Microsoft", description="Multilingual, reasoning, math, and function calling", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:phi3", display_name="Phi 3", filename="", url="", size_gb=0, params="3.8b-14b", family="Microsoft", description="Lightweight state-of-the-art models by Microsoft", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:phi3.5", display_name="Phi 3.5", filename="", url="", size_gb=0, params="3.8b", family="Microsoft", description="Lightweight AI model with enhanced long context", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:glm-4.7-flash", display_name="GLM 4.7 Flash", filename="", url="", size_gb=0, params="~30b", family="GLM", description="Strongest in 30B class, balancing performance and efficiency", backend="ollama", tags=("tools", "thinking"), category="general"),
    CatalogModel(name="ollama:glm4", display_name="GLM 4", filename="", url="", size_gb=0, params="9b", family="GLM", description="Strong multi-lingual general model", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:granite4", display_name="Granite 4", filename="", url="", size_gb=0, params="350m-3b", family="IBM", description="IBM Granite with improved instruction following and tool-calling", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3.3", display_name="Granite 3.3", filename="", url="", size_gb=0, params="2b-8b", family="IBM", description="IBM Granite 128K context with improved reasoning", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3.2", display_name="Granite 3.2", filename="", url="", size_gb=0, params="2b-8b", family="IBM", description="IBM Granite fine-tuned for thinking capabilities", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3.1-dense", display_name="Granite 3.1 Dense", filename="", url="", size_gb=0, params="2b-8b", family="IBM", description="IBM Granite 12T tokens, improved performance and speed", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3-dense", display_name="Granite 3 Dense", filename="", url="", size_gb=0, params="2b-8b", family="IBM", description="IBM Granite for tool-based use cases and RAG", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3.1-moe", display_name="Granite 3.1 MoE", filename="", url="", size_gb=0, params="1b-3b", family="IBM", description="IBM long-context MoE for low latency", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite3-moe", display_name="Granite 3 MoE", filename="", url="", size_gb=0, params="1b-3b", family="IBM", description="IBM first MoE Granite for low latency", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:granite-code", display_name="Granite Code", filename="", url="", size_gb=0, params="3b-34b", family="IBM", description="IBM open foundation models for Code Intelligence", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:olmo-3", display_name="OLMo 3", filename="", url="", size_gb=0, params="7b-32b", family="Allen AI", description="Open language models for science of LMs", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:olmo-3.1", display_name="OLMo 3.1", filename="", url="", size_gb=0, params="32b", family="Allen AI", description="Fully open-source language model", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:olmo2", display_name="OLMo 2", filename="", url="", size_gb=0, params="7b-13b", family="Allen AI", description="Competitive with Llama 3.1 on English benchmarks", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:hermes3", display_name="Hermes 3", filename="", url="", size_gb=0, params="3b-405b", family="Nous Research", description="Latest Hermes series by Nous Research", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:command-r", display_name="Command R", filename="", url="", size_gb=0, params="35b", family="Cohere", description="Optimized for conversational interaction and long context", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:command-r-plus", display_name="Command R+", filename="", url="", size_gb=0, params="104b", family="Cohere", description="Powerful, scalable model for enterprise use", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:command-a", display_name="Command A", filename="", url="", size_gb=0, params="111b", family="Cohere", description="111B model for demanding enterprises", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:command-r7b", display_name="Command R7B", filename="", url="", size_gb=0, params="7b", family="Cohere", description="Smallest model in R series for edge devices", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:command-r7b-arabic", display_name="Command R7B Arabic", filename="", url="", size_gb=0, params="7b", family="Cohere", description="Arabic language capabilities for MENA enterprises", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:aya-expanse", display_name="Aya Expanse", filename="", url="", size_gb=0, params="8b-32b", family="Cohere", description="Performs well across 23 different languages", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:aya", display_name="Aya 23", filename="", url="", size_gb=0, params="8b-35b", family="Cohere", description="Multilingual models supporting 23 languages", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:cogito", display_name="Cogito", filename="", url="", size_gb=0, params="3b-70b", family="Deep Cogito", description="Hybrid reasoning models outperforming competitors", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:cogito-2.1", display_name="Cogito 2.1", filename="", url="", size_gb=0, params="671b", family="Deep Cogito", description="Instruction-tuned models under MIT license", backend="ollama", tags=("cloud",), category="general"),
    CatalogModel(name="ollama:nemotron-3-nano", display_name="Nemotron 3 Nano", filename="", url="", size_gb=0, params="4b-30b", family="NVIDIA", description="NVIDIA efficient agentic models", backend="ollama", tags=("tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:nemotron", display_name="Nemotron", filename="", url="", size_gb=0, params="70b", family="NVIDIA", description="Llama 3.1 customized by NVIDIA for helpfulness", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:nemotron-mini", display_name="Nemotron Mini", filename="", url="", size_gb=0, params="4b", family="NVIDIA", description="Small model for roleplay, RAG, and function calling", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:gpt-oss", display_name="GPT OSS", filename="", url="", size_gb=0, params="20b-120b", family="OpenAI", description="OpenAI's open-weight models for reasoning and agentic tasks", backend="ollama", tags=("tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:gpt-oss-safeguard", display_name="GPT OSS Safeguard", filename="", url="", size_gb=0, params="20b-120b", family="OpenAI", description="Safety reasoning models built upon gpt-oss", backend="ollama", tags=("tools", "thinking"), category="general"),
    CatalogModel(name="ollama:qwen2.5", display_name="Qwen 2.5", filename="", url="", size_gb=0, params="0.5b-72b", family="Qwen", description="18 trillion tokens, 128K context, multilingual", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:qwen2", display_name="Qwen 2", filename="", url="", size_gb=0, params="0.5b-72b", family="Qwen", description="Qwen 2 large language models", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:qwen3-next", display_name="Qwen 3 Next", filename="", url="", size_gb=0, params="80b", family="Qwen", description="Strong in parameter efficiency and inference speed", backend="ollama", tags=("tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:kimi-k2.5", display_name="Kimi K2.5", filename="", url="", size_gb=0, params="cloud", family="Moonshot", description="Native multimodal agentic model", backend="ollama", tags=("vision", "tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:kimi-k2", display_name="Kimi K2", filename="", url="", size_gb=0, params="cloud", family="Moonshot", description="State-of-the-art MoE with strong coding", backend="ollama", tags=("tools", "cloud"), category="general"),
    CatalogModel(name="ollama:kimi-k2-thinking", display_name="Kimi K2 Thinking", filename="", url="", size_gb=0, params="cloud", family="Moonshot", description="Best open-source thinking model", backend="ollama", tags=("tools", "thinking", "cloud"), category="reasoning"),
    CatalogModel(name="ollama:deepseek-v3", display_name="DeepSeek V3", filename="", url="", size_gb=0, params="671b", family="DeepSeek", description="Strong MoE with 671B total / 37B active", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:deepseek-v2.5", display_name="DeepSeek V2.5", filename="", url="", size_gb=0, params="236b", family="DeepSeek", description="Integrates general and coding abilities", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:deepseek-v2", display_name="DeepSeek V2", filename="", url="", size_gb=0, params="16b-236b", family="DeepSeek", description="Strong, economical MoE language model", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:deepseek-llm", display_name="DeepSeek LLM", filename="", url="", size_gb=0, params="7b-67b", family="DeepSeek", description="Advanced model trained on 2 trillion tokens", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:mixtral", display_name="Mixtral", filename="", url="", size_gb=0, params="8x7b-8x22b", family="Mistral", description="Mixture of Experts by Mistral AI", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:dolphin3", display_name="Dolphin 3", filename="", url="", size_gb=0, params="8b", family="Dolphin", description="General purpose model for coding, math, agentic", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:dolphin-llama3", display_name="Dolphin Llama 3", filename="", url="", size_gb=0, params="8b-70b", family="Dolphin", description="Instruct, conversational, and coding skills", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:dolphin-mixtral", display_name="Dolphin Mixtral", filename="", url="", size_gb=0, params="8x7b-8x22b", family="Dolphin", description="Uncensored model that excels at coding", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:dolphin-mistral", display_name="Dolphin Mistral", filename="", url="", size_gb=0, params="7b", family="Dolphin", description="Uncensored model that excels at coding", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:dolphin-phi", display_name="Dolphin Phi", filename="", url="", size_gb=0, params="2.7b", family="Dolphin", description="Uncensored 2.7B model based on Microsoft Phi", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:falcon3", display_name="Falcon 3", filename="", url="", size_gb=0, params="1b-10b", family="TII", description="Efficient models under 10B for science, math, coding", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:falcon2", display_name="Falcon 2", filename="", url="", size_gb=0, params="11b", family="TII", description="11B model with 5T tokens of training", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:falcon", display_name="Falcon", filename="", url="", size_gb=0, params="7b-180b", family="TII", description="Large language model by Technology Innovation Institute", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:solar-pro", display_name="Solar Pro", filename="", url="", size_gb=0, params="22b", family="Solar", description="Advanced LLM designed to fit in a single GPU", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:solar", display_name="Solar", filename="", url="", size_gb=0, params="10.7b", family="Solar", description="Compact, powerful model for single-turn conversation", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:internlm2", display_name="InternLM 2", filename="", url="", size_gb=0, params="1.8b-20b", family="InternLM", description="Outstanding reasoning capability", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:yi", display_name="Yi 1.5", filename="", url="", size_gb=0, params="6b-34b", family="Yi", description="High-performing bilingual model", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:exaone3.5", display_name="EXAONE 3.5", filename="", url="", size_gb=0, params="2.4b-32b", family="LG AI", description="Instruction-tuned bilingual models (English/Korean)", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama2", display_name="Llama 2", filename="", url="", size_gb=0, params="7b-70b", family="Meta", description="Collection of foundation language models", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama2-uncensored", display_name="Llama 2 Uncensored", filename="", url="", size_gb=0, params="7b-70b", family="Llama", description="Uncensored Llama 2 model", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:dbrx", display_name="DBRX", filename="", url="", size_gb=0, params="132b", family="Databricks", description="Open general-purpose LLM by Databricks", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:wizard-vicuna-uncensored", display_name="Wizard Vicuna Uncensored", filename="", url="", size_gb=0, params="7b-30b", family="WizardLM", description="Uncensored model based on Llama 2", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:wizardlm2", display_name="WizardLM 2", filename="", url="", size_gb=0, params="7b-8x22b", family="WizardLM", description="State-of-the-art for chat, multilingual, reasoning", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:wizardlm", display_name="WizardLM", filename="", url="", size_gb=0, params="general", family="WizardLM", description="General use model based on Llama 2", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:wizardlm-uncensored", display_name="WizardLM Uncensored", filename="", url="", size_gb=0, params="13b", family="WizardLM", description="Uncensored version of Wizard LM", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:athene-v2", display_name="Athene V2", filename="", url="", size_gb=0, params="72b", family="Athene", description="Excels at code completion, math, and log extraction", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:tulu3", display_name="Tülu 3", filename="", url="", size_gb=0, params="8b-70b", family="Allen AI", description="Leading instruction following model family", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:sailor2", display_name="Sailor 2", filename="", url="", size_gb=0, params="1b-20b", family="Sailor", description="Multilingual models for South-East Asia", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:nous-hermes2", display_name="Nous Hermes 2", filename="", url="", size_gb=0, params="10.7b-34b", family="Nous Research", description="Excels at scientific discussion and coding", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:nous-hermes2-mixtral", display_name="Nous Hermes 2 Mixtral", filename="", url="", size_gb=0, params="8x7b", family="Nous Research", description="Hermes 2 trained over Mixtral", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:nous-hermes", display_name="Nous Hermes", filename="", url="", size_gb=0, params="7b-13b", family="Nous Research", description="General use models based on Llama", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:openchat", display_name="OpenChat", filename="", url="", size_gb=0, params="7b", family="OpenChat", description="Surpasses ChatGPT on various benchmarks", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:openhermes", display_name="OpenHermes", filename="", url="", size_gb=0, params="7b", family="Teknium", description="Fine-tuned by Teknium on Mistral", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:vicuna", display_name="Vicuna", filename="", url="", size_gb=0, params="7b-33b", family="Vicuna", description="General use chat model based on Llama", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:zephyr", display_name="Zephyr", filename="", url="", size_gb=0, params="7b-141b", family="Zephyr", description="Fine-tuned Mistral/Mixtral for helpful assistance", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:starling-lm", display_name="Starling LM", filename="", url="", size_gb=0, params="7b", family="Starling", description="Trained by RL from AI feedback for chatbot helpfulness", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:neural-chat", display_name="Neural Chat", filename="", url="", size_gb=0, params="7b", family="Intel", description="Fine-tuned Mistral with good domain coverage", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama-pro", display_name="Llama Pro", filename="", url="", size_gb=0, params="8b", family="Meta", description="Llama 2 expansion for programming and mathematics", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama3-chatqa", display_name="Llama 3 ChatQA", filename="", url="", size_gb=0, params="8b-70b", family="NVIDIA", description="Excels at conversational QA and RAG", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:firefunction-v2", display_name="FireFunction V2", filename="", url="", size_gb=0, params="70b", family="Fireworks", description="Function calling competitive with GPT-4o", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:llama3-groq-tool-use", display_name="Llama 3 Groq Tool Use", filename="", url="", size_gb=0, params="8b-70b", family="Groq", description="Open-source AI for tool use/function calling", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:llama-guard3", display_name="Llama Guard 3", filename="", url="", size_gb=0, params="1b-8b", family="Meta", description="Content safety classification of LLM inputs/responses", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:granite3-guardian", display_name="Granite 3 Guardian", filename="", url="", size_gb=0, params="2b-8b", family="IBM", description="Detect risks in prompts and responses", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:bespoke-minicheck", display_name="Bespoke Minicheck", filename="", url="", size_gb=0, params="7b", family="Bespoke", description="State-of-the-art fact-checking model", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:reflection", display_name="Reflection", filename="", url="", size_gb=0, params="70b", family="Reflection", description="Self-correcting model using Reflection-tuning", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:nuextract", display_name="NuExtract", filename="", url="", size_gb=0, params="3.8b", family="NuExtract", description="Fine-tuned for information extraction", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:lfm2", display_name="LFM2", filename="", url="", size_gb=0, params="24b", family="LFM", description="Hybrid models for on-device deployment", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:lfm2.5-thinking", display_name="LFM2.5 Thinking", filename="", url="", size_gb=0, params="1.2b", family="LFM", description="On-device deployment with thinking", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:gemini-3-flash-preview", display_name="Gemini 3 Flash Preview", filename="", url="", size_gb=0, params="cloud", family="Google", description="Frontier intelligence built for speed", backend="ollama", tags=("vision", "tools", "thinking", "cloud"), category="general"),
    CatalogModel(name="ollama:wizard-math", display_name="Wizard Math", filename="", url="", size_gb=0, params="7b-70b", family="WizardLM", description="Focused on math and logic problems", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:mathstral", display_name="Mathstral", filename="", url="", size_gb=0, params="7b", family="Mistral", description="7B model for math reasoning and scientific discovery", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:qwen2-math", display_name="Qwen 2 Math", filename="", url="", size_gb=0, params="1.5b-72b", family="Qwen", description="Specialized math model outperforming GPT-4o on math", backend="ollama", tags=(), category="reasoning"),

    # ── Vision models ──────────────────────────────────────
    CatalogModel(name="ollama:qwen3-vl", display_name="Qwen 3 VL", filename="", url="", size_gb=0, params="2b-235b", family="Qwen", description="Most powerful vision-language model in Qwen family", backend="ollama", tags=("vision", "tools", "thinking"), category="vision"),
    CatalogModel(name="ollama:qwen2.5vl", display_name="Qwen 2.5 VL", filename="", url="", size_gb=0, params="3b-72b", family="Qwen", description="Flagship vision-language model", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:llama3.2-vision", display_name="Llama 3.2 Vision", filename="", url="", size_gb=0, params="11b-90b", family="Meta", description="Meta's instruction-tuned image reasoning models", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:granite3.2-vision", display_name="Granite 3.2 Vision", filename="", url="", size_gb=0, params="2b", family="IBM", description="Compact model for visual document understanding", backend="ollama", tags=("vision", "tools"), category="vision"),
    CatalogModel(name="ollama:moondream", display_name="Moondream", filename="", url="", size_gb=0, params="1.8b", family="Moondream", description="Small vision language model for edge devices", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:minicpm-v", display_name="MiniCPM-V", filename="", url="", size_gb=0, params="8b", family="MiniCPM", description="Multimodal LLMs for vision-language understanding", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:llava", display_name="LLaVA", filename="", url="", size_gb=0, params="7b-34b", family="LLaVA", description="End-to-end trained multimodal model", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:llava-phi3", display_name="LLaVA Phi3", filename="", url="", size_gb=0, params="3.8b", family="LLaVA", description="Small LLaVA fine-tuned from Phi 3 Mini", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:llava-llama3", display_name="LLaVA Llama3", filename="", url="", size_gb=0, params="8b", family="LLaVA", description="LLaVA fine-tuned from Llama 3", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:bakllava", display_name="BakLLaVA", filename="", url="", size_gb=0, params="7b", family="BakLLaVA", description="Mistral 7B with LLaVA architecture", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:glm-ocr", display_name="GLM OCR", filename="", url="", size_gb=0, params="cloud", family="GLM", description="Multimodal OCR for complex document understanding", backend="ollama", tags=("vision", "tools"), category="vision"),
    CatalogModel(name="ollama:deepseek-ocr", display_name="DeepSeek OCR", filename="", url="", size_gb=0, params="3b", family="DeepSeek", description="Vision-language model for token-efficient OCR", backend="ollama", tags=("vision",), category="vision"),
    CatalogModel(name="ollama:translategemma", display_name="TranslateGemma", filename="", url="", size_gb=0, params="4b-27b", family="Google", description="Open translation models for 55 languages", backend="ollama", tags=("vision",), category="vision"),

    # ── Small / edge models ────────────────────────────────
    CatalogModel(name="ollama:smollm2", display_name="SmolLM2", filename="", url="", size_gb=0, params="135m-1.7b", family="HuggingFace", description="Compact language models", backend="ollama", tags=("tools",), category="small"),
    CatalogModel(name="ollama:smollm", display_name="SmolLM", filename="", url="", size_gb=0, params="135m-1.7b", family="HuggingFace", description="Small models trained on high-quality data", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:tinyllama", display_name="TinyLlama", filename="", url="", size_gb=0, params="1.1b", family="TinyLlama", description="Compact 1.1B model trained on 3 trillion tokens", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:tinydolphin", display_name="TinyDolphin", filename="", url="", size_gb=0, params="1.1b", family="Dolphin", description="Experimental 1.1B model based on TinyLlama", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:gemma3n", display_name="Gemma 3n", filename="", url="", size_gb=0, params="e2b-e4b", family="Google", description="Efficient execution on everyday devices", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:ministral-3", display_name="Ministral 3", filename="", url="", size_gb=0, params="3b-14b", family="Mistral", description="Edge deployment on a wide range of hardware", backend="ollama", tags=("vision", "tools", "cloud"), category="small"),
    CatalogModel(name="ollama:functiongemma", display_name="FunctionGemma", filename="", url="", size_gb=0, params="270m", family="Google", description="Specialized 270M for function calling", backend="ollama", tags=("tools",), category="small"),
    CatalogModel(name="ollama:stablelm2", display_name="StableLM 2", filename="", url="", size_gb=0, params="1.6b-12b", family="Stability", description="State-of-the-art multilingual model", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:stablelm-zephyr", display_name="StableLM Zephyr", filename="", url="", size_gb=0, params="3b", family="Stability", description="Lightweight chat model", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:reader-lm", display_name="Reader LM", filename="", url="", size_gb=0, params="0.5b-1.5b", family="Jina", description="HTML to Markdown conversion models", backend="ollama", tags=(), category="small"),
    CatalogModel(name="ollama:phi", display_name="Phi 2", filename="", url="", size_gb=0, params="2.7b", family="Microsoft", description="2.7B model with outstanding reasoning", backend="ollama", tags=(), category="small"),

    # ── Embedding models ───────────────────────────────────
    CatalogModel(name="ollama:nomic-embed-text", display_name="Nomic Embed Text", filename="", url="", size_gb=0, params="embed", family="Nomic", description="High-performing open embedding model", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:nomic-embed-text-v2-moe", display_name="Nomic Embed Text V2 MoE", filename="", url="", size_gb=0, params="embed", family="Nomic", description="Multilingual MoE text embedding model", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:mxbai-embed-large", display_name="Mxbai Embed Large", filename="", url="", size_gb=0, params="335m", family="Mixedbread", description="State-of-the-art large embedding model", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:bge-m3", display_name="BGE-M3", filename="", url="", size_gb=0, params="567m", family="BAAI", description="Multi-Functionality, Multi-Linguality embedding", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:bge-large", display_name="BGE Large", filename="", url="", size_gb=0, params="335m", family="BAAI", description="Embedding model mapping texts to vectors", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:snowflake-arctic-embed", display_name="Snowflake Arctic Embed", filename="", url="", size_gb=0, params="22m-335m", family="Snowflake", description="Text embeddings optimized for performance", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:snowflake-arctic-embed2", display_name="Snowflake Arctic Embed 2", filename="", url="", size_gb=0, params="568m", family="Snowflake", description="Frontier embedding with multilingual support", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:all-minilm", display_name="All MiniLM", filename="", url="", size_gb=0, params="22m-33m", family="MiniLM", description="Sentence-level embedding models", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:paraphrase-multilingual", display_name="Paraphrase Multilingual", filename="", url="", size_gb=0, params="278m", family="Sentence-Transformers", description="For clustering and semantic search", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:granite-embedding", display_name="Granite Embedding", filename="", url="", size_gb=0, params="30m-278m", family="IBM", description="IBM text-only dense embedding models", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:embeddinggemma", display_name="EmbeddingGemma", filename="", url="", size_gb=0, params="300m", family="Google", description="300M embedding model from Google", backend="ollama", tags=("embedding",), category="embedding"),
    CatalogModel(name="ollama:qwen3-embedding", display_name="Qwen 3 Embedding", filename="", url="", size_gb=0, params="0.6b-8b", family="Qwen", description="Comprehensive range of text embeddings", backend="ollama", tags=("embedding",), category="embedding"),

    # ── Additional Ollama models (legacy + specialized) ────
    CatalogModel(name="ollama:gemma", display_name="Gemma", filename="", url="", size_gb=0, params="2b-7b", family="Google", description="Lightweight, state-of-the-art open models by Google DeepMind", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:qwen", display_name="Qwen 1.5", filename="", url="", size_gb=0, params="0.5b-110b", family="Qwen", description="Series of LLMs by Alibaba Cloud", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:orca-mini", display_name="Orca Mini", filename="", url="", size_gb=0, params="3b-70b", family="Orca", description="General-purpose model for entry-level hardware", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:orca2", display_name="Orca 2", filename="", url="", size_gb=0, params="7b-13b", family="Orca", description="Microsoft model that excels at reasoning", backend="ollama", tags=(), category="reasoning"),
    CatalogModel(name="ollama:llama2-chinese", display_name="Llama 2 Chinese", filename="", url="", size_gb=0, params="7b-13b", family="Meta", description="Llama 2 fine-tuned for Chinese dialogue", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:yarn-llama2", display_name="YaRN Llama 2", filename="", url="", size_gb=0, params="7b-13b", family="Meta", description="Llama 2 extended to 128K context", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:yarn-mistral", display_name="YaRN Mistral", filename="", url="", size_gb=0, params="7b", family="Mistral", description="Mistral extended to 64K-128K context", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:samantha-mistral", display_name="Samantha Mistral", filename="", url="", size_gb=0, params="7b", family="Mistral", description="Companion assistant trained in philosophy and psychology", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:mistral-openorca", display_name="Mistral OpenOrca", filename="", url="", size_gb=0, params="7b", family="Mistral", description="Fine-tuned Mistral using OpenOrca dataset", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:mistrallite", display_name="MistralLite", filename="", url="", size_gb=0, params="7b", family="Mistral", description="Fine-tuned Mistral for long contexts", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:nexusraven", display_name="Nexus Raven", filename="", url="", size_gb=0, params="13b", family="Nexus", description="Instruction-tuned model for function calling", backend="ollama", tags=("tools",), category="general"),
    CatalogModel(name="ollama:shieldgemma", display_name="ShieldGemma", filename="", url="", size_gb=0, params="2b-27b", family="Google", description="Safety models for evaluating text safety", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:stable-beluga", display_name="Stable Beluga", filename="", url="", size_gb=0, params="7b-70b", family="Stability", description="Llama 2 fine-tuned on Orca-style dataset", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:notus", display_name="Notus", filename="", url="", size_gb=0, params="7b", family="Notus", description="Chat model fine-tuned with high-quality data", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:notux", display_name="Notux", filename="", url="", size_gb=0, params="8x7b", family="Notux", description="Top-performing MoE model fine-tuned with high-quality data", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:goliath", display_name="Goliath", filename="", url="", size_gb=0, params="120b", family="Goliath", description="Combining two fine-tuned Llama 2 70B models", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:megadolphin", display_name="MegaDolphin", filename="", url="", size_gb=0, params="120b", family="Dolphin", description="Dolphin-2.2-70b interleaved with itself", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:wizard-vicuna", display_name="Wizard Vicuna", filename="", url="", size_gb=0, params="13b", family="WizardLM", description="Llama 2 based model by MelodysDreamj", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:open-orca-platypus2", display_name="Open Orca Platypus 2", filename="", url="", size_gb=0, params="13b", family="Platypus", description="Merge of OpenChat and Platypus for chat and code", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:xwinlm", display_name="XWinLM", filename="", url="", size_gb=0, params="7b-13b", family="XWinLM", description="Conversational model competitive on benchmarks", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:alfred", display_name="Alfred", filename="", url="", size_gb=0, params="40b", family="Alfred", description="Robust conversational model for chat and instruct", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:everythinglm", display_name="EverythingLM", filename="", url="", size_gb=0, params="13b", family="EverythingLM", description="Uncensored Llama2 with 16K context", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:llama3-gradient", display_name="Llama 3 Gradient", filename="", url="", size_gb=0, params="8b-70b", family="Meta", description="Llama 3 extended to over 1M context tokens", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:duckdb-nsql", display_name="DuckDB NSQL", filename="", url="", size_gb=0, params="7b", family="DuckDB", description="Text-to-SQL model by MotherDuck", backend="ollama", tags=(), category="coding"),
    CatalogModel(name="ollama:meditron", display_name="Meditron", filename="", url="", size_gb=0, params="7b-70b", family="Medical", description="Open-source medical LLM adapted from Llama 2", backend="ollama", tags=(), category="general"),
    CatalogModel(name="ollama:medllama2", display_name="MedLlama 2", filename="", url="", size_gb=0, params="7b", family="Medical", description="Fine-tuned Llama 2 for medical questions", backend="ollama", tags=(), category="general"),
]

# Quick lookup by name
CATALOG_BY_NAME: dict[str, CatalogModel] = {m.name: m for m in MODEL_CATALOG}


def search_catalog(query: str) -> list[CatalogModel]:
    """Search the catalog by name, family, or description."""
    q = query.lower()
    return [
        m for m in MODEL_CATALOG
        if q in m.name.lower()
        or q in m.family.lower()
        or q in m.display_name.lower()
        or q in m.description.lower()
    ]


def get_recommended_models() -> list[CatalogModel]:
    """Return a curated list of recommended starter models (GGUF)."""
    recs = ["qwen2.5-coder-7b", "deepseek-r1-7b", "llama3.2-3b", "qwen2.5-coder-3b"]
    return [CATALOG_BY_NAME[n] for n in recs if n in CATALOG_BY_NAME]


# ── Ollama catalog helpers ─────────────────────────────────
# Work against MODEL_CATALOG entries with backend="ollama".

# For backwards compat, OllamaModel is just CatalogModel
OllamaModel = CatalogModel


OLLAMA_CATALOG: list[CatalogModel] = [
    m for m in MODEL_CATALOG if m.backend == "ollama"
]

OLLAMA_BY_NAME: dict[str, CatalogModel] = {
    m.name: m for m in OLLAMA_CATALOG
}
# Strip "ollama:" prefix for alternate lookup
OLLAMA_BY_NAME.update({
    m.name.removeprefix("ollama:"): m for m in OLLAMA_CATALOG
})


def search_ollama_catalog(query: str) -> list[CatalogModel]:
    """Search the Ollama catalog by name, category, or description."""
    q = query.lower()
    return [
        m for m in OLLAMA_CATALOG
        if q in m.name.lower()
        or q in m.category.lower()
        or q in m.display_name.lower()
        or q in m.description.lower()
    ]


def get_recommended_ollama_models() -> list[CatalogModel]:
    """Return recommended Ollama models for Sage — the best available."""
    recs = [
        "ollama:qwen3.5",          # Alibaba's latest flagship
        "ollama:gemma4",            # Google's best
        "ollama:glm-5.1",          # Z.ai's best coding agent
        "ollama:devstral",          # Mistral's best coding agent
        "ollama:nemotron-mini",     # NVIDIA's fast reasoning
        "ollama:qwen3",             # Strong all-around
        "ollama:deepseek-r1",       # Best open reasoning
        "ollama:mistral-small",     # Efficient general purpose
        "ollama:phi4-mini",         # Microsoft's small powerhouse
        "ollama:minimax-m2.7",      # MiniMax's best for coding
    ]
    return [CATALOG_BY_NAME[n] for n in recs if n in CATALOG_BY_NAME]


def get_ollama_models_by_category(category: str) -> list[CatalogModel]:
    """Filter Ollama catalog by category."""
    return [m for m in OLLAMA_CATALOG if m.category == category]


def get_default_models() -> list[CatalogModel]:
    """Return models that should be installed by default.
    These are the best models for coding that run well on most hardware.
    GGUF defaults (~11.4 GB): qwen2.5-coder-7b, deepseek-r1-7b, llama3.2-3b
    """
    return [m for m in MODEL_CATALOG if m.default and m.backend == "gguf"]


# Best Ollama models to pre-pull on `sage install`
DEFAULT_OLLAMA_MODELS = [
    "qwen3.5",          # Alibaba's latest flagship — best overall
    "gemma4",           # Google's best — strong reasoning + coding
    "devstral",         # Mistral's best coding agent model
    "nemotron-mini",    # NVIDIA's fast reasoning model
    "deepseek-r1:7b",  # Best open reasoning model
    "phi4-mini",        # Microsoft's strong small model
    "mistral-small",    # Mistral's efficient general model
    "qwen3",            # Alibaba Qwen 3 — strong all-around
]


# Best model rankings for display and recommendations
BEST_MODELS_RANKED = [
    # Tier 1: State-of-the-art (latest flagships)
    "qwen3.5", "gemma4", "devstral", "qwen3",
    # Tier 2: Best reasoning + coding agents
    "deepseek-r1:7b", "nemotron-mini", "mistral-small", "phi4-mini",
    # Tier 3: Best dedicated coding
    "qwen2.5-coder-7b", "codegemma", "deepcoder",
    # Tier 4: General purpose
    "llama3.2-3b", "llama3.1-8b", "qwen2.5-7b",
]


DEFAULT_MODEL_NAME = "qwen2.5-coder-7b"


# ── Remote catalog auto-update ────────────────────────────

GCS_CATALOG_URL = "https://storage.googleapis.com/sage-ai-models/catalog.json"
_CACHE_DIR = Path.home() / ".sage" / "cache"
_CACHE_FILE = _CACHE_DIR / "catalog.json"
_CACHE_TTL_SECONDS = 3600  # 1 hour


def _dict_to_model(d: dict) -> CatalogModel:
    return CatalogModel(
        name=d["name"],
        display_name=d.get("display_name", d["name"]),
        filename=d.get("filename", ""),
        url=d.get("url", ""),
        size_gb=d.get("size_gb", 0),
        params=d.get("params", ""),
        family=d.get("family", ""),
        description=d.get("description", ""),
        backend=d.get("backend", "gguf"),
        tags=tuple(d.get("tags", ())),
        category=d.get("category", "general"),
        default=d.get("default", False),
    )


def fetch_remote_catalog(force: bool = False) -> list[CatalogModel] | None:
    """Fetch the latest catalog from GCS with local cache.

    Returns a list of CatalogModel if successful, or None to use the
    hardcoded catalog as fallback.
    """
    # Check cache first
    if not force and _CACHE_FILE.exists():
        age = time.time() - _CACHE_FILE.stat().st_mtime
        if age < _CACHE_TTL_SECONDS:
            try:
                data = json.loads(_CACHE_FILE.read_text())
                return [_dict_to_model(m) for m in data.get("models", [])]
            except (json.JSONDecodeError, KeyError):
                pass  # Corrupted cache, fetch fresh

    # Fetch from GCS
    try:
        import httpx
        resp = httpx.get(GCS_CATALOG_URL, timeout=10, follow_redirects=True)
        resp.raise_for_status()
        data = resp.json()

        # Cache it
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(json.dumps(data, indent=2))

        return [_dict_to_model(m) for m in data.get("models", [])]
    except Exception:
        # Network failure — try stale cache
        if _CACHE_FILE.exists():
            try:
                data = json.loads(_CACHE_FILE.read_text())
                return [_dict_to_model(m) for m in data.get("models", [])]
            except (json.JSONDecodeError, KeyError):
                pass

    return None  # Use hardcoded catalog


def get_full_catalog() -> list[CatalogModel]:
    """Return the best available catalog: remote > cache > hardcoded."""
    remote = fetch_remote_catalog()
    if remote and len(remote) > 0:
        return remote
    return MODEL_CATALOG

