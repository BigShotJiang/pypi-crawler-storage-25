"""Tests for autopolit improvements - TDD approach."""

import pytest
import re
import tempfile
import shutil
from pathlib import Path

# Import the functions we're testing
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from sage.main import (
    _extract_and_write_files,
    _is_garbage_content,
    _detect_broken_test_files,
    _cleanup_broken_tests,
    _validate_imports_in_content,
    _module_exists_in_codebase,
)


def _extract_file_blocks(response: str) -> list[tuple[str, str]]:
    """Extract FILE: blocks from response.

    Returns list of (filepath, content) tuples.
    This function tests the FILE block extraction logic.
    """
    blocks = []

    # Primary pattern: FILE: path\n```lang\ncontent\n```
    # Also handles FILE:path (no space) and extra whitespace
    pattern = r"FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```"

    for m in re.finditer(pattern, response, re.DOTALL):
        fp = m.group(1).strip()
        content = m.group(2)
        blocks.append((fp, content))

    return blocks


class MockRenderer:
    """Mock renderer for testing."""
    def __init__(self):
        self.warnings = []
        self.infos = []
        self.errors = []

    def warning(self, msg):
        self.warnings.append(msg)

    def info(self, msg):
        self.infos.append(msg)

    def error(self, msg):
        self.errors.append(msg)


class TestFileBlockExtraction:
    """Test FILE: block parsing and extraction."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.renderer = MockRenderer()

    def teardown_method(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_extract_simple_file_block(self):
        """Test extracting a simple FILE: block."""
        response = '''Here's the code:

FILE: test.py
```python
def hello():
    return "world"
```

That's the implementation.'''

        blocks = _extract_file_blocks(response)
        assert len(blocks) == 1
        assert blocks[0][0] == "test.py"
        assert "def hello():" in blocks[0][1]

    def test_extract_multiple_file_blocks(self):
        """Test extracting multiple FILE: blocks."""
        response = '''Creating two files:

FILE: foo.py
```python
def foo():
    return 1
```

FILE: bar.py
```python
def bar():
    return 2
```
'''
        blocks = _extract_file_blocks(response)
        assert len(blocks) == 2
        assert blocks[0][0] == "foo.py"
        assert blocks[1][0] == "bar.py"

    def test_extract_file_block_with_path(self):
        """Test FILE: block with subdirectory path."""
        response = '''
FILE: src/utils/helpers.py
```python
def helper():
    pass
```
'''
        blocks = _extract_file_blocks(response)
        assert len(blocks) == 1
        assert blocks[0][0] == "src/utils/helpers.py"

    def test_ignore_code_blocks_without_file_prefix(self):
        """Test that regular code blocks without FILE: are ignored."""
        response = '''Here's some code:

```python
def example():
    return True
```

That's it.'''

        blocks = _extract_file_blocks(response)
        assert len(blocks) == 0

    def test_extract_file_block_various_formats(self):
        """Test FILE: block with various formats."""
        # Test with space after FILE:
        response1 = '''FILE: test.py
```python
code
```'''

        # Test with newline immediately after FILE:
        response2 = '''FILE:test.py
```python
code
```'''

        # Test with extra whitespace
        response3 = '''FILE:   test.py
```python
code
```'''

        for response in [response1, response2, response3]:
            blocks = _extract_file_blocks(response)
            assert len(blocks) >= 0  # Should not crash


class TestGarbageContentDetection:
    """Test garbage content detection."""

    def test_empty_functions_detected(self):
        """Test that files with too many empty functions are rejected."""
        content = '''
def func1():
    pass

def func2():
    pass

def func3():
    pass
'''
        is_garbage, reason = _is_garbage_content("test.py", content)
        assert is_garbage is True
        # Accept both "empty functions" and "empty function(s)" formats
        assert "empty function" in reason.lower()
        assert "pass" in reason.lower()

    def test_test_without_assertions_rejected(self):
        """Test that test files without assertions are rejected."""
        content = '''
def test_something():
    x = 1 + 1
    y = 2
'''
        is_garbage, reason = _is_garbage_content("test_foo.py", content)
        assert is_garbage is True
        # Accept both "no assertions" and "no real assertions" formats
        assert "assertion" in reason.lower()

    def test_test_with_assertions_accepted(self):
        """Test that test files with assertions are accepted."""
        content = '''
def test_something():
    x = 1 + 1
    assert x == 2
'''
        is_garbage, reason = _is_garbage_content("test_foo.py", content)
        assert is_garbage is False

    def test_placeholder_comments_rejected(self):
        """Test that files with placeholder comments are rejected."""
        content = '''
def foo():
    # TODO: implement this
    pass
'''
        is_garbage, reason = _is_garbage_content("foo.py", content)
        assert is_garbage is True
        assert "placeholder" in reason.lower() or "TODO" in reason

    def test_valid_implementation_accepted(self):
        """Test that valid implementations are accepted."""
        content = '''
def calculate_sum(a, b):
    """Calculate sum of two numbers."""
    return a + b

def calculate_product(a, b):
    """Calculate product of two numbers."""
    return a * b
'''
        is_garbage, reason = _is_garbage_content("math_utils.py", content)
        assert is_garbage is False


class TestBrokenTestDetection:
    """Test broken test file detection."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())
        # Create tests directory
        (self.temp_dir / "tests").mkdir()
        # Create a broken test file
        (self.temp_dir / "tests" / "test_broken.py").write_text('''
from nonexistent_module import something

def test_foo():
    assert True
''')

    def teardown_method(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_detect_import_error(self):
        """Test detection of ModuleNotFoundError in test output."""
        output = '''
============================= test session starts ==============================
tests/test_broken.py:1: in <module>
    from nonexistent_module import something
E   ModuleNotFoundError: No module named 'nonexistent_module'
'''
        broken = _detect_broken_test_files(output, self.temp_dir)
        assert len(broken) == 1
        assert "test_broken.py" in str(broken[0])

    def test_detect_error_collecting(self):
        """Test detection of 'error collecting' pattern."""
        output = '''
============================= ERRORS =============================
____________ ERROR collecting tests/test_broken.py ____________
tests/test_broken.py:1: in <module>
    from fake_module import fake_func
E   ModuleNotFoundError: No module named 'fake_module'
'''
        broken = _detect_broken_test_files(output, self.temp_dir)
        assert len(broken) == 1

    def test_ignore_valid_import_errors(self):
        """Test that import errors for standard library are ignored."""
        # Create a test file that imports from standard library
        (self.temp_dir / "tests" / "test_valid.py").write_text('''
import json  # Standard library
def test_foo():
    assert json.loads('{}') == {}
''')
        output = '''
tests/test_valid.py:1: in <module>
    import json
'''
        broken = _detect_broken_test_files(output, self.temp_dir)
        # Should not detect json as broken
        broken_names = [str(b) for b in broken]
        assert not any("test_valid.py" in name for name in broken_names)


class TestImportValidation:
    """Test import validation for Python files."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())
        # Create a local module
        (self.temp_dir / "my_module.py").write_text("def foo(): pass")
        # Create a package
        pkg_dir = self.temp_dir / "my_package"
        pkg_dir.mkdir()
        (pkg_dir / "__init__.py").write_text("")
        (pkg_dir / "utils.py").write_text("def bar(): pass")

    def teardown_method(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_local_module_exists(self):
        """Test that local modules are detected."""
        assert _module_exists_in_codebase("my_module", self.temp_dir) is True

    def test_local_package_exists(self):
        """Test that local packages are detected."""
        assert _module_exists_in_codebase("my_package", self.temp_dir) is True

    def test_nonexistent_module_not_found(self):
        """Test that nonexistent modules are not found."""
        assert _module_exists_in_codebase("nonexistent_xyz", self.temp_dir) is False

    def test_standard_library_exists(self):
        """Test that standard library modules are detected."""
        assert _module_exists_in_codebase("json", self.temp_dir) is True
        assert _module_exists_in_codebase("os", self.temp_dir) is True
        assert _module_exists_in_codebase("sys", self.temp_dir) is True

    def test_validate_imports_with_local_module(self):
        """Test validation passes for local modules."""
        content = '''
from my_module import foo
def test_foo():
    assert foo() is None
'''
        is_valid, missing = _validate_imports_in_content(content, self.temp_dir)
        assert is_valid is True
        assert len(missing) == 0

    def test_validate_imports_with_missing_module(self):
        """Test validation fails for missing modules."""
        content = '''
from totally_fake_module import fake_func
def test_fake():
    fake_func()
'''
        is_valid, missing = _validate_imports_in_content(content, self.temp_dir)
        assert is_valid is False
        assert "totally_fake_module" in missing


class TestFileWriting:
    """Test file writing with validation."""

    def setup_method(self):
        """Set up test fixtures."""
        from sage.main import _clear_classification

        _clear_classification()
        self.temp_dir = Path(tempfile.mkdtemp())
        # Create an existing file to test READ-before-write
        (self.temp_dir / "existing.py").write_text("# Original content\n")

    def teardown_method(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_write_new_file(self):
        """Test writing a new file."""
        response = '''
FILE: new_file.py
```python
def new_function():
    return 42
```
'''
        written = _extract_and_write_files(response, self.temp_dir)
        assert len(written) == 1
        assert "new_file.py" in written[0]
        assert (self.temp_dir / "new_file.py").exists()

    def test_reject_write_without_read(self):
        """Test that writing to existing files without READ is rejected."""
        response = '''
FILE: existing.py
```python
# Modified content
```
'''
        written = _extract_and_write_files(response, self.temp_dir, files_read=set())
        # Should be rejected because file wasn't READ first
        assert len(written) == 0

    def test_allow_write_after_read(self):
        """Test that writing to existing files after READ is allowed."""
        response = '''
FILE: existing.py
```python
# Modified content
def updated():
    return True
```
'''
        written = _extract_and_write_files(
            response, self.temp_dir,
            files_read={"existing.py"}
        )
        assert len(written) == 1


class TestCodeQuality:
    """Test code quality validation before writing."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())

    def teardown_method(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_reject_syntax_error(self):
        """Test that files with syntax errors are rejected."""
        # This would require a syntax validation function
        pass

    def test_reject_empty_test_file(self):
        """Test that test files without tests are rejected."""
        response = '''
FILE: tests/test_empty.py
```python
# Just a comment
pass
```
'''
        written = _extract_and_write_files(response, self.temp_dir)
        # Empty test files should be rejected
        assert len(written) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
