"""Tool execution framework for SAGE.

This module provides the tool execution infrastructure for SAGE's
agentic capabilities, including file operations, shell execution,
and search functionality.

P3 Items 123-126: Extract tool execution from main.py.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from sage.core.commands import execute_command


__all__ = [
    "ToolType",
    "ToolResult",
    "ToolContext",
    "ToolExecutor",
    "FileWriteTool",
    "FileReadTool",
    "ShellTool",
    "SearchTool",
    "WebFetchTool",
]


class ToolType(Enum):
    """Types of tools available to SAGE."""
    FILE_WRITE = "file_write"
    FILE_READ = "file_read"
    FILE_DELETE = "file_delete"
    SHELL = "shell"
    SEARCH_CODE = "search_code"
    SEARCH_FILES = "search_files"
    WEB_FETCH = "web_fetch"
    GIT = "git"
    LINT = "lint"
    TEST = "test"


class ToolStatus(Enum):
    """Tool execution status."""
    SUCCESS = "success"
    ERROR = "error"
    DENIED = "denied"
    TIMEOUT = "timeout"


@dataclass
class ToolResult:
    """Result of a tool execution."""
    tool_type: ToolType
    status: ToolStatus
    output: str | None = None
    error: str | None = None
    files_modified: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)
    files_deleted: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        return self.status == ToolStatus.SUCCESS

    def to_dict(self) -> dict:
        return {
            "tool_type": self.tool_type.value,
            "status": self.status.value,
            "output": self.output,
            "error": self.error,
            "files_modified": self.files_modified,
            "files_created": self.files_created,
            "files_deleted": self.files_deleted,
            "metadata": self.metadata,
        }


@dataclass
class ToolContext:
    """Context for tool execution."""
    cwd: Path
    allowed_paths: list[Path] = field(default_factory=list)
    blocked_patterns: list[str] = field(default_factory=lambda: [
        r".*\.env$",
        r".*\.env\..*$",
        r".*\.pem$",
        r".*\.key$",
        r".*id_rsa.*$",
        r".*credentials.*",
        r".*secrets.*",
        r".*\.aws.*",
    ])
    max_file_size: int = 10 * 1024 * 1024  # 10MB
    shell_timeout: int = 60  # seconds
    dry_run: bool = False
    require_confirmation: bool = True

    def is_path_allowed(self, path: Path) -> bool:
        """Check if a path is allowed for modification.

        Security checks performed:
        1. Null byte injection
        2. Path traversal (both Unix and Windows style)
        3. Symlink resolution - ensures final path is within bounds
        4. Absolute paths outside allowed roots
        5. Blocked filename patterns (.env, keys, etc.)
        """
        path_str = str(path)

        # Security: Block null bytes
        if "\x00" in path_str:
            return False

        # Security: Normalize and check for Windows-style path traversal
        # Convert backslashes to forward slashes for security checks
        normalized_path_str = path_str.replace("\\", "/")

        # Block path traversal patterns (both Unix and Windows style)
        if ".." in normalized_path_str:
            return False

        # Block absolute paths outside allowed roots
        if path.is_absolute():
            allowed_roots = [self.cwd.resolve()] + [p.resolve() for p in self.allowed_paths]
            if not any(self._is_subpath(path.resolve(), root) for root in allowed_roots):
                return False

        # Security: Additional check for traversal in original string
        if ".." in path_str:
            # Resolve to check if it escapes
            try:
                resolved = (self.cwd / path).resolve()
                allowed_roots = [self.cwd.resolve()] + [p.resolve() for p in self.allowed_paths]
                if not any(self._is_subpath(resolved, root) for root in allowed_roots):
                    return False
            except (OSError, ValueError):
                return False

        # Resolve to absolute path for further checks
        try:
            abs_path = (self.cwd / path).resolve() if not path.is_absolute() else path.resolve()
        except (OSError, ValueError):
            return False

        # Security: Check if path is a symlink and resolve to final target
        # This prevents symlink-based escapes from the allowed paths
        try:
            if abs_path.is_symlink():
                # Get the final resolved path (follows all symlinks)
                final_path = abs_path.resolve()
                allowed_roots = [self.cwd.resolve()] + [p.resolve() for p in self.allowed_paths]
                if not any(self._is_subpath(final_path, root) for root in allowed_roots):
                    return False
        except (OSError, ValueError):
            return False

        # Must be within cwd or allowed paths
        allowed_roots = [self.cwd.resolve()] + [p.resolve() for p in self.allowed_paths]
        if not any(self._is_subpath(abs_path, root) for root in allowed_roots):
            return False

        # Check blocked patterns against full path and filename
        path_str = str(abs_path)
        filename = abs_path.name
        for pattern in self.blocked_patterns:
            if re.match(pattern, path_str, re.IGNORECASE):
                return False
            if re.match(pattern, filename, re.IGNORECASE):
                return False

        return True

    def _is_subpath(self, path: Path, parent: Path) -> bool:
        """Check if path is under parent."""
        try:
            path.relative_to(parent)
            return True
        except ValueError:
            return False


class FileWriteTool:
    """Tool for writing files safely."""

    def __init__(self, context: ToolContext):
        self.context = context

    def write(
        self,
        filepath: str,
        content: str,
        create_dirs: bool = True,
        backup: bool = True,
    ) -> ToolResult:
        """Write content to a file.

        Args:
            filepath: Relative or absolute path
            content: File content
            create_dirs: Create parent directories if needed
            backup: Create backup of existing file

        Returns:
            ToolResult
        """
        target = Path(filepath)
        if not target.is_absolute():
            target = self.context.cwd / filepath

        # Security check
        if not self.context.is_path_allowed(target):
            return ToolResult(
                tool_type=ToolType.FILE_WRITE,
                status=ToolStatus.DENIED,
                error=f"Path not allowed: {filepath}",
            )

        # Size check
        if len(content.encode()) > self.context.max_file_size:
            return ToolResult(
                tool_type=ToolType.FILE_WRITE,
                status=ToolStatus.ERROR,
                error=f"Content too large: {len(content)} bytes",
            )

        if self.context.dry_run:
            return ToolResult(
                tool_type=ToolType.FILE_WRITE,
                status=ToolStatus.SUCCESS,
                output=f"[DRY RUN] Would write {len(content)} bytes to {filepath}",
                metadata={"dry_run": True},
            )

        try:
            existed = target.exists()

            # Create backup
            if existed and backup:
                backup_path = target.with_suffix(target.suffix + ".bak")
                backup_path.write_text(target.read_text())

            # Create directories
            if create_dirs:
                target.parent.mkdir(parents=True, exist_ok=True)

            # Write file
            target.write_text(content)

            return ToolResult(
                tool_type=ToolType.FILE_WRITE,
                status=ToolStatus.SUCCESS,
                output=f"Wrote {len(content)} bytes to {filepath}",
                files_modified=[str(filepath)] if existed else [],
                files_created=[str(filepath)] if not existed else [],
            )

        except Exception as e:
            return ToolResult(
                tool_type=ToolType.FILE_WRITE,
                status=ToolStatus.ERROR,
                error=str(e),
            )


class FileReadTool:
    """Tool for reading files."""

    def __init__(self, context: ToolContext):
        self.context = context
        self.max_lines = 1000
        self.max_size = 1024 * 1024  # 1MB

    def read(
        self,
        filepath: str,
        max_lines: int | None = None,
        start_line: int = 1,
    ) -> ToolResult:
        """Read a file.

        Args:
            filepath: Path to file
            max_lines: Maximum lines to read
            start_line: Starting line number (1-indexed)

        Returns:
            ToolResult with file content
        """
        target = Path(filepath)
        if not target.is_absolute():
            target = self.context.cwd / filepath

        # Security check - verify path is allowed (handles symlinks, traversal, etc.)
        if not self.context.is_path_allowed(target):
            return ToolResult(
                tool_type=ToolType.FILE_READ,
                status=ToolStatus.DENIED,
                error=f"Path not allowed: {filepath}",
            )

        if not target.exists():
            return ToolResult(
                tool_type=ToolType.FILE_READ,
                status=ToolStatus.ERROR,
                error=f"File not found: {filepath}",
            )

        if not target.is_file():
            return ToolResult(
                tool_type=ToolType.FILE_READ,
                status=ToolStatus.ERROR,
                error=f"Not a file: {filepath}",
            )

        try:
            # Check size
            size = target.stat().st_size
            if size > self.max_size:
                return ToolResult(
                    tool_type=ToolType.FILE_READ,
                    status=ToolStatus.ERROR,
                    error=f"File too large: {size} bytes (max {self.max_size})",
                )

            content = target.read_text(errors="replace")
            lines = content.split("\n")
            total_lines = len(lines)

            # Apply line limits
            max_l = max_lines or self.max_lines
            start_idx = max(0, start_line - 1)
            end_idx = min(start_idx + max_l, total_lines)

            selected_lines = lines[start_idx:end_idx]
            truncated = end_idx < total_lines

            # Add line numbers
            numbered = [
                f"{i}: {line}"
                for i, line in enumerate(selected_lines, start=start_idx + 1)
            ]

            output = "\n".join(numbered)
            if truncated:
                output += f"\n... ({total_lines - end_idx} more lines)"

            return ToolResult(
                tool_type=ToolType.FILE_READ,
                status=ToolStatus.SUCCESS,
                output=output,
                metadata={
                    "total_lines": total_lines,
                    "lines_shown": len(selected_lines),
                    "truncated": truncated,
                },
            )

        except Exception as e:
            return ToolResult(
                tool_type=ToolType.FILE_READ,
                status=ToolStatus.ERROR,
                error=str(e),
            )


class ShellTool:
    """Tool for executing shell commands safely."""

    # Commands that are always blocked
    BLOCKED_COMMANDS = {
        "rm -rf /",
        "rm -rf /*",
        "mkfs",
        "dd if=/dev/zero",
        ":(){:|:&};:",
        "chmod -R 777 /",
        "chmod 777 /",
        "shutdown",
        "reboot",
        "halt",
        "poweroff",
    }

    # Patterns for dangerous commands
    DANGEROUS_PATTERNS = [
        r"^sudo\s+",  # sudo commands
        r"^doas\s+",  # doas commands (OpenBSD sudo alternative)
        r"rm\s+.*-rf\s+/(?!\w)",  # rm -rf / or rm -rf /*
        r"rm\s+-rf\s+/(?!\w)",  # rm -rf /
        r">\s*/dev/sd[a-z]",  # Write to raw devices
        r"dd\s+.*of=/dev/sd",  # dd to raw devices
        r"dd\s+.*of=/dev/sda",  # dd to raw devices
        r"chmod.*777\s+/(?!\w|\S)",  # chmod 777 on root
        r"mkfs\.",  # mkfs commands
    ]

    def __init__(self, context: ToolContext):
        self.context = context
        self.history: list[tuple[str, ToolResult]] = []

    def execute(
        self,
        command: str,
        timeout: int | None = None,
        cwd: Path | None = None,
    ) -> ToolResult:
        """Execute a shell command.

        Args:
            command: Shell command to execute
            timeout: Timeout in seconds
            cwd: Working directory (default: context.cwd)

        Returns:
            ToolResult with command output
        """
        # Safety checks
        if self._is_blocked(command):
            result = ToolResult(
                tool_type=ToolType.SHELL,
                status=ToolStatus.DENIED,
                error=f"Blocked dangerous command: {command}",
            )
            self.history.append((command, result))
            return result

        work_dir = cwd or self.context.cwd
        timeout_secs = timeout or self.context.shell_timeout

        if self.context.dry_run:
            result = ToolResult(
                tool_type=ToolType.SHELL,
                status=ToolStatus.SUCCESS,
                output=f"[DRY RUN] Would execute: {command}",
                metadata={"dry_run": True},
            )
            self.history.append((command, result))
            return result

        # P0-10-15: Use safe command execution instead of shell=True
        cmd_result = execute_command(
            command,
            cwd=work_dir,
            timeout=timeout_secs,
            allow_shell=True,  # Complex commands may need shell
            validate=False,  # Already validated by _is_blocked
        )

        output = cmd_result.stdout
        if cmd_result.stderr:
            output += f"\n[stderr]\n{cmd_result.stderr}"

        if cmd_result.timed_out:
            status = ToolStatus.TIMEOUT
            error = f"Command timed out after {timeout_secs}s"
        elif cmd_result.error:
            status = ToolStatus.ERROR
            error = cmd_result.error
        else:
            status = ToolStatus.SUCCESS if cmd_result.success else ToolStatus.ERROR
            error = cmd_result.stderr if not cmd_result.success else None

        result = ToolResult(
            tool_type=ToolType.SHELL,
            status=status,
            output=output,
            error=error,
            metadata={
                "return_code": cmd_result.returncode,
                "command": command,
            },
        )
        self.history.append((command, result))
        return result

    def _is_blocked(self, command: str) -> bool:
        """Check if a command is blocked."""
        cmd_lower = command.lower().strip()

        # Check exact blocks
        if cmd_lower in self.BLOCKED_COMMANDS:
            return True

        # Check patterns
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True

        return False


class SearchTool:
    """Tool for searching code and files."""

    def __init__(self, context: ToolContext):
        self.context = context

    def search_code(
        self,
        pattern: str,
        file_pattern: str = "*",
        max_results: int = 50,
        case_sensitive: bool = False,
    ) -> ToolResult:
        """Search for pattern in code.

        Args:
            pattern: Search pattern (regex)
            file_pattern: Glob pattern for files
            max_results: Maximum results to return
            case_sensitive: Case sensitive search

        Returns:
            ToolResult with matches
        """
        try:
            # Use ripgrep if available, else grep
            rg_available = subprocess.run(
                ["rg", "--version"],
                capture_output=True,
            ).returncode == 0

            if rg_available:
                cmd = ["rg", "--line-number", "--max-count", str(max_results)]
                if not case_sensitive:
                    cmd.append("-i")
                if file_pattern != "*":
                    cmd.extend(["--glob", file_pattern])
                cmd.append(pattern)
            else:
                cmd = ["grep", "-rn"]
                if not case_sensitive:
                    cmd.append("-i")
                cmd.extend(["--include", file_pattern, pattern, "."])

            proc = subprocess.run(
                cmd,
                cwd=self.context.cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            lines = proc.stdout.strip().split("\n") if proc.stdout else []
            matches = lines[:max_results]

            return ToolResult(
                tool_type=ToolType.SEARCH_CODE,
                status=ToolStatus.SUCCESS,
                output="\n".join(matches) if matches else "No matches found",
                metadata={
                    "pattern": pattern,
                    "match_count": len(matches),
                    "truncated": len(lines) > max_results,
                },
            )

        except subprocess.TimeoutExpired:
            return ToolResult(
                tool_type=ToolType.SEARCH_CODE,
                status=ToolStatus.TIMEOUT,
                error="Search timed out",
            )
        except Exception as e:
            return ToolResult(
                tool_type=ToolType.SEARCH_CODE,
                status=ToolStatus.ERROR,
                error=str(e),
            )

    def search_files(
        self,
        pattern: str,
        max_results: int = 100,
    ) -> ToolResult:
        """Search for files by name pattern.

        Args:
            pattern: Glob or regex pattern
            max_results: Maximum results

        Returns:
            ToolResult with matching file paths
        """
        try:
            matches = []
            for path in self.context.cwd.rglob(pattern):
                if len(matches) >= max_results:
                    break
                # Skip hidden and common ignore dirs
                rel_path = path.relative_to(self.context.cwd)
                parts = rel_path.parts
                if any(p.startswith(".") or p in {"node_modules", "__pycache__", "venv", ".venv"}
                       for p in parts):
                    continue
                matches.append(str(rel_path))

            return ToolResult(
                tool_type=ToolType.SEARCH_FILES,
                status=ToolStatus.SUCCESS,
                output="\n".join(matches) if matches else "No files found",
                metadata={
                    "pattern": pattern,
                    "file_count": len(matches),
                },
            )

        except Exception as e:
            return ToolResult(
                tool_type=ToolType.SEARCH_FILES,
                status=ToolStatus.ERROR,
                error=str(e),
            )


class WebFetchTool:
    """Tool for fetching web content."""

    # Blocked URL schemes
    BLOCKED_SCHEMES = {"file", "ftp", "javascript", "data"}

    # Blocked hosts (SSRF prevention)
    BLOCKED_HOSTS = {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
        "::1",
    }

    # Blocked IP ranges (SSRF prevention)
    BLOCKED_IP_PREFIXES = [
        "10.",           # Private Class A
        "172.16.", "172.17.", "172.18.", "172.19.",
        "172.20.", "172.21.", "172.22.", "172.23.",
        "172.24.", "172.25.", "172.26.", "172.27.",
        "172.28.", "172.29.", "172.30.", "172.31.",  # Private Class B
        "192.168.",      # Private Class C
        "169.254.",      # Link-local
    ]

    def __init__(self, context: ToolContext):
        self.context = context
        self._session = None

    def _is_blocked_url(self, url: str) -> tuple[bool, str]:
        """Check if a URL should be blocked for security reasons."""
        from urllib.parse import urlparse

        try:
            parsed = urlparse(url)
        except Exception:
            return True, "Invalid URL format"

        # Check scheme
        scheme = parsed.scheme.lower()
        if scheme in self.BLOCKED_SCHEMES:
            return True, f"Blocked scheme: {scheme}"
        if scheme not in {"http", "https"}:
            return True, f"Unsupported scheme: {scheme}"

        # Check host
        host = parsed.hostname or ""
        host_lower = host.lower()

        if host_lower in self.BLOCKED_HOSTS:
            return True, f"Blocked host: {host}"

        # Check IP prefixes
        for prefix in self.BLOCKED_IP_PREFIXES:
            if host.startswith(prefix):
                return True, f"Blocked internal IP: {host}"

        return False, ""

    def fetch(
        self,
        url: str,
        timeout: int = 10,
    ) -> ToolResult:
        """Fetch content from a URL.

        Args:
            url: URL to fetch
            timeout: Request timeout

        Returns:
            ToolResult with page content
        """
        # Security: Check for blocked URLs (SSRF prevention)
        blocked, reason = self._is_blocked_url(url)
        if blocked:
            return ToolResult(
                tool_type=ToolType.WEB_FETCH,
                status=ToolStatus.DENIED,
                error=f"URL blocked: {reason}",
                metadata={"url": url},
            )

        try:
            import httpx
        except ImportError:
            return ToolResult(
                tool_type=ToolType.WEB_FETCH,
                status=ToolStatus.ERROR,
                error="httpx not installed",
            )

        try:
            with httpx.Client(timeout=timeout) as client:
                response = client.get(url)
                response.raise_for_status()

                content_type = response.headers.get("content-type", "")

                if "text/html" in content_type:
                    # Try to extract text from HTML
                    try:
                        from bs4 import BeautifulSoup
                        soup = BeautifulSoup(response.text, "html.parser")
                        # Remove script and style elements
                        for script in soup(["script", "style"]):
                            script.decompose()
                        text = soup.get_text(separator="\n", strip=True)
                    except ImportError:
                        text = response.text
                else:
                    text = response.text

                # Truncate if too long
                max_chars = 50000
                if len(text) > max_chars:
                    text = text[:max_chars] + "\n...(truncated)"

                return ToolResult(
                    tool_type=ToolType.WEB_FETCH,
                    status=ToolStatus.SUCCESS,
                    output=text,
                    metadata={
                        "url": url,
                        "status_code": response.status_code,
                        "content_type": content_type,
                    },
                )

        except Exception as e:
            return ToolResult(
                tool_type=ToolType.WEB_FETCH,
                status=ToolStatus.ERROR,
                error=str(e),
                metadata={"url": url},
            )


class ToolExecutor:
    """Central executor for all tools."""

    def __init__(self, context: ToolContext):
        self.context = context
        self.file_write = FileWriteTool(context)
        self.file_read = FileReadTool(context)
        self.shell = ShellTool(context)
        self.search = SearchTool(context)
        self.web_fetch = WebFetchTool(context)
        self.history: list[ToolResult] = []

    def execute(
        self,
        tool_type: ToolType,
        **kwargs: Any,
    ) -> ToolResult:
        """Execute a tool by type.

        Args:
            tool_type: Type of tool to execute
            **kwargs: Tool-specific arguments

        Returns:
            ToolResult
        """
        if tool_type == ToolType.FILE_WRITE:
            result = self.file_write.write(**kwargs)
        elif tool_type == ToolType.FILE_READ:
            result = self.file_read.read(**kwargs)
        elif tool_type == ToolType.SHELL:
            result = self.shell.execute(**kwargs)
        elif tool_type == ToolType.SEARCH_CODE:
            result = self.search.search_code(**kwargs)
        elif tool_type == ToolType.SEARCH_FILES:
            result = self.search.search_files(**kwargs)
        elif tool_type == ToolType.WEB_FETCH:
            result = self.web_fetch.fetch(**kwargs)
        else:
            result = ToolResult(
                tool_type=tool_type,
                status=ToolStatus.ERROR,
                error=f"Unknown tool type: {tool_type}",
            )

        self.history.append(result)
        return result

    def get_history(self, limit: int = 10) -> list[ToolResult]:
        """Get recent tool execution history."""
        return self.history[-limit:]

    def clear_history(self) -> None:
        """Clear tool history."""
        self.history.clear()
