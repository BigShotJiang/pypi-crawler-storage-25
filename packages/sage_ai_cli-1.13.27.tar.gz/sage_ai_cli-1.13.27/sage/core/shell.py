"""Shell command execution utilities for SAGE.

This module contains functions for:
- Running shell commands with scoped directory support
- Extracting shell/bash blocks from text
- Quoting strings for safe shell use
- Reading files with line numbers

Extracted from main.py for better code organization (P3-73).

P0-10-15: Now uses safe execution via commands.py instead of shell=True.

P2-25: Unified Command Safety Policy
=====================================
This module works with sage/core/commands.py to provide consistent command safety:

1. commands.py provides:
   - CommandRisk enum (SAFE, NEEDS_REVIEW, BLOCKED)
   - validate_command() for allowlist checking
   - execute_command() as the primary execution entry point

2. shell.py provides:
   - SAFE_READONLY_COMMANDS: Commands safe for analysis mode
   - BLOCKED_READONLY_PATTERNS: Dangerous patterns to block
   - is_safe_readonly_command(): Validation for read-only flows
   - run_readonly_shell(): Safe execution wrapper

All command execution should go through:
- execute_command() for general execution with validation
- run_readonly_shell() for read-only analysis contexts
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Tuple, Optional, List

from sage.core.commands import execute_command, CommandResult


__all__ = [
    "extract_scoped_prefix",
    "resolve_scoped_directory",
    "run_shell",
    "safe_shell_exec",
    "shell_quote",
    "extract_bash_blocks",
    "sanitize_shell_block",
    "strip_search_comment",
    "read_file_context",
    "CommandResult",
    # TDD-specific functions
    "run_tdd_test",
    "detect_test_framework",
    "parse_test_output",
    # P0-7: Read-only command validation
    "is_safe_readonly_command",
    "run_readonly_shell",
]


# P0-7: Safe read-only commands that can run in analysis mode
SAFE_READONLY_COMMANDS = frozenset([
    "ls", "cat", "head", "tail", "grep", "find", "wc", "file",
    "tree", "pwd", "which", "type", "echo", "less", "more",
    "stat", "du", "df", "uptime", "whoami", "id", "env",
    "rg", "fd", "bat", "exa",  # Modern CLI tools
])

# P0-7: Dangerous patterns that should never execute in read-only mode
BLOCKED_READONLY_PATTERNS = [
    r"\brm\b",
    r"\bmv\b",
    r"\bcp\b",
    r"\bchmod\b",
    r"\bchown\b",
    r"\bsudo\b",
    r"\b(pip|npm|cargo|yarn|pnpm)\s+install\b",
    r"\bgit\s+(push|commit|checkout|reset|rebase|merge)\b",
    r"\bcurl\b.*\|\s*(bash|sh)",
    r"\bwget\b.*\|\s*(bash|sh)",
    r">\s*[/~]",  # Redirect to files
    r"\beval\b",
    r"\bexec\b",
    r"\bmkdir\b",
    r"\btouch\b",
    r"\bwrite\b",
]


def is_safe_readonly_command(command: str) -> tuple[bool, str]:
    """
    Check if command is safe for read-only execution.

    P0-7: Stop executing RUN: commands with weak validation in read-only flows.

    Args:
        command: Shell command to validate

    Returns:
        Tuple of (is_safe, reason if not safe)
    """
    if not command or not command.strip():
        return False, "Empty command"

    # Check for blocked patterns first
    for pattern in BLOCKED_READONLY_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            return False, f"Blocked pattern: {pattern}"

    # Extract base command
    parts = command.strip().split()
    if not parts:
        return False, "Empty command"

    base_cmd = parts[0].split("/")[-1]  # Handle /bin/ls etc

    # Must start with a safe command
    if base_cmd not in SAFE_READONLY_COMMANDS:
        return False, f"Command '{base_cmd}' not in safe read-only list"

    # Check for shell operators that could chain dangerous commands
    if any(op in command for op in [";", "&&", "||", "`", "$("]):
        return False, "Shell operators not allowed in read-only mode"

    # For piped commands, check each segment
    if "|" in command:
        segments = command.split("|")
        for seg in segments:
            seg_parts = seg.strip().split()
            if seg_parts:
                seg_cmd = seg_parts[0].split("/")[-1]
                if seg_cmd not in SAFE_READONLY_COMMANDS:
                    return False, f"Piped command '{seg_cmd}' not safe"

    return True, ""


def run_readonly_shell(cmd: str, cwd: Path, timeout: int = 30) -> str:
    """
    Run a shell command in read-only mode with strict validation.

    P0-7: Safe command execution for read-only analysis flows.

    Args:
        cmd: Shell command to run
        cwd: Current working directory
        timeout: Command timeout in seconds

    Returns:
        Command output or error message
    """
    is_safe, reason = is_safe_readonly_command(cmd)
    if not is_safe:
        return f"[blocked: {reason}]"

    return run_shell(cmd, cwd, timeout)


def extract_scoped_prefix(value: str) -> Tuple[Optional[str], str]:
    """Extract an optional `[cwd=path]` or `[dir=path]` prefix.

    Args:
        value: String that may contain a scoped prefix

    Returns:
        Tuple of (scope_path or None, remaining_value)

    Examples:
        >>> extract_scoped_prefix("[cwd=src] pytest")
        ('src', 'pytest')
        >>> extract_scoped_prefix("pytest")
        (None, 'pytest')
    """
    match = re.match(r"^\s*\[(?:cwd|dir)=(.+?)\]\s*(.*)$", value, re.DOTALL)
    if not match:
        return None, value.strip()
    return match.group(1).strip(), match.group(2).strip()


def resolve_scoped_directory(
    scope: str, cwd: Path
) -> Tuple[Optional[Path], Optional[str]]:
    """Resolve a scoped child directory under the workspace root.

    Args:
        scope: Relative or absolute path to resolve
        cwd: Current working directory (workspace root)

    Returns:
        Tuple of (resolved_path or None, error_message or None)
    """
    workspace_root = cwd.resolve()
    try:
        candidate = Path(scope)
        target = (
            candidate.resolve()
            if candidate.is_absolute()
            else (cwd / candidate).resolve()
        )
    except (OSError, ValueError) as exc:
        return None, f"[error: invalid scoped directory {scope!r}: {exc}]"

    if not str(target).startswith(str(workspace_root)):
        return None, f"[error: scoped directory outside workspace: {scope}]"
    if not target.exists() or not target.is_dir():
        return None, f"[error: scoped directory not found: {scope}]"
    return target, None


def run_shell(cmd: str, cwd: Path, timeout: int = 30) -> str:
    """Run a shell command and return combined stdout+stderr.

    Supports scoped directory prefixes like `[cwd=subdir] command`.

    P0-10-15: Now uses safe execution via commands.py instead of direct shell=True.
    For complex commands with shell operators, falls back to shell execution
    only after validation against blocked patterns.

    Args:
        cmd: Shell command to run (may include [cwd=path] prefix)
        cwd: Current working directory
        timeout: Command timeout in seconds

    Returns:
        Combined stdout and stderr output, or error message
    """
    scope, inner_cmd = extract_scoped_prefix(cmd)
    scoped_cwd = cwd
    if scope:
        scoped_cwd_result, error = resolve_scoped_directory(scope, cwd)
        if error:
            return error
        assert scoped_cwd_result is not None  # error is None means result is valid
        scoped_cwd = scoped_cwd_result
        cmd = inner_cmd
    if not cmd.strip():
        return "[error: empty command]"

    # Use safe command execution from commands.py
    # allow_shell=True for backward compatibility with complex commands
    # validate=False to allow grep/find etc that aren't in strict allowlist
    result = execute_command(
        cmd,
        cwd=scoped_cwd,
        timeout=timeout,
        allow_shell=True,  # Allow shell for complex commands with pipes etc
        validate=False,  # Don't enforce strict allowlist for backward compat
    )

    return result.output


def safe_shell_exec(
    cmd: str,
    cwd: Path,
    timeout: int = 30,
    validate: bool = True,
) -> CommandResult:
    """Execute a shell command safely with full validation.

    This is the preferred API for new code. It returns a structured
    CommandResult and validates commands by default.

    Args:
        cmd: Shell command to run
        cwd: Current working directory
        timeout: Command timeout in seconds
        validate: Whether to validate against allowlists (default True)

    Returns:
        CommandResult with success status, output, and error info
    """
    scope, inner_cmd = extract_scoped_prefix(cmd)
    scoped_cwd = cwd
    if scope:
        scoped_cwd_result, error = resolve_scoped_directory(scope, cwd)
        if error:
            return CommandResult(
                success=False,
                returncode=-1,
                stdout="",
                stderr=error,
                command=cmd,
                error=error,
            )
        assert scoped_cwd_result is not None
        scoped_cwd = scoped_cwd_result
        cmd = inner_cmd

    return execute_command(
        cmd,
        cwd=scoped_cwd,
        timeout=timeout,
        allow_shell=True,  # Allow shell for backward compat
        validate=validate,
    )


def shell_quote(s: str) -> str:
    """Quote a string for safe shell use.

    Args:
        s: String to quote

    Returns:
        Single-quoted string with proper escaping
    """
    return "'" + s.replace("'", "'\\''") + "'"


def extract_bash_blocks(text: str) -> List[str]:
    """Extract ```bash or ```shell code blocks from model output.

    Args:
        text: Text containing potential code blocks

    Returns:
        List of command strings from bash/shell code blocks
    """
    blocks = []
    for m in re.finditer(r"```(?:bash|shell|sh)\s*\n(.*?)```", text, re.DOTALL):
        cmd = m.group(1).strip()
        if cmd:
            blocks.append(cmd)
    return blocks


def sanitize_shell_block(cmd: str) -> str:
    """Remove non-shell pseudo-tool directives from a shell block.

    Filters out READ:, SEARCH:, RUN:, FILE: directives and other
    non-command lines that may appear in model output.

    Args:
        cmd: Raw command block from model output

    Returns:
        Cleaned command string
    """
    cleaned: List[str] = []
    for raw in cmd.splitlines():
        line = raw.strip()
        if not line:
            continue
        if re.match(r"^(?:[-*]\s*)?(READ|SEARCH|RUN|FILE):\s*", line):
            continue
        if line.startswith("Task Understanding"):
            continue
        cleaned.append(raw)
    return "\n".join(cleaned).strip()


def strip_search_comment(pattern: str) -> str:
    """Remove trailing instructional comments from SEARCH patterns.

    Args:
        pattern: Search pattern that may have trailing comments

    Returns:
        Clean pattern without trailing # comments
    """
    return re.sub(r"\s+#.*$", "", pattern).strip()


def read_file_context(
    filepath: str, cwd: Path, max_lines: int = 200
) -> Optional[str]:
    """Read a file or directory and return grounded context.

    Args:
        filepath: Relative path to file
        cwd: Current working directory
        max_lines: Maximum number of lines to read

    Returns:
        Formatted file content with line numbers, directory listing, or None if not found
    """
    target = (cwd / filepath).resolve()
    if not str(target).startswith(str(cwd.resolve())):
        return None
    if not target.exists():
        return None
    if target.is_dir():
        try:
            entries = sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            shown = entries[:max_lines]
            display_path = filepath or "."
            lines = []
            for entry in shown:
                suffix = "/" if entry.is_dir() else ""
                lines.append(f"  {entry.name}{suffix}")
            truncated = (
                f"\n... ({len(shown)}/{len(entries)} entries shown)"
                if len(entries) > len(shown)
                else ""
            )
            return f"Directory: {display_path}\n" + "\n".join(lines) + truncated
        except Exception:
            return None
    if not target.is_file():
        return None
    try:
        full_content = target.read_text("utf-8", errors="replace")
        all_lines = full_content.splitlines()
        lines = all_lines[:max_lines]
        numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
        truncated = (
            f"\n... ({len(lines)}/{len(all_lines)} lines shown)"
            if len(lines) == max_lines and len(all_lines) > max_lines
            else ""
        )
        return f"File: {filepath}\n{numbered}{truncated}"
    except Exception:
        return None


# =============================================================================
# TDD-Specific Shell Functions
# =============================================================================

def run_tdd_test(
    test_cmd: str,
    cwd: Path,
    timeout: int = 60,
    expect_failure: bool = False
) -> Tuple[bool, str, str]:
    """Run a test command for TDD workflow.

    Args:
        test_cmd: Test command to run (e.g., 'pytest tests/test_foo.py -v')
        cwd: Current working directory
        timeout: Command timeout in seconds
        expect_failure: If True, success means tests failed (RED phase)

    Returns:
        Tuple of (success, message, raw_output)
        - success: True if the TDD phase requirement is met
        - message: Human-readable status message
        - raw_output: Raw command output
    """
    result = safe_shell_exec(test_cmd, cwd, timeout=timeout, validate=False)

    if not result.success and result.returncode == -1:
        # Command failed to execute (not a test failure)
        return False, f"Failed to execute test command: {result.error}", result.output

    # Check if tests passed or failed
    tests_passed = result.returncode == 0

    if expect_failure:
        # RED phase: we expect tests to fail
        if tests_passed:
            return (
                False,
                "TDD RED PHASE FAILED: Tests passed but should fail (no implementation yet)",
                result.output
            )
        else:
            return (
                True,
                "TDD RED PHASE OK: Tests fail as expected - ready for implementation",
                result.output
            )
    else:
        # GREEN phase: we expect tests to pass
        if tests_passed:
            return (
                True,
                "TDD GREEN PHASE OK: All tests pass",
                result.output
            )
        else:
            return (
                False,
                "TDD GREEN PHASE FAILED: Tests still failing after implementation",
                result.output
            )


def detect_test_framework(cwd: Path) -> Optional[str]:
    """Detect which test framework is used in the project.

    Args:
        cwd: Project root directory

    Returns:
        Test command string or None if no framework detected
    """
    # Check for common config files
    if (cwd / "pytest.ini").exists() or (cwd / "pyproject.toml").exists():
        # Check if pytest is configured
        pyproject = cwd / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text()
            if "pytest" in content or "[tool.pytest" in content:
                return "python -m pytest -v --tb=short"

    if (cwd / "setup.py").exists() or (cwd / "requirements.txt").exists():
        return "python -m pytest -v --tb=short"

    if (cwd / "package.json").exists():
        # Node.js project
        pkg = cwd / "package.json"
        content = pkg.read_text()
        if "jest" in content:
            return "npm test"
        if "mocha" in content:
            return "npm test"

    if (cwd / "Cargo.toml").exists():
        return "cargo test"

    if (cwd / "go.mod").exists():
        return "go test ./..."

    # Default to pytest for Python-like directories
    if list(cwd.glob("**/*.py")):
        return "python -m pytest -v --tb=short"

    return None


def parse_test_output(output: str) -> dict:
    """Parse test output to extract structured results.

    Args:
        output: Raw test command output

    Returns:
        Dict with keys: passed, failed, errors, skipped, total, failure_details
    """
    result = {
        "passed": 0,
        "failed": 0,
        "errors": 0,
        "skipped": 0,
        "total": 0,
        "failure_details": [],
    }

    # pytest output parsing
    pytest_summary = re.search(
        r"(\d+) passed(?:, (\d+) failed)?(?:, (\d+) error)?(?:, (\d+) skipped)?",
        output
    )
    if pytest_summary:
        result["passed"] = int(pytest_summary.group(1) or 0)
        result["failed"] = int(pytest_summary.group(2) or 0)
        result["errors"] = int(pytest_summary.group(3) or 0)
        result["skipped"] = int(pytest_summary.group(4) or 0)
        result["total"] = sum([
            result["passed"],
            result["failed"],
            result["errors"],
            result["skipped"]
        ])

    # Also check for pytest-style failure summaries (X failed)
    failed_match = re.search(r"(\d+) failed", output)
    if failed_match:
        result["failed"] = int(failed_match.group(1))

    # Extract failure details
    failure_blocks = re.findall(
        r"FAILED ([\w/]+\.py::\w+)",
        output
    )
    result["failure_details"] = failure_blocks

    return result


# Backward compatibility aliases (prefixed versions for main.py)
_extract_scoped_prefix = extract_scoped_prefix
_resolve_scoped_directory = resolve_scoped_directory
_run_shell = run_shell
_safe_shell_exec = safe_shell_exec
_shell_quote = shell_quote
_extract_bash_blocks = extract_bash_blocks
_sanitize_shell_block = sanitize_shell_block
_strip_search_comment = strip_search_comment
_read_file_context = read_file_context
_run_tdd_test = run_tdd_test
_detect_test_framework = detect_test_framework
_parse_test_output = parse_test_output
