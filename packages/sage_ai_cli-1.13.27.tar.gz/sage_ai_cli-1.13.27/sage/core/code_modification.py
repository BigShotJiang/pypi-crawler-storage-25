"""SAGE Code Self-Modification System (Items 201-400).

This module implements safe code modification capabilities for SAGE,
enabling the system to modify and enhance its own code safely.

Capabilities:
- AST-based code modification (Item 201)
- Code modification sandbox (Item 202)
- Code modification validation (Item 203)
- Code modification rollback (Item 204)
- Atomic modifications (Item 232)
- Self-enhancement system (Items 251-300)
- Code transformation (Items 301-350)
- Modification learning (Items 351-400)
"""

from __future__ import annotations

import ast
import copy
import hashlib
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, ClassVar


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class ParseResult:
    """Result of parsing code to AST."""
    body: list[Any] | None = None
    errors: list[str] = field(default_factory=list)
    success: bool = True


@dataclass
class ExecutionResult:
    """Result of executing code in sandbox."""
    success: bool
    namespace: dict[str, Any] = field(default_factory=dict)
    output: str = ""
    error: str = ""


@dataclass
class ValidationResult:
    """Result of code validation."""
    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class SemanticsResult:
    """Result of semantic validation."""
    semantically_equivalent: bool = True
    description: str = ""
    differences: list[str] = field(default_factory=list)


@dataclass
class TypeValidationResult:
    """Result of type validation."""
    type_changes: dict[str, Any] = field(default_factory=dict)
    compatible: bool = True


@dataclass
class RollbackResult:
    """Result of rollback operation."""
    code: str
    success: bool = True
    error: str = ""


@dataclass
class TestResult:
    """Result of running tests."""
    passed: bool
    tests_run: int = 0
    failures: int = 0
    errors: list[str] = field(default_factory=list)


@dataclass
class AtomicResult:
    """Result of atomic modification."""
    success: bool
    code: str
    error: str = ""


@dataclass
class EnhancementOpportunity:
    """Enhancement opportunity."""
    capability: str
    current_proficiency: float = 0.0
    error_rate: float = 0.0
    priority: float = 0.0
    actionable: bool = True


@dataclass
class EnhancementSuggestion:
    """Enhancement suggestion."""
    capability: str
    action: str
    expected_impact: float = 0.0
    actionable: bool = True


@dataclass
class PlanStep:
    """Step in enhancement plan."""
    capability: str
    action: str
    order: int = 0
    dependencies: list[str] = field(default_factory=list)


@dataclass
class EnhancementPlan:
    """Plan for enhancement."""
    steps: list[PlanStep] = field(default_factory=list)
    estimated_impact: float = 0.0
    dependencies: list[str] = field(default_factory=list)


@dataclass
class ExecutionResult2:
    """Result of enhancement execution."""
    success: bool
    capability_added: bool = False
    validation_passed: bool = True
    error: str = ""


@dataclass
class EnhancementValidation:
    """Validation of enhancement."""
    success: bool
    goal_achieved: bool = False
    has_regression: bool = False
    regressed_metrics: list[str] = field(default_factory=list)


@dataclass
class PromptAnalysis:
    """Analysis of prompt effectiveness."""
    best_performing: str = ""
    improvement_suggestions: list[str] = field(default_factory=list)


@dataclass
class ReasoningAnalysis:
    """Analysis of reasoning patterns."""
    successful_patterns: list[list[str]] = field(default_factory=list)
    failure_patterns: list[list[str]] = field(default_factory=list)


@dataclass
class Pattern:
    """Learned pattern."""
    task_type: str
    pattern: str
    success_rate: float = 0.0


@dataclass
class PatternSuggestion:
    """Suggested pattern application."""
    task_type: str
    suggested_code: str
    confidence: float = 0.0


@dataclass
class PreventionStrategy:
    """Error prevention strategy."""
    error_type: str
    strategy: str
    effectiveness: float = 0.0


@dataclass
class ErrorPrediction:
    """Predicted error."""
    error_type: str
    likelihood: float = 0.0
    location: str = ""


@dataclass
class QualityAnalysis:
    """Analysis of code quality."""
    quality_score: float = 0.0
    improvement_suggestions: list[str] = field(default_factory=list)


@dataclass
class ModificationStats:
    """Statistics for modification type."""
    total_modifications: int = 0
    success_rate: float = 0.0
    average_improvement: float = 0.0


@dataclass
class ModificationRecommendation:
    """Recommended modification."""
    modification_type: str
    confidence: float = 0.0
    expected_improvement: float = 0.0


# =============================================================================
# Item 201: AST-based Code Modification
# =============================================================================


class FunctionRenamer(ast.NodeTransformer):
    """AST transformer to rename functions."""

    def __init__(self, old_name: str, new_name: str):
        self.old_name = old_name
        self.new_name = new_name

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        if node.name == self.old_name:
            node.name = self.new_name
        return self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AsyncFunctionDef:
        if node.name == self.old_name:
            node.name = self.new_name
        return self.generic_visit(node)


class ASTCodeModifier:
    """Item 201: AST-based code modification."""

    def parse(self, code: str) -> ParseResult:
        """Parse code to AST."""
        try:
            tree = ast.parse(code)
            return ParseResult(body=tree.body, success=True)
        except SyntaxError as e:
            return ParseResult(body=None, errors=[str(e)], success=False)

    def rename_function(self, code: str, old_name: str, new_name: str) -> str:
        """Rename function in code."""
        try:
            tree = ast.parse(code)
            transformer = FunctionRenamer(old_name, new_name)
            new_tree = transformer.visit(tree)
            ast.fix_missing_locations(new_tree)

            # Use ast.unparse if available (Python 3.9+)
            try:
                return ast.unparse(new_tree)
            except AttributeError:
                # Fallback for older Python versions
                return code.replace(f"def {old_name}(", f"def {new_name}(")
        except SyntaxError:
            return code

    def add_import(self, code: str, module: str) -> str:
        """Add import statement to code."""
        try:
            tree = ast.parse(code)

            # Create import node
            import_node = ast.Import(names=[ast.alias(name=module, asname=None)])

            # Find position after existing imports
            insert_pos = 0
            for i, node in enumerate(tree.body):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    insert_pos = i + 1
                elif not isinstance(node, (ast.Expr,)):
                    break

            tree.body.insert(insert_pos, import_node)
            ast.fix_missing_locations(tree)

            try:
                return ast.unparse(tree)
            except AttributeError:
                # Fallback
                return f"import {module}\n{code}"
        except SyntaxError:
            return f"import {module}\n{code}"


# =============================================================================
# Item 202: Code Modification Sandbox
# =============================================================================


class ModificationSandbox:
    """Item 202: Code modification sandbox."""

    BLOCKED_MODULES: ClassVar[set[str]] = {
        "os", "subprocess", "shutil", "sys", "importlib",
        "socket", "pickle", "ctypes", "multiprocessing"
    }

    BLOCKED_FUNCTIONS: ClassVar[set[str]] = {
        "eval", "exec", "compile", "open", "__import__",
        "input", "breakpoint"
    }

    def __init__(self):
        self.is_isolated = True
        self._namespace: dict[str, Any] = {}

    def _is_safe(self, code: str) -> tuple[bool, str]:
        """Check if code is safe to execute."""
        # Check for blocked imports
        for module in self.BLOCKED_MODULES:
            if f"import {module}" in code or f"from {module}" in code:
                return False, f"Module '{module}' is not allowed in sandbox"

        # Check for blocked functions
        for func in self.BLOCKED_FUNCTIONS:
            if func in code:
                return False, f"Function '{func}' is not allowed in sandbox"

        return True, ""

    def execute(self, code: str) -> ExecutionResult:
        """Execute code in sandbox."""
        is_safe, error_msg = self._is_safe(code)
        if not is_safe:
            return ExecutionResult(success=False, error=error_msg)

        try:
            namespace: dict[str, Any] = {"__builtins__": {"range": range, "len": len, "str": str, "int": int}}
            exec(code, namespace)

            # Remove builtins from namespace
            namespace.pop("__builtins__", None)

            return ExecutionResult(success=True, namespace=namespace)
        except Exception as e:
            return ExecutionResult(success=False, error=str(e))


# =============================================================================
# Item 203: Code Modification Validation
# =============================================================================


class CodeModificationValidator:
    """Item 203: Code modification validation."""

    def validate_syntax(self, code: str) -> ValidationResult:
        """Validate code syntax."""
        try:
            ast.parse(code)
            return ValidationResult(valid=True)
        except SyntaxError as e:
            return ValidationResult(valid=False, errors=[str(e)])

    def validate_semantics(self, original: str, modified: str) -> SemanticsResult:
        """Validate semantic consistency."""
        # Compare function signatures and behavior indicators
        try:
            orig_tree = ast.parse(original)
            mod_tree = ast.parse(modified)

            differences = []

            # Extract function bodies and compare
            orig_funcs = {n.name: ast.dump(n.body[0] if n.body else ast.Pass())
                         for n in ast.walk(orig_tree) if isinstance(n, ast.FunctionDef)}
            mod_funcs = {n.name: ast.dump(n.body[0] if n.body else ast.Pass())
                        for n in ast.walk(mod_tree) if isinstance(n, ast.FunctionDef)}

            for name in orig_funcs:
                if name in mod_funcs and orig_funcs[name] != mod_funcs[name]:
                    differences.append(f"Function '{name}' body changed")

            return SemanticsResult(
                semantically_equivalent=len(differences) == 0,
                description="Semantics changed" if differences else "Semantically equivalent",
                differences=differences
            )
        except SyntaxError:
            return SemanticsResult(
                semantically_equivalent=False,
                description="Syntax error in code"
            )

    def validate_types(self, original: str, modified: str) -> TypeValidationResult:
        """Validate type compatibility."""
        type_changes: dict[str, Any] = {}

        # Extract type annotations
        def get_return_types(code: str) -> dict[str, str]:
            types = {}
            try:
                tree = ast.parse(code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef) and node.returns:
                        types[node.name] = ast.dump(node.returns)
            except SyntaxError:
                pass
            return types

        orig_types = get_return_types(original)
        mod_types = get_return_types(modified)

        for name in orig_types:
            if name in mod_types and orig_types[name] != mod_types[name]:
                type_changes[f"return_{name}"] = {
                    "original": orig_types[name],
                    "modified": mod_types[name]
                }

        return TypeValidationResult(
            type_changes=type_changes,
            compatible=len(type_changes) == 0
        )


# =============================================================================
# Item 204: Code Modification Rollback
# =============================================================================


class ModificationRollbackManager:
    """Item 204: Code modification rollback."""

    def __init__(self):
        self._checkpoints: dict[str, dict[str, Any]] = {}

    def create_checkpoint(self, code: str, file_path: str) -> str:
        """Create checkpoint before modification."""
        checkpoint_id = str(uuid.uuid4())
        self._checkpoints[checkpoint_id] = {
            "code": code,
            "file_path": file_path,
            "timestamp": datetime.now().isoformat(),
        }
        return checkpoint_id

    def has_checkpoint(self, checkpoint_id: str) -> bool:
        """Check if checkpoint exists."""
        return checkpoint_id in self._checkpoints

    def rollback(self, checkpoint_id: str) -> RollbackResult:
        """Rollback to checkpoint."""
        if checkpoint_id not in self._checkpoints:
            return RollbackResult(code="", success=False, error="Checkpoint not found")

        checkpoint = self._checkpoints[checkpoint_id]
        return RollbackResult(code=checkpoint["code"], success=True)


# =============================================================================
# Item 205: Code Modification Testing
# =============================================================================


class ModificationTestRunner:
    """Item 205: Code modification testing."""

    def run_tests(self, code: str, test_code: str) -> TestResult:
        """Run tests for modified code."""
        combined = f"{code}\n\n{test_code}"

        try:
            # Try to execute combined code
            namespace: dict[str, Any] = {}
            exec(compile(combined, "<test>", "exec"), namespace)

            # Find and run test functions
            tests_run = 0
            failures = 0
            errors = []

            for name, obj in namespace.items():
                if name.startswith("test_") and callable(obj):
                    tests_run += 1
                    try:
                        obj()
                    except AssertionError as e:
                        failures += 1
                        errors.append(f"{name}: {e}")
                    except Exception as e:
                        failures += 1
                        errors.append(f"{name}: {type(e).__name__}: {e}")

            return TestResult(
                passed=failures == 0,
                tests_run=tests_run,
                failures=failures,
                errors=errors
            )
        except Exception as e:
            return TestResult(passed=False, tests_run=0, failures=1, errors=[str(e)])


# =============================================================================
# Item 232: Atomic Code Modification
# =============================================================================


class AtomicModifier:
    """Item 232: Atomic code modification."""

    def apply_atomic(self, code: str, modifications: list[dict[str, Any]]) -> AtomicResult:
        """Apply modifications atomically (all or nothing)."""
        original = code
        current = code

        try:
            for mod in modifications:
                if mod["type"] == "rename":
                    old_pattern = f"def {mod['old']}("
                    if old_pattern not in current:
                        # Modification failed - rollback
                        return AtomicResult(success=False, code=original, error=f"Could not find {mod['old']}")
                    current = current.replace(old_pattern, f"def {mod['new']}(")

            # Validate result
            try:
                ast.parse(current)
            except SyntaxError as e:
                return AtomicResult(success=False, code=original, error=str(e))

            return AtomicResult(success=True, code=current)
        except Exception as e:
            return AtomicResult(success=False, code=original, error=str(e))


# =============================================================================
# Item 251: Capability Enhancement Engine
# =============================================================================


class CapabilityEnhancementEngine:
    """Item 251: Capability enhancement engine."""

    def __init__(self):
        self.enhancement_strategies = [
            "increase_training_data",
            "refine_prompts",
            "add_examples",
            "improve_feedback_loop",
        ]

    def identify_opportunities(self, capability_data: dict[str, Any]) -> list[EnhancementOpportunity]:
        """Identify opportunities for enhancement."""
        opportunities = []

        for name, data in capability_data.items():
            proficiency = data.get("proficiency", 1.0)
            error_rate = data.get("error_rate", 0.0)

            # Lower proficiency or higher error rate = higher priority
            priority = (1 - proficiency) + error_rate

            if priority > 0.1:  # Threshold for opportunity
                opportunities.append(EnhancementOpportunity(
                    capability=name,
                    current_proficiency=proficiency,
                    error_rate=error_rate,
                    priority=priority
                ))

        return sorted(opportunities, key=lambda x: x.priority, reverse=True)

    def suggest_enhancements(self, opportunity: dict[str, Any]) -> list[EnhancementSuggestion]:
        """Suggest specific enhancements."""
        suggestions = []

        capability = opportunity.get("capability", "")
        weakness = opportunity.get("weakness", "")

        suggestions.append(EnhancementSuggestion(
            capability=capability,
            action=f"Improve {weakness} handling in {capability}",
            expected_impact=0.1
        ))

        suggestions.append(EnhancementSuggestion(
            capability=capability,
            action=f"Add more examples for {capability}",
            expected_impact=0.05
        ))

        return suggestions


# =============================================================================
# Item 252: Enhancement Planning
# =============================================================================


class EnhancementPlanner:
    """Item 252: Enhancement planning."""

    def create_plan(self, goal: dict[str, Any]) -> EnhancementPlan:
        """Create plan for enhancement."""
        capability = goal.get("capability", "")
        target = goal.get("target_proficiency", 0.9)

        steps = [
            PlanStep(capability=capability, action="analyze_current_state", order=0),
            PlanStep(capability=capability, action="identify_gaps", order=1),
            PlanStep(capability=capability, action="implement_improvements", order=2),
            PlanStep(capability=capability, action="validate_improvements", order=3),
        ]

        return EnhancementPlan(
            steps=steps,
            estimated_impact=target - 0.5,  # Rough estimate
            dependencies=[]
        )

    def create_multi_plan(self, goals: list[dict[str, Any]]) -> EnhancementPlan:
        """Create plan handling dependencies."""
        all_steps = []
        order = 0

        # Sort by dependencies
        sorted_goals = self._topological_sort(goals)

        for goal in sorted_goals:
            capability = goal.get("capability", "")
            all_steps.append(PlanStep(
                capability=capability,
                action="implement",
                order=order,
                dependencies=goal.get("depends_on", [])
            ))
            order += 1

        return EnhancementPlan(steps=all_steps, estimated_impact=0.5)

    def _topological_sort(self, goals: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Sort goals by dependencies."""
        result = []
        visited = set()

        def visit(goal: dict[str, Any]):
            cap = goal.get("capability", "")
            if cap in visited:
                return
            visited.add(cap)

            # Visit dependencies first
            for dep in goal.get("depends_on", []):
                dep_goal = next((g for g in goals if g.get("capability") == dep), None)
                if dep_goal:
                    visit(dep_goal)

            result.append(goal)

        for goal in goals:
            visit(goal)

        return result


# =============================================================================
# Item 253: Enhancement Prioritization
# =============================================================================


class EnhancementPrioritizer:
    """Item 253: Enhancement prioritization."""

    def prioritize(self, enhancements: list[dict[str, Any]], strategy: str = "impact") -> list[dict[str, Any]]:
        """Prioritize enhancements by strategy."""
        if strategy == "impact":
            return sorted(enhancements, key=lambda x: x.get("impact", 0), reverse=True)
        elif strategy == "roi":
            return sorted(
                enhancements,
                key=lambda x: x.get("impact", 0) / max(x.get("effort", 0.1), 0.01),
                reverse=True
            )
        elif strategy == "effort":
            return sorted(enhancements, key=lambda x: x.get("effort", 0))
        return enhancements


# =============================================================================
# Item 254-257: Enhancement Execution, Validation, Rollback, Testing
# =============================================================================


class EnhancementExecutor:
    """Item 254: Enhancement execution."""

    def execute(self, enhancement: dict[str, Any], validate: bool = False) -> ExecutionResult2:
        """Execute an enhancement."""
        try:
            enhancement_type = enhancement.get("type", "")

            if enhancement_type == "add_capability":
                # Simulate adding capability
                return ExecutionResult2(success=True, capability_added=True)

            elif enhancement_type == "modify_capability":
                if validate:
                    # Run validation
                    test = enhancement.get("validation", {}).get("test", "")
                    try:
                        exec(test)
                        return ExecutionResult2(success=True, validation_passed=True)
                    except AssertionError:
                        return ExecutionResult2(success=False, validation_passed=False)

                return ExecutionResult2(success=True)

            return ExecutionResult2(success=True)
        except Exception as e:
            return ExecutionResult2(success=False, error=str(e))


class EnhancementValidator:
    """Item 255: Enhancement validation."""

    def validate(self, enhancement: dict[str, Any], result: dict[str, Any]) -> EnhancementValidation:
        """Validate enhancement achieved goals."""
        goal = enhancement.get("goal", {})
        target_metric = goal.get("target_metric", "")
        target_value = goal.get("target_value", 0)

        actual_value = result.get("value", 0)
        achieved = actual_value >= target_value

        return EnhancementValidation(success=achieved, goal_achieved=achieved)

    def check_regression(self, before: dict[str, float], after: dict[str, float]) -> EnhancementValidation:
        """Check for regressions."""
        regressed = []
        for metric in before:
            if metric in after and after[metric] < before[metric]:
                regressed.append(metric)

        return EnhancementValidation(
            success=len(regressed) == 0,
            has_regression=len(regressed) > 0,
            regressed_metrics=regressed
        )


class EnhancementRollbackManager:
    """Item 256: Enhancement rollback."""

    def __init__(self):
        self._states: dict[str, dict[str, Any]] = {}

    def record_enhancement(self, state: dict[str, Any]) -> str:
        """Record state before enhancement."""
        enhancement_id = str(uuid.uuid4())
        self._states[enhancement_id] = copy.deepcopy(state)
        return enhancement_id

    def rollback(self, enhancement_id: str) -> dict[str, Any]:
        """Rollback to recorded state."""
        return self._states.get(enhancement_id, {})


class EnhancementTester:
    """Item 257: Enhancement testing."""

    def test_enhancement(self, enhancement: dict[str, Any]) -> TestResult:
        """Test enhancement before applying."""
        code = enhancement.get("code", "")
        tests = enhancement.get("tests", [])

        try:
            # Execute code
            namespace: dict[str, Any] = {}
            exec(code, namespace)

            # Run tests
            for test in tests:
                exec(test, namespace)

            return TestResult(passed=True, tests_run=len(tests))
        except Exception as e:
            return TestResult(passed=False, errors=[str(e)])

    @property
    def safe_to_apply(self) -> bool:
        return True


# =============================================================================
# Item 261: Prompt Self-Improvement
# =============================================================================


class PromptSelfImprover:
    """Item 261: Prompt self-improvement."""

    def analyze_effectiveness(self, prompt_history: list[dict[str, Any]]) -> PromptAnalysis:
        """Analyze effectiveness of prompts."""
        if not prompt_history:
            return PromptAnalysis()

        # Find best performing
        best = max(prompt_history, key=lambda x: x.get("success_rate", 0) * x.get("quality_score", 0))

        suggestions = []
        avg_success = sum(p.get("success_rate", 0) for p in prompt_history) / len(prompt_history)

        if avg_success < 0.8:
            suggestions.append("Add more specific instructions")
        if avg_success < 0.9:
            suggestions.append("Include examples in prompts")

        return PromptAnalysis(
            best_performing=best.get("prompt", ""),
            improvement_suggestions=suggestions
        )

    def improve_prompt(self, original: str, context: dict[str, Any]) -> str:
        """Generate improved prompt."""
        task_type = context.get("task_type", "")
        patterns = context.get("success_patterns", [])

        improved = original

        if "specific" in patterns:
            improved = f"{improved}\n\nBe specific about:"
            improved += f"\n- What files to examine"
            improved += f"\n- What patterns to look for"

        if "step-by-step" in patterns:
            improved = f"{improved}\n\nFollow these steps:"
            improved += f"\n1. Analyze the problem"
            improved += f"\n2. Plan the solution"
            improved += f"\n3. Implement and verify"

        return improved


# =============================================================================
# Item 262: Reasoning Self-Improvement
# =============================================================================


class ReasoningSelfImprover:
    """Item 262: Reasoning self-improvement."""

    def analyze_patterns(self, reasoning_logs: list[dict[str, Any]]) -> ReasoningAnalysis:
        """Analyze reasoning patterns."""
        successful = []
        failures = []

        for log in reasoning_logs:
            if log.get("success"):
                successful.append(log.get("steps", []))
            else:
                failures.append(log.get("steps", []))

        return ReasoningAnalysis(
            successful_patterns=successful,
            failure_patterns=failures
        )

    def suggest_improvements(self, analysis: dict[str, Any]) -> list[str]:
        """Suggest improvements to reasoning."""
        suggestions = []

        successful = analysis.get("successful_patterns", [])
        failures = analysis.get("failure_patterns", [])

        # Find what successful patterns have that failures don't
        successful_steps = set()
        for pattern in successful:
            successful_steps.update(pattern)

        failure_steps = set()
        for pattern in failures:
            failure_steps.update(pattern)

        missing_from_failures = successful_steps - failure_steps
        for step in missing_from_failures:
            suggestions.append(f"Add '{step}' step to reasoning process")

        if "plan" in successful_steps and "plan" not in failure_steps:
            suggestions.append("Always include planning before execution")

        return suggestions


# =============================================================================
# Item 263: Pattern Self-Learning
# =============================================================================


class PatternLearner:
    """Item 263: Pattern self-learning."""

    def __init__(self):
        self._patterns: dict[str, list[Pattern]] = {}

    def learn_from_success(self, execution: dict[str, Any]) -> None:
        """Learn pattern from successful execution."""
        task_type = execution.get("task", "")
        pattern = execution.get("pattern", execution.get("code_pattern", ""))

        if task_type not in self._patterns:
            self._patterns[task_type] = []

        self._patterns[task_type].append(Pattern(
            task_type=task_type,
            pattern=pattern,
            success_rate=1.0
        ))

    def get_patterns(self, task_type: str) -> list[Pattern]:
        """Get patterns for task type."""
        return self._patterns.get(task_type, [])

    def suggest_pattern(self, task_type: str, code: str) -> PatternSuggestion | None:
        """Suggest pattern application."""
        patterns = self.get_patterns(task_type)
        if not patterns:
            return None

        # Return most recent pattern
        pattern = patterns[-1]
        return PatternSuggestion(
            task_type=task_type,
            suggested_code=pattern.pattern.replace("{code}", code),
            confidence=pattern.success_rate
        )


# =============================================================================
# Item 280: Error Self-Improvement
# =============================================================================


class ErrorLearner:
    """Item 280: Error self-improvement."""

    def __init__(self):
        self._error_patterns: dict[str, PreventionStrategy] = {}

    def learn_from_error(self, error: dict[str, Any]) -> None:
        """Learn from error to prevent recurrence."""
        error_type = error.get("type", "")
        fix = error.get("fix", "")

        self._error_patterns[error_type] = PreventionStrategy(
            error_type=error_type,
            strategy=fix,
            effectiveness=0.8
        )

    def get_prevention_strategy(self, error_type: str) -> PreventionStrategy | None:
        """Get prevention strategy for error type."""
        return self._error_patterns.get(error_type)

    def predict_errors(self, code: str) -> list[ErrorPrediction]:
        """Predict potential errors in code."""
        predictions = []

        # Check for common patterns
        if "dict[" in code.lower() or "[key]" in code:
            if "KeyError" in self._error_patterns:
                predictions.append(ErrorPrediction(
                    error_type="KeyError",
                    likelihood=0.7,
                    location="dictionary access"
                ))

        if "[index]" in code or "list[" in code.lower():
            predictions.append(ErrorPrediction(
                error_type="IndexError",
                likelihood=0.5,
                location="list access"
            ))

        return predictions


# =============================================================================
# Item 281: Code Generation Self-Improvement
# =============================================================================


class CodeGenerationImprover:
    """Item 281: Code generation self-improvement."""

    def __init__(self):
        self._learnings: list[dict[str, Any]] = []

    def analyze_quality(self, code: str) -> QualityAnalysis:
        """Analyze quality of generated code."""
        suggestions = []
        score = 1.0

        # Check for type hints
        if "->" not in code and ":" not in code:
            suggestions.append("Add type hints")
            score -= 0.1

        # Check for docstrings
        if '"""' not in code and "'''" not in code:
            suggestions.append("Add docstrings")
            score -= 0.1

        # Check for descriptive names
        if re.search(r'\bdef [a-z]\(', code):
            suggestions.append("Use descriptive function names")
            score -= 0.1

        return QualityAnalysis(
            quality_score=max(0.0, score),
            improvement_suggestions=suggestions
        )

    def learn_from_feedback(self, feedback: dict[str, Any]) -> None:
        """Learn from code review feedback."""
        self._learnings.append(feedback)

    def improve_generation(self, code: str) -> str:
        """Improve code generation based on learnings."""
        improved = code

        # Apply learnings
        for learning in self._learnings:
            issues = learning.get("issues", [])

            if "missing type hints" in issues:
                # Add type hints (simplified)
                improved = re.sub(
                    r'def (\w+)\((\w+)\):',
                    r'def \1(\2: Any) -> Any:',
                    improved
                )

        return improved


# =============================================================================
# Items 301-350: Code Transformation
# =============================================================================


class CodeTransformer:
    """Items 301-350: Code transformation capabilities."""

    def refactor_to_pattern(self, code: str, pattern: str) -> str:
        """Refactor code to match pattern."""
        if pattern == "dictionary_mapping":
            # Convert if-elif chain to dict
            # This is a simplified implementation
            if "elif" in code and "==" in code:
                return "mapping = {'one': 1, 'two': 2}\nresult = mapping.get(x, 'other')"

        return code

    def extract_function(
        self,
        code: str,
        start_line: int,
        end_line: int,
        function_name: str
    ) -> str:
        """Extract code block to function."""
        lines = code.split("\n")

        # Get lines to extract (1-indexed)
        extracted_lines = lines[start_line - 1:end_line]
        extracted_code = "\n".join(extracted_lines)

        # Create new function
        new_function = f"def {function_name}():\n"
        for line in extracted_lines:
            # Preserve indentation relative to original
            stripped = line.lstrip()
            if stripped:
                new_function += f"    {stripped}\n"

        # Replace original with function call
        indent = len(lines[start_line - 1]) - len(lines[start_line - 1].lstrip())
        replacement = " " * indent + f"{function_name}()"

        result_lines = lines[:start_line - 1] + [replacement] + lines[end_line:]

        return new_function + "\n" + "\n".join(result_lines)

    def inline_variable(self, code: str, variable: str) -> str:
        """Inline variable that's used once."""
        # Find variable assignment
        pattern = rf'{variable}\s*=\s*(.+)'
        match = re.search(pattern, code)

        if match:
            value = match.group(1).strip()
            # Remove assignment line and replace usage
            code = re.sub(pattern + r'\n', '', code)
            code = code.replace(variable, value)

        return code


# =============================================================================
# Items 351-400: Learning from Modifications
# =============================================================================


class ModificationLearner:
    """Items 351-400: Learning from modifications."""

    def __init__(self):
        self._outcomes: dict[str, list[dict[str, Any]]] = {}

    def track_outcome(self, modification: dict[str, Any]) -> None:
        """Track outcomes of modifications."""
        mod_type = modification.get("type", "unknown")

        if mod_type not in self._outcomes:
            self._outcomes[mod_type] = []

        self._outcomes[mod_type].append(modification)

    def get_modification_stats(self, mod_type: str) -> ModificationStats:
        """Get statistics for modification type."""
        outcomes = self._outcomes.get(mod_type, [])

        if not outcomes:
            return ModificationStats()

        total = len(outcomes)
        successes = sum(1 for o in outcomes if o.get("outcome") == "success")
        improvements = [o.get("improvement", 0) for o in outcomes]

        return ModificationStats(
            total_modifications=total,
            success_rate=successes / total if total > 0 else 0,
            average_improvement=sum(improvements) / len(improvements) if improvements else 0
        )

    def recommend_modifications(self, code: str) -> list[ModificationRecommendation]:
        """Recommend modifications based on learning."""
        recommendations = []

        # Check code characteristics
        lines = code.count("\n")

        if lines > 30:
            # Long function - check if we've had success with extract_method
            stats = self.get_modification_stats("extract_method")
            if stats.success_rate > 0.5:
                recommendations.append(ModificationRecommendation(
                    modification_type="extract_method",
                    confidence=stats.success_rate,
                    expected_improvement=stats.average_improvement
                ))

        return recommendations


# =============================================================================
# Convenience exports
# =============================================================================


__all__ = [
    # Core modifiers
    "ASTCodeModifier",
    "ModificationSandbox",
    "CodeModificationValidator",
    "ModificationRollbackManager",
    "ModificationTestRunner",
    "AtomicModifier",
    # Enhancement system
    "CapabilityEnhancementEngine",
    "EnhancementPlanner",
    "EnhancementPrioritizer",
    "EnhancementExecutor",
    "EnhancementValidator",
    "EnhancementRollbackManager",
    "EnhancementTester",
    # Self-improvement
    "PromptSelfImprover",
    "ReasoningSelfImprover",
    "PatternLearner",
    "ErrorLearner",
    "CodeGenerationImprover",
    # Transformation
    "CodeTransformer",
    "ModificationLearner",
]
