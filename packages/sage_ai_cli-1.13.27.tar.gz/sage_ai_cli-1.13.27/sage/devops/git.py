"""Git operations module for SAGE DevOps.

This module provides git-related operations including:
- Branch management
- Commit operations
- Status checking
- Diff generation

NOTE: This is a stub implementation. Full functionality coming soon.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class GitStatus:
    """Git repository status."""

    branch: str
    is_clean: bool
    staged_files: list[str] = field(default_factory=list)
    modified_files: list[str] = field(default_factory=list)
    untracked_files: list[str] = field(default_factory=list)


@dataclass
class GitCommit:
    """A git commit."""

    sha: str
    message: str
    author: str
    date: str


class GitOps:
    """Git operations handler.

    Provides safe git operations for SAGE workflows.
    """

    def __init__(self, repo_path: Path | str | None = None):
        """Initialize GitOps.

        Args:
            repo_path: Path to the git repository. If None, uses current directory.
        """
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self._validate_repo()

    def _validate_repo(self) -> None:
        """Validate that the path is a git repository."""
        git_dir = self.repo_path / ".git"
        if not git_dir.exists():
            # Try to find git root
            result = self._run_git(["rev-parse", "--git-dir"], check=False)
            if result.returncode != 0:
                raise ValueError(f"Not a git repository: {self.repo_path}")

    def _run_git(
        self,
        args: list[str],
        check: bool = True,
        capture_output: bool = True,
    ) -> subprocess.CompletedProcess:
        """Run a git command."""
        cmd = ["git"] + args
        return subprocess.run(
            cmd,
            cwd=self.repo_path,
            capture_output=capture_output,
            text=True,
            check=check,
        )

    def get_status(self) -> GitStatus:
        """Get current git status."""
        result = self._run_git(["status", "--porcelain", "-b"])
        lines = result.stdout.strip().split("\n")

        # Parse branch from first line
        branch = "unknown"
        if lines and lines[0].startswith("##"):
            branch = lines[0][3:].split("...")[0]
            lines = lines[1:]

        staged = []
        modified = []
        untracked = []

        for line in lines:
            if not line:
                continue
            status = line[:2]
            filepath = line[3:]

            if status[0] in "MADRC":
                staged.append(filepath)
            if status[1] in "MD":
                modified.append(filepath)
            if status == "??":
                untracked.append(filepath)

        return GitStatus(
            branch=branch,
            is_clean=len(staged) == 0 and len(modified) == 0,
            staged_files=staged,
            modified_files=modified,
            untracked_files=untracked,
        )

    def get_current_branch(self) -> str:
        """Get current branch name."""
        result = self._run_git(["rev-parse", "--abbrev-ref", "HEAD"])
        return str(result.stdout).strip()

    def get_diff(self, staged: bool = False) -> str:
        """Get diff of changes.

        Args:
            staged: If True, show staged changes. Otherwise show unstaged.
        """
        args = ["diff"]
        if staged:
            args.append("--staged")
        result = self._run_git(args)
        return str(result.stdout)

    def get_log(self, count: int = 10) -> list[GitCommit]:
        """Get recent commits."""
        result = self._run_git([
            "log",
            f"-{count}",
            "--format=%H|%s|%an|%ai",
        ])

        commits = []
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            parts = line.split("|")
            if len(parts) >= 4:
                commits.append(GitCommit(
                    sha=parts[0],
                    message=parts[1],
                    author=parts[2],
                    date=parts[3],
                ))

        return commits

    def stage_files(self, files: list[str]) -> None:
        """Stage files for commit."""
        if files:
            self._run_git(["add"] + files)

    def commit(self, message: str) -> str:
        """Create a commit.

        Returns:
            The commit SHA.
        """
        self._run_git(["commit", "-m", message])
        result = self._run_git(["rev-parse", "HEAD"])
        return str(result.stdout).strip()

    def create_branch(self, name: str, checkout: bool = True) -> None:
        """Create a new branch."""
        self._run_git(["branch", name])
        if checkout:
            self._run_git(["checkout", name])

    def checkout(self, ref: str) -> None:
        """Checkout a branch or commit."""
        self._run_git(["checkout", ref])

    def pull(self, remote: str = "origin", branch: str | None = None) -> None:
        """Pull from remote."""
        args = ["pull", remote]
        if branch:
            args.append(branch)
        self._run_git(args)

    def push(self, remote: str = "origin", branch: str | None = None) -> None:
        """Push to remote."""
        args = ["push", remote]
        if branch:
            args.append(branch)
        self._run_git(args)

    def stash(self, message: str | None = None) -> None:
        """Stash current changes."""
        args = ["stash", "push"]
        if message:
            args.extend(["-m", message])
        self._run_git(args)

    def stash_pop(self) -> None:
        """Pop stashed changes."""
        self._run_git(["stash", "pop"])
