import re
from pydantic import BaseModel, Field, field_validator


class SchemaBase(BaseModel):
    model_config = {"protected_namespaces": ()}


# P0-8: Safe ID patterns to prevent path traversal
SAFE_MODEL_ID_PATTERN = r"^[a-zA-Z0-9][a-zA-Z0-9_:\.\-]{0,127}$"
SAFE_CONVERSATION_ID_PATTERN = r"^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,63}$"


def validate_safe_id(value: str, id_type: str = "generic") -> str:
    """
    P0-8: Validate that an ID is safe and doesn't contain path traversal.

    Raises ValueError if validation fails.
    """
    if not value:
        raise ValueError(f"{id_type} cannot be empty")

    # Check for path traversal
    if ".." in value:
        raise ValueError(f"{id_type} contains path traversal")

    if value.startswith("/") or value.startswith("\\"):
        raise ValueError(f"{id_type} cannot start with path separator")

    # Check for null bytes
    if "\x00" in value:
        raise ValueError(f"{id_type} contains null byte")

    return value


# ── Model records ──────────────────────────────────────────────


class ModelVersion(SchemaBase):
    version: int
    version_tag: str | None = None  # git tag from source repo
    file_path: str
    source_url: str | None = None
    local_import: bool = False
    sha256: str | None = None
    size_gb: float | None = None
    created_at: str | None = None


class ModelRecord(SchemaBase):
    model_id: str
    runtime: str
    license: str | None = None
    format: str | None = None  # gguf, safetensors, onnx
    source_repo: str | None = None  # "owner/repo" on GitHub
    active_version: int = 1
    versions: list[ModelVersion] = Field(default_factory=list)

    def active(self) -> ModelVersion:
        for v in self.versions:
            if v.version == self.active_version:
                return v
        raise KeyError(f"Active version {self.active_version} not found")

    def latest_version_number(self) -> int:
        if not self.versions:
            return 0
        return max(v.version for v in self.versions)

    def all_hashes(self) -> set[str]:
        """Return all known SHA256 hashes for deduplication."""
        return {v.sha256.lower() for v in self.versions if v.sha256}

    def all_tags(self) -> set[str]:
        """Return all known version tags for deduplication."""
        return {v.version_tag for v in self.versions if v.version_tag}


# ── Request schemas ────────────────────────────────────────────

RUNTIME_PATTERN = "^(llama_cpp|transformers|vllm|onnx|ollama|cloud)$"


class DownloadModelReq(SchemaBase):
    model_id: str = Field(min_length=2, pattern=SAFE_MODEL_ID_PATTERN)
    source_url: str = Field(min_length=8)
    runtime: str = Field(pattern=RUNTIME_PATTERN)
    filename: str | None = None
    sha256: str | None = None
    license: str | None = None
    size_gb: float | None = None
    format: str | None = None
    version_tag: str | None = None

    @field_validator("model_id")
    @classmethod
    def validate_model_id(cls, v: str) -> str:
        return validate_safe_id(v, "model_id")


class ImportModelReq(SchemaBase):
    model_id: str = Field(min_length=2)
    local_path: str
    runtime: str = Field(pattern=RUNTIME_PATTERN)
    license: str | None = None
    format: str | None = None


class LoadModelReq(SchemaBase):
    model_id: str
    version: int | None = None
    threads: int | None = Field(default=None, ge=1, le=256)


class SetActiveVersionReq(SchemaBase):
    model_id: str
    version: int = Field(ge=1)


class ChatMessage(SchemaBase):
    role: str = Field(pattern="^(system|user|assistant)$")
    content: str


class ChatReq(SchemaBase):
    model_id: str = Field(pattern=SAFE_MODEL_ID_PATTERN)
    messages: list[ChatMessage]
    temperature: float = Field(default=0.3, ge=0, le=2)
    max_tokens: int = Field(default=512, ge=32, le=4096)
    top_p: float = Field(default=0.95, ge=0, le=1)
    stream: bool = True
    conversation_id: str | None = Field(default=None, pattern=SAFE_CONVERSATION_ID_PATTERN)

    @field_validator("model_id")
    @classmethod
    def validate_model_id(cls, v: str) -> str:
        return validate_safe_id(v, "model_id")

    @field_validator("conversation_id")
    @classmethod
    def validate_conversation_id(cls, v: str | None) -> str | None:
        if v is not None:
            return validate_safe_id(v, "conversation_id")
        return v


class CreateConversationReq(SchemaBase):
    title: str = Field(min_length=1, max_length=120)


# ── Source tracking schemas ────────────────────────────────────


class AddSourceReq(SchemaBase):
    repo_url: str = Field(min_length=5)
    model_id: str = Field(min_length=2)
    runtime: str = Field(pattern=RUNTIME_PATTERN, default="llama_cpp")
    asset_pattern: str = Field(default="*.gguf")
    license: str | None = None
