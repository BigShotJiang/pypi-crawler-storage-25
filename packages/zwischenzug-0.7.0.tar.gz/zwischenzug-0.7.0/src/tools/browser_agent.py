"""
Browser Agent tool — autonomous browser automation via browser-use Agent.

Unlike the low-level `browser` tool (where the LLM manually issues open/click/type),
this tool gives a high-level *task* to browser-use's Agent, which autonomously plans
and executes browser actions (navigation, clicks, typing, scrolling, screenshots, etc.)
using its own internal LLM.

The browser runs non-headless by default so the user can watch it live via VNC/noVNC
in environments like GitHub Codespaces.

A single persistent Chromium process is launched on first use and kept alive forever
(until explicit "close" command). browser-use attaches to it via CDP each run, so the
browser window is always visible in VNC before and after tasks complete.
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import time
import urllib.request
from typing import Any

from . import Tool, ToolContext, ToolOutput

logger = logging.getLogger("zwischenzug.tools.browser_agent")

# The single persistent Chromium subprocess (module-level singleton).
_CHROMIUM_PROC: subprocess.Popen | None = None
_CDP_PORT = 9222
_CDP_URL = f"http://localhost:{_CDP_PORT}"


def _browser_use_available() -> bool:
    try:
        import browser_use  # noqa: F401
        return True
    except ImportError:
        return False


def _chromium_binary() -> str:
    """Find the Playwright-installed Chromium binary."""
    import shutil
    for candidate in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        path = shutil.which(candidate)
        if path:
            return path
    # Playwright installs chromium here (chrome-linux or chrome-linux64)
    pw_chromium = os.path.expanduser(
        "~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"
    )
    import glob
    matches = glob.glob(pw_chromium)
    if matches:
        return matches[0]
    raise FileNotFoundError("Could not find a Chromium binary. Run: playwright install chromium")


def _ensure_chromium_running(display: str) -> None:
    """Start the persistent Chromium process if it is not already running."""
    global _CHROMIUM_PROC

    # Check if existing process is still alive
    if _CHROMIUM_PROC is not None and _CHROMIUM_PROC.poll() is None:
        return  # already running

    # Check if a Chromium is already listening on the CDP port (e.g. survived a zwis restart)
    import urllib.request
    try:
        urllib.request.urlopen(f"{_CDP_URL}/json/version", timeout=1)
        logger.info("Chromium already running at %s — reusing it", _CDP_URL)
        return
    except Exception:
        pass

    binary = _chromium_binary()
    env = {**os.environ, "DISPLAY": display}
    cmd = [
        binary,
        f"--remote-debugging-port={_CDP_PORT}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-extensions",
        "--start-maximized",
        "--no-sandbox",
        "about:blank",
    ]
    logger.info("Launching persistent Chromium: %s", " ".join(cmd))
    _CHROMIUM_PROC = subprocess.Popen(
        cmd,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,  # own process group — survives zwis Ctrl+C
    )
    # Give Chromium a moment to start up and open the debugging port
    for _ in range(20):
        time.sleep(0.3)
        try:
            urllib.request.urlopen(f"{_CDP_URL}/json/version", timeout=1)
            logger.info("Chromium CDP ready at %s", _CDP_URL)
            return
        except Exception:
            pass
    raise RuntimeError("Chromium did not start in time — CDP port not responding")


def _auto_start_chromium() -> None:
    """Launch Chromium at import time so VNC always shows a browser window."""
    display = os.environ.get("DISPLAY", "")
    if not display:
        try:
            ps = subprocess.check_output(["pgrep", "-a", "Xtigervnc"], text=True, stderr=subprocess.DEVNULL)
            for line in ps.strip().splitlines():
                for token in line.split():
                    if token.startswith(":"):
                        display = token
                        os.environ["DISPLAY"] = display
                        break
        except Exception:
            pass
    if not display:
        return
    try:
        _chromium_binary()  # check binary exists before trying
    except FileNotFoundError:
        return
    _ensure_chromium_running(display)


# Auto-start on import so the browser is visible in VNC from the moment zwis launches.
try:
    _auto_start_chromium()
except Exception as _e:
    logger.debug("Auto-start Chromium skipped: %s", _e)


def _build_llm(provider: str | None = None, model: str | None = None) -> Any:
    """Build a browser-use compatible LLM from env/config.

    Checks for a dedicated BROWSER_AGENT_MODEL env var first, then falls back
    to the main Zwischenzug provider/model, then to sensible defaults.
    """
    ba_model = os.getenv("BROWSER_AGENT_MODEL", "").strip()

    if ba_model:
        # User explicitly set a browser-agent model
        model_id = ba_model
    elif provider and model:
        model_id = model
    else:
        # Fall back to env
        model_id = os.getenv("ZWISCHENZUG_MODEL", "").strip()
        provider = os.getenv("ZWISCHENZUG_PROVIDER", "").strip().lower()

    if not model_id:
        raise ValueError(
            "No LLM configured for browser agent. Set BROWSER_AGENT_MODEL or "
            "ZWISCHENZUG_MODEL in your .env."
        )

    from langchain_litellm import ChatLiteLLM

    # browser-use's Agent checks `llm.provider` internally. ChatLiteLLM is a
    # Pydantic model that raises AttributeError for unknown attrs, so we add
    # the field via a minimal subclass to keep browser-use happy.
    class _BrowserCompatLLM(ChatLiteLLM):
        provider: str = ""

    # Normalize to LiteLLM format: provider/model
    if provider and not model_id.startswith(f"{provider}/"):
        litellm_model = f"{provider}/{model_id}"
    else:
        litellm_model = model_id

    return _BrowserCompatLLM(model=litellm_model, temperature=1.0)


class BrowserAgentTool(Tool):
    """Give a high-level task to an autonomous browser agent."""

    @property
    def name(self) -> str:
        return "browser_agent"

    @property
    def description(self) -> str:
        return (
            "Autonomous browser agent. Give it a task in plain English and it will "
            "navigate websites, click buttons, fill forms, scroll, take screenshots, "
            "and extract information — all on its own.\n"
            "Examples:\n"
            "- 'Go to google.com and search for OpenAI'\n"
            "- 'Go to github.com/anthropics and list the top repositories'\n"
            "- 'Fill out the contact form at example.com with test data'\n"
            "The browser is visible via VNC (port 6080) so you can watch it work.\n"
            "Requires: pip install browser-use"
        )

    @property
    def is_read_only(self) -> bool:
        return False

    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "The task for the browser agent to accomplish, in plain English. "
                        "Be specific about what you want it to do and what information to extract. "
                        "Use 'close' to close the browser when done inspecting."
                    ),
                },
                "max_steps": {
                    "type": "integer",
                    "description": "Maximum number of browser actions (default 25).",
                },
                "headless": {
                    "type": "boolean",
                    "description": "Run headless (no visible browser). Default false — browser is visible via VNC.",
                },
                "keep_open": {
                    "type": "boolean",
                    "description": (
                        "Keep the browser open after the task finishes so you can inspect "
                        "the page via VNC. Default true. Set false to close immediately."
                    ),
                },
            },
            "required": ["task"],
        }

    async def execute(self, ctx: ToolContext, **kwargs: Any) -> ToolOutput:
        task = kwargs.get("task", "").strip()

        # Handle "close" action to shut down a kept-open browser.
        if task.lower() == "close":
            return await self._close_browser(ctx)

        if not task:
            return ToolOutput.error("'browser_agent' requires a 'task'.")

        if not _browser_use_available():
            return ToolOutput.error(
                "browser-use is not installed. Run:\n"
                "  pip install browser-use playwright\n"
                "  playwright install chromium"
            )

        max_steps = int(kwargs.get("max_steps", 25))
        headless = kwargs.get("headless", False)
        keep_open = kwargs.get("keep_open", True)

        try:
            return await self._run_agent(ctx, task, max_steps, headless, keep_open)
        except Exception as exc:
            logger.exception("Browser agent failed")
            return ToolOutput.error(f"Browser agent failed: {exc}")

    async def _close_browser(self, ctx: ToolContext) -> ToolOutput:
        """Kill the persistent Chromium process."""
        global _CHROMIUM_PROC
        if _CHROMIUM_PROC is None or _CHROMIUM_PROC.poll() is not None:
            return ToolOutput.success("No browser running.")
        _CHROMIUM_PROC.terminate()
        try:
            _CHROMIUM_PROC.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _CHROMIUM_PROC.kill()
        _CHROMIUM_PROC = None
        return ToolOutput.success("Browser closed.")

    def _auto_detect_display(self) -> bool:
        """Set DISPLAY from running Xvfb if not already set. Returns True if a display is available."""
        if os.environ.get("DISPLAY"):
            return True
        import subprocess
        try:
            ps = subprocess.check_output(
                ["pgrep", "-a", "Xvfb"], text=True, stderr=subprocess.DEVNULL
            )
            for line in ps.strip().splitlines():
                for token in line.split():
                    if token.startswith(":"):
                        os.environ["DISPLAY"] = token
                        logger.info("Auto-detected DISPLAY=%s from running Xvfb", token)
                        return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
        return False

    async def _create_session(self, headless: bool = False) -> Any:
        """Create a browser-use BrowserSession.

        If our persistent Chromium is reachable via CDP, attach to it.
        Otherwise (headless env, no DISPLAY) let browser-use manage its own
        Playwright-based headless instance.
        """
        from browser_use import BrowserSession

        import urllib.request
        cdp_available = False
        try:
            urllib.request.urlopen(f"{_CDP_URL}/json/version", timeout=1)
            cdp_available = True
        except Exception:
            pass

        if cdp_available:
            return BrowserSession(cdp_url=_CDP_URL, highlight_elements=True)

        return BrowserSession(headless=True, highlight_elements=False)

    async def _run_agent(
        self, ctx: ToolContext, task: str, max_steps: int, headless: bool, keep_open: bool
    ) -> ToolOutput:
        from browser_use import Agent

        # Auto-detect display and ensure persistent Chromium is running.
        if not headless:
            if not self._auto_detect_display():
                logger.warning("No DISPLAY found — falling back to headless")
                headless = True
            else:
                _ensure_chromium_running(os.environ["DISPLAY"])

        # Build LLM for the browser agent
        provider = os.getenv("ZWISCHENZUG_PROVIDER", "").strip().lower()
        model = os.getenv("ZWISCHENZUG_MODEL", "").strip()
        llm = _build_llm(provider, model)

        # Fresh session each run — CDP if Chromium is running, headless otherwise.
        session = await self._create_session(headless=headless)

        # Step callback for live progress reporting
        steps_log: list[str] = []

        def on_step(state, output, step_num):
            action_names = []
            if hasattr(output, 'action') and output.action:
                for action in output.action if isinstance(output.action, list) else [output.action]:
                    name = getattr(action, 'name', None) or type(action).__name__
                    action_names.append(name)
            thought = ""
            if hasattr(output, 'current_state') and output.current_state:
                cs = output.current_state
                thought = getattr(cs, 'thought', '') or ''
            summary = f"Step {step_num}: {', '.join(action_names) or 'thinking'}"
            if thought:
                summary += f" — {thought[:120]}"
            steps_log.append(summary)
            logger.info(summary)

        try:
            agent = Agent(
                task=task,
                llm=llm,
                browser_session=session,
                register_new_step_callback=on_step,
                max_actions_per_step=3,
                use_vision=True,
            )

            history = await agent.run(max_steps=max_steps)

            # Build result summary
            parts: list[str] = []
            parts.append(f"Task: {task}")
            parts.append(f"Steps: {history.number_of_steps()}")
            parts.append(f"Done: {history.is_done()}")

            if history.is_done() and history.final_result():
                parts.append(f"\nResult:\n{history.final_result()}")

            extracted = history.extracted_content()
            if extracted:
                content = "\n".join(str(e) for e in extracted)
                if content.strip():
                    parts.append(f"\nExtracted content:\n{content[:5000]}")

            if history.has_errors():
                errors = history.errors()
                parts.append(f"\nErrors: {errors[:500]}")

            if steps_log:
                parts.append("\nAction log:\n" + "\n".join(steps_log[-15:]))

            urls = history.urls()
            if urls:
                parts.append(f"\nVisited URLs: {', '.join(urls[:10])}")

            parts.append("\nBrowser remains open — check it via VNC (port 6080). "
                         "Use browser_agent(task='close') to shut it down.")
            return ToolOutput.success("\n".join(parts))

        finally:
            # Detach the session wrapper but leave the Chromium process running.
            try:
                await session.stop()
            except Exception:
                pass