"""
Runtime de conversation (boucle tool-use).

Traduit depuis conversation.rs.
"""
from __future__ import annotations
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from .session import Session, ConversationMessage, ContentBlock, TextBlock, ToolUseBlock, ToolResultBlock, MessageRole
from .usage import TokenUsage, UsageTracker
from .permissions import PermissionPolicy, PermissionOutcome, PermissionContext, PermissionPrompter, PermissionOverride
from .hooks import HookRunner, HookAbortSignal, HookProgressReporter, HookRunResult
from .compact import compact_session, estimate_session_tokens, CompactionConfig, CompactionResult
from .config import RuntimeFeatureConfig

_DEFAULT_AUTO_COMPACTION_INPUT_TOKENS_THRESHOLD = 100_000
_AUTO_COMPACTION_THRESHOLD_ENV_VAR = "CLAUDE_CODE_AUTO_COMPACT_INPUT_TOKENS"

@dataclass
class ApiRequest:
    system_prompt: list[str] = field(default_factory=list)
    messages: list[ConversationMessage] = field(default_factory=list)

@dataclass
class PromptCacheEvent:
    unexpected: bool = False
    reason: str = ""
    previous_cache_read_input_tokens: int = 0
    current_cache_read_input_tokens: int = 0
    token_drop: int = 0

class AssistantEvent:
    pass

@dataclass
class TextDelta(AssistantEvent):
    text: str = ""

@dataclass
class ToolUse(AssistantEvent):
    id: str = ""
    name: str = ""
    input: str = ""

@dataclass
class UsageEvent(AssistantEvent):
    usage: TokenUsage = field(default_factory=TokenUsage)

@dataclass
class PromptCache(AssistantEvent):
    event: PromptCacheEvent = field(default_factory=PromptCacheEvent)

class MessageStop(AssistantEvent):
    pass

class ToolError(Exception):
    pass

class RuntimeError_(Exception):
    pass

class StreamCallback:
    """Callback pour recevoir les events en temps réel pendant le streaming."""
    def on_text_delta(self, text: str) -> None: ...
    def on_tool_use_start(self, name: str, id: str) -> None: ...
    def on_tool_use_end(self, name: str) -> None: ...
    def on_tool_result(self, name: str, output: str, is_error: bool) -> None: ...
    def on_turn_complete(self) -> None: ...

class ApiClient(ABC):
    @abstractmethod
    def stream(self, request: ApiRequest) -> list[AssistantEvent]: ...

class ToolExecutor(ABC):
    @abstractmethod
    def execute(self, tool_name: str, input_str: str) -> str: ...

@dataclass
class TurnSummary:
    assistant_messages: list[ConversationMessage] = field(default_factory=list)
    tool_results: list[ConversationMessage] = field(default_factory=list)
    prompt_cache_events: list[PromptCacheEvent] = field(default_factory=list)
    iterations: int = 0
    usage: TokenUsage = field(default_factory=TokenUsage)
    auto_compaction: AutoCompactionEvent | None = None

@dataclass
class AutoCompactionEvent:
    removed_message_count: int = 0

class StaticToolExecutor(ToolExecutor):
    def __init__(self) -> None:
        self._handlers: dict[str, callable] = {}
    def register(self, tool_name: str, handler) -> StaticToolExecutor:
        self._handlers[tool_name] = handler
        return self
    def execute(self, tool_name: str, input_str: str) -> str:
        handler = self._handlers.get(tool_name)
        if handler is None:
            raise ToolError(f"unknown tool: {tool_name}")
        return handler(input_str)

class ConversationRuntime:
    def __init__(self, session: Session, api_client: ApiClient, tool_executor: ToolExecutor, permission_policy: PermissionPolicy, system_prompt: list[str], feature_config: RuntimeFeatureConfig | None = None) -> None:
        self._session = session
        self._api_client = api_client
        self._tool_executor = tool_executor
        self._permission_policy = permission_policy
        self._system_prompt = system_prompt
        self._max_iterations = 2**31
        self._usage_tracker = UsageTracker.from_session(session)
        self._hook_runner = HookRunner.from_feature_config(feature_config) if feature_config else HookRunner()
        self._auto_compaction_threshold = auto_compaction_threshold_from_env()
        self._hook_abort_signal = HookAbortSignal()
        self._hook_progress_reporter: HookProgressReporter | None = None

    @staticmethod
    def new_with_features(session, api_client, tool_executor, permission_policy, system_prompt, feature_config) -> ConversationRuntime:
        return ConversationRuntime(session, api_client, tool_executor, permission_policy, system_prompt, feature_config)

    def with_max_iterations(self, n: int) -> ConversationRuntime:
        self._max_iterations = n
        return self

    def with_auto_compaction_input_tokens_threshold(self, t: int) -> ConversationRuntime:
        self._auto_compaction_threshold = t
        return self

    def run_turn(self, user_input: str, prompter: PermissionPrompter | None = None, stream_callback: StreamCallback | None = None) -> TurnSummary:
        self._session.push_user_text(user_input)
        assistant_messages: list[ConversationMessage] = []
        tool_results: list[ConversationMessage] = []
        prompt_cache_events: list[PromptCacheEvent] = []
        iterations = 0

        while True:
            iterations += 1
            if iterations > self._max_iterations:
                raise RuntimeError_("conversation loop exceeded the maximum number of iterations")

            request = ApiRequest(system_prompt=self._system_prompt, messages=list(self._session.messages))
            events = self._api_client.stream(request)

            # Stream text deltas to callback in real-time
            if stream_callback:
                for event in events:
                    if isinstance(event, TextDelta):
                        stream_callback.on_text_delta(event.text)
                    elif isinstance(event, ToolUse):
                        stream_callback.on_tool_use_start(event.name, event.id)

            assistant_msg, usage, pce = _build_assistant_message(events)
            if usage:
                self._usage_tracker.record(usage)
            prompt_cache_events.extend(pce)

            pending = [(b.id, b.name, b.input) for b in assistant_msg.blocks if isinstance(b, ToolUseBlock)]
            self._session.push_message(assistant_msg)
            assistant_messages.append(assistant_msg)

            if not pending:
                if stream_callback:
                    stream_callback.on_turn_complete()
                break

            for tool_use_id, tool_name, inp in pending:
                pre = self._hook_runner.run_pre_tool_use(tool_name, inp)
                effective_input = pre.updated_input() or inp
                context = PermissionContext(override_decision=pre.permission_override(), override_reason=pre.permission_reason())

                if pre.is_cancelled() or pre.is_failed() or pre.is_denied():
                    reason = "\n".join(pre.messages()) if pre.messages() else f"PreToolUse hook blocked tool `{tool_name}`"
                    result_msg = ConversationMessage.tool_result(tool_use_id, tool_name, reason, True)
                    if stream_callback:
                        stream_callback.on_tool_result(tool_name, reason, True)
                else:
                    outcome = self._permission_policy.authorize_with_context(tool_name, effective_input, context, prompter)
                    if outcome.allowed:
                        try:
                            output = self._tool_executor.execute(tool_name, effective_input)
                            is_error = False
                        except (ToolError, Exception) as e:
                            output = str(e)
                            is_error = True
                        result_msg = ConversationMessage.tool_result(tool_use_id, tool_name, output, is_error)
                        if stream_callback:
                            stream_callback.on_tool_result(tool_name, output[:200], is_error)
                    else:
                        result_msg = ConversationMessage.tool_result(tool_use_id, tool_name, outcome.reason, True)
                        if stream_callback:
                            stream_callback.on_tool_result(tool_name, outcome.reason, True)

                self._session.push_message(result_msg)
                tool_results.append(result_msg)

        auto_compaction = self._maybe_auto_compact()
        return TurnSummary(
            assistant_messages=assistant_messages, tool_results=tool_results,
            prompt_cache_events=prompt_cache_events, iterations=iterations,
            usage=self._usage_tracker.cumulative_usage(), auto_compaction=auto_compaction,
        )

    def session(self) -> Session:
        return self._session

    def usage(self) -> UsageTracker:
        return self._usage_tracker

    def compact(self, config: CompactionConfig) -> CompactionResult:
        return compact_session(self._session, config)

    def estimated_tokens(self) -> int:
        return estimate_session_tokens(self._session)

    def fork_session(self, branch_name: str | None = None) -> Session:
        return self._session.fork(branch_name)

    def into_session(self) -> Session:
        return self._session

    def _maybe_auto_compact(self) -> AutoCompactionEvent | None:
        if self._usage_tracker.cumulative_usage().input_tokens < self._auto_compaction_threshold:
            return None
        result = compact_session(self._session, CompactionConfig(max_estimated_tokens=0))
        if result.removed_message_count == 0:
            return None
        self._session = result.compacted_session
        return AutoCompactionEvent(removed_message_count=result.removed_message_count)


def auto_compaction_threshold_from_env() -> int:
    raw = os.environ.get(_AUTO_COMPACTION_THRESHOLD_ENV_VAR)
    if raw:
        try:
            val = int(raw.strip())
            if val > 0:
                return val
        except ValueError:
            pass
    return _DEFAULT_AUTO_COMPACTION_INPUT_TOKENS_THRESHOLD


def _build_assistant_message(events: list[AssistantEvent]) -> tuple[ConversationMessage, TokenUsage | None, list[PromptCacheEvent]]:
    text = ""
    blocks: list[ContentBlock] = []
    pce: list[PromptCacheEvent] = []
    finished = False
    usage = None

    for event in events:
        if isinstance(event, TextDelta):
            text += event.text
        elif isinstance(event, ToolUse):
            if text:
                blocks.append(TextBlock(text=text))
                text = ""
            blocks.append(ToolUseBlock(id=event.id, name=event.name, input=event.input))
        elif isinstance(event, UsageEvent):
            usage = event.usage
        elif isinstance(event, PromptCache):
            pce.append(event.event)
        elif isinstance(event, MessageStop):
            finished = True

    if text:
        blocks.append(TextBlock(text=text))
    if not finished:
        raise RuntimeError_("assistant stream ended without a message stop event")
    if not blocks:
        raise RuntimeError_("assistant stream produced no content")
    return ConversationMessage.assistant_with_usage(blocks, usage), usage, pce
