"""FileWriteTool — writes or creates files, creating parent directories as needed."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class FileWriteTool(Tool):
    name = "file_write"
    description = (
        "Writes content to a file. Creates parent directories if they don't exist. "
        "Overwrites the file if it already exists."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to write.",
            },
            "content": {
                "type": "string",
                "description": "Content to write to the file.",
            },
        },
        "required": ["path", "content"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        file_path = Path(args["path"])
        content = args["content"]

        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
        except PermissionError:
            return ToolResult(
                content=f"Permission denied: {file_path}", is_error=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error writing {file_path}: {e}", is_error=True
            )

        return ToolResult(
            content=f"Written {len(content)} bytes to {file_path}",
            metadata={"bytes_written": len(content.encode("utf-8"))},
        )
