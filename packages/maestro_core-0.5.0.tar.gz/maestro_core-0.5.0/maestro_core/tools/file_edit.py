"""FileEditTool — edits files with search/replace."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult


class FileEditTool(Tool):
    name = "file_edit"
    description = (
        "Edits a file by replacing an exact string with a new string. "
        "When replace_all is false (default), the old_string must appear exactly once. "
        "When replace_all is true, all occurrences are replaced."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to edit.",
            },
            "old_string": {
                "type": "string",
                "description": "The exact string to find and replace.",
            },
            "new_string": {
                "type": "string",
                "description": "The replacement string.",
            },
            "replace_all": {
                "type": "boolean",
                "description": "Replace all occurrences (default: false).",
                "default": False,
            },
        },
        "required": ["path", "old_string", "new_string"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        file_path = Path(args["path"])
        old_string = args["old_string"]
        new_string = args["new_string"]
        replace_all = args.get("replace_all", False)

        if not file_path.exists():
            return ToolResult(
                content=f"File not found: {file_path}", is_error=True
            )

        if not file_path.is_file():
            return ToolResult(
                content=f"Not a file: {file_path}", is_error=True
            )

        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            return ToolResult(
                content=f"Error reading {file_path}: {e}", is_error=True
            )

        occurrences = content.count(old_string)

        if occurrences == 0:
            return ToolResult(
                content=f"old_string not found in {file_path}",
                is_error=True,
            )

        if not replace_all and occurrences > 1:
            return ToolResult(
                content=(
                    f"old_string found {occurrences} times in {file_path}. "
                    "Use replace_all=true to replace all, or provide a more specific string."
                ),
                is_error=True,
            )

        if replace_all:
            new_content = content.replace(old_string, new_string)
        else:
            new_content = content.replace(old_string, new_string, 1)

        try:
            file_path.write_text(new_content, encoding="utf-8")
        except Exception as e:
            return ToolResult(
                content=f"Error writing {file_path}: {e}", is_error=True
            )

        return ToolResult(
            content=f"Replaced {occurrences if replace_all else 1} occurrence(s) in {file_path}",
            metadata={"replacements": occurrences if replace_all else 1},
        )
