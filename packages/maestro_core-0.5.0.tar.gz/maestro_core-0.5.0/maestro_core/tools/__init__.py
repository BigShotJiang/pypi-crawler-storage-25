"""Maestro tool framework — shared between CLI and OKE cloud.

Exports:
- Base classes: Tool, ToolRegistry, ToolResult, ToolDefinition, RiskLevel
- Tool implementations: BashTool, FileReadTool, FileWriteTool, FileEditTool,
  GrepTool, GlobTool, NotebookEditTool, TodoWriteTool, WebFetchTool, MCPBridgeTool
- Spec system: ToolSpec, PermissionMode, GlobalToolRegistry, mvp_tool_specs
- Execution: execute_tool_dispatch
"""

# --- Base framework ---
from maestro_core.tools.base import Tool, ToolRegistry, ToolResult, ToolDefinition, RiskLevel

# --- Concrete tool implementations (async) ---
from maestro_core.tools.bash import BashTool
from maestro_core.tools.file_read import FileReadTool
from maestro_core.tools.file_write import FileWriteTool
from maestro_core.tools.file_edit import FileEditTool
from maestro_core.tools.grep import GrepTool
from maestro_core.tools.glob_tool import GlobTool
from maestro_core.tools.notebook_edit import NotebookEditTool
from maestro_core.tools.todo_write import TodoWriteTool
from maestro_core.tools.web_fetch import WebFetchTool
from maestro_core.tools.mcp_bridge import MCPBridgeTool

# --- Spec system (JSON schemas + registry from CC Rust harness) ---
from maestro_core.tools.specs import ToolSpec, PermissionMode
from maestro_core.tools.registry import (
    GlobalToolRegistry,
    RuntimeToolDefinition,
    ToolManifestEntry,
    ToolSearchOutput,
    ToolSource,
    mvp_tool_specs,
    execute_tool,
)

# --- Synchronous execution dispatch ---
from maestro_core.tools.execution import execute_tool_dispatch

__all__ = [
    # Base
    "Tool",
    "ToolRegistry",
    "ToolResult",
    "ToolDefinition",
    "RiskLevel",
    # Tool implementations
    "BashTool",
    "FileReadTool",
    "FileWriteTool",
    "FileEditTool",
    "GrepTool",
    "GlobTool",
    "NotebookEditTool",
    "TodoWriteTool",
    "WebFetchTool",
    "MCPBridgeTool",
    # Spec system
    "ToolSpec",
    "PermissionMode",
    "GlobalToolRegistry",
    "RuntimeToolDefinition",
    "ToolManifestEntry",
    "ToolSearchOutput",
    "ToolSource",
    "mvp_tool_specs",
    "execute_tool",
    # Execution
    "execute_tool_dispatch",
]
