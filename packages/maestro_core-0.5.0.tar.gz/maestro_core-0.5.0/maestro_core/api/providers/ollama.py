"""Client Ollama — provider local compatible OpenAI.

Ollama expose un endpoint compatible OpenAI à http://localhost:11434/v1.
Ce provider hérite du comportement OpenAI compatible et gère les cas
où les modèles ne supportent pas le tool calling."""

from __future__ import annotations

import os
from typing import Any, Optional

import httpx

from ..error import ApiError, HttpError
from ..types import (
    MessageRequest,
    MessageResponse,
    StreamEvent,
    TextOutputBlock,
    Usage,
)
from .openai_compat import (
    OpenAiCompatClient,
    OpenAiCompatConfig,
    OpenAiMessageStream,
    _build_chat_completion_request,
    _normalize_response,
    _expect_success,
    _request_id_from_headers,
    _error_is_retryable,
)

DEFAULT_OLLAMA_BASE_URL = "http://localhost:11434/v1"

# Modèles connus qui supportent le tool calling
_TOOL_CAPABLE_MODELS = {
    "llama3.1", "llama3.2", "llama3.3",
    "mistral", "mistral-nemo", "mistral-large", "ministral",
    "mixtral",
    "command-r", "command-r-plus",
    "qwen2", "qwen2.5", "qwen3",
    "hermes", "hermes4", "firefunction",
    "deepseek-r1",
}


def _model_supports_tools(model: str) -> bool:
    """Heuristique : vérifie si un modèle Ollama supporte les outils.

    On vérifie si le nom de base du modèle (sans tag) est dans la liste connue.
    En cas de doute, on tente quand même — Ollama ignorera silencieusement."""
    base_name = model.split(":")[0].lower()
    for known in _TOOL_CAPABLE_MODELS:
        if base_name.startswith(known):
            return True
    return False


class OllamaConfig(OpenAiCompatConfig):
    """Configuration spécifique Ollama."""

    def __init__(self, base_url: Optional[str] = None) -> None:
        resolved_url = (
            base_url
            or os.environ.get("OLLAMA_BASE_URL")
            or DEFAULT_OLLAMA_BASE_URL
        )
        # Ollama n'a pas besoin de clé API
        super().__init__(
            provider_name="Ollama",
            api_key_env="",  # Pas de clé requise
            base_url_env="OLLAMA_BASE_URL",
            default_base_url=resolved_url,
        )

    def credential_env_vars(self) -> tuple[str, ...]:
        return ()  # Aucune clé nécessaire


class OllamaClient:
    """Client pour Ollama (local, offline).

    Utilise le format OpenAI compatible, avec gestion gracieuse
    des modèles qui ne supportent pas le tool calling."""

    def __init__(self, base_url: Optional[str] = None) -> None:
        self._config = OllamaConfig(base_url)
        self._base_url = self._config.default_base_url
        self._http = httpx.AsyncClient(
            timeout=300.0,  # Ollama peut être lent sur les gros modèles
        )
        # Pas de clé API pour Ollama
        self._api_key = "ollama"  # Placeholder, ignoré par Ollama

    @classmethod
    def from_env(cls) -> OllamaClient:
        """Crée un client depuis les variables d'environnement."""
        return cls()

    async def send_message(self, request: MessageRequest) -> MessageResponse:
        """Envoie un message non-streaming."""
        cleaned = self._prepare_request(request)
        response = await self._send_raw(cleaned, stream=False)
        checked = _expect_success(response)
        payload = checked.json()
        return _normalize_response(request.model, payload)

    async def stream_message(self, request: MessageRequest) -> OpenAiMessageStream:
        """Envoie un message en mode streaming."""
        cleaned = self._prepare_request(request)
        streaming = cleaned.with_streaming()
        response = await self._send_raw(streaming, stream=True)
        checked = _expect_success(response)
        return OpenAiMessageStream(
            request_id=_request_id_from_headers(checked.headers),
            response=checked,
            model=request.model,
        )

    def _prepare_request(self, request: MessageRequest) -> MessageRequest:
        """Prépare la requête — retire les outils si le modèle ne les supporte pas."""
        if request.tools and not _model_supports_tools(request.model):
            # Convertir les outils en instructions textuelles dans le system prompt
            tool_instructions = self._tools_as_text(request.tools)
            augmented_system = (request.system or "") + "\n\n" + tool_instructions
            return MessageRequest(
                model=request.model,
                max_tokens=request.max_tokens,
                messages=request.messages,
                system=augmented_system.strip(),
                tools=None,  # Retirer les outils
                tool_choice=None,
                stream=request.stream,
            )
        return request

    def _tools_as_text(self, tools: list[Any]) -> str:
        """Convertit les définitions d'outils en instructions textuelles.

        Fallback pour les modèles qui ne supportent pas nativement les outils."""
        lines = [
            "Tu as accès aux outils suivants. Pour les appeler, "
            "réponds avec un bloc JSON dans ce format :",
            '```json\n{"tool": "nom_outil", "arguments": {...}}\n```',
            "",
            "Outils disponibles :",
        ]
        for tool in tools:
            if hasattr(tool, "name"):
                desc = getattr(tool, "description", "") or ""
                lines.append(f"- **{tool.name}** : {desc}")
        return "\n".join(lines)

    async def _send_raw(
        self, request: MessageRequest, stream: bool
    ) -> httpx.Response:
        """Envoie une requête brute à Ollama."""
        url = f"{self._base_url.rstrip('/')}/chat/completions"
        headers = {
            "content-type": "application/json",
            "authorization": f"Bearer {self._api_key}",
        }
        body = _build_chat_completion_request(request, self._config)

        try:
            if stream:
                req = self._http.build_request(
                    "POST", url, json=body, headers=headers
                )
                response = await self._http.send(req, stream=True)
                return response
            else:
                return await self._http.post(url, json=body, headers=headers)
        except httpx.ConnectError as exc:
            raise HttpError(
                original=ConnectionError(
                    f"Impossible de se connecter à Ollama ({self._base_url}). "
                    f"Vérifiez que le serveur est démarré avec `ollama serve`."
                )
            ) from exc
        except httpx.HTTPError as exc:
            raise HttpError(original=exc) from exc

    async def is_available(self) -> bool:
        """Vérifie si Ollama est accessible (utile pour le mode offline)."""
        try:
            # Endpoint de santé Ollama (hors API OpenAI compat)
            base = self._base_url.replace("/v1", "")
            response = await self._http.get(f"{base}/api/tags", timeout=5.0)
            return response.is_success
        except (httpx.HTTPError, OSError):
            return False

    async def list_models(self) -> list[str]:
        """Liste les modèles disponibles localement sur Ollama."""
        try:
            base = self._base_url.replace("/v1", "")
            response = await self._http.get(f"{base}/api/tags", timeout=10.0)
            if response.is_success:
                data = response.json()
                return [m["name"] for m in data.get("models", [])]
        except (httpx.HTTPError, OSError, KeyError):
            pass
        return []

    async def close(self) -> None:
        """Ferme le client HTTP."""
        await self._http.aclose()
