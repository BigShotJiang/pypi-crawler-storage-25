"""/pop command plugin."""
