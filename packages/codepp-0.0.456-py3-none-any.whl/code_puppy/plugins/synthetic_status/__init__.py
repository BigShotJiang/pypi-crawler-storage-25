"""Synthetic provider status plugin."""
