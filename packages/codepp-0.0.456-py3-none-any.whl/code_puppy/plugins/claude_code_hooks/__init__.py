"""Claude Code hooks plugin."""
