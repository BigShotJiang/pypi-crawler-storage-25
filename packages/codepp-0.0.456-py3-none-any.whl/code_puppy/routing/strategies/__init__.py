"""Built-in routing strategies."""
