"""GUI components package."""
