<picture>
  <source media="(prefers-color-scheme: dark)" srcset="cupel/ui/cupel-logo-dark.svg">
  <img src="cupel/ui/cupel-logo.svg" alt="cupel" height="42">
</picture>

> separates precious LLMs from base LLMs. works with any OpenAI/Anthropic compatible API

cupel sends the same prompts to multiple models (local and cloud, side by side),
scores responses with a configurable judge, and shows results on a leaderboard.

the name comes from metallurgy: a cupel is the small dish used in a fire assay to separate precious metal from base metal.

## key features

- **your own benchmarks** — prompts and rubrics that test what _you_ care about, not MMLU
- **LLM-assisted authoring** — describe what you want to test, an LLM drafts the prompt and rubric
- **local + cloud side by side** — bench oMLX, Ollama, OpenRouter, Anthropic, OpenAI models in one run
- **auto-discovers your stack** — probes oMLX, Ollama, LM Studio, SGLang on startup
- **custom judges** — use Claude, GPT-4o, or a local model as judge. local/remote toggle in settings
- **thinking model support** — separates `<think>` blocks from answers, only judges the response
- **multi-turn + multimodal** — tool-call conversations, injected results, vision prompts
- **tool call capture** — native `tool_calls` JSON captured and shown to the judge
- **speed tracking** — tok/s and response times on your hardware, right on the leaderboard
- **CLI and web** — same engine, pick your workflow

## install

```bash
pip install cupel
```

no node, no npm, no build step. the web UI ships inside the python package.

## quick start

```bash
cupel
```

browser opens to `localhost:8042` with **pre-baked example data** — 5 models scored by Claude Opus on 8 prompts. real data, not mock. you're exploring the leaderboard, reading judge reasoning, and comparing responses immediately.

cupel probes your machine for inference servers. if it finds one, a welcome banner offers to run the same prompts on your model with one click.

install → "my model scored 19/24" takes about 3 minutes.

## the dashboard

models ranked by score, with:

- **score bars** — per-prompt ticks color-coded 3/2/1/0
- **judge + hardware** — each row shows which judge scored it and where it ran (local hardware or cloud provider)
- **category breakdown** — grid of categories x models
- **detail panel** — click a row to see per-prompt scores, judge reasons, rubric, full responses
- **speed column** — tok/s and avg response time

## bench it

the "Bench It" page runs evals from the UI:

1. **Models** — multiselect from all local + cloud providers, grouped by provider
2. **IQ Tasks** — category chips: `all`, `starter`, `coding`, `systems`, `reasoning`, etc.
3. **Judge** — pre-populated from your config default, or pick any model
4. click the button — live progress grid fills in as prompts complete and get scored

partial results are saved if you stop mid-run. model and category selections persist across page navigations.

## author prompts

describe what you want to test → pick a category and model → generate.

the LLM drafts title, prompt, and 0-3 rubric. review, edit, save to your eval set. handles messy LLM output: extracts JSON from thinking-heavy responses, repairs truncated output.

## eval set

browse all prompts in your active eval set — titles, categories, full prompt text and rubrics. click any row to expand. cupel ships with a starter set (8 prompts) and a full set (22 prompts).

## results

view, tag, and manage all result files. each file records model, judge, timestamp, per-prompt scores and judge reasoning. sort by model, score, or date. delete old runs or tag them for organization.

## settings

configure temperature, max tokens, thinking budget, judge model (local/remote toggle), and output directory. add cloud providers from presets (Anthropic, OpenRouter, OpenAI) or define custom endpoints. fetch available models from a provider's API, validate API keys, and test connections before saving.

## providers

cupel auto-discovers local servers on known ports:

| port | server |
|------|--------|
| 8000 | oMLX / vLLM |
| 11434 | Ollama |
| 1234 | LM Studio |
| 30000 | SGLang |

add cloud providers from the Settings page (presets for Anthropic, OpenRouter, OpenAI) or in config:

```yaml
# config.yml
providers:
  - name: openrouter
    api_url: https://openrouter.ai/api/v1/chat/completions
    api_key_env: OPENROUTER_API_KEY
    models: [google/gemini-2.5-pro, deepseek/deepseek-r1]

  - name: anthropic
    api_url: https://api.anthropic.com/v1/messages
    api_key_env: ANTHROPIC_API_KEY
    models: [claude-opus-4-6, claude-sonnet-4-6]
```

the Settings page can fetch available models from a provider's API (with pricing for OpenRouter), validate API keys, and test connections before saving.

### API keys

each provider gets its own env var. put them in `.env` or `~/.cupel/.env`:

```bash
OMLX_API_KEY=4242
ANTHROPIC_API_KEY=sk-ant-...
OPENROUTER_API_KEY=sk-or-...
OPENAI_API_KEY=sk-proj-...
```

legacy `LLM_API_KEY` / `LLM_API_URL` still work as fallbacks.

## judge

set a default judge in Settings (Local/Remote toggle + model dropdown) or in config:

```yaml
judge:
  model: claude-opus-4-6
```

the judge is resolved through its provider — no need to repeat URLs and keys. scores are 0-3:

| score | meaning |
|-------|---------|
| 3 | correct and insightful |
| 2 | correct but shallow |
| 1 | partially correct |
| 0 | wrong or hallucinated |

## CLI

```bash
cupel run                              # collect responses
cupel run --models "Qwen3.5-27B-8bit"  # specific model
cupel run --prompts 18-22              # specific prompts
cupel judge eval-results/eval_*.json   # score with judge
cupel judge eval-results/*.json --judge-model gpt-4o  # override judge
cupel ui                               # open dashboard
cupel init                             # create config.yml + eval-set
```

## prompt format

the idea is you write your own prompts:

```json
{
  "id": 14,
  "category": "math_estimation",
  "title": "Model Memory from Quantization",
  "prompt": "A model has 70B parameters. Estimate memory for FP16, 8-bit, and 4-bit.",
  "rubric": {
    "3": "FP16: ~140GB, 8-bit: ~70GB, 4-bit: ~35GB. Shows the math.",
    "2": "Correct for 2 of 3, or all correct but no explanation.",
    "1": "Gets the direction right but wrong numbers.",
    "0": "Wrong math or doesn't understand quantization."
  }
}
```

### multi-turn prompts

for tool calling and conversations, use `turns` instead of `prompt`:

```json
{
  "id": 21,
  "title": "Tool Calling — School Status Check",
  "turns": [
    {
      "messages": [
        {"role": "system", "content": "You have tools: get_grades(name), ..."},
        {"role": "user", "content": "How are both kids doing?"}
      ]
    },
    {
      "inject_after": [
        {"role": "user", "content": "Tool results: get_grades(\"phoebe\") => ..."}
      ]
    }
  ],
  "rubric": { "3": "Emits correct tool calls, synthesizes results...", ... }
}
```

### thinking models

cupel handles `<think>` blocks automatically — separates thinking from the answer, only judges the response. configure in `config.yml`:

```yaml
thinking: null   # model default (recommended)
thinking: 0      # disable
thinking: 4096   # explicit budget
```

## development

```bash
git clone https://github.com/tolitius/cupel.git && cd cupel
pip install -e .
uvicorn cupel.server:app --reload --port 8042  # dev mode
```

vanilla JS frontend (Preact + HTM from CDN). no build step.

## license

Copyright © 2025 tolitius

Distributed under the MIT License.
