import os

import pytest

from pendra import AsyncPendra, Pendra
from pendra.resources.async_models import AsyncModels
from pendra.resources.models import Models


class TestPendraInit:
    def test_raises_without_api_key(self, monkeypatch):
        monkeypatch.delenv("PENDRA_API_KEY", raising=False)
        with pytest.raises(ValueError, match="No API key"):
            Pendra()

    def test_picks_up_env_var(self, monkeypatch):
        monkeypatch.setenv("PENDRA_API_KEY", "pdr_sk_from_env")
        client = Pendra()
        assert client.api_key == "pdr_sk_from_env"
        client.close()

    def test_strips_trailing_slash(self, api_key):
        client = Pendra(api_key=api_key, base_url="https://example.com/")
        assert client.base_url == "https://example.com"
        client.close()

    def test_context_manager(self, api_key, base_url):
        with Pendra(api_key=api_key, base_url=base_url) as client:
            assert client.api_key == api_key

    def test_has_chat_and_models(self, sync_client):
        assert hasattr(sync_client, "chat")
        assert isinstance(sync_client.models, Models)


class TestAsyncPendraInit:
    def test_raises_without_api_key(self, monkeypatch):
        monkeypatch.delenv("PENDRA_API_KEY", raising=False)
        with pytest.raises(ValueError, match="No API key"):
            AsyncPendra()

    def test_picks_up_env_var(self, monkeypatch):
        monkeypatch.setenv("PENDRA_API_KEY", "pdr_sk_from_env")
        client = AsyncPendra()
        assert client.api_key == "pdr_sk_from_env"

    def test_has_chat_and_models(self, api_key, base_url):
        client = AsyncPendra(api_key=api_key, base_url=base_url)
        assert hasattr(client, "chat")
        assert isinstance(client.models, AsyncModels)

    @pytest.mark.asyncio
    async def test_async_context_manager(self, api_key, base_url):
        async with AsyncPendra(api_key=api_key, base_url=base_url) as client:
            assert client.api_key == api_key
