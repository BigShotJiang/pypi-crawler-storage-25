import json

import httpx
import pytest
import respx

from pendra._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)
from pendra.types.embeddings import CreateEmbeddingResponse

EMBEDDINGS_URL = "https://test.pendra.ai/api/v1/embeddings"

SAMPLE_RESPONSE = {
    "object": "list",
    "data": [
        {"object": "embedding", "embedding": [0.1, 0.2, 0.3], "index": 0},
    ],
    "model": "nomic-embed-text:latest",
    "usage": {"prompt_tokens": 5, "total_tokens": 5},
}


class TestSyncEmbeddings:
    @respx.mock
    def test_create_with_string_input(self, sync_client):
        respx.post(EMBEDDINGS_URL).respond(json=SAMPLE_RESPONSE)
        result = sync_client.embeddings.create(
            model="nomic-embed-text:latest",
            input="Hello world",
        )
        assert isinstance(result, CreateEmbeddingResponse)
        assert result.object == "list"
        assert len(result.data) == 1
        assert result.data[0].embedding == [0.1, 0.2, 0.3]
        assert result.data[0].index == 0
        assert result.usage.prompt_tokens == 5

    @respx.mock
    def test_create_with_list_input(self, sync_client):
        batch_response = {
            **SAMPLE_RESPONSE,
            "data": [
                {"object": "embedding", "embedding": [0.1], "index": 0},
                {"object": "embedding", "embedding": [0.2], "index": 1},
            ],
        }
        route = respx.post(EMBEDDINGS_URL).respond(json=batch_response)
        result = sync_client.embeddings.create(
            model="all-minilm:22m",
            input=["foo", "bar"],
        )
        assert len(result.data) == 2
        body = json.loads(route.calls[0].request.content)
        assert body["input"] == ["foo", "bar"]

    @respx.mock
    def test_forwards_params(self, sync_client):
        route = respx.post(EMBEDDINGS_URL).respond(json=SAMPLE_RESPONSE)
        sync_client.embeddings.create(
            model="nomic-embed-text:latest",
            input="hi",
            encoding_format="base64",
            dimensions=256,
            user="u1",
        )
        body = json.loads(route.calls[0].request.content)
        assert body["encoding_format"] == "base64"
        assert body["dimensions"] == 256
        assert body["user"] == "u1"

    @respx.mock
    def test_sends_bearer_auth(self, sync_client):
        route = respx.post(EMBEDDINGS_URL).respond(json=SAMPLE_RESPONSE)
        sync_client.embeddings.create(model="m", input="hi")
        assert route.calls[0].request.headers["authorization"] == "Bearer pdr_sk_test123"

    def test_rejects_empty_string_input(self, sync_client):
        with pytest.raises(ValueError):
            sync_client.embeddings.create(model="m", input="")

    def test_rejects_empty_list_input(self, sync_client):
        with pytest.raises(ValueError):
            sync_client.embeddings.create(model="m", input=[])

    def test_rejects_non_string_items(self, sync_client):
        with pytest.raises(ValueError):
            sync_client.embeddings.create(model="m", input=["foo", ""])

    def test_rejects_bad_input_type(self, sync_client):
        with pytest.raises(TypeError):
            sync_client.embeddings.create(model="m", input=123)  # type: ignore[arg-type]

    @respx.mock
    def test_401_raises_authentication_error(self, sync_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            sync_client.embeddings.create(model="m", input="hi")

    @respx.mock
    def test_429_raises_rate_limit_error(self, sync_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=429)
        with pytest.raises(RateLimitError):
            sync_client.embeddings.create(model="m", input="hi")

    @respx.mock
    def test_500_raises_api_status_error(self, sync_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=500, json={"detail": "boom"})
        with pytest.raises(APIStatusError) as exc:
            sync_client.embeddings.create(model="m", input="hi")
        assert exc.value.status_code == 500

    @respx.mock
    def test_connection_error(self, sync_client):
        respx.post(EMBEDDINGS_URL).mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(APIConnectionError):
            sync_client.embeddings.create(model="m", input="hi")
