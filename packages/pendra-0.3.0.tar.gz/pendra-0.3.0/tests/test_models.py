import respx
import pytest

from pendra.resources.models import Model

MODELS_URL = "https://test.pendra.ai/api/v1/models"

SAMPLE_MODELS = {
    "data": [
        {"id": "meta-llama/Llama-3.2-8B-Instruct", "object": "model", "created": 1700000000, "owned_by": "meta-llama"},
        {"id": "mistralai/Mistral-7B-Instruct-v0.3", "object": "model", "created": 1700000001, "owned_by": "mistralai"},
    ]
}


class TestSyncModels:
    @respx.mock
    def test_list_success(self, sync_client):
        respx.get(MODELS_URL).respond(json=SAMPLE_MODELS)
        models = sync_client.models.list()
        assert len(models) == 2
        assert all(isinstance(m, Model) for m in models)
        assert models[0].id == "meta-llama/Llama-3.2-8B-Instruct"
        assert models[1].owned_by == "mistralai"

    @respx.mock
    def test_list_empty(self, sync_client):
        respx.get(MODELS_URL).respond(json={"data": []})
        models = sync_client.models.list()
        assert models == []

    @respx.mock
    def test_list_401(self, sync_client):
        respx.get(MODELS_URL).respond(status_code=401)
        with pytest.raises(Exception):
            sync_client.models.list()
