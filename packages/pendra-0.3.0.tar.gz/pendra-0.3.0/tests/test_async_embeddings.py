import json

import httpx
import pytest
import respx

from pendra._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)
from pendra.types.embeddings import CreateEmbeddingResponse

pytestmark = pytest.mark.asyncio

EMBEDDINGS_URL = "https://test.pendra.ai/api/v1/embeddings"

SAMPLE_RESPONSE = {
    "object": "list",
    "data": [
        {"object": "embedding", "embedding": [0.1, 0.2, 0.3], "index": 0},
    ],
    "model": "nomic-embed-text:latest",
    "usage": {"prompt_tokens": 5, "total_tokens": 5},
}


class TestAsyncEmbeddings:
    @respx.mock
    async def test_create_success(self, async_client):
        respx.post(EMBEDDINGS_URL).respond(json=SAMPLE_RESPONSE)
        result = await async_client.embeddings.create(
            model="nomic-embed-text:latest",
            input="Hello",
        )
        assert isinstance(result, CreateEmbeddingResponse)
        assert result.data[0].embedding == [0.1, 0.2, 0.3]

    @respx.mock
    async def test_forwards_params(self, async_client):
        route = respx.post(EMBEDDINGS_URL).respond(json=SAMPLE_RESPONSE)
        await async_client.embeddings.create(
            model="m", input=["a", "b"], encoding_format="base64", dimensions=128,
        )
        body = json.loads(route.calls[0].request.content)
        assert body["input"] == ["a", "b"]
        assert body["encoding_format"] == "base64"
        assert body["dimensions"] == 128

    @respx.mock
    async def test_401_raises_authentication_error(self, async_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            await async_client.embeddings.create(model="m", input="hi")

    @respx.mock
    async def test_429_raises_rate_limit_error(self, async_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=429)
        with pytest.raises(RateLimitError):
            await async_client.embeddings.create(model="m", input="hi")

    @respx.mock
    async def test_500_raises_api_status_error(self, async_client):
        respx.post(EMBEDDINGS_URL).respond(status_code=500, json={"detail": "boom"})
        with pytest.raises(APIStatusError):
            await async_client.embeddings.create(model="m", input="hi")

    @respx.mock
    async def test_connection_error(self, async_client):
        respx.post(EMBEDDINGS_URL).mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(APIConnectionError):
            await async_client.embeddings.create(model="m", input="hi")
