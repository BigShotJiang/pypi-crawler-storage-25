from pendra._exceptions import (
    APIConnectionError,
    APIError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)


class TestExceptionHierarchy:
    def test_api_connection_error_is_api_error(self):
        assert issubclass(APIConnectionError, APIError)

    def test_api_status_error_is_api_error(self):
        assert issubclass(APIStatusError, APIError)

    def test_authentication_error_is_status_error(self):
        assert issubclass(AuthenticationError, APIStatusError)

    def test_rate_limit_error_is_status_error(self):
        assert issubclass(RateLimitError, APIStatusError)

    def test_authentication_error_status_code(self):
        err = AuthenticationError()
        assert err.status_code == 401

    def test_rate_limit_error_status_code(self):
        err = RateLimitError()
        assert err.status_code == 429

    def test_api_error_message(self):
        err = APIError("something broke", status_code=503)
        assert str(err) == "something broke"
        assert err.status_code == 503

    def test_api_connection_error_default_message(self):
        err = APIConnectionError()
        assert "Failed to connect" in str(err)
