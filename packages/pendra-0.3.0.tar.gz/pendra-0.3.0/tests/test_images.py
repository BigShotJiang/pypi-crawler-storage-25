import json

import httpx
import pytest
import respx

from pendra._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from pendra.types.images import ImageResponse

IMAGES_URL = "https://test.pendra.ai/api/v1/images/generations"

SAMPLE_B64 = {
    "created": 1700000000,
    "data": [{"b64_json": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Zk8wQAAAABJRU5ErkJggg=="}],
}

SAMPLE_URL = {
    "created": 1700000001,
    "data": [{"url": "https://example.com/img.png"}],
}


class TestSyncImages:
    @respx.mock
    def test_create_success_b64(self, sync_client):
        respx.post(IMAGES_URL).respond(json=SAMPLE_B64)
        result = sync_client.images.generations.create(model="x/z-image-turbo", prompt="A sunset over mountains")
        assert isinstance(result, ImageResponse)
        assert result.created == 1700000000
        assert result.data[0].b64_json.startswith("iVBOR")
        assert result.data[0].url is None

    @respx.mock
    def test_create_success_url_response_format(self, sync_client):
        respx.post(IMAGES_URL).respond(json=SAMPLE_URL)
        result = sync_client.images.generations.create(
            model="x/z-image-turbo", prompt="A sunset", response_format="url"
        )
        assert result.data[0].url == "https://example.com/img.png"
        assert result.data[0].b64_json is None

    @respx.mock
    def test_sends_optional_params_only_when_set(self, sync_client):
        route = respx.post(IMAGES_URL).respond(json=SAMPLE_B64)
        sync_client.images.generations.create(
            model="x/z-image-turbo",
            prompt="A cat",
            n=2,
            size="512x512",
            seed=42,
            negative_prompt="blurry",
            num_inference_steps=30,
        )
        payload = json.loads(route.calls[0].request.content)
        assert payload["model"] == "x/z-image-turbo"
        assert payload["prompt"] == "A cat"
        assert payload["n"] == 2
        assert payload["size"] == "512x512"
        assert payload["seed"] == 42
        assert payload["negative_prompt"] == "blurry"
        assert payload["num_inference_steps"] == 30

    @respx.mock
    def test_omits_optional_params_when_unset(self, sync_client):
        route = respx.post(IMAGES_URL).respond(json=SAMPLE_B64)
        sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")
        payload = json.loads(route.calls[0].request.content)
        assert "seed" not in payload
        assert "negative_prompt" not in payload
        assert "num_inference_steps" not in payload

    @respx.mock
    def test_401_raises_authentication_error(self, sync_client):
        respx.post(IMAGES_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")

    @respx.mock
    def test_429_raises_rate_limit_error(self, sync_client):
        respx.post(IMAGES_URL).respond(status_code=429)
        with pytest.raises(RateLimitError):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")

    @respx.mock
    def test_422_validation_error_raises_api_status_error(self, sync_client):
        respx.post(IMAGES_URL).respond(status_code=422, json={"detail": "Invalid size"})
        with pytest.raises(APIStatusError) as exc_info:
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")
        assert exc_info.value.status_code == 422

    @respx.mock
    def test_connection_error(self, sync_client):
        respx.post(IMAGES_URL).mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(APIConnectionError):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")

    def test_client_validation_empty_prompt(self, sync_client):
        with pytest.raises(ValueError, match="prompt"):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="   ")

    def test_client_validation_n_out_of_range(self, sync_client):
        with pytest.raises(ValueError, match="n must be"):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat", n=0)
        with pytest.raises(ValueError, match="n must be"):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat", n=5)

    def test_client_validation_bad_size(self, sync_client):
        with pytest.raises(ValueError, match="size"):
            sync_client.images.generations.create(model="x/z-image-turbo", prompt="A cat", size="big")


class TestAsyncImages:
    @respx.mock
    @pytest.mark.asyncio
    async def test_create_success(self, async_client):
        respx.post(IMAGES_URL).respond(json=SAMPLE_B64)
        result = await async_client.images.generations.create(
            model="x/z-image-turbo", prompt="A sunset over mountains"
        )
        assert isinstance(result, ImageResponse)
        assert result.data[0].b64_json.startswith("iVBOR")

    @respx.mock
    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, async_client):
        respx.post(IMAGES_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            await async_client.images.generations.create(model="x/z-image-turbo", prompt="A cat")

    @pytest.mark.asyncio
    async def test_client_validation_bad_size(self, async_client):
        with pytest.raises(ValueError, match="size"):
            await async_client.images.generations.create(
                model="x/z-image-turbo", prompt="A cat", size="huge"
            )
