from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Optional, Union

from .._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)
from ..types.embeddings import CreateEmbeddingResponse

if TYPE_CHECKING:
    from .._client import AsyncPendra, Pendra


def _build_payload(
    *,
    model: str,
    input: Union[str, list[str]],
    encoding_format: Literal["float", "base64"],
    dimensions: Optional[int],
    user: Optional[str],
    extra: dict,
) -> dict:
    if not model or not isinstance(model, str):
        raise ValueError("model must be a non-empty string")
    if isinstance(input, str):
        if not input:
            raise ValueError("input must be a non-empty string or non-empty list of strings")
    elif isinstance(input, list):
        if not input or not all(isinstance(i, str) and i for i in input):
            raise ValueError("input must be a non-empty string or non-empty list of strings")
    else:
        raise TypeError("input must be a string or a list of strings")

    payload: dict = {
        "model": model,
        "input": input,
        "encoding_format": encoding_format,
    }
    if dimensions is not None:
        payload["dimensions"] = dimensions
    if user is not None:
        payload["user"] = user
    payload.update(extra)
    return payload


def _raise_for_status(response) -> None:
    if response.status_code == 401:
        raise AuthenticationError()
    if response.status_code == 429:
        raise RateLimitError()
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise APIStatusError(detail, status_code=response.status_code)


class Embeddings:
    """Synchronous embeddings resource. OpenAI-compatible."""

    def __init__(self, client: "Pendra"):
        self._client = client

    def create(
        self,
        *,
        model: str,
        input: Union[str, list[str]],
        encoding_format: Literal["float", "base64"] = "float",
        dimensions: Optional[int] = None,
        user: Optional[str] = None,
        **kwargs,
    ) -> CreateEmbeddingResponse:
        """Create embeddings for the given input.

        Args:
            model: Embedding model id (e.g. ``"nomic-embed-text:latest"``).
            input: A string, or a list of strings, to embed.
            encoding_format: ``"float"`` (default) or ``"base64"``.
            dimensions: Optional output dimensionality for models that support
                Matryoshka truncation (e.g. nomic-embed-text).
            user: Optional end-user identifier for abuse monitoring.

        Example::

            from pendra import Pendra

            client = Pendra()
            resp = client.embeddings.create(
                model="nomic-embed-text:latest",
                input="Hello world",
            )
            print(len(resp.data[0].embedding))
        """
        payload = _build_payload(
            model=model,
            input=input,
            encoding_format=encoding_format,
            dimensions=dimensions,
            user=user,
            extra=kwargs,
        )

        url = f"{self._client.base_url}/api/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = self._client._http.post(url, json=payload, headers=headers, timeout=60.0)
            _raise_for_status(resp)
            return CreateEmbeddingResponse.from_dict(resp.json())
        except Exception as exc:
            if isinstance(exc, (APIStatusError, APIConnectionError, AuthenticationError, RateLimitError)):
                raise
            raise APIConnectionError(str(exc)) from exc


class AsyncEmbeddings:
    """Async embeddings resource. OpenAI-compatible."""

    def __init__(self, client: "AsyncPendra"):
        self._client = client

    async def create(
        self,
        *,
        model: str,
        input: Union[str, list[str]],
        encoding_format: Literal["float", "base64"] = "float",
        dimensions: Optional[int] = None,
        user: Optional[str] = None,
        **kwargs,
    ) -> CreateEmbeddingResponse:
        payload = _build_payload(
            model=model,
            input=input,
            encoding_format=encoding_format,
            dimensions=dimensions,
            user=user,
            extra=kwargs,
        )

        url = f"{self._client.base_url}/api/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = await self._client._http.post(url, json=payload, headers=headers, timeout=60.0)
            _raise_for_status(resp)
            return CreateEmbeddingResponse.from_dict(resp.json())
        except Exception as exc:
            if isinstance(exc, (APIStatusError, APIConnectionError, AuthenticationError, RateLimitError)):
                raise
            raise APIConnectionError(str(exc)) from exc
