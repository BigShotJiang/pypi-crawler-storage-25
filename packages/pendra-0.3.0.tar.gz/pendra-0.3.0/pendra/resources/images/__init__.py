from .generations import Generations


class Images:
    def __init__(self, client):
        self.generations = Generations(client)
