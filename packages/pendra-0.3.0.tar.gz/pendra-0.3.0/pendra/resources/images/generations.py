from __future__ import annotations

import re
from typing import TYPE_CHECKING, Optional

from ..._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from ...types.images import ImageResponse

if TYPE_CHECKING:
    from ..._client import Pendra


_SIZE_RE = re.compile(r"^\d+x\d+$")


def _validate_image_params(prompt: str, n: int, size: str) -> None:
    if not prompt or not prompt.strip():
        raise ValueError("prompt must be a non-empty string")
    if n < 1 or n > 4:
        raise ValueError("n must be between 1 and 4")
    if not _SIZE_RE.match(size):
        raise ValueError("size must be in the form WIDTHxHEIGHT (e.g. '1024x1024')")


class Generations:
    def __init__(self, client: "Pendra"):
        self._client = client

    def create(
        self,
        *,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        response_format: str = "b64_json",
        num_inference_steps: Optional[int] = None,
        seed: Optional[int] = None,
        negative_prompt: Optional[str] = None,
        **kwargs,
    ) -> ImageResponse:
        """Generate images from a text prompt.

        Args:
            model: The image generation model ID (e.g. "x/z-image-turbo").
            prompt: Text description of the image to generate.
            n: Number of images to generate (1-4).
            size: Image dimensions as "WIDTHxHEIGHT" (e.g. "1024x1024").
            response_format: Output format (currently only "b64_json").
            num_inference_steps: Number of diffusion steps (optional).
            seed: Random seed for reproducibility (optional).
            negative_prompt: Text to avoid in generation (optional).

        Returns:
            ImageResponse with base64-encoded PNG images.

        Example::

            from pendra import Pendra

            client = Pendra()
            response = client.images.generations.create(
                model="x/z-image-turbo",
                prompt="A sunset over mountains",
                size="1024x1024",
            )
            # Access base64-encoded image data
            print(response.data[0].b64_json[:50])
        """
        _validate_image_params(prompt, n, size)
        payload: dict = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            "response_format": response_format,
        }
        if num_inference_steps is not None:
            payload["num_inference_steps"] = num_inference_steps
        if seed is not None:
            payload["seed"] = seed
        if negative_prompt is not None:
            payload["negative_prompt"] = negative_prompt
        payload.update(kwargs)

        url = f"{self._client.base_url}/api/v1/images/generations"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = self._client._http.post(url, json=payload, headers=headers, timeout=300.0)
            self._raise_for_status(resp)
            return ImageResponse.from_dict(resp.json())
        except Exception as exc:
            if isinstance(exc, (APIStatusError, APIConnectionError)):
                raise
            raise APIConnectionError(str(exc)) from exc

    def _raise_for_status(self, response) -> None:
        if response.status_code == 401:
            raise AuthenticationError()
        if response.status_code == 429:
            raise RateLimitError()
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIStatusError(detail, status_code=response.status_code)
