from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Literal, Optional, Union, overload

from .._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from .._streaming import Stream
from ..types.chat import ChatCompletion, ChatCompletionChunk

if TYPE_CHECKING:
    from .._client import AsyncPendra


class AsyncCompletions:
    def __init__(self, client: "AsyncPendra"):
        self._client = client

    async def create(
        self,
        *,
        model: str,
        messages: list[dict],
        stream: bool = False,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, list[str]]] = None,
        **kwargs,
    ) -> Union[ChatCompletion, AsyncIterator[ChatCompletionChunk]]:
        payload: dict = {"model": model, "messages": messages, "stream": stream}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if top_p is not None:
            payload["top_p"] = top_p
        if stop is not None:
            payload["stop"] = stop
        payload.update(kwargs)

        url = f"{self._client.base_url}/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        if stream:
            return self._stream(url, payload, headers)
        else:
            resp = await self._client._http.post(url, json=payload, headers=headers)
            self._raise_for_status(resp)
            return ChatCompletion.from_dict(resp.json())

    async def _stream(
        self, url: str, payload: dict, headers: dict
    ) -> AsyncIterator[ChatCompletionChunk]:
        async with self._client._http.stream("POST", url, json=payload, headers=headers) as resp:
            self._raise_for_status(resp)
            async for line in resp.aiter_lines():
                line = line.strip()
                if not line or not line.startswith("data: "):
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    yield ChatCompletionChunk.from_dict(json.loads(data))
                except (json.JSONDecodeError, KeyError):
                    continue

    def _raise_for_status(self, response) -> None:
        if response.status_code == 401:
            raise AuthenticationError()
        if response.status_code == 429:
            raise RateLimitError()
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIStatusError(detail, status_code=response.status_code)


class AsyncChat:
    def __init__(self, client: "AsyncPendra"):
        self.completions = AsyncCompletions(client)
