from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .._client import Pendra


@dataclass
class Model:
    id: str
    object: str
    created: int
    owned_by: str

    @classmethod
    def from_dict(cls, d: dict) -> "Model":
        return cls(
            id=d["id"],
            object=d.get("object", "model"),
            created=d.get("created", 0),
            owned_by=d.get("owned_by", "pendra"),
        )


class Models:
    def __init__(self, client: "Pendra"):
        self._client = client

    def list(self) -> list[Model]:
        """List all available models on this Pendra instance."""
        url = f"{self._client.base_url}/api/v1/models"
        headers = {"Authorization": f"Bearer {self._client.api_key}"}
        resp = self._client._http.get(url, headers=headers)
        resp.raise_for_status()
        return [Model.from_dict(m) for m in resp.json().get("data", [])]
