from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from ..types.images import ImageResponse
from .images.generations import _validate_image_params

if TYPE_CHECKING:
    from .._client import AsyncPendra


class AsyncGenerations:
    def __init__(self, client: "AsyncPendra"):
        self._client = client

    async def create(
        self,
        *,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        response_format: str = "b64_json",
        num_inference_steps: Optional[int] = None,
        seed: Optional[int] = None,
        negative_prompt: Optional[str] = None,
        **kwargs,
    ) -> ImageResponse:
        """Generate images from a text prompt (async)."""
        _validate_image_params(prompt, n, size)
        payload: dict = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            "response_format": response_format,
        }
        if num_inference_steps is not None:
            payload["num_inference_steps"] = num_inference_steps
        if seed is not None:
            payload["seed"] = seed
        if negative_prompt is not None:
            payload["negative_prompt"] = negative_prompt
        payload.update(kwargs)

        url = f"{self._client.base_url}/api/v1/images/generations"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        resp = await self._client._http.post(url, json=payload, headers=headers, timeout=300.0)
        self._raise_for_status(resp)
        return ImageResponse.from_dict(resp.json())

    def _raise_for_status(self, response) -> None:
        if response.status_code == 401:
            raise AuthenticationError()
        if response.status_code == 429:
            raise RateLimitError()
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIStatusError(detail, status_code=response.status_code)


class AsyncImages:
    def __init__(self, client: "AsyncPendra"):
        self.generations = AsyncGenerations(client)
