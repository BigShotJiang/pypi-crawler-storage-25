from __future__ import annotations

from typing import TYPE_CHECKING

from .models import Model

if TYPE_CHECKING:
    from .._client import AsyncPendra


class AsyncModels:
    def __init__(self, client: "AsyncPendra"):
        self._client = client

    async def list(self) -> list[Model]:
        """List all available models on this Pendra instance."""
        url = f"{self._client.base_url}/api/v1/models"
        headers = {"Authorization": f"Bearer {self._client.api_key}"}
        resp = await self._client._http.get(url, headers=headers)
        resp.raise_for_status()
        return [Model.from_dict(m) for m in resp.json().get("data", [])]
