from __future__ import annotations

from typing import TYPE_CHECKING, Iterator, Literal, Optional, Union, overload

from ..._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from ..._streaming import Stream
from ...types.chat import ChatCompletion

if TYPE_CHECKING:
    from ..._client import Pendra


class Completions:
    def __init__(self, client: "Pendra"):
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        messages: list[dict],
        stream: Literal[False] = ...,
        temperature: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        top_p: Optional[float] = ...,
        stop: Optional[Union[str, list[str]]] = ...,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: list[dict],
        stream: Literal[True],
        temperature: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        top_p: Optional[float] = ...,
        stop: Optional[Union[str, list[str]]] = ...,
    ) -> Stream: ...

    def create(
        self,
        *,
        model: str,
        messages: list[dict],
        stream: bool = False,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, list[str]]] = None,
        **kwargs,
    ) -> Union[ChatCompletion, Stream]:
        """
        Create a chat completion.

        Args:
            model: The model ID to use (e.g. "llama3.2").
            messages: List of {"role": ..., "content": ...} dicts.
            stream: If True, returns a streaming iterator.
            temperature: Sampling temperature 0-2.
            max_tokens: Maximum tokens to generate.
            top_p: Top-p sampling value.
            stop: Stop sequence(s).

        Returns:
            ChatCompletion for non-streaming, Stream for streaming.

        Example::

            from pendra import Pendra

            client = Pendra()

            # Non-streaming
            response = client.chat.completions.create(
                model="llama3.2",
                messages=[{"role": "user", "content": "Hello!"}],
            )
            print(response.choices[0].message.content)

            # Streaming
            with client.chat.completions.create(
                model="llama3.2",
                messages=[{"role": "user", "content": "Tell me a story"}],
                stream=True,
            ) as stream:
                for chunk in stream:
                    print(chunk.choices[0].delta.content or "", end="", flush=True)
        """
        payload: dict = {"model": model, "messages": messages, "stream": stream}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if top_p is not None:
            payload["top_p"] = top_p
        if stop is not None:
            payload["stop"] = stop
        payload.update(kwargs)

        url = f"{self._client.base_url}/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "Content-Type": "application/json",
        }

        try:
            if stream:
                ctx = self._client._http.stream(
                    "POST", url, json=payload, headers=headers
                )
                raw = ctx.__enter__()
                self._raise_for_status(raw)
                return Stream(ctx, raw)
            else:
                resp = self._client._http.post(url, json=payload, headers=headers)
                self._raise_for_status(resp)
                return ChatCompletion.from_dict(resp.json())
        except Exception as exc:
            if isinstance(exc, (APIStatusError, APIConnectionError)):
                raise
            raise APIConnectionError(str(exc)) from exc

    def _raise_for_status(self, response) -> None:
        if response.status_code == 401:
            raise AuthenticationError()
        if response.status_code == 429:
            raise RateLimitError()
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIStatusError(detail, status_code=response.status_code)
