class APIError(Exception):
    """Base exception for all Pendra API errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class APIConnectionError(APIError):
    """Raised when the API cannot be reached."""

    def __init__(self, message: str = "Failed to connect to the Pendra API"):
        super().__init__(message)


class APIStatusError(APIError):
    """Raised when the API returns a non-2xx response."""


class AuthenticationError(APIStatusError):
    """Raised on 401 Unauthorized."""

    def __init__(self):
        super().__init__("Invalid API key — check your PENDRA_API_KEY", status_code=401)


class RateLimitError(APIStatusError):
    """Raised on 429 Too Many Requests."""

    def __init__(self):
        super().__init__("Rate limit exceeded", status_code=429)
