from __future__ import annotations

import os

import httpx

from .resources.chat import Chat
from .resources.embeddings import Embeddings
from .resources.images import Images
from .resources.models import Models


class Pendra:
    """
    Synchronous Pendra client.

    Usage::

        import pendra

        client = pendra.Pendra(
            api_key="pdr_sk_...",
            base_url="http://localhost",  # or your Pendra instance
        )

        response = client.chat.completions.create(
            model="llama3.2",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        print(response.choices[0].message.content)
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://api.pendra.ai",
        timeout: float = 120.0,
    ):
        self.api_key = api_key or os.environ.get("PENDRA_API_KEY")
        if not self.api_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the "
                "PENDRA_API_KEY environment variable."
            )

        self.base_url = base_url.rstrip("/")
        self._http = httpx.Client(timeout=timeout)

        self.chat = Chat(self)
        self.images = Images(self)
        self.embeddings = Embeddings(self)
        self.models = Models(self)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self._http.close()

    def close(self):
        self._http.close()


class AsyncPendra:
    """
    Async Pendra client for use with asyncio.

    Usage::

        import asyncio
        import pendra

        async def main():
            async with pendra.AsyncPendra(api_key="pdr_sk_...") as client:
                response = await client.chat.completions.create(
                    model="llama3.2",
                    messages=[{"role": "user", "content": "Hello!"}],
                )
                print(response.choices[0].message.content)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://api.pendra.ai",
        timeout: float = 120.0,
    ):
        self.api_key = api_key or os.environ.get("PENDRA_API_KEY")
        if not self.api_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the "
                "PENDRA_API_KEY environment variable."
            )

        self.base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(timeout=timeout)

        # Async resources share the sync interface via separate implementation
        from .resources.async_chat import AsyncChat
        from .resources.async_images import AsyncImages
        from .resources.async_models import AsyncModels
        from .resources.embeddings import AsyncEmbeddings

        self.chat = AsyncChat(self)
        self.images = AsyncImages(self)
        self.embeddings = AsyncEmbeddings(self)
        self.models = AsyncModels(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self._http.aclose()

    async def close(self):
        await self._http.aclose()
