import json
from collections.abc import Iterator
from typing import TYPE_CHECKING

from .types.chat import ChatCompletionChunk

if TYPE_CHECKING:
    import httpx


class Stream:
    """Iterates over SSE chunks from a streaming chat completion."""

    def __init__(self, ctx_manager, response: "httpx.Response"):
        self._ctx = ctx_manager   # keeps the httpx stream context alive
        self._response = response
        self._iter = response.iter_lines()

    def __iter__(self) -> Iterator[ChatCompletionChunk]:
        for line in self._iter:
            line = line.strip()
            if not line or not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                break
            try:
                chunk = ChatCompletionChunk.from_dict(json.loads(data))
                yield chunk
            except (json.JSONDecodeError, KeyError):
                continue

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._response.close()
        self._ctx.__exit__(*args)
