from dataclasses import dataclass
from typing import Optional


@dataclass
class ImageData:
    b64_json: Optional[str] = None
    url: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "ImageData":
        return cls(b64_json=d.get("b64_json"), url=d.get("url"))


@dataclass
class ImageResponse:
    created: int
    data: list[ImageData]

    @classmethod
    def from_dict(cls, d: dict) -> "ImageResponse":
        return cls(
            created=d.get("created", 0),
            data=[ImageData.from_dict(img) for img in d.get("data", [])],
        )
