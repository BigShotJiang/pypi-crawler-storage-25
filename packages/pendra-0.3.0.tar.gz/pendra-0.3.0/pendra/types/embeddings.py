from dataclasses import dataclass
from typing import Union


@dataclass
class Embedding:
    object: str
    embedding: Union[list[float], str]  # list of floats or base64 string
    index: int

    @classmethod
    def from_dict(cls, d: dict) -> "Embedding":
        return cls(
            object=d.get("object", "embedding"),
            embedding=d.get("embedding", []),
            index=d.get("index", 0),
        )


@dataclass
class EmbeddingUsage:
    prompt_tokens: int
    total_tokens: int

    @classmethod
    def from_dict(cls, d: dict) -> "EmbeddingUsage":
        return cls(
            prompt_tokens=d.get("prompt_tokens", 0),
            total_tokens=d.get("total_tokens", 0),
        )


@dataclass
class CreateEmbeddingResponse:
    object: str
    data: list[Embedding]
    model: str
    usage: EmbeddingUsage

    @classmethod
    def from_dict(cls, d: dict) -> "CreateEmbeddingResponse":
        return cls(
            object=d.get("object", "list"),
            data=[Embedding.from_dict(e) for e in d.get("data", [])],
            model=d.get("model", ""),
            usage=EmbeddingUsage.from_dict(d.get("usage") or {}),
        )
