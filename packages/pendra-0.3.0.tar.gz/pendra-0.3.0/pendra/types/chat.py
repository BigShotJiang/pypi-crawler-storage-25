from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

    @classmethod
    def from_dict(cls, d: dict) -> "Usage":
        return cls(
            prompt_tokens=d.get("prompt_tokens", 0),
            completion_tokens=d.get("completion_tokens", 0),
            total_tokens=d.get("total_tokens", 0),
        )


@dataclass
class ChatCompletionMessage:
    role: str
    content: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "ChatCompletionMessage":
        return cls(role=d["role"], content=d.get("content"))


@dataclass
class Choice:
    index: int
    message: ChatCompletionMessage
    finish_reason: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "Choice":
        return cls(
            index=d["index"],
            message=ChatCompletionMessage.from_dict(d["message"]),
            finish_reason=d.get("finish_reason"),
        )


@dataclass
class ChatCompletion:
    id: str
    object: str
    created: int
    model: str
    choices: list[Choice]
    usage: Optional[Usage]

    @classmethod
    def from_dict(cls, d: dict) -> "ChatCompletion":
        return cls(
            id=d["id"],
            object=d.get("object", "chat.completion"),
            created=d.get("created", 0),
            model=d["model"],
            choices=[Choice.from_dict(c) for c in d.get("choices", [])],
            usage=Usage.from_dict(d["usage"]) if d.get("usage") else None,
        )


# ── Streaming types ──────────────────────────────────────────


@dataclass
class ChoiceDelta:
    role: Optional[str]
    content: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "ChoiceDelta":
        return cls(role=d.get("role"), content=d.get("content"))


@dataclass
class StreamChoice:
    index: int
    delta: ChoiceDelta
    finish_reason: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "StreamChoice":
        return cls(
            index=d["index"],
            delta=ChoiceDelta.from_dict(d.get("delta", {})),
            finish_reason=d.get("finish_reason"),
        )


@dataclass
class ChatCompletionChunk:
    id: str
    object: str
    created: int
    model: str
    choices: list[StreamChoice]

    @classmethod
    def from_dict(cls, d: dict) -> "ChatCompletionChunk":
        return cls(
            id=d["id"],
            object=d.get("object", "chat.completion.chunk"),
            created=d.get("created", 0),
            model=d["model"],
            choices=[StreamChoice.from_dict(c) for c in d.get("choices", [])],
        )
