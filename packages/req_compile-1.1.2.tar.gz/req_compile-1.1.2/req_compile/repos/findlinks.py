import os
from hashlib import sha256
from pathlib import Path
from typing import Any, List, Optional, Sequence, Tuple, Union

import packaging.requirements
from overrides import overrides

import req_compile.metadata
import req_compile.metadata.metadata
import req_compile.repos.repository
from req_compile import utils
from req_compile.containers import RequirementContainer
from req_compile.repos import Repository, RepositoryInitializationError
from req_compile.repos.repository import Candidate


class FindLinksRepository(Repository):
    """
    A directory on the filesystem as a source of distributions.
    """

    def __init__(
        self,
        path: Union[str, Path],
        allow_prerelease: Optional[bool] = None,
        relative_to: Optional[Union[str, Path]] = None,
    ) -> None:
        super().__init__("findlinks", allow_prerelease=allow_prerelease)
        self.path = Path(path).as_posix()
        self.relative_path = (
            Path(os.path.relpath(self.path, relative_to)).as_posix()
            if relative_to
            else None
        )
        self.links: List[Candidate] = []
        self._find_all_links()

    def __repr__(self) -> str:
        return "--find-links {}".format(self.relative_path or self.path)

    def __eq__(self, other: Any) -> bool:
        return (
            isinstance(other, FindLinksRepository)
            and super(FindLinksRepository, self).__eq__(other)
            and self.path == other.path
        )

    def __hash__(self) -> int:
        return hash("findlinks") ^ hash(self.path)

    def _find_all_links(self) -> None:
        if not os.path.exists(self.path):
            raise RepositoryInitializationError(
                FindLinksRepository, "Directory {} not found.".format(self.path)
            )
        for filename in os.listdir(self.path):
            full_path = os.path.join(self.path, filename)
            candidate = req_compile.repos.repository.filename_to_candidate(
                (
                    str(self.relative_path) if self.relative_path else self.path,
                    os.path.join(self.relative_path or self.path, filename),
                ),
                full_path,
            )
            if candidate is not None:
                self.links.append(candidate)

    @overrides
    def get_candidates(
        self, req: Optional[packaging.requirements.Requirement]
    ) -> Sequence[Candidate]:
        project_name = None
        if req is not None:
            project_name = utils.normalize_project_name(req.name)
        results = []
        for candidate in self.links:
            if (
                req is None
                or utils.normalize_project_name(candidate.name) == project_name
            ):
                results.append(candidate)

        return results

    @overrides
    def resolve_candidate(
        self, candidate: Candidate
    ) -> Tuple[RequirementContainer, bool]:
        if candidate.filename is None:
            raise ValueError("Candidate not found on disk: {}".format(candidate))

        filename = os.path.join(self.path, candidate.filename)
        hasher = sha256()
        dist_info = req_compile.metadata.extract_metadata(filename, origin=self)
        with open(filename, "rb") as handle:
            while True:
                block = handle.read(4096)
                if not block:
                    break
                hasher.update(block)
        dist_info.hash = "sha256:" + hasher.hexdigest()
        return (
            dist_info,
            True,
        )

    @overrides
    def close(self) -> None:
        pass
