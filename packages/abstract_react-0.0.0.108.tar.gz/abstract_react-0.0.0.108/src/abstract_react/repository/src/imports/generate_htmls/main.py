from src import *
PDF_ROOT = "/srv/media/thedailydialectics/pdfs"
from pathlib import Path

pdf_paths = [str(p) for p in Path(PDF_ROOT).rglob("*.pdf")]
pdf_url = None
for pdf_path in pdf_paths:
    try:
        pdf_url = get_viewer_page(pdf_path)
    except Exception as e:
        print(f"{e}")
        pass
    print(pdf_url)
