import os
import sys

# 1. Add the current directory to the DLL search path (Windows Python 3.8+)
#    This is required so pydp.pyd can find boost_python312...dll
if sys.platform == 'win32' and sys.version_info >= (3, 8):
    libs_dir = os.path.abspath(os.path.dirname(__file__))
    os.add_dll_directory(libs_dir)

# 2. Import the actual extension module
#    Since pydp.pyd is inside the 'pydp' package, it is 'pydp.pydp'
from .pydp import *