"""Tests for authentication modes."""

from __future__ import annotations

import pytest
import responses

from wisentwire.auth import (
    COGNITO_URL,
    authenticate_cognito,
    build_session_local,
    build_session_token,
)
from wisentwire.client import WisentWireClient
from wisentwire.errors import AuthenticationError


class TestCognitoAuth:
    """Cognito USER_PASSWORD_AUTH flow."""

    @responses.activate
    def test_returns_id_token(self):
        responses.post(
            COGNITO_URL,
            json={
                "AuthenticationResult": {
                    "IdToken": "id-tok-123",
                    "AccessToken": "access-tok",
                    "RefreshToken": "refresh-tok",
                },
            },
        )
        token = authenticate_cognito("u@test.com", "pass")
        assert token == "id-tok-123"

    @responses.activate
    def test_bad_credentials_raises(self):
        responses.post(COGNITO_URL, status=400, json={"message": "bad"})
        with pytest.raises(AuthenticationError):
            authenticate_cognito("u@test.com", "wrong")


class TestLocalAuth:
    """Header-based local dev auth."""

    def test_sets_forwarded_headers(self):
        session = build_session_local("dev@test.com")
        assert session.headers["X-Forwarded-User-Email"] == "dev@test.com"
        assert session.headers["X-Forwarded-User-Name"] == "dev@test.com"


class TestTokenAuth:
    """Pre-existing bearer token auth."""

    def test_sets_bearer_header(self):
        session = build_session_token("my-jwt")
        assert session.headers["Authorization"] == "Bearer my-jwt"


class TestClientInit:
    """WisentWireClient constructor picks correct auth mode."""

    def test_local_mode(self):
        c = WisentWireClient(
            base_url="http://localhost:7998",
            email="dev@test.com", local=True,
        )
        assert c.session.headers["X-Forwarded-User-Email"] == "dev@test.com"

    def test_token_mode(self):
        c = WisentWireClient(
            base_url="http://localhost:7998", token="tok-abc",
        )
        assert c.session.headers["Authorization"] == "Bearer tok-abc"

    @responses.activate
    def test_cognito_mode(self):
        responses.post(
            COGNITO_URL,
            json={
                "AuthenticationResult": {"IdToken": "cog-tok"},
            },
        )
        c = WisentWireClient(
            base_url="http://localhost:7998",
            email="u@test.com", password="pw",
        )
        assert c.session.headers["Authorization"] == "Bearer cog-tok"

    def test_no_credentials_raises(self):
        with pytest.raises(ValueError, match="Provide"):
            WisentWireClient(base_url="http://localhost:7998")

    def test_base_url_strips_trailing_slash(self):
        c = WisentWireClient(
            base_url="http://localhost:7998/",
            email="dev@test.com", local=True,
        )
        assert c.base_url == "http://localhost:7998"
