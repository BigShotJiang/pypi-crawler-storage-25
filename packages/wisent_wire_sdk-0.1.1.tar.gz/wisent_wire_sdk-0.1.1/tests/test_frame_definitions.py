"""Tests for frame definitions and commands."""

from __future__ import annotations

import json

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.frame_definitions.models import (
    CommandDefinition,
    FieldCategory,
    FieldDataType,
    FrameDefinition,
)

BASE_URL = "http://localhost:7998"

FRAME_FIELD_JSON = {
    "name": "header",
    "fieldOrder": 0,
    "category": "CONSTANT",
    "size": 2,
    "constantValue": "AA55",
}

FRAME_DEF_JSON = {
    "id": 1,
    "name": "My Frame",
    "dataType": "HEX",
    "createdAt": "2025-01-01T00:00:00Z",
    "fields": [FRAME_FIELD_JSON],
}

COMMAND_JSON = {
    "id": 1,
    "name": "Read Status",
    "createdAt": "2025-01-01T00:00:00Z",
    "fieldValues": [{"fieldName": "header", "hexValue": "AA55"}],
}


class TestListFrameDefinitions:
    def test_returns_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/frame-definitions", json=[FRAME_DEF_JSON])

        result = client.list_frame_definitions()

        assert len(result) == 1
        fd = result[0]
        assert isinstance(fd, FrameDefinition)
        assert fd.name == "My Frame"
        assert fd.data_type == FieldDataType.HEX
        assert len(fd.fields) == 1
        assert fd.fields[0].category == FieldCategory.CONSTANT

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/frame-definitions", json=[])

        assert client.list_frame_definitions() == []


class TestGetFrameDefinition:
    def test_returns_definition(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/frame-definitions/1", json=FRAME_DEF_JSON)

        result = client.get_frame_definition(frame_def_id=1)

        assert result.id == 1
        assert result.fields[0].constant_value == "AA55"

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/frame-definitions/999",
            status=404, json={"detail": "Not found"},
        )

        with pytest.raises(NotFoundError):
            client.get_frame_definition(frame_def_id=999)


class TestCreateFrameDefinition:
    def test_creates_definition(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/frame-definitions", json=FRAME_DEF_JSON)

        fields = [{"name": "header", "fieldOrder": 0, "category": "CONSTANT"}]
        result = client.create_frame_definition(name="My Frame", fields=fields)

        assert isinstance(result, FrameDefinition)
        assert result.name == "My Frame"

    def test_sends_data_type(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/frame-definitions", json=FRAME_DEF_JSON)

        client.create_frame_definition(
            name="My Frame", fields=[], data_type="ASCII",
        )

        body = json.loads(mock_api.calls[0].request.body)
        assert body["dataType"] == "ASCII"


class TestDeleteFrameDefinition:
    def test_deletes(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/frame-definitions/1", status=204)

        client.delete_frame_definition(frame_def_id=1)

        assert mock_api.calls[0].request.method == "DELETE"


class TestListCommands:
    def test_returns_commands(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/frame-definitions/1/commands",
            json=[COMMAND_JSON],
        )

        result = client.list_commands(frame_def_id=1)

        assert len(result) == 1
        cmd = result[0]
        assert isinstance(cmd, CommandDefinition)
        assert cmd.name == "Read Status"
        assert cmd.field_values[0].field_name == "header"


class TestCreateCommand:
    def test_creates_command(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/frame-definitions/1/commands",
            json=COMMAND_JSON,
        )

        result = client.create_command(frame_def_id=1, name="Read Status")

        assert isinstance(result, CommandDefinition)
        assert result.name == "Read Status"


class TestDeleteCommand:
    def test_deletes_command(self, client, mock_api):
        mock_api.delete(
            f"{BASE_URL}/api/frame-definitions/1/commands/1", status=204,
        )

        client.delete_command(frame_def_id=1, command_id=1)

        assert mock_api.calls[0].request.method == "DELETE"
