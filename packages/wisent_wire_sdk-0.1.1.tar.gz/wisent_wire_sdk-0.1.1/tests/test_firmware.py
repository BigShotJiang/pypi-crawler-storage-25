"""Tests for firmware feature — list, upload URL, confirm, delete."""

from __future__ import annotations

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.firmware.models import FirmwareBinary, FirmwareStatus, FirmwareUploadResponse

BASE_URL = "http://localhost:7998"

FIRMWARE_JSON = {
    "id": 1,
    "orgId": 10,
    "filename": "app.bin",
    "s3Key": "fw/app.bin",
    "sizeBytes": 1024,
    "target": "stm32f4",
    "status": "READY",
    "uploadedBy": 1,
    "createdAt": "2025-01-01T00:00:00Z",
    "crc32": "AABBCCDD",
}

UPLOAD_RESPONSE_JSON = {
    "id": 1,
    "uploadUrl": "https://s3.example.com/upload",
}


class TestListFirmware:
    def test_returns_firmware_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/firmware", json=[FIRMWARE_JSON])

        result = client.list_firmware()

        assert len(result) == 1
        fw = result[0]
        assert isinstance(fw, FirmwareBinary)
        assert fw.id == 1
        assert fw.org_id == 10
        assert fw.filename == "app.bin"
        assert fw.s3_key == "fw/app.bin"
        assert fw.size_bytes == 1024
        assert fw.target == "stm32f4"
        assert fw.status == FirmwareStatus.READY
        assert fw.crc32 == "AABBCCDD"

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/firmware", json=[])

        result = client.list_firmware()

        assert result == []


class TestRequestUploadUrl:
    def test_returns_upload_response(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/firmware/upload-url",
            json=UPLOAD_RESPONSE_JSON, status=201,
        )

        result = client.request_upload_url("app.bin", 1024, "stm32f4")

        assert isinstance(result, FirmwareUploadResponse)
        assert result.id == 1
        assert result.upload_url == "https://s3.example.com/upload"

    def test_sends_crc32_when_provided(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/firmware/upload-url",
            json=UPLOAD_RESPONSE_JSON, status=201,
        )

        client.request_upload_url("app.bin", 1024, "stm32f4", crc32="AABBCCDD")

        body = mock_api.calls[0].request.body
        assert b"AABBCCDD" in body


class TestConfirmFirmware:
    def test_returns_confirmed_firmware(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/firmware/1/confirm", json=FIRMWARE_JSON,
        )

        result = client.confirm_firmware(firmware_id=1)

        assert isinstance(result, FirmwareBinary)
        assert result.id == 1
        assert result.status == FirmwareStatus.READY

    def test_not_found_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/firmware/999/confirm",
            status=404, json={"detail": "Firmware not found"},
        )

        with pytest.raises(NotFoundError):
            client.confirm_firmware(firmware_id=999)


class TestDeleteFirmware:
    def test_deletes_successfully(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/firmware/1", status=204)

        client.delete_firmware(firmware_id=1)

        assert mock_api.calls[0].request.method == "DELETE"

    def test_not_found_raises(self, client, mock_api):
        mock_api.delete(
            f"{BASE_URL}/api/firmware/999",
            status=404, json={"detail": "Firmware not found"},
        )

        with pytest.raises(NotFoundError):
            client.delete_firmware(firmware_id=999)
