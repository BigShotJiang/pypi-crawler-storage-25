"""Tests for wisentwire CRUD and availability."""

from __future__ import annotations

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.wisentwires.models import WisentWire, WisentWireStatus

BASE_URL = "http://localhost:7998"

WW_JSON = {
    "id": 1,
    "orgId": 10,
    "name": "lab-1",
    "isVirtual": False,
    "status": "READY",
    "thingName": "thing-1",
}


class TestListWisentWires:
    def test_returns_typed_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires", json=[WW_JSON], status=200)

        result = client.list_wisentwires()

        assert len(result) == 1
        assert isinstance(result[0], WisentWire)
        assert result[0].name == "lab-1"
        assert result[0].status == WisentWireStatus.READY

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires", json=[], status=200)

        assert client.list_wisentwires() == []


class TestGetWisentWire:
    def test_returns_wisentwire(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1", json=WW_JSON, status=200)

        ww = client.get_wisentwire(ww_id=1)

        assert ww.id == 1
        assert ww.org_id == 10
        assert ww.is_virtual is False
        assert ww.thing_name == "thing-1"

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.get_wisentwire(ww_id=999)


class TestCreateWisentWire:
    def test_creates_wisentwire(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/wisent-wires", json=WW_JSON, status=201)

        ww = client.create_wisentwire(name="lab-1", is_virtual=False, thing_name="thing-1")

        assert ww.name == "lab-1"
        body = mock_api.calls[0].request.body
        assert b'"isVirtual": false' in body or b'"isVirtual":false' in body

    def test_creates_virtual_without_thing_name(self, client, mock_api):
        virtual = {**WW_JSON, "isVirtual": True, "thingName": None}
        mock_api.post(f"{BASE_URL}/api/wisent-wires", json=virtual, status=201)

        ww = client.create_wisentwire(name="lab-1", is_virtual=True)

        assert ww.is_virtual is True


class TestUpdateWisentWire:
    def test_renames_wisentwire(self, client, mock_api):
        updated = {**WW_JSON, "name": "lab-2"}
        mock_api.patch(f"{BASE_URL}/api/wisent-wires/1", json=updated, status=200)

        ww = client.update_wisentwire(ww_id=1, name="lab-2")

        assert ww.name == "lab-2"

    def test_update_not_found_raises(self, client, mock_api):
        mock_api.patch(
            f"{BASE_URL}/api/wisent-wires/999",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.update_wisentwire(ww_id=999, name="nope")


class TestDeleteWisentWire:
    def test_deletes_wisentwire(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/wisent-wires/1", status=204)

        client.delete_wisentwire(ww_id=1)

    def test_delete_not_found_raises(self, client, mock_api):
        mock_api.delete(
            f"{BASE_URL}/api/wisent-wires/999",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.delete_wisentwire(ww_id=999)


class TestIsWisentWireAvailable:
    def test_returns_true(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/available", json=True, status=200)

        assert client.is_wisentwire_available(ww_id=1) is True

    def test_returns_false(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/available", json=False, status=200)

        assert client.is_wisentwire_available(ww_id=1) is False

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999/available",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.is_wisentwire_available(ww_id=999)
