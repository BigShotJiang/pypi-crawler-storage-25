"""Tests for telemetry feature — power supply telemetry."""

from __future__ import annotations

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.telemetry.models import PowerSupplyTelemetryPoint

BASE_URL = "http://localhost:7998"

TELEMETRY_POINT_JSON = {
    "timestamp": 1711800000,
    "voltage": 3.3,
    "current": 0.15,
}


class TestGetPowerTelemetry:
    def test_returns_telemetry_points(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/telemetry/power-supply",
            json=[TELEMETRY_POINT_JSON],
        )

        result = client.get_power_telemetry(ww_id=1)

        assert len(result) == 1
        point = result[0]
        assert isinstance(point, PowerSupplyTelemetryPoint)
        assert point.timestamp == 1711800000
        assert point.voltage == 3.3
        assert point.current == 0.15

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/telemetry/power-supply",
            json=[],
        )

        result = client.get_power_telemetry(ww_id=1)

        assert result == []

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999/telemetry/power-supply",
            status=404, json={"detail": "Wire not found"},
        )

        with pytest.raises(NotFoundError):
            client.get_power_telemetry(ww_id=999)
