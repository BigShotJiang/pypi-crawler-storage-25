"""Tests for organization management."""

from __future__ import annotations

import json

from wisentwire.organization.models import (
    Invitation,
    MembershipRequest,
    Organization,
    OrgMember,
    RequestStatus,
)

BASE_URL = "http://localhost:7998"

ORG_JSON = {"id": 1, "name": "Acme Corp", "code": "ACME"}

MEMBER_JSON = {
    "userId": 1, "email": "dev@acme.com", "role": "ADMIN",
    "joinedAt": "2025-01-01T00:00:00Z", "name": "Dev",
}

INVITATION_JSON = {
    "id": 1, "orgId": 1, "email": "new@acme.com",
    "token": "tok-abc", "expiresAt": "2025-02-01T00:00:00Z",
    "createdAt": "2025-01-01T00:00:00Z",
}

MEMBERSHIP_REQUEST_JSON = {
    "id": 1, "orgId": 1, "userId": 2, "email": "req@acme.com",
    "status": "PENDING", "createdAt": "2025-01-01T00:00:00Z",
}


class TestGetOrganization:
    def test_returns_organization(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/my-organization", json=ORG_JSON)

        result = client.get_organization()

        assert isinstance(result, Organization)
        assert result.name == "Acme Corp"
        assert result.code == "ACME"


class TestCreateOrganization:
    def test_creates_organization(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/organizations", json=ORG_JSON)

        result = client.create_organization(name="Acme Corp")

        assert isinstance(result, Organization)
        assert result.id == 1

    def test_sends_name_in_body(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/organizations", json=ORG_JSON)

        client.create_organization(name="Acme Corp")

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"name": "Acme Corp"}


class TestListMembers:
    def test_returns_member_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/my-organization/members", json=[MEMBER_JSON])

        result = client.list_members()

        assert len(result) == 1
        m = result[0]
        assert isinstance(m, OrgMember)
        assert m.email == "dev@acme.com"
        assert m.role == "ADMIN"


class TestUpdateMemberRole:
    def test_updates_role(self, client, mock_api):
        mock_api.put(
            f"{BASE_URL}/api/my-organization/members/1/role", status=200,
            json={},
        )

        client.update_member_role(user_id=1, role="USER")

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"role": "USER"}


class TestRemoveMember:
    def test_removes_member(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/my-organization/members/1", status=204)

        client.remove_member(user_id=1)

        assert mock_api.calls[0].request.method == "DELETE"


class TestCreateInvitation:
    def test_creates_invitation(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/my-organization/invitations",
            json=INVITATION_JSON,
        )

        result = client.create_invitation(email="new@acme.com")

        assert isinstance(result, Invitation)
        assert result.token == "tok-abc"


class TestListInvitations:
    def test_returns_invitations(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/my-organization/invitations",
            json=[INVITATION_JSON],
        )

        result = client.list_invitations()

        assert len(result) == 1
        assert result[0].email == "new@acme.com"


class TestDeleteInvitation:
    def test_deletes_invitation(self, client, mock_api):
        mock_api.delete(
            f"{BASE_URL}/api/my-organization/invitations/1", status=204,
        )

        client.delete_invitation(invitation_id=1)

        assert mock_api.calls[0].request.method == "DELETE"


class TestAcceptInvitation:
    def test_accepts_invitation(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/invitations/accept", status=200, json={})

        client.accept_invitation(token="tok-abc")

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"token": "tok-abc"}


class TestRequestToJoin:
    def test_returns_membership_request(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/organizations/join",
            json=MEMBERSHIP_REQUEST_JSON,
        )

        result = client.request_to_join(code="ACME")

        assert isinstance(result, MembershipRequest)
        assert result.status == RequestStatus.PENDING


class TestListMembershipRequests:
    def test_returns_requests(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/my-organization/membership-requests",
            json=[MEMBERSHIP_REQUEST_JSON],
        )

        result = client.list_membership_requests()

        assert len(result) == 1
        assert result[0].email == "req@acme.com"


class TestApproveMembershipRequest:
    def test_approves_request(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/my-organization/membership-requests/1/approve",
            status=200, json={},
        )

        client.approve_membership_request(request_id=1)

        assert mock_api.calls[0].request.method == "POST"


class TestRejectMembershipRequest:
    def test_rejects_request(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/my-organization/membership-requests/1/reject",
            status=200, json={},
        )

        client.reject_membership_request(request_id=1)

        assert mock_api.calls[0].request.method == "POST"
