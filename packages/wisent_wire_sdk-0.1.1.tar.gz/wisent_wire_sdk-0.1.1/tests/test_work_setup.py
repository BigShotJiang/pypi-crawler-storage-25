"""Tests for work setup CRUD."""

from __future__ import annotations

import json

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.work_setup.models import WorkSetup

BASE_URL = "http://localhost:7998"

WORK_SETUP_JSON = {
    "id": 1,
    "wisentWireId": 1,
    "name": "My Setup",
    "targetMcu": "stm32f4",
    "description": "Test setup",
    "powerSupplyAddress": "192.168.1.10",
    "powerSupplyIdn": "Rigol DP832",
    "communications": "UART",
    "frameDefinitionId": 5,
}


class TestGetWorkSetup:
    def test_returns_work_setup(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/work-setup",
            json=WORK_SETUP_JSON,
        )

        result = client.get_work_setup(ww_id=1)

        assert isinstance(result, WorkSetup)
        assert result.id == 1
        assert result.name == "My Setup"
        assert result.target_mcu == "stm32f4"
        assert result.frame_definition_id == 5

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999/work-setup",
            status=404, json={"detail": "Not found"},
        )

        with pytest.raises(NotFoundError):
            client.get_work_setup(ww_id=999)


class TestCreateWorkSetup:
    def test_creates_work_setup(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/work-setup",
            json=WORK_SETUP_JSON, status=200,
        )

        result = client.create_work_setup(ww_id=1, name="My Setup", target_mcu="stm32f4")

        assert isinstance(result, WorkSetup)
        assert result.name == "My Setup"

    def test_sends_optional_fields(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/work-setup",
            json=WORK_SETUP_JSON, status=200,
        )

        client.create_work_setup(
            ww_id=1, name="My Setup", target_mcu="stm32f4",
            description="Test setup",
        )

        body = json.loads(mock_api.calls[0].request.body)
        assert body["description"] == "Test setup"


class TestUpdateWorkSetup:
    def test_updates_work_setup(self, client, mock_api):
        mock_api.put(
            f"{BASE_URL}/api/wisent-wires/1/work-setup",
            json=WORK_SETUP_JSON,
        )

        result = client.update_work_setup(ww_id=1, name="My Setup", target_mcu="stm32f4")

        assert isinstance(result, WorkSetup)
        assert result.target_mcu == "stm32f4"


class TestDeleteWorkSetup:
    def test_deletes_work_setup(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/wisent-wires/1/work-setup", status=204)

        client.delete_work_setup(ww_id=1)

        assert mock_api.calls[0].request.method == "DELETE"

    def test_not_found_raises(self, client, mock_api):
        mock_api.delete(
            f"{BASE_URL}/api/wisent-wires/999/work-setup",
            status=404, json={"detail": "Not found"},
        )

        with pytest.raises(NotFoundError):
            client.delete_work_setup(ww_id=999)
