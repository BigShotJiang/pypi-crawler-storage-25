"""Tests for error handling."""

from __future__ import annotations

import pytest
import responses

from wisentwire.errors import (
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    ServiceUnavailableError,
    WisentWireError,
    _handle_response,
)

BASE = "http://localhost:7998"


class TestHandleResponse:
    """_handle_response maps HTTP status to typed exceptions."""

    @responses.activate
    def test_2xx_does_not_raise(self):
        responses.get(f"{BASE}/ok", status=200, json={"ok": True})
        import requests
        resp = requests.get(f"{BASE}/ok")
        _handle_response(resp)

    @responses.activate
    @pytest.mark.parametrize(
        ("status", "exc_cls"),
        [
            (400, BadRequestError),
            (401, AuthenticationError),
            (403, ForbiddenError),
            (404, NotFoundError),
            (409, ConflictError),
            (503, ServiceUnavailableError),
        ],
    )
    def test_status_maps_to_exception(self, status, exc_cls):
        responses.get(
            f"{BASE}/err", status=status,
            json={"detail": "boom"},
        )
        import requests
        resp = requests.get(f"{BASE}/err")
        with pytest.raises(exc_cls, match="boom"):
            _handle_response(resp)

    @responses.activate
    def test_unknown_status_raises_base(self):
        responses.get(f"{BASE}/err", status=418, body="teapot")
        import requests
        resp = requests.get(f"{BASE}/err")
        with pytest.raises(WisentWireError):
            _handle_response(resp)

    @responses.activate
    def test_exception_has_status_code(self):
        responses.get(
            f"{BASE}/err", status=404,
            json={"detail": "not found", "status": 404},
        )
        import requests
        resp = requests.get(f"{BASE}/err")
        with pytest.raises(NotFoundError) as exc_info:
            _handle_response(resp)
        assert exc_info.value.status == 404

    @responses.activate
    def test_exception_has_detail_dict(self):
        body = {"type": "about:blank", "status": 404, "detail": "gone"}
        responses.get(f"{BASE}/err", status=404, json=body)
        import requests
        resp = requests.get(f"{BASE}/err")
        with pytest.raises(NotFoundError) as exc_info:
            _handle_response(resp)
        assert exc_info.value.detail == body

    @responses.activate
    def test_non_json_body_has_no_detail(self):
        responses.get(f"{BASE}/err", status=500, body="oops")
        import requests
        resp = requests.get(f"{BASE}/err")
        with pytest.raises(WisentWireError) as exc_info:
            _handle_response(resp)
        assert exc_info.value.detail is None
