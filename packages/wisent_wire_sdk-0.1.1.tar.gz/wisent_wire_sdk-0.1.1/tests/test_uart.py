"""Tests for UART send/receive endpoints."""

from __future__ import annotations

import json

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.uart.models import UartDirection, UartMessage

BASE_URL = "http://localhost:7998"

UART_MSG_JSON = {"timestamp": 1711800000, "direction": "TX", "bytesHex": "A1B2"}


class TestSendUart:
    def test_sends_hex_data(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/wisent-wires/1/uart/send", status=204)

        client.send_uart(ww_id=1, hex_data="A1B2")

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"bytesHex": "A1B2"}

    def test_not_found_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/999/uart/send",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.send_uart(ww_id=999, hex_data="FF")


class TestSendUartAscii:
    def test_converts_ascii_to_hex(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/wisent-wires/1/uart/send", status=204)

        client.send_uart_ascii(ww_id=1, text="Hi")

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"bytesHex": "4869"}

    def test_not_found_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/999/uart/send",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.send_uart_ascii(ww_id=999, text="Hi")


class TestGetUartMessages:
    def test_returns_typed_message_list(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/uart/messages",
            json=[UART_MSG_JSON],
            status=200,
        )

        result = client.get_uart_messages(ww_id=1)

        assert len(result) == 1
        msg = result[0]
        assert isinstance(msg, UartMessage)
        assert msg.timestamp == 1711800000
        assert msg.direction == UartDirection.TX
        assert msg.bytes_hex == "A1B2"

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/uart/messages", json=[], status=200,
        )

        assert client.get_uart_messages(ww_id=1) == []

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999/uart/messages",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.get_uart_messages(ww_id=999)
