"""Tests for convenience polling methods."""

from __future__ import annotations

import pytest

from wisentwire._client_polling import FlashFailedError

BASE_URL = "http://localhost:7998"

SHADOW_JSON = {
    "desired": {"state": "ON", "voltageSetpoint": 5.0, "currentLimit": 0.5},
    "reported": {"state": "ON", "voltageSetpoint": 5.0, "currentLimit": 0.5},
    "hasDelta": False,
    "availableLabTools": [],
}


class TestWaitShadowState:
    def test_returns_when_state_matches(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/shadow", json=SHADOW_JSON)

        shadow = client.wait_shadow_state(1, "ON", timeout=3)

        assert shadow.reported.state == "ON"

    def test_raises_on_timeout(self, client, mock_api):
        off = {**SHADOW_JSON, "reported": {**SHADOW_JSON["reported"], "state": "OFF"}}
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/shadow", json=off)

        with pytest.raises(AssertionError):
            client.wait_shadow_state(1, "ON", timeout=2)


class TestWaitFlashComplete:
    def test_returns_on_succeeded(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/j1/status",
            json={"jobId": "j1", "status": "SUCCEEDED"},
        )

        result = client.wait_flash_complete(1, "j1", timeout=3)

        assert result.status == "SUCCEEDED"

    def test_raises_on_failed(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/j1/status",
            json={"jobId": "j1", "status": "FAILED"},
        )

        with pytest.raises(FlashFailedError):
            client.wait_flash_complete(1, "j1", timeout=3)

    def test_retries_on_initial_not_found(self, client, mock_api):
        url = f"{BASE_URL}/api/wisent-wires/1/flash/j1/status"
        mock_api.get(
            url, status=404,
            json={"title": "Flashing error", "detail": "Flash job j1 not found"},
        )
        mock_api.get(
            url, json={"jobId": "j1", "status": "SUCCEEDED"},
        )

        result = client.wait_flash_complete(1, "j1", timeout=5)

        assert result.status == "SUCCEEDED"
        assert len(mock_api.calls) == 2

    def test_raises_on_timeout(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/j1/status",
            json={"jobId": "j1", "status": "IN_PROGRESS"},
        )

        with pytest.raises(AssertionError):
            client.wait_flash_complete(1, "j1", timeout=2)


class TestWaitForUartRx:
    def test_returns_matching_rx_message(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/uart/messages",
            json=[
                {"timestamp": 1, "direction": "TX", "bytesHex": "AABB"},
                {"timestamp": 2, "direction": "RX", "bytesHex": "AABB"},
            ],
        )

        msg = client.wait_for_uart_rx(1, match_hex="AABB", timeout=3)

        assert msg.bytes_hex == "AABB"

    def test_returns_any_rx_without_match(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/uart/messages",
            json=[{"timestamp": 1, "direction": "RX", "bytesHex": "FF00"}],
        )

        msg = client.wait_for_uart_rx(1, timeout=3)

        assert msg.bytes_hex == "FF00"

    def test_raises_on_timeout_no_rx(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/uart/messages",
            json=[{"timestamp": 1, "direction": "TX", "bytesHex": "AABB"}],
        )

        with pytest.raises(AssertionError):
            client.wait_for_uart_rx(1, match_hex="AABB", timeout=2)


class TestUploadFirmware:
    def test_full_upload_flow(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/firmware/upload-url",
            json={"id": 1, "uploadUrl": "http://localhost:9999/upload"},
            status=201,
        )
        mock_api.add(
            method="PUT", url="http://localhost:9999/upload", status=200,
        )
        mock_api.post(
            f"{BASE_URL}/api/firmware/1/confirm",
            json={
                "id": 1, "orgId": 10, "filename": "app.bin", "s3Key": "fw/app.bin",
                "sizeBytes": 4, "target": "stm32f4", "status": "READY",
                "uploadedBy": 1, "createdAt": "2025-01-01T00:00:00Z",
            },
        )

        fw = client.upload_firmware("app.bin", b"\x00" * 4, "stm32f4")

        assert fw.id == 1
        assert fw.status.value == "READY"
        assert len(mock_api.calls) == 3
