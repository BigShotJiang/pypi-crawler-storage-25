"""Tests for flash feature — flash, status, flasher logs."""

from __future__ import annotations

import pytest

from wisentwire.errors import (
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    ServiceUnavailableError,
)
from wisentwire.flash.models import FlasherLogEntry, FlashJobStatus

BASE_URL = "http://localhost:7998"

FLASH_JOB_STATUS_JSON = {"jobId": "job-123", "status": "COMPLETED"}

FLASHER_LOG_JSON = {
    "timestamp": 1711800000,
    "source": "stlink",
    "data": "Flashing...",
}


class TestFlash:
    def test_returns_job_id(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            json={"jobId": "job-123"}, status=202,
        )

        result = client.flash(ww_id=1, firmware_id=5)

        assert result == "job-123"

    def test_sends_firmware_id_in_body(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            json={"jobId": "job-123"}, status=202,
        )

        client.flash(ww_id=1, firmware_id=5)

        body = mock_api.calls[0].request.body
        assert b'"firmwareId": 5' in body or b'"firmwareId":5' in body

    def test_firmware_not_found_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            status=404,
            json={"title": "Flashing error", "detail": "Firmware binary 99 not found"},
        )

        with pytest.raises(NotFoundError):
            client.flash(ww_id=1, firmware_id=99)

    def test_firmware_not_ready_raises_conflict(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            status=409,
            json={"title": "Flashing error", "detail": "Firmware binary 5 is not in READY status"},
        )

        with pytest.raises(ConflictError):
            client.flash(ww_id=1, firmware_id=5)

    def test_forbidden_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            status=403,
            json={"title": "Access denied", "detail": "Access denied"},
        )

        with pytest.raises(ForbiddenError):
            client.flash(ww_id=1, firmware_id=5)

    def test_iot_not_configured_raises_service_unavailable(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            status=503,
            json={"title": "Flashing error", "detail": "IoT is not configured"},
        )

        with pytest.raises(ServiceUnavailableError):
            client.flash(ww_id=1, firmware_id=5)

    def test_firmware_too_large_raises_bad_request(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/wisent-wires/1/flash",
            status=400,
            json={"title": "Flashing error", "detail": "Firmware size exceeds maximum"},
        )

        with pytest.raises(BadRequestError):
            client.flash(ww_id=1, firmware_id=5)


class TestGetFlashStatus:
    def test_returns_flash_job_status(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/job-123/status",
            json=FLASH_JOB_STATUS_JSON,
        )

        result = client.get_flash_status(ww_id=1, job_id="job-123")

        assert isinstance(result, FlashJobStatus)
        assert result.job_id == "job-123"
        assert result.status == "COMPLETED"

    def test_job_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/bad-id/status",
            status=404,
            json={"title": "Flashing error", "detail": "Flash job bad-id not found"},
        )

        with pytest.raises(NotFoundError):
            client.get_flash_status(ww_id=1, job_id="bad-id")

    def test_forbidden_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/job-123/status",
            status=403,
            json={"title": "Access denied", "detail": "Access denied"},
        )

        with pytest.raises(ForbiddenError):
            client.get_flash_status(ww_id=1, job_id="job-123")

    def test_iot_not_configured_raises_service_unavailable(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/flash/job-123/status",
            status=503,
            json={"title": "Flashing error", "detail": "IoT is not configured"},
        )

        with pytest.raises(ServiceUnavailableError):
            client.get_flash_status(ww_id=1, job_id="job-123")


class TestGetFlasherLogs:
    def test_returns_log_entries(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/telemetry/flasher-logs",
            json=[FLASHER_LOG_JSON],
        )

        result = client.get_flasher_logs(ww_id=1)

        assert len(result) == 1
        entry = result[0]
        assert isinstance(entry, FlasherLogEntry)
        assert entry.timestamp == 1711800000
        assert entry.source == "stlink"
        assert entry.data == "Flashing..."

    def test_returns_empty_list(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/telemetry/flasher-logs",
            json=[],
        )

        result = client.get_flasher_logs(ww_id=1)

        assert result == []

    def test_forbidden_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/1/telemetry/flasher-logs",
            status=403,
            json={"title": "Access denied", "detail": "Access denied"},
        )

        with pytest.raises(ForbiddenError):
            client.get_flasher_logs(ww_id=1)
