"""Tests for shadow / power supply endpoints."""

from __future__ import annotations

import json

import pytest

from wisentwire.errors import NotFoundError
from wisentwire.shadow.models import PowerSupplyShadow

BASE_URL = "http://localhost:7998"

SHADOW_JSON = {
    "desired": {"state": "ON", "voltageSetpoint": 5.0, "currentLimit": 0.5},
    "reported": {"state": "ON", "voltageSetpoint": 5.0, "currentLimit": 0.5},
    "hasDelta": False,
    "availableLabTools": [{"address": "USB0::0x1234", "idn": "Keysight,E36312A"}],
}


class TestGetShadow:
    def test_returns_shadow(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/shadow", json=SHADOW_JSON, status=200)

        shadow = client.get_shadow(ww_id=1)

        assert isinstance(shadow, PowerSupplyShadow)
        assert shadow.has_delta is False
        assert shadow.desired.state == "ON"
        assert shadow.desired.voltage_setpoint == 5.0
        assert shadow.desired.current_limit == 0.5
        assert shadow.reported.state == "ON"

    def test_returns_shadow_with_lab_tools(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/shadow", json=SHADOW_JSON, status=200)

        shadow = client.get_shadow(ww_id=1)

        assert len(shadow.available_lab_tools) == 1
        assert shadow.available_lab_tools[0].address == "USB0::0x1234"
        assert shadow.available_lab_tools[0].idn == "Keysight,E36312A"

    def test_shadow_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/wisent-wires/999/shadow",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.get_shadow(ww_id=999)

    def test_returns_shadow_without_lab_tools(self, client, mock_api):
        no_tools = {**SHADOW_JSON, "availableLabTools": None}
        mock_api.get(f"{BASE_URL}/api/wisent-wires/1/shadow", json=no_tools, status=200)

        shadow = client.get_shadow(ww_id=1)

        assert shadow.available_lab_tools is None


class TestSetPowerSupply:
    def test_sets_full_power_supply(self, client, mock_api):
        mock_api.patch(
            f"{BASE_URL}/api/wisent-wires/1/shadow/power-supply", status=204,
        )

        client.set_power_supply(
            ww_id=1, state="ON", voltage=5.0, current=0.5, address="USB0::0x1234",
        )

        body = json.loads(mock_api.calls[0].request.body)
        assert body["state"] == "ON"
        assert body["voltageSetpoint"] == 5.0
        assert body["currentLimit"] == 0.5
        assert body["address"] == "USB0::0x1234"

    def test_sets_partial_power_supply(self, client, mock_api):
        mock_api.patch(
            f"{BASE_URL}/api/wisent-wires/1/shadow/power-supply", status=204,
        )

        client.set_power_supply(ww_id=1, voltage=3.3)

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"voltageSetpoint": 3.3}

    def test_not_found_raises(self, client, mock_api):
        mock_api.patch(
            f"{BASE_URL}/api/wisent-wires/999/shadow/power-supply",
            json={"detail": "Wire not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.set_power_supply(ww_id=999, state="ON")
