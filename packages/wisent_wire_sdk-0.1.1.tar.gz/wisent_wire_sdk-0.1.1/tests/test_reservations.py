"""Tests for reservations feature."""

from __future__ import annotations

import pytest

from wisentwire.errors import ConflictError, NotFoundError
from wisentwire.reservations.models import Reservation

BASE_URL = "http://localhost:7998"

RESERVATION_JSON = {
    "id": 1, "orgId": 10, "wisentWireId": 1, "wisentWireName": "lab-1",
    "userId": 1, "userName": "Dev", "description": "Testing",
    "startAt": "2025-04-01T10:00:00", "endAt": "2025-04-01T12:00:00",
    "createdAt": "2025-03-30T08:00:00",
}


class TestListReservations:
    def test_returns_reservation_list(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/reservations", json=[RESERVATION_JSON])
        result = client.list_reservations("2025-03-31")
        assert len(result) == 1
        assert isinstance(result[0], Reservation)
        assert result[0].wisent_wire_name == "lab-1"


class TestGetReservation:
    def test_returns_reservation(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/reservations/1", json=RESERVATION_JSON)
        r = client.get_reservation(1)
        assert r.id == 1

    def test_not_found_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/reservations/999", status=404,
            json={"detail": "not found"},
        )
        with pytest.raises(NotFoundError):
            client.get_reservation(999)


class TestCreateReservation:
    def test_creates_reservation(self, client, mock_api):
        mock_api.post(f"{BASE_URL}/api/reservations", json=RESERVATION_JSON, status=201)
        r = client.create_reservation(1, "2025-04-01T10:00:00", "2025-04-01T12:00:00")
        assert r.description == "Testing"

    def test_conflict_raises(self, client, mock_api):
        mock_api.post(
            f"{BASE_URL}/api/reservations", status=409,
            json={"detail": "already booked"},
        )
        with pytest.raises(ConflictError):
            client.create_reservation(1, "2025-04-01T10:00:00", "2025-04-01T12:00:00")


class TestDeleteReservation:
    def test_deletes_reservation(self, client, mock_api):
        mock_api.delete(f"{BASE_URL}/api/reservations/1", status=204)
        client.delete_reservation(1)
