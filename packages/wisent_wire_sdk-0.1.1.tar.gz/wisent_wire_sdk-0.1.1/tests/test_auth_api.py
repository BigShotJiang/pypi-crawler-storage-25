"""Tests for auth_api feature — me() and check_auth()."""

from __future__ import annotations

import pytest

from wisentwire.auth_api.models import MeResponse
from wisentwire.errors import AuthenticationError

BASE_URL = "http://localhost:7998"

ME_RESPONSE = {
    "userId": 1,
    "email": "dev@test.com",
    "name": "Dev User",
    "roles": ["USER"],
    "organization": {
        "orgId": 10,
        "orgName": "Test Org",
        "orgCode": "TEST",
        "role": "ADMIN",
        "joinedAt": "2025-01-15T10:30:00",
    },
}

ME_NO_ORG = {
    "userId": 2,
    "email": "solo@test.com",
    "name": None,
    "roles": ["USER"],
    "organization": None,
}


class TestMe:
    def test_returns_me_response(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/me", json=ME_RESPONSE)

        result = client.me()

        assert isinstance(result, MeResponse)
        assert result.user_id == 1
        assert result.email == "dev@test.com"
        assert result.organization.org_name == "Test Org"
        assert result.organization.org_code == "TEST"

    def test_handles_no_organization(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/me", json=ME_NO_ORG)

        result = client.me()

        assert result.organization is None
        assert result.name is None

    def test_unauthenticated_raises(self, client, mock_api):
        mock_api.get(
            f"{BASE_URL}/api/me", status=401,
            json={"detail": "Missing user identity header"},
        )
        with pytest.raises(AuthenticationError):
            client.me()


class TestCheckAuth:
    def test_returns_me_response(self, client, mock_api):
        mock_api.get(f"{BASE_URL}/api/auth/check", json=ME_RESPONSE)

        result = client.check_auth()

        assert isinstance(result, MeResponse)
        assert result.user_id == 1
