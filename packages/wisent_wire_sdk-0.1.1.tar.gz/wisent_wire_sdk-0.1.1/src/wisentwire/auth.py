"""Authentication helpers — Cognito, local header, and token modes."""

from __future__ import annotations

import logging

import requests

from wisentwire.errors import AuthenticationError

log = logging.getLogger("wisentwire")

COGNITO_REGION = "eu-central-1"
COGNITO_URL = f"https://cognito-idp.{COGNITO_REGION}.amazonaws.com/"
DEFAULT_COGNITO_CLIENT_ID = "39m3iratdeohlc3a5c1ljombbv"

_HEADER_EMAIL = "X-Forwarded-User-Email"
_HEADER_NAME = "X-Forwarded-User-Name"


def authenticate_cognito(
    email: str,
    password: str,
    cognito_client_id: str = DEFAULT_COGNITO_CLIENT_ID,
) -> str:
    """Exchange email + password for a Cognito ID token via HTTP."""
    headers = {
        "Content-Type": "application/x-amz-json-1.1",
        "X-Amz-Target": (
            "AWSCognitoIdentityProviderService.InitiateAuth"
        ),
    }
    payload = {
        "AuthFlow": "USER_PASSWORD_AUTH",
        "ClientId": cognito_client_id,
        "AuthParameters": {
            "USERNAME": email,
            "PASSWORD": password,
        },
    }
    resp = requests.post(
        COGNITO_URL, json=payload, headers=headers, timeout=15,
    )
    if not resp.ok:
        raise AuthenticationError(
            f"Cognito auth failed: {resp.text}", status=resp.status_code,
        )
    token: str = resp.json()["AuthenticationResult"]["IdToken"]
    return token


def build_session_cognito(
    email: str,
    password: str,
    cognito_client_id: str = DEFAULT_COGNITO_CLIENT_ID,
) -> requests.Session:
    """Create a session authenticated via Cognito."""
    log.info("Authenticating via Cognito as %s", email)
    token = authenticate_cognito(email, password, cognito_client_id)
    log.debug("Cognito token obtained")
    return _session_with_bearer(token)


def build_session_local(email: str) -> requests.Session:
    """Create a session with local dev header-based auth."""
    log.info("Using local auth for %s", email)
    session = requests.Session()
    session.headers[_HEADER_EMAIL] = email
    session.headers[_HEADER_NAME] = email
    return session


def build_session_token(token: str) -> requests.Session:
    """Create a session with a pre-existing bearer token."""
    log.info("Using pre-existing token")
    return _session_with_bearer(token)


def _session_with_bearer(token: str) -> requests.Session:
    session = requests.Session()
    session.headers["Authorization"] = f"Bearer {token}"
    return session
