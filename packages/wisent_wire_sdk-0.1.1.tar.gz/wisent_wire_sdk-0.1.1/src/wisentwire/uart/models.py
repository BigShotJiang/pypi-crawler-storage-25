"""Models for UART communication."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = ["UartDirection", "UartMessage"]


class UartDirection(str, Enum):
    TX = "TX"
    RX = "RX"


@dataclass
class UartMessage:
    timestamp: int
    direction: UartDirection
    bytes_hex: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> UartMessage:
        return cls(
            timestamp=data["timestamp"],
            direction=UartDirection(data["direction"]),
            bytes_hex=data["bytesHex"],
        )
