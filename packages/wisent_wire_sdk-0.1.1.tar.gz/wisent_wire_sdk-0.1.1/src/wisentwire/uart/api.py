"""UART send/receive endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.uart.models import UartMessage


def send_uart(
    session: requests.Session, base_url: str, ww_id: int, hex_data: str,
) -> None:
    """Send hex bytes via UART."""
    resp = session.post(
        f"{base_url}/api/wisent-wires/{ww_id}/uart/send",
        json={"bytesHex": hex_data},
    )
    _handle_response(resp)


def send_uart_ascii(
    session: requests.Session, base_url: str, ww_id: int, text: str,
) -> None:
    """Send ASCII text via UART (converted to hex)."""
    hex_data = text.encode().hex().upper()
    send_uart(session, base_url, ww_id, hex_data)


def get_uart_messages(
    session: requests.Session, base_url: str, ww_id: int,
) -> list[UartMessage]:
    """Get UART messages for a wisentwire."""
    resp = session.get(f"{base_url}/api/wisent-wires/{ww_id}/uart/messages")
    _handle_response(resp)
    return [UartMessage.from_dict(m) for m in resp.json()]
