"""Models for reservations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["Reservation"]


@dataclass
class Reservation:
    id: int
    org_id: int
    wisent_wire_id: int
    wisent_wire_name: str
    user_id: int
    start_at: str
    end_at: str
    created_at: str
    user_name: str | None = None
    description: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Reservation:
        return cls(
            id=data["id"],
            org_id=data["orgId"],
            wisent_wire_id=data["wisentWireId"],
            wisent_wire_name=data["wisentWireName"],
            user_id=data["userId"],
            start_at=data["startAt"],
            end_at=data["endAt"],
            created_at=data["createdAt"],
            user_name=data.get("userName"),
            description=data.get("description"),
        )
