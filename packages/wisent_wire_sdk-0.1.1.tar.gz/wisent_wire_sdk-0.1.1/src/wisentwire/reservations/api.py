"""Reservation CRUD endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.reservations.models import Reservation


def list_reservations(
    session: requests.Session, base_url: str, week_start: str,
) -> list[Reservation]:
    """List reservations for a given week."""
    resp = session.get(
        f"{base_url}/api/reservations", params={"weekStart": week_start},
    )
    _handle_response(resp)
    return [Reservation.from_dict(r) for r in resp.json()]


def get_reservation(
    session: requests.Session, base_url: str, reservation_id: int,
) -> Reservation:
    """Get a single reservation."""
    resp = session.get(f"{base_url}/api/reservations/{reservation_id}")
    _handle_response(resp)
    return Reservation.from_dict(resp.json())


def create_reservation(
    session: requests.Session,
    base_url: str,
    ww_id: int,
    start_at: str,
    end_at: str,
    description: str | None = None,
) -> Reservation:
    """Create a reservation."""
    body: dict[str, object] = {
        "wisentWireId": ww_id,
        "startAt": start_at,
        "endAt": end_at,
    }
    if description is not None:
        body["description"] = description
    resp = session.post(f"{base_url}/api/reservations", json=body)
    _handle_response(resp)
    return Reservation.from_dict(resp.json())


def delete_reservation(
    session: requests.Session, base_url: str, reservation_id: int,
) -> None:
    """Delete a reservation."""
    resp = session.delete(f"{base_url}/api/reservations/{reservation_id}")
    _handle_response(resp)
