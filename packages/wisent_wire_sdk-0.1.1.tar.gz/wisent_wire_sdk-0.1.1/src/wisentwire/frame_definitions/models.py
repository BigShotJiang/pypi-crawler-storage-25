"""Models for frame definitions and commands."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

__all__ = [
    "ChecksumAlgorithm",
    "CommandDefinition",
    "CommandFieldValue",
    "ComputationType",
    "FieldCategory",
    "FieldDataType",
    "FrameDefinition",
    "FrameField",
]


class FieldDataType(str, Enum):
    HEX = "HEX"
    ASCII = "ASCII"


class FieldCategory(str, Enum):
    CONSTANT = "CONSTANT"
    COMPUTED = "COMPUTED"
    USER_PROVIDED = "USER_PROVIDED"


class ComputationType(str, Enum):
    CHECKSUM = "CHECKSUM"
    LENGTH = "LENGTH"


class ChecksumAlgorithm(str, Enum):
    XOR = "XOR"
    CRC16_CCITT = "CRC16_CCITT"
    CRC32 = "CRC32"


@dataclass
class FrameField:
    name: str
    field_order: int
    category: FieldCategory
    size: int | None = None
    max_size: int | None = None
    constant_value: str | None = None
    computation_type: ComputationType | None = None
    range_from: str | None = None
    range_to: str | None = None
    checksum_algorithm: ChecksumAlgorithm | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FrameField:
        return cls(
            name=data["name"],
            field_order=data["fieldOrder"],
            category=FieldCategory(data["category"]),
            size=data.get("size"),
            max_size=data.get("maxSize"),
            constant_value=data.get("constantValue"),
            computation_type=_parse_enum(ComputationType, data.get("computationType")),
            range_from=data.get("rangeFrom"),
            range_to=data.get("rangeTo"),
            checksum_algorithm=_parse_enum(ChecksumAlgorithm, data.get("checksumAlgorithm")),
        )


@dataclass
class FrameDefinition:
    id: int
    name: str
    data_type: FieldDataType
    created_at: str
    fields: list[FrameField] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FrameDefinition:
        return cls(
            id=data["id"],
            name=data["name"],
            data_type=FieldDataType(data["dataType"]),
            created_at=data["createdAt"],
            fields=[FrameField.from_dict(f) for f in data.get("fields", [])],
        )


@dataclass
class CommandFieldValue:
    field_name: str
    hex_value: str | None = None
    default_hex_value: str | None = None
    label: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CommandFieldValue:
        return cls(
            field_name=data["fieldName"],
            hex_value=data.get("hexValue"),
            default_hex_value=data.get("defaultHexValue"),
            label=data.get("label"),
        )


@dataclass
class CommandDefinition:
    id: int
    name: str
    created_at: str
    field_values: list[CommandFieldValue] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CommandDefinition:
        return cls(
            id=data["id"],
            name=data["name"],
            created_at=data["createdAt"],
            field_values=[CommandFieldValue.from_dict(v) for v in data.get("fieldValues", [])],
        )


def _parse_enum(enum_cls: type, value: Any) -> Any:
    return enum_cls(value) if value else None
