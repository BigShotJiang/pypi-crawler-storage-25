"""Frame definition and command endpoints."""

from __future__ import annotations

from typing import Any

import requests

from wisentwire.errors import _handle_response
from wisentwire.frame_definitions.models import CommandDefinition, FrameDefinition


def list_frame_definitions(
    session: requests.Session, base_url: str,
) -> list[FrameDefinition]:
    """List all frame definitions."""
    resp = session.get(f"{base_url}/api/frame-definitions")
    _handle_response(resp)
    return [FrameDefinition.from_dict(d) for d in resp.json()]


def get_frame_definition(
    session: requests.Session, base_url: str, frame_def_id: int,
) -> FrameDefinition:
    """Get a single frame definition."""
    resp = session.get(f"{base_url}/api/frame-definitions/{frame_def_id}")
    _handle_response(resp)
    return FrameDefinition.from_dict(resp.json())


def create_frame_definition(
    session: requests.Session,
    base_url: str,
    name: str,
    fields: list[dict[str, Any]],
    data_type: str = "HEX",
) -> FrameDefinition:
    """Create a frame definition."""
    body = {"name": name, "dataType": data_type, "fields": fields}
    resp = session.post(f"{base_url}/api/frame-definitions", json=body)
    _handle_response(resp)
    return FrameDefinition.from_dict(resp.json())


def update_frame_definition(
    session: requests.Session,
    base_url: str,
    frame_def_id: int,
    name: str,
    fields: list[dict[str, Any]],
    data_type: str = "HEX",
) -> FrameDefinition:
    """Update a frame definition."""
    body = {"name": name, "dataType": data_type, "fields": fields}
    resp = session.put(
        f"{base_url}/api/frame-definitions/{frame_def_id}", json=body,
    )
    _handle_response(resp)
    return FrameDefinition.from_dict(resp.json())


def delete_frame_definition(
    session: requests.Session, base_url: str, frame_def_id: int,
) -> None:
    """Delete a frame definition."""
    resp = session.delete(f"{base_url}/api/frame-definitions/{frame_def_id}")
    _handle_response(resp)


def list_commands(
    session: requests.Session, base_url: str, frame_def_id: int,
) -> list[CommandDefinition]:
    """List commands for a frame definition."""
    resp = session.get(
        f"{base_url}/api/frame-definitions/{frame_def_id}/commands",
    )
    _handle_response(resp)
    return [CommandDefinition.from_dict(c) for c in resp.json()]


def create_command(
    session: requests.Session,
    base_url: str,
    frame_def_id: int,
    name: str,
    field_values: list[dict[str, Any]] | None = None,
) -> CommandDefinition:
    """Create a command for a frame definition."""
    body: dict[str, Any] = {"name": name}
    if field_values is not None:
        body["fieldValues"] = field_values
    resp = session.post(
        f"{base_url}/api/frame-definitions/{frame_def_id}/commands",
        json=body,
    )
    _handle_response(resp)
    return CommandDefinition.from_dict(resp.json())


def update_command(
    session: requests.Session,
    base_url: str,
    frame_def_id: int,
    command_id: int,
    name: str,
    field_values: list[dict[str, Any]] | None = None,
) -> CommandDefinition:
    """Update a command."""
    body: dict[str, Any] = {"name": name}
    if field_values is not None:
        body["fieldValues"] = field_values
    resp = session.put(
        f"{base_url}/api/frame-definitions/{frame_def_id}/commands/{command_id}",
        json=body,
    )
    _handle_response(resp)
    return CommandDefinition.from_dict(resp.json())


def delete_command(
    session: requests.Session, base_url: str, frame_def_id: int, command_id: int,
) -> None:
    """Delete a command."""
    resp = session.delete(
        f"{base_url}/api/frame-definitions/{frame_def_id}/commands/{command_id}",
    )
    _handle_response(resp)
