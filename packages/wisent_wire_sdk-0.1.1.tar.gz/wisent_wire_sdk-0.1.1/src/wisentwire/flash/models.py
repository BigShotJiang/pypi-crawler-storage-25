"""Models for flash jobs."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["FlashJobStatus", "FlasherLogEntry"]


@dataclass
class FlashJobStatus:
    job_id: str
    status: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FlashJobStatus:
        return cls(job_id=data["jobId"], status=data["status"])


@dataclass
class FlasherLogEntry:
    timestamp: int
    source: str
    data: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FlasherLogEntry:
        return cls(
            timestamp=data["timestamp"],
            source=data["source"],
            data=data["data"],
        )
