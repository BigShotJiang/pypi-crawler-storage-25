"""Flash job endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.flash.models import FlasherLogEntry, FlashJobStatus


def flash(
    session: requests.Session,
    base_url: str,
    ww_id: int,
    firmware_id: int,
    *,
    erase: bool = True,
    verify: bool = True,
    reset: bool = True,
    start_address: str = "0x08000000",
    flasher: str = "stlink",
    timeout: int = 60,
) -> str:
    """Start a flash job. Returns the job ID."""
    body = {
        "firmwareId": firmware_id,
        "eraseBeforeFlash": erase,
        "verifyAfterFlash": verify,
        "resetBeforeFlash": reset,
        "startAddress": start_address,
        "flasher": flasher,
        "timeout": timeout,
    }
    resp = session.post(
        f"{base_url}/api/wisent-wires/{ww_id}/flash", json=body,
    )
    _handle_response(resp)
    job_id: str = resp.json()["jobId"]
    return job_id


def get_flash_status(
    session: requests.Session, base_url: str, ww_id: int, job_id: str,
) -> FlashJobStatus:
    """Get the status of a flash job."""
    resp = session.get(
        f"{base_url}/api/wisent-wires/{ww_id}/flash/{job_id}/status",
    )
    _handle_response(resp)
    return FlashJobStatus.from_dict(resp.json())


def get_flasher_logs(
    session: requests.Session, base_url: str, ww_id: int,
) -> list[FlasherLogEntry]:
    """Get flasher log entries for a wisentwire."""
    resp = session.get(
        f"{base_url}/api/wisent-wires/{ww_id}/telemetry/flasher-logs",
    )
    _handle_response(resp)
    return [FlasherLogEntry.from_dict(e) for e in resp.json()]
