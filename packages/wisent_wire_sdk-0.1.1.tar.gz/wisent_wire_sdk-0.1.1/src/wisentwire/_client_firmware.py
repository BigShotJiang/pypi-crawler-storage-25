"""Firmware, flash, and telemetry client methods."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisentwire.firmware.models import FirmwareBinary, FirmwareUploadResponse
    from wisentwire.flash.models import FlasherLogEntry, FlashJobStatus
    from wisentwire.telemetry.models import PowerSupplyTelemetryPoint


class FirmwareClientMixin:
    """Firmware, flash, and telemetry methods for WisentWireClient."""

    def list_firmware(self) -> list[FirmwareBinary]:
        """List all firmware binaries."""
        from wisentwire.firmware.api import list_firmware
        return list_firmware(self.session, self._base_url)  # type: ignore[attr-defined]

    def request_upload_url(
        self, filename: str, size_bytes: int, target: str,
        crc32: str | None = None,
    ) -> FirmwareUploadResponse:
        """Request a pre-signed upload URL."""
        from wisentwire.firmware.api import request_upload_url
        return request_upload_url(
            self.session, self._base_url, filename, size_bytes, target, crc32,  # type: ignore[attr-defined]
        )

    def confirm_firmware(self, firmware_id: int) -> FirmwareBinary:
        """Confirm a firmware upload is complete."""
        from wisentwire.firmware.api import confirm_firmware
        return confirm_firmware(self.session, self._base_url, firmware_id)  # type: ignore[attr-defined]

    def delete_firmware(self, firmware_id: int) -> None:
        """Delete a firmware binary."""
        from wisentwire.firmware.api import delete_firmware
        delete_firmware(self.session, self._base_url, firmware_id)  # type: ignore[attr-defined]

    def flash(
        self, ww_id: int, firmware_id: int, **kwargs: Any,
    ) -> str:
        """Start a flash job. Returns the job ID."""
        from wisentwire.flash.api import flash
        return flash(self.session, self._base_url, ww_id, firmware_id, **kwargs)  # type: ignore[attr-defined]

    def get_flash_status(self, ww_id: int, job_id: str) -> FlashJobStatus:
        """Get the status of a flash job."""
        from wisentwire.flash.api import get_flash_status
        return get_flash_status(self.session, self._base_url, ww_id, job_id)  # type: ignore[attr-defined]

    def get_flasher_logs(self, ww_id: int) -> list[FlasherLogEntry]:
        """Get flasher log entries for a wisentwire."""
        from wisentwire.flash.api import get_flasher_logs
        return get_flasher_logs(self.session, self._base_url, ww_id)  # type: ignore[attr-defined]

    def get_power_telemetry(self, ww_id: int) -> list[PowerSupplyTelemetryPoint]:
        """Get power supply telemetry for a wisentwire."""
        from wisentwire.telemetry.api import get_power_telemetry
        return get_power_telemetry(self.session, self._base_url, ww_id)  # type: ignore[attr-defined]
