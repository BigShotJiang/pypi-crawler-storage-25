"""Models for auth API responses."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = ["MeOrganization", "MeResponse", "Role"]


class Role(str, Enum):
    USER = "USER"
    ADMIN = "ADMIN"
    SYSTEM_ADMIN = "SYSTEM_ADMIN"


@dataclass
class MeOrganization:
    org_id: int
    org_name: str
    role: str
    joined_at: str
    org_code: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MeOrganization:
        return cls(
            org_id=data["orgId"],
            org_name=data["orgName"],
            role=data["role"],
            joined_at=data["joinedAt"],
            org_code=data.get("orgCode"),
        )


@dataclass
class MeResponse:
    user_id: int
    email: str
    roles: list[str]
    name: str | None = None
    organization: MeOrganization | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MeResponse:
        org = data.get("organization")
        return cls(
            user_id=data["userId"],
            email=data["email"],
            roles=list(data["roles"]),
            name=data.get("name"),
            organization=MeOrganization.from_dict(org) if org else None,
        )
