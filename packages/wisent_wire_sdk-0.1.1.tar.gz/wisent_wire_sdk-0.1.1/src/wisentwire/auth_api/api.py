"""Auth API endpoints — /api/me, /api/auth/check."""

from __future__ import annotations

import requests

from wisentwire.auth_api.models import MeResponse
from wisentwire.errors import _handle_response


def get_me(session: requests.Session, base_url: str) -> MeResponse:
    """Get the current authenticated user."""
    resp = session.get(f"{base_url}/api/me")
    _handle_response(resp)
    return MeResponse.from_dict(resp.json())


def check_auth(session: requests.Session, base_url: str) -> MeResponse:
    """Check authentication status."""
    resp = session.get(f"{base_url}/api/auth/check")
    _handle_response(resp)
    return MeResponse.from_dict(resp.json())
