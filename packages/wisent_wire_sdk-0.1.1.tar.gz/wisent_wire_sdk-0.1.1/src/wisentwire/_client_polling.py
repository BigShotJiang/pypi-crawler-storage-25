"""Convenience polling methods for WisentWireClient."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from tenacity import retry, retry_if_exception_type, stop_after_delay, wait_fixed

from wisentwire.errors import NotFoundError

if TYPE_CHECKING:
    from wisentwire.firmware.models import FirmwareBinary
    from wisentwire.flash.models import FlashJobStatus
    from wisentwire.shadow.models import PowerSupplyShadow
    from wisentwire.uart.models import UartMessage

log = logging.getLogger("wisentwire")


class FlashFailedError(Exception):
    """Raised when a flash job reaches FAILED status."""


class PollingClientMixin:
    """Convenience polling methods for WisentWireClient."""

    def wait_shadow_state(
        self, ww_id: int, expected_state: str, *, timeout: int = 25,
    ) -> PowerSupplyShadow:
        """Poll shadow until reported.state matches expected_state."""
        @retry(
            stop=stop_after_delay(timeout), wait=wait_fixed(1),
            retry=retry_if_exception_type(AssertionError), reraise=True,
        )
        def _poll() -> PowerSupplyShadow:
            shadow = self.get_shadow(ww_id)  # type: ignore[attr-defined]
            actual = shadow.reported.state if shadow.reported else None
            log.debug("Shadow state: %s (want %s)", actual, expected_state)
            assert actual == expected_state
            return shadow  # type: ignore[no-any-return]

        return _poll()

    def wait_flash_complete(
        self, ww_id: int, job_id: str, *, timeout: int = 120,
    ) -> FlashJobStatus:
        """Poll flash status until SUCCEEDED or FAILED."""
        @retry(
            stop=stop_after_delay(timeout), wait=wait_fixed(1),
            retry=retry_if_exception_type(AssertionError), reraise=True,
        )
        def _poll() -> FlashJobStatus:
            try:
                status = self.get_flash_status(ww_id, job_id)  # type: ignore[attr-defined]
            except NotFoundError:
                log.debug("Flash job %s not yet available, retrying...", job_id)
                raise AssertionError("job not found yet")  # noqa: B904
            log.info("Flash job %s: %s", job_id, status.status)
            if status.status == "FAILED":
                raise FlashFailedError(f"Flash job {job_id} failed")
            assert status.status == "SUCCEEDED"
            return status  # type: ignore[no-any-return]

        return _poll()

    def wait_for_uart_rx(
        self, ww_id: int, *, match_hex: str | None = None, timeout: int = 15,
    ) -> UartMessage:
        """Poll UART messages until an RX message appears (optionally matching hex)."""
        @retry(
            stop=stop_after_delay(timeout), wait=wait_fixed(1),
            retry=retry_if_exception_type(AssertionError), reraise=True,
        )
        def _poll() -> UartMessage:
            messages = self.get_uart_messages(ww_id)  # type: ignore[attr-defined]
            for msg in reversed(messages):
                if msg.direction.value != "RX":
                    continue
                if match_hex and match_hex not in msg.bytes_hex:
                    continue
                log.debug("UART RX match: %s", msg.bytes_hex)
                return msg  # type: ignore[no-any-return]
            assert False, "No matching UART RX message"  # noqa: B011

        return _poll()

    def upload_firmware(
        self, filename: str, data: bytes, target: str,
        *, crc32: str | None = None,
    ) -> FirmwareBinary:
        """Upload firmware in one call: request URL -> PUT to S3 -> confirm."""
        import requests as req

        upload = self.request_upload_url(  # type: ignore[attr-defined]
            filename, len(data), target, crc32,
        )
        log.info("Uploading %s (%d bytes) to S3...", filename, len(data))
        resp = req.put(
            upload.upload_url, data=data,
            headers={"Content-Type": "application/octet-stream"},
            timeout=60,
        )
        resp.raise_for_status()
        log.info("Upload complete, confirming firmware %d", upload.id)
        fw: FirmwareBinary = self.confirm_firmware(upload.id)  # type: ignore[attr-defined]
        return fw
