"""Organization client methods."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wisentwire.organization.models import (
        Invitation,
        MembershipRequest,
        Organization,
        OrgMember,
    )


class OrgClientMixin:
    """Organization management methods for WisentWireClient."""

    def get_organization(self) -> Organization:
        """Get the current user's organization."""
        from wisentwire.organization.api import get_organization
        return get_organization(self.session, self._base_url)  # type: ignore[attr-defined]

    def create_organization(self, name: str) -> Organization:
        """Create a new organization."""
        from wisentwire.organization.api import create_organization
        return create_organization(self.session, self._base_url, name)  # type: ignore[attr-defined]

    def list_members(self) -> list[OrgMember]:
        """List organization members."""
        from wisentwire.organization.api import list_members
        return list_members(self.session, self._base_url)  # type: ignore[attr-defined]

    def update_member_role(self, user_id: int, role: str) -> None:
        """Update a member's role."""
        from wisentwire.organization.api import update_member_role
        update_member_role(self.session, self._base_url, user_id, role)  # type: ignore[attr-defined]

    def remove_member(self, user_id: int) -> None:
        """Remove a member from the organization."""
        from wisentwire.organization.api import remove_member
        remove_member(self.session, self._base_url, user_id)  # type: ignore[attr-defined]

    def create_invitation(self, email: str) -> Invitation:
        """Invite a user to the organization."""
        from wisentwire.organization.api import create_invitation
        return create_invitation(self.session, self._base_url, email)  # type: ignore[attr-defined]

    def list_invitations(self) -> list[Invitation]:
        """List pending invitations."""
        from wisentwire.organization.api import list_invitations
        return list_invitations(self.session, self._base_url)  # type: ignore[attr-defined]

    def delete_invitation(self, invitation_id: int) -> None:
        """Delete an invitation."""
        from wisentwire.organization.api import delete_invitation
        delete_invitation(self.session, self._base_url, invitation_id)  # type: ignore[attr-defined]

    def accept_invitation(self, token: str) -> None:
        """Accept an invitation by token."""
        from wisentwire.organization.api import accept_invitation
        accept_invitation(self.session, self._base_url, token)  # type: ignore[attr-defined]

    def request_to_join(self, code: str) -> MembershipRequest:
        """Request to join an organization by code."""
        from wisentwire.organization.api import request_to_join
        return request_to_join(self.session, self._base_url, code)  # type: ignore[attr-defined]

    def list_membership_requests(self) -> list[MembershipRequest]:
        """List pending membership requests."""
        from wisentwire.organization.api import list_membership_requests
        return list_membership_requests(self.session, self._base_url)  # type: ignore[attr-defined]

    def approve_membership_request(self, request_id: int) -> None:
        """Approve a membership request."""
        from wisentwire.organization.api import approve_membership_request
        approve_membership_request(self.session, self._base_url, request_id)  # type: ignore[attr-defined]

    def reject_membership_request(self, request_id: int) -> None:
        """Reject a membership request."""
        from wisentwire.organization.api import reject_membership_request
        reject_membership_request(self.session, self._base_url, request_id)  # type: ignore[attr-defined]
