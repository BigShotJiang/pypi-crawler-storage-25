"""Power supply telemetry endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.telemetry.models import PowerSupplyTelemetryPoint


def get_power_telemetry(
    session: requests.Session, base_url: str, ww_id: int,
) -> list[PowerSupplyTelemetryPoint]:
    """Get power supply telemetry for a wisentwire."""
    resp = session.get(
        f"{base_url}/api/wisent-wires/{ww_id}/telemetry/power-supply",
    )
    _handle_response(resp)
    return [PowerSupplyTelemetryPoint.from_dict(p) for p in resp.json()]
