"""Models for power supply telemetry."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["PowerSupplyTelemetryPoint"]


@dataclass
class PowerSupplyTelemetryPoint:
    timestamp: int
    voltage: float
    current: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PowerSupplyTelemetryPoint:
        return cls(
            timestamp=data["timestamp"],
            voltage=data["voltage"],
            current=data["current"],
        )
