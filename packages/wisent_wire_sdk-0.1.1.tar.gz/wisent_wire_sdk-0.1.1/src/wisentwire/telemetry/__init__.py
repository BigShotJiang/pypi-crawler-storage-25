"""Telemetry feature — power supply telemetry."""

from .models import PowerSupplyTelemetryPoint

__all__ = ["PowerSupplyTelemetryPoint"]
