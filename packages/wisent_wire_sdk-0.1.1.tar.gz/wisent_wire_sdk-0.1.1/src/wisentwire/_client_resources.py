"""Reservations, work setup, frame definitions, and organization client methods."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisentwire.frame_definitions.models import CommandDefinition, FrameDefinition
    from wisentwire.reservations.models import Reservation
    from wisentwire.work_setup.models import WorkSetup


class ReservationsClientMixin:
    """Reservations and work setup methods for WisentWireClient."""

    def list_reservations(self, week_start: str) -> list[Reservation]:
        """List reservations for a given week."""
        from wisentwire.reservations.api import list_reservations
        return list_reservations(self.session, self._base_url, week_start)  # type: ignore[attr-defined]

    def get_reservation(self, reservation_id: int) -> Reservation:
        """Get a single reservation."""
        from wisentwire.reservations.api import get_reservation
        return get_reservation(self.session, self._base_url, reservation_id)  # type: ignore[attr-defined]

    def create_reservation(
        self, ww_id: int, start_at: str, end_at: str,
        description: str | None = None,
    ) -> Reservation:
        """Create a reservation."""
        from wisentwire.reservations.api import create_reservation
        return create_reservation(
            self.session, self._base_url, ww_id, start_at, end_at, description,  # type: ignore[attr-defined]
        )

    def delete_reservation(self, reservation_id: int) -> None:
        """Delete a reservation."""
        from wisentwire.reservations.api import delete_reservation
        delete_reservation(self.session, self._base_url, reservation_id)  # type: ignore[attr-defined]

    def get_work_setup(self, ww_id: int) -> WorkSetup:
        """Get the work setup for a wisentwire."""
        from wisentwire.work_setup.api import get_work_setup
        return get_work_setup(self.session, self._base_url, ww_id)  # type: ignore[attr-defined]

    def create_work_setup(
        self, ww_id: int, name: str, target_mcu: str, **kwargs: object,
    ) -> WorkSetup:
        """Create a work setup for a wisentwire."""
        from wisentwire.work_setup.api import create_work_setup
        return create_work_setup(
            self.session, self._base_url, ww_id, name, target_mcu, **kwargs,  # type: ignore[attr-defined]
        )

    def update_work_setup(
        self, ww_id: int, name: str, target_mcu: str, **kwargs: object,
    ) -> WorkSetup:
        """Update the work setup for a wisentwire."""
        from wisentwire.work_setup.api import update_work_setup
        return update_work_setup(
            self.session, self._base_url, ww_id, name, target_mcu, **kwargs,  # type: ignore[attr-defined]
        )

    def delete_work_setup(self, ww_id: int) -> None:
        """Delete the work setup for a wisentwire."""
        from wisentwire.work_setup.api import delete_work_setup
        delete_work_setup(self.session, self._base_url, ww_id)  # type: ignore[attr-defined]


class FrameDefsClientMixin:
    """Frame definitions and commands methods for WisentWireClient."""

    def list_frame_definitions(self) -> list[FrameDefinition]:
        """List all frame definitions."""
        from wisentwire.frame_definitions.api import list_frame_definitions
        return list_frame_definitions(self.session, self._base_url)  # type: ignore[attr-defined]

    def get_frame_definition(self, frame_def_id: int) -> FrameDefinition:
        """Get a single frame definition."""
        from wisentwire.frame_definitions.api import get_frame_definition
        return get_frame_definition(self.session, self._base_url, frame_def_id)  # type: ignore[attr-defined]

    def create_frame_definition(
        self, name: str, fields: list[dict[str, Any]],
        data_type: str = "HEX",
    ) -> FrameDefinition:
        """Create a frame definition."""
        from wisentwire.frame_definitions.api import create_frame_definition
        return create_frame_definition(
            self.session, self._base_url, name, fields, data_type,  # type: ignore[attr-defined]
        )

    def update_frame_definition(
        self, frame_def_id: int, name: str,
        fields: list[dict[str, Any]], data_type: str = "HEX",
    ) -> FrameDefinition:
        """Update a frame definition."""
        from wisentwire.frame_definitions.api import update_frame_definition
        return update_frame_definition(
            self.session, self._base_url, frame_def_id, name, fields, data_type,  # type: ignore[attr-defined]
        )

    def delete_frame_definition(self, frame_def_id: int) -> None:
        """Delete a frame definition."""
        from wisentwire.frame_definitions.api import delete_frame_definition
        delete_frame_definition(self.session, self._base_url, frame_def_id)  # type: ignore[attr-defined]

    def list_commands(self, frame_def_id: int) -> list[CommandDefinition]:
        """List commands for a frame definition."""
        from wisentwire.frame_definitions.api import list_commands
        return list_commands(self.session, self._base_url, frame_def_id)  # type: ignore[attr-defined]

    def create_command(
        self, frame_def_id: int, name: str,
        field_values: list[dict[str, Any]] | None = None,
    ) -> CommandDefinition:
        """Create a command for a frame definition."""
        from wisentwire.frame_definitions.api import create_command
        return create_command(
            self.session, self._base_url, frame_def_id, name, field_values,  # type: ignore[attr-defined]
        )

    def update_command(
        self, frame_def_id: int, command_id: int, name: str,
        field_values: list[dict[str, Any]] | None = None,
    ) -> CommandDefinition:
        """Update a command."""
        from wisentwire.frame_definitions.api import update_command
        return update_command(
            self.session, self._base_url, frame_def_id, command_id, name, field_values,  # type: ignore[attr-defined]
        )

    def delete_command(self, frame_def_id: int, command_id: int) -> None:
        """Delete a command."""
        from wisentwire.frame_definitions.api import delete_command
        delete_command(self.session, self._base_url, frame_def_id, command_id)  # type: ignore[attr-defined]
