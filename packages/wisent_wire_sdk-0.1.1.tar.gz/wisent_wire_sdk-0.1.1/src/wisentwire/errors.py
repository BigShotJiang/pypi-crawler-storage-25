"""Exception hierarchy and response handling for the WisentWire SDK."""

from __future__ import annotations

import logging
from typing import Any

import requests

log = logging.getLogger("wisentwire")


class WisentWireError(Exception):
    """Base exception for all SDK errors."""

    def __init__(
        self,
        message: str,
        status: int | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.detail = detail


class AuthenticationError(WisentWireError):
    """401 — missing or invalid credentials."""


class ForbiddenError(WisentWireError):
    """403 — insufficient permissions."""


class NotFoundError(WisentWireError):
    """404 — resource not found."""


class ConflictError(WisentWireError):
    """409 — business rule conflict (e.g. reservation clash)."""


class BadRequestError(WisentWireError):
    """400 — invalid request data."""


class RateLimitError(WisentWireError):
    """429 — too many requests."""


class ServiceUnavailableError(WisentWireError):
    """503 — backend dependency unavailable."""


_STATUS_TO_ERROR: dict[int, type[WisentWireError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    429: RateLimitError,
    503: ServiceUnavailableError,
}


def _handle_response(response: requests.Response) -> None:
    """Raise a typed exception for non-2xx responses."""
    log.debug(
        "%s %s -> %s",
        response.request.method, response.request.path_url, response.status_code,
    )
    if response.ok:
        return
    body = _parse_body(response)
    message = _extract_message(body, response)
    error_cls = _STATUS_TO_ERROR.get(
        response.status_code, WisentWireError,
    )
    log.warning("%s %s: %s", response.status_code, error_cls.__name__, message)
    log.debug(
        "Request: %s %s | Headers: %s",
        response.request.method, response.request.url, dict(response.request.headers),
    )
    raise error_cls(message, status=response.status_code, detail=body)


def _extract_message(
    body: dict[str, Any] | None, response: requests.Response,
) -> str:
    """Build a human-readable error message from the response."""
    if body:
        detail = body.get("detail", "")
        if detail:
            return str(detail)
    if response.text:
        return response.text
    return f"HTTP {response.status_code}"


def _parse_body(response: requests.Response) -> dict[str, Any] | None:
    """Try to parse the response as ProblemDetail JSON."""
    try:
        body: dict[str, Any] = response.json()
        return body
    except (ValueError, KeyError):
        return None
