"""WisentWire CRUD + availability endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.wisentwires.models import WisentWire


def list_wisentwires(session: requests.Session, base_url: str) -> list[WisentWire]:
    """List all wisentwires in the user's organization."""
    resp = session.get(f"{base_url}/api/wisent-wires")
    _handle_response(resp)
    return [WisentWire.from_dict(w) for w in resp.json()]


def get_wisentwire(session: requests.Session, base_url: str, ww_id: int) -> WisentWire:
    """Get a single wisentwire by ID."""
    resp = session.get(f"{base_url}/api/wisent-wires/{ww_id}")
    _handle_response(resp)
    return WisentWire.from_dict(resp.json())


def create_wisentwire(
    session: requests.Session,
    base_url: str,
    name: str,
    is_virtual: bool,
    thing_name: str | None = None,
) -> WisentWire:
    """Create a new wisentwire."""
    body: dict[str, object] = {"name": name, "isVirtual": is_virtual}
    if thing_name is not None:
        body["thingName"] = thing_name
    resp = session.post(f"{base_url}/api/wisent-wires", json=body)
    _handle_response(resp)
    return WisentWire.from_dict(resp.json())


def update_wisentwire(
    session: requests.Session, base_url: str, ww_id: int, name: str,
) -> WisentWire:
    """Rename a wisentwire."""
    resp = session.patch(
        f"{base_url}/api/wisent-wires/{ww_id}", json={"name": name},
    )
    _handle_response(resp)
    return WisentWire.from_dict(resp.json())


def delete_wisentwire(session: requests.Session, base_url: str, ww_id: int) -> None:
    """Delete a wisentwire."""
    resp = session.delete(f"{base_url}/api/wisent-wires/{ww_id}")
    _handle_response(resp)


def is_wisentwire_available(session: requests.Session, base_url: str, ww_id: int) -> bool:
    """Check if a wisentwire is available."""
    resp = session.get(f"{base_url}/api/wisent-wires/{ww_id}/available")
    _handle_response(resp)
    result: bool = resp.json()
    return result
