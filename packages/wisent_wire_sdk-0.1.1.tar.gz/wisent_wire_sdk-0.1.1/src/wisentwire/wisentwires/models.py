"""Models for wisentwires."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = ["WisentWire", "WisentWireStatus"]


class WisentWireStatus(str, Enum):
    READY = "READY"
    RESERVED = "RESERVED"
    OFFLINE = "OFFLINE"


@dataclass
class WisentWire:
    id: int
    org_id: int
    name: str
    is_virtual: bool
    status: WisentWireStatus
    reserved_until: str | None = None
    target_mcu: str | None = None
    thing_name: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WisentWire:
        return cls(
            id=data["id"],
            org_id=data["orgId"],
            name=data["name"],
            is_virtual=data["isVirtual"],
            status=WisentWireStatus(data["status"]),
            reserved_until=data.get("reservedUntil"),
            target_mcu=data.get("targetMcu"),
            thing_name=data.get("thingName"),
        )
