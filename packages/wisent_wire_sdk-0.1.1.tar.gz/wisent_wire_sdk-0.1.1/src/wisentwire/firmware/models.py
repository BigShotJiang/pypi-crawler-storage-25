"""Models for firmware management."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = ["FirmwareBinary", "FirmwareStatus", "FirmwareUploadResponse"]


class FirmwareStatus(str, Enum):
    PENDING = "PENDING"
    READY = "READY"


@dataclass
class FirmwareBinary:
    id: int
    org_id: int
    filename: str
    s3_key: str
    size_bytes: int
    target: str
    status: FirmwareStatus
    uploaded_by: int
    created_at: str
    crc32: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FirmwareBinary:
        return cls(
            id=data["id"],
            org_id=data["orgId"],
            filename=data["filename"],
            s3_key=data["s3Key"],
            size_bytes=data["sizeBytes"],
            target=data["target"],
            status=FirmwareStatus(data["status"]),
            uploaded_by=data["uploadedBy"],
            created_at=data["createdAt"],
            crc32=data.get("crc32"),
        )


@dataclass
class FirmwareUploadResponse:
    id: int
    upload_url: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FirmwareUploadResponse:
        return cls(id=data["id"], upload_url=data["uploadUrl"])
