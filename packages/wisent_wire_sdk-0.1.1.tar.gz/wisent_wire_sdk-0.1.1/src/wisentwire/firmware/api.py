"""Firmware upload flow endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.firmware.models import FirmwareBinary, FirmwareUploadResponse


def list_firmware(
    session: requests.Session, base_url: str,
) -> list[FirmwareBinary]:
    """List all firmware binaries."""
    resp = session.get(f"{base_url}/api/firmware")
    _handle_response(resp)
    return [FirmwareBinary.from_dict(f) for f in resp.json()]


def request_upload_url(
    session: requests.Session,
    base_url: str,
    filename: str,
    size_bytes: int,
    target: str,
    crc32: str | None = None,
) -> FirmwareUploadResponse:
    """Request a pre-signed upload URL."""
    body: dict[str, object] = {
        "filename": filename,
        "sizeBytes": size_bytes,
        "target": target,
    }
    if crc32 is not None:
        body["crc32"] = crc32
    resp = session.post(f"{base_url}/api/firmware/upload-url", json=body)
    _handle_response(resp)
    return FirmwareUploadResponse.from_dict(resp.json())


def confirm_firmware(
    session: requests.Session, base_url: str, firmware_id: int,
) -> FirmwareBinary:
    """Confirm a firmware upload is complete."""
    resp = session.post(f"{base_url}/api/firmware/{firmware_id}/confirm")
    _handle_response(resp)
    return FirmwareBinary.from_dict(resp.json())


def delete_firmware(
    session: requests.Session, base_url: str, firmware_id: int,
) -> None:
    """Delete a firmware binary."""
    resp = session.delete(f"{base_url}/api/firmware/{firmware_id}")
    _handle_response(resp)
