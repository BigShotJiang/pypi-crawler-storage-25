"""Main SDK entry point."""

from __future__ import annotations

import logging
import threading

import requests

from wisentwire._client_firmware import FirmwareClientMixin
from wisentwire._client_org import OrgClientMixin
from wisentwire._client_polling import PollingClientMixin
from wisentwire._client_resources import FrameDefsClientMixin, ReservationsClientMixin
from wisentwire.auth import (
    build_session_cognito,
    build_session_local,
    build_session_token,
)
from wisentwire.auth_api.api import check_auth, get_me
from wisentwire.auth_api.models import MeResponse
from wisentwire.shadow.models import PowerSupplyShadow
from wisentwire.uart.models import UartMessage
from wisentwire.wisentwires.models import WisentWire

log = logging.getLogger("wisentwire")


class WisentWireClient(
    FirmwareClientMixin,
    ReservationsClientMixin,
    FrameDefsClientMixin,
    OrgClientMixin,
    PollingClientMixin,
):
    """Single entry point for the WisentWire SDK."""

    def __init__(
        self,
        base_url: str = "https://int.wisent-wire.com",
        *,
        email: str | None = None,
        password: str | None = None,
        token: str | None = None,
        local: bool = False,
        cognito_client_id: str | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._session = _resolve_session(
            email=email, password=password,
            token=token, local=local,
            cognito_client_id=cognito_client_id,
        )
        self._local = threading.local()
        log.info("Client ready — %s", self._base_url)

    @property
    def session(self) -> requests.Session:
        """Thread-local session (shares headers from the root session)."""
        s: requests.Session | None = getattr(self._local, "session", None)
        if s is not None:
            return s
        s = requests.Session()
        s.headers.update(self._session.headers)
        self._local.session = s
        return s

    @property
    def base_url(self) -> str:
        return self._base_url

    # --- Auth API ---

    def me(self) -> MeResponse:
        """Get the current authenticated user."""
        return get_me(self.session, self._base_url)

    def check_auth(self) -> MeResponse:
        """Check authentication status."""
        return check_auth(self.session, self._base_url)

    # --- WisentWires ---

    def list_wisentwires(self) -> list[WisentWire]:
        """List all WisentWires in the user's organization."""
        from wisentwire.wisentwires.api import list_wisentwires
        return list_wisentwires(self.session, self._base_url)

    def get_wisentwire(self, ww_id: int) -> WisentWire:
        """Get a single WisentWire by ID."""
        from wisentwire.wisentwires.api import get_wisentwire
        return get_wisentwire(self.session, self._base_url, ww_id)

    def create_wisentwire(
        self, name: str, is_virtual: bool, thing_name: str | None = None,
    ) -> WisentWire:
        """Create a new WisentWire."""
        from wisentwire.wisentwires.api import create_wisentwire
        return create_wisentwire(self.session, self._base_url, name, is_virtual, thing_name)

    def update_wisentwire(self, ww_id: int, name: str) -> WisentWire:
        """Rename a WisentWire."""
        from wisentwire.wisentwires.api import update_wisentwire
        return update_wisentwire(self.session, self._base_url, ww_id, name)

    def delete_wisentwire(self, ww_id: int) -> None:
        """Delete a WisentWire."""
        from wisentwire.wisentwires.api import delete_wisentwire
        delete_wisentwire(self.session, self._base_url, ww_id)

    def is_wisentwire_available(self, ww_id: int) -> bool:
        """Check if a WisentWire is available."""
        from wisentwire.wisentwires.api import is_wisentwire_available
        return is_wisentwire_available(self.session, self._base_url, ww_id)

    # --- Shadow ---

    def get_shadow(self, ww_id: int) -> PowerSupplyShadow:
        """Get the power supply shadow for a wisentwire."""
        from wisentwire.shadow.api import get_shadow
        return get_shadow(self.session, self._base_url, ww_id)

    def set_power_supply(
        self,
        ww_id: int,
        *,
        state: str | None = None,
        voltage: float | None = None,
        current: float | None = None,
        address: str | None = None,
    ) -> None:
        """Update the power supply desired state."""
        from wisentwire.shadow.api import set_power_supply
        set_power_supply(
            self.session, self._base_url, ww_id,
            state=state, voltage=voltage, current=current, address=address,
        )

    # --- UART ---

    def send_uart(self, ww_id: int, hex_data: str) -> None:
        """Send hex bytes via UART."""
        from wisentwire.uart.api import send_uart
        send_uart(self.session, self._base_url, ww_id, hex_data)

    def send_uart_ascii(self, ww_id: int, text: str) -> None:
        """Send ASCII text via UART."""
        from wisentwire.uart.api import send_uart_ascii
        send_uart_ascii(self.session, self._base_url, ww_id, text)

    def get_uart_messages(self, ww_id: int) -> list[UartMessage]:
        """Get UART messages for a wisentwire."""
        from wisentwire.uart.api import get_uart_messages
        return get_uart_messages(self.session, self._base_url, ww_id)


def _resolve_session(
    *,
    email: str | None,
    password: str | None,
    token: str | None,
    local: bool,
    cognito_client_id: str | None,
) -> requests.Session:
    if token:
        return build_session_token(token)
    if local and email:
        return build_session_local(email)
    if email and password:
        return build_session_cognito(
            email, password, **(
                {"cognito_client_id": cognito_client_id}
                if cognito_client_id else {}
            ),
        )
    raise ValueError(
        "Provide (email + password), (email + local=True), or (token).",
    )
