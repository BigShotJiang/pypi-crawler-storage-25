"""Models for organization management."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = [
    "Invitation",
    "MembershipRequest",
    "MembershipRole",
    "OrgMember",
    "Organization",
    "RequestStatus",
]


class MembershipRole(str, Enum):
    USER = "USER"
    ADMIN = "ADMIN"


class RequestStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class Organization:
    id: int
    name: str
    code: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Organization:
        return cls(id=data["id"], name=data["name"], code=data.get("code"))


@dataclass
class OrgMember:
    user_id: int
    email: str
    role: str
    joined_at: str
    name: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OrgMember:
        return cls(
            user_id=data["userId"],
            email=data["email"],
            role=data["role"],
            joined_at=data["joinedAt"],
            name=data.get("name"),
        )


@dataclass
class Invitation:
    id: int
    org_id: int
    email: str
    token: str
    expires_at: str
    created_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Invitation:
        return cls(
            id=data["id"],
            org_id=data["orgId"],
            email=data["email"],
            token=data["token"],
            expires_at=data["expiresAt"],
            created_at=data["createdAt"],
        )


@dataclass
class MembershipRequest:
    id: int
    org_id: int
    user_id: int
    email: str
    status: RequestStatus
    created_at: str
    name: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MembershipRequest:
        return cls(
            id=data["id"],
            org_id=data["orgId"],
            user_id=data["userId"],
            email=data["email"],
            status=RequestStatus(data["status"]),
            created_at=data["createdAt"],
            name=data.get("name"),
        )
