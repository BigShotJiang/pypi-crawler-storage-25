"""Organization management endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.organization.models import (
    Invitation,
    MembershipRequest,
    Organization,
    OrgMember,
)


def get_organization(
    session: requests.Session, base_url: str,
) -> Organization:
    """Get the current user's organization."""
    resp = session.get(f"{base_url}/api/my-organization")
    _handle_response(resp)
    return Organization.from_dict(resp.json())


def create_organization(
    session: requests.Session, base_url: str, name: str,
) -> Organization:
    """Create a new organization."""
    resp = session.post(f"{base_url}/api/organizations", json={"name": name})
    _handle_response(resp)
    return Organization.from_dict(resp.json())


def list_members(
    session: requests.Session, base_url: str,
) -> list[OrgMember]:
    """List organization members."""
    resp = session.get(f"{base_url}/api/my-organization/members")
    _handle_response(resp)
    return [OrgMember.from_dict(m) for m in resp.json()]


def update_member_role(
    session: requests.Session, base_url: str, user_id: int, role: str,
) -> None:
    """Update a member's role."""
    resp = session.put(
        f"{base_url}/api/my-organization/members/{user_id}/role",
        json={"role": role},
    )
    _handle_response(resp)


def remove_member(
    session: requests.Session, base_url: str, user_id: int,
) -> None:
    """Remove a member from the organization."""
    resp = session.delete(f"{base_url}/api/my-organization/members/{user_id}")
    _handle_response(resp)


def create_invitation(
    session: requests.Session, base_url: str, email: str,
) -> Invitation:
    """Invite a user to the organization."""
    resp = session.post(
        f"{base_url}/api/my-organization/invitations",
        json={"email": email},
    )
    _handle_response(resp)
    return Invitation.from_dict(resp.json())


def list_invitations(
    session: requests.Session, base_url: str,
) -> list[Invitation]:
    """List pending invitations."""
    resp = session.get(f"{base_url}/api/my-organization/invitations")
    _handle_response(resp)
    return [Invitation.from_dict(i) for i in resp.json()]


def delete_invitation(
    session: requests.Session, base_url: str, invitation_id: int,
) -> None:
    """Delete an invitation."""
    resp = session.delete(
        f"{base_url}/api/my-organization/invitations/{invitation_id}",
    )
    _handle_response(resp)


def accept_invitation(
    session: requests.Session, base_url: str, token: str,
) -> None:
    """Accept an invitation by token."""
    resp = session.post(
        f"{base_url}/api/invitations/accept", json={"token": token},
    )
    _handle_response(resp)


def request_to_join(
    session: requests.Session, base_url: str, code: str,
) -> MembershipRequest:
    """Request to join an organization by code."""
    resp = session.post(
        f"{base_url}/api/organizations/join", json={"code": code},
    )
    _handle_response(resp)
    return MembershipRequest.from_dict(resp.json())


def list_membership_requests(
    session: requests.Session, base_url: str,
) -> list[MembershipRequest]:
    """List pending membership requests."""
    resp = session.get(f"{base_url}/api/my-organization/membership-requests")
    _handle_response(resp)
    return [MembershipRequest.from_dict(r) for r in resp.json()]


def approve_membership_request(
    session: requests.Session, base_url: str, request_id: int,
) -> None:
    """Approve a membership request."""
    resp = session.post(
        f"{base_url}/api/my-organization/membership-requests/{request_id}/approve",
    )
    _handle_response(resp)


def reject_membership_request(
    session: requests.Session, base_url: str, request_id: int,
) -> None:
    """Reject a membership request."""
    resp = session.post(
        f"{base_url}/api/my-organization/membership-requests/{request_id}/reject",
    )
    _handle_response(resp)
