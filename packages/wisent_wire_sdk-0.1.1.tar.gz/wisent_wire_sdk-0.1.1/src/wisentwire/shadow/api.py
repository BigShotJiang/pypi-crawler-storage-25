"""Shadow / power supply endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.shadow.models import PowerSupplyShadow


def get_shadow(
    session: requests.Session, base_url: str, ww_id: int,
) -> PowerSupplyShadow:
    """Get the power supply shadow for a wisentwire."""
    resp = session.get(f"{base_url}/api/wisent-wires/{ww_id}/shadow")
    _handle_response(resp)
    return PowerSupplyShadow.from_dict(resp.json())


def set_power_supply(
    session: requests.Session,
    base_url: str,
    ww_id: int,
    *,
    state: str | None = None,
    voltage: float | None = None,
    current: float | None = None,
    address: str | None = None,
) -> None:
    """Update the power supply desired state."""
    body: dict[str, object] = {}
    if state is not None:
        body["state"] = state
    if voltage is not None:
        body["voltageSetpoint"] = voltage
    if current is not None:
        body["currentLimit"] = current
    if address is not None:
        body["address"] = address
    resp = session.patch(
        f"{base_url}/api/wisent-wires/{ww_id}/shadow/power-supply",
        json=body,
    )
    _handle_response(resp)
