"""Models for shadow / power supply."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["LabTool", "PowerSupplyConfig", "PowerSupplyShadow"]


@dataclass
class LabTool:
    address: str
    idn: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LabTool:
        return cls(address=data["address"], idn=data["idn"])


@dataclass
class PowerSupplyConfig:
    state: str
    voltage_setpoint: float
    current_limit: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PowerSupplyConfig:
        return cls(
            state=data["state"],
            voltage_setpoint=data["voltageSetpoint"],
            current_limit=data["currentLimit"],
        )


@dataclass
class PowerSupplyShadow:
    desired: PowerSupplyConfig | None
    reported: PowerSupplyConfig | None
    has_delta: bool
    available_lab_tools: list[LabTool] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PowerSupplyShadow:
        tools = data.get("availableLabTools")
        return cls(
            desired=_parse_config(data.get("desired")),
            reported=_parse_config(data.get("reported")),
            has_delta=data["hasDelta"],
            available_lab_tools=[LabTool.from_dict(t) for t in tools] if tools else None,
        )


def _parse_config(data: dict[str, Any] | None) -> PowerSupplyConfig | None:
    return PowerSupplyConfig.from_dict(data) if data else None
