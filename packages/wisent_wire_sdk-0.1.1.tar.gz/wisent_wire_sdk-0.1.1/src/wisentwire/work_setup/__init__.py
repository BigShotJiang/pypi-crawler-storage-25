"""Work setup feature — work setup CRUD."""

from .models import WorkSetup

__all__ = ["WorkSetup"]
