"""Work setup CRUD endpoints."""

from __future__ import annotations

import requests

from wisentwire.errors import _handle_response
from wisentwire.work_setup.models import WorkSetup


def get_work_setup(
    session: requests.Session, base_url: str, ww_id: int,
) -> WorkSetup:
    """Get the work setup for a wisentwire."""
    resp = session.get(f"{base_url}/api/wisent-wires/{ww_id}/work-setup")
    _handle_response(resp)
    return WorkSetup.from_dict(resp.json())


def create_work_setup(
    session: requests.Session,
    base_url: str,
    ww_id: int,
    name: str,
    target_mcu: str,
    **kwargs: object,
) -> WorkSetup:
    """Create a work setup for a wisentwire."""
    body = _build_work_setup_body(name, target_mcu, **kwargs)
    resp = session.post(
        f"{base_url}/api/wisent-wires/{ww_id}/work-setup", json=body,
    )
    _handle_response(resp)
    return WorkSetup.from_dict(resp.json())


def update_work_setup(
    session: requests.Session,
    base_url: str,
    ww_id: int,
    name: str,
    target_mcu: str,
    **kwargs: object,
) -> WorkSetup:
    """Update the work setup for a wisentwire."""
    body = _build_work_setup_body(name, target_mcu, **kwargs)
    resp = session.put(
        f"{base_url}/api/wisent-wires/{ww_id}/work-setup", json=body,
    )
    _handle_response(resp)
    return WorkSetup.from_dict(resp.json())


def delete_work_setup(
    session: requests.Session, base_url: str, ww_id: int,
) -> None:
    """Delete the work setup for a wisentwire."""
    resp = session.delete(f"{base_url}/api/wisent-wires/{ww_id}/work-setup")
    _handle_response(resp)


def _build_work_setup_body(
    name: str, target_mcu: str, **kwargs: object,
) -> dict[str, object]:
    body: dict[str, object] = {"name": name, "targetMcu": target_mcu}
    _FIELD_MAP = {
        "description": "description",
        "power_supply_address": "powerSupplyAddress",
        "power_supply_idn": "powerSupplyIdn",
        "communications": "communications",
        "frame_definition_id": "frameDefinitionId",
    }
    for py_name, api_name in _FIELD_MAP.items():
        if py_name in kwargs:
            body[api_name] = kwargs[py_name]
    return body
