"""Models for work setup."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["WorkSetup"]


@dataclass
class WorkSetup:
    id: int
    wisent_wire_id: int
    name: str
    target_mcu: str
    description: str | None = None
    power_supply_address: str | None = None
    power_supply_idn: str | None = None
    communications: str | None = None
    frame_definition_id: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkSetup:
        return cls(
            id=data["id"],
            wisent_wire_id=data["wisentWireId"],
            name=data["name"],
            target_mcu=data["targetMcu"],
            description=data.get("description"),
            power_supply_address=data.get("powerSupplyAddress"),
            power_supply_idn=data.get("powerSupplyIdn"),
            communications=data.get("communications"),
            frame_definition_id=data.get("frameDefinitionId"),
        )
