"""Codebase analysis CLI commands.

Commands for scanning, analyzing, and assessing application codebases
against hardware targets.
"""

import json
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


@click.group()
def codebase():
    """Analyze application codebases for hardware assessment.

    \b
    Examples:
      branes codebase scan /path/to/project
      branes codebase analyze /path/to/project
      branes codebase assess /path/to/project --hardware jetson_orin
    """
    pass


@codebase.command("scan")
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.pass_context
def codebase_scan(ctx, project_path: str):
    """Quick static scan of a project directory.

    Returns file inventory, languages, build system, ML model files,
    and dependencies. No LLM needed.

    \b
    Examples:
      branes codebase scan .
      branes codebase scan /path/to/my/app
    """
    json_output = ctx.obj.get("json", False)

    try:
        from embodied_ai_architect.codebase.scanner import CodebaseScanner

        scanner = CodebaseScanner()
        result = scanner.scan(Path(project_path))

        if json_output:
            click.echo(json.dumps(result.model_dump(), indent=2, default=str))
        else:
            _display_scan_result(result)

    except Exception as e:
        if json_output:
            click.echo(json.dumps({"status": "error", "error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        ctx.exit(1)


@codebase.command("analyze")
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.pass_context
def codebase_analyze(ctx, project_path: str):
    """Full LLM-powered codebase analysis.

    Scans the project, then runs multi-pass LLM analysis to extract
    compute kernels, dataflow, and pipeline structure.

    Requires ANTHROPIC_API_KEY to be set.

    \b
    Examples:
      branes codebase analyze /path/to/app
    """
    json_output = ctx.obj.get("json", False)

    try:
        from embodied_ai_architect.codebase.scanner import CodebaseScanner
        from embodied_ai_architect.codebase.analyzer import CodeAnalyzer
        from embodied_ai_architect.llm.client import LLMClient

        path = Path(project_path)

        if not json_output:
            console.print(f"[bold]Scanning {path.name}...[/bold]")

        scanner = CodebaseScanner()
        scan_result = scanner.scan(path)

        if not json_output:
            console.print(
                f"  Found {len(scan_result.source_files)} source files, "
                f"{scan_result.total_lines} lines"
            )
            console.print(f"  Build system: {scan_result.build_system}")
            console.print("[bold]Running LLM analysis (4 passes)...[/bold]")

        llm = LLMClient()
        analyzer = CodeAnalyzer(llm)
        analysis = analyzer.analyze(scan_result, path)

        # Issue #38: also infer suggested constraints from kernel characteristics
        from embodied_ai_architect.codebase.converter import infer_constraints

        suggestions = infer_constraints(analysis)

        if json_output:
            payload = analysis.model_dump()
            payload["suggested_constraints"] = suggestions.model_dump()
            click.echo(json.dumps(payload, indent=2, default=str))
        else:
            _display_analysis_result(analysis)
            _display_suggested_constraints(suggestions)

    except ImportError as e:
        if "anthropic" in str(e).lower() or "LLMClient" in str(e):
            msg = (
                "LLM client not available. Set ANTHROPIC_API_KEY and install: pip install anthropic"
            )
        else:
            msg = str(e)
        if json_output:
            click.echo(json.dumps({"status": "error", "error": msg}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {msg}")
        ctx.exit(1)
    except Exception as e:
        if json_output:
            click.echo(json.dumps({"status": "error", "error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        ctx.exit(1)


@codebase.command("assess")
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--hardware",
    type=str,
    default=None,
    help="Comma-separated hardware targets (e.g., jetson_orin,custom_kpu)",
)
@click.option(
    "--power-budget",
    type=float,
    default=None,
    help="Maximum power budget in watts",
)
@click.option(
    "--latency-target",
    type=float,
    default=None,
    help="Target end-to-end latency in milliseconds",
)
@click.option(
    "--save-session",
    is_flag=True,
    help="Persist results as a design session for /architect-* skills",
)
@click.pass_context
def codebase_assess(
    ctx,
    project_path: str,
    hardware: str | None,
    power_budget: float | None,
    latency_target: float | None,
    save_session: bool,
):
    """End-to-end hardware assessment of a codebase.

    Scans the project, runs LLM analysis, converts to workload profile,
    and runs through the hardware assessment pipeline.

    \b
    Examples:
      branes codebase assess /path/to/app
      branes codebase assess /path/to/app --hardware jetson_orin,custom_kpu
      branes codebase assess /path/to/app --power-budget 15 --latency-target 33
      branes codebase assess /path/to/app --save-session
    """
    json_output = ctx.obj.get("json", False)

    try:
        from embodied_ai_architect.agents.codebase_analyzer import CodebaseAnalyzerAgent

        target_hardware = hardware.split(",") if hardware else None

        agent = CodebaseAnalyzerAgent()
        result = agent.execute(
            {
                "project_path": project_path,
                "target_hardware": target_hardware,
            }
        )

        if not result.success:
            raise Exception(result.error)

        session_id: str | None = None
        if save_session:
            session_id = _save_codebase_session(
                project_path, result.data, power_budget, latency_target
            )
            if not json_output:
                console.print(f"\n[bold green]Session saved:[/bold green] {session_id}")
                console.print(
                    "[dim]Run [cyan]/architect-assess[/cyan] in chat to see "
                    "source-mapped operator breakdown[/dim]"
                )

        # Issue #39: when no explicit --hardware was given, run the
        # workload-based recommender so the architect sees a ranked list
        # of candidates instead of a generic assessment.
        recommendations = []
        if not target_hardware:
            from embodied_ai_architect.codebase.recommender import recommend_hardware

            workload_profile = result.data.get("workload_profile", {}) or {}
            recommendations = recommend_hardware(
                workload_profile,
                top_k=5,
                power_envelope_watts=power_budget or 0.0,
            )

        if json_output:
            payload = dict(result.data)
            if session_id:
                payload["session_id"] = session_id
            if recommendations:
                payload["recommendations"] = [r.to_dict() for r in recommendations]
            click.echo(json.dumps(payload, indent=2, default=str))
        else:
            _display_assessment_result(result.data, power_budget, latency_target)
            if recommendations:
                _display_hardware_recommendations(
                    recommendations, result.data.get("workload_profile", {})
                )

    except Exception as e:
        if json_output:
            click.echo(json.dumps({"status": "error", "error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        ctx.exit(1)


def _save_codebase_session(
    project_path: str,
    data: dict,
    power_budget: float | None,
    latency_target: float | None,
) -> str:
    """Persist a codebase assessment as a SoC design session.

    Delegates to the shared `codebase_data_to_soc_state` helper from issue
    #37 so this command and `branes codebase design` produce identical
    state shapes.
    """
    from embodied_ai_architect.codebase.converter import codebase_data_to_soc_state
    from embodied_ai_architect.graphs.session_store import SessionStore
    from embodied_ai_architect.graphs.soc_state import DesignConstraints

    constraint_kwargs = {}
    if power_budget is not None:
        constraint_kwargs["max_power_watts"] = power_budget
    if latency_target is not None:
        constraint_kwargs["max_latency_ms"] = latency_target
    constraints = DesignConstraints(**constraint_kwargs) if constraint_kwargs else None

    state = codebase_data_to_soc_state(
        analysis_data=data.get("analysis", {}) or {},
        scan_data=data.get("scan_result", {}) or {},
        project_path=project_path,
        constraints=constraints,
    )
    # Preserve the converter's pre-built workload_profile from the agent
    # path — the agent may have enriched it beyond what
    # codebase_to_soc_state computes from the bare analysis.
    if data.get("workload_profile"):
        state["workload_profile"] = data["workload_profile"]

    # Preserve the legacy `assess --save-session` semantics so existing
    # /architect-* skill consumers and tests don't see a behavior shift:
    # use_case stays "codebase_analysis" (the new inferred-by-kernel-type
    # behavior is reserved for `branes codebase design`), and the
    # scan-derived total_lines lands on codebase_metadata.
    state["use_case"] = "codebase_analysis"
    scan_result = data.get("scan_result", {}) or {}
    if "total_lines" in scan_result:
        state.setdefault("codebase_metadata", {}).setdefault("scan_summary", {})["total_lines"] = (
            scan_result["total_lines"]
        )

    store = SessionStore()
    return store.save(state)


@codebase.command("design")
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.option("--power", type=float, default=None, help="Max power in watts")
@click.option("--latency", type=float, default=None, help="Max latency in milliseconds")
@click.option("--area", type=float, default=None, help="Max die area in mm²")
@click.option("--cost", type=float, default=None, help="Max cost in USD")
@click.pass_context
def codebase_design(
    ctx,
    project_path: str,
    power: float | None,
    latency: float | None,
    area: float | None,
    cost: float | None,
):
    """Build a SoC design session from a codebase scan + analysis (issue #37).

    Runs scan → analyze → codebase_to_soc_state → save session → render plan
    review snapshot. The output is a saved session that the architect can
    inspect with `branes session show`, drill into via /architect-drill, or
    feed into the optimizer via `branes design`.

    \\b
    Examples:
      branes codebase design /path/to/drone_app
      branes codebase design . --power 5 --latency 33
      branes codebase design . --power 15 --area 100 --cost 50
    """
    from embodied_ai_architect.codebase.converter import codebase_to_soc_state
    from embodied_ai_architect.codebase.scanner import CodebaseScanner
    from embodied_ai_architect.codebase.analyzer import CodeAnalyzer
    from embodied_ai_architect.graphs.session_store import SessionStore
    from embodied_ai_architect.graphs.soc_state import DesignConstraints
    from embodied_ai_architect.graphs.review import (
        build_review_snapshot,
        render_plan_review_rich,
    )
    from embodied_ai_architect.graphs.planner import PlannerNode
    from embodied_ai_architect.graphs.specialists import create_default_dispatcher
    from embodied_ai_architect.llm.client import LLMClient

    json_output = ctx.obj.get("json", False)

    try:
        # 1. Scan
        project_root = Path(project_path).resolve()
        if not json_output:
            console.print(f"[cyan]Scanning[/cyan] {project_path} ...")
        scanner = CodebaseScanner()
        scan_result = scanner.scan(project_root)

        # 2. Analyze (uses LLM)
        if not json_output:
            console.print("[cyan]Analyzing[/cyan] (this calls the LLM) ...")
        llm = LLMClient()
        analyzer = CodeAnalyzer(llm)
        analysis = analyzer.analyze(scan_result, project_root)

        # 3. Build constraints from CLI options
        constraint_kwargs = {}
        if power is not None:
            constraint_kwargs["max_power_watts"] = power
        if latency is not None:
            constraint_kwargs["max_latency_ms"] = latency
        if area is not None:
            constraint_kwargs["max_area_mm2"] = area
        if cost is not None:
            constraint_kwargs["max_cost_usd"] = cost
        constraints = DesignConstraints(**constraint_kwargs) if constraint_kwargs else None

        # 4. Bridge: codebase → SoCDesignState
        state = codebase_to_soc_state(
            analysis,
            constraints=constraints,
            project_path=project_path,
        )

        # 5. Run the default planner so we have a task graph for the
        #    plan review snapshot.
        planner = PlannerNode(llm=llm)
        try:
            plan_updates = planner(state)
            state = {**state, **plan_updates}
        except Exception as plan_err:
            # If planner fails (e.g. LLM unavailable), persist the state
            # anyway — the workload_profile is the valuable bit.
            if not json_output:
                console.print(f"[yellow]Planner skipped:[/yellow] {plan_err}")

        # 6. Save (must complete successfully — anything below this line
        # is presentation only and must not flip success → failure for the
        # caller, otherwise users will rerun and create duplicate sessions).
        store = SessionStore()
        session_id = store.save(state)

    except Exception as e:
        if json_output:
            click.echo(json.dumps({"status": "error", "error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        ctx.exit(1)
        return

    # 7. Render plan review — wrapped in its own try so a rendering bug
    # cannot turn an already-persisted session into an exit-1 failure
    # (CodeRabbit PR #88).
    try:
        if not json_output:
            console.print(f"\n[bold green]Session saved:[/bold green] {session_id}")
            console.print(f"  Goal:        {state.get('goal', '')}")
            console.print(f"  Use case:    {state.get('use_case', '')}")
            wp = state.get("workload_profile", {})
            console.print(
                f"  Workload:    {wp.get('workload_count', 0)} kernels, "
                f"{wp.get('total_estimated_gflops', 0):.1f} GFLOPS, "
                f"{wp.get('total_estimated_memory_mb', 0):.1f} MB"
            )

            if state.get("task_graph", {}).get("nodes"):
                dispatcher = create_default_dispatcher()
                snapshot = build_review_snapshot(state, sorted(dispatcher._agents.keys()))
                console.print()
                console.print(render_plan_review_rich(snapshot))

            console.print(
                "\n[dim]Inspect with: [cyan]branes session show " f"{session_id}[/cyan][/dim]"
            )
            console.print("[dim]Or drill in: [cyan]/architect-drill[/cyan] in chat[/dim]")

        if json_output:
            click.echo(
                json.dumps(
                    {
                        "session_id": session_id,
                        "goal": state.get("goal", ""),
                        "use_case": state.get("use_case", ""),
                        "workload_profile": state.get("workload_profile", {}),
                        "kernel_count": len(analysis.kernels),
                    },
                    indent=2,
                    default=str,
                )
            )
    except Exception as render_err:
        # Session is already saved — surface the error but exit 0.
        if not json_output:
            console.print(
                f"\n[yellow]Session saved as {session_id} but rendering "
                f"failed:[/yellow] {render_err}"
            )


@codebase.command("qualify")
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--goal",
    type=str,
    default=None,
    help="Override the auto-generated goal text",
)
@click.option(
    "--domain",
    type=str,
    default=None,
    help="Force a domain (drone, ugv, robot_arm) — overrides auto-detection",
)
@click.option(
    "--auto",
    is_flag=True,
    help="Skip interactive Q&A; only use auto-detected answers",
)
@click.pass_context
def codebase_qualify(
    ctx,
    project_path: str,
    goal: str | None,
    domain: str | None,
    auto: bool,
):
    """Auto-qualify a project by scanning the codebase.

    Detects platform (drone/ugv/robot_arm), perception tasks (object detection,
    SLAM, tracking), and control output (flight controller, path planner) from
    the project's dependencies and source files. Pre-fills the qualifier with
    detected answers, then runs interactive Q&A only on the remaining gaps.

    \b
    Examples:
      branes codebase qualify /path/to/drone_app
      branes codebase qualify . --domain drone
      branes codebase qualify . --auto                # non-interactive
      branes codebase qualify . --goal "custom goal"  # override goal text
    """
    json_output = ctx.obj.get("json", False)

    try:
        from embodied_ai_architect.codebase.qualifier_bridge import (
            codebase_to_qualification,
        )
        from embodied_ai_architect.codebase.scanner import CodebaseScanner
        from embodied_ai_architect.qualification.qualifier import (
            GoalQualifier,
            render_qualification_result,
        )

        # Step 1: Scan the project
        if not json_output:
            console.print(f"[dim]Scanning {project_path}...[/dim]")
        scanner = CodebaseScanner()
        scan = scanner.scan(Path(project_path))

        # Step 2: Bridge → detection report + prefilled answers
        bridge = codebase_to_qualification(scan)

        if not json_output:
            _display_detection_report(scan, bridge)

        # Step 3: Build the goal text
        effective_goal = goal or _synthesize_goal(scan, bridge)

        # Step 4: Run the qualifier with the detected domain
        effective_domain = domain or bridge.domain
        qualifier = GoalQualifier()
        result = qualifier.assess(effective_goal, domain=effective_domain)

        # Step 5: Pre-fill the answers — only when a domain template is
        # actually loaded. If assess() returned a domain selection prompt
        # (no template), the qualifier has no questions yet so prefilling
        # would silently drop everything.
        if bridge.prefilled_answers and effective_domain and result.next_question:
            if not result.next_question.id.startswith("_"):
                result = qualifier.prefill_answers(bridge.prefilled_answers)

        # Step 6: JSON output mode — dump everything and exit
        if json_output:
            click.echo(
                json.dumps(
                    {
                        "scan": scan.model_dump(),
                        "detection": {
                            "domain": bridge.domain,
                            "domain_evidence": bridge.report.domain_evidence,
                            "perception_tasks": bridge.report.perception_tasks,
                            "perception_evidence": bridge.report.perception_evidence,
                            "control_output": bridge.report.control_output,
                            "control_evidence": bridge.report.control_evidence,
                            "ml_frameworks": bridge.report.ml_frameworks,
                            "has_ml_models": bridge.report.has_ml_models,
                            "confidence": bridge.report.confidence,
                        },
                        "prefilled_answers": bridge.prefilled_answers,
                        "qualification": {
                            "is_tangible": result.is_tangible,
                            "missing_dimensions": result.qualification.missing_dimensions,
                            "answers": result.answers,
                            "accumulated_spec": result.accumulated_spec,
                        },
                    },
                    indent=2,
                    default=str,
                )
            )
            return

        # Step 7: Auto mode — print the qualification state and exit
        if auto:
            console.print()
            console.print(render_qualification_result(result))
            return

        # Step 8: Interactive — only ask the gaps
        console.print()
        console.print(render_qualification_result(result))

        while result.next_question:
            q = result.next_question
            console.print()
            console.print(f"[bold]{q.text}[/bold]")
            if q.explanation:
                console.print(f"[dim]{q.explanation}[/dim]")
            if q.options:
                for i, opt in enumerate(q.options, 1):
                    desc = q.option_descriptions.get(opt, "")
                    console.print(f"  {i}. [cyan]{opt}[/cyan]" + (f" — {desc}" if desc else ""))

                is_multi = q.question_type.value == "multi_choice"
                if is_multi:
                    prompt = "Select (comma-separated numbers, or 's' to skip): "
                else:
                    prompt = "Select (number, or 's' to skip): "
                raw = console.input(f"[bold]{prompt}[/bold]").strip()

                if raw.lower() == "s" or not raw:
                    result = qualifier.skip(q.id)
                elif is_multi:
                    # Parse comma-separated indices
                    selected: list[str] = []
                    for tok in raw.split(","):
                        tok = tok.strip()
                        if tok.isdigit():
                            idx = int(tok) - 1
                            if 0 <= idx < len(q.options):
                                selected.append(q.options[idx])
                    if selected:
                        result = qualifier.answer(q.id, selected)
                    else:
                        result = qualifier.skip(q.id)
                elif raw.isdigit():
                    idx = int(raw) - 1
                    if 0 <= idx < len(q.options):
                        result = qualifier.answer(q.id, q.options[idx])
                    else:
                        result = qualifier.skip(q.id)
                else:
                    result = qualifier.skip(q.id)
            else:
                raw = console.input(f"[bold]{q.text} [/bold]")
                if raw.strip():
                    if q.question_type.value == "numeric":
                        try:
                            result = qualifier.answer(q.id, float(raw))
                        except ValueError:
                            result = qualifier.skip(q.id)
                    else:
                        result = qualifier.answer(q.id, raw.strip())
                else:
                    result = qualifier.skip(q.id)
            console.print()
            console.print(render_qualification_result(result))

        if result.is_tangible:
            console.print("\n[bold green]✓ Goal qualified![/bold green]")
            console.print("[dim]Next: branes design plan with these constraints[/dim]")
        else:
            console.print("\n[yellow]Goal could not be fully qualified.[/yellow]")
            console.print(
                "[dim]Missing: " + ", ".join(result.qualification.missing_dimensions) + "[/dim]"
            )

    except Exception as e:
        if json_output:
            click.echo(json.dumps({"status": "error", "error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        ctx.exit(1)


def _synthesize_goal(scan, bridge) -> str:
    """Build a natural-language goal from scan + detection."""
    parts = [f"Application '{scan.project_name}'"]
    if bridge.domain:
        parts.append(f"on a {bridge.domain} platform")
    if bridge.report.perception_tasks:
        tasks = ", ".join(bridge.report.perception_tasks)
        parts.append(f"performing {tasks}")
    if scan.languages:
        parts.append(f"({', '.join(scan.languages[:3])})")
    return " ".join(parts)


def _display_detection_report(scan, bridge) -> None:
    """Display the auto-detection report from the codebase qualifier bridge."""
    report = bridge.report

    console.print()
    console.print(
        Panel(
            f"Project: [bold]{scan.project_name}[/bold]\n"
            f"Languages: {', '.join(scan.languages) or 'none'}\n"
            f"Dependencies: {len(scan.dependencies)}\n"
            f"ML models: {len(scan.ml_models)}",
            title="Codebase Scan",
            border_style="cyan",
        )
    )

    detection_lines = []
    if report.domain:
        ev = ", ".join(report.domain_evidence[:5])
        detection_lines.append(f"  [cyan]Domain:[/cyan] [bold]{report.domain}[/bold]  ({ev})")
    else:
        detection_lines.append("  [cyan]Domain:[/cyan] [dim]not detected[/dim]")

    if report.perception_tasks:
        tasks = ", ".join(report.perception_tasks)
        ev = ", ".join(report.perception_evidence[:3])
        detection_lines.append(f"  [cyan]Perception:[/cyan] {tasks}  ({ev})")
    else:
        detection_lines.append("  [cyan]Perception:[/cyan] [dim]not detected[/dim]")

    if report.control_output:
        outs = ", ".join(report.control_output)
        ev = ", ".join(report.control_evidence[:3])
        detection_lines.append(f"  [cyan]Control:[/cyan] {outs}  ({ev})")
    else:
        detection_lines.append("  [cyan]Control:[/cyan] [dim]not detected[/dim]")

    if report.ml_frameworks:
        detection_lines.append(f"  [cyan]ML frameworks:[/cyan] {', '.join(report.ml_frameworks)}")

    confidence_color = {"high": "green", "medium": "yellow", "low": "red"}.get(
        report.confidence, "white"
    )
    detection_lines.append(
        f"  [cyan]Confidence:[/cyan] [{confidence_color}]{report.confidence}[/{confidence_color}]"
    )

    console.print(
        Panel(
            "\n".join(detection_lines),
            title="Auto-Detection",
            border_style="green" if report.has_any_signal() else "yellow",
        )
    )


# --- Display helpers ---


def _display_scan_result(result) -> None:
    """Display scan results using Rich formatting."""
    console.print(f"\n[bold green]Scan complete:[/bold green] {result.project_name}\n")

    # Summary panel
    summary = (
        f"Languages: {', '.join(result.languages) or 'none detected'}\n"
        f"Build system: {result.build_system}\n"
        f"Source files: {len(result.source_files)}\n"
        f"Total lines: {result.total_lines:,}\n"
        f"ML models: {len(result.ml_models)}"
    )
    console.print(Panel(summary, title="Project Summary", border_style="cyan"))

    # File table
    if result.source_files:
        table = Table(title="Source Files", show_header=True)
        table.add_column("File", style="cyan")
        table.add_column("Language")
        table.add_column("Lines", justify="right")
        table.add_column("Role")
        table.add_column("Entry Type", style="yellow")

        for sf in result.source_files[:20]:
            table.add_row(sf.path, sf.language, str(sf.lines), sf.role, sf.entry_type or "")

        if len(result.source_files) > 20:
            table.add_row(f"... +{len(result.source_files) - 20} more", "", "", "", "")

        console.print(table)

    # ML models
    if result.ml_models:
        console.print("\n[bold]ML Model Files:[/bold]")
        for m in result.ml_models:
            size_mb = m.get("size_bytes", 0) / (1024 * 1024)
            console.print(f"  {m['path']} ({m['format']}, {size_mb:.1f} MB)")

    # Dependencies
    if result.dependencies:
        console.print(f"\n[bold]Dependencies:[/bold] {', '.join(result.dependencies[:15])}")
        if len(result.dependencies) > 15:
            console.print(f"  ... +{len(result.dependencies) - 15} more")

    # Recommended entry point
    rec = result.recommended_entry_point
    if rec:
        confidence = rec.get("confidence", "low")
        path = rec.get("path", "")
        alternatives = rec.get("alternatives", [])

        console.print()
        if confidence == "medium" and alternatives:
            console.print(
                f"[bold]Recommended application entry point:[/bold]\n"
                f"  → {path}  (confidence: {confidence}, "
                f"{len(alternatives) + 1} candidates)\n"
                f"  Alternatives: {', '.join(alternatives)}"
            )
        else:
            console.print(
                f"[bold]Recommended application entry point:[/bold]\n"
                f"  → {path}  (confidence: {confidence})"
            )

        # Use relative path if under cwd, otherwise absolute
        try:
            project_path = str(Path(result.project_path).relative_to(Path.cwd()))
        except ValueError:
            project_path = result.project_path
        console.print(
            f"\n[bold]Next step[/bold] — run LLM-powered analysis on this entry point:\n\n"
            f"  branes codebase analyze {project_path}\n"
        )


def _display_hardware_recommendations(recommendations, workload_profile) -> None:
    """Display ranked hardware recommendations (issue #39)."""
    if not recommendations:
        return

    from embodied_ai_architect.codebase.recommender import classify_workload

    archetype = classify_workload(workload_profile or {})
    gflops = float((workload_profile or {}).get("total_estimated_gflops", 0.0) or 0.0)

    console.print()
    console.print(
        f"[bold cyan]RECOMMENDED HARDWARE[/bold cyan] "
        f"[dim](for {archetype} workload, {gflops:.1f} GFLOPS)[/dim]"
    )
    table = Table(show_header=True, border_style="cyan")
    table.add_column("Rank", style="dim", width=4)
    table.add_column("Hardware", style="cyan")
    table.add_column("Vendor", style="dim")
    table.add_column("Fit", justify="right")
    table.add_column("Strengths", style="green")
    table.add_column("Weaknesses", style="yellow")

    for i, rec in enumerate(recommendations, start=1):
        table.add_row(
            str(i),
            rec.name,
            rec.vendor,
            f"{rec.fit_score:.2f}",
            ", ".join(rec.strengths[:3]) or "—",
            ", ".join(rec.weaknesses[:2]) or "—",
        )
    console.print(table)
    console.print(
        "[dim]Pass [cyan]--hardware <id1>,<id2>[/cyan] to assess against " "specific targets[/dim]"
    )


def _display_suggested_constraints(suggestions) -> None:
    """Display inferred design constraints (issue #38)."""
    if not suggestions or not suggestions.constraints:
        return

    console.print()
    console.print(
        "[bold cyan]SUGGESTED CONSTRAINTS[/bold cyan] "
        "[dim](inferred from codebase analysis)[/dim]"
    )
    table = Table(show_header=True, border_style="cyan")
    table.add_column("Constraint", style="cyan")
    table.add_column("Value", justify="right")
    table.add_column("Confidence")
    table.add_column("Rationale", style="dim")

    confidence_color = {"high": "green", "medium": "yellow", "low": "red"}
    for c in suggestions.constraints:
        color = confidence_color.get(c.confidence, "white")
        confidence_cell = f"[{color}]{c.confidence}[/{color}]"
        value_str = str(c.value) if not isinstance(c.value, float) else f"{c.value:g}"
        table.add_row(c.name, value_str, confidence_cell, c.rationale)
    console.print(table)
    console.print(f"[dim]{suggestions.summary}[/dim]")
    console.print(
        "[dim]To use as a starting point: [cyan]branes codebase design "
        "<path>[/cyan] (issue #37)[/dim]"
    )


def _display_analysis_result(analysis) -> None:
    """Display full analysis results."""
    console.print(f"\n[bold green]Analysis complete:[/bold green] {analysis.project_name}\n")

    if analysis.summary:
        console.print(Panel(analysis.summary, title="Summary", border_style="blue"))

    # Kernels table
    if analysis.kernels:
        table = Table(title="Compute Kernels", show_header=True)
        table.add_column("Kernel", style="cyan")
        table.add_column("Type")
        table.add_column("Ops/Call", justify="right")
        table.add_column("Freq (Hz)", justify="right")
        table.add_column("Data Types")
        table.add_column("Parallelism")

        for k in analysis.kernels:
            ops_str = (
                f"{k.estimated_ops_per_invocation:.1e}"
                if k.estimated_ops_per_invocation > 0
                else "-"
            )
            freq_str = f"{k.invocation_frequency_hz:.0f}" if k.invocation_frequency_hz > 0 else "-"
            table.add_row(
                k.name,
                k.kernel_type,
                ops_str,
                freq_str,
                ", ".join(k.data_types),
                k.parallelism,
            )

        console.print(table)

    # Dataflow
    if analysis.dataflow:
        console.print("\n[bold]Dataflow:[/bold]")
        for df in analysis.dataflow:
            console.print(f"  {df.source_kernel} -> {df.sink_kernel} ({df.transfer_type})")


def _display_assessment_result(
    data: dict, power_budget: float | None, latency_target: float | None
) -> None:
    """Display assessment results."""
    scan = data.get("scan_result", {})
    wp = data.get("workload_profile", {})

    console.print(
        f"\n[bold green]Assessment complete:[/bold green] "
        f"{scan.get('project_name', 'project')}\n"
    )

    # Workload summary
    summary = (
        f"Workloads: {wp.get('workload_count', 0)}\n"
        f"Total GFLOPS: {wp.get('total_estimated_gflops', 0):.2f}\n"
        f"Total Memory: {wp.get('total_estimated_memory_mb', 0):.1f} MB\n"
        f"Dominant Op: {wp.get('dominant_op', 'unknown')}"
    )
    console.print(Panel(summary, title="Workload Profile", border_style="cyan"))

    # Workload details
    for w in wp.get("workloads", []):
        console.print(
            f"  [cyan]{w['name']}[/cyan]: {w.get('estimated_gflops', 0):.2f} GFLOPS, "
            f"{w.get('estimated_memory_mb', 0):.1f} MB, "
            f"type={w.get('kernel_type', 'unknown')}"
        )

    if power_budget:
        console.print(f"\n[bold]Constraints:[/bold] power={power_budget}W", end="")
    if latency_target:
        console.print(f", latency={latency_target}ms", end="")
    if power_budget or latency_target:
        console.print()
