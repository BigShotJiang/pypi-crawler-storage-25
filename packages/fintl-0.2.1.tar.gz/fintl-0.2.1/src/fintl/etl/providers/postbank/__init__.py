"""Postbank provider plugin."""
