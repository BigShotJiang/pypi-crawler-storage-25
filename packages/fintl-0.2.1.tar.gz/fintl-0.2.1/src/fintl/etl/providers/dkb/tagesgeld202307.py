"""DKB Tagesgeld (daily savings account) statement parser (format introduced 2023-07)."""

import datetime
import logging
import re
from pathlib import Path

import polars as pl

from fintl.common import Case, Config
from fintl.etl.common.exceptions import (
    ExtractBalanceError,
    ExtractTransactionsError,
)
from fintl.etl.common.number_conversion import german_string_numbers_to_floats
from fintl.etl.common.schemas import (
    HASH_COLUMNS,
    TRANSACTION_COLUMNS,
    BalanceInfo,
    DKBTagesgeldParserEnum,
    ProviderEnum,
    ServiceEnum,
)
from fintl.etl.common.transactions import (
    hash_transactions,
    verify_transactions,
)
from fintl.etl.io.files.balances import store_balance
from fintl.etl.io.files.copy import copy_new_files
from fintl.etl.io.files.detect import (
    detect_encoding,
    detect_new_raw_files,
    detect_relevant_target_files,
    find_line_with_pattern,
)
from fintl.etl.io.files.orchestrator import (
    concatenate_new_information_to_history,
    get_parser_source_files,
)
from fintl.etl.io.files.select import select_files_to_copy
from fintl.etl.io.files.transactions import store_transactions
from fintl.etl.io.files.utils import (
    load_lines,
)

logger = logging.getLogger(__name__)

CASE = Case(
    provider=ProviderEnum.dkb.value,
    service=ServiceEnum.tagesgeld.value,
    parser=DKBTagesgeldParserEnum.tagesgeld202307.value,
)


def check_if_parser_applies(file_path: Path) -> bool:
    """Return True if this parser handles the given file."""
    is_file_name_match = (
        re.search(
            r"^(\d{2}-\d{2}-\d{4}\_Umsatzliste\_Tagesgeld.*\.csv)",
            str(file_path.name),
        )
        is not None
    )

    encoding = detect_encoding(file_path)
    lines = load_lines(file_path, encoding)
    is_header_match = any(
        re.search(
            r'"Buchungsdatum";"Wertstellung";"Status";"Zahlungspflichtige\*r";"Zahlungsempfänger\*in";"Verwendungszweck";"Umsatztyp";"Betrag";"Gläubiger-ID";"Mandatsreferenz";"Kundenreferenz"',
            line,
        )
        for line in lines
    )

    return is_file_name_match and is_header_match


def extract_transactions(
    case: Case, file_path: Path, lines: list[str], encoding: str
) -> pl.DataFrame:
    """Extract and normalise transactions from parsed CSV lines."""
    transaction_pattern: str = '^("?Buchungsdatum";"Wertstellung")'  # start of transactions

    date_format: str = "%d.%m.%y"
    date_cols: list = ["Buchungsdatum", "Wertstellung"]

    ix_start_transactions, transactions_header = find_line_with_pattern(
        lines, pattern=transaction_pattern
    )
    logger.debug(f"{file_path=} has {ix_start_transactions=} and {transactions_header=}")

    schema = {
        "Buchungsdatum": pl.Utf8,
        "Wertstellung": pl.Utf8,
        "Status": pl.Utf8,
        "Zahlungspflichtige*r": pl.Utf8,
        "Zahlungsempfänger*in": pl.Utf8,
        "Verwendungszweck": pl.Utf8,
        "Umsatztyp": pl.Utf8,
        "Betrag": pl.Utf8,
        "Gläubiger-ID": pl.Utf8,
        "Mandatsreferenz": pl.Utf8,
        "Kundenreferenz": pl.Utf8,
    }

    transactions = pl.read_csv(
        file_path,
        skip_rows=ix_start_transactions,
        separator=";",
        truncate_ragged_lines=True,
        encoding=encoding,
        schema=schema,
    )

    transactions = transactions.with_columns(
        [pl.col(col).str.to_date(date_format) for col in date_cols],
    )

    transactions = transactions.with_columns(
        pl.col("Betrag")
        .str.replace("€", "")
        .str.strip_chars_end()
        .map_elements(german_string_numbers_to_floats, return_dtype=pl.Float64),
    )

    transactions = transactions.with_columns(
        amount=pl.col("Betrag"),
        description=pl.col("Verwendungszweck"),
        date=pl.col("Buchungsdatum"),
        source=pl.col("Zahlungspflichtige*r"),
        recipient=pl.col("Zahlungsempfänger*in"),
        provider=pl.lit(case.provider),
        service=pl.lit(case.service),
        parser=pl.lit(case.parser),
        file=pl.lit(str(file_path)),
    )
    transactions = hash_transactions(transactions, HASH_COLUMNS)

    verify_transactions(TRANSACTION_COLUMNS, transactions, file_path)

    transactions = transactions.select(TRANSACTION_COLUMNS)

    return transactions


def extract_balance(case: Case, file_path: Path, lines: list[str]) -> BalanceInfo:
    """Extract balance information from parsed CSV lines."""
    balance_info_pattern: str = '^("?Kontostand vom)'  # start of balance info
    ix_start_balance, balance_line = find_line_with_pattern(lines, pattern=balance_info_pattern)

    logger.debug(f"{file_path=} has {ix_start_balance=} and {balance_line=}")

    line = balance_line.split(";")
    date, total = line[0], line[1]

    date = date.strip('"').strip(":").split(" ")[2]

    date = [int(v) for v in date.split(".")]
    date = datetime.date(date[2], date[1], date[0])

    total = total.strip('"').split(" ")
    amount, currency = total[0], total[1].rstrip().rstrip('"')
    amount = german_string_numbers_to_floats(amount)

    return BalanceInfo(
        date=date,
        amount=amount,
        currency=currency,
        provider=case.provider,
        service=case.service,
        parser=case.parser,
        file=str(file_path),
    )


def parse_csv_file(case: Case, file_path: Path) -> tuple[pl.DataFrame, BalanceInfo]:
    """Parse a single CSV file and return transactions and balance."""
    encoding = detect_encoding(file_path)
    logger.debug(f"{file_path=} has {encoding=}")

    lines = load_lines(file_path, encoding)

    try:
        transactions = extract_transactions(case, file_path, lines, encoding)
    except Exception as e:
        msg = f"failed to parse {case=} transactions: {file_path=}"
        logger.error(msg)
        raise ExtractTransactionsError(msg) from e

    try:
        balance = extract_balance(case, file_path, lines)
    except Exception as e:
        msg = f"failed to parse {case=} balance: {file_path=}"
        logger.error(msg)
        raise ExtractBalanceError(msg) from e

    return transactions, balance


def parse_new_files(
    case: Case,
    new_files_to_parse: list[Path],
    parsed_dir: Path,
):
    """Parse all newly discovered files for this account type."""
    if len(new_files_to_parse) == 0:
        logger.info("No new files to parse")
        return

    if not parsed_dir.exists():
        logger.info(f"Creating {parsed_dir=}")
        parsed_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Parsing {len(new_files_to_parse):_} new files to {parsed_dir=}")

    for file_path in new_files_to_parse:
        logger.debug(f"Parsing {file_path=} to {parsed_dir=}")
        try:
            transactions, balance = parse_csv_file(case, file_path)
        except (ExtractBalanceError, ExtractTransactionsError):
            continue  # already logged in parse_csv_file

        store_transactions(parsed_dir, file_path, transactions)
        store_balance(parsed_dir, file_path, balance)

    logger.info(f"Finished parsing {len(new_files_to_parse):_d} new files")


def main(config: Config):
    """Run the full ETL pipeline for this parser."""
    logger.info(f"Processing {CASE=}")

    # scan source files
    relevant_source_files = get_parser_source_files(CASE, config, check_if_parser_applies)

    # scan target files
    raw_dir = config.get_raw_dir(CASE)
    relevant_target_files = detect_relevant_target_files(raw_dir)

    # select new source files to be processed
    new_files_to_copy = select_files_to_copy(relevant_source_files, relevant_target_files)

    # copy new source files
    copy_new_files(raw_dir, new_files_to_copy)

    # detect new raw files
    parsed_dir = config.get_parsed_dir(CASE)
    new_files_to_parse = detect_new_raw_files(
        raw_dir, check_if_parser_applies, parsed_dir, CASE.provider, CASE.service
    )

    # parse new files to parquet -> transactions & balance
    parse_new_files(CASE, new_files_to_parse, parsed_dir)

    # extend pre-existing parquets for this parser
    parser_dir = config.get_parser_dir(CASE)
    concatenate_new_information_to_history(parser_dir, parsed_dir, new_files_to_parse)

    logger.info(f"Done processing {CASE=}")
