"""DKB bank provider plugin."""
