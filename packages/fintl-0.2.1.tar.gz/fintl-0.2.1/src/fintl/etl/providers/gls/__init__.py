"""GLS bank provider plugin."""
