"""Google Ads MCP server -- 32 tools for reading, writing, and analyzing accounts.

Read (8):     GAQL execution, account discovery, keyword ideas, geo targets,
              field metadata, query validation, recommendations
Write (16):   Campaigns, budgets, ad groups, ads, keywords, targeting, recommendations
              (disabled by default — set GOOGLE_ADS_MCP_WRITE_ENABLED=true)
Workflow (7): Campaign audit, underspend diagnosis, budget reallocation,
              creative analysis, creative fatigue, audience analysis, test monitoring
Utility (1):  Connection status check
"""

import asyncio
import os
import signal
import sys
from contextlib import asynccontextmanager
from types import FrameType
from typing import Any, AsyncGenerator, Optional

from fastmcp import Context, FastMCP

from src.audit import get_audit_logger
from src.middleware.audit_middleware import AuditMiddleware
from src.middleware.rate_limit_middleware import RateLimitMiddleware
from src.sdk_client import GoogleAdsSdkClient, get_sdk_client, set_sdk_client
from src.servers.read_server import read_server
from src.servers.workflow_server import workflow_server
from src.utils import get_logger, load_dotenv

logger = get_logger(__name__)

load_dotenv()

WRITE_ENABLED = (
    os.environ.get("GOOGLE_ADS_MCP_WRITE_ENABLED", "false").lower() == "true"
)


@asynccontextmanager
async def lifespan(app: Any) -> AsyncGenerator[None, None]:  # noqa: ARG001
    """Manage Google Ads SDK client lifecycle."""
    logger.info("Starting Google Ads MCP server...")
    client = None
    try:
        client = GoogleAdsSdkClient()
        set_sdk_client(client)
        logger.info("Google Ads SDK client initialized successfully")
        yield
    finally:
        logger.info("Shutting down Google Ads MCP server...")
        get_audit_logger().close()
        if client:
            client.close()


mcp = FastMCP(
    name="google-ads",
    instructions=f"""Google Ads MCP server — {"32" if WRITE_ENABLED else "16"} tools for {"reading, writing, and analyzing" if WRITE_ENABLED else "reading and analyzing"} Google Ads accounts.

    READ (8 tools): Use execute_query for any GAQL query. Use get_field_metadata
    to discover available fields and validate_query_fields to check compatibility.
    list_accessible_customers is the bootstrap call (no customer ID needed).
    {""}
    {"WRITE (16 tools): Create and update campaigns, budgets, ad groups, ads, keywords, and targeting criteria. apply_recommendation / dismiss_recommendation for Google optimization suggestions." if WRITE_ENABLED else "WRITE TOOLS ARE DISABLED. Set GOOGLE_ADS_MCP_WRITE_ENABLED=true to enable 16 write tools."}

    WORKFLOW (7 tools): High-level analysis tools that run multiple queries and apply
    scoring logic. Campaign audit, underspend diagnosis, budget reallocation, creative
    analysis, creative fatigue detection, audience analysis, and test monitoring.

    All customer IDs accept hyphens (stripped automatically).
    Use execute_query with GAQL for any read not covered by a dedicated tool.""",
    lifespan=lifespan,
    middleware=[AuditMiddleware(), RateLimitMiddleware()],
)

# Mount servers — write tools require explicit opt-in
mcp.mount(read_server)
if WRITE_ENABLED:
    from src.servers.write_server import write_server

    mcp.mount(write_server)
    logger.warning("WRITE TOOLS ENABLED — 16 write tools are active")
else:
    logger.info(
        "Write tools disabled (set GOOGLE_ADS_MCP_WRITE_ENABLED=true to enable)"
    )
mcp.mount(workflow_server)


@mcp.tool
async def check_connection_status(ctx: Context) -> str:  # noqa: ARG001
    """Check if the Google Ads SDK client is initialized and return the MCC ID.

    Use this to verify credentials are working before making other calls.
    """
    try:
        client = get_sdk_client()
        if client:
            login_cid = os.environ.get("GOOGLE_ADS_LOGIN_CUSTOMER_ID", "not set")
            write_status = "ENABLED" if WRITE_ENABLED else "DISABLED"
            return (
                f"Google Ads SDK client is initialized and ready. "
                f"MCC (login_customer_id): {login_cid}. "
                f"Write tools: {write_status}. "
                f"To list accounts, call list_accessible_customers."
            )
    except Exception:
        pass
    return "Google Ads SDK client is not initialized"


# --- Shutdown handling ---

shutdown_event = asyncio.Event()


def signal_handler(signum: int, frame: Optional[FrameType]) -> None:  # noqa: ARG001
    """Handle shutdown signals gracefully."""
    logger.info(f"Received signal {signum}, shutting down...")
    shutdown_event.set()

    import threading

    threading.Timer(2.0, lambda: os._exit(0)).start()


async def run_with_shutdown() -> None:
    """Run the MCP server with graceful shutdown support."""
    server_task = asyncio.create_task(mcp.run_async(transport="stdio"))
    shutdown_task = asyncio.create_task(shutdown_event.wait())

    _, pending = await asyncio.wait(
        [server_task, shutdown_task], return_when=asyncio.FIRST_COMPLETED
    )

    for task in pending:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    logger.info("Server stopped gracefully")


def main() -> None:
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        asyncio.run(run_with_shutdown())
    except KeyboardInterrupt:
        logger.info("Received KeyboardInterrupt during startup")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
