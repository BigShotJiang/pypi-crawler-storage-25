## Google Ads MCP Server

32 tools wrapping the Google Ads Python SDK (v23+) via FastMCP.

### Architecture

```
main.py                          Entry point — mounts 3 servers + 1 inline tool
src/servers/read_server.py       8 read tools (GAQL, field metadata, keywords, geo, recommendations)
src/servers/write_server.py      16 write tools (campaigns, budgets, ad groups, ads, keywords, targeting)
src/servers/workflow_server.py   7 workflow tools (audit, underspend, realloc, creative, fatigue, audience, test)
src/services/                    Business logic layer (service classes)
src/sdk_client.py                Global SDK client singleton + get_type() helper
src/utils.py                     Logging, dotenv, customer ID formatting, proto serialization
```

### Key Patterns

- All types use `get_type("TypeName")` from `src/sdk_client.py` — never import v23 types directly
- Service classes use lazy `@property` for SDK client initialization
- `serialize_proto_message()` converts proto-plus objects to dicts
- `format_customer_id()` strips hyphens from customer IDs
- Workflow tools compose multiple GAQL queries with scoring/business logic

### Rules

1. Use `uv` for package management — `uv sync`, `uv run`
2. After changes: `uv run ruff format .` and `uv run pyright`
3. All tools must have clear docstrings (these become the LLM's tool descriptions)
4. Read tools use GAQL via `execute_query` — don't create dedicated read tools for entities queryable via GAQL
5. The 7 workflow tools are BlueAlpha's differentiators — they should not be simplified or removed

### Resources

1. `./refs/googleads.llms.txt` — Google Ads API reference
2. `./refs/fastmcp.llms.txt` — FastMCP documentation
3. `G_ADS_MCP_STRATEGY_AGENT.md` — Migration plan, tool tiering, consumer agent architecture
