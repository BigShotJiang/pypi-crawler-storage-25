"""Per-customer-ID rate limiting middleware for Google Ads MCP.

Prevents LLM tool-call loops by enforcing sliding-window rate limits
on read, write, and workflow tools — scoped per Google Ads customer ID.

Uses collections.deque with time.monotonic() timestamps for clock-safe,
in-memory sliding windows. No external dependencies.

Environment variables:
    GOOGLE_ADS_MCP_RATE_LIMIT_ENABLED: Master switch (default: true)
    GOOGLE_ADS_MCP_RATE_LIMIT_READS_PER_MIN: Read tools (default: 60)
    GOOGLE_ADS_MCP_RATE_LIMIT_WRITES_PER_HOUR: Write tools (default: 20)
    GOOGLE_ADS_MCP_RATE_LIMIT_WORKFLOWS_PER_MIN: Workflow tools
        (default: 10)
    GOOGLE_ADS_MCP_RATE_LIMIT_BUDGET_CHANGES_PER_HOUR: Budget mutation
        subcap (default: 0 = disabled)
"""

import math
import os
import time
from collections import deque
from typing import Any

import mcp.types as mt
from fastmcp.server.middleware import Middleware, MiddlewareContext

from src.audit import classify_tool, extract_customer_id

# ── Configuration ────────────────────────────────────────────────────

RATE_LIMIT_ENABLED = (
    os.environ.get("GOOGLE_ADS_MCP_RATE_LIMIT_ENABLED", "true").lower() == "true"
)
READS_PER_MIN = int(os.environ.get("GOOGLE_ADS_MCP_RATE_LIMIT_READS_PER_MIN", "60"))
WRITES_PER_HOUR = int(os.environ.get("GOOGLE_ADS_MCP_RATE_LIMIT_WRITES_PER_HOUR", "20"))
WORKFLOWS_PER_MIN = int(
    os.environ.get("GOOGLE_ADS_MCP_RATE_LIMIT_WORKFLOWS_PER_MIN", "10")
)
BUDGET_CHANGES_PER_HOUR = int(
    os.environ.get("GOOGLE_ADS_MCP_RATE_LIMIT_BUDGET_CHANGES_PER_HOUR", "0")
)

# Category → (max_calls, window_seconds)
_LIMITS: dict[str, tuple[int, int]] = {
    "read": (READS_PER_MIN, 60),
    "write": (WRITES_PER_HOUR, 3600),
    "workflow": (WORKFLOWS_PER_MIN, 60),
    "budget": (BUDGET_CHANGES_PER_HOUR, 3600),
}

# Budget tools that count toward the optional budget subcap
_BUDGET_TOOLS = frozenset({"create_campaign_budget", "update_campaign_budget"})

# Human-readable window labels for error messages
_WINDOW_LABELS: dict[str, str] = {
    "read": "per minute",
    "write": "per hour",
    "workflow": "per minute",
    "budget": "per hour",
}


# ── Sliding window ──────────────────────────────────────────────────


class SlidingWindow:
    """In-memory sliding window counter using a deque of timestamps."""

    def __init__(self, max_calls: int, window_seconds: int) -> None:
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._timestamps: deque[float] = deque()

    def _prune(self, now: float) -> None:
        """Remove timestamps older than the window."""
        cutoff = now - self.window_seconds
        while self._timestamps and self._timestamps[0] <= cutoff:
            self._timestamps.popleft()

    def is_allowed(self) -> bool:
        """Check if a new call is allowed and record it if so."""
        now = time.monotonic()
        self._prune(now)
        if len(self._timestamps) >= self.max_calls:
            return False
        self._timestamps.append(now)
        return True

    def time_until_next_slot(self) -> float:
        """Seconds until the oldest entry expires and a slot opens."""
        if not self._timestamps:
            return 0.0
        now = time.monotonic()
        self._prune(now)
        if len(self._timestamps) < self.max_calls:
            return 0.0
        oldest = self._timestamps[0]
        return max(0.0, (oldest + self.window_seconds) - now)

    @property
    def current_count(self) -> int:
        """Number of calls in the current window (for observability)."""
        self._prune(time.monotonic())
        return len(self._timestamps)


# ── Registry ────────────────────────────────────────────────────────


class RateLimitRegistry:
    """Manages per-customer-ID, per-category sliding windows.

    Keys are (customer_id, category) tuples. Windows are created
    lazily on first access.
    """

    def __init__(self) -> None:
        self._windows: dict[tuple[str, str], SlidingWindow] = {}

    def check(self, customer_id: str, category: str) -> tuple[bool, float]:
        """Check if a call is allowed.

        Returns:
            (allowed, retry_after_seconds)
        """
        max_calls, _ = _LIMITS.get(category, (0, 0))
        if max_calls <= 0:
            # Category disabled (e.g., budget subcap default 0)
            return True, 0.0

        window = self._get_or_create(customer_id, category)
        if window.is_allowed():
            return True, 0.0
        return False, window.time_until_next_slot()

    def _get_or_create(self, customer_id: str, category: str) -> SlidingWindow:
        key = (customer_id, category)
        if key not in self._windows:
            max_calls, window_seconds = _LIMITS[category]
            self._windows[key] = SlidingWindow(max_calls, window_seconds)
        return self._windows[key]


# ── Middleware ────────────────────────────────────────────────────────


class RateLimitMiddleware(Middleware):
    """FastMCP middleware that enforces per-customer rate limits.

    Short-circuits with an error dict when limits are exceeded,
    matching the guardrail block pattern from write_validator.py.
    """

    def __init__(self) -> None:
        self._registry = RateLimitRegistry()

    async def on_call_tool(  # type: ignore[override]
        self,
        context: MiddlewareContext[mt.CallToolRequestParams],
        call_next: Any,
    ) -> Any:
        if not RATE_LIMIT_ENABLED:
            return await call_next(context)

        tool_name = context.message.name
        arguments = context.message.arguments
        category = classify_tool(tool_name)

        # Utility tools and tools without customer_id are exempt
        if category == "utility":
            return await call_next(context)

        customer_id = extract_customer_id(arguments)
        if not customer_id:
            return await call_next(context)

        # Check optional budget subcap FIRST — before the category-level
        # check records a timestamp, so a blocked budget call does not
        # burn a write-window slot.
        if tool_name in _BUDGET_TOOLS and BUDGET_CHANGES_PER_HOUR > 0:
            allowed, retry_after = self._registry.check(customer_id, "budget")
            if not allowed:
                return {
                    "error": (
                        f"Budget change rate limit exceeded: "
                        f"{BUDGET_CHANGES_PER_HOUR} budget changes "
                        f"per hour for customer {customer_id}. "
                        f"Try again in "
                        f"{math.ceil(retry_after)} seconds."
                    ),
                    "rate_limited": True,
                    "retry_after_seconds": math.ceil(retry_after),
                }

        # Check the category-level limit
        allowed, retry_after = self._registry.check(customer_id, category)
        if not allowed:
            label = _WINDOW_LABELS.get(category, "")
            limit = _LIMITS[category][0]
            return {
                "error": (
                    f"Rate limit exceeded: {limit} {category} calls "
                    f"{label} for customer {customer_id}. "
                    f"Try again in {math.ceil(retry_after)} seconds."
                ),
                "rate_limited": True,
                "retry_after_seconds": math.ceil(retry_after),
            }

        return await call_next(context)
