"""FastMCP middleware that audits every tool invocation to JSONL.

Intercepts all tool calls at the framework level via on_call_tool(),
capturing timing, arguments, outcome, and guardrail results — with zero
changes to individual tool handlers.

Writes to the singleton AuditLogger (JSONL file) and optionally emits
a condensed line to the MCP protocol log (visible to the LLM client).

Note: FastMCP's call_next() returns the raw handler result (dict, list,
str, etc.), not a CallToolResult. FastMCP wraps it in CallToolResult
*after* middleware completes. All parsing here works on raw Python types.
"""

import json
import time
from typing import Any

import mcp.types as mt
from fastmcp.server.middleware import Middleware, MiddlewareContext

from src.audit import build_record, get_audit_logger

# ── Result parsing helpers ───────────────────────────────────────────


def _extract_outcome(
    result: Any,
) -> tuple[str, str | None, int | None, list[str] | None]:
    """Parse a raw tool handler result into audit fields.

    Tool handlers return raw Python objects (dicts, lists, strings).
    Write tools that hit a guardrail block return
    {"error": ..., "risk_tier": ...} as a dict.
    """
    error: str | None = None
    risk_tier: int | None = None
    guardrail_warnings: list[str] | None = None

    # Dict results — check for rate limit, guardrail block, or success
    if isinstance(result, dict):
        if "rate_limited" in result:
            return "rate_limited", str(result.get("error", ""))[:500], None, None
        if "error" in result:
            outcome = "blocked" if "risk_tier" in result else "error"
            error = str(result["error"])[:500]
            risk_tier = result.get("risk_tier")
        else:
            outcome = "success"
        if "guardrail_warnings" in result:
            guardrail_warnings = result["guardrail_warnings"]
        return outcome, error, risk_tier, guardrail_warnings

    # String results — always success (e.g. check_connection_status)
    if isinstance(result, str):
        return "success", None, None, None

    # List results — always success (e.g. search_stream returns a list)
    if isinstance(result, list):
        return "success", None, None, None

    # CallToolResult — handle if FastMCP changes behavior in the future
    if hasattr(result, "isError"):
        outcome = "error" if result.isError else "success"
        if result.isError and hasattr(result, "content") and result.content:
            for item in result.content:
                if hasattr(item, "text"):
                    error = item.text[:500]
                    break
        return outcome, error, risk_tier, guardrail_warnings

    # Fallback — unknown type
    return "success", None, None, None


def _summarize_result(result: Any) -> str | None:
    """Extract a short summary from the raw tool result."""
    if isinstance(result, dict):
        if "results" in result and isinstance(result["results"], list):
            return f"{len(result['results'])} result(s)"
        if "resource_name" in result:
            return str(result["resource_name"])
        if "error" in result:
            return None  # Already captured in outcome
        # Summarize by key count for other dicts
        return f"{len(result)} field(s)"

    if isinstance(result, list):
        return f"{len(result)} row(s)"

    if isinstance(result, str):
        return f"{len(result)} chars"

    # CallToolResult fallback
    if hasattr(result, "content") and result.content:
        for item in result.content:
            if hasattr(item, "text"):
                try:
                    data = json.loads(item.text)
                    if isinstance(data, dict) and "results" in data:
                        return f"{len(data['results'])} result(s)"
                except (json.JSONDecodeError, TypeError):
                    pass
                return f"{len(item.text)} chars"

    return None


# ── Middleware ────────────────────────────────────────────────────────


class AuditMiddleware(Middleware):
    """Logs every tool call to the JSONL audit trail.

    Captures:
    - Tool name and classification (read/write/workflow/utility)
    - Redacted arguments (secrets stripped)
    - Customer ID (extracted from args)
    - Outcome (success/error/blocked)
    - Elapsed time in milliseconds
    - Risk tier and guardrail warnings (for write tools)
    - Result summary (row count or resource name)
    """

    async def on_call_tool(  # type: ignore[override]
        self,
        context: MiddlewareContext[mt.CallToolRequestParams],
        call_next: Any,
    ) -> Any:
        tool_name = context.message.name
        arguments = context.message.arguments
        t0 = time.perf_counter()

        try:
            result = await call_next(context)
        except Exception as exc:
            # Tool raised an unhandled exception
            elapsed_ms = int((time.perf_counter() - t0) * 1000)
            audit = get_audit_logger()
            audit.log(
                build_record(
                    tool_name=tool_name,
                    arguments=arguments,
                    outcome="error",
                    elapsed_ms=elapsed_ms,
                    error=str(exc)[:500],
                )
            )
            raise

        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        outcome, error, risk_tier, guardrail_warnings = _extract_outcome(result)
        summary = _summarize_result(result)

        audit = get_audit_logger()
        audit.log(
            build_record(
                tool_name=tool_name,
                arguments=arguments,
                outcome=outcome,
                elapsed_ms=elapsed_ms,
                error=error,
                risk_tier=risk_tier,
                guardrail_warnings=guardrail_warnings,
                result_summary=summary,
            )
        )

        return result
