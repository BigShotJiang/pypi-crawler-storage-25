"""FastMCP middleware -- audit logging and rate limiting."""
