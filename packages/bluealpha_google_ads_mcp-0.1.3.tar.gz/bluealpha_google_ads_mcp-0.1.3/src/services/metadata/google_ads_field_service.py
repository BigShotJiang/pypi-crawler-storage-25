"""Google Ads field service implementation using Google Ads SDK."""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.utils import get_logger, serialize_proto_message

logger = get_logger(__name__)


class GoogleAdsFieldService:
    """Google Ads field service for discovering field metadata."""

    def __init__(self) -> None:
        """Initialize the Google Ads field service."""
        self._client = None

    @property
    def client(self):
        """Get the Google Ads field service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("GoogleAdsFieldService")
        assert self._client is not None
        return self._client

    async def get_field_metadata(
        self,
        ctx: Context,
        field_name: str,
    ) -> Dict[str, Any]:
        """Get metadata for a specific field.

        Args:
            ctx: FastMCP context
            field_name: The field name (e.g., "campaign.name")

        Returns:
            Field metadata including type, category, and attributes
        """
        try:
            # Make the API call
            field = self.client.get_google_ads_field(
                resource_name=f"googleAdsFields/{field_name}",
            )

            await ctx.log(
                level="info",
                message=f"Retrieved metadata for field: {field_name}",
            )

            return serialize_proto_message(field)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to get field metadata: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def search_fields(
        self,
        ctx: Context,
        query: Optional[str] = None,
        category_filter: Optional[str] = None,
        selectable_only: bool = False,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Search for Google Ads fields based on criteria.

        Args:
            ctx: FastMCP context
            query: Optional name filter (e.g., "campaign" to find fields containing "campaign").
                   Treated as a name substring filter: name LIKE '%{query}%'
            category_filter: Optional category filter string (RESOURCE, ATTRIBUTE, SEGMENT, METRIC)
            selectable_only: Only return selectable fields
            limit: Maximum number of results

        Returns:
            List of field metadata
        """
        try:
            # Build WHERE conditions
            conditions = []

            if query:
                conditions.append(f"name LIKE '%{query}%'")

            if category_filter:
                conditions.append(f"category = '{category_filter}'")

            if selectable_only:
                conditions.append("selectable = true")

            # Construct final query with SELECT
            where_clause = " AND ".join(conditions) if conditions else "name != ''"
            search_query = f"SELECT name, category, selectable, filterable, sortable, data_type, is_repeated WHERE {where_clause} LIMIT {limit}"

            # Make the API call - returns a pager
            pager = self.client.search_google_ads_fields(query=search_query)

            # Process results
            fields = []
            for field in pager:
                fields.append(serialize_proto_message(field))

            await ctx.log(
                level="info",
                message=f"Found {len(fields)} fields matching criteria",
            )

            return fields

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to search fields: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def get_resource_fields(
        self,
        ctx: Context,
        resource_name: str,
        include_metrics: bool = True,
        include_segments: bool = True,
    ) -> Dict[str, Any]:
        """Get all available fields for a specific resource.

        Args:
            ctx: FastMCP context
            resource_name: The resource name (e.g., "campaign", "ad_group")
            include_metrics: Include metric fields
            include_segments: Include segment fields

        Returns:
            Dictionary with categorized fields for the resource
        """
        try:
            # Query GoogleAdsFieldService directly to avoid double-wrapping
            attr_query = f"SELECT name, category, selectable, filterable, sortable, data_type, is_repeated WHERE name LIKE '{resource_name}.%' AND category = 'ATTRIBUTE' LIMIT 500"
            pager = self.client.search_google_ads_fields(query=attr_query)
            resource_fields = [serialize_proto_message(f) for f in pager]

            result: Dict[str, Any] = {
                "resource": resource_name,
                "attributes": resource_fields,
            }

            # Get metrics if requested
            if include_metrics:
                metric_query = "SELECT name, category, selectable, filterable, sortable, data_type, is_repeated WHERE name LIKE 'metrics.%' AND category = 'METRIC' LIMIT 200"
                metric_pager = self.client.search_google_ads_fields(query=metric_query)
                result["metrics"] = [serialize_proto_message(f) for f in metric_pager]

            # Get segments if requested
            if include_segments:
                segment_query = "SELECT name, category, selectable, filterable, sortable, data_type, is_repeated WHERE name LIKE 'segments.%' AND category = 'SEGMENT' LIMIT 100"
                segment_pager = self.client.search_google_ads_fields(
                    query=segment_query
                )
                result["segments"] = [serialize_proto_message(f) for f in segment_pager]

            await ctx.log(
                level="info",
                message=f"Retrieved field information for resource: {resource_name}",
            )

            return result

        except Exception as e:
            error_msg = f"Failed to get resource fields: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def validate_query_fields(
        self,
        ctx: Context,
        resource_name: str,
        field_names: List[str],
    ) -> Dict[str, Any]:
        """Validate if fields can be selected together in a query.

        Args:
            ctx: FastMCP context
            resource_name: The main resource (e.g., "campaign")
            field_names: List of field names to validate

        Returns:
            Validation result with compatibility information
        """
        try:
            validation_result: Dict[str, Any] = {
                "resource": resource_name,
                "fields": {},
                "all_compatible": True,
                "issues": [],
            }

            # Check each field
            for field_name in field_names:
                try:
                    field_metadata = await self.get_field_metadata(ctx, field_name)
                    validation_result["fields"][field_name] = {
                        "valid": True,
                        "selectable": field_metadata.get("selectable", False),
                        "data_type": field_metadata.get("dataType", "UNKNOWN"),
                        "category": field_metadata.get("category", "UNKNOWN"),
                    }

                    if not field_metadata.get("selectable", False):
                        validation_result["all_compatible"] = False
                        validation_result["issues"].append(
                            f"Field '{field_name}' is not selectable"
                        )

                except Exception:
                    validation_result["fields"][field_name] = {
                        "valid": False,
                        "error": f"Field '{field_name}' not found",
                    }
                    validation_result["all_compatible"] = False
                    validation_result["issues"].append(
                        f"Field '{field_name}' is not a valid field"
                    )

            await ctx.log(
                level="info",
                message=f"Validated {len(field_names)} fields for resource: {resource_name}",
            )

            return validation_result

        except Exception as e:
            error_msg = f"Failed to validate query fields: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
