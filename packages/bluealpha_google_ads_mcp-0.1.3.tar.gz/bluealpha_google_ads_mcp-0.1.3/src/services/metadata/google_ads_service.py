"""Google Ads service implementation with get_type() pattern for version safety."""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v23.services.services.google_ads_service import (
    GoogleAdsServiceClient,
)

from src.sdk_client import get_sdk_client, get_type
from src.utils import format_customer_id, get_logger, serialize_proto_message

logger = get_logger(__name__)


class GoogleAdsService:
    """Complete Google Ads service for search and mutate operations."""

    def __init__(self) -> None:
        """Initialize the Google Ads service."""
        self._client: Optional[GoogleAdsServiceClient] = None

    @property
    def client(self) -> GoogleAdsServiceClient:
        """Get the Google Ads service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("GoogleAdsService")
        assert self._client is not None
        return self._client

    async def search(
        self,
        ctx: Context,
        customer_id: str,
        query: str,
        page_size: int = 1000,
        page_token: Optional[str] = None,
        validate_only: bool = False,
        summary_row_setting: str = "NO_SUMMARY_ROW",
    ) -> Dict[str, Any]:
        """Execute a GAQL query and return paginated results.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            query: The GAQL (Google Ads Query Language) query
            page_size: Kept for backward compatibility but not passed to API
                (v23 uses fixed page size of 10000)
            page_token: Token for pagination
            validate_only: If true, only validates the query
            summary_row_setting: Whether to include summary row (string name)

        Returns:
            Dictionary containing results and pagination info
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Execute search — v23 uses fixed page_size of 10000, cannot be set
            response = self.client.search(customer_id=customer_id, query=query)

            # Process results
            results: List[Dict[str, Any]] = []
            for row in response.results:
                results.append(serialize_proto_message(row))

            # Include summary row if present
            summary_row = None
            if response.summary_row:
                summary_row = serialize_proto_message(response.summary_row)

            return {
                "results": results,
                "next_page_token": response.next_page_token,
                "total_results_count": response.total_results_count,
                "summary_row": summary_row,
                "field_mask": response.field_mask.paths if response.field_mask else [],
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to execute search: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def search_stream(
        self,
        ctx: Context,
        customer_id: str,
        query: str,
        summary_row_setting: str = "NO_SUMMARY_ROW",
    ) -> List[Dict[str, Any]]:
        """Execute a GAQL query and stream all results.

        For large result sets, this is more efficient than paginated search.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            query: The GAQL (Google Ads Query Language) query
            summary_row_setting: Whether to include summary row (string name)

        Returns:
            List of all results
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Execute streaming search — use keyword args for v23 compatibility
            stream = self.client.search_stream(customer_id=customer_id, query=query)

            # Process all results
            results: List[Dict[str, Any]] = []
            total_count = 0

            for batch in stream:
                for row in batch.results:
                    results.append(serialize_proto_message(row))
                    total_count += 1

                # Log progress for large result sets
                if total_count % 10000 == 0:
                    await ctx.log(
                        level="info",
                        message=f"Processed {total_count} rows so far...",
                    )

            await ctx.log(
                level="info",
                message=f"Query completed. Total rows: {total_count}",
            )

            return results

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to execute search stream: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def mutate(
        self,
        ctx: Context,
        customer_id: str,
        operations: List[Any],
        partial_failure: bool = False,
        validate_only: bool = False,
        response_content_type: str = "MUTABLE_RESOURCE",
    ) -> Dict[str, Any]:
        """Execute multiple mutate operations across different resource types.

        This is the most flexible mutation method, allowing operations on
        multiple resource types in a single request.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            operations: List of mutate operations
            partial_failure: If true, valid operations succeed even if others fail
            validate_only: If true, only validates without executing
            response_content_type: What to return in response (string name)

        Returns:
            Mutation results
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Create the request
            request = get_type("MutateGoogleAdsRequest")
            request.customer_id = customer_id
            request.mutate_operations.extend(operations)
            request.partial_failure = partial_failure
            request.validate_only = validate_only
            request.response_content_type = getattr(
                get_type("ResponseContentTypeEnum").ResponseContentType,
                response_content_type,
            )

            # Execute mutations
            response = self.client.mutate(request=request)

            # Process results
            results: List[Dict[str, Any]] = []
            for result in response.mutate_operation_responses:
                results.append(serialize_proto_message(result))

            # Handle partial_failure_error - only include if it has actual content
            partial_failure_error = None
            if (
                response.partial_failure_error
                and response.partial_failure_error.message
            ):
                partial_failure_error = serialize_proto_message(
                    response.partial_failure_error
                )

            return {
                "results": results,
                "partial_failure_error": partial_failure_error,
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to execute mutations: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
