"""Customer service implementation using Google Ads SDK."""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v23.services.services.customer_service import (
    CustomerServiceClient,
)

from src.sdk_client import get_sdk_client, get_type
from src.utils import format_customer_id, get_logger, serialize_proto_message

logger = get_logger(__name__)


class CustomerService:
    """Customer service for managing Google Ads customers."""

    def __init__(self) -> None:
        """Initialize the customer service."""
        self._client: Optional[CustomerServiceClient] = None

    @property
    def client(self) -> CustomerServiceClient:
        """Get the customer service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("CustomerService")
        assert self._client is not None
        return self._client

    async def create_customer_client(
        self,
        ctx: Context,
        manager_customer_id: str,
        descriptive_name: str,
        currency_code: str = "USD",
        time_zone: str = "America/New_York",
    ) -> Dict[str, Any]:
        """Create a new client customer under a manager account.

        Args:
            ctx: FastMCP context
            manager_customer_id: The manager customer ID
            descriptive_name: Name of the new client
            currency_code: Currency code (e.g. USD, EUR)
            time_zone: Time zone ID

        Returns:
            Created customer details
        """
        try:
            manager_customer_id = format_customer_id(manager_customer_id)

            # Create a new customer object
            customer = get_type("Customer")
            customer.descriptive_name = descriptive_name
            customer.currency_code = currency_code
            customer.time_zone = time_zone

            # Make the API call
            response = self.client.create_customer_client(
                customer_id=manager_customer_id,
                customer_client=customer,
            )

            # Extract customer ID from resource name
            customer_resource = response.resource_name
            customer_id = customer_resource.split("/")[-1] if customer_resource else ""

            await ctx.log(
                level="info",
                message=f"Created customer client {customer_id} under manager {manager_customer_id}",
            )

            # Return serialized response
            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to create customer client: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def list_accessible_customers(self, ctx: Context) -> List[str]:
        """List all accessible customers for the authenticated user.

        Args:
            ctx: FastMCP context

        Returns:
            List of accessible customer IDs
        """
        try:
            # Make the API call
            response = self.client.list_accessible_customers(
                request=get_type("ListAccessibleCustomersRequest")
            )

            customer_ids = response.resource_names

            await ctx.log(
                level="info",
                message=f"Found {len(customer_ids)} accessible customers",
            )

            # Extract customer IDs from resource names
            return [
                resource_name.split("/")[-1]
                for resource_name in customer_ids
                if resource_name
            ]

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to list accessible customers: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
