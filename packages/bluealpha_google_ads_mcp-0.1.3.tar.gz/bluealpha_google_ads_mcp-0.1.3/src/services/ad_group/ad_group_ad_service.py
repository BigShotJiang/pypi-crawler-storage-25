"""Ad group ad service implementation using Google Ads SDK."""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v23.services.services.ad_group_ad_service import (
    AdGroupAdServiceClient,
)
from google.ads.googleads.v23.services.services.google_ads_service import (
    GoogleAdsServiceClient,
)
from google.protobuf import field_mask_pb2

from src.sdk_client import get_sdk_client, get_type
from src.utils import format_customer_id, get_logger, serialize_proto_message

logger = get_logger(__name__)


class AdGroupAdService:
    """Ad group ad service for managing ads within ad groups."""

    def __init__(self) -> None:
        """Initialize the ad group ad service."""
        self._client: Optional[AdGroupAdServiceClient] = None

    @property
    def client(self) -> AdGroupAdServiceClient:
        """Get the ad group ad service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("AdGroupAdService")
        assert self._client is not None
        return self._client

    async def create_ad_group_ad(
        self,
        ctx: Context,
        customer_id: str,
        ad_group_id: str,
        ad_resource_name: str,
        status: str = "ENABLED",
    ) -> Dict[str, Any]:
        """Create a new ad group ad (associate an ad with an ad group).

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            ad_group_id: The ad group ID
            ad_resource_name: The resource name of the ad to add
            status: Ad group ad status string (ENABLED, PAUSED, REMOVED)

        Returns:
            Created ad group ad details
        """
        try:
            customer_id = format_customer_id(customer_id)
            ad_group_resource = f"customers/{customer_id}/adGroups/{ad_group_id}"

            # Convert string status to enum
            status_enum = getattr(
                get_type("AdGroupAdStatusEnum").AdGroupAdStatus, status
            )

            # Create ad group ad
            ad_group_ad = get_type("AdGroupAd")
            ad_group_ad.ad_group = ad_group_resource

            # Create ad with resource name
            ad = get_type("Ad")
            ad.resource_name = ad_resource_name
            ad_group_ad.ad = ad
            ad_group_ad.status = status_enum

            # Create operation
            operation = get_type("AdGroupAdOperation")
            operation.create = ad_group_ad

            # Make the API call
            response = self.client.mutate_ad_group_ads(
                customer_id=customer_id, operations=[operation]
            )

            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to create ad group ad: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def update_ad_group_ad_status(
        self,
        ctx: Context,
        customer_id: str,
        ad_group_ad_resource_name: str,
        status: str,
    ) -> Dict[str, Any]:
        """Update the status of an ad group ad.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            ad_group_ad_resource_name: The resource name of the ad group ad
            status: New status string (ENABLED, PAUSED, REMOVED)

        Returns:
            Updated ad group ad details
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Convert string status to enum
            status_enum = getattr(
                get_type("AdGroupAdStatusEnum").AdGroupAdStatus, status
            )

            # Create ad group ad with updated status
            ad_group_ad = get_type("AdGroupAd")
            ad_group_ad.resource_name = ad_group_ad_resource_name
            ad_group_ad.status = status_enum

            # Create operation
            operation = get_type("AdGroupAdOperation")
            operation.update = ad_group_ad
            operation.update_mask.CopyFrom(field_mask_pb2.FieldMask(paths=["status"]))

            # Make the API call
            response = self.client.mutate_ad_group_ads(
                customer_id=customer_id, operations=[operation]
            )

            await ctx.log(
                level="info",
                message=f"Updated ad group ad status to {status}",
            )

            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to update ad group ad status: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def list_ad_group_ads(
        self,
        ctx: Context,
        customer_id: str,
        ad_group_id: Optional[str] = None,
        include_policy_data: bool = False,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List ad group ads.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            ad_group_id: Optional ad group ID to filter by
            include_policy_data: Whether to include policy approval data
            limit: Maximum number of results

        Returns:
            List of ad group ads
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Use GoogleAdsService for search
            sdk_client = get_sdk_client()
            google_ads_service: GoogleAdsServiceClient = sdk_client.client.get_service(
                "GoogleAdsService"
            )

            # Build query
            query = """
                SELECT
                    ad_group_ad.resource_name,
                    ad_group_ad.ad_group,
                    ad_group_ad.ad.id,
                    ad_group_ad.ad.name,
                    ad_group_ad.ad.type,
                    ad_group_ad.status,
                    ad_group.id,
                    ad_group.name
            """

            if include_policy_data:
                query += """,
                    ad_group_ad.policy_summary.approval_status,
                    ad_group_ad.policy_summary.review_status
                """

            query += """
                FROM ad_group_ad
                WHERE ad_group_ad.status != 'REMOVED'
            """

            if ad_group_id:
                query += f" AND ad_group.id = {ad_group_id}"

            query += f" ORDER BY ad_group.id LIMIT {limit}"

            # Execute search
            response = google_ads_service.search(customer_id=customer_id, query=query)

            # Process results
            ad_group_ads = []
            for row in response:
                ad_group_ad_data = serialize_proto_message(row.ad_group_ad)
                ad_group_ad_data["ad_group_details"] = serialize_proto_message(
                    row.ad_group
                )
                ad_group_ads.append(ad_group_ad_data)

            await ctx.log(
                level="info",
                message=f"Found {len(ad_group_ads)} ad group ads",
            )

            return ad_group_ads

        except Exception as e:
            error_msg = f"Failed to list ad group ads: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def remove_ad_group_ad(
        self,
        ctx: Context,
        customer_id: str,
        ad_group_ad_resource_name: str,
    ) -> Dict[str, Any]:
        """Remove an ad from an ad group.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            ad_group_ad_resource_name: The resource name of the ad group ad to remove

        Returns:
            Removal result
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Create operation
            operation = get_type("AdGroupAdOperation")
            operation.remove = ad_group_ad_resource_name

            # Make the API call
            response = self.client.mutate_ad_group_ads(
                customer_id=customer_id, operations=[operation]
            )

            await ctx.log(
                level="info",
                message=f"Removed ad group ad: {ad_group_ad_resource_name}",
            )

            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to remove ad group ad: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
