"""Ad group services."""
