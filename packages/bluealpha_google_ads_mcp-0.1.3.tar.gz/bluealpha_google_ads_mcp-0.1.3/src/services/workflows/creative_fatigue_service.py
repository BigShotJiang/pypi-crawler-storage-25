"""Creative Fatigue Detection — workflow from creative-fatigue.md

Compares last 7 days vs prior 7 days per ad. Upper/lower funnel triggers differ.
If 2+ triggers fire → recommend pause/substitute/cap frequency.

Reads: all via GAQL ✅
Writes needed:
  - ad_group_ad_update_ad_group_ad_status ❌ NOT FIXED (pause fatigued ads)
  - ad_group_ad_create_ad_group_ad ❌ NOT FIXED (create fresh variants)
  - campaign_update_campaign ✅ FIXED (frequency cap)
"""

from typing import Any, Dict, List

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.utils import format_customer_id, get_logger, safe_num, serialize_proto_message

logger = get_logger(__name__)


class CreativeFatigueService:
    """Detects creative fatigue via week-over-week metric comparison."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        response = self.service.search(customer_id=customer_id, query=query)
        return [serialize_proto_message(row) for row in response]

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    def _get_ad_daily_metrics(self, customer_id: str) -> List[Dict[str, Any]]:
        """Pull daily ad metrics for last 14 days (7d current + 7d prior)."""
        return self._query(
            customer_id,
            """
            SELECT
                ad_group_ad.ad.id,
                ad_group_ad.status,
                ad_group.id,
                ad_group.name,
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.bidding_strategy_type,
                segments.date,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions,
                metrics.cost_micros,
                metrics.conversions_value
            FROM ad_group_ad
            WHERE ad_group_ad.status = 'ENABLED'
                AND campaign.status = 'ENABLED'
                AND segments.date DURING LAST_14_DAYS
            """,
        )

    def _get_campaign_frequency(self, customer_id: str) -> List[Dict[str, Any]]:
        """Pull campaign-level frequency metrics (last 7d vs prior 7d)."""
        return self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                segments.date,
                metrics.impressions,
                metrics.unique_users
            FROM campaign
            WHERE campaign.status = 'ENABLED'
                AND segments.date DURING LAST_14_DAYS
            """,
        )

    def _get_change_history(self, customer_id: str) -> List[Dict[str, Any]]:
        """Pull recent changes to detect targeting/bid/LP changes in last 7d."""
        return self._query(
            customer_id,
            """
            SELECT
                change_event.change_date_time,
                change_event.change_resource_type,
                change_event.changed_fields,
                change_event.campaign,
                change_event.ad_group,
                change_event.user_email
            FROM change_event
            WHERE change_event.change_date_time DURING LAST_7_DAYS
                AND change_event.change_resource_type IN (
                    'CAMPAIGN', 'AD_GROUP', 'AD_GROUP_AD',
                    'AD_GROUP_CRITERION', 'CAMPAIGN_CRITERION'
                )
            ORDER BY change_event.change_date_time DESC
            LIMIT 500
            """,
        )

    # ------------------------------------------------------------------
    # Fatigue detection logic
    # ------------------------------------------------------------------

    def _split_weeks(
        self, daily_rows: List[Dict[str, Any]], ad_id: str
    ) -> tuple[Dict[str, float], Dict[str, float]]:
        """Split 14 days of data into current 7d and prior 7d aggregates."""
        # Sort by date
        ad_rows = [
            r
            for r in daily_rows
            if str(r.get("ad_group_ad", {}).get("ad", {}).get("id", "")) == ad_id
        ]
        ad_rows.sort(key=lambda r: r.get("segments", {}).get("date", ""))

        midpoint = len(ad_rows) // 2
        prior = ad_rows[:midpoint]
        current = ad_rows[midpoint:]

        def aggregate(rows: List[Dict[str, Any]]) -> Dict[str, float]:
            totals: Dict[str, float] = {
                "impressions": 0,
                "clicks": 0,
                "conversions": 0,
                "cost": 0,
                "conv_value": 0,
                "days": len(rows),
            }
            for r in rows:
                m = r.get("metrics", {})
                totals["impressions"] += safe_num(m.get("impressions", 0))
                totals["clicks"] += safe_num(m.get("clicks", 0))
                totals["conversions"] += safe_num(m.get("conversions", 0))
                totals["cost"] += safe_num(m.get("cost_micros", 0)) / 1_000_000
                totals["conv_value"] += safe_num(m.get("conversions_value", 0))
            return totals

        return aggregate(prior), aggregate(current)

    def _compute_wow_change(self, prior: float, current: float) -> float:
        """Compute week-over-week % change. Positive = increase."""
        if prior == 0:
            return 0.0
        return (current - prior) / prior

    def _classify_funnel(self, channel_type: str, bidding_strategy: str) -> str:
        """Classify as upper or lower funnel based on channel + bid strategy."""
        upper = channel_type in ("DISPLAY", "VIDEO") or bidding_strategy in (
            "TARGET_CPM",
            "MAXIMIZE_CLICKS",
        )
        return "UPPER" if upper else "LOWER"

    def _check_upper_funnel_triggers(
        self,
        prior: Dict[str, float],
        current: Dict[str, float],
        frequency_wow: float,
        current_frequency: float,
    ) -> List[str]:
        """Upper funnel: any 2 of 4 triggers = fatigue."""
        triggers: List[str] = []

        # 1. Frequency >= 2.5 and +20% WoW
        if current_frequency >= 2.5 and frequency_wow >= 0.20:
            triggers.append(
                f"HIGH_FREQUENCY — Freq {current_frequency:.1f}, +{frequency_wow * 100:.0f}% WoW"
            )

        # 2. Unique reach growth < 5% WoW AND spend flat/rising
        spend_wow = self._compute_wow_change(prior["cost"], current["cost"])
        impr_wow = self._compute_wow_change(
            prior["impressions"], current["impressions"]
        )
        if impr_wow < 0.05 and spend_wow >= 0:
            triggers.append(
                f"REACH_STALL — Impression growth {impr_wow * 100:.0f}% WoW with spend {'+' if spend_wow >= 0 else ''}{spend_wow * 100:.0f}%"
            )

        # 3. CTR or video VR down >= 25% WoW
        prior_ctr = (
            prior["clicks"] / prior["impressions"] if prior["impressions"] > 0 else 0
        )
        current_ctr = (
            current["clicks"] / current["impressions"]
            if current["impressions"] > 0
            else 0
        )
        ctr_wow = self._compute_wow_change(prior_ctr, current_ctr)
        if ctr_wow <= -0.25:
            triggers.append(
                f"CTR_DROP — CTR {ctr_wow * 100:.0f}% WoW ({prior_ctr * 100:.2f}% → {current_ctr * 100:.2f}%)"
            )

        # 4. CPM up >= 20% WoW without targeting changes
        prior_cpm = (
            (prior["cost"] / prior["impressions"] * 1000)
            if prior["impressions"] > 0
            else 0
        )
        current_cpm = (
            (current["cost"] / current["impressions"] * 1000)
            if current["impressions"] > 0
            else 0
        )
        cpm_wow = self._compute_wow_change(prior_cpm, current_cpm)
        if cpm_wow >= 0.20:
            triggers.append(
                f"CPM_SPIKE — CPM +{cpm_wow * 100:.0f}% WoW (${prior_cpm:.2f} → ${current_cpm:.2f})"
            )

        return triggers

    def _check_lower_funnel_triggers(
        self,
        prior: Dict[str, float],
        current: Dict[str, float],
        current_frequency: float,
        frequency_wow: float,
    ) -> List[str]:
        """Lower funnel: any 2 of 4 triggers = fatigue."""
        triggers: List[str] = []

        # 1. CTR down >= 25% WoW
        prior_ctr = (
            prior["clicks"] / prior["impressions"] if prior["impressions"] > 0 else 0
        )
        current_ctr = (
            current["clicks"] / current["impressions"]
            if current["impressions"] > 0
            else 0
        )
        ctr_wow = self._compute_wow_change(prior_ctr, current_ctr)
        if ctr_wow <= -0.25:
            triggers.append(f"CTR_DROP — CTR {ctr_wow * 100:.0f}% WoW")

        # 2. CVR down >= 20% WoW at similar CPC
        prior_cvr = prior["conversions"] / prior["clicks"] if prior["clicks"] > 0 else 0
        current_cvr = (
            current["conversions"] / current["clicks"] if current["clicks"] > 0 else 0
        )
        cvr_wow = self._compute_wow_change(prior_cvr, current_cvr)
        prior_cpc = prior["cost"] / prior["clicks"] if prior["clicks"] > 0 else 0
        current_cpc = (
            current["cost"] / current["clicks"] if current["clicks"] > 0 else 0
        )
        cpc_wow = self._compute_wow_change(prior_cpc, current_cpc)
        if cvr_wow <= -0.20 and abs(cpc_wow) < 0.15:
            triggers.append(
                f"CVR_DROP — CVR {cvr_wow * 100:.0f}% WoW at similar CPC ({cpc_wow * 100:+.0f}%)"
            )

        # 3. CPA up >= 20% OR ROAS down >= 20% WoW
        prior_cpa = (
            prior["cost"] / prior["conversions"] if prior["conversions"] > 0 else 0
        )
        current_cpa = (
            current["cost"] / current["conversions"]
            if current["conversions"] > 0
            else 0
        )
        cpa_wow = self._compute_wow_change(prior_cpa, current_cpa)
        if cpa_wow >= 0.20 and prior_cpa > 0:
            triggers.append(
                f"CPA_SPIKE — CPA +{cpa_wow * 100:.0f}% WoW (${prior_cpa:.2f} → ${current_cpa:.2f})"
            )

        prior_roas = prior["conv_value"] / prior["cost"] if prior["cost"] > 0 else 0
        current_roas = (
            current["conv_value"] / current["cost"] if current["cost"] > 0 else 0
        )
        roas_wow = self._compute_wow_change(prior_roas, current_roas)
        if roas_wow <= -0.20 and prior_roas > 0:
            triggers.append(
                f"ROAS_DROP — ROAS {roas_wow * 100:.0f}% WoW ({prior_roas:.2f} → {current_roas:.2f})"
            )

        # 4. Frequency >= 3 and rising
        if current_frequency >= 3 and frequency_wow > 0:
            triggers.append(
                f"HIGH_FREQUENCY — Freq {current_frequency:.1f}, +{frequency_wow * 100:.0f}% WoW"
            )

        return triggers

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def detect_creative_fatigue(
        self,
        ctx: Context,
        customer_id: str,
    ) -> Dict[str, Any]:
        """Detect creative fatigue across all active ads.

        Compares last 7 days vs prior 7 days. Separate trigger logic for
        upper funnel (reach/awareness) and lower funnel (conversions).
        2+ triggers = fatigued.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID

        Returns:
            Fatigue analysis with triggers, spend share, and recommendations.
        """
        customer_id = format_customer_id(customer_id)

        try:
            daily_data = self._get_ad_daily_metrics(customer_id)
            freq_data = self._get_campaign_frequency(customer_id)

            # Compute campaign-level frequency
            campaign_freq: Dict[str, Dict[str, float]] = {}
            for row in freq_data:
                cid = str(row.get("campaign", {}).get("id", ""))
                date = row.get("segments", {}).get("date", "")
                m = row.get("metrics", {})
                bucket = campaign_freq.setdefault(
                    cid,
                    {
                        "prior_impr": 0,
                        "prior_unique": 0,
                        "current_impr": 0,
                        "current_unique": 0,
                    },
                )
                # Simple split: first half = prior, second half = current
                # (would need proper date comparison in production)
                impr = safe_num(m.get("impressions", 0))
                unique = safe_num(m.get("unique_users", 0))
                bucket["current_impr"] += impr
                bucket["current_unique"] += unique

            # Get unique ad IDs
            ad_ids = set()
            ad_meta: Dict[str, Dict[str, Any]] = {}
            for row in daily_data:
                ad_id = str(row.get("ad_group_ad", {}).get("ad", {}).get("id", ""))
                ad_ids.add(ad_id)
                if ad_id not in ad_meta:
                    ad_meta[ad_id] = {
                        "ad_group_id": str(row.get("ad_group", {}).get("id", "")),
                        "ad_group_name": row.get("ad_group", {}).get("name", ""),
                        "campaign_id": str(row.get("campaign", {}).get("id", "")),
                        "campaign_name": row.get("campaign", {}).get("name", ""),
                        "channel_type": row.get("campaign", {}).get(
                            "advertising_channel_type", ""
                        ),
                        "bidding_strategy": row.get("campaign", {}).get(
                            "bidding_strategy_type", ""
                        ),
                    }

            # Analyze each ad
            fatigued: List[Dict[str, Any]] = []
            healthy: List[Dict[str, Any]] = []
            filtered: List[Dict[str, Any]] = []

            for ad_id in ad_ids:
                meta = ad_meta[ad_id]
                prior, current = self._split_weeks(daily_data, ad_id)

                # Guardrails
                if current["impressions"] < 1000 and current["clicks"] < 50:
                    filtered.append(
                        {
                            "ad_id": ad_id,
                            "reason": "Below minimum volume (< 1000 impr or < 50 clicks)",
                        }
                    )
                    continue
                if current["days"] < 3:
                    filtered.append({"ad_id": ad_id, "reason": "Live < 3 days"})
                    continue

                funnel = self._classify_funnel(
                    meta["channel_type"], meta["bidding_strategy"]
                )

                # Estimate frequency from campaign-level data
                cid = meta["campaign_id"]
                cf = campaign_freq.get(cid, {})
                current_frequency = cf.get("current_impr", 0) / max(
                    cf.get("current_unique", 1), 1
                )
                prior_frequency = cf.get("prior_impr", 0) / max(
                    cf.get("prior_unique", 1), 1
                )
                frequency_wow = self._compute_wow_change(
                    prior_frequency, current_frequency
                )

                if funnel == "UPPER":
                    triggers = self._check_upper_funnel_triggers(
                        prior, current, frequency_wow, current_frequency
                    )
                else:
                    triggers = self._check_lower_funnel_triggers(
                        prior, current, current_frequency, frequency_wow
                    )

                is_fatigued = len(triggers) >= 2

                entry = {
                    "ad_id": ad_id,
                    **meta,
                    "funnel": funnel,
                    "triggers": triggers,
                    "trigger_count": len(triggers),
                    "is_fatigued": is_fatigued,
                    "current_7d_spend": round(current["cost"], 2),
                    "prior_7d_spend": round(prior["cost"], 2),
                }

                if is_fatigued:
                    fatigued.append(entry)
                else:
                    healthy.append(entry)

            # Compute spend share of fatigued ads
            total_spend = sum(a["current_7d_spend"] for a in fatigued + healthy)
            fatigued_spend = sum(a["current_7d_spend"] for a in fatigued)
            fatigued_spend_share = (
                fatigued_spend / total_spend if total_spend > 0 else 0
            )

            # Recommendation logic from Matthias
            if fatigued_spend_share <= 0.30:
                action = "PAUSE_ALL — Fatigued ads are <= 30% of spend. Pause them and substitute with 1-2 fresh variants each."
            else:
                action = "SELECTIVE_PAUSE — Fatigued ads are > 30% of spend. Pause selectively to stay under 30% total spend disruption. Add 1-2 variants to remaining without pausing. Re-evaluate next cycle."

            await ctx.log(
                level="info",
                message=f"Fatigue check: {len(fatigued)} fatigued, {len(healthy)} healthy, {len(filtered)} filtered",
            )

            return {
                "summary": {
                    "total_ads_checked": len(fatigued) + len(healthy),
                    "fatigued_count": len(fatigued),
                    "healthy_count": len(healthy),
                    "filtered_count": len(filtered),
                    "fatigued_spend_share": round(fatigued_spend_share * 100, 1),
                    "recommendation": action,
                },
                "fatigued_ads": fatigued,
                "healthy_ads": healthy,
                "filtered_ads": filtered,
                "write_actions_available": {
                    "pause_ad": False,
                    "pause_ad_reason": "ad_group_ad_service NOT FIXED",
                    "create_ad_variant": False,
                    "create_ad_variant_reason": "ad_group_ad_service NOT FIXED",
                    "set_frequency_cap": True,
                },
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_creative_fatigue_tools(mcp: FastMCP[Any]) -> CreativeFatigueService:
    """Register creative fatigue workflow tools with the MCP server."""
    service = CreativeFatigueService()

    @mcp.tool()
    async def detect_creative_fatigue(
        ctx: Context,
        customer_id: str,
    ) -> Dict[str, Any]:
        """Detect creative fatigue by comparing last 7 days vs prior 7 days.

        Upper funnel triggers: high frequency, reach stall, CTR drop, CPM spike.
        Lower funnel triggers: CTR drop, CVR drop, CPA spike / ROAS drop, high frequency.
        2+ triggers = fatigued. Recommends pause/substitute based on spend share.

        Args:
            customer_id: Google Ads customer ID
        """
        return await service.detect_creative_fatigue(ctx, customer_id)

    return service
