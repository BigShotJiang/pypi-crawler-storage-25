"""Workflow orchestrators — high-level MCP tools that compose GAQL queries
with Matthias's business logic for the BlueAlpha strategy agent."""
