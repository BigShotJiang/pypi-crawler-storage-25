"""Test Monitoring v2 — workflow from test-monitoring-v2.md

Two-frequency monitoring for incrementality tests:
  High-frequency: entity status, geo leakage, change history audit
  Standard-frequency: budget pacing, impression delivery, auction volatility,
                       conversion sparsity, keyword mix shift, auction competition

All reads via GAQL ✅
All writes via fixed services ✅ (campaign_update_campaign for kill switch)

Alert priorities:
  P-0: Test halted (entity not ACTIVE)
  P-1: Config changed (change_history)
  P-2: Geo leakage (impressions in control region)
  P-3: Zero impressions (active but not serving)
  W-1: Budget pacing anomaly (< 70% or > 130%)
  W-2: Market volatility (CPM/CPC > 50% vs benchmark)
  W-3: Conversion sparsity (< 7 rolling 7d)
  W-4: Keyword mix shift
  W-5: Auction competition shift
"""

from typing import Any, Dict, List, Optional, Set

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.utils import format_customer_id, get_logger, safe_num, serialize_proto_message

logger = get_logger(__name__)


class TestMonitoringService:
    """Incrementality test integrity monitoring."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        response = self.service.search(customer_id=customer_id, query=query)
        return [serialize_proto_message(row) for row in response]

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    def _get_entity_status(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Check status of all entities in the test."""
        ids_clause = ", ".join(campaign_ids)
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                campaign.name,
                campaign.status,
                ad_group.id,
                ad_group.name,
                ad_group.status,
                ad_group_ad.ad.id,
                ad_group_ad.status,
                ad_group_ad.policy_summary.approval_status
            FROM ad_group_ad
            WHERE campaign.id IN ({ids_clause})
            """,
        )

    def _get_geo_report(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Geographic breakdown for leakage detection."""
        ids_clause = ", ".join(campaign_ids)
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                geographic_view.country_criterion_id,
                geographic_view.location_type,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros
            FROM geographic_view
            WHERE campaign.id IN ({ids_clause})
                AND segments.date DURING LAST_7_DAYS
            """,
        )

    def _get_change_history(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Change history for test campaigns."""
        ids_clause = ", ".join(
            f"'customers/{customer_id}/campaigns/{cid}'" for cid in campaign_ids
        )
        return self._query(
            customer_id,
            """
            SELECT
                change_event.change_date_time,
                change_event.change_resource_type,
                change_event.changed_fields,
                change_event.campaign,
                change_event.ad_group,
                change_event.user_email,
                change_event.client_type
            FROM change_event
            WHERE change_event.change_date_time DURING LAST_7_DAYS
            ORDER BY change_event.change_date_time DESC
            LIMIT 200
            """,
        )

    def _get_budget_pacing(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Daily spend for budget pacing check."""
        ids_clause = ", ".join(campaign_ids)
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                campaign.name,
                campaign_budget.amount_micros,
                segments.date,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions
            FROM campaign
            WHERE campaign.id IN ({ids_clause})
                AND segments.date DURING LAST_7_DAYS
            """,
        )

    def _get_keyword_performance(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Keyword-level metrics for mix shift detection."""
        ids_clause = ", ".join(campaign_ids)
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                ad_group_criterion.keyword.text,
                ad_group_criterion.keyword.match_type,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.search_impression_share
            FROM keyword_view
            WHERE campaign.id IN ({ids_clause})
                AND segments.date DURING LAST_7_DAYS
            ORDER BY metrics.impressions DESC
            LIMIT 50
            """,
        )

    def _get_cpm_cpc_metrics(
        self, customer_id: str, campaign_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """Daily CPM/CPC for volatility check."""
        ids_clause = ", ".join(campaign_ids)
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                segments.date,
                metrics.average_cpm,
                metrics.average_cpc,
                metrics.impressions,
                metrics.clicks
            FROM campaign
            WHERE campaign.id IN ({ids_clause})
                AND segments.date DURING LAST_14_DAYS
            """,
        )

    # ------------------------------------------------------------------
    # Check implementations
    # ------------------------------------------------------------------

    def _check_entity_status(
        self, entities: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """P-0: Any entity not ACTIVE."""
        alerts: List[Dict[str, Any]] = []
        for entity in entities:
            campaign = entity.get("campaign", {})
            ad_group = entity.get("ad_group", {})
            ad = entity.get("ad_group_ad", {})

            if campaign.get("status") != "ENABLED":
                alerts.append(
                    {
                        "priority": "P-0",
                        "type": "ENTITY_NOT_ACTIVE",
                        "entity_type": "CAMPAIGN",
                        "entity_id": str(campaign.get("id", "")),
                        "entity_name": campaign.get("name", ""),
                        "status": campaign.get("status"),
                        "message": f"CRITICAL: Campaign {campaign.get('name')} is {campaign.get('status')}. Test is NOT running.",
                    }
                )

            if ad_group.get("status") != "ENABLED":
                alerts.append(
                    {
                        "priority": "P-0",
                        "type": "ENTITY_NOT_ACTIVE",
                        "entity_type": "AD_GROUP",
                        "entity_id": str(ad_group.get("id", "")),
                        "entity_name": ad_group.get("name", ""),
                        "status": ad_group.get("status"),
                        "message": f"CRITICAL: Ad Group {ad_group.get('name')} is {ad_group.get('status')}.",
                    }
                )

            if ad.get("status") != "ENABLED":
                alerts.append(
                    {
                        "priority": "P-0",
                        "type": "ENTITY_NOT_ACTIVE",
                        "entity_type": "AD",
                        "entity_id": str(ad.get("ad", {}).get("id", "")),
                        "status": ad.get("status"),
                        "approval": ad.get("policy_summary", {}).get(
                            "approval_status", ""
                        ),
                        "message": f"CRITICAL: Ad {ad.get('ad', {}).get('id')} is {ad.get('status')}.",
                    }
                )

        # Deduplicate by entity_id
        seen: Set[str] = set()
        unique_alerts: List[Dict[str, Any]] = []
        for alert in alerts:
            key = f"{alert['entity_type']}_{alert['entity_id']}"
            if key not in seen:
                seen.add(key)
                unique_alerts.append(alert)

        return unique_alerts

    def _check_geo_leakage(
        self,
        geo_data: List[Dict[str, Any]],
        control_regions: List[str],
        test_regions: List[str],
    ) -> List[Dict[str, Any]]:
        """P-2: Impressions/spend in control regions."""
        alerts: List[Dict[str, Any]] = []
        for row in geo_data:
            geo = row.get("geographic_view", {})
            m = row.get("metrics", {})
            region_id = str(geo.get("country_criterion_id", ""))
            impressions = safe_num(m.get("impressions", 0))
            spend = safe_num(m.get("cost_micros", 0)) / 1_000_000

            if region_id in control_regions and (impressions > 0 or spend > 0):
                alerts.append(
                    {
                        "priority": "P-2",
                        "type": "GEO_LEAKAGE",
                        "region_id": region_id,
                        "impressions": impressions,
                        "spend": round(spend, 2),
                        "message": f"CRITICAL: {impressions} impressions in control region {region_id}. Test integrity compromised.",
                    }
                )

            if (
                test_regions
                and region_id not in test_regions
                and region_id not in control_regions
            ):
                if impressions > 0:
                    alerts.append(
                        {
                            "priority": "P-2",
                            "type": "UNKNOWN_REGION",
                            "region_id": region_id,
                            "impressions": impressions,
                            "message": f"CRITICAL: Impressions in unknown region {region_id} (not test or control).",
                        }
                    )

        return alerts

    def _check_change_history(
        self, changes: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """P-1: Critical changes to test entities."""
        alerts: List[Dict[str, Any]] = []
        critical_fields = {
            "status",
            "budget",
            "bid_strategy",
            "targeting",
            "geo",
            "audience",
            "creative",
        }

        for change in changes:
            event = change.get("change_event", {})
            changed_fields = event.get("changed_fields", "")
            resource_type = event.get("change_resource_type", "")

            # Check if any critical field was changed
            is_critical = any(
                f in (changed_fields or "").lower() for f in critical_fields
            )
            if is_critical:
                alerts.append(
                    {
                        "priority": "P-1",
                        "type": "CONFIG_CHANGED",
                        "resource_type": resource_type,
                        "changed_fields": changed_fields,
                        "user_email": event.get("user_email", "unknown"),
                        "timestamp": event.get("change_date_time", ""),
                        "message": f"CRITICAL: {event.get('user_email', 'unknown')} modified {changed_fields} on {resource_type}.",
                    }
                )

        return alerts

    def _check_budget_pacing(
        self, pacing_data: List[Dict[str, Any]], target_daily_budget: float
    ) -> List[Dict[str, Any]]:
        """W-1: Budget pacing anomaly (< 70% or > 130%)."""
        alerts: List[Dict[str, Any]] = []

        # Aggregate daily spend per campaign
        daily_totals: Dict[str, Dict[str, float]] = {}
        for row in pacing_data:
            date = row.get("segments", {}).get("date", "")
            m = row.get("metrics", {})
            daily_spend = safe_num(m.get("cost_micros", 0)) / 1_000_000
            daily_totals.setdefault(date, {"spend": 0})["spend"] += daily_spend

        for date, totals in sorted(daily_totals.items()):
            pacing_pct = (
                totals["spend"] / target_daily_budget if target_daily_budget > 0 else 0
            )
            if pacing_pct < 0.70:
                alerts.append(
                    {
                        "priority": "W-1",
                        "type": "UNDER_PACING",
                        "date": date,
                        "daily_spend": round(totals["spend"], 2),
                        "target": round(target_daily_budget, 2),
                        "pacing_pct": round(pacing_pct * 100, 1),
                        "message": f"WARNING: Spend ${totals['spend']:.2f} = {pacing_pct * 100:.0f}% of target ${target_daily_budget:.2f}. Test may be under-powered.",
                    }
                )
            elif pacing_pct > 1.30:
                alerts.append(
                    {
                        "priority": "W-1",
                        "type": "OVER_PACING",
                        "date": date,
                        "daily_spend": round(totals["spend"], 2),
                        "target": round(target_daily_budget, 2),
                        "pacing_pct": round(pacing_pct * 100, 1),
                        "message": f"WARNING: Spend ${totals['spend']:.2f} = {pacing_pct * 100:.0f}% of target. Over-pacing.",
                    }
                )

        return alerts

    def _check_conversion_sparsity(
        self, pacing_data: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """W-3: Rolling 7-day conversions < 7."""
        alerts: List[Dict[str, Any]] = []
        total_conversions = sum(
            safe_num(row.get("metrics", {}).get("conversions", 0))
            for row in pacing_data
        )

        if total_conversions < 3:
            alerts.append(
                {
                    "priority": "W-3",
                    "type": "CONVERSION_SPARSITY_CRITICAL",
                    "rolling_7d_conversions": round(total_conversions, 1),
                    "message": f"CRITICAL: Only {total_conversions:.0f} conversions in 7 days. Platform optimization severely limited.",
                }
            )
        elif total_conversions < 7:
            alerts.append(
                {
                    "priority": "W-3",
                    "type": "CONVERSION_SPARSITY_WARNING",
                    "rolling_7d_conversions": round(total_conversions, 1),
                    "message": f"WARNING: Only {total_conversions:.0f} conversions in 7 days. Platform optimization may be limited.",
                }
            )

        return alerts

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def monitor_test(
        self,
        ctx: Context,
        customer_id: str,
        campaign_ids: List[str],
        control_regions: Optional[List[str]] = None,
        test_regions: Optional[List[str]] = None,
        target_daily_budget: float = 0,
        benchmark_cpm: float = 0,
        benchmark_cpc: float = 0,
    ) -> Dict[str, Any]:
        """Run full test monitoring suite.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID
            campaign_ids: List of campaign IDs in the test
            control_regions: Geo criterion IDs for control regions (for leakage check)
            test_regions: Geo criterion IDs for test regions
            target_daily_budget: Expected daily budget for pacing check
            benchmark_cpm: Pre-test benchmark CPM for volatility check
            benchmark_cpc: Pre-test benchmark CPC for volatility check

        Returns:
            Test monitoring results with prioritized alerts.
        """
        customer_id = format_customer_id(customer_id)
        control_regions = control_regions or []
        test_regions = test_regions or []

        try:
            # Pull all data
            entities = self._get_entity_status(customer_id, campaign_ids)
            geo_data = (
                self._get_geo_report(customer_id, campaign_ids)
                if control_regions or test_regions
                else []
            )
            changes = self._get_change_history(customer_id, campaign_ids)
            pacing = self._get_budget_pacing(customer_id, campaign_ids)
            cpm_cpc = self._get_cpm_cpc_metrics(customer_id, campaign_ids)

            # Run all checks
            all_alerts: List[Dict[str, Any]] = []

            # High-frequency checks
            all_alerts.extend(self._check_entity_status(entities))
            if geo_data:
                all_alerts.extend(
                    self._check_geo_leakage(geo_data, control_regions, test_regions)
                )
            all_alerts.extend(self._check_change_history(changes))

            # Standard-frequency checks
            if target_daily_budget > 0:
                all_alerts.extend(
                    self._check_budget_pacing(pacing, target_daily_budget)
                )

            # Zero impressions check (P-3)
            for row in pacing:
                if safe_num(row.get("metrics", {}).get("impressions", 0)) == 0:
                    cid = str(row.get("campaign", {}).get("id", ""))
                    all_alerts.append(
                        {
                            "priority": "P-3",
                            "type": "ZERO_IMPRESSIONS",
                            "campaign_id": cid,
                            "date": row.get("segments", {}).get("date", ""),
                            "message": f"CRITICAL: Campaign {cid} is active but serving 0 impressions.",
                        }
                    )

            all_alerts.extend(self._check_conversion_sparsity(pacing))

            # Auction volatility (W-2)
            if benchmark_cpm > 0 or benchmark_cpc > 0:
                recent_cpm_total = 0.0
                recent_cpc_total = 0.0
                recent_days = 0
                for row in cpm_cpc:
                    m = row.get("metrics", {})
                    cpm = safe_num(m.get("average_cpm", 0))
                    cpc = safe_num(m.get("average_cpc", 0))
                    if cpm > 0 or cpc > 0:
                        recent_cpm_total += cpm / 1_000_000  # micros to dollars
                        recent_cpc_total += cpc / 1_000_000
                        recent_days += 1

                if recent_days > 0:
                    avg_cpm = recent_cpm_total / recent_days
                    avg_cpc = recent_cpc_total / recent_days
                    if (
                        benchmark_cpm > 0
                        and abs(avg_cpm - benchmark_cpm) / benchmark_cpm > 0.50
                    ):
                        all_alerts.append(
                            {
                                "priority": "W-2",
                                "type": "CPM_VOLATILITY",
                                "current_cpm": round(avg_cpm, 2),
                                "benchmark_cpm": round(benchmark_cpm, 2),
                                "deviation_pct": round(
                                    ((avg_cpm - benchmark_cpm) / benchmark_cpm) * 100, 1
                                ),
                                "message": f"WARNING: CPM ${avg_cpm:.2f} vs benchmark ${benchmark_cpm:.2f}. Market conditions shifted.",
                            }
                        )
                    if (
                        benchmark_cpc > 0
                        and abs(avg_cpc - benchmark_cpc) / benchmark_cpc > 0.50
                    ):
                        all_alerts.append(
                            {
                                "priority": "W-2",
                                "type": "CPC_VOLATILITY",
                                "current_cpc": round(avg_cpc, 2),
                                "benchmark_cpc": round(benchmark_cpc, 2),
                                "deviation_pct": round(
                                    ((avg_cpc - benchmark_cpc) / benchmark_cpc) * 100, 1
                                ),
                                "message": f"WARNING: CPC ${avg_cpc:.2f} vs benchmark ${benchmark_cpc:.2f}.",
                            }
                        )

            # Sort by priority
            priority_order = {
                "P-0": 0,
                "P-1": 1,
                "P-2": 2,
                "P-3": 3,
                "W-1": 4,
                "W-2": 5,
                "W-3": 6,
                "W-4": 7,
                "W-5": 8,
            }
            all_alerts.sort(key=lambda a: priority_order.get(a.get("priority", ""), 99))

            # Summary
            critical_count = len(
                [a for a in all_alerts if a["priority"].startswith("P-")]
            )
            warning_count = len(
                [a for a in all_alerts if a["priority"].startswith("W-")]
            )

            if critical_count > 0:
                status = "CRITICAL — Test integrity compromised. Immediate intervention required."
            elif warning_count > 0:
                status = (
                    "WARNING — Test running but anomalies detected. Monitor closely."
                )
            else:
                status = "HEALTHY — Test running as designed."

            await ctx.log(
                level="info",
                message=f"Test monitoring: {critical_count} critical, {warning_count} warnings",
            )

            return {
                "test_status": status,
                "critical_alerts": critical_count,
                "warnings": warning_count,
                "total_alerts": len(all_alerts),
                "alerts": all_alerts,
                "campaigns_monitored": campaign_ids,
                "write_actions_available": {
                    "pause_campaign_kill_switch": True,
                },
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_test_monitoring_tools(mcp: FastMCP[Any]) -> TestMonitoringService:
    """Register test monitoring workflow tools with the MCP server."""
    service = TestMonitoringService()

    @mcp.tool()
    async def monitor_incrementality_test(
        ctx: Context,
        customer_id: str,
        campaign_ids: List[str],
        control_regions: Optional[List[str]] = None,
        test_regions: Optional[List[str]] = None,
        target_daily_budget: float = 0,
        benchmark_cpm: float = 0,
        benchmark_cpc: float = 0,
    ) -> Dict[str, Any]:
        """Monitor incrementality test integrity with prioritized alerts.

        High-frequency checks: entity status (P-0), geo leakage (P-2), change history (P-1).
        Standard checks: budget pacing (W-1), zero impressions (P-3), CPM/CPC volatility (W-2),
        conversion sparsity (W-3).

        Args:
            customer_id: Google Ads customer ID
            campaign_ids: Campaign IDs included in the test
            control_regions: Geo criterion IDs for control/holdout regions
            test_regions: Geo criterion IDs for test regions
            target_daily_budget: Expected daily budget (for pacing check)
            benchmark_cpm: Pre-test benchmark CPM (for volatility check)
            benchmark_cpc: Pre-test benchmark CPC (for volatility check)
        """
        return await service.monitor_test(
            ctx,
            customer_id,
            campaign_ids,
            control_regions,
            test_regions,
            target_daily_budget,
            benchmark_cpm,
            benchmark_cpc,
        )

    return service
