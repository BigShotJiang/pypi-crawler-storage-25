"""Budget Reallocation — workflow from budget-reallocation.md

Three tiers: Very Simple, Simple, Intermediate.
Uses efficiency scoring + constraint checks (budget-limited, reach-limited, bid/quality-limited).

All reads via GAQL. Write actions:
  - budget_update_campaign_budget ✅ FIXED
  - campaign_update_campaign ✅ FIXED (for tCPA/tROAS adjustments)

Key rules:
  - Minimum data: 100+ clicks OR spend >= 1x target CPA in last 30d
  - Never change budget by > 30% in one pass
  - PMax uses 60-90 day windows
  - Cap moves at -30% to +30%
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.utils import format_customer_id, get_logger, safe_num, serialize_proto_message


def _date_range_clause(days: int) -> str:
    """Convert days to GAQL date filter. Uses DURING for 7/14/30, explicit range otherwise."""
    if days in (7, 14, 30):
        return f"segments.date DURING LAST_{days}_DAYS"
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    return f"segments.date BETWEEN '{start}' AND '{end}'"


logger = get_logger(__name__)


class BudgetReallocationService:
    """Orchestrates budget reallocation analysis and recommendations."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        response = self.service.search(customer_id=customer_id, query=query)
        return [serialize_proto_message(row) for row in response]

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    def _get_campaign_performance(
        self, customer_id: str, days: int = 30
    ) -> List[Dict[str, Any]]:
        """Campaign metrics + bidding + budget + impression share for last N days."""
        return self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.advertising_channel_sub_type,
                campaign.bidding_strategy_type,
                campaign.target_cpa.target_cpa_micros,
                campaign.maximize_conversions.target_cpa_micros,
                campaign.maximize_conversion_value.target_roas,
                campaign.target_roas.target_roas,
                campaign_budget.amount_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.conversions,
                metrics.conversions_value,
                metrics.search_impression_share,
                metrics.search_budget_lost_impression_share,
                metrics.search_rank_lost_impression_share
            FROM campaign
            WHERE campaign.status = 'ENABLED'
                AND {_date_range_clause(days)}
            """,
        )

    def _get_campaign_trend(self, customer_id: str) -> List[Dict[str, Any]]:
        """Daily metrics for last 14 days to compute 7d vs prior 7d trends."""
        return self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                segments.date,
                metrics.clicks,
                metrics.conversions,
                metrics.cost_micros,
                metrics.conversions_value,
                metrics.impressions
            FROM campaign
            WHERE campaign.status = 'ENABLED'
                AND segments.date DURING LAST_14_DAYS
            """,
        )

    # ------------------------------------------------------------------
    # Business logic
    # ------------------------------------------------------------------

    def _classify_bid_strategy(self, strategy: str) -> str:
        """Classify into Matthias's 4 categories."""
        if strategy in ("MAXIMIZE_CONVERSIONS", "MAXIMIZE_CONVERSION_VALUE"):
            return "MAXIMIZE"
        if strategy == "TARGET_CPA":
            return "TARGET_CPA"
        if strategy == "TARGET_ROAS":
            return "TARGET_ROAS"
        if strategy in ("TARGET_CPM", "MAXIMIZE_CLICKS"):
            return "CPM_AWARENESS"
        return "OTHER"

    def _get_target_metric(self, campaign: Dict[str, Any]) -> Dict[str, Any]:
        """Extract the target metric (CPA or ROAS) and its value."""
        camp = campaign.get("campaign", {})
        strategy = camp.get("bidding_strategy_type", "")

        # Target CPA
        target_cpa_micros = safe_num(
            camp.get("target_cpa", {}).get("target_cpa_micros", 0)
        ) or safe_num(camp.get("maximize_conversions", {}).get("target_cpa_micros", 0))
        if target_cpa_micros:
            return {"type": "CPA", "target": target_cpa_micros / 1_000_000}

        # Target ROAS
        target_roas = safe_num(
            camp.get("target_roas", {}).get("target_roas", 0)
        ) or safe_num(camp.get("maximize_conversion_value", {}).get("target_roas", 0))
        if target_roas:
            return {"type": "ROAS", "target": target_roas}

        return {"type": "NONE", "target": 0}

    def _check_constraints(self, campaign: Dict[str, Any]) -> Dict[str, Any]:
        """Check budget-limited, reach-limited, bid/quality-limited."""
        metrics = campaign.get("metrics", {})

        lost_budget = safe_num(metrics.get("search_budget_lost_impression_share", 0))
        lost_rank = safe_num(metrics.get("search_rank_lost_impression_share", 0))
        impr_share = safe_num(metrics.get("search_impression_share", 0))

        budget_limited = lost_budget >= 0.20
        bid_quality_limited = lost_rank >= 0.30
        reach_limited = impr_share < 0.30 and not budget_limited

        return {
            "budget_limited": budget_limited,
            "reach_limited": reach_limited,
            "bid_quality_limited": bid_quality_limited,
            "lost_budget_pct": round(lost_budget * 100, 1),
            "lost_rank_pct": round(lost_rank * 100, 1),
            "impression_share_pct": round(impr_share * 100, 1),
        }

    def _compute_recommendation(
        self,
        bid_category: str,
        constraints: Dict[str, Any],
        hitting_target: bool,
        target_info: Dict[str, Any],
        actual_metric: float,
    ) -> Dict[str, Any]:
        """Apply Matthias's decision matrix to produce budget recommendation."""
        bl = constraints["budget_limited"]
        rl = constraints["reach_limited"]
        bql = constraints["bid_quality_limited"]

        # Bid/quality limit blocks budget increases
        if bql:
            return {
                "budget_move": "0%",
                "action": "FIX_QUALITY — Bid/quality limiting. Recommend bid increase, quality fixes (ads/LP), or loosen tCPA gradually. Do NOT increase budget.",
                "reason": f"Search lost IS (rank) = {constraints['lost_rank_pct']}% >= 30%",
            }

        if bid_category == "MAXIMIZE":
            if bl and not rl:
                return {
                    "budget_move": "+10% to +30%",
                    "action": "INCREASE — Budget limited, increase budget",
                }
            if bl and rl:
                return {
                    "budget_move": "0%",
                    "action": "EXPAND_REACH — Budget + reach limited. Broaden geo, audiences, or inventory before adding budget.",
                }
            # Not budget limited
            if hitting_target:
                return {
                    "budget_move": "-10% to +15%",
                    "action": "CAUTIOUS — Not budget limited. If CPA/ROAS acceptable, increase slightly; otherwise fix creative/targeting.",
                }
            return {
                "budget_move": "-10% to +15%",
                "action": "OPTIMIZE — Fix creative and targeting before scaling.",
            }

        if bid_category == "TARGET_CPA":
            if bl and not rl and hitting_target:
                return {
                    "budget_move": "+10% to +25%",
                    "action": "INCREASE — Budget limited, hitting target. Increase without changing tCPA.",
                }
            if bl and not rl and not hitting_target:
                return {
                    "budget_move": "0% or -10%",
                    "action": "LOOSEN — Budget limited but missing target. Raise tCPA or fix CVR. Don't increase budget.",
                }
            if rl:
                return {
                    "budget_move": "0%",
                    "action": "EXPAND_REACH — Expand reach first. No point adding budget.",
                }
            if hitting_target:
                return {
                    "budget_move": "+10% to +20%",
                    "action": "INCREASE — Hitting target, room to scale.",
                }
            return {
                "budget_move": "-10% to -25%",
                "action": "REDUCE — Missing target. Reduce budget or raise tCPA.",
            }

        if bid_category == "TARGET_ROAS":
            if bl and not rl and hitting_target:
                return {
                    "budget_move": "+10% to +25%",
                    "action": "INCREASE — Budget limited, hitting ROAS. Increase without changing tROAS.",
                }
            if bl and not rl and not hitting_target:
                return {
                    "budget_move": "0% or -10%",
                    "action": "LOOSEN — Budget limited but missing ROAS. Lower tROAS if margin allows, or fix feed/creative/LP.",
                }
            if rl:
                return {
                    "budget_move": "0%",
                    "action": "EXPAND_REACH — Expand reach first.",
                }
            if hitting_target:
                return {
                    "budget_move": "+10% to +20%",
                    "action": "INCREASE — Hitting ROAS target, room to scale.",
                }
            return {
                "budget_move": "-10% to -25%",
                "action": "REDUCE — Missing ROAS target. Reduce or lower tROAS slightly.",
            }

        if bid_category == "CPM_AWARENESS":
            if hitting_target:
                return {
                    "budget_move": "0% to +10%",
                    "action": "MAINTAIN — Downstream lift observed. Maintain or scale slightly.",
                }
            return {
                "budget_move": "-10% to -25%",
                "action": "REDUCE — No downstream lift. Reduce or switch to tCPA once enough conversions exist.",
            }

        return {
            "budget_move": "0%",
            "action": "REVIEW — Unclassified bid strategy. Manual review needed.",
        }

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def analyze_budget_reallocation(
        self,
        ctx: Context,
        customer_id: str,
        channel_filter: Optional[str] = None,
        days: int = 30,
    ) -> List[Dict[str, Any]]:
        """Analyze budget reallocation opportunities across campaigns.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID
            channel_filter: Optional filter (SEARCH, DISPLAY, VIDEO, PERFORMANCE_MAX)
            days: Lookback window (30 standard, 60-90 for PMax)

        Returns:
            List of campaigns with budget recommendations and constraints.
        """
        customer_id = format_customer_id(customer_id)

        try:
            campaigns = self._get_campaign_performance(customer_id, days)

            results: List[Dict[str, Any]] = []
            for campaign in campaigns:
                camp = campaign.get("campaign", {})
                metrics = campaign.get("metrics", {})
                cid = str(camp.get("id", ""))
                name = camp.get("name", "")
                channel = camp.get("advertising_channel_type", "")
                strategy = camp.get("bidding_strategy_type", "")

                # Apply channel filter if provided
                if channel_filter and channel != channel_filter:
                    continue

                # Minimum data threshold
                clicks = safe_num(metrics.get("clicks", 0))
                cost = safe_num(metrics.get("cost_micros", 0)) / 1_000_000
                conversions = safe_num(metrics.get("conversions", 0))
                conv_value = safe_num(metrics.get("conversions_value", 0))

                target_info = self._get_target_metric(campaign)
                target_cpa = (
                    target_info["target"] if target_info["type"] == "CPA" else 0
                )
                # Fallback: avg CPA over period
                avg_cpa = cost / conversions if conversions > 0 else 0
                effective_cpa = target_cpa or avg_cpa

                if clicks < 100 and (effective_cpa == 0 or cost < effective_cpa):
                    results.append(
                        {
                            "campaign_id": cid,
                            "campaign_name": name,
                            "channel": channel,
                            "status": "INSUFFICIENT_DATA",
                            "reason": f"{clicks} clicks, ${cost:.2f} spend — below minimum threshold",
                            "recommendation": None,
                        }
                    )
                    continue

                # Classify and check constraints
                bid_category = self._classify_bid_strategy(strategy)
                constraints = self._check_constraints(campaign)

                # Check if hitting target
                hitting_target = False
                actual_metric = 0.0
                if target_info["type"] == "CPA" and conversions > 0:
                    actual_metric = cost / conversions
                    hitting_target = actual_metric <= target_info["target"]
                elif target_info["type"] == "ROAS" and cost > 0:
                    actual_metric = conv_value / cost
                    hitting_target = actual_metric >= target_info["target"]
                elif bid_category == "MAXIMIZE" and conversions > 0:
                    # For unconstrained strategies, use avg CPA/ROAS as reasonable
                    hitting_target = True  # No explicit target to miss

                recommendation = self._compute_recommendation(
                    bid_category,
                    constraints,
                    hitting_target,
                    target_info,
                    actual_metric,
                )

                daily_budget = (
                    safe_num(
                        campaign.get("campaign_budget", {}).get("amount_micros", 0)
                    )
                    / 1_000_000
                )

                results.append(
                    {
                        "campaign_id": cid,
                        "campaign_name": name,
                        "channel": channel,
                        "bid_category": bid_category,
                        "bidding_strategy": strategy,
                        "daily_budget": round(daily_budget, 2),
                        "spend_30d": round(cost, 2),
                        "conversions": round(conversions, 1),
                        "target": target_info,
                        "actual_metric": round(actual_metric, 2),
                        "hitting_target": hitting_target,
                        "constraints": constraints,
                        "recommendation": recommendation,
                    }
                )

            # Sort: budget-limited campaigns first (most actionable)
            results.sort(
                key=lambda r: (
                    r.get("status") == "INSUFFICIENT_DATA",
                    not r.get("constraints", {}).get("budget_limited", False),
                )
            )

            await ctx.log(
                level="info",
                message=f"Analyzed {len(results)} campaigns for budget reallocation",
            )
            return results

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_budget_reallocation_tools(mcp: FastMCP[Any]) -> BudgetReallocationService:
    """Register budget reallocation workflow tools with the MCP server."""
    service = BudgetReallocationService()

    @mcp.tool()
    async def analyze_budget_reallocation(
        ctx: Context,
        customer_id: str,
        channel_filter: Optional[str] = None,
        days: int = 30,
    ) -> List[Dict[str, Any]]:
        """Analyze budget reallocation opportunities using efficiency scoring + constraint checks.

        Classifies campaigns by bid strategy, checks budget/reach/quality constraints,
        and applies a decision matrix to recommend budget moves (-30% to +30%).

        Args:
            customer_id: Google Ads customer ID
            channel_filter: Optional — SEARCH, DISPLAY, VIDEO, PERFORMANCE_MAX
            days: Lookback window (default 30, use 60-90 for PMax)
        """
        return await service.analyze_budget_reallocation(
            ctx, customer_id, channel_filter, days
        )

    return service
