"""Bidding services."""
