"""Campaign service implementation using Google Ads SDK."""

from typing import Any, Dict, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v23.services.services.campaign_service import (
    CampaignServiceClient,
)
from google.protobuf import field_mask_pb2

from src.sdk_client import get_sdk_client, get_type
from src.utils import format_customer_id, get_logger, serialize_proto_message

logger = get_logger(__name__)


class CampaignService:
    """Campaign service for managing Google Ads campaigns."""

    def __init__(self) -> None:
        """Initialize the campaign service."""
        self._client: Optional[CampaignServiceClient] = None

    @property
    def client(self) -> CampaignServiceClient:
        """Get the campaign service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("CampaignService")
        assert self._client is not None
        return self._client

    async def create_campaign(
        self,
        ctx: Context,
        customer_id: str,
        name: str,
        budget_resource_name: str,
        advertising_channel_type: str = "SEARCH",
        status: str = "PAUSED",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        business_name: Optional[str] = None,
        logo_asset_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new campaign.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            name: Campaign name
            budget_resource_name: Resource name of the campaign budget
            advertising_channel_type: Type of advertising channel (SEARCH, DISPLAY, PERFORMANCE_MAX, etc.)
            status: Campaign status (ENABLED, PAUSED, REMOVED)
            start_date: Campaign start date (YYYY-MM-DD)
            end_date: Campaign end date (YYYY-MM-DD)
            business_name: Business name (required for PMax campaigns)
            logo_asset_id: Logo asset ID (for PMax campaigns)

        Returns:
            Created campaign details
        """
        try:
            customer_id = format_customer_id(customer_id)

            # Create a new campaign
            campaign = get_type("Campaign")
            campaign.name = name
            campaign.campaign_budget = budget_resource_name

            # Set advertising channel type
            channel_type_enum = getattr(
                get_type("AdvertisingChannelTypeEnum").AdvertisingChannelType,
                advertising_channel_type,
            )
            campaign.advertising_channel_type = channel_type_enum

            # Set status
            campaign.status = getattr(
                get_type("CampaignStatusEnum").CampaignStatus, status
            )

            is_pmax = advertising_channel_type == "PERFORMANCE_MAX"

            if is_pmax:
                # PMax campaigns use maximize_conversions, no network_settings or experiment_type
                maximize_conversions = get_type("MaximizeConversions")
                campaign.maximize_conversions = maximize_conversions
            else:
                # Set network settings for non-PMax campaigns
                campaign.network_settings.target_google_search = True
                campaign.network_settings.target_search_network = True
                campaign.network_settings.target_content_network = True
                campaign.network_settings.target_partner_search_network = False

                # Set campaign experiment type
                campaign.experiment_type = get_type(
                    "CampaignExperimentTypeEnum"
                ).CampaignExperimentType.BASE

                # Set manual CPC bidding strategy
                manual_cpc = get_type("ManualCpc")
                campaign.manual_cpc = manual_cpc

            # Set dates if provided (YYYY-MM-DD format)
            if start_date:
                campaign.start_date = start_date
            if end_date:
                campaign.end_date = end_date

            # Create the operation
            operation = get_type("CampaignOperation")
            operation.create = campaign

            # Make the API call
            response = self.client.mutate_campaigns(
                customer_id=customer_id, operations=[operation]
            )
            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to create campaign: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def update_campaign(
        self,
        ctx: Context,
        customer_id: str,
        campaign_id: str,
        name: Optional[str] = None,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        bidding_strategy: Optional[str] = None,
        target_cpa_micros: Optional[int] = None,
        target_roas: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Update an existing campaign.

        Args:
            ctx: FastMCP context
            customer_id: The customer ID
            campaign_id: The campaign ID to update
            name: New campaign name (optional)
            status: New campaign status (optional)
            start_date: New start date (optional)
            end_date: New end date (optional)
            bidding_strategy: Bidding strategy to set - MAXIMIZE_CONVERSIONS, TARGET_CPA, TARGET_ROAS (optional)
            target_cpa_micros: Target CPA in micros when using MAXIMIZE_CONVERSIONS or TARGET_CPA (optional)
            target_roas: Target ROAS value when using TARGET_ROAS (optional)

        Returns:
            Updated campaign details
        """
        try:
            customer_id = format_customer_id(customer_id)
            resource_name = f"customers/{customer_id}/campaigns/{campaign_id}"

            # Create campaign with resource name
            campaign = get_type("Campaign")
            campaign.resource_name = resource_name

            # Create update mask
            update_mask_fields = []

            if name is not None:
                campaign.name = name
                update_mask_fields.append("name")

            if status is not None:
                campaign.status = getattr(
                    get_type("CampaignStatusEnum").CampaignStatus, status
                )
                update_mask_fields.append("status")

            if start_date is not None:
                campaign.start_date = start_date
                update_mask_fields.append("start_date")

            if end_date is not None:
                campaign.end_date = end_date
                update_mask_fields.append("end_date")

            # Handle bidding strategy updates
            if bidding_strategy is not None:
                if bidding_strategy == "MAXIMIZE_CONVERSIONS":
                    maximize_conversions = get_type("MaximizeConversions")
                    if target_cpa_micros is not None:
                        maximize_conversions.target_cpa_micros = target_cpa_micros
                        update_mask_fields.append(
                            "maximize_conversions.target_cpa_micros"
                        )
                    else:
                        update_mask_fields.append("maximize_conversions")
                    campaign.maximize_conversions = maximize_conversions
                elif bidding_strategy == "TARGET_CPA":
                    target_cpa = get_type("TargetCpa")
                    if target_cpa_micros is not None:
                        target_cpa.target_cpa_micros = target_cpa_micros
                        update_mask_fields.append("target_cpa.target_cpa_micros")
                    else:
                        update_mask_fields.append("target_cpa")
                    campaign.target_cpa = target_cpa
                elif bidding_strategy == "TARGET_ROAS":
                    target_roas_obj = get_type("TargetRoas")
                    if target_roas is not None:
                        target_roas_obj.target_roas = target_roas
                        update_mask_fields.append("target_roas.target_roas")
                    else:
                        update_mask_fields.append("target_roas")
                    campaign.target_roas = target_roas_obj
                elif bidding_strategy == "MANUAL_CPC":
                    manual_cpc = get_type("ManualCpc")
                    campaign.manual_cpc = manual_cpc
                    update_mask_fields.append("manual_cpc")

            # Create the operation
            operation = get_type("CampaignOperation")
            operation.update = campaign
            operation.update_mask.CopyFrom(
                field_mask_pb2.FieldMask(paths=update_mask_fields)
            )

            # Make the API call
            response = self.client.mutate_campaigns(
                customer_id=customer_id, operations=[operation]
            )

            await ctx.log(
                level="info",
                message=f"Updated campaign {campaign_id} for customer {customer_id}",
            )

            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to update campaign: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
