"""Structured JSONL audit logger for all MCP tool invocations.

Writes one JSON object per line to an append-only file. Every tool call
(read, write, workflow) is logged with: tool name, arguments (redacted),
outcome, timing, guardrail tier, and customer ID extraction.

Environment variables:
    GOOGLE_ADS_AUDIT_LOG_PATH: Path to the JSONL audit log file.
        Default: ./audit.jsonl (relative to cwd).
        Set to empty string to disable file logging.
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from src.utils import get_logger

logger = get_logger(__name__)

# ── Configuration ────────────────────────────────────────────────────

_default_audit_path = str(Path.home() / ".bluealpha" / "google-ads-audit.jsonl")
AUDIT_LOG_PATH = os.environ.get("GOOGLE_ADS_AUDIT_LOG_PATH", _default_audit_path)

# ── Redaction ────────────────────────────────────────────────────────

# Precise denylist of credential field names. These are env vars consumed
# by the SDK client and should never appear in tool arguments — but if
# the tool schema is ever extended to accept them, they must not leak
# into the audit log. No regex or substring matching: both produce false
# positives on legitimate fields (campaign names, resource names, etc.).
SENSITIVE_KEYS = frozenset(
    {
        "developer_token",
        "client_secret",
        "refresh_token",
        "access_token",
        "json_key_file_path",
    }
)


def redact_args(args: dict[str, Any] | None) -> dict[str, Any]:
    """Redact sensitive fields from tool arguments.

    Uses a precise denylist of credential field names. All 54 known tool
    parameter names (customer_id, query, amount_micros, etc.) are
    non-sensitive and logged as-is for debuggability.
    """
    if not args:
        return {}

    redacted: dict[str, Any] = {}
    for key, value in args.items():
        if key.lower() in SENSITIVE_KEYS:
            redacted[key] = "[REDACTED]"
        elif isinstance(value, dict):
            redacted[key] = redact_args(value)
        elif isinstance(value, list) and value:
            redacted[key] = [
                redact_args(item) if isinstance(item, dict) else item for item in value
            ]
        else:
            redacted[key] = value

    return redacted


# ── Customer ID extraction ───────────────────────────────────────────


def extract_customer_id(args: dict[str, Any] | None) -> str | None:
    """Pull customer_id from tool arguments if present."""
    if not args:
        return None
    return args.get("customer_id")


# ── Server classification ───────────────────────────────────────────

# Prefix → server mapping for tool names
_WRITE_TOOLS = frozenset(
    {
        "create_campaign",
        "update_campaign",
        "create_campaign_budget",
        "update_campaign_budget",
        "create_ad_group",
        "update_ad_group",
        "create_ad",
        "update_ad_status",
        "add_keywords",
        "remove_keyword",
        "add_negative_keywords",
        "add_location_targeting",
        "add_language_targeting",
        "remove_campaign_criterion",
        "apply_recommendation",
        "dismiss_recommendation",
    }
)

_READ_TOOLS = frozenset(
    {
        "execute_query",
        "execute_query_stream",
        "list_accessible_customers",
        "generate_keyword_ideas",
        "suggest_geo_targets",
        "get_field_metadata",
        "validate_query_fields",
        "get_recommendations",
    }
)


def classify_tool(tool_name: str) -> str:
    """Classify a tool as read, write, workflow, or utility."""
    if tool_name in _WRITE_TOOLS:
        return "write"
    if tool_name in _READ_TOOLS:
        return "read"
    if tool_name == "check_connection_status":
        return "utility"
    return "workflow"


# ── Audit record builder ────────────────────────────────────────────


def build_record(
    *,
    tool_name: str,
    arguments: dict[str, Any] | None,
    outcome: str,
    elapsed_ms: int,
    error: str | None = None,
    risk_tier: int | None = None,
    guardrail_warnings: list[str] | None = None,
    result_summary: str | None = None,
) -> dict[str, Any]:
    """Build a structured audit record dict.

    This is the canonical shape of every line in the JSONL audit log.
    """
    record: dict[str, Any] = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_id": str(uuid.uuid4()),
        "tool": tool_name,
        "server": classify_tool(tool_name),
        "customer_id": extract_customer_id(arguments),
        "arguments": redact_args(arguments),
        "outcome": outcome,  # "success" | "error" | "blocked"
        "elapsed_ms": elapsed_ms,
    }

    if error:
        record["error"] = error[:500]  # Truncate long errors
    if risk_tier is not None:
        record["risk_tier"] = risk_tier
    if guardrail_warnings:
        record["guardrail_warnings"] = guardrail_warnings
    if result_summary:
        record["result_summary"] = result_summary[:200]

    return record


# ── JSONL writer ─────────────────────────────────────────────────────


class AuditLogger:
    """Append-only JSONL audit logger.

    Thread-safe via Python's logging module (which handles file locking).
    Each log line is a complete, self-contained JSON object.
    """

    def __init__(self, path: str | None = None) -> None:
        self._path = path if path is not None else AUDIT_LOG_PATH
        self._logger: logging.Logger | None = None

        if self._path:
            self._setup_logger()

    def _setup_logger(self) -> None:
        """Configure a dedicated Python logger that writes JSONL to file."""
        self._logger = logging.getLogger(f"audit.{id(self)}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        # Remove any existing handlers (in case of re-init)
        self._logger.handlers.clear()

        # Ensure parent directory exists
        log_path = Path(self._path)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(handler)

    @property
    def path(self) -> str:
        return self._path

    @property
    def enabled(self) -> bool:
        return self._logger is not None

    def log(self, record: dict[str, Any]) -> None:
        """Write a single audit record as one JSONL line."""
        if not self._logger:
            return
        try:
            self._logger.info(json.dumps(record, default=str))
        except Exception as e:
            logger.warning(f"Failed to write audit record: {e}")

    def close(self) -> None:
        """Flush and close the file handler."""
        if self._logger:
            for handler in self._logger.handlers:
                handler.close()


# ── Module-level singleton ───────────────────────────────────────────

_audit_logger: AuditLogger | None = None


def get_audit_logger() -> AuditLogger:
    """Get or create the singleton AuditLogger instance."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger()
        if _audit_logger.enabled:
            logger.info(f"Audit logging to: {_audit_logger.path}")
        else:
            logger.info("Audit file logging disabled (empty path)")
    return _audit_logger
