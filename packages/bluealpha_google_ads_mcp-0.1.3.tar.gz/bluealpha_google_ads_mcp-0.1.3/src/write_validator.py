"""Write operation validation and guardrails.

Validates budget changes, campaign updates, and other write operations
before execution. Inspired by BlueAlpha's sql_validator.py pattern:
tiered validation with warnings vs hard blocks.

Environment variables:
    GOOGLE_ADS_MCP_MAX_BUDGET_CHANGE_PCT: Max allowed budget change % (default: 30)
    GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD: Per-budget ceiling in USD
        (default: 0 = no limit). Blocks any single budget from exceeding
        this value. Not an aggregate account spend limit.
"""

import os
from dataclasses import dataclass, field

from src.utils import get_logger

logger = get_logger(__name__)

# ── Configuration ─────────────────────────────────────────────────────

MAX_BUDGET_CHANGE_PCT = float(
    os.environ.get("GOOGLE_ADS_MCP_MAX_BUDGET_CHANGE_PCT", "30")
)
ACCOUNT_DAILY_CEILING_USD = float(
    os.environ.get("GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD", "0")
)

# ── Constants ─────────────────────────────────────────────────────────

# Campaign statuses that are permanent (no API rollback)
DESTRUCTIVE_STATUSES = {"REMOVED"}

# Statuses that trigger immediate spend
SPEND_TRIGGERING_STATUSES = {"ENABLED"}

# Bidding strategies that reset learning phase on change
LEARNING_PHASE_STRATEGIES = {
    "TARGET_CPA",
    "TARGET_ROAS",
    "MAXIMIZE_CONVERSIONS",
    "MAXIMIZE_CONVERSION_VALUE",
}


# ── Result type ───────────────────────────────────────────────────────


@dataclass
class WriteValidationResult:
    """Result of a write operation validation check."""

    is_valid: bool
    risk_tier: int = 0  # 0=safe, 1=low, 2=medium, 3=high, 4=critical
    error: str | None = None
    warnings: list[str] = field(default_factory=list)


# ── Budget validation ─────────────────────────────────────────────────


def validate_budget_change(
    current_amount_micros: int,
    new_amount_micros: int,
) -> WriteValidationResult:
    """Validate a budget change against guardrails.

    Checks:
    - Account daily ceiling (hard block if exceeded)
    - Change percentage thresholds:
        >50%  → Tier 4 (critical: runaway spend risk)
        >30%  → Tier 3 (high: exceeds configured cap)
        >20%  → Tier 2 (medium: triggers Smart Bidding learning phase)
        ≤20%  → Tier 1 (low: normal operation)

    Args:
        current_amount_micros: Current budget in micros
        new_amount_micros: Proposed new budget in micros

    Returns:
        WriteValidationResult with risk tier and any warnings
    """
    current_usd = current_amount_micros / 1_000_000
    new_usd = new_amount_micros / 1_000_000

    # Hard block: account ceiling
    if ACCOUNT_DAILY_CEILING_USD > 0 and new_usd > ACCOUNT_DAILY_CEILING_USD:
        return WriteValidationResult(
            is_valid=False,
            risk_tier=4,
            error=(
                f"Budget ${new_usd:.2f}/day exceeds account ceiling "
                f"${ACCOUNT_DAILY_CEILING_USD:.2f}/day "
                f"(set GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD to adjust)"
            ),
        )

    # New budget creation (no baseline) — ceiling was already checked above,
    # percentage tiers are meaningless without a prior value to compare against.
    if current_usd == 0:
        return WriteValidationResult(is_valid=True, risk_tier=1)

    # Calculate change percentage
    change_pct = abs(new_usd - current_usd) / current_usd * 100

    direction = "increase" if new_usd > current_usd else "decrease"

    # Tier 4: >50% change — case studies show runaway spend
    if change_pct > 50:
        return WriteValidationResult(
            is_valid=True,
            risk_tier=4,
            warnings=[
                f"Budget {direction} of {change_pct:.0f}% "
                f"(${current_usd:.2f} → ${new_usd:.2f}). "
                f"Changes >50% have caused runaway spend in documented cases."
            ],
        )

    # Tier 3: exceeds configured cap
    if change_pct > MAX_BUDGET_CHANGE_PCT:
        return WriteValidationResult(
            is_valid=True,
            risk_tier=3,
            warnings=[
                f"Budget {direction} of {change_pct:.0f}% "
                f"(${current_usd:.2f} → ${new_usd:.2f}) "
                f"exceeds {MAX_BUDGET_CHANGE_PCT:.0f}% cap."
            ],
        )

    # Tier 2: >20% triggers Smart Bidding learning phase reset
    if change_pct > 20:
        return WriteValidationResult(
            is_valid=True,
            risk_tier=2,
            warnings=[
                f"Budget {direction} of {change_pct:.0f}% "
                f"(${current_usd:.2f} → ${new_usd:.2f}). "
                f"Changes >20% trigger Smart Bidding learning phase reset — "
                f"expect CPA/ROAS volatility for 1-2 weeks."
            ],
        )

    # Tier 1: normal operation
    return WriteValidationResult(is_valid=True, risk_tier=1)


# ── Campaign update validation ────────────────────────────────────────


def validate_campaign_update(
    status: str | None = None,
    bidding_strategy: str | None = None,
) -> WriteValidationResult:
    """Validate a campaign update operation.

    Checks:
    - REMOVED status is permanent (Tier 4)
    - ENABLED status starts spend immediately (Tier 2)
    - Bidding strategy changes trigger learning phase (Tier 3)

    Args:
        status: New campaign status (if being changed)
        bidding_strategy: New bidding strategy (if being changed)

    Returns:
        WriteValidationResult with risk tier and any warnings
    """
    warnings: list[str] = []
    tier = 1

    # Normalize to uppercase — callers may pass "removed" or "Enabled"
    status = status.upper() if status else status
    bidding_strategy = (
        bidding_strategy.upper() if bidding_strategy else bidding_strategy
    )

    if status and status in DESTRUCTIVE_STATUSES:
        return WriteValidationResult(
            is_valid=True,
            risk_tier=4,
            warnings=[
                "REMOVE is permanent — campaign cannot be restored via the API. "
                "All ad groups, ads, and keywords inside will also be removed."
            ],
        )

    if status and status in SPEND_TRIGGERING_STATUSES:
        tier = max(tier, 2)
        warnings.append("Enabling campaign — ad spend begins immediately.")

    if bidding_strategy and bidding_strategy in LEARNING_PHASE_STRATEGIES:
        tier = max(tier, 3)
        warnings.append(
            f"Switching to {bidding_strategy} triggers a learning phase — "
            f"expect CPA/ROAS volatility for 1-2 weeks."
        )

    return WriteValidationResult(is_valid=True, risk_tier=tier, warnings=warnings)
