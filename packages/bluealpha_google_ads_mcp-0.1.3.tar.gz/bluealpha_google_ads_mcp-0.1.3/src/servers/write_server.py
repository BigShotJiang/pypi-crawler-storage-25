"""Write server -- 16 tools for creating and modifying Google Ads entities.

Tools:
  Campaign:    create_campaign, update_campaign
  Budget:      create_campaign_budget, update_campaign_budget
  Ad Group:    create_ad_group, update_ad_group
  Ad:          create_ad, update_ad_status
  Keywords:    add_keywords, remove_keyword
  Targeting:   add_negative_keywords, add_location_targeting, add_language_targeting, remove_campaign_criterion
  Recommends:  apply_recommendation, dismiss_recommendation
"""

from typing import Any, Dict, List, Optional

from fastmcp import Context, FastMCP

from src.write_validator import validate_budget_change, validate_campaign_update
from src.services.ad_group.ad_group_ad_service import AdGroupAdService
from src.services.ad_group.ad_group_criterion_service import AdGroupCriterionService
from src.services.ad_group.ad_group_service import AdGroupService
from src.services.bidding.budget_service import BudgetService
from src.services.campaign.campaign_criterion_service import CampaignCriterionService
from src.services.campaign.campaign_service import CampaignService
from src.services.planning.recommendation_service import RecommendationService

write_server = FastMCP(name="write-service")

_campaign = CampaignService()
_budget = BudgetService()
_ad_group = AdGroupService()
_ad_group_ad = AdGroupAdService()
_ad_group_criterion = AdGroupCriterionService()
_campaign_criterion = CampaignCriterionService()
_recommendation = RecommendationService()


# ---------------------------------------------------------------------------
# Campaign CRUD
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def create_campaign(
    ctx: Context,
    customer_id: str,
    name: str,
    budget_resource_name: str,
    advertising_channel_type: str = "SEARCH",
    status: str = "PAUSED",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a new Google Ads campaign. Defaults to PAUSED to prevent accidental spend.

    Args:
        customer_id: The customer ID
        name: Campaign name
        budget_resource_name: Budget resource (e.g. "customers/123/campaignBudgets/456")
        advertising_channel_type: SEARCH, DISPLAY, SHOPPING, VIDEO, PERFORMANCE_MAX
        status: PAUSED (default) or ENABLED
        start_date: Optional start date (YYYY-MM-DD)
        end_date: Optional end date (YYYY-MM-DD)
    """
    return await _campaign.create_campaign(
        ctx=ctx,
        customer_id=customer_id,
        name=name,
        budget_resource_name=budget_resource_name,
        advertising_channel_type=advertising_channel_type,
        status=status,
        start_date=start_date,
        end_date=end_date,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
    }
)
async def update_campaign(
    ctx: Context,
    customer_id: str,
    campaign_id: str,
    name: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    bidding_strategy: Optional[str] = None,
    target_cpa_micros: Optional[int] = None,
    target_roas: Optional[float] = None,
) -> Dict[str, Any]:
    """Update an existing campaign.

    WARNING: Setting status=REMOVED is permanent (no API undo).
    Changing bidding strategy triggers a learning phase (1-2 weeks of CPA/ROAS volatility).

    Args:
        customer_id: The customer ID
        campaign_id: The campaign ID to update
        name: New campaign name
        status: ENABLED, PAUSED, or REMOVED
        start_date: New start date (YYYY-MM-DD)
        end_date: New end date (YYYY-MM-DD)
        bidding_strategy: MAXIMIZE_CONVERSIONS, TARGET_CPA, TARGET_ROAS, MANUAL_CPC
        target_cpa_micros: Target CPA in micros (for TARGET_CPA strategy)
        target_roas: Target ROAS (for TARGET_ROAS strategy)
    """
    # Validate campaign update risks
    validation = validate_campaign_update(
        status=status, bidding_strategy=bidding_strategy
    )
    if not validation.is_valid:
        return {"error": validation.error, "risk_tier": validation.risk_tier}
    if validation.warnings:
        for warning in validation.warnings:
            await ctx.log(level="warning", message=f"[GUARDRAIL] {warning}")

    return await _campaign.update_campaign(
        ctx=ctx,
        customer_id=customer_id,
        campaign_id=campaign_id,
        name=name,
        status=status,
        start_date=start_date,
        end_date=end_date,
        bidding_strategy=bidding_strategy,
        target_cpa_micros=target_cpa_micros,
        target_roas=target_roas,
    )


# ---------------------------------------------------------------------------
# Budget CRUD
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def create_campaign_budget(
    ctx: Context,
    customer_id: str,
    name: str,
    amount_micros: int,
    delivery_method: str = "STANDARD",
    explicitly_shared: bool = False,
) -> Dict[str, Any]:
    """Create a new campaign budget.

    Args:
        customer_id: The customer ID
        name: Budget name
        amount_micros: Daily budget in micros (e.g. 10000000 = $10)
        delivery_method: STANDARD or ACCELERATED
        explicitly_shared: Whether budget is shared across campaigns
    """
    # Validate against account ceiling
    validation = validate_budget_change(0, amount_micros)
    if not validation.is_valid:
        return {"error": validation.error, "risk_tier": validation.risk_tier}
    if validation.warnings:
        for warning in validation.warnings:
            await ctx.log(level="warning", message=f"[GUARDRAIL] {warning}")
    return await _budget.create_campaign_budget(
        ctx=ctx,
        customer_id=customer_id,
        name=name,
        amount_micros=amount_micros,
        delivery_method=delivery_method,
        explicitly_shared=explicitly_shared,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def update_campaign_budget(
    ctx: Context,
    customer_id: str,
    budget_id: str,
    name: Optional[str] = None,
    amount_micros: Optional[int] = None,
    current_amount_micros: Optional[int] = None,
    delivery_method: Optional[str] = None,
) -> Dict[str, Any]:
    """Update an existing campaign budget.

    Budget changes >20% trigger Smart Bidding learning phase reset.
    Changes >50% are flagged as critical risk.

    Args:
        customer_id: The customer ID
        budget_id: The budget ID to update
        name: New budget name
        amount_micros: New daily budget in micros
        current_amount_micros: Current budget in micros (for guardrail % check — read first via GAQL)
        delivery_method: STANDARD or ACCELERATED
    """
    # Validate budget change if both current and new are provided
    if amount_micros is not None and current_amount_micros is not None:
        validation = validate_budget_change(current_amount_micros, amount_micros)
        if not validation.is_valid:
            return {"error": validation.error, "risk_tier": validation.risk_tier}
        if validation.warnings:
            for warning in validation.warnings:
                await ctx.log(level="warning", message=f"[GUARDRAIL] {warning}")
    elif amount_micros is not None:
        # No current value provided — still check ceiling and warn on large values
        validation = validate_budget_change(0, amount_micros)
        if not validation.is_valid:
            return {"error": validation.error, "risk_tier": validation.risk_tier}
        if validation.warnings:
            for warning in validation.warnings:
                await ctx.log(level="warning", message=f"[GUARDRAIL] {warning}")

    return await _budget.update_campaign_budget(
        ctx=ctx,
        customer_id=customer_id,
        budget_id=budget_id,
        name=name,
        amount_micros=amount_micros,
        delivery_method=delivery_method,
    )


# ---------------------------------------------------------------------------
# Ad Group CRUD
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def create_ad_group(
    ctx: Context,
    customer_id: str,
    campaign_id: str,
    name: str,
    status: str = "ENABLED",
    type: str = "SEARCH_STANDARD",
    cpc_bid_micros: Optional[int] = None,
) -> Dict[str, Any]:
    """Create a new ad group within a campaign.

    Args:
        customer_id: The customer ID
        campaign_id: The parent campaign ID
        name: Ad group name
        status: ENABLED (default) or PAUSED
        type: SEARCH_STANDARD, DISPLAY_STANDARD, SHOPPING_PRODUCT_ADS, etc.
        cpc_bid_micros: Default CPC bid in micros
    """
    return await _ad_group.create_ad_group(
        ctx=ctx,
        customer_id=customer_id,
        campaign_id=campaign_id,
        name=name,
        status=status,
        type=type,
        cpc_bid_micros=cpc_bid_micros,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def update_ad_group(
    ctx: Context,
    customer_id: str,
    ad_group_id: str,
    name: Optional[str] = None,
    status: Optional[str] = None,
    cpc_bid_micros: Optional[int] = None,
) -> Dict[str, Any]:
    """Update an existing ad group.

    Args:
        customer_id: The customer ID
        ad_group_id: The ad group ID to update
        name: New ad group name
        status: ENABLED, PAUSED, or REMOVED
        cpc_bid_micros: New default CPC bid in micros
    """
    return await _ad_group.update_ad_group(
        ctx=ctx,
        customer_id=customer_id,
        ad_group_id=ad_group_id,
        name=name,
        status=status,
        cpc_bid_micros=cpc_bid_micros,
    )


# ---------------------------------------------------------------------------
# Ad CRUD
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def create_ad(
    ctx: Context,
    customer_id: str,
    ad_group_id: str,
    ad_resource_name: str,
    status: str = "ENABLED",
) -> Dict[str, Any]:
    """Create a new ad in an ad group.

    Args:
        customer_id: The customer ID
        ad_group_id: The parent ad group ID
        ad_resource_name: The ad resource name
        status: ENABLED (default) or PAUSED
    """
    return await _ad_group_ad.create_ad_group_ad(
        ctx=ctx,
        customer_id=customer_id,
        ad_group_id=ad_group_id,
        ad_resource_name=ad_resource_name,
        status=status,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def update_ad_status(
    ctx: Context,
    customer_id: str,
    ad_group_ad_resource_name: str,
    status: str,
) -> Dict[str, Any]:
    """Pause or enable an ad.

    Args:
        customer_id: The customer ID
        ad_group_ad_resource_name: The ad resource name to update
        status: ENABLED or PAUSED
    """
    return await _ad_group_ad.update_ad_group_ad_status(
        ctx=ctx,
        customer_id=customer_id,
        ad_group_ad_resource_name=ad_group_ad_resource_name,
        status=status,
    )


# ---------------------------------------------------------------------------
# Keyword management
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def add_keywords(
    ctx: Context,
    customer_id: str,
    ad_group_id: str,
    keywords: List[Dict[str, Any]],
    negative: bool = False,
) -> Dict[str, Any]:
    """Add keywords to an ad group.

    Args:
        customer_id: The customer ID
        ad_group_id: The ad group ID
        keywords: List of keyword dicts: [{"text": "...", "match_type": "BROAD|PHRASE|EXACT", "cpc_bid_micros": ...}]
        negative: If true, add as negative keywords
    """
    return await _ad_group_criterion.add_keywords(
        ctx=ctx,
        customer_id=customer_id,
        ad_group_id=ad_group_id,
        keywords=keywords,
        negative=negative,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
    }
)
async def remove_keyword(
    ctx: Context,
    customer_id: str,
    criterion_resource_name: str,
) -> Dict[str, Any]:
    """Remove a keyword from an ad group.

    Args:
        customer_id: The customer ID
        criterion_resource_name: The criterion resource name to remove
    """
    return await _ad_group_criterion.remove_ad_group_criterion(
        ctx=ctx,
        customer_id=customer_id,
        criterion_resource_name=criterion_resource_name,
    )


# ---------------------------------------------------------------------------
# Campaign targeting
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def add_negative_keywords(
    ctx: Context,
    customer_id: str,
    campaign_id: str,
    keywords: List[Dict[str, str]],
) -> Dict[str, Any]:
    """Add negative keywords to a campaign.

    Args:
        customer_id: The customer ID
        campaign_id: The campaign ID
        keywords: List of keyword dicts: [{"text": "...", "match_type": "BROAD|PHRASE|EXACT"}]
    """
    return await _campaign_criterion.add_negative_keyword_criteria(
        ctx=ctx,
        customer_id=customer_id,
        campaign_id=campaign_id,
        keywords=keywords,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def add_location_targeting(
    ctx: Context,
    customer_id: str,
    campaign_id: str,
    location_ids: List[str],
    negative: bool = False,
    bid_modifier: Optional[float] = None,
) -> Dict[str, Any]:
    """Add location targeting to a campaign.

    Use suggest_geo_targets to find location IDs first.

    Args:
        customer_id: The customer ID
        campaign_id: The campaign ID
        location_ids: Geo target constant IDs (e.g. ["2840"] for US)
        negative: If true, exclude these locations
        bid_modifier: Optional bid adjustment (e.g. 1.2 = +20%)
    """
    return await _campaign_criterion.add_location_criteria(
        ctx=ctx,
        customer_id=customer_id,
        campaign_id=campaign_id,
        location_ids=location_ids,
        negative=negative,
        bid_modifier=bid_modifier,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def add_language_targeting(
    ctx: Context,
    customer_id: str,
    campaign_id: str,
    language_ids: List[str],
) -> Dict[str, Any]:
    """Add language targeting to a campaign.

    Args:
        customer_id: The customer ID
        campaign_id: The campaign ID
        language_ids: Language constant IDs (e.g. ["1000"] for English)
    """
    return await _campaign_criterion.add_language_criteria(
        ctx=ctx,
        customer_id=customer_id,
        campaign_id=campaign_id,
        language_ids=language_ids,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
    }
)
async def remove_campaign_criterion(
    ctx: Context,
    customer_id: str,
    criterion_resource_name: str,
) -> Dict[str, Any]:
    """Remove a targeting criterion from a campaign.

    Args:
        customer_id: The customer ID
        criterion_resource_name: The criterion resource name to remove
    """
    return await _campaign_criterion.remove_campaign_criterion(
        ctx=ctx,
        customer_id=customer_id,
        criterion_resource_name=criterion_resource_name,
    )


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
    }
)
async def apply_recommendation(
    ctx: Context,
    customer_id: str,
    recommendation_resource_name: str,
) -> Dict[str, Any]:
    """Apply a Google Ads optimization recommendation.

    Use get_recommendations to discover available recommendations first.

    Args:
        customer_id: The customer ID
        recommendation_resource_name: The recommendation resource name
    """
    return await _recommendation.apply_recommendation(
        ctx=ctx,
        customer_id=customer_id,
        recommendation_resource_name=recommendation_resource_name,
    )


@write_server.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
    }
)
async def dismiss_recommendation(
    ctx: Context,
    customer_id: str,
    recommendation_resource_names: List[str],
) -> Dict[str, Any]:
    """Dismiss one or more Google Ads optimization recommendations.

    Args:
        customer_id: The customer ID
        recommendation_resource_names: List of recommendation resource names to dismiss
    """
    return await _recommendation.dismiss_recommendation(
        ctx=ctx,
        customer_id=customer_id,
        recommendation_resource_names=recommendation_resource_names,
    )
