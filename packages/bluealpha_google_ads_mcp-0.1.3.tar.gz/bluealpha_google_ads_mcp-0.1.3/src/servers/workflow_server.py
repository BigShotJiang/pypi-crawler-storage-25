"""Workflow server -- 7 analysis tools that compose GAQL queries with business logic.

These are BlueAlpha's differentiators -- no competitor has workflow-level tools.
Each tool runs multiple GAQL queries and applies scoring/classification logic.

Tools:
  audit_campaign_structure     Campaign scoring (0-110) across 6 dimensions
  diagnose_underspend          5-layer underspend diagnostic
  analyze_budget_reallocation  Efficiency scoring + constraint checks
  analyze_creatives            Creative scoring (efficiency, quality, engagement)
  detect_creative_fatigue      Week-over-week trigger comparison
  analyze_audiences            Audience efficiency scoring and classification
  monitor_incrementality_test  Test integrity monitoring with alert tiers
"""

from fastmcp import FastMCP

from src.services.workflows.audience_analysis_service import (
    register_audience_analysis_tools,
)
from src.services.workflows.budget_reallocation_service import (
    register_budget_reallocation_tools,
)
from src.services.workflows.campaign_audit_service import (
    register_campaign_audit_tools,
)
from src.services.workflows.creative_analysis_service import (
    register_creative_analysis_tools,
)
from src.services.workflows.creative_fatigue_service import (
    register_creative_fatigue_tools,
)
from src.services.workflows.test_monitoring_service import (
    register_test_monitoring_tools,
)
from src.services.workflows.underspend_diagnosis_service import (
    register_underspend_diagnosis_tools,
)

workflow_server = FastMCP(name="workflow-service")

register_campaign_audit_tools(workflow_server)
register_budget_reallocation_tools(workflow_server)
register_creative_analysis_tools(workflow_server)
register_creative_fatigue_tools(workflow_server)
register_underspend_diagnosis_tools(workflow_server)
register_audience_analysis_tools(workflow_server)
register_test_monitoring_tools(workflow_server)
