"""Google Ads SDK client for MCP server."""

import os
from typing import Optional, Dict, Any

import yaml
from google.ads.googleads.client import GoogleAdsClient

from src.utils import get_logger

logger = get_logger(__name__)


class GoogleAdsSdkClient:
    """SDK client for Google Ads with OAuth or service account authentication."""

    def __init__(self, config_path: str | None = None):
        """Initialize the SDK client with configuration.

        Auth priority: environment variables (OAuth) > YAML file (service account).
        Pass config_path only if using YAML-based service account auth.
        """
        self.config_path = config_path
        self._client: Optional[GoogleAdsClient] = None

    def _load_config_from_env(self) -> Optional[Dict[str, Any]]:
        """Try to load configuration from environment variables."""
        developer_token = os.environ.get("GOOGLE_ADS_DEVELOPER_TOKEN")
        if not developer_token:
            return None

        # Check for OAuth credentials in env
        client_id = os.environ.get("GOOGLE_ADS_CLIENT_ID")
        client_secret = os.environ.get("GOOGLE_ADS_CLIENT_SECRET")
        refresh_token = os.environ.get("GOOGLE_ADS_REFRESH_TOKEN")

        if client_id and client_secret and refresh_token:
            config: Dict[str, Any] = {
                "developer_token": developer_token,
                "client_id": client_id,
                "client_secret": client_secret,
                "refresh_token": refresh_token,
                "use_proto_plus": True,
            }
            login_customer_id = os.environ.get("GOOGLE_ADS_LOGIN_CUSTOMER_ID")
            if login_customer_id:
                config["login_customer_id"] = login_customer_id.replace("-", "")
            return config

        return None

    def _load_config_from_yaml(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        with open(self.config_path, "r") as f:
            config = yaml.safe_load(f)

        # Ensure required fields are present
        required_fields = ["developer_token", "json_key_file_path"]
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Missing required field in config: {field}")

        return config

    @property
    def client(self) -> GoogleAdsClient:
        """Get or create the Google Ads client."""
        if self._client is None:
            # Try env vars first, fall back to YAML
            env_config = self._load_config_from_env()

            if env_config:
                self._client = GoogleAdsClient.load_from_dict(env_config)
                logger.info(
                    "Google Ads SDK client initialized from environment variables"
                )
            elif self.config_path:
                config = self._load_config_from_yaml()
                client_config = {
                    "developer_token": config["developer_token"],
                    "use_proto_plus": True,
                    "json_key_file_path": config["json_key_file_path"],
                }
                if "login_customer_id" in config:
                    login_customer_id = str(config["login_customer_id"]).replace(
                        "-", ""
                    )
                    client_config["login_customer_id"] = login_customer_id
                self._client = GoogleAdsClient.load_from_dict(client_config)
                logger.info("Google Ads SDK client initialized from YAML config")
            else:
                raise RuntimeError(
                    "No Google Ads credentials found. Set GOOGLE_ADS_DEVELOPER_TOKEN + "
                    "OAuth env vars, or pass config_path for YAML-based service account auth."
                )

        return self._client

    def close(self) -> None:
        """Close the client and clean up resources."""
        if self._client:
            self._client = None
            logger.info("Google Ads SDK client closed")


# Global client instance
_sdk_client: Optional[GoogleAdsSdkClient] = None


def get_sdk_client() -> GoogleAdsSdkClient:
    """Get the global SDK client instance."""
    global _sdk_client
    if _sdk_client is None:
        raise RuntimeError("SDK client not initialized. Call set_sdk_client first.")
    return _sdk_client


def set_sdk_client(client: GoogleAdsSdkClient) -> None:
    """Set the global SDK client instance."""
    global _sdk_client
    _sdk_client = client


def get_type(type_name: str) -> type:
    """Get a proto-plus type class compatible with the current SDK version.

    SDK v29+ services use v23 types internally. Direct imports from
    google.ads.googleads.v23.* return v20 types which are incompatible.
    This function returns the correct version via GoogleAdsClient.get_type().
    """
    return get_sdk_client().client.get_type(type_name)
