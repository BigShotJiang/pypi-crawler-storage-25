# Google Ads MCP → Consumer Strategy Agent: Technical Strategy

**Date:** 2026-03-27
**Author:** BlueAlpha Engineering
**Status:** Draft — all claims should be verified against linked sources

---

## Table of Contents

1. [Current State](#1-current-state)
2. [API Sunset Timeline & Migration Plan](#2-api-sunset-timeline--migration-plan)
3. [defer_loading Architecture for Strategy Agent](#3-defer_loading-architecture-for-strategy-agent)
4. [Tool Tiering Strategy](#4-tool-tiering-strategy)
5. [Consumer Agent Architecture](#5-consumer-agent-architecture)
6. [OSS Release Plan](#6-oss-release-plan)
7. [Auth Architecture](#7-auth-architecture)
8. [Maintenance Cadence](#8-maintenance-cadence)
9. [Risk Register](#9-risk-register)
10. [Implementation Phases](#10-implementation-phases)

---

## 1. Current State

### What exists today

| Component | Value | Verify |
|-----------|-------|--------|
| MCP server location | `bluealpha-mcp/servers/google-ads/` | `ls` the directory |
| Installed SDK | `google-ads` **v27.0.0** (not v29.2 as AUDIT.md claims) | Run `uv pip show google-ads` or check `uv.lock` |
| SDK default API version | **v20** | Check `_VALID_API_VERSIONS` in installed `client.py` |
| Code imports from | `google.ads.googleads.v20.*` | `grep -r "v20" src/` |
| `get_type()` returns | **v20 types** (because SDK v27 defaults to v20) | Call `get_type("Campaign")` and check `__module__` |
| Total tools (mounted) | 64 read-only | Run server, count via `mcp.get_tools()` |
| Write servers | 19 servers commented out in `main.py` lines 148-167 | Read `main.py` |
| v20 sunset | **June 2026** (~3 months) | [Google sunset schedule](https://developers.google.com/google-ads/api/docs/sunset-dates) |

### Critical correction: no v20/v23 mismatch exists today

The AUDIT.md describes a v20-vs-v23 type mismatch — this would only apply if the SDK were upgraded to v29+. On SDK v27, everything is v20. The `get_type()` helper works correctly but returns v20 types, same as direct imports.

**This means the "fixed" vs "unfixed" service file distinction in AUDIT.md is misleading.** All 87 service files work identically on SDK v27 — they all use v20 types. The mismatch will appear when you upgrade the SDK to v29+ (which you must do before June 2026).

---

## 2. API Sunset Timeline & Migration Plan

### Version lifecycle

| Version | Released | Sunsets | Status |
|---------|----------|--------|--------|
| **v20** | Jun 4, 2025 | **June 2026** | Active — **3 months left** |
| v21 | Aug 6, 2025 | Aug 2026 | Active |
| v22 | Oct 15, 2025 | Oct 2026 | Active |
| **v23** | Jan 28, 2026 | **Feb 2027** | Active — **latest major, ~11 months left** |
| v23.1 | Feb 2026 | Feb 2027 | Active (minor) |
| v23.2 | Mar 2026 | Feb 2027 | Active (minor) |
| v24 | Apr 2026 (expected) | May 2027 | Not yet released |

**Source:** [Google Ads API sunset dates](https://developers.google.com/google-ads/api/docs/sunset-dates), [Release cadence blog post (Sep 2025)](https://ads-developers.googleblog.com/)

**Verify:** Check the sunset dates page directly — Google updates it periodically.

### What happens at sunset

After v20 sunset (June 2026):
- All gRPC/REST requests to `googleads.googleapis.com/v20/...` return errors (404 / NOT_FOUND)
- Python SDK v20 imports still work locally (they're generated protobuf code, not network calls)
- But any service client call that hits the v20 endpoint **fails at the network level**
- `get_type()` still works for type construction — execution fails

**Source:** Google sunset announcements consistently state "all v[X] API requests will begin to fail."

### Migration: what changes between v20 and v23

| Change Type | Examples | Impact |
|------------|---------|--------|
| Import paths | `v20` → `v23` in all imports | All 87 service files |
| Removed types | `CallAd`/`CallAdInfo` removed entirely | Low (we don't use call-only ads) |
| Field renames | `minimum_bugdet_amount_micros` → `minimum_budget_amount_micros` (typo fix) | Low |
| Metric renames | Several video metrics renamed with "trueview" prefix | Low (GAQL queries may need updating) |
| New required fields | `contains_eu_political_advertising` (enum, not bool) on Campaign | Already handled in campaign_service.py |
| Datetime vs date | Campaign start/end now require datetime, not date-only | Medium — check campaign creation code |
| Removed features | `url_expansion_opt_out` → `AssetAutomationType` settings | Low |

**Source:** [v23 release notes](https://developers.google.com/google-ads/api/docs/release-notes)

**Verify:** Read the full v23 release notes before migrating.

### Migration plan

**Target:** Migrate to SDK v30 + v23 imports by **May 2026** (1 month buffer before v20 sunset).

| Step | Action | Effort |
|------|--------|--------|
| 1 | Upgrade `pyproject.toml`: `google-ads>=30.0.0` | 5 min |
| 2 | Run `uv lock && uv sync` | 5 min |
| 3 | Find-and-replace `v20` → `v23` in all service imports | 1 hour (87 files, scripted) |
| 4 | Fix breaking changes (field renames, removed types, datetime fields) | 2-4 hours |
| 5 | Run `uv run pyright` to catch type errors | 30 min |
| 6 | Test all mounted tools against test account | 2-4 hours |
| 7 | Update AUDIT.md | 30 min |

**Alternative approach:** Instead of find-and-replace on import paths, switch ALL type creation to `get_type()` (which auto-resolves to the SDK's default version). This means:
- Service client imports: `v20` → `v23` (must change, these are version-specific)
- Type/enum/resource imports: remove entirely, use `get_type("TypeName")` everywhere
- This is more work upfront but makes future version bumps trivial (just upgrade SDK, no import changes)

**Verify:** After migration, run every mounted tool against test account `310-503-1374`.

---

## 3. defer_loading Architecture for Strategy Agent

### What defer_loading is

An Anthropic API parameter that tells Claude to **not load a tool definition into context until it's needed**. Claude gets a `tool_search_tool` instead, and searches for tools on demand.

**This is an Anthropic Messages API feature, NOT an MCP feature.** It works when your backend calls the Anthropic API directly. MCP clients (Claude Code, Cursor, Claude Desktop) load all tools at connection time — no deferral.

**Source:** [Anthropic tool search docs](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool)

### How it works (exact flow)

```
1. Your backend sends API request with:
   - 5 non-deferred tools (always in context)
   - 55 deferred tools (defer_loading: true)
   - 1 tool_search_tool (regex or BM25 variant)

2. Claude sees only:
   - 5 tool definitions (~5,000 tokens)
   - 1 tool_search_tool definition (~200 tokens)
   - Total: ~5,200 tokens (vs ~60,000 without defer_loading)

3. When Claude needs a deferred tool:
   - Claude calls tool_search_tool with a query
   - API server searches tool names + descriptions
   - Returns 3-5 matching tool_reference blocks
   - Tool definitions are expanded inline (not in system prompt)
   - Claude calls the discovered tool normally

4. On subsequent turns:
   - Previously discovered tools remain expanded
   - No re-searching needed for tools already found
```

### Token savings

| Scenario | Without defer_loading | With defer_loading | Reduction |
|----------|----------------------|-------------------|-----------|
| 60 tools (~1,000 tokens each) | ~60,000 tokens | ~5,200 tokens | **91%** |
| Anthropic's benchmark (58 tools) | ~55,000 tokens | ~3,500 tokens | **94%** |
| Worst case (134K tokens) | 134,000 tokens | ~8,700 tokens | **93%** |

**Source:** [Anthropic engineering blog — Advanced tool use](https://www.anthropic.com/engineering/advanced-tool-use)

**Verify:** Run a test request with and without defer_loading, compare `input_tokens` in the usage response.

### Tool search accuracy

| Model | Without tool search | With tool search |
|-------|-------------------|-----------------|
| Opus 4.0 | 49% | **74%** |
| Opus 4.5 | 79.5% | **88.1%** |

Independent testing (Arcade.dev, 4,027 tools): regex achieved 56% retrieval accuracy, BM25 achieved 64%. Tool naming quality is critical.

**Source:** [Arcade.dev analysis](https://arcade.dev/blog/anthropic-tool-search-claude-mcp-runtime)

### Two search variants

| Variant | Type value | Best for |
|---------|-----------|----------|
| **Regex** | `tool_search_tool_regex_20251119` | Well-named tools with consistent prefixes (e.g., `google_ads_*`) |
| **BM25** | `tool_search_tool_bm25_20251119` | Natural language queries, broader recall |

**Recommendation for BlueAlpha:** Use **regex** — our tools use consistent `search_`, `list_`, `create_`, `update_` prefixes with `google_ads` namespace. Regex will be more precise.

### Model support

| Model | Supported |
|-------|-----------|
| Claude Opus 4.0+ | Yes |
| Claude Sonnet 4.0+ | Yes |
| Claude Haiku (all) | **No** |
| Claude 3.x | **No** |

**Source:** [Anthropic tool search docs](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool)

**Verify:** Test with your target model before committing.

### Exact API request format

```python
import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=4096,
    messages=[{"role": "user", "content": "How are my campaigns performing?"}],
    tools=[
        # Tool search tool (always loaded, no defer_loading allowed on this)
        {
            "type": "tool_search_tool_regex_20251119",
            "name": "tool_search_tool_regex",
        },

        # === NON-DEFERRED: always in context (3-5 most used) ===
        {
            "name": "execute_query",
            "description": "Execute a GAQL query against Google Ads. Use for any reporting, metrics, or data retrieval.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string", "description": "Google Ads customer ID"},
                    "query": {"type": "string", "description": "GAQL query string"},
                },
                "required": ["customer_id", "query"],
            },
        },
        {
            "name": "search_campaigns",
            "description": "List all campaigns with status, budget, and type.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string"},
                    "include_removed": {"type": "boolean", "default": False},
                },
                "required": ["customer_id"],
            },
        },
        {
            "name": "audit_campaign_structure",
            "description": "Score campaign health 0-100 across structure, keywords, ads, extensions, targeting.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string"},
                    "campaign_id": {"type": "string"},
                },
                "required": ["customer_id"],
            },
        },
        {
            "name": "list_accessible_customers",
            "description": "List all Google Ads accounts accessible with current credentials.",
            "input_schema": {"type": "object", "properties": {}},
        },

        # === DEFERRED: loaded on demand via tool search ===
        {
            "name": "create_campaign",
            "description": "Create a new Google Ads search campaign with budget, bidding, and targeting.",
            "input_schema": { ... },
            "defer_loading": True,
        },
        {
            "name": "update_campaign_budget",
            "description": "Update daily budget for a campaign.",
            "input_schema": { ... },
            "defer_loading": True,
        },
        # ... all other tools with defer_loading: True
    ],
)
```

**Source:** [Anthropic SDK Python](https://github.com/anthropics/anthropic-sdk-python), SDK v0.75.0+ required for `defer_loading` support.

**Verify:** Check `anthropic` package version supports `defer_loading` parameter.

### Response format

```json
{
  "content": [
    {
      "type": "server_tool_use",
      "id": "srvtoolu_01ABC123",
      "name": "tool_search_tool_regex",
      "input": {"query": "create.*campaign"}
    },
    {
      "type": "tool_search_tool_result",
      "tool_use_id": "srvtoolu_01ABC123",
      "content": {
        "type": "tool_search_tool_search_result",
        "tool_references": [
          {"type": "tool_reference", "tool_name": "create_campaign"}
        ]
      }
    },
    {
      "type": "tool_use",
      "id": "toolu_01XYZ789",
      "name": "create_campaign",
      "input": {"customer_id": "1234567890", "name": "Spring Sale", ...}
    }
  ],
  "stop_reason": "tool_use"
}
```

**Key:** `server_tool_use` (with `srvtoolu_` prefix) = tool search execution (server-side). `tool_use` (with `toolu_` prefix) = actual tool call (your backend executes).

### Prompt caching interaction

- Deferred tools are stripped **before** cache key computation
- Adding/removing deferred tools does NOT invalidate your cache
- Discovered tools are appended inline in the conversation body, not in the system prompt prefix
- Place `cache_control: {"type": "ephemeral"}` on the last non-deferred tool to cache the prefix

**Source:** [Anthropic prompt caching + tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-use-with-prompt-caching)

**Verify:** Monitor cache hit rates in the usage response after implementing.

### Gotchas

| Gotcha | Detail |
|--------|--------|
| At least 1 non-deferred tool required | API returns 400 if all tools have `defer_loading: true` |
| Incompatible with `input_examples` | Cannot use few-shot tool use examples with tool search |
| No Haiku support | Sonnet 4.0+ and Opus 4.0+ only |
| All tools still sent in request | You still send all tool definitions in the API request — savings are in context window, not request size |
| Data retention | Server-side tool search stores tool catalog data per Anthropic's retention policy — NOT ZDR-eligible |
| No framework support | LangChain etc. don't support `defer_loading` natively — must use Anthropic SDK directly |
| Tool naming matters | Regex search works on names + descriptions. Use consistent prefixes (`google_ads_`, `campaign_`, etc.) |

---

## 4. Tool Tiering Strategy

### Tier 1: Always loaded (non-deferred) — 4-5 tools

These are in context on every request. Choose the tools that cover 80% of user intents:

| Tool | Why always loaded |
|------|-------------------|
| `execute_query` | Covers any GAQL query — the Swiss army knife |
| `search_campaigns` | First thing every user asks for |
| `audit_campaign_structure` | BlueAlpha's differentiator — campaign health scoring |
| `list_accessible_customers` | Needed to discover customer IDs |

### Tier 2: Deferred read tools — ~35 tools

Discovered on demand when the user asks specific questions:

| Category | Tools | Example trigger |
|----------|-------|----------------|
| Ad group reads | `search_ad_groups`, `list_ad_group_ads`, `list_ad_group_assets` | "Show me ad groups in campaign X" |
| Keyword reads | `search_keywords`, `get_keyword_ideas` | "What keywords am I bidding on?" |
| Audience/list reads | `list_audiences`, `list_user_lists`, `list_custom_audiences` | "What audiences do I have?" |
| Conversion reads | `list_conversion_actions`, `list_conversion_value_rules` | "What conversions am I tracking?" |
| Budget/bidding reads | `list_bidding_strategies`, `list_bidding_data_exclusions` | "What bidding strategy am I using?" |
| Workflow analysis | `analyze_budget_reallocation`, `analyze_creatives`, `detect_creative_fatigue`, `diagnose_underspend`, `analyze_audiences`, `monitor_incrementality_test` | "Where should I move budget?", "Are my ads stale?" |
| Metadata | `get_field_metadata`, `search_fields`, `get_resource_fields`, `validate_query_fields` | Agent self-use for query building |
| Geo targeting | `search_geo_targets`, `suggest_geo_targets_by_location`, `suggest_geo_targets_by_address` | "Target California" |
| Labels/assets | `list_labels`, `list_campaign_assets`, `search_assets`, `list_ad_group_labels`, etc. | "What labels do I have?" |
| Account info | `list_billing_setups`, `list_payments_accounts`, `list_user_access`, etc. | "Who has access to my account?" |

### Tier 3: Deferred write tools — ~20 tools (approval-gated)

Only discovered when the user explicitly wants to make changes:

| Category | Tools | Example trigger |
|----------|-------|----------------|
| Campaign CRUD | `create_campaign`, `update_campaign` | "Create a new campaign" |
| Budget CRUD | `create_campaign_budget`, `update_campaign_budget` | "Change my budget to $50/day" |
| Ad group CRUD | `create_ad_group`, `update_ad_group` | "Add an ad group" |
| Keyword CRUD | `add_keywords`, `update_keyword_bid`, `remove_keyword` | "Add these keywords" |
| Ad CRUD | `create_responsive_search_ad`, `update_ad_status` | "Create a new ad", "Pause this ad" |
| Targeting | `add_location_criteria`, `add_language_criteria`, `add_negative_keyword_criteria` | "Target New York", "Exclude 'free'" |

### Tier 4: Full catalog — remaining tools

Only in the `full` profile for power users. Not loaded in the consumer agent by default.

---

## 5. Consumer Agent Architecture

### System design

```
┌─────────────────────────────────────────────────────┐
│                   User's Browser                     │
│                  (BlueAlpha Web App)                  │
└──────────────────────┬──────────────────────────────┘
                       │ HTTPS
                       ▼
┌─────────────────────────────────────────────────────┐
│              BlueAlpha Backend (FastAPI)              │
│                                                      │
│  ┌──────────────┐  ┌─────────────────────────────┐  │
│  │ Auth Layer    │  │ Conversation Manager         │  │
│  │               │  │                              │  │
│  │ - OAuth store │  │ - Message history            │  │
│  │ - Per-user    │  │ - Anthropic API calls        │  │
│  │   refresh     │  │ - defer_loading config       │  │
│  │   tokens      │  │ - Tool result handling       │  │
│  │ - AES-256     │  │                              │  │
│  └──────┬───────┘  └──────────┬──────────────────┘  │
│         │                     │                      │
│         │           ┌────────▼────────────────────┐  │
│         │           │ Tool Execution Layer         │  │
│         │           │                              │  │
│         │           │ - Same functions as MCP      │  │
│         │           │ - Per-user credential swap   │  │
│         └──────────►│ - Write approval gate        │  │
│                     │ - Audit logging              │  │
│                     └────────┬────────────────────┘  │
└──────────────────────────────┼──────────────────────┘
                               │ gRPC
                               ▼
                    ┌──────────────────────┐
                    │   Google Ads API      │
                    │   (v23+)              │
                    └──────────────────────┘
```

### Backend pseudocode

```python
from anthropic import Anthropic
from google.ads.googleads.client import GoogleAdsClient

anthropic_client = Anthropic()

ALWAYS_LOADED_TOOLS = [
    {"name": "execute_query", "description": "...", "input_schema": {...}},
    {"name": "search_campaigns", "description": "...", "input_schema": {...}},
    {"name": "audit_campaign_structure", "description": "...", "input_schema": {...}},
    {"name": "list_accessible_customers", "description": "...", "input_schema": {...}},
]

DEFERRED_TOOLS = [
    {"name": "create_campaign", ..., "defer_loading": True},
    {"name": "update_campaign_budget", ..., "defer_loading": True},
    {"name": "analyze_budget_reallocation", ..., "defer_loading": True},
    # ... all other tools
]

TOOL_SEARCH = {
    "type": "tool_search_tool_regex_20251119",
    "name": "tool_search_tool_regex",
}

WRITE_TOOLS = {
    "create_campaign", "update_campaign", "create_campaign_budget",
    "update_campaign_budget", "create_ad_group", "add_keywords",
    "create_responsive_search_ad", "update_ad_status", "remove_keyword",
    "add_location_criteria", "add_language_criteria",
    "add_negative_keyword_criteria",
}


async def chat(user_id: str, message: str, conversation_history: list):
    # 1. Get user's Google Ads credentials
    user_creds = db.get_google_ads_credentials(user_id)
    google_client = build_google_client(user_creds)

    # 2. Build tool list
    all_tools = [TOOL_SEARCH] + ALWAYS_LOADED_TOOLS + DEFERRED_TOOLS

    # 3. Call Anthropic API
    messages = conversation_history + [{"role": "user", "content": message}]
    response = anthropic_client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        system="You are BlueAlpha's strategy agent for Google Ads...",
        messages=messages,
        tools=all_tools,
    )

    # 4. Tool execution loop
    while response.stop_reason == "tool_use":
        tool_results = []

        for block in response.content:
            if block.type == "tool_use":
                tool_name = block.name

                # Write approval gate
                if tool_name in WRITE_TOOLS:
                    # Return to user for confirmation before executing
                    return {
                        "type": "approval_required",
                        "tool": tool_name,
                        "args": block.input,
                        "message": response.content,  # includes Claude's explanation
                    }

                # Execute read tool
                result = execute_tool(tool_name, block.input, google_client)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result),
                })

                # Audit log
                log_tool_call(user_id, tool_name, block.input)

        # Send results back to Claude
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})

        response = anthropic_client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4096,
            messages=messages,
            tools=all_tools,
        )

    return {"type": "response", "message": response.content}
```

**Verify:** This is pseudocode — the exact Anthropic SDK response structure should be verified against the [SDK docs](https://github.com/anthropics/anthropic-sdk-python).

### MCP vs direct API — when to use which

| Deployment | Protocol | defer_loading | Use case |
|-----------|----------|---------------|----------|
| OSS (Claude Code / Cursor / Claude Desktop) | MCP (stdio) | **No** — MCP loads all tools at connection | Developers, your boss |
| Consumer strategy agent | Anthropic Messages API | **Yes** | End users via BlueAlpha web app |
| Hosted MCP for external clients | MCP (SSE/HTTP) | **No** — MCP doesn't support it | If you ever want to offer a hosted MCP endpoint |

**Key insight:** The same Python tool functions power both deployments. The MCP server wraps them in MCP protocol. The consumer agent wraps them in Anthropic API tool definitions. Same code, different entry points.

---

## 6. OSS Release Plan

### Tool profile system

```
TOOL_PROFILE=basic      → ~15 tools (read-only monitoring)
TOOL_PROFILE=standard   → ~40-45 tools (read + core write)  ← default
TOOL_PROFILE=full       → all tools
```

Implemented via FastMCP tag-based filtering or conditional `mcp.mount()` in `main.py`.

### What ships publicly

- Source code on GitHub (MIT license, attribution to promobase)
- `.env.example` with blank credentials
- Setup docs (GCP project → OAuth → dev token → refresh token → env vars)
- No PyPI initially — users clone and run with `uv`
- Workflow analysis tools (BlueAlpha's differentiator) included — they're the hook

### What doesn't ship

- `.env` with real credentials (gitignored)
- BlueAlpha's dev token, client ID, client secret, refresh token
- Consumer agent backend code
- Anthropic API integration code

### Credential model

Every user brings their own:
1. Google Ads developer token (from their MCC's API Center)
2. OAuth client ID + secret (from their GCP project)
3. Refresh token (via OAuth flow)
4. Login customer ID (optional, for MCC users)

**Source:** This is the same model used by [Google's official MCP server](https://github.com/googleads/google-ads-mcp), [Opteo/google-ads-api](https://github.com/Opteo/google-ads-api), and all other OSS Google Ads tools.

---

## 7. Auth Architecture

### OSS (current, Claude Desktop for your boss)

```
.env file (local, gitignored):
  GOOGLE_ADS_DEVELOPER_TOKEN=xxx     ← BlueAlpha's, shared privately
  GOOGLE_ADS_CLIENT_ID=xxx           ← BlueAlpha's GCP project
  GOOGLE_ADS_CLIENT_SECRET=xxx       ← BlueAlpha's GCP project
  GOOGLE_ADS_REFRESH_TOKEN=xxx       ← Per-person (boss generates his own)
  GOOGLE_ADS_LOGIN_CUSTOMER_ID=xxx   ← BlueAlpha's MCC
```

### Consumer agent (future)

```
BlueAlpha's backend:
  BLUEALPHA_DEV_TOKEN=xxx            ← one dev token for all users
  BLUEALPHA_CLIENT_ID=xxx            ← one OAuth Web App client
  BLUEALPHA_CLIENT_SECRET=xxx        ← one OAuth Web App client

Per-user (stored encrypted in DB):
  user_refresh_token=xxx             ← unique per user, from OAuth consent flow
  user_customer_ids=[...]            ← discovered via list_accessible_customers
```

### Access level requirements

| Deployment | Access Level | Daily Ops Limit | Sufficient? |
|-----------|-------------|-----------------|-------------|
| OSS | User's own (any) | User's own | Yes — their problem |
| Boss on Claude Desktop | BlueAlpha's Basic | 15,000/day | Yes — 1 user |
| Consumer agent (10 users) | BlueAlpha's Basic | 15,000/day shared | Maybe |
| Consumer agent (50+ users) | **BlueAlpha's Standard** | **Unlimited** | Required |

**Action:** Apply for Standard access now. Review takes ~10 business days + current backlog.

**Source:** [Google Ads API access levels](https://developers.google.com/google-ads/api/docs/api-policy/access-levels)

**Verify:** Check your current access level at Google Ads > Tools & Settings > API Center.

---

## 8. Maintenance Cadence

### Google Ads API release cycle (new as of Sep 2025)

| Month | Release | Type |
|-------|---------|------|
| January | v23 | Major |
| February | v23.1 | Minor (backward-compatible) |
| March | v23.2 | Minor (backward-compatible) |
| **April** | **v24** | **Major (potential breaking changes)** |
| May | v24.1 | Minor |
| June | v24.2 | Minor |
| **July** | **v25** | **Major** |
| August | v25.1 | Minor |
| September | v25.2 | Minor |
| **October** | **v26** | **Major** |
| November | v26.1 | Minor |
| December | (holiday freeze) | None |

**Source:** [More frequent releases blog post (Sep 2025)](https://ads-developers.googleblog.com/)

### Maintenance schedule

| When | What | Effort |
|------|------|--------|
| **May 2026** (URGENT) | Migrate v20 → v23 before June sunset | 1-2 days |
| **Quarterly** (Apr, Jul, Oct) | Review major version release notes for breaking changes | 2 hours |
| **Annually** | Upgrade to latest major version before current version sunsets | 1-2 days |
| **As needed** | Fix any tools broken by API changes | Varies |

### Monitoring strategy (post-OSS-launch)

Track which tools are called (opt-in telemetry):

```python
import logging
logger = logging.getLogger("tool_usage")

# In each tool execution
logger.info(f"tool_call tool={tool_name} profile={profile}")
```

After 6 months, tools below a usage threshold:
1. Move to `TOOL_PROFILE=full` only
2. Mark as "community-maintained" in docs
3. Skip during version migration (don't fix if nobody uses them)

---

## 9. Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| v20 sunset before migration complete | Medium (3 months) | Critical — all API calls fail | Start migration in April 2026, 1 month buffer |
| Google rejects Standard access application | Low | Blocks consumer agent at scale | Apply now, have backup plan (per-user tokens) |
| Tool search accuracy too low for 60+ tools | Medium | Users get wrong tools, bad UX | Good tool naming, test with real queries, fallback to BM25 |
| Google bans dev token for policy violation | Very low | Service down | Follow ToS strictly, no credential embedding, proper RMF |
| Anthropic changes defer_loading API | Low | Backend code needs updating | Pin SDK version, monitor changelog |
| Rate limiting under multi-user load | Medium | Degraded service | Implement per-user request queuing + circuit breakers |
| OAuth token expiry/revocation | Medium | Individual user loses access | Automatic token refresh, graceful error handling, re-auth flow |

---

## 10. Implementation Phases

### Phase 0: Now → April 2026 (Ship OSS + boss access)

- [x] Copy MCP server to `bluealpha-mcp/servers/google-ads/`
- [ ] Share `.env` credentials with boss privately
- [ ] Boss configures Claude Desktop
- [ ] Verify all 64 read tools work via Claude Desktop
- [ ] Submit Standard access application to Google
- [ ] Prepare OSS repo (README, setup guide, license attribution)

### Phase 1: April–May 2026 (v20 → v23 migration)

- [ ] Read v23 release notes in full
- [ ] Upgrade SDK: `google-ads>=30.0.0`
- [ ] Migrate all service imports from v20 → v23
- [ ] Switch all type creation to `get_type()` (future-proof)
- [ ] Fix breaking changes (field renames, datetime fields)
- [ ] Test all mounted tools against test account
- [ ] Update AUDIT.md

### Phase 2: May–June 2026 (tool profiles + OSS launch)

- [ ] Implement `TOOL_PROFILE` env var with tag-based filtering
- [ ] Define `basic`, `standard`, `full` profiles
- [ ] Write setup documentation
- [ ] Publish to GitHub
- [ ] Add opt-in usage telemetry

### Phase 3: Q3 2026 (consumer agent backend)

- [ ] Build FastAPI backend with Anthropic API integration
- [ ] Implement `defer_loading` with 4-5 always-loaded tools
- [ ] Build OAuth Web App consent flow
- [ ] Per-user credential storage (encrypted)
- [ ] Write approval gate for write operations
- [ ] Audit logging
- [ ] Deploy to Cloud Run
- [ ] Standard access should be approved by now

### Phase 4: Q3–Q4 2026 (multi-channel expansion)

- [ ] Add Facebook/Meta Ads MCP server (fork promobase/facebook-business-mcp)
- [ ] Add TikTok, LinkedIn MCP servers (or via Composio for Tier 3)
- [ ] Unified tool namespace across platforms
- [ ] Cross-platform strategy agent reasoning

---

## Appendix: Key Sources

| Topic | Source | URL |
|-------|--------|-----|
| defer_loading docs | Anthropic | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool |
| Tool reference docs | Anthropic | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-reference |
| Prompt caching + tools | Anthropic | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-use-with-prompt-caching |
| Anthropic SDK Python | GitHub | https://github.com/anthropics/anthropic-sdk-python |
| Advanced tool use blog | Anthropic | https://www.anthropic.com/engineering/advanced-tool-use |
| Google Ads API sunset dates | Google | https://developers.google.com/google-ads/api/docs/sunset-dates |
| Google Ads API release notes | Google | https://developers.google.com/google-ads/api/docs/release-notes |
| Google Ads API access levels | Google | https://developers.google.com/google-ads/api/docs/api-policy/access-levels |
| Google official MCP server | GitHub | https://github.com/googleads/google-ads-mcp |
| Release cadence change | Google blog | https://ads-developers.googleblog.com/ |
| Tool count degradation | Speakeasy | https://www.speakeasy.com/mcp/tool-design/less-is-more |
| Tool search accuracy | Arcade.dev | https://arcade.dev/blog/anthropic-tool-search-claude-mcp-runtime |
| Block's MCP playbook | Block eng blog | https://engineering.block.xyz/blog/blocks-playbook-for-designing-mcp-servers |
| Google Ads API secure credentials | Google | https://developers.google.com/google-ads/api/docs/productionize/secure-credentials |
| Google APIs ToS | Google | https://developers.google.com/terms |
