"""Tests for the audit trail system: JSONL logger, redaction, and middleware.

Three layers:
  1. Pure unit tests for audit.py (redaction, classification, record building)
  2. AuditLogger file I/O (writes real JSONL, reads it back)
  3. Middleware integration (verifies the full on_call_tool pipeline)
"""

import json
import os
from unittest.mock import AsyncMock

import mcp.types as mt
import pytest

from src.audit import (
    AuditLogger,
    build_record,
    classify_tool,
    extract_customer_id,
    redact_args,
)
from src.middleware.audit_middleware import (
    AuditMiddleware,
    _extract_outcome,
    _summarize_result,
)


# ---------------------------------------------------------------------------
# 1. Redaction
# ---------------------------------------------------------------------------


class TestRedaction:
    def test_credential_keys_redacted(self) -> None:
        args = {
            "customer_id": "123",
            "developer_token": "abc123secret",
            "refresh_token": "long-token-value",
            "access_token": "ya29.something",
            "client_secret": "GOCSPX-abc",
            "json_key_file_path": "/path/to/key.json",
        }
        result = redact_args(args)
        assert result["customer_id"] == "123"
        assert result["developer_token"] == "[REDACTED]"
        assert result["refresh_token"] == "[REDACTED]"
        assert result["access_token"] == "[REDACTED]"
        assert result["client_secret"] == "[REDACTED]"
        assert result["json_key_file_path"] == "[REDACTED]"

    def test_non_secret_keys_not_redacted(self) -> None:
        """Fields that look sensitive but aren't should be preserved."""
        args = {
            "client_id": "123456.apps.googleusercontent.com",
            "next_page_token": "CjkKLwor",
            "token_count": 42,
        }
        result = redact_args(args)
        # client_id is public (OAuth), page tokens are cursors, not secrets
        assert result["client_id"] == "123456.apps.googleusercontent.com"
        assert result["next_page_token"] == "CjkKLwor"
        assert result["token_count"] == 42

    def test_long_strings_not_redacted(self) -> None:
        """Long values like campaign names should NOT be redacted."""
        args = {
            "name": "summer-sale-exact-match-branded-2024-q4-us-west",
            "query": "SELECT campaign.id, campaign.name FROM campaign",
        }
        result = redact_args(args)
        assert result == args

    def test_normal_tool_args_preserved(self) -> None:
        args = {
            "customer_id": "123-456-7890",
            "name": "Summer Sale Campaign",
            "amount_micros": 50000000,
            "status": "PAUSED",
        }
        result = redact_args(args)
        assert result == args

    def test_nested_dicts_redacted(self) -> None:
        args = {
            "config": {"client_secret": "s3cret", "region": "us"},
        }
        result = redact_args(args)
        assert result["config"]["client_secret"] == "[REDACTED]"
        assert result["config"]["region"] == "us"

    def test_list_with_mixed_types(self) -> None:
        """Dicts in lists are recursively redacted regardless of position."""
        args = {
            "items": [
                "plain_string",
                {"refresh_token": "secret", "name": "ok"},
                {"text": "running shoes", "match_type": "BROAD"},
            ],
        }
        result = redact_args(args)
        assert result["items"][0] == "plain_string"
        assert result["items"][1]["refresh_token"] == "[REDACTED]"
        assert result["items"][1]["name"] == "ok"
        assert result["items"][2]["match_type"] == "BROAD"

    def test_none_args_returns_empty(self) -> None:
        assert redact_args(None) == {}

    def test_empty_args_returns_empty(self) -> None:
        assert redact_args({}) == {}


# ---------------------------------------------------------------------------
# 2. Classification and extraction
# ---------------------------------------------------------------------------


class TestClassification:
    def test_write_tools(self) -> None:
        for name in [
            "create_campaign",
            "update_campaign",
            "remove_keyword",
        ]:
            assert classify_tool(name) == "write"

    def test_read_tools(self) -> None:
        for name in [
            "execute_query",
            "list_accessible_customers",
            "get_field_metadata",
        ]:
            assert classify_tool(name) == "read"

    def test_utility_tool(self) -> None:
        assert classify_tool("check_connection_status") == "utility"

    def test_workflow_tools(self) -> None:
        assert classify_tool("audit_campaign_structure") == "workflow"
        assert classify_tool("analyze_audiences") == "workflow"

    def test_unknown_defaults_to_workflow(self) -> None:
        assert classify_tool("some_future_tool") == "workflow"


class TestCustomerIdExtraction:
    def test_extracts_from_args(self) -> None:
        assert extract_customer_id({"customer_id": "123"}) == "123"

    def test_none_when_missing(self) -> None:
        assert extract_customer_id({"name": "test"}) is None

    def test_none_for_none_args(self) -> None:
        assert extract_customer_id(None) is None


# ---------------------------------------------------------------------------
# 3. Record building
# ---------------------------------------------------------------------------


class TestBuildRecord:
    def test_success_record_shape(self) -> None:
        record = build_record(
            tool_name="execute_query",
            arguments={"customer_id": "123", "query": "SELECT campaign.id"},
            outcome="success",
            elapsed_ms=42,
        )
        assert record["tool"] == "execute_query"
        assert record["server"] == "read"
        assert record["customer_id"] == "123"
        assert record["outcome"] == "success"
        assert record["elapsed_ms"] == 42
        assert "timestamp" in record
        assert "event_id" in record
        # Arguments should be redacted copy
        assert record["arguments"]["query"] == "SELECT campaign.id"
        # No optional fields when not provided
        assert "error" not in record
        assert "risk_tier" not in record

    def test_error_record(self) -> None:
        record = build_record(
            tool_name="create_campaign",
            arguments={"customer_id": "456"},
            outcome="error",
            elapsed_ms=100,
            error="GoogleAdsException: INVALID_ARGUMENT",
        )
        assert record["outcome"] == "error"
        assert "INVALID_ARGUMENT" in record["error"]

    def test_blocked_record_with_guardrails(self) -> None:
        record = build_record(
            tool_name="create_campaign_budget",
            arguments={"customer_id": "789", "amount_micros": 999000000},
            outcome="blocked",
            elapsed_ms=1,
            error="Budget exceeds ceiling",
            risk_tier=4,
            guardrail_warnings=["Budget $999 exceeds $500 ceiling"],
        )
        assert record["outcome"] == "blocked"
        assert record["risk_tier"] == 4
        assert len(record["guardrail_warnings"]) == 1

    def test_error_truncated_to_500_chars(self) -> None:
        long_error = "x" * 1000
        record = build_record(
            tool_name="execute_query",
            arguments=None,
            outcome="error",
            elapsed_ms=0,
            error=long_error,
        )
        assert len(record["error"]) == 500

    def test_sensitive_args_redacted_in_record(self) -> None:
        record = build_record(
            tool_name="execute_query",
            arguments={
                "customer_id": "123",
                "developer_token": "supersecret",
            },
            outcome="success",
            elapsed_ms=10,
        )
        assert record["arguments"]["developer_token"] == "[REDACTED]"
        assert record["customer_id"] == "123"


# ---------------------------------------------------------------------------
# 4. JSONL file I/O
# ---------------------------------------------------------------------------


class TestAuditLogger:
    def test_writes_valid_jsonl(self, tmp_path) -> None:
        log_path = str(tmp_path / "test.jsonl")
        audit = AuditLogger(path=log_path)

        record1 = build_record(
            tool_name="execute_query",
            arguments={"customer_id": "111"},
            outcome="success",
            elapsed_ms=50,
        )
        record2 = build_record(
            tool_name="create_campaign",
            arguments={"customer_id": "222"},
            outcome="error",
            elapsed_ms=200,
            error="Something failed",
        )

        audit.log(record1)
        audit.log(record2)
        audit.close()

        # Read back and verify
        with open(log_path) as f:
            lines = f.readlines()

        assert len(lines) == 2

        parsed1 = json.loads(lines[0])
        assert parsed1["tool"] == "execute_query"
        assert parsed1["customer_id"] == "111"

        parsed2 = json.loads(lines[1])
        assert parsed2["tool"] == "create_campaign"
        assert parsed2["outcome"] == "error"

    def test_disabled_when_empty_path(self) -> None:
        audit = AuditLogger(path="")
        assert audit.enabled is False
        # Should not raise
        audit.log({"test": True})

    def test_creates_parent_directories(self, tmp_path) -> None:
        log_path = str(tmp_path / "deep" / "nested" / "audit.jsonl")
        audit = AuditLogger(path=log_path)
        assert audit.enabled is True
        audit.log(
            build_record(
                tool_name="test",
                arguments=None,
                outcome="success",
                elapsed_ms=0,
            )
        )
        audit.close()
        assert os.path.exists(log_path)


# ---------------------------------------------------------------------------
# 5. Middleware result parsing
# ---------------------------------------------------------------------------


class TestOutcomeExtraction:
    """Result parsing works on raw Python objects (not CallToolResult)."""

    def test_success_dict(self) -> None:
        result = {"results": [{"campaign": {"name": "Test"}}]}
        outcome, error, tier, warnings = _extract_outcome(result)
        assert outcome == "success"
        assert error is None
        assert tier is None

    def test_guardrail_blocked_dict(self) -> None:
        result = {"error": "Budget exceeds ceiling", "risk_tier": 4}
        outcome, error, tier, warnings = _extract_outcome(result)
        assert outcome == "blocked"
        assert "ceiling" in error
        assert tier == 4

    def test_error_dict_without_risk_tier(self) -> None:
        result = {"error": "GoogleAdsException: INVALID_ARGUMENT"}
        outcome, error, tier, warnings = _extract_outcome(result)
        assert outcome == "error"
        assert "INVALID_ARGUMENT" in error
        assert tier is None

    def test_string_result(self) -> None:
        result = "Google Ads SDK client is initialized and ready."
        outcome, error, tier, warnings = _extract_outcome(result)
        assert outcome == "success"
        assert error is None

    def test_list_result(self) -> None:
        result = [{"campaign": {"id": "1"}}, {"campaign": {"id": "2"}}]
        outcome, error, tier, warnings = _extract_outcome(result)
        assert outcome == "success"


class TestResultSummary:
    """Summary extraction works on raw Python objects."""

    def test_dict_with_results_list(self) -> None:
        result = {"results": [{"id": 1}, {"id": 2}]}
        assert _summarize_result(result) == "2 result(s)"

    def test_dict_with_resource_name(self) -> None:
        result = {"resource_name": "customers/123/campaigns/456"}
        assert _summarize_result(result) == "customers/123/campaigns/456"

    def test_plain_string(self) -> None:
        assert _summarize_result("OK") == "2 chars"

    def test_list_result(self) -> None:
        result = [{"row": 1}, {"row": 2}, {"row": 3}]
        assert _summarize_result(result) == "3 row(s)"

    def test_none_result(self) -> None:
        assert _summarize_result(None) is None


# ---------------------------------------------------------------------------
# 6. Middleware integration — end-to-end through on_call_tool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_middleware_logs_successful_call(tmp_path) -> None:
    """Full pipeline: middleware → audit logger → JSONL file."""
    log_path = str(tmp_path / "audit.jsonl")

    # Patch the singleton so the middleware writes to our temp file
    import src.audit as audit_mod

    original = audit_mod._audit_logger
    audit_mod._audit_logger = AuditLogger(path=log_path)

    try:
        middleware = AuditMiddleware()

        # Build a fake context and call_next
        context = AsyncMock()
        context.message = mt.CallToolRequestParams(
            name="execute_query",
            arguments={
                "customer_id": "999-888-7777",
                "query": "SELECT campaign.name FROM campaign",
            },
        )

        # FastMCP call_next returns raw handler results, not CallToolResult
        fake_result = {"results": [{"campaign": {"name": "Test"}}]}

        async def fake_call_next(ctx):
            return fake_result

        result = await middleware.on_call_tool(context, fake_call_next)

        assert result == fake_result

        # Verify JSONL was written
        audit_mod._audit_logger.close()
        with open(log_path) as f:
            lines = f.readlines()

        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["tool"] == "execute_query"
        assert record["server"] == "read"
        assert record["customer_id"] == "999-888-7777"
        assert record["outcome"] == "success"
        assert record["elapsed_ms"] >= 0
        assert record["result_summary"] == "1 result(s)"
    finally:
        audit_mod._audit_logger = original


@pytest.mark.asyncio
async def test_middleware_logs_exception(tmp_path) -> None:
    """Middleware should log errors even when the tool raises."""
    log_path = str(tmp_path / "audit.jsonl")

    import src.audit as audit_mod

    original = audit_mod._audit_logger
    audit_mod._audit_logger = AuditLogger(path=log_path)

    try:
        middleware = AuditMiddleware()

        context = AsyncMock()
        context.message = mt.CallToolRequestParams(
            name="create_campaign",
            arguments={"customer_id": "111"},
        )

        async def exploding_call_next(ctx):
            raise RuntimeError("API connection failed")

        with pytest.raises(RuntimeError, match="API connection failed"):
            await middleware.on_call_tool(context, exploding_call_next)

        # Error should still be logged
        audit_mod._audit_logger.close()
        with open(log_path) as f:
            record = json.loads(f.readline())

        assert record["tool"] == "create_campaign"
        assert record["outcome"] == "error"
        assert "API connection failed" in record["error"]
    finally:
        audit_mod._audit_logger = original
