"""Google Ads MCP server tests."""
