"""Tests for write guardrails: budget validation, campaign validation, and tool annotations.

Three layers:
  1. Pure unit tests for write_validator.py (no mocks, no async)
  2. Tool annotation verification via FastMCP's get_tools()
  3. Integration tests for write_server.py handlers (mock_ctx)
"""

import os
from unittest.mock import AsyncMock, patch

import pytest

from src.write_validator import (
    validate_budget_change,
    validate_campaign_update,
)


# ---------------------------------------------------------------------------
# 1. Budget validation — pure unit tests
# ---------------------------------------------------------------------------


class TestBudgetCeiling:
    """Account daily ceiling (hard block)."""

    @patch.dict(os.environ, {"GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD": "500"})
    def test_ceiling_blocks_when_exceeded(self) -> None:
        # Reload to pick up patched env
        import importlib
        import src.write_validator as mod

        importlib.reload(mod)
        result = mod.validate_budget_change(0, 600_000_000)  # $600
        assert result.is_valid is False
        assert result.risk_tier == 4
        assert "$600.00" in (result.error or "")
        assert "$500.00" in (result.error or "")

    @patch.dict(os.environ, {"GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD": "500"})
    def test_ceiling_allows_when_under(self) -> None:
        import importlib
        import src.write_validator as mod

        importlib.reload(mod)
        result = mod.validate_budget_change(0, 400_000_000)  # $400
        assert result.is_valid is True

    @patch.dict(os.environ, {"GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD": "0"})
    def test_ceiling_disabled_when_zero(self) -> None:
        import importlib
        import src.write_validator as mod

        importlib.reload(mod)
        result = mod.validate_budget_change(0, 999_000_000_000)  # $999k
        assert result.is_valid is True


class TestBudgetPercentageTiers:
    """Budget change percentage risk tiers."""

    def test_new_budget_skips_percentage_tiers(self) -> None:
        """New budgets (current=0) should not trigger percentage warnings."""
        result = validate_budget_change(0, 50_000_000)  # $50 new budget
        assert result.is_valid is True
        assert result.risk_tier == 1
        assert result.warnings == []

    def test_tier1_small_change(self) -> None:
        """≤20% change → Tier 1, no warnings."""
        result = validate_budget_change(100_000_000, 115_000_000)  # 15%
        assert result.risk_tier == 1
        assert result.warnings == []

    def test_tier2_learning_phase(self) -> None:
        """>20% change → Tier 2, Smart Bidding warning."""
        result = validate_budget_change(100_000_000, 125_000_000)  # 25%
        assert result.risk_tier == 2
        assert len(result.warnings) == 1
        assert "Smart Bidding" in result.warnings[0]

    def test_tier3_exceeds_cap(self) -> None:
        """>30% (default cap) → Tier 3."""
        result = validate_budget_change(100_000_000, 140_000_000)  # 40%
        assert result.risk_tier == 3
        assert len(result.warnings) == 1
        assert "cap" in result.warnings[0]

    def test_tier4_critical(self) -> None:
        """>50% change → Tier 4, runaway spend warning."""
        result = validate_budget_change(100_000_000, 200_000_000)  # 100%
        assert result.risk_tier == 4
        assert "runaway spend" in result.warnings[0]

    def test_decrease_also_tiered(self) -> None:
        """Budget decreases are evaluated the same as increases."""
        result = validate_budget_change(100_000_000, 40_000_000)  # -60%
        assert result.risk_tier == 4
        assert "decrease" in result.warnings[0]

    def test_all_tiers_return_valid(self) -> None:
        """Percentage tiers warn but never block — only ceiling blocks."""
        for new in [115, 125, 140, 200]:
            result = validate_budget_change(100_000_000, new * 1_000_000)
            assert result.is_valid is True


# ---------------------------------------------------------------------------
# 2. Campaign update validation — pure unit tests
# ---------------------------------------------------------------------------


class TestCampaignUpdateValidation:
    """Campaign status and bidding strategy guardrails."""

    def test_removed_is_tier4(self) -> None:
        result = validate_campaign_update(status="REMOVED")
        assert result.risk_tier == 4
        assert "permanent" in result.warnings[0]
        assert result.is_valid is True  # warns, doesn't block

    def test_enabled_is_tier2(self) -> None:
        result = validate_campaign_update(status="ENABLED")
        assert result.risk_tier == 2
        assert "spend begins immediately" in result.warnings[0]

    def test_paused_is_tier1_no_warnings(self) -> None:
        result = validate_campaign_update(status="PAUSED")
        assert result.risk_tier == 1
        assert result.warnings == []

    def test_learning_phase_strategies(self) -> None:
        for strategy in [
            "TARGET_CPA",
            "TARGET_ROAS",
            "MAXIMIZE_CONVERSIONS",
            "MAXIMIZE_CONVERSION_VALUE",
        ]:
            result = validate_campaign_update(bidding_strategy=strategy)
            assert result.risk_tier == 3, f"{strategy} should be tier 3"
            assert "learning phase" in result.warnings[0]

    def test_manual_cpc_no_warning(self) -> None:
        result = validate_campaign_update(bidding_strategy="MANUAL_CPC")
        assert result.risk_tier == 1
        assert result.warnings == []

    def test_enabled_plus_learning_strategy_accumulates(self) -> None:
        """Both warnings should fire, tier = max(2, 3) = 3."""
        result = validate_campaign_update(
            status="ENABLED", bidding_strategy="TARGET_CPA"
        )
        assert result.risk_tier == 3
        assert len(result.warnings) == 2

    def test_no_changes_is_safe(self) -> None:
        result = validate_campaign_update()
        assert result.risk_tier == 1
        assert result.warnings == []


# ---------------------------------------------------------------------------
# 3. Tool annotations — verified via FastMCP get_tools()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_read_tools_annotated_readonly() -> None:
    """Every read tool must have readOnlyHint=True."""
    from src.servers.read_server import read_server

    tools = await read_server.get_tools()
    for name, tool in tools.items():
        ann = tool.annotations
        assert ann is not None, f"{name} has no annotations"
        assert ann.readOnlyHint is True, f"{name} should be readOnlyHint=True"


@pytest.mark.asyncio
async def test_write_tools_not_readonly() -> None:
    """Every write tool must have readOnlyHint=False."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    for name, tool in tools.items():
        ann = tool.annotations
        assert ann is not None, f"{name} has no annotations"
        assert ann.readOnlyHint is False, f"{name} should be readOnlyHint=False"


@pytest.mark.asyncio
async def test_destructive_tools_annotated() -> None:
    """Tools that delete/remove must be destructiveHint=True."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    expected_destructive = {
        "update_campaign",
        "remove_keyword",
        "remove_campaign_criterion",
    }

    for name in expected_destructive:
        assert name in tools, f"{name} not registered"
        assert tools[name].annotations is not None
        assert tools[name].annotations.destructiveHint is True, (
            f"{name} should be destructiveHint=True"
        )


@pytest.mark.asyncio
async def test_create_tools_not_destructive() -> None:
    """Create/add tools should be destructiveHint=False."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    create_tools = {n for n in tools if n.startswith(("create_", "add_"))}

    for name in create_tools:
        assert tools[name].annotations is not None
        assert tools[name].annotations.destructiveHint is False, (
            f"{name} should be destructiveHint=False"
        )


@pytest.mark.asyncio
async def test_dismiss_recommendation_is_idempotent() -> None:
    """dismiss_recommendation should be the only idempotent write tool."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    idempotent = {
        n
        for n, t in tools.items()
        if t.annotations and t.annotations.idempotentHint is True
    }
    assert idempotent == {"dismiss_recommendation"}


# ---------------------------------------------------------------------------
# 4. Write server integration — guardrail warnings flow through ctx.log
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_campaign_removed_logs_warning(mock_ctx: AsyncMock) -> None:
    """REMOVED status should log a [GUARDRAIL] warning via ctx."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    update_fn = tools["update_campaign"].fn

    # The API call will fail (mock), but the guardrail runs first
    try:
        await update_fn(
            ctx=mock_ctx,
            customer_id="1234567890",
            campaign_id="111",
            status="REMOVED",
        )
    except Exception:
        pass  # downstream API mock isn't wired — we only care about the log

    mock_ctx.log.assert_called()
    logged = mock_ctx.log.call_args_list[0]
    assert logged.kwargs["level"] == "warning"
    assert "[GUARDRAIL]" in logged.kwargs["message"]
    assert "permanent" in logged.kwargs["message"]


@pytest.mark.asyncio
async def test_create_budget_ceiling_blocks(mock_ctx: AsyncMock) -> None:
    """Budget exceeding ceiling should return error dict, not call API."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    create_fn = tools["create_campaign_budget"].fn

    with patch.dict(os.environ, {"GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD": "100"}):
        import importlib
        import src.write_validator as mod

        importlib.reload(mod)
        # Re-patch the imported references in write_server
        with patch(
            "src.servers.write_server.validate_budget_change",
            mod.validate_budget_change,
        ):
            result = await create_fn(
                ctx=mock_ctx,
                customer_id="1234567890",
                name="Test Budget",
                amount_micros=200_000_000,  # $200 > $100 ceiling
            )

    assert "error" in result
    assert result["risk_tier"] == 4


@pytest.mark.asyncio
async def test_update_budget_logs_warnings(mock_ctx: AsyncMock) -> None:
    """Budget change >50% should log [GUARDRAIL] warning via ctx."""
    import importlib

    import src.write_validator as mod

    # Reset module to default ceiling (0 = disabled) in case a prior test
    # reloaded it with a custom ceiling value.
    with patch.dict(os.environ, {"GOOGLE_ADS_MCP_ACCOUNT_DAILY_CEILING_USD": "0"}):
        importlib.reload(mod)

    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    update_fn = tools["update_campaign_budget"].fn

    with patch(
        "src.servers.write_server.validate_budget_change",
        mod.validate_budget_change,
    ):
        try:
            await update_fn(
                ctx=mock_ctx,
                customer_id="1234567890",
                budget_id="222",
                amount_micros=200_000_000,  # $200
                current_amount_micros=100_000_000,  # $100 → 100% = tier 4
            )
        except Exception:
            pass  # downstream API mock isn't wired — we only care about the log

    mock_ctx.log.assert_called()
    logged = mock_ctx.log.call_args_list[0]
    assert "[GUARDRAIL]" in logged.kwargs["message"]
