"""Shared test fixtures for Google Ads MCP server tests."""

from typing import Iterator
from unittest.mock import AsyncMock, Mock

import pytest
import pytest_asyncio
from fastmcp import Context
from google.ads.googleads.client import GoogleAdsClient


@pytest.fixture
def mock_google_ads_client() -> Mock:
    """Create a mock GoogleAdsClient."""
    client = Mock(spec=GoogleAdsClient)
    client.get_service = Mock()
    client.get_type = Mock()
    return client


@pytest.fixture
def mock_sdk_client(mock_google_ads_client: Mock) -> Mock:
    """Create a mock SdkClient with a mocked GoogleAdsClient."""
    sdk_client = Mock()
    sdk_client.client = mock_google_ads_client
    return sdk_client


@pytest_asyncio.fixture
async def mock_ctx() -> AsyncMock:
    """Create a mock FastMCP context."""
    ctx = AsyncMock(spec=Context)
    ctx.log = AsyncMock()
    return ctx


@pytest.fixture(autouse=True)
def _setup_global_sdk_client(mock_sdk_client: Mock) -> Iterator[None]:
    """Set the global SDK client so get_sdk_client() and get_type() work in all tests."""
    import src.sdk_client as sdk_mod

    sdk_mod._sdk_client = mock_sdk_client
    yield
    sdk_mod._sdk_client = None
