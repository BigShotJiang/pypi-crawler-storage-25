"""Level B tests -- verify tool registration for all 3 servers.

These tests use FastMCP's in-memory client to verify that each server
registers the expected tools with correct names. This catches registration
bugs, import errors, and schema changes across the tool surface.

Note: total tool count tests verify the servers directly (not via main.py
module reload) to avoid .env file interference during testing.
"""

import pytest


@pytest.mark.asyncio
async def test_read_server_tools() -> None:
    """Read server registers exactly 8 tools."""
    from src.servers.read_server import read_server

    tools = await read_server.get_tools()
    tool_names = set(tools.keys())

    expected = {
        "execute_query",
        "execute_query_stream",
        "list_accessible_customers",
        "generate_keyword_ideas",
        "suggest_geo_targets",
        "get_field_metadata",
        "validate_query_fields",
        "get_recommendations",
    }

    assert tool_names == expected, (
        f"Missing: {expected - tool_names}, Extra: {tool_names - expected}"
    )
    assert len(tool_names) == 8


@pytest.mark.asyncio
async def test_write_server_tools() -> None:
    """Write server registers exactly 16 tools."""
    from src.servers.write_server import write_server

    tools = await write_server.get_tools()
    tool_names = set(tools.keys())

    expected = {
        "create_campaign",
        "update_campaign",
        "create_campaign_budget",
        "update_campaign_budget",
        "create_ad_group",
        "update_ad_group",
        "create_ad",
        "update_ad_status",
        "add_keywords",
        "remove_keyword",
        "add_negative_keywords",
        "add_location_targeting",
        "add_language_targeting",
        "remove_campaign_criterion",
        "apply_recommendation",
        "dismiss_recommendation",
    }

    assert tool_names == expected, (
        f"Missing: {expected - tool_names}, Extra: {tool_names - expected}"
    )
    assert len(tool_names) == 16


@pytest.mark.asyncio
async def test_workflow_server_tools() -> None:
    """Workflow server registers exactly 7 tools."""
    from src.servers.workflow_server import workflow_server

    tools = await workflow_server.get_tools()
    tool_names = set(tools.keys())

    assert len(tool_names) == 7, (
        f"Expected 7 workflow tools, got {len(tool_names)}: {tool_names}"
    )


@pytest.mark.asyncio
async def test_total_tool_count() -> None:
    """All 3 servers combined + 1 utility = 32 tools.

    Tests the assembly directly rather than reloading main.py,
    since .env files can interfere with WRITE_ENABLED during reload.
    """
    from src.servers.read_server import read_server
    from src.servers.write_server import write_server
    from src.servers.workflow_server import workflow_server

    read_tools = await read_server.get_tools()
    write_tools = await write_server.get_tools()
    workflow_tools = await workflow_server.get_tools()

    total = (
        len(read_tools) + len(write_tools) + len(workflow_tools) + 1
    )  # +1 check_connection_status
    assert total == 32, (
        f"Expected 32 total (8+16+7+1), got {total}: "
        f"read={len(read_tools)}, write={len(write_tools)}, "
        f"workflow={len(workflow_tools)}, utility=1"
    )
