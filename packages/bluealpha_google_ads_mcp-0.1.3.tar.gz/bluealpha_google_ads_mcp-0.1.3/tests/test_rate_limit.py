"""Tests for the rate limiting middleware: sliding window, registry, and middleware.

Three layers:
  1. SlidingWindow pure unit tests (no async, monkeypatched time)
  2. RateLimitRegistry unit tests (per-customer, per-category isolation)
  3. RateLimitMiddleware integration tests (full on_call_tool pipeline)
  4. Audit integration (rate_limited outcome captured in audit log)
"""

from unittest.mock import AsyncMock, patch

import mcp.types as mt
import pytest

from src.middleware.rate_limit_middleware import (
    RateLimitMiddleware,
    RateLimitRegistry,
    SlidingWindow,
)


# ---------------------------------------------------------------------------
# 1. SlidingWindow — pure unit tests
# ---------------------------------------------------------------------------


class TestSlidingWindow:
    def test_allows_within_limit(self) -> None:
        window = SlidingWindow(max_calls=5, window_seconds=60)
        for _ in range(5):
            assert window.is_allowed() is True

    def test_blocks_at_limit(self) -> None:
        window = SlidingWindow(max_calls=3, window_seconds=60)
        for _ in range(3):
            assert window.is_allowed() is True
        assert window.is_allowed() is False

    def test_window_expires(self) -> None:
        """After the window passes, calls should be allowed again."""
        window = SlidingWindow(max_calls=2, window_seconds=10)

        # Use up the limit
        base_time = 1000.0
        with patch("src.middleware.rate_limit_middleware.time") as mock_time:
            mock_time.monotonic.return_value = base_time
            assert window.is_allowed() is True
            assert window.is_allowed() is True
            assert window.is_allowed() is False

            # Advance past the window
            mock_time.monotonic.return_value = base_time + 11.0
            assert window.is_allowed() is True

    def test_time_until_next_slot(self) -> None:
        window = SlidingWindow(max_calls=1, window_seconds=60)

        base_time = 1000.0
        with patch("src.middleware.rate_limit_middleware.time") as mock_time:
            mock_time.monotonic.return_value = base_time
            window.is_allowed()  # Use the one slot

            # 10 seconds later, should have ~50 seconds left
            mock_time.monotonic.return_value = base_time + 10.0
            remaining = window.time_until_next_slot()
            assert 49.0 <= remaining <= 51.0

    def test_current_count(self) -> None:
        window = SlidingWindow(max_calls=10, window_seconds=60)
        assert window.current_count == 0
        window.is_allowed()
        window.is_allowed()
        assert window.current_count == 2

    def test_time_until_next_slot_when_empty(self) -> None:
        window = SlidingWindow(max_calls=5, window_seconds=60)
        assert window.time_until_next_slot() == 0.0


# ---------------------------------------------------------------------------
# 2. RateLimitRegistry — per-customer, per-category isolation
# ---------------------------------------------------------------------------


class TestRateLimitRegistry:
    def test_separate_customer_ids(self) -> None:
        """Two customer IDs should have independent limits."""
        registry = RateLimitRegistry()

        # Fill up customer A's read limit
        with patch.dict(
            "src.middleware.rate_limit_middleware._LIMITS",
            {"read": (2, 60)},
        ):
            assert registry.check("cust_A", "read") == (True, 0.0)
            assert registry.check("cust_A", "read") == (True, 0.0)
            allowed, _ = registry.check("cust_A", "read")
            assert allowed is False

            # Customer B should still be allowed
            allowed, _ = registry.check("cust_B", "read")
            assert allowed is True

    def test_separate_categories(self) -> None:
        """Same customer, different categories are independent."""
        registry = RateLimitRegistry()

        with patch.dict(
            "src.middleware.rate_limit_middleware._LIMITS",
            {"read": (1, 60), "write": (1, 3600)},
        ):
            # Use up read limit
            registry.check("cust_A", "read")
            allowed_read, _ = registry.check("cust_A", "read")
            assert allowed_read is False

            # Write should still work
            allowed_write, _ = registry.check("cust_A", "write")
            assert allowed_write is True

    def test_disabled_category_always_allows(self) -> None:
        """Category with max_calls=0 should always allow."""
        registry = RateLimitRegistry()

        with patch.dict(
            "src.middleware.rate_limit_middleware._LIMITS",
            {"budget": (0, 3600)},
        ):
            allowed, _ = registry.check("cust_A", "budget")
            assert allowed is True

    def test_unknown_category_allows(self) -> None:
        """Unknown category should pass through."""
        registry = RateLimitRegistry()
        allowed, _ = registry.check("cust_A", "nonexistent")
        assert allowed is True


# ---------------------------------------------------------------------------
# 3. RateLimitMiddleware — integration tests
# ---------------------------------------------------------------------------


def _make_context(tool_name: str, arguments: dict | None = None):
    """Build a mock MiddlewareContext for testing."""
    context = AsyncMock()
    context.message = mt.CallToolRequestParams(
        name=tool_name,
        arguments=arguments,
    )
    return context


@pytest.mark.asyncio
async def test_allows_normal_call() -> None:
    """A single call within limits should pass through."""
    middleware = RateLimitMiddleware()
    context = _make_context(
        "execute_query", {"customer_id": "123", "query": "SELECT 1"}
    )
    expected = {"results": []}

    async def fake_call_next(ctx):
        return expected

    result = await middleware.on_call_tool(context, fake_call_next)
    assert result == expected


@pytest.mark.asyncio
async def test_blocks_when_exceeded() -> None:
    """After exceeding the limit, should return error dict."""
    middleware = RateLimitMiddleware()

    # Patch to a very low limit
    with patch.dict(
        "src.middleware.rate_limit_middleware._LIMITS",
        {"read": (2, 60)},
    ):

        async def fake_call_next(ctx):
            return {"results": []}

        context1 = _make_context("execute_query", {"customer_id": "456"})
        context2 = _make_context("execute_query", {"customer_id": "456"})
        context3 = _make_context("execute_query", {"customer_id": "456"})

        await middleware.on_call_tool(context1, fake_call_next)
        await middleware.on_call_tool(context2, fake_call_next)
        result = await middleware.on_call_tool(context3, fake_call_next)

        assert result["rate_limited"] is True
        assert "error" in result
        assert "retry_after_seconds" in result


@pytest.mark.asyncio
async def test_error_dict_shape() -> None:
    """Verify the exact shape of the rate limit error dict."""
    middleware = RateLimitMiddleware()

    with patch.dict(
        "src.middleware.rate_limit_middleware._LIMITS",
        {"write": (1, 3600)},
    ):

        async def fake_call_next(ctx):
            return {"results": []}

        ctx1 = _make_context("create_campaign", {"customer_id": "789"})
        ctx2 = _make_context("create_campaign", {"customer_id": "789"})

        await middleware.on_call_tool(ctx1, fake_call_next)
        result = await middleware.on_call_tool(ctx2, fake_call_next)

        assert isinstance(result, dict)
        assert result["rate_limited"] is True
        assert isinstance(result["error"], str)
        assert isinstance(result["retry_after_seconds"], int)
        assert result["retry_after_seconds"] > 0
        assert "789" in result["error"]


@pytest.mark.asyncio
async def test_skips_utility_tools() -> None:
    """Utility tools (check_connection_status) are never rate-limited."""
    middleware = RateLimitMiddleware()

    async def fake_call_next(ctx):
        return "SDK ready"

    # Even with impossibly low limits, utility tools pass through
    with patch.dict(
        "src.middleware.rate_limit_middleware._LIMITS",
        {"utility": (0, 60)},
    ):
        for _ in range(10):
            context = _make_context("check_connection_status", {})
            result = await middleware.on_call_tool(context, fake_call_next)
            assert result == "SDK ready"


@pytest.mark.asyncio
async def test_skips_no_customer_id() -> None:
    """Tools without customer_id in args are exempt."""
    middleware = RateLimitMiddleware()

    async def fake_call_next(ctx):
        return {"customers": ["123", "456"]}

    with patch.dict(
        "src.middleware.rate_limit_middleware._LIMITS",
        {"read": (1, 60)},
    ):
        # list_accessible_customers has no customer_id
        for _ in range(5):
            context = _make_context("list_accessible_customers", {})
            result = await middleware.on_call_tool(context, fake_call_next)
            assert "customers" in result


@pytest.mark.asyncio
async def test_disabled_via_env() -> None:
    """When RATE_LIMIT_ENABLED=false, all calls pass through."""
    with patch("src.middleware.rate_limit_middleware.RATE_LIMIT_ENABLED", False):
        middleware = RateLimitMiddleware()

        async def fake_call_next(ctx):
            return {"results": []}

        # Even with 0 limit, should pass when disabled
        with patch.dict(
            "src.middleware.rate_limit_middleware._LIMITS",
            {"read": (1, 60)},
        ):
            for _ in range(10):
                context = _make_context("execute_query", {"customer_id": "999"})
                result = await middleware.on_call_tool(context, fake_call_next)
                assert result == {"results": []}


@pytest.mark.asyncio
async def test_budget_subcap() -> None:
    """Budget-specific subcap is checked separately from general writes."""
    middleware = RateLimitMiddleware()

    with (
        patch.dict(
            "src.middleware.rate_limit_middleware._LIMITS",
            {
                "write": (100, 3600),  # General write limit is high
                "budget": (1, 3600),  # Budget subcap is 1
            },
        ),
        patch("src.middleware.rate_limit_middleware.BUDGET_CHANGES_PER_HOUR", 1),
    ):

        async def fake_call_next(ctx):
            return {"results": []}

        ctx1 = _make_context(
            "update_campaign_budget",
            {"customer_id": "111", "budget_id": "222"},
        )
        ctx2 = _make_context(
            "update_campaign_budget",
            {"customer_id": "111", "budget_id": "333"},
        )

        # First budget change succeeds
        r1 = await middleware.on_call_tool(ctx1, fake_call_next)
        assert "rate_limited" not in r1

        # Second budget change blocked by subcap
        r2 = await middleware.on_call_tool(ctx2, fake_call_next)
        assert r2["rate_limited"] is True
        assert "budget" in r2["error"].lower()


# ---------------------------------------------------------------------------
# 4. Audit integration — rate_limited outcome
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_audit_captures_rate_limited_outcome() -> None:
    """Audit middleware should log rate-limited calls with distinct outcome."""
    from src.middleware.audit_middleware import _extract_outcome

    rate_limited_result = {
        "error": "Rate limit exceeded: 20 write calls per hour",
        "rate_limited": True,
        "retry_after_seconds": 42,
    }
    outcome, error, tier, warnings = _extract_outcome(rate_limited_result)
    assert outcome == "rate_limited"
    assert "Rate limit exceeded" in error
    assert tier is None  # Rate limits don't have risk tiers
    assert warnings is None
