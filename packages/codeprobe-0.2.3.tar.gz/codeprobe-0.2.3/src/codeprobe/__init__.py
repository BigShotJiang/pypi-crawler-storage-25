"""codeprobe — Benchmark AI coding agents against your own codebase."""

__version__ = "0.2.0"
