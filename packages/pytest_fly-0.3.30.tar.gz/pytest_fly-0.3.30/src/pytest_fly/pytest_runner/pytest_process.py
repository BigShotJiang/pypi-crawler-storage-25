"""
Single-test subprocess — runs one pytest module with coverage collection
and a :class:`ProcessMonitor` that samples CPU/memory usage.
"""

import contextlib
import io
import shutil
import time
import traceback
from multiprocessing import Process
from pathlib import Path
from queue import Empty

import pytest
from coverage import Coverage
from typeguard import typechecked

from ..__version__ import application_name
from ..db import PytestProcessInfoDB
from ..file_util import sanitize_test_name
from ..interfaces import PyTestFlyExitCode, PytestProcessInfo
from ..logger import get_logger
from .process_monitor import ProcessMonitor

log = get_logger(application_name)


class PytestProcess(Process):
    """
    A process that performs a pytest run.
    """

    @typechecked()
    def __init__(self, run_guid: str, test: Path | str, data_dir: Path, update_rate: float, put_version: str = "", put_fingerprint: str = "") -> None:
        """
        Pytest process for a single pytest test.

        :param run_guid: the pytest run this process is associated with (same GUID for all tests in a pytest run)
        :param test: the test to run
        :param data_dir: the directory to store coverage data in
        :param update_rate: the update rate for the process monitor
        :param put_version: display label for the program under test (stamped on each DB record)
        :param put_fingerprint: program-under-test fingerprint for RunMode.CHECK comparison
        """
        super().__init__(name=str(test))
        self.data_dir = data_dir
        self.run_guid = run_guid
        self.update_rate = update_rate
        self.put_version = put_version
        self.put_fingerprint = put_fingerprint

        self._process_monitor_process = None

    def run(self) -> None:

        # start the process monitor to monitor things like CPU and memory usage
        self._process_monitor_process = ProcessMonitor(self.run_guid, self.name, self.pid, self.update_rate)
        self._process_monitor_process.start()

        # update the pytest process info to show that the test is running
        with PytestProcessInfoDB(self.data_dir) as db:
            pytest_process_info = PytestProcessInfo(
                self.run_guid,
                self.name,
                self.pid,
                PyTestFlyExitCode.NONE,
                None,
                time_stamp=time.time(),
                put_version=self.put_version,
                put_fingerprint=self.put_fingerprint,
            )
            db.write(pytest_process_info)

        # Finally, actually run pytest!
        # Redirect stdout and stderr so nothing goes to the console.
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            # create a temp coverage file and then move it so if the file exists, the content is complete (the save is not necessarily instantaneous and atomic)
            coverage_dir = Path(self.data_dir, "coverage")
            coverage_dir.mkdir(parents=True, exist_ok=True)
            safe_name = sanitize_test_name(self.name)
            coverage_file_path = Path(coverage_dir, f"{safe_name}.coverage")
            coverage_temp_file_path = Path(coverage_dir, f"{safe_name}.temp")
            coverage_temp_file_path.unlink(missing_ok=True)
            coverage = Coverage(coverage_temp_file_path)
            coverage.start()

            try:
                # -rA: show full short test summary (all outcomes, untruncated assertion messages)
                exit_code = pytest.main([self.name, "-rA"])
            except Exception:
                exit_code = PyTestFlyExitCode.INTERNAL_ERROR
                try:
                    buf.write(f"\n\npytest.main raised an exception:\n{traceback.format_exc()}")
                except (ValueError, OSError):
                    pass  # buf may be closed if the test redirected/closed stderr

            coverage.stop()
            coverage.save()
            coverage_file_path.unlink(missing_ok=True)
            shutil.move(coverage_temp_file_path, coverage_file_path)

        output: str = buf.getvalue()

        # stop the process monitor
        self._process_monitor_process.request_stop()
        self._process_monitor_process.join(100.0)  # plenty of time for the monitor to stop
        if self._process_monitor_process.is_alive():
            log.warning(f"{self._process_monitor_process} is alive")

        # drain the process monitor queue to compute peak CPU and memory usage
        cpu_samples = []
        memory_samples = []
        while True:
            try:
                monitor_info = self._process_monitor_process.process_monitor_queue.get_nowait()
                if monitor_info.cpu_percent is not None:
                    cpu_samples.append(monitor_info.cpu_percent)
                if monitor_info.memory_percent is not None:
                    memory_samples.append(monitor_info.memory_percent)
            except Empty:
                break
        peak_cpu = max(cpu_samples) if cpu_samples else None
        peak_memory = max(memory_samples) if memory_samples else None

        # update the pytest process info to show that the test has finished
        with PytestProcessInfoDB(self.data_dir) as db:
            pytest_process_info = PytestProcessInfo(
                self.run_guid,
                self.name,
                self.pid,
                exit_code,
                output,
                time.time(),
                peak_cpu,
                peak_memory,
                put_version=self.put_version,
                put_fingerprint=self.put_fingerprint,
            )
            db.write(pytest_process_info)

        log.debug(f"{self.name=},{self.name},{exit_code=},{output=}")
