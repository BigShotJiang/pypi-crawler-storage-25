import strax
import numpy as np
import numba
import os
from scipy.optimize import curve_fit
from straxion.constants import (
    TIME_DTYPE,
    CHANNEL_DTYPE,
    SECOND_TO_NANOSECOND,
    HIT_WINDOW_LENGTH_LEFT,
    HIT_WINDOW_LENGTH_RIGHT,
    DATA_DTYPE,
    NOISE_PSD_38kHz,
    DEFAULT_TEMPLATE_INTERP_PATH,
    TEMPLATE_INTERP_FOLDER,
    INDEX_DTYPE,
)
from straxion.utils import load_interpolation
from .hits import DxHits

export, __all__ = strax.exporter()


# =============================================================================
# Numba-accelerated helper functions for optimal filter
# =============================================================================


@numba.njit(cache=True)
def _movmean_numba(data, window_size):
    """Numba-accelerated moving average with edge handling.

    Args:
        data (np.ndarray): The input 1D array (float64).
        window_size (int): The size of the moving average window.

    Returns:
        np.ndarray: Array containing the moving average.

    """
    n = len(data)
    result = np.empty(n, dtype=np.float64)
    half_w = window_size // 2

    for i in range(n):
        start = max(0, i - half_w)
        end = min(n, i + half_w + 1)
        total = 0.0
        for j in range(start, end):
            total += data[j]
        result[i] = total / (end - start)

    return result


@numba.njit(cache=True)
def _compute_chi2_batch_numba(
    Sf_real, Sf_imag, Af_real_all, Af_imag_all, Jf_safe, n_samples, n_shifts
):
    """Compute chi-squared for all shifts in a batch using numba.

    Args:
        Sf_real (np.ndarray): Real part of signal FFT (1D, length n_samples).
        Sf_imag (np.ndarray): Imaginary part of signal FFT (1D, length n_samples).
        Af_real_all (np.ndarray): Real parts of template FFTs (2D, n_shifts x n_samples).
        Af_imag_all (np.ndarray): Imag parts of template FFTs (2D, n_shifts x n_samples).
        Jf_safe (np.ndarray): Safe noise PSD (1D, length n_samples).
        n_samples (int): Number of frequency samples.
        n_shifts (int): Number of time shifts.

    Returns:
        tuple: (ahatOF_arr, chi2_arr) - arrays of amplitude and chi2 for each shift.

    """
    ahatOF_arr = np.empty(n_shifts, dtype=np.float64)
    chi2_arr = np.empty(n_shifts, dtype=np.float64)

    for shift_idx in range(n_shifts):
        # Get template FFT for this shift
        Af_real = Af_real_all[shift_idx]
        Af_imag = Af_imag_all[shift_idx]

        # Compute ahatOF = sum(real(Sf * conj(Af))) / sum(real(Af * conj(Af)))
        # Sf * conj(Af) = (Sr + j*Si) * (Ar - j*Ai)
        #               = (Sr*Ar + Si*Ai) + j*(Si*Ar - Sr*Ai)
        numer = 0.0
        denom = 0.0
        for i in range(n_samples):
            numer += Sf_real[i] * Af_real[i] + Sf_imag[i] * Af_imag[i]
            denom += Af_real[i] * Af_real[i] + Af_imag[i] * Af_imag[i]

        ahatOF = numer / denom
        ahatOF_arr[shift_idx] = ahatOF

        # Compute chi2 = sum(|Sf - ahatOF * Af|^2 / Jf) / (n - 1)
        chi2 = 0.0
        for i in range(n_samples):
            diff_real = Sf_real[i] - ahatOF * Af_real[i]
            diff_imag = Sf_imag[i] - ahatOF * Af_imag[i]
            chi2 += (diff_real * diff_real + diff_imag * diff_imag) / Jf_safe[i]
        chi2 /= n_samples - 1

        chi2_arr[shift_idx] = chi2

    return ahatOF_arr, chi2_arr


@numba.njit(cache=True)
def _profile_fit_numba(x, amplitude, center, kappa):
    """Numba-accelerated double-sided exponential profile.

    Args:
        x (np.ndarray): The x values (time shifts).
        amplitude (float): The peak amplitude.
        center (float): The center position.
        kappa (float): The double-sided exponential width.

    Returns:
        np.ndarray: The profile values.

    """
    n = len(x)
    result = np.empty(n, dtype=np.float64)
    for i in range(n):
        result[i] = amplitude * np.exp(-np.abs(x[i] - center) / kappa)
    return result


@export
@strax.takes_config(
    strax.Option(
        "max_spike_coincidence",
        type=int,
        default=1,
        track=True,
        help=("Maximum number of spikes that can be coincident with a photon candidate hit."),
    ),
    strax.Option(
        "spike_coincidence_window",
        type=float,
        default=0.131e-3,
        track=True,
        help=("Window length for checking spike coincidence, in unit of seconds."),
    ),
    strax.Option(
        "spike_threshold_dx",
        default=None,
        track=True,
        type=float,
        help="Threshold for spike finding in units of dx=df/f0.",
    ),
    strax.Option(
        "spike_thresholds_sigma",
        default=[4.0 for _ in range(41)],
        track=True,
        type=list,
        help=(
            "Threshold for spike finding in units of sigma of standard deviation of the noise. "
            "If None, the spike threshold will be calculated based on the signal statistics."
        ),
    ),
    strax.Option(
        "fs",
        default=38_000,
        track=True,
        type=int,
        help="Sampling frequency (assumed the same for all channels) in unit of Hz",
    ),
    strax.Option(
        "symmetric_spike_inspection_window_length",
        type=int,
        default=25,
        track=True,
        help=(
            "Length of the inspection window for identifying symmetric spikes, "
            "in unit of samples."
        ),
    ),
    strax.Option(
        "symmetric_spike_min_slope",
        type=list,
        default=[0.0 for _ in range(41)],
        track=True,
        help=(
            "Minimum rise edge slope of the moving averaged signal for identifying a physical hit "
            "against symmetric spikes, in unit of dx/second."
        ),
    ),
    strax.Option(
        "template_interp_path",
        type=str,
        default=DEFAULT_TEMPLATE_INTERP_PATH,
        track=False,
        help="Path to the saved template interpolation file.",
    ),
    strax.Option(
        "template_interp_folder",
        type=str,
        default=TEMPLATE_INTERP_FOLDER,
        track=False,
        help="Folder containing the template interpolation files.",
    ),
    strax.Option(
        "of_shift_range_min",
        type=int,
        default=-50,
        track=True,
        help="Minimum time shift for optimal filter coarse scan (in samples).",
    ),
    strax.Option(
        "of_shift_range_max",
        type=int,
        default=50,
        track=True,
        help="Maximum time shift for optimal filter coarse scan (in samples).",
    ),
    strax.Option(
        "of_shift_step",
        type=int,
        default=1,
        track=True,
        help="Step size for optimal filter coarse scan (in samples).",
    ),
    strax.Option(
        "noise_psd_placeholder",
        type=list,
        default=NOISE_PSD_38kHz,
        track=True,
        help=(
            "Noise power spectral density (PSD) array. " "The same PSD is used for all channels."
        ),
    ),
    strax.Option(
        "of_window_left",
        type=int,
        default=100,
        track=True,
        help=(
            "Left window size for optimal filter in samples. "
            "Window starts at HIT_WINDOW_LENGTH_LEFT - of_window_left."
        ),
    ),
    strax.Option(
        "of_window_right",
        type=int,
        default=300,
        track=True,
        help=(
            "Right window size for optimal filter in samples. "
            "Window ends at HIT_WINDOW_LENGTH_LEFT + of_window_right."
        ),
    ),
    strax.Option(
        "kappa_fit_half_band_width",
        type=int,
        default=25,
        track=True,
        help=(
            "Half band width around best shift for kappa fitting (in samples). "
            "This should not go beyond the bandwidth of of shift range.",
        ),
    ),
    strax.Option(
        "kappa_fit_smoothing_window",
        type=int,
        default=3,
        track=True,
        help="Window size for moving average smoothing before kappa fitting.",
    ),
    strax.Option(
        "kappa_fit_amplitude_bound_low",
        type=float,
        default=0.9,
        track=True,
        help="Lower bound multiplier for amplitude in kappa curve fitting.",
    ),
    strax.Option(
        "kappa_fit_amplitude_bound_high",
        type=float,
        default=1.1,
        track=True,
        help="Upper bound multiplier for amplitude in kappa curve fitting.",
    ),
    strax.Option(
        "kappa_fit_center_tolerance",
        type=float,
        default=0.1,
        track=True,
        help="Tolerance for center position bounds in kappa curve fitting (in samples).",
    ),
)
class DxHitClassification(strax.Plugin):
    """Classify hits into different types based on their coincidence with spikes."""

    __version__ = "0.3.3"

    depends_on = ("hits", "records", "noises")
    provides = "hit_classification"
    data_kind = "hits"
    save_when = strax.SaveWhen.ALWAYS

    def infer_dtype(self):
        base_dtype = [
            (("Start time since unix epoch [ns]", "time"), TIME_DTYPE),
            (("Exclusive end time since unix epoch [ns]", "endtime"), TIME_DTYPE),
            (("Channel number defined by channel_map", "channel"), CHANNEL_DTYPE),
        ]

        hit_id_dtype = [
            (("Is in coincidence with spikes", "is_coincident_with_spikes"), bool),
            (("Is symmetric spike hit", "is_symmetric_spike"), bool),
            (("Is truncated hit", "is_truncated_hit"), bool),
            (("Is invalid kappa (inf or nan)", "is_invalid_kappa"), bool),
            (("Photon candidate hit", "is_photon_candidate"), bool),
        ]

        hit_feature_dtype = [
            (
                (
                    "Rise edge slope of the hit waveform, in unit of dx/second",
                    "rise_edge_slope",
                ),
                DATA_DTYPE,
            ),
            (
                ("Number of channels with spikes coinciding with the hit", "n_spikes_coinciding"),
                int,
            ),
            (
                ("Best optimal filter amplitude", "best_aOF"),
                DATA_DTYPE,
            ),
            (
                ("Best chi-squared value from optimal filter", "best_chi2"),
                DATA_DTYPE,
            ),
            (
                ("Best time shift in samples for optimal filter", "best_OF_shift"),
                int,
            ),
            (
                ("Double-sided exponential width from aOF-shift fit", "kappa"),
                DATA_DTYPE,
            ),
            (
                (
                    (
                        "Width of the hit waveform (length above the hit threshold) "
                        "in unit of samples.",
                    ),
                    "width",
                ),
                INDEX_DTYPE,
            ),
            (
                (
                    ("Maximum amplitude of the dx hit waveform",),
                    "amplitude",
                ),
                DATA_DTYPE,
            ),
            (
                (
                    "Maximum amplitude of the dx hit waveform further smoothed by moving average",
                    "amplitude_moving_average",
                ),
                DATA_DTYPE,
            ),
            (
                (
                    "Maximum amplitude of the dx hit waveform further smoothed by pulse kernel",
                    "amplitude_convolved",
                ),
                DATA_DTYPE,
            ),
            (
                (
                    "Hit finding threshold in unit of dx=df/f0 for kernel convolved signal.",
                    "hit_threshold",
                ),
                DATA_DTYPE,
            ),
        ]

        return base_dtype + hit_id_dtype + hit_feature_dtype

    def setup(self):
        self.spike_coincidence_window = int(
            round(self.config["spike_coincidence_window"] * self.config["fs"])
        )
        self.spike_threshold_dx = self.config["spike_threshold_dx"]
        self.ss_min_slope = np.array(self.config["symmetric_spike_min_slope"])
        self.ss_window = self.config["symmetric_spike_inspection_window_length"]
        self.max_spike_coincidence = self.config["max_spike_coincidence"]
        self.dt_exact = 1 / self.config["fs"] * SECOND_TO_NANOSECOND
        self.template_interp_path = self.config["template_interp_path"]
        self.template_interp_folder = self.config["template_interp_folder"]
        self.noise_psd = self.config["noise_psd_placeholder"]
        self.of_window_left = self.config["of_window_left"]
        self.of_window_right = self.config["of_window_right"]
        self.kappa_fit_half_band_width = self.config["kappa_fit_half_band_width"]
        self.kappa_fit_smoothing_window = self.config["kappa_fit_smoothing_window"]
        self.kappa_fit_amplitude_bound_low = self.config["kappa_fit_amplitude_bound_low"]
        self.kappa_fit_amplitude_bound_high = self.config["kappa_fit_amplitude_bound_high"]
        self.kappa_fit_center_tolerance = self.config["kappa_fit_center_tolerance"]

        # Validate noise PSD length matches window size
        expected_length = self.of_window_left + self.of_window_right
        if len(self.noise_psd) != expected_length:
            raise ValueError(
                f"Noise PSD length ({len(self.noise_psd)}) does not match "
                f"optimal filter window size ({expected_length}). "
                f"Expected length: of_window_left ({self.of_window_left}) + "
                f"of_window_right ({self.of_window_right}) = {expected_length}"
            )

        # Load interpolation function
        self.At_interp, self.t_max = load_interpolation(self.template_interp_path)
        self.At_interp_dict = {}
        self.t_max_dict = {}
        # Load per-channel templates if folder exists, otherwise use default for all channels
        if os.path.isdir(self.template_interp_folder):
            for file in os.listdir(self.template_interp_folder):
                if file.endswith(".pkl"):
                    ch = int(file.split("_")[0].split("ch")[1])
                    self.At_interp_dict[ch], self.t_max_dict[ch] = load_interpolation(
                        os.path.join(self.template_interp_folder, file)
                    )

    def compute_per_channel_noise_psd(self, noises, n_channels):
        """Compute per-channel noise PSDs from noise windows.

        Args:
            noises (np.ndarray): Array of noise windows.
            n_channels (int): Number of channels.

        Returns:
            dict: Dictionary mapping channel number to PSD array.
                  Returns None for channels with no noise windows.

        """
        channel_noise_psds = {}
        window_size = self.of_window_left + self.of_window_right

        for ch in range(n_channels):
            # Filter noise windows for this channel
            ch_noises = noises[noises["channel"] == ch]

            if len(ch_noises) == 0:
                # No noise windows for this channel
                channel_noise_psds[ch] = None
            else:
                # Extract first window_size samples and compute PSDs
                psds = []
                for noise in ch_noises:
                    noise_window = noise["data_dx"][:window_size]
                    # Compute PSD: |FFT|^2
                    psd = np.abs(np.fft.fft(noise_window)) ** 2
                    psds.append(psd)

                # Average PSDs across all noise windows
                channel_noise_psds[ch] = np.mean(psds, axis=0)

        return channel_noise_psds

    @staticmethod
    @staticmethod
    def _movmean(data, window_size):
        """Calculate simple moving average of a 1D array.

        Uses numba-accelerated implementation for better performance.

        Args:
            data (np.ndarray): The input 1D array.
            window_size (int): The size of the moving average window.

        Returns:
            np.ndarray: Array containing the simple moving average.

        """
        if window_size <= 0:
            raise ValueError("Window size must be a positive integer.")
        # Use numba-accelerated version
        return _movmean_numba(np.asarray(data, dtype=np.float64), window_size)

    @staticmethod
    def _profile_fit(x, amplitude, center, kappa):
        """Double-sided exponential profile for fitting.

        Args:
            x (np.ndarray): The x values (time shifts).
            amplitude (float): The peak amplitude.
            center (float): The center position.
            kappa (float): The double-sided exponential width.

        Returns:
            np.ndarray: The profile values.

        """
        return amplitude * np.exp(-np.abs(x - center) / kappa)

    @staticmethod
    def modify_template(
        St,
        dt_seconds,
        tau,
        At_interp=None,
        t_max_seconds=None,
        amplitude=1.0,
        interp_path="template_interp.pkl",
        apply_window=False,
        of_window_left=None,
        of_window_right=None,
    ):
        """
        Modify template using pre-built interpolation function.

        Parameters:
        -----------
        St : array
            Signal timestream
        dt_seconds : float
            Time step in seconds
        tau : float
            Time shift parameter (in samples)
        At_interp : interp1d, optional
            Pre-built interpolation function.
            If None, loads from file.
        t_max_seconds : float, optional
            Time of maximum value in seconds. If None, loads from file.
        amplitude : float, optional
            Amplitude multiplier to scale the template. Default is 1.0.
        interp_path : str
            Path to saved interpolation file
        apply_window : bool, optional
            If True, apply windowing using of_window_left and
            of_window_right. Default is False for backward
            compatibility.
        of_window_left : int, optional
            Left window size for optimal filter in samples.
            Required if apply_window is True.
        of_window_right : int, optional
            Right window size for optimal filter in samples.
            Required if apply_window is True.

        Returns:
        --------
        At_modified : array
            Extended template array with padding, scaled by amplitude.
            If apply_window is True, returns only the windowed portion.
        """
        # Load interpolation function if not provided
        if At_interp is None or t_max_seconds is None:
            At_interp, t_max_seconds = load_interpolation(interp_path)

        target_length = len(St)
        t_seconds = np.arange(target_length) * dt_seconds
        max_index = np.argmin((t_seconds - t_max_seconds) ** 2)
        final_max_index = max_index + tau
        time_new_seconds = np.arange(target_length) * dt_seconds
        time_shift_seconds = time_new_seconds[final_max_index] - t_max_seconds
        timeshifted_seconds = time_new_seconds - time_shift_seconds
        At_modified = At_interp(timeshifted_seconds) * amplitude

        # Apply windowing if requested
        if apply_window:
            if of_window_left is None or of_window_right is None:
                raise ValueError(
                    "of_window_left and of_window_right must be "
                    "provided when apply_window is True"
                )
            window_start = max_index - of_window_left
            window_end = max_index + of_window_right
            At_modified = At_modified[window_start:window_end]

        return At_modified

    @staticmethod
    def _optimal_filter(St, Jf, At):
        """
        Calculate optimal filter amplitude and chi-squared score.

        Parameters:
        -----------
        St : array
            Signal timestream (to be filtered)
        Jf : array
            Noise PSD (taken from averaged FFTs of many noise banks)
        At : array
            Template timestream (to be filtered)

        Returns:
        --------
        ahatOF : float
            Optimal filter amplitude scaling factor
        chisq : float
            Chi-squared score
        """

        Sf = np.fft.fft(St)  # FFT of the hit signal
        Af = np.fft.fft(At)  # FFT of the template

        # Calculate optimal filter amplitude
        numer = np.sum(np.real(np.multiply(Sf, np.conjugate(Af))))
        denom = np.sum(np.real(np.multiply(Af, np.conjugate(Af))))
        ahatOF = numer / denom

        # Protect against division by zero in chi-squared calculation
        # Replace zero or very small values in Jf with a small positive value
        Jf_safe = np.where(Jf > 1e-20, Jf, 1e-20)
        chisq = np.sum(np.abs(Sf - ahatOF * Af) ** 2 / Jf_safe) / (len(Sf) - 1)

        return ahatOF, chisq

    @staticmethod
    def _optimal_filter_with_precomputed_fft(Sf, Jf_safe, At):
        """
        Calculate optimal filter amplitude and chi-squared with pre-computed signal FFT.

        This is an optimized version that avoids redundant FFT computation of the signal.

        Parameters:
        -----------
        Sf : array
            Pre-computed FFT of the signal timestream
        Jf_safe : array
            Safe noise PSD (with zeros replaced by small positive values)
        At : array
            Template timestream (to be filtered)

        Returns:
        --------
        ahatOF : float
            Optimal filter amplitude scaling factor
        chisq : float
            Chi-squared score
        """
        Af = np.fft.fft(At)  # FFT of the template

        # Calculate optimal filter amplitude
        numer = np.sum(np.real(Sf * np.conjugate(Af)))
        denom = np.sum(np.real(Af * np.conjugate(Af)))
        ahatOF = numer / denom

        # Chi-squared calculation
        chisq = np.sum(np.abs(Sf - ahatOF * Af) ** 2 / Jf_safe) / (len(Sf) - 1)

        return ahatOF, chisq

    @staticmethod
    def _extract_signal_window(St, dt_seconds, t_max_seconds, of_window_left, of_window_right):
        """Extract windowed signal around t_max for optimal filter.

        Args:
            St: Signal timestream
            dt_seconds: Time step in seconds
            t_max_seconds: Time of maximum value in seconds
            of_window_left: Left window size in samples
            of_window_right: Right window size in samples

        Returns:
            tuple: (St_windowed, window_start, window_end, max_index)
        """
        t_seconds = np.arange(len(St)) * dt_seconds
        max_index = np.argmin((t_seconds - t_max_seconds) ** 2)
        window_start = max_index - of_window_left
        window_end = max_index + of_window_right
        St_windowed = St[window_start:window_end]
        return St_windowed, window_start, window_end, max_index

    @staticmethod
    def _compute_shifted_template_ffts(
        St,
        dt_seconds,
        At_interp,
        t_max_seconds,
        of_window_left,
        of_window_right,
        N_shiftOF_arr,
        n_samples,
    ):
        """Compute FFTs of all shifted templates using FFT time-shift property.

        Args:
            St: Signal timestream (for template generation)
            dt_seconds: Time step in seconds
            At_interp: Template interpolation function
            t_max_seconds: Time of maximum value in seconds
            of_window_left: Left window size in samples
            of_window_right: Right window size in samples
            N_shiftOF_arr: Array of time shifts in samples
            n_samples: Number of samples in windowed signal

        Returns:
            tuple: (Af_all, Af_real_all, Af_imag_all) - FFTs of all shifted templates
        """
        # Pre-compute base template at tau=0
        At_base = DxHitClassification.modify_template(
            St,
            dt_seconds,
            0,  # tau=0 for base template
            At_interp=At_interp,
            t_max_seconds=t_max_seconds,
            apply_window=True,
            of_window_left=of_window_left,
            of_window_right=of_window_right,
        )
        Af_base = np.fft.fft(At_base)

        # Pre-compute frequency indices for shift
        k = np.fft.fftfreq(n_samples) * n_samples  # frequency bin indices

        # Vectorized computation of all shifted template FFTs
        # Using FFT time-shift property: FFT(shift(x, tau)) = FFT(x) * exp(-2*pi*j*k*tau/N)
        phase_shifts = np.exp(
            -2j * np.pi * k[np.newaxis, :] * N_shiftOF_arr[:, np.newaxis] / n_samples
        )
        Af_all = Af_base[np.newaxis, :] * phase_shifts  # (n_shifts, n_samples)

        # Extract real and imaginary parts for numba
        Af_real_all = np.real(Af_all).astype(np.float64)
        Af_imag_all = np.imag(Af_all).astype(np.float64)

        return Af_all, Af_real_all, Af_imag_all

    @staticmethod
    def _fit_kappa(
        ahatOF_arr,
        N_shiftOF_arr,
        best_idx,
        best_aOF,
        best_OF_shift,
        kappa_fit_half_band_width,
        kappa_fit_smoothing_window,
        kappa_fit_amplitude_bound_low,
        kappa_fit_amplitude_bound_high,
        kappa_fit_center_tolerance,
    ):
        """Fit kappa by fitting double-sided exponential to aOF vs shift curve.

        Args:
            ahatOF_arr: Array of optimal filter amplitudes for each shift
            N_shiftOF_arr: Array of time shifts in samples
            best_idx: Index of best shift
            best_aOF: Best optimal filter amplitude
            best_OF_shift: Best time shift in samples
            kappa_fit_half_band_width: Half band width for fitting
            kappa_fit_smoothing_window: Window size for moving average
            kappa_fit_amplitude_bound_low: Lower bound multiplier for amplitude
            kappa_fit_amplitude_bound_high: Upper bound multiplier for amplitude
            kappa_fit_center_tolerance: Tolerance for center position bounds

        Returns:
            tuple: (kappa, profile, popt) - kappa value, smoothed profile, fit params
        """
        hbw = kappa_fit_half_band_width

        # Compute smoothed profile unconditionally (needed for debug plotting)
        profile = _movmean_numba(ahatOF_arr, kappa_fit_smoothing_window)

        # Store fitted parameters (None if fit fails/skipped)
        popt = None

        if best_idx - hbw < 0 or best_idx + hbw > len(N_shiftOF_arr):
            # Fit window out of bounds
            kappa = np.inf
        else:
            try:
                # Extract the fine region around best shift
                N_shiftOF_arr_fine = N_shiftOF_arr[best_idx - hbw : best_idx + hbw]
                profile_fine = profile[best_idx - hbw : best_idx + hbw]

                # Initial guess: [amplitude, center, kappa]
                p0 = [best_aOF, float(best_OF_shift), 1.0]

                # Set bounds for curve_fit
                # Use min/max to handle negative best_aOF correctly
                amp_bound_1 = best_aOF * kappa_fit_amplitude_bound_low
                amp_bound_2 = best_aOF * kappa_fit_amplitude_bound_high
                amp_lower = min(amp_bound_1, amp_bound_2)
                amp_upper = max(amp_bound_1, amp_bound_2)

                bounds = (
                    [
                        amp_lower,
                        best_OF_shift - kappa_fit_center_tolerance,
                        0,
                    ],  # lower bounds
                    [
                        amp_upper,
                        best_OF_shift + kappa_fit_center_tolerance,
                        np.inf,
                    ],  # upper bounds
                )

                popt, _ = curve_fit(
                    DxHitClassification._profile_fit,
                    N_shiftOF_arr_fine.astype(np.float64),
                    profile_fine,
                    p0=p0,
                    bounds=bounds,
                )
                kappa = popt[2]
            except (RuntimeError, ValueError):
                # Fit failed
                kappa = np.inf

        return kappa, profile, popt

    @staticmethod
    def _plot_optimal_filter_debug(
        St,
        dt_seconds,
        window_start,
        window_end,
        At_shifted_arr,
        N_shiftOF_arr,
        best_At_shifted,
        best_aOF,
        best_OF_shift,
        kappa,
        ahatOF_arr,
        profile,
        popt,
        kappa_fit_half_band_width,
    ):
        """Create debug plots for optimal filter visualization.

        Args:
            St: Original signal timestream
            dt_seconds: Time step in seconds
            St_windowed: Windowed signal
            window_start: Start index of window
            window_end: End index of window
            At_shifted_arr: Array of shifted templates
            N_shiftOF_arr: Array of time shifts in samples
            best_At_shifted: Best shifted template
            best_aOF: Best optimal filter amplitude
            best_OF_shift: Best time shift in samples
            kappa: Fitted kappa value
            ahatOF_arr: Array of amplitudes for each shift
            profile: Smoothed profile
            popt: Fitted parameters (None if fit failed)
            kappa_fit_half_band_width: Half band width for kappa fitting
        """
        import matplotlib.pyplot as plt
        from straxion import register_xenon_colors

        # Load custom style and register xenon colors
        mplstyle_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".customized_mplstyle"
        )
        if os.path.exists(mplstyle_path):
            plt.style.use(mplstyle_path)
        register_xenon_colors()

        # Compute time arrays and sampling frequency
        fs = 1.0 / dt_seconds
        times_ms = np.arange(len(St)) * 1000 / fs
        shifts_ms = N_shiftOF_arr / fs * 1000

        # Create 2-column figure
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6, 3))

        # === Left plot: OF Visualization ===
        # Plot original signal
        ax1.plot(times_ms, St, alpha=0.5, color="gray")

        # Plot all shifted templates
        window_times_ms = times_ms[window_start:window_end]
        for i, At_shifted in enumerate(At_shifted_arr):
            ax1.plot(window_times_ms, At_shifted, color="xenon_lightblue", alpha=0.05)
            # Highlight unshifted template (shift=0)
            if N_shiftOF_arr[i] == 0:
                ax1.plot(window_times_ms, At_shifted, color="xenon_red", alpha=1, label="Unshifted")

        # Plot best shifted template
        ax1.plot(window_times_ms, best_At_shifted, color="xenon_blue", label="Best")

        ax1.set_xlabel("Time [ms]")
        ax1.set_ylabel(r"Amplitude $\delta x$")
        ax1.legend(loc="best")
        ax1.set_xlim(times_ms[0], times_ms[-1])

        # === Right plot: Kappa Derivation ===
        # Plot raw ahatOF vs shifts
        ax2.plot(shifts_ms, ahatOF_arr, "o", markersize=2, alpha=0.5, label="Raw")

        # Plot smoothed profile
        ax2.plot(shifts_ms, profile, "-", linewidth=1, label="Smoothed")

        # Plot best-fit double exponential if fitting succeeded
        if popt is not None and np.isfinite(kappa):
            # Generate fit curve centered at the fitted center (popt[1])
            # and spanning the fitting half-band width on each side
            fit_center = popt[1]  # fitted center in samples
            fit_shifts = np.linspace(
                fit_center - kappa_fit_half_band_width, fit_center + kappa_fit_half_band_width, 100
            )
            fit_curve = DxHitClassification._profile_fit(
                fit_shifts.astype(np.float64), popt[0], popt[1], popt[2]
            )
            fit_shifts_ms = fit_shifts / fs * 1000
            ax2.plot(fit_shifts_ms, fit_curve, "--", color="xenon_red", linewidth=1.5, label="Fit")

        ax2.set_xlabel("Time shift [ms]")
        ax2.set_ylabel(r"$\hat{a}$")
        ax2.legend(loc="best")

        # Shared title for both plots
        fig.suptitle(
            rf"$t_0={best_OF_shift / fs * 1000:.2f}$ ms, "
            rf"$\hat{{a}}={best_aOF:.2e}$, "
            rf"$\kappa={kappa / fs * 1000:.2f}$ ms"
        )

        plt.tight_layout()
        plt.show()

    @staticmethod
    def optimal_filter(
        St,
        dt_seconds,
        Jf,
        At_interp,
        t_max_seconds,
        of_window_left=100,
        of_window_right=300,
        of_shift_range_min=-50,
        of_shift_range_max=50,
        of_shift_step=1,
        kappa_fit_half_band_width=25,
        kappa_fit_smoothing_window=3,
        kappa_fit_amplitude_bound_low=0.9,
        kappa_fit_amplitude_bound_high=1.1,
        kappa_fit_center_tolerance=0.1,
        debug=False,
    ):
        """
        Calculate optimal filter with coarse time shift optimization.

        This is an optimized implementation using:
        1. Pre-computed signal FFT (computed once, reused for all shifts)
        2. Vectorized template generation using FFT time-shift property
        3. Numba-accelerated batch chi2 computation
        4. Numba-accelerated moving average for kappa fitting

        Parameters:
        -----------
        St : array
            Signal timestream (to be filtered)
        dt_seconds : float
            Time step in seconds
        Jf : array
            Noise PSD (taken from averaged FFTs of many noise banks)
        At_interp : interp1d
            Pre-built interpolation function
        t_max_seconds : float
            Time of maximum value in seconds
        of_window_left : int
            Left window size for optimal filter in samples
        of_window_right : int
            Right window size for optimal filter in samples
        of_shift_range_min : int
            Minimum time shift for optimal filter coarse scan (samples)
        of_shift_range_max : int
            Maximum time shift for optimal filter coarse scan (samples)
        of_shift_step : int
            Step size for optimal filter coarse scan (in samples)
        kappa_fit_half_band_width : int
            Half band width around best shift for kappa fitting (in samples)
        kappa_fit_smoothing_window : int
            Window size for moving average smoothing before kappa fitting
        kappa_fit_amplitude_bound_low : float
            Lower bound multiplier for amplitude in kappa curve fitting
        kappa_fit_amplitude_bound_high : float
            Upper bound multiplier for amplitude in kappa curve fitting
        kappa_fit_center_tolerance : float
            Tolerance for center position bounds in kappa curve fitting (in samples)
        debug : bool
            Whether to return the chi-squared values for all time shifts
            and the shifted templates. Default is False.

        Returns:
        --------
        best_aOF : float
            Best optimal filter amplitude
        best_chi2 : float
            Best chi-squared value
        best_OF_shift : int
            Best time shift in samples
        kappa : float
            Double-sided exponential width from fitting aOF vs shift
        best_At_shifted : array
            Template shifted to best position and scaled by best_aOF

        Notes:
        ------
        Kappa is computed by fitting a double-sided exponential profile
        `amplitude * exp(-|x - center| / kappa)` to the smoothed aOF vs shift curve.
        The curve_fit bounds constrain the three fitted parameters:

        +-----------+----------------------------------+----------------------------------+
        | Parameter | Lower Bound                      | Upper Bound                      |
        +===========+==================================+==================================+
        | amplitude | best_aOF * amplitude_bound_low   | best_aOF * amplitude_bound_high  |
        +-----------+----------------------------------+----------------------------------+
        | center    | best_OF_shift - center_tolerance | best_OF_shift + center_tolerance |
        +-----------+----------------------------------+----------------------------------+
        | kappa     | 0                                | inf                              |
        +-----------+----------------------------------+----------------------------------+

        The amplitude and center are tightly constrained since we already found good
        values from the optimal filter. Kappa is the parameter we want to estimate.
        """
        # Extract windowed signal
        St_windowed, window_start, window_end, max_index = (
            DxHitClassification._extract_signal_window(
                St, dt_seconds, t_max_seconds, of_window_left, of_window_right
            )
        )
        n_samples = len(St_windowed)

        # Pre-compute signal FFT once (reused for all shifts)
        Sf = np.fft.fft(St_windowed)
        Sf_real = np.real(Sf).astype(np.float64)
        Sf_imag = np.imag(Sf).astype(np.float64)

        # Pre-compute safe Jf (avoid repeated np.where)
        Jf_safe = np.where(Jf > 1e-20, Jf, 1e-20).astype(np.float64)

        # Define shift array
        N_shiftOF_arr = np.arange(
            of_shift_range_min,
            of_shift_range_max,
            of_shift_step,
        )
        n_shifts = len(N_shiftOF_arr)

        # Compute all shifted template FFTs using FFT time-shift property
        Af_all, Af_real_all, Af_imag_all = DxHitClassification._compute_shifted_template_ffts(
            St,
            dt_seconds,
            At_interp,
            t_max_seconds,
            of_window_left,
            of_window_right,
            N_shiftOF_arr,
            n_samples,
        )

        # Use numba-accelerated batch computation
        ahatOF_arr, chi2_arr = _compute_chi2_batch_numba(
            Sf_real, Sf_imag, Af_real_all, Af_imag_all, Jf_safe, n_samples, n_shifts
        )

        # Store debug info if needed
        if debug:
            At_shifted_arr = np.zeros(n_shifts, dtype=object)
            for nn in range(n_shifts):
                # Reconstruct template from FFT for debug output
                At_shifted_arr[nn] = np.real(np.fft.ifft(Af_all[nn])) * ahatOF_arr[nn]

        # Find best shift
        best_idx = np.argmin(chi2_arr)
        best_chi2 = chi2_arr[best_idx]
        best_aOF = ahatOF_arr[best_idx]
        best_OF_shift = N_shiftOF_arr[best_idx]

        # Fit kappa from aOF vs shift curve
        kappa, profile, popt = DxHitClassification._fit_kappa(
            ahatOF_arr,
            N_shiftOF_arr,
            best_idx,
            best_aOF,
            best_OF_shift,
            kappa_fit_half_band_width,
            kappa_fit_smoothing_window,
            kappa_fit_amplitude_bound_low,
            kappa_fit_amplitude_bound_high,
            kappa_fit_center_tolerance,
        )

        # Generate final shifted template scaled by best amplitude
        best_At_shifted = np.real(np.fft.ifft(Af_all[best_idx])) * best_aOF

        # Create debug plots if requested
        if debug:
            DxHitClassification._plot_optimal_filter_debug(
                St,
                dt_seconds,
                window_start,
                window_end,
                At_shifted_arr,
                N_shiftOF_arr,
                best_At_shifted,
                best_aOF,
                best_OF_shift,
                kappa,
                ahatOF_arr,
                profile,
                popt,
                kappa_fit_half_band_width,
            )
            return (
                best_aOF,
                best_chi2,
                best_OF_shift,
                kappa,
                best_At_shifted,
                chi2_arr,
                At_shifted_arr,
                ahatOF_arr,
            )
        else:
            return best_aOF, best_chi2, best_OF_shift, kappa, best_At_shifted

    def determine_spike_threshold(self, records):
        """Determine the spike threshold based on the provided configuration.
        You can either provide spike_threshold_dx or spike_thresholds_sigma.
        You cannot provide both.

        Returns:
            np.ndarray: Spike threshold for each record.
        """
        if self.spike_threshold_dx is None and self.spike_thresholds_sigma is not None:
            # If spike_thresholds_sigma are single values,
            # we need to convert them to arrays.
            if isinstance(self.spike_thresholds_sigma, float):
                spike_thresholds_sigma = np.full(
                    len(records["channel"]), self.spike_thresholds_sigma
                )
            else:
                spike_thresholds_sigma = np.array(self.spike_thresholds_sigma)
            # Calculate spike threshold and find spike candidates
            spike_threshold_dx = DxHits.calculate_hit_threshold(
                records["data_dx_convolved"],
                spike_thresholds_sigma[records["channel"]],
            )
        elif self.spike_threshold_dx is not None and self.spike_thresholds_sigma is None:
            # If spike_threshold_dx is a single value, we need to convert it to an array.
            if isinstance(self.spike_threshold_dx, float):
                spike_threshold_dx = np.full(len(records["channel"]), self.spike_threshold_dx)
            else:
                spike_threshold_dx = np.array(self.spike_threshold_dx)
        else:
            raise ValueError(
                "Either spike_threshold_dx or spike_thresholds_sigma "
                "must be provided. You cannot provide both."
            )

        return spike_threshold_dx

    def _get_ss_window(self, hits, window_start_offset):
        """Extract windows from all hits using vectorized operations.

        Args:
            hits: Array of hits containing the data
            window_start_offset: Offset from climax_shift for window starts in samples.

        Returns:
            Array of extracted windows with shape (n_hits, window_length)
        """
        # The inspected window ends at the maximum of the moving averaged signal.
        climax_shift = (
            hits["amplitude_moving_average_max_record_i"] - hits["amplitude_convolved_max_record_i"]
        )

        # Calculate start indices for all hits at once
        start_indices = window_start_offset + climax_shift

        # Extract windows using vectorized operations
        # Create index arrays for all hits
        n_hits = len(hits)
        window_indices = np.arange(self.ss_window)[None, :]  # Shape: (1, ss_window)
        start_indices = start_indices[:, None]  # Shape: (n_hits, 1)

        # Broadcast to get all indices for all hits
        all_indices = start_indices + window_indices  # Shape: (n_hits, ss_window)

        # Get waveform length to validate bounds
        waveform_length = hits["data_dx_moving_average"].shape[1]

        # Clamp indices to valid range [0, waveform_length - 1] to prevent IndexError
        # This handles cases where climax_shift is too large (e.g., >= 601)
        all_indices = np.clip(all_indices, 0, waveform_length - 1)

        # Use advanced indexing to extract all windows at once
        return hits["data_dx_moving_average"][np.arange(n_hits)[:, None], all_indices]

    def compute_rise_edge_slope(self, hits, hit_classification):
        """Compute the rise edge slope of the moving averaged signal."""

        # Temporary time stamps for the inspected window, in unit of seconds.
        dt_nanoseconds = self.dt_exact
        times_seconds = np.arange(self.ss_window) * dt_nanoseconds / SECOND_TO_NANOSECOND

        inspected_wfs = self._get_ss_window(hits, HIT_WINDOW_LENGTH_LEFT - self.ss_window)
        # Fit a linear model to the inspected window.
        hit_classification["rise_edge_slope"] = np.polyfit(times_seconds, inspected_wfs.T, 1)[0]

    def is_symmetric_spike_hit(self, hits, hit_classification):
        """Identify symmetric spike hits."""
        hit_classification["is_symmetric_spike"] = (
            hit_classification["rise_edge_slope"] < self.ss_min_slope[hits["channel"]]
        )

    def is_truncated_hit(self, hits, hit_classification):
        """Identify truncated hits.

        A hit is considered truncated if its length does not equal
        the expected full window length.
        """
        expected_length = HIT_WINDOW_LENGTH_LEFT + HIT_WINDOW_LENGTH_RIGHT
        hit_classification["is_truncated_hit"] = hits["length"] != expected_length

    def find_spike_coincidence(self, hit_classification, hits, records, spike_threshold_dx):
        """Find the spike coincidence of the hit in the convolved signal.

        Args:
            hit_classification (np.ndarray): Array to store classification results.
            hits (np.ndarray): Array of hits.
            records (np.ndarray): Array of records.
            spike_threshold_dx (np.ndarray): Spike threshold for each record.
        """
        spike_coincidence = np.zeros(len(hits))
        for i, hit in enumerate(hits):
            # Get the index of the hit maximum in the record
            hit_climax_i = hit["amplitude_convolved_max_record_i"]

            # Calculate slice boundaries
            start_i = hit_climax_i - self.spike_coincidence_window
            end_i = hit_climax_i + self.spike_coincidence_window

            # Skip if window is invalid or empty
            if start_i >= end_i or end_i <= 0 or start_i >= records["data_dx"].shape[1]:
                continue

            # Extract windows from all records at once
            inspected_wfs = records["data_dx_convolved"][:, start_i:end_i]

            # Skip if inspected_wfs is empty (shape[1] == 0)
            if inspected_wfs.shape[1] == 0:
                continue

            # Count records with spikes above threshold
            spike_coincidence[i] = np.sum(
                np.max(inspected_wfs, axis=1) > spike_threshold_dx[records["channel"]]
            )
        hit_classification["n_spikes_coinciding"] = spike_coincidence

    def compute_optimal_filter_parameters(self, hit_classification, hits, channel_noise_psds):
        """Compute optimal filter parameters for all hits.

        Uses hits["data_dx"] as the signal timestream and
        per-channel noise PSDs from channel_noise_psds.
        Falls back to self.noise_psd placeholder if no PSD available for a channel.

        Args:
            hit_classification (np.ndarray): Array to store classification results.
            hits (np.ndarray): Array of hits.
            channel_noise_psds (dict): Dictionary mapping channel to PSD array.

        Note: All optimal filter calculations require dt in seconds.
        """
        # Convert dt from nanoseconds to seconds for optimal filter
        # self.dt_exact is in nanoseconds (= 1/fs * SECOND_TO_NANOSECOND)
        # Optimal filter functions require dt in seconds
        dt_seconds = self.dt_exact / SECOND_TO_NANOSECOND

        # Convert placeholder noise_psd to numpy array if it's a list
        if isinstance(self.noise_psd, list):
            placeholder_psd = np.array(self.noise_psd)
        else:
            placeholder_psd = self.noise_psd

        for i, hit in enumerate(hits):
            # Extract signal timestream from hit
            St = hit["data_dx"]
            ch = hit["channel"]

            # Get channel-specific PSD or use placeholder
            if channel_noise_psds[ch] is None:
                # No noise windows for this channel, use placeholder
                self.log.warning(
                    f"No noise windows found for channel {ch}, " f"using placeholder PSD"
                )
                Jf = placeholder_psd
            else:
                Jf = channel_noise_psds[ch]

            # If the template interpolation file for this channel exists, use it,
            # otherwise use the default one.
            if ch in self.At_interp_dict.keys():
                At_interp = self.At_interp_dict[ch]
                t_max = self.t_max_dict[ch]
            else:
                At_interp = self.At_interp
                t_max = self.t_max

            # Compute optimal filter with shift optimization
            # dt_seconds is explicitly in seconds
            best_aOF, best_chi2, best_OF_shift, kappa, _ = self.optimal_filter(
                St,
                dt_seconds,
                Jf,
                At_interp,
                t_max,
                self.of_window_left,
                self.of_window_right,
                self.config["of_shift_range_min"],
                self.config["of_shift_range_max"],
                self.config["of_shift_step"],
                self.kappa_fit_half_band_width,
                self.kappa_fit_smoothing_window,
                self.kappa_fit_amplitude_bound_low,
                self.kappa_fit_amplitude_bound_high,
                self.kappa_fit_center_tolerance,
            )

            # Store results
            hit_classification["best_aOF"][i] = best_aOF
            hit_classification["best_chi2"][i] = best_chi2
            hit_classification["best_OF_shift"][i] = best_OF_shift
            hit_classification["kappa"][i] = kappa

    def compute(self, hits, records, noises):
        spike_threshold_dx = self.determine_spike_threshold(records)

        # Compute per-channel noise PSDs from noise windows
        n_channels = len(records)
        channel_noise_psds = self.compute_per_channel_noise_psd(noises, n_channels)

        hit_classification = np.zeros(len(hits), dtype=self.infer_dtype())
        hit_classification["time"] = hits["time"]
        hit_classification["endtime"] = hits["endtime"]
        hit_classification["channel"] = hits["channel"]
        hit_classification["width"] = hits["width"]
        hit_classification["amplitude"] = hits["amplitude"]
        hit_classification["amplitude_moving_average"] = hits["amplitude_moving_average"]
        hit_classification["amplitude_convolved"] = hits["amplitude_convolved"]
        hit_classification["hit_threshold"] = hits["hit_threshold"]

        self.compute_rise_edge_slope(hits, hit_classification)
        self.find_spike_coincidence(hit_classification, hits, records, spike_threshold_dx)
        self.is_symmetric_spike_hit(hits, hit_classification)
        self.is_truncated_hit(hits, hit_classification)

        # Compute optimal filter parameters with per-channel PSDs
        self.compute_optimal_filter_parameters(hit_classification, hits, channel_noise_psds)

        hit_classification["is_coincident_with_spikes"] = (
            hit_classification["n_spikes_coinciding"] > self.max_spike_coincidence
        )

        # Invalid kappa means not finite (inf or nan)
        hit_classification["is_invalid_kappa"] = ~np.isfinite(hit_classification["kappa"])

        # Photon candidate must pass all quality cuts (all exclusion flags must be False)
        hit_classification["is_photon_candidate"] = ~(
            hit_classification["is_coincident_with_spikes"]
            | hit_classification["is_symmetric_spike"]
            | hit_classification["is_truncated_hit"]
            | hit_classification["is_invalid_kappa"]
        )

        return hit_classification


@export
@strax.takes_config(
    strax.Option(
        "cr_ma_std_coeff",
        type=list,
        default=[20.0 for _ in range(41)],
        help=(
            "Coefficients applied to the moving averaged signal's "
            "standard deviation for identifying cosmic ray hits."
        ),
    ),
    strax.Option(
        "cr_convolved_std_coeff",
        type=list,
        default=[20.0 for _ in range(41)],
        help=(
            "Coefficients applied to the convolved signal's "
            "standard deviation for identifying cosmic ray hits."
        ),
    ),
    strax.Option(
        "cr_min_ma_amplitude",
        type=list,
        default=[1.0 for _ in range(41)],
        help=(
            "Minimum amplitude of the moving averaged signal's " "for identifying cosmic ray hits."
        ),
    ),
    strax.Option(
        "symmetric_spike_min_slope",
        type=list,
        default=[75.0 for _ in range(41)],
        help=(
            "Minimum slope for identifying a physical hit against symmetric spikes, "
            "in unit of rad/second."
        ),
    ),
    strax.Option(
        "symmetric_spike_inspection_window_length",
        type=int,
        default=25,
        help=(
            "Length of the inspection window for identifying symmetric spikes, "
            "in unit of samples."
        ),
    ),
)
class HitClassification(strax.Plugin):
    """Classify hits into different types based on their characteristics."""

    __version__ = "0.0.0"

    depends_on = "hits"
    provides = "hit_classification"
    data_kind = "hits"
    save_when = strax.SaveWhen.ALWAYS

    def setup(self):
        self.cr_ma_std_coeff = np.array(self.config["cr_ma_std_coeff"])
        self.cr_convolved_std_coeff = np.array(self.config["cr_convolved_std_coeff"])
        self.cr_min_ma_amplitude = np.array(self.config["cr_min_ma_amplitude"])
        self.ss_min_slope = np.array(self.config["symmetric_spike_min_slope"])
        self.ss_window = self.config["symmetric_spike_inspection_window_length"]

    def infer_dtype(self):
        base_dtype = [
            (("Start time since unix epoch [ns]", "time"), TIME_DTYPE),
            (("Exclusive end time since unix epoch [ns]", "endtime"), TIME_DTYPE),
            (("Channel number defined by channel_map", "channel"), CHANNEL_DTYPE),
        ]

        hit_id_dtype = [
            (("Is identified as cosmic ray hit", "is_cr"), bool),
            (("Is identified as symmetric spike hit", "is_symmetric_spike"), bool),
            (("Is unidentified hit", "is_unidentified"), bool),
        ]

        hit_feature_dtype = [
            (
                (
                    "Rise edge slope of the moving averaged signal, in unit of rad/second",
                    "ma_rise_edge_slope",
                ),
                DATA_DTYPE,
            ),
        ]

        return base_dtype + hit_id_dtype + hit_feature_dtype

    def compute_ma_rise_edge_slope(self, hits, hit_classification):
        """Compute the rise edge slope of the moving averaged signal."""
        assert (
            len(np.unique(hits["dt"])) == 1
        ), "The sampling frequency is not constant!? We found {} unique values: {}".format(
            len(np.unique(hits["dt"])), np.unique(hits["dt"])
        )
        # Temporary time stamps for the inspected window, in unit of seconds.
        dt = hits["dt"][0]
        times = np.arange(self.ss_window) * dt / SECOND_TO_NANOSECOND

        # Extract windows from all hits at once (fully vectorized)
        inspected_wfs = hits["data_theta_moving_average"][
            :, HIT_WINDOW_LENGTH_LEFT - self.ss_window : HIT_WINDOW_LENGTH_LEFT
        ]
        # Fit a linear model to the inspected window.
        hit_classification["ma_rise_edge_slope"] = np.polyfit(times, inspected_wfs.T, 1)[0]

    def is_unidentified_hit(self, hits, hit_classification):
        """Identify unidentified hits.

        The hit is identified as an unidentified hit if the amplitude of the hit is
        less than the threshold.

        Args:
            hits (np.ndarray): Hit array.

        """
        hit_classification["is_unidentified"] = (
            hits["amplitude_convolved_max"] < hits["hit_threshold"]
        )

    def is_cr_hit(self, hits, hit_classification):
        """Identify cosmic ray hits.

        The hit is identified as a cosmic ray hit if it satisfies either of the following
        conditions, for both convolved and moving averaged signals:
        1. The amplitude of the hit is greater than the threshold.
        2. The amplitude of the hit is greater than the standard deviation of the signal
        multiplied by the coefficient.

        Args:
            hits (np.ndarray): Hit array.

        Returns:
            np.ndarray: Hit array with `is_cr` field.

        """
        mask_convolved = hits["amplitude_convolved_max"] >= hits["hit_threshold"]
        mask_convolved &= hits["amplitude_convolved_max_ext"] >= (
            hits["record_convolved_std"] * self.cr_convolved_std_coeff[hits["channel"]]
        )
        mask_ma = hits["amplitude_ma_max_ext"] >= self.cr_min_ma_amplitude[hits["channel"]]
        mask_ma |= hits["amplitude_ma_max_ext"] >= (
            hits["record_ma_mean"] + hits["record_ma_std"] * self.cr_ma_std_coeff[hits["channel"]]
        )
        hit_classification["is_cr"] = mask_convolved | mask_ma

    def is_symmetric_spike_hit(self, hits, hit_classification):
        self.compute_ma_rise_edge_slope(hits, hit_classification)
        hit_classification["is_symmetric_spike"] = (
            hit_classification["ma_rise_edge_slope"] < self.ss_min_slope[hits["channel"]]
        )

    def compute(self, hits):
        hit_classification = np.zeros(len(hits), dtype=self.infer_dtype())
        hit_classification["time"] = hits["time"]
        hit_classification["endtime"] = hits["endtime"]
        hit_classification["channel"] = hits["channel"]

        self.is_unidentified_hit(hits, hit_classification)
        self.is_cr_hit(hits, hit_classification)
        self.is_symmetric_spike_hit(hits, hit_classification)

        return hit_classification
