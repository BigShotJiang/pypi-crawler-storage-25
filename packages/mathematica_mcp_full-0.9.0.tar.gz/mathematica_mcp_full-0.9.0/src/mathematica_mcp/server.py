import asyncio
import contextlib
import difflib
import json
import logging
import os
import re
from collections.abc import Callable
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP, Image

from .cache import (
    _query_cache,
    bump_kernel_epoch,
    clear_cache,
    list_cached_expressions,
)
from .cache import (
    cache_expression as _cache_expr,
)
from .cache import (
    get_cached_expression as _get_cached,
)
from .config import FEATURES
from .connection import get_mathematica_connection
from .constants import ExecutionPath as _EP
from .error_analyzer import analyze_messages, format_error_for_llm
from .guidance import (
    build_mathematica_expert_prompt,
    create_notebook_doc,
    evaluate_cell_doc,
    evaluate_selection_doc,
    execute_code_doc,
    legacy_notebook_doc,
    read_notebook_doc,
    write_cell_doc,
)
from .session import (
    clear_raster_cache,
    close_kernel_session,
    execute_in_kernel,
    get_kernel_session,
)
from .telemetry import get_usage_stats, reset_stats
from .transport_classification import (
    classify_final_transport as _classify_transport,
)
from .transport_classification import (
    extract_error_families as _extract_error_families,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("mathematica_mcp")

mcp = FastMCP(
    "mathematica-mcp",
    instructions=(
        "You have access to a live Mathematica instance through this MCP server. "
        "ALWAYS use the provided MCP tools (execute_code, create_notebook, etc.) for "
        "ALL Mathematica tasks. NEVER use wolframscript CLI, shell commands, or manual "
        ".nb file creation — the MCP tools talk directly to the running Mathematica "
        "frontend and kernel.\n\n"
        "IMPORTANT: A 'notebook' here means a LIVE WINDOW inside the Mathematica "
        "frontend, not a .nb file on disk. create_notebook() opens a live window. "
        "execute_code(output_target='notebook') writes and evaluates code in that "
        "live window. You do NOT need to search for files, create directories, or "
        "save/export anything unless the user explicitly asks.\n\n"
        "Workflow (use the style= parameter for easy mode selection):\n"
        "- User says 'calculate/compute/what is' → execute_code(style='compute')\n"
        "- User says 'plot/show/in notebook' → execute_code(style='notebook')\n"
        "- User says 'new notebook' → create_notebook(title='...') first, then execute_code(style='notebook')\n"
        "- User says 'interactive/manipulate/dynamic' → execute_code(style='interactive')\n\n"
        "Do NOT search for .nb files, do NOT create directories, do NOT run wolframscript, "
        "do NOT save or export unless asked. Just call the MCP tools directly."
    ),
)
_CORE_TOOL_REGISTRY: list[tuple[str, Callable[..., Any]]] = []

# --- Execution style presets ---
# style bundles only output_target + mode. sync/max_wait/timeout are orthogonal.
_STYLE_DEFAULTS: dict[str, dict[str, str]] = {
    "compute": {"output_target": "cli", "mode": "kernel"},
    "notebook": {"output_target": "notebook", "mode": "kernel"},
    "interactive": {"output_target": "notebook", "mode": "frontend"},
}


def _resolve_execution_params(
    style: str | None,
    output_target: str | None,
    mode: str | None,
    default_output_target: str,
) -> tuple[str, str]:
    """Resolve effective output_target and mode.

    Priority: explicit param > style defaults > profile defaults.
    Raises ValueError for unknown styles.
    """
    if style is not None and style not in _STYLE_DEFAULTS:
        raise ValueError(f"Unknown style '{style}'. Valid styles: compute, notebook, interactive")
    style_defaults = _STYLE_DEFAULTS.get(style, {}) if style else {}

    eff_output_target = output_target or style_defaults.get("output_target", default_output_target)
    eff_mode = mode or style_defaults.get("mode", "kernel")

    # Normalize: CLI path ignores mode entirely, so canonicalize to kernel
    if eff_output_target == "cli":
        eff_mode = "kernel"

    return eff_output_target, eff_mode


def _tool(group: str):
    """Tag a core tool with its exposure group."""

    def decorator(func):
        _CORE_TOOL_REGISTRY.append((group, func))
        return func

    return decorator


def _register_core_tools() -> None:
    from .telemetry import telemetry_tool

    for group, func in _CORE_TOOL_REGISTRY:
        if FEATURES.tool_group_enabled(group):
            mcp.tool()(telemetry_tool(func.__name__)(func))


def _json_response(payload: Any) -> str:
    return json.dumps(payload, indent=2)


# ---------------------------------------------------------------------------
# Routing memory (lazy init)
# ---------------------------------------------------------------------------

_routing_mem = None  # set during startup if routing_memory != "off"

# Journal singleton — records computation history before response filtering
_journal = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Transport status classification
# ---------------------------------------------------------------------------


def _finalize_execute_response(
    response: dict,
    *,
    route_variant: str,
    execution_path: str,
    fell_back: bool,
    start_time: float,
    response_detail: str = "standard",
    expression_type: str | None = None,
) -> str:
    """Normalize execute_code response and optionally record routing stats."""
    import time as _time

    response["route_variant"] = route_variant
    response["execution_path"] = execution_path
    response["overall_timing_ms"] = int((_time.monotonic() - start_time) * 1000)
    # Extract families FIRST — used by transport classification
    response["error_families"] = _extract_error_families(response)
    # Then classify — uses error_families to avoid misclassifying semantic failures
    response["transport_status"] = _classify_transport(response, fell_back=fell_back)
    _maybe_record_routing(response, route_variant=route_variant, expression_type=expression_type)

    # Journal recording — BEFORE response filtering (captures raw canonical result)
    if _journal is not None:
        with contextlib.suppress(Exception):
            _journal.record(
                code=response.get("code", ""),
                output=response.get("output", ""),
                success=response.get("success", response.get("status") == "executed_in_notebook"),
                timing_ms=response.get("overall_timing_ms", 0),
                route_variant=route_variant,
                execution_path=execution_path,
                transport_status=response.get("transport_status", ""),
                error_families=response.get("error_families"),
                timed_out=response.get("timed_out", False),
                from_cache=response.get("from_cache", False),
            )

    # Response detail filtering — applied LAST (after routing + journal recording)
    from .cache import get_kernel_epoch
    from .response_filter import _filter_response

    _diag_hints = None
    if response_detail == "diagnostic" and _routing_mem is not None:
        _diag_hints = _routing_mem.get_routing_hints(FEATURES.profile) or None

    filtered = _filter_response(
        response,
        response_detail,
        cache_epoch=get_kernel_epoch() if response_detail == "diagnostic" else None,
        routing_hints=_diag_hints,
    )
    return _json_response(filtered)


def _maybe_record_routing(response: dict, *, route_variant: str, expression_type: str | None = None) -> None:
    """Fire-and-forget routing stat recording. Never raises."""
    if _routing_mem is None:
        return
    with contextlib.suppress(Exception):
        _routing_mem.record(
            profile=FEATURES.profile,
            route_variant=route_variant,
            execution_path=response.get("execution_path", "unknown"),
            transport_status=response.get("transport_status", "ok"),
            latency_ms=response.get("overall_timing_ms", 0),
            error_families=response.get("error_families", []),
            expression_type=expression_type,
        )


async def _run_blocking(func, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)


async def _addon_result(
    command: str,
    params: dict | None = None,
    timeout: float | None = None,
) -> dict:
    return await _run_blocking(_try_addon_command, command, params, timeout)


async def _addon_json(command: str, params: dict | None = None) -> str:
    return _json_response(await _addon_result(command, params))


async def _image_from_result(result: dict) -> Image:
    image_path = result["path"]

    def _read_and_remove() -> bytes:
        if not _is_valid_png(image_path):
            # Clean up invalid file and raise so caller gets a clear error.
            if os.path.exists(image_path):
                with contextlib.suppress(OSError):
                    os.remove(image_path)
            raise ValueError(f"Invalid or corrupt PNG at {image_path}")
        with open(image_path, "rb") as f:
            image_bytes = f.read()
        os.remove(image_path)
        return image_bytes

    image_bytes = await _run_blocking(_read_and_remove)
    return Image(data=image_bytes, format="png")


_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def _is_valid_png(path: str) -> bool:
    """Check that *path* exists, is non-empty, and starts with PNG magic bytes."""
    try:
        if not os.path.exists(path) or os.path.getsize(path) < 8:
            return False
        with open(path, "rb") as f:
            return f.read(8) == _PNG_MAGIC
    except OSError:
        return False


def _attach_image_if_valid(result: dict) -> None:
    """Attach rendered_image to result if image_path exists and is a valid PNG.

    Validates the file on disk before trusting the path.  Strips is_graphics
    and image_path from the result if the file is missing, empty, or not a
    valid PNG so the caller does not hand out a broken path.
    """
    if not result.get("is_graphics") or not result.get("image_path"):
        return
    image_path = result["image_path"]
    if _is_valid_png(image_path):
        result["rendered_image"] = image_path
        result["tip"] = "Use Read tool to view image."
    else:
        # Rasterization claimed success but no valid file — delete the
        # bad file from disk (if it exists) and strip metadata so
        # clients don't receive a broken path.
        if os.path.exists(image_path):
            with contextlib.suppress(OSError):
                os.remove(image_path)
        result.pop("image_path", None)
        result.pop("is_graphics", None)
        result.pop("rendered_image", None)
        result.pop("tip", None)
        # Restore output to the textual form so clients don't see a
        # broken "[Graphics rendered to image: ...]" placeholder.
        if result.get("output_inputform"):
            result["output"] = result["output_inputform"]


def _hydrate_usage(symbols: list[str]) -> dict[str, str]:
    """Batch-fetch usage strings for *symbols* via a single subprocess call.

    Returns a dict mapping symbol name → usage string.  Cached results
    from the symbol index metadata cache are used where available.
    """
    from . import symbol_index

    result: dict[str, str] = {}
    uncached: list[str] = []

    for sym in symbols:
        meta = symbol_index.get_cached_metadata(sym)
        if meta and meta.get("usage"):
            result[sym] = meta["usage"]
        else:
            uncached.append(sym)

    if not uncached:
        return result

    from .lazy_wolfram_tools import _find_wolframscript

    wolframscript = _find_wolframscript()
    if not wolframscript:
        return result

    import subprocess

    sym_list = ", ".join(f'"{s}"' for s in uncached)
    code = f'Association[Map[# -> Quiet[Check[ToString[ToExpression[# <> "::usage"]], ""]] &, {{{sym_list}}}]]'

    try:
        proc = subprocess.run(
            [wolframscript, "-code", code],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if proc.returncode == 0:
            parsed = _parse_wolfram_association(proc.stdout.strip())
            if isinstance(parsed, dict):
                for sym in uncached:
                    usage = parsed.get(sym, "")
                    if isinstance(usage, str) and usage:
                        result[sym] = usage
                        symbol_index.cache_metadata(sym, {"usage": usage})
    except Exception:
        pass

    return result


def _lookup_symbols_in_kernel(query: str) -> dict[str, Any]:
    """Search for Wolfram symbols matching *query*.

    Tries the in-memory symbol index first (pure Python, no subprocess).
    Falls back to a wolframscript subprocess if the index is unavailable.
    """
    from . import symbol_index

    # Fast path: use pre-built index for System symbols.
    matches = symbol_index.search(query, max_results=20)
    if matches:
        return {
            "success": True,
            "candidates": [{"symbol": name, "usage": ""} for name in matches],
            "system_only": True,
        }

    # Fallback: subprocess.
    import subprocess

    from .lazy_wolfram_tools import _find_wolframscript

    wolframscript = _find_wolframscript()
    if not wolframscript:
        return {"success": False, "error": "wolframscript not found"}

    lookup_code = f'''
Module[{{query, candidates, systemMatches, globalMatches, allMatches, getInfo}},
  query = "{query}";
  systemMatches = Select[Names["System`*"], StringContainsQ[#, query, IgnoreCase -> True] &];
  globalMatches = Select[Names["Global`*"], StringContainsQ[#, query, IgnoreCase -> True] &];
  allMatches = Take[Join[systemMatches, globalMatches], UpTo[20]];
  getInfo[sym_String] := Module[{{usage, opts, attrs, syntaxInfo}},
    usage = Quiet[Check[ToString[ToExpression[sym <> "::usage"]], ""]];
    opts = Quiet[Check[ToString[Length[Options[ToExpression[sym]]]], "0"]];
    attrs = Quiet[Check[ToString[Attributes[ToExpression[sym]]], "{{}}"]];
    syntaxInfo = Quiet[Check[ToString[SyntaxInformation[ToExpression[sym]]], "{{}}"]];
    <|"symbol" -> sym, "usage" -> usage, "options_count" -> opts, "attributes" -> attrs, "syntax_info" -> syntaxInfo|>
  ];
  <|"success" -> True, "query" -> query, "matches" -> (getInfo /@ allMatches)|>
]
'''

    try:
        result = subprocess.run(
            [wolframscript, "-code", lookup_code],
            capture_output=True,
            text=True,
            timeout=30,
        )
        output = result.stdout.strip()

        if result.returncode != 0:
            return {"success": False, "error": result.stderr or "Lookup failed"}

        return {"success": True, "raw_output": output}
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Lookup timed out"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _parse_wolfram_association(raw: str) -> dict[str, Any]:
    """Convert Wolfram Association syntax (<|...|>) to Python dict."""
    try:
        s = raw.strip()
        # Remove newlines within the association (multiline Mathematica output)
        s = re.sub(r"\n\s*", " ", s)
        # Remove carriage returns
        s = s.replace("\r", "")
        # Handle fractions like 100584/625 - quote them as strings
        s = re.sub(r":\s*(\d+)/(\d+)\s*([,}])", r': "\1/\2"\3', s)
        # Convert Association delimiters
        s = re.sub(r"<\|", "{", s)
        s = re.sub(r"\|>", "}", s)
        # Convert arrow to colon
        s = re.sub(r"\s*->\s*", ": ", s)
        # Convert Mathematica booleans
        s = s.replace("True", "true").replace("False", "false").replace("Null", "null")
        # Quote unquoted symbols (identifiers starting with letter, may contain ` $ digits)
        # But be careful not to match already quoted strings or numbers
        s = re.sub(r":\s*([A-Za-z][A-Za-z0-9`$]*(?:\s+[A-Za-z][A-Za-z0-9`$]*)*)\s*([,}])", r': "\1"\2', s)
        # Handle special Mathematica output like "100584 kilometers" with line breaks
        s = re.sub(r":\s*(\d+)\s+([A-Za-z]+)\s*([,}])", r': "\1 \2"\3', s)
        return json.loads(s)
    except Exception:
        return {"success": True, "raw": raw, "parse_error": True}


def _extract_short_description(usage: str) -> str:
    """Extract first sentence from Wolfram usage string."""
    if not usage or usage == "Null":
        return "No description available"

    usage = re.sub(r"^[A-Za-z]+\[.*?\]\s*", "", usage, count=1)
    match = re.match(r"^([^.!?]*[.!?])", usage)
    if match:
        return match.group(1).strip()
    return usage[:100].strip() + ("..." if len(usage) > 100 else "")


def _extract_example_signature(usage: str, symbol: str) -> str:
    """Extract usage pattern like Symbol[args] from usage string."""
    if not usage or usage == "Null":
        return f"{symbol}[...]"

    pattern = rf"{re.escape(symbol)}\[[^\]]*\]"
    match = re.search(pattern, usage)
    if match:
        return match.group(0)
    return f"{symbol}[...]"


def _rank_candidates(query: str, candidates: list[dict]) -> list[dict]:
    """Rank symbol candidates by relevance using exact/prefix/similarity scoring."""
    query_lower = query.lower()
    scored = []

    for c in candidates:
        symbol = c.get("symbol", "")
        symbol_name = symbol.split("`")[-1]
        symbol_lower = symbol_name.lower()

        score = 0.0
        if symbol_lower == query_lower:
            score += 100
        elif symbol_lower.startswith(query_lower):
            score += 50
        elif query_lower in symbol_lower:
            score += 25

        similarity = difflib.SequenceMatcher(None, query_lower, symbol_lower).ratio()
        score += similarity * 20
        score -= len(symbol_name) * 0.1

        if symbol.startswith("System`"):
            score += 5

        c["_score"] = score
        c["symbol_name"] = symbol_name
        scored.append(c)

    scored.sort(key=lambda x: x["_score"], reverse=True)
    return scored


def _try_addon_command(
    command: str,
    params: dict | None = None,
    timeout: float | None = None,
) -> dict:
    try:
        conn = get_mathematica_connection()
        return conn.send_command(command, params or {}, timeout=timeout)
    except Exception as e:
        return {"success": False, "error": str(e)}


@_tool("core")
async def get_mathematica_status() -> str:
    """Get connection status and system info."""
    try:
        result = await _addon_result("get_status")
        if result.get("success") is False and result.get("error"):
            raise RuntimeError(result["error"])
        result["connection_mode"] = "addon"
        return _json_response(result)
    except Exception as e:
        try:
            session = await _run_blocking(get_kernel_session)
            if session is None:
                raise RuntimeError("No kernel session available")
            from wolframclient.language import wlexpr

            version = session.evaluate(wlexpr("$VersionNumber"))
            return _json_response(
                {
                    "connection_mode": "kernel_only",
                    "kernel_version": float(version),
                    "note": "Addon not running - notebook control unavailable. Execute StartMCPServer[] in Mathematica.",
                    "error": str(e),
                }
            )
        except Exception as e2:
            return _json_response(
                {
                    "connection_mode": "disconnected",
                    "error": f"No connection available: {e2}",
                }
            )


@_tool("core")
async def get_session_brief() -> str:
    """Compact session state summary: connection, profile, recent errors, routing advice."""
    from .guidance import build_session_brief
    from .session import has_existing_kernel_session

    # Determine connection mode with short timeout
    connection_mode = "disconnected"
    try:
        result = await _addon_result("get_status", timeout=0.5)
        if result.get("success") is not False:
            connection_mode = "addon"
        else:
            # Addon returned failure — check for kernel session
            if await _run_blocking(has_existing_kernel_session):
                connection_mode = "kernel_only"
    except Exception:
        if await _run_blocking(has_existing_kernel_session):
            connection_mode = "kernel_only"

    # Gather routing hints and recent errors
    routing_hints: list[str] = []
    recent_errors: list[str] = []
    if _routing_mem is not None:
        if _routing_mem.mode == "advise":
            routing_hints = _routing_mem.get_routing_hints(FEATURES.profile)[:2]
        recent_errors = _routing_mem.get_recent_error_families(limit=3, max_age_seconds=86400)

    return build_session_brief(
        FEATURES,
        connection_mode=connection_mode,
        routing_hints=routing_hints,
        recent_errors=recent_errors,
    )


@_tool("notebook_primary")
async def get_notebooks() -> str:
    """List all open Mathematica notebooks. Returns ID, filename, title."""
    return await _addon_json("get_notebooks")


@_tool("notebook_primary")
async def get_notebook_info(notebook: str | None = None, session_id: str | None = None) -> str:
    """Get details about a notebook (filename, directory, cell count)."""
    result = await _addon_result("get_notebook_info", {"notebook": notebook, "session_id": session_id})
    return _json_response(result)


@_tool("notebook_primary")
async def create_notebook(title: str = "Untitled", session_id: str | None = None) -> str:
    """Create a new empty notebook. Returns notebook ID.

    Use when the user explicitly asks for a NEW notebook. Sets the active
    notebook so subsequent execute_code(output_target="notebook") calls target it.
    """
    result = await _addon_result("create_notebook", {"title": title, "session_id": session_id})
    return _json_response(result)


@_tool("notebook_primary")
async def save_notebook(
    notebook: str | None = None,
    path: str | None = None,
    format: Literal["Notebook", "PDF", "HTML", "TeX"] = "Notebook",
    session_id: str | None = None,
) -> str:
    """Save a notebook to disk."""
    result = await _addon_result(
        "save_notebook",
        {
            "notebook": notebook,
            "path": path,
            "format": format,
            "session_id": session_id,
        },
    )
    return _json_response(result)


@_tool("notebook_primary")
async def close_notebook(notebook: str | None = None, session_id: str | None = None) -> str:
    """Close a notebook."""
    result = await _addon_result("close_notebook", {"notebook": notebook, "session_id": session_id})
    return _json_response(result)


@_tool("notebook_primary")
async def get_cells(
    notebook: str | None = None,
    style: str | None = None,
    session_id: str | None = None,
    offset: int = 0,
    limit: int | None = None,
    include_content: bool = True,
) -> str:
    """Get list of cells in a notebook."""
    result = await _addon_result(
        "get_cells",
        {
            "notebook": notebook,
            "style": style,
            "session_id": session_id,
            "offset": offset,
            "limit": limit,
            "include_content": include_content,
        },
    )
    return _json_response(result)


@_tool("notebook_primary")
async def get_cell_content(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
) -> str:
    """Get the full content of a specific cell."""
    result = await _addon_result(
        "get_cell_content",
        {"cell_id": cell_id, "notebook": notebook, "session_id": session_id},
    )
    return _json_response(result)


@_tool("notebook_advanced")
async def write_cell(
    content: str,
    style: str = "Input",
    notebook: str | None = None,
    position: Literal["After", "Before", "End", "Beginning"] = "After",
    session_id: str | None = None,
    sync: Literal["none", "refresh", "strict"] = "none",
    sync_wait: float = 2,
) -> str:
    """Write a new cell to a notebook without evaluating it.

    NOTE: For executing code, prefer execute_code(code, output_target="notebook")
    which writes AND evaluates the cell atomically.
    """
    result = await _addon_result(
        "write_cell",
        {
            "notebook": notebook,
            "content": content,
            "style": style,
            "position": position,
            "session_id": session_id,
            "sync": sync,
            "sync_wait": sync_wait,
        },
    )
    return _json_response(result)


@_tool("notebook_advanced")
async def delete_cell(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
) -> str:
    """Delete a cell from a notebook."""
    result = await _addon_result(
        "delete_cell",
        {"cell_id": cell_id, "notebook": notebook, "session_id": session_id},
    )
    return _json_response(result)


@_tool("notebook_advanced")
async def evaluate_cell(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
    max_wait: int = 10,
    sync: Literal["none", "refresh", "strict"] = "none",
    sync_wait: float = 2,
) -> str:
    """Evaluate a specific cell."""
    result = await _addon_result(
        "evaluate_cell",
        {
            "cell_id": cell_id,
            "notebook": notebook,
            "session_id": session_id,
            "max_wait": max_wait,
            "sync": sync,
            "sync_wait": sync_wait,
        },
    )
    return _json_response(result)


@_tool("core")
async def execute_code(
    code: str,
    format: Literal["text", "latex", "mathematica"] = "text",
    output_target: Literal["cli", "notebook"] | None = None,
    mode: Literal["kernel", "frontend"] | None = None,
    render_graphics: bool = True,
    deterministic_seed: int | None = None,
    session_id: str | None = None,
    isolate_context: bool = False,
    timeout: int = 300,
    max_wait: int = 30,
    sync: Literal["none", "refresh", "strict"] = "none",
    sync_wait: float = 2,
    *,
    style: Literal["compute", "notebook", "interactive"] | None = None,
    response_detail: Literal["compact", "standard", "verbose", "diagnostic"] = "standard",
) -> str:
    """Execute Wolfram Language code."""
    import time as _time

    _exec_start = _time.monotonic()
    try:
        output_target, mode = _resolve_execution_params(style, output_target, mode, FEATURES.default_output_target)
    except ValueError as e:
        return _json_response({"success": False, "error": str(e)})

    # Route variant for routing memory (agent-controlled dimensions only)
    if output_target == "cli":
        route_variant = "compute"
    elif mode == "frontend":
        route_variant = "notebook_frontend"
    else:
        route_variant = "notebook_kernel"

    # Expression classification for routing telemetry
    _expr_type: str | None = None
    if _routing_mem is not None:
        from .routing_memory import _classify_expression

        _expr_type = _classify_expression(code)

    if output_target == "notebook":
        try:
            # Use atomic command that combines find/create notebook + write + evaluate
            # in a single round-trip for better performance
            # mode="kernel" is the new fast path (no polling)
            params = {
                "code": code,
                "max_wait": max_wait,
                "mode": mode,
                "session_id": session_id,
                "isolate_context": isolate_context,
                "sync": sync,
                "sync_wait": sync_wait,
                "timeout": timeout,
            }
            if deterministic_seed is not None:
                params["deterministic_seed"] = deterministic_seed
            # Use timeout + 10s margin for socket so the addon can enforce its own timeout
            socket_timeout = float(timeout) + 10.0
            result = await _addon_result("execute_code_notebook", params, timeout=socket_timeout)

            # Handle timeout: return immediately, do NOT fall through to CLI
            if result.get("timed_out"):
                # kernel mode returns timing_ms, frontend returns waited_seconds
                duration_ms = result.get("timing_ms")
                if duration_ms is None and result.get("waited_seconds") is not None:
                    duration_ms = round(result["waited_seconds"] * 1000)
                response = {
                    "status": "timeout",
                    "code": code,
                    "notebook_id": result.get("notebook_id"),
                    "cell_id": result.get("cell_id"),
                    "evaluated": False,
                    "timed_out": True,
                    "timing_ms": duration_ms,
                    "message": (
                        f"Computation exceeded {timeout}s timeout. "
                        "Increase timeout or use submit_computation() for long tasks."
                    ),
                }
                if result.get("output_preview"):
                    response["output_preview"] = result.get("output_preview")
                response["executed_output_target"] = "notebook"
                response["executed_mode"] = mode
                if style is not None:
                    response["requested_style"] = style
                return _finalize_execute_response(
                    response,
                    route_variant=route_variant,
                    execution_path="addon_notebook",
                    fell_back=False,
                    start_time=_exec_start,
                    response_detail=response_detail,
                    expression_type=_expr_type,
                )

            if result.get("success"):
                response = {
                    "status": "executed_in_notebook",
                    "code": code,
                    "notebook_id": result.get("notebook_id"),
                    "cell_id": result.get("cell_id"),
                    "evaluated": True,
                    "message": "Executed in notebook.",
                }
                if result.get("created_notebook"):
                    response["note"] = "Created new notebook 'Analysis'."

                # NEW: Process error messages if present
                if result.get("has_errors") or result.get("has_warnings"):
                    messages = result.get("messages", [])
                    response["messages"] = messages
                    response["has_errors"] = result.get("has_errors", False)
                    response["has_warnings"] = result.get("has_warnings", False)

                    # Update status to indicate errors
                    if result.get("has_errors"):
                        response["status"] = "executed_with_errors"
                        response["message"] = (
                            "Code executed in notebook but produced errors. "
                            "See 'error_analysis' field for detailed suggestions."
                        )

                    # Format error summary for easy reading
                    error_msgs = [m for m in messages if m.get("type") == "error"]
                    warning_msgs = [m for m in messages if m.get("type") == "warning"]

                    if error_msgs or warning_msgs:
                        summary_parts = []
                        if error_msgs:
                            summary_parts.append(
                                f"{len(error_msgs)} error(s): "
                                + "; ".join(f"{m.get('tag', 'Unknown')}" for m in error_msgs[:3])
                            )
                        if warning_msgs:
                            summary_parts.append(
                                f"{len(warning_msgs)} warning(s): "
                                + "; ".join(f"{m.get('tag', 'Unknown')}" for m in warning_msgs[:3])
                            )
                        response["error_summary"] = " | ".join(summary_parts)

                        # NEW: Add intelligent error analysis
                        error_analysis = analyze_messages(messages)
                        response["error_analysis"] = {
                            "total_errors": error_analysis["errors"],
                            "total_warnings": error_analysis["warnings"],
                            "severity": error_analysis["severity"],
                            "recommendations": error_analysis["recommendations"],
                            "should_retry": error_analysis["should_retry"],
                        }

                        # Include detailed analysis for each error
                        if error_analysis.get("analyses"):
                            response["detailed_analyses"] = [
                                {
                                    "tag": a["original_message"]["tag"],
                                    "description": a.get("description", ""),
                                    "suggested_fix": a.get("suggested_fix", ""),
                                    "example": a.get("example", ""),
                                    "confidence": a.get("confidence", "low"),
                                }
                                for a in error_analysis["analyses"]
                                if a.get("confidence") in ["high", "medium"]
                            ]

                        # Add formatted error message for LLM
                        response["llm_error_report"] = format_error_for_llm(messages, code)

                        # Add output preview if available
                        if result.get("output_preview"):
                            response["output_preview"] = result.get("output_preview")

                response["executed_output_target"] = "notebook"
                response["executed_mode"] = mode
                if style is not None:
                    response["requested_style"] = style
                return _finalize_execute_response(
                    response,
                    route_variant=route_variant,
                    execution_path="addon_notebook",
                    fell_back=False,
                    start_time=_exec_start,
                    response_detail=response_detail,
                    expression_type=_expr_type,
                )
            else:
                raise RuntimeError(result.get("error", "Atomic notebook execution failed"))

        except Exception as e:
            logger.warning(f"Notebook execution failed: {e}. Falling back to CLI.")

            # Record addon_notebook failure in attempt telemetry
            if _routing_mem is not None:
                from .constants import AttemptOutcome as _AO

                _routing_mem.record_transport_attempt(
                    FEATURES.profile, route_variant, _EP.ADDON_NOTEBOOK, _AO.INFRA_ERROR
                )

            # Fallback to CLI execution with auto-rasterization for graphics
            try:
                params = {
                    "code": code,
                    "format": format,
                    "render_graphics": render_graphics,
                    "session_id": session_id,
                    "isolate_context": isolate_context,
                    "timeout": timeout,
                }
                if deterministic_seed is not None:
                    params["deterministic_seed"] = deterministic_seed
                socket_timeout = float(timeout) + 10.0
                result = await _addon_result("execute_code", params, timeout=socket_timeout)

                # Record addon_cli attempt telemetry for notebook fallback
                if _routing_mem is not None:
                    from .transport_classification import classify_attempt_outcome as _classify_att

                    _routing_mem.record_transport_attempt(
                        FEATURES.profile,
                        route_variant,
                        _EP.ADDON_CLI,
                        _classify_att(result),
                    )

                if isinstance(result, dict):
                    result["note"] = "Executed via CLI (notebook error)."
                    result["executed_output_target"] = "cli"
                    if style is not None:
                        result["requested_style"] = style
                    _attach_image_if_valid(result)
                    return _finalize_execute_response(
                        result,
                        route_variant=route_variant,
                        execution_path="addon_cli",
                        fell_back=True,
                        start_time=_exec_start,
                        response_detail=response_detail,
                        expression_type=_expr_type,
                    )
                return f"{result}\n(Note: Executed via CLI due to notebook error)"
            except Exception:
                # Record addon_cli infra error for notebook fallback
                if _routing_mem is not None:
                    from .constants import AttemptOutcome as _AO

                    _routing_mem.record_transport_attempt(
                        FEATURES.profile, route_variant, _EP.ADDON_CLI, _AO.INFRA_ERROR
                    )

                result = await _run_blocking(
                    execute_in_kernel,
                    code,
                    format,
                    render_graphics=render_graphics,
                    deterministic_seed=deterministic_seed,
                    session_id=session_id,
                    isolate_context=isolate_context,
                    timeout=timeout,
                )
                result["execution_mode"] = "kernel_fallback"
                result["note"] = "Executed via CLI (notebook error). Run StartMCPServer[] in Mathematica."
                result["executed_output_target"] = "cli"
                if style is not None:
                    result["requested_style"] = style
                _attach_image_if_valid(result)
                return _finalize_execute_response(
                    result,
                    route_variant=route_variant,
                    execution_path="kernel_fallback",
                    fell_back=True,
                    start_time=_exec_start,
                    response_detail=response_detail,
                    expression_type=_expr_type,
                )

    # Check breaker before attempting addon_cli
    _cli_lease = None
    _routing_skipped = False
    if _routing_mem is not None:
        _cli_lease = _routing_mem.begin_transport_attempt(FEATURES.profile, route_variant, _EP.ADDON_CLI)
        if _cli_lease.action == "skip":
            _routing_skipped = True

    if _routing_skipped:
        # Breaker says skip addon_cli — go straight to kernel
        result = await _run_blocking(
            execute_in_kernel,
            code,
            format,
            render_graphics=render_graphics,
            deterministic_seed=deterministic_seed,
            session_id=session_id,
            isolate_context=isolate_context,
            timeout=timeout,
        )
        result["executed_output_target"] = "cli"
        if style is not None:
            result["requested_style"] = style
        _attach_image_if_valid(result)
        return _finalize_execute_response(
            result,
            route_variant=route_variant,
            execution_path=_EP.KERNEL_DIRECT_ROUTING_SKIP,
            fell_back=False,
            start_time=_exec_start,
            response_detail=response_detail,
            expression_type=_expr_type,
        )

    params = {
        "code": code,
        "format": format,
        "render_graphics": render_graphics,
        "session_id": session_id,
        "isolate_context": isolate_context,
        "timeout": timeout,
    }
    if deterministic_seed is not None:
        params["deterministic_seed"] = deterministic_seed
    socket_timeout = float(timeout) + 10.0

    _lease_completed = False
    try:
        result = await _addon_result("execute_code", params, timeout=socket_timeout)

        # Unified lifecycle: records attempt telemetry + handles probe
        if _routing_mem is not None and _cli_lease is not None:
            from .transport_classification import classify_attempt_outcome

            _attempt_outcome = classify_attempt_outcome(result)
            _routing_mem.finish_transport_attempt(_cli_lease, _attempt_outcome, profile=FEATURES.profile)
            _lease_completed = True
    except Exception:
        if _routing_mem is not None and _cli_lease is not None:
            from .constants import AttemptOutcome as _AO

            _routing_mem.finish_transport_attempt(_cli_lease, _AO.INFRA_ERROR, profile=FEATURES.profile)
            _lease_completed = True
        raise
    finally:
        if _cli_lease is not None and not _lease_completed:
            _routing_mem.abort_transport_attempt(_cli_lease)

    # Check if addon command succeeded, otherwise fall back to kernel
    _cli_fell_back = False
    if result.get("success") is False or "error" in result:
        result = await _run_blocking(
            execute_in_kernel,
            code,
            format,
            render_graphics=render_graphics,
            deterministic_seed=deterministic_seed,
            session_id=session_id,
            isolate_context=isolate_context,
            timeout=timeout,
        )
        result["execution_mode"] = "kernel_fallback"
        _cli_fell_back = True
    result["executed_output_target"] = "cli"
    if style is not None:
        result["requested_style"] = style
    _attach_image_if_valid(result)
    return _finalize_execute_response(
        result,
        route_variant=route_variant,
        execution_path=_EP.KERNEL_FALLBACK if _cli_fell_back else _EP.ADDON_CLI,
        fell_back=_cli_fell_back,
        start_time=_exec_start,
        response_detail=response_detail,
        expression_type=_expr_type,
    )


@_tool("admin")
async def batch_commands(commands: list[dict[str, Any]]) -> str:
    """Execute multiple commands in one round-trip."""
    return await _addon_json("batch_commands", {"commands": commands})


@_tool("notebook_advanced")
async def evaluate_selection(
    notebook: str | None = None,
    session_id: str | None = None,
    max_wait: int = 10,
    sync: Literal["none", "refresh", "strict"] = "none",
    sync_wait: float = 2,
) -> str:
    """
    Evaluate the currently selected cell(s) in a notebook.

    Args:
        notebook: Notebook ID. If None, uses selected notebook.
    """
    result = await _addon_result(
        "execute_selection",
        {
            "notebook": notebook,
            "session_id": session_id,
            "max_wait": max_wait,
            "sync": sync,
            "sync_wait": sync_wait,
        },
    )
    return _json_response(result)


@_tool("notebook_primary")
async def screenshot_notebook(
    notebook: str | None = None,
    max_height: int = 2000,
    session_id: str | None = None,
    use_rasterize: bool = False,
    wait_ms: int = 100,
) -> Image:
    """
    Capture a screenshot of an entire notebook window.

    Args:
        notebook: Notebook ID. If None, uses selected notebook.
        max_height: Maximum height in pixels (prevents huge images)

    Returns the screenshot as an image that can be viewed directly.
    """
    result = await _addon_result(
        "screenshot_notebook",
        {
            "notebook": notebook,
            "max_height": max_height,
            "session_id": session_id,
            "use_rasterize": use_rasterize,
            "wait_ms": wait_ms,
        },
    )

    return await _image_from_result(result)


@_tool("notebook_primary")
async def screenshot_cell(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
    use_rasterize: bool = False,
) -> Image:
    """
    Capture a screenshot of a specific cell's content and output.

    Useful for seeing plots, graphics, or formatted mathematical output.

    Args:
        cell_id: The cell object ID to screenshot
    """
    result = await _addon_result(
        "screenshot_cell",
        {
            "cell_id": cell_id,
            "notebook": notebook,
            "session_id": session_id,
            "use_rasterize": use_rasterize,
        },
    )

    return await _image_from_result(result)


@_tool("notebook_primary")
async def rasterize_expression(expression: str, image_size: int = 400) -> Image:
    """
    Render a Wolfram Language expression as an image.

    Useful for visualizing plots, matrices, or formatted output without
    modifying any notebook.

    Args:
        expression: Wolfram Language expression to render
        image_size: Size of the resulting image in pixels

    Examples:
        rasterize_expression("Plot[Sin[x], {x, 0, 2 Pi}]")
        rasterize_expression("MatrixForm[{{1, 2}, {3, 4}}]")
        rasterize_expression("Graphics[Circle[]]", image_size=200)
    """
    result = await _addon_result("rasterize_expression", {"expression": expression, "image_size": image_size})
    return await _image_from_result(result)


@_tool("notebook_advanced")
async def select_cell(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
) -> str:
    """Select a cell in the notebook (moves cursor to it)."""
    result = await _addon_result(
        "select_cell",
        {"cell_id": cell_id, "notebook": notebook, "session_id": session_id},
    )
    return _json_response(result)


@_tool("notebook_advanced")
async def scroll_to_cell(
    cell_id: str,
    notebook: str | None = None,
    session_id: str | None = None,
) -> str:
    """Scroll the notebook view to make a cell visible."""
    result = await _addon_result(
        "scroll_to_cell",
        {"cell_id": cell_id, "notebook": notebook, "session_id": session_id},
    )
    return _json_response(result)


@_tool("notebook_primary")
async def export_notebook(
    path: str,
    notebook: str | None = None,
    format: Literal["PDF", "HTML", "TeX", "Markdown"] = "PDF",
    session_id: str | None = None,
) -> str:
    """Export a notebook to PDF, HTML, TeX, or Markdown."""
    result = await _addon_result(
        "export_notebook",
        {"notebook": notebook, "path": path, "format": format, "session_id": session_id},
    )
    return _json_response(result)


@_tool("debug")
async def verify_derivation(
    steps: list[str],
    format: Literal["text", "latex", "mathematica"] = "text",
    timeout: int = 120,
) -> str:
    """Verify a sequence of mathematical expressions steps."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.verify_derivation(
        steps,
        format,
        timeout,
        parse_wolfram_association=_parse_wolfram_association,
    )


@_tool("core")
async def get_kernel_state() -> str:
    """Get current Wolfram kernel session state (memory, uptime, version)."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.get_kernel_state(parse_wolfram_association=_parse_wolfram_association)


@_tool("kernel_tools")
async def load_package(package_name: str) -> str:
    """Load a Mathematica package (e.g., "Developer`")."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    result = await _lazy_wolfram_tools.load_package(
        package_name,
        parse_wolfram_association=_parse_wolfram_association,
    )
    # Only invalidate cache if the package load actually succeeded.
    try:
        if json.loads(result).get("success"):
            bump_kernel_epoch()
    except (json.JSONDecodeError, AttributeError):
        bump_kernel_epoch()  # Can't tell — assume state may have changed.
    return result


@_tool("kernel_tools")
async def list_loaded_packages() -> str:
    """List all currently loaded packages and contexts."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.list_loaded_packages(parse_wolfram_association=_parse_wolfram_association)


# ============================================================================
# TIER 1: Variable Introspection (Session State)
# ============================================================================


@_tool("session")
async def list_variables(include_system: bool = False) -> str:
    """List all user-defined variables in the current Mathematica kernel session."""
    result = await _addon_result("list_variables", {"include_system": include_system})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    return _json_response(result)


@_tool("session")
async def get_variable(name: str) -> str:
    """Get detailed information about a specific variable."""
    result = await _addon_result("get_variable", {"name": name})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    return _json_response(result)


@_tool("session")
async def set_variable(name: str, value: str) -> str:
    """
    Set a variable in the Mathematica kernel session.

    Args:
        name: Variable name (e.g., "x", "myData")
        value: Wolfram Language expression to assign (e.g., "5", "{1,2,3}", "Plot[Sin[x],{x,0,Pi}]")

    Returns:
        Confirmation with the assigned value

    Example:
        set_variable("x", "Range[10]") -> {success: true, value: "{1,2,3,4,5,6,7,8,9,10}"}
    """
    result = await _addon_result("set_variable", {"name": name, "value": value})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    bump_kernel_epoch()
    return _json_response(result)


@_tool("session")
async def clear_variables(
    names: list[str] | None = None,
    pattern: str | None = None,
    clear_all: bool = False,
) -> str:
    """
    Clear variables from the Mathematica kernel session.

    Equivalent to Python's 'del' or clearing notebook state.

    Args:
        names: Specific variable names to clear (e.g., ["x", "y", "z"])
        pattern: Wolfram pattern to match (e.g., "temp*" clears temp1, temp2, etc.)
        clear_all: If True, clear ALL Global` variables (use with caution!)

    Returns:
        List of cleared variables

    Example:
        clear_variables(names=["x", "y"]) -> {cleared: ["x", "y"], count: 2}
        clear_variables(pattern="temp*") -> {cleared: ["temp1", "temp2"], count: 2}
    """
    params = {}
    if names:
        params["names"] = names
    if pattern:
        params["pattern"] = pattern
    if clear_all:
        params["clear_all"] = True

    result = await _addon_result("clear_variables", params)

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    bump_kernel_epoch()
    return _json_response(result)


@_tool("session")
async def get_expression_info(expression: str) -> str:
    """
    Get detailed structural information about a Wolfram expression.

    Like Python's type() on steroids - shows Head, FullForm, tree structure,
    depth, leaf count, and type checks (NumericQ, ListQ, etc.)

    Args:
        expression: Wolfram Language expression to analyze

    Returns:
        Structural information: head, full form, depth, leaf count, type flags

    Example:
        get_expression_info("{{1,2},{3,4}}") -> {head: "List", depth: 3, dimensions: [2,2]}
        get_expression_info("Sin[x] + Cos[x]") -> {head: "Plus", leaf_count: 3}
    """
    result = await _addon_result("get_expression_info", {"expression": expression})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    return _json_response(result)


# ============================================================================
# TIER 1: Error Recovery
# ============================================================================


@_tool("core")
async def get_messages(count: int = 10) -> str:
    """
    Get recent Mathematica messages/warnings from the session.

    Like Python's exception traceback - helps debug what went wrong.

    Args:
        count: Number of recent messages to retrieve (default 10)

    Returns:
        List of recent messages with timestamps

    Example:
        After a failed computation:
        get_messages() -> [{timestamp: "...", message: "Power::infy: Infinite expression 1/0 encountered."}]
    """
    result = await _addon_result("get_messages", {"count": count})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"]})

    return _json_response(result)


@_tool("core")
async def restart_kernel() -> str:
    """
    Restart the Mathematica kernel, clearing all state.

    This is the nuclear option - clears all variables, definitions, and state.
    Use when the kernel is in a bad state or you need a fresh start.

    Returns:
        Confirmation of kernel restart
    """
    await _run_blocking(close_kernel_session)
    # Invalidate all cached results — kernel state is completely reset.
    _query_cache.clear()
    clear_cache()
    clear_raster_cache()
    bump_kernel_epoch()
    # Force reconnection
    result = await _addon_result("ping")

    return _json_response(
        {
            "success": True,
            "message": "Kernel session cleared. Fresh session will be created on next execution.",
            "ping_result": result,
        }
    )


# ============================================================================
# TIER 2: File Handling (.nb, .wl, .wlnb)
# ============================================================================


def _expand_path(path: str) -> str:
    """Expand ~ and make path absolute."""
    expanded = os.path.expanduser(path)
    return os.path.abspath(expanded)


def _load_cached_notebook(path: str, truncation_threshold: int = 25000):
    from .notebook_parser import parse_notebook_cached

    return parse_notebook_cached(path, truncation_threshold=truncation_threshold)


class _TelemetryMcpWrapper:
    """Proxy that auto-wraps every tool registered via ``@mcp.tool()``
    with the :func:`telemetry_tool` decorator so that optional tool
    modules get instrumentation for free without changing their code."""

    def __init__(self, mcp_instance):
        self._mcp = mcp_instance

    def tool(self, *args, **kwargs):
        from .telemetry import telemetry_tool

        original_decorator = self._mcp.tool(*args, **kwargs)

        def instrumenting_decorator(func):
            instrumented = telemetry_tool(func.__name__)(func)
            return original_decorator(instrumented)

        return instrumenting_decorator

    def __getattr__(self, name):
        return getattr(self._mcp, name)


def _register_optional_tools() -> None:
    instrumented_mcp = _TelemetryMcpWrapper(mcp)

    if FEATURES.symbol_lookup:
        from .optional_symbol_tools import register_symbol_lookup_tools

        register_symbol_lookup_tools(
            instrumented_mcp,
            lookup_symbols_in_kernel=_lookup_symbols_in_kernel,
            hydrate_usage=_hydrate_usage,
            extract_short_description=_extract_short_description,
            extract_example_signature=_extract_example_signature,
            rank_candidates=_rank_candidates,
            parse_wolfram_association=_parse_wolfram_association,
            execute_code=execute_code,
        )

    if FEATURES.math_aliases:
        from .optional_math_aliases import register_math_alias_tools

        register_math_alias_tools(instrumented_mcp, execute_code)

    if FEATURES.function_repository:
        from .optional_repository_tools import register_function_repository_tools

        register_function_repository_tools(instrumented_mcp, parse_wolfram_association=_parse_wolfram_association)

    if FEATURES.data_repository:
        from .optional_repository_tools import register_data_repository_tools

        register_data_repository_tools(instrumented_mcp, parse_wolfram_association=_parse_wolfram_association)

    if FEATURES.async_computation:
        from .optional_async_jobs import register_async_computation_tools

        register_async_computation_tools(instrumented_mcp)

    if FEATURES.cache_tools:
        from .optional_cache_tools import register_cache_tools

        register_cache_tools(
            instrumented_mcp,
            cache_expression_fn=_cache_expr,
            get_cached_expression_fn=_get_cached,
            list_cached_expressions_fn=list_cached_expressions,
            clear_cache_fn=clear_cache,
            execute_code=execute_code,
        )

    if FEATURES.telemetry:
        from .optional_telemetry_tools import register_telemetry_tools

        register_telemetry_tools(
            instrumented_mcp,
            get_usage_stats=get_usage_stats,
            reset_stats=reset_stats,
        )

    if FEATURES.routing_memory != "off" and FEATURES.profile == "full":
        from .optional_routing_tools import register_routing_tools

        register_routing_tools(instrumented_mcp)


def _apply_guidance_docs() -> None:
    execute_code.__doc__ = execute_code_doc(FEATURES.default_output_target)
    create_notebook.__doc__ = create_notebook_doc()
    write_cell.__doc__ = write_cell_doc()
    evaluate_cell.__doc__ = evaluate_cell_doc()
    evaluate_selection.__doc__ = evaluate_selection_doc()
    read_notebook.__doc__ = read_notebook_doc()
    read_notebook_content.__doc__ = legacy_notebook_doc("Read notebook content as structured text.")
    convert_notebook.__doc__ = legacy_notebook_doc(
        "Convert a notebook into markdown, LaTeX, plain text, or Wolfram code."
    )
    get_notebook_outline.__doc__ = legacy_notebook_doc("Get the notebook's section outline.")
    parse_notebook_python.__doc__ = legacy_notebook_doc("Parse a notebook with the Python-native parser.")
    get_notebook_cell.__doc__ = legacy_notebook_doc("Read a single notebook cell by index.")


@_tool("notebook_primary")
async def open_notebook_file(path: str, session_id: str | None = None) -> str:
    """
    Open an existing Mathematica notebook file (.nb) in the Mathematica frontend.

    Supports:
    - Absolute paths: /Users/foo/notebook.nb
    - Home-relative paths: ~/Documents/notebook.nb
    - Relative paths (resolved from current directory)

    Args:
        path: Path to the .nb file

    Returns:
        Notebook ID and metadata for use with other notebook commands

    Example:
        open_notebook_file("~/Documents/analysis.nb") -> {id: "NotebookObject[...]", cell_count: 15}
    """
    expanded = _expand_path(path)
    result = await _addon_result("open_notebook_file", {"path": expanded, "session_id": session_id})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"], "path": expanded})

    return _json_response(result)


@_tool("file_legacy")
async def run_script(path: str) -> str:
    """
    Execute a Wolfram Language script file (.wl, .m) and return the result.

    This is equivalent to Get[path] - loads and executes the script in the
    current kernel session. Any definitions or side effects persist.

    Args:
        path: Path to the .wl or .m script file

    Returns:
        The result of the last expression in the script, plus timing info

    Example:
        run_script("~/scripts/setup.wl") -> {result: "Null", timing_ms: 150}
    """
    expanded = _expand_path(path)
    result = await _addon_result("run_script", {"path": expanded})

    if result.get("error"):
        return _json_response({"success": False, "error": result["error"], "path": expanded})

    bump_kernel_epoch()
    return _json_response(result)


@_tool("file_legacy")
async def read_notebook_content(path: str, include_outputs: bool = False) -> str:
    """
    Read the content of a notebook file as structured text.

    Extracts all cells from a notebook file without opening it in the frontend.
    Useful for understanding what's in a notebook before opening it.

    Args:
        path: Path to the .nb file
        include_outputs: If True, include Output cells (default: only Input/Text)

    Returns:
        Structured list of cells with their content and styles
    """
    expanded = _expand_path(path)

    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    try:
        from .notebook_parser import CellStyle

        notebook = await _run_blocking(_load_cached_notebook, expanded, truncation_threshold=25000)
        allowed_styles = {
            CellStyle.INPUT,
            CellStyle.CODE,
            CellStyle.TEXT,
            CellStyle.SECTION,
            CellStyle.SUBSECTION,
            CellStyle.TITLE,
        }

        cells = []
        for cell in notebook.cells:
            if include_outputs or cell.style in allowed_styles:
                cells.append({"content": cell.content, "style": cell.style.value})

        return _json_response(
            {
                "success": True,
                "path": expanded,
                "cell_count": len(cells),
                "cells": cells[:50],
            }
        )
    except Exception as e:
        return _json_response({"success": False, "error": str(e)})


@_tool("file_legacy")
async def convert_notebook(
    path: str,
    output_format: Literal["markdown", "latex", "plain", "wolfram"] = "markdown",
) -> str:
    """
    Convert a Mathematica notebook to another format.

    Supported formats:
    - markdown: Readable Markdown with code blocks
    - latex: LaTeX document
    - plain: Plain text
    - wolfram: Pure Wolfram Language code only

    Args:
        path: Path to the .nb file
        output_format: Target format

    Returns:
        Converted content as a string
    """
    expanded = _expand_path(path)

    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    try:
        from .notebook_parser import NotebookParser

        notebook = await _run_blocking(_load_cached_notebook, expanded, truncation_threshold=25000)
        parser = NotebookParser(truncation_threshold=25000)

        if output_format == "markdown":
            content = parser.to_markdown(notebook)
        elif output_format == "wolfram":
            content = parser.to_wolfram_code(notebook)
        elif output_format == "plain":
            content = parser.to_plain_text(notebook)
        else:
            import subprocess

            from .lazy_wolfram_tools import _find_wolframscript

            wolframscript = _find_wolframscript()
            if not wolframscript:
                return _json_response({"success": False, "error": "wolframscript not found"})

            code = f'''
Module[{{nb, content}},
  nb = Import["{expanded}"];
  content = ExportString[nb, "TeX"];
  <|"success" -> True, "format" -> "{output_format}", "content" -> content|>
]
'''
            result = await _run_blocking(
                subprocess.run,
                [wolframscript, "-code", code],
                capture_output=True,
                text=True,
                timeout=60,
            )
            output = result.stdout.strip()
            parsed = _parse_wolfram_association(output)
            return _json_response(parsed)

        return _json_response({"success": True, "format": output_format, "content": content})
    except Exception as e:
        return _json_response({"success": False, "error": str(e)})


@_tool("file_legacy")
async def get_notebook_outline(path: str) -> str:
    """
    Get the structural outline of a notebook (sections, subsections, titles).

    Like a table of contents - shows the organization without full content.

    Args:
        path: Path to the .nb file

    Returns:
        Hierarchical outline of notebook sections
    """
    expanded = _expand_path(path)

    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    try:
        notebook = await _run_blocking(_load_cached_notebook, expanded, truncation_threshold=25000)
        sections = notebook.get_outline()
        return _json_response(
            {
                "success": True,
                "path": expanded,
                "sections": sections,
                "count": len(sections),
            }
        )
    except Exception as e:
        return _json_response({"success": False, "error": str(e)})


@_tool("file_legacy")
async def parse_notebook_python(
    path: str,
    output_format: Literal["markdown", "wolfram", "outline", "json"] = "markdown",
    truncation_threshold: int = 25000,
) -> str:
    """
    Parse a Mathematica notebook using Python-native parser.

    This tool provides offline notebook parsing without requiring wolframscript.
    It extracts clean, readable Wolfram code from complex BoxData structures.

    Args:
        path: Path to the .nb file
        output_format:
            - "markdown": Readable Markdown with code blocks (default)
            - "wolfram": Pure executable Wolfram Language code only
            - "outline": Hierarchical section outline
            - "json": Structured JSON with all cell data
        truncation_threshold: Max chars per cell before truncation (default 25000).
            Set to 0 to disable truncation (may timeout on large notebooks).

    Returns:
        Notebook content in the requested format
    """
    from .notebook_parser import NotebookParser

    expanded = _expand_path(path)

    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    try:
        effective_threshold = truncation_threshold if truncation_threshold > 0 else 10**9
        parser = NotebookParser(truncation_threshold=effective_threshold)
        notebook = await _run_blocking(
            _load_cached_notebook,
            expanded,
            truncation_threshold=effective_threshold,
        )

        if output_format == "markdown":
            content = parser.to_markdown(notebook)
            return json.dumps(
                {
                    "success": True,
                    "format": "markdown",
                    "path": expanded,
                    "cell_count": len(notebook.cells),
                    "code_cells": len(notebook.get_code_cells()),
                    "content": content,
                },
                indent=2,
            )

        elif output_format == "wolfram":
            content = parser.to_wolfram_code(notebook)
            return json.dumps(
                {
                    "success": True,
                    "format": "wolfram",
                    "path": expanded,
                    "code_cells": len(notebook.get_code_cells()),
                    "content": content,
                },
                indent=2,
            )

        elif output_format == "outline":
            outline = notebook.get_outline()
            return json.dumps(
                {
                    "success": True,
                    "format": "outline",
                    "path": expanded,
                    "section_count": len(outline),
                    "sections": outline,
                },
                indent=2,
            )

        elif output_format == "json":
            cells_data = [
                {
                    "index": c.cell_index,
                    "style": c.style.value,
                    "label": c.cell_label,
                    "content": c.content[:500] if len(c.content) > 500 else c.content,
                    "content_length": len(c.content),
                    "truncated_in_json": len(c.content) > 500,
                    "was_truncated": c.was_truncated,
                    "original_length": c.original_length if c.was_truncated else len(c.content),
                }
                for c in notebook.cells
            ]
            return json.dumps(
                {
                    "success": True,
                    "format": "json",
                    "path": expanded,
                    "title": notebook.title,
                    "cell_count": len(notebook.cells),
                    "code_cells": len(notebook.get_code_cells()),
                    "cells": cells_data,
                },
                indent=2,
            )

        else:
            return json.dumps(
                {"success": False, "error": f"Unknown format: {output_format}"},
                indent=2,
            )

    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, indent=2)


@_tool("file_legacy")
async def get_notebook_cell(
    path: str,
    cell_index: int,
    full: bool = False,
) -> str:
    """
    Get the full content of a specific cell by index.

    Use parse_notebook_python with format="json" to see all cell indices first.

    Args:
        path: Path to the .nb file
        cell_index: Cell index (0-based)
        full: If True, bypass truncation and return complete cell content (may be very large)

    Returns:
        Full cell content and metadata
    """

    expanded = _expand_path(path)

    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    try:
        threshold = 10**9 if full else 25000
        notebook = await _run_blocking(_load_cached_notebook, expanded, truncation_threshold=threshold)

        if cell_index < 0 or cell_index >= len(notebook.cells):
            return json.dumps(
                {
                    "success": False,
                    "error": f"Cell index {cell_index} out of range (0-{len(notebook.cells) - 1})",
                },
                indent=2,
            )

        cell = notebook.cells[cell_index]
        return json.dumps(
            {
                "success": True,
                "index": cell.cell_index,
                "style": cell.style.value,
                "label": cell.cell_label,
                "content": cell.content,
                "content_length": len(cell.content),
                "was_truncated": cell.was_truncated,
                "original_length": cell.original_length if cell.was_truncated else len(cell.content),
                "raw_content_preview": cell.raw_content[:500] if cell.raw_content else "",
            },
            indent=2,
        )

    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, indent=2)


# ============================================================================
# TIER 2b: Consolidated Notebook Reading (backend-aware)
# ============================================================================


@_tool("notebook_primary")
async def read_notebook(
    path: str,
    output_format: Literal["markdown", "wolfram", "outline", "json", "plain"] = "markdown",
    cell_types: list[str] | None = None,
    include_outputs: bool = True,
    backend: str | None = None,
    view: str = "semantic",
    include_alternates: bool = False,
    truncation_threshold: int = 25000,
) -> str:
    """
    Read a Mathematica notebook with capability-based backend dispatch.

    Consolidates notebook reading into a single tool. Uses the best available
    backend: kernel (accurate, via NotebookImport) or Python parser (offline).

    Args:
        path: Path to the .nb file
        output_format:
            - "markdown": Readable Markdown with code blocks (default)
            - "wolfram": Pure executable Wolfram Language code only
            - "outline": Hierarchical section outline
            - "json": Structured JSON with cell data and metadata
            - "plain": Plain text
        cell_types: Optional filter — list of styles like ["Input", "Text", "Section"].
                    If omitted, all cell types are included.
        include_outputs: If True (default), include Output cells.
                         If False, filters out Output/Message/Print cells.
        backend: Force a specific backend: "python_syntax" or "kernel_semantic".
                 If omitted, auto-selects based on capability and availability.
        view: Primary view mode: "semantic" (default), "display", or "raw"
        include_alternates: If True, include alternate views per cell (JSON only)
        truncation_threshold: Max chars per cell before truncation (0 = no limit)

    Returns:
        Notebook content in the requested format
    """
    from .notebook_backend import CellView, extract_notebook

    expanded = _expand_path(path)
    if not os.path.exists(expanded):
        return json.dumps({"success": False, "error": f"File not found: {expanded}"}, indent=2)

    # Build cell type filter
    effective_types = list(cell_types) if cell_types else None
    if not include_outputs:
        # Remove output-like styles from whatever type list we have
        output_styles = {"Output", "Message", "Print"}
        if effective_types is not None:
            effective_types = [t for t in effective_types if t not in output_styles]
        else:
            # No explicit types: include everything except output styles
            effective_types = [
                "Input",
                "Code",
                "Text",
                "Title",
                "Chapter",
                "Section",
                "Subsection",
                "Subsubsection",
                "Item",
                "ItemNumbered",
            ]

    # Map format to capability hint for dispatch
    capability_map = {
        "wolfram": "code",
        "outline": "outline",
        "plain": "text",
        "markdown": "full",
        "json": "full",
    }
    capability = capability_map.get(output_format, "full")

    view_enum = {
        "semantic": CellView.SEMANTIC,
        "display": CellView.DISPLAY,
        "raw": CellView.RAW,
    }.get(view, CellView.SEMANTIC)

    try:
        result = await extract_notebook(
            expanded,
            capability=capability,
            cell_types=effective_types,
            view=view_enum,
            include_alternates=include_alternates,
            truncation_threshold=truncation_threshold,
            force_backend=backend,
        )

        if result.error:
            return _json_response({"success": False, "error": result.error})

        if output_format == "markdown":
            return _json_response(
                {
                    "success": True,
                    "format": "markdown",
                    "backend": result.backend,
                    "path": expanded,
                    "cell_count": result.cell_count,
                    "code_cells": result.code_cell_count,
                    "content": result.to_markdown(),
                }
            )
        elif output_format == "wolfram":
            return _json_response(
                {
                    "success": True,
                    "format": "wolfram",
                    "backend": result.backend,
                    "path": expanded,
                    "code_cells": result.code_cell_count,
                    "content": result.to_wolfram_code(),
                }
            )
        elif output_format == "outline":
            outline = result.to_outline()
            return _json_response(
                {
                    "success": True,
                    "format": "outline",
                    "backend": result.backend,
                    "path": expanded,
                    "section_count": len(outline),
                    "sections": outline,
                }
            )
        elif output_format == "plain":
            return _json_response(
                {
                    "success": True,
                    "format": "plain",
                    "backend": result.backend,
                    "path": expanded,
                    "cell_count": result.cell_count,
                    "content": result.to_plain_text(),
                }
            )
        elif output_format == "json":
            return _json_response(result.to_dict(include_alternates))
        else:
            return _json_response({"success": False, "error": f"Unknown format: {output_format}"})

    except Exception as e:
        return _json_response({"success": False, "error": str(e)})


# ============================================================================
# TIER 3: Wolfram Alpha & Natural Language
# ============================================================================


@_tool("knowledge")
async def wolfram_alpha(
    query: str,
    return_type: Literal["result", "data", "full"] = "result",
) -> str:
    """
    Query Wolfram Alpha with natural language.

    This gives Mathematica superpowers - ask questions in plain English
    and get computed answers, data, and more.

    Args:
        query: Natural language question (e.g., "population of France",
               "integrate x^2 from 0 to 1", "weather in Tokyo")
        return_type:
            - "result": Simple text result (default)
            - "data": Structured data when available
            - "full": All available pods/information

    Returns:
        Wolfram Alpha response in requested format

    Example:
        wolfram_alpha("population of Tokyo") -> "13.96 million people (2021)"
        wolfram_alpha("derivative of sin(x^2)", "data") -> {result: "2 x cos(x^2)"}
    """
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.wolfram_alpha(
        query,
        return_type,
        parse_wolfram_association=_parse_wolfram_association,
    )


@_tool("knowledge")
async def interpret_natural_language(text: str) -> str:
    """
    Convert natural language mathematical description to Wolfram Language code.

    This is magic - describe what you want in English and get executable code.

    Args:
        text: Natural language description (e.g., "the integral of x squared from 0 to 1",
              "solve x squared equals 4 for x", "plot sine of x from 0 to 2 pi")

    Returns:
        Wolfram Language code and its evaluation result

    Example:
        interpret_natural_language("the derivative of e to the x")
        -> {code: "D[E^x, x]", result: "E^x"}
    """
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.interpret_natural_language(text)


@_tool("knowledge")
async def entity_lookup(
    entity_type: str,
    name: str,
    properties: list[str] | None = None,
) -> str:
    """
    Look up real-world entity data from Wolfram's curated knowledge base.

    Entity types include: "Country", "City", "Chemical", "Planet", "Company",
    "Person", "Movie", "University", "Element", "Star", and many more.

    Args:
        entity_type: Type of entity (e.g., "Country", "City", "Chemical")
        name: Name to look up (e.g., "France", "Tokyo", "Water")
        properties: Specific properties to retrieve (default: common properties)

    Returns:
        Entity data with requested properties

    Example:
        entity_lookup("Country", "Japan", ["Population", "Capital", "GDP"])
        -> {name: "Japan", Population: "125.8 million", Capital: "Tokyo", GDP: "$4.94 trillion"}
    """
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.entity_lookup(
        entity_type,
        name,
        properties,
        parse_wolfram_association=_parse_wolfram_association,
    )


@_tool("knowledge")
async def convert_units(quantity: str, target_unit: str) -> str:
    """
    Convert between units using Wolfram's comprehensive unit system.

    Args:
        quantity: Value with unit (e.g., "5 miles", "100 kg", "25 Celsius")
        target_unit: Target unit (e.g., "kilometers", "pounds", "Fahrenheit")

    Returns:
        Converted quantity

    Example:
        convert_units("100 kilometers", "miles") -> "62.1371 miles"
        convert_units("0 Celsius", "Fahrenheit") -> "32 Fahrenheit"
    """
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.convert_units(
        quantity,
        target_unit,
        parse_wolfram_association=_parse_wolfram_association,
    )


@_tool("knowledge")
async def get_constant(name: str) -> str:
    """
    Get a physical or mathematical constant.

    Args:
        name: Constant name (e.g., "SpeedOfLight", "PlanckConstant", "Pi",
              "EulerGamma", "GoldenRatio", "Avogadro")

    Returns:
        Constant value with unit (if applicable) and numeric approximation

    Example:
        get_constant("SpeedOfLight") -> {value: "299792458 m/s", numeric: "2.998e8"}
    """
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.get_constant(name, parse_wolfram_association=_parse_wolfram_association)


# ============================================================================
# TIER 4: Interactive Debugging & Tracing
# ============================================================================


@_tool("debug")
async def trace_evaluation(expression: str, max_depth: int = 5) -> str:
    """Trace the step-by-step evaluation of an expression."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.trace_evaluation(
        expression,
        max_depth,
        addon_result=_addon_result,
    )


@_tool("debug")
async def time_expression(expression: str) -> str:
    """Time the evaluation of an expression with memory tracking."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.time_expression(expression, addon_result=_addon_result)


@_tool("core")
async def check_syntax(code: str) -> str:
    """Validate Wolfram Language code syntax without executing it."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.check_syntax(code, addon_result=_addon_result)


# ============================================================================
# TIER 5: Data I/O
# ============================================================================


@_tool("data")
async def import_data(
    path: str,
    format: str | None = None,
) -> str:
    """Import data from a file or URL into Mathematica."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.import_data(
        path,
        format,
        addon_result=_addon_result,
        expand_path=_expand_path,
    )


@_tool("data")
async def export_data(
    expression: str,
    path: str,
    format: str | None = None,
) -> str:
    """Export data or graphics to a file."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.export_data(
        expression,
        path,
        format,
        addon_result=_addon_result,
        expand_path=_expand_path,
    )


@_tool("data")
async def list_supported_formats() -> str:
    """List all supported import/export formats."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.list_supported_formats(
        addon_result=_addon_result,
        parse_wolfram_association=_parse_wolfram_association,
    )


# ============================================================================
# TIER 6: Visualization
# ============================================================================


@_tool("graphics")
async def inspect_graphics(expression: str) -> str:
    """Analyze the structure of a graphics object."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.inspect_graphics(expression, parse_wolfram_association=_parse_wolfram_association)


@_tool("graphics")
async def export_graphics(
    expression: str,
    path: str,
    format: Literal["PNG", "PDF", "SVG", "EPS", "JPEG"] = "PNG",
    size: int = 600,
) -> str:
    """Export a graphics expression to an image file."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.export_graphics(
        expression,
        path,
        format,
        size,
        addon_result=_addon_result,
        expand_path=_expand_path,
    )


@_tool("graphics")
async def compare_plots(expressions: list[str], labels: list[str] | None = None) -> str:
    """Generate a side-by-side comparison of multiple plots."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.compare_plots(
        expressions,
        labels,
        parse_wolfram_association=_parse_wolfram_association,
    )


@_tool("graphics")
async def create_animation(
    expression: str,
    parameter: str,
    range_spec: str,
    frames: int = 20,
) -> str:
    """Create an animation by varying a parameter."""
    from . import lazy_wolfram_tools as _lazy_wolfram_tools

    return await _lazy_wolfram_tools.create_animation(
        expression,
        parameter,
        range_spec,
        frames,
        parse_wolfram_association=_parse_wolfram_association,
    )


# ============================================================================
# Feature Flags and Telemetry
# ============================================================================


@_tool("core")
async def get_feature_status() -> str:
    """Get the status of all feature flags."""
    return json.dumps(
        {
            "success": True,
            "features": FEATURES.to_dict(),
        },
        indent=2,
    )


@_tool("debug")
async def get_computation_journal() -> str:
    """Get recent computation history: code previews, outputs, timing, success status."""
    if _journal is None:
        return _json_response({"success": False, "error": "Journal not initialized"})
    return _json_response({"success": True, **_journal.to_dict()})


@_tool("debug")
async def clear_computation_journal() -> str:
    """Clear the computation journal."""
    if _journal is None:
        return _json_response({"success": False, "error": "Journal not initialized"})
    _journal.clear()
    return _json_response({"success": True, "message": "Computation journal cleared."})


_apply_guidance_docs()
_register_core_tools()
_register_optional_tools()

# Initialize routing memory if enabled
if FEATURES.routing_memory != "off":
    from .routing_memory import init as _init_routing

    _routing_mem = _init_routing(FEATURES.routing_memory)

# Initialize journal
from .journal import ComputationJournal  # noqa: E402

_journal = ComputationJournal()


@mcp.prompt()
def mathematica_expert(user_request: str = "") -> str:
    """Expert guidance for using Mathematica tools effectively."""
    return build_mathematica_expert_prompt(user_request, features=FEATURES)


@mcp.prompt()
def calculate(expression: str) -> str:
    """Compute a result inline in chat. Use for quick math, algebra, or any text answer."""
    return f"Calculate the following and return the result inline (use style='compute'):\n\n{expression}"


@mcp.prompt()
def notebook(task: str) -> str:
    """Execute in the current Mathematica notebook. Use for plots, visualizations, or notebook artifacts."""
    return f"Execute the following in the current Mathematica notebook (use style='notebook'):\n\n{task}"


@mcp.prompt()
def new_notebook(task: str, title: str = "Analysis") -> str:
    """Create a fresh Mathematica notebook and execute there. Use when you want a clean slate."""
    return (
        f"Create a new Mathematica notebook titled '{title}' using create_notebook(), "
        f"then execute the following in it (use style='notebook'):\n\n"
        f"{task}"
    )


@mcp.prompt()
def interactive(task: str) -> str:
    """Execute with frontend mode for dynamic/interactive content (Manipulate, Animate, sliders)."""
    return (
        f"Execute the following in the notebook using frontend mode for dynamic interaction "
        f"(use style='interactive'):\n\n"
        f"{task}"
    )


@mcp.prompt()
def quickstart() -> str:
    """Show available execution styles and how to use them."""
    return f"""Show the user this quick reference for Mathematica MCP styles:

## Mathematica MCP — Execution Styles

### For chat users — use keywords in your prompt

| Say this...                     | What happens                                    |
|---------------------------------|-------------------------------------------------|
| **"calculate ..."**             | Result appears inline in chat                   |
| **"plot ..."** / **"show ..."** | Executes in current Mathematica notebook         |
| **"in new notebook: ..."**      | Creates a fresh notebook, then executes there    |
| **"interactive ..."**           | Notebook with sliders/Manipulate (frontend mode) |

### For tool callers — use the `style` parameter

| `style=`          | What happens                                    |
|-------------------|-------------------------------------------------|
| `"compute"`       | Fast kernel evaluation, result in chat          |
| `"notebook"`      | Evaluate in kernel, show in notebook cell       |
| `"interactive"`   | Front-end evaluation (Manipulate/Dynamic)       |

> There is no `style="new_notebook"`. Create a fresh notebook with
> `create_notebook(title="...")` then `execute_code(style="notebook")`.

### Examples
- "Calculate the integral of x^3 from 0 to 1"  →  answer in chat
- "Plot Sin[x] from 0 to 2π"  →  plot appears in notebook
- "In new notebook: integrate 1/x^5 + x^7 and plot the region"  →  fresh notebook
- "Interactive: Manipulate a slider for Plot[Sin[n x], {{x, 0, 2π}}]"  →  dynamic UI

If you don't use a keyword, the default is: `{FEATURES.default_output_target}`
"""


def main():
    mcp.run()


if __name__ == "__main__":
    main()
