""" life_cycle_state_machine.py """

# System
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from mx.domain import Domain

# Model Integration
from pyral.relation import Relation

# MX
from mx.state_machine import StateMachine
from mx.db_names import mmdb
from mx.mxtypes import StateMachineType


class LifecycleStateMachine(StateMachine):

    instance_id = None
    class_name = None
    domain = None

    def __init__(self, lifecycle_sm_id: int, current_state: str, instance_id: dict[str, Any], class_name: str,
                 domain: "Domain"):

        # Owner name is prefixed with the state machine type
        rv_owner = f"Lifecycle_SM_{lifecycle_sm_id}"

        super().__init__(sm_id=f"lc_{lifecycle_sm_id}", rv_owner=rv_owner, current_state=current_state,
                         state_model=class_name, sm_type=StateMachineType.LIFECYCLE, domain=domain)

        self.lifecycle_sm_id = lifecycle_sm_id  # Unique among lifecycle state machines in this domain
        self.instance_id = instance_id
        self.class_name = class_name

