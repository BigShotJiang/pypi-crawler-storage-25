""" signal_action.py -- Executes a Signal Action as defined in the SM Metamodel """

# System
import logging
from typing import TYPE_CHECKING, NamedTuple

# Model Integration
from pyral.relation import Relation
from pyral.relation import _relation  # For table_msg
from pyral.database import Database  # Diagnostics

# MX
if TYPE_CHECKING:
    from mx.activity_execution import ActivityExecution
from mx.log_table_config import TABLE, log_table
from mx.message import *
from mx.db_names import mmdb
from mx.actions.action_execution import ActionExecution
from mx.actions.flow import ActiveFlow
from mx.completion_event import CompletionEvent
from mx.interaction_event import InteractionEvent
from mx.rvname import declare_rvs
from mx.exceptions import *
from mx.mxtypes import *

_logger = logging.getLogger(__name__)


class MMRVs(NamedTuple):
    send_signal_action: str
    signal_assigner_action: str
    signal_instance_action: str
    initial_signal_action: str
    initial_pseudo_state: str  # Delegated Creation Activity
    initial_transition: str


# This wrapper calls the imported declare_rvs function to generate a NamedTuple instance with each of our
# variables above as a member.
def declare_mm_rvs(owner: str) -> MMRVs:
    rvs = declare_rvs(mmdb, owner,
                      "send_signal_action",
                      "signal_assigner_action",
                      "signal_instance_action",
                      "initial_signal_action",
                      "initial_pseudo_state",
                      "initial_transition",
                      )
    return MMRVs(*rvs)


class Signal(ActionExecution):
    """
    See the Signal Action subsystem class model to find all referenced classes in the comments
    in this python module.
    """
    # Default model debugger monitoring options
    monitor_external = False
    monitor_internal = False

    def __init__(self, action_id: str, activity_execution: "ActivityExecution"):
        super().__init__(activity_execution=activity_execution, action_id=action_id)

        # Do not execute this Action if it is not enabled, see comment in Action class
        if self.disabled:
            return

        # Get a NamedTuple with a field for each relation variable name
        self.mmrv = declare_mm_rvs(owner=self.owner)

        self.signal_source = self.set_source_address()
        self.event_spec: str | None = None
        self.supplied_params = self.set_supplied_params()

        self.process_signal()

        self.complete()

    def set_source_address(self) -> ElementAddress:
        """
        Determine the address of the event source.

        Returns:
            ElementAddress: namedtuple with the source address data
        """
        # TODO: This only works for state activity sources, add Method / Domain operation activities
        # Determine the source type
        match self.activity_execution.state_machine.sm_type:
            case StateMachineType.LIFECYCLE:
                signal_source = InstanceAddress(
                    domain=self.activity_execution.domain.name,
                    class_name=self.activity_execution.state_machine.state_model,
                    instance_id=self.activity_execution.state_machine.instance_id
                )
            case StateMachineType.MA:
                signal_source = AssignerAddress(
                    domain=self.activity_execution.domain.name,
                    rel_name=self.activity_execution.state_machine.state_model,
                    instance_id=self.activity_execution.state_machine.instance_id
                )
            case StateMachineType.SA:
                signal_source = AssignerAddress(
                    domain=self.activity_execution.domain.name,
                    rel_name=self.activity_execution.state_machine.state_model,
                    instance_id=None
                )
        return signal_source

    def process_signal(self):
        """
        Determine whether this Signal Action actually sends a signal or if it is cancelling a delayed event.
        """
        mmrv = self.mmrv

        # Determine the type of signal to be generated
        send_signal_t = Relation.semijoin(db=mmdb, rname1=self.action_mmrv, rname2="Send Signal Action",
                                          svar_name=mmrv.send_signal_action)
        log_table(_logger, table_msg(db=mmdb, variable_name=mmrv.send_signal_action))
        if send_signal_t.body:
            self.process_send_signal()
        else:
            self.process_cancel_delay()

    def process_send_signal(self):
        """
        Here we determine the type of destination and process accordingly.
        Each subclass of Send Signal Action defines a possible destination.
        """
        mmrv = self.mmrv

        # Get any supplied parameters
        self.set_supplied_params()

        # Get the event spec name (needed for any Send Signal Action)
        signal_send_action_r = Relation.restrict(db=mmdb, relation=mmrv.send_signal_action)
        self.event_spec = signal_send_action_r.body[0]["Event_spec"]

        # Mutually exclusive destination cases

        # Signal Completion Action (self)
        signal_completion_action_r = Relation.join(
            db=mmdb, rname1=mmrv.send_signal_action, rname2="Signal Completion Action",
            svar_name=mmrv.signal_instance_action
        )
        if signal_completion_action_r.body:
            self.signal_completion()
            return

        # For all other cases we will need to specify the source of the event as an ElementAddress

        # Signal Instance
        signal_instance_action_r = Relation.join(
            db=mmdb, rname1=mmrv.send_signal_action, rname2="Signal Instance Action",
            svar_name=mmrv.signal_instance_action
        )
        if signal_instance_action_r.body:
            log_table(_logger, table_msg(db=mmdb, variable_name=mmrv.signal_instance_action))
            self.signal_instance(target_inst_flow_name = signal_instance_action_r.body[0]['Instance_flow'])
            return

        # Signal Assigner State Machine (single or multiple)
        signal_assigner_action_r = Relation.join(
            db=mmdb, rname1=mmrv.send_signal_action, rname2="Signal Assigner Action",
            svar_name=mmrv.signal_assigner_action
        )
        if signal_assigner_action_r.body:
            log_table(_logger, table_msg(db=mmdb, variable_name=mmrv.signal_assigner_action))
            self.signal_assigner()
            return

        # Initial Signal
        initial_signal_action_r = Relation.join(
            db=mmdb, rname1=mmrv.send_signal_action, rname2="Initial Signal Action",
            svar_name=mmrv.initial_signal_action
        )
        if initial_signal_action_r.body:
            log_table(_logger, table_msg(db=mmdb, variable_name=mmrv.initial_signal_action))
            self.initial_signal()
            return

    def signal_instance(self, target_inst_flow_name: str):
        """
        Process an signal to an instance. An event is dispatched to an existing lifecycle state machine.

        Args:
            target_inst_flow_name: The name of the flow providing the instance recieving the signal
        """
        mmrv = self.mmrv
        # Check for a delivery time
        delay_duration = None  # Default assumption
        delivery_time_r = Relation.semijoin(db=mmdb, rname1=mmrv.signal_instance_action, rname2='Delivery Time',
                                            attrs={'ID': 'Action', 'Activity': 'Activity', 'Domain': 'Domain'})
        if delivery_time_r.body:
            t = delivery_time_r.body[0]
            if not t['Relative']:
                # This is not a delay, but a specified time
                # TODO: We'll support this in the future
                msg = f"Absolute time event delivery not yet supported"
                _logger.error(msg)
                raise MXActionException(msg)
            pass

            delay_flow_name = t['Flow']
            delay_duration = float(self.activity_execution.flows[delay_flow_name].value)

        # The Signal Instance Action takes an input that specifies any number of target instances
        # all belonging to the same class
        target_inst_flow = self.activity_execution.flows[target_inst_flow_name]
        log_table(_logger, table_msg(db=self.domdb, variable_name=target_inst_flow.value))
        target_inst_r = Relation.restrict(db=self.domdb, relation=target_inst_flow.value)

        # The flow type gives us the class name
        target_class_name = target_inst_flow.flowtype

        # We dispatch a distinct signal (if any) to each target instance
        for t in target_inst_r.body:
            # Create an instance of Interaction Event to dispatch it
            # Each t is a reference to a single instance of the flow's class type
            InteractionEvent(sm_type=StateMachineType.LIFECYCLE, event_spec=self.event_spec, params=self.supplied_params,
                             domain=self.activity_execution.domain, source=self.signal_source, to_instance=t,
                             to_class=target_class_name, delay=delay_duration)
        pass

    def initial_signal(self):
        """
        Process an initial signal. An event is dispatched to an lifecycle state machine, but the instance and
        state machine must be created first.
        """
        mmrv = self.mmrv
        # Locate the Delegated Creaction Activity and execute it
        # Most of what we need is in the Initial Pseudo State class
        Relation.semijoin(db=mmdb, rname1=mmrv.initial_signal_action, rname2='Initial Pseudo State',
                          attrs={'Pseudo_state': 'Name', 'Class': 'Class', 'Domain': 'Domain'},
                          svar_name=mmrv.initial_pseudo_state)
        # log_table(_logger, table_msg(db=mmdb, variable_name=mmrv.initial_pseudo_state))

        from mx.dc_activity_execution import DelegatedCreationActivity
        dca = DelegatedCreationActivity(ips_rv=mmrv.initial_pseudo_state, parameters=self.supplied_params,
                                        domain=self.activity_execution.domain,
                                        signal_action_mmrv=mmrv.initial_signal_action,
                                        source_activity_execution=self.activity_execution)

        # Create an instance of Interaction Event to dispatch it
        InteractionEvent(sm_type=StateMachineType.LIFECYCLE, event_spec=self.event_spec, params=self.supplied_params,
                         domain=self.activity_execution.domain, source=self.signal_source, to_instance=dca.new_inst_id,
                         to_class=dca.lsm.class_name)
        pass

    def signal_assigner(self):
        mmrv = self.mmrv
        pass
        signal_assigner_action_t = Relation.semijoin(db=mmdb, rname1=mmrv.signal_assigner_action,
                                                     rname2="Signal Assigner Action")
        rnum = signal_assigner_action_t.body[0]['Association']
        ma_partition_instance_t = Relation.semijoin(db=mmdb, rname2="Multiple Assigner Partition Instance")
        partition_flow = None if not ma_partition_instance_t.body else ma_partition_instance_t.body[0]["Partition"]
        pinst_id = None
        pclass = None
        if partition_flow:
            _logger.info(f"Partition flow on multiple assigner: {partition_flow}")
            pflow_value = self.activity_execution.flows[partition_flow].value
            pclass = self.activity_execution.flows[partition_flow].flowtype
            pflow_t = Relation.restrict(db=self.domdb, relation=pflow_value)
            pinst_id = pflow_t.body[0]
        send_signal_action_t = Relation.restrict(db=mmdb, relation=mmrv.send_signal_action)
        InteractionEvent(
            sm_type=StateMachineType.MA if partition_flow else StateMachineType.SA,
            event_spec=send_signal_action_t.body[0]["Event_spec"],
            params=self.supplied_params,
            domain=self.activity_execution.domain,
            source=InstanceAddress(
                domain=self.activity_execution.domain.name,
                class_name=self.activity_execution.state_machine.state_model,
                instance_id=self.activity_execution.state_machine.instance_id),
            to_instance=None,
            to_class=None,
            partitioning_instance=pinst_id,
            partitioning_class=pclass,
            to_rnum=rnum
        )

    def signal_completion(self):
        """
        Dispatch a Completion Event
        """
        # The source is the same as the destination for a Completion Event
        # And we know the source must be a State Model, assigner or lifecycle
        # So we must fill out the appropriate named tuple
        match self.activity_execution.state_machine.sm_type:
            case StateMachineType.LIFECYCLE:
                CompletionEvent(sm_type=self.activity_execution.state_machine.sm_type,
                                event_spec=self.event_spec, params=self.supplied_params,
                                domain=self.activity_execution.domain, source=self.signal_source)
            case StateMachineType.MA:
                CompletionEvent(sm_type=self.activity_execution.state_machine.sm_type,
                                event_spec=self.event_spec, params=self.supplied_params,
                                domain=self.activity_execution.domain, source=self.signal_source,
                                partitioning_class=self.activity_execution.state_machine.pclass_name,
                                partitioning_instance=self.activity_execution.state_machine.instance_id,
                                to_rnum=self.activity_execution.state_machine.state_model)
            case StateMachineType.SA:
                pass


    def process_cancel_delay(self):
        pass

    def set_supplied_params(self) -> NamedValues:
        # Get the parameters
        # TODO: Process signal with parameters when we have an example
        # supplied_parameter_value_r = Relation.semijoin(db=mmdb, rname1=send_signal_action_rv,
        #                                                rname2="Supplied Parameter Value")
        return {}

        pass
