""" flow.py -- Active Flow type """

# System
from enum import Enum, auto
from typing import TYPE_CHECKING, NamedTuple, Any

# Model Integration
from pyral.relation import Relation

# MX
from mx.db_names import mmdb
if TYPE_CHECKING:
    from mx.activity_execution import ActivityExecution


class ActiveFlow(NamedTuple):
    value: Any
    flowtype: str
    scalar: str | None = None  # We set this value only if the flowtype is 'scalar'

class FlowDir(Enum):
    IN = "in"
    OUT = "out"

def label(name: str, activity: "ActivityExecution") -> str:
    R = f"ID:<{name}>, Activity:<{activity.anum}>, Domain:<{activity.domain.name}>"
    labeled_flow_r = Relation.restrict(db=mmdb, relation='Labeled Flow', restriction=R)
    if labeled_flow_r.body:
        return labeled_flow_r.body[0]["Name"]
    else:
        return ""




