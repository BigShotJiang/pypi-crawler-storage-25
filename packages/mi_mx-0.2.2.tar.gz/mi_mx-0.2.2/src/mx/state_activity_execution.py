""" state_activity_execution.py -- A metamodel StateActivity """

import logging
from typing import TYPE_CHECKING, NamedTuple

if TYPE_CHECKING:
    from mx.state_machine import StateMachine

# Model Integration
from pyral.relvar import Relvar
from pyral.relation import Relation
from pyral.database import Database

# MX
from mx.log_table_config import TABLE
from mx.message import *
from mx.actions.flow import ActiveFlow
from mx.activity_execution import ActivityExecution
from mx.mxtypes import StateMachineType
from mx.utility import *
from mx.db_names import mmdb
from mx.mxtypes import ActionState

_logger = logging.getLogger(__name__)

class StateActivityExecution(ActivityExecution):

    def __init__(self, state_name: str, anum: str, state_machine: "StateMachine"):
        """
        We are here to execute all of the Actions in a State Activity

        Args:
            state_name: Name of the executing state
            anum:  Activity number identifying the State Activity
            state_machine:  State Machine object (instance specific) executing this State Activity
        """
        sa_label = f"{state_machine.state_model}->[{state_name}]"  # For display in log messages
        self.state = state_name
        self.state_machine = state_machine  # The Lifecycle or Assigner State Machine

        # Holds a value only if this is a Lifecycle State Machine
        self.instance_id_value = None
        self.xi_flow_name = None

        # Holds a value only if this is a Multiple Assigner State Machine
        self.pi_flow_name = None
        self.pi_flow_name = None

        # Set signum
        R = f"Name:<{self.state}>, State_model:<{self.state_machine.state_model}>, Domain:<{self.state_machine.domain.name}>"
        state_sig_r = Relation.restrict(db=mmdb, relation="Real State", restriction=R)
        signum = state_sig_r.body[0]['Signature']

        # Initialization specific to each type of State Machine
        match self.state_machine.sm_type:
            case StateMachineType.LIFECYCLE:
                # There is an executing instance of the State Model's Class running this State Activity
                # We flatten the instance id into a string and then use it to define this's ActivityExecution's
                # owner_name. We'll use that to name any local relational variables that are declared, used, and
                # freed up during execution of this State Activity.
                self.instance_id_value = '_'.join(v for v in self.state_machine.instance_id.values())
                # The owner_name is passed along to the superclass for initialization as a self variable

                # We are careful to strip away any terminating ? that may appear in a state name
                # (actually we weren't careful, we got a nasty TclRAL error, and fixed it)  - LS
                owner_name = f"LSM_{self.state_machine.state_model}__{self.state.removesuffix('?')}_{anum}_inst_{self.instance_id_value}"

                # Now we save our Lifecycle Activity instance for use by any executing Action
                # The activity rv_name is passed along to the superclass
                activity_rvn = Relation.declare_rv(db=mmdb, owner=owner_name, name="lifecycle_name")
                R = f"Anum:<{anum}>, Domain:<{self.state_machine.domain.name}>"
                Relation.restrict(db=mmdb, relation='Lifecycle Activity', restriction=R)
                lifecycle_activity_r = Relation.rename(db=mmdb, names={"Anum": "Activity"}, svar_name=activity_rvn)

                # The name of our executing instance flow. This always ends up as "F1", but
                # just in case our Flow naming scheme changes, we check to be sure
                self.xi_flow_name = lifecycle_activity_r.body[0]["Executing_instance_flow"]

            case StateMachineType.MA:
                # It must be a multiple assigner state machine
                # we need the rnum plus the partitioning instance

                # There is an instance of the partitioning class input to this State Activity
                # We flatten the instance id into a string and then use it to define this's ActivityExecution's
                # owner_name. We'll use that to name any local relational variables that are declared, used, and
                # freed up during execution of this State Activity.
                self.pinstance_id_value = '_'.join(v for v in self.state_machine.instance_id.values())
                # The owner_name is passed along to the superclass for initialization as a self variable
                owner_name = f"MASM_{self.state_machine.state_model}__{self.state}_{anum}_inst_"  # TODO: add partitioning inst id
                activity_rvn = Relation.declare_rv(db=mmdb, owner=owner_name, name="multiple_assigner_name")

                # Now we save our Multiple Assigner Activity instance for use by any executing Action
                # The activity rv_name is passed along to the superclass
                R = f"Anum:<{anum}>, Domain:<{self.state_machine.domain.name}>"
                Relation.restrict(db=mmdb, relation='Multiple Assigner Activity', restriction=R)
                ma_activity_r = Relation.rename(db=mmdb, names={"Anum": "Activity"}, svar_name=activity_rvn)

                # The name of our executing instance flow. This always ends up as "F1", but
                # just in case our Flow naming scheme changes, we check to be sure
                self.pi_flow_name = ma_activity_r.body[0]["Partitioning_instance_flow"]

            case StateMachineType.SA:
                # Single assigner is just the rnum
                owner_name = f"SASM_{self.state_machine.state_model}__{self.state}_{anum}"
                activity_rvn = Relation.declare_rv(db=mmdb, owner=owner_name, name="single_assigner_name")

        super().__init__(domain=state_machine.domain, activity_label=sa_label, anum=anum, owner_name=owner_name, activity_rvn=activity_rvn,
                         signum=signum, parameters=state_machine.active_event.params)
        self.cleanup()

    def initialize_action_states(self) -> bool:
        """
        Initialize value of action_states relvar for the executing instance's Real State

        Returns:
            False if there are no Actions defined in this Real State
        """
        _logger.info("Initializing this instance's executing State action states to U (unenabled)")
        # We declare a temporary relation to build the relvar value
        action_init_mmrv = Relation.declare_rv(db=mmdb, owner=self.owner_name, name="action_init")

        # Get all Actions in this State Activity, if any
        R = f"Activity:<{self.anum}>, Domain:<{self.domain.name}>"
        state_action_r = Relation.restrict(db=mmdb, relation="Action", restriction=R, svar_name=action_init_mmrv)
        if not state_action_r.body:
            _logger.info(f"No actions defined in [{self.state}]")
            return False

        # There are actions in this Real State
        # Create a relation and set the execution state of each Action to (U) - unexecuted
        Relation.project(db=mmdb, attributes=("ID",), svar_name=action_init_mmrv)
        Relation.extend(db=mmdb, attrs={'State': 'U'}, svar_name=action_init_mmrv)
        # Now we set the relvar to initial action states
        Relvar.set(db=mmdb, relvar=self.action_states, relation=action_init_mmrv)
        # And free up the temporary relation variable
        Relation.free_rvs(db=mmdb, owner=self.owner_name, names=(action_init_mmrv,))
        _logger.info("Actions states initialized")
        return True

    def _check_delete_state(self) -> None:
        # If completing in a lifecycle's deletion state, we need to delete the instance along with its statemachine
        if (self.state_machine.sm_type == StateMachineType.LIFECYCLE and
                self.state_machine.current_state in self.domain.lifecycle_deletion_states.get(
                    self.state_machine.state_model, set()
                )
        ):
            domdb = self.domain.alias
            # Find this State Activity's lifecycle state machine and delete it
            # We use the state machine id and class name to find it in the domain's dictionary of lifecycles
            sm_id = self.state_machine.lifecycle_sm_id
            class_name = self.state_machine.class_name
            inst_id = self.state_machine.instance_id
            # And we delete that entry
            del self.domain.lifecycles[class_name][sm_id]
            # Now we need to delete the instance from the dommain db
            Relvar.deleteone(db=domdb, relvar_name=class_name, tid=inst_id)
            # Finally, update the inst_id mapping for the class
            # We do this by restricting to our instance mapping and then subtracting it from the inst_mapping rv
            id_to_delete_drv = Relation.declare_rv(db=domdb, owner=self.owner_name, name='id_to_delete')
            inst_drv = self.domain.sm_instance_rvs[class_name]
            Relation.restrict(db=domdb, relation=inst_drv, restriction=f'_instance:<{sm_id}>',
                              svar_name=id_to_delete_drv)
            Relation.subtract(db=domdb, rname1=inst_drv, rname2=id_to_delete_drv, svar_name=inst_drv)

    def enable_xi_flow(self):
        """
        An executing instance (xi) is the instance progressing through a Lifecycle
        State Machine. We set the value of this Flow (F1) in that case.

        If this is a Multiple Assigner State Machine, there will be a partitioning
        instance (pi) as F1 instead.

        Otherwise, this must be a Single Assigner State Machine which is defined
        on an Association and there is no associated instance and no flow value to
        set.
        """
        domdb = self.state_machine.domain.alias

        if self.xi_flow_name:
            # This must be a Lifecycle State Machine
            class_name = self.state_machine.state_model
            instance_id = self.state_machine.instance_id
            xi_flow_value_rv = Relation.declare_rv(
                db=domdb, owner=self.owner_name, name="xi_flow_value"
            )
            # Convert identifier to a restriction phrase
            R = ", ".join(f"{k}:<{v}>" for k, v in instance_id.items())
            # Set a relation variable name for the xi flow value
            Relation.restrict(db=domdb, relation=class_name, restriction=R)
            id_attr_names = tuple(k for k in instance_id.keys())
            Relation.project(db=domdb, attributes=id_attr_names, svar_name=xi_flow_value_rv)

            # Set the xi flow value to a relation variable holding a single instance reference for the xi
            self.flows[self.xi_flow_name] = ActiveFlow(value=xi_flow_value_rv, flowtype=class_name)
            _logger.info(f"{self.xi_flow_name} set to executing instance")
            log_table(_logger, table_msg(db=domdb, variable_name=xi_flow_value_rv, table_name=self.owner_name))

        elif self.pi_flow_name:
            # This must be a Multiple Assigner State Machine
            pclass_name = self.state_machine.pclass_name
            pinstance_id = self.state_machine.instance_id
            pi_flow_value_rv = Relation.declare_rv(
                db=domdb, owner=self.owner_name, name="pi_flow_value"
            )
            # Convert identifier to a restriction phrase
            R = ", ".join(f"{k}:<{v}>" for k, v in pinstance_id.items())
            # Set a relation variable name for the pi flow value
            Relation.restrict(db=domdb, relation=pclass_name, restriction=R)
            id_attr_names = tuple(k for k in pinstance_id.keys())
            Relation.project(db=domdb, attributes=id_attr_names, svar_name=pi_flow_value_rv)

            # Set the xi flow value to a relation variable holding a single instance reference for the xi
            self.flows[self.pi_flow_name] = ActiveFlow(value=pi_flow_value_rv, flowtype=pclass_name)
            pass

        # Neither case executes if this is an Single Assigner