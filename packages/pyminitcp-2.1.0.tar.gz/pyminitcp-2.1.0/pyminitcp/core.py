import errno
import json
import os
import socket
import time
from dataclasses import dataclass, asdict
from typing import Optional
from contextlib import closing

__all__ = ["tcp_check", "udp_check", "CheckResult"]

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
BOLD = '\033[1m'
RESET = '\033[0m'


@dataclass
class CheckResult:
    """
    Result of TCP and UDP connectivity check.
    """
    status: int         # 1 for success, 0 for failure
    resp_time: float    # Response time in s, or 0 if failed
    error: str          # Error description or empty string if success
    family: object      # socket.AF_INET or socket.AF_INET6 (or None)
    sockaddr: object    # Tuple (ip, port) or None
    namelookup_time: float = 0.0
    connect_time: float = 0.0
    phase: Optional[str] = None
    errno_code: Optional[int] = None
    errno_name: Optional[str] = None
    os_error: Optional[str] = None
    banner: Optional[str] = None

    def as_dict(self):
        return asdict(self)

    def as_json(self, **kwargs) -> str:
        """
        Return a result as a JSON string.

        kwargs are passed to json.dumps(), for example:
            indent=2
            ensure_ascii=False
        """
        return json.dumps(self.as_dict(), **kwargs)

    @property
    def short_error(self) -> str:
        if self.phase and self.errno_name:
            return f"{self.phase}:{self.errno_name}"
        if self.phase:
            return self.phase
        return self.error or ""

    def __str__(self):
        status_str = f"{GREEN}Success{RESET}" if self.status else f"{RED}Failure{RESET}"
        error_str = f"{RED}{self.error}{RESET}" if self.error else f"{GREEN}-{RESET}"
        return (
            f"{BOLD}{CYAN}Status        :{RESET} {status_str}\n"
            f"{BOLD}{CYAN}Name lookup ms:{RESET} {YELLOW}{self.namelookup_time if self.status else 'N/A'}{RESET}\n"
            f"{BOLD}{CYAN}Connect ms    :{RESET} {YELLOW}{self.connect_time if self.status else 'N/A'}{RESET}\n"
            f"{BOLD}{CYAN}Response ms   :{RESET} {YELLOW}{self.resp_time if self.status else 'N/A'}{RESET}\n"
            f"{BOLD}{CYAN}Error         :{RESET} {error_str}\n"
            f"{BOLD}{CYAN}Family        :{RESET} {self.family}\n"
            f"{BOLD}{CYAN}Sockaddr      :{RESET} {self.sockaddr}\n"
        )


def format_socket_error(exc: Exception) -> str:
    """
    Returns a human-readable description of socket exceptions.
    """
    if isinstance(exc, socket.timeout):
        return "Connection timed out"
    if isinstance(exc, socket.gaierror):
        return f"Address-related error: {exc}"
    if isinstance(exc, socket.herror):
        return f"Host-related error: {exc}"
    if isinstance(exc, OSError):
        return f"OS/socket error: {exc}"
    return str(exc)


def build_error_info(e: Exception, phase: str) -> dict:
    info = {
        "phase": phase,
        "errno_code": None,
        "errno_name": None,
        "os_error": None,
        "error": format_socket_error(e),
    }

    if isinstance(e, socket.timeout):
        info["os_error"] = "Connection timed out"
        return info

    if isinstance(e, socket.gaierror):
        info["errno_code"] = getattr(e, "errno", None)
        info["os_error"] = str(e)
        return info

    if isinstance(e, socket.herror):
        info["errno_code"] = getattr(e, "errno", None)
        info["os_error"] = str(e)
        return info

    if isinstance(e, OSError):
        err_no = getattr(e, "errno", None)
        info["errno_code"] = err_no
        info["errno_name"] = errno.errorcode.get(err_no) if err_no is not None else None
        info["os_error"] = os.strerror(err_no) if err_no is not None else str(e)

        if info["errno_name"] and info["os_error"]:
            info["error"] = f"{info['errno_name']}: {info['os_error']}"
        elif info["os_error"]:
            info["error"] = info["os_error"]

    return info


def build_connect_ex_error_info(code: int, phase: str = "connect") -> dict:
    errno_name = errno.errorcode.get(code)
    os_error = os.strerror(code) if code else ""

    error = os_error or "Connection failed"
    if errno_name and os_error:
        error = f"{errno_name}: {os_error}"

    return {
        "phase": phase,
        "errno_code": code,
        "errno_name": errno_name,
        "os_error": os_error,
        "error": error,
    }


def tcp_check(host: str, port: int, timeout: float = 10, require_banner: bool = False,
              banner: bool = False, read_bytes: int = 1024, request_data: bytes = None) -> CheckResult:
    """
    Perform a TCP connectivity check for an IPv4/IPv6 address or domain.
    Args:
        host (str): Hostname or IP address.
        port (int): TCP port to check.
        timeout (int, optional): Timeout in seconds. Defaults to 3.
        banner (bool, optional): Whether to read the server banner. Defaults to False.
        require_banner (bool, optional): Whether to fail if the banner read fails. Defaults to False.
        read_bytes (int, optional): Number of bytes to read from the server. Defaults to 1024.
        request_data (bytes, optional): Data to send to the server. Defaults to None.

    Returns:
        CheckResult: The result of the check.
    """
    port = int(port)
    last_error = None
    start = time.time()

    try:
        infos = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
        dns_time = time.time() - start
    except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
        err = build_error_info(e, phase="resolve")
        return CheckResult(
            0, 0, err["error"], None, None,
            phase=err["phase"],
            errno_code=err["errno_code"],
            errno_name=err["errno_name"],
            os_error=err["os_error"],
        )

    for family, socktype, proto, canonname, sockaddr in infos:
        try:
            with closing(socket.socket(family, socket.SOCK_STREAM, proto)) as sock:
                sock.settimeout(timeout)
                conn_start = time.time()
                res = sock.connect_ex(sockaddr)
                conn_time = time.time() - conn_start
                elapsed = time.time() - start

                if res == 0:
                    banner_data = None

                    if request_data:
                        try:
                            sock.sendall(request_data)
                        except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
                            if isinstance(e, socket.timeout):
                                err["error"] = "Timed out waiting for banner"
                                err["os_error"] = "Timed out waiting for banner"
                            err = build_error_info(e, phase="send")
                            return CheckResult(
                                7,
                                elapsed,
                                err["error"],
                                family,
                                sockaddr,
                                dns_time,
                                conn_time,
                                phase=err["phase"],
                                errno_code=err["errno_code"],
                                errno_name=err["errno_name"],
                                os_error=err["os_error"],
                            )

                    if banner:
                        try:
                            data = sock.recv(read_bytes)
                            banner_data = data.decode(errors="ignore").strip()
                        except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
                            if require_banner:
                                err = build_error_info(e, phase="recv")
                                if isinstance(e, socket.timeout):
                                    err["error"] = "Timed out waiting for banner"
                                    err["os_error"] = "Timed out waiting for banner"
                                return CheckResult(
                                    7,
                                    elapsed,
                                    err["error"],
                                    family,
                                    sockaddr,
                                    dns_time,
                                    conn_time,
                                    phase=err["phase"],
                                    errno_code=err["errno_code"],
                                    errno_name=err["errno_name"],
                                    os_error=err["os_error"],
                                )

                    return CheckResult(
                        1,
                        elapsed,
                        '',
                        family,
                        sockaddr,
                        dns_time,
                        conn_time,
                        banner=banner_data
                    )
                else:
                    last_error = build_connect_ex_error_info(res, phase="connect")
        except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
            last_error = build_error_info(e, phase="connect")
            continue

    return CheckResult(
        0, 0,
        last_error["error"] if last_error else "Connection failed",
        None, None,
        phase=last_error["phase"] if last_error else None,
        errno_code=last_error["errno_code"] if last_error else None,
        errno_name=last_error["errno_name"] if last_error else None,
        os_error=last_error["os_error"] if last_error else None,
    )


def udp_check(host: str, port: int, timeout: float = 10, payload: bytes = b'', hex_payload: str = None) -> CheckResult:
    """
    Perform a UDP connectivity check for an IPv4/IPv6 address or domain.

    Args:
        host (str): Hostname or IP address.
        port (int): UDP port to check.
        timeout (int, optional): Timeout in seconds. Defaults to 3.
        payload (bytes, optional): Payload to send. Defaults to b"".
        hex_payload (str, optional): Hex payload to send. Defaults to b"".

    Returns:
        CheckResult: The result of the check.
    """
    port = int(port)

    if hex_payload:
        try:
            payload = bytes.fromhex(hex_payload)
        except ValueError:
            return CheckResult(0, 0, "Invalid hex payload", None, None, phase="send")

    try:
        start_dns = time.time()
        infos = socket.getaddrinfo(host, port, 0, socket.SOCK_DGRAM)
        dns_time = (time.time() - start_dns)
    except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
        err = build_error_info(e, phase="resolve")
        return CheckResult(
            0, 0, err["error"], None, None,
            phase=err["phase"],
            errno_code=err["errno_code"],
            errno_name=err["errno_name"],
            os_error=err["os_error"],
        )

    for family, socktype, proto, canonname, sockaddr in infos:
        try:
            with closing(socket.socket(family, socket.SOCK_DGRAM, proto)) as sock:
                sock.settimeout(timeout)
                start = time.time()

                try:
                    sock.sendto(payload, sockaddr)
                except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
                    err = build_error_info(e, phase="send")
                    return CheckResult(
                        0, 0, err["error"], None, None,
                        phase=err["phase"],
                        errno_code=err["errno_code"],
                        errno_name=err["errno_name"],
                        os_error=err["os_error"],
                    )

                try:
                    sock.recvfrom(1024)
                except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
                    err = build_error_info(e, phase="recv")
                    return CheckResult(
                        0, 0, err["error"], None, None,
                        phase=err["phase"],
                        errno_code=err["errno_code"],
                        errno_name=err["errno_name"],
                        os_error=err["os_error"],
                    )

                elapsed = (time.time() - start)
                return CheckResult(1, elapsed, '', family, sockaddr, dns_time)
        except (socket.gaierror, socket.herror, socket.timeout, OSError) as e:
            err = build_error_info(e, phase="send")
            return CheckResult(
                0, 0, err["error"], None, None,
                phase=err["phase"],
                errno_code=err["errno_code"],
                errno_name=err["errno_name"],
                os_error=err["os_error"],
            )

    return CheckResult(0, 0, "UDP check failed", None, None)
