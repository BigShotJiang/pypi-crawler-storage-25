import argparse

from pyminitcp import tcp_check, udp_check


def main():
    parser = argparse.ArgumentParser(
        description="Simple TCP/UDP connectivity checker (IPv4/IPv6/domain)"
    )
    parser.add_argument("host", help="Host to check (IP or domain)")
    parser.add_argument("port", type=int, help="TCP port number to check")
    parser.add_argument("-t", "--timeout", type=int, default=3, help="Timeout in seconds (default: 3)")
    parser.add_argument("--tcp", action="store_true", default=True, help="Do TCP check. By default")
    parser.add_argument("--udp", action="store_true", default='', help="Do UDP check")
    parser.add_argument("-p", "--payload", type=str, default=b'', help="Payload to send in UDP check")
    parser.add_argument("--hex-payload", type=str, default=None, help="Hex payload to send in UDP check")
    parser.add_argument("--banner", action="store_true", help="Get and show server banner (default: False)")
    parser.add_argument("--require-banner", action="store_true", help="Fail if banner read fails (default: False)")
    parser.add_argument("--send-data", help="Send text data before reading banner")
    parser.add_argument("--read-bytes", type=int, default=1024, help="How many bytes to read")
    parser.add_argument("--send-hex", help="Send hex data before reading banner")
    parser.add_argument("-j", "--json", action="store_true", help="Output in JSON format")
    args = parser.parse_args()

    if args.udp:
        result = udp_check(args.host, args.port, args.timeout, args.payload, args.hex_payload)
    else:
        request_data = None

        if args.send_hex:
            try:
                request_data = bytes.fromhex(args.send_hex)
            except ValueError:
                print("Invalid hex data for --send-hex")
                raise SystemExit(1)
        elif args.send_data:
            request_data = args.send_data.encode()
        result = tcp_check(args.host, args.port, args.timeout, args.require_banner, args.banner, args.read_bytes, request_data)

    if args.json:
        print(result.as_json(indent=2))
    else:
        print(result)


if __name__ == "__main__":
    main()
