"""JoinMiner — placeholder release. Full implementation coming soon."""

__version__ = "0.0.1"
