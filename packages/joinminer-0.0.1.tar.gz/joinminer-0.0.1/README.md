# JoinMiner

**Graph-based tabular data mining.**

> ⚠️ **Placeholder release.** This package name is reserved on PyPI for the upcoming
> JoinMiner framework. The full implementation is still under active development
> and will be published in a future release.

## About

JoinMiner is a framework for large-scale tabular data mining by representing
tables as a graph and learning from it.

The first functional release is coming soon. Stay tuned.

## Installation

```bash
pip install joinminer
```

## License

MIT
