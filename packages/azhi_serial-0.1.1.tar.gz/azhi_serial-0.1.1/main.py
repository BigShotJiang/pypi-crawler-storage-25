import comtool
def main():
    print("Hello from azhi-serial!")
    print("=" * 50)
    comtool.main()


if __name__ == "__main__":
    main()
