# -------------------------- 工具类：校验和 helper --------------------------
class ChecksumHelper:
    @staticmethod
    def modbus_crc16(data: bytes) -> int:
        crc = 0xFFFF
        for b in data:
            crc ^= b
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc

    @staticmethod
    def checksum8(data: bytes) -> int:
        return sum(data) & 0xFF

    @staticmethod
    def apply_checksum(tx_buf: bytes, mode: str) -> bytes:
        """
        根据模式追加校验和
        mode: 'n' (无), 's' (Checksum8 + 0x16), 'm' (Modbus CRC16)
        """
        if mode == 's':
            cs = ChecksumHelper.checksum8(tx_buf)
            return tx_buf + bytes([cs, 0x16])
        elif mode == 'm':
            crc = ChecksumHelper.modbus_crc16(tx_buf)
            low = crc & 0xFF
            high = (crc >> 8) & 0xFF
            return tx_buf + bytes([low, high])
        else:
            return tx_buf