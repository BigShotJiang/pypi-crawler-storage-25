# -------------------------- UI 类：控制台交互 --------------------------
import threading
import sys
import time
from util.Color import cprint, Color
from util.ChecksumHelper import ChecksumHelper
from util.SerialManager import SerialManager
from util.LocalSender import LoopSender


class ConsoleUI:
    def __init__(self, serial_mgr: SerialManager, loop_sender: LoopSender, hex_mode: bool, checksum_mode: str):
        self.serial_mgr = serial_mgr
        self.loop_sender = loop_sender
        self.hex_mode = hex_mode
        self.checksum_mode = checksum_mode.lower()
        self.console_lock = threading.Lock()

    def start_recv_thread(self):
        t = threading.Thread(target=self._recv_loop, daemon=True)
        t.start()

    def _recv_loop(self):
        while self.serial_mgr.is_open:
            try:
                data = self.serial_mgr.read(1024)
                if not data:
                    continue
                
                with self.console_lock:
                    # sys.stdout.write('\r\033[K')  # 清除当前行
                    
                    if self.hex_mode:
                        msg = f"[RX HEX] {self._bytes2hex(data)}"
                    else:
                        try:
                            msg = f"[RX TXT] {data.decode('utf-8')}"
                        except UnicodeDecodeError:
                            msg = f"[RX HEX] {self._bytes2hex(data)}"
                    
                    # RX 均为绿色
                    sys.stdout.write(f"{Color.GREEN}{msg}{Color.RESET}\n")
                    # sys.stdout.write(">> ")
                    sys.stdout.flush()
            except Exception:
                break

    def run_interactive_loop(self):
        try:
            while True:
                try:
                    time.sleep(self.serial_mgr.timeout+0.2) # 避免CPU双线程竞争，input()会阻塞线程，自带\r,清除打印行
                    user_text = input(">> ")
                except EOFError:
                    break
                
                if not user_text.strip():
                    continue

                # 命令处理
                if user_text.strip().lower() == 'loop':
                    if self.loop_sender.loop_flag:
                        self.loop_sender.stop_loop()
                    else:
                        self.loop_sender.start_loop()
                    continue

                # 数据发送处理
                self._handle_send(user_text)

        except KeyboardInterrupt:
            pass

    def _handle_send(self, user_text: str):
        try:
            if self.hex_mode:
                tx_buf = bytes.fromhex(user_text.strip().replace(" ", ""))
            else:
                tx_buf = user_text.encode("utf-8")
        except Exception as e:
            # 错误为红色
            cprint(f"[错误] 输入格式无效: {e}", Color.RED)
            return

        # 应用校验
        final_buf = ChecksumHelper.apply_checksum(tx_buf, self.checksum_mode)
        
        # 打印校验信息（Info 为绿色）
        if self.checksum_mode == 's':
            cs = ChecksumHelper.checksum8(tx_buf)
            cprint(f"[Info] 自动追加 Checksum8: {cs:02X} 16", Color.GREEN)
        elif self.checksum_mode == 'm':
            crc = ChecksumHelper.modbus_crc16(tx_buf)
            cprint(f"[Info] 自动追加 Modbus CRC16: {crc & 0xFF:02X} {(crc >> 8) & 0xFF:02X}", Color.GREEN)

        # 发送
        try:
            self.serial_mgr.write(final_buf)
            with self.console_lock:
                # TX 为蓝色
                cprint(f"[TX] {self._bytes2hex(final_buf)}", Color.BLUE)
            
            self.loop_sender.update_last_data(final_buf)
        except Exception as e:
            # 发送错误为红色
            cprint(f"[发送错误] {e}", Color.RED)

    @staticmethod
    def _bytes2hex(data: bytes) -> str:
        return " ".join(f"{b:02X}" for b in data)