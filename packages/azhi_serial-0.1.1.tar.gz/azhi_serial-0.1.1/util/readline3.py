"""
交互式命令行shell,支持历史记录和Tab补全。
只依赖pyreadline3库，适用于Python 3.x版本。
"""
import readline

def callable():
    while True:
        cmd = input(">>")
        if cmd.lower() in ["q", "exit"]:
            break
        print(f"执行：{cmd}")
def run_interactive_shell(callable, history_file=".his.txt", history_length=500):
    """
    运行一个交互式命令行 shell，支持历史记录和 Tab 补全。
    
    Args:
        history_file (str): 历史记录文件路径。
        history_length (int): 最大历史记录条数。
    """
    readline.parse_and_bind("tab: history-search-backward")
    readline.set_history_length(history_length)

    try:
        readline.read_history_file(history_file)
        callable()
    except FileNotFoundError:
        pass
    except KeyboardInterrupt:
        print("\n用户已手动中断程序运行。")
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        readline.write_history_file(history_file)

if __name__ == "__main__":
    run_interactive_shell(callable)
