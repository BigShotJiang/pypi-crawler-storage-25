# -------------------------- 颜色与工具类 --------------------------
class Color:
    """ANSI 颜色代码"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def cprint(text: str, color: str = Color.RESET):
    """彩色打印辅助函数"""
    print(f"{color}{text}{Color.RESET}")