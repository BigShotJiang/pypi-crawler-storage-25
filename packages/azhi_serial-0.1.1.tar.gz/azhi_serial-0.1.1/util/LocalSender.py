# -------------------------- 业务类：循环发送 --------------------------
import threading
import time
from typing import Optional
from util.Color import cprint, Color
from util.SerialManager import SerialManager
class LoopSender:
    def __init__(self, serial_mgr: SerialManager, loop_period: float = 3.0):
        self.serial_mgr = serial_mgr
        self.loop_period = loop_period
        self.loop_flag = False
        self.last_tx_data = b""
        self.thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def start_loop(self):
        with self._lock:
            if not self.last_tx_data:
                cprint("[警告] 暂无发送记录，无法开启循环发送", Color.RED)
                return
            if self.loop_flag:
                cprint("[提示] 循环发送已在运行中", Color.GREEN)
                return
            
            self.loop_flag = True
            self.thread = threading.Thread(target=self._worker, daemon=True)
            self.thread.start()
            cprint(f"[状态] 已开启{self.loop_period}秒循环发送", Color.GREEN)

    def stop_loop(self):
        with self._lock:
            if self.loop_flag:
                self.loop_flag = False
                if self.thread:
                    self.thread.join(timeout=1)
                cprint("[状态] 已停止循环发送", Color.GREEN)
            else:
                cprint("[提示] 循环发送未运行", Color.GREEN)

    def _worker(self):
        while True:
            with self._lock:
                if not self.loop_flag or not self.serial_mgr.is_open:
                    break
                data_to_send = self.last_tx_data
            
            if data_to_send:
                try:
                    self.serial_mgr.write(data_to_send)
                    # TX 均为蓝色
                    cprint(f"\n[循环TX] {self._bytes2hex(data_to_send)}", Color.BLUE)
                except Exception:
                    break
            time.sleep(self.loop_period)

    def update_last_data(self, data: bytes):
        with self._lock:
            self.last_tx_data = data

    @staticmethod
    def _bytes2hex(data: bytes) -> str:
        return " ".join(f"{b:02X}" for b in data)