# -------------------------- 工具类：串口管理 --------------------------
import serial
import serial.tools.list_ports
from typing import Optional
from util.Color import cprint, Color
class SerialManager:
    def __init__(self, port: Optional[str], baudrate: int, parity: str, timeout: float = 0.5):
        self.port = port
        self.baudrate = baudrate
        self.parity = parity
        self.timeout = timeout
        self.ser: Optional[serial.Serial] = None

    def auto_detect_port(self) -> str:
        """自动检测端口，如果只有一个则直接使用"""
        ports = list(serial.tools.list_ports.comports())
        if not ports:
            raise Exception("未检测到任何可用串口")
        
        if len(ports) == 1:
            detected_port = ports[0].device
            cprint(f"[自动检测] 发现唯一串口: {detected_port} ({ports[0].description})", Color.GREEN)
            return detected_port
        
        # 多个端口时，列出并建议用户指定，默认返回第一个
        cprint("[警告] 检测到多个串口:", Color.GREEN)
        for p in ports:
            print(f"  - {p.device}: {p.description}")
        default_port = ports[0].device
        cprint(f"[提示] 未指定端口，默认使用: {default_port}", Color.GREEN)
        return default_port

    def open(self):
        if not self.port:
            self.port = self.auto_detect_port()

        parity_map = {
            "N": serial.PARITY_NONE,
            "E": serial.PARITY_EVEN,
            "O": serial.PARITY_ODD,
        }
        
        try:
            self.ser = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                parity=parity_map.get(self.parity, serial.PARITY_NONE),
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=self.timeout
            )
            cprint(f"[成功] 串口已打开: {self.port} @ {self.baudrate}，校验位: {self.parity}", Color.GREEN)
        except Exception as e:
            raise Exception(f"串口打开失败: {e}")

    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()
            cprint("[信息] 串口已关闭", Color.GREEN)

    def write(self, data: bytes):
        if self.ser and self.ser.is_open:
            self.ser.write(data)
        else:
            raise Exception("串口未打开")

    def read(self, size: int = 1024) -> bytes:
        if self.ser and self.ser.is_open:
            return self.ser.read(size)
        return b""

    @property
    def is_open(self):
        return self.ser.is_open if self.ser else False