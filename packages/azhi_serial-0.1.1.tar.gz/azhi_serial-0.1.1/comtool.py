"""
串口调试工具
只依赖pyserial，支持自动检测串口、循环发送、HEX模式和校验功能
"""

import argparse
import sys
import util.readline3 as readline3
from util.SerialManager import SerialManager
from util.LocalSender import LoopSender
from util.ConsoleUI import ConsoleUI
from util.Color import cprint, Color
# -------------------------- 主程序入口 --------------------------
def main():
    parser = argparse.ArgumentParser(description="串口调试助手 - 优雅的串口调试工具，支持自动检测、循环发送、HEX模式和校验功能")
    parser.add_argument("-P", "--port", type=str, default=None, help="串口名称 (默认自动检测)")
    parser.add_argument("-b", "--baud", type=int, default=9600, help="波特率")
    parser.add_argument("-p", "--parity", choices=["N", "E", "O"], default="N", help="校验位")
    parser.add_argument("--hex", action="store_true", help="HEX模式")
    parser.add_argument("-c", "--choice", type=str, default="n", choices=["n", "s", "m"], 
                        help="校验方式: n=无, s=Checksum8, m=CRC16")
    parser.add_argument("--loop-period", type=float, default=3.0, help="循环发送间隔时间(秒)")
    parser.add_argument("-t", "--timeout", type=float, default=0.5, help="串口读取超时时间(秒)")
    
    args = parser.parse_args()

    # 1. 初始化串口管理器
    serial_mgr = SerialManager(args.port, args.baud, args.parity, timeout=args.timeout)
    try:
        serial_mgr.open()
    except Exception as e:
        # 启动失败为红色
        cprint(str(e), Color.RED)
        sys.exit(1)

    # 2. 初始化循环发送器
    loop_sender = LoopSender(serial_mgr, loop_period=args.loop_period)

    # 3. 初始化 UI 并启动
    ui = ConsoleUI(serial_mgr, loop_sender, args.hex, args.choice)
    
    print("=" * 50)
    cprint(f"端口: {serial_mgr.port} | 波特: {args.baud} | HEX: {args.hex}", Color.BOLD)
    cprint(f"校验: {args.choice} (n:无, s:CS8+0x16, m:CRC16)", Color.BOLD)
    cprint(f"循环间隔: {args.loop_period}s | 超时: {args.timeout}s", Color.BOLD)
    print("命令: 'loop' 启停循环发送 | Ctrl+C 退出")
    print("=" * 50)

    ui.start_recv_thread()
    # ui.run_interactive_loop() # 启动交互(单机版)

    readline3.run_interactive_shell(ui.run_interactive_loop) # 启动交互(使用 readline3)
    # 清理资源
    loop_sender.stop_loop()
    serial_mgr.close()
    cprint("\n程序已退出", Color.GREEN)

if __name__ == "__main__":
    main()