"C:\Users\azhi_\AppData\Roaming\uv\uv.toml"
```bash
[[index]]
url = "https://pypi.tuna.tsinghua.edu.cn/simple"
default = true
```
```bash
uv init
uv add pyserial
uv add readline3
uv run python main.py #直接运行虚拟环境
```
```bash
uv venv
uv sync
uv build
pip install .\dist\azhi_serial-0.1.0-py3-none-any.whl
azhi-serial --help
uv publish
```
```bash
pyinstaller -F -i "E:\ziyuan\banner\z_1997.ico" main.py
```
激活虚拟环境
```bash
(Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned) ; (& e:\ziyuan\tools\uart\azhi_serial\.venv\Scripts\Activate.ps1)
deactivate
```