from dsi_internal_python_utils.core.logger import setup_logger
import logging

devmode = False

if devmode:
    logger = setup_logger("test-logger", level=logging.DEBUG)
else:
    logger = setup_logger("test-logger", level=logging.INFO)

logger.debug("Debug message")
logger.info("Info message")