# dsi-internal-python-utils

Librairie python d'utilitaires web et autres pour les projets internes de DSI