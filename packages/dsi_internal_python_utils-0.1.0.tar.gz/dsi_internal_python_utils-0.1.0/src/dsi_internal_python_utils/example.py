def add_one(number):
    """Adds one to the given number."""
    return number + 1