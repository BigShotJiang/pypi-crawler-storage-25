"""Middleware FastAPI d'authentification Keycloak — vérifie le JWT via les clés JWKS du realm et injecte la payload du token dans ``request.state.keycloak_claims``."""

from typing import List, Optional

import httpx
import jwt as pyjwt
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware


# Cache JWKS en mémoire
_jwks_cache: Optional[dict] = None


async def _get_jwks(server_url: str, realm: str) -> dict:
    global _jwks_cache
    if _jwks_cache:
        return _jwks_cache
    url = f"{server_url}/realms/{realm}/protocol/openid-connect/certs"
    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        resp.raise_for_status()
        _jwks_cache = resp.json()
    return _jwks_cache


def _decode_token(token: str, jwks: dict) -> Optional[dict]:
    try:
        header = pyjwt.get_unverified_header(token)
        kid = header.get("kid")
        key_data = next((k for k in jwks.get("keys", []) if k.get("kid") == kid), None)
        if not key_data:
            return None
        public_key = pyjwt.PyJWK.from_dict(key_data).key
        return pyjwt.decode(token, public_key, algorithms=["RS256"], options={"verify_aud": False})
    except Exception:
        return None


class KeycloakAuthMiddleware(BaseHTTPMiddleware):
    """Middleware FastAPI qui protège les routes via un token JWT Keycloak.

    Vérifie le token Bearer présent dans le header ``Authorization`` à l'aide
    des clés publiques JWKS du realm Keycloak, puis injecte la payload
    complète du token dans ``request.state.keycloak_claims``.

    Args:
        app: Application ou routeur FastAPI.
        server_url: URL du serveur Keycloak (ex: ``http://keycloak:8080``).
        realm: Nom du realm Keycloak.
        excluded_paths: Préfixes de chemins exclus de l'authentification.

    Example::

        from fastapi import FastAPI, Request
        from dsi_internal_python_utils.keycloak import KeycloakAuthMiddleware

        app = FastAPI()
        app.add_middleware(
            KeycloakAuthMiddleware,
            server_url="http://keycloak:8080",
            realm="mon-realm",
            excluded_paths=["/health"],
        )

        @app.get("/me")
        async def me(request: Request):
            claims = request.state.keycloak_claims
            return {"sub": claims["sub"], "email": claims.get("email")}
    """

    def __init__(
        self,
        app,
        server_url: str,
        realm: str,
        excluded_paths: Optional[List[str]] = None,
    ):
        super().__init__(app)
        self.server_url = server_url
        self.realm = realm
        self.excluded_paths = excluded_paths or []

    async def dispatch(self, request: Request, call_next):
        if any(request.url.path.startswith(p) for p in self.excluded_paths):
            return await call_next(request)

        auth = request.headers.get("Authorization")
        if not auth or not auth.startswith("Bearer "):
            return JSONResponse(status_code=401, content={"detail": "Token manquant"})

        token = auth.split(" ", 1)[1]
        try:
            jwks = await _get_jwks(self.server_url, self.realm)
        except Exception:
            return JSONResponse(status_code=401, content={"detail": "Impossible de récupérer les clés Keycloak"})

        claims = _decode_token(token, jwks)
        if not claims:
            return JSONResponse(status_code=401, content={"detail": "Token invalide"})

        request.state.keycloak_claims = claims
        return await call_next(request)
