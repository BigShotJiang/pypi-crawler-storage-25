# Module `keycloak`

Authentification JWT Keycloak pour FastAPI — middleware de protection des routes et utilitaire d'administration des attributs utilisateur.

**Librairies de base** : `PyJWT`, `httpx`, `python-keycloak`.

---

## Scope

Ce module fournit :

1. **`KeycloakAuthMiddleware`** : un middleware Starlette/FastAPI qui vérifie le token Bearer JWT via les clés JWKS du realm Keycloak et injecte la payload complète du token dans `request.state.keycloak_claims`.
2. **`update_user_attributes`** : fonction d'administration pour mettre à jour les attributs d'un utilisateur dans Keycloak.

---

## Fonctions & Classes

### `KeycloakAuthMiddleware`

Middleware FastAPI qui protège les routes via JWT Keycloak.

| Paramètre | Type | Défaut | Description |
|-----------|------|--------|-------------|
| `app` | — | — | Application ou routeur FastAPI |
| `server_url` | `str` | — | URL du serveur Keycloak |
| `realm` | `str` | — | Nom du realm |
| `excluded_paths` | `list[str] \| None` | `None` | Préfixes de chemins exclus de l'authentification |

**Effet** : injecte `request.state.keycloak_claims` (`dict`) contenant la payload complète du token JWT pour chaque requête authentifiée.

```python
from fastapi import FastAPI, Request
from dsi_internal_python_utils.keycloak import KeycloakAuthMiddleware

app = FastAPI()
app.add_middleware(
    KeycloakAuthMiddleware,
    server_url="http://keycloak:8080",
    realm="mon-realm",
    excluded_paths=["/health"],
)

@app.get("/me")
async def me(request: Request):
    claims = request.state.keycloak_claims
    return {"sub": claims["sub"], "email": claims.get("email")}
```

### `update_user_attributes`

Met à jour les attributs d'un utilisateur dans Keycloak via `python-keycloak`.

| Paramètre | Type | Description |
|-----------|------|-------------|
| `server_url` | `str` | URL du serveur Keycloak |
| `realm` | `str` | Nom du realm |
| `client_id` | `str` | Client ID admin (ex: `admin-cli`) |
| `client_secret` | `str` | Client secret admin |
| `user_id` | `str` | Identifiant Keycloak de l'utilisateur (`sub`) |
| `attributes` | `dict` | Dictionnaire des attributs à définir |

**Retour** : Réponse HTTP de Keycloak (`dict`).

```python
from dsi_internal_python_utils.keycloak import update_user_attributes

update_user_attributes(
    server_url="http://keycloak:8080",
    realm="mon-realm",
    client_id="admin-cli",
    client_secret="secret",
    user_id="user-uuid",
    attributes={"role_app": "admin", "department": "DSI"},
)
```

---

## Guide d'implémentation : authentification Keycloak + FastAPI

### 1. Configuration de Keycloak

Depuis l'interface d'administration de Keycloak, dans votre realm :

1. **Client Scopes → profile** : vérifiez que les mappers suivants sont présents et activés :
   - `given_name` → champ **Prénom** (User Attribute: `firstName`, Token Claim Name: `given_name`)
   - `family_name` → champ **Nom** (User Attribute: `lastName`, Token Claim Name: `family_name`)
   - `email` → champ **Email** (User Attribute: `email`, Token Claim Name: `email`)

2. **Ajout d'attributs customs dans le token** : pour chaque attribut (ex: `role_app`) :
   - Allez dans **Client Scopes → votre scope** (ou créez-en un)
   - **Add mapper → By configuration → User Attribute**
   - Remplissez : Name = `role_app`, User Attribute = `role_app`, Token Claim Name = `role_app`, Claim JSON Type = `String`
   - Cochez **Add to ID token** et **Add to access token**

3. **Identity Provider** : configurez Microsoft comme broker (Identity Providers → Add provider → Microsoft) avec les bons `client_id` / `client_secret` Azure AD. Activez le first login flow pour créer automatiquement les utilisateurs.

4. **Client pour votre application** : créez un client OpenID Connect avec les bons redirect URIs et activez les scopes contenant vos mappers customs.

### 2. Microservice protégé (service métier)

```python
from fastapi import FastAPI, Request
from dsi_internal_python_utils.keycloak import KeycloakAuthMiddleware

app = FastAPI()

app.add_middleware(
    KeycloakAuthMiddleware,
    server_url="http://keycloak:8080",
    realm="mon-realm",
    excluded_paths=["/health"],
)

@app.get("/dashboard")
async def dashboard(request: Request):
    claims = request.state.keycloak_claims
    role = claims.get("role_app", "viewer")
    return {"message": f"Bienvenue {claims.get('given_name')}", "role": role}
```

### 3. Service de gestion des utilisateurs

Ce service fait le lien entre Keycloak et la base de données métier. Il utilise le middleware pour récupérer l'identité de l'utilisateur, et `update_user_attributes` pour synchroniser les attributs.

```python
from fastapi import FastAPI, Request, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from dsi_internal_python_utils.keycloak import KeycloakAuthMiddleware, update_user_attributes
from dsi_internal_python_utils.db import Database

app = FastAPI()
db = Database()

app.add_middleware(
    KeycloakAuthMiddleware,
    server_url="http://keycloak:8080",
    realm="mon-realm",
)

@app.post("/users/register")
async def register(request: Request, session: AsyncSession = Depends(db.get_db)):
    claims = request.state.keycloak_claims

    db_user = UserModel(
        keycloak_id=claims["sub"],
        first_name=claims.get("given_name", ""),
        last_name=claims.get("family_name", ""),
        email=claims.get("email", ""),
        role="viewer",
    )
    session.add(db_user)
    await session.flush()

    update_user_attributes(
        server_url="http://keycloak:8080",
        realm="mon-realm",
        client_id="admin-cli",
        client_secret="admin-secret",
        user_id=claims["sub"],
        attributes={"role_app": "viewer"},
    )
    return {"status": "ok"}

@app.put("/users/{user_id}/role")
async def update_role(
    user_id: str,
    role: str,
    session: AsyncSession = Depends(db.get_db),
):
    # Mettre à jour le rôle en base
    # ...

    update_user_attributes(
        server_url="http://keycloak:8080",
        realm="mon-realm",
        client_id="admin-cli",
        client_secret="admin-secret",
        user_id=user_id,
        attributes={"role_app": role},
    )
    return {"status": "ok"}
```

### Avantages de cette architecture

- **Découplage** : les services métier n'ont pas besoin d'appeler le service utilisateur pour connaître le rôle — il est directement dans le token JWT.
- **Performance** : pas de requête HTTP supplémentaire ni de lecture en base pour l'autorisation — tout est dans le token.
- **Simplicité** : une ligne `add_middleware(...)` suffit pour protéger un microservice entier.
- **Flexibilité** : l'intégralité de la payload JWT est disponible dans `request.state.keycloak_claims`, sans présupposer quels champs sont nécessaires.
