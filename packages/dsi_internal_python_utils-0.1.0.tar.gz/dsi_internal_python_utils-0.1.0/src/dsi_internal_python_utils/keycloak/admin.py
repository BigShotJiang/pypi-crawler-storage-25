"""Utilitaire d'administration Keycloak — wrapper autour de python-keycloak pour la mise à jour d'attributs utilisateur."""

from keycloak import KeycloakAdmin


def update_user_attributes(
    server_url: str,
    realm: str,
    client_id: str,
    client_secret: str,
    user_id: str,
    attributes: dict,
) -> dict:
    """Met à jour les attributs d'un utilisateur dans Keycloak.

    Utilise la librairie ``python-keycloak`` et sa méthode
    ``KeycloakAdmin.update_user()`` pour modifier les attributs d'un
    utilisateur identifié par son id Keycloak.

    Args:
        server_url: URL du serveur Keycloak (ex: ``http://keycloak:8080``).
        realm: Nom du realm.
        client_id: Client ID du compte admin (ex: ``admin-cli``).
        client_secret: Client secret du compte admin.
        user_id: Identifiant Keycloak de l'utilisateur (``sub``).
        attributes: Dictionnaire des attributs à définir ou mettre à jour.

    Returns:
        Réponse HTTP de Keycloak.

    Example::

        from dsi_internal_python_utils.keycloak import update_user_attributes

        update_user_attributes(
            server_url="http://keycloak:8080",
            realm="mon-realm",
            client_id="admin-cli",
            client_secret="secret",
            user_id="user-uuid",
            attributes={"role_app": "admin", "department": "DSI"},
        )
    """
    admin = KeycloakAdmin(
        server_url=server_url,
        realm_name=realm,
        client_id=client_id,
        client_secret_key=client_secret,
        verify=True,
    )
    return admin.update_user(user_id=user_id, payload={"attributes": attributes})
