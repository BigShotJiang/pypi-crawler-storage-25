"""Client de connexion async à PostgreSQL — basé sur SQLAlchemy 2.x + asyncpg."""

import os
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine


def build_database_url(
    host: Optional[str] = None,
    port: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    name: Optional[str] = None,
) -> str:
    """Construit l'URL de connexion PostgreSQL async à partir de paramètres ou de variables d'environnement.

    Se base sur les variables ``DB_HOST``, ``DB_PORT``, ``DB_USER``,
    ``DB_PASSWORD`` et ``DB_NAME``. Chaque paramètre explicite prend
    le dessus sur la variable d'environnement correspondante.

    Args:
        host: Hôte de la base (défaut : ``DB_HOST`` ou ``localhost``).
        port: Port (défaut : ``DB_PORT`` ou ``5432``).
        user: Utilisateur (défaut : ``DB_USER`` ou ``postgres``).
        password: Mot de passe (défaut : ``DB_PASSWORD`` ou ``postgres``).
        name: Nom de la base (défaut : ``DB_NAME`` ou ``postgres``).

    Returns:
        URL au format ``postgresql+asyncpg://…``.

    Example::

        from dsi_internal_python_utils.db import build_database_url

        url = build_database_url(host="db", name="mydb")
    """
    h = host or os.getenv("DB_HOST", "localhost")
    p = port or os.getenv("DB_PORT", "5432")
    u = user or os.getenv("DB_USER", "postgres")
    pw = password or os.getenv("DB_PASSWORD", "postgres")
    n = name or os.getenv("DB_NAME", "postgres")
    return f"postgresql+asyncpg://{u}:{pw}@{h}:{p}/{n}"


class Database:
    """Client async PostgreSQL réutilisable pour FastAPI.

    Encapsule un ``AsyncEngine`` et une ``async_sessionmaker`` SQLAlchemy.
    Fournit un context manager ``session()`` et une dépendance FastAPI ``get_db()``.

    Args:
        database_url: URL de connexion. Si ``None``, construite automatiquement
            via ``build_database_url()``.
        engine_options: Options supplémentaires passées à ``create_async_engine``.
        session_options: Options supplémentaires passées à ``async_sessionmaker``.

    Example::

        from dsi_internal_python_utils.db import Database

        db = Database()  # utilise les variables d'environnement

        # Dans une route FastAPI :
        @app.get("/items")
        async def get_items(session: AsyncSession = Depends(db.get_db)):
            ...
    """

    def __init__(
        self,
        database_url: Optional[str] = None,
        engine_options: Optional[dict] = None,
        session_options: Optional[dict] = None,
    ):
        url = database_url or build_database_url()
        self.engine = create_async_engine(url, **{
            "echo": False,
            "pool_pre_ping": True,
            "pool_recycle": 1800,
            **(engine_options or {}),
        })
        self.session_factory = async_sessionmaker(
            bind=self.engine,
            class_=AsyncSession,
            **{
                "expire_on_commit": False,
                "autoflush": False,
                **(session_options or {}),
            },
        )

    @asynccontextmanager
    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        """Context manager fournissant une session async avec rollback automatique en cas d'erreur.

        Example::

            async with db.session() as session:
                result = await session.execute(select(User))
        """
        async with self.session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise

    async def get_db(self) -> AsyncGenerator[AsyncSession, None]:
        """Dépendance FastAPI injectant une session async.

        Example::

            app = FastAPI()
            db = Database()

            @app.get("/")
            async def root(session: AsyncSession = Depends(db.get_db)):
                ...
        """
        async with self.session() as session:
            yield session

    async def close(self) -> None:
        """Ferme le pool de connexions (à appeler au shutdown de l'app).

        Example::

            @app.on_event("shutdown")
            async def shutdown():
                await db.close()
        """
        await self.engine.dispose()
