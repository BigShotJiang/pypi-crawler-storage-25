# Module `db`

Client async de connexion à PostgreSQL prêt à l'emploi pour FastAPI.

**Librairies de base** : `SQLAlchemy 2.x` (async) + `asyncpg`.

---

## Fonctions

### `build_database_url`

Construit l'URL de connexion `postgresql+asyncpg://…` à partir de paramètres explicites ou de variables d'environnement.

| Paramètre | Type | Var. d'env. | Défaut |
|-----------|------|------------|--------|
| `host` | `str \| None` | `DB_HOST` | `localhost` |
| `port` | `str \| None` | `DB_PORT` | `5432` |
| `user` | `str \| None` | `DB_USER` | `postgres` |
| `password` | `str \| None` | `DB_PASSWORD` | `postgres` |
| `name` | `str \| None` | `DB_NAME` | `postgres` |

**Retour** : `str`

```python
from dsi_internal_python_utils.db import build_database_url

url = build_database_url()  # lit les variables d'environnement
```

---

## Classes

### `Database`

Client réutilisable encapsulant un `AsyncEngine` et une `async_sessionmaker`.

#### Constructeur

| Paramètre | Type | Défaut | Description |
|-----------|------|--------|-------------|
| `database_url` | `str \| None` | `None` | URL de connexion. Si `None`, construite via `build_database_url()`. |
| `engine_options` | `dict \| None` | `None` | Options supplémentaires pour `create_async_engine`. |
| `session_options` | `dict \| None` | `None` | Options supplémentaires pour `async_sessionmaker`. |

Options par défaut de l'engine : `echo=False`, `pool_pre_ping=True`, `pool_recycle=1800`.  
Options par défaut de la session : `expire_on_commit=False`, `autoflush=False`.

#### Méthodes

| Méthode | Description |
|---------|-------------|
| `session()` | Context manager async fournissant une `AsyncSession` avec commit/rollback automatique. |
| `get_db()` | Générateur async utilisable comme dépendance FastAPI (`Depends(db.get_db)`). |
| `close()` | Ferme le pool de connexions. |

#### Exemple complet

```python
from fastapi import FastAPI, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from dsi_internal_python_utils.db import Database

app = FastAPI()
db = Database()  # variables d'env DB_HOST, DB_PORT, etc.

@app.get("/items")
async def get_items(session: AsyncSession = Depends(db.get_db)):
    result = await session.execute(...)
    return result.scalars().all()

@app.on_event("shutdown")
async def shutdown():
    await db.close()
```
