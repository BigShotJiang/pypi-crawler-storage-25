"""Logger commun aux microservices — utilise la librairie logging avec un format explicite : dd/mm hh:mm:ss - LEVEL - fichier:ligne - message."""

import logging
import sys


def setup_logger(name: str = "app", level: int = logging.INFO) -> logging.Logger:
    """Configure et retourne un logger avec un format horodaté français.

    Utilise la librairie standard ``logging`` avec sortie sur ``stdout``
    et le format ``dd/mm hh:mm:ss - LEVEL - fichier:ligne - message``.

    Args:
        name: Nom du logger.
        level: Niveau de log (par défaut ``logging.INFO``).

    Returns:
        Instance de ``logging.Logger`` configurée.

    Example::

        from dsi_internal_python_utils.core import setup_logger

        logger = setup_logger("mon-service")
        logger.info("Démarrage du service")
        # 15/04 10:30:00 - INFO - main.py:4 - Démarrage du service
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(level)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s - %(levelname)s - %(name)s - %(filename)s:%(lineno)d - %(message)s",
            datefmt="%d/%m %H:%M:%S",
        ))
        logger.addHandler(handler)
    return logger


logger = setup_logger()
