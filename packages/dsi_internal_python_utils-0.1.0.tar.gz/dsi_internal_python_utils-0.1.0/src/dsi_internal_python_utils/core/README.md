# Module `core`

Utilitaires génériques partagés entre les microservices.

**Librairie de base** : `logging` (stdlib Python).

---

## Fonctions

### `setup_logger`

Configure et retourne un logger avec le format horodaté français `dd/mm hh:mm:ss - LEVEL - fichier:ligne - message`.

| Paramètre | Type | Défaut | Description |
|-----------|------|--------|-------------|
| `name` | `str` | `"app"` | Nom du logger |
| `level` | `int` | `logging.INFO` | Niveau de log |

**Retour** : `logging.Logger`

```python
from dsi_internal_python_utils.core import setup_logger
import logging

logger = setup_logger("mon-service", level=logging.DEBUG)
logger.info("Hello")
#
```

### `logger`

Instance globale pré-configurée avec le nom `"app"` et le niveau `INFO`.

```python
from dsi_internal_python_utils.core import logger

logger.info("Démarrage")
```
