#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : aidenmo
# @Email : aidenmo@tencent.com
# @Time : 2026/3/11 15:50
from dotenv import load_dotenv
load_dotenv()

from openai.types import chat

_original_validate = chat.ChatCompletion.model_validate

@classmethod
def _patched_validate(cls, obj, *args, **kwargs):
    if isinstance(obj, dict) and obj.get('service_tier') == '':
        obj['service_tier'] = None
    return _original_validate(obj, *args, **kwargs)

# chat.ChatCompletion.model_validate = _patched_validate



from pydantic_ai import Agent

agent = Agent(
    'openai:deepseek-v3',
    instructions='Be concise, reply with one sentence.',
)

result = agent.run_sync('Where does "hello world" come from?')
print(result.output)
"""
The first known use of "hello, world" was in a 1974 textbook about the C programming language.
"""