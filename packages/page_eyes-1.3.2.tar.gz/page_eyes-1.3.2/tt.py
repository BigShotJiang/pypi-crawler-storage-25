#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : aidenmo
# @Email : aidenmo@tencent.com
# @Time : 2026/3/7 19:12
from pydantic import BaseModel


class Transaction(BaseModel):
    user: str
    amount: float

