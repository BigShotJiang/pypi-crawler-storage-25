"""
PyAccelerate — High-performance Python acceleration engine.

Modules
-------
- **cpu**        : CPU detection, core count, frequency, affinity, NUMA topology
- **threads**    : Virtual thread pool, sliding-window executor, async bridge
- **gpu**        : Multi-vendor GPU detection, ranking, dispatch (CUDA/OpenCL/Intel)
- **npu**        : NPU detection & inference (OpenVINO, ONNX Runtime, DirectML, CoreML)
- **virt**       : Virtualization detection (Hyper-V, VT-x/AMD-V, WSL2, Docker)
- **memory**     : Memory monitoring, pressure detection, pool allocator
- **profiler**   : Decorator-based profiling & timing utilities
- **benchmark**  : Built-in micro-benchmarks for the current host
- **priority**   : OS-level task priority & energy profile management
- **max_mode**   : Maximum optimization mode — all resources in parallel
- **android**    : Android/Termux platform detection, ARM SoC database, thermal/battery
- **iot**        : IoT / SBC detection (Raspberry Pi, Jetson, BeagleBone, Coral, Hailo)
- **autotune**   : Auto-tuning feedback loop (benchmark → config → re-tune)
- **metrics**    : Prometheus metrics exporter (``/metrics`` HTTP endpoint)
- **server**     : JSON HTTP & gRPC server for multi-language integration
- **k8s**        : Kubernetes integration, GPU auto-scaling, manifest generation
- **engine**     : Unified orchestrator that auto-tunes all subsystems
- **lockfree_queue** : Lock-free MPMC & Chase-Lev work-stealing deques
- **work_stealing**  : Work-stealing scheduler (Tokio / Go / ForkJoinPool style)
- **adaptive**       : Adaptive scheduler — latency, CPU & memory pressure driven
- **pipeline**       : Typed pipeline stages with backpressure
- **retry**          : Configurable retry with exponential backoff & jitter
- **circuit_breaker**: Circuit breaker pattern for flaky operations
- **rate_limiter**   : Token-bucket rate limiter
- **health**         : Aggregated system health checks (CPU, memory, GPU, disk)
- **plugins**        : Lightweight plugin discovery via entry points
- **_native**        : Optional Cython / Rust accelerators for hot-path data structures

Quick start::

    from pyaccelerate import Engine

    engine = Engine()          # auto-detects hardware
    print(engine.summary())    # human-readable report

    # Maximum optimization mode
    from pyaccelerate.max_mode import MaxMode

    with MaxMode() as m:
        results = m.run_all(
            cpu_fn=cpu_task, cpu_items=cpu_data,
            io_fn=io_task, io_items=io_data,
        )

    # OS priority control
    from pyaccelerate.priority import max_performance, balanced
    max_performance()   # HIGH priority + ULTRA energy
    balanced()          # restore defaults

    # Use the shared virtual-thread pool
    from pyaccelerate.threads import get_pool, run_parallel

    pool = get_pool()
    fut = pool.submit(my_io_func, arg1, arg2)

    # GPU compute
    from pyaccelerate.gpu import detect_all, best_gpu, dispatch

    gpus = detect_all()
    result = dispatch(my_kernel, data, gpus=gpus)
"""

from importlib.metadata import PackageNotFoundError, version as _version

try:
    __version__: str = _version("pyaccelerate")
except PackageNotFoundError:
    # Running from source / not installed
    from pathlib import Path as _Path

    _vf = _Path(__file__).resolve().parent.parent.parent / "VERSION"
    __version__ = _vf.read_text().strip() if _vf.exists() else "0.0.0-dev"

# Convenience re-exports
from pyaccelerate.engine import Engine  # noqa: E402, F401
from pyaccelerate.max_mode import MaxMode  # noqa: E402, F401
from pyaccelerate.priority import (  # noqa: E402, F401
    TaskPriority,
    EnergyProfile,
    max_performance,
    balanced,
    power_saver,
)
from pyaccelerate.autotune import (  # noqa: E402, F401
    auto_tune, get_or_tune, apply_profile,
    hardware_safe_limits, clamp_config,
)
from pyaccelerate.memory import get_gpu_memory_stats  # noqa: E402, F401
from pyaccelerate.server import PyAccelerateServer  # noqa: E402, F401
from pyaccelerate.work_stealing import (  # noqa: E402, F401
    WorkStealingScheduler,
    get_scheduler,
    ws_submit,
    ws_map,
)
from pyaccelerate.adaptive import AdaptiveScheduler, AdaptiveConfig  # noqa: E402, F401
from pyaccelerate.lockfree_queue import WorkDeque, MPMCQueue  # noqa: E402, F401
from pyaccelerate.pipeline import Pipeline, Stage, PipelineResult  # noqa: E402, F401
from pyaccelerate.retry import RetryPolicy, retry, retry_call  # noqa: E402, F401
from pyaccelerate.circuit_breaker import CircuitBreaker, CircuitOpenError  # noqa: E402, F401
from pyaccelerate.rate_limiter import RateLimiter  # noqa: E402, F401
from pyaccelerate.health import health_check, HealthReport, Status as HealthStatus  # noqa: E402, F401
from pyaccelerate.plugins import discover as discover_plugins, register as register_plugin  # noqa: E402, F401

__all__ = [
    "__version__",
    "Engine",
    "MaxMode",
    "TaskPriority",
    "EnergyProfile",
    "max_performance",
    "balanced",
    "power_saver",
    "auto_tune",
    "get_or_tune",
    "apply_profile",
    "PyAccelerateServer",
    "WorkStealingScheduler",
    "get_scheduler",
    "ws_submit",
    "ws_map",
    "AdaptiveScheduler",
    "AdaptiveConfig",
    "WorkDeque",
    "MPMCQueue",
    "hardware_safe_limits",
    "clamp_config",
    "get_gpu_memory_stats",
    "Pipeline",
    "Stage",
    "PipelineResult",
    "RetryPolicy",
    "retry",
    "retry_call",
    "CircuitBreaker",
    "CircuitOpenError",
    "RateLimiter",
    "health_check",
    "HealthReport",
    "HealthStatus",
    "discover_plugins",
    "register_plugin",
]
