"""Shared DoS check registry, result schema, and execution helpers."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from blue_tap.core.result_schema import (
    EXECUTION_COMPLETED,
    EXECUTION_ERROR,
    build_run_envelope,
    make_evidence,
    make_execution,
    now_iso,
)
from blue_tap.fuzz.protocols.att import build_find_info_req
from blue_tap.fuzz.transport import BLETransport
from blue_tap.utils.bt_helpers import check_tool, run_cmd


DOS_STATUS_SUCCESS = "success"
DOS_STATUS_UNRESPONSIVE = "unresponsive"
DOS_STATUS_RECOVERED = "recovered"
DOS_STATUS_FAILED = "failed"
DOS_STATUS_ERROR = "error"
DOS_STATUS_NOT_APPLICABLE = "not_applicable"
DOS_STATUS_SKIPPED = "skipped"

# Probe timeouts (seconds) — kept as named constants so they're tunable in one place
_L2PING_PROBE_TIMEOUT = 10   # hcitool/l2ping round-trip probe timeout
_NAME_PROBE_TIMEOUT = 8      # hcitool name lookup timeout

RECOVERY_PROBE_CLASSIC_L2PING = "classic_l2ping"
RECOVERY_PROBE_CLASSIC_NAME = "classic_name"
RECOVERY_PROBE_BLE_ATT = "ble_att"
RECOVERY_PROBE_BLE_ATT_REQUEST = "ble_att_request"
RECOVERY_PROBE_BLE_ADVERTISING = "ble_advertising"


@dataclass(frozen=True)
class DosCheck:
    """Structured metadata for one DoS check."""

    check_id: str
    title: str
    protocol: str
    runner: Callable[..., dict]
    default_params: dict[str, Any] = field(default_factory=dict)
    description: str = ""
    cves: tuple[str, ...] = field(default_factory=tuple)
    destructive: bool = True
    requires_darkfirmware: bool = False
    requires_pairing: bool = False
    category: str = "protocol"
    recovery_probes: tuple[str, ...] = field(default_factory=tuple)

def _detect_unresponsive_text(text: str) -> bool:
    lowered = text.lower()
    return any(token in lowered for token in (
        "target_unresponsive",
        "possibly_crashed",
        "connection lost",
        "send failed",
        "crash",
        "timeout",
        "hung",
        "frozen",
        "disconnected",
    ))


def infer_dos_status(raw_result: dict) -> str:
    """Normalize ad hoc attack result dicts to a stable DoS status."""

    if not isinstance(raw_result, dict):
        return DOS_STATUS_ERROR

    result = str(raw_result.get("result", raw_result.get("target_status", raw_result.get("status", ""))))
    notes = str(raw_result.get("notes", ""))
    error = str(raw_result.get("error", ""))
    combined = " ".join((result, notes, error)).lower()

    if "precondition failed" in combined or "existing bond or active pairing may be required" in combined:
        return DOS_STATUS_NOT_APPLICABLE

    if result in {DOS_STATUS_NOT_APPLICABLE, "not-applicable"}:
        return DOS_STATUS_NOT_APPLICABLE
    if result in {"success", "survived"}:
        return DOS_STATUS_SUCCESS
    if result in {"error", ""} and error:
        return DOS_STATUS_ERROR
    if result in {"target_unresponsive", "possibly_crashed"}:
        return DOS_STATUS_UNRESPONSIVE
    if _detect_unresponsive_text(" ".join((result, notes, error))):
        return DOS_STATUS_UNRESPONSIVE
    if result:
        return DOS_STATUS_FAILED
    return DOS_STATUS_ERROR


def default_recovery_probes(protocol: str) -> tuple[str, ...]:
    normalized = protocol.strip().lower()
    if normalized in {"ble", "att", "gatt", "smp", "eatt"}:
        return (RECOVERY_PROBE_BLE_ATT_REQUEST, RECOVERY_PROBE_BLE_ADVERTISING)
    if normalized in {"dual", "hybrid", "classic+ble"}:
        return (
            RECOVERY_PROBE_CLASSIC_L2PING,
            RECOVERY_PROBE_CLASSIC_NAME,
            RECOVERY_PROBE_BLE_ATT,
            RECOVERY_PROBE_BLE_ADVERTISING,
        )
    return (RECOVERY_PROBE_CLASSIC_L2PING, RECOVERY_PROBE_CLASSIC_NAME)


def _probe_classic_l2ping(address: str, hci: str) -> tuple[bool, str]:
    if not check_tool("l2ping"):
        return False, "classic_l2ping unavailable"
    result = run_cmd(["l2ping", "-i", hci, "-c", "1", "-t", "3", address], timeout=_L2PING_PROBE_TIMEOUT)
    if result.returncode == 0:
        line = result.stdout.strip().splitlines()
        return True, line[-1] if line else "classic_l2ping success"
    stderr = (result.stderr or "").strip()
    return False, stderr or (result.stdout or "").strip() or "classic_l2ping failed"


def _probe_classic_name(address: str, hci: str) -> tuple[bool, str]:
    if not check_tool("hcitool"):
        return False, "classic_name unavailable"
    result = run_cmd(["hcitool", "-i", hci, "name", address], timeout=_NAME_PROBE_TIMEOUT)
    if result.returncode == 0 and result.stdout.strip():
        return True, f"classic_name responded: {result.stdout.strip()}"
    stderr = (result.stderr or "").strip()
    return False, f"classic_name failed: {stderr or result.stdout.strip() or 'no response'}"


def _probe_ble_att(address: str, hci: str) -> tuple[bool, str]:
    try:
        address_type = BLETransport._detect_address_type(address)
        transport = BLETransport(address, cid=BLETransport.ATT_CID, address_type=address_type, timeout=3.0)
        alive = transport.is_alive()
        addr_type_label = "random" if address_type == 2 else "public"
        if alive:
            return True, f"ble_att connect succeeded (addr_type={addr_type_label}, adapter={hci})"
        return False, f"ble_att connect failed (addr_type={addr_type_label}, adapter={hci})"
    except Exception as exc:
        return False, f"ble_att probe error: {exc}"


def _probe_ble_att_request(address: str, hci: str) -> tuple[bool, str]:
    """Probe real ATT responsiveness, not just BLE connection setup."""
    transport = None
    try:
        address_type = BLETransport._detect_address_type(address)
        transport = BLETransport(
            address,
            cid=BLETransport.ATT_CID,
            address_type=address_type,
            timeout=3.0,
        )
        if not transport.connect():
            return False, "ble_att_request connect failed"
        req = build_find_info_req(0x0001, 0x0001)
        sent = transport.send(req)
        if sent <= 0:
            return False, "ble_att_request send failed"
        resp = transport.recv(64, recv_timeout=2.0)
        if resp:
            return True, f"ble_att_request response opcode=0x{resp[0]:02X} len={len(resp)}"
        return False, "ble_att_request timed out"
    except Exception as exc:
        return False, f"ble_att_request probe error: {exc}"
    finally:
        if transport is not None:
            transport.close()


async def _scan_for_ble_target(address: str, adapter: str, timeout: float) -> tuple[bool, str]:
    try:
        from bleak import BleakScanner
    except ImportError:
        return False, "ble_advertising unavailable (bleak not installed)"

    kwargs: dict[str, Any] = {"timeout": timeout, "return_adv": True}
    if adapter:
        kwargs["adapter"] = adapter
    discovered = await BleakScanner.discover(**kwargs)
    target = address.upper()
    for dev, adv in discovered.values():
        if str(dev.address).upper() == target:
            uuids = getattr(adv, "service_uuids", None) or []
            uuid_preview = ",".join(uuids[:2]) if uuids else "none"
            name = dev.name or getattr(adv, "local_name", None) or "Unknown"
            return True, f"ble_advertising seen name={name} rssi={adv.rssi} uuids={uuid_preview}"
    return False, "ble_advertising target not seen"


def _probe_ble_advertising(address: str, hci: str, scan_seconds: float = 4.0) -> tuple[bool, str]:
    try:
        return asyncio.run(_scan_for_ble_target(address, hci, scan_seconds))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            return loop.run_until_complete(_scan_for_ble_target(address, hci, scan_seconds))
        finally:
            asyncio.set_event_loop(None)
            loop.close()
    except Exception as exc:
        return False, f"ble_advertising probe error: {exc}"


def wait_for_target_recovery(address: str, hci: str = "hci0", timeout_seconds: int = 180,
                             interval_seconds: int = 10,
                             recovery_probes: tuple[str, ...] | None = None) -> dict[str, Any]:
    """Poll for target recovery after a disruptive DoS check."""

    started = time.time()
    probes: list[str] = []
    selected_probes = tuple(recovery_probes or default_recovery_probes("classic"))

    while time.time() - started < timeout_seconds:
        responsive, evidence, details = probe_target_responsive(address, hci, selected_probes)
        probes.append(evidence)
        if responsive:
            return {
                "recovered": True,
                "waited_seconds": int(time.time() - started),
                "last_probe": evidence,
                "probe_history": probes[-5:],
                "probe_details": details,
                "probe_strategy": list(selected_probes),
            }
        time.sleep(interval_seconds)

    return {
        "recovered": False,
        "waited_seconds": timeout_seconds,
        "last_probe": probes[-1] if probes else "no probe data",
        "probe_history": probes[-5:],
        "probe_details": [],
        "probe_strategy": list(selected_probes),
    }


def probe_target_responsive(address: str, hci: str = "hci0",
                            recovery_probes: tuple[str, ...] | None = None) -> tuple[bool, str, list[dict[str, str]]]:
    """Check whether the target appears responsive using the selected probe chain."""

    selected_probes = tuple(recovery_probes or default_recovery_probes("classic"))
    details: list[dict[str, str]] = []
    last_evidence = "no probe data"

    for probe_name in selected_probes:
        if probe_name == RECOVERY_PROBE_CLASSIC_L2PING:
            responsive, evidence = _probe_classic_l2ping(address, hci)
        elif probe_name == RECOVERY_PROBE_CLASSIC_NAME:
            responsive, evidence = _probe_classic_name(address, hci)
        elif probe_name == RECOVERY_PROBE_BLE_ATT:
            responsive, evidence = _probe_ble_att(address, hci)
        elif probe_name == RECOVERY_PROBE_BLE_ATT_REQUEST:
            responsive, evidence = _probe_ble_att_request(address, hci)
        elif probe_name == RECOVERY_PROBE_BLE_ADVERTISING:
            responsive, evidence = _probe_ble_advertising(address, hci)
        else:
            responsive, evidence = False, f"unknown recovery probe {probe_name}"

        last_evidence = evidence
        details.append({"probe": probe_name, "result": "responsive" if responsive else "no_response", "evidence": evidence})
        if responsive:
            return True, evidence, details

    return False, last_evidence, details


def build_dos_run_result(
    *,
    target: str,
    adapter: str,
    mode: str,
    checks: list[dict],
    started_at: str,
    selected_checks: list[str] | None = None,
    completed_at: str | None = None,
    recovery_timeout: int | None = None,
    interrupted_on: str | None = None,
    abort_reason: str | None = None,
    run_id: str | None = None,
) -> dict[str, Any]:
    summary = summarize_dos_checks(checks)
    finished = completed_at or now_iso()
    executions = []
    for check in checks:
        raw_status = str(check.get("status", DOS_STATUS_ERROR))
        evidence = make_evidence(
            summary=str(check.get("evidence", "")) or f"{check.get('title', 'DoS check')} completed",
            confidence="high" if raw_status in {DOS_STATUS_UNRESPONSIVE, DOS_STATUS_RECOVERED} else "medium",
            observations=[str(check.get("evidence", ""))] if check.get("evidence") else [],
            state_changes=[
                f"recovered={check.get('recovery', {}).get('recovered')}",
                f"waited_seconds={check.get('recovery', {}).get('waited_seconds', 0)}",
            ] if check.get("recovery") else [],
            module_evidence={
                "recovery": check.get("recovery", {}),
                "cves": check.get("cves", []),
                "params": check.get("params", {}),
            },
        )
        executions.append(
            make_execution(
                kind="check",
                id=check.get("check_id", "dos_check"),
                title=check.get("title", "DoS Check"),
                module="dos",
                protocol=check.get("protocol", "unknown"),
                execution_status=EXECUTION_ERROR if raw_status == DOS_STATUS_ERROR else EXECUTION_COMPLETED,
                module_outcome=raw_status,
                severity=None,
                destructive=bool(check.get("destructive", True)),
                requires_pairing=bool(check.get("requires_pairing", False)),
                started_at=check.get("started_at", started_at),
                completed_at=check.get("completed_at", finished),
                evidence=evidence,
                tags=["dos", check.get("category", "protocol")],
                module_data=dict(check),
            )
        )
    return build_run_envelope(
        schema="blue_tap.dos.result",
        module="dos",
        target=target,
        adapter=adapter,
        operator_context={
            "mode": mode,
            "selected_checks": list(selected_checks or []),
            "recovery_timeout": recovery_timeout,
        },
        summary=summary,
        executions=executions,
        module_data={
            "mode": mode,
            "selected_checks": list(selected_checks or []),
            "recovery_timeout": recovery_timeout,
            "interrupted_on": interrupted_on,
            "abort_reason": abort_reason,
            "checks": checks,
        },
        started_at=started_at,
        completed_at=finished,
        run_id=run_id,
    )


def summarize_dos_checks(checks: list[dict]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for check in checks:
        status = str(check.get("status", DOS_STATUS_ERROR))
        counts[status] = counts.get(status, 0) + 1
    return {
        "total": len(checks),
        "status_counts": counts,
        "success": counts.get(DOS_STATUS_SUCCESS, 0),
        "recovered": counts.get(DOS_STATUS_RECOVERED, 0),
        "unresponsive": counts.get(DOS_STATUS_UNRESPONSIVE, 0),
        "failed": counts.get(DOS_STATUS_FAILED, 0),
        "error": counts.get(DOS_STATUS_ERROR, 0),
        "not_applicable": counts.get(DOS_STATUS_NOT_APPLICABLE, 0),
        "skipped": counts.get(DOS_STATUS_SKIPPED, 0),
    }


def build_dos_operation_result(
    *,
    target: str,
    adapter: str,
    operation: str,
    title: str,
    protocol: str,
    raw_result: dict[str, Any],
    started_at: str,
    observations: list[str] | None = None,
    destructive: bool = True,
    requires_pairing: bool = False,
    category: str = "protocol",
    run_id: str | None = None,
) -> dict[str, Any]:
    """Wrap a legacy standalone DoS command in the standardized DoS envelope."""

    raw = dict(raw_result or {})
    status = infer_dos_status(raw)
    evidence_summary = next(
        (str(raw.get(key)) for key in ("notes", "error", "result", "target_status") if raw.get(key)),
        f"{title} completed",
    )
    check = {
        "check_id": operation,
        "title": title,
        "protocol": protocol,
        "status": status,
        "params": {},
        "requires_pairing": requires_pairing,
        "destructive": destructive,
        "category": category,
        "evidence": evidence_summary,
        "raw_result": raw,
        "recovery": {},
        "started_at": started_at,
        "completed_at": now_iso(),
    }
    return build_dos_run_result(
        target=target,
        adapter=adapter,
        mode="single_operation",
        checks=[check],
        started_at=started_at,
        completed_at=now_iso(),
        selected_checks=[operation],
        run_id=run_id,
    )
