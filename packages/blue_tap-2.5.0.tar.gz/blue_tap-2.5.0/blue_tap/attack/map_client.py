"""MAP (Message Access Profile) client for SMS/MMS extraction from IVI.

MAP uses OBEX over RFCOMM/L2CAP to access messages on the remote device.
The IVI typically mirrors messages from the paired phone.

Target UUID: 0x1132 (MAP MAS - Message Access Server)
OBEX Target: bb582b40-420c-11db-b0de-0800200c9a66 (MAP MAS)
"""

import os
import socket
import struct
import re
import textwrap
import xml.etree.ElementTree as ET

from blue_tap.core.obex_client import MAPSession, ObexError
from blue_tap.utils.bt_helpers import normalize_mac
from blue_tap.utils.output import info, success, error, warning


# MAP MAS OBEX Target UUID
MAP_MAS_TARGET_UUID = bytes.fromhex("bb582b40420c11dbb0de0800200c9a66")

OBEX_CONNECT = 0x80
OBEX_DISCONNECT = 0x81
OBEX_GET = 0x83
OBEX_SETPATH = 0x85
OBEX_RESPONSE_SUCCESS = 0xA0
OBEX_RESPONSE_CONTINUE = 0x90

OBEX_HEADER_NAME = 0x01
OBEX_HEADER_TYPE = 0x42
OBEX_HEADER_BODY = 0x48
OBEX_HEADER_END_OF_BODY = 0x49
OBEX_HEADER_TARGET = 0x46
OBEX_HEADER_CONNECTION_ID = 0xCB
OBEX_HEADER_APP_PARAMS = 0x4C

# MAP message types
MAP_MSG_TYPES = {
    0x00: "EMAIL",
    0x01: "SMS_GSM",
    0x02: "SMS_CDMA",
    0x03: "MMS",
    0x04: "IM",
}

# MAP folders
MAP_FOLDERS = [
    "telecom/msg/inbox",
    "telecom/msg/outbox",
    "telecom/msg/sent",
    "telecom/msg/deleted",
    "telecom/msg/draft",
]

MAP_FOLDER_ALIASES = {
    "inbox": "telecom/msg/inbox",
    "outbox": "telecom/msg/outbox",
    "sent": "telecom/msg/sent",
    "deleted": "telecom/msg/deleted",
    "draft": "telecom/msg/draft",
    "drafts": "telecom/msg/draft",
}


class MAPClient:
    """MAP client for downloading SMS/MMS messages from IVI/phone.

    Usage:
        client = MAPClient("AA:BB:CC:DD:EE:FF", channel=16)
        client.connect()
        messages = client.get_messages_listing("telecom/msg/inbox")
        for msg_handle in messages:
            content = client.get_message(msg_handle)
        client.disconnect()
    """

    def __init__(self, address: str, channel: int | None = None):
        self.address = normalize_mac(address)
        self.channel = channel
        self.sock = None
        self.connection_id = None
        self._obex_session: MAPSession | None = None
        self._current_folder_components: list[str] = []
        self.last_capability_limitations: list[str] = []

    def connect(self) -> bool:
        """Establish OBEX connection to MAP MAS server."""
        try:
            self._obex_session = MAPSession(self.address, channel=self.channel)
            if self._obex_session.connect():
                success("MAP OBEX D-Bus session established")
                return True
        except ObexError as exc:
            warning(f"MAP D-Bus session unavailable, falling back to raw OBEX: {exc}")
            self._obex_session = None

        try:
            self.sock = socket.socket(
                socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM
            )
            self.sock.settimeout(15.0)
            info(f"Connecting MAP to {self.address} channel {self.channel}...")
            self.sock.connect((self.address, self.channel))
            success("RFCOMM connected for MAP")

            # OBEX Connect with MAP target
            target_header = struct.pack(">BH", OBEX_HEADER_TARGET,
                                        len(MAP_MAS_TARGET_UUID) + 3) + MAP_MAS_TARGET_UUID
            body = struct.pack(">BBH", 0x10, 0x00, 0xFFFF) + target_header
            packet = struct.pack(">BH", OBEX_CONNECT, 3 + len(body)) + body
            self.sock.send(packet)

            response = self._recv_response()
            if response and response[0] == OBEX_RESPONSE_SUCCESS:
                self._parse_connection_id(response)
                success(f"MAP session established (conn_id={self.connection_id})")
                return True
            else:
                error("MAP OBEX Connect rejected")
                return False

        except OSError as e:
            error(f"MAP connect failed: {e}")
            return False

    def disconnect(self):
        """Disconnect MAP session cleanly with OBEX Disconnect."""
        if self._obex_session is not None:
            self._obex_session.disconnect()
            self._obex_session = None
            self._current_folder_components = []
            info("MAP disconnected")
            return

        if self.sock:
            try:
                # Send OBEX Disconnect
                disconnect_pkt = struct.pack(">BH", OBEX_DISCONNECT, 3)
                if self.connection_id is not None:
                    disconnect_pkt = struct.pack(">BH", OBEX_DISCONNECT, 8)
                    disconnect_pkt += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID,
                                                  self.connection_id)
                self.sock.send(disconnect_pkt)
                self._recv_response()
            except OSError:
                pass
            finally:
                try:
                    self.sock.close()
                except OSError:
                    pass
                self.sock = None
            info("MAP disconnected")

    def set_folder(self, path: str) -> bool:
        """Navigate to a MAP folder using OBEX SetPath."""
        path = self.normalize_folder(path)
        if self._obex_session is not None:
            try:
                target_components = self._folder_components(path)
                common_prefix = 0
                while (
                    common_prefix < len(self._current_folder_components)
                    and common_prefix < len(target_components)
                    and self._current_folder_components[common_prefix] == target_components[common_prefix]
                ):
                    common_prefix += 1

                for _ in range(len(self._current_folder_components) - common_prefix):
                    self._obex_session.set_folder("..")

                for component in target_components[common_prefix:]:
                    self._obex_session.set_folder(component)
                self._current_folder_components = target_components
                info(f"Current MAP folder: {path}")
                return True
            except ObexError as exc:
                warning(f"MAP D-Bus set_folder failed, using raw OBEX fallback: {exc}")
        # Navigate to root first
        self._setpath_root()

        # Then navigate down each component
        for component in path.split("/"):
            if not self._setpath_down(component):
                error(f"Failed to navigate to folder component: {component}")
                return False

        info(f"Current MAP folder: {path}")
        return True

    def list_folders(self, folder: str = "telecom/msg", max_count: int = 100, offset: int = 0) -> list[dict]:
        """List subfolders beneath a MAP folder."""
        folder = self.normalize_folder(folder)
        info(f"Listing MAP folders under {folder}")

        if self._obex_session is not None:
            try:
                if folder not in {"telecom/msg", "telecom", ""}:
                    self.set_folder(folder)
                return self._obex_session.list_folders({"MaxCount": max_count, "Offset": offset})
            except ObexError as exc:
                warning(f"MAP D-Bus folder listing failed, using static fallback: {exc}")

        # Raw fallback has no generic ListFolders implementation yet.
        # Return static known folders when the caller requests the MAP root.
        if folder in {"telecom/msg", "telecom", ""}:
            return [{"Name": item.split("/")[-1]} for item in MAP_FOLDERS]
        return []

    def get_messages_listing(
        self,
        folder: str = "telecom/msg/inbox",
        max_count: int = 100,
        offset: int = 0,
        subject_length: int = 256,
        fields: list[str] | None = None,
        msg_types: list[str] | None = None,
        period_begin: str | None = None,
        period_end: str | None = None,
        read: bool | None = None,
        recipient: str | None = None,
        sender: str | None = None,
        priority: bool | None = None,
    ) -> str:
        """Get listing of messages in a folder.

        Returns XML listing with message handles, subjects, senders, timestamps.
        """
        folder = self.normalize_folder(folder)
        info(f"Listing messages in {folder}")

        if self._obex_session is not None:
            try:
                messages = self._obex_session.list_messages(
                    folder,
                    self._build_obex_filters(
                        max_count=max_count,
                        offset=offset,
                        subject_length=subject_length,
                        fields=fields,
                        msg_types=msg_types,
                        period_begin=period_begin,
                        period_end=period_end,
                        read=read,
                        recipient=recipient,
                        sender=sender,
                        priority=priority,
                    ),
                )
                xml = self._messages_to_listing_xml(messages)
                if xml:
                    success(f"Retrieved message listing ({len(xml)} bytes)")
                return xml
            except ObexError as exc:
                warning(f"MAP D-Bus listing failed, using raw OBEX fallback: {exc}")

        unsupported_filters = any(
            value not in (None, [], "", 0, 256)
            for value in [offset, fields or [], msg_types or [], period_begin, period_end, read, recipient, sender, priority]
        )
        if unsupported_filters:
            warning("MAP raw OBEX fallback currently supports only MaxCount; additional filters were ignored")

        if not self.set_folder(folder):
            return ""

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        # Type header for message listing
        type_str = b"x-bt/MAP-msg-listing\x00"
        headers += struct.pack(">BH", OBEX_HEADER_TYPE, len(type_str) + 3) + type_str

        # App params: MaxListCount
        app_params = struct.pack(">BBH", 0x01, 0x02, max_count)
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        packet = struct.pack(">BH", OBEX_GET, 3 + len(headers)) + headers
        self.sock.send(packet)

        body = self._recv_body()
        result = body.decode("utf-8", errors="replace")
        if result:
            success(f"Retrieved message listing ({len(result)} bytes)")
        return result

    def get_message(self, handle: str) -> str:
        """Get a specific message by handle.

        Returns the message in bMessage format (contains sender, recipient,
        timestamp, and message body).
        """
        info(f"Fetching message: {handle}")

        if self._obex_session is not None and str(handle).startswith("/org/bluez/obex/"):
            try:
                targetfile = self._obex_session.create_temp_file_path(
                    prefix="blue_tap_map_",
                    suffix=".bmsg",
                )
                transfer_path, transfer_props = self._obex_session.get_message(handle, targetfile, attachment=False)
                filename, _ = self._obex_session.finalize_transfer_file(
                    transfer_path,
                    transfer_props,
                    fallback_path=targetfile,
                )
                return self._obex_session.read_text_file(filename)
            except (ObexError, OSError) as exc:
                warning(f"MAP D-Bus message fetch failed, using raw OBEX fallback: {exc}")

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        # Name header (message handle)
        name_bytes = handle.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        # Type header
        type_str = b"x-bt/message\x00"
        headers += struct.pack(">BH", OBEX_HEADER_TYPE, len(type_str) + 3) + type_str

        # App params: charset=UTF-8
        app_params = struct.pack(">BBB", 0x14, 0x01, 0x01)  # Charset UTF-8
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        packet = struct.pack(">BH", OBEX_GET, 3 + len(headers)) + headers
        self.sock.send(packet)

        body = self._recv_body()
        return body.decode("utf-8", errors="replace")

    def normalize_folder(self, folder: str) -> str:
        """Resolve short folder aliases to full MAP paths."""
        cleaned = (folder or "").strip().strip("/")
        if cleaned.lower() in {"msg", "telecom/msg"}:
            return "telecom/msg"
        return MAP_FOLDER_ALIASES.get(cleaned.lower(), cleaned or "telecom/msg/inbox")

    def _build_obex_filters(
        self,
        *,
        max_count: int = 100,
        offset: int = 0,
        subject_length: int = 256,
        fields: list[str] | None = None,
        msg_types: list[str] | None = None,
        period_begin: str | None = None,
        period_end: str | None = None,
        read: bool | None = None,
        recipient: str | None = None,
        sender: str | None = None,
        priority: bool | None = None,
    ) -> dict[str, object]:
        filters: dict[str, object] = {"MaxCount": max_count}
        if offset:
            filters["Offset"] = offset
        if subject_length != 256:
            filters["SubjectLength"] = max(1, min(255, subject_length))
        if fields:
            filters["Fields"] = [str(item) for item in fields]
        if msg_types:
            filters["Types"] = [str(item) for item in msg_types]
        if period_begin:
            filters["PeriodBegin"] = period_begin
        if period_end:
            filters["PeriodEnd"] = period_end
        if read is not None:
            filters["Read"] = read
        if recipient:
            filters["Recipient"] = recipient
        if sender:
            filters["Sender"] = sender
        if priority is not None:
            filters["Priority"] = priority
        return filters

    def _folder_components(self, folder: str) -> list[str]:
        normalized = self.normalize_folder(folder)
        components = [part for part in normalized.split("/") if part]
        if components[:2] == ["telecom", "msg"]:
            return components[2:]
        return components

    def parse_message_listing(self, listing_xml: str) -> list[dict]:
        """Parse MAP message listing XML into structured message summaries."""
        listing_xml = (listing_xml or "").strip()
        if not listing_xml:
            return []

        try:
            root = ET.fromstring(listing_xml)
        except ET.ParseError:
            return self._parse_listing_fragments(listing_xml, "msg")

        messages: list[dict] = []
        for node in root.iter():
            tag_name = str(node.tag).split("}", 1)[-1].lower()
            if tag_name != "msg":
                continue
            item = {str(key): str(value) for key, value in node.attrib.items()}
            messages.append(item)
        return messages

    def _messages_to_listing_xml(self, messages: list[dict]) -> str:
        xml_lines = ['<?xml version="1.0"?>', '<MAP-msg-listing version="1.0">']
        for item in messages:
            attrs = []
            for key, value in item.items():
                attrs.append(f'{self._xml_escape(str(key))}="{self._xml_escape(str(value))}"')
            xml_lines.append(f"  <msg {' '.join(attrs)}/>")
        xml_lines.append("</MAP-msg-listing>")
        return "\n".join(xml_lines)

    @staticmethod
    def _xml_escape(value: str) -> str:
        return (
            str(value)
            .replace("&", "&amp;")
            .replace('"', "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    @staticmethod
    def _parse_listing_fragments(payload: str, tag_name: str) -> list[dict]:
        matches = re.findall(
            rf'<(?:[A-Za-z0-9_.-]+:)?{tag_name}\b([^>]*)/?\s*>',
            payload,
            flags=re.IGNORECASE,
        )
        parsed = []
        for attrs in matches:
            item = {}
            for key, value in re.findall(r'([A-Za-z0-9_.:-]+)\s*=\s*"([^"]*)"', attrs):
                item[str(key)] = str(value)
            if item:
                parsed.append(item)
        return parsed

    def dump_all_messages(self, output_dir: str = "map_dump") -> dict:
        """Dump all messages from all folders."""
        import json

        os.makedirs(output_dir, exist_ok=True)
        results = {}

        for folder in MAP_FOLDERS:
            folder_name = folder.split("/")[-1]
            listing = self.get_messages_listing(folder)
            if listing:
                listing_file = os.path.join(output_dir, f"{folder_name}_listing.xml")
                with open(listing_file, "w") as f:
                    f.write(listing)
                results[folder] = {"listing_file": listing_file, "messages": []}
                success(f"Saved listing: {listing_file}")

                # Parse message handles from XML listing
                # MAP listing XML uses <msg handle="XXXX" .../>
                parsed_listing = self.parse_message_listing(listing)
                listing_json = os.path.join(output_dir, f"{folder_name}_listing.json")
                with open(listing_json, "w") as f:
                    json.dump(parsed_listing, f, indent=2, default=str)
                results[folder]["listing_json"] = listing_json

                message_ids = [
                    item.get("handle") or item.get("path") or ""
                    for item in parsed_listing
                    if item.get("handle") or item.get("path")
                ]
                if message_ids:
                    info(f"Found {len(message_ids)} message reference(s) in {folder_name}")
                    msg_dir = os.path.join(output_dir, folder_name)
                    os.makedirs(msg_dir, exist_ok=True)

                    for message_id in message_ids:
                        try:
                            content = self.get_message(message_id)
                            if content:
                                safe_handle = os.path.basename(message_id).replace("/", "_").replace("\\", "_")
                                msg_file = os.path.join(msg_dir, f"{safe_handle}.bmsg")
                                with open(msg_file, "w") as f:
                                    f.write(content)
                                parsed = parse_bmessage(content)
                                parsed_file = os.path.join(msg_dir, f"{safe_handle}.json")
                                with open(parsed_file, "w") as f:
                                    json.dump(parsed, f, indent=2, default=str)
                                results[folder]["messages"].append({
                                    "handle": message_id,
                                    "file": msg_file,
                                    "parsed_file": parsed_file,
                                    "parsed": parsed,
                                })
                        except OSError as e:
                            warning(f"Failed to fetch message {message_id}: {e}")

                    fetched = len(results[folder]["messages"])
                    if fetched:
                        success(f"Fetched {fetched}/{len(message_ids)} messages from {folder_name}")

        return results

    def update_inbox(self) -> bool:
        """Request inbox refresh from the remote MAP server."""
        if self._obex_session is not None:
            try:
                self._obex_session.update_inbox()
                success("MAP inbox update requested")
                return True
            except ObexError as exc:
                warning(f"MAP D-Bus inbox update failed: {exc}")
                return False
        warning("MAP inbox update requires D-Bus/obexd path; raw fallback does not support it yet")
        return False

    def _setpath_root(self):
        """Navigate to root folder."""
        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)
        # SetPath with flags=0x02 (go to root)
        body = struct.pack(">BB", 0x02, 0x00) + headers
        packet = struct.pack(">BH", OBEX_SETPATH, 3 + len(body)) + body
        self.sock.send(packet)
        self._recv_response()

    def _setpath_down(self, folder: str) -> bool:
        """Navigate down one folder level."""
        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)
        name_bytes = folder.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        body = struct.pack(">BB", 0x00, 0x00) + headers
        packet = struct.pack(">BH", OBEX_SETPATH, 3 + len(body)) + body
        self.sock.send(packet)

        response = self._recv_response()
        return response is not None and response[0] == OBEX_RESPONSE_SUCCESS

    def _recv_response(self) -> bytes | None:
        try:
            self.sock.settimeout(10.0)
            header = self.sock.recv(3)
            if len(header) < 3:
                return None
            length = struct.unpack(">H", header[1:3])[0]
            remaining = length - 3
            data = b""
            while remaining > 0:
                chunk = self.sock.recv(min(remaining, 4096))
                if not chunk:
                    break
                data += chunk
                remaining -= len(chunk)
            return bytes([header[0]]) + header[1:3] + data
        except (TimeoutError, OSError):
            return None

    def _recv_body(self) -> bytes:
        """Receive multi-part OBEX body."""
        body = b""
        while True:
            response = self._recv_response()
            if response is None:
                break
            opcode = response[0]
            body += self._extract_body_data(response)
            if opcode == OBEX_RESPONSE_SUCCESS:
                break
            elif opcode == OBEX_RESPONSE_CONTINUE:
                cont_headers = b""
                if self.connection_id is not None:
                    cont_headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID,
                                                self.connection_id)
                self.sock.send(struct.pack(">BH", OBEX_GET, 3 + len(cont_headers)) + cont_headers)
            else:
                break
        return body

    def _extract_body_data(self, response: bytes) -> bytes:
        data = b""
        offset = 3
        while offset < len(response):
            hid = response[offset]
            if hid in (OBEX_HEADER_BODY, OBEX_HEADER_END_OF_BODY):
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                data += response[offset + 3:offset + length]
                offset += length
            elif hid & 0xC0 in (0x00, 0x40):
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif hid & 0xC0 == 0x80:
                offset += 2
            elif hid & 0xC0 == 0xC0:
                offset += 5
            else:
                break
        return data

    def push_message(self, folder: str, recipient: str, body: str,
                      msg_type: str = "SMS_GSM", *, transparent: bool = False, retry: bool = True,
                      charset: str = "UTF-8") -> bool:
        """Send an SMS/MMS through the IVI via MAP PushMessage.

        This sends a message FROM the paired phone via the IVI's connection.
        Requires MAP write access (not all IVIs support this).

        Args:
            folder: Target folder (e.g., "telecom/msg/outbox")
            recipient: Phone number to send to
            body: Message text
            msg_type: Message type (SMS_GSM, SMS_CDMA, MMS, EMAIL)
        """
        info(f"Pushing {msg_type} to {recipient} via MAP...")
        self.last_capability_limitations = []

        # Build bMessage format
        bmsg = (
            f"BEGIN:BMSG\r\n"
            f"VERSION:1.0\r\n"
            f"STATUS:UNREAD\r\n"
            f"TYPE:{msg_type}\r\n"
            f"FOLDER:{folder}\r\n"
            f"BEGIN:VCARD\r\n"
            f"VERSION:2.1\r\n"
            f"TEL:{recipient}\r\n"
            f"END:VCARD\r\n"
            f"BEGIN:BENV\r\n"
            f"BEGIN:BBODY\r\n"
            f"CHARSET:{charset}\r\n"
            f"LENGTH:{len(body)}\r\n"
            f"BEGIN:MSG\r\n"
            f"{body}\r\n"
            f"END:MSG\r\n"
            f"END:BBODY\r\n"
            f"END:BENV\r\n"
            f"END:BMSG\r\n"
        )

        if self._obex_session is not None:
            try:
                if not self.set_folder(folder):
                    error(f"Cannot navigate to {folder}")
                    return False
                # TODO: Hardware-validate BlueZ PushMessage interoperability on
                # at least one real MAP server for Transparent/Retry/Charset
                # behavior before treating those args as broadly reliable.
                sourcefile = self._obex_session.create_temp_file_path(
                    prefix="blue_tap_map_push_",
                    suffix=".bmsg",
                )
                with open(sourcefile, "wb") as tmp:
                    tmp.write(bmsg.encode("utf-8"))
                try:
                    transfer_path, transfer_props = self._obex_session.push_message(
                        sourcefile,
                        "",
                        {"Transparent": transparent, "Retry": retry, "Charset": charset},
                    )
                    _, transfer_final = self._obex_session.finalize_transfer_file(
                        transfer_path,
                        transfer_props,
                        fallback_path=sourcefile,
                    )
                    if str(transfer_final.get("Status", "complete")).lower() == "complete":
                        success(f"Message pushed to {recipient}")
                        return True
                    warning(f"MAP D-Bus push did not complete cleanly: {transfer_props}")
                    return False
                finally:
                    try:
                        os.unlink(sourcefile)
                    except OSError:
                        pass
            except ObexError as exc:
                self.last_capability_limitations = [
                    "BlueZ obexd MAP PushMessage path unavailable or rejected; using raw OBEX fallback"
                ]
                warning(f"MAP D-Bus push failed, using raw OBEX fallback: {exc}")

        if not self.set_folder(folder):
            error(f"Cannot navigate to {folder}")
            return False

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        # Type header
        type_str = b"x-bt/message\x00"
        headers += struct.pack(">BH", 0x42, len(type_str) + 3) + type_str

        # App params: Charset=UTF-8
        app_params = struct.pack(">BBB", 0x14, 0x01, 0x01)
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        # Body
        body_bytes = bmsg.encode("utf-8")
        headers += struct.pack(">BH", OBEX_HEADER_END_OF_BODY,
                               len(body_bytes) + 3) + body_bytes

        # OBEX PUT (0x82 = PUT-Final)
        packet = struct.pack(">BH", 0x82, 3 + len(headers)) + headers
        self.sock.send(packet)

        response = self._recv_response()
        if response and response[0] == OBEX_RESPONSE_SUCCESS:
            success(f"Message pushed to {recipient}")
            return True
        else:
            error("PushMessage failed — IVI may not support MAP write access")
            return False

    def set_message_status(self, handle: str, indicator: str,
                            value: bool) -> bool:
        """Set message status (read/deleted) on the IVI.

        Args:
            handle: Message handle from listing
            indicator: "read" or "deleted"
            value: True to set, False to clear

        This can be used to:
          - Mark messages as read (hide new message notifications)
          - Delete messages remotely
        """
        indicator_id = {"read": 0x00, "deleted": 0x01}.get(indicator)
        if indicator_id is None:
            error(f"Invalid indicator: {indicator} (use 'read' or 'deleted')")
            return False

        info(f"Setting message {handle} {indicator}={value}")
        self.last_capability_limitations = []

        if self._obex_session is not None and str(handle).startswith("/org/bluez/obex/"):
            try:
                # TODO: Hardware-validate Message1.Read/Deleted writes against a
                # real target because BlueZ exposes the properties, but remote
                # MAP servers vary in whether they actually honor the change.
                if indicator == "read":
                    self._obex_session.set_message_read(handle, value)
                else:
                    self._obex_session.set_message_deleted(handle, value)
                success(f"Message {handle} {indicator} set to {value}")
                return True
            except ObexError as exc:
                self.last_capability_limitations = [
                    "BlueZ obexd MAP message-property write path unavailable or rejected; using raw OBEX fallback"
                ]
                warning(f"MAP D-Bus status update failed, using raw OBEX fallback: {exc}")

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        name_bytes = handle.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        type_str = b"x-bt/messageStatus\x00"
        headers += struct.pack(">BH", 0x42, len(type_str) + 3) + type_str

        # App params: StatusIndicator + StatusValue
        app_params = struct.pack(">BBB", 0x17, 0x01, indicator_id)
        app_params += struct.pack(">BBB", 0x18, 0x01, 0x01 if value else 0x00)
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        packet = struct.pack(">BH", 0x82, 3 + len(headers)) + headers
        self.sock.send(packet)

        response = self._recv_response()
        if response and response[0] == OBEX_RESPONSE_SUCCESS:
            success(f"Message {handle} {indicator} set to {value}")
            return True
        error(f"SetMessageStatus failed for {handle}")
        return False

    def enable_notifications(self) -> bool:
        """Register for MAP event notifications (new message, delivery, etc).

        When enabled, the IVI will push events to us via MNS (Message
        Notification Server). Events include:
          - NewMessage: New SMS/MMS received
          - DeliverySuccess: Message delivered
          - SendingSuccess: Message sent
          - MessageDeleted: Message deleted
          - MessageShift: Message moved between folders

        Note: Requires running an MNS server (OBEX server) to receive events.
        This method only sends the registration request.
        """
        info("Registering for MAP event notifications...")

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        type_str = b"x-bt/MAP-NotificationRegistration\x00"
        headers += struct.pack(">BH", 0x42, len(type_str) + 3) + type_str

        # App params: NotificationStatus = ON
        app_params = struct.pack(">BBB", 0x0E, 0x01, 0x01)
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        packet = struct.pack(">BH", 0x82, 3 + len(headers)) + headers
        self.sock.send(packet)

        response = self._recv_response()
        if response and response[0] == OBEX_RESPONSE_SUCCESS:
            success("MAP notifications enabled — listening for events")
            return True
        warning("Notification registration failed — IVI may not support MNS")
        return False

    def _parse_connection_id(self, response: bytes):
        offset = 7
        while offset < len(response):
            hid = response[offset]
            if hid == OBEX_HEADER_CONNECTION_ID:
                self.connection_id = struct.unpack(">I", response[offset + 1:offset + 5])[0]
                return
            elif hid & 0xC0 in (0x00, 0x40):
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif hid & 0xC0 == 0x80:
                offset += 2
            elif hid & 0xC0 == 0xC0:
                offset += 5
            else:
                break


def _unfold_rfc2425_lines(text: str) -> list[str]:
    """Unfold folded vCard/bMessage lines without over-constraining payloads."""
    text = textwrap.dedent(text)
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    unfolded: list[str] = []
    for line in lines:
        if not line:
            unfolded.append("")
            continue
        stripped = line.lstrip(" \t")
        if line[:1] in {" ", "\t"} and unfolded and not _looks_like_property_line(stripped):
            unfolded[-1] += line[1:]
        else:
            unfolded.append(stripped if line[:1] in {" ", "\t"} else line)
    return unfolded


def _looks_like_property_line(line: str) -> bool:
    """Return True when an indented line still looks like a fresh property/block line."""
    if not line:
        return False
    return bool(re.match(r"^(BEGIN|END|[A-Za-z0-9-]+(?:;[^:]*)?):", line))


def _parse_vcard_block(vcard_text: str) -> dict:
    fields: dict[str, object] = {
        "full_name": "",
        "formatted_name": "",
        "name": "",
        "phones": [],
        "emails": [],
        "organization": "",
    }
    for raw_line in _unfold_rfc2425_lines(vcard_text):
        line = raw_line.strip()
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        value = value.strip()
        upper_key = key.upper()
        if upper_key.startswith("FN"):
            fields["formatted_name"] = value
            if not fields["full_name"]:
                fields["full_name"] = value
        elif upper_key.startswith("N"):
            fields["name"] = value
            if not fields["full_name"]:
                fields["full_name"] = value
        elif upper_key.startswith("TEL"):
            fields["phones"].append(value)
        elif upper_key.startswith("EMAIL"):
            fields["emails"].append(value)
        elif upper_key.startswith("ORG"):
            fields["organization"] = value
    return fields


def parse_bmessage(bmsg_text: str) -> dict:
    """Parse a bMessage payload into permissive structured data."""
    result = {
        "version": "",
        "type": "",
        "status": "",
        "folder": "",
        "charset": "",
        "encoding": "",
        "language": "",
        "length": None,
        "sender": "",
        "sender_name": "",
        "sender_email": "",
        "recipient": "",
        "recipient_name": "",
        "recipient_email": "",
        "body": "",
        "body_parts": [],
        "vcards": [],
        "headers": {},
    }

    top_level_keys = {"VERSION", "TYPE", "STATUS", "FOLDER", "CHARSET", "ENCODING", "LANGUAGE", "LENGTH"}
    for raw_line in _unfold_rfc2425_lines(bmsg_text):
        line = raw_line.strip()
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        upper_key = key.upper()
        if upper_key not in top_level_keys:
            continue
        result["headers"][upper_key.lower()] = value
        if upper_key == "VERSION":
            result["version"] = value
        elif upper_key == "TYPE":
            result["type"] = value
        elif upper_key == "STATUS":
            result["status"] = value
        elif upper_key == "FOLDER":
            result["folder"] = value
        elif upper_key == "CHARSET":
            result["charset"] = value
        elif upper_key == "ENCODING":
            result["encoding"] = value
        elif upper_key == "LANGUAGE":
            result["language"] = value
        elif upper_key == "LENGTH":
            try:
                result["length"] = int(value)
            except ValueError:
                result["length"] = value

    vcard_blocks = re.findall(r"BEGIN:VCARD\r?\n(.*?)END:VCARD", bmsg_text, re.DOTALL | re.IGNORECASE)
    parsed_vcards = [_parse_vcard_block(block) for block in vcard_blocks]
    result["vcards"] = parsed_vcards

    if parsed_vcards:
        sender_vcard = parsed_vcards[0]
        sender_phones = sender_vcard.get("phones", [])
        sender_emails = sender_vcard.get("emails", [])
        if sender_phones:
            result["sender"] = str(sender_phones[0])
        if sender_emails:
            result["sender_email"] = str(sender_emails[0])
        result["sender_name"] = str(sender_vcard.get("full_name", "") or "")

    if len(parsed_vcards) > 1:
        recipient_vcard = parsed_vcards[1]
        recipient_phones = recipient_vcard.get("phones", [])
        recipient_emails = recipient_vcard.get("emails", [])
        if recipient_phones:
            result["recipient"] = str(recipient_phones[0])
        if recipient_emails:
            result["recipient_email"] = str(recipient_emails[0])
        result["recipient_name"] = str(recipient_vcard.get("full_name", "") or "")

    body_parts = [
        match.strip()
        for match in re.findall(r"BEGIN:MSG\r?\n(.*?)END:MSG", bmsg_text, re.DOTALL | re.IGNORECASE)
        if match.strip()
    ]
    result["body_parts"] = body_parts
    result["body"] = "\n\n".join(body_parts)

    return result
