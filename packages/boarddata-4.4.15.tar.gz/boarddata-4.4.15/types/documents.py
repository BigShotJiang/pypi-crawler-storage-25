"""Document types."""

from __future__ import annotations

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict


class DocumentListItem(TypedDict):
    id: str
    title: str
    document_type: str
    company_name: str
    publication_date: str | None
    fiscal_year: int | None
    file: str | None
    url: str
    original_url: str


class DocumentDetail(TypedDict):
    """Same shape as list item for documents."""
    id: str
    title: str
    document_type: str
    company_name: str
    publication_date: str | None
    fiscal_year: int | None
    file: str | None
    url: str
    original_url: str


class CreateDocumentPayload(TypedDict):
    title: str
    document_type: str
    publication_date: NotRequired[str]
    fiscal_year: NotRequired[int]
    isin: NotRequired[str]
    language: NotRequired[str]
    url: NotRequired[str]
    original_url: NotRequired[str]


class UpdateDocumentPayload(TypedDict, total=False):
    title: str
    document_type: str
    publication_date: str
    fiscal_year: int
    isin: str
    language: str
    url: str


class PresignedUrlResponse(TypedDict):
    url: str
