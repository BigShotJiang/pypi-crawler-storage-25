"""Tests for AssemblyMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._assemblies import AssemblyMixin
    from boarddata._base import Base

    class TestClient(AssemblyMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateAssembly:
    def test_sends_required_fields(self):
        c = make_client()
        c._request.return_value = {"id": "asm1"}
        c.create_assembly("comp-uuid", "2024-05-15", "OGM", 2024)
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["company"] == "comp-uuid"
        assert payload["assembly_type"] == "OGM"
        assert payload["fiscal_year"] == 2024


class TestListResolutions:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_resolutions(company="uuid1")
        args, _ = c._request.call_args
        assert args == ("GET", "resolutions/")

    def test_forwards_rejected_param(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_resolutions(rejected=True)
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {"rejected": True}

    def test_forwards_narrowly_passed_param(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_resolutions(narrowly_passed=True)
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {"narrowly_passed": True}


class TestCreateAssemblyResolution:
    def test_batch_creates(self):
        c = make_client()
        c._request.return_value = [{"id": "r1"}, {"id": "r2"}]
        data = [
            {"number_or_letter": "1", "resolution_type_id": 1},
            {"number_or_letter": "2", "resolution_type_id": 2},
        ]
        c.create_assembly_resolution("asm-uuid", data)
        args, kwargs = c._request.call_args
        assert args == ("POST", "assemblies/asm-uuid/resolutions/")
        assert len(kwargs["json"]) == 2
