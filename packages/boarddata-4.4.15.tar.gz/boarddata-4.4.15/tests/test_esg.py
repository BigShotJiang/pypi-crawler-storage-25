"""Tests for ESGMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._esg import ESGMixin
    from boarddata._base import Base

    class TestClient(ESGMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateIRO:
    def test_sends_required_fields(self):
        c = make_client()
        c._request.return_value = {"id": "iro1"}
        c.create_iro("comp-uuid", "2024-01-15", "Climate Risk", "E")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["company"] == "comp-uuid"
        assert payload["esg_type"] == "E"
        assert payload["name"] == "Climate Risk"


class TestCreateTransitionPlan:
    def test_sends_nested_children(self):
        c = make_client()
        c._request.return_value = {"id": "tp1"}
        targets = [{"target_name": "Net Zero", "scope": "1+2", "target_year": 2050}]
        c.create_transition_plan("comp-uuid", "2024-01-15", targets=targets)
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["targets"] == targets


class TestListEsgBenchmark:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_esg_benchmark(search="Total")
        args, _ = c._request.call_args
        assert args == ("GET", "companies/benchmark/")


class TestGetEsgBenchmarkStats:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {
            "count": 42,
            "environment": 10,
            "social": 8,
            "governance": 5,
            "total_iros": 23,
        }
        result = c.get_esg_benchmark_stats(
            sectors_include=["Energy"],
            date_from="2024-01-01",
        )
        args, kwargs = c._request.call_args
        assert args == ("GET", "companies/benchmark/stats/")
        assert kwargs["params"] == {
            "sectors_include": ["Energy"],
            "date_from": "2024-01-01",
        }
        assert result["total_iros"] == 23
        assert result["count"] == 42
