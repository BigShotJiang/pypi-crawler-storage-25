"""swim-py: pure-Python SWIM+ membership protocol implementation.

This 0.0.0 release reserves the package name. Implementation is forthcoming.
"""

__version__ = "0.0.0"
