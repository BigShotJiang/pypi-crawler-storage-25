# swim-py

Pure-Python implementation of the SWIM+ membership protocol, designed to be wire-compatible with the Rust [foca](https://github.com/caio/foca) crate via a shared protobuf codec.

**Status: planning / pre-implementation.** This 0.0.0 release reserves the package name on PyPI. The actual implementation is forthcoming.

## Goals

- **Pure Python.** No native dependencies. Ships as a small wheel that pip can install on any Python 3.10+ environment.
- **Codec-agnostic core.** SWIM message types are Python dataclasses; wire encoding is pluggable. A protobuf-based default codec is shipped, designed to be wire-compatible with foca configured to use the same schema.
- **Transport-agnostic core.** I/O is delegated to a Transport interface. An asyncio-UDP default is shipped; users can swap it (TCP framing, in-memory for tests, custom IPC).
- **Discovery-delegated.** Bootstrap peer discovery is a user-supplied interface; the library ships a static-list default and consumers plug in environment-specific implementations (k8s Endpoints, slurm-nodelist, multicast, etc).
- **Application-domain neutral.** The library knows about members, broadcasts, and gossip. Application semantics live entirely in user-supplied broadcast handlers.

## Why

Existing pure-Python SWIM implementations are research-grade or unmaintained. The Rust ecosystem has battle-tested options (foca, memberlist-rs, chitchat) but bundling native code in a Python plugin context (e.g., a vLLM plugin) introduces deployment friction. swim-py fills the gap: a pure-Python SWIM+ implementation suitable for production use, designed for in-process integration into Python-shaped distributed systems.

## License

Apache-2.0. See LICENSE.

## Acknowledgments

Design is foca-inspired: the algorithmic choices and engineering tradeoffs in foca informed this library's architecture. swim-py is a clean-room reimplementation, not a port. The protobuf wire schema is designed for cross-language compatibility with foca configured to use the same codec.
