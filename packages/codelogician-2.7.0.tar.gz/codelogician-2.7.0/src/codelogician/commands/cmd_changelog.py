#
#   Imandra Inc.
#
#   codelogician/commands/cmd_changelog.py
#

from __future__ import annotations

import re
from pathlib import Path
from typing import Annotated

import typer

# Changelog parsing
# ==================

_VERSION_HEADING_RE = re.compile(
    r'^## \[(?P<version>[^\]]+)\]'  # ## [x.y.z] or ## [Unreleased]
)


def _find_changelog() -> Path | None:
    """Locate CHANGELOG.md — bundled in the package, or at the repo root."""
    # Installed package: CHANGELOG.md is force-included next to the package
    pkg_dir = Path(__file__).resolve().parent.parent  # .../codelogician/
    bundled = pkg_dir / 'CHANGELOG.md'
    if bundled.exists():
        return bundled

    # Development: CHANGELOG.md lives at the repository root
    repo_root = pkg_dir.parent.parent  # .../src -> .../repo
    dev = repo_root / 'CHANGELOG.md'
    if dev.exists():
        return dev

    return None


def parse_changelog(text: str) -> list[tuple[str, str]]:
    """Parse *Keep a Changelog* formatted text.

    Return:
        a list of `(version, body)` tuples in document order.
        - `version` is the string inside the brackets (e.g. `"2.6.0"` or
          `"Unreleased"`).
        - `body` is the raw Markdown content under that heading, stripped
           of leading/trailing blank lines.
    """
    sections: list[tuple[str, str]] = []
    current_version: str | None = None
    lines: list[str] = []

    for line in text.splitlines():
        m = _VERSION_HEADING_RE.match(line)
        if m:
            if current_version is not None:
                sections.append((current_version, '\n'.join(lines).strip()))
            current_version = m.group('version')
            lines = []
        elif current_version is not None:
            lines.append(line)

    # flush last section
    if current_version is not None:
        sections.append((current_version, '\n'.join(lines).strip()))

    return sections


def extract_between(
    sections: list[tuple[str, str]],
    since: str,
    until: str | None = None,
) -> list[tuple[str, str]]:
    """Return sections *after* ``since`` up to and including ``until``.

    Both endpoints are matched against version strings (case-insensitive).
    If ``until`` is ``None``, all sections newer than ``since`` are returned.
    """
    versions = [v.lower() for v, _ in sections]
    since_lower = since.lower()
    until_lower = until.lower() if until is not None else None

    if since_lower not in versions:
        return []

    since_idx = versions.index(since_lower)

    if until_lower is not None:
        if until_lower not in versions:
            return []
        until_idx = versions.index(until_lower)
        # versions are in document order (newest first), so until_idx <= since_idx
        return sections[until_idx:since_idx]
    else:
        return sections[:since_idx]


# CLI command
# ===========


def run_changelog_cmd(
    since: Annotated[
        str | None,
        typer.Option(
            help='Show changes after this version (exclusive).',
        ),
    ] = None,
    until: Annotated[
        str | None,
        typer.Option(
            help='Show changes up to and including this version.',
        ),
    ] = None,
) -> None:
    """Show changelog entries, optionally between two versions.

    Arguments:
        if --until without --since: show just that single version
    Raise:
        exit 1 if both --since and ---until are None
    """
    changelog_path = _find_changelog()
    if changelog_path is None:
        typer.echo('Changelog not found.', err=True)
        raise typer.Exit(1)

    sections: list[tuple[str, str]] = parse_changelog(changelog_path.read_text())

    if not sections:
        typer.echo('Changelog is empty.', err=True)
        raise typer.Exit(1)

    if since is not None:
        selected = extract_between(sections, since=since, until=until)
    elif until is not None:
        selected = [(v, body) for v, body in sections if v.lower() == until.lower()]
    else:
        selected = sections

    if not selected:
        typer.echo('No changelog entries found for the specified range.', err=True)
        raise typer.Exit(1)

    for version, body in selected:
        typer.echo(f'## [{version}]')
        if body:
            typer.echo('')
            typer.echo(body)
        typer.echo('')
