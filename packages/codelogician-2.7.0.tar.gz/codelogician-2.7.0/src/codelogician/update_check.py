#
#   Imandra Inc.
#
#   update_check.py - Non-blocking update check against PyPI
#
#
# Behavior:
# ========
#
# version check:
# - force ==> version is fetched from PyPI, cached
# - not force && cache is fresh and valid ==> version is checked against the cache
# - not force && cache is stale or missing ==> version is fetched from PyPI, cached
#
# update message:
# - on latest && force ==> notify(already on latest, guide for re-install)
# - on latest && not force ==> None
# - not (on latest) && latest > current ==> notify(update available)
# - not (on latest) && latest < current ==> warn(cache corrupted)


# pyright: strict
import json
import os
import time
from pathlib import Path
from typing import Any, cast

_CACHE_DIR = (
    Path(os.environ.get('XDG_CACHE_HOME', Path.home() / '.cache')) / 'codelogician'
)
_CACHE_FILE = _CACHE_DIR / 'update-check.json'
_CHECK_INTERVAL = 86400  # 24 hours
_PYPI_URL = 'https://pypi.org/pypi/codelogician/json'
_REQUEST_TIMEOUT = 2  # seconds


def _read_cache() -> dict[str, Any] | None:
    """Return cached data if fresh (within $_CHECK_INTERVAL), None otherwise."""
    try:
        data = json.loads(_CACHE_FILE.read_text())
        if time.time() - data.get('last_check', 0) < _CHECK_INTERVAL:
            return data
    except Exception:
        pass
    return None


def _write_cache(latest_version: str) -> None:
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(
            json.dumps({'last_check': time.time(), 'latest_version': latest_version})
        )
    except Exception:
        pass


def _fetch_latest_version() -> str | None:
    """Get the latest version from PyPI.

    Returns:
        return None if the request fails.
    """
    try:
        from urllib.request import Request, urlopen

        req = Request(_PYPI_URL, headers={'Accept': 'application/json'})
        with urlopen(req, timeout=_REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read())
            return data['info']['version']
    except Exception:
        return None


def _parse_version(v: str) -> tuple[int, ...]:
    """Simple version tuple for comparison, ignoring pre-release suffixes."""
    import re

    match = re.match(r'(\d+(?:\.\d+)*)', v)
    if not match:
        return (0,)
    return tuple(int(x) for x in match.group(1).split('.'))


def check_for_update(force: bool = False) -> tuple[str | None, bool]:
    """
    Checks for update

    Returns:
        A string with the update message if an update is available, otherwise None.
        is_zero_exit_code (bool)
    """
    from codelogician import __version__

    current = __version__

    # Try cache first
    if force:
        latest = _fetch_latest_version()
        # Update cache if latest version is fetched successfully
        if latest is not None:
            _write_cache(latest)
    else:
        cache = _read_cache()
        if cache is None or not isinstance(cache.get('latest_version'), str):
            latest = _fetch_latest_version()
            # Update cache if latest version is fetched successfully
            if latest is not None:
                _write_cache(latest)
        else:
            latest = cache.get('latest_version')
    if latest is None:
        return (
            'Failed to determine latest version (PyPI unreachable and no valid cache)',
            False,
        )
    latest = cast(str, latest)

    parsed_latest = _parse_version(latest)
    parsed_current = _parse_version(current)

    if parsed_latest > parsed_current:
        msg = (
            f'\n  Update available: {current} -> {latest}'
            f'    Run: uv tool upgrade codelogician\n'
        )
        return msg, True
    elif parsed_latest == parsed_current and force:
        msg = (
            f'\n  Already on latest version: {current}'
            f'    Force reinstall: uv tool install codelogician\n'
        )
        return msg, True
    elif parsed_latest == parsed_current and not force:
        # On latest, but not force
        return None, True
    else:
        # Latest < Current
        msg = f'CodeLogician cache corrupted, consider clearing {_CACHE_FILE}'
        return msg, False


def check_for_update_safe(force: bool = False) -> None:
    """Safely (non-blocking) print a notice to if a newer version is available on PyPI.

    - Checks at most once per 24 hours (cached in ~/.cache/codelogician/)
    - Never blocks for more than 2 seconds
    - Silently does nothing on any error
    - Disabled by setting CODELOGICIAN_NO_UPDATE_CHECK=1

    Precedence: env var > `force`

    Args:
        force (bool): if True, cache is skipped and a fresh check against PyPI is always performed.

    Returns:
        None

    Effects:
        io: prints a notice to stdout or stderr if a newer version is available.
    """
    if os.environ.get('CODELOGICIAN_NO_UPDATE_CHECK', '') == '1':
        return

    try:
        msg, is_zero_exit_code = check_for_update(force)
        if msg is not None:
            import typer

            if is_zero_exit_code:
                typer.echo(msg)
            else:
                typer.echo(msg, err=True)

    except Exception:
        pass
