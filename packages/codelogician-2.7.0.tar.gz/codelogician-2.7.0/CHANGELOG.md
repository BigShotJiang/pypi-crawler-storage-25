# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.7.0] - 2026-04-14

- `update` command: prompt for running upgrade script if update is available
- Added: `changelog` command, show changelog entries

## [2.6.0] - 2026-04-01

- Added trace command

## [2.5.0] - 2026-04-01

- Added: goal-state formatting

## [2.4.0] - 2026-03-26

- dependency: bump imandrax-api to v19

## [2.3.2] - 2026-03-25

- gracefully exit if no API key is detected

## [2.3.1] - 2026-03-25

- update help message

## [2.3.0] - 2026-03-24

- TUI: more reactive model screen
- CLI automatic version check
- doc: simplified sub-commands, error-search, JSON interfaces, updated prompts
- bump iml-query and imandrax-codegen for some bug fixes

## [2.2.1] - 2026-03-13

- Remove `chromadb` in dependency

## [2.2.0] - 2026-03-13

- Make `imandrax-codegen` an optional dependency

## [2.1.0] - 2026-02-27

### Added

- Add multi-file support for `eval` command

## [2.0.3] - 2026-02-25

- Minor improvements: more specific debug environment variable; better help message; API key fallback

## [2.0.2] - 2026-01-27

### Fixed

- Removed matplotlib as a dependency

## [2.0.1] - 2026-02-13

### Added

- Improved reporting of Imandra API key errors from command line tools.

### Fixed

- Missing/invalid API key handling

## [2.0.0b11] - 2026-01-27

### Added

- Re-enabled verification goal and region decomposition analysis as separate tasks

### Fixed

- Improved presentation of formalization errors in models view
- Fixed switching to disk source in overview screen
- Internal reorganization
- Eval command JSON serialization errors

## [2.0.0b10] - 2026-01-16

## [2.0.0b9] - 2026-01-16

- Minor fixes

## [2.0.0b8] - 2026-01-13

- Various internal improvements and dependency upgrades

## [2.0.0b7] - 2026-01-07

### Fixed

- langgraph-sdk>=0.3 adds id field in streaming output, causing tuple unpacking error
- nested async event loop in eval command

## [2.0.0b6] - 2026-01-06

- fixes

## [2.0.0b5] - 2025-12-11

### Fixed

- Slow loading of TUI help screen

### Added

- TUI help screen documentation on XState sample applications
- Improved reporting of formalization errors in TUI

## [2.0.0b4] - 2025-12-05

### Fixed

- Crashes in TUI if the server switches to a new metamodel
- Code views in TUI 'Models' screen now scroll horizontally if the code is too wide to fit

### Added

- TUI help screen documentation on region decomposition and verification goals
- Command line interface Code Logician tool
- Improved status line information in TUI

## [2.0.0b3] - 2025-11-25

### Fixed

- `codelogician eval check --json` serialization error

## [2.0.0b2] - 2025-11-25

### Added

- enhanced `eval` subcommand:
  - added support for listing and evaluating verification goals and region decomposition requests in IML files
  - added native JSON output support
