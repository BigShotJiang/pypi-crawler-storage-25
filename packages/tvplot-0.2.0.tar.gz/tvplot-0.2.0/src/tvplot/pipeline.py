"""Main pipeline: get_plotlines() orchestrates Pass 0 → Pass 1 → Pass 2 → Pass 3 → Pass 4 → post-processing."""

from __future__ import annotations

import logging
import re

from tvplot.callbacks import PipelineCallback
from tvplot.llm import LLMConfig, UsageStats, usage
from tvplot.models import CastMember, EpisodeBreakdown, Plotline, TVPlotlinesResult, SeriesContext
from tvplot.pass0 import detect_context
from tvplot.pass1 import extract_plotlines
from tvplot.pass2 import assign_events, assign_events_batch, assign_events_parallel
from tvplot.pass3 import review_plotlines
from tvplot.pass4 import assign_arc_functions
from tvplot.postprocess import assign_orphan_events, compute_ranks, compute_span, validate_ranks
from tvplot.verdicts import apply_verdicts

logger = logging.getLogger(__name__)

_EPISODE_ID_RE = re.compile(r"^S\d{2}E\d{2}$")


def _warn_rank_limits(
    plotlines: list[Plotline], is_ensemble: bool, n_episodes: int,
) -> list[Plotline]:
    """Log warnings if plotline counts exceed expected limits. No mutations."""
    if is_ensemble:
        max_total = 9 if n_episodes >= 9 else 7
    else:
        max_total = 7 if n_episodes >= 9 else 5

    total = len([p for p in plotlines if p.computed_rank])
    if total > max_total:
        logger.warning("Plotline count %d exceeds expected max %d", total, max_total)

    return plotlines


def _fire(callback: PipelineCallback | None, method: str, *args) -> None:
    """Call a callback method, swallowing exceptions."""
    if callback is None:
        return
    try:
        getattr(callback, method)(*args)
    except Exception:
        logger.exception("Callback %s raised", method)


def get_plotlines(
    show: str,
    season: int,
    episodes: dict[str, str],
    *,
    prior: TVPlotlinesResult | None = None,
    context: SeriesContext | None = None,
    cast: list[CastMember] | None = None,
    plotlines: list[Plotline] | None = None,
    breakdowns: list[EpisodeBreakdown] | None = None,
    suggested_plotlines: list[dict] | None = None,
    llm_provider: str = "anthropic",
    model: str | None = None,
    base_url: str | None = None,
    system: str = "hollywood",
    skip_review: bool = False,
    pass2_mode: str = "batch",
    batch_id: str | None = None,
    callback: PipelineCallback | None = None,
) -> TVPlotlinesResult:
    """Extract plotlines from TV series synopses.

    Args:
        show: Series title.
        season: Season number.
        episodes: Dict mapping episode IDs (e.g. "S01E01") to synopsis texts.
            Keys must match S{dd}E{dd} format and the season number must match
            the ``season`` parameter.
        prior: TVPlotlinesResult from the previous season. When provided and
            context is None, reuses prior.context to skip Pass 0. Also
            passes prior cast and plotlines to Pass 1 for continuity.
            Incompatible with anthology format (anthology seasons are
            independent by definition).
        context: If provided, skip Pass 0 (auto-detection).
        cast: If provided with plotlines, skip Pass 1.
        plotlines: If provided with cast, skip Pass 1.
        breakdowns: If provided, skip Pass 2.
        llm_provider: "anthropic" or "openai".
        model: Specific model name, or provider default.
        skip_review: If True, skip Pass 3 (structural review).
        pass2_mode: How to run Pass 2:
            "parallel" — all episodes at once via async (fast, default)
            "batch" — Anthropic batch API (50% cheaper, slower)
            "sequential" — one episode at a time (simple, for debugging)
        batch_id: Resume a batch by ID (only with pass2_mode="batch").
        callback: PipelineCallback subclass for progress notifications.

    Returns:
        TVPlotlinesResult with context, cast, plotlines, and episode breakdowns.
    """
    if system == "narratology":
        from tvplot.narratology import run_narratology
        nconfig = LLMConfig(
            provider=llm_provider, model=model, base_url=base_url, system=system,
        )
        return run_narratology(
            show=show, season=season, episodes=episodes,
            config=nconfig, callback=callback, skip_review=skip_review,
        )
    config = LLMConfig(provider=llm_provider, model=model, base_url=base_url, system=system)

    # Validate episode keys and convert to sorted (id, text) pairs
    season_prefix = f"S{season:02d}"
    for key in episodes:
        if not _EPISODE_ID_RE.match(key):
            raise ValueError(
                f"Episode key {key!r} must match S{{dd}}E{{dd}} format (e.g. 'S01E01')"
            )
        if not key.startswith(season_prefix):
            raise ValueError(
                f"Episode key {key!r} does not match season={season} "
                f"(expected prefix {season_prefix!r})"
            )
    episode_pairs = [(eid, episodes[eid]) for eid in sorted(episodes)]
    episode_ids = [eid for eid, _ in episode_pairs]
    episode_texts = [text for _, text in episode_pairs]

    # Validate resume parameters
    if (cast is None) != (plotlines is None):
        raise ValueError("cast and plotlines must be provided together (or both omitted)")

    if breakdowns is not None and len(breakdowns) != len(episode_ids):
        raise ValueError(
            f"breakdowns length ({len(breakdowns)}) != episodes length ({len(episode_ids)})"
        )

    if batch_id is not None and pass2_mode != "batch":
        raise ValueError(f"batch_id requires pass2_mode='batch', got {pass2_mode!r}")

    # Validate prior parameter
    if prior is not None:
        prior_context = context or prior.context
        if prior_context.is_anthology:
            raise ValueError(
                "prior is not supported for anthology format "
                "(anthology seasons are independent by definition)"
            )
        if context is None:
            context = prior.context

    # Reset usage tracker for this run
    global usage
    usage.__init__()

    # Pass 0: detect context (skip if provided)
    if context is None:
        context = detect_context(
            show, season, episode_pairs[:3], config=config,
            suggested_plotlines=suggested_plotlines,
        )
    _fire(callback, "on_pass0_complete", context)

    # Pass 1: extract cast and plotlines from all synopses
    if cast is None:
        cast, plotlines = extract_plotlines(
            show, season, context, episode_pairs,
            prior_cast=prior.cast if prior else None,
            prior_plotlines=prior.plotlines if prior else None,
            suggested_plotlines=suggested_plotlines,
            config=config,
        )
    _fire(callback, "on_pass1_complete", cast, plotlines)

    # Pass 2: assign events for each episode
    if breakdowns is None:
        if pass2_mode == "parallel":
            breakdowns = assign_events_parallel(
                show, season, episode_pairs, context, cast, plotlines,
                config=config,
            )
        elif pass2_mode == "batch":
            breakdowns = assign_events_batch(
                show, season, episode_pairs, context, cast, plotlines,
                config=config,
                batch_id=batch_id,
                on_batch_submitted=lambda bid: _fire(callback, "on_batch_submitted", bid),
            )
        elif pass2_mode == "sequential":
            breakdowns = []
            for i, (episode_id, synopsis) in enumerate(episode_pairs):
                breakdown = assign_events(
                    show, season, episode_id, synopsis, context, cast, plotlines,
                    config=config,
                )
                breakdowns.append(breakdown)
                _fire(callback, "on_episode_complete", i, breakdown)
        else:
            raise ValueError(f"Unknown pass2_mode: {pass2_mode!r}")

    _fire(callback, "on_pass2_complete", breakdowns)

    # Post-processing: assign orphan events, compute span/rank, validate
    assign_orphan_events(plotlines, breakdowns)
    compute_span(plotlines, breakdowns)
    compute_ranks(plotlines, breakdowns, context)
    flags = validate_ranks(plotlines, breakdowns)
    _warn_rank_limits(plotlines, context.is_ensemble, len(episode_ids))

    # Pass 3: structural review (with diagnostic flags as context)
    if not skip_review:
        pass3_result = review_plotlines(
            show, season, context, cast, plotlines, breakdowns,
            diagnostics=flags or None,
            config=config,
        )
        verdicts = pass3_result["verdicts"]
        llm_ranks = pass3_result.get("ranks", {})

        _fire(callback, "on_pass3_complete", verdicts)
        if verdicts:
            plotlines = apply_verdicts(
                verdicts, plotlines, breakdowns,
                series_format=context.format,
            )
            # Recompute span after verdicts (ranks are not recomputed —
            # Pass 3 changes go into reviewed_rank, computed_rank stays)
            compute_span(plotlines, breakdowns)

        # Compare LLM-assigned ranks with computed_rank
        for plotline in plotlines:
            llm_rank = llm_ranks.get(plotline.id)
            if llm_rank and llm_rank != plotline.computed_rank:
                plotline.reviewed_rank = llm_rank

        # Pass 4: assign arc functions to all events
        count = assign_arc_functions(
            show, season, context, cast, plotlines, breakdowns,
            config=config,
        )
        _fire(callback, "on_pass4_complete", count)

    result = TVPlotlinesResult(
        context=context,
        cast=cast,
        plotlines=plotlines,
        episodes=breakdowns,
    )
    result.usage = usage.summary(config.resolved_model)
    return result
