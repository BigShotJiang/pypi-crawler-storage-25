"""
Photoscanpy v5 - Aplicación de escaneo moderna para Windows
Con detección automática y recorte de fotografías
Interfaz rediseñada con CustomTkinter

Requiere: pip install Pillow pywin32 opencv-python numpy customtkinter
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import os
from datetime import datetime
from pathlib import Path

try:
    from PIL import Image, ImageTk, ImageOps
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

# ── Tema CustomTkinter ─────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# ── Paleta monocromática de alto contraste ────────────────────────────────────
BG_ROOT      = "#0a0a0a"   # negro casi puro
BG_SIDEBAR   = "#111111"   # negro sidebar
BG_CARD      = "#1a1a1a"   # tarjeta
BG_PANEL     = "#141414"   # panel foto
BORDER_DIM   = "#2a2a2a"   # bordes suaves
BORDER_MED   = "#3a3a3a"   # bordes medios
BORDER_HI    = "#555555"   # bordes destacados

TEXT_WHITE   = "#f5f5f5"
TEXT_GREY    = "#aaaaaa"
TEXT_DIM     = "#555555"

ACCENT_WHITE = "#ffffff"
ACCENT_GREY  = "#888888"
BTN_SCAN_BG  = "#ffffff"
BTN_SCAN_FG  = "#000000"
SUCCESS      = "#cccccc"
WARNING      = "#999999"

FONT_TITLE   = ("Segoe UI", 15, "bold")
FONT_HEAD    = ("Segoe UI", 10, "bold")
FONT_BODY    = ("Segoe UI", 10)
FONT_SMALL   = ("Segoe UI", 9)
FONT_MICRO   = ("Segoe UI", 8)
FONT_MONO    = ("Consolas", 9)
FONT_BTN     = ("Segoe UI", 12, "bold")
FONT_SEC     = ("Segoe UI", 7, "bold")


# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-RECORTE
# ══════════════════════════════════════════════════════════════════════════════

def pil_to_cv2(pil_img):
    arr = np.array(pil_img.convert("RGB"))
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

def cv2_to_pil(cv2_img):
    rgb = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)

def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect

def four_point_transform(image, pts):
    rect = order_points(pts)
    (tl, tr, br, bl) = rect
    widthA  = np.linalg.norm(br - bl)
    widthB  = np.linalg.norm(tr - tl)
    maxW    = max(int(widthA), int(widthB))
    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxH    = max(int(heightA), int(heightB))
    dst = np.array([[0,0],[maxW-1,0],[maxW-1,maxH-1],[0,maxH-1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(image, M, (maxW, maxH))

def auto_crop_photo(pil_img, margin_px=0):
    if not CV2_AVAILABLE:
        return pil_img, "OpenCV no disponible — recorte manual necesario"
    cv_img = pil_to_cv2(pil_img)
    h, w   = cv_img.shape[:2]
    gray  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return pil_img, "No se encontró ningún objeto — imagen original"
    total_area = h * w
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
    best_cnt = None
    for cnt in cnts:
        area = cv2.contourArea(cnt)
        if area < total_area * 0.05: break
        if area > total_area * 0.92: continue
        best_cnt = cnt
        break
    if best_cnt is None:
        best_cnt = cnts[0]
    peri   = cv2.arcLength(best_cnt, True)
    approx = cv2.approxPolyDP(best_cnt, 0.02 * peri, True)
    if len(approx) == 4:
        pts     = approx.reshape(4, 2).astype("float32")
        cropped = four_point_transform(cv_img, pts)
        method  = "corrección de perspectiva"
    else:
        x, y, bw, bh = cv2.boundingRect(best_cnt)
        x1 = max(0, x - margin_px); y1 = max(0, y - margin_px)
        x2 = min(w, x + bw + margin_px); y2 = min(h, y + bh + margin_px)
        cropped = cv_img[y1:y2, x1:x2]
        method  = "bounding-box"
    result = cv2_to_pil(cropped)
    rw, rh = result.size
    return result, f"✓ Foto recortada ({rw}×{rh}px) — {method}"


def auto_crop_n_photos(pil_img, n_photos=1, margin_px=0):
    """
    Detecta hasta n_photos fotografías dentro del folio y las devuelve recortadas.
    Devuelve (lista_imgs, msg) — la lista puede tener menos de n_photos elementos.
    """
    if not CV2_AVAILABLE:
        return [pil_img], "OpenCV no disponible — recorte manual necesario"

    cv_img = pil_to_cv2(pil_img)
    h, w   = cv_img.shape[:2]
    total_area = h * w

    gray  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return [pil_img], "No se encontró ningún objeto — imagen original"

    # Fracción máxima por foto según cuántas esperamos
    max_frac = 0.92 if n_photos == 1 else (0.70 if n_photos == 2 else 0.50)
    valid = [c for c in cnts
             if total_area * 0.04 < cv2.contourArea(c) < total_area * max_frac]
    valid.sort(key=cv2.contourArea, reverse=True)

    def crop_one(cnt):
        peri   = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2).astype("float32")
            return cv2_to_pil(four_point_transform(cv_img, pts))
        x, y, bw, bh = cv2.boundingRect(cnt)
        x1 = max(0, x - margin_px); y1 = max(0, y - margin_px)
        x2 = min(w, x + bw + margin_px); y2 = min(h, y + bh + margin_px)
        return cv2_to_pil(cv_img[y1:y2, x1:x2])

    imgs = [crop_one(valid[i]) for i in range(min(n_photos, len(valid)))]
    if not imgs:
        imgs = [pil_img]

    n = len(imgs)
    msg = f"✓ {n} foto{'s' if n>1 else ''} detectada{'s' if n>1 else ''} y recortada{'s' if n>1 else ''}"
    return imgs, msg


# ══════════════════════════════════════════════════════════════════════════════
#  WIA
# ══════════════════════════════════════════════════════════════════════════════

def get_wia_scanners():
    try:
        import win32com.client, pythoncom
        pythoncom.CoInitialize()
        try:
            wia = win32com.client.Dispatch("WIA.DeviceManager")
            devices = []
            for info in wia.DeviceInfos:
                if info.Type == 1:
                    devices.append((info.Properties("Name").Value, info.DeviceID))
            return devices
        finally:
            pythoncom.CoUninitialize()
    except Exception:
        return []

def scan_with_wia(device_id=None, dpi=300, color_mode="Color"):
    import win32com.client, tempfile, pythoncom
    pythoncom.CoInitialize()
    try:
        wia = win32com.client.Dispatch("WIA.DeviceManager")
        device_info = None
        for info in wia.DeviceInfos:
            if info.Type == 1:
                if device_id is None or info.DeviceID == device_id:
                    device_info = info
                    break
        if device_info is None:
            raise RuntimeError("No se encontró ningún escáner WIA conectado.")
        device = device_info.Connect()
        item   = device.Items(1)
        color_map = {"Color": 4, "Grayscale": 2, "BlackWhite": 1}
        def set_prop(it, pid, val):
            try: it.Properties(pid).Value = val
            except Exception: pass
        set_prop(item, 6147, dpi)
        set_prop(item, 6148, dpi)
        set_prop(item, 4103, color_map.get(color_mode, 4))
        img_file = item.Transfer("{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}")
        tmp = tempfile.mktemp(suffix=".png")
        img_file.SaveFile(tmp)
        pil_img = Image.open(tmp).copy()
        os.remove(tmp)
        return pil_img
    finally:
        pythoncom.CoUninitialize()


# ══════════════════════════════════════════════════════════════════════════════
#  TOOLTIP
# ══════════════════════════════════════════════════════════════════════════════

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget; self.text = text; self.tip = None
        widget.bind("<Enter>", self.show); widget.bind("<Leave>", self.hide)
    def show(self, _=None):
        x = self.widget.winfo_rootx() + 30
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self.tip, text=self.text, bg="#222222", fg=TEXT_WHITE,
                 font=FONT_SMALL, padx=8, pady=4, relief="flat").pack()
    def hide(self, _=None):
        if self.tip: self.tip.destroy(); self.tip = None


# ══════════════════════════════════════════════════════════════════════════════
#  APP
# ══════════════════════════════════════════════════════════════════════════════

class EscanApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Photoscanpy")
        self.geometry("1400x800")
        self.minsize(1100, 640)
        self.configure(fg_color=BG_ROOT)

        # Estado
        self.scanned_raw  = None
        self.photos       = [None, None, None]   # hasta 3 fotos
        self.tk_images    = [None, None, None]
        self.zoom_levels  = [1.0,  1.0,  1.0]
        self.scan_history = []
        self.history_idx  = -1
        self.scanner_list = []
        self.n_photos_var = tk.IntVar(value=1)   # cuántas fotos espera el usuario

        # Variables de escaneo
        self.scan_var_dpi      = tk.IntVar(value=300)
        self.scan_var_color    = tk.StringVar(value="Color")
        self.scan_var_device   = tk.StringVar(value="")
        self.scan_var_autocrop = tk.BooleanVar(value=True)
        self.status_text       = tk.StringVar(value="Listo para escanear")

        if not PIL_AVAILABLE:
            messagebox.showerror("Error", "Instala Pillow:\npip install Pillow")
            self.destroy(); return

        self._build_ui()
        self._refresh_scanners()
        self._animate_dot()

    # ── UI principal ──────────────────────────────────────────────────────────
    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._set_icon()
        self._build_sidebar()
        self._build_main()
        self._build_statusbar()

    def _set_icon(self):
        """Carga logo.png o logo.ico como icono de ventana."""
        icon_paths = [
            Path(__file__).parent / "logo.ico",
            Path(__file__).parent / "logo.png",
        ]
        for p in icon_paths:
            if p.exists():
                try:
                    img = Image.open(p).convert("RGBA")
                    sizes = []
                    for s in (256, 64, 32, 16):
                        sizes.append(ImageTk.PhotoImage(
                            img.resize((s, s), Image.LANCZOS)))
                    self._icon_refs = sizes
                    self.iconphoto(True, *sizes)
                    break
                except Exception:
                    pass

    # ── Sidebar ───────────────────────────────────────────────────────────────
    def _build_sidebar(self):
        # Contenedor fijo que ocupa toda la columna izquierda
        sb_outer = ctk.CTkFrame(self, width=272, corner_radius=0,
                                fg_color=BG_SIDEBAR, border_width=0)
        sb_outer.grid(row=0, column=0, sticky="nsew")
        sb_outer.grid_propagate(False)
        sb_outer.columnconfigure(0, weight=1)
        sb_outer.rowconfigure(1, weight=1)   # el scroll ocupa el espacio central

        # ── Cabecera fija (no se desplaza) ──────────────────────────────────
        header = ctk.CTkFrame(sb_outer, fg_color=BG_SIDEBAR, corner_radius=0)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        logo_frame = ctk.CTkFrame(header, fg_color="transparent")
        logo_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=(20, 14))
        logo_frame.columnconfigure(0, weight=1)

        ctk.CTkLabel(logo_frame, text="PHOTOSCANPY",
                     font=ctk.CTkFont("Segoe UI", 16, "bold"),
                     text_color=TEXT_WHITE, anchor="w"
                     ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(logo_frame, text="v5.0  ·  Escáner inteligente",
                     font=ctk.CTkFont("Segoe UI", 8),
                     text_color=TEXT_DIM, anchor="w"
                     ).grid(row=1, column=0, sticky="w")

        ctk.CTkFrame(header, fg_color=BORDER_DIM, height=1,
                     corner_radius=0).grid(row=1, column=0, sticky="ew",
                                           padx=16, pady=(0, 0))

        # ── Zona con scroll (todo el contenido de ajustes) ───────────────────
        sb = ctk.CTkScrollableFrame(
            sb_outer,
            fg_color=BG_SIDEBAR,
            scrollbar_fg_color=BG_SIDEBAR,
            scrollbar_button_color=BORDER_MED,
            scrollbar_button_hover_color=BORDER_HI,
            corner_radius=0)
        sb.grid(row=1, column=0, sticky="nsew")
        sb.columnconfigure(0, weight=1)

        # ── Pie fijo: botón ESCANEAR + historial ─────────────────────────────
        footer = ctk.CTkFrame(sb_outer, fg_color=BG_SIDEBAR, corner_radius=0)
        footer.grid(row=2, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)

        ctk.CTkFrame(footer, fg_color=BORDER_DIM, height=1,
                     corner_radius=0).grid(row=0, column=0, sticky="ew",
                                           padx=16, pady=(0, 8))

        self.scan_btn = ctk.CTkButton(
            footer, text="▶  ESCANEAR",
            height=48, corner_radius=6,
            fg_color=BTN_SCAN_BG, hover_color="#e0e0e0",
            text_color=BTN_SCAN_FG,
            font=ctk.CTkFont("Segoe UI", 13, "bold"),
            command=self._start_scan)
        self.scan_btn.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 8))

        self._sec_label(footer, 2, "HISTORIAL")
        hf = ctk.CTkFrame(footer, fg_color="transparent")
        hf.grid(row=3, column=0, sticky="ew", padx=16, pady=(0, 16))
        hf.columnconfigure((0, 1), weight=1)
        for col, (lbl, cmd) in enumerate([
                ("← Anterior", self._history_prev),
                ("Siguiente →", self._history_next)]):
            ctk.CTkButton(
                hf, text=lbl, height=30, corner_radius=4,
                fg_color=BG_CARD, hover_color=BORDER_MED,
                text_color=TEXT_GREY, border_width=1,
                border_color=BORDER_DIM,
                font=ctk.CTkFont("Segoe UI", 9),
                command=cmd
            ).grid(row=0, column=col,
                   padx=(0, 3) if col == 0 else (3, 0), sticky="ew")

        # ════════════════════════════════════════════════════════════════════
        #  Contenido del scroll  (igual que antes, pero padre = sb)
        # ════════════════════════════════════════════════════════════════════
        r = 0

        # ── Dispositivo ──
        self._sec_label(sb, r, "DISPOSITIVO"); r += 1

        self.device_combo = ctk.CTkComboBox(
            sb, variable=self.scan_var_device, state="readonly",
            fg_color=BG_CARD, border_color=BORDER_MED,
            button_color=BORDER_MED, button_hover_color=BORDER_HI,
            text_color=TEXT_WHITE, dropdown_fg_color=BG_CARD,
            dropdown_text_color=TEXT_WHITE,
            font=ctk.CTkFont("Segoe UI", 9), values=[])
        self.device_combo.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 4))
        r += 1

        ctk.CTkButton(sb, text="↻  Actualizar lista",
                      height=30, corner_radius=4,
                      fg_color=BG_CARD, hover_color=BORDER_MED,
                      text_color=TEXT_GREY, border_width=1,
                      border_color=BORDER_DIM,
                      font=ctk.CTkFont("Segoe UI", 9),
                      command=self._refresh_scanners
                      ).grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 12))
        r += 1

        self._hsep(sb, r); r += 1

        # ── Número de fotos ──
        self._sec_label(sb, r, "NÚMERO DE FOTOS"); r += 1

        nf_frame = ctk.CTkFrame(sb, fg_color="transparent")
        nf_frame.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 4))
        nf_frame.columnconfigure((0, 1, 2), weight=1)

        for i, n in enumerate([1, 2, 3]):
            ctk.CTkRadioButton(
                nf_frame, text=str(n),
                variable=self.n_photos_var, value=n,
                fg_color=TEXT_WHITE, hover_color=ACCENT_GREY,
                border_color=BORDER_HI,
                text_color=TEXT_WHITE,
                font=ctk.CTkFont("Segoe UI", 11, "bold")
            ).grid(row=0, column=i, padx=4, sticky="w")
        r += 1

        desc_texts = {1: "1 foto en el cristal",
                      2: "2 fotos en el cristal",
                      3: "3 fotos en el cristal"}
        self.nf_desc = ctk.CTkLabel(sb, text="1 foto en el cristal",
                                    font=ctk.CTkFont("Segoe UI", 8),
                                    text_color=TEXT_DIM, anchor="w")
        self.nf_desc.grid(row=r, column=0, sticky="w", padx=20, pady=(0, 10))
        r += 1

        def _update_desc(*_):
            n = self.n_photos_var.get()
            self.nf_desc.configure(text=desc_texts[n])
            self._rebuild_photo_panels()
        self.n_photos_var.trace_add("write", _update_desc)

        self._hsep(sb, r); r += 1

        # ── Resolución ──
        self._sec_label(sb, r, "RESOLUCIÓN (DPI)"); r += 1

        dpi_frame = ctk.CTkFrame(sb, fg_color="transparent")
        dpi_frame.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 10))
        dpi_frame.columnconfigure((0, 1, 2), weight=1)

        for i, d in enumerate([150, 300, 600]):
            ctk.CTkRadioButton(
                dpi_frame, text=str(d),
                variable=self.scan_var_dpi, value=d,
                fg_color=TEXT_WHITE, hover_color=ACCENT_GREY,
                border_color=BORDER_HI,
                text_color=TEXT_WHITE,
                font=ctk.CTkFont("Segoe UI", 10)
            ).grid(row=0, column=i, padx=2, sticky="w")
        r += 1

        # ── Modo de color ──
        self._sec_label(sb, r, "MODO DE COLOR"); r += 1

        for mode, lbl in [("Color","  Color"), ("Grayscale","  Escala de grises"),
                           ("BlackWhite","  Blanco y negro")]:
            ctk.CTkRadioButton(
                sb, text=lbl, variable=self.scan_var_color, value=mode,
                fg_color=TEXT_WHITE, hover_color=ACCENT_GREY,
                border_color=BORDER_HI, text_color=TEXT_WHITE,
                font=ctk.CTkFont("Segoe UI", 9)
            ).grid(row=r, column=0, sticky="w", padx=20, pady=2)
            r += 1

        self._hsep(sb, r); r += 1

        # ── Auto-recorte ──
        self._sec_label(sb, r, "✂  AUTO-RECORTE"); r += 1

        crop_card = ctk.CTkFrame(sb, fg_color=BG_CARD, corner_radius=6,
                                 border_width=1, border_color=BORDER_DIM)
        crop_card.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 6))
        crop_card.columnconfigure(0, weight=1)
        r += 1

        toggle_row = ctk.CTkFrame(crop_card, fg_color="transparent")
        toggle_row.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        toggle_row.columnconfigure(0, weight=1)

        ctk.CTkLabel(toggle_row, text="Recorte automático al escanear",
                     font=ctk.CTkFont("Segoe UI", 9),
                     text_color=TEXT_WHITE, anchor="w"
                     ).grid(row=0, column=0, sticky="w")

        ctk.CTkSwitch(toggle_row, text="", variable=self.scan_var_autocrop,
                      onvalue=True, offvalue=False,
                      progress_color=TEXT_WHITE, button_color=BG_ROOT,
                      button_hover_color=ACCENT_GREY,
                      command=self._on_crop_toggle
                      ).grid(row=0, column=1, padx=4)

        ctk.CTkLabel(crop_card,
                     text="Detecta la foto en el folio,\n"
                          "corrige perspectiva y recorta\n"
                          "automáticamente.",
                     font=ctk.CTkFont("Segoe UI", 8),
                     text_color=TEXT_DIM, anchor="w", justify="left"
                     ).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 8))

        # Botones recorte manual / restaurar
        self.crop_now_btn = ctk.CTkButton(
            sb, text="✂  Recortar ahora",
            height=32, corner_radius=4,
            fg_color=BORDER_HI, hover_color=ACCENT_GREY,
            text_color=TEXT_WHITE, border_width=0,
            font=ctk.CTkFont("Segoe UI", 9),
            command=self._manual_crop, state="disabled")
        self.crop_now_btn.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 4))
        r += 1

        self.restore_btn = ctk.CTkButton(
            sb, text="↩  Restaurar original",
            height=32, corner_radius=4,
            fg_color=BG_CARD, hover_color=BORDER_MED,
            text_color=TEXT_GREY, border_width=1,
            border_color=BORDER_DIM,
            font=ctk.CTkFont("Segoe UI", 9),
            command=self._restore_original, state="disabled")
        self.restore_btn.grid(row=r, column=0, sticky="ew", padx=16, pady=(0, 16))
        r += 1

    # ── Main area ─────────────────────────────────────────────────────────────
    def _build_main(self):
        self.main_frame = ctk.CTkFrame(self, fg_color=BG_ROOT, corner_radius=0)
        self.main_frame.grid(row=0, column=1, sticky="nsew")
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        # Toolbar
        self._build_toolbar()
        # Contenedor de paneles de foto (dinámico)
        self.panels_frame = ctk.CTkFrame(self.main_frame, fg_color=BG_ROOT,
                                         corner_radius=0)
        self.panels_frame.grid(row=1, column=0, sticky="nsew",
                               padx=12, pady=(0, 8))
        self._build_photo_panels()

    def _build_toolbar(self):
        tb = ctk.CTkFrame(self.main_frame, fg_color=BG_CARD, corner_radius=0,
                          height=44, border_width=0)
        tb.grid(row=0, column=0, sticky="ew")

        # Zoom
        ctk.CTkLabel(tb, text="Zoom", font=ctk.CTkFont("Segoe UI", 9),
                     text_color=TEXT_DIM).pack(side="left", padx=(16, 4))

        def tb_btn(text, cmd, tip=None):
            b = ctk.CTkButton(tb, text=text, width=34, height=28,
                              corner_radius=4, fg_color="transparent",
                              hover_color=BORDER_MED, text_color=TEXT_GREY,
                              border_width=1, border_color=BORDER_DIM,
                              font=ctk.CTkFont("Segoe UI", 11),
                              command=cmd)
            b.pack(side="left", padx=2, pady=7)
            if tip: Tooltip(b, tip)
            return b

        tb_btn("−", self._zoom_out)
        self.zoom_label = ctk.CTkLabel(tb, text="100%",
                                       font=ctk.CTkFont("Consolas", 9),
                                       text_color=TEXT_WHITE, width=46)
        self.zoom_label.pack(side="left")
        tb_btn("+", self._zoom_in)
        tb_btn("⊡ Ajustar", self._zoom_fit)

        # Separador
        ctk.CTkFrame(tb, fg_color=BORDER_DIM, width=1,
                     height=24).pack(side="left", padx=12, pady=10)

        tb_btn("↺", lambda: self._rotate(-90), "Rotar izquierda 90°")
        tb_btn("↻", lambda: self._rotate(90),  "Rotar derecha 90°")

    # ── Paneles de foto (se reconstruyen al cambiar n_photos) ─────────────────
    def _build_photo_panels(self):
        n = self.n_photos_var.get()
        pf = self.panels_frame

        for widget in pf.winfo_children():
            widget.destroy()

        self.canvases   = []
        self.info_labels = []
        self.save_btns  = []

        for i in range(n):
            pf.columnconfigure(i, weight=1)
        pf.rowconfigure(0, weight=1)

        for i in range(n):
            panel = ctk.CTkFrame(pf, fg_color=BG_PANEL, corner_radius=6,
                                 border_width=1, border_color=BORDER_DIM)
            panel.grid(row=0, column=i, sticky="nsew",
                       padx=(0 if i == 0 else 6, 0), pady=0)
            panel.columnconfigure(0, weight=1)
            panel.rowconfigure(1, weight=1)

            # Cabecera del panel
            hdr = ctk.CTkFrame(panel, fg_color=BG_CARD, corner_radius=0,
                               height=30, border_width=0)
            hdr.grid(row=0, column=0, columnspan=2, sticky="ew")
            hdr.columnconfigure(0, weight=1)

            ctk.CTkLabel(hdr,
                         text=f"  FOTO {i+1}",
                         font=ctk.CTkFont("Segoe UI", 9, "bold"),
                         text_color=TEXT_WHITE, anchor="w"
                         ).grid(row=0, column=0, sticky="w", padx=4)

            info = ctk.CTkLabel(hdr, text="Sin imagen",
                                font=ctk.CTkFont("Segoe UI", 8),
                                text_color=TEXT_DIM, anchor="e")
            info.grid(row=0, column=1, sticky="e", padx=8)
            self.info_labels.append(info)

            # Canvas
            cv = tk.Canvas(panel, bg="#0d0d0d",
                           highlightthickness=0, cursor="crosshair")
            cv.grid(row=1, column=0, sticky="nsew")
            vb = tk.Scrollbar(panel, orient="vertical", command=cv.yview,
                              bg=BG_CARD, troughcolor=BG_PANEL,
                              activebackground=BORDER_HI, bd=0)
            vb.grid(row=1, column=1, sticky="ns")
            hb = tk.Scrollbar(panel, orient="horizontal", command=cv.xview,
                              bg=BG_CARD, troughcolor=BG_PANEL,
                              activebackground=BORDER_HI, bd=0)
            hb.grid(row=2, column=0, sticky="ew")
            cv.configure(yscrollcommand=vb.set, xscrollcommand=hb.set)
            idx = i
            cv.bind("<Configure>", lambda e, k=idx: self._on_resize(k))
            self.canvases.append(cv)

            # Botón guardar
            save_btn = ctk.CTkButton(
                panel, text=f"↓  Guardar Foto {i+1}",
                height=34, corner_radius=0,
                fg_color=BG_CARD, hover_color=BORDER_MED,
                text_color=TEXT_GREY, border_width=0,
                font=ctk.CTkFont("Segoe UI", 9),
                command=lambda k=i: self._save_image(k),
                state="disabled")
            save_btn.grid(row=3, column=0, columnspan=2, sticky="ew")
            self.save_btns.append(save_btn)

        # Dibujar placeholders en los canvases nuevos
        self.after(50, self._draw_all_placeholders)

    def _rebuild_photo_panels(self):
        """Limpia fotos y reconstruye paneles según n_photos seleccionado."""
        self.photos      = [None, None, None]
        self.zoom_levels = [1.0,  1.0,  1.0]
        self.tk_images   = [None, None, None]
        self._build_photo_panels()

    def _draw_all_placeholders(self):
        n = self.n_photos_var.get()
        for i in range(n):
            self._draw_placeholder(i)

    # ── Helpers UI ────────────────────────────────────────────────────────────
    def _hsep(self, parent, row):
        f = ctk.CTkFrame(parent, fg_color=BORDER_DIM, height=1, corner_radius=0)
        f.grid(row=row, column=0, sticky="ew", padx=16, pady=(0, 10))

    def _sec_label(self, parent, row, text):
        ctk.CTkLabel(parent, text=text,
                     font=ctk.CTkFont("Segoe UI", 7, "bold"),
                     text_color=TEXT_DIM, anchor="w"
                     ).grid(row=row, column=0, sticky="w", padx=20, pady=(6, 3))

    # ── Statusbar ─────────────────────────────────────────────────────────────
    def _build_statusbar(self):
        bar = ctk.CTkFrame(self, fg_color=BG_SIDEBAR, corner_radius=0, height=32)
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.columnconfigure(2, weight=1)

        self.dot_lbl = ctk.CTkLabel(bar, text="●",
                                    font=ctk.CTkFont("Segoe UI", 10),
                                    text_color=TEXT_WHITE)
        self.dot_lbl.grid(row=0, column=0, padx=(16, 4))

        ctk.CTkLabel(bar, textvariable=self.status_text,
                     font=ctk.CTkFont("Segoe UI", 9),
                     text_color=TEXT_GREY, anchor="w"
                     ).grid(row=0, column=1, sticky="w")

        self.progress = ctk.CTkProgressBar(bar, width=120, height=4,
                                           fg_color=BORDER_DIM,
                                           progress_color=TEXT_WHITE)
        self.progress.set(0)
        self.progress.grid(row=0, column=3, padx=16)
        self._progress_running = False

    def _progress_start(self):
        self._progress_running = True
        self._progress_val = 0.0
        self._progress_tick()

    def _progress_tick(self):
        if not self._progress_running:
            return
        self._progress_val = (self._progress_val + 0.015) % 1.0
        self.progress.set(self._progress_val)
        self.after(40, self._progress_tick)

    def _progress_stop(self):
        self._progress_running = False
        self.progress.set(0)

    # ── Escaneo ───────────────────────────────────────────────────────────────
    def _refresh_scanners(self):
        self.scanner_list = get_wia_scanners()
        names = [n for n, _ in self.scanner_list]
        self.device_combo.configure(values=names or ["(ningún escáner detectado)"])
        if names:
            self.scan_var_device.set(names[0])
            self.status_text.set(f"Escáner encontrado: {names[0]}")
        else:
            self.scan_var_device.set("(ningún escáner detectado)")
            self.status_text.set("No se detectó ningún escáner WIA")

    def _start_scan(self):
        if not self.scanner_list:
            messagebox.showwarning("Sin escáner",
                "Comprueba que el escáner está encendido y pulsa 'Actualizar lista'.")
            return
        self.status_text.set("Escaneando…")
        self._progress_start()
        threading.Thread(target=self._do_scan, daemon=True).start()

    def _do_scan(self):
        try:
            sel = self.scan_var_device.get()
            did = next((d for n, d in self.scanner_list if n == sel), None)
            img = scan_with_wia(device_id=did,
                                dpi=self.scan_var_dpi.get(),
                                color_mode=self.scan_var_color.get())
            self.after(0, self._scan_done, img)
        except Exception as e:
            self.after(0, self._scan_error, str(e))

    def _scan_done(self, img):
        self._progress_stop()
        self.scanned_raw = img
        ts   = datetime.now().strftime("%H:%M:%S")
        dpi  = self.scan_var_dpi.get()
        n    = self.n_photos_var.get()

        if self.scan_var_autocrop.get():
            self.status_text.set("Detectando y recortando fotos…")
            imgs, msg = auto_crop_n_photos(img, n_photos=n)
        else:
            imgs = [img]
            msg  = "✓ Escaneo completado"

        # Rellenar self.photos
        self.photos = [None, None, None]
        for i, im in enumerate(imgs[:n]):
            self.photos[i] = im

        # Actualizar paneles
        active_n = min(n, len(self.canvases))
        for i in range(active_n):
            if self.photos[i]:
                w, h = self.photos[i].size
                self.info_labels[i].configure(
                    text=f"{w}×{h}px  ·  {dpi} DPI  ·  {ts}",
                    text_color=TEXT_WHITE)
                self.save_btns[i].configure(state="normal")
                self.zoom_levels[i] = 1.0
                self._zoom_fit(i)
            else:
                self.info_labels[i].configure(text="No detectada",
                                              text_color=TEXT_DIM)
                self._draw_placeholder(i)

        self.scan_history.append(list(self.photos))
        self.history_idx = len(self.scan_history) - 1
        self.status_text.set(msg)
        self.crop_now_btn.configure(state="normal")
        self.restore_btn.configure(state="normal")

    def _scan_error(self, msg):
        self._progress_stop()
        self.status_text.set("Error al escanear")
        messagebox.showerror("Error de escaneo",
            f"No se pudo completar el escaneo:\n\n{msg}\n\n"
            "Comprueba que el escáner está listo.")

    # ── Recorte ───────────────────────────────────────────────────────────────
    def _on_crop_toggle(self):
        if not CV2_AVAILABLE and self.scan_var_autocrop.get():
            messagebox.showwarning("OpenCV no instalado",
                "Para el auto-recorte instala:\n\npip install opencv-python numpy\n\n"
                "El recorte se ha desactivado.")
            self.scan_var_autocrop.set(False)

    def _manual_crop(self):
        if not self.scanned_raw: return
        if not CV2_AVAILABLE:
            messagebox.showwarning("OpenCV no instalado",
                "pip install opencv-python numpy")
            return
        self.status_text.set("Recortando…")
        n = self.n_photos_var.get()
        def _do():
            imgs, msg = auto_crop_n_photos(self.scanned_raw, n_photos=n)
            self.after(0, self._crop_done, imgs, msg)
        threading.Thread(target=_do, daemon=True).start()

    def _crop_done(self, imgs, msg):
        self.photos = [None, None, None]
        for i, im in enumerate(imgs[:3]):
            self.photos[i] = im
        active_n = min(self.n_photos_var.get(), len(self.canvases))
        for i in range(active_n):
            if self.photos[i]:
                w, h = self.photos[i].size
                self.info_labels[i].configure(
                    text=f"{w}×{h}px (recortada)", text_color=TEXT_WHITE)
                self.save_btns[i].configure(state="normal")
                self.zoom_levels[i] = 1.0
                self._zoom_fit(i)
            else:
                self.info_labels[i].configure(text="No detectada",
                                              text_color=TEXT_DIM)
                self._draw_placeholder(i)
        self.status_text.set(msg)

    def _restore_original(self):
        if not self.scanned_raw: return
        self.photos    = [None, None, None]
        self.photos[0] = self.scanned_raw
        w, h = self.scanned_raw.size
        if self.info_labels:
            self.info_labels[0].configure(
                text=f"{w}×{h}px (original)", text_color=WARNING)
        self.zoom_levels[0] = 1.0
        self._zoom_fit(0)
        for i in range(1, len(self.canvases)):
            self.info_labels[i].configure(text="Sin imagen", text_color=TEXT_DIM)
            self.save_btns[i].configure(state="disabled")
            self._draw_placeholder(i)
        self.status_text.set("Imagen original restaurada")

    # ── Canvas ────────────────────────────────────────────────────────────────
    def _draw_placeholder(self, idx=0):
        if idx >= len(self.canvases): return
        cv = self.canvases[idx]
        cv.delete("all")
        w  = cv.winfo_width()  or 400
        h  = cv.winfo_height() or 340
        cx, cy = w // 2, h // 2
        # Grid de puntos muy sutiles
        for x in range(0, w, 28):
            for y in range(0, h, 28):
                cv.create_oval(x-1, y-1, x+1, y+1, fill="#1a1a1a", outline="")
        # Icono central
        cv.create_rectangle(cx-38, cy-28, cx+38, cy+28,
                            outline=BORDER_DIM, width=1, fill="")
        cv.create_line(cx-38, cy-28, cx+38, cy+28, fill=BORDER_DIM, width=1)
        cv.create_line(cx+38, cy-28, cx-38, cy+28, fill=BORDER_DIM, width=1)
        cv.create_text(cx, cy + 50,
                       text=f"Foto {idx+1} aparecerá aquí",
                       font=("Segoe UI", 9), fill=TEXT_DIM)

    def _on_resize(self, idx):
        if idx < len(self.photos) and self.photos[idx]:
            self._show_image(idx)
        else:
            self._draw_placeholder(idx)

    def _show_image(self, idx):
        if idx >= len(self.photos) or not self.photos[idx]: return
        img = self.photos[idx]
        cv  = self.canvases[idx]
        zl  = self.zoom_levels[idx]
        ow, oh = img.size
        nw = max(1, int(ow * zl))
        nh = max(1, int(oh * zl))
        resized = img.resize((nw, nh), Image.LANCZOS)
        tk_img  = ImageTk.PhotoImage(resized)
        self.tk_images[idx] = tk_img
        cv.delete("all")
        cv.config(scrollregion=(0, 0, nw, nh))
        cw = cv.winfo_width(); ch = cv.winfo_height()
        x  = max(nw // 2, cw // 2); y = max(nh // 2, ch // 2)
        cv.create_image(x, y, image=tk_img, anchor="center")
        self.zoom_label.configure(text=f"{int(zl*100)}%")

    def _zoom_fit(self, idx=None):
        targets = list(range(len(self.canvases))) if idx is None else [idx]
        self.update_idletasks()
        for i in targets:
            if i >= len(self.photos) or not self.photos[i]: continue
            cv = self.canvases[i]
            cw = cv.winfo_width(); ch = cv.winfo_height()
            iw, ih = self.photos[i].size
            if iw and ih:
                zl = min((cw - 20) / iw, (ch - 20) / ih, 1.0)
                self.zoom_levels[i] = zl
                self._show_image(i)

    def _zoom_in(self):
        for i in range(len(self.canvases)):
            if self.photos[i]:
                self.zoom_levels[i] = min(self.zoom_levels[i] * 1.25, 8.0)
                self._show_image(i)

    def _zoom_out(self):
        for i in range(len(self.canvases)):
            if self.photos[i]:
                self.zoom_levels[i] = max(self.zoom_levels[i] / 1.25, 0.05)
                self._show_image(i)

    def _rotate(self, deg):
        for i in range(len(self.canvases)):
            if self.photos[i]:
                self.photos[i] = self.photos[i].rotate(-deg, expand=True)
                self._show_image(i)

    # ── Historial ─────────────────────────────────────────────────────────────
    def _history_prev(self):
        if self.history_idx > 0:
            self.history_idx -= 1; self._load_history()

    def _history_next(self):
        if self.history_idx < len(self.scan_history) - 1:
            self.history_idx += 1; self._load_history()

    def _load_history(self):
        saved = self.scan_history[self.history_idx]
        self.photos = list(saved) + [None] * (3 - len(saved))
        for i in range(len(self.canvases)):
            if self.photos[i]:
                self._zoom_fit(i)
            else:
                self._draw_placeholder(i)
        self.status_text.set(
            f"Historial {self.history_idx+1}/{len(self.scan_history)}")

    # ── Guardar ───────────────────────────────────────────────────────────────
    def _save_image(self, idx):
        img = self.photos[idx] if idx < len(self.photos) else None
        if not img:
            messagebox.showinfo("Sin imagen",
                                f"Primero escanea para obtener la Foto {idx+1}.")
            return
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(
            defaultextension=".jpg",
            filetypes=[("JPEG","*.jpg"),("PNG","*.png"),
                       ("PDF","*.pdf"),("TIFF","*.tiff")],
            initialfile=f"foto{idx+1}_{ts}",
            title=f"Guardar Foto {idx+1}")
        if not path: return
        ext = Path(path).suffix.lower()
        if ext in (".jpg", ".jpeg"):
            img.convert("RGB").save(path, "JPEG", quality=96)
        elif ext == ".pdf":
            img.convert("RGB").save(path, "PDF",
                                    resolution=self.scan_var_dpi.get())
        elif ext == ".tiff":
            img.save(path, "TIFF")
        else:
            img.save(path, "PNG")
        self.status_text.set(f"✓ Foto {idx+1} guardada: {Path(path).name}")
        messagebox.showinfo("Guardado", f"Foto {idx+1} guardada en:\n{path}")

    # ── Dot animado ───────────────────────────────────────────────────────────
    def _animate_dot(self):
        colors = [TEXT_WHITE, ACCENT_GREY, TEXT_DIM]
        c = getattr(self, "_dot_c", 0)
        st = self.status_text.get()
        if "Listo" in st or "✓" in st:
            self.dot_lbl.configure(text_color=colors[c % len(colors)])
            self._dot_c = c + 1
        self.after(900, self._animate_dot)


# ══════════════════════════════════════════════════════════════════════════════
def main():
    app = EscanApp()
    app.mainloop()

if __name__ == "__main__":
    main()
