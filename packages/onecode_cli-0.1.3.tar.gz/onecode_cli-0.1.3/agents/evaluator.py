"""Evaluation agent — evaluates modules using natural language queries."""

import asyncio
import json
from typing import Optional
import config
from kg.graph import KnowledgeGraph
from eval import (
    make_module_analyzer,
    generate_golden_dataset,
    create_ragas_evaluator,
)
from utils.retry import call_api


def make_evaluation_agent(kg: KnowledgeGraph, codebase_root: str = ""):
    """
    Factory function that returns an evaluation agent.

    Args:
        kg: Knowledge graph of the codebase
        codebase_root: Root path of codebase for dataset caching

    Returns:
        Evaluation agent function
    """

    def evaluate(query: str) -> str:
        """
        Evaluate modules based on natural language query.

        Args:
            query: Natural language query (e.g., "evaluate the codebase",
                   "evaluate summarizer agent",
                   "what is the faithfulness of coder agent")

        Returns:
            Formatted evaluation results
        """
        try:
            # Step 1: Analyze what the user is asking for
            evaluation_request = _parse_evaluation_query(query)

            if not evaluation_request:
                return "Unable to parse evaluation query. Try: 'evaluate the codebase', 'evaluate [agent_name]', or 'what metrics for [agent_name]'"

            print(f"\n[evaluator] Target: {evaluation_request['target']}")
            print(f"[evaluator] Metrics: {evaluation_request['metrics'] or 'all'}")
            print(f"[evaluator] Samples: {evaluation_request['num_samples']}")

            # Step 2: Get modules to evaluate
            print("[evaluator] Analyzing modules...")
            analyzer = make_module_analyzer(kg)
            modules_info = _extract_modules_from_analysis(analyzer("analyze modules"))
            print(f"[evaluator] Found {len(modules_info)} evaluable modules")

            if not modules_info:
                return "No evaluable modules found in codebase"

            # Filter modules if specific agent requested
            if evaluation_request["target"] != "codebase":
                modules_info = [
                    m
                    for m in modules_info
                    if evaluation_request["target"].lower() in m["name"].lower()
                ]

                if not modules_info:
                    return f"Module '{evaluation_request['target']}' not found"

            # Step 3: Run evaluation with proper async handling
            runner = asyncio.Runner()
            try:
                results = runner.run(
                    _evaluate_modules(
                        modules_info,
                        metrics=evaluation_request["metrics"],
                        num_samples=evaluation_request["num_samples"],
                        codebase_root=codebase_root,
                    )
                )
            finally:
                runner.close()

            # Step 4: Format results
            return _format_evaluation_results(results, evaluation_request)

        except Exception as e:
            return f"Evaluation error: {e}"

    return evaluate


def _parse_evaluation_query(query: str) -> Optional[dict]:
    """
    Parse natural language evaluation query using LLM to extract intent.

    Returns dict with:
    - target: "codebase" or module name
    - metrics: list of metrics to compute (empty = all)
    - num_samples: number of test samples
    """
    prompt = f"""Extract the evaluation request from this query. Return ONLY valid JSON.

Query: "{query}"

INSTRUCTIONS:
1. Extract target module (look for agent names: coder, reader, executor, deleter, renamer, search, git, supervisor, summarizer)
   - If no specific agent mentioned → target is "codebase"

2. Extract requested metrics (empty array = all metrics wanted):
   Metric names: faithfulness, answer_relevancy, context_precision, context_recall, agent_goal_accuracy, tool_call_f1
   Aliases:
   - "faithful", "truthfulness" → faithfulness
   - "relevant", "relevance" → answer_relevancy
   - "precision" → context_precision
   - "recall" → context_recall
   - "accuracy", "goal" → agent_goal_accuracy
   - "tool" → tool_call_f1

3. Extract sample count - MUST check keywords carefully:
   - "quick" or "few" → 2 samples
   - "comprehensive" or "detailed" → 10 samples
   - default → 5 samples

EXAMPLES:
- "quick evaluation" → {{"target": "codebase", "metrics": [], "num_samples": 2}}
- "quick evaluation of reader accuracy" → {{"target": "reader", "metrics": ["agent_goal_accuracy"], "num_samples": 2}}
- "how faithful is coder" → {{"target": "coder", "metrics": ["faithfulness"], "num_samples": 5}}
- "comprehensive reader" → {{"target": "reader", "metrics": [], "num_samples": 10}}

START WITH {{ CHARACTER. ONLY JSON."""

    try:
        client = config.get_client()
        response = client.chat.completions.create(
            model=config.MODEL,
            max_tokens=200,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        response_text = response.choices[0].message.content.strip()

        # Clean up response if it has markdown code blocks
        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
        response_text = response_text.strip()

        # Parse JSON
        import json
        result = json.loads(response_text)

        return {
            "target": result.get("target", "codebase"),
            "metrics": result.get("metrics", []) or None,  # None means all metrics
            "num_samples": result.get("num_samples", 5),
        }
    except Exception as e:
        print(f"[evaluator] Warning: Failed to parse query with LLM: {e}")
        print(f"[evaluator] Using defaults: codebase, all metrics, 5 samples")
        return {
            "target": "codebase",
            "metrics": None,
            "num_samples": 5,
        }


def _extract_modules_from_analysis(analysis_output: str) -> list[dict]:
    """Extract module information from module analyzer output."""
    modules = []

    # Parse the analysis output to extract modules
    lines = analysis_output.split("\n")

    current_module = None
    for line in lines:
        # Look for module entries (e.g., "1. agents/summarizer.py")
        if line.strip() and line[0].isdigit() and "." in line:
            parts = line.split(".", 1)
            if len(parts) > 1:
                module_name = parts[1].strip()
                current_module = {"name": module_name, "kind": "unknown"}

        # Extract module kind
        if current_module and "Module Kind:" in line:
            kind = line.split("Module Kind:")[-1].strip()
            current_module["kind"] = kind
            modules.append(current_module)
            current_module = None

    return modules


async def _evaluate_modules(
    modules: list[dict],
    metrics: Optional[list[str]] = None,
    num_samples: int = 5,
    codebase_root: str = "",
) -> list[dict]:
    """Evaluate modules asynchronously with dataset caching."""
    results = []
    print(f"[evaluator] Starting evaluation of {len(modules)} modules...\n")

    # Create evaluator once and reuse for all modules (avoids event loop cleanup issues)
    evaluator = create_ragas_evaluator(llm_model="gpt-4o-mini")

    for idx, module in enumerate(modules, 1):
        try:
            print(f"[{idx}/{len(modules)}] {module['name']} ({module['kind']})...", end=" ")

            # Skip non-evaluable modules
            if module["kind"] == "non-agentic":
                print("⏭️  skipped (non-agentic)")
                results.append(
                    {
                        "name": module["name"],
                        "kind": module["kind"],
                        "status": "skipped",
                        "reason": "Non-agentic modules cannot be evaluated",
                    }
                )
                continue

            # Generate golden dataset
            print("generating dataset...", end=" ")
            module_info = {
                "name": module["name"],
                "module_kind": module["kind"],
                "description": f"{module['name']} module",
                "uses_llm": module["kind"] in ("genai", "agentic"),
                "uses_tools": module["kind"] == "agentic",
            }

            dataset = generate_golden_dataset(
                module_info,
                num_samples=num_samples,
                module_content="",
                codebase_root=codebase_root,
            )

            if not dataset.questions:
                print("❌ failed (dataset generation)")
                results.append(
                    {
                        "name": module["name"],
                        "kind": module["kind"],
                        "status": "failed",
                        "reason": "Failed to generate golden dataset",
                    }
                )
                continue

            # Evaluate with RAGAS (using gpt-4o-mini for best compatibility)
            print("computing metrics...", end=" ")

            if module["kind"] == "genai":
                eval_metrics = await evaluator.evaluate_genai_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                )
            elif module["kind"] == "agentic":
                eval_metrics = await evaluator.evaluate_agentic_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                    expected_tool_calls=dataset.expected_tool_calls or [],
                    selected_tool_calls=dataset.selected_tool_calls or [],
                )
            else:
                continue

            print("✓")
            results.append(
                {
                    "name": module["name"],
                    "kind": module["kind"],
                    "status": "success",
                    "metrics": eval_metrics,
                    "num_samples": num_samples,
                }
            )

        except Exception as e:
            print(f"❌ error: {str(e)[:60]}")
            results.append(
                {
                    "name": module["name"],
                    "kind": module["kind"],
                    "status": "failed",
                    "error": str(e),
                }
            )

    print(f"\n[evaluator] Evaluation complete. Results: {len([r for r in results if r['status'] == 'success'])} passed, {len([r for r in results if r['status'] == 'failed'])} failed\n")
    return results


def _format_evaluation_results(
    results: list[dict], request: dict
) -> str:
    """Format evaluation results for display."""
    lines = ["\n" + "=" * 80, "EVALUATION RESULTS", "=" * 80]

    successful = [r for r in results if r["status"] == "success"]
    failed = [r for r in results if r["status"] == "failed"]
    skipped = [r for r in results if r["status"] == "skipped"]

    # Summary
    lines.append(
        f"\nSummary: {len(successful)} evaluated, {len(failed)} failed, {len(skipped)} skipped"
    )

    # Detailed results
    if successful:
        lines.append("\n" + "-" * 80)
        lines.append("SUCCESSFUL EVALUATIONS")
        lines.append("-" * 80)

        for result in successful:
            lines.append(f"\n📊 {result['name']} ({result['kind']})")
            lines.append(f"   Samples: {result['num_samples']}")

            metrics = result["metrics"]

            # Show requested metrics or all if none specified
            if request["metrics"]:
                # Show only requested metrics
                for metric in request["metrics"]:
                    key = f"{metric}_avg"
                    if key in metrics and metrics[key] is not None:
                        lines.append(f"   {metric.replace('_', ' ').title()}: {metrics[key]:.3f}")
            else:
                # Show all available metrics
                if metrics.get("faithfulness_avg") is not None:
                    lines.append(f"   Faithfulness: {metrics['faithfulness_avg']:.3f}")
                if metrics.get("answer_relevancy_avg") is not None:
                    lines.append(f"   Answer Relevancy: {metrics['answer_relevancy_avg']:.3f}")
                if metrics.get("context_relevance_avg") is not None:
                    lines.append(f"   Context Relevance: {metrics['context_relevance_avg']:.3f}")
                if metrics.get("context_precision_avg") is not None:
                    lines.append(f"   Context Precision: {metrics['context_precision_avg']:.3f}")
                if metrics.get("context_recall_avg") is not None:
                    lines.append(f"   Context Recall: {metrics['context_recall_avg']:.3f}")
                if metrics.get("agent_goal_accuracy_avg") is not None:
                    lines.append(
                        f"   Agent Goal Accuracy: {metrics['agent_goal_accuracy_avg']:.3f}"
                    )
                if metrics.get("tool_call_f1_avg") is not None:
                    lines.append(f"   Tool Call F1: {metrics['tool_call_f1_avg']:.3f}")

    if skipped:
        lines.append("\n" + "-" * 80)
        lines.append("SKIPPED")
        lines.append("-" * 80)
        for result in skipped:
            lines.append(f"\n⏭️  {result['name']}: {result['reason']}")

    if failed:
        lines.append("\n" + "-" * 80)
        lines.append("FAILED")
        lines.append("-" * 80)
        for result in failed:
            reason = result.get("error") or result.get("reason", "Unknown error")
            lines.append(f"\n❌ {result['name']}: {reason}")

    lines.append("\n" + "=" * 80 + "\n")

    return "\n".join(lines)
