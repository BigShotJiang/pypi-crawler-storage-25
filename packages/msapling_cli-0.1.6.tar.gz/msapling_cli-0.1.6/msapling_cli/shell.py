"""MSapling Interactive Shell - Feature parity with Claude Code / Gemini CLI / Codex.

Provides a persistent interactive session with:
- Slash commands (/help, /model, /cost, /compact, /clear, /files, /plan, etc.)
- Local file operations (read, write, search, glob, grep)
- Terminal command execution
- Session persistence (save/resume)
- Project context auto-loading (.msapling.md)
- Cost tracking per session
- Diff mode (token-efficient output)
- Multi-model support
"""
from __future__ import annotations

import asyncio
import glob as globmod
import json
import os
import re
import shlex
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.tree import Tree

from .tui import (
    console as tui_console,
    render_session_header,
    render_prompt,
    render_user_message,
    render_assistant_response,
    render_cost_footer,
    render_help,
    status_bar,
)

from . import __version__
from .api import MSaplingClient
from .completer import setup_completion
from .config import get_settings, get_token, save_settings
from .local import detect_project_root, build_file_tree, read_files_as_context, git_status
from .memory import get_memories, add_memory, list_memories, clear_memories
from .storage import (
    register_session, unregister_session, append_history,
    append_conversation, list_project_sessions, save_plan, list_plans,
    load_plan, backup_file, load_settings as load_global_settings,
)
from .session import save_session, load_session, list_sessions
from .tier import check_tier, is_free_model

console = Console()

# ─── Project Instructions (.msapling.md) ──────────────────────────────

INSTRUCTION_FILES = [".msapling.md", "MSAPLING.md", "CLAUDE.md", "GEMINI.md", "AGENTS.md"]


def _load_project_instructions(project_root: str) -> str:
    """Load project instruction file (like CLAUDE.md) if present."""
    for name in INSTRUCTION_FILES:
        fpath = Path(project_root) / name
        if fpath.is_file():
            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")[:8000]
                return f"[Project instructions from {name}]\n{content}"
            except Exception:
                continue
    return ""


# ─── Slash Commands ───────────────────────────────────────────────────

SLASH_HELP = """
[bold]Session & Navigation[/bold]
  /help              Show this help
  /clear             Clear conversation history
  /compact           Summarize old messages via LLM to compress context
  /context           Show context window usage
  /save              Save session for later
  /resume [id]       Resume a previous session
  /sessions          List saved sessions
  /fork              Fork current conversation into new session
  /rewind [n]        Undo last n messages (default: 2)
  /copy              Copy last response to clipboard
  /export [file]     Export conversation to markdown
  /restore [file]    Restore file from pre-edit backup
  /diff              Interactive git diff viewer
  /permissions [mode] Set permission profile (ask/auto/readonly/full)
  /quit              Exit (also: /exit, /q, Ctrl+C)

[bold]Model & Mode[/bold]
  /model <id>        Switch model (e.g. /model gpt-4o)
  /models            List available models
  /plan              Toggle plan mode (read-only suggestions)
  /agent             Toggle agent mode (AI uses tools autonomously -- DEFAULT ON)
  /simple            Switch to simple chat mode (no tool use)
  /vim               Toggle vim-style input (multiline with Esc)
  /fast              Toggle fast/quality mode
  /effort <lvl>      Set thinking effort (low/medium/high)

[bold]File Operations[/bold]
  /files [pattern]   List files matching glob (e.g. /files **/*.py)
  /read <path>       Read file into context
  /write <path>      Write content to file (opens editor)
  /edit <path>       Edit file with AI (ask what to change)
  /grep <pattern>    Search file contents (regex)
  /mention <path>    Attach file to next message

[bold]Terminal & Git[/bold]
  /run <command>     Execute shell command
  /git <args>        Run git command
  /diff              Show git diff
  /status            Show git status

[bold]Multi-Model[/bold]
  /multi <prompt>    Send to multiple models in parallel (Pro)
  /swarm <prompt>    Run swarm with synthesis (Pro)
  /agent <prompt>    Spawn background subagent (Pro)

[bold]Workers (Multi-Chat)[/bold]
  /workers           List active parallel workers
  /join <name|#>     Switch focus to a worker
  /broadcast <msg>   Send message to all workers
  /collect           Show last response from each worker
  /kill <name|#>     Stop and remove a worker
  /budget [amount]   Set/view cost ceiling (e.g. /budget 0.50)

[bold]Project & Account[/bold]
  /project           Show project info
  /init              Generate .msapling.md from project
  /whoami            Show account info
  /cost              Show session cost and token usage
  /hooks             Manage lifecycle hooks
  /image <path>      Attach image to next message
  /paste             Paste image from clipboard into next message
""".strip()

# ─── Hooks System ─────────────────────────────────────────────────────
# Supported events (matching Claude Code's hook model):
#   on_session_start    — Shell starts (after auth, before input loop)
#   on_session_end      — Shell exits (before save)
#   on_before_message   — Before sending user message to LLM
#   on_after_message    — After receiving LLM response
#   on_before_tool      — Before agent executes a tool
#   on_after_tool       — After agent executes a tool
#   on_tool_failure     — When a tool execution fails
#   on_file_write       — After a file is written (by agent or /write)
#   on_file_read        — After a file is read into context
#   on_permission_ask   — When user is prompted for tool approval
#   on_model_change     — When model is switched (/model or agent model_switch)
#   on_compact           — When context is compacted (/compact)
#   on_worktree_create  — When a git worktree is created
#   on_worktree_remove  — When a git worktree is removed
#   on_subagent_start   — When a background subagent is spawned
#   on_subagent_done    — When a subagent completes
#   on_worker_spawn     — When a multi-chat worker is created
#   on_worker_kill      — When a worker is killed
#   on_instructions_loaded — When project instructions (.msapling.md) are loaded
#   on_budget_exceeded  — When cost ceiling is hit
#   on_config_change    — When a setting is changed
#   on_cwd_change       — When project root / worktree changes

HOOKS_FILE = Path.home() / ".msapling" / "hooks.json"


def _load_hooks() -> Dict[str, List[str]]:
    """Load hooks from ~/.msapling/hooks.json"""
    if HOOKS_FILE.exists():
        try:
            return json.loads(HOOKS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_hooks(hooks: Dict[str, List[str]]):
    HOOKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    HOOKS_FILE.write_text(json.dumps(hooks, indent=2), encoding="utf-8")


def _safe_path(project_root: str, rel_path: str) -> Optional[Path]:
    """Resolve a path and verify it stays within the project root."""
    try:
        resolved = (Path(project_root) / rel_path.strip()).resolve()
        root_resolved = Path(project_root).resolve()
        if resolved == root_resolved or resolved.is_relative_to(root_resolved):
            return resolved
    except Exception:
        pass
    return None


def _parse_menu_number(choice: str, action: str, *, allow_bare_number: bool = False) -> Optional[int]:
    """Parse menu actions like `R 1`, `R1`, `R<1>`, or bare `1`."""
    cleaned = str(choice or "").strip().upper()
    if not cleaned:
        return None
    if allow_bare_number and cleaned.isdigit():
        value = int(cleaned)
        return value if value > 0 else None
    match = re.fullmatch(rf"{re.escape(action.upper())}\s*<?\s*(\d+)\s*>?", cleaned)
    if not match:
        return None
    value = int(match.group(1))
    return value if value > 0 else None


def _run_hooks(event: str, hooks: Dict[str, List[str]], cwd: str) -> List[str]:
    """Run hooks for a lifecycle event. Returns list of outputs."""
    outputs = []
    for cmd in hooks.get(event, []):
        try:
            cmd_parts = shlex.split(cmd, posix=(sys.platform != "win32"))
            result = subprocess.run(
                cmd_parts, shell=False, cwd=cwd,
                capture_output=True, text=True, timeout=10,
            )
            if result.stdout.strip():
                outputs.append(result.stdout.strip())
        except Exception:
            pass
    return outputs


class InteractiveShell:
    """Persistent interactive shell for MSapling CLI.

    On startup, requires user to select a project and chat mode (single or
    multi-chat up to 6 parallel workers).  Same limits as the web UI.
    """

    # Hardcoded limits — must match backend config.py
    MAX_CHATS_PER_PROJECT = 6
    FREE_MAX_CHATS = 2

    def __init__(self, model=None, project=None, session_id=None, resume_id=None):
        settings = get_settings()
        self.model = model or settings.default_model
        self.project_root, self.project_info = detect_project_root(".")
        self.project_name = project  # Set during startup flow (None = ask user)
        self.session_id = session_id or str(uuid.uuid4())[:12]
        self.chat_id: Optional[str] = None  # Active chat (server-side)
        self.messages: List[Dict[str, str]] = []
        self.cost_total = 0.0
        self.tokens_total = 0
        self.plan_mode = False
        self.vim_mode = False
        self.fast_mode = False
        self.effort = "high"
        self.pending_attachments: List[Dict[str, str]] = []
        self.hooks = _load_hooks()
        self.workers: List[Dict[str, Any]] = []  # Parallel chat workers
        self.subagents: List[Dict[str, Any]] = []  # Background subagents
        self.cost_ceiling: Optional[float] = None  # Max $ for this session (None = no limit)
        self.agent_mode = True
        self.client = MSaplingClient()
        self.user: Dict[str, Any] = {}
        self._completer = None
        self._resume_id = resume_id

    # ─── Startup Flow ────────────────────────────────────────────────

    async def start(self):
        """Main entry: authenticate, select project, select chat mode, then run."""
        token = get_token()
        if not token:
            console.print("[red]Not logged in. Run: msapling login[/red]")
            return
        try:
            self.user = await self.client.me()
        except Exception as e:
            console.print(f"[red]Auth failed: {e}[/red]")
            return

        tier = self.user.get("tier", "free")
        credits = self.user.get("fuel_credits", 0)
        is_paid = tier in ("pro", "monthly", "lifetime") or self.user.get("is_pro")

        console.print()
        console.print(f"[bold]  ◆ MSapling CLI[/bold] [dim]v{__version__}[/dim]")
        console.print(f"  [dim]Logged in:[/dim] {self.user.get('email', '?')} [dim]({tier}, ${credits:.4f} fuel)[/dim]")
        console.print()

        # If resuming a saved session, skip the selection flow
        if self._resume_id:
            await self._resume_session()
        else:
            # ── Step 1: Select or create project ──
            selected = await self._select_project(is_paid)
            if selected is None:
                return  # User quit

            # ── Step 2: Select chat mode ──
            started = await self._select_chat_mode(selected, is_paid)
            if not started:
                return  # User quit

        # ── Load context ──
        instructions = _load_project_instructions(self.project_root)
        if instructions:
            self.messages.append({"role": "system", "content": instructions})
            _run_hooks("on_instructions_loaded", self.hooks, self.project_root)

        memories = get_memories(self.project_root)
        if memories:
            self.messages.append({"role": "system", "content": memories})

        # Session header
        worker_count = len(self.workers)
        mode_desc = f"{worker_count} workers" if worker_count > 1 else "single chat"
        render_session_header(
            model=self.model,
            tier=tier,
            credits=credits,
            project=self.project_name or "~",
            agent_mode=self.agent_mode,
            instructions_loaded=bool(instructions),
            memories_loaded=bool(memories),
        )
        if worker_count > 1:
            console.print(f"  [bold cyan]{worker_count} parallel workers active[/bold cyan]  [dim]type /workers to see status[/dim]")
            console.print()

        # Reset agent tool permissions at session start (security)
        from .agent import reset_permissions
        reset_permissions()

        register_session(os.getpid(), self.session_id, self.project_root)
        self._completer = setup_completion(project_root=self.project_root)

        for out in _run_hooks("on_session_start", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")

        await self._main_loop()
        for out in _run_hooks("on_session_end", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")
        self._save()
        unregister_session(os.getpid())
        console.print("[ms.dim]Session saved. Resume with: msapling shell --resume[/ms.dim]")
        await self.client.close()

    async def _select_project(self, is_paid: bool) -> Optional[Dict[str, Any]]:
        """Interactive project selection. Returns project dict or None to quit."""
        try:
            overview = await self.client.projects_overview(self.user)
        except Exception as e:
            console.print(f"[red]Failed to load projects: {e}[/red]")
            return None

        projects = overview.get("projects", [])
        project_limit = overview.get("project_limit", 10)
        can_create = overview.get("can_create_project", True)

        console.print(f"  [bold]Your Projects[/bold] [dim]({len(projects)}/{project_limit}):[/dim]")
        console.print()
        for i, p in enumerate(projects, 1):
            name = p["name"]
            count = p["chat_count"]
            limit = p["chat_limit"]
            full_tag = "  [red][FULL][/red]" if p["is_full"] else ""
            console.print(f"    [cyan]{i}.[/cyan] {name}  [dim]{count}/{limit} chats[/dim]{full_tag}")

        console.print()
        if can_create:
            console.print("    [cyan]N.[/cyan] New project")
        console.print("    [cyan]Q.[/cyan] Quit")
        console.print()

        while True:
            try:
                choice = console.input("  [bold]Select:[/bold] ").strip().upper()
            except (KeyboardInterrupt, EOFError):
                return None

            if choice == "Q":
                return None

            if choice == "N":
                if not can_create:
                    console.print(f"  [yellow]Project limit reached ({project_limit} max).[/yellow]")
                    continue
                try:
                    name = console.input("  [bold]Project name:[/bold] ").strip()
                except (KeyboardInterrupt, EOFError):
                    return None
                if not name:
                    continue
                try:
                    result = await self.client.create_project(name)
                    self.project_name = name
                    return {"name": name, "chat_count": 0, "chat_limit": self.MAX_CHATS_PER_PROJECT if is_paid else self.FREE_MAX_CHATS, "is_full": False, "chats": []}
                except Exception as e:
                    console.print(f"  [red]{e}[/red]")
                    continue

            try:
                idx = int(choice) - 1
                if 0 <= idx < len(projects):
                    selected = projects[idx]
                    self.project_name = selected["name"]
                    # Fetch existing chats for this project
                    try:
                        chats = await self.client.list_project_chats(selected["name"])
                        selected["chats"] = chats
                    except Exception:
                        selected["chats"] = []
                    return selected
            except ValueError:
                pass
            console.print("  [yellow]Invalid choice.[/yellow]")

    async def _select_chat_mode(self, project: Dict[str, Any], is_paid: bool) -> bool:
        """After project is selected, pick resume/single/multi chat. Returns False to quit."""
        chats = project.get("chats", [])
        chat_count = project.get("chat_count", len(chats))
        chat_limit = project.get("chat_limit", self.MAX_CHATS_PER_PROJECT)
        free_slots = max(0, chat_limit - chat_count)

        console.print()
        console.print(f"  [bold]{self.project_name}[/bold] [dim]({chat_count}/{chat_limit} chats):[/dim]")
        console.print()

        if chats:
            for i, c in enumerate(chats, 1):
                title = c.get("title", c.get("slot_label", "Chat"))
                model = c.get("model", "?")
                model_short = model.split("/")[-1] if "/" in model else model
                console.print(f"    [cyan]{i}.[/cyan] {title}  [dim]({model_short})[/dim]")
            console.print()

        console.print(f"  [dim]{free_slots} slot(s) free[/dim]")
        console.print()
        console.print("  [bold]Options:[/bold]")
        if chats:
            console.print("    [cyan]R <#>[/cyan]       Resume existing chat")
        if free_slots > 0:
            console.print("    [cyan]S[/cyan]           New single chat")
            if is_paid and free_slots >= 2:
                max_w = min(free_slots, 6)
                console.print(f"    [cyan]M <2-{max_w}>[/cyan]      New multi-chat (parallel workers)")
        if chats:
            console.print("    [cyan]D <#>[/cyan]       Delete chat to free slot")
        console.print("    [cyan]B[/cyan]           Back to projects")
        console.print()

        while True:
            try:
                choice = console.input("  [bold]Select:[/bold] ").strip().upper()
            except (KeyboardInterrupt, EOFError):
                return False

            if choice == "B":
                return False

            # Resume existing chat
            resume_number = _parse_menu_number(choice, "R", allow_bare_number=True)
            if resume_number is not None and chats:
                idx = resume_number - 1
                if 0 <= idx < len(chats):
                    c = chats[idx]
                    self.chat_id = c.get("id")
                    self.model = c.get("model", self.model)
                    console.print(f"  [green]Resumed: {c.get('title', 'Chat')}[/green]")
                    return True
                console.print("  [yellow]Invalid chat number.[/yellow]")
                continue
            if choice == "R" or (choice.startswith("R") and chats):
                console.print("  [yellow]Usage: R <number>[/yellow]")
                continue

            # New single chat
            if choice == "S":
                if free_slots <= 0:
                    console.print("  [yellow]No free slots. Delete a chat first.[/yellow]")
                    continue
                try:
                    result = await self.client.create_chat(
                        self.project_name, title=f"cli:{os.environ.get('COMPUTERNAME', 'shell')}",
                        model=self.model, client_type="cli",
                    )
                    self.chat_id = result["chat_id"]
                    console.print(f"  [green]Created: {result.get('title', 'CLI Chat')}[/green]")
                    return True
                except Exception as e:
                    console.print(f"  [red]{e}[/red]")
                    continue

            # Multi-chat workers
            multi_number = _parse_menu_number(choice, "M")
            if choice == "M" or multi_number is not None:
                if not is_paid:
                    console.print("  [yellow]Multi-chat requires Pro tier.[/yellow]")
                    continue
                count = multi_number if multi_number is not None else 2
                if choice.startswith("M") and multi_number is None and choice != "M":
                    console.print("  [yellow]Usage: M <number>[/yellow]")
                    continue
                if count < 2:
                    count = 2
                if count > free_slots:
                    console.print(f"  [yellow]Only {free_slots} slot(s) free. Max M {free_slots}.[/yellow]")
                    continue
                if count > 6:
                    console.print("  [yellow]Max 6 parallel chats.[/yellow]")
                    continue
                # Create workers
                await self._setup_workers(count)
                if self.workers:
                    self.chat_id = self.workers[0]["chat_id"]
                    self.model = self.workers[0]["model"]
                    return True
                continue

            # Delete chat
            delete_number = _parse_menu_number(choice, "D")
            if delete_number is not None and chats:
                idx = delete_number - 1
                if 0 <= idx < len(chats):
                    c = chats[idx]
                    try:
                        await self.client.delete_chat(c["id"])
                        title = c.get("title", "Chat")
                        console.print(f"  [green]Deleted: {title}[/green]")
                        chats.pop(idx)
                        chat_count -= 1
                        free_slots += 1
                    except Exception as e:
                        console.print(f"  [red]{e}[/red]")
                else:
                    console.print("  [yellow]Invalid chat number.[/yellow]")
                continue
            if choice == "D" or (choice.startswith("D") and chats):
                console.print("  [yellow]Usage: D <number>[/yellow]")
                continue

            console.print("  [yellow]Invalid choice.[/yellow]")

    async def _setup_workers(self, count: int):
        """Create N worker chats interactively."""
        from .completer import resolve_model
        self.workers = []
        for i in range(1, count + 1):
            console.print(f"  [cyan]Worker {i}/{count}:[/cyan]")
            try:
                name = console.input(f"    Name: ").strip() or f"worker-{i}"
                model_input = console.input(f"    Model [{self.model}]: ").strip()
            except (KeyboardInterrupt, EOFError):
                break
            if model_input:
                resolved, _ = resolve_model(model_input)
            else:
                resolved = self.model
            try:
                result = await self.client.create_chat(
                    self.project_name,
                    title=f"worker:{name}",
                    model=resolved,
                    client_type="cli-worker",
                )
                self.workers.append({
                    "name": name,
                    "chat_id": result["chat_id"],
                    "model": resolved,
                    "status": "ready",
                    "messages": [],
                    "cost": 0.0,
                    "tokens": 0,
                })
                console.print(f"    [green]Created worker:{name} ({resolved.split('/')[-1]})[/green]")
            except Exception as e:
                console.print(f"    [red]Failed: {e}[/red]")
                break
        if self.workers:
            console.print(f"  [green]{len(self.workers)} workers ready.[/green]")

    async def _resume_session(self):
        """Resume a saved session by ID."""
        sessions = list_sessions()
        target = None
        try:
            idx = int(self._resume_id) - 1
            if 0 <= idx < len(sessions):
                target = sessions[idx]
        except ValueError:
            for s in sessions:
                if s["id"] == self._resume_id or s["id"].startswith(self._resume_id):
                    target = s
                    break
        if target:
            self.session_id = target["id"]
            self.messages = target.get("messages", [])
            self.model = target.get("model", self.model)
            self.cost_total = target.get("cost_total", 0)
            self.tokens_total = target.get("tokens_total", 0)
            self.project_name = target.get("metadata", {}).get("project_name") or self.project_name
            self.chat_id = target.get("metadata", {}).get("chat_id")
            if target.get("project_root"):
                self.project_root = target["project_root"]
            n = len(self.messages)
            console.print(f"  [green]Resumed session {self.session_id} ({n} messages)[/green]")
        else:
            console.print("  [yellow]Session not found, starting fresh.[/yellow]")

    # ─── Main Input Loop ─────────────────────────────────────────────

    async def _main_loop(self):
        """Main input loop after project/chat selection."""
        while True:
            try:
                if self.vim_mode:
                    console.print("[dim](vim mode: empty line to send)[/dim]")
                    lines = []
                    while True:
                        line = console.input("[bold green]| [/bold green]")
                        if line.strip() == ".":
                            lines = []
                            break
                        if line == "":
                            break
                        lines.append(line)
                    prompt = "\n".join(lines)
                else:
                    # Use builtin input() for readline/tab-completion support
                    console.print(render_prompt(), end="")
                    prompt = input()
            except (KeyboardInterrupt, EOFError):
                break

            prompt = prompt.strip()
            if not prompt:
                continue
            if prompt.startswith("/"):
                should_continue = await self._handle_slash(prompt)
                if not should_continue:
                    break
                continue
            await self._chat(prompt)

    def _total_session_cost(self) -> float:
        """Total cost across main chat + all workers."""
        worker_cost = sum(w.get("cost", 0.0) for w in self.workers)
        return self.cost_total + worker_cost

    def _check_cost_ceiling(self) -> bool:
        """Returns True if under budget, False if ceiling hit."""
        if self.cost_ceiling is None:
            return True
        if self._total_session_cost() >= self.cost_ceiling:
            console.print(f"[red]Cost ceiling reached (${self.cost_ceiling:.4f}). Use /budget to adjust.[/red]")
            _run_hooks("on_budget_exceeded", self.hooks, self.project_root)
            return False
        return True

    def _record_usage(self, tokens: int, cost: float):
        self.tokens_total += int(tokens)
        self.cost_total += float(cost)

    async def _chat(self, prompt: str):
        """Send a message and stream the response."""
        if not self._check_cost_ceiling():
            return
        allowed, msg = check_tier(self.user, "chat", self.model)
        if not allowed:
            console.print(f"[yellow]{msg}[/yellow]")
            return

        if self.plan_mode:
            prompt = "[PLAN MODE - suggest only]\n" + prompt

        if self.pending_attachments:
            att = "\n\n".join(
                f"[Attached: {a['name']}]\n```\n{a['content']}\n```"
                for a in self.pending_attachments
            )
            prompt = prompt + "\n\n" + att
            n_att = len(self.pending_attachments)
            console.print(f"[dim]Attached {n_att} file(s)[/dim]")
            self.pending_attachments.clear()

        # Log to history and conversation transcript (like Claude Code)
        append_history(prompt, self.project_root, self.session_id)
        append_conversation(self.project_root, self.session_id, "user", prompt)

        for out in _run_hooks("on_before_message", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")

        if self.agent_mode:
            try:
                from .agent import run_agent_loop, get_and_clear_switched_model

                def _on_usage(tokens: int, cost: float):
                    self.tokens_total += tokens
                    self.cost_total += cost

                response = await run_agent_loop(
                    client=self.client,
                    prompt=prompt,
                    model=self.model,
                    project_root=self.project_root,
                    messages=self.messages,
                    on_text=lambda text: None,
                    on_usage=_on_usage,
                    project_name=self.project_name or "",
                    chat_id=self.chat_id or "",
                )
                if response:
                    render_assistant_response(response)
                    append_conversation(self.project_root, self.session_id, "assistant", response)
                render_cost_footer(self.tokens_total, self.cost_total)
                _run_hooks("on_after_message", self.hooks, self.project_root)

                # Check if agent switched models mid-task
                new_model = get_and_clear_switched_model()
                if new_model:
                    self.model = new_model
                    console.print(f"[dim]Agent switched model to: {new_model}[/dim]")
            except Exception as e:
                console.print(f"[red]Agent error: {e}[/red]")
            return

        self.messages.append({"role": "user", "content": prompt})

        # Use server-side history (Layer 0/1/2 compressed) when we have a chat_id,
        # fall back to local messages for offline/anonymous sessions.
        history_to_send = self.messages[-20:]
        if self.chat_id:
            try:
                server_history = await self.client.get_chat_history(self.chat_id, limit=20)
                if server_history:
                    # Server returns pre-compressed context (sagas + blocks + recent)
                    history_to_send = server_history
            except Exception:
                pass  # Offline fallback to local messages

        try:
            parts = []
            thinking_parts = []
            in_thinking = False
            with Live(console=console, refresh_per_second=8) as live:
                async for chunk in self.client.stream_chat(
                    chat_id=self.chat_id or self.session_id,
                    prompt=prompt,
                    model=self.model,
                    project_name=self.project_name,
                    history=history_to_send,
                ):
                    content = chunk.get("content", "")
                    # Detect thinking/reasoning blocks (Claude/GPT extended thinking)
                    chunk_type = chunk.get("type", "")
                    if chunk_type == "thinking" or chunk.get("thinking"):
                        thinking_text = chunk.get("thinking", content)
                        if thinking_text:
                            thinking_parts.append(thinking_text)
                            # Show thinking in dim text
                            from rich.text import Text
                            thinking_display = Text("".join(thinking_parts), style="dim italic")
                            live.update(thinking_display)
                        continue
                    if content:
                        # If we were showing thinking, clear and switch to main response
                        if thinking_parts and not parts:
                            console.print()  # Newline after thinking
                        parts.append(content)
                        live.update(Markdown("".join(parts)))
                    if chunk_type == "usage" or chunk.get("usage"):
                        usage = chunk.get("usage", {})
                        self.tokens_total += usage.get("total_tokens", 0)
                        self.cost_total += float(chunk.get("cost", 0))

            # Show thinking summary if any
            if thinking_parts:
                thinking_text = "".join(thinking_parts)
                if len(thinking_text) > 200:
                    console.print(Panel(
                        f"[dim italic]{thinking_text[:500]}{'...' if len(thinking_text) > 500 else ''}[/dim italic]",
                        title="[dim]Thinking[/dim]",
                        border_style="dim",
                    ))

            response = "".join(parts)
            if response:
                self.messages.append({"role": "assistant", "content": response})
                append_conversation(self.project_root, self.session_id, "assistant", response)
                render_cost_footer(self.tokens_total, self.cost_total)
            else:
                console.print("[yellow]No response[/yellow]")
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")

    async def _handle_slash(self, cmd: str) -> bool:
        """Handle slash command. Returns False to exit."""
        parts = cmd.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        if command in ("/quit", "/exit", "/q"):
            return False
        elif command == "/help":
            render_help()
        elif command == "/model":
            if args:
                from .completer import resolve_model
                old = self.model
                resolved, was_fuzzy = resolve_model(args.strip())
                self.model = resolved
                if was_fuzzy:
                    console.print(f"[ms.accent]Model: {old} -> {self.model}[/ms.accent] [ms.dim](matched from '{args.strip()}')[/ms.dim]")
                else:
                    console.print(f"[ms.accent]Model: {old} -> {self.model}[/ms.accent]")
                _run_hooks("on_model_change", self.hooks, self.project_root)
            else:
                console.print(f"Current model: [ms.accent]{self.model}[/ms.accent]")
        elif command == "/models":
            try:
                models = await self.client.get_models()
                model_ids = []
                for m in models[:20]:
                    mid = m.get("id", "?")
                    model_ids.append(mid)
                    tag = "[green]free[/green]" if is_free_model(mid) else "[yellow]pro[/yellow]"
                    console.print(f"  {mid} ({tag})")
                if len(models) > 20:
                    console.print(f"  [dim]...and {len(models) - 20} more[/dim]")
                    model_ids.extend(m.get("id", "") for m in models[20:] if m.get("id"))
                # Update tab completer with fetched model IDs
                if self._completer and model_ids:
                    self._completer.set_models(model_ids)
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/cost":
            console.print(f"[cyan]Session cost:[/cyan] ${self.cost_total:.4f}")
            console.print(f"[cyan]Tokens used:[/cyan] {self.tokens_total:,}")
            console.print(f"[cyan]Messages:[/cyan] {len(self.messages)}")
            fuel = self.user.get('fuel_credits', 0)
            console.print(f"[cyan]Fuel remaining:[/cyan] ${fuel:.4f}")
        elif command == "/clear":
            self.messages = [m for m in self.messages if m.get("role") == "system"]
            self.cost_total = 0.0
            self.tokens_total = 0
            console.print("[green]Conversation cleared[/green]")
        elif command == "/compact":
            await self._compact_context()
        elif command == "/context":
            # Better token estimation: ~3.5 chars/token for English code
            sys_msgs = [m for m in self.messages if m.get("role") == "system"]
            user_msgs = [m for m in self.messages if m.get("role") == "user"]
            asst_msgs = [m for m in self.messages if m.get("role") == "assistant"]
            sys_chars = sum(len(m.get("content", "")) for m in sys_msgs)
            user_chars = sum(len(m.get("content", "")) for m in user_msgs)
            asst_chars = sum(len(m.get("content", "")) for m in asst_msgs)
            total_chars = sys_chars + user_chars + asst_chars
            # ~3.5 chars per token for code-heavy content
            token_est = int(total_chars / 3.5)
            # Visual bar (rough context usage assuming 128k model)
            max_ctx = 128000
            pct = min(100, int(token_est / max_ctx * 100))
            bar_len = 30
            filled = int(bar_len * pct / 100)
            bar = "[green]" + "█" * filled + "[/green]" + "[dim]░[/dim]" * (bar_len - filled)
            color = "green" if pct < 50 else ("yellow" if pct < 80 else "red")

            console.print(f"  [cyan]Model:[/cyan]    {self.model}")
            console.print(f"  [cyan]Messages:[/cyan] {len(sys_msgs)} system, {len(user_msgs)} user, {len(asst_msgs)} assistant")
            console.print(f"  [cyan]Tokens:[/cyan]   ~{token_est:,} / {max_ctx:,} [{color}]({pct}%)[/{color}]")
            console.print(f"  [cyan]Usage:[/cyan]    {bar} {pct}%")
            console.print(f"  [cyan]Cost:[/cyan]     ${self.cost_total:.4f}  ({self.tokens_total:,} tokens used)")
            if pct > 70:
                console.print("  [yellow]Consider /compact to free context space.[/yellow]")
        elif command == "/files":
            pattern = args.strip() or "**/*"
            try:
                matches = sorted(globmod.glob(
                    str(Path(self.project_root) / pattern), recursive=True
                ))[:50]
                skip = {".git", "node_modules", "__pycache__", "venv", "dist", "build"}
                for f in matches:
                    rel = os.path.relpath(f, self.project_root).replace("\\", "/")
                    if any(s in rel.split("/") for s in skip):
                        continue
                    if os.path.isfile(f):
                        size = os.path.getsize(f)
                        console.print(f"  {rel} ({size / 1024:.1f}KB)")
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/read":
            fpath = _safe_path(self.project_root, args.strip())
            if not fpath:
                console.print("[red]Path outside project root[/red]")
            elif not fpath.is_file():
                console.print(f"[red]File not found: {args}[/red]")
            else:
                try:
                    content = fpath.read_text(encoding="utf-8", errors="ignore")
                    if len(content) > 50000:
                        content = content[:50000]
                    ext = fpath.suffix.lstrip(".")
                    lang_map = {"py": "python", "ts": "typescript", "js": "javascript", "tsx": "tsx"}
                    console.print(Syntax(content, lang_map.get(ext, ext), theme="monokai", line_numbers=True))
                    self.messages.append({
                        "role": "user",
                        "content": f"[File: {args.strip()}]\n```\n{content}\n```",
                    })
                    console.print(f"[dim]Added to context ({len(content)//4} tokens)[/dim]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
        elif command == "/grep":
            if not args:
                console.print("[yellow]Usage: /grep <pattern> [path][/yellow]")
            else:
                gp = args.split(maxsplit=1)
                pat = gp[0]
                sp = gp[1] if len(gp) > 1 else "."
                cmds = [
                    ["rg", "-n", "--max-count=30", pat, sp],
                    ["grep", "-rn", pat, sp],
                ]
                found = False
                for gc in cmds:
                    try:
                        r = subprocess.run(gc, cwd=self.project_root, capture_output=True, text=True, timeout=10)
                        if r.stdout:
                            for ln in r.stdout.strip().split("\n")[:30]:
                                console.print(f"  {ln}")
                        else:
                            console.print("[yellow]No matches[/yellow]")
                        found = True
                        break
                    except FileNotFoundError:
                        continue
                if not found:
                    console.print("[red]Neither rg nor grep found.[/red]")
        elif command == "/run":
            if not args:
                console.print("[yellow]Usage: /run <command>[/yellow]")
            else:
                try:
                    # shlex.split with posix=False on Windows to preserve backslashes
                    cp = shlex.split(args, posix=(sys.platform != "win32"))
                    r = subprocess.run(cp, shell=False, cwd=self.project_root, capture_output=True, text=True, timeout=30)
                    if r.stdout:
                        console.print(r.stdout[:5000])
                    if r.stderr and r.returncode != 0:
                        console.print(f"[red]{r.stderr[:2000]}[/red]")
                    console.print(f"[dim]exit code: {r.returncode}[/dim]")
                except subprocess.TimeoutExpired:
                    console.print("[red]Command timed out (30s)[/red]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
        elif command == "/git":
            if not args:
                args = "status --short"
            try:
                r = subprocess.run(["git"] + args.split(), cwd=self.project_root, capture_output=True, text=True, timeout=30)
                out = r.stdout or r.stderr
                if args.split()[0] in ("diff", "show", "log"):
                    console.print(Syntax(out[:5000], "diff", theme="monokai"))
                else:
                    console.print(out[:5000])
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/status":
            await self._handle_slash("/git status --short")
        elif command == "/plan":
            from .agent import set_permission_mode
            self.plan_mode = not self.plan_mode
            if self.plan_mode:
                set_permission_mode("plan")
                console.print("[green]Plan mode: ON[/green] [dim](read-only, no file writes or commands)[/dim]")
            else:
                set_permission_mode("ask")
                console.print("[red]Plan mode: OFF[/red] [dim](back to normal)[/dim]")
        elif command == "/save":
            self._save()
            console.print(f"[green]Session saved: {self.session_id}[/green]")
        elif command == "/resume":
            sessions = list_sessions()
            if not sessions:
                console.print("[yellow]No saved sessions[/yellow]")
            else:
                table = Table(title="Saved Sessions")
                table.add_column("#", style="cyan")
                table.add_column("ID")
                table.add_column("Model")
                table.add_column("Messages", justify="right")
                table.add_column("Last Prompt")
                for i, s in enumerate(sessions[:10]):
                    table.add_row(
                        str(i + 1), s["id"], s.get("model", "?"),
                        str(len(s.get("messages", []))),
                        s.get("_summary", "")[:60],
                    )
                console.print(table)
        elif command == "/sessions":
            await self._handle_slash("/resume")
        elif command == "/project":
            console.print(f"[cyan]Root:[/cyan] {self.project_root}")
            console.print(f"[cyan]Type:[/cyan] {self.project_info.get('type', 'unknown')}")
            console.print(f"[cyan]Git:[/cyan] {git_status(self.project_root)[:200]}")
        elif command == "/init":
            await self._generate_project_instructions()
        elif command == "/whoami":
            console.print(f"[cyan]Email:[/cyan] {self.user.get('email', '?')}")
            console.print(f"[cyan]Tier:[/cyan] {self.user.get('tier', 'free')}")
            fuel = self.user.get('fuel_credits', 0)
            console.print(f"[cyan]Credits:[/cyan] ${fuel:.4f}")
        elif command == "/memory":
            if not args.strip():
                entries = list_memories(self.project_root)
                if not entries:
                    console.print("[yellow]No memories.[/yellow]")
                else:
                    for e in entries[-15:]:
                        sc = e.get("_scope", "?")
                        console.print(f"  [{sc}] {e.get('text', '')[:100]}")
            elif args.startswith("add "):
                text = args[4:].strip()
                if text:
                    r = add_memory(text, project_root=self.project_root)
                    console.print(f"[green]{r}[/green]")
            elif args.strip() == "clear":
                clear_memories(self.project_root)
                console.print("[green]Memories cleared[/green]")
        elif command == "/permissions":
            from .agent import get_permission_mode, set_permission_mode
            if not args.strip():
                mode = get_permission_mode()
                console.print(f"[cyan]Permission mode:[/cyan] {mode}")
                console.print("[dim]  ask      = prompt for writes/commands (default)")
                console.print("  auto     = auto-approve edits, ask for commands")
                console.print("  readonly = block all writes")
                console.print("  full     = approve everything")
                console.print(f"  Set with: /permissions <mode>[/dim]")
            else:
                new_mode = set_permission_mode(args.strip().lower())
                console.print(f"[green]Permission mode: {new_mode}[/green]")
        elif command == "/worktree":
            sub = args.split()[0].lower() if args.strip() else "list"
            wt_arg = args.split()[1] if len(args.split()) > 1 else ""
            if sub == "list":
                try:
                    r = subprocess.run(["git", "worktree", "list"], cwd=self.project_root,
                                       capture_output=True, text=True, timeout=10)
                    console.print(r.stdout or "[yellow]No worktrees[/yellow]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "create" and wt_arg:
                branch = wt_arg
                wt_path = os.path.join(self.project_root, f"../{Path(self.project_root).name}-{branch}")
                try:
                    r = subprocess.run(
                        ["git", "worktree", "add", wt_path, "-b", branch],
                        cwd=self.project_root, capture_output=True, text=True, timeout=30,
                    )
                    if r.returncode == 0:
                        console.print(f"[green]Worktree created: {wt_path}[/green]")
                        console.print(f"[dim]Switch with: /worktree switch {branch}[/dim]")
                    else:
                        console.print(f"[red]{r.stderr}[/red]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "switch" and wt_arg:
                try:
                    r = subprocess.run(["git", "worktree", "list", "--porcelain"],
                                       cwd=self.project_root, capture_output=True, text=True, timeout=10)
                    for line in r.stdout.split("\n"):
                        if line.startswith("worktree ") and wt_arg in line:
                            new_root = line.replace("worktree ", "").strip()
                            self.project_root = new_root
                            console.print(f"[green]Switched to worktree: {new_root}[/green]")
                            break
                    else:
                        console.print(f"[yellow]Worktree not found: {wt_arg}[/yellow]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "delete" and wt_arg:
                try:
                    r = subprocess.run(["git", "worktree", "remove", wt_arg],
                                       cwd=self.project_root, capture_output=True, text=True, timeout=10)
                    if r.returncode == 0:
                        console.print(f"[green]Worktree removed: {wt_arg}[/green]")
                    else:
                        console.print(f"[red]{r.stderr}[/red]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            else:
                console.print("[yellow]Usage: /worktree <create|list|switch|delete> [branch][/yellow]")
        elif command == "/sandbox":
            from .agent import set_sandbox, _sandbox_enabled
            if not args.strip():
                status = "[green]ON[/green]" if _sandbox_enabled else "[red]OFF[/red]"
                console.print(f"[cyan]Command sandbox:[/cyan] {status}")
                console.print("[dim]  Blocks dangerous commands (rm -rf /, sudo, curl|bash, etc.)")
                console.print("  /sandbox off  — disable  |  /sandbox on  — enable[/dim]")
            elif args.strip().lower() in ("on", "true", "1"):
                set_sandbox(True)
                console.print("[green]Sandbox: ON[/green]")
            elif args.strip().lower() in ("off", "false", "0"):
                set_sandbox(False)
                console.print("[yellow]Sandbox: OFF — dangerous commands allowed[/yellow]")
        elif command == "/simple":
            self.agent_mode = False
            console.print("Mode: [yellow]Simple[/yellow]")
        elif command == "/agent":
            if not args.strip():
                # Toggle agent mode
                self.agent_mode = True
                console.print("Mode: [green]Agent[/green]")
            else:
                # Spawn background subagent with task
                allowed, msg = check_tier(self.user, "swarm")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    aid = str(uuid.uuid4())[:8]
                    console.print(f"[cyan]Spawning agent {aid}...[/cyan]")
                    try:
                        response = await self.client.chat_once(args.strip(), self.model)
                        self.subagents.append({"id": aid, "task": args.strip(), "result": response[:2000]})
                        console.print(Panel(Markdown(response[:2000]), title=f"Agent {aid}", border_style="magenta"))
                    except Exception as e:
                        console.print(f"[red]Agent failed: {e}[/red]")
        elif command == "/vim":
            self.vim_mode = not self.vim_mode
            st = "[green]ON[/green]" if self.vim_mode else "[red]OFF[/red]"
            console.print(f"Vim mode: {st}")
        elif command == "/fast":
            self.fast_mode = not self.fast_mode
            st = "[green]ON[/green]" if self.fast_mode else "[red]OFF[/red]"
            console.print(f"Fast mode: {st}")
        elif command == "/effort":
            if args.strip() in ("low", "medium", "high"):
                self.effort = args.strip()
                console.print(f"[green]Effort: {self.effort}[/green]")
            else:
                console.print(f"Current: {self.effort}. Options: low, medium, high")
        elif command == "/write":
            if not args.strip():
                console.print("[yellow]Usage: /write <path>[/yellow]")
            else:
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath:
                    console.print("[red]Path outside project root[/red]")
                    return True
                console.print("[cyan]Enter content (empty line to finish):[/cyan]")
                lines = []
                while True:
                    try:
                        line = console.input("[dim]| [/dim]")
                        if line == "":
                            break
                        lines.append(line)
                    except (KeyboardInterrupt, EOFError):
                        break
                if lines:
                    content = "\n".join(lines)
                    fpath.parent.mkdir(parents=True, exist_ok=True)
                    fpath.write_text(content, encoding="utf-8")
                    console.print(f"[green]Wrote {len(content)} bytes[/green]")
        elif command == "/edit":
            if not args.strip():
                console.print("[yellow]Usage: /edit <path>[/yellow]")
            else:
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath or not fpath.is_file():
                    console.print(f"[red]File not found: {args}[/red]")
                else:
                    instruction = console.input("[cyan]What to change: [/cyan]")
                    if instruction.strip():
                        original = fpath.read_text(encoding="utf-8", errors="ignore")
                        ep = (
                            f"Edit this file: {args.strip()}\n"
                            f"Instruction: {instruction}\n\n"
                            f"```\n{original[:30000]}\n```\n\n"
                            "Return ONLY the unified diff."
                        )
                        ep_parts = []
                        try:
                            async for chunk in self.client.stream_chat(
                                chat_id=str(uuid.uuid4()), prompt=ep, model=self.model,
                            ):
                                if chunk.get("content"):
                                    ep_parts.append(chunk["content"])
                            diff_text = "".join(ep_parts)
                            console.print(Syntax(diff_text, "diff", theme="monokai"))
                            confirm = console.input("[cyan]Apply? (y/n): [/cyan]")
                            if confirm.strip().lower() in ("y", "yes"):
                                try:
                                    r = await self.client.apply_diff(original, diff_text)
                                    applied = r.get("applied_content", "")
                                    if applied:
                                        fpath.write_text(applied, encoding="utf-8")
                                        console.print(f"[green]Applied[/green]")
                                    else:
                                        console.print("[yellow]Could not apply diff[/yellow]")
                                except Exception as e:
                                    console.print(f"[red]Apply failed: {e}[/red]")
                        except Exception as e:
                            console.print(f"[red]Error: {e}[/red]")
        elif command in ("/mention", "/attach"):
            if not args.strip():
                console.print("[yellow]Usage: /mention <path>[/yellow]")
            else:
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath or not fpath.is_file():
                    console.print(f"[red]File not found: {args}[/red]")
                else:
                    content = fpath.read_text(encoding="utf-8", errors="ignore")[:30000]
                    self.pending_attachments.append({"name": args.strip(), "content": content})
                    console.print(f"[green]Attached {args.strip()}[/green]")
        elif command == "/image":
            if not args.strip():
                console.print("[yellow]Usage: /image <path>[/yellow]")
            else:
                import base64
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath:
                    console.print("[red]Path outside project root.[/red]")
                elif not fpath.is_file():
                    console.print(f"[red]File not found: {args}[/red]")
                else:
                    try:
                        data = fpath.read_bytes()
                        if len(data) > 10 * 1024 * 1024:
                            console.print("[red]Image too large (10MB max).[/red]")
                        else:
                            b64 = base64.b64encode(data).decode("ascii")
                            ext = fpath.suffix.lower().lstrip(".")
                            mime_map = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}
                            mime = mime_map.get(ext, "image/png")
                            kb = len(data) // 1024
                            # Full base64 data URI — NOT truncated
                            uri = f"data:{mime};base64,{b64}"
                            self.pending_attachments.append({"name": args.strip(), "content": uri})
                            console.print(f"[green]Image attached: {args.strip()} ({kb}KB)[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
        elif command == "/paste":
            import base64
            try:
                from PIL import ImageGrab
                img = ImageGrab.grabclipboard()
                if img is None:
                    console.print("[yellow]No image on clipboard.[/yellow]")
                    console.print("[dim]Copy an image first, then /paste[/dim]")
                else:
                    import io
                    buf = io.BytesIO()
                    img.save(buf, format="PNG")
                    raw = buf.getvalue()
                    kb = len(raw) // 1024
                    b64 = base64.b64encode(raw).decode("ascii")
                    # Full base64 data URI — NOT truncated
                    uri = f"data:image/png;base64,{b64}"
                    self.pending_attachments.append({"name": "clipboard.png", "content": uri})
                    console.print(f"[green]Clipboard image ({kb}KB) attached.[/green]")
            except ImportError:
                console.print("[yellow]Pillow required for /paste.[/yellow]")
                console.print("[dim]Install: pip install Pillow[/dim]")
            except Exception as e:
                console.print(f"[red]Clipboard paste error: {e}[/red]")
        elif command == "/multi":
            if not args.strip():
                console.print("[yellow]Usage: /multi <prompt>[/yellow]")
            else:
                allowed, msg = check_tier(self.user, "multi")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    console.print("[cyan]Running multi-model...[/cyan]")
                    try:
                        results = await self.client.multi_chat(args.strip(), [
                            "google/gemini-flash-1.5", "anthropic/claude-3-haiku", "openai/gpt-4o-mini",
                        ])
                        for r in results:
                            color = "green" if r["status"] == "ok" else "red"
                            body = Markdown(r["response"][:2000]) if r["response"] else "[red]failed[/red]"
                            console.print(Panel(body, title=f"[{color}]{r['model']}[/{color}]", border_style=color))
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
        elif command == "/swarm":
            if not args.strip():
                console.print("[yellow]Usage: /swarm <prompt>[/yellow]")
            else:
                allowed, msg = check_tier(self.user, "swarm")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    console.print("[cyan]Running swarm...[/cyan]")
                    try:
                        result = await self.client.swarm(args.strip())
                        for r in result["agent_responses"]:
                            console.print(f"[dim]-- {r['model']} --[/dim]")
                            console.print(Markdown(r["response"][:1000]))
                        console.print(Panel(Markdown(result["synthesis"]), title="Synthesis", border_style="cyan"))
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
        elif command == "/rewind":
            n = 2
            if args.strip().isdigit():
                n = int(args.strip())
            if len(self.messages) < n:
                console.print(f"[yellow]Only {len(self.messages)} messages[/yellow]")
            else:
                self.messages = self.messages[:-n]
                console.print(f"[green]Rewound {n} messages.[/green]")
        elif command == "/fork":
            old_id = self.session_id
            self._save()
            self.session_id = str(uuid.uuid4())[:12]
            console.print(f"[green]Forked {old_id} -> {self.session_id}[/green]")
            self._save()
        elif command == "/copy":
            # Copy last assistant response to clipboard
            last_response = ""
            for m in reversed(self.messages):
                if m.get("role") == "assistant":
                    last_response = m.get("content", "")
                    break
            if not last_response:
                console.print("[yellow]No response to copy.[/yellow]")
            else:
                try:
                    import subprocess as _sp
                    # Try platform-native clipboard
                    if sys.platform == "win32":
                        _sp.run(["clip"], input=last_response.encode("utf-8"), check=True)
                    elif sys.platform == "darwin":
                        _sp.run(["pbcopy"], input=last_response.encode("utf-8"), check=True)
                    else:
                        _sp.run(["xclip", "-selection", "clipboard"], input=last_response.encode("utf-8"), check=True)
                    console.print(f"[green]Copied {len(last_response)} chars to clipboard.[/green]")
                except Exception:
                    # Fallback: print it so user can manually copy
                    console.print("[yellow]Clipboard not available. Last response:[/yellow]")
                    console.print(last_response[:500])
        elif command == "/export":
            # Export conversation to markdown file
            filename = args.strip() or f"msapling-export-{self.session_id}.md"
            lines = [f"# MSapling Session {self.session_id}\n"]
            lines.append(f"Project: {self.project_name}  \nModel: {self.model}  \nCost: ${self.cost_total:.4f}\n\n---\n")
            for m in self.messages:
                role = m.get("role", "unknown")
                content = m.get("content", "")
                if role == "system":
                    continue
                prefix = "**You:**" if role == "user" else "**Assistant:**"
                lines.append(f"\n{prefix}\n\n{content}\n")
            try:
                Path(filename).write_text("\n".join(lines), encoding="utf-8")
                console.print(f"[green]Exported to {filename}[/green]")
            except Exception as e:
                console.print(f"[red]Export failed: {e}[/red]")
        elif command == "/restore":
            # Restore a file from backup
            if not args.strip():
                from .storage import list_backups
                backups = list_backups(self.session_id)
                if not backups:
                    console.print("[yellow]No backups for this session.[/yellow]")
                else:
                    console.print(f"[cyan]Backups ({len(backups)}):[/cyan]")
                    for i, b in enumerate(backups[:20], 1):
                        console.print(f"  {i}. {b['name']}  ({b['size']} bytes)")
                    console.print("[dim]Usage: /restore <filename>[/dim]")
            else:
                from .storage import list_backups
                target = args.strip()
                backups = list_backups(self.session_id)
                found = None
                for b in backups:
                    if target in b["name"]:
                        found = b
                        break
                if not found:
                    console.print(f"[yellow]Backup not found: {target}[/yellow]")
                else:
                    from pathlib import Path as _Path
                    backup_path = _Path.home() / ".msapling" / "backups" / self.session_id / found["name"]
                    try:
                        content = backup_path.read_text(encoding="utf-8")
                        # Extract original filename from backup name (strip timestamp suffix)
                        orig_name = found["name"].rsplit(".", 1)[0].replace("_", "/")
                        fpath = Path(self.project_root) / orig_name
                        fpath.write_text(content, encoding="utf-8")
                        console.print(f"[green]Restored {orig_name} from backup.[/green]")
                    except Exception as e:
                        console.print(f"[red]Restore failed: {e}[/red]")
        elif command == "/diff":
            # Interactive git diff viewer
            try:
                r = subprocess.run(
                    ["git", "diff", "--stat"], cwd=self.project_root,
                    capture_output=True, text=True, timeout=10,
                )
                if not r.stdout.strip():
                    console.print("[yellow]No uncommitted changes.[/yellow]")
                else:
                    console.print(Panel(
                        Syntax(r.stdout[:3000], "diff", theme="monokai"),
                        title="[cyan]Uncommitted Changes (summary)[/cyan]",
                        border_style="cyan",
                    ))
                    # Full diff
                    r2 = subprocess.run(
                        ["git", "diff"], cwd=self.project_root,
                        capture_output=True, text=True, timeout=10,
                    )
                    if r2.stdout:
                        console.print(Syntax(r2.stdout[:8000], "diff", theme="monokai", line_numbers=True))
                        if len(r2.stdout) > 8000:
                            console.print(f"[dim]... {len(r2.stdout) - 8000} more chars (use /git diff for full)[/dim]")
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/hooks":
            if not args.strip():
                if self.hooks:
                    for event, cmds in self.hooks.items():
                        console.print(f"  [cyan]{event}:[/cyan]")
                        for hc in cmds:
                            console.print(f"    {hc}")
                else:
                    console.print("[yellow]No hooks configured.[/yellow]")
            else:
                hp = args.split(maxsplit=2)
                if len(hp) >= 3 and hp[0] == "add":
                    ev, hc = hp[1], hp[2]
                    if ev not in self.hooks:
                        self.hooks[ev] = []
                    self.hooks[ev].append(hc)
                    _save_hooks(self.hooks)
                    console.print(f"[green]Added hook: {ev} -> {hc}[/green]")
                elif len(hp) >= 2 and hp[0] == "remove":
                    ev = hp[1]
                    if ev in self.hooks:
                        del self.hooks[ev]
                        _save_hooks(self.hooks)
                        console.print(f"[green]Removed hooks for: {ev}[/green]")
                elif hp[0] == "clear":
                    self.hooks = {}
                    _save_hooks(self.hooks)
                    console.print("[green]All hooks cleared[/green]")
        elif command == "/mdrive":
            sub_parts = args.split() if args.strip() else ["status"]
            sub = sub_parts[0].lower()
            sub_arg = sub_parts[1] if len(sub_parts) > 1 else ""
            sub_arg2 = sub_parts[2] if len(sub_parts) > 2 else ""

            if sub == "status":
                console.print(f"  [cyan]Project:[/cyan]  {self.project_name}")
                try:
                    usage = await self.client.mdrive_usage()
                    total_bytes = usage.get("total_bytes", 0)
                    total_files = usage.get("total_files", 0)
                    kb = total_bytes / 1024 if total_bytes else 0
                    console.print(f"  [cyan]Storage:[/cyan]  {kb:.1f} KB across {total_files} files")
                except Exception:
                    console.print("  [dim]Storage stats unavailable[/dim]")
                console.print("  [dim]Commands: ls, push, pull, sync, history, trash, search[/dim]")

            elif sub == "ls":
                path = sub_arg or "/"
                try:
                    files = await self.client.list_files(self.project_name, path)
                    if not files:
                        console.print("[yellow]No files.[/yellow]")
                    else:
                        table = Table(title=f"MDrive: {self.project_name}{path}")
                        table.add_column("Name", style="cyan")
                        table.add_column("Size", justify="right")
                        table.add_column("Modified")
                        for f in files[:50]:
                            name = f.get("name", f.get("file_path", "?"))
                            size = f.get("size", f.get("size_bytes", 0))
                            modified = str(f.get("modified", f.get("updated_at", "")))[:19]
                            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
                            table.add_row(name, size_str, modified)
                        console.print(table)
                except Exception as e:
                    console.print(f"[red]{e}[/red]")

            elif sub == "push":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive push <file|glob>[/yellow]")
                else:
                    import glob as _glob
                    pattern = str(Path(self.project_root) / sub_arg)
                    matches = _glob.glob(pattern, recursive=True)
                    if not matches:
                        # Try as single file
                        fpath = Path(self.project_root) / sub_arg
                        if fpath.is_file():
                            matches = [str(fpath)]
                        else:
                            console.print(f"[red]No files matched: {sub_arg}[/red]")
                    pushed = 0
                    for fpath_str in matches:
                        fpath = Path(fpath_str)
                        if not fpath.is_file():
                            continue
                        rel = os.path.relpath(fpath_str, self.project_root).replace("\\", "/")
                        try:
                            content = fpath.read_text(encoding="utf-8", errors="ignore")
                            await self.client.mdrive_write(
                                self.project_name, rel, content,
                                agent_id="cli", change_summary=f"Pushed from CLI",
                            )
                            console.print(f"  [green]Pushed {rel}[/green]")
                            pushed += 1
                        except Exception as e:
                            console.print(f"  [red]{rel}: {e}[/red]")
                    if pushed > 1:
                        console.print(f"[green]{pushed} files pushed.[/green]")

            elif sub == "pull":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive pull <file>[/yellow]")
                else:
                    try:
                        content = await self.client.mdrive_read(self.project_name, sub_arg)
                        fpath = Path(self.project_root) / sub_arg
                        fpath.parent.mkdir(parents=True, exist_ok=True)
                        fpath.write_text(content, encoding="utf-8")
                        console.print(f"[green]Pulled {sub_arg} ({len(content)} bytes)[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "sync":
                console.print("[cyan]Syncing local ↔ MDrive...[/cyan]")
                try:
                    remote_files = await self.client.list_files(self.project_name)
                    remote_set = {f.get("name", f.get("file_path", "")): f for f in remote_files}
                    # Pull remote files that don't exist locally
                    pulled = 0
                    for name, meta in remote_set.items():
                        local_path = Path(self.project_root) / name
                        if not local_path.exists():
                            try:
                                content = await self.client.mdrive_read(self.project_name, name)
                                local_path.parent.mkdir(parents=True, exist_ok=True)
                                local_path.write_text(content, encoding="utf-8")
                                pulled += 1
                            except Exception:
                                pass
                    console.print(f"  [green]Pulled {pulled} new files from MDrive.[/green]")
                except Exception as e:
                    console.print(f"[red]Sync failed: {e}[/red]")

            elif sub == "history":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive history <file>[/yellow]")
                else:
                    try:
                        versions = await self.client.mdrive_versions(self.project_name, sub_arg)
                        if not versions:
                            console.print(f"[yellow]No version history for {sub_arg}[/yellow]")
                        else:
                            table = Table(title=f"Versions: {sub_arg}")
                            table.add_column("#", style="cyan")
                            table.add_column("Version")
                            table.add_column("Size", justify="right")
                            table.add_column("By")
                            table.add_column("Date")
                            table.add_column("Summary")
                            for v in versions[:20]:
                                ver_num = str(v.get("version_number", "?"))
                                size = v.get("size_bytes", 0)
                                by = v.get("created_by_agent", v.get("created_by_user", "?"))[:15]
                                date = str(v.get("created_at", ""))[:19]
                                summary = (v.get("change_summary", "") or "")[:40]
                                table.add_row(ver_num, v.get("id", "?")[:8], f"{size:,}", by, date, summary)
                            console.print(table)
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "restore":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive restore <file> [version_id][/yellow]")
                else:
                    try:
                        result = await self.client.mdrive_restore(self.project_name, sub_arg, sub_arg2)
                        console.print(f"[green]Restored {sub_arg} to version {sub_arg2 or 'latest'}[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "trash":
                try:
                    files = await self.client.mdrive_trash(self.project_name)
                    if not files:
                        console.print("[yellow]Trash is empty.[/yellow]")
                    else:
                        for f in files[:30]:
                            name = f.get("file_path", f.get("name", "?"))
                            deleted = str(f.get("deleted_at", ""))[:19]
                            console.print(f"  [red]{name}[/red]  [dim]deleted {deleted}[/dim]")
                        console.print(f"[dim]Recover with: /mdrive undelete <file>[/dim]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")

            elif sub == "undelete":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive undelete <file>[/yellow]")
                else:
                    try:
                        await self.client.mdrive_undelete(self.project_name, sub_arg)
                        console.print(f"[green]Restored {sub_arg} from trash.[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "search":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive search <query>[/yellow]")
                else:
                    query = " ".join(sub_parts[1:])
                    try:
                        results = await self.client.mdrive_search(self.project_name, query)
                        if not results:
                            console.print("[yellow]No results.[/yellow]")
                        else:
                            for r in results[:15]:
                                name = r.get("file_path", r.get("name", "?"))
                                preview = (r.get("preview", r.get("snippet", "")) or "")[:80]
                                console.print(f"  [cyan]{name}[/cyan]  {preview}")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            else:
                console.print("[yellow]MDrive commands: status, ls, push, pull, sync, history, restore, trash, undelete, search[/yellow]")
        # ─── Budget / Cost Ceiling ────────────────────────────────────
        elif command == "/budget":
            if not args.strip():
                if self.cost_ceiling is not None:
                    total = self._total_session_cost()
                    console.print(f"[cyan]Budget:[/cyan] ${total:.4f} / ${self.cost_ceiling:.4f}")
                    remaining = max(0, self.cost_ceiling - total)
                    console.print(f"[cyan]Remaining:[/cyan] ${remaining:.4f}")
                else:
                    console.print(f"[cyan]No budget set.[/cyan] Session cost so far: ${self._total_session_cost():.4f}")
                    console.print("[dim]Set with: /budget 0.50[/dim]")
            elif args.strip().lower() in ("off", "none", "clear"):
                self.cost_ceiling = None
                console.print("[green]Budget removed (no ceiling).[/green]")
            else:
                try:
                    val = float(args.strip().lstrip("$"))
                    if val <= 0:
                        console.print("[yellow]Budget must be > $0.[/yellow]")
                    else:
                        self.cost_ceiling = val
                        console.print(f"[green]Budget set: ${val:.4f}. All workers stop when total hits this.[/green]")
                except ValueError:
                    console.print("[yellow]Usage: /budget <amount> or /budget off[/yellow]")
        # ─── Worker Commands (multi-chat) ────────────────────────────
        elif command == "/workers":
            if not self.workers:
                console.print("[yellow]No workers. Start with multi-chat (M) at startup.[/yellow]")
            else:
                table = Table(title=f"Workers in {self.project_name}")
                table.add_column("#", style="cyan")
                table.add_column("Name", style="bold")
                table.add_column("Model")
                table.add_column("Status")
                table.add_column("Tokens", justify="right")
                table.add_column("Cost", justify="right")
                for i, w in enumerate(self.workers, 1):
                    active = "[green]>>>[/green] " if w["chat_id"] == self.chat_id else "    "
                    model_short = w["model"].split("/")[-1] if "/" in w["model"] else w["model"]
                    console.print(f"{active}[cyan]{i}.[/cyan] {w['name']}  [dim]{model_short}[/dim]  {w['status']}  {w['tokens']:,} tok  ${w['cost']:.4f}")
        elif command == "/join":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /join <name or #>[/yellow]")
            else:
                target = args.strip()
                found = None
                # By number
                try:
                    idx = int(target) - 1
                    if 0 <= idx < len(self.workers):
                        found = self.workers[idx]
                except ValueError:
                    pass
                # By name
                if not found:
                    for w in self.workers:
                        if w["name"].lower() == target.lower():
                            found = w
                            break
                if found:
                    # Save current context to the worker we're leaving
                    for w in self.workers:
                        if w["chat_id"] == self.chat_id:
                            w["messages"] = list(self.messages)
                            break
                    self.chat_id = found["chat_id"]
                    self.model = found["model"]
                    self.messages = list(found.get("messages", []))
                    console.print(f"[green]Joined worker: {found['name']} ({found['model'].split('/')[-1]})[/green]")
                else:
                    console.print(f"[yellow]Worker not found: {target}[/yellow]")
        elif command == "/broadcast":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /broadcast <message>[/yellow]")
            elif not self._check_cost_ceiling():
                pass  # Budget exceeded
            else:
                msg = args.strip()
                console.print(f"[cyan]Broadcasting to {len(self.workers)} in parallel...[/cyan]")

                async def _broadcast_one(w):
                    try:
                        parts = []
                        async for chunk in self.client.stream_chat(
                            chat_id=w["chat_id"], prompt=msg, model=w["model"],
                            project_name=self.project_name, history=w.get("messages", [])[-10:],
                        ):
                            content = chunk.get("content", "")
                            if content:
                                parts.append(content)
                            if chunk.get("type") == "usage":
                                usage = chunk.get("usage", {})
                                tok = usage.get("total_tokens", 0)
                                cst = float(chunk.get("cost", 0))
                                w["tokens"] += tok
                                w["cost"] += cst
                                self.tokens_total += tok
                                self.cost_total += cst
                        response = "".join(parts)
                        if response:
                            w.setdefault("messages", []).append({"role": "user", "content": msg})
                            w["messages"].append({"role": "assistant", "content": response})
                        return w["name"], response, None
                    except Exception as e:
                        return w["name"], "", e

                results = await asyncio.gather(*[_broadcast_one(w) for w in self.workers])
                for name, response, err in results:
                    if err:
                        console.print(f"  [red]{name}: {err}[/red]")
                    elif response:
                        preview = f"{response[:120]}..." if len(response) > 120 else response
                        console.print(f"  [green]{name}[/green]: {preview}")
                    else:
                        console.print(f"  [yellow]{name}[/yellow]: (no response)")
        elif command == "/collect":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            else:
                for w in self.workers:
                    msgs = w.get("messages", [])
                    last = ""
                    for m in reversed(msgs):
                        if m.get("role") == "assistant":
                            last = m.get("content", "")[:200]
                            break
                    console.print(f"  [cyan]{w['name']}[/cyan] ({w['status']}): {last or '[no response yet]'}")
        elif command == "/kill":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /kill <name or #>[/yellow]")
            else:
                target = args.strip()
                found_idx = None
                try:
                    idx = int(target) - 1
                    if 0 <= idx < len(self.workers):
                        found_idx = idx
                except ValueError:
                    for i, w in enumerate(self.workers):
                        if w["name"].lower() == target.lower():
                            found_idx = i
                            break
                if found_idx is not None:
                    removed = self.workers.pop(found_idx)
                    console.print(f"[green]Killed worker: {removed['name']}[/green]")
                    if self.chat_id == removed["chat_id"] and self.workers:
                        self.chat_id = self.workers[0]["chat_id"]
                        console.print(f"[dim]Switched to: {self.workers[0]['name']}[/dim]")
                else:
                    console.print(f"[yellow]Worker not found: {target}[/yellow]")
        else:
            console.print(f"[yellow]Unknown command: {command}. Type /help[/yellow]")

        return True

    async def _compact_context(self):
        """Compress context using backend Layer 0/1/2 system when available,
        or local LLM summarization as fallback."""

        # ── Strategy 1: Server-side compact (triggers refresh_summaries) ──
        if self.chat_id:
            console.print("[cyan]Requesting server-side context compression (Layer 0/1/2)...[/cyan]")
            try:
                # The backend auto-runs refresh_summaries on each message.
                # Sending a lightweight system-level "compact" hint triggers it.
                # We fetch updated history which includes saga + blocks.
                server_history = await self.client.get_chat_history(self.chat_id, limit=20)
                if server_history:
                    # Replace local messages with server-compressed version
                    sys_msgs = [m for m in self.messages if m.get("role") == "system"]
                    self.messages = sys_msgs + server_history
                    console.print(f"[green]Context refreshed from server ({len(server_history)} messages with Layer 1/2 compression).[/green]")

                    # Show layer stats
                    try:
                        stats = await self.client.get_context_stats(self.chat_id)
                        tokens = stats.get("tokens_used", 0)
                        console.print(f"[dim]  Server stats: {tokens:,} tokens used in this chat[/dim]")
                    except Exception:
                        pass
                    return
            except Exception as e:
                console.print(f"[yellow]Server compact unavailable ({e}), using local fallback...[/yellow]")

        # ── Strategy 2: Local LLM-based compression (offline fallback) ──
        if len(self.messages) <= 6:
            console.print("[yellow]Not enough messages to compact.[/yellow]")
            return
        sys_msgs = [m for m in self.messages if m.get("role") == "system"]
        non_sys = [m for m in self.messages if m.get("role") != "system"]
        recent = non_sys[-5:]
        old_msgs = non_sys[:-5]
        if not old_msgs:
            console.print("[yellow]Nothing to summarize.[/yellow]")
            return
        n_old = len(old_msgs)
        console.print(f"[cyan]Summarizing {n_old} older messages via LLM...[/cyan]")
        parts = []
        for m in old_msgs:
            role = m.get("role", "unknown")
            text = m.get("content", "")[:2000]
            parts.append(f"{role}: {text}")
        transcript = "\n\n".join(parts)
        if len(transcript) > 12000:
            transcript = transcript[:12000] + "\n... (truncated)"
        summary_prompt = (
            "Summarize the following conversation into a concise recap. "
            "Preserve key decisions, code changes, file paths, and action items. "
            "Keep it under 500 words.\n\n"
            "--- Conversation ---\n" + transcript + "\n--- End ---"
        )
        try:
            summary = await self.client.chat_once(summary_prompt, self.model)
            if not summary.strip():
                summary = f"[Previous {n_old} messages compacted.]"
            self.messages = sys_msgs + [
                {"role": "system", "content": f"[Conversation summary]\n{summary}"}
            ] + recent
            console.print(f"[green]Compacted {n_old} messages → {len(self.messages)} remaining.[/green]")
        except Exception as exc:
            self.messages = sys_msgs + [
                {"role": "system", "content": f"[Previous {n_old} messages compacted. Summary unavailable: {exc}]"}
            ] + recent
            console.print(f"[yellow]LLM summary failed. {len(self.messages)} messages remaining.[/yellow]")

    async def _generate_project_instructions(self):
        """Generate .msapling.md from project analysis."""
        console.print("[cyan]Analyzing project...[/cyan]")
        files = build_file_tree(self.project_root, max_files=20)
        context = read_files_as_context(self.project_root, files[:10], max_size_kb=30)
        prompt = (
            "Analyze this project and generate a .msapling.md instructions file. "
            "Include: project description, tech stack, key files, coding conventions, "
            "testing commands, and any important notes."
            + "\n\n" + context[:8000]
        )
        parts = []
        try:
            async for chunk in self.client.stream_chat(
                chat_id=str(uuid.uuid4()), prompt=prompt, model=self.model,
            ):
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
            result = "".join(parts)
            out_path = Path(self.project_root) / ".msapling.md"
            out_path.write_text(result, encoding="utf-8")
            console.print(f"[green]Generated {out_path}[/green]")
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")

    def _save(self):
        save_session(
            session_id=self.session_id,
            messages=self.messages,
            model=self.model,
            project_root=self.project_root,
            cost_total=self.cost_total,
            tokens_total=self.tokens_total,
            metadata={
                "project_name": self.project_name,
                "chat_id": self.chat_id,
                "workers": [
                    {"name": w["name"], "chat_id": w["chat_id"], "model": w["model"]}
                    for w in self.workers
                ],
            },
        )


async def run_shell(model=None, project=None, resume_id=None):
    """Entry point for the interactive shell."""
    shell = InteractiveShell(model=model, project=project, resume_id=resume_id)
    await shell.start()
