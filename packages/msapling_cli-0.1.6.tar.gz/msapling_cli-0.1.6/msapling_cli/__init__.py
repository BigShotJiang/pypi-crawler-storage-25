"""MSapling CLI - Multi-chat AI development environment in your terminal."""
__version__ = "0.1.6"
