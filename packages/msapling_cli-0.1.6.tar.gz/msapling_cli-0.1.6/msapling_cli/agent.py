"""Agentic tool-use loop for MSapling CLI.

This is the core differentiator — instead of the user manually running
/read, /edit, /run, the AI decides what tools to use based on the conversation.

The agent loop:
1. User sends a message
2. LLM responds — may include tool calls in structured format
3. CLI executes tool calls locally (read file, write file, run command, grep, glob)
4. Tool results are fed back to the LLM
5. Repeat until LLM responds with just text (no more tool calls)

This makes MSapling CLI behave like Claude Code — the AI autonomously
reads your code, edits files, and runs commands.
"""
from __future__ import annotations

import asyncio
import html as html_module
import json
import os
import re
import subprocess
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.status import Status

from .tui import (
    console,
    render_approval_prompt,
    tool_header,
    tool_result_display,
    shimmer_text,
)

# Maximum agent loop iterations to prevent infinite loops
MAX_AGENT_STEPS = 15

# ─── Permission Profiles ─────────────────────────────────────────────
# Matches Claude Code / Codex CLI permission model:
#   "ask"      = Prompt for write/run tools (default, safe)
#   "auto"     = Auto-approve file edits within project, ask for commands
#   "readonly" = Block all write tools, read-only browsing
#   "full"     = Approve everything without asking (like --yolo)
#   "plan"     = Same as readonly (used by plan mode)

_permission_mode: str = "ask"

# Per-tool session overrides (from "always" answers)
_permissions: Dict[str, bool] = {}

# Read-only tools that never require approval in any mode
_READ_ONLY_TOOLS = frozenset({
    "read_file", "glob_files", "grep_search", "web_search", "web_fetch",
    "cost_check", "list_directory", "ask_user", "todo_list",
})

# Write tools blocked in readonly/plan mode
_WRITE_TOOLS = frozenset({"write_file", "edit_file", "run_command"})


def reset_permissions() -> None:
    """Reset all session permissions (called at session start)."""
    global _permission_mode
    _permissions.clear()
    _permission_mode = "ask"


def set_permission_mode(mode: str) -> str:
    """Set the permission profile. Returns the active mode."""
    global _permission_mode
    valid = ("ask", "auto", "readonly", "full", "plan")
    if mode not in valid:
        return _permission_mode
    _permission_mode = mode
    return _permission_mode


def get_permission_mode() -> str:
    return _permission_mode


def _truncated_lines(text: str, max_lines: int) -> str:
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    return "\n".join(lines[:max_lines]) + f"\n  ... ({len(lines) - max_lines} more lines)"


def _prompt_for_approval(tool_name: str, args: Dict[str, Any]) -> str:
    """Show a styled preview and ask for approval. Returns 'y', 'n', or 'always'."""
    return render_approval_prompt(tool_name, args)

# Tools the agent can use — matches Claude Code's tool set
AGENT_TOOLS_SCHEMA = [
    {
        "name": "read_file",
        "description": "Read a file's contents. Use this to understand code before making changes.",
        "parameters": {"path": "string (relative file path)", "offset": "int (optional, start line)", "limit": "int (optional, max lines)"},
    },
    {
        "name": "write_file",
        "description": "Create or overwrite a file with new content.",
        "parameters": {"path": "string (relative file path)", "content": "string (full file content)"},
    },
    {
        "name": "edit_file",
        "description": "Make a targeted edit to a file by replacing a specific string. Use this instead of write_file when making small changes.",
        "parameters": {"path": "string (relative file path)", "old_string": "string (exact text to find)", "new_string": "string (replacement text)"},
    },
    {
        "name": "run_command",
        "description": "Execute a shell command and return its output. Use for running tests, builds, git operations, etc.",
        "parameters": {"command": "string (the command to run)"},
    },
    {
        "name": "glob_files",
        "description": "Find files matching a glob pattern. Use to discover project structure.",
        "parameters": {"pattern": "string (glob pattern like '**/*.py' or 'src/**/*.ts')"},
    },
    {
        "name": "grep_search",
        "description": "Search file contents for a regex pattern. Returns matching lines with file paths and line numbers.",
        "parameters": {"pattern": "string (regex pattern)", "path": "string (optional, directory to search, default '.')"},
    },
    {
        "name": "web_search",
        "description": "Search the web for current information. Uses MSapling's backend search. Use when the user asks about recent events, documentation, or anything that might be outdated in your training data.",
        "parameters": {"query": "string (search query)"},
    },
    {
        "name": "web_fetch",
        "description": "Fetch the content of a specific URL. Returns the page text (HTML stripped). Use for reading documentation, API references, or specific web pages.",
        "parameters": {"url": "string (full URL to fetch)"},
    },
    {
        "name": "list_directory",
        "description": "List files and directories at a path with sizes and types. More detailed than glob_files.",
        "parameters": {"path": "string (relative directory path, default '.')"},
    },
    {
        "name": "ask_user",
        "description": "Ask the user a clarifying question when you need more information to proceed. Use sparingly — only when truly ambiguous.",
        "parameters": {"question": "string (the question to ask)"},
    },
    {
        "name": "todo_list",
        "description": "Manage a task checklist for the current session. Use to plan multi-step work and track progress.",
        "parameters": {"action": "string ('add', 'done', 'list', 'clear')", "item": "string (task description, for 'add' and 'done')"},
    },
    {
        "name": "search_replace_all",
        "description": "Replace ALL occurrences of a string in a file (not just the first). Use when renaming a variable or updating all imports.",
        "parameters": {"path": "string (relative file path)", "old_string": "string (text to find)", "new_string": "string (replacement)"},
    },
    {
        "name": "cost_check",
        "description": "Check the user's remaining fuel credits and session cost before expensive operations. Use this before large file writes or multi-step tasks.",
        "parameters": {},
    },
    {
        "name": "model_switch",
        "description": "Switch to a different LLM model mid-task. Use a cheaper model (gemini-flash, gpt-4o-mini) for grunt work like formatting or boilerplate, and a premium model (claude-3.5-sonnet, gpt-4o) for complex reasoning.",
        "parameters": {"model": "string (model ID like 'google/gemini-2.0-flash-001' or 'openai/gpt-4o')"},
    },
]

_LOCAL_FILESYSTEM_KEYWORDS = (
    "directory", "folder", "file tree", "file directory", "list files",
    "project files", "read file", "open file", "inspect", "scan", "check",
)

_LOCAL_ACCESS_REFUSAL_PHRASES = (
    "unable to directly access local files",
    "cannot directly access local files",
    "can't directly access local files",
    "unable to access local files",
    "cannot access local files",
    "can't access local files",
    "unable to directly access files on your computer",
    "do not have direct access to local files",
    "don't have direct access to local files",
    "cannot browse your filesystem",
    "cannot inspect local files",
)


def _looks_like_local_filesystem_request(prompt: str) -> bool:
    text = str(prompt or "")
    lowered = text.lower()
    has_path = bool(re.search(r"[A-Za-z]:\\|/[^\s]+", text))
    return has_path or any(keyword in lowered for keyword in _LOCAL_FILESYSTEM_KEYWORDS)


def _looks_like_local_access_refusal(response_text: str) -> bool:
    lowered = str(response_text or "").lower()
    return any(phrase in lowered for phrase in _LOCAL_ACCESS_REFUSAL_PHRASES)


AGENT_SYSTEM_PROMPT = """You are MSapling, an AI coding assistant running in a CLI terminal.
You have access to tools for reading files, writing files, editing code, running commands, searching, and cost management.

When the user asks you to do something with code:
1. First READ the relevant files to understand the code
2. Then EDIT or WRITE files to make changes
3. Then RUN tests or commands to verify

To use a tool, respond with a JSON block in this format:
```tool
{"tool": "tool_name", "args": {"param1": "value1"}}
```

Available tools:
- read_file: Read a file (supports text, PDF, notebooks). Args: path, offset (optional), limit (optional)
- write_file: Create/overwrite a file. Args: path, content
- edit_file: Replace first occurrence of a string. Args: path, old_string, new_string
- search_replace_all: Replace ALL occurrences in a file. Args: path, old_string, new_string
- run_command: Execute a shell command. Args: command
- list_directory: List files with sizes and types. Args: path (default ".")
- glob_files: Find files by pattern. Args: pattern
- grep_search: Search file contents. Args: pattern, path (optional)
- web_search: Search the web via MSapling backend. Args: query
- web_fetch: Fetch content of a specific URL. Args: url
- ask_user: Ask the user a clarifying question. Args: question
- todo_list: Manage task checklist. Args: action (add/done/list/clear), item
- cost_check: Check remaining fuel credits. No args.
- model_switch: Switch model mid-task. Args: model

Tips: Use cost_check before expensive tasks. Use model_switch for cheaper models on grunt work. Use search_replace_all for renaming variables across a file.

You can use multiple tools in one response. After tool results, continue reasoning.
When you're done (no more tools needed), just respond with your final message.

Keep responses concise. Use diffs when showing code changes.
"""


def _safe_path(project_root: str, rel_path: str) -> Optional[Path]:
    """Validate path stays within project root."""
    try:
        resolved = (Path(project_root) / rel_path.strip()).resolve()
        root_resolved = Path(project_root).resolve()
        if resolved == root_resolved or resolved.is_relative_to(root_resolved):
            return resolved
    except Exception:
        pass
    return None


def _extract_tool_calls(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """Extract tool call blocks from LLM response text.

    Returns (clean_text, tool_calls) where clean_text has tool blocks removed.
    """
    tool_calls = []
    clean_parts = []

    # Match ```tool ... ``` blocks
    pattern = r'```tool\s*\n(.*?)\n```'
    last_end = 0
    for match in re.finditer(pattern, text, re.DOTALL):
        clean_parts.append(text[last_end:match.start()])
        try:
            tool_data = json.loads(match.group(1).strip())
            if isinstance(tool_data, dict) and "tool" in tool_data:
                tool_calls.append(tool_data)
        except json.JSONDecodeError:
            clean_parts.append(match.group(0))  # Keep invalid blocks as text
        last_end = match.end()
    clean_parts.append(text[last_end:])

    # Also try inline JSON tool calls (fallback)
    if not tool_calls:
        for match in re.finditer(r'\{"tool"\s*:\s*"(\w+)"[^}]*\}', text):
            try:
                tool_data = json.loads(match.group(0))
                if "tool" in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                continue

    return "".join(clean_parts).strip(), tool_calls


def _check_approval(tool_name: str, args: Dict[str, Any]) -> Optional[str]:
    """Check whether the user approves executing this tool.

    Returns ``None`` if approved (proceed), or a skip message string.

    Permission modes:
      ask      — prompt for write/run tools
      auto     — auto-approve edits in project, prompt for run_command
      readonly — block all write tools
      full     — approve everything silently
      plan     — same as readonly
    """
    # Read-only tools always pass
    if tool_name in _READ_ONLY_TOOLS:
        return None

    # readonly / plan mode: block all write tools
    if _permission_mode in ("readonly", "plan"):
        if tool_name in _WRITE_TOOLS:
            return f"Blocked: {tool_name} not allowed in {_permission_mode} mode"
        return None

    # full mode: approve everything
    if _permission_mode == "full":
        return None

    # auto mode: approve file edits silently, ask for commands
    if _permission_mode == "auto":
        if tool_name in ("write_file", "edit_file"):
            return None  # auto-approve file edits
        if tool_name == "run_command":
            # Still ask for commands (safety)
            pass  # Fall through to prompt
        else:
            return None

    # Per-tool session override (from previous "always" answer)
    if _permissions.get(tool_name):
        return None

    # ask mode (default): prompt user
    answer = _prompt_for_approval(tool_name, args)
    if answer == "always":
        _permissions[tool_name] = True
        return None
    if answer == "y":
        return None
    return "Skipped by user"


def _web_search(query: str) -> str:
    """Search the web using DuckDuckGo Lite (HTML) and extract results.

    Tries the MSapling backend /api/tools/web-research endpoint first.
    Falls back to a direct DuckDuckGo Lite HTML scrape via httpx.
    """
    import httpx as _httpx

    # --- Attempt 1: MSapling backend web-research endpoint ---
    try:
        from .config import get_settings, get_token
        settings = get_settings()
        api_url = settings.api_url.rstrip("/")
        token = get_token()
        cookies = {"msaplingauth": token} if token else {}
        search_url = f"https://www.google.com/search?q={quote_plus(query)}"
        resp = _httpx.post(
            f"{api_url}/api/tools/web-research",
            json={"url": search_url},
            cookies=cookies,
            timeout=15.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            content = data.get("content", data.get("text", ""))
            if content and len(content) > 20:
                # Truncate to keep context reasonable
                return content[:8000]
    except Exception:
        pass  # Fall through to DuckDuckGo

    # --- Attempt 2: DuckDuckGo Lite HTML scrape ---
    try:
        resp = _httpx.get(
            "https://lite.duckduckgo.com/lite/",
            params={"q": query},
            headers={"User-Agent": "MSapling-CLI/0.1"},
            timeout=10.0,
            follow_redirects=True,
        )
        if resp.status_code != 200:
            return f"Web search failed (HTTP {resp.status_code})"

        body = resp.text
        results = []

        # Extract result snippets from DuckDuckGo Lite HTML
        # DDG Lite uses <a class="result-link"> and <td class="result-snippet">
        link_pattern = re.compile(
            r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_pattern = re.compile(
            r'<td\s+class="result-snippet">(.*?)</td>',
            re.DOTALL,
        )

        links = link_pattern.findall(body)
        snippets = snippet_pattern.findall(body)

        for i, (url, title_html) in enumerate(links[:8]):
            title = re.sub(r"<[^>]+>", "", title_html).strip()
            title = html_module.unescape(title)
            snippet = ""
            if i < len(snippets):
                snippet = re.sub(r"<[^>]+>", "", snippets[i]).strip()
                snippet = html_module.unescape(snippet)
            results.append(f"{i+1}. {title}\n   {url}\n   {snippet}")

        if results:
            return f"Web search results for: {query}\n\n" + "\n\n".join(results)

        # Fallback: extract any text content from the page
        text = re.sub(r"<[^>]+>", " ", body)
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            return f"Web search results for: {query}\n\n{text[:4000]}"

        return "Web search returned no results."
    except Exception as e:
        return f"Web search error: {e}"


# ─── Command Sandbox ─────────────────────────────────────────────────
# Block dangerous command patterns. Not OS-level but catches common mistakes.

_BLOCKED_COMMAND_PATTERNS = [
    r"\brm\s+(-[rRf]+\s+)?/",           # rm -rf /
    r"\brm\s+-[rRf]*\s+~",              # rm -rf ~
    r"\brm\s+-[rRf]*\s+\.\.",           # rm -rf ..
    r"\bsudo\b",                          # sudo anything
    r"\bchmod\s+777\b",                  # chmod 777
    r"\bchmod\s+-R\b",                   # chmod -R (recursive)
    r"\bmkfs\b",                          # format filesystem
    r"\bdd\s+if=",                       # dd disk write
    r"\b:()\s*\{",                        # fork bomb
    r"\bcurl\b.*\|\s*bash",             # curl | bash
    r"\bwget\b.*\|\s*bash",            # wget | bash
    r"\bcurl\b.*\|\s*sh",              # curl | sh
    r"\bwget\b.*\|\s*sh",             # wget | sh
    r">\s*/dev/sd",                      # write to disk device
    r"\bshutdown\b",                     # shutdown
    r"\breboot\b",                       # reboot
    r"\bkill\s+-9\s+1\b",              # kill init
    r"\biptables\b",                     # firewall rules
    r"\bufw\b",                          # firewall
]

_sandbox_enabled: bool = True


def _check_command_sandbox(command: str) -> Optional[str]:
    """Check if a command is blocked by the sandbox. Returns error message or None."""
    if not _sandbox_enabled:
        return None
    cmd_lower = command.lower().strip()
    for pattern in _BLOCKED_COMMAND_PATTERNS:
        if re.search(pattern, cmd_lower):
            return f"Blocked by sandbox: '{command[:60]}' matches dangerous pattern. Use /sandbox off to disable."
    return None


def set_sandbox(enabled: bool) -> bool:
    global _sandbox_enabled
    _sandbox_enabled = enabled
    return _sandbox_enabled


# Strong references to background tasks so they don't get GC'd mid-flight.
# See: https://docs.python.org/3/library/asyncio-task.html#creating-tasks
_background_tasks: set = set()

# Agent todo list (managed via todo_list tool)
_agent_todos: List[Dict[str, Any]] = []


def _mdrive_auto_push(project_root: str, rel_path: str, content: str, project_name: str = "", agent_id: str = "cli-agent"):
    """Background push to MDrive after local file write. Best-effort, non-blocking."""
    if not project_name:
        return
    try:
        import asyncio as _aio
        from .api import MSaplingClient

        async def _push():
            client = MSaplingClient()
            try:
                await client.mdrive_write(
                    project_name, rel_path, content,
                    agent_id=agent_id,
                    change_summary="Auto-pushed by agent tool",
                )
            finally:
                await client.close()

        try:
            loop = _aio.get_running_loop()
            task = loop.create_task(_push())
            # Hold strong reference until task completes
            _background_tasks.add(task)
            task.add_done_callback(_background_tasks.discard)
        except RuntimeError:
            _aio.run(_push())
    except Exception:
        pass  # Best-effort, never block the agent


def _execute_tool(
    tool_name: str,
    args: Dict[str, Any],
    project_root: str,
    hooks_mgr: Any = None,
    model: str = "",
    project_name: str = "",
) -> str:
    """Execute a single tool call locally. Returns result as string.

    When *hooks_mgr* is provided (a HooksManager), the function fires
    *on_file_write* hooks after a successful write_file or edit_file.
    When *project_name* is set, auto-pushes written files to MDrive.
    """

    # --- Approval gate for mutating tools ---
    skip_msg = _check_approval(tool_name, args)
    if skip_msg is not None:
        return skip_msg

    if tool_name == "read_file":
        path = args.get("path", "")
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            ext = fpath.suffix.lower()

            # PDF reading
            if ext == ".pdf":
                try:
                    import pdfplumber
                    text_parts = []
                    with pdfplumber.open(fpath) as pdf:
                        for i, page in enumerate(pdf.pages[:30]):
                            page_text = page.extract_text() or ""
                            if page_text.strip():
                                text_parts.append(f"--- Page {i+1} ---\n{page_text}")
                    content = "\n\n".join(text_parts) if text_parts else "(no extractable text)"
                except ImportError:
                    return "Error: PDF reading requires pdfplumber. Install: pip install pdfplumber"

            # Jupyter notebook reading
            elif ext == ".ipynb":
                try:
                    nb = json.loads(fpath.read_text(encoding="utf-8"))
                    cells = nb.get("cells", [])
                    parts = []
                    for i, cell in enumerate(cells):
                        cell_type = cell.get("cell_type", "code")
                        source = "".join(cell.get("source", []))
                        if cell_type == "markdown":
                            parts.append(f"[Markdown cell {i+1}]\n{source}")
                        else:
                            parts.append(f"[Code cell {i+1}]\n```\n{source}\n```")
                            outputs = cell.get("outputs", [])
                            for out in outputs[:3]:
                                if "text" in out:
                                    parts.append("Output: " + "".join(out["text"])[:500])
                    content = "\n\n".join(parts)
                except Exception as e:
                    return f"Error parsing notebook: {e}"

            # Standard text file
            else:
                content = fpath.read_text(encoding="utf-8", errors="ignore")

            offset = int(args.get("offset", 0))
            limit = int(args.get("limit", 0))
            if offset or limit:
                lines = content.splitlines(keepends=True)
                start = max(0, offset - 1) if offset else 0
                end = start + limit if limit else len(lines)
                content = "".join(lines[start:end])
            if len(content) > 50000:
                content = content[:50000] + "\n... [truncated at 50KB]"
            return content
        except Exception as e:
            return f"Error reading {path}: {e}"

    elif tool_name == "write_file":
        path = args.get("path", "")
        content = args.get("content", "")
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        try:
            fpath.parent.mkdir(parents=True, exist_ok=True)
            fpath.write_text(content, encoding="utf-8")
            if hooks_mgr is not None:
                hooks_mgr.run(
                    "on_file_write", project_root,
                    project=project_root, model=model,
                    file=str(fpath), tool="write_file",
                )
            # Auto-push to MDrive (best-effort, non-blocking)
            _mdrive_auto_push(project_root, path, content, project_name)
            return f"Wrote {len(content)} bytes to {path}"
        except Exception as e:
            return f"Error writing {path}: {e}"

    elif tool_name == "edit_file":
        path = args.get("path", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
            if old_string not in content:
                return f"Error: old_string not found in {path}. The file may have changed."
            # Backup before editing (like Claude Code's file-history)
            try:
                from .storage import backup_file
                import hashlib
                session_key = hashlib.md5(project_root.encode()).hexdigest()[:12]
                backup_file(path, content, session_key)
            except Exception:
                pass
            new_content = content.replace(old_string, new_string, 1)
            fpath.write_text(new_content, encoding="utf-8")
            if hooks_mgr is not None:
                hooks_mgr.run(
                    "on_file_write", project_root,
                    project=project_root, model=model,
                    file=str(fpath), tool="edit_file",
                )
            # Auto-push to MDrive (best-effort, non-blocking)
            _mdrive_auto_push(project_root, path, new_content, project_name)
            return f"Edited {path}: replaced {len(old_string)} chars with {len(new_string)} chars"
        except Exception as e:
            return f"Error editing {path}: {e}"

    elif tool_name == "run_command":
        command = args.get("command", "")
        if not command:
            return "Error: no command provided"
        # Sandbox check: block dangerous patterns
        blocked = _check_command_sandbox(command)
        if blocked:
            return blocked
        try:
            result = subprocess.run(
                command, shell=True, cwd=project_root,
                capture_output=True, text=True, timeout=60,
            )
            output = ""
            if result.stdout:
                output += result.stdout[:10000]
            if result.stderr:
                output += f"\nSTDERR:\n{result.stderr[:5000]}"
            output += f"\n(exit code: {result.returncode})"
            return output or "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: command timed out (60s limit)"
        except Exception as e:
            return f"Error running command: {e}"

    elif tool_name == "glob_files":
        pattern = args.get("pattern", "")
        import glob as globmod
        try:
            skip = {".git", "node_modules", "__pycache__", "venv", "dist", "build", ".next"}
            matches = []
            for f in sorted(globmod.glob(str(Path(project_root) / pattern), recursive=True)):
                rel = os.path.relpath(f, project_root).replace("\\", "/")
                if any(s in rel.split("/") for s in skip):
                    continue
                if os.path.isfile(f):
                    matches.append(rel)
                if len(matches) >= 50:
                    break
            return "\n".join(matches) if matches else "No files matched"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "grep_search":
        pattern = args.get("pattern", "")
        search_path = args.get("path", ".")
        try:
            # Try ripgrep first, then grep
            for cmd in [
                ["rg", "-n", "--max-count=30", "-g", "!.git", "-g", "!node_modules", pattern, search_path],
                ["grep", "-rn", "--exclude-dir=.git", "--exclude-dir=node_modules", pattern, search_path],
            ]:
                try:
                    result = subprocess.run(
                        cmd, cwd=project_root, capture_output=True, text=True, timeout=10,
                    )
                    return result.stdout[:8000] if result.stdout else "No matches found"
                except FileNotFoundError:
                    continue
            return "Error: neither rg (ripgrep) nor grep found"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "web_search":
        query = args.get("query", "")
        if not query:
            return "Error: no search query provided"
        return _web_search(query)

    elif tool_name == "web_fetch":
        url = args.get("url", "")
        if not url:
            return "Error: no URL provided"
        try:
            # Try backend first, fall back to direct fetch
            from .config import get_settings, get_token
            import httpx as _httpx
            settings = get_settings()
            api_url = settings.api_url.rstrip("/")
            token = get_token()
            cookies = {"msaplingauth": token} if token else {}
            try:
                resp = _httpx.post(
                    f"{api_url}/api/tools/web-research",
                    json={"url": url}, cookies=cookies, timeout=15.0,
                )
                if resp.status_code == 200:
                    content = resp.json().get("content", resp.json().get("text", ""))
                    if content and len(content) > 20:
                        return content[:8000]
            except Exception:
                pass
            # Direct fetch fallback
            resp = _httpx.get(url, timeout=15.0, follow_redirects=True,
                              headers={"User-Agent": "MSapling-CLI/0.2"})
            text = resp.text
            # Strip HTML tags for readability
            text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL)
            text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            return text[:8000] if text else "No content found"
        except Exception as e:
            return f"Error fetching URL: {e}"

    elif tool_name == "list_directory":
        dir_path = args.get("path", ".")
        fpath = _safe_path(project_root, dir_path)
        if not fpath:
            return f"Error: path '{dir_path}' is outside project root"
        if not fpath.is_dir():
            return f"Error: not a directory: {dir_path}"
        try:
            skip = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build"}
            entries = []
            for item in sorted(fpath.iterdir()):
                name = item.name
                if name in skip:
                    continue
                if item.is_dir():
                    entries.append(f"  {name}/")
                else:
                    size = item.stat().st_size
                    size_str = f"{size / 1024:.1f}KB" if size > 1024 else f"{size}B"
                    entries.append(f"  {name}  ({size_str})")
                if len(entries) >= 80:
                    entries.append(f"  ... (truncated)")
                    break
            return "\n".join(entries) if entries else "(empty directory)"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "ask_user":
        question = args.get("question", "")
        if not question:
            return "Error: no question provided"
        try:
            console.print(f"\n[bold yellow]Agent asks:[/bold yellow] {question}")
            answer = console.input("[bold green]Your answer:[/bold green] ")
            return answer.strip() or "(no answer)"
        except (KeyboardInterrupt, EOFError):
            return "(user declined to answer)"

    elif tool_name == "todo_list":
        action = args.get("action", "list").lower()
        item = args.get("item", "")
        # Module-level todo storage
        global _agent_todos
        if action == "add" and item:
            _agent_todos.append({"text": item, "done": False})
            return f"Added: {item} ({len(_agent_todos)} total)"
        elif action == "done" and item:
            for t in _agent_todos:
                if item.lower() in t["text"].lower() and not t["done"]:
                    t["done"] = True
                    return f"Completed: {t['text']}"
            return f"Not found: {item}"
        elif action == "clear":
            _agent_todos.clear()
            return "Todo list cleared"
        else:
            if not _agent_todos:
                return "Todo list is empty"
            lines = []
            for i, t in enumerate(_agent_todos, 1):
                mark = "x" if t["done"] else " "
                lines.append(f"  [{mark}] {i}. {t['text']}")
            return "\n".join(lines)

    elif tool_name == "search_replace_all":
        path = args.get("path", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
            count = content.count(old_string)
            if count == 0:
                return f"Error: string not found in {path}"
            try:
                from .storage import backup_file
                import hashlib
                session_key = hashlib.md5(project_root.encode()).hexdigest()[:12]
                backup_file(path, content, session_key)
            except Exception:
                pass
            new_content = content.replace(old_string, new_string)
            fpath.write_text(new_content, encoding="utf-8")
            _mdrive_auto_push(project_root, path, new_content, project_name)
            return f"Replaced {count} occurrence(s) in {path}"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "cost_check":
        try:
            from .api import MSaplingClient
            import concurrent.futures

            async def _check():
                client = MSaplingClient()
                try:
                    user = await client.me()
                    fuel = user.get("fuel_credits", 0)
                    tier = user.get("tier", "free")
                    return (
                        f"Tier: {tier}\n"
                        f"Fuel credits remaining: ${fuel:.4f}\n"
                        f"Pro: {user.get('is_pro', False)}"
                    )
                finally:
                    await client.close()

            # _execute_tool is sync but called from within a running event loop.
            # Use a thread to avoid "event loop already running" RuntimeError.
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                result = pool.submit(asyncio.run, _check()).result(timeout=10)
            return result
        except Exception as e:
            return f"Cost check error: {e}"

    elif tool_name == "model_switch":
        new_model = args.get("model", "")
        if not new_model:
            return "Error: provide a model ID (e.g. 'google/gemini-2.0-flash-001')"
        # Store in a module-level var that the shell can read
        global _switched_model
        _switched_model = new_model
        return f"Model switched to: {new_model} (takes effect on next LLM call)"

    return f"Unknown tool: {tool_name}"

# Module-level var for model_switch tool — shell reads this after agent loop
_switched_model: Optional[str] = None

def get_and_clear_switched_model() -> Optional[str]:
    """Return the model set by model_switch tool and clear it."""
    global _switched_model
    m = _switched_model
    _switched_model = None
    return m


async def run_agent_loop(
    client,
    prompt: str,
    model: str,
    project_root: str,
    messages: List[Dict[str, str]],
    on_text: Any = None,
    on_usage: Any = None,
    hooks_mgr: Any = None,
    project_name: str = "",
    chat_id: str = "",
) -> str:
    """Run the agentic tool-use loop.

    The LLM receives the user's message plus tool definitions.
    If it responds with tool calls, we execute them and feed results back.
    Loop continues until the LLM responds with just text.

    Args:
        client: MSaplingClient instance
        prompt: User's message
        model: Model ID
        project_root: Path to project root
        messages: Conversation history (mutated in place)
        on_text: Optional callback(text) for streaming display
        on_usage: Optional callback(tokens, cost) for usage accounting
        hooks_mgr: Optional HooksManager for lifecycle hooks

    Returns:
        Final assistant response text
    """
    original_prompt = prompt

    # Inject agent system prompt if not already present
    has_agent_prompt = any(
        m.get("role") == "system" and "tool" in m.get("content", "").lower()
        for m in messages
    )
    if not has_agent_prompt:
        messages.insert(0, {"role": "system", "content": AGENT_SYSTEM_PROMPT})

    messages.append({"role": "user", "content": prompt})

    for step in range(MAX_AGENT_STEPS):
        # Get LLM response
        parts = []
        async for chunk in client.stream_chat(
            chat_id=chat_id or str(uuid.uuid4())[:12],
            prompt=prompt if step == 0 else "",
            model=model,
            project_name=project_name,
            history=messages[-30:],  # Keep recent context
        ):
            content = chunk.get("content", "")
            if content:
                parts.append(content)
                if on_text:
                    on_text("".join(parts))
            if chunk.get("type") == "usage" and on_usage:
                usage = chunk.get("usage", {})
                on_usage(usage.get("total_tokens", 0), float(chunk.get("cost", 0)))

        response_text = "".join(parts)
        if not response_text:
            break

        # Extract tool calls
        clean_text, tool_calls = _extract_tool_calls(response_text)

        if not tool_calls:
            if (
                step == 0
                and _looks_like_local_filesystem_request(original_prompt)
                and _looks_like_local_access_refusal(response_text)
            ):
                messages.append({"role": "assistant", "content": response_text})
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "You do have access to local files and directories through CLI tools in this "
                            "session. Do not claim you cannot access them. Use list_directory, read_file, "
                            "glob_files, or grep_search against the user's requested path and continue."
                        ),
                    }
                )
                prompt = ""
                continue

            # No tools ? final response
            messages.append({"role": "assistant", "content": response_text})
            return clean_text or response_text

        # Execute tools
        messages.append({"role": "assistant", "content": response_text})
        tool_results = []

        for tc in tool_calls:
            tool_name = tc.get("tool", "")
            tool_args = tc.get("args", {})

            # Show tool execution header (styled)
            console.print(tool_header(tool_name, tool_args))

            # on_before_tool hook
            if hooks_mgr is not None:
                hooks_mgr.run(
                    "on_before_tool", project_root,
                    project=project_root, model=model,
                    tool=tool_name,
                )

            result = _execute_tool(
                tool_name, tool_args, project_root,
                hooks_mgr=hooks_mgr, model=model,
                project_name=project_name,
            )

            # on_after_tool hook
            if hooks_mgr is not None:
                hooks_mgr.run(
                    "on_after_tool", project_root,
                    project=project_root, model=model,
                    tool=tool_name,
                )

            # Show styled result
            console.print(tool_result_display(tool_name, result, tool_args))

            tool_results.append(f"[Tool: {tool_name}]\n{result}")

        # Feed results back to LLM
        tool_feedback = "\n\n".join(tool_results)
        messages.append({"role": "user", "content": f"[Tool results]\n{tool_feedback}"})
        prompt = ""  # Empty prompt for continuation

    return "(Agent reached maximum steps)"
