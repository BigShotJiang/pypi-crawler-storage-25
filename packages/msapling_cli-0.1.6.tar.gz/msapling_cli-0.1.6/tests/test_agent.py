"""Tests for the agentic tool-use engine."""

import pytest
from unittest.mock import patch

from msapling_cli.agent import (
    AGENT_TOOLS_SCHEMA,
    MAX_AGENT_STEPS,
    _execute_tool,
    _extract_tool_calls,
    _looks_like_local_access_refusal,
    _looks_like_local_filesystem_request,
    _permissions,
    _safe_path,
    run_agent_loop,
)

# Auto-allow all tools in tests (skip approval prompts)
_permissions["write_file"] = True
_permissions["edit_file"] = True
_permissions["run_command"] = True


def test_extract_single_tool_call():
    text = """Let me read that.
```tool
{"tool": "read_file", "args": {"path": "main.py"}}
```
"""
    clean, calls = _extract_tool_calls(text)
    assert len(calls) == 1
    assert calls[0]["tool"] == "read_file"
    assert "main.py" in str(calls[0]["args"])
    assert "```tool" not in clean


def test_extract_multiple_tool_calls():
    text = """```tool
{"tool": "read_file", "args": {"path": "a.py"}}
```
Then:
```tool
{"tool": "grep_search", "args": {"pattern": "TODO"}}
```
"""
    clean, calls = _extract_tool_calls(text)
    assert len(calls) == 2
    assert calls[0]["tool"] == "read_file"
    assert calls[1]["tool"] == "grep_search"


def test_extract_no_tool_calls():
    text = "Just a regular response with no tools."
    clean, calls = _extract_tool_calls(text)
    assert len(calls) == 0
    assert clean == text


def test_extract_invalid_json():
    text = """```tool
{not valid json}
```
"""
    clean, calls = _extract_tool_calls(text)
    assert len(calls) == 0


def test_execute_read_file(tmp_path):
    (tmp_path / "test.py").write_text("print('hello')\n")
    result = _execute_tool("read_file", {"path": "test.py"}, str(tmp_path))
    assert "print('hello')" in result


def test_execute_read_file_not_found(tmp_path):
    result = _execute_tool("read_file", {"path": "nope.py"}, str(tmp_path))
    assert "not found" in result.lower() or "Error" in result


def test_execute_write_file(tmp_path):
    result = _execute_tool("write_file", {"path": "new.py", "content": "x = 1\n"}, str(tmp_path))
    assert "Wrote" in result
    assert (tmp_path / "new.py").read_text() == "x = 1\n"


def test_execute_write_file_creates_dirs(tmp_path):
    result = _execute_tool("write_file", {"path": "src/deep/file.py", "content": "pass"}, str(tmp_path))
    assert "Wrote" in result
    assert (tmp_path / "src" / "deep" / "file.py").exists()


def test_execute_edit_file(tmp_path):
    (tmp_path / "app.py").write_text("x = 1\ny = 2\n")
    result = _execute_tool("edit_file", {
        "path": "app.py",
        "old_string": "x = 1",
        "new_string": "x = 42",
    }, str(tmp_path))
    assert "Edited" in result
    assert "x = 42" in (tmp_path / "app.py").read_text()


def test_execute_edit_file_not_found(tmp_path):
    result = _execute_tool("edit_file", {
        "path": "nope.py", "old_string": "x", "new_string": "y",
    }, str(tmp_path))
    assert "not found" in result.lower()


def test_execute_edit_file_string_not_found(tmp_path):
    (tmp_path / "app.py").write_text("x = 1\n")
    result = _execute_tool("edit_file", {
        "path": "app.py", "old_string": "NONEXISTENT", "new_string": "y",
    }, str(tmp_path))
    assert "not found" in result.lower()


def test_execute_glob(tmp_path):
    (tmp_path / "a.py").write_text("")
    (tmp_path / "b.py").write_text("")
    (tmp_path / "c.txt").write_text("")
    result = _execute_tool("glob_files", {"pattern": "*.py"}, str(tmp_path))
    assert "a.py" in result
    assert "b.py" in result
    assert "c.txt" not in result


def test_execute_run_command(tmp_path):
    result = _execute_tool("run_command", {"command": "echo hello"}, str(tmp_path))
    assert "hello" in result


def test_execute_run_command_timeout(tmp_path):
    result = _execute_tool("run_command", {"command": "echo fast"}, str(tmp_path))
    assert "fast" in result or "exit code" in result


def test_execute_unknown_tool(tmp_path):
    _permissions["nonexistent_tool"] = True
    result = _execute_tool("nonexistent_tool", {}, str(tmp_path))
    assert "Unknown" in result


def test_safe_path_traversal(tmp_path):
    assert _safe_path(str(tmp_path), "../../etc/passwd") is None


def test_safe_path_valid(tmp_path):
    (tmp_path / "ok.py").write_text("")
    assert _safe_path(str(tmp_path), "ok.py") is not None


def test_safe_path_blocks_prefixed_sibling(tmp_path):
    sibling = tmp_path.parent / f"{tmp_path.name}-evil"
    sibling.mkdir()
    target = sibling / "steal.py"
    target.write_text("x = 1\n")
    assert _safe_path(str(tmp_path), str(target)) is None


def test_tools_schema_complete():
    assert len(AGENT_TOOLS_SCHEMA) == 14
    names = {tool["name"] for tool in AGENT_TOOLS_SCHEMA}
    assert "read_file" in names
    assert "write_file" in names
    assert "edit_file" in names
    assert "run_command" in names
    assert "glob_files" in names
    assert "grep_search" in names
    assert "cost_check" in names
    assert "model_switch" in names
    assert "search_replace_all" in names
    assert "todo_list" in names
    assert "ask_user" in names
    assert "list_directory" in names
    assert "web_fetch" in names


def test_max_steps_bounded():
    assert MAX_AGENT_STEPS == 15


def test_detect_local_filesystem_request():
    assert _looks_like_local_filesystem_request(r"Check D:\Projects\MSapling_LAB and generate a file directory") is True
    assert _looks_like_local_filesystem_request("List files in this folder") is True
    assert _looks_like_local_filesystem_request("Explain Python decorators") is False


def test_detect_local_access_refusal():
    assert _looks_like_local_access_refusal("I am unable to directly access local files on your computer.") is True
    assert _looks_like_local_access_refusal("I can list the directory for you.") is False


@pytest.mark.asyncio
async def test_run_agent_loop_retries_after_local_access_refusal():
    class FakeClient:
        def __init__(self):
            self.calls = 0
            self.responses = [
                [{"content": "I am unable to directly access local files on your computer."}],
                [{"content": "```tool\n{\"tool\": \"list_directory\", \"args\": {\"path\": \"D:\\\\Projects\\\\MSapling_LAB\"}}\n```"}],
                [{"content": "Here is the directory listing."}],
            ]

        async def stream_chat(self, **kwargs):
            current = self.responses[self.calls]
            self.calls += 1
            for chunk in current:
                yield chunk

    client = FakeClient()
    messages = []

    with patch("msapling_cli.agent._execute_tool", return_value="  cli/\n  backend/") as mock_tool, patch("msapling_cli.agent.console.print"):
        result = await run_agent_loop(
            client=client,
            prompt=r"Check D:\Projects\MSapling_LAB and generate a file directory",
            model="google/gemini-2.0-flash-001",
            project_root=r"D:\Projects\MSapling_LAB",
            messages=messages,
            on_text=None,
            on_usage=None,
        )

    assert result == "Here is the directory listing."
    assert client.calls == 3
    mock_tool.assert_called_once()
