"""LLM adapters package."""
