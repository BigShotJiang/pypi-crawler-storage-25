"""
System renderer.

Presentation logic for system-level telemetry:
- CLI rendering (Rich)
- Dashboard payload (dict)
- Summary logging (optional)

All metric computation is delegated to SystemMetricsComputer.
"""

import shutil
from typing import Any, Dict

from rich.panel import Panel
from rich.table import Table

from traceml.aggregator.display_drivers.layout import SYSTEM_LAYOUT
from traceml.loggers.error_log import get_error_logger
from traceml.renderers.base_renderer import BaseRenderer
from traceml.utils.formatting import fmt_mem_new, fmt_mem_ratio, fmt_percent

from .computer import SystemMetricsComputer


class SystemRenderer(BaseRenderer):
    """
    Renderer for system-level telemetry.

    Driver expectations:
    - CLI driver calls get_panel_renderable()
    - Dashboard driver calls get_dashboard_renderable()
    """

    NAME = "System"

    def __init__(self, db_path) -> None:
        super().__init__(name=self.NAME, layout_section_name=SYSTEM_LAYOUT)
        self.db_path = db_path
        self._logger = get_error_logger(self.NAME + "Renderer")
        self._computer = SystemMetricsComputer(db_path=self.db_path)

    def _compute_cli(self) -> Dict[str, Any]:
        return self._computer.compute_cli()

    def _compute_dashboard(self, window_n: int = 100) -> Dict[str, Any]:
        return self._computer.compute_dashboard(window_n=window_n)

    def get_panel_renderable(self) -> Panel:
        """Return a Rich Panel for CLI display (latest sample)."""
        data = self._compute_cli()

        grid = Table.grid(padding=(0, 1))
        grid.add_column(justify="left", style="bright_white", no_wrap=True)
        grid.add_column(justify="left", style="bright_white", no_wrap=True)

        # CPU + RAM row
        ram_pct_str = ""
        if data["ram_total"]:
            ram_pct = data["ram_used"] * 100.0 / data["ram_total"]
            ram_pct_str = f" ({ram_pct:.1f}%)"

        grid.add_row(
            f"[bold green]CPU[/bold green] {fmt_percent(data['cpu'])}",
            f"[bold green]RAM[/bold green] "
            f"{fmt_mem_ratio(data['ram_used'], data['ram_total'])}{ram_pct_str}",
        )

        # GPU rows
        if not data["gpu_available"]:
            grid.add_row(
                "[bold green]GPU[/bold green]", "[red]Not available[/red]"
            )
        else:
            util_total = data.get("gpu_util_total")
            avg = (
                util_total / max(data["gpu_count"], 1)
                if util_total is not None
                else None
            )
            util_str = fmt_percent(avg) if avg is not None else "N/A"

            skew = data.get("gpu_util_skew")
            if skew is not None:
                util_str = f"{util_str} (Δ {skew:.1f}%)"

            grid.add_row(
                f"[bold green]GPU UTIL[/bold green] {util_str}",
                f"[bold green]GPU MEM[/bold green] "
                f"{fmt_mem_ratio(data['gpu_mem_used'], data['gpu_mem_total'])}",
            )

            temp = data.get("gpu_temp_max")
            temp_str = (
                f"[bold green]GPU TMP[/bold green] {temp:.1f}°C"
                if temp is not None
                else "[bold green]GPU TMP[/bold green] N/A"
            )

            headroom = data.get("gpu_mem_headroom_min")
            headroom_idx = data.get("gpu_mem_headroom_min_idx")
            headroom_str = (
                f"[bold green]GPU HDRM[/bold green] "
                f"gpu{headroom_idx}: {fmt_mem_new(headroom)}"
                if headroom is not None and headroom_idx is not None
                else "[bold green]GPU HDRM[/bold green] N/A"
            )
            grid.add_row(temp_str, headroom_str)

        cols, _ = shutil.get_terminal_size()
        panel_width = min(max(100, int(cols * 0.75)), 100)

        return Panel(
            grid,
            title="[bold cyan]System Metrics[/bold cyan]",
            title_align="center",
            border_style="cyan",
            width=panel_width,
        )

    def get_dashboard_renderable(self) -> Dict[str, Any]:
        """
        Return a compact dashboard payload.

        This matches the semantics of your existing system dashboard card, but
        avoids shipping the raw system table to the UI.
        """
        return self._compute_dashboard(window_n=100)
