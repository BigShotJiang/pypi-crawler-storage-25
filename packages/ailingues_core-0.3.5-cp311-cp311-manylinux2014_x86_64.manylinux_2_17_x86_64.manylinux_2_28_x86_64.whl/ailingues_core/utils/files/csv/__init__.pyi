from .split import split_by_columns as split_by_columns, split_by_rows as split_by_rows, split_by_size as split_by_size

__all__ = ['split_by_columns', 'split_by_rows', 'split_by_size']
