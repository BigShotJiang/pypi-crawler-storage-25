"""pandas DataFrame 変換ヘルパ (optional: ``pip install core-master-sdk-python[pandas]``).

各リスト系メソッドの結果を DataFrame に載せ替える純粋関数群。
pandas を import せずに使う場合はこのモジュールを import しない。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Mapping

from core_master_sdk.types.lookup import LookupHit
from core_master_sdk.types.malls import (
    CoreMall,
    CoreMallCodeDefinition,
    CoreMallIdentifier,
)
from core_master_sdk.types.product_costs import CoreProductCost
from core_master_sdk.types.products import CoreProduct, CoreProductGroup

if TYPE_CHECKING:
    import pandas as pd


def _require_pandas() -> "type[pd.DataFrame]":
    try:
        import pandas as pd
    except ImportError as e:  # pragma: no cover - exercised via runtime test
        raise RuntimeError(
            "pandas is required. Install with: "
            "pip install originaiagent-core-master-sdk-python[pandas]"
        ) from e
    return pd.DataFrame


def products_to_df(rows: list[CoreProduct]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def product_groups_to_df(rows: list[CoreProductGroup]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def product_costs_to_df(rows: list[CoreProductCost]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def mall_identifiers_to_df(rows: list[CoreMallIdentifier]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def mall_code_definitions_to_df(rows: list[CoreMallCodeDefinition]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def malls_to_df(rows: list[CoreMall]) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    return DataFrame([r.model_dump() for r in rows])


def lookup_bulk_to_df(
    result: Mapping[str, LookupHit | None],
) -> "pd.DataFrame":
    DataFrame = _require_pandas()
    records = []
    for key, hit in result.items():
        if hit is None:
            records.append(
                {"value": key, "core_product_id": None, "mall_identifier_id": None}
            )
        else:
            records.append(
                {
                    "value": key,
                    "core_product_id": hit.core_product_id,
                    "mall_identifier_id": hit.mall_identifier_id,
                }
            )
    return DataFrame(records)
