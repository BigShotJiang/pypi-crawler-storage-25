"""malls resource (read-only, v0.1)。TS 版 resources/malls.ts に対応。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterNotFound, CoreMasterValidationError
from core_master_sdk.resources._common import (
    fields_to_query,
    validate_positive_int,
)
from core_master_sdk.types.malls import CoreMall


def _list_query(fields: Sequence[str] | None) -> dict[str, Any]:
    query: dict[str, Any] = {}
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    return query


class MallsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list(self, *, fields: Sequence[str] | None = None) -> list[CoreMall]:
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/malls",
                query=_list_query(fields),
                resource="malls.list",
            )
        )
        return [CoreMall.model_validate(item) for item in (data or [])]

    def get_by_id(
        self,
        id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreMall:
        """TS 版と同じく /malls を取得 → Python 側 filter。"""
        validate_positive_int("malls.get_by_id: id", id)
        all_malls = self.list(fields=fields)
        for mall in all_malls:
            if mall.id == id:
                return mall
        raise CoreMasterNotFound(f"Mall {id} not found")

    def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreMall:
        validate_positive_int("malls.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "malls.patch: body must be non-empty mapping"
            )

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/malls/{id}",
                method="PATCH",
                body=dict(body),
                resource="malls.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreMall.model_validate(data)


class AsyncMallsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list(
        self, *, fields: Sequence[str] | None = None
    ) -> list[CoreMall]:
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/malls",
                query=_list_query(fields),
                resource="malls.list",
            )
        )
        return [CoreMall.model_validate(item) for item in (data or [])]

    async def get_by_id(
        self,
        id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreMall:
        validate_positive_int("malls.get_by_id: id", id)
        all_malls = await self.list(fields=fields)
        for mall in all_malls:
            if mall.id == id:
                return mall
        raise CoreMasterNotFound(f"Mall {id} not found")

    async def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreMall:
        validate_positive_int("malls.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "malls.patch: body must be non-empty mapping"
            )

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/malls/{id}",
                method="PATCH",
                body=dict(body),
                resource="malls.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreMall.model_validate(data)
