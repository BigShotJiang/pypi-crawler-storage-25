"""product_mall_settings resource (v0.3, sync + async)。

TS 版 resources/productMallSettings.ts に対応。

5 メソッド:
  - list(...)            → GET  /api/v1/master/product-mall-settings
  - get_by_product(...)  → GET  /api/v1/master/product-mall-settings/by-product/:productId
  - create(...)          → POST /api/v1/master/product-mall-settings
  - patch(id, body, ...) → PATCH /api/v1/master/product-mall-settings/:id
  - soft_delete(id, ...) = patch({"deleted_at": now ISO}) を呼ぶ
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import (
    fields_to_query,
    validate_non_empty_string,
    validate_positive_int,
)
from core_master_sdk.types.product_mall_settings import CoreProductMallSetting

LIST_PATH = "/api/v1/master/product-mall-settings"


def _list_query(
    filter_: Mapping[str, Any] | None,
    fields: Sequence[str] | None,
    limit: int | None,
    offset: int | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    if filter_:
        product_id = filter_.get("product_id")
        if product_id is not None:
            validate_positive_int(
                "product_mall_settings.list: filter.product_id", product_id
            )
            # TS 版と一致: filter[product_id]=... 形式
            query["filter[product_id]"] = product_id
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    if limit is not None:
        query["limit"] = limit
    if offset is not None:
        query["offset"] = offset
    return query


def _validate_create_body(body: Mapping[str, Any]) -> None:
    if not isinstance(body, Mapping) or not body:
        raise CoreMasterValidationError(
            "product_mall_settings.create: body must be non-empty mapping"
        )
    pid = body.get("product_id")
    validate_positive_int("product_mall_settings.create: product_id", pid)
    mt = body.get("mall_type")
    validate_non_empty_string("product_mall_settings.create: mall_type", mt)


def _now_iso_utc() -> str:
    """soft_delete のタイムスタンプ用。Z suffix の ISO 8601 (TS new Date().toISOString() と一致)。"""
    return (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.")
        + f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"
    )


class ProductMallSettingsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list(
        self,
        *,
        filter: Mapping[str, Any] | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[CoreProductMallSetting]:
        query = _list_query(filter, fields, limit, offset)
        data = self._fetcher.fetch(
            FetchInput(path=LIST_PATH, query=query, resource="product_mall_settings.list")
        )
        return [CoreProductMallSetting.model_validate(item) for item in (data or [])]

    def get_by_product(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProductMallSetting]:
        validate_positive_int("product_mall_settings.get_by_product: product_id", product_id)
        query: dict[str, Any] = {}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = self._fetcher.fetch(
            FetchInput(
                path=f"{LIST_PATH}/by-product/{product_id}",
                query=query,
                resource="product_mall_settings.get_by_product",
            )
        )
        return [CoreProductMallSetting.model_validate(item) for item in (data or [])]

    def create(
        self,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        _validate_create_body(body)
        data = self._fetcher.fetch(
            FetchInput(
                path=LIST_PATH,
                method="POST",
                body=dict(body),
                resource="product_mall_settings.create",
                tool_name=tool_name,
                user_email=user_email,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductMallSetting.model_validate(data)

    def patch(
        self,
        id: str,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        validate_non_empty_string("product_mall_settings.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_mall_settings.patch: body must be non-empty mapping"
            )
        data = self._fetcher.fetch(
            FetchInput(
                path=f"{LIST_PATH}/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_mall_settings.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductMallSetting.model_validate(data)

    def soft_delete(
        self,
        id: str,
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        validate_non_empty_string("product_mall_settings.soft_delete: id", id)
        return self.patch(
            id,
            {"deleted_at": _now_iso_utc()},
            tool_name=tool_name,
            user_email=user_email,
            idempotency_key=idempotency_key,
        )


class AsyncProductMallSettingsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list(
        self,
        *,
        filter: Mapping[str, Any] | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[CoreProductMallSetting]:
        query = _list_query(filter, fields, limit, offset)
        data = await self._fetcher.fetch(
            FetchInput(path=LIST_PATH, query=query, resource="product_mall_settings.list")
        )
        return [CoreProductMallSetting.model_validate(item) for item in (data or [])]

    async def get_by_product(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProductMallSetting]:
        validate_positive_int("product_mall_settings.get_by_product: product_id", product_id)
        query: dict[str, Any] = {}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = await self._fetcher.fetch(
            FetchInput(
                path=f"{LIST_PATH}/by-product/{product_id}",
                query=query,
                resource="product_mall_settings.get_by_product",
            )
        )
        return [CoreProductMallSetting.model_validate(item) for item in (data or [])]

    async def create(
        self,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        _validate_create_body(body)
        data = await self._fetcher.fetch(
            FetchInput(
                path=LIST_PATH,
                method="POST",
                body=dict(body),
                resource="product_mall_settings.create",
                tool_name=tool_name,
                user_email=user_email,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductMallSetting.model_validate(data)

    async def patch(
        self,
        id: str,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        validate_non_empty_string("product_mall_settings.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_mall_settings.patch: body must be non-empty mapping"
            )
        data = await self._fetcher.fetch(
            FetchInput(
                path=f"{LIST_PATH}/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_mall_settings.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductMallSetting.model_validate(data)

    async def soft_delete(
        self,
        id: str,
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductMallSetting:
        validate_non_empty_string("product_mall_settings.soft_delete: id", id)
        return await self.patch(
            id,
            {"deleted_at": _now_iso_utc()},
            tool_name=tool_name,
            user_email=user_email,
            idempotency_key=idempotency_key,
        )
