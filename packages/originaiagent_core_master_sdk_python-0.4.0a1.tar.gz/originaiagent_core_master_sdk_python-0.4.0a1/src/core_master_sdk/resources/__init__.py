"""リソース名前空間 (sync / async 両方)。"""

from core_master_sdk.resources.mall_code_definitions import (
    AsyncMallCodeDefinitionsResource,
    MallCodeDefinitionsResource,
)
from core_master_sdk.resources.mall_identifiers import (
    AsyncMallIdentifiersResource,
    MallIdentifiersResource,
)
from core_master_sdk.resources.malls import AsyncMallsResource, MallsResource
from core_master_sdk.resources.product_costs import (
    AsyncProductCostsResource,
    ProductCostsResource,
)
from core_master_sdk.resources.product_groups import (
    AsyncProductGroupsResource,
    ProductGroupsResource,
)
from core_master_sdk.resources.product_skus import (
    AsyncProductSkusResource,
    ProductSkusResource,
)
from core_master_sdk.resources.product_specs import (
    AsyncProductSpecsResource,
    ProductSpecsResource,
)
from core_master_sdk.resources.products import (
    AsyncProductsResource,
    ProductsResource,
)

__all__ = [
    "AsyncMallCodeDefinitionsResource",
    "AsyncMallIdentifiersResource",
    "AsyncMallsResource",
    "AsyncProductCostsResource",
    "AsyncProductGroupsResource",
    "AsyncProductSkusResource",
    "AsyncProductSpecsResource",
    "AsyncProductsResource",
    "MallCodeDefinitionsResource",
    "MallIdentifiersResource",
    "MallsResource",
    "ProductCostsResource",
    "ProductGroupsResource",
    "ProductSkusResource",
    "ProductSpecsResource",
    "ProductsResource",
]
