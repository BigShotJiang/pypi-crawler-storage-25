"""リソース共通の引数バリデーション・クエリ組立ヘルパ。

TS 各 resources/*.ts の冒頭バリデーションと同じ条件で CoreMasterValidationError を raise する。
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from typing import Any, Iterable, Mapping

from core_master_sdk.errors import CoreMasterValidationError

_ASIN_RE = re.compile(r"^B0[A-Z0-9]{8}$")

LOOKUP_BULK_MAX = 500


def validate_positive_int(name: str, value: Any) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise CoreMasterValidationError(f"{name}: must be positive integer")
    return value


def validate_non_empty_string(name: str, value: Any) -> str:
    if not isinstance(value, str) or value.strip() == "":
        raise CoreMasterValidationError(f"{name}: must be non-empty string")
    return value


def validate_ids(name: str, ids: Any) -> list[int]:
    if not isinstance(ids, Sequence) or isinstance(ids, (str, bytes)):
        raise CoreMasterValidationError(f"{name}: ids must be a sequence")
    ids_list = list(ids)
    if len(ids_list) == 0:
        raise CoreMasterValidationError(f"{name}: ids must be non-empty")
    if len(ids_list) > LOOKUP_BULK_MAX:
        raise CoreMasterValidationError(
            f"{name}: max {LOOKUP_BULK_MAX} ids per call"
        )
    for i, v in enumerate(ids_list):
        if not isinstance(v, int) or isinstance(v, bool) or v <= 0:
            raise CoreMasterValidationError(
                f"{name}: ids[{i}] must be positive integer"
            )
    return ids_list


def is_amazon_asin(value: str) -> bool:
    return bool(_ASIN_RE.fullmatch(value))


def fields_to_query(fields: Sequence[str] | None) -> list[str] | None:
    """fields をクエリ用のリストに変換 (空ならスキップ)。"""
    if fields is None:
        return None
    items = list(fields)
    if not items:
        return None
    return items


def dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for v in values:
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def chunk_list(items: Sequence[str], size: int) -> list[list[str]]:
    return [list(items[i : i + size]) for i in range(0, len(items), size)]


def merge_filter_query(
    filter_dict: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """filter={"product_group_id": 12} → {"filter[product_group_id]": 12}."""
    if not filter_dict:
        return {}
    out: dict[str, Any] = {}
    for key, value in filter_dict.items():
        if value is None:
            continue
        out[f"filter[{key}]"] = value
    return out
