"""product_skus resource (Write support, v0.2).
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import validate_non_empty_string
from core_master_sdk.types.product_skus import CoreProductSku


class ProductSkusResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def patch(
        self,
        id: str,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductSku:
        validate_non_empty_string("product_skus.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_skus.patch: body must be non-empty mapping"
            )

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-skus/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_skus.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductSku.model_validate(data)


class AsyncProductSkusResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def patch(
        self,
        id: str,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductSku:
        validate_non_empty_string("product_skus.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_skus.patch: body must be non-empty mapping"
            )

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-skus/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_skus.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductSku.model_validate(data)
