"""product_groups resource (read-only, v0.1)。TS 版 resources/productGroups.ts に対応。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Literal

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import (
    fields_to_query,
    validate_positive_int,
)
from core_master_sdk.types.products import CoreProductGroup


def _list_query(
    q: str | None,
    fields: Sequence[str] | None,
    limit: int | None,
    offset: int | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    if q:
        query["q"] = q
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    if limit is not None:
        query["limit"] = limit
    if offset is not None:
        query["offset"] = offset
    return query


def _get_by_id_query(
    include: Sequence[Literal["products"]] | None,
    product_fields: Sequence[str] | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    if include:
        include_list = list(include)
        if include_list:
            query["include"] = include_list
    fields_list = fields_to_query(product_fields)
    if fields_list is not None:
        query["productFields"] = fields_list
    return query


class ProductGroupsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list(
        self,
        *,
        q: str | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[CoreProductGroup]:
        query = _list_query(q, fields, limit, offset)
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-groups",
                query=query,
                resource="product_groups.list",
            )
        )
        return [CoreProductGroup.model_validate(item) for item in (data or [])]

    def get_by_id(
        self,
        id: int,
        *,
        include: Sequence[Literal["products"]] | None = None,
        product_fields: Sequence[str] | None = None,
    ) -> CoreProductGroup:
        validate_positive_int("product_groups.get_by_id: id", id)
        query = _get_by_id_query(include, product_fields)
        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-groups/{id}",
                query=query,
                resource="product_groups.get_by_id",
            )
        )
        return CoreProductGroup.model_validate(data)

    def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductGroup:
        validate_positive_int("product_groups.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_groups.patch: body must be non-empty mapping"
            )

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-groups/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_groups.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductGroup.model_validate(data)


class AsyncProductGroupsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list(
        self,
        *,
        q: str | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[CoreProductGroup]:
        query = _list_query(q, fields, limit, offset)
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-groups",
                query=query,
                resource="product_groups.list",
            )
        )
        return [CoreProductGroup.model_validate(item) for item in (data or [])]

    async def get_by_id(
        self,
        id: int,
        *,
        include: Sequence[Literal["products"]] | None = None,
        product_fields: Sequence[str] | None = None,
    ) -> CoreProductGroup:
        validate_positive_int("product_groups.get_by_id: id", id)
        query = _get_by_id_query(include, product_fields)
        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-groups/{id}",
                query=query,
                resource="product_groups.get_by_id",
            )
        )
        return CoreProductGroup.model_validate(data)

    async def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductGroup:
        validate_positive_int("product_groups.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_groups.patch: body must be non-empty mapping"
            )

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-groups/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_groups.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductGroup.model_validate(data)
