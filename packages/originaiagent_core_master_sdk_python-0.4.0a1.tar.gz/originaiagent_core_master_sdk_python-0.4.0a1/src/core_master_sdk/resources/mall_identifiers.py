"""mall_identifiers resource (read-only, v0.1)。TS 版 resources/mallIdentifiers.ts に対応。"""

from __future__ import annotations

import asyncio
from collections.abc import Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import (
    LOOKUP_BULK_MAX,
    chunk_list,
    dedupe_preserve_order,
    fields_to_query,
    validate_non_empty_string,
    validate_positive_int,
)
from core_master_sdk.types.lookup import (
    IdentifierSlot,
    LookupHit,
    MallCode,
)
from core_master_sdk.types.malls import CoreMallIdentifier

_BULK_CONCURRENCY = 3


def _list_query(
    product_id: int,
    mall_code: MallCode | None,
    fields: Sequence[str] | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {"productId": product_id}
    if mall_code:
        query["mallCode"] = mall_code
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    return query


def _validate_lookup_args(mall_code: Any, slot: Any, value: Any = None) -> None:
    if not isinstance(mall_code, str) or not mall_code:
        raise CoreMasterValidationError(
            "mall_identifiers.lookup: mall_code is required (string)"
        )
    if not isinstance(slot, str) or not slot:
        raise CoreMasterValidationError(
            "mall_identifiers.lookup: slot is required (string)"
        )
    if value is not None:
        validate_non_empty_string("mall_identifiers.lookup: value", value)


def _validate_lookup_bulk_args(
    mall_code: Any, slot: Any, values: Any
) -> list[str]:
    _validate_lookup_args(mall_code, slot)
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise CoreMasterValidationError(
            "mall_identifiers.lookup_bulk: values must be a sequence"
        )
    values_list = list(values)
    if not values_list:
        raise CoreMasterValidationError(
            "mall_identifiers.lookup_bulk: values must be non-empty"
        )
    for i, v in enumerate(values_list):
        if not isinstance(v, str) or not v:
            raise CoreMasterValidationError(
                f"mall_identifiers.lookup_bulk: values[{i}] must be non-empty string"
            )
    return values_list


def _parse_lookup_hit(raw: Any) -> LookupHit | None:
    if raw is None:
        return None
    return LookupHit.model_validate(raw)


def _parse_bulk_response(raw: Any) -> dict[str, LookupHit | None]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, LookupHit | None] = {}
    for key, value in raw.items():
        out[key] = _parse_lookup_hit(value)
    return out


def _merge_bulk_results(
    original_values: Sequence[str],
    batches: list[dict[str, LookupHit | None]],
) -> dict[str, LookupHit | None]:
    merged: dict[str, LookupHit | None] = {}
    for batch in batches:
        merged.update(batch)
    for v in original_values:
        merged.setdefault(v, None)
    return merged


class MallIdentifiersResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list_by_product_id(
        self,
        product_id: int,
        *,
        mall_code: MallCode | None = None,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallIdentifier]:
        validate_positive_int(
            "mall_identifiers.list_by_product_id: product_id", product_id
        )
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-identifiers",
                query=_list_query(product_id, mall_code, fields),
                resource="mall_identifiers.list_by_product_id",
            )
        )
        return [CoreMallIdentifier.model_validate(item) for item in (data or [])]

    def lookup(
        self,
        *,
        mall_code: MallCode,
        slot: IdentifierSlot,
        value: str,
    ) -> LookupHit | None:
        _validate_lookup_args(mall_code, slot, value)
        raw = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-identifiers/lookup",
                query={"mallCode": mall_code, "slot": slot, "value": value},
                resource="mall_identifiers.lookup",
            )
        )
        return _parse_lookup_hit(raw)

    def lookup_bulk(
        self,
        *,
        mall_code: MallCode,
        slot: IdentifierSlot,
        values: Sequence[str],
    ) -> dict[str, LookupHit | None]:
        values_list = _validate_lookup_bulk_args(mall_code, slot, values)
        unique = dedupe_preserve_order(values_list)
        batches = chunk_list(unique, LOOKUP_BULK_MAX)

        def _fetch_one(batch: list[str]) -> dict[str, LookupHit | None]:
            raw = self._fetcher.fetch(
                FetchInput(
                    path="/api/v1/master/mall-identifiers/lookup-bulk",
                    query={"mallCode": mall_code, "slot": slot, "values": batch},
                    resource="mall_identifiers.lookup_bulk",
                )
            )
            return _parse_bulk_response(raw)

        if len(batches) <= 1:
            results = [_fetch_one(b) for b in batches]
        else:
            with ThreadPoolExecutor(max_workers=_BULK_CONCURRENCY) as pool:
                results = list(pool.map(_fetch_one, batches))
        return _merge_bulk_results(values_list, results)

    def amazon_asin_map(self, asins: Sequence[str]) -> dict[str, int | None]:
        bulk = self.lookup_bulk(
            mall_code="amazon", slot="identifier_2", values=asins
        )
        return {
            asin: (hit.core_product_id if hit else None) for asin, hit in bulk.items()
        }

    def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreMallIdentifier:
        validate_positive_int("mall_identifiers.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "mall_identifiers.patch: body must be non-empty mapping"
            )

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/mall-identifiers/{id}",
                method="PATCH",
                body=dict(body),
                resource="mall_identifiers.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreMallIdentifier.model_validate(data)


class AsyncMallIdentifiersResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list_by_product_id(
        self,
        product_id: int,
        *,
        mall_code: MallCode | None = None,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallIdentifier]:
        validate_positive_int(
            "mall_identifiers.list_by_product_id: product_id", product_id
        )
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-identifiers",
                query=_list_query(product_id, mall_code, fields),
                resource="mall_identifiers.list_by_product_id",
            )
        )
        return [CoreMallIdentifier.model_validate(item) for item in (data or [])]

    async def lookup(
        self,
        *,
        mall_code: MallCode,
        slot: IdentifierSlot,
        value: str,
    ) -> LookupHit | None:
        _validate_lookup_args(mall_code, slot, value)
        raw = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-identifiers/lookup",
                query={"mallCode": mall_code, "slot": slot, "value": value},
                resource="mall_identifiers.lookup",
            )
        )
        return _parse_lookup_hit(raw)

    async def lookup_bulk(
        self,
        *,
        mall_code: MallCode,
        slot: IdentifierSlot,
        values: Sequence[str],
    ) -> dict[str, LookupHit | None]:
        values_list = _validate_lookup_bulk_args(mall_code, slot, values)
        unique = dedupe_preserve_order(values_list)
        batches = chunk_list(unique, LOOKUP_BULK_MAX)

        semaphore = asyncio.Semaphore(_BULK_CONCURRENCY)

        async def _fetch_one(batch: list[str]) -> dict[str, LookupHit | None]:
            async with semaphore:
                raw = await self._fetcher.fetch(
                    FetchInput(
                        path="/api/v1/master/mall-identifiers/lookup-bulk",
                        query={"mallCode": mall_code, "slot": slot, "values": batch},
                        resource="mall_identifiers.lookup_bulk",
                    )
                )
            return _parse_bulk_response(raw)

        results = await asyncio.gather(*[_fetch_one(b) for b in batches])
        return _merge_bulk_results(values_list, results)

    async def amazon_asin_map(
        self, asins: Sequence[str]
    ) -> dict[str, int | None]:
        bulk = await self.lookup_bulk(
            mall_code="amazon", slot="identifier_2", values=asins
        )
        return {
            asin: (hit.core_product_id if hit else None) for asin, hit in bulk.items()
        }

    async def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreMallIdentifier:
        validate_positive_int("mall_identifiers.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "mall_identifiers.patch: body must be non-empty mapping"
            )

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/mall-identifiers/{id}",
                method="PATCH",
                body=dict(body),
                resource="mall_identifiers.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreMallIdentifier.model_validate(data)
