"""product_costs resource (read-only, v0.1)。TS 版 resources/productCosts.ts に対応。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import (
    fields_to_query,
    validate_positive_int,
)
from core_master_sdk.types.product_costs import CoreProductCost


def _build_query(
    product_id: int,
    fields: Sequence[str] | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {"productId": product_id}
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    return query


class ProductCostsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list_by_product_id(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProductCost]:
        validate_positive_int("product_costs.list_by_product_id: product_id", product_id)
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-costs",
                query=_build_query(product_id, fields),
                resource="product_costs.list_by_product_id",
            )
        )
        return [CoreProductCost.model_validate(item) for item in (data or [])]

    def get_latest_by_product_id(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProductCost | None:
        validate_positive_int(
            "product_costs.get_latest_by_product_id: product_id", product_id
        )
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-costs/latest",
                query=_build_query(product_id, fields),
                resource="product_costs.get_latest_by_product_id",
            )
        )
        if data is None:
            return None
        return CoreProductCost.model_validate(data)

    def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductCost:
        validate_positive_int("product_costs.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_costs.patch: body must be non-empty mapping"
            )
        if "change_reason" not in body:
            raise CoreMasterValidationError(
                "product_costs.patch: 'change_reason' is required in body"
            )

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-costs/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_costs.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductCost.model_validate(data)


class AsyncProductCostsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list_by_product_id(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProductCost]:
        validate_positive_int("product_costs.list_by_product_id: product_id", product_id)
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-costs",
                query=_build_query(product_id, fields),
                resource="product_costs.list_by_product_id",
            )
        )
        return [CoreProductCost.model_validate(item) for item in (data or [])]

    async def get_latest_by_product_id(
        self,
        product_id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProductCost | None:
        validate_positive_int(
            "product_costs.get_latest_by_product_id: product_id", product_id
        )
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/product-costs/latest",
                query=_build_query(product_id, fields),
                resource="product_costs.get_latest_by_product_id",
            )
        )
        if data is None:
            return None
        return CoreProductCost.model_validate(data)

    async def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProductCost:
        validate_positive_int("product_costs.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError(
                "product_costs.patch: body must be non-empty mapping"
            )
        if "change_reason" not in body:
            raise CoreMasterValidationError(
                "product_costs.patch: 'change_reason' is required in body"
            )

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/product-costs/{id}",
                method="PATCH",
                body=dict(body),
                resource="product_costs.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProductCost.model_validate(data)
