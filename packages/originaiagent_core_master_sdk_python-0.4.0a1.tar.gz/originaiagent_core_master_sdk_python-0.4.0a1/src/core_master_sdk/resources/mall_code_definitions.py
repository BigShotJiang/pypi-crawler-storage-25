"""mall_code_definitions resource (read-only, v0.1)。

TS 版 resources/mallCodeDefinitions.ts に対応。
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterValidationError
from core_master_sdk.resources._common import fields_to_query
from core_master_sdk.types.lookup import MallCode
from core_master_sdk.types.malls import CoreMallCodeDefinition


def _list_query(
    mall_code: MallCode | None,
    fields: Sequence[str] | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    if mall_code:
        query["mallCode"] = mall_code
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    return query


class MallCodeDefinitionsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list(
        self,
        *,
        mall_code: MallCode | None = None,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallCodeDefinition]:
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-code-definitions",
                query=_list_query(mall_code, fields),
                resource="mall_code_definitions.list",
            )
        )
        return [CoreMallCodeDefinition.model_validate(item) for item in (data or [])]

    def get_by_mall_id(
        self,
        mall_code: MallCode,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallCodeDefinition]:
        if not isinstance(mall_code, str) or not mall_code:
            raise CoreMasterValidationError(
                "mall_code_definitions.get_by_mall_id: mall_code is required (string)"
            )
        return self.list(mall_code=mall_code, fields=fields)


class AsyncMallCodeDefinitionsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list(
        self,
        *,
        mall_code: MallCode | None = None,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallCodeDefinition]:
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/mall-code-definitions",
                query=_list_query(mall_code, fields),
                resource="mall_code_definitions.list",
            )
        )
        return [CoreMallCodeDefinition.model_validate(item) for item in (data or [])]

    async def get_by_mall_id(
        self,
        mall_code: MallCode,
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreMallCodeDefinition]:
        if not isinstance(mall_code, str) or not mall_code:
            raise CoreMasterValidationError(
                "mall_code_definitions.get_by_mall_id: mall_code is required (string)"
            )
        return await self.list(mall_code=mall_code, fields=fields)
