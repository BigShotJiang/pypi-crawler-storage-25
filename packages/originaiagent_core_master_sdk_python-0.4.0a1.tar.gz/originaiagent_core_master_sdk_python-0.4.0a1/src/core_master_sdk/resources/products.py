"""products resource (read-only, v0.1)。TS 版 resources/products.ts に対応。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from core_master_sdk.client._request import FetchInput
from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.errors import CoreMasterNotFound, CoreMasterValidationError
from core_master_sdk.resources._common import (
    fields_to_query,
    is_amazon_asin,
    merge_filter_query,
    validate_ids,
    validate_non_empty_string,
    validate_positive_int,
)
from core_master_sdk.types.products import CoreProduct


def _list_query(
    q: str | None,
    filter: Mapping[str, Any] | None,
    fields: Sequence[str] | None,
    limit: int | None,
    offset: int | None,
    order: str | None,
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    if q:
        query["q"] = q
    query.update(merge_filter_query(filter))
    fields_list = fields_to_query(fields)
    if fields_list is not None:
        query["fields"] = fields_list
    if limit is not None:
        query["limit"] = limit
    if offset is not None:
        query["offset"] = offset
    if order:
        query["order"] = order
    return query


class ProductsResource:
    def __init__(self, fetcher: SyncFetcher) -> None:
        self._fetcher = fetcher

    def list(
        self,
        *,
        q: str | None = None,
        filter: Mapping[str, Any] | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
        order: str | None = None,
    ) -> list[CoreProduct]:
        query = _list_query(q, filter, fields, limit, offset, order)
        data = self._fetcher.fetch(
            FetchInput(path="/api/v1/master/products", query=query, resource="products.list")
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    def get_by_id(
        self,
        id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProduct:
        validate_positive_int("products.get_by_id: id", id)
        query: dict[str, Any] = {}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/products/{id}",
                query=query,
                resource="products.get_by_id",
            )
        )
        return CoreProduct.model_validate(data)

    def by_ids(
        self,
        ids: Sequence[int],
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProduct]:
        ids_list = validate_ids("products.by_ids", ids)
        query: dict[str, Any] = {"ids": ids_list}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/products/by-ids",
                query=query,
                resource="products.by_ids",
            )
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    def search(
        self,
        q: str,
        *,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
    ) -> list[CoreProduct]:
        validate_non_empty_string("products.search: q", q)
        query: dict[str, Any] = {"q": q}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        if limit is not None:
            query["limit"] = limit
        data = self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/products/search",
                query=query,
                resource="products.search",
            )
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    def get_by_logi_id(
        self,
        logi_id: str,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProduct | None:
        """Logi products.id (ASIN or 'prod-NNNN') → Core マスタ逆引き。

        TS 版 §16.4 ネジレ吸収と同一ロジック (Core 側エンドポイント追加なし)。
        """
        validate_non_empty_string("products.get_by_logi_id: logi_id", logi_id)
        if not is_amazon_asin(logi_id):
            return None

        # lookup を直接呼ぶ (mall_identifiers resource と同じクエリ)
        try:
            hit_raw = self._fetcher.fetch(
                FetchInput(
                    path="/api/v1/master/mall-identifiers/lookup",
                    query={
                        "mallCode": "amazon",
                        "slot": "identifier_2",
                        "value": logi_id,
                    },
                    resource="products.get_by_logi_id.lookup",
                )
            )
        except CoreMasterNotFound:
            return None
        if not hit_raw:
            return None
        # hit_raw は {"coreProductId": ..., "mallIdentifierId": ...}
        core_product_id = hit_raw.get("coreProductId")
        if not isinstance(core_product_id, int):
            return None
        try:
            return self.get_by_id(core_product_id, fields=fields)
        except CoreMasterNotFound:
            return None

    def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProduct:
        validate_positive_int("products.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError("products.patch: body must be non-empty mapping")

        data = self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/products/{id}",
                method="PATCH",
                body=dict(body),
                resource="products.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProduct.model_validate(data)


class AsyncProductsResource:
    def __init__(self, fetcher: AsyncFetcher) -> None:
        self._fetcher = fetcher

    async def list(
        self,
        *,
        q: str | None = None,
        filter: Mapping[str, Any] | None = None,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
        order: str | None = None,
    ) -> list[CoreProduct]:
        query = _list_query(q, filter, fields, limit, offset, order)
        data = await self._fetcher.fetch(
            FetchInput(path="/api/v1/master/products", query=query, resource="products.list")
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    async def get_by_id(
        self,
        id: int,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProduct:
        validate_positive_int("products.get_by_id: id", id)
        query: dict[str, Any] = {}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/products/{id}",
                query=query,
                resource="products.get_by_id",
            )
        )
        return CoreProduct.model_validate(data)

    async def by_ids(
        self,
        ids: Sequence[int],
        *,
        fields: Sequence[str] | None = None,
    ) -> list[CoreProduct]:
        ids_list = validate_ids("products.by_ids", ids)
        query: dict[str, Any] = {"ids": ids_list}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/products/by-ids",
                query=query,
                resource="products.by_ids",
            )
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    async def search(
        self,
        q: str,
        *,
        fields: Sequence[str] | None = None,
        limit: int | None = None,
    ) -> list[CoreProduct]:
        validate_non_empty_string("products.search: q", q)
        query: dict[str, Any] = {"q": q}
        fields_list = fields_to_query(fields)
        if fields_list is not None:
            query["fields"] = fields_list
        if limit is not None:
            query["limit"] = limit
        data = await self._fetcher.fetch(
            FetchInput(
                path="/api/v1/master/products/search",
                query=query,
                resource="products.search",
            )
        )
        return [CoreProduct.model_validate(item) for item in (data or [])]

    async def get_by_logi_id(
        self,
        logi_id: str,
        *,
        fields: Sequence[str] | None = None,
    ) -> CoreProduct | None:
        validate_non_empty_string("products.get_by_logi_id: logi_id", logi_id)
        if not is_amazon_asin(logi_id):
            return None
        try:
            hit_raw = await self._fetcher.fetch(
                FetchInput(
                    path="/api/v1/master/mall-identifiers/lookup",
                    query={
                        "mallCode": "amazon",
                        "slot": "identifier_2",
                        "value": logi_id,
                    },
                    resource="products.get_by_logi_id.lookup",
                )
            )
        except CoreMasterNotFound:
            return None
        if not hit_raw:
            return None
        core_product_id = hit_raw.get("coreProductId")
        if not isinstance(core_product_id, int):
            return None
        try:
            return await self.get_by_id(core_product_id, fields=fields)
        except CoreMasterNotFound:
            return None

    async def patch(
        self,
        id: int,
        body: Mapping[str, Any],
        *,
        tool_name: str | None = None,
        user_email: str | None = None,
        if_match: str | None = None,
        idempotency_key: str | None = None,
    ) -> CoreProduct:
        validate_positive_int("products.patch: id", id)
        if not isinstance(body, Mapping) or not body:
            raise CoreMasterValidationError("products.patch: body must be non-empty mapping")

        data = await self._fetcher.fetch(
            FetchInput(
                path=f"/api/v1/master/products/{id}",
                method="PATCH",
                body=dict(body),
                resource="products.patch",
                tool_name=tool_name,
                user_email=user_email,
                if_match=if_match,
                idempotency_key=idempotency_key,
            )
        )
        return CoreProduct.model_validate(data)
