"""SDK エラー階層。TS 版 @originaiagent/core-master-sdk の errors/index.ts と一致。

運用ルール (TS §3.4 / §11.3.8):
  - AuthError / ValidationError / NotFound は silent 禁止（明示 raise）
  - UpstreamError / RateLimitError は SDK 内で retry 後に raise
  - 呼び側は `except CoreMasterNotFound:` でハンドリング可能
"""

from __future__ import annotations

from typing import Any


class CoreMasterError(Exception):
    """SDK 全例外の基底クラス。"""

    def __init__(
        self,
        message: str = "",
        *,
        status_code: int = 0,
        upstream: dict[str, Any] | None = None,
        trace_id: str | None = None,
        retryable: bool = False,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.upstream = upstream
        self.trace_id = trace_id
        self.retryable = retryable
        if cause is not None:
            self.__cause__ = cause


class CoreMasterAuthError(CoreMasterError):
    """401 / 403 — 認証失敗。INTERNAL_API_KEY を確認。"""

    def __init__(self, message: str = "Authentication failed", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 401)
        kwargs.setdefault("retryable", False)
        super().__init__(message, **kwargs)


class CoreMasterNotFound(CoreMasterError):
    """404 — リソース不在。"""

    def __init__(self, message: str = "Resource not found", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 404)
        kwargs.setdefault("retryable", False)
        super().__init__(message, **kwargs)


class CoreMasterValidationError(CoreMasterError):
    """400 / 422 — 入力バリデーション違反。SDK 側引数チェックでも投げる。"""

    def __init__(self, message: str = "Request validation failed", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 400)
        kwargs.setdefault("retryable", False)
        super().__init__(message, **kwargs)


class CoreMasterRateLimitError(CoreMasterError):
    """429 — レート制限。retry 対象。"""

    def __init__(self, message: str = "Rate limit exceeded", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 429)
        kwargs.setdefault("retryable", True)
        super().__init__(message, **kwargs)


class CoreMasterUpstreamError(CoreMasterError):
    """5xx / タイムアウト / ネットワーク障害。retry 対象。"""

    def __init__(self, message: str = "Upstream service error", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 502)
        kwargs.setdefault("retryable", True)
        super().__init__(message, **kwargs)


class CoreMasterPreconditionFailedError(CoreMasterError):
    """412 — 前提条件失敗 (updated_at 不一致など)。"""

    def __init__(self, message: str = "Precondition failed", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 412)
        kwargs.setdefault("retryable", False)
        super().__init__(message, **kwargs)
