"""@originaiagent/core-master-sdk の Python ポート。

- 型のみ必要なら `from core_master_sdk import CoreProduct` 等
- 同期クライアント: `from core_master_sdk import create_core_master`
- 非同期クライアント: `from core_master_sdk import create_async_core_master`
- pandas ヘルパは `from core_master_sdk.pandas_helpers import products_to_df` (optional)
"""

from core_master_sdk._version import __version__
from core_master_sdk.client import (
    AsyncCoreMasterClient,
    CoreMasterClient,
    CoreMasterErrorContext,
    CoreMasterRequestContext,
    CreateCoreMasterOptions,
    create_async_core_master,
    create_core_master,
)
from core_master_sdk.errors import (
    CoreMasterAuthError,
    CoreMasterError,
    CoreMasterNotFound,
    CoreMasterPreconditionFailedError,
    CoreMasterRateLimitError,
    CoreMasterUpstreamError,
    CoreMasterValidationError,
)
from core_master_sdk.types import (
    CoreMall,
    CoreMallCodeDefinition,
    CoreMallIdentifier,
    CoreMallType,
    CoreProduct,
    CoreProductCost,
    CoreProductGroup,
    CoreProductMallSetting,
    CoreProductPhase,
    CoreProductSku,
    CoreProductSpec,
    CoreValueSourceEntry,
    CoreValueSources,
    IdentifierSlot,
    LookupBulkInput,
    LookupBulkOutput,
    LookupHit,
    LookupInput,
    MallCode,
)

__all__ = [
    "AsyncCoreMasterClient",
    "CoreMall",
    "CoreMallCodeDefinition",
    "CoreMallIdentifier",
    "CoreMallType",
    "CoreMasterAuthError",
    "CoreMasterClient",
    "CoreMasterError",
    "CoreMasterErrorContext",
    "CoreMasterNotFound",
    "CoreMasterPreconditionFailedError",
    "CoreMasterRateLimitError",
    "CoreMasterRequestContext",
    "CoreMasterUpstreamError",
    "CoreMasterValidationError",
    "CoreProduct",
    "CoreProductCost",
    "CoreProductGroup",
    "CoreProductMallSetting",
    "CoreProductPhase",
    "CoreProductSku",
    "CoreProductSpec",
    "CoreValueSourceEntry",
    "CoreValueSources",
    "CreateCoreMasterOptions",
    "IdentifierSlot",
    "LookupBulkInput",
    "LookupBulkOutput",
    "LookupHit",
    "LookupInput",
    "MallCode",
    "__version__",
    "create_async_core_master",
    "create_core_master",
]
