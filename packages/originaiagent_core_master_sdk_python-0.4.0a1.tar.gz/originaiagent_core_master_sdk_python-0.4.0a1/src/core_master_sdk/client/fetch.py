"""同期 HTTP フェッチャ (httpx.Client ベース)。"""

from __future__ import annotations

import time
import uuid
from typing import Any

import httpx

from core_master_sdk.client._request import (
    FetchInput,
    backoff_delay_seconds,
    build_headers,
    build_query_params,
    build_url,
    build_write_headers,
    extract_data,
    map_http_error,
    parse_body,
    should_retry,
    wrap_timeout_as_upstream,
    wrap_transport_as_upstream,
)
from core_master_sdk.client.options import (
    CoreMasterErrorContext,
    CoreMasterRequestContext,
    CreateCoreMasterOptions,
)
from core_master_sdk.errors import CoreMasterError


class SyncFetcher:
    """httpx.Client を共有する同期 fetcher。ライフサイクルは client クラスが管理。"""

    def __init__(
        self,
        options: CreateCoreMasterOptions,
        context: CoreMasterRequestContext,
        http_client: httpx.Client,
    ) -> None:
        self._options = options
        self._context = context
        self._http = http_client

    def with_context(self, context: CoreMasterRequestContext) -> "SyncFetcher":
        return SyncFetcher(self._options, context, self._http)

    def fetch(self, input_: FetchInput) -> Any:
        options = self._options
        url = build_url(options, input_.path)
        params = build_query_params(input_.query)

        # ヘッダ組み立て (v0.3 で POST 追加)
        headers = build_headers(options, self._context)
        if input_.method in ("POST", "PATCH"):
            # Idempotency-Key 確定 (retry 間で固定)
            if not input_.idempotency_key:
                input_.idempotency_key = uuid.uuid4().hex
            headers.update(build_write_headers(input_, options))

        max_attempts = options.retries + 1 if input_.method in ("GET", "POST", "PATCH") else 1

        last_error: BaseException | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                response = self._http.request(
                    input_.method,
                    url,
                    headers=headers,
                    params=params,
                    json=input_.body,
                )
            except httpx.TimeoutException as err:
                last_error = wrap_timeout_as_upstream(err)
            except httpx.TransportError as err:
                last_error = wrap_transport_as_upstream(err)
            else:
                body, trace_id = parse_body(response)
                if response.is_success:
                    return extract_data(body)
                last_error = map_http_error(response.status_code, body, trace_id)

            is_last = attempt == max_attempts
            if not is_last and should_retry(last_error):
                time.sleep(backoff_delay_seconds(attempt))
                continue
            break

        assert last_error is not None
        self._invoke_on_error(last_error, input_)
        raise last_error

    def _invoke_on_error(self, err: BaseException, input_: FetchInput) -> None:
        hook = self._options.on_error
        if hook is None or not isinstance(err, Exception):
            return
        ctx = CoreMasterErrorContext(
            resource=input_.resource,
            method=input_.method,
            status_code=err.status_code if isinstance(err, CoreMasterError) else None,
            trace_id=err.trace_id if isinstance(err, CoreMasterError) else None,
            endpoint=input_.path,
        )
        try:
            hook(err, ctx)
        except Exception:
            # hook 自身の失敗は握り潰す (呼び側責務)
            pass
