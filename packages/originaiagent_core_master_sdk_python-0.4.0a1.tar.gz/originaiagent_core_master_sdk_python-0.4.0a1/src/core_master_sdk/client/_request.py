"""HTTP リクエスト組み立ての共通ヘルパ (sync / async 共用)。

TS 版 fetchJson.ts の buildQueryString / mapHttpError / shouldRetry / backoffDelayMs
と挙動を一致させる。
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

import httpx

from core_master_sdk.client.options import (
    CoreMasterRequestContext,
    CreateCoreMasterOptions,
)
from core_master_sdk.errors import (
    CoreMasterAuthError,
    CoreMasterError,
    CoreMasterNotFound,
    CoreMasterPreconditionFailedError,
    CoreMasterRateLimitError,
    CoreMasterUpstreamError,
    CoreMasterValidationError,
)

QueryValue = str | int | float | bool | None | Iterable[str | int | float]


@dataclass
class FetchInput:
    """fetch* への入力 (TS FetchJsonInput 相当)。"""

    path: str
    query: Mapping[str, QueryValue] | None = None
    resource: str | None = None
    method: str = "GET"
    body: Mapping[str, Any] | None = None
    tool_name: str | None = None
    user_email: str | None = None
    if_match: str | None = None
    idempotency_key: str | None = None


def build_headers(
    options: CreateCoreMasterOptions,
    context: CoreMasterRequestContext,
) -> dict[str, str]:
    """全リクエストに付与する共通ヘッダ (TS fetchJson と同一)。"""
    assert options.internal_api_key is not None  # resolve() 後想定
    headers: dict[str, str] = {
        "X-Internal-API-Key": options.internal_api_key,
        "Accept": "application/json",
    }
    if options.user_agent:
        headers["User-Agent"] = options.user_agent
    if context.run_id:
        headers["X-Run-Id"] = context.run_id
    if context.user_id:
        headers["X-User-Id"] = context.user_id
    if context.caller_tool:
        headers["X-Caller-Tool"] = context.caller_tool
    return headers


def build_write_headers(
    input_: FetchInput,
    options: CreateCoreMasterOptions,
) -> dict[str, str]:
    """POST / PATCH の書き込みリクエスト用の追加ヘッダ (v0.3 で POST 追加)。"""
    headers: dict[str, str] = {}

    # Tool-Name 解決: call-specific -> default -> Error
    tool_name = input_.tool_name or options.default_tool_name
    if not tool_name:
        raise CoreMasterValidationError(
            f"{input_.resource or 'request'}: tool_name is required for write operations"
        )
    headers["X-Tool-Name"] = tool_name

    # User-Email 解決: call-specific -> default -> None
    user_email = input_.user_email or options.default_user_email
    if user_email:
        headers["X-User-Email"] = user_email

    if input_.if_match:
        headers["If-Match"] = input_.if_match

    if input_.idempotency_key:
        headers["Idempotency-Key"] = input_.idempotency_key

    return headers


def build_url(options: CreateCoreMasterOptions, path: str) -> str:
    assert options.base_url is not None  # resolve() 後想定
    if not path.startswith("/"):
        raise CoreMasterValidationError(
            f"fetch path must start with '/': got {path!r}"
        )
    return f"{options.base_url}{path}"


def build_query_params(
    query: Mapping[str, QueryValue] | None,
) -> list[tuple[str, str]]:
    """None / 空配列はスキップ。配列はカンマ結合 (TS buildQueryString 互換)。"""
    if not query:
        return []
    params: list[tuple[str, str]] = []
    for key, value in query.items():
        if value is None:
            continue
        if isinstance(value, (str, int, float, bool)):
            params.append((key, str(value)))
        elif isinstance(value, Iterable):
            # 配列はカンマ結合 1 パラメータ (TS と一致)
            items = [str(v) for v in value]
            if not items:
                continue
            params.append((key, ",".join(items)))
        else:  # pragma: no cover
            params.append((key, str(value)))
    return params


def parse_body(response: httpx.Response) -> tuple[Any, str | None]:
    """レスポンスボディ → (body, trace_id) をパースする。

    TS 版 fetchJson.ts と同じ 2 段フォールバック:
      - JSON パース成功 → dict
      - JSON パース失敗 → 文字列そのまま
      - 空ボディ → None
    trace_id は `x-trace-id` ヘッダ → body.meta.traceId → body.error.traceId の順。
    """
    text = response.text
    body: Any = None
    if text:
        try:
            body = response.json()
        except ValueError:
            body = text
    trace_id: str | None = response.headers.get("x-trace-id")
    if trace_id is None and isinstance(body, dict):
        meta = body.get("meta")
        if isinstance(meta, dict):
            value = meta.get("traceId")
            if isinstance(value, str):
                trace_id = value
        if trace_id is None:
            err = body.get("error")
            if isinstance(err, dict):
                value = err.get("traceId")
                if isinstance(value, str):
                    trace_id = value
    return body, trace_id


def extract_data(body: Any) -> Any:
    """成功 envelope から `data` を取り出す。envelope 外なら body 全体を返す。"""
    if isinstance(body, dict) and "data" in body:
        return body["data"]
    return body


def map_http_error(
    status: int,
    body: Any,
    trace_id: str | None,
) -> CoreMasterError:
    """HTTP status → 例外クラスマッピング (TS fetchJson と同一)。"""
    message = _extract_error_message(body, status)
    upstream: dict[str, Any] | None = {"status": status, "body": body}

    if status in (401, 403):
        return CoreMasterAuthError(
            message, status_code=status, upstream=upstream, trace_id=trace_id
        )
    if status == 404:
        return CoreMasterNotFound(message, upstream=upstream, trace_id=trace_id)
    if status == 412:
        return CoreMasterPreconditionFailedError(
            message, upstream=upstream, trace_id=trace_id
        )
    if status in (400, 422):
        return CoreMasterValidationError(
            message, status_code=status, upstream=upstream, trace_id=trace_id
        )
    if status == 429:
        return CoreMasterRateLimitError(
            message, upstream=upstream, trace_id=trace_id
        )
    if status >= 500:
        return CoreMasterUpstreamError(
            message, status_code=status, upstream=upstream, trace_id=trace_id
        )
    return CoreMasterError(
        message, status_code=status, upstream=upstream, trace_id=trace_id
    )


def _extract_error_message(body: Any, status: int) -> str:
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            msg = err.get("message")
            if isinstance(msg, str) and msg:
                return msg
    return f"HTTP {status}"


def should_retry(err: BaseException) -> bool:
    """retry 対象判定 (TS shouldRetry 互換)。"""
    if isinstance(err, CoreMasterRateLimitError):
        return True
    if isinstance(err, CoreMasterUpstreamError):
        return True
    if isinstance(err, CoreMasterError):
        return err.retryable
    if isinstance(err, httpx.TimeoutException):
        return True
    if isinstance(err, httpx.TransportError):
        return True
    return False


def backoff_delay_seconds(attempt: int) -> float:
    """指数バックオフ + jitter (TS backoffDelayMs と同一式、単位は秒)。"""
    base_ms = 200 * (2 ** (attempt - 1))
    jitter_ms = random.randint(0, 99)
    return (base_ms + jitter_ms) / 1000.0


def wrap_timeout_as_upstream(err: BaseException) -> CoreMasterUpstreamError:
    """httpx のタイムアウトを CoreMasterUpstreamError(retryable=True) にラップ。"""
    return CoreMasterUpstreamError("Request timeout", status_code=0, retryable=True, cause=err)


def wrap_transport_as_upstream(err: BaseException) -> CoreMasterUpstreamError:
    """httpx TransportError を CoreMasterUpstreamError(retryable=True) にラップ。"""
    return CoreMasterUpstreamError(
        f"Network error: {err}", status_code=0, retryable=True, cause=err
    )
