"""同期クライアント本体 (CoreMasterClient)。"""

from __future__ import annotations

from types import TracebackType
from typing import Any

import httpx

from core_master_sdk.client.fetch import SyncFetcher
from core_master_sdk.client.options import (
    CoreMasterRequestContext,
    CreateCoreMasterOptions,
)
from core_master_sdk.resources.mall_code_definitions import MallCodeDefinitionsResource
from core_master_sdk.resources.mall_identifiers import MallIdentifiersResource
from core_master_sdk.resources.malls import MallsResource
from core_master_sdk.resources.product_costs import ProductCostsResource
from core_master_sdk.resources.product_groups import ProductGroupsResource
from core_master_sdk.resources.product_mall_settings import ProductMallSettingsResource
from core_master_sdk.resources.product_skus import ProductSkusResource
from core_master_sdk.resources.product_specs import ProductSpecsResource
from core_master_sdk.resources.products import ProductsResource


class CoreMasterClient:
    """同期クライアント。`create_core_master()` で生成。

    `with` コンテキストマネージャ対応 (httpx.Client の close)。
    """

    def __init__(
        self,
        options: CreateCoreMasterOptions,
        context: CoreMasterRequestContext | None = None,
        http_client: httpx.Client | None = None,
        _owns_http: bool = True,
    ) -> None:
        self._options = options
        self._context = context or CoreMasterRequestContext()
        if http_client is None:
            http_client = _build_http_client(options)
        self._http = http_client
        self._owns_http = _owns_http
        fetcher = SyncFetcher(options, self._context, self._http)
        self.products = ProductsResource(fetcher)
        self.product_groups = ProductGroupsResource(fetcher)
        self.product_costs = ProductCostsResource(fetcher)
        self.product_specs = ProductSpecsResource(fetcher)
        self.product_skus = ProductSkusResource(fetcher)
        self.product_mall_settings = ProductMallSettingsResource(fetcher)
        self.mall_identifiers = MallIdentifiersResource(fetcher)
        self.mall_code_definitions = MallCodeDefinitionsResource(fetcher)
        self.malls = MallsResource(fetcher)

    def with_context(
        self,
        *,
        run_id: str | None = None,
        user_id: str | None = None,
        caller_tool: str | None = None,
    ) -> "CoreMasterClient":
        """新しいリクエストコンテキストで派生クライアントを返す (X-Run-Id 等を伝播)。

        httpx.Client のコネクションプールは親と共有する (閉じない)。
        """
        new_ctx = self._context.merged_with(
            run_id=run_id, user_id=user_id, caller_tool=caller_tool
        )
        return CoreMasterClient(
            self._options,
            context=new_ctx,
            http_client=self._http,
            _owns_http=False,
        )

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> "CoreMasterClient":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


def _build_http_client(options: CreateCoreMasterOptions) -> httpx.Client:
    kwargs: dict[str, Any] = {
        "timeout": httpx.Timeout(options.timeout_seconds),
    }
    if options.transport is not None:
        kwargs["transport"] = options.transport
    return httpx.Client(**kwargs)


def create_core_master(
    *,
    base_url: str | None = None,
    internal_api_key: str | None = None,
    transport: Any | None = None,
    timeout_seconds: float = 15.0,
    retries: int = 2,
    user_agent: str | None = None,
    on_error: Any | None = None,
    default_tool_name: str | None = None,
    default_user_email: str | None = None,
) -> CoreMasterClient:
    """同期クライアントを生成する。

    引数未指定時は `CORE_MASTER_BASE_URL` / `CORE_MASTER_INTERNAL_API_KEY` 環境変数
    (後者は `INTERNAL_API_KEY` フォールバック) を参照する。どちらも未設定なら
    `CoreMasterValidationError` を raise (silent 禁止)。
    """
    options = CreateCoreMasterOptions(
        base_url=base_url,
        internal_api_key=internal_api_key,
        transport=transport,
        timeout_seconds=timeout_seconds,
        retries=retries,
        user_agent=user_agent,
        on_error=on_error,
        default_tool_name=default_tool_name,
        default_user_email=default_user_email,
    ).resolve()
    return CoreMasterClient(options)
