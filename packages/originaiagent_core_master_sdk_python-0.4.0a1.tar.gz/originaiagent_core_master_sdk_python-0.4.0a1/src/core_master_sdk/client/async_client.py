"""非同期クライアント本体 (AsyncCoreMasterClient)。"""

from __future__ import annotations

from types import TracebackType
from typing import Any

import httpx

from core_master_sdk.client.afetch import AsyncFetcher
from core_master_sdk.client.options import (
    CoreMasterRequestContext,
    CreateCoreMasterOptions,
)
from core_master_sdk.resources.mall_code_definitions import (
    AsyncMallCodeDefinitionsResource,
)
from core_master_sdk.resources.mall_identifiers import AsyncMallIdentifiersResource
from core_master_sdk.resources.malls import AsyncMallsResource
from core_master_sdk.resources.product_costs import AsyncProductCostsResource
from core_master_sdk.resources.product_groups import AsyncProductGroupsResource
from core_master_sdk.resources.product_mall_settings import (
    AsyncProductMallSettingsResource,
)
from core_master_sdk.resources.product_skus import AsyncProductSkusResource
from core_master_sdk.resources.product_specs import AsyncProductSpecsResource
from core_master_sdk.resources.products import AsyncProductsResource


class AsyncCoreMasterClient:
    """非同期クライアント。`create_async_core_master()` で生成。

    `async with` コンテキストマネージャ対応 (httpx.AsyncClient の aclose)。
    """

    def __init__(
        self,
        options: CreateCoreMasterOptions,
        context: CoreMasterRequestContext | None = None,
        http_client: httpx.AsyncClient | None = None,
        _owns_http: bool = True,
    ) -> None:
        self._options = options
        self._context = context or CoreMasterRequestContext()
        if http_client is None:
            http_client = _build_async_http_client(options)
        self._http = http_client
        self._owns_http = _owns_http
        fetcher = AsyncFetcher(options, self._context, self._http)
        self.products = AsyncProductsResource(fetcher)
        self.product_groups = AsyncProductGroupsResource(fetcher)
        self.product_costs = AsyncProductCostsResource(fetcher)
        self.product_specs = AsyncProductSpecsResource(fetcher)
        self.product_skus = AsyncProductSkusResource(fetcher)
        self.product_mall_settings = AsyncProductMallSettingsResource(fetcher)
        self.mall_identifiers = AsyncMallIdentifiersResource(fetcher)
        self.mall_code_definitions = AsyncMallCodeDefinitionsResource(fetcher)
        self.malls = AsyncMallsResource(fetcher)

    def with_context(
        self,
        *,
        run_id: str | None = None,
        user_id: str | None = None,
        caller_tool: str | None = None,
    ) -> "AsyncCoreMasterClient":
        new_ctx = self._context.merged_with(
            run_id=run_id, user_id=user_id, caller_tool=caller_tool
        )
        return AsyncCoreMasterClient(
            self._options,
            context=new_ctx,
            http_client=self._http,
            _owns_http=False,
        )

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    async def __aenter__(self) -> "AsyncCoreMasterClient":
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()


def _build_async_http_client(options: CreateCoreMasterOptions) -> httpx.AsyncClient:
    kwargs: dict[str, Any] = {
        "timeout": httpx.Timeout(options.timeout_seconds),
    }
    if options.transport is not None:
        kwargs["transport"] = options.transport
    return httpx.AsyncClient(**kwargs)


def create_async_core_master(
    *,
    base_url: str | None = None,
    internal_api_key: str | None = None,
    transport: Any | None = None,
    timeout_seconds: float = 15.0,
    retries: int = 2,
    user_agent: str | None = None,
    on_error: Any | None = None,
    default_tool_name: str | None = None,
    default_user_email: str | None = None,
) -> AsyncCoreMasterClient:
    """非同期クライアントを生成する (引数未指定時は環境変数フォールバック)。"""
    options = CreateCoreMasterOptions(
        base_url=base_url,
        internal_api_key=internal_api_key,
        transport=transport,
        timeout_seconds=timeout_seconds,
        retries=retries,
        user_agent=user_agent,
        on_error=on_error,
        default_tool_name=default_tool_name,
        default_user_email=default_user_email,
    ).resolve()
    return AsyncCoreMasterClient(options)
