"""SDK 初期化オプション / リクエストコンテキスト / エラーコンテキスト。

TS 版 createCoreMaster.ts の CreateCoreMasterOptions / CoreMasterRequestContext /
CoreMasterErrorContext と機能一致。
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Optional

import httpx

from core_master_sdk.errors import CoreMasterValidationError

_DEFAULT_TIMEOUT_SECONDS: float = 15.0
_DEFAULT_RETRIES: int = 2

_ENV_BASE_URL = "CORE_MASTER_BASE_URL"
_ENV_PRIMARY_KEY = "CORE_MASTER_INTERNAL_API_KEY"
_ENV_FALLBACK_KEY = "INTERNAL_API_KEY"


@dataclass(frozen=True)
class CoreMasterRequestContext:
    """`with_context` で伝播する呼出スコープ。"""

    run_id: str | None = None
    user_id: str | None = None
    caller_tool: str | None = None

    def merged_with(
        self,
        *,
        run_id: str | None = None,
        user_id: str | None = None,
        caller_tool: str | None = None,
    ) -> "CoreMasterRequestContext":
        return replace(
            self,
            run_id=run_id if run_id is not None else self.run_id,
            user_id=user_id if user_id is not None else self.user_id,
            caller_tool=caller_tool if caller_tool is not None else self.caller_tool,
        )


@dataclass(frozen=True)
class CoreMasterErrorContext:
    """`on_error` hook に渡されるコンテキスト。"""

    resource: str | None = None
    method: str | None = None
    status_code: int | None = None
    trace_id: str | None = None
    endpoint: str | None = None


OnErrorHook = Callable[[Exception, CoreMasterErrorContext], None]


@dataclass
class CreateCoreMasterOptions:
    """createCoreMaster / create_async_core_master の設定値。

    base_url / internal_api_key は env 変数フォールバックを許容する
    (`resolve()` 後は必ず値が入る)。
    """

    base_url: str | None = None
    internal_api_key: str | None = None
    transport: Optional[Any] = None  # httpx.BaseTransport | httpx.AsyncBaseTransport
    timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS
    retries: int = _DEFAULT_RETRIES
    user_agent: str | None = None
    on_error: OnErrorHook | None = None
    default_tool_name: str | None = None
    default_user_email: str | None = None

    def resolve(self) -> "CreateCoreMasterOptions":
        """環境変数フォールバック後の確定値を返す (silent 禁止)。"""
        base_url = _resolve_base_url(self.base_url)
        internal_api_key = _resolve_internal_api_key(self.internal_api_key)
        if self.timeout_seconds <= 0:
            raise CoreMasterValidationError(
                "create_core_master: timeout_seconds must be positive"
            )
        if self.retries < 0:
            raise CoreMasterValidationError(
                "create_core_master: retries must be >= 0"
            )
        return CreateCoreMasterOptions(
            base_url=base_url,
            internal_api_key=internal_api_key,
            transport=self.transport,
            timeout_seconds=self.timeout_seconds,
            retries=self.retries,
            user_agent=self.user_agent,
            on_error=self.on_error,
            default_tool_name=self.default_tool_name,
            default_user_email=self.default_user_email,
        )


def _resolve_base_url(provided: str | None) -> str:
    if provided:
        return provided.rstrip("/")
    env_value = os.environ.get(_ENV_BASE_URL, "").strip()
    if env_value:
        return env_value.rstrip("/")
    raise CoreMasterValidationError(
        "create_core_master: base_url is required "
        f"(pass explicitly or set {_ENV_BASE_URL})"
    )


def _resolve_internal_api_key(provided: str | None) -> str:
    if provided:
        return provided
    primary = os.environ.get(_ENV_PRIMARY_KEY, "").strip()
    fallback = os.environ.get(_ENV_FALLBACK_KEY, "").strip()
    if primary and fallback and primary != fallback:
        warnings.warn(
            f"Both {_ENV_PRIMARY_KEY} and {_ENV_FALLBACK_KEY} are set with different "
            f"values; using {_ENV_PRIMARY_KEY}",
            stacklevel=3,
        )
    if primary:
        return primary
    if fallback:
        warnings.warn(
            f"{_ENV_PRIMARY_KEY} is not set; using {_ENV_FALLBACK_KEY} as fallback. "
            f"Please migrate to {_ENV_PRIMARY_KEY}.",
            stacklevel=3,
        )
        return fallback
    raise CoreMasterValidationError(
        "create_core_master: internal_api_key is required "
        f"(pass explicitly or set {_ENV_PRIMARY_KEY})"
    )
