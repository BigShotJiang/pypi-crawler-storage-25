"""product_costs (正規化テーブル)。

TS 版 types/public/productCosts.ts と一致。
"""

from __future__ import annotations

from core_master_sdk.types._base import _Base
from core_master_sdk.types.value_sources import CoreValueSources


class CoreProductCost(_Base):
    id: int
    product_id: int
    # CNY breakdown
    exw_price_cny: float | None
    inspection_fee_cny: float | None
    domestic_shipping_cny: float | None
    subtotal_cny: float | None
    # JPY breakdown
    container_shipping_jpy: float | None
    domestic_shipping_jpy: float | None
    subtotal_jpy: float | None
    import_tax_rate: float | None
    import_tax_amount: float | None
    total_cost: float | None
    # Meta
    exchange_rate: float | None
    effective_from: str | None
    changed_by_id: int | None
    change_reason: str | None
    value_sources: CoreValueSources
    created_at: str | None
    updated_at: str | None
    # JOIN 由来
    changed_by_name: str | None = None
