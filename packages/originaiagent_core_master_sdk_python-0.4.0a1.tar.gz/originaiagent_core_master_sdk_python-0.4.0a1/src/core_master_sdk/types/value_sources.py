"""value_sources jsonb: 各フィールドの出所 / 編集者 / 更新時刻

TS 版 types/public/valueSources.ts と一致。
"""

from __future__ import annotations

from typing import Literal

from core_master_sdk.types._base import _Base


class CoreValueSourceEntry(_Base):
    source: Literal["manual", "external", "auto"]
    actor: str | None
    updated_at: str


CoreValueSources = dict[str, CoreValueSourceEntry]
