"""product_skus types.
"""

from __future__ import annotations

from core_master_sdk.types._base import _Base


class CoreProductSku(_Base):
    id: str
    product_id: int
    variation_name: str | None = None
    # Other fields are extra=ignore
