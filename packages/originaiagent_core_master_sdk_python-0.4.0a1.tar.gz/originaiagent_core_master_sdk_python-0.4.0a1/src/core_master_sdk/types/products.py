"""Core products / product_groups (正規化テーブル群)。

TS 版 types/public/products.ts と一致。
"""

from __future__ import annotations

from core_master_sdk.types._base import _Base


class CoreProduct(_Base):
    id: int
    product_group_id: int | None
    product_name: str | None
    variation: str | None
    jan_code: str | None
    model_number: str | None
    developer: str | None
    factory_liaison: str | None
    lp_designer: str | None
    rsl_shipping_size: str | None
    amazon_package_size: str | None
    volume_cm3: float | None
    actual_weight_kg: float | None
    volumetric_weight_kg: float | None
    case_quantity: int | None
    fba_storage_type: str | None
    shipping_box_weight_kg: float | None
    shipping_box_length_cm: float | None
    shipping_box_width_cm: float | None
    shipping_box_height_cm: float | None
    created_at: str | None
    updated_at: str | None
    # JOIN 由来
    group_name: str | None = None


class CoreProductGroup(_Base):
    id: int
    group_name: str
    developer: str | None
    category: str | None
    created_at: str | None
    updated_at: str | None
    # fields 指定時のみ返る
    product_count: int | None = None
    # include=['products'] 時のみ
    products: list[CoreProduct] | None = None
