"""Lookup resource 型 (TS 版 resources/mallIdentifiers.ts の export 型)。"""

from __future__ import annotations

from typing import Literal

from pydantic import Field
from typing_extensions import TypedDict

from core_master_sdk.types._base import _Base

MallCode = Literal[
    "amazon",
    "rakuten",
    "yahoo",
    "qoo10",
    "aupay",
    "boss",
    "shopify",
]

IdentifierSlot = Literal[
    "identifier_1",
    "identifier_2",
    "identifier_3",
    "identifier_4",
    "identifier_5",
    "identifier_6",
    "identifier_7",
    "identifier_8",
    "identifier_9",
    "identifier_10",
]


class LookupHit(_Base):
    """Core API `/mall-identifiers/lookup` が返す唯一の camelCase レスポンス。

    `_Base` の `populate_by_name=True` により、Python 側からは
    `LookupHit(core_product_id=1, mall_identifier_id=2)` で初期化も可能。
    """

    core_product_id: int = Field(alias="coreProductId")
    mall_identifier_id: int = Field(alias="mallIdentifierId")


class LookupInput(TypedDict):
    mall_code: MallCode
    slot: IdentifierSlot
    value: str


class LookupBulkInput(TypedDict):
    mall_code: MallCode
    slot: IdentifierSlot
    values: list[str]


LookupBulkOutput = dict[str, LookupHit | None]
