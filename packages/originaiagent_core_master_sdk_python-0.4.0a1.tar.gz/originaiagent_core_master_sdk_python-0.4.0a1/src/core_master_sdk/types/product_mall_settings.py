"""product_mall_settings 型 (TS 版 types/public/productMallSettings.ts と一致)。

v0.3 (2026-04-26 / dev_backlog 19522be3): create / softDelete 対応のため
deleted_at timestamptz NULL を追加。
"""

from __future__ import annotations

from typing import Literal

from core_master_sdk.types._base import _Base

CoreMallType = Literal["amazon", "rakuten", "yahoo", "aupay", "qoo10", "self_ec"]
CoreProductPhase = Literal[
    "sample",
    "mass_production",
    "quality_improvement",
    "rough_diamond",
    "bad",
    "discontinued",
]


class CoreProductMallSetting(_Base):
    id: str
    product_id: int
    mall_type: CoreMallType
    parent_asin: str | None = None
    child_asin: str | None = None
    product_management_number: str | None = None
    sku_management_number: str | None = None
    product_code: str | None = None
    individual_product_code: str | None = None
    management_id: str | None = None
    seller_product_code: str | None = None
    seller_option_code: str | None = None
    page_id: str | None = None
    sku_code: str | None = None
    planned_price: int | None = None
    product_page_url: str | None = None
    product_phase: CoreProductPhase | None = None
    # v0.3: soft delete (NULL=active, set=deleted)
    deleted_at: str | None = None
    created_at: str
    updated_at: str
