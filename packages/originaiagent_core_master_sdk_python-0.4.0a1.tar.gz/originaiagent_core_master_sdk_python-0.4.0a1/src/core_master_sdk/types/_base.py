"""全 public モデルの基底クラス。

- `extra="ignore"`: Core が将来カラム追加してもクライアント壊さない
- `populate_by_name=True`: alias / snake_case フィールド名どちらでも初期化可能
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class _Base(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
        populate_by_name=True,
    )
