"""product_specs types.
"""

from __future__ import annotations

from core_master_sdk.types._base import _Base


class CoreProductSpec(_Base):
    id: int
    product_id: int
    # Other fields are extra=ignore
