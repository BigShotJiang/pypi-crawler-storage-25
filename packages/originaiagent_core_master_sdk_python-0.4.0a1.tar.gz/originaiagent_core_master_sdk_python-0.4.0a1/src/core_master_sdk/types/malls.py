"""malls / mall_identifiers / mall_code_definitions (正規化テーブル群)。

TS 版 types/public/malls.ts と一致。
"""

from __future__ import annotations

from core_master_sdk.types._base import _Base
from core_master_sdk.types.value_sources import CoreValueSources


class CoreMall(_Base):
    id: int
    code: str
    name: str
    created_at: str | None


class CoreMallIdentifier(_Base):
    id: int
    product_id: int
    mall_id: int
    identifier_1: str | None
    identifier_2: str | None
    identifier_3: str | None
    identifier_4: str | None
    identifier_5: str | None
    identifier_6: str | None
    identifier_7: str | None
    identifier_8: str | None
    identifier_9: str | None
    identifier_10: str | None
    value_sources: CoreValueSources
    created_at: str | None
    updated_at: str | None
    # JOIN 由来
    mall_code: str | None = None
    mall_name: str | None = None


class CoreMallCodeDefinition(_Base):
    id: int
    mall_id: int
    slot_order: int
    label: str
    input_source: str | None
    is_active: bool
    # JOIN 由来
    mall_code: str | None = None
    mall_name: str | None = None
