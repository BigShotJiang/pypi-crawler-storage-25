from __future__ import annotations

import datetime
from typing import ClassVar
from typing import Optional
from typing import TYPE_CHECKING

from armis_sdk.entities.data_export.base_exported_entity import BaseExportedEntity


if TYPE_CHECKING:
    import pandas


class Application(BaseExportedEntity):
    """
    This class represents an application row that was exported using the data export API.
    """

    entity_name: ClassVar[str] = "applications"

    device_id: int | None = None
    """The id of the device with the application"""

    vendor: str | None = None
    """
    The vendor of the application

    **Example**: `Google`
    """

    name: str | None = None
    """
    The name of the application

    **Example**: `Chrome`
    """

    version: str | None = None
    """
    The version of the application

    **Example**: `30.0.1599.40`
    """

    cpe: str | None = None
    """
    The CPE (Common Platform Enumeration) of the application

    **Example**: `cpe:2.3:a:google:chrome:30.0.1599.40:*:*:*:*:*:*:*`
    """

    first_seen: datetime.datetime | None = None
    """When the application was first seen on the device"""

    last_seen: datetime.datetime | None = None
    """When the application was last seen on the device"""

    @classmethod
    def series_to_model(cls, series: pandas.Series) -> Application:
        return Application(
            device_id=cls._value_or_none(series.get("device_id")),
            vendor=cls._value_or_none(series.get("vendor")),
            name=cls._value_or_none(series.get("name")),
            version=cls._value_or_none(series.get("version")),
            cpe=cls._value_or_none(series.get("cpe")),
            first_seen=cls._value_or_none(series.get("first_seen")),
            last_seen=cls._value_or_none(series.get("last_seen")),
        )
