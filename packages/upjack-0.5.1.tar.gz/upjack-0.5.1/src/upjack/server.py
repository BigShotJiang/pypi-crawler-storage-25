"""FastMCP server that reads an Upjack manifest and auto-generates domain-specific tools."""

import argparse
import copy
import json
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

try:
    from fastmcp import FastMCP
    from fastmcp.tools.tool import Tool, ToolResult
except ImportError as e:
    raise ImportError(
        "FastMCP is required for server functionality. Install with: pip install upjack[mcp]"
    ) from e

from mcp.types import TextContent

from upjack.activity import ACTIVITY_ENTITY_DEF
from upjack.app import UpjackApp
from upjack.relations import rebuild_index
from upjack.schema import (
    BASE_ENTITY_FIELDS,
    BASE_ENTITY_MARKER,
    BASE_ENTITY_REF,
    build_entity_output_schema,
    build_list_output_schema,
    load_schema,
    validate_schema_change,
)

# Alias for readability at call sites — this is the canonical set of
# framework-managed fields, imported from upjack.schema so both the server
# module here and the parity tests reference one source of truth.
_BASE_ENTITY_KEYS = BASE_ENTITY_FIELDS


def _wrap_list(entities: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    """Wrap a list of entities in a standard response envelope."""
    result: dict[str, Any] = {
        "entities": entities,
        "count": len(entities),
    }
    result.update(extra)
    return result


def _prepare_entity_schema(schema: dict[str, Any], *, for_update: bool = False) -> dict[str, Any]:
    """Project an app entity schema onto an MCP tool input schema.

    Tool inputs carry only user-controlled fields — framework-managed base
    fields (id, type, timestamps, status, tags, source) are excluded. That
    means:

    - Any ``allOf`` member pointing at the bundled base entity schema is
      dropped entirely — it only contributes base fields.
    - ``properties`` and ``required`` are filtered to remove those same base
      fields.
    - For update tools, ``required`` is dropped (partial merge semantics).
    - JSON Schema meta keywords (``$schema``, ``$id``) are stripped.

    Assumes ``schema`` has been loaded via ``load_schema`` so any base-entity
    ``$ref`` has already been inlined. Allowing a raw on-disk schema through
    here would leave a remote ``$ref`` that downstream serializers could try
    to dereference over the network.
    """
    result = copy.deepcopy(schema)
    result.pop("$schema", None)
    result.pop("$id", None)

    if "allOf" in result:
        result["allOf"] = [sub for sub in result["allOf"] if not _is_base_entity_schema(sub)]
        if not result["allOf"]:
            del result["allOf"]

    if "properties" in result:
        result["properties"] = {
            k: v for k, v in result["properties"].items() if k not in _BASE_ENTITY_KEYS
        }

    if for_update:
        result.pop("required", None)
    elif "required" in result:
        result["required"] = [r for r in result["required"] if r not in _BASE_ENTITY_KEYS]
        if not result["required"]:
            del result["required"]

    return result


def _is_base_entity_schema(node: Any) -> bool:
    """True if ``node`` is either a ``$ref`` to the base entity schema (raw
    on-disk form) or an inlined copy carrying ``BASE_ENTITY_MARKER`` (the form
    produced by ``load_schema``)."""
    if not isinstance(node, dict):
        return False
    return node.get("$ref") == BASE_ENTITY_REF or node.get(BASE_ENTITY_MARKER) is True


def _make_entity_tool(
    *,
    name: str,
    description: str,
    parameters: dict[str, Any],
    handler: Callable[[dict[str, Any]], dict[str, Any]],
    output_schema: dict[str, Any] | None = None,
) -> Tool:
    """Create a Tool instance with raw JSON Schema parameters and a handler closure.

    Uses a dynamically-created subclass so the handler is captured in the closure
    scope — no Pydantic private-attribute hacks required.
    """

    async def run(self: Tool, arguments: dict[str, Any]) -> ToolResult:
        # Raw Tool subclasses bypass FastMCP's Pydantic deserialization —
        # object arguments may arrive as JSON strings over stdio transport
        parsed: dict[str, Any] = {}
        for k, v in arguments.items():
            if isinstance(v, str) and v.startswith(("{", "[")):
                try:
                    parsed[k] = json.loads(v)
                except (json.JSONDecodeError, ValueError):
                    parsed[k] = v
            else:
                parsed[k] = v
        result = handler(parsed)
        text = json.dumps(result, default=str)
        structured = json.loads(text) if isinstance(result, dict) else None
        return ToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content=structured,
        )

    tool_cls = type(f"_{name}_tool", (Tool,), {"run": run})
    return tool_cls(
        name=name, description=description, parameters=parameters, output_schema=output_schema
    )


# ---------------------------------------------------------------------------
# Tool listing filter
# ---------------------------------------------------------------------------

_CATEGORY_TO_TOOL: dict[str, str] = {
    "create": "create_{name}",
    "get": "get_{name}",
    "update": "update_{name}",
    "list": "list_{plural}",
    "search": "search_{plural}",
    "delete": "delete_{name}",
    "query_by_relationship": "query_{plural}_by_relationship",
    "get_related": "get_related_{name}",
    "get_composite": "get_{name}_composite",
}

_ALL_UTILITY_TOOLS = frozenset({"seed_data", "add_field", "rebuild_index"})


def _resolve_listed_tools(
    name: str,
    plural: str,
    tools: list[str] | None,
) -> set[str]:
    """Map tool category names to actual tool names for an entity."""
    categories = (
        _CATEGORY_TO_TOOL
        if tools is None
        else {k: v for k, v in _CATEGORY_TO_TOOL.items() if k in tools}
    )
    return {tmpl.format(name=name, plural=plural) for tmpl in categories.values()}


def _resolve_utility_tools(utility_tools: list[str] | None) -> set[str]:
    """Resolve which utility tools should be listed."""
    if utility_tools is None:
        return set(_ALL_UTILITY_TOOLS)
    return set(utility_tools) & _ALL_UTILITY_TOOLS


def _register_entity_tools(
    mcp: FastMCP,
    app: UpjackApp,
    entity_def: dict[str, Any],
    schema: dict[str, Any] | None,
) -> None:
    """Register 6 CRUD+search tools for a single entity type."""
    name = entity_def["name"]
    plural = entity_def.get("plural", name + "s")
    prefix = entity_def["prefix"]

    id_hint = f"IDs start with {prefix}_"
    id_param = f"{name}_id"

    # Build output schemas from the entity's JSON Schema
    entity_out = build_entity_output_schema(schema) if schema else None
    list_out = build_list_output_schema(schema) if schema else None

    # Author-supplied examples on the entity schema are passed through to
    # create / update tool schemas as in-context anchors for LLMs. This is
    # pass-through, not generation — we don't invent values. Base entity
    # fields are auto-managed, so we strip them from examples even if the
    # author included them.
    schema_examples = schema.get("examples") if isinstance(schema, dict) else None
    raw_examples = schema_examples if isinstance(schema_examples, list) else []
    author_examples = [
        {k: v for k, v in ex.items() if k not in _BASE_ENTITY_KEYS}
        for ex in raw_examples
        if isinstance(ex, dict)
    ]

    # --- create_{name} ---
    if schema:
        create_params = _prepare_entity_schema(schema)
    else:
        create_params = {"type": "object"}
    create_params.setdefault("type", "object")
    if author_examples:
        create_params["examples"] = copy.deepcopy(author_examples)

    mcp.add_tool(
        _make_entity_tool(
            name=f"create_{name}",
            description=f"Create a new {name}. {id_hint}.",
            parameters=create_params,
            handler=lambda args, _n=name: app.create_entity(_n, args),
            output_schema=entity_out,
        )
    )

    # --- get_{name} ---
    mcp.add_tool(
        _make_entity_tool(
            name=f"get_{name}",
            description=f"Get a {name} by ID. {id_hint}.",
            parameters={
                "type": "object",
                "properties": {
                    id_param: {
                        "type": "string",
                        "description": f"{name} ID ({prefix}_...)",
                    },
                },
                "required": [id_param],
                "examples": [{id_param: f"{prefix}_01HXXX"}],
            },
            handler=lambda args, _n=name, _p=id_param: app.get_entity(_n, args[_p]),
            output_schema=entity_out,
        )
    )

    # --- update_{name} ---
    if schema:
        update_fields_schema = _prepare_entity_schema(schema, for_update=True)
    else:
        update_fields_schema = {"type": "object"}

    raw_props = update_fields_schema.get("properties")
    extra_props: dict[str, Any] = raw_props if isinstance(raw_props, dict) else {}
    update_params: dict[str, Any] = {
        "type": "object",
        "properties": {
            id_param: {
                "type": "string",
                "description": f"{name} ID ({prefix}_...)",
            },
            **extra_props,
        },
        "required": [id_param],
    }
    if author_examples:
        update_params["examples"] = [
            {id_param: f"{prefix}_01HXXX", **example} for example in author_examples
        ]

    mcp.add_tool(
        _make_entity_tool(
            name=f"update_{name}",
            description=(
                f"Update a {name} by ID. Merges fields by default — pass any subset "
                f"of fields to change. Unknown fields are merged onto the entity "
                f"as-is (the schema does not enforce additionalProperties=false). "
                f"{id_hint}."
            ),
            parameters=update_params,
            # NB: we strip the id param from the payload before merging.
            # If an app ever declares a top-level entity property literally
            # named ``{entity_name}_id`` (e.g. ``user_id`` on a ``user``
            # entity), it becomes unreachable via the update tool. Avoid
            # that collision in your schema — or use a differently-named
            # external-id field.
            handler=lambda args, _n=name, _p=id_param: app.update_entity(
                _n, args[_p], {k: v for k, v in args.items() if k != _p}
            ),
            output_schema=entity_out,
        )
    )

    # --- list_{plural} ---
    list_desc = (
        f"List {plural}. Filters by status (default: active). Returns newest first. {id_hint}."
    )

    @mcp.tool(name=f"list_{plural}", description=list_desc, output_schema=list_out)
    def list_tool(status: str = "active", limit: int = 50, _name: str = name) -> dict[str, Any]:
        entities = app.list_entities(_name, status=status, limit=limit)
        return _wrap_list(entities, status_filter=status, limit=limit)

    # --- search_{plural} ---
    search_desc = (
        f"Search {plural} with text query and/or structured filters. "
        f"Text query matches across all string fields (case-insensitive). "
        f"Filters support: direct equality, $gt, $gte, $lt, $lte, $ne, $in, "
        f"$contains, $exists. Sort with '-field' for descending. {id_hint}."
    )

    @mcp.tool(name=f"search_{plural}", description=search_desc, output_schema=list_out)
    def search_tool(
        query: str | None = None,
        filter: dict[str, Any] | None = None,
        sort: str = "-updated_at",
        limit: int = 20,
        _name: str = name,
    ) -> dict[str, Any]:
        entities = app.search_entities(_name, query=query, filter=filter, sort=sort, limit=limit)
        return _wrap_list(entities, query=query, limit=limit)

    # --- delete_{name} ---
    mcp.add_tool(
        _make_entity_tool(
            name=f"delete_{name}",
            description=(
                f"Delete a {name} by ID. Soft delete by default (sets status to 'deleted'). "
                f"Set hard=true to permanently remove. {id_hint}."
            ),
            parameters={
                "type": "object",
                "properties": {
                    id_param: {
                        "type": "string",
                        "description": f"{name} ID ({prefix}_...)",
                    },
                    "hard": {
                        "type": "boolean",
                        "description": "Permanently remove instead of soft delete.",
                        "default": False,
                    },
                },
                "required": [id_param],
                "examples": [{id_param: f"{prefix}_01HXXX"}],
            },
            handler=lambda args, _n=name, _p=id_param: app.delete_entity(
                _n, args[_p], hard=args.get("hard", False)
            ),
            output_schema=entity_out,
        )
    )


def _register_seed_tool(
    mcp: FastMCP,
    app: UpjackApp,
    manifest_dir: Path,
    upjack: dict[str, Any],
) -> None:
    """Register the seed_data tool if seed config exists."""
    seed_config = upjack.get("seed")
    if not seed_config:
        return

    seed_dir = manifest_dir / seed_config.get("data", "seed/")

    @mcp.tool(
        name="seed_data",
        description="Load sample data from the app's seed directory into the workspace.",
    )
    def seed_data() -> dict[str, Any]:
        if not seed_dir.exists():
            return {"error": f"Seed directory not found: {seed_dir}"}

        loaded: list[str] = []
        errors: list[str] = []

        for file in sorted(seed_dir.glob("*.json")):
            raw = json.loads(file.read_text())

            # Normalize to list (single entity or array)
            items = raw if isinstance(raw, list) else [raw]

            for item in items:
                entity_type = item.get("type")
                if not entity_type:
                    errors.append(f"{file.name}: missing 'type' field")
                    continue

                # Extract app data (strip base fields that create_entity generates).
                # Keep "id" so seed data with stable IDs can be used for cross-references.
                data = {
                    k: v
                    for k, v in item.items()
                    if k not in {"type", "created_at", "updated_at", "created_by"}
                }

                try:
                    result = app.create_entity(entity_type, data, created_by="system")
                    loaded.append(f"{entity_type}: {result['id']}")
                except (ValueError, KeyError) as e:
                    errors.append(f"{file.name} ({entity_type}): {e}")

        return {"loaded": loaded, "errors": errors}


_ALLOWED_FIELD_TYPES = frozenset({"string", "integer", "number", "boolean", "array", "object"})

_TYPE_VALIDATORS: dict[str, type | tuple[type, ...]] = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
}

_FIELD_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")

# Reserved field names for the add_field tool — any name matching one of the
# framework-managed fields is rejected. Same set as the tool-input strip list.
_BASE_ENTITY_FIELD_NAMES = BASE_ENTITY_FIELDS


def _register_add_field_tool(
    mcp: FastMCP,
    app: UpjackApp,
    manifest_dir: Path,
) -> None:
    """Register the add_field tool for agent-initiated schema evolution."""

    @mcp.tool(
        name="add_field",
        description=(
            "Add a new field to an entity schema. Validates the change is safe, "
            "writes the updated schema to disk, and reloads it."
        ),
    )
    def add_field(
        entity_type: str,
        field_name: str,
        field_type: str,
        default: Any,
        description: str = "",
        required: bool = True,
    ) -> dict[str, Any]:
        if not _FIELD_NAME_RE.match(field_name):
            return {"error": f"Invalid field_name '{field_name}'. Must match [a-z][a-z0-9_]*"}

        if field_name in _BASE_ENTITY_FIELD_NAMES:
            return {"error": f"Field '{field_name}' is a reserved base entity field"}

        if field_type not in _ALLOWED_FIELD_TYPES:
            return {
                "error": f"Invalid field_type '{field_type}'. Allowed: {sorted(_ALLOWED_FIELD_TYPES)}"
            }

        expected = _TYPE_VALIDATORS[field_type]
        if not isinstance(default, expected):
            return {
                "error": f"Default value {default!r} is not compatible with type '{field_type}'"
            }

        # Look up entity def to find schema path
        if entity_type not in app._entities:
            return {"error": f"Unknown entity type '{entity_type}'"}
        entity_def = app._entities[entity_type]
        schema_path = (manifest_dir / entity_def["schema"]).resolve()

        if not schema_path.is_relative_to(manifest_dir.resolve()):
            return {"error": "Schema path escapes the manifest directory"}

        old_schema = load_schema(schema_path)

        # Check if field already exists
        old_props = old_schema.get("properties", {})
        if field_name in old_props:
            existing_type = old_props[field_name].get("type")
            if existing_type and existing_type != field_type:
                return {"error": f"Field '{field_name}' already exists with type '{existing_type}'"}
            return {"error": f"Field '{field_name}' already exists"}

        # Build new schema
        new_schema = copy.deepcopy(old_schema)
        if "properties" not in new_schema:
            new_schema["properties"] = {}

        prop_def: dict[str, Any] = {"type": field_type, "default": default}
        if description:
            prop_def["description"] = description
        new_schema["properties"][field_name] = prop_def

        if required:
            req = new_schema.setdefault("required", [])
            if field_name not in req:
                req.append(field_name)

        # Validate the change
        diagnostics = validate_schema_change(old_schema, new_schema)
        errors = [d for d in diagnostics if d["severity"] == "error"]
        if errors:
            return {"error": "Schema change validation failed", "diagnostics": errors}

        warnings = [d for d in diagnostics if d["severity"] == "warning"]

        # Write and reload
        schema_path.write_text(json.dumps(new_schema, indent=2) + "\n")
        app.reload_schema(entity_type)

        result: dict[str, Any] = {
            "success": True,
            "entity_type": entity_type,
            "field": {
                "name": field_name,
                "type": field_type,
                "default": default,
                "required": required,
            },
        }
        if warnings:
            result["warnings"] = warnings
        return result


def _register_relationship_tools(
    mcp: FastMCP,
    app: UpjackApp,
    entity_def: dict[str, Any],
    schema: dict[str, Any] | None = None,
) -> None:
    """Register relationship query tools for an entity type."""
    name = entity_def["name"]
    plural = entity_def.get("plural", name + "s")
    id_param = f"{name}_id"

    # Output schemas for relationship tools
    list_out = build_list_output_schema(schema) if schema else None
    entity_out = build_entity_output_schema(schema) if schema else None

    @mcp.tool(
        name=f"query_{plural}_by_relationship",
        description=(
            f"Find {plural} that have a specific relationship pointing to a target entity. "
            f"For example, find all {plural} that 'belongs_to' a given entity."
        ),
        output_schema=list_out,
    )
    def query_by_rel(
        rel: str,
        target_id: str,
        filter: dict[str, Any] | None = None,
        limit: int = 50,
        _name: str = name,
    ) -> dict[str, Any]:
        entities = app.query_by_relationship(_name, rel, target_id, filter=filter, limit=limit)
        return _wrap_list(entities)

    mcp.add_tool(
        _make_entity_tool(
            name=f"get_related_{name}",
            description=(
                f"Follow relationship edges from a {name}. "
                f"'forward' returns entities this {name} points to. "
                f"'reverse' returns entities that point to this {name}."
            ),
            parameters={
                "type": "object",
                "properties": {
                    id_param: {
                        "type": "string",
                        "description": f"{name} ID ({entity_def['prefix']}_...)",
                    },
                    "rel": {
                        "type": "string",
                        "description": "Relationship type to follow. Omit to follow all.",
                    },
                    "direction": {
                        "type": "string",
                        "description": "'forward' or 'reverse'.",
                        "default": "forward",
                    },
                },
                "required": [id_param],
            },
            handler=lambda args, _p=id_param: _wrap_list(
                app.get_related(
                    args[_p],
                    rel=args.get("rel"),
                    direction=args.get("direction", "forward"),
                )
            ),
            output_schema=list_out,
        )
    )

    mcp.add_tool(
        _make_entity_tool(
            name=f"get_{name}_composite",
            description=(
                f"Load a {name} with all related entities in one call. "
                f"Returns the entity with a '_related' key containing forward "
                f"relationships (keyed by rel name) and reverse relationships "
                f"(keyed by ~rel name)."
            ),
            parameters={
                "type": "object",
                "properties": {
                    id_param: {
                        "type": "string",
                        "description": f"{name} ID ({entity_def['prefix']}_...)",
                    },
                    "depth": {
                        "type": "integer",
                        "description": "Traversal depth (default 1).",
                        "default": 1,
                    },
                },
                "required": [id_param],
            },
            handler=lambda args, _n=name, _p=id_param: app.get_composite(
                _n, args[_p], depth=args.get("depth", 1)
            ),
            output_schema=entity_out,
        )
    )


def _register_rebuild_index_tool(
    mcp: FastMCP,
    app: UpjackApp,
) -> None:
    """Register the global rebuild_index tool."""

    @mcp.tool(
        name="rebuild_index",
        description=(
            "Force a full rebuild of the relationship index from entity files. "
            "Use this if the index seems stale or after manual file edits."
        ),
    )
    def do_rebuild_index() -> dict[str, Any]:
        index = rebuild_index(
            app.root,
            app.namespace,
            app._entity_defs_list(),
        )
        total = sum(len(entries) for entries in index.get("reverse", {}).values())
        return {"success": True, "entries": total}


def _register_activity_tools(mcp: FastMCP, app: UpjackApp) -> None:
    """Register convenience tools for activity tracking.

    These are higher-level than the raw CRUD tools (create_activity, etc.)
    because they auto-wire the subject relationship and provide a simpler
    interface for logging and querying activities.
    """

    mcp.add_tool(
        _make_entity_tool(
            name="log_activity",
            description=(
                "Log an activity against an entity. Auto-wires a 'subject' relationship "
                "to the given entity. Use this instead of create_activity when you want "
                "the relationship set up automatically."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "subject_id": {
                        "type": "string",
                        "description": "The entity ID this activity is about.",
                    },
                    "action": {
                        "type": "string",
                        "description": "What happened (e.g., 'email_sent', 'meeting_held').",
                    },
                    "detail": {
                        "type": "object",
                        "description": "Optional structured data about the activity.",
                    },
                },
                "required": ["subject_id", "action"],
            },
            handler=lambda args: app.log_activity(
                subject_id=args["subject_id"],
                action=args["action"],
                detail=args.get("detail"),
            ),
        )
    )

    mcp.add_tool(
        _make_entity_tool(
            name="get_activities",
            description=(
                "Get activities recorded against an entity. Returns activities sorted "
                "most-recent first. Optionally filter by action type."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "subject_id": {
                        "type": "string",
                        "description": "The entity ID to get activities for.",
                    },
                    "action": {
                        "type": "string",
                        "description": "Optional filter — only return activities with this action.",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results (default 50).",
                        "default": 50,
                    },
                },
                "required": ["subject_id"],
            },
            handler=lambda args: app.get_activities(
                subject_id=args["subject_id"],
                action=args.get("action"),
                limit=args.get("limit", 50),
            ),
        )
    )


def _register_resources(
    mcp: FastMCP,
    manifest_dir: Path,
    upjack: dict[str, Any],
) -> None:
    """Register context and skill resources."""
    # Context resource
    context_file = upjack.get("context")
    if context_file:
        context_path = manifest_dir / context_file
        if context_path.exists():

            @mcp.resource("upjack://context", name="Context", description="App domain knowledge")
            def get_context() -> str:
                return context_path.read_text()

    # Skill resources
    skills = upjack.get("skills", [])
    for skill in skills:
        if skill.get("source") != "bundled":
            continue
        skill_path = manifest_dir / skill["path"]
        if not skill_path.exists():
            continue

        # Extract skill name from path (e.g., "skills/lead-qualification/SKILL.md" → "lead-qualification")
        skill_name = skill_path.parent.name
        _register_skill_resource(mcp, skill_name, skill_path)


def _register_skill_resource(mcp: FastMCP, skill_name: str, skill_path: Path) -> None:
    """Register a single skill resource (separate function for clean closure)."""

    @mcp.resource(
        f"upjack://skills/{skill_name}",
        name=skill_name,
        description=f"Skill: {skill_name}",
    )
    def get_skill() -> str:
        return skill_path.read_text()


def _build_instructions(upjack: dict[str, Any]) -> str:
    """Build server instructions from manifest metadata."""
    display = upjack.get("display", {})
    app_name = display.get("name", "App")

    entities = upjack.get("entities", [])
    entity_summaries = []
    for e in entities:
        name = e["name"]
        prefix = e["prefix"]
        entity_summaries.append(f"{name} ({prefix}_)")

    instructions = f"{app_name} with {len(entities)} entity types: {', '.join(entity_summaries)}."

    if upjack.get("context"):
        instructions += "\nRead the upjack://context resource for domain knowledge."

    return instructions


def create_server(manifest_path: str | Path, root: str | Path | None = None) -> FastMCP:
    """Create a FastMCP server from an Upjack manifest.

    Args:
        manifest_path: Path to manifest.json.
        root: Workspace root directory.

    Returns:
        Configured FastMCP server instance.
    """
    manifest_path = Path(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    manifest_dir = manifest_path.parent

    upjack = manifest.get("_meta", {}).get("ai.nimblebrain/upjack", {})
    display = upjack.get("display", {})
    app_name = display.get("name", manifest.get("title", "Upjack App"))

    app = UpjackApp.from_manifest(manifest_path, root=root)

    mcp = FastMCP(
        name=app_name,
        instructions=_build_instructions(upjack),
    )

    # Register tools for each entity type
    for entity_def in upjack.get("entities", []):
        schema = app._schemas.get(entity_def["name"])
        _register_entity_tools(mcp, app, entity_def, schema)

    # Register activity CRUD tools + convenience tools when activities enabled
    if upjack.get("activities"):
        activity_schema = app._schemas.get("activity")
        _register_entity_tools(mcp, app, ACTIVITY_ENTITY_DEF, activity_schema)
        _register_activity_tools(mcp, app)

    # Register seed tool
    _register_seed_tool(mcp, app, manifest_dir, upjack)

    # Register add_field tool
    _register_add_field_tool(mcp, app, manifest_dir)

    # Register relationship tools for each entity type
    for entity_def in upjack.get("entities", []):
        schema = app._schemas.get(entity_def["name"])
        _register_relationship_tools(mcp, app, entity_def, schema)
    # Also register for activity if enabled
    if upjack.get("activities"):
        activity_schema = app._schemas.get("activity")
        _register_relationship_tools(mcp, app, ACTIVITY_ENTITY_DEF, activity_schema)
    _register_rebuild_index_tool(mcp, app)

    # Register resources
    _register_resources(mcp, manifest_dir, upjack)

    # Apply tool listing filter if any entity specifies a tools array.
    # The filter hides auto-generated tools not in the allowlist but always
    # passes through custom tools registered after create_server() returns.
    has_filter = (
        any(e.get("tools") is not None for e in upjack.get("entities", []))
        or upjack.get("utility_tools") is not None
    )

    if has_filter:
        listed_tools: set[str] = set()
        for entity_def in upjack.get("entities", []):
            ename = entity_def["name"]
            eplural = entity_def.get("plural", ename + "s")
            listed_tools.update(_resolve_listed_tools(ename, eplural, entity_def.get("tools")))
        if upjack.get("activities"):
            listed_tools.update(_resolve_listed_tools("activity", "activities", None))
            listed_tools.update({"log_activity", "get_activities"})
        listed_tools.update(_resolve_utility_tools(upjack.get("utility_tools")))

        _original_list_tools = mcp._list_tools

        async def _filtered_list_tools():
            all_tools = await _original_list_tools()
            # Collect the full set of auto-generated names (listed + unlisted)
            all_auto = set()
            for entity_def in upjack.get("entities", []):
                ename = entity_def["name"]
                eplural = entity_def.get("plural", ename + "s")
                all_auto.update(
                    _resolve_listed_tools(ename, eplural, None)  # None = all categories
                )
            if upjack.get("activities"):
                all_auto.update(_resolve_listed_tools("activity", "activities", None))
                all_auto.update({"log_activity", "get_activities"})
            all_auto.update(_ALL_UTILITY_TOOLS)

            return [
                t
                for t in all_tools
                if t.name in listed_tools  # explicitly allowed auto-generated
                or t.name not in all_auto  # custom tool (not auto-generated)
            ]

        mcp._list_tools = _filtered_list_tools  # type: ignore[assignment]

    return mcp


def main() -> None:
    """CLI entrypoint for running the Upjack MCP server."""
    parser = argparse.ArgumentParser(description="Run an Upjack MCP server from a manifest")
    parser.add_argument(
        "manifest",
        help="Path to the Upjack manifest.json",
    )
    parser.add_argument(
        "--root",
        default=None,
        help="Workspace root (default: UPJACK_ROOT env or .upjack)",
    )
    args = parser.parse_args()

    from upjack.paths import resolve_root

    manifest_path = Path(args.manifest).resolve()
    root = resolve_root(args.root)

    # Ensure workspace exists
    root.mkdir(parents=True, exist_ok=True)

    mcp = create_server(manifest_path, root)
    mcp.run()


if __name__ == "__main__":
    main()
