# Copyright (c) 2026 Strategic Innovations AI. All rights reserved.
# Type stubs for catalyst_hdc — generated from src/py_api.rs (catalyst-brain v1.3.2)
# Hand-edited stubs (no automatic generator was wired in v0.7.0).

from typing import Any, Optional, overload

# ── HDC Free Functions ──────────────────────────────────────────────────────────

def rand_bipolar(dim: int) -> list[float]:
    """Random bipolar hypervector of dimension `dim` with values in {-1.0, +1.0}."""

def resonance(a: list[float], b: list[float]) -> float:
    """Cosine similarity normalized to [0, 1]. 1.0 = identical, 0.5 = orthogonal."""

def hdc_bind(a: list[float], b: list[float]) -> list[float]:
    """Element-wise multiplication binding (Patent §Definition 2). Self-inverse."""

def hdc_bundle(a: list[float], b: list[float]) -> list[float]:
    """Majority-vote superposition (Patent §Definition 3). Iterate via functools.reduce."""

def hdc_unbind(compound: list[float], key: list[float]) -> list[float]:
    """Inverse of bind. unbind(bind(A, B), A) ≈ B."""

def hebbian(weights: list[float], pre: list[float], post: list[float], lr: float, dim: int) -> list[float]:
    """O(D) sparse Hebbian outer-product update. Returns new weights."""

def hdc_permute(v: list[float], n: int) -> list[float]:
    """Right-cyclic rotation by n positions (handles negative + wraps modulo dim)."""

def normalise_bipolar(v: list[float]) -> list[float]:
    """Normalize so max absolute value is 1.0."""

def hv_hash(v: list[float]) -> int:
    """Deterministic u64 hash of a hypervector, used for compact identity keys."""

def hv_hash_string(s: str, dim: int) -> list[float]:
    """Deterministically encode a string into a bipolar hypervector of dimension `dim`."""

# ── Holographic Diagnostic Telemetry (v1.3) ────────────────────────────────────

def diagnostic_role(dim: int) -> list[float]:
    """Deterministic DIAGNOSTIC_ROLE bipolar hypervector of dimension `dim`.
    SDK and worker produce identical vectors without coordination."""

def encode_system_state(
    dim: int,
    ram_pct: float,
    cpu_pct: float,
    error_count: int,
    latency_us: int,
) -> list[float]:
    """Encode a system snapshot as a bundled hypervector.
    Each field (ram, cpu, err, lat) is scalar-quantized and bound to its field role."""

def bundle_diagnostics(
    payload: list[float],
    ram_pct: float,
    cpu_pct: float,
    error_count: int,
    latency_us: int,
) -> list[float]:
    """Superpose a diagnostic snapshot onto `payload` using DIAGNOSTIC_ROLE binding.
    Use extract_system_state() on the receiver side to recover the state vector."""

def extract_system_state(bundled: list[float]) -> list[float]:
    """Unbind DIAGNOSTIC_ROLE from `bundled` to recover the (noisy) system-state vector.
    Resonate the result against bucket-encoded scalar HVs to read field values."""


# ── PyCausalMemory ─────────────────────────────────────────────────────────────

class PyCausalMemory:
    """O(1) causal-chain storage backed by streaming causal graph + HMK index."""
    def __init__(self, dim: int) -> None: ...
    def store(self, cause: list[float], effect: list[float], time: list[float]) -> None: ...
    def record(self, cause: list[float], effect: list[float], time: list[float]) -> None: ...
    def query_effect(self, cause: list[float]) -> Optional[list[float]]: ...
    def recall_effect(self, cause: list[float]) -> Optional[list[float]]: ...
    def query_cause(self, effect: list[float]) -> list[list[float]]: ...
    def recall_cause(self, effect: list[float]) -> list[list[float]]: ...
    def query_by_time(self, time: list[float]) -> Optional[list[float]]: ...
    def recall_by_time(self, time: list[float]) -> Optional[list[float]]: ...


# ── PyMultiHopReasoner ─────────────────────────────────────────────────────────

class PyMultiHopReasoner:
    def __init__(self, dim: int) -> None: ...
    def add_fact(self, fact: list[float]) -> int: ...
    def add_link(self, a: int, b: int) -> None: ...
    def reason(self, query: list[float], hops: int) -> list[tuple[int, float]]: ...
    def reset(self) -> None: ...


# ── PyMetacognition ────────────────────────────────────────────────────────────

class PyMetacognition:
    def __init__(self, dim: int) -> None: ...
    def record(self, res: float, coh: float, acc: float, context: list[float], hash: int) -> None: ...
    def success_rate(self) -> float: ...
    def avg_resonance(self) -> float: ...
    def recommend(self) -> list[tuple[str, float, str]]:
        """Returns list of (action, delta, reason) recommendations."""


# ── PySelfAudit ────────────────────────────────────────────────────────────────

class PySelfAudit:
    def __init__(self, dim: int) -> None: ...
    def full_audit(self, hv: list[float]) -> tuple[float, bool, list[str]]:
        """Returns (score, passed, issues)."""
    def check_consistency(self, h1: list[float], h2: list[float]) -> tuple[float, bool, list[str]]:
        """Returns (score, passed, issues). Passed if score >= 0.7."""


# ── PyOptimizer ────────────────────────────────────────────────────────────────

class PyOptimizer:
    def __init__(self) -> None: ...
    def apply(self, action: str, delta: float, reason: str) -> None: ...
    def rollback(self) -> None: ...
    def get(self, name: str) -> Optional[float]:
        """Valid names: learning_rate, attention_weight, momentum, excitation_bias,
        inhibition_bias, identity_lr, exploration_rate."""
    def get_params(self) -> dict[str, float]: ...


# ── PyQuantumAttentionHead ─────────────────────────────────────────────────────

class PyQuantumAttentionHead:
    def __init__(self, dim: int, nqubits: int) -> None: ...
    def compute(self, query: list[float], keys: list[list[float]], values: list[list[float]]) -> list[float]: ...


# ── PyHoloCPUScheduler ─────────────────────────────────────────────────────────

class PyHoloCPUScheduler:
    """O(1) Resonant Superposition Memory + Grover attention + metacognition.

    NOTE: v0.7.0 dopamine API (`process_dopamine_hit`, `dopamine_level`) was
    renamed to `process_feedback`/`feedback_strength`. README is out of date.
    """
    dim: int  # via @getter
    qc: int   # via @getter

    def __init__(self, dim: int, quantum_capacity: int) -> None: ...
    def dimension(self) -> int: ...
    def quantum_capacity(self) -> int: ...
    def store_memory(self, target: str) -> None: ...
    def recall(self, target: str) -> bool: ...
    def export_holographic_state(self) -> list[float]: ...
    def process_feedback(self, signal: float) -> None:
        """Apply a feedback signal in [0.0, 1.0]. Replaces v0.6 process_dopamine_hit."""
    def feedback_strength(self) -> float:
        """Replaces v0.6 dopamine_level."""
    def quantum_grover_search(
        self,
        query: list[float],
        keys: list[list[float]],
        values: list[list[float]],
    ) -> list[float]: ...
    def run_audit_integrity_check(self) -> bool: ...
    def generate_role(self, label: str) -> list[float]: ...


# ── PyHoloGenEngine ────────────────────────────────────────────────────────────

class PyHoloGenEngine:
    """Geometric encoding via HKVC (BVH, photons, materials, pixels)."""
    def __init__(self, dim: int) -> None: ...
    def structural_dimension(self) -> int: ...
    def generate_pixel_geometry(self, x: int, y: int, frame_id: Optional[int] = None) -> list[int]:
        """Map (x, y[, frame_id]) → bipolar i8 hypervector. README v0.7.0 omitted frame_id."""
    def generate_material_mapping(
        self,
        position: list[float],   # length 3
        normal: list[float],     # length 3
        material_id: int,
    ) -> list[int]: ...
    @overload
    def generate_photon(self, color: str) -> list[int]:
        """String color form. Supported: violet/purple, blue, cyan, green, yellow,
        amber/orange, red, white. Wavelength is selected automatically; position
        defaults to [0,0,0] and direction to [1,0,0]."""
    @overload
    def generate_photon(
        self,
        position: list[float],   # length 3
        direction: list[float],  # length 3 — required when position is a vector
        wavelength: float,        # required when position is a vector
    ) -> list[int]: ...
    def encode_bvh_node(
        self,
        min_bounds: list[float],  # length 3
        max_bounds: list[float],  # length 3
        left: list[int],          # bipolar i8 hypervector
        right: list[int],         # bipolar i8 hypervector
    ) -> list[int]: ...
    def simulate_counterfactual(
        self,
        root_state: Any,    # Vec[i8] OR any object whose str() will be hashed to one
        intervention: Any,  # same
    ) -> list[int]: ...


# ── PyHoloSwarm (v0.7.0) ───────────────────────────────────────────────────────

class PyHoloSwarm:
    """Spectral Capability Synthesis: Role ⊗ Policy ⊗ Skill superposition."""
    dim: int

    def __init__(self, dim: int) -> None: ...
    def add_agent(
        self,
        role: str, r_hv: list[float],
        policy: str, p_hv: list[float],
        skill: str, s_hv: list[float],
    ) -> None: ...
    def add_paradox_trap(
        self,
        names: list[str],
        roles: list[list[float]],
        keys: list[list[float]],
    ) -> None: ...
    def resonate(
        self,
        role_key: str,
        p_guess: list[float],
        s_guess: list[float],
        max_iter: int,
    ) -> tuple[str, str, str, float]:
        """Returns (role_name, policy_name, skill_name, final_resonance)."""
    def materialize(self, probe: list[float], threshold: float) -> list[tuple[str, float]]: ...
    def get_swarm_vector(self) -> list[float]: ...


# ── PyHKVC (Holographic Key-Value Cache) ───────────────────────────────────────

class PyHKVC:
    """Complex-domain accumulator for recency-unbiased O(1) KV cache (Patent §6.3)."""
    def __init__(self, dim: int) -> None: ...
    def store(self, key: str, value: str, position: int) -> None: ...
    def query(self, query_key: str) -> tuple[str, float]:
        """Returns (best_value, score)."""
    def count(self) -> int: ...
    def position_score(self, position: int) -> float: ...
    def accumulator_magnitude(self) -> list[float]: ...
