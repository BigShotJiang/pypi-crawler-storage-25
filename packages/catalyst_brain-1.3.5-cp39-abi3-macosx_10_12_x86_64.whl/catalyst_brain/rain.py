# catalyst_brain.rain — Rain Protocol v2: Binary HDC State Transfer
#
# Rain v2 is a binary-first communication layer for Hyperdimensional Computing
# agents. Instead of transmitting JSON tokens, Rain encodes holographic
# hypervectors as compact binary payloads, enabling stateful agent handoff
# in serverless environments without a database.
#
# Key Capabilities:
#   - O(1) zero-copy serialization of hypervector state
#   - Holographic Digest: single D-dimensional vector summarizing agent knowledge
#   - Algebraic Merging: bundle (superpose) digests from multiple agents
#   - SHA-256 integrity verification for transit corruption detection
#   - Base64 header encoding for X-Rain-State HTTP header transfer
#
# Wire Format (.rain):
#   [RAIN 4B][version u16 BE][flags u16 BE][dim u32 BE][n_edges u32 BE]
#   [sha256 32B][compressed payload]
#
# Copyright (c) 2026 Strategic Innovations AI. All rights reserved.
# Licensed under the Research & Evaluation License v1.0.
# Patent: U.S. Provisional Patent Application CATALYST-2026-001.

from __future__ import annotations

import base64
import hashlib
import io
import json
import platform
import struct
import time
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

__all__ = [
    "RainPayload",
    "RainDigest",
    "dump",
    "load",
    "dumps",
    "loads",
    "to_header",
    "from_header",
    "merge_digests",
    "RainError",
    "RAIN_VERSION",
]

# ── Constants ────────────────────────────────────────────────────────────────

RAIN_MAGIC = b"RAIN"
RAIN_VERSION = 2
HEADER_SIZE = 4 + 2 + 2 + 4 + 4 + 32  # magic + ver + flags + dim + n_edges + sha256 = 48B

# Flags
FLAG_COMPRESSED = 0x01
FLAG_HAS_WORLD_VECTOR = 0x02
FLAG_HAS_WEIGHTS = 0x04
FLAG_HAS_EDGES = 0x08

_SDK_VERSION = "1.3.5"


class RainError(Exception):
    """Raised on corrupt, invalid, or incompatible .rain data."""


# ── Holographic Digest ───────────────────────────────────────────────────────

@dataclass
class RainDigest:
    """A single D-dimensional hypervector summarizing an agent's knowledge state.

    Rather than sending a full conversation history, an agent transmits its
    digest — a holographic superposition of all causal edges it has learned.
    Recipients can algebraically merge digests via bundle() without "reading"
    the underlying data.
    """
    agent_id: str
    vector: List[float]
    dim: int = 0
    timestamp: float = 0.0

    def __post_init__(self):
        self.dim = self.dim or len(self.vector)
        self.timestamp = self.timestamp or time.time()


def merge_digests(digests: List[RainDigest]) -> RainDigest:
    """Algebraically merge multiple holographic digests via majority-vote bundle.

    This is the core of Rain v2's "Holographic State Sync" — when an Architect
    agent receives digests from N Specialists, it bundles them into a single
    vector that contains the essence of all agents' work.

    Complexity: O(D) where D = hypervector dimension.
    """
    if not digests:
        raise RainError("Cannot merge empty digest list")

    dim = digests[0].dim
    if any(d.dim != dim for d in digests):
        raise RainError("All digests must have the same dimension")

    # Majority-vote superposition (bundle operation from Patent §Definition 3)
    merged = [0.0] * dim
    for d in digests:
        for i in range(dim):
            merged[i] += d.vector[i]

    # Binarize: sign(sum) → bipolar
    for i in range(dim):
        if merged[i] > 0:
            merged[i] = 1.0
        elif merged[i] < 0:
            merged[i] = -1.0
        # else stays 0.0 (tie)

    return RainDigest(
        agent_id=f"merged:{'+'.join(d.agent_id for d in digests)}",
        vector=merged,
        dim=dim,
    )


# ── Payload ──────────────────────────────────────────────────────────────────

@dataclass
class RainPayload:
    """Self-contained agent state envelope for Rain Protocol v2.

    Encodes the full HDC state of an agent — causal memory edges, world vector,
    Hebbian weights, and scheduler config — into a compact binary format that
    can be transferred between serverless invocations without a database.

    Attributes:
        agent_id:       Unique identifier for the agent instance.
        dim:            Hypervector dimension (typically 10,000).
        world_vector:   Holographic superposition of all causal knowledge.
        edges:          List of (cause, effect, time) hypervector triples.
        weights:        Flattened Hebbian weight matrix.
        config:         Arbitrary agent configuration dict.
        metadata:       Auto-populated transport metadata.
    """
    agent_id: str
    dim: int = 10000
    world_vector: Optional[List[float]] = None
    edges: Optional[List[Tuple[List[float], List[float], List[float]]]] = None
    weights: Optional[List[float]] = None
    config: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.metadata:
            self.metadata = {
                "created_at": time.time(),
                "sdk_version": _SDK_VERSION,
                "platform": platform.system(),
                "arch": platform.machine(),
                "protocol": f"rain-v{RAIN_VERSION}",
            }

    def to_digest(self) -> RainDigest:
        """Extract a holographic digest from this payload's world vector."""
        if self.world_vector is None:
            raise RainError("No world_vector to create digest from")
        return RainDigest(
            agent_id=self.agent_id,
            vector=list(self.world_vector),
            dim=self.dim,
        )

    @property
    def edge_count(self) -> int:
        return len(self.edges) if self.edges else 0

    @property
    def state_size_bytes(self) -> int:
        """Approximate memory footprint of the HDC state."""
        size = 0
        if self.world_vector:
            size += len(self.world_vector) * 4  # f32
        if self.edges:
            size += len(self.edges) * self.dim * 3 * 4  # 3 vectors per edge
        if self.weights:
            size += len(self.weights) * 4
        return size


# ── Serialization ────────────────────────────────────────────────────────────

def _float_list_to_bytes(vec: List[float]) -> bytes:
    """Pack a float list as little-endian f32 array (zero-copy friendly)."""
    return struct.pack(f"<{len(vec)}f", *vec)


def _bytes_to_float_list(data: bytes, count: int) -> List[float]:
    """Unpack little-endian f32 array back to float list."""
    return list(struct.unpack(f"<{count}f", data))


def _serialize(payload: RainPayload) -> Tuple[bytes, int]:
    """Serialize a RainPayload to compressed binary.

    Returns (compressed_bytes, flags).
    """
    flags = FLAG_COMPRESSED
    parts = []

    # Envelope metadata (JSON, compact)
    envelope = {
        "agent_id": payload.agent_id,
        "dim": payload.dim,
        "config": payload.config,
        "metadata": payload.metadata,
    }
    env_bytes = json.dumps(envelope, separators=(",", ":"), sort_keys=True).encode("utf-8")
    parts.append(struct.pack(">I", len(env_bytes)))
    parts.append(env_bytes)

    # World vector (raw f32 binary — zero-copy on decode)
    if payload.world_vector is not None:
        flags |= FLAG_HAS_WORLD_VECTOR
        wv_bytes = _float_list_to_bytes(payload.world_vector)
        parts.append(struct.pack(">I", len(wv_bytes)))
        parts.append(wv_bytes)

    # Causal edges (packed f32 triples)
    if payload.edges:
        flags |= FLAG_HAS_EDGES
        parts.append(struct.pack(">I", len(payload.edges)))
        for cause, effect, t in payload.edges:
            parts.append(_float_list_to_bytes(cause))
            parts.append(_float_list_to_bytes(effect))
            parts.append(_float_list_to_bytes(t))

    # Hebbian weights (raw f32)
    if payload.weights is not None:
        flags |= FLAG_HAS_WEIGHTS
        w_bytes = _float_list_to_bytes(payload.weights)
        parts.append(struct.pack(">I", len(w_bytes)))
        parts.append(w_bytes)

    raw = b"".join(parts)
    compressed = zlib.compress(raw, level=6)
    return compressed, flags


def _deserialize(data: bytes, flags: int, dim: int) -> RainPayload:
    """Deserialize compressed binary to a RainPayload."""
    if flags & FLAG_COMPRESSED:
        try:
            raw = zlib.decompress(data)
        except zlib.error as e:
            raise RainError(f"Decompression failed: {e}") from e
    else:
        raw = data

    offset = 0

    # Envelope
    env_len = struct.unpack(">I", raw[offset:offset + 4])[0]
    offset += 4
    envelope = json.loads(raw[offset:offset + env_len])
    offset += env_len

    world_vector = None
    edges = None
    weights = None

    # World vector
    if flags & FLAG_HAS_WORLD_VECTOR:
        wv_len = struct.unpack(">I", raw[offset:offset + 4])[0]
        offset += 4
        world_vector = _bytes_to_float_list(raw[offset:offset + wv_len], wv_len // 4)
        offset += wv_len

    # Edges
    if flags & FLAG_HAS_EDGES:
        n_edges = struct.unpack(">I", raw[offset:offset + 4])[0]
        offset += 4
        edges = []
        edge_bytes = dim * 4  # f32 per dimension
        for _ in range(n_edges):
            cause = _bytes_to_float_list(raw[offset:offset + edge_bytes], dim)
            offset += edge_bytes
            effect = _bytes_to_float_list(raw[offset:offset + edge_bytes], dim)
            offset += edge_bytes
            t = _bytes_to_float_list(raw[offset:offset + edge_bytes], dim)
            offset += edge_bytes
            edges.append((cause, effect, t))

    # Weights
    if flags & FLAG_HAS_WEIGHTS:
        w_len = struct.unpack(">I", raw[offset:offset + 4])[0]
        offset += 4
        weights = _bytes_to_float_list(raw[offset:offset + w_len], w_len // 4)
        offset += w_len

    return RainPayload(
        agent_id=envelope["agent_id"],
        dim=envelope.get("dim", dim),
        world_vector=world_vector,
        edges=edges,
        weights=weights,
        config=envelope.get("config", {}),
        metadata=envelope.get("metadata", {}),
    )


def _checksum(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


# ── Public API ───────────────────────────────────────────────────────────────

def dumps(payload: RainPayload) -> bytes:
    """Serialize a RainPayload to .rain binary format (in-memory).

    Wire format:
        [RAIN 4B][version u16 BE][flags u16 BE][dim u32 BE][n_edges u32 BE]
        [sha256 32B][compressed payload]
    """
    compressed, flags = _serialize(payload)
    checksum = _checksum(compressed)
    header = (
        RAIN_MAGIC
        + struct.pack(">H", RAIN_VERSION)
        + struct.pack(">H", flags)
        + struct.pack(">I", payload.dim)
        + struct.pack(">I", payload.edge_count)
        + checksum
    )
    return header + compressed


def loads(data: bytes) -> RainPayload:
    """Deserialize .rain binary format to a RainPayload (in-memory)."""
    if len(data) < HEADER_SIZE:
        raise RainError(f"Data too short ({len(data)} bytes), minimum is {HEADER_SIZE}")
    if data[:4] != RAIN_MAGIC:
        raise RainError(f"Bad magic: expected {RAIN_MAGIC!r}, got {data[:4]!r}")

    version = struct.unpack(">H", data[4:6])[0]
    if version > RAIN_VERSION:
        raise RainError(f"Unsupported protocol version {version} (max: {RAIN_VERSION})")

    flags = struct.unpack(">H", data[6:8])[0]
    dim = struct.unpack(">I", data[8:12])[0]
    _n_edges = struct.unpack(">I", data[12:16])[0]
    expected_checksum = data[16:48]
    compressed = data[48:]

    actual_checksum = _checksum(compressed)
    if actual_checksum != expected_checksum:
        raise RainError("Checksum mismatch — payload corrupted in transit")

    return _deserialize(compressed, flags, dim)


def dump(payload: RainPayload, target: Union[str, Path, io.IOBase]) -> None:
    """Serialize a RainPayload to a .rain file."""
    data = dumps(payload)
    if isinstance(target, (str, Path)):
        Path(target).write_bytes(data)
    else:
        target.write(data)


def load(source: Union[str, Path, io.IOBase]) -> RainPayload:
    """Deserialize a .rain file to a RainPayload."""
    if isinstance(source, (str, Path)):
        data = Path(source).read_bytes()
    else:
        data = source.read()
    return loads(data)


def to_header(payload: RainPayload) -> str:
    """Encode a RainPayload as base64 for the ``X-Rain-State`` HTTP header.

    Enables stateless agent handoff between serverless invocations:

        # Agent A (Lambda/Worker)
        state = capture_agent_state()
        payload = RainPayload(agent_id="swarm-lead", world_vector=state.wv)
        headers = {"X-Rain-State": to_header(payload)}
        requests.post("https://next-agent.workers.dev", headers=headers)

        # Agent B (receives)
        restored = from_header(request.headers["X-Rain-State"])
        resume_from(restored.world_vector)
    """
    return base64.b64encode(dumps(payload)).decode("ascii")


def from_header(header: str) -> RainPayload:
    """Decode a RainPayload from a base64 ``X-Rain-State`` header value."""
    try:
        data = base64.b64decode(header)
    except Exception as e:
        raise RainError(f"Base64 decode failed: {e}") from e
    return loads(data)
