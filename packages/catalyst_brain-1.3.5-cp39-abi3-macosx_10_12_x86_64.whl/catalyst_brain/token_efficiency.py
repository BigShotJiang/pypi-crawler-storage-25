"""Catalyst-backed token-efficiency primitives for agent tool loops.

The kernel keeps verbose tool schemas and execution outputs out of model
context until the agent explicitly asks for them. It is intentionally shaped so
an MCP server can wrap it directly: list compact tools, discover relevant tools,
create deferred task records, and export a compact Rain session snapshot.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from typing import Any, Iterable

import catalyst_hdc as hdc

from catalyst_brain.rain import RainPayload, to_header


def _canonical_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def _estimate_tokens(value: str) -> int:
    """Cheap context estimator: four bytes per token is close enough here."""
    return max(1, (len(value.encode("utf-8")) + 3) // 4)


def _cursor_to_index(cursor: str | None) -> int:
    if cursor in (None, ""):
        return 0
    try:
        index = int(cursor)
    except ValueError as exc:
        raise ValueError(f"Invalid cursor {cursor!r}") from exc
    if index < 0:
        raise ValueError(f"Invalid cursor {cursor!r}")
    return index


def _norm_terms(parts: Iterable[str]) -> set[str]:
    terms: set[str] = set()
    for part in parts:
        cleaned = "".join(ch.lower() if ch.isalnum() else " " for ch in part)
        terms.update(token for token in cleaned.split() if token)
    return terms


def _text_hv(value: str, dim: int) -> list[float]:
    """Deterministically encode text as a Catalyst-compatible bipolar HV."""
    raw = value.encode("utf-8")
    out: list[float] = []
    counter = 0
    while len(out) < dim:
        digest = hashlib.blake2b(
            raw + counter.to_bytes(4, "big"),
            digest_size=64,
        ).digest()
        for byte in digest:
            for bit in range(8):
                out.append(1.0 if byte & (1 << bit) else -1.0)
                if len(out) == dim:
                    break
            if len(out) == dim:
                break
        counter += 1
    return out


def _check_python_imports(code: str, allowed_imports: set[str]) -> str | None:
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return f"SyntaxError: {exc}"
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".", 1)[0]
                if root not in allowed_imports:
                    return f"SecurityError: import '{alias.name}' is not allowed."
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".", 1)[0]
            if root not in allowed_imports:
                return f"SecurityError: from '{node.module}' is not allowed."
    return None


@dataclass(frozen=True)
class ToolSpec:
    """Verbose tool definition registered once and expanded only on demand."""

    name: str
    description: str
    input_schema: dict[str, Any]
    tags: tuple[str, ...] = field(default_factory=tuple)

    def full_descriptor(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
            "tags": list(self.tags),
        }

    def search_terms(self) -> set[str]:
        return _norm_terms((self.name, self.description, *self.tags))


@dataclass(frozen=True)
class ToolPage:
    """Compact MCP-style page for progressive tool discovery."""

    tools: list[dict[str, Any]]
    next_cursor: str | None
    compact_bytes: int
    full_bytes: int

    @property
    def saved_context_tokens(self) -> int:
        return max(
            0,
            _estimate_tokens("x" * self.full_bytes)
            - _estimate_tokens("x" * self.compact_bytes),
        )


class CatalystTokenKernel:
    """Progressive discovery and compact task state backed by Catalyst HDC.

    `PyHKVC` stores full descriptors behind compact keys, while hypervector
    fingerprints give agents stable handles for schemas and task outputs. The
    ranked discovery layer uses lexical scoring because raw HDC string hashes
    are designed to be quasi-orthogonal, not semantic embeddings.
    """

    def __init__(self, *, dim: int = 4096, preview_chars: int = 96) -> None:
        self.dim = dim
        self.preview_chars = preview_chars
        self._kv = hdc.PyHKVC(dim)
        self._tools: list[ToolSpec] = []
        self._tool_index: dict[str, int] = {}
        self._tasks: dict[str, dict[str, Any]] = {}
        self._world_vector: list[float] | None = None
        self._positions = 0

    def register_tool(self, spec: ToolSpec) -> dict[str, Any]:
        """Register a verbose tool schema and return its compact descriptor."""
        if not spec.name:
            raise ValueError("ToolSpec.name is required")
        if not spec.description:
            raise ValueError("ToolSpec.description is required")

        position = self._tool_index.get(spec.name)
        if position is None:
            position = len(self._tools)
            self._tools.append(spec)
            self._tool_index[spec.name] = position
        else:
            self._tools[position] = spec

        full = _canonical_json(spec.full_descriptor())
        self._kv.store(f"tool:{spec.name}:full", full, self._next_position())
        self._absorb(f"tool:{spec.name}:{full}")
        return self._compact_tool(spec)

    def list_tools(self, *, limit: int = 20, cursor: str | None = None) -> ToolPage:
        """Return a cursor-paginated compact manifest without schemas."""
        if limit <= 0:
            raise ValueError("limit must be positive")
        start = _cursor_to_index(cursor)
        end = min(start + limit, len(self._tools))
        tools = [self._compact_tool(spec) for spec in self._tools[start:end]]
        next_cursor = str(end) if end < len(self._tools) else None
        return ToolPage(
            tools=tools,
            next_cursor=next_cursor,
            compact_bytes=len(_canonical_json(tools).encode("utf-8")),
            full_bytes=sum(self._full_tool_bytes(spec) for spec in self._tools[start:end]),
        )

    def discover(
        self,
        query: str,
        *,
        limit: int = 5,
        include_schema: bool = False,
    ) -> list[dict[str, Any]]:
        """Rank tools for a task and expand schemas only when requested."""
        if limit <= 0:
            raise ValueError("limit must be positive")
        query_terms = _norm_terms((query,))
        scored: list[tuple[float, ToolSpec, list[str]]] = []
        for spec in self._tools:
            terms = spec.search_terms()
            overlap = sorted(query_terms & terms)
            phrase_bonus = 0.0
            lowered = query.lower()
            for tag in spec.tags:
                if tag.lower() in lowered:
                    phrase_bonus += 0.15
            score = (len(overlap) / max(1, len(query_terms))) + phrase_bonus
            if score == 0.0:
                score = self._fingerprint_resonance(query, spec)
            scored.append((score, spec, overlap))

        scored.sort(key=lambda item: (-item[0], item[1].name))
        results: list[dict[str, Any]] = []
        for score, spec, overlap in scored[:limit]:
            item = self._compact_tool(spec)
            item["score"] = round(score, 6)
            item["why"] = overlap or ["holographic_fingerprint"]
            if include_schema:
                item["schema"] = self._load_schema(spec)
            results.append(item)
        self._absorb(f"discover:{query}:{[item['name'] for item in results]}")
        return results

    def create_code_execution_task(
        self,
        *,
        code: str,
        stdout: str = "",
        stderr: str = "",
        status: str = "queued",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a compact deferred execution record.

        Full code/stdout/stderr are retained in the kernel, while the returned
        status is small enough to stay in the agent loop.
        """
        if status not in {"queued", "running", "completed", "failed"}:
            raise ValueError(f"Unsupported task status {status!r}")
        task_id = self._fingerprint(f"task:{time.time_ns()}:{code}:{stdout}:{stderr}")
        record = {
            "task_id": task_id,
            "status": status,
            "code": code,
            "stdout": stdout,
            "stderr": stderr,
            "metadata": metadata or {},
            "created_at": time.time(),
        }
        self._tasks[task_id] = record
        self._kv.store(f"task:{task_id}:result", _canonical_json(record), self._next_position())
        self._absorb(f"task:{task_id}:{status}:{code}:{stdout}:{stderr}")
        return self.compact_task_status(task_id)

    def run_python_task(
        self,
        code: str,
        *,
        timeout_s: float = 5.0,
        allowed_imports: Iterable[str] | None = None,
    ) -> dict[str, Any]:
        """Execute Python locally and return only a compact task status.

        This is a constrained executor for MCP-style task adapters, not a
        hardened security boundary. It blocks disallowed imports and enforces a
        wall-clock timeout before storing full output behind `fetch_task_result`.
        """
        allowed = set(
            allowed_imports
            or (
                "collections",
                "functools",
                "itertools",
                "json",
                "math",
                "re",
                "statistics",
            )
        )
        violation = _check_python_imports(code, allowed)
        if violation:
            return self.create_code_execution_task(
                code=code,
                stdout="",
                stderr=violation,
                status="failed",
                metadata={"executor": "python-subprocess", "blocked": True},
            )

        tmp_name = ""
        try:
            with tempfile.NamedTemporaryFile(
                suffix=".py",
                mode="w",
                encoding="utf-8",
                delete=False,
            ) as handle:
                handle.write(code)
                tmp_name = handle.name
            proc = subprocess.run(
                [sys.executable, tmp_name],
                capture_output=True,
                text=True,
                timeout=timeout_s,
                env={"PATH": os.environ.get("PATH", "")},
                check=False,
            )
            status = "completed" if proc.returncode == 0 else "failed"
            return self.create_code_execution_task(
                code=code,
                stdout=proc.stdout,
                stderr=proc.stderr,
                status=status,
                metadata={
                    "executor": "python-subprocess",
                    "returncode": proc.returncode,
                    "timeout_s": timeout_s,
                },
            )
        except subprocess.TimeoutExpired:
            return self.create_code_execution_task(
                code=code,
                stdout="",
                stderr=f"TimeoutError: code exceeded {timeout_s}s limit.",
                status="failed",
                metadata={"executor": "python-subprocess", "timeout_s": timeout_s},
            )
        finally:
            if tmp_name:
                try:
                    os.unlink(tmp_name)
                except OSError:
                    pass

    def compact_task_status(self, task_id: str) -> dict[str, Any]:
        record = self._tasks[task_id]
        full_payload = _canonical_json(
            {
                "code": record["code"],
                "stdout": record["stdout"],
                "stderr": record["stderr"],
                "metadata": record["metadata"],
            }
        )
        preview = record["stdout"][: self.preview_chars]
        if len(record["stdout"]) > self.preview_chars:
            preview += "..."
        compact = {
            "task_id": task_id,
            "status": record["status"],
            "output_available": bool(record["stdout"] or record["stderr"]),
            "stdout_preview": preview,
            "stderr_digest": self._fingerprint(record["stderr"]) if record["stderr"] else None,
            "result_ref": f"hkvc://task/{task_id}/result",
        }
        compact_bytes = len(_canonical_json(compact).encode("utf-8"))
        full_bytes = len(full_payload.encode("utf-8"))
        compact["saved_context_tokens"] = max(
            0,
            _estimate_tokens("x" * full_bytes) - _estimate_tokens("x" * compact_bytes),
        )
        return compact

    def fetch_task_result(self, task_id: str) -> dict[str, Any]:
        """Return the full task result only after an explicit fetch."""
        record = self._tasks[task_id]
        return {
            "task_id": task_id,
            "status": record["status"],
            "code": record["code"],
            "stdout": record["stdout"],
            "stderr": record["stderr"],
            "metadata": dict(record["metadata"]),
        }

    def export_rain_snapshot(self, *, agent_id: str = "catalyst-token-kernel") -> dict[str, Any]:
        """Export compact Catalyst state for agent handoff."""
        vector = self._world_vector or _text_hv("empty-token-kernel", self.dim)
        payload = RainPayload(
            agent_id=agent_id,
            dim=self.dim,
            world_vector=vector,
            config={
                "tool_count": len(self._tools),
                "task_count": len(self._tasks),
                "mode": "progressive_tool_discovery",
            },
        )
        header = to_header(payload)
        compact_state_bytes = len(header.encode("utf-8"))
        full_manifest = _canonical_json(
            {
                "tools": [spec.full_descriptor() for spec in self._tools],
                "tasks": list(self._tasks.values()),
            }
        )
        legacy_turns = max(4, len(self._tools) + len(self._tasks))
        full_manifest_bytes = len(full_manifest.encode("utf-8")) * legacy_turns
        ratio = self.estimate_token_savings(compact_state_bytes, full_manifest_bytes)
        return {
            "agent_id": agent_id,
            "rain_header": header,
            "compact_state_bytes": compact_state_bytes,
            "full_manifest_bytes": full_manifest_bytes,
            "legacy_turns_compared": legacy_turns,
            "estimated_reduction_ratio": ratio,
        }

    def estimate_token_savings(self, compact_bytes: int, full_bytes: int) -> float:
        if full_bytes <= 0:
            return 0.0
        return round(max(0.0, 1.0 - (compact_bytes / full_bytes)), 6)

    def _compact_tool(self, spec: ToolSpec) -> dict[str, Any]:
        fingerprint = self._fingerprint(_canonical_json(spec.full_descriptor()))
        return {
            "name": spec.name,
            "description": self._preview(spec.description),
            "tags": list(spec.tags),
            "fingerprint": fingerprint,
            "schema_ref": f"hkvc://tool/{fingerprint}/schema",
        }

    def _load_schema(self, spec: ToolSpec) -> dict[str, Any]:
        encoded, confidence = self._kv.query(f"tool:{spec.name}:full")
        if confidence <= 0.0 or not encoded:
            return spec.input_schema
        try:
            return json.loads(encoded)["input_schema"]
        except (json.JSONDecodeError, KeyError, TypeError):
            return spec.input_schema

    def _full_tool_bytes(self, spec: ToolSpec) -> int:
        return len(_canonical_json(spec.full_descriptor()).encode("utf-8"))

    def _next_position(self) -> int:
        position = self._positions
        self._positions += 1
        return position

    def _preview(self, value: str) -> str:
        if len(value) <= self.preview_chars:
            return value
        return value[: self.preview_chars].rstrip() + "..."

    def _fingerprint(self, value: str) -> str:
        return hashlib.blake2b(value.encode("utf-8"), digest_size=8).hexdigest()

    def _fingerprint_resonance(self, query: str, spec: ToolSpec) -> float:
        query_hv = _text_hv(query, self.dim)
        tool_hv = _text_hv(_canonical_json(spec.full_descriptor()), self.dim)
        return round(hdc.resonance(query_hv, tool_hv) * 0.01, 6)

    def _absorb(self, event: str) -> None:
        event_hv = _text_hv(event, self.dim)
        if self._world_vector is None:
            self._world_vector = event_hv
        else:
            self._world_vector = hdc.hdc_bundle(self._world_vector, event_hv)
