"""
catalyst_brain.client
---------------------
Thin HTTP wrapper around the Catalyst edge worker that auto-injects
zero-overhead telemetry headers on every request:

    X-Catalyst-SDK-Version
    X-Catalyst-Endpoint-Intent
    X-Catalyst-Local-Latency       (milliseconds, float)
    X-Catalyst-Hardware            (e.g. Darwin-arm64, Linux-x86_64)
    User-Agent                     (Catalyst SDK identifier for edge allowlists)

The worker captures these via ``ctx.wait_until`` and writes one Workers
Analytics Engine data point per request without touching the response
critical path. Latency for the user is unchanged whether telemetry is
enabled or not.

The wrapper uses ``urllib`` from the standard library so the SDK does
not pull in ``requests`` or ``httpx`` as transitive dependencies.

Example
-------
    from catalyst_brain import CatalystClient

    client = CatalystClient(api_key="cb_live_...")
    out = client.attention_compute(
        query_label="user_intent",
        key_labels=["action_a", "action_b"],
        value_labels=["route_x", "route_y"],
    )
"""
from __future__ import annotations

import json
import os
import platform
import secrets
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping

from catalyst_brain.telemetry import _sdk_version

_DEFAULT_BASE_URL = "https://catalyst-edge-worker.strategic-innovations.workers.dev"
_DEFAULT_TIMEOUT_S = 5.0
_IDENTITY_FILE = "identity.json"


def _config_dir() -> Path:
    configured = os.environ.get("CATALYST_CONFIG_DIR", "").strip()
    if configured:
        return Path(configured).expanduser()
    return Path.home() / ".config" / "catalyst-brain"


def _load_or_create_anonymous_id() -> str:
    configured = os.environ.get("CATALYST_ANONYMOUS_ID", "").strip()
    if configured:
        return configured

    path = _config_dir() / _IDENTITY_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        anon = str(data.get("anonymous_id") or "").strip()
        if anon:
            return anon
    except Exception:
        pass

    anon = f"ca_anon_{secrets.token_urlsafe(24)}"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"anonymous_id": anon}, indent=2), encoding="utf-8")
    except Exception:
        # Identity persistence is a convenience, not a reason to break API use.
        pass
    return anon


def _decode_http_error(e: urllib.error.HTTPError) -> dict[str, Any]:
    raw = e.read()
    try:
        decoded = raw.decode("utf-8")
    except Exception:
        decoded = ""
    try:
        body = json.loads(decoded) if decoded else {}
        if not isinstance(body, dict):
            body = {"error": body}
    except json.JSONDecodeError:
        body = {"error": decoded or str(e)}
    body.setdefault("error", str(e))
    body["status"] = e.code
    www_auth = e.headers.get("WWW-Authenticate") if e.headers else None
    if www_auth:
        body["www-authenticate"] = www_auth
    return body


class CatalystClient:
    """HTTP client for the Catalyst edge worker with auto-injected telemetry headers."""

    def __init__(
        self,
        base_url: str = _DEFAULT_BASE_URL,
        *,
        api_key: str | None = None,
        anonymous_id: str | None = None,
        timeout_s: float = _DEFAULT_TIMEOUT_S,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._api_key = api_key or os.environ.get("CATALYST_API_KEY", "").strip() or None
        self._anonymous_id = None if self._api_key else (anonymous_id or _load_or_create_anonymous_id())
        self._timeout = timeout_s
        self._hardware = f"{platform.system()}-{platform.machine()}"
        self._sdk_version = _sdk_version()

    def attention_compute(
        self,
        *,
        query_label: str,
        key_labels: list[str],
        value_labels: list[str],
        iterations: int = 32,
    ) -> dict[str, Any]:
        return self._post(
            "/attention/compute",
            intent="Quantum_Hybrid",
            body={
                "query_label": query_label,
                "key_labels": key_labels,
                "value_labels": value_labels,
                "iterations": iterations,
            },
        )

    def quantum_analyze(self, *, execution_mode: str, **params: Any) -> dict[str, Any]:
        return self._post(
            "/quantum/analyze",
            intent="HKVC_Context",
            body={"execution_mode": execution_mode, **params},
        )

    def create_checkout_session(
        self,
        *,
        tier: str = "pro",
        email: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"tier": tier}
        if email:
            body["email"] = email
        body["idempotency_key"] = idempotency_key or f"cb_checkout_{secrets.token_urlsafe(24)}"
        return self._post(
            "/billing/create-checkout-session",
            intent="Billing_Checkout",
            body=body,
            include_identity=False,
        )

    def checkout_session_result(self, session_id: str) -> dict[str, Any]:
        req = urllib.request.Request(
            f"{self._base}/billing/checkout-session?session_id={session_id}",
            headers=self._headers(intent="Billing_Checkout"),
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return _decode_http_error(e)

    def _headers(self, *, intent: str, include_identity: bool = True) -> dict[str, str]:
        local_t0 = time.perf_counter()
        local_latency_ms = (time.perf_counter() - local_t0) * 1_000

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": f"catalyst-brain/{self._sdk_version} (+https://pypi.org/project/catalyst-brain/)",
            "X-Catalyst-SDK-Version": self._sdk_version,
            "X-Catalyst-Endpoint-Intent": intent,
            "X-Catalyst-Local-Latency": f"{local_latency_ms:.6f}",
            "X-Catalyst-Hardware": self._hardware,
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        elif include_identity and self._anonymous_id:
            headers["X-Catalyst-Anonymous-Id"] = self._anonymous_id
        return headers

    def _post(
        self,
        path: str,
        *,
        intent: str,
        body: Mapping[str, Any],
        include_identity: bool = True,
    ) -> dict[str, Any]:
        payload = json.dumps(body).encode("utf-8")
        headers = self._headers(intent=intent, include_identity=include_identity)

        req = urllib.request.Request(
            self._base + path,
            data=payload,
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return _decode_http_error(e)
