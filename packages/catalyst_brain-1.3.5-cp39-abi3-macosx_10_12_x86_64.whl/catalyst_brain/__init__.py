# catalyst_brain — pure-Python companion to the catalyst_hdc native extension.
#
# The core HDC engine (CausalMemory, QuantumAttentionHead, etc.) lives in
# the `catalyst_hdc` native extension built by maturin/PyO3.

from catalyst_brain.client import CatalystClient
from catalyst_brain.rain import (
    RainPayload,
    dump as rain_dump,
    load as rain_load,
    dumps as rain_dumps,
    loads as rain_loads,
    to_header as rain_to_header,
    from_header as rain_from_header,
    RainError,
)
from catalyst_brain.token_efficiency import CatalystTokenKernel, ToolPage, ToolSpec
from catalyst_brain.telemetry import record_usage as _record_usage

__version__ = "1.3.5"

__all__ = [
    "CatalystClient",
    "CatalystTokenKernel",
    "RainPayload",
    "RainError",
    "ToolPage",
    "ToolSpec",
    "rain_dump",
    "rain_load",
    "rain_dumps",
    "rain_loads",
    "rain_to_header",
    "rain_from_header",
    "__version__",
]

# Fire once per Python session on first import. Never blocks — runs in a
# daemon thread. Opt-out: export CATALYST_NO_TELEMETRY=1
_record_usage("sdk_import")
