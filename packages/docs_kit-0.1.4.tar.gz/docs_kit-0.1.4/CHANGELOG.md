# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-16

### Added

- `DocsKitAgent` high-level Python API: `ingest()`, `query()`
- CLI: `docs-kit init`, `fetch`, `ingest`, `serve`, `install`, `query`, `inspect`, `doctor`
- GitBook fetch via `/llms-full.txt` / `/llms.txt` and linked pages
- Local embeddings with FastEmbed (dense + sparse/BM25)
- Vector store: Qdrant (local path or remote URL)
- Document parsers: `.txt`, `.md`
- `DocsKitConfig` with YAML and environment variable support
- MCP server tools: `search_docs`, `list_sources`, `get_collection_info`, `get_full_document`
- `docs-kit.yaml` annotated example config
- GitHub Actions CI (Python 3.11, 3.12) and publish pipeline (TestPyPI → PyPI)
