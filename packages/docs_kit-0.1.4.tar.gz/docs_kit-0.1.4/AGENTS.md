# docs-kit — Agent Instructions

## Scope

This document applies to AI agents working on the **docs-kit** codebase: a **PyPI** package (and optional **npx** wrapper) that **fetches documentation** (GitBook, Mintlify, or local files), **stores and embeds it locally** (markdown on disk + Qdrant), and **teaches coding agents to call the CLI** via **installed skills** — not via an MCP server.

---

## What the product does

1. **Fetch** — Fetchers use `/llms-full.txt` and `/llms.txt` on public doc sites; **Mintlify** also falls back to `/sitemap.xml` when needed. **GitBook** and **Mintlify** are supported; `docs-kit ingest` accepts `--provider auto|gitbook|mintlify`.
2. **Local storage** — `docs-kit fetch` writes `.md` files; `docs-kit ingest` chunks, embeds with FastEmbed (dense + sparse/BM25), and upserts into local Qdrant. Concurrent CLI processes coordinate with **filelock** on the Qdrant path.
3. **Agent integration** — `docs-kit install <agent>` installs **skill templates** (`docs_kit/templates/`) so agents run **`docs-kit` CLI** commands (`query`, `list`, `ingest`, `remove`, `inspect`, `doctor`, etc.). **Claude Desktop** gets a zip to upload in the app; **Cursor** may also get a home-level `AGENTS.md` fallback fragment.
4. **Install targets** (see `INSTALL_TARGETS` in `docs_kit/cli/commands.py`): `claude-code`, `claude-desktop`, `cursor`, `codex`, `codex-app`, `codex-desktop`, `opencode`.

The **npx** package under `npx-wrapper/` ensures Python 3.11+ and installs/runs the **`docs-kit`** Python module; behavior lives in Python.

---

## Security (Non-Negotiable)

- **MUST NOT** read, access, or reference `.env`, `.env.local`, `.env.*`, or any secret/credentials files.
- **MUST NOT** recommend reading environment files. If config is needed, ask the user for non-sensitive details.
- **MUST** treat `.env` files as if they do not exist.

---

## Verification After Changes

From the repository root:

```bash
pytest tests/ -v
```

- **MUST NOT** claim work is complete without a successful test run when behavior or dependencies changed.

---

## Git Commit Workflow

When the user asks to commit, stage, or write a commit message:

1. **MUST** analyze staged/unstaged changes via `git status` and `git diff` in the relevant git root.
2. **MUST** write a commit message following Conventional Commits:
   - `feat:` — new feature
   - `fix:` — bug fix
   - `chore:` — maintenance, deps, config
   - `docs:` — documentation only
   - `style:` — formatting, no logic change
   - `refactor:` — code restructure
   - `test:` — tests only
   - `perf:` — performance
3. **SHOULD** keep subject line under 50 chars, imperative mood; use bullet points in body.
4. **SHOULD** suggest splitting into atomic commits if changes span unrelated concerns.

---

## Project Context (Brief)

- **Package name:** `docs-kit` (import `docs_kit`, CLI `docs-kit`). **Python:** `>=3.11,<3.14` (`pyproject.toml`); no `mcp` dependency in this tree.
- **Main types:** `DocsKitConfig` (`docs_kit/core/config.py`), `DocsKitAgent` (`docs_kit/agent.py`).
- **CLI:** `docs_kit/cli/commands.py` + `docs_kit/cli/__main__.py` — `init`, `fetch`, `ingest`, `query`, `inspect`, `doctor`, `install`, `remove`, `list`.
- **Fetchers:** `docs_kit/connectors/fetchers/gitbook.py`, `mintlify.py`, shared `llms_txt` helpers.
- **Skills / install artifacts:** `docs_kit/templates/` (e.g. `skill.md`, `claude_code_skill.md`, `cursor_agents_md.md`).
- **Docs:** [README.md](README.md) for user-facing quickstart (if it diverges from the repo, trust the code and `docs/project-overview.md` for architecture).
