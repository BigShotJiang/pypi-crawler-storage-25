import click
from docs_kit.cli.commands import init_cmd, ingest_cmd, inspect_cmd, doctor_cmd, query_cmd, fetch_cmd, install_cmd, remove_cmd, list_cmd
from docs_kit.cli.help import DocsKitGroup, HELP_CONTEXT_SETTINGS, format_examples


@click.group(
    cls=DocsKitGroup,
    context_settings=HELP_CONTEXT_SETTINGS,
    epilog=format_examples(
        "docs-kit ingest https://docs.example.com",
        'docs-kit query "How do I authenticate?"',
        "docs-kit install claude-code",
    ),
)
@click.version_option(package_name="docs-kit")
def cli():
    """Fetch docs, embed them locally, and expose them to AI agents via skills."""
    pass


cli.add_command(init_cmd, "init")
cli.add_command(ingest_cmd, "ingest")
cli.add_command(inspect_cmd, "inspect")
cli.add_command(doctor_cmd, "doctor")
cli.add_command(query_cmd, "query")
cli.add_command(fetch_cmd, "fetch")
cli.add_command(install_cmd, "install")
cli.add_command(remove_cmd, "remove")
cli.add_command(list_cmd, "list")


if __name__ == "__main__":
    cli()
