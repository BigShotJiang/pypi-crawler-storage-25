# docs-kit — Documentation Knowledge Base

docs-kit is a globally installed CLI tool for searching and managing local documentation embeddings.
All configuration and data are stored under `~/.docs-kit/` — no extra setup required.

Executable: `{{DOCS_KIT_CMD}}`

## When to use

Use docs-kit when working with third-party library docs, API references, or documentation that has
been ingested into the local knowledge base.

## Workflow

1. Run `{{DOCS_KIT_CMD}} list` to check what documentation is available.
2. Run `{{DOCS_KIT_CMD}} query "your question"` to search.
3. If docs are not ingested yet, suggest: `{{DOCS_KIT_CMD}} ingest <url-or-path>`

## Commands

- `{{DOCS_KIT_CMD}} query "search terms"` — search ingested documentation
- `{{DOCS_KIT_CMD}} list` — list all ingested sources with dates
- `{{DOCS_KIT_CMD}} ingest <url-or-path>` — ingest docs from a URL or local path
- `{{DOCS_KIT_CMD}} fetch <url>` — download docs to local Markdown files
- `{{DOCS_KIT_CMD}} remove <source>` — remove a previously ingested source
- `{{DOCS_KIT_CMD}} inspect` — show collection stats
- `{{DOCS_KIT_CMD}} doctor` — diagnose issues
