---
name: docs-kit
description: Search and manage documentation knowledge bases using docs-kit CLI commands for ingesting, querying, and managing local doc embeddings.
---

# docs-kit — Documentation Knowledge Base

docs-kit is a globally installed CLI tool that fetches, embeds, and searches documentation locally.
All configuration and data are stored under `~/.docs-kit/` — no extra setup required.

Executable: `{{DOCS_KIT_CMD}}`

## When to use

Use docs-kit when the user asks about third-party library docs, API references, or wants to manage documentation sources.

## Workflow

1. Run `{{DOCS_KIT_CMD}} list` to check what documentation is available.
2. Run `{{DOCS_KIT_CMD}} query "your question"` to search ingested docs.
3. If docs are not yet ingested: `{{DOCS_KIT_CMD}} ingest <url-or-path>`

## Commands

- `{{DOCS_KIT_CMD}} query "search terms"` — search documentation
- `{{DOCS_KIT_CMD}} list` — list all ingested sources
- `{{DOCS_KIT_CMD}} ingest <url-or-path>` — ingest new docs
- `{{DOCS_KIT_CMD}} fetch <url>` — download docs to local files
- `{{DOCS_KIT_CMD}} remove <source>` — remove a source
- `{{DOCS_KIT_CMD}} inspect` — collection stats
- `{{DOCS_KIT_CMD}} doctor` — diagnose issues
