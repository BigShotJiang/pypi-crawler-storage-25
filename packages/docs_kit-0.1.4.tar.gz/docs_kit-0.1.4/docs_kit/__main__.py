from docs_kit.cli.__main__ import cli

if __name__ == "__main__":
    cli()
