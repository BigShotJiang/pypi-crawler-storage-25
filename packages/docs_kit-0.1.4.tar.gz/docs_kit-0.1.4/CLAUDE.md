# docs-kit — Project Memory

## Project Overview

**docs-kit** is a distributable toolkit (PyPI **`docs-kit`**, optional **npm/npx** wrapper) that:

1. **Pulls** documentation from public **GitBook** and **Mintlify** sites via AI-oriented endpoints (`/llms-full.txt` or `/llms.txt` and linked pages).
2. **Stores** content locally — either as downloaded `.md` files (`docs-kit fetch`) or in a **local Qdrant** vector store after embedding (`docs-kit ingest`).
3. **Ingests** with **local embeddings** (FastEmbed by default; no API keys required for embeddings).
4. **Installs skill files** into AI agents (Claude Code, Cursor, Codex, OpenCode, Claude Desktop) that teach them to call `docs-kit` CLI commands directly — no background server required.

**Pitch:** Point at any public docs, embed locally, let your coding agents query them directly via CLI skills.

**Target:** Developers who want product/docs RAG in the agent loop without shipping docs to a remote embedding API.

---

## Distribution

| Channel | What it is |
|---------|------------|
| **PyPI** | Canonical install: `pipx install docs-kit`. CLI entry: `docs-kit`. |
| **npm/npx** | `npx-wrapper/` — thin Node shim that ensures Python 3.11+ and `pip install docs-kit`, then runs `python -m docs_kit …`. |

---

## Repo Structure

| Path | Purpose |
|------|---------|
| `docs_kit/` | Python package: `DocsKitAgent`, GitBook/Mintlify fetchers, parsers, FastEmbed, Qdrant store, Click CLI |
| `docs_kit/cli/` | CLI (`docs-kit init`, `fetch`, `ingest`, `install`, `query`, `inspect`, `list`, `remove`, `doctor`) |
| `docs_kit/templates/` | Skill/instruction template files installed by `docs-kit install` |
| `docs_kit/connectors/fetchers/gitbook.py` | GitBook `llms-full.txt` / `llms.txt` fetch |
| `docs_kit/connectors/fetchers/mintlify.py` | Mintlify fetch with sitemap.xml fallback |
| `npx-wrapper/` | npm package wrapping the Python CLI |
| `tests/` | pytest suite |
| `data/sample_docs/` | Sample markdown for local ingest tests |

---

## Tech Stack

- **Python** ≥ 3.11, **Click**, **Pydantic** / **pydantic-settings**, **httpx**, **PyYAML**
- **Embeddings:** FastEmbed (local)
- **Vector store:** Qdrant (local embedded, path `~/.docs-kit/qdrant` for user config)
- **Concurrency:** `filelock` for serializing concurrent embedded Qdrant access

---

## Security & Privacy

- **NEVER** touch `.env`, `.env.local`, `.env.*`, or other secret/credentials files. Treat them as if they do not exist.
- **NEVER** read, access, reference, or recommend reading environment or secret files.
- **ALWAYS** work on `.env.example` when documenting or adding environment variables — use placeholder values only.
- If config is needed, ask the user for non-sensitive details.

---

## Build & Verification

From the project root (where `pyproject.toml` lives):

```bash
/usr/local/bin/python3.13 -m pytest tests/ -v
```

After substantive changes, run the full test suite before claiming completion.

---

## Git Commits

- **MUST** write descriptive commit messages using [Conventional Commits](https://www.conventionalcommits.org/): `feat`, `fix`, `chore`, `docs`, `style`, `refactor`, `test`, `perf`.
- **SHOULD** keep subject line under 50 characters, imperative mood; use bullet points in body for context.

---

## Key Paths & Commands

- **Config:** auto-created at `~/.docs-kit/docs-kit.yaml` on first use; or project-local `docs-kit.yaml` via `docs-kit init`
- **Fetch only:** `docs-kit fetch <url> --output docs-kit-docs`
- **Ingest URL or path:** `docs-kit ingest https://example.gitbook.io/docs` or `docs-kit ingest ./path/to/markdown`
- **Agent setup:** `docs-kit install claude-code` (or `cursor`, `codex`, `opencode`, `claude-desktop`)
- **No MCP server:** `serve` and `stop` commands do not exist; agents call CLI directly via installed skill files
