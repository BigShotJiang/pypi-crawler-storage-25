"""Record-and-replay proxy functionality."""

from mockllm.recorder.proxy import create_recording_app

__all__ = ["create_recording_app"]
