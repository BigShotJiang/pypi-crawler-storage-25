"""SSE streaming simulation."""

from mockllm.streaming.sse import stream_response

__all__ = ["stream_response"]
