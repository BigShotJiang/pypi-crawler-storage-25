"""Version information for gitflow-analytics."""

__version__ = "3.13.29"
__version_info__ = tuple(int(x) for x in __version__.split("."))
