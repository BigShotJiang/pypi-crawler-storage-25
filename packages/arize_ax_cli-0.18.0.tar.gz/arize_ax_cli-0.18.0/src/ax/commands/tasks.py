"""Task management commands."""

from datetime import datetime
from typing import Annotated, Any

import typer
from arize.tasks.client import RunStatus, TaskType
from arize.tasks.types import TasksCreateRequestEvaluatorsInner

from ax.core.client_factory import make_client
from ax.core.decorators import handle_errors
from ax.core.exceptions import APIError, UsageError
from ax.core.output import output_data
from ax.utils.console import (
    confirm,
    info,
    setup_logging,
    spinner,
    warning,
)
from ax.utils.file_io import parse_output_option
from ax.utils.json_source import load_json

app = typer.Typer(
    name="tasks",
    help="Manage evaluation tasks",
    no_args_is_help=True,
    context_settings={"help_option_names": ["--help", "-h"]},
)


def _build_evaluators(
    parsed: dict[str, Any] | list[dict[str, Any]],
) -> list[TasksCreateRequestEvaluatorsInner]:
    """Parse a JSON string into a list of TasksCreateRequestEvaluatorsInner."""
    if not isinstance(parsed, list) or not parsed:
        raise typer.BadParameter(
            "--evaluators must be a non-empty JSON array of evaluator objects"
        )
    try:
        evaluators = [
            TasksCreateRequestEvaluatorsInner.from_dict(e) for e in parsed
        ]
    except Exception as exc:
        raise typer.BadParameter(f"Failed to parse evaluators: {exc}") from exc

    none_indices = [i for i, e in enumerate(evaluators) if e is None]
    if none_indices:
        raise typer.BadParameter(
            f"Failed to parse evaluator(s) at index(es): {none_indices}"
        )
    return evaluators  # type: ignore[return-value]


def _parse_experiment_ids(value: str | None) -> list[str] | None:
    """Parse a comma-separated string of experiment IDs into a list."""
    if not value:
        return None
    return [e.strip() for e in value.split(",") if e.strip()]


# ---------------------------------------------------------------------------
# Task commands
# ---------------------------------------------------------------------------


@app.command("list")
@handle_errors
def list_tasks(
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            "-n",
            help="Case-insensitive substring filter on task name",
        ),
    ] = None,
    project: Annotated[
        str | None,
        typer.Option("--project", help="Filter tasks by project name or ID"),
    ] = None,
    dataset: Annotated[
        str | None,
        typer.Option("--dataset", help="Filter tasks by dataset name or ID"),
    ] = None,
    space: Annotated[
        str | None,
        typer.Option("--space", "-s", help="Space name or ID"),
    ] = None,
    task_type: Annotated[
        TaskType | None,
        typer.Option(
            "--task-type",
            help="Filter by task type: template_evaluation or code_evaluation",
        ),
    ] = None,
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-l",
            help="Maximum number of tasks to return",
        ),
    ] = 15,
    cursor: Annotated[
        str | None,
        typer.Option(
            "--cursor",
            "-c",
            help="Pagination cursor for next page",
        ),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="Enable verbose logs",
        ),
    ] = False,
) -> None:
    """List evaluation tasks."""
    setup_logging(verbose)
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Fetching tasks"):
            response = client.tasks.list(
                name=name,
                space=space,
                project=project,
                dataset=dataset,
                task_type=task_type,
                limit=limit,
                cursor=cursor,
            )
    except Exception as e:
        raise APIError(f"Failed to list tasks: {e}") from e
    else:
        output_data(
            response, format_type=output_format, output_file=output_file
        )


@app.command("get")
@handle_errors
def get_task(
    task_id: Annotated[str, typer.Argument(help="Task name or ID")],
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Get a task by name or ID."""
    setup_logging(verbose)
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Fetching task"):
            task = client.tasks.get(task=task_id)
    except Exception as e:
        raise APIError(f"Failed to get task: {e}") from e
    else:
        output_data(task, format_type=output_format, output_file=output_file)


@app.command("create")
@handle_errors
def create_task(
    name: Annotated[
        str,
        typer.Option(
            "--name",
            "-n",
            help="Task name (unique within the space)",
        ),
    ],
    task_type: Annotated[
        TaskType,
        typer.Option(
            "--task-type",
            help="Task type: template_evaluation or code_evaluation",
        ),
    ],
    evaluators: Annotated[
        str,
        typer.Option(
            "--evaluators",
            help=(
                "JSON array of evaluator configs. Find evaluator IDs with `ax evaluators list`. "
                'Example: \'[{"evaluator_id": "RXZhbaGWx9yOjEyMzQ1", '
                '"query_filter": "tag[environment] = \'production\'", '
                '"column_mappings": {"input": "user_query", "output": "model_response"}}]\'. '
                "Fields: evaluator_id (required, base64 ID from ax evaluators list), "
                "query_filter (optional per-evaluator filter string), "
                "column_mappings (optional dict remapping column names)."
            ),
        ),
    ],
    project: Annotated[
        str | None,
        typer.Option(
            "--project",
            help="Project name or ID; mutually exclusive with --dataset",
        ),
    ] = None,
    space: Annotated[
        str | None,
        typer.Option(
            "--space",
            "-s",
            help="Space name or ID (required when using a project name)",
        ),
    ] = None,
    dataset: Annotated[
        str | None,
        typer.Option(
            "--dataset",
            help="Dataset name or ID; mutually exclusive with --project",
        ),
    ] = None,
    experiment_ids: Annotated[
        str | None,
        typer.Option(
            "--experiment-ids",
            help="Comma-separated experiment global IDs (required for dataset-based tasks)",
        ),
    ] = None,
    sampling_rate: Annotated[
        float | None,
        typer.Option(
            "--sampling-rate",
            help="Fraction of data to evaluate (0-1); project tasks only",
        ),
    ] = None,
    is_continuous: Annotated[
        bool | None,
        typer.Option(
            "--is-continuous/--no-continuous",
            help="Run task continuously on incoming data",
        ),
    ] = None,
    query_filter: Annotated[
        str | None,
        typer.Option(
            "--query-filter",
            help="Task-level query filter applied to all evaluators",
        ),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Create a new evaluation task."""
    setup_logging(verbose)

    if project is None and dataset is None:
        raise UsageError("One of --project or --dataset must be provided")
    if project is not None and dataset is not None:
        raise UsageError("--project and --dataset are mutually exclusive")
    if sampling_rate is not None and not (0.0 <= sampling_rate <= 1.0):
        raise UsageError("--sampling-rate must be between 0.0 and 1.0")

    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    parsed_evaluators = _build_evaluators(load_json(evaluators))

    try:
        with spinner("Creating task", success_msg="Task created successfully"):
            task = client.tasks.create(
                name=name,
                task_type=task_type,
                evaluators=parsed_evaluators,
                project=project,
                dataset=dataset,
                space=space,
                experiment_ids=_parse_experiment_ids(experiment_ids),
                sampling_rate=sampling_rate,
                is_continuous=is_continuous,
                query_filter=query_filter,
            )
    except Exception as e:
        raise APIError(f"Failed to create task: {e}") from e
    else:
        output_data(task, format_type=output_format, output_file=output_file)


@app.command("update")
@handle_errors
def update_task(
    task: Annotated[str, typer.Argument(help="Task name or ID")],
    space: Annotated[
        str | None,
        typer.Option(
            "--space",
            "-s",
            help="Space name or ID (required when resolving task by name)",
        ),
    ] = None,
    new_name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="New task display name"),
    ] = None,
    sampling_rate: Annotated[
        float | None,
        typer.Option(
            "--sampling-rate",
            help="Sampling rate between 0 and 1 (project tasks only)",
        ),
    ] = None,
    is_continuous: Annotated[
        bool | None,
        typer.Option(
            "--is-continuous/--no-continuous",
            help="Whether the task runs continuously (project tasks only)",
        ),
    ] = None,
    query_filter: Annotated[
        str | None,
        typer.Option(
            "--query-filter",
            help=(
                "Task-level query filter. Pass an empty string with "
                '`--query-filter ""` to clear the existing filter.'
            ),
        ),
    ] = None,
    evaluators: Annotated[
        str | None,
        typer.Option(
            "--evaluators",
            help=(
                "JSON array replacing the full evaluator list. Same shape as "
                "`ax tasks create --evaluators`. Find IDs with `ax evaluators list`."
            ),
        ),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Update mutable fields on an evaluation task."""
    setup_logging(verbose)

    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    update_kwargs: dict[str, Any] = {"task": task}
    if space is not None:
        update_kwargs["space"] = space

    has_field = False
    if new_name is not None:
        update_kwargs["name"] = new_name
        has_field = True
    if sampling_rate is not None:
        if not (0.0 <= sampling_rate <= 1.0):
            raise UsageError("--sampling-rate must be between 0.0 and 1.0")
        update_kwargs["sampling_rate"] = sampling_rate
        has_field = True
    if is_continuous is not None:
        update_kwargs["is_continuous"] = is_continuous
        has_field = True
    if query_filter is not None:
        update_kwargs["query_filter"] = (
            None if query_filter == "" else query_filter
        )
        has_field = True
    if evaluators is not None:
        update_kwargs["evaluators"] = _build_evaluators(load_json(evaluators))
        has_field = True

    if not has_field:
        raise UsageError(
            "Provide at least one field to update (see --help for available options).",
        )

    try:
        with spinner("Updating task", success_msg="Task updated"):
            updated = client.tasks.update(**update_kwargs)
    except Exception as e:
        raise APIError(f"Failed to update task: {e}") from e
    else:
        output_data(updated, format_type=output_format, output_file=output_file)


@app.command("delete")
@handle_errors
def delete_task(
    task: Annotated[str, typer.Argument(help="Task name or ID")],
    space: Annotated[
        str | None,
        typer.Option(
            "--space",
            "-s",
            help="Space name or ID (required when resolving task by name)",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Delete an evaluation task (irreversible)."""
    setup_logging(verbose)

    if not force:
        warning("This will permanently delete the task and its configuration")
        if not confirm("Are you sure?", default=False):
            info("Task not deleted")
            raise typer.Exit()

    client, _ = make_client()

    try:
        with spinner("Deleting task", success_msg="Task deleted"):
            client.tasks.delete(task=task, space=space)
    except Exception as e:
        raise APIError(f"Failed to delete task: {e}") from e


# ---------------------------------------------------------------------------
# Task run commands
# ---------------------------------------------------------------------------


@app.command("trigger-run")
@handle_errors
def trigger_run(
    task_id: Annotated[str, typer.Argument(help="Task name or ID")],
    data_start_time: Annotated[
        datetime | None,
        typer.Option(
            "--data-start-time",
            help="ISO 8601 start of the data window to evaluate",
        ),
    ] = None,
    data_end_time: Annotated[
        datetime | None,
        typer.Option(
            "--data-end-time",
            help="ISO 8601 end of the data window (defaults to now)",
        ),
    ] = None,
    max_spans: Annotated[
        int | None,
        typer.Option(
            "--max-spans",
            help="Maximum number of spans to process (default 10 000)",
        ),
    ] = None,
    override_evaluations: Annotated[
        bool | None,
        typer.Option(
            "--override-evaluations/--no-override-evaluations",
            help="Re-evaluate data that already has evaluation labels",
        ),
    ] = None,
    experiment_ids: Annotated[
        str | None,
        typer.Option(
            "--experiment-ids",
            help="Comma-separated experiment global IDs; dataset-based tasks only",
        ),
    ] = None,
    wait: Annotated[
        bool,
        typer.Option(
            "--wait", "-w", help="Wait for the run to reach a terminal state"
        ),
    ] = False,
    poll_interval: Annotated[
        float,
        typer.Option(
            "--poll-interval",
            help="Seconds between polling attempts (used with --wait)",
        ),
    ] = 5.0,
    timeout: Annotated[
        float,
        typer.Option(
            "--timeout", help="Maximum seconds to wait (used with --wait)"
        ),
    ] = 600.0,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Trigger an on-demand run for a task."""
    setup_logging(verbose)
    if not wait and (poll_interval != 5.0 or timeout != 600.0):
        warning("--poll-interval and --timeout have no effect without --wait")
    if experiment_ids and (
        data_start_time is not None or data_end_time is not None
    ):
        warning(
            "--data-start-time and --data-end-time are ignored when --experiment-ids is provided; "
            "experiment tasks fetch data directly from the experiment, not a time-based scan"
        )
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Triggering task run", success_msg="Task run triggered"):
            run = client.tasks.trigger_run(
                task=task_id,
                data_start_time=data_start_time,
                data_end_time=data_end_time,
                max_spans=max_spans,
                override_evaluations=override_evaluations,
                experiment_ids=_parse_experiment_ids(experiment_ids),
            )
    except Exception as e:
        raise APIError(f"Failed to trigger task run: {e}") from e

    if wait:
        try:
            with spinner("Waiting for task run to complete"):
                run = client.tasks.wait_for_run(
                    run_id=run.id,
                    poll_interval=poll_interval,
                    timeout=timeout,
                )
        except TimeoutError as e:
            msg = str(e)
            raise APIError(msg if msg else "Task run timed out") from e
        except Exception as e:
            raise APIError(f"Failed while waiting for task run: {e}") from e

    output_data(run, format_type=output_format, output_file=output_file)


@app.command("list-runs")
@handle_errors
def list_runs(
    task_id: Annotated[str, typer.Argument(help="Task name or ID")],
    status: Annotated[
        RunStatus | None,
        typer.Option(
            "--status",
            help="Filter by run status: pending, running, completed, failed, cancelled",
        ),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", "-l", help="Maximum number of runs to return"),
    ] = 15,
    cursor: Annotated[
        str | None,
        typer.Option(
            "--cursor",
            "-c",
            help="Pagination cursor for next page",
        ),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="Enable verbose logs",
        ),
    ] = False,
) -> None:
    """List runs for a task."""
    setup_logging(verbose)
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Fetching task runs"):
            response = client.tasks.list_runs(
                task=task_id,
                status=status,
                limit=limit,
                cursor=cursor,
            )
    except Exception as e:
        raise APIError(f"Failed to list task runs: {e}") from e
    else:
        output_data(
            response, format_type=output_format, output_file=output_file
        )


@app.command("get-run")
@handle_errors
def get_run(
    run_id: Annotated[str, typer.Argument(help="Task run global ID (base64)")],
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Get a task run by ID."""
    setup_logging(verbose)
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Fetching task run"):
            run = client.tasks.get_run(run_id=run_id)
    except Exception as e:
        raise APIError(f"Failed to get task run: {e}") from e
    else:
        output_data(run, format_type=output_format, output_file=output_file)


@app.command("cancel-run")
@handle_errors
def cancel_run(
    run_id: Annotated[str, typer.Argument(help="Task run global ID (base64)")],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Cancel a task run (only valid when pending or running)."""
    setup_logging(verbose)

    if not force:
        warning("This will cancel the task run")
        if not confirm("Are you sure?", default=False):
            info("Task run not cancelled")
            raise typer.Exit()

    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Cancelling task run", success_msg="Task run cancelled"):
            run = client.tasks.cancel_run(run_id=run_id)
    except Exception as e:
        raise APIError(f"Failed to cancel task run: {e}") from e
    else:
        output_data(run, format_type=output_format, output_file=output_file)


@app.command("wait-for-run")
@handle_errors
def wait_for_run(
    run_id: Annotated[str, typer.Argument(help="Task run global ID (base64)")],
    poll_interval: Annotated[
        float,
        typer.Option(
            "--poll-interval",
            help="Seconds between polling attempts (default 5)",
        ),
    ] = 5.0,
    timeout: Annotated[
        float,
        typer.Option("--timeout", help="Maximum seconds to wait (default 600)"),
    ] = 600.0,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Output format (table, json, csv, parquet) or file path",
        ),
    ] = "",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose logs"),
    ] = False,
) -> None:
    """Wait for a task run to reach a terminal state (completed, failed, or cancelled)."""
    setup_logging(verbose)
    client, config = make_client()

    output_format, output_file = parse_output_option(
        output if output else config.output.format
    )

    try:
        with spinner("Waiting for task run to complete"):
            run = client.tasks.wait_for_run(
                run_id=run_id,
                poll_interval=poll_interval,
                timeout=timeout,
            )
    except TimeoutError as e:
        msg = str(e)
        raise APIError(msg if msg else "Task run timed out") from e
    except Exception as e:
        raise APIError(f"Failed while waiting for task run: {e}") from e
    else:
        output_data(run, format_type=output_format, output_file=output_file)
