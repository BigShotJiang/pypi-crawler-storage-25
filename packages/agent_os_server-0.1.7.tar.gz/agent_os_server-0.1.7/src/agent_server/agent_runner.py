import logging
import uuid
from google.adk.runners import Runner
from ag_ui_adk import ADKAgent
from google.adk.agents import BaseAgent
from google.adk.agents.run_config import RunConfig, StreamingMode
from google.genai import types as genai_types
from ag_ui.core import RunAgentInput, UserMessage

from agent_server.service import Service
from agent_server.utils import ChatRequest


class AgentRunner(object):
    def __init__(self, agents_path: str, session_service_uri: str, memory_service_uri: str):
        self.agent_name = "AgentOS"
        self.app_name = f"{self.agent_name}_APP"

        self.agent = AgentRunner.load_adk_agents(agents_path=agents_path)
        self.session_service = Service.session_service(db_url=session_service_uri)
        self.memory_service = Service.memory_service(db_uri=memory_service_uri)
        self.agui_runner: ADKAgent | None = None
        self.adk_runner: Runner | None = None
        self.create_agent_runner()

    def create_agent_runner(self):
        if self.agent is None:
            raise ValueError("Failed load agents")

        self.agui_runner = ADKAgent(
            adk_agent=self.agent, app_name=self.app_name,
            session_service=self.session_service, memory_service=self.memory_service,
            use_thread_id_as_session_id=True,
            user_id_extractor=AgentRunner._extract_agui_user_id
        )
        self.adk_runner = Runner(
            agent=self.agent, app_name=self.app_name,
            session_service=self.session_service, memory_service=self.memory_service,
            auto_create_session=False,
        )

    @staticmethod
    def _extract_agui_user_id(input_data: RunAgentInput) -> str:
        forwarded_props = getattr(input_data, "forwarded_props", None) or {}
        return forwarded_props.get("user_id") or f"thread_user_{input_data.thread_id}"

    @staticmethod
    def load_adk_agents(agents_path: str) -> BaseAgent | None:
        """
        加载智能体配置
        :param agents_path:
        :return:
        """
        try:
            import sys
            sys.path.append(str(agents_path))
            from agents import root_agent
            return root_agent
        except Exception as e:
            logging.error(f"Failed to load agents {e}")
            return None

    def run(self, user_id: str, request: ChatRequest, use_adk_sse=True):
        if request.type == "adk":
            if use_adk_sse:
                return self.adk_runner.run_async(
                    user_id=user_id, session_id=request.session_id, new_message=genai_types.Content(
                        role="user", parts=[genai_types.Part(text=request.message)]
                    ),
                    run_config=RunConfig(streaming_mode=StreamingMode.SSE)
                )
            else:
                return self.adk_runner.run_async(
                    user_id=user_id, session_id=request.session_id, new_message=genai_types.Content(
                        role="user", parts=[genai_types.Part(text=request.message)]
                    )
                )
        elif request.type == "agui":
            input_data = RunAgentInput(
                thread_id=request.session_id,
                run_id=f"Run-{request.session_id}",
                messages=[
                    UserMessage(id=f"user-message-{uuid.uuid4().hex}", role="user", content=request.message)
                ],
                context=[],
                tools=[],
                state={},
                forwarded_props={"user_id": user_id}
            )
            return self.agui_runner.run(input=input_data)
        else:
            raise ValueError(f"Error runner type {request.type}")
