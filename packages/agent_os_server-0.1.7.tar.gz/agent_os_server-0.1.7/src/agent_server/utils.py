from pydantic import BaseModel
from dotenv import dotenv_values


class ServerConfig(BaseModel):
    # 智能体配置文件夹
    agents_path: str

    # session服务URI
    session_service_uri: str

    # memory服务URI
    memory_service_uri: str

    # 用户服务URI
    user_service_uri: str

    # trace service URI
    trace_service_uri: str

    # host
    host: str

    # port
    port: int


class ChatRequest(BaseModel):
    type: str = "adk"
    session_id: str
    message: str


class Utils:
    @staticmethod
    def safe_jsonable(value):
        if value is None:
            return None

        if hasattr(value, "model_dump"):
            try:
                return value.model_dump(mode="json")
            except Exception:
                pass

        if hasattr(value, "dict"):
            try:
                return value.dict()
            except Exception:
                pass

        if isinstance(value, (str, int, float, bool, list, dict)):
            return value

        return str(value)

    @staticmethod
    def load_envs(env_file: str) -> ServerConfig | None:
        config = dotenv_values(env_file)
        return ServerConfig(
            agents_path=config.get("AGENTS_PATH", ""),
            session_service_uri=config.get("SESSION_SERVICE_URI", ""),
            memory_service_uri=config.get("MEMORY_SERVICE_URI", ""),
            user_service_uri=config.get("USER_SERVICE_URI", ""),
            trace_service_uri=config.get("TRACE_SERVICE_URI", ""),
            host=config.get("HOST", "0.0.0.0"),
            port=int(config.get("PORT", "8000"))
        )
