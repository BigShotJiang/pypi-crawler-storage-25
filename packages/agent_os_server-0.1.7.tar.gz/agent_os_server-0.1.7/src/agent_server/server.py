import json
import sys
import uvicorn
import logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
from fastapi.responses import StreamingResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from fastapi import FastAPI, Request

from agent_server.utils import Utils, ServerConfig, ChatRequest
from agent_server.service import Service
from agent_server.agent_runner import AgentRunner


class UserWhitelistMiddleware(BaseHTTPMiddleware):
    ALLOWED_USERS = {"alice", "bob"}

    async def dispatch(self, request: Request, call_next):
        # 1. 可选：定义路由白名单，用于跳过验证的端点
        # 例如，一个公开的 /health 端点，无需用户验证
        if request.url.path in [
            "/api/v1/health",
            "/docs", "/openapi.json"
        ]:
            return await call_next(request)

        # 2. 提取并验证用户ID
        user_id = request.headers.get("X-User-Id")
        if not user_id:
            logging.warning(f"Access Denied: You SHOULD provide X-User-Id first. from {request.client.host}")
            return Response("Unauthorized: Missing user identity identifier", status_code=401)

        if user_id not in UserWhitelistMiddleware.ALLOWED_USERS:
            logging.warning(
                f"Access Denied: There is no user named '{user_id}' in whitelist. From {request.client.host}"
            )
            return Response(f"Access Denied: User '{user_id}' have no permission", status_code=403)

        # 3. 用户在白名单内，记录日志并继续处理请求
        logging.info(f"User '{user_id}' has passed verification in whitelist")
        return await call_next(request)


class Application:
    server_config: ServerConfig = Utils.load_envs(".server.env")
    runner = AgentRunner(
        agents_path=server_config.agents_path,
        session_service_uri=server_config.session_service_uri,
        memory_service_uri=server_config.memory_service_uri
    )

    api = FastAPI(title=f"{runner.agent_name} Server")
    api.add_middleware(UserWhitelistMiddleware)

    @staticmethod
    @api.get("/api/v1/reload", tags=["API"])
    async def reload():
        try:
            Application.runner = AgentRunner(
                agents_path=Application.server_config.agents_path,
                session_service_uri=Application.server_config.session_service_uri,
                memory_service_uri=Application.server_config.memory_service_uri
            )
        except Exception:
            logging.error("Failed to load agents")
            return {"code": 10000, "message": "Failed to load agents", "data": ""}

        return {"code": 0, "message": "", "data": "OK"}

    @staticmethod
    @api.get("/api/v1/session/create", tags=["API"])
    async def create_session(request: Request):
        try:
            user_id = request.headers.get("X-User-Id")
            session = await Service.ensure_session(
                session_service=Application.runner.session_service,
                app_name=Application.runner.app_name,
                user_id=user_id, session_id=None
            )
            return {"code": 0, "message": "", "data": {"user_id": user_id, "session_id": session.id}}

        except Exception as e:
            logging.exception(f"create_session failed {e}")
            return {"code": 10001, "message": "create_session failed", "data": ""}

    @staticmethod
    @api.get("/api/v1/session/{session_id}/state", tags=["API"])
    async def get_session_state(request: Request, session_id: str):
        try:
            user_id = request.headers.get("X-User-Id")
            session = await Application.runner.session_service.get_session(
                app_name=Application.runner.app_name,
                user_id=user_id, session_id=session_id,
            )
            if not session:
                logging.error("Session not found")
                return {"code": 10002, "message": "Session not found", "data": ""}

            return {"code": 0, "message": "", "data": {"state": Utils.safe_jsonable(session.state)}}

        except Exception as e:
            logging.exception(f"get_session_state failed {e}")
            return {"code": 10003, "message": "get session state failed", "data": ""}

    @staticmethod
    @api.get("/api/v1/session/{session_id}/event", tags=["API"])
    async def get_session_event(request: Request, session_id: str):
        try:
            user_id = request.headers.get("X-User-Id")
            session = await Application.runner.session_service.get_session(
                app_name=Application.runner.app_name,
                user_id=user_id, session_id=session_id,
            )
            if not session:
                logging.error("Session not found")
                return {"code": 10002, "message": "Session not found", "data": ""}

            return {"code": 0, "message": "", "data": {"events": Utils.safe_jsonable(session.events)}}

        except Exception as e:
            logging.exception(f"get_session_state failed {e}")
            return {"code": 10003, "message": "get session state failed", "data": ""}

    @staticmethod
    @api.get("/api/v1/health", tags=["API"])
    async def health_check():
        return {"code": 0, "message": "", "data": "OK"}

    @staticmethod
    @api.post("/api/v1/chat/completions", tags=["API"])
    async def chat_completion(request: Request):
        """"""
        user_id = request.headers.get("X-User-Id")
        data = ChatRequest.model_validate_json(await request.body())

        async def event_generator():
            async for event in Application.runner.run(user_id=user_id, request=data):
                yield json.dumps(Utils.safe_jsonable(event), ensure_ascii=False) + "\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")


def main():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
        stream=sys.stderr
    )
    uvicorn.run(Application.api, host=Application.server_config.host, port=Application.server_config.port)


if __name__ == '__main__':
    main()
