from google.adk.memory import InMemoryMemoryService, BaseMemoryService
from google.adk.sessions import DatabaseSessionService, InMemorySessionService, BaseSessionService
from google.adk.sessions import Session


class Service:
    @staticmethod
    def memory_service(db_uri: str) -> BaseMemoryService | None:
        """
        Memory服务
        """
        if db_uri is None:
            return None

        if db_uri == "":
            return InMemoryMemoryService()

        return InMemoryMemoryService()

    @staticmethod
    def session_service(db_url: str) -> BaseSessionService | None:
        """Session服务"""
        if db_url is None:
            return None

        if db_url == "":
            return InMemorySessionService()

        return DatabaseSessionService(db_url=db_url)

    @staticmethod
    async def ensure_session(
            session_service: BaseSessionService,
            app_name: str, user_id: str,
            session_id: str | None = None
    ) -> Session:
        if session_id:
            session = await session_service.get_session(
                app_name=app_name, user_id=user_id, session_id=session_id
            )
            if session:
                return session

            return await session_service.create_session(
                app_name=app_name, user_id=user_id, session_id=session_id,
                state={},
            )

        return await session_service.create_session(
            app_name=app_name, user_id=user_id, state={},
        )
