import importlib.metadata


APP_NAME = "zalando-kubectl"

KUBECTL_VERSION = "v1.35.3"
KUBECTL_SHA512 = {
    "linux": "93d3ecc0e796f5a79eb9236de738a87fe1a5c3753daed12e8195b276ac18ef86e131915e26c01baedf9b855307d9230bfdeda4fad801dbffc83d9f6284872abb",
    "darwin": "aa9bde5a8f0d6cc9941e4a405be0909a082d079afc23e6ff1109b174dd4f6e90ebd584e142ebf2d178bfed3c97d9f277d977d779c68b1406ae4271f90295d4ec",
}
STERN_VERSION = "1.30.0"
STERN_SHA256 = {
    "linux": "ea1bf1f1dddf1fd4b9971148582e88c637884ac1592dcba71838a6a42277708b",
    "darwin": "4eaf8f0d60924902a3dda1aaebb573a376137bb830f45703d7a0bd89e884494a",
}
KUBELOGIN_VERSION = "v1.36.0"
KUBELOGIN_SHA256 = {
    "linux": "a344f42be911dd681da8956234e37d8dd4edc48fd332d86c9de8d59d095d0eca",
    "darwin": "2dcb68f51c4efa91e09cf39ed31f34a6661fdb925357235f726994a718839bd3",
}
ZALANDO_AWS_CLI_VERSION = "1.2.0"
ZALANDO_AWS_CLI_SHA256 = {
    "linux": "846d233665d6c36f9da3cf5235cc64b4e419ad077ffbbd4c445700c18bcf3086",
    "darwin": "7930ec5e669163fbadbb4ea1e66e2e0a73f3ae4cf7afe142b1b7b81bc0f86f95",
}

APP_VERSION = "v" + importlib.metadata.version(APP_NAME)
