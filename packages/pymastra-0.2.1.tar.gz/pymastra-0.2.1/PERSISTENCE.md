# Pymastra Persistence Guide

This guide explains how to use persistent storage backends with Pymastra workflows.

## Storage Backends

Pymastra supports three storage backends for different use cases:

### 1. In-Memory Storage (Default)

Best for: Development, testing, single-process applications

```python
from pymastra import Workflow, MemoryStorage

storage = MemoryStorage()  # Default, doesn't require setup
workflow = Workflow(
    name="my_workflow",
    trigger_schema=Input,
    storage=storage,
)
```

**Pros:**
- ✅ Zero setup required
- ✅ Fastest performance
- ✅ Great for development

**Cons:**
- ❌ Data lost when process exits
- ❌ Not shared between processes
- ❌ Not suitable for production

---

### 2. SQLite Storage

Best for: Self-hosted deployments, small-to-medium scale

```python
from pymastra import Workflow, SQLiteStorage

# Requires: pip install pymastra[sqlite]

storage = SQLiteStorage(db_path="pymastra.db")
workflow = Workflow(
    name="my_workflow",
    trigger_schema=Input,
    storage=storage,
)
```

**Pros:**
- ✅ Persistent file-based storage
- ✅ No database server needed
- ✅ Great for self-hosted deployments
- ✅ Queryable storage
- ✅ Low operational overhead

**Cons:**
- ❌ Not suitable for high concurrency
- ❌ File-based (slower than in-memory)
- ❌ Limited to single machine

**Recommended for:**
- Self-hosted applications
- Small to medium deployments (< 1000 runs)
- Local development/testing with persistence
- Applications without external database

---

### 3. PostgreSQL Storage

Best for: Production, large-scale deployments

```python
from pymastra import Workflow, PostgresStorage

# Requires: pip install pymastra[postgres]

storage = PostgresStorage(
    dsn="postgresql://user:password@localhost/pymastra"
)
workflow = Workflow(
    name="my_workflow",
    trigger_schema=Input,
    storage=storage,
)
```

**Pros:**
- ✅ Highly scalable
- ✅ Multi-process/multi-server
- ✅ ACID compliance
- ✅ Advanced querying
- ✅ Built-in backup solutions

**Cons:**
- ❌ Requires database server
- ❌ More operational overhead
- ❌ Higher latency than in-memory

**Recommended for:**
- Production deployments
- High-concurrency scenarios
- Multi-server setups
- Large-scale applications

---

## SQLite Setup & Usage

### Installation

```bash
# Install with SQLite support
pip install pymastra[sqlite]

# Or install all optional dependencies
pip install pymastra[all]
```

### Quick Start

```python
from pymastra import Workflow, Step, SQLiteStorage

# Create storage
storage = SQLiteStorage(db_path="my_workflows.db")

# Create steps
step = Step(
    id="process",
    description="Process data",
    input_schema=InputSchema,
    output_schema=OutputSchema,
    execute=my_step_function,
)

# Build workflow with persistent storage
workflow = Workflow(
    name="my_workflow",
    trigger_schema=InputSchema,
    storage=storage,
)
workflow.step(step).commit()

# Execute - workflow state is saved to SQLite
run = await workflow.execute(input_data)

# Load workflow from database
loaded_run = await storage.load_run(run.run_id)
print(loaded_run.status)  # "suspended" or "completed"

# Resume workflow
if loaded_run.status == "suspended":
    final_run = await loaded_run.resume(human_approval)
```

### Querying Runs

```python
# List all suspended workflows
suspended = await storage.list_runs(status="suspended")

# List completed workflows
completed = await storage.list_runs(status="completed", limit=50)

# List runs for specific workflow
workflow_runs = await storage.list_runs(workflow_id="my_workflow")

# Count runs by status
total = await storage.count_runs()
suspended_count = await storage.count_runs(status="suspended")
```

### Database File Management

```bash
# Database is stored as a single file
ls -lh pymastra.db

# Backup the database
cp pymastra.db pymastra.db.backup

# Reset the database (deletes all runs)
rm pymastra.db
```

---

## Using with FastAPI Server

### Basic Setup

```python
from pymastra import SQLiteStorage, server, Workflow, Step

# Create storage
storage = SQLiteStorage(db_path="workflows.db")

# Create server with persistent storage
app_server = server.create_server(storage=storage)

# Register workflows
workflow = Workflow(...)
app_server.register_workflow("my_workflow", workflow)

app = app_server.get_app()
```

### Server with Dashboard

```python
# When using server_with_dashboard.py, simply pass storage:
app_server = server.create_server(storage=storage)

# All workflow runs will be saved to SQLite
# Dashboard can query and manage runs
```

### Example Server

```python
from pathlib import Path
from pymastra import SQLiteStorage, server

# Create data directory
Path("data").mkdir(exist_ok=True)

# Create storage
storage = SQLiteStorage(db_path="data/workflows.db")

# Create server
app_server = server.create_server(storage=storage)

# Add custom endpoints
@app.get("/api/stats")
async def stats():
    total = await storage.count_runs()
    suspended = await storage.count_runs(status="suspended")
    return {
        "total_runs": total,
        "suspended": suspended,
    }
```

---

## Best Practices

### 1. Use Appropriate Storage for Your Scale

| Scale | Storage | Reason |
|-------|---------|--------|
| Development | In-Memory | Fast, no setup |
| < 1000 runs | SQLite | Simple, no server needed |
| > 1000 runs | PostgreSQL | Scalable, reliable |

### 2. Database File Location

```python
from pathlib import Path

# Good: Store in project data directory
data_dir = Path("data")
data_dir.mkdir(exist_ok=True)
storage = SQLiteStorage(db_path=str(data_dir / "pymastra.db"))

# Good: Use environment variable for flexibility
import os
db_path = os.getenv("PYMASTRA_DB", "pymastra.db")
storage = SQLiteStorage(db_path=db_path)

# Avoid: Hardcoded root directory
storage = SQLiteStorage(db_path="/pymastra.db")  # Don't do this
```

### 3. Backup Strategy

```bash
#!/bin/bash
# Daily backup script
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
cp pymastra.db "backups/pymastra_$TIMESTAMP.db"

# Keep last 30 days of backups
find backups -name "pymastra_*.db" -mtime +30 -delete
```

### 4. Handling Large Workflows

```python
# For high-volume workflows, periodically archive old runs
async def archive_old_runs():
    # List completed runs older than 30 days
    old_runs = await storage.list_runs(status="completed", limit=1000)

    for run in old_runs:
        # Archive to separate database or backup
        # Then delete from active storage
        await storage.delete_run(run.run_id)
```

### 5. Connection Pooling (PostgreSQL)

```python
from pymastra import PostgresStorage

# PostgreSQL automatically uses connection pooling
storage = PostgresStorage(
    dsn="postgresql://user:password@localhost/pymastra"
)

# Connection pool is created on first use
# Reused for subsequent queries
```

### 6. Monitoring & Logging

```python
import asyncio
from pymastra import SQLiteStorage

async def monitor_storage():
    storage = SQLiteStorage(db_path="pymastra.db")

    while True:
        total = await storage.count_runs()
        suspended = await storage.count_runs(status="suspended")
        completed = await storage.count_runs(status="completed")

        print(f"Runs - Total: {total}, Suspended: {suspended}, Completed: {completed}")

        await asyncio.sleep(60)  # Check every minute
```

---

## Troubleshooting

### "Database is locked"

**Cause:** Multiple processes accessing the same SQLite file

**Solution:**
- Use PostgreSQL for multi-process deployments
- Or ensure only one process accesses the database

```python
# ✗ Wrong - multiple processes
for i in range(10):
    asyncio.run(workflow.execute(data))  # Each creates new event loop

# ✓ Correct - single event loop, single storage
async def main():
    for i in range(10):
        await workflow.execute(data)  # Reuses connection

asyncio.run(main())
```

### "No such table: workflow_runs"

**Cause:** Database file is corrupted or from old version

**Solution:**
```python
# Recreate the database
import os
os.remove("pymastra.db")

# Storage will recreate on next run
storage = SQLiteStorage(db_path="pymastra.db")
```

### Memory Usage Growing

**Cause:** Too many runs kept in memory (if using MemoryStorage)

**Solution:**
```python
# Switch to SQLite
from pymastra import SQLiteStorage

storage = SQLiteStorage()
# Runs are stored on disk, not in memory
```

---

## Performance Tuning

### SQLite Configuration

```python
from pymastra import SQLiteStorage

class OptimizedSQLiteStorage(SQLiteStorage):
    async def _ensure_table(self):
        await super()._ensure_table()

        # Enable performance optimizations
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA journal_mode=WAL")  # Write-ahead logging
            await db.execute("PRAGMA synchronous=NORMAL")  # Faster writes
            await db.execute("PRAGMA cache_size=10000")  # Larger cache
            await db.commit()
```

### PostgreSQL Connection Pooling

```python
from pymastra import PostgresStorage

# PostgreSQL with optimized settings
storage = PostgresStorage(
    dsn="postgresql://user:password@localhost/pymastra"
)

# Connection pooling happens automatically
# Default: 10-20 connections
```

---

## Migration Guide

### From In-Memory to SQLite

```python
# Old code
from pymastra import Workflow, MemoryStorage

storage = MemoryStorage()

# New code
from pymastra import Workflow, SQLiteStorage

storage = SQLiteStorage(db_path="pymastra.db")

# No other changes needed!
workflow = Workflow(..., storage=storage)
```

### From SQLite to PostgreSQL

```python
# Old code
from pymastra import SQLiteStorage

storage = SQLiteStorage(db_path="pymastra.db")

# New code
from pymastra import PostgresStorage

storage = PostgresStorage(
    dsn="postgresql://user:password@localhost/pymastra"
)

# Tables are created automatically on first use
# No migration script needed
```

---

## Example: Complete Self-Hosted Setup

```python
import os
from pathlib import Path
from pymastra import Workflow, SQLiteStorage, server

# Setup
Path("data").mkdir(exist_ok=True)

# Database configuration from environment
db_path = os.getenv("PYMASTRA_DB", "data/pymastra.db")
storage = SQLiteStorage(db_path=db_path)

# Create server
app_server = server.create_server(storage=storage)

# Register workflows
app_server.register_workflow("workflow_1", workflow1)
app_server.register_workflow("workflow_2", workflow2)

# Get FastAPI app
app = app_server.get_app()

# In production:
# uvicorn main:app --host 0.0.0.0 --port 8000
```

---

## Resources

- [SQLite Documentation](https://www.sqlite.org/docs.html)
- [aiosqlite](https://github.com/omnilib/aiosqlite)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [asyncpg](https://github.com/MagicStack/asyncpg)
