# Code of Conduct

## Our Pledge

We are committed to providing a welcoming and inspiring community for all.
People of all backgrounds and identities are welcomed and valued in this community.

## Our Standards

Examples of behavior that contributes to creating a positive environment include:

- Using welcoming and inclusive language
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members
- Being patient and understanding

Examples of unacceptable behavior include:

- Harassment of any kind
- Discriminatory jokes and language
- Posting sexually explicit or violent material
- Posting (or threatening to post) others' personally identifying information
- Personal attacks
- Unwelcome sexual attention
- Trolling or insulting/derogatory comments

## Enforcement

Project maintainers are responsible for clarifying and enforcing our standards of
acceptable behavior and will take appropriate and fair corrective action in response
to any behavior that they deem inappropriate, threatening, offensive, or harmful.

Project maintainers have the right and responsibility to remove, edit, or reject:

- Comments, commits, code, wiki edits, issues, and other contributions that are
  not aligned with this Code of Conduct
- Comments and other contributions from individuals who are not following this Code
  of Conduct

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org),
version 2.0, available at https://www.contributor-covenant.org/version/2/0/code_of_conduct.html.

## Questions?

If you have questions about this Code of Conduct, please open an issue.
