# Deployment Guide

Production deployment of Pymastra workflows with security best practices.

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Security Setup](#security-setup)
5. [Database Setup](#database-setup)
6. [Running the Server](#running-the-server)
7. [Docker Deployment](#docker-deployment)
8. [Monitoring](#monitoring)
9. [Troubleshooting](#troubleshooting)

## System Requirements

- **Python**: 3.11 or 3.12
- **OS**: Linux (recommended), macOS, or Windows
- **Memory**: 512MB minimum, 2GB+ recommended
- **Storage**: Depends on workflow runs, SQLite: ~1MB per 1000 runs
- **Database**: SQLite (default) or PostgreSQL (production)

## Installation

### 1. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 2. Install Pymastra

```bash
# For production server
pip install pymastra[server,postgres]

# Or all features
pip install pymastra[all]
```

### 3. Verify Installation

```bash
python3 -c "from pymastra import Workflow; print('Pymastra installed successfully')"
```

## Configuration

### Environment Variables

Create a `.env` file (never commit to git):

```bash
# API Security
PYMASTRA_API_KEY=your-secret-api-key-here

# Database (SQLite or PostgreSQL)
DATABASE_URL=sqlite:///workflows.db
# OR for PostgreSQL:
# DATABASE_URL=postgresql://user:password@localhost/pymastra

# Webhook secrets
WEBHOOK_SECRET=your-webhook-secret

# Server configuration
PYMASTRA_DEBUG=false
PYMASTRA_HOST=0.0.0.0
PYMASTRA_PORT=8000

# Optional: CORS allowed origins (comma-separated)
CORS_ORIGINS=https://yourdomain.com,https://app.yourdomain.com

# Optional: External service keys
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key
```

### Load Environment Variables

```bash
# Before running the server
source .env

# Or in Python
from dotenv import load_dotenv
load_dotenv()
```

## Security Setup

### 1. API Key Configuration

```python
import os
from pymastra.server import WorkflowServer

# Load from environment (never hardcode)
api_key = os.environ.get("PYMASTRA_API_KEY")
if not api_key:
    raise ValueError("PYMASTRA_API_KEY must be set in production")

# Create server with authentication
server = WorkflowServer(
    auth_enabled=True,
    api_key=api_key,
    rate_limit=100,  # requests per minute
    debug=False,  # Never True in production
)
```

### 2. API Client Configuration

All requests to the server must include the API key:

```bash
# Using curl with Bearer token
curl -H "Authorization: Bearer ${PYMASTRA_API_KEY}" \
     https://your-server.com/api/runs

# Using Python
import httpx

client = httpx.Client(
    headers={"Authorization": f"Bearer {api_key}"}
)
response = client.get("https://your-server.com/api/runs")
```

### 3. CORS Configuration

For browser-based access, configure allowed origins:

```python
server = WorkflowServer(
    cors_origins=[
        "https://yourdomain.com",
        "https://app.yourdomain.com",
    ]
)
```

### 4. Webhook Security

Always use HTTPS for webhooks and validate signatures:

```python
from pymastra import Webhook, EventType

webhook = Webhook(
    id="slack-notifications",
    url="https://hooks.slack.com/services/YOUR/WEBHOOK",
    events=[EventType.WORKFLOW_COMPLETED],
    secret=os.environ.get("WEBHOOK_SECRET"),  # IMPORTANT: Use secret
    headers={
        "X-Custom-Auth": os.environ.get("CUSTOM_AUTH_TOKEN"),
    }
)
```

Webhook payload validation (on receiving end):

```python
import hmac
import hashlib

def verify_webhook(request_body: str, signature: str, secret: str) -> bool:
    expected = hmac.new(
        secret.encode(),
        request_body.encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected}", signature)
```

## Database Setup

### SQLite (Development/Small Scale)

```python
from pymastra.storage import SQLiteStorage

storage = SQLiteStorage(path="./workflows.db")
server = WorkflowServer(storage=storage)
```

**Permissions**: Set restrictive file permissions:

```bash
chmod 600 workflows.db
```

### PostgreSQL (Production)

1. **Create database and user**:

```sql
CREATE DATABASE pymastra;
CREATE USER pymastra_user WITH PASSWORD 'strong-password-here';
GRANT ALL PRIVILEGES ON DATABASE pymastra TO pymastra_user;
```

2. **Configure connection**:

```python
import os
from pymastra.storage import PostgresStorage

storage = PostgresStorage(
    url=os.environ.get("DATABASE_URL")
)
server = WorkflowServer(storage=storage)
```

3. **Connection pooling**:

The PostgresStorage uses connection pooling with sensible defaults:
- Min connections: 5
- Max connections: 20
- Connection timeout: 30s

### Database Backup

SQLite:
```bash
# Simple file copy
cp workflows.db workflows.db.backup

# Or using sqlite3
sqlite3 workflows.db ".backup workflows.db.backup"
```

PostgreSQL:
```bash
pg_dump pymastra > backup.sql
# Restore: psql pymastra < backup.sql
```

## Running the Server

### Basic Startup

```python
# server.py
import os
import asyncio
from pymastra.server import WorkflowServer
from pymastra.storage import SQLiteStorage

async def main():
    # Setup storage
    storage = SQLiteStorage(path="./data/workflows.db")

    # Create server with security
    server = WorkflowServer(
        storage=storage,
        auth_enabled=True,
        api_key=os.environ.get("PYMASTRA_API_KEY"),
        rate_limit=100,
        cors_origins=os.environ.get("CORS_ORIGINS", "").split(","),
        debug=os.environ.get("PYMASTRA_DEBUG", "false").lower() == "true",
    )

    # Get the FastAPI app
    app = server.get_app()

    # Run with uvicorn
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

if __name__ == "__main__":
    asyncio.run(main())
```

Start the server:

```bash
python3 server.py
```

Or with uvicorn directly:

```bash
uvicorn server:app --host 0.0.0.0 --port 8000 --workers 4
```

### Production Startup

Use a process manager like systemd or supervisor:

```ini
# /etc/systemd/system/pymastra.service
[Unit]
Description=Pymastra Workflow Server
After=network.target postgresql.service

[Service]
Type=notify
User=pymastra
WorkingDirectory=/opt/pymastra
EnvironmentFile=/opt/pymastra/.env
ExecStart=/opt/pymastra/venv/bin/python3 /opt/pymastra/server.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl enable pymastra
sudo systemctl start pymastra
sudo systemctl status pymastra
```

## Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.12-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y postgresql-client && rm -rf /var/lib/apt/lists/*

# Copy and install requirements
COPY pyproject.toml .
RUN pip install --no-cache-dir ".[server,postgres]"

# Copy application
COPY . .

# Create non-root user
RUN useradd -m -u 1000 pymastra && chown -R pymastra:pymastra /app
USER pymastra

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python -c "import httpx; httpx.get('http://localhost:8000/health')"

EXPOSE 8000
CMD ["python3", "server.py"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: pymastra
      POSTGRES_USER: pymastra_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - db_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U pymastra_user"]
      interval: 10s
      timeout: 5s
      retries: 5

  server:
    build: .
    environment:
      DATABASE_URL: postgresql://pymastra_user:${DB_PASSWORD}@db/pymastra
      PYMASTRA_API_KEY: ${PYMASTRA_API_KEY}
      CORS_ORIGINS: ${CORS_ORIGINS}
      PYMASTRA_DEBUG: "false"
    ports:
      - "8000:8000"
    depends_on:
      db:
        condition: service_healthy
    restart: unless-stopped

volumes:
  db_data:
```

Run with Docker Compose:

```bash
export PYMASTRA_API_KEY=your-secret-key
export DB_PASSWORD=your-db-password
export CORS_ORIGINS=https://yourdomain.com

docker-compose up -d
```

## Monitoring

### Health Check Endpoint

```bash
curl https://your-server.com/health
# Response: {"status": "healthy"}
```

### Prometheus Metrics

Add metrics collection to your server:

```python
from pymastra import get_metrics

metrics = get_metrics()
print(f"Completed runs: {metrics.completed_count}")
print(f"Failed runs: {metrics.failed_count}")
print(f"Average execution time: {metrics.avg_execution_time_ms}ms")
```

### Logging

Enable structured logging:

```python
import logging
import json

logging.basicConfig(
    level=logging.INFO,
    format='%(message)s'
)

# Logs will include workflow execution events
```

### Alerting

Set up alerts for:
- High error rates (> 5% failures)
- Slow execution (> 5s average)
- Database errors
- Webhook delivery failures

## Troubleshooting

### Common Issues

**Issue**: "PYMASTRA_API_KEY not set"
- **Solution**: Set the environment variable before running
  ```bash
  export PYMASTRA_API_KEY=your-key
  python3 server.py
  ```

**Issue**: "Permission denied" on database file
- **Solution**: Set correct permissions
  ```bash
  chmod 600 workflows.db
  chmod 755 $(dirname workflows.db)
  ```

**Issue**: PostgreSQL connection failed
- **Solution**: Verify connection string
  ```bash
  psql $DATABASE_URL -c "SELECT 1;"
  ```

**Issue**: High memory usage
- **Solution**:
  - Enable connection pooling (PostgreSQL)
  - Increase rate limiting
  - Archive old workflow runs

### Performance Tuning

1. **Database indexes**: Already configured for common queries
2. **Connection pooling**: Enabled by default for PostgreSQL
3. **Rate limiting**: Adjust based on server capacity
4. **Worker processes**: Use multiple uvicorn workers

## Security Checklist

- [ ] API key configured and stored in environment (not git)
- [ ] Database password uses strong random value
- [ ] HTTPS enabled (use reverse proxy like nginx)
- [ ] API key rotated regularly (every 90 days)
- [ ] Database backups automated
- [ ] Error messages sanitized (debug=False)
- [ ] CORS origins restricted to your domains
- [ ] Webhook secrets configured
- [ ] Database access restricted to application
- [ ] Server logs monitored for errors
- [ ] Dependency versions pinned in production
- [ ] Security patches applied promptly

## Getting Help

- **Documentation**: See [README.md](README.md) and other guides
- **Issues**: Report on GitHub issues tracker
- **Security**: See [SECURITY.md](SECURITY.md)
