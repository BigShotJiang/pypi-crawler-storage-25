"""Tests for pymastra.storage.sqlite — SQLiteStorage backend."""

import os
import tempfile

import pytest

from pymastra.storage.base import WorkflowRunState
from pymastra.storage.sqlite import SQLiteStorage


@pytest.fixture
async def storage(tmp_path):
    db_path = str(tmp_path / "test.db")
    s = SQLiteStorage(db_path=db_path)
    yield s


def _make_state(
    run_id: str = "run_1",
    workflow_id: str = "wf_1",
    status: str = "running",
    outputs: dict | None = None,
    suspend_payload: dict | None = None,
    suspended_at_step: str | None = None,
) -> WorkflowRunState:
    return WorkflowRunState(
        run_id=run_id,
        workflow_id=workflow_id,
        status=status,
        outputs=outputs or {},
        suspend_payload=suspend_payload,
        suspended_at_step=suspended_at_step,
    )


class TestSQLiteStorageSaveAndLoad:
    async def test_save_and_load(self, storage: SQLiteStorage) -> None:
        state = _make_state()
        await storage.save_run(state)
        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.run_id == "run_1"
        assert loaded.workflow_id == "wf_1"
        assert loaded.status == "running"

    async def test_load_nonexistent(self, storage: SQLiteStorage) -> None:
        result = await storage.load_run("does_not_exist")
        assert result is None

    async def test_save_with_outputs(self, storage: SQLiteStorage) -> None:
        state = _make_state(outputs={"step_1": {"result": "ok", "score": 0.9}})
        await storage.save_run(state)
        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.outputs == {"step_1": {"result": "ok", "score": 0.9}}

    async def test_save_with_suspension(self, storage: SQLiteStorage) -> None:
        state = _make_state(
            status="suspended",
            suspend_payload={"question": "approve?"},
            suspended_at_step="review",
        )
        await storage.save_run(state)
        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.status == "suspended"
        assert loaded.suspend_payload == {"question": "approve?"}
        assert loaded.suspended_at_step == "review"


class TestSQLiteStorageUpdate:
    async def test_update_via_save(self, storage: SQLiteStorage) -> None:
        state = _make_state(status="running")
        await storage.save_run(state)

        state.status = "completed"
        state.outputs = {"step_1": {"done": True}}
        await storage.update_run(state)

        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.status == "completed"
        assert loaded.outputs == {"step_1": {"done": True}}


class TestSQLiteStorageDelete:
    async def test_delete_run(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state())
        await storage.delete_run("run_1")
        assert await storage.load_run("run_1") is None

    async def test_delete_nonexistent(self, storage: SQLiteStorage) -> None:
        # Should not raise
        await storage.delete_run("nonexistent")


class TestSQLiteStorageListRuns:
    async def test_list_all(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state(run_id="r1", status="running"))
        await storage.save_run(_make_state(run_id="r2", status="completed"))
        await storage.save_run(_make_state(run_id="r3", status="failed"))

        runs = await storage.list_runs()
        assert len(runs) == 3

    async def test_list_by_status(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state(run_id="r1", status="running"))
        await storage.save_run(_make_state(run_id="r2", status="completed"))
        await storage.save_run(_make_state(run_id="r3", status="completed"))

        completed = await storage.list_runs(status="completed")
        assert len(completed) == 2
        assert all(r.status == "completed" for r in completed)

    async def test_list_by_workflow_id(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state(run_id="r1", workflow_id="wf_a"))
        await storage.save_run(_make_state(run_id="r2", workflow_id="wf_b"))
        await storage.save_run(_make_state(run_id="r3", workflow_id="wf_a"))

        wf_a_runs = await storage.list_runs(workflow_id="wf_a")
        assert len(wf_a_runs) == 2

    async def test_list_with_limit(self, storage: SQLiteStorage) -> None:
        for i in range(10):
            await storage.save_run(_make_state(run_id=f"r{i}"))

        runs = await storage.list_runs(limit=3)
        assert len(runs) == 3


class TestSQLiteStorageCountRuns:
    async def test_count_all(self, storage: SQLiteStorage) -> None:
        for i in range(5):
            await storage.save_run(_make_state(run_id=f"r{i}"))

        count = await storage.count_runs()
        assert count == 5

    async def test_count_by_status(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state(run_id="r1", status="running"))
        await storage.save_run(_make_state(run_id="r2", status="completed"))
        await storage.save_run(_make_state(run_id="r3", status="completed"))

        assert await storage.count_runs(status="completed") == 2
        assert await storage.count_runs(status="running") == 1
        assert await storage.count_runs(status="failed") == 0

    async def test_count_empty(self, storage: SQLiteStorage) -> None:
        assert await storage.count_runs() == 0


class TestSQLiteStorageTableCreation:
    async def test_table_created_on_first_use(self, storage: SQLiteStorage) -> None:
        assert storage._initialized is False
        await storage.save_run(_make_state())
        assert storage._initialized is True

    async def test_idempotent_table_creation(self, storage: SQLiteStorage) -> None:
        await storage.save_run(_make_state(run_id="r1"))
        await storage.save_run(_make_state(run_id="r2"))
        # Both operations should succeed without table creation error
        assert await storage.count_runs() == 2
