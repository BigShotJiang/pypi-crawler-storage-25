"""Tests for pymastra package — imports and version."""

import pymastra


class TestPackageImports:
    def test_version(self) -> None:
        assert pymastra.__version__ == "0.2.0"

    def test_core_classes_importable(self) -> None:
        assert pymastra.Step is not None
        assert pymastra.Workflow is not None
        assert pymastra.StepContext is not None
        assert pymastra.WorkflowRun is not None
        assert pymastra.RetryConfig is not None

    def test_error_classes_importable(self) -> None:
        assert pymastra.PymaestraError is not None
        assert pymastra.WorkflowValidationError is not None
        assert pymastra.StepExecutionError is not None
        assert pymastra.SuspendError is not None
        assert pymastra.ResumeError is not None
        assert pymastra.StorageError is not None

    def test_storage_classes_importable(self) -> None:
        assert pymastra.StorageBackend is not None
        assert pymastra.WorkflowRunState is not None
        assert pymastra.MemoryStorage is not None

    def test_tool_classes_importable(self) -> None:
        assert pymastra.Tool is not None
        assert pymastra.ToolRegistry is not None
        assert pymastra.tool is not None

    def test_llm_classes_importable(self) -> None:
        assert pymastra.LLMClient is not None
        assert pymastra.LLMConfig is not None
        assert pymastra.LLMChain is not None

    def test_observability_importable(self) -> None:
        assert pymastra.EventType is not None
        assert pymastra.Event is not None
        assert pymastra.Span is not None
        assert pymastra.Metrics is not None
        assert pymastra.EventLogger is not None
        assert pymastra.TraceContext is not None

    def test_debug_functions_importable(self) -> None:
        assert pymastra.format_run_summary is not None
        assert pymastra.format_step_context is not None
        assert pymastra.format_validation_error is not None
        assert pymastra.print_workflow_structure is not None

    def test_all_list_populated(self) -> None:
        assert len(pymastra.__all__) > 0
        # Spot check a few
        assert "Step" in pymastra.__all__
        assert "Workflow" in pymastra.__all__
        assert "Tool" in pymastra.__all__
