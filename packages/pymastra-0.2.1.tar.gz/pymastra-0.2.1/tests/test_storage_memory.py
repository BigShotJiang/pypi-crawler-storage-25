"""Tests for pymastra.storage.memory — MemoryStorage backend."""

import pytest

from pymastra.storage.base import WorkflowRunState
from pymastra.storage.memory import MemoryStorage


@pytest.fixture
def storage() -> MemoryStorage:
    return MemoryStorage()


def _make_state(
    run_id: str = "run_1",
    workflow_id: str = "wf_1",
    status: str = "running",
) -> WorkflowRunState:
    return WorkflowRunState(
        run_id=run_id,
        workflow_id=workflow_id,
        status=status,
        outputs={},
    )


class TestMemoryStorageSaveAndLoad:
    async def test_save_and_load(self, storage: MemoryStorage) -> None:
        state = _make_state()
        await storage.save_run(state)
        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.run_id == "run_1"
        assert loaded.status == "running"

    async def test_load_nonexistent(self, storage: MemoryStorage) -> None:
        result = await storage.load_run("does_not_exist")
        assert result is None

    async def test_save_overwrites(self, storage: MemoryStorage) -> None:
        state1 = _make_state(status="running")
        await storage.save_run(state1)

        state2 = _make_state(status="completed")
        await storage.save_run(state2)

        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.status == "completed"


class TestMemoryStorageUpdate:
    async def test_update_run(self, storage: MemoryStorage) -> None:
        state = _make_state()
        await storage.save_run(state)

        state.status = "completed"
        state.outputs = {"step_1": {"result": "ok"}}
        await storage.update_run(state)

        loaded = await storage.load_run("run_1")
        assert loaded is not None
        assert loaded.status == "completed"
        assert loaded.outputs == {"step_1": {"result": "ok"}}


class TestMemoryStorageDelete:
    async def test_delete_run(self, storage: MemoryStorage) -> None:
        state = _make_state()
        await storage.save_run(state)
        await storage.delete_run("run_1")
        assert await storage.load_run("run_1") is None

    async def test_delete_nonexistent_is_noop(self, storage: MemoryStorage) -> None:
        # Should not raise
        await storage.delete_run("does_not_exist")


class TestMemoryStorageMultipleRuns:
    async def test_multiple_runs_independent(self, storage: MemoryStorage) -> None:
        await storage.save_run(_make_state(run_id="r1", status="running"))
        await storage.save_run(_make_state(run_id="r2", status="completed"))

        r1 = await storage.load_run("r1")
        r2 = await storage.load_run("r2")
        assert r1 is not None and r1.status == "running"
        assert r2 is not None and r2.status == "completed"

    async def test_delete_one_preserves_others(self, storage: MemoryStorage) -> None:
        await storage.save_run(_make_state(run_id="r1"))
        await storage.save_run(_make_state(run_id="r2"))
        await storage.delete_run("r1")

        assert await storage.load_run("r1") is None
        assert await storage.load_run("r2") is not None


class TestWorkflowRunState:
    def test_state_defaults(self) -> None:
        state = WorkflowRunState(
            run_id="r1",
            workflow_id="wf1",
            status="running",
            outputs={},
        )
        assert state.suspend_payload is None
        assert state.suspended_at_step is None
        assert state.error is None

    def test_state_with_suspension(self) -> None:
        state = WorkflowRunState(
            run_id="r1",
            workflow_id="wf1",
            status="suspended",
            outputs={"step_1": {"val": 1}},
            suspend_payload={"question": "ok?"},
            suspended_at_step="step_2",
        )
        assert state.status == "suspended"
        assert state.suspend_payload == {"question": "ok?"}
        assert state.suspended_at_step == "step_2"
