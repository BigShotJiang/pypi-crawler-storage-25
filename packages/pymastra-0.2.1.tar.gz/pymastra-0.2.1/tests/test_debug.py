"""Tests for pymastra.debug — debugging utilities."""

import pytest

from pymastra.debug import (
    format_run_summary,
    format_step_context,
    format_validation_error,
    print_workflow_structure,
)
from pymastra.run import WorkflowRun
from pymastra.step import Step
from pymastra.retry import RetryConfig
from pymastra.workflow import Workflow

from tests.conftest import TriggerInput, StepOutput


class TestFormatRunSummary:
    def test_basic_summary(self) -> None:
        run = WorkflowRun(run_id="r1", status="completed")
        result = format_run_summary(run)
        assert "r1" in result
        assert "completed" in result
        assert "Outputs: 0 step(s)" in result

    def test_summary_with_outputs(self) -> None:
        run = WorkflowRun(
            run_id="r1",
            status="completed",
            outputs={"step_1": StepOutput(result="done")},
        )
        result = format_run_summary(run)
        assert "step_1" in result
        assert "1 step(s)" in result

    def test_summary_with_suspension(self) -> None:
        run = WorkflowRun(
            run_id="r1",
            status="suspended",
            suspended_at_step="review",
            suspend_payload={"question": "approve?"},
        )
        result = format_run_summary(run)
        assert "suspended" in result.lower() or "Suspended at: review" in result
        assert "question" in result

    def test_summary_formatting(self) -> None:
        run = WorkflowRun(run_id="r1", status="running")
        result = format_run_summary(run)
        assert result.startswith("╔")
        assert "╚" in result


class TestFormatStepContext:
    def test_basic_context(self) -> None:
        result = format_step_context("s1", {}, TriggerInput(text="hi"))
        assert "s1" in result
        assert "TriggerInput" in result
        assert "no previous outputs" in result

    def test_context_with_outputs(self) -> None:
        outputs = {"prev": StepOutput(result="ok")}
        result = format_step_context("s2", outputs, TriggerInput(text="hi"))
        assert "prev" in result
        assert "StepOutput" in result

    def test_formatting(self) -> None:
        result = format_step_context("s1", {}, TriggerInput(text="hi"))
        assert result.startswith("╔")
        assert "╚" in result


class TestFormatValidationError:
    def test_basic_error(self) -> None:
        result = format_validation_error(
            step_id="s1",
            schema_name="MySchema",
            error_details="field 'name' is required",
        )
        assert "s1" in result
        assert "MySchema" in result
        assert "name" in result

    def test_error_with_received_data(self) -> None:
        result = format_validation_error(
            step_id="s1",
            schema_name="MySchema",
            error_details="field missing",
            received_data={"wrong_key": "val"},
        )
        assert "wrong_key" in result
        assert "Received" in result

    def test_error_with_non_serializable_data(self) -> None:
        class NotSerializable:
            pass

        result = format_validation_error(
            step_id="s1",
            schema_name="MySchema",
            error_details="error",
            received_data=NotSerializable(),
        )
        assert "NotSerializable" in result

    def test_formatting(self) -> None:
        result = format_validation_error("s1", "Schema", "error")
        assert result.startswith("╔")
        assert "╚" in result


class TestPrintWorkflowStructure:
    def test_prints_workflow(self, capsys) -> None:
        async def fn(ctx):
            return StepOutput(result="ok")

        wf = Workflow(name="my_workflow", trigger_schema=TriggerInput)
        wf.step(
            Step(
                id="s1",
                description="First step",
                input_schema=TriggerInput,
                output_schema=StepOutput,
                execute=fn,
            )
        )
        wf.commit()

        print_workflow_structure(wf)
        captured = capsys.readouterr()
        assert "my_workflow" in captured.out
        assert "s1" in captured.out
        assert "First step" in captured.out

    def test_prints_retry_info(self, capsys) -> None:
        async def fn(ctx):
            return StepOutput(result="ok")

        wf = Workflow(name="wf", trigger_schema=TriggerInput)
        wf.step(
            Step(
                id="s1",
                description="Step with retry",
                input_schema=TriggerInput,
                output_schema=StepOutput,
                execute=fn,
                retry=RetryConfig(max_attempts=3, backoff="exponential"),
            )
        )
        wf.commit()

        print_workflow_structure(wf)
        captured = capsys.readouterr()
        assert "3 attempts" in captured.out
        assert "exponential" in captured.out

    def test_prints_branches(self, capsys) -> None:
        async def fn(ctx):
            return StepOutput(result="ok")

        wf = Workflow(name="wf", trigger_schema=TriggerInput)
        wf.step(Step(id="s1", description="d", input_schema=TriggerInput, output_schema=StepOutput, execute=fn))
        wf.step(Step(id="s2", description="d", input_schema=TriggerInput, output_schema=StepOutput, execute=fn))
        wf.branch("s1", lambda ctx: True, "s2")
        wf.commit()

        print_workflow_structure(wf)
        captured = capsys.readouterr()
        assert "s1" in captured.out
        assert "s2" in captured.out
        assert "conditional" in captured.out
