"""Tests for pymastra.workflow — Workflow execution engine."""

import pytest
from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.errors import (
    StepExecutionError,
    SuspendError,
    WorkflowValidationError,
)
from pymastra.retry import RetryConfig
from pymastra.step import Step
from pymastra.storage.memory import MemoryStorage
from pymastra.workflow import Workflow

from tests.conftest import TriggerInput, StepOutput


# ── Helpers ──────────────────────────────────────────────────────────


def _step(
    step_id: str,
    fn=None,
    retry: RetryConfig | None = None,
) -> Step:
    if fn is None:

        async def fn(ctx: StepContext) -> StepOutput:
            return StepOutput(result=f"{step_id}-done")

    return Step(
        id=step_id,
        description=f"Step {step_id}",
        input_schema=TriggerInput,
        output_schema=StepOutput,
        execute=fn,
        retry=retry,
    )


# ── Workflow construction ────────────────────────────────────────────


class TestWorkflowConstruction:
    def test_basic_init(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        assert wf.name == "test"
        assert wf.trigger_schema is TriggerInput
        assert wf.steps == []
        assert wf.branches == {}
        assert wf._committed is False

    def test_default_storage_is_memory(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        assert isinstance(wf.storage, MemoryStorage)

    def test_custom_storage(self) -> None:
        storage = MemoryStorage()
        wf = Workflow(name="test", trigger_schema=TriggerInput, storage=storage)
        assert wf.storage is storage

    def test_step_adds_step(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        s = _step("s1")
        result = wf.step(s)
        assert len(wf.steps) == 1
        assert wf.steps[0] is s
        assert result is wf  # chaining

    def test_then_is_alias_for_step(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        s = _step("s1")
        result = wf.then(s)
        assert len(wf.steps) == 1
        assert result is wf

    def test_chaining(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).then(_step("s2")).then(_step("s3"))
        assert len(wf.steps) == 3

    def test_branch(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).step(_step("s2")).step(_step("s3"))
        result = wf.branch("s1", lambda ctx: True, "s3")
        assert result is wf
        assert "s1" in wf.branches
        assert len(wf.branches["s1"]) == 1


# ── Workflow commit ──────────────────────────────────────────────────


class TestWorkflowCommit:
    def test_commit_sets_flag(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1"))
        wf.commit()
        assert wf._committed is True

    def test_commit_returns_self(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1"))
        result = wf.commit()
        assert result is wf

    def test_commit_rejects_duplicate_step_ids(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).step(_step("s1"))
        with pytest.raises(WorkflowValidationError, match="Duplicate step IDs"):
            wf.commit()

    def test_commit_rejects_invalid_branch_source(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).step(_step("s2"))
        wf.branch("nonexistent", lambda ctx: True, "s2")
        with pytest.raises(WorkflowValidationError, match="not found"):
            wf.commit()

    def test_commit_rejects_invalid_branch_destination(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).step(_step("s2"))
        wf.branch("s1", lambda ctx: True, "nonexistent")
        with pytest.raises(WorkflowValidationError, match="not found"):
            wf.commit()

    def test_commit_accepts_valid_branches(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).step(_step("s2")).step(_step("s3"))
        wf.branch("s1", lambda ctx: True, "s3")
        wf.commit()  # Should not raise


# ── Workflow execution ───────────────────────────────────────────────


class TestWorkflowExecution:
    async def test_execute_requires_commit(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1"))
        with pytest.raises(WorkflowValidationError, match="must be committed"):
            await wf.execute({"text": "hello", "value": 1})

    async def test_single_step_workflow(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).commit()

        run = await wf.execute({"text": "hi", "value": 1})
        assert run.status == "completed"
        assert "s1" in run.outputs

    async def test_multi_step_workflow(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).then(_step("s2")).then(_step("s3")).commit()

        run = await wf.execute({"text": "hi", "value": 1})
        assert run.status == "completed"
        assert len(run.outputs) == 3
        assert all(k in run.outputs for k in ["s1", "s2", "s3"])

    async def test_trigger_data_validation_with_dict(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).commit()

        run = await wf.execute({"text": "hello", "value": 5})
        assert run.status == "completed"

    async def test_trigger_data_validation_with_model(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).commit()

        trigger = TriggerInput(text="hello", value=5)
        run = await wf.execute(trigger)
        assert run.status == "completed"

    async def test_trigger_data_validation_failure(self) -> None:
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1")).commit()

        with pytest.raises(WorkflowValidationError, match="validation failed"):
            await wf.execute({"not_text": "oops"})

    async def test_step_receives_trigger_data(self) -> None:
        received = {}

        async def capture(ctx: StepContext) -> StepOutput:
            received["text"] = ctx.trigger_data.text
            received["value"] = ctx.trigger_data.value
            return StepOutput(result="ok")

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=capture)).commit()

        await wf.execute({"text": "hello", "value": 42})
        assert received["text"] == "hello"
        assert received["value"] == 42

    async def test_step_receives_previous_outputs(self) -> None:
        async def step1(ctx: StepContext) -> StepOutput:
            return StepOutput(result="first", score=1.0)

        async def step2(ctx: StepContext) -> StepOutput:
            prev = ctx.outputs["s1"]
            return StepOutput(result=f"after-{prev.result}", score=2.0)

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=step1)).then(_step("s2", fn=step2)).commit()

        run = await wf.execute({"text": "hi"})
        assert run.status == "completed"
        assert run.outputs["s2"].result == "after-first"

    async def test_step_failure_sets_failed_status(self) -> None:
        async def bad_step(ctx: StepContext) -> StepOutput:
            raise RuntimeError("step exploded")

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=bad_step)).commit()

        with pytest.raises(StepExecutionError, match="step exploded"):
            await wf.execute({"text": "hi"})

    async def test_run_saved_to_storage(self) -> None:
        storage = MemoryStorage()
        wf = Workflow(name="test", trigger_schema=TriggerInput, storage=storage)
        wf.step(_step("s1")).commit()

        run = await wf.execute({"text": "hi"})
        loaded = await storage.load_run(run.run_id)
        assert loaded is not None
        assert loaded.status == "completed"


# ── Branching ────────────────────────────────────────────────────────


class TestWorkflowBranching:
    async def test_branch_taken(self) -> None:
        """When condition is True, jump to target step."""
        call_order: list[str] = []

        async def track(step_id: str):
            async def fn(ctx: StepContext) -> StepOutput:
                call_order.append(step_id)
                return StepOutput(result=step_id)

            return fn

        s1_fn = await track("s1")
        s2_fn = await track("s2")
        s3_fn = await track("s3")

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=s1_fn))
        wf.step(_step("s2", fn=s2_fn))
        wf.step(_step("s3", fn=s3_fn))
        wf.branch("s1", lambda ctx: True, "s3")  # skip s2
        wf.commit()

        run = await wf.execute({"text": "hi"})
        assert run.status == "completed"
        assert "s1" in call_order
        assert "s3" in call_order
        assert "s2" not in call_order

    async def test_branch_not_taken(self) -> None:
        """When condition is False, follow sequential order."""
        call_order: list[str] = []

        async def track(step_id: str):
            async def fn(ctx: StepContext) -> StepOutput:
                call_order.append(step_id)
                return StepOutput(result=step_id)

            return fn

        s1_fn = await track("s1")
        s2_fn = await track("s2")
        s3_fn = await track("s3")

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=s1_fn))
        wf.step(_step("s2", fn=s2_fn))
        wf.step(_step("s3", fn=s3_fn))
        wf.branch("s1", lambda ctx: False, "s3")  # condition not met
        wf.commit()

        run = await wf.execute({"text": "hi"})
        assert run.status == "completed"
        # All steps should execute in order
        assert call_order == ["s1", "s2", "s3"]


# ── Retry ────────────────────────────────────────────────────────────


class TestWorkflowRetry:
    async def test_retry_on_failure(self) -> None:
        attempt_count = 0

        async def flaky_step(ctx: StepContext) -> StepOutput:
            nonlocal attempt_count
            attempt_count += 1
            if attempt_count < 3:
                raise ValueError("temporary error")
            return StepOutput(result="recovered")

        retry = RetryConfig(max_attempts=3, delay_seconds=0.01)
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=flaky_step, retry=retry)).commit()

        run = await wf.execute({"text": "hi"})
        assert run.status == "completed"
        assert attempt_count == 3

    async def test_retry_exhausted(self) -> None:
        async def always_fail(ctx: StepContext) -> StepOutput:
            raise ValueError("permanent error")

        retry = RetryConfig(max_attempts=2, delay_seconds=0.01)
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=always_fail, retry=retry)).commit()

        with pytest.raises(StepExecutionError, match="permanent error"):
            await wf.execute({"text": "hi"})

    async def test_no_retry_when_should_retry_returns_false(self) -> None:
        attempt_count = 0

        async def fail_step(ctx: StepContext) -> StepOutput:
            nonlocal attempt_count
            attempt_count += 1
            raise TypeError("not retryable")

        # Only retry on ValueError, but step raises TypeError
        retry = RetryConfig(max_attempts=3, delay_seconds=0.01, retry_on=[ValueError])
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=fail_step, retry=retry)).commit()

        with pytest.raises(StepExecutionError):
            await wf.execute({"text": "hi"})
        assert attempt_count == 1  # No retries


# ── Suspension ───────────────────────────────────────────────────────


class TestWorkflowSuspension:
    async def test_suspend_sets_status(self) -> None:
        async def suspending_step(ctx: StepContext) -> StepOutput:
            await ctx.suspend({"question": "approve?"})
            return StepOutput(result="never reached")

        wf = Workflow(name="test", trigger_schema=TriggerInput)
        wf.step(_step("s1", fn=suspending_step)).commit()

        run = await wf.execute({"text": "hi"})
        assert run.status == "suspended"
        assert run.suspended_at_step == "s1"

    async def test_suspend_saves_to_storage(self) -> None:
        storage = MemoryStorage()

        async def suspending_step(ctx: StepContext) -> StepOutput:
            await ctx.suspend({"question": "approve?"})
            return StepOutput(result="never reached")

        wf = Workflow(name="test", trigger_schema=TriggerInput, storage=storage)
        wf.step(_step("s1", fn=suspending_step)).commit()

        run = await wf.execute({"text": "hi"})
        loaded = await storage.load_run(run.run_id)
        assert loaded is not None
        assert loaded.status == "suspended"
