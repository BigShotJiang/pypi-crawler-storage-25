"""Tests for pymastra.context — StepContext."""

import pytest
from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.errors import SuspendError

from tests.conftest import TriggerInput, StepOutput


class TestStepContextInit:
    def test_basic_construction(self) -> None:
        trigger = TriggerInput(text="hi", value=1)
        ctx = StepContext(
            trigger_data=trigger,
            outputs={},
            step_id="s1",
            run_id="r1",
        )
        assert ctx.trigger_data == trigger
        assert ctx.outputs == {}
        assert ctx.step_id == "s1"
        assert ctx.run_id == "r1"
        assert ctx._suspend_fn is None

    def test_with_existing_outputs(self) -> None:
        outputs = {"prev_step": StepOutput(result="done", score=0.9)}
        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs=outputs,
            step_id="s2",
            run_id="r2",
        )
        assert "prev_step" in ctx.outputs
        assert ctx.outputs["prev_step"].result == "done"

    def test_with_suspend_fn(self) -> None:
        async def my_suspend(payload):
            return {}

        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs={},
            step_id="s1",
            run_id="r1",
            suspend_fn=my_suspend,
        )
        assert ctx._suspend_fn is my_suspend


class TestStepContextSuspend:
    async def test_suspend_raises_suspend_error(self) -> None:
        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs={},
            step_id="s1",
            run_id="r1",
        )
        with pytest.raises(SuspendError):
            await ctx.suspend({"question": "approve?"})

    async def test_suspend_payload_in_error(self) -> None:
        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs={},
            step_id="s1",
            run_id="r1",
        )
        payload = {"question": "approve?", "data": [1, 2, 3]}
        with pytest.raises(SuspendError) as exc_info:
            await ctx.suspend(payload)
        # SuspendError is called with payload as the message argument
        # so the string representation is the dict
        assert str(exc_info.value) == str(payload)
