"""Tests for pymastra.server — FastAPI workflow server."""

import pytest
from fastapi.testclient import TestClient
from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.server import WorkflowServer, create_server
from pymastra.step import Step
from pymastra.storage.memory import MemoryStorage
from pymastra.workflow import Workflow

from tests.conftest import TriggerInput, StepOutput


# ── Helpers ──────────────────────────────────────────────────────────


def _build_workflow(name: str = "test_wf") -> Workflow:
    async def process(ctx: StepContext) -> StepOutput:
        return StepOutput(result=f"processed-{ctx.trigger_data.text}")

    wf = Workflow(name=name, trigger_schema=TriggerInput)
    wf.step(
        Step(
            id="process",
            description="Process input",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=process,
        )
    ).commit()
    return wf


@pytest.fixture
def server() -> WorkflowServer:
    s = WorkflowServer(rate_limit=0)
    s.register_workflow("test_wf", _build_workflow())
    return s


@pytest.fixture
def client(server: WorkflowServer) -> TestClient:
    return TestClient(server.app)


# ── Server creation ──────────────────────────────────────────────────


class TestServerCreation:
    def test_create_server_factory(self) -> None:
        s = create_server()
        assert isinstance(s, WorkflowServer)

    def test_server_with_custom_storage(self) -> None:
        storage = MemoryStorage()
        s = WorkflowServer(storage=storage, rate_limit=0)
        assert s.storage is storage

    def test_server_auth_requires_key(self) -> None:
        with pytest.raises(ValueError, match="api_key"):
            WorkflowServer(auth_enabled=True, rate_limit=0)

    def test_server_auth_with_key(self) -> None:
        s = WorkflowServer(auth_enabled=True, api_key="test-key", rate_limit=0)
        assert s.api_key == "test-key"

    def test_register_uncommitted_workflow_fails(self) -> None:
        s = WorkflowServer(rate_limit=0)
        wf = Workflow(name="test", trigger_schema=TriggerInput)
        with pytest.raises(ValueError, match="committed"):
            s.register_workflow("test", wf)

    def test_get_app(self) -> None:
        s = WorkflowServer(rate_limit=0)
        app = s.get_app()
        assert app is s.app


# ── Health endpoint ──────────────────────────────────────────────────


class TestHealthEndpoint:
    def test_health_check(self, client: TestClient) -> None:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "healthy"}


# ── Workflow execution endpoint ──────────────────────────────────────


class TestExecuteEndpoint:
    def test_execute_workflow(self, client: TestClient) -> None:
        response = client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"text": "hello", "value": 1}},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "completed"
        assert body["run_id"]

    def test_execute_nonexistent_workflow(self, client: TestClient) -> None:
        response = client.post(
            "/workflows/execute",
            json={"workflow_id": "nonexistent", "data": {"text": "hi"}},
        )
        assert response.status_code == 404

    def test_execute_with_invalid_data(self, client: TestClient) -> None:
        response = client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"invalid_key": "nope"}},
        )
        assert response.status_code == 400


# ── Run status endpoint ──────────────────────────────────────────────


class TestRunEndpoints:
    def test_get_run_status(self, client: TestClient) -> None:
        # Execute first
        exec_resp = client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"text": "hello"}},
        )
        run_id = exec_resp.json()["run_id"]

        # Get status
        response = client.get(f"/runs/{run_id}")
        assert response.status_code == 200
        assert response.json()["status"] == "completed"

    def test_get_nonexistent_run(self, client: TestClient) -> None:
        response = client.get("/runs/nonexistent")
        assert response.status_code == 404

    def test_list_runs(self, client: TestClient) -> None:
        # Execute a workflow
        client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"text": "hello"}},
        )

        response = client.get("/api/runs")
        assert response.status_code == 200
        assert "runs" in response.json()
        assert len(response.json()["runs"]) >= 1


# ── Suspend payload endpoint ─────────────────────────────────────────


class TestSuspendPayloadEndpoint:
    def test_get_payload_non_suspended(self, client: TestClient) -> None:
        exec_resp = client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"text": "hello"}},
        )
        run_id = exec_resp.json()["run_id"]

        response = client.get(f"/runs/{run_id}/suspend_payload")
        assert response.status_code == 400
        assert "not suspended" in response.json()["detail"]

    def test_get_payload_nonexistent_run(self, client: TestClient) -> None:
        response = client.get("/runs/fake/suspend_payload")
        assert response.status_code == 404


# ── Resume endpoint ──────────────────────────────────────────────────


class TestResumeEndpoint:
    def test_resume_non_suspended_run(self, client: TestClient) -> None:
        exec_resp = client.post(
            "/workflows/execute",
            json={"workflow_id": "test_wf", "data": {"text": "hello"}},
        )
        run_id = exec_resp.json()["run_id"]

        response = client.post(
            f"/runs/{run_id}/resume",
            json={"human_input": {"approved": True}},
        )
        assert response.status_code == 400

    def test_resume_nonexistent_run(self, client: TestClient) -> None:
        response = client.post(
            "/runs/fake/resume",
            json={"human_input": {"approved": True}},
        )
        assert response.status_code == 404


# ── Authentication ───────────────────────────────────────────────────


class TestAuthentication:
    def test_auth_rejects_missing_key(self) -> None:
        s = WorkflowServer(auth_enabled=True, api_key="secret", rate_limit=0)
        s.register_workflow("test_wf", _build_workflow())
        client = TestClient(s.app)

        response = client.get("/api/runs")
        assert response.status_code == 401

    def test_auth_rejects_wrong_key(self) -> None:
        s = WorkflowServer(auth_enabled=True, api_key="secret", rate_limit=0)
        s.register_workflow("test_wf", _build_workflow())
        client = TestClient(s.app)

        response = client.get("/api/runs", headers={"Authorization": "wrong"})
        assert response.status_code == 401

    def test_auth_accepts_correct_key(self) -> None:
        s = WorkflowServer(auth_enabled=True, api_key="secret", rate_limit=0)
        s.register_workflow("test_wf", _build_workflow())
        client = TestClient(s.app)

        response = client.get("/api/runs", headers={"Authorization": "secret"})
        assert response.status_code == 200

    def test_auth_accepts_bearer_format(self) -> None:
        s = WorkflowServer(auth_enabled=True, api_key="secret", rate_limit=0)
        s.register_workflow("test_wf", _build_workflow())
        client = TestClient(s.app)

        response = client.get("/api/runs", headers={"Authorization": "Bearer secret"})
        assert response.status_code == 200
