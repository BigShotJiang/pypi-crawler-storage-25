"""Tests for pymastra.run — WorkflowRun."""

import pytest

from pymastra.errors import ResumeError
from pymastra.run import WorkflowRun
from pymastra.storage.base import WorkflowRunState
from pymastra.storage.memory import MemoryStorage


class TestWorkflowRunInit:
    def test_default_values(self) -> None:
        run = WorkflowRun()
        assert run.run_id  # auto-generated UUID
        assert run.status == "running"
        assert run.outputs == {}
        assert run.workflow is None
        assert run.storage is None
        assert run.suspend_payload is None
        assert run.suspended_at_step is None

    def test_custom_run_id(self) -> None:
        run = WorkflowRun(run_id="my-run-123")
        assert run.run_id == "my-run-123"

    def test_auto_generated_run_id_is_uuid(self) -> None:
        run = WorkflowRun()
        parts = run.run_id.split("-")
        assert len(parts) == 5  # UUID format

    def test_custom_values(self) -> None:
        run = WorkflowRun(
            run_id="r1",
            status="suspended",
            outputs={"step_1": {"val": 1}},
            suspend_payload={"q": "ok?"},
            suspended_at_step="step_2",
        )
        assert run.status == "suspended"
        assert run.outputs == {"step_1": {"val": 1}}
        assert run.suspend_payload == {"q": "ok?"}
        assert run.suspended_at_step == "step_2"


class TestWorkflowRunSave:
    async def test_save_to_storage(self) -> None:
        storage = MemoryStorage()
        run = WorkflowRun(run_id="r1", storage=storage, status="running")
        await run.save("test_wf")

        loaded = await storage.load_run("r1")
        assert loaded is not None
        assert loaded.workflow_id == "test_wf"
        assert loaded.status == "running"

    async def test_save_without_storage_is_noop(self) -> None:
        run = WorkflowRun(run_id="r1", storage=None)
        # Should not raise
        await run.save("test_wf")

    async def test_save_captures_all_state(self) -> None:
        storage = MemoryStorage()
        run = WorkflowRun(
            run_id="r1",
            storage=storage,
            status="suspended",
            outputs={"s1": {"data": "val"}},
            suspend_payload={"q": "approve?"},
            suspended_at_step="s2",
        )
        await run.save("my_wf")

        loaded = await storage.load_run("r1")
        assert loaded is not None
        assert loaded.status == "suspended"
        assert loaded.outputs == {"s1": {"data": "val"}}
        assert loaded.suspend_payload == {"q": "approve?"}
        assert loaded.suspended_at_step == "s2"


class TestWorkflowRunResume:
    async def test_resume_requires_suspended_status(self) -> None:
        run = WorkflowRun(status="completed")
        with pytest.raises(ResumeError, match="not 'suspended'"):
            await run.resume({"approved": True})

    async def test_resume_requires_suspended_at_step(self) -> None:
        run = WorkflowRun(status="suspended", suspended_at_step=None)
        with pytest.raises(ResumeError, match="suspension step information is missing"):
            await run.resume({"approved": True})

    async def test_resume_requires_workflow(self) -> None:
        run = WorkflowRun(
            status="suspended",
            suspended_at_step="review",
            workflow=None,
        )
        with pytest.raises(ResumeError, match="workflow object is not available"):
            await run.resume({"approved": True})

    async def test_resume_fails_on_running_status(self) -> None:
        run = WorkflowRun(status="running")
        with pytest.raises(ResumeError):
            await run.resume({})

    async def test_resume_fails_on_failed_status(self) -> None:
        run = WorkflowRun(status="failed")
        with pytest.raises(ResumeError):
            await run.resume({})
