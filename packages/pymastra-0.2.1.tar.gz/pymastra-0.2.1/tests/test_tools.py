"""Tests for pymastra.tools — Tool, ToolRegistry, @tool decorator."""

import pytest

from pymastra.tools import Tool, ToolRegistry, tool


# ── Helper functions ─────────────────────────────────────────────────


def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


def greet(name: str, greeting: str = "Hello") -> str:
    """Greet someone."""
    return f"{greeting}, {name}!"


async def async_multiply(x: int, y: int) -> int:
    """Multiply two numbers."""
    return x * y


# ── Tool tests ───────────────────────────────────────────────────────


class TestTool:
    def test_name_from_function(self) -> None:
        t = Tool(add)
        assert t.name == "add"

    def test_custom_name(self) -> None:
        t = Tool(add, name="my_add")
        assert t.name == "my_add"

    def test_description_from_docstring(self) -> None:
        t = Tool(add)
        assert t.description == "Add two numbers."

    def test_custom_description(self) -> None:
        t = Tool(add, description="Custom desc")
        assert t.description == "Custom desc"

    def test_input_schema_generated(self) -> None:
        t = Tool(add)
        schema = t.input_schema
        fields = schema.model_fields
        assert "a" in fields
        assert "b" in fields

    def test_input_schema_with_defaults(self) -> None:
        t = Tool(greet)
        schema = t.input_schema
        fields = schema.model_fields
        assert "name" in fields
        assert "greeting" in fields
        # greeting has a default
        assert fields["greeting"].default == "Hello"

    async def test_call_sync_function(self) -> None:
        t = Tool(add)
        result = await t.call(a=3, b=4)
        assert result == 7

    async def test_call_async_function(self) -> None:
        t = Tool(async_multiply)
        result = await t.call(x=5, y=6)
        assert result == 30

    async def test_call_with_defaults(self) -> None:
        t = Tool(greet)
        result = await t.call(name="World")
        assert result == "Hello, World!"

    async def test_call_override_default(self) -> None:
        t = Tool(greet)
        result = await t.call(name="World", greeting="Hi")
        assert result == "Hi, World!"

    def test_to_dict(self) -> None:
        t = Tool(add)
        d = t.to_dict()
        assert d["name"] == "add"
        assert d["description"] == "Add two numbers."
        assert "input_schema" in d
        assert d["input_schema"]["type"] == "object"
        assert "a" in d["input_schema"]["properties"]
        assert "b" in d["input_schema"]["properties"]

    async def test_call_validates_input(self) -> None:
        t = Tool(add)
        # Missing required arg
        with pytest.raises(Exception):
            await t.call(a=1)


# ── ToolRegistry tests ───────────────────────────────────────────────


class TestToolRegistry:
    def test_register_and_get(self) -> None:
        registry = ToolRegistry()
        t = Tool(add)
        registry.register(t)
        assert registry.get_tool("add") is t

    def test_get_nonexistent_returns_none(self) -> None:
        registry = ToolRegistry()
        assert registry.get_tool("nonexistent") is None

    def test_register_function(self) -> None:
        registry = ToolRegistry()
        t = registry.register_function(add, name="adder", description="Adds")
        assert isinstance(t, Tool)
        assert registry.get_tool("adder") is t
        assert t.description == "Adds"

    def test_list_tools(self) -> None:
        registry = ToolRegistry()
        registry.register(Tool(add))
        registry.register(Tool(greet))
        tools = registry.list_tools()
        assert len(tools) == 2
        names = {t["name"] for t in tools}
        assert names == {"add", "greet"}

    async def test_execute_tool(self) -> None:
        registry = ToolRegistry()
        registry.register(Tool(add))
        result = await registry.execute_tool("add", a=10, b=20)
        assert result == 30

    async def test_execute_tool_not_found(self) -> None:
        registry = ToolRegistry()
        with pytest.raises(ValueError, match="not found"):
            await registry.execute_tool("missing")

    async def test_execute_async_tool(self) -> None:
        registry = ToolRegistry()
        registry.register(Tool(async_multiply))
        result = await registry.execute_tool("async_multiply", x=3, y=7)
        assert result == 21


# ── @tool decorator tests ────────────────────────────────────────────


class TestToolDecorator:
    def test_decorator_without_args(self) -> None:
        @tool
        def my_func(x: int) -> int:
            """Double it."""
            return x * 2

        assert isinstance(my_func, Tool)
        assert my_func.name == "my_func"
        assert my_func.description == "Double it."

    def test_decorator_with_args(self) -> None:
        @tool(name="doubler", description="Doubles a number")
        def my_func(x: int) -> int:
            return x * 2

        assert isinstance(my_func, Tool)
        assert my_func.name == "doubler"
        assert my_func.description == "Doubles a number"

    async def test_decorated_tool_can_be_called(self) -> None:
        @tool
        def square(n: int) -> int:
            """Square a number."""
            return n * n

        result = await square.call(n=5)
        assert result == 25

    async def test_decorated_async_tool(self) -> None:
        @tool
        async def fetch_data(url: str) -> str:
            """Fetch data from URL."""
            return f"data from {url}"

        result = await fetch_data.call(url="example.com")
        assert result == "data from example.com"
