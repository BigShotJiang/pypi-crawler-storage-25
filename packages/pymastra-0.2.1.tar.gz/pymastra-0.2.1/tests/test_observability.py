"""Tests for pymastra.observability — metrics, events, spans, traces."""

import time

import pytest

from pymastra.observability import (
    Event,
    EventLogger,
    EventType,
    Metrics,
    Span,
    TraceContext,
    get_event_logger,
    get_metrics,
)


# ── EventType ────────────────────────────────────────────────────────


class TestEventType:
    def test_values(self) -> None:
        assert EventType.WORKFLOW_START == "workflow.start"
        assert EventType.WORKFLOW_COMPLETE == "workflow.complete"
        assert EventType.STEP_START == "step.start"
        assert EventType.ERROR == "error"

    def test_is_string_enum(self) -> None:
        assert isinstance(EventType.WORKFLOW_START, str)
        assert EventType.WORKFLOW_START.value == "workflow.start"


# ── Span ─────────────────────────────────────────────────────────────


class TestSpan:
    def test_creation(self) -> None:
        span = Span(name="test", start_time=time.time())
        assert span.name == "test"
        assert span.status == "pending"
        assert span.end_time is None
        assert span.duration_ms is None

    def test_end_span(self) -> None:
        span = Span(name="test", start_time=time.time() - 0.1)
        span.end(status="success")
        assert span.status == "success"
        assert span.end_time is not None
        assert span.duration_ms is not None
        assert span.duration_ms > 0

    def test_end_with_metadata(self) -> None:
        span = Span(name="test", start_time=time.time())
        span.end(status="error", metadata={"error": "timeout"})
        assert span.metadata == {"error": "timeout"}

    def test_end_merges_metadata(self) -> None:
        span = Span(name="test", start_time=time.time(), metadata={"key": "val"})
        span.end(metadata={"extra": "info"})
        assert span.metadata == {"key": "val", "extra": "info"}

    def test_to_dict(self) -> None:
        span = Span(name="test", start_time=1000.0)
        span.end()
        d = span.to_dict()
        assert d["name"] == "test"
        assert d["start_time"] == 1000.0
        assert "end_time" in d
        assert "duration_ms" in d

    def test_to_dict_empty_metadata(self) -> None:
        span = Span(name="test", start_time=1000.0)
        d = span.to_dict()
        assert d["metadata"] == {}


# ── Event ────────────────────────────────────────────────────────────


class TestEvent:
    def test_creation(self) -> None:
        event = Event(
            type=EventType.STEP_START,
            timestamp=1000.0,
            run_id="r1",
            workflow_id="wf1",
            step_id="s1",
            message="Step started",
        )
        assert event.type == EventType.STEP_START
        assert event.run_id == "r1"
        assert event.step_id == "s1"

    def test_to_dict(self) -> None:
        event = Event(
            type=EventType.WORKFLOW_COMPLETE,
            timestamp=1000.0,
            run_id="r1",
            workflow_id="wf1",
            message="Done",
            data={"total_steps": 3},
        )
        d = event.to_dict()
        assert d["type"] == "workflow.complete"
        assert d["run_id"] == "r1"
        assert d["data"] == {"total_steps": 3}

    def test_to_json(self) -> None:
        event = Event(
            type=EventType.ERROR,
            timestamp=1000.0,
            run_id="r1",
            workflow_id="wf1",
        )
        json_str = event.to_json()
        assert '"type": "error"' in json_str
        assert '"run_id": "r1"' in json_str

    def test_defaults(self) -> None:
        event = Event(
            type=EventType.STEP_START,
            timestamp=0,
            run_id="r1",
            workflow_id="wf1",
        )
        assert event.step_id is None
        assert event.message == ""
        assert event.data is None
        assert event.duration_ms is None


# ── Metrics ──────────────────────────────────────────────────────────


class TestMetrics:
    def test_initial_values(self) -> None:
        m = Metrics()
        assert m.workflows_started == 0
        assert m.workflows_completed == 0
        assert m.steps_executed == 0

    def test_record_workflow_lifecycle(self) -> None:
        m = Metrics()
        m.record_workflow_start()
        m.record_workflow_start()
        m.record_workflow_complete()
        m.record_workflow_failed()
        m.record_workflow_suspended()

        assert m.workflows_started == 2
        assert m.workflows_completed == 1
        assert m.workflows_failed == 1
        assert m.workflows_suspended == 1

    def test_record_step_executed(self) -> None:
        m = Metrics()
        m.record_step_executed("s1", 100.0)
        m.record_step_executed("s1", 200.0)
        m.record_step_executed("s2", 50.0)

        assert m.steps_executed == 3
        assert len(m.step_durations["s1"]) == 2
        assert len(m.step_durations["s2"]) == 1

    def test_record_step_failed_and_suspended(self) -> None:
        m = Metrics()
        m.record_step_failed()
        m.record_step_suspended()
        assert m.steps_failed == 1
        assert m.steps_suspended == 1

    def test_record_tool_call(self) -> None:
        m = Metrics()
        m.record_tool_call(success=True)
        m.record_tool_call(success=True)
        m.record_tool_call(success=False)

        assert m.tool_calls == 3
        assert m.tool_failures == 1

    def test_get_step_stats(self) -> None:
        m = Metrics()
        m.record_step_executed("s1", 100.0)
        m.record_step_executed("s1", 200.0)
        m.record_step_executed("s1", 300.0)

        stats = m.get_step_stats("s1")
        assert stats["count"] == 3
        assert stats["min_ms"] == 100.0
        assert stats["max_ms"] == 300.0
        assert stats["avg_ms"] == 200.0

    def test_get_step_stats_nonexistent(self) -> None:
        m = Metrics()
        stats = m.get_step_stats("unknown")
        assert stats["count"] == 0
        assert stats["min_ms"] == 0
        assert stats["max_ms"] == 0

    def test_get_summary(self) -> None:
        m = Metrics()
        m.record_workflow_start()
        m.record_workflow_complete()
        m.record_step_executed("s1", 100.0)
        m.record_tool_call(success=True)

        summary = m.get_summary()
        assert summary["workflows"]["started"] == 1
        assert summary["workflows"]["completed"] == 1
        assert summary["workflows"]["success_rate_pct"] == 100.0
        assert summary["steps"]["executed"] == 1
        assert summary["tools"]["calls"] == 1
        assert "s1" in summary["step_timings"]

    def test_summary_zero_division(self) -> None:
        m = Metrics()
        summary = m.get_summary()
        assert summary["workflows"]["success_rate_pct"] == 0.0
        assert summary["tools"]["success_rate_pct"] == 0.0


# ── EventLogger ──────────────────────────────────────────────────────


class TestEventLogger:
    async def test_log_event(self) -> None:
        logger = EventLogger()
        event = Event(
            type=EventType.STEP_START,
            timestamp=time.time(),
            run_id="r1",
            workflow_id="wf1",
        )
        await logger.log_event(event)
        assert len(logger.events) == 1

    async def test_handler_called(self) -> None:
        received: list[Event] = []
        logger = EventLogger()
        logger.register_handler(lambda e: received.append(e))

        event = Event(
            type=EventType.STEP_START,
            timestamp=time.time(),
            run_id="r1",
            workflow_id="wf1",
        )
        await logger.log_event(event)
        assert len(received) == 1

    async def test_async_handler_called(self) -> None:
        received: list[Event] = []

        async def handler(e: Event) -> None:
            received.append(e)

        logger = EventLogger()
        logger.register_handler(handler)

        event = Event(
            type=EventType.STEP_COMPLETE,
            timestamp=time.time(),
            run_id="r1",
            workflow_id="wf1",
        )
        await logger.log_event(event)
        assert len(received) == 1

    async def test_handler_error_doesnt_crash(self) -> None:
        def bad_handler(e: Event) -> None:
            raise RuntimeError("handler crash")

        logger = EventLogger()
        logger.register_handler(bad_handler)

        event = Event(
            type=EventType.ERROR,
            timestamp=time.time(),
            run_id="r1",
            workflow_id="wf1",
        )
        # Should not raise
        await logger.log_event(event)

    def test_get_events_filtering(self) -> None:
        logger = EventLogger()
        logger.events = [
            Event(type=EventType.STEP_START, timestamp=0, run_id="r1", workflow_id="wf1"),
            Event(type=EventType.STEP_COMPLETE, timestamp=1, run_id="r1", workflow_id="wf1"),
            Event(type=EventType.STEP_START, timestamp=2, run_id="r2", workflow_id="wf1"),
        ]

        # Filter by type
        starts = logger.get_events(event_type=EventType.STEP_START)
        assert len(starts) == 2

        # Filter by run_id
        r1_events = logger.get_events(run_id="r1")
        assert len(r1_events) == 2

        # Filter by both
        r2_starts = logger.get_events(event_type=EventType.STEP_START, run_id="r2")
        assert len(r2_starts) == 1

    def test_get_events_limit(self) -> None:
        logger = EventLogger()
        logger.events = [
            Event(type=EventType.STEP_START, timestamp=i, run_id="r1", workflow_id="wf1")
            for i in range(10)
        ]
        events = logger.get_events(limit=3)
        assert len(events) == 3

    def test_export_events(self) -> None:
        logger = EventLogger()
        logger.events = [
            Event(type=EventType.STEP_START, timestamp=0, run_id="r1", workflow_id="wf1"),
        ]
        exported = logger.export_events()
        assert len(exported) == 1
        assert exported[0]["type"] == "step.start"


# ── TraceContext ─────────────────────────────────────────────────────


class TestTraceContext:
    def test_creation(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        assert tc.run_id == "r1"
        assert tc.workflow_id == "wf1"
        assert tc.spans == []
        assert tc.events == []

    def test_create_span(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        span = tc.create_span("my_span", metadata={"key": "val"})
        assert isinstance(span, Span)
        assert span.name == "my_span"
        assert len(tc.spans) == 1

    def test_add_event(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        event = tc.add_event(
            EventType.STEP_START,
            step_id="s1",
            message="started",
        )
        assert isinstance(event, Event)
        assert event.run_id == "r1"
        assert len(tc.events) == 1

    def test_get_duration(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        duration = tc.get_duration()
        assert duration >= 0

    def test_get_summary(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        span = tc.create_span("s1")
        span.end()
        tc.add_event(EventType.STEP_START)

        summary = tc.get_summary()
        assert summary["run_id"] == "r1"
        assert summary["spans"] == 1
        assert summary["events"] == 1
        assert summary["span_summary"]["count"] == 1

    def test_summary_no_spans(self) -> None:
        tc = TraceContext(run_id="r1", workflow_id="wf1")
        summary = tc.get_summary()
        assert summary["span_summary"]["count"] == 0
        assert summary["span_summary"]["min_ms"] == 0


# ── Global instances ─────────────────────────────────────────────────


class TestGlobalInstances:
    def test_get_metrics_returns_singleton(self) -> None:
        m1 = get_metrics()
        m2 = get_metrics()
        assert m1 is m2
        assert isinstance(m1, Metrics)

    def test_get_event_logger_returns_singleton(self) -> None:
        l1 = get_event_logger()
        l2 = get_event_logger()
        assert l1 is l2
        assert isinstance(l1, EventLogger)
