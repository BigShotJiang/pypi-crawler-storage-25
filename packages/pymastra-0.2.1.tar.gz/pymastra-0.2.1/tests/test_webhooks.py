"""Tests for pymastra.webhooks — webhook URL validation and configuration."""

import pytest

from pymastra.observability import EventType
from pymastra.webhooks import Webhook, _validate_webhook_url


# ── URL validation ───────────────────────────────────────────────────


class TestValidateWebhookUrl:
    def test_valid_https_url(self) -> None:
        _validate_webhook_url("https://example.com/webhook")

    def test_valid_http_url(self) -> None:
        _validate_webhook_url("http://example.com/webhook")

    def test_rejects_non_http_schemes(self) -> None:
        with pytest.raises(ValueError, match="Invalid URL scheme"):
            _validate_webhook_url("ftp://example.com")

        with pytest.raises(ValueError, match="Invalid URL scheme"):
            _validate_webhook_url("file:///etc/passwd")

    def test_rejects_localhost(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://localhost/hook")

    def test_rejects_127_addresses(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://127.0.0.1/hook")

    def test_rejects_private_192_168(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://192.168.1.1/hook")

    def test_rejects_private_10(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://10.0.0.1/hook")

    def test_rejects_private_172(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://172.16.0.1/hook")

    def test_rejects_link_local(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            _validate_webhook_url("http://169.254.0.1/hook")

    def test_rejects_empty_hostname(self) -> None:
        with pytest.raises(ValueError):
            _validate_webhook_url("http:///path")


# ── Webhook class ────────────────────────────────────────────────────


class TestWebhook:
    def test_basic_creation(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
        )
        assert wh.id == "wh1"
        assert wh.url == "https://example.com/hook"
        assert wh.events == [EventType.WORKFLOW_COMPLETE]
        assert wh.active is True

    def test_creation_with_string_events(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=["workflow.complete", "step.failed"],
        )
        assert EventType.WORKFLOW_COMPLETE in wh.events
        assert EventType.STEP_FAILED in wh.events

    def test_creation_with_secret(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
            secret="my-secret-key",
        )
        assert wh.secret == "my-secret-key"

    def test_creation_with_headers(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
            headers={"X-Custom": "value"},
        )
        assert wh.headers == {"X-Custom": "value"}

    def test_inactive_webhook(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
            active=False,
        )
        assert wh.active is False

    def test_invalid_url_rejected(self) -> None:
        with pytest.raises(ValueError):
            Webhook(
                id="wh1",
                url="http://localhost/hook",
                events=[EventType.WORKFLOW_COMPLETE],
            )


class TestWebhookMatchesEvent:
    def test_matches_registered_event(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE, EventType.STEP_FAILED],
        )
        assert wh.matches_event(EventType.WORKFLOW_COMPLETE) is True
        assert wh.matches_event(EventType.STEP_FAILED) is True

    def test_does_not_match_unregistered_event(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
        )
        assert wh.matches_event(EventType.STEP_START) is False

    def test_inactive_never_matches(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE],
            active=False,
        )
        assert wh.matches_event(EventType.WORKFLOW_COMPLETE) is False


class TestWebhookToDict:
    def test_to_dict(self) -> None:
        wh = Webhook(
            id="wh1",
            url="https://example.com/hook",
            events=[EventType.WORKFLOW_COMPLETE, EventType.STEP_FAILED],
            active=True,
        )
        d = wh.to_dict()
        assert d["id"] == "wh1"
        assert d["url"] == "https://example.com/hook"
        assert "workflow.complete" in d["events"]
        assert "step.failed" in d["events"]
        assert d["active"] is True
