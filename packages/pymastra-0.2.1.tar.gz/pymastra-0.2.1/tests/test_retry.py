"""Tests for pymastra.retry — retry configuration and logic."""

import asyncio
import time

import pytest

from pymastra.retry import RetryConfig


class TestRetryConfigDefaults:
    def test_default_max_attempts_is_one(self) -> None:
        rc = RetryConfig()
        assert rc.max_attempts == 1

    def test_default_delay(self) -> None:
        rc = RetryConfig()
        assert rc.delay_seconds == 1.0

    def test_default_backoff_is_exponential(self) -> None:
        rc = RetryConfig()
        assert rc.backoff == "exponential"

    def test_default_retry_on_is_none(self) -> None:
        rc = RetryConfig()
        assert rc.retry_on is None


class TestRetryConfigCustom:
    def test_custom_values(self) -> None:
        rc = RetryConfig(max_attempts=5, delay_seconds=2.0, backoff="fixed")
        assert rc.max_attempts == 5
        assert rc.delay_seconds == 2.0
        assert rc.backoff == "fixed"

    def test_max_attempts_minimum_is_one(self) -> None:
        rc = RetryConfig(max_attempts=0)
        assert rc.max_attempts == 1

        rc2 = RetryConfig(max_attempts=-5)
        assert rc2.max_attempts == 1

    def test_retry_on_specific_exceptions(self) -> None:
        rc = RetryConfig(retry_on=[ValueError, TypeError])
        assert rc.retry_on == [ValueError, TypeError]


class TestShouldRetry:
    def test_retries_all_when_retry_on_is_none(self) -> None:
        rc = RetryConfig()
        assert rc.should_retry(ValueError("test")) is True
        assert rc.should_retry(RuntimeError("test")) is True

    def test_retries_only_specified_exceptions(self) -> None:
        rc = RetryConfig(retry_on=[ValueError])
        assert rc.should_retry(ValueError("test")) is True
        assert rc.should_retry(RuntimeError("test")) is False

    def test_retries_subclasses(self) -> None:
        rc = RetryConfig(retry_on=[Exception])
        assert rc.should_retry(ValueError("test")) is True

    def test_empty_retry_on_list(self) -> None:
        rc = RetryConfig(retry_on=[])
        assert rc.should_retry(ValueError("test")) is False


class TestGetDelay:
    def test_fixed_delay(self) -> None:
        rc = RetryConfig(delay_seconds=2.0, backoff="fixed")
        assert rc.get_delay(0) == 2.0
        assert rc.get_delay(1) == 2.0
        assert rc.get_delay(5) == 2.0

    def test_exponential_delay(self) -> None:
        rc = RetryConfig(delay_seconds=1.0, backoff="exponential")
        assert rc.get_delay(0) == 1.0   # 1 * 2^0
        assert rc.get_delay(1) == 2.0   # 1 * 2^1
        assert rc.get_delay(2) == 4.0   # 1 * 2^2
        assert rc.get_delay(3) == 8.0   # 1 * 2^3

    def test_exponential_with_custom_base(self) -> None:
        rc = RetryConfig(delay_seconds=0.5, backoff="exponential")
        assert rc.get_delay(0) == 0.5
        assert rc.get_delay(1) == 1.0
        assert rc.get_delay(2) == 2.0


class TestWait:
    async def test_wait_actually_delays(self) -> None:
        rc = RetryConfig(delay_seconds=0.05, backoff="fixed")
        start = time.monotonic()
        await rc.wait(0)
        elapsed = time.monotonic() - start
        assert elapsed >= 0.04  # Allow small timing tolerance
