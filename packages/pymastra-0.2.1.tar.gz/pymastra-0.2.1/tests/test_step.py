"""Tests for pymastra.step — Step class."""

import pytest
from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.retry import RetryConfig
from pymastra.step import Step

from tests.conftest import TriggerInput, StepOutput


class TestStepInit:
    def test_basic_construction(self) -> None:
        async def fn(ctx: StepContext) -> StepOutput:
            return StepOutput(result="ok")

        step = Step(
            id="s1",
            description="Test step",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
        )
        assert step.id == "s1"
        assert step.description == "Test step"
        assert step.input_schema is TriggerInput
        assert step.output_schema is StepOutput
        assert step.execute is fn

    def test_default_retry_config(self) -> None:
        async def fn(ctx: StepContext) -> StepOutput:
            return StepOutput(result="ok")

        step = Step(
            id="s1",
            description="desc",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
        )
        assert step.retry.max_attempts == 1

    def test_custom_retry_config(self) -> None:
        rc = RetryConfig(max_attempts=3, delay_seconds=0.1)

        async def fn(ctx: StepContext) -> StepOutput:
            return StepOutput(result="ok")

        step = Step(
            id="s1",
            description="desc",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
            retry=rc,
        )
        assert step.retry.max_attempts == 3
        assert step.retry.delay_seconds == 0.1


class TestStepCall:
    async def test_call_executes_function(self) -> None:
        async def fn(ctx: StepContext) -> StepOutput:
            return StepOutput(result=f"processed-{ctx.trigger_data.text}")

        step = Step(
            id="s1",
            description="desc",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
        )

        ctx = StepContext(
            trigger_data=TriggerInput(text="hello"),
            outputs={},
            step_id="s1",
            run_id="r1",
        )

        result = await step(ctx)
        assert isinstance(result, StepOutput)
        assert result.result == "processed-hello"

    async def test_call_propagates_exception(self) -> None:
        async def fn(ctx: StepContext) -> StepOutput:
            raise ValueError("boom")

        step = Step(
            id="s1",
            description="desc",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
        )

        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs={},
            step_id="s1",
            run_id="r1",
        )

        with pytest.raises(ValueError, match="boom"):
            await step(ctx)

    async def test_call_accesses_previous_outputs(self) -> None:
        prev_output = StepOutput(result="step0-done", score=0.8)

        async def fn(ctx: StepContext) -> StepOutput:
            prev = ctx.outputs["step_0"]
            return StepOutput(result=f"continued-{prev.result}")

        step = Step(
            id="s1",
            description="desc",
            input_schema=TriggerInput,
            output_schema=StepOutput,
            execute=fn,
        )

        ctx = StepContext(
            trigger_data=TriggerInput(text="x"),
            outputs={"step_0": prev_output},
            step_id="s1",
            run_id="r1",
        )

        result = await step(ctx)
        assert result.result == "continued-step0-done"
