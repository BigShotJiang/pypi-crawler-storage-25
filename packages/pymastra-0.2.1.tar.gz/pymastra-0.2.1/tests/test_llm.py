"""Tests for pymastra.llm — LLM configuration and client."""

import pytest

from pymastra.llm import LLMClient, LLMConfig


class TestLLMConfig:
    def test_default_config(self) -> None:
        config = LLMConfig()
        assert config.provider == "claude"
        assert config.model == "claude-3-5-sonnet-20241022"
        assert config.temperature == 0.7
        assert config.max_tokens == 1024

    def test_openai_provider(self) -> None:
        config = LLMConfig(provider="openai", model="gpt-4")
        assert config.provider == "openai"
        assert config.model == "gpt-4"

    def test_claude_provider(self) -> None:
        config = LLMConfig(provider="claude", model="claude-3-opus-20240229")
        assert config.provider == "claude"

    def test_custom_temperature(self) -> None:
        config = LLMConfig(temperature=0.0)
        assert config.temperature == 0.0

    def test_custom_max_tokens(self) -> None:
        config = LLMConfig(max_tokens=4096)
        assert config.max_tokens == 4096

    def test_api_key(self) -> None:
        config = LLMConfig(api_key="test-key")
        assert config.api_key == "test-key"

    def test_invalid_provider(self) -> None:
        with pytest.raises(ValueError, match="Unknown provider"):
            LLMConfig(provider="invalid")  # type: ignore


class TestLLMClientTokenCount:
    def test_count_tokens_estimation(self) -> None:
        config = LLMConfig()
        client = LLMClient(config)
        # Simple estimation: ~4 chars per token
        count = client.count_tokens("Hello World!")  # 12 chars
        assert count == 3  # 12 // 4

    def test_count_tokens_empty(self) -> None:
        config = LLMConfig()
        client = LLMClient(config)
        assert client.count_tokens("") == 0

    def test_count_tokens_long_text(self) -> None:
        config = LLMConfig()
        client = LLMClient(config)
        text = "a" * 1000
        assert client.count_tokens(text) == 250
