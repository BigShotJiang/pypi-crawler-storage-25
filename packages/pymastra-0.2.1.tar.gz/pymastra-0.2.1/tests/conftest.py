"""Shared test fixtures for Pymastra test suite."""

import pytest
from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.retry import RetryConfig
from pymastra.step import Step
from pymastra.storage.memory import MemoryStorage


# ── Pydantic models for testing ──────────────────────────────────────


class TriggerInput(BaseModel):
    text: str
    value: int = 0


class StepOutput(BaseModel):
    result: str
    score: float = 1.0


class ReviewPayload(BaseModel):
    approved: bool
    comment: str = ""


# ── Fixtures ─────────────────────────────────────────────────────────


@pytest.fixture
def memory_storage() -> MemoryStorage:
    return MemoryStorage()


@pytest.fixture
def trigger_data() -> TriggerInput:
    return TriggerInput(text="hello", value=42)


@pytest.fixture
def make_step():
    """Factory fixture to create steps with custom execute functions."""

    def _make(
        step_id: str = "step_1",
        description: str = "Test step",
        input_schema: type[BaseModel] = TriggerInput,
        output_schema: type[BaseModel] = StepOutput,
        execute=None,
        retry: RetryConfig | None = None,
    ) -> Step:
        if execute is None:

            async def execute(ctx: StepContext) -> StepOutput:
                return StepOutput(result="ok")

        return Step(
            id=step_id,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
            execute=execute,
            retry=retry,
        )

    return _make


@pytest.fixture
def make_context():
    """Factory fixture to create StepContext instances."""

    def _make(
        trigger_data: BaseModel | None = None,
        outputs: dict | None = None,
        step_id: str = "test_step",
        run_id: str = "run_001",
    ) -> StepContext:
        if trigger_data is None:
            trigger_data = TriggerInput(text="test", value=1)
        return StepContext(
            trigger_data=trigger_data,
            outputs=outputs or {},
            step_id=step_id,
            run_id=run_id,
        )

    return _make
