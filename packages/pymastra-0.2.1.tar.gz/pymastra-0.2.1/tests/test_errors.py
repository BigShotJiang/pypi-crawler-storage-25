"""Tests for pymastra.errors — custom exception classes."""

import pytest

from pymastra.errors import (
    PymaestraError,
    ResumeError,
    StorageError,
    StepExecutionError,
    SuspendError,
    WorkflowValidationError,
)


class TestExceptionHierarchy:
    def test_base_error_is_exception(self) -> None:
        assert issubclass(PymaestraError, Exception)

    def test_all_errors_inherit_from_base(self) -> None:
        for exc_cls in (
            WorkflowValidationError,
            StepExecutionError,
            SuspendError,
            ResumeError,
            StorageError,
        ):
            assert issubclass(exc_cls, PymaestraError)

    def test_base_error_can_be_raised_and_caught(self) -> None:
        with pytest.raises(PymaestraError, match="test"):
            raise PymaestraError("test")

    def test_workflow_validation_error(self) -> None:
        with pytest.raises(WorkflowValidationError, match="bad config"):
            raise WorkflowValidationError("bad config")

    def test_step_execution_error(self) -> None:
        with pytest.raises(StepExecutionError, match="step failed"):
            raise StepExecutionError("step failed")

    def test_resume_error(self) -> None:
        with pytest.raises(ResumeError, match="cannot resume"):
            raise ResumeError("cannot resume")

    def test_storage_error(self) -> None:
        with pytest.raises(StorageError, match="db error"):
            raise StorageError("db error")


class TestSuspendError:
    def test_suspend_error_with_message_only(self) -> None:
        err = SuspendError("paused")
        assert str(err) == "paused"
        assert err.payload is None

    def test_suspend_error_with_payload(self) -> None:
        payload = {"question": "approve?"}
        err = SuspendError("paused", payload=payload)
        assert str(err) == "paused"
        assert err.payload == payload

    def test_suspend_error_caught_as_base(self) -> None:
        with pytest.raises(PymaestraError):
            raise SuspendError("suspend")
