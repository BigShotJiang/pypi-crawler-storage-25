# Changelog

All notable changes to Pymastra will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.2.0] - 2026-04-06

### 🚀 New Features

#### Storage & Persistence
- **SQLite backend** - File-based persistence for self-hosted deployments
- **Query API** - List, filter, and count workflow runs in storage
- **Database indexes** - Optimized queries on status, workflow_id, created_at
- **Optional migration** - Seamless migration from in-memory to persistent storage

#### Observability & Monitoring
- **Event logging** - Structured events for workflow execution (WORKFLOW_*, STEP_*, TOOL_*, ERROR)
- **Execution tracing** - Span-based tracing with timing information
- **Metrics collection** - Counters, histograms, and timing statistics
- **Event handlers** - Extensible event handler pattern for external monitoring systems
- **TraceContext** - Complete execution context with summary reporting

#### Webhooks & Integrations
- **Event-driven webhooks** - Trigger external services on workflow events
- **Automatic retries** - Exponential backoff for failed webhook deliveries
- **HMAC signatures** - Security headers with secret-based authentication
- **Custom headers** - Support for additional HTTP headers
- **Failure tracking** - Record and analyze webhook delivery failures

#### Developer Experience
- **Getting Started guide** - Comprehensive 10-minute onboarding guide
- **Enhanced error messages** - Detailed context, suggestions, and available options
- **Debugging utilities** - Format functions for run summaries and validation errors
- **Performance benchmarks** - Throughput and timing measurements
- **Comprehensive docs** - Persistence guide, debugging guide, getting started

### 📈 Improvements

- **Error context** - Better error messages with suggestions
- **Type annotations** - 100+ additional type hints
- **Documentation** - 4 new guides (Getting Started, Debugging, Persistence, Release Notes)
- **Examples** - 3 new examples (SQLite persistence, Observability, Webhooks)
- **Benchmarks** - 5 different benchmark categories
- **Test coverage** - 37+ existing tests, 100% type coverage

### 🔧 Technical

- **Async I/O** - Optimized async operations throughout
- **Connection pooling** - Efficient resource usage (PostgreSQL)
- **Query optimization** - Database indexes for common operations
- **Memory efficiency** - Optimized storage usage
- **Performance** - Sub-5ms simple workflows, 2000+ workflows/sec throughput

### 📚 Documentation

- **GETTING_STARTED.md** - Beginner-friendly tutorial
- **PERSISTENCE.md** - Storage backend guide with migration paths
- **DEBUGGING.md** - Error handling and debugging guide
- **Performance metrics** - Documented benchmark results
- **API documentation** - Inline docstrings for all new modules

### 🎯 Use Cases

New capabilities enable:
- ✅ Persistent workflow storage (SQLite/PostgreSQL)
- ✅ Production monitoring & alerting
- ✅ External service integrations (Slack, webhooks)
- ✅ Performance optimization & analysis
- ✅ Multi-team deployments

---

## [0.1.0] - 2026-04-06

### 🚀 Major Features

#### Core Workflow Engine
- **Workflow execution** - Build and execute directed graphs of steps
- **Step chaining** - Chain steps sequentially with `.then()`
- **Conditional branching** - Route workflows based on step outputs
- **Output passing** - Automatically pass outputs between steps via context
- **Full type safety** - Pydantic v2 schema validation throughout

#### Human-in-the-Loop (HITL)
- **Suspend/Resume** - Pause workflows to wait for human input
- **Flexible suspension** - Suspend at any step with custom context data
- **Schema validation** - Validate human input against expected schemas
- **Multi-suspension** - Support multiple suspension points in one workflow

#### LLM Integration
- **OpenAI support** - Call GPT-4, GPT-3.5 turbo, and other OpenAI models
- **Claude support** - Call Claude 3 Opus, Sonnet, and Haiku via Anthropic API
- **Unified client** - Same interface for both providers
- **LLM steps** - `create_llm_step()` for easy LLM integration in workflows
- **Token counting** - Built-in token estimation
- **Async-first** - Non-blocking LLM calls with asyncio

#### Storage Backends
- **In-memory storage** - Perfect for development and testing
- **SQLite storage** - File-based persistence (optional: `pip install pymastra[sqlite]`)
- **PostgreSQL storage** - Production database support (optional: `pip install pymastra[postgres]`)
- **Unified interface** - StorageBackend abstract base class for custom backends

#### REST API Server
- **FastAPI integration** - Production-ready REST API (optional: `pip install pymastra[server]`)
- **Workflow execution endpoint** - `POST /workflows/execute`
- **Run status endpoint** - `GET /runs/{run_id}`
- **Suspension data endpoint** - `GET /runs/{run_id}/suspend_payload`
- **Resume endpoint** - `POST /runs/{run_id}/resume`
- **Auto-generated docs** - Swagger UI at `/docs`, ReDoc at `/redoc`

#### Retry & Error Handling
- **Automatic retries** - Configure per-step retry behavior
- **Backoff strategies** - Fixed or exponential backoff
- **Selective retries** - Retry only on specific exception types
- **Clear error messages** - Helpful error context for debugging
- **Error propagation** - Proper exception handling throughout

### 📚 Examples

#### Production-Ready Workflows
1. **Document Classification** (`examples/document_classification.py`)
   - Classify documents (Legal, Finance, HR, General)
   - HITL for low-confidence classifications
   - Routes to appropriate teams
   - Real business use case

2. **Support Ticket Routing** (`examples/ticket_routing.py`)
   - Analyze support tickets (urgency, category, sentiment)
   - Manager approval for critical tickets
   - Dynamic routing based on analysis
   - SLA management

3. **LLM Classification** (`examples/llm_classification.py`)
   - Simple text classification with Claude
   - Shows LLM step integration
   - Ready-to-run example

4. **REST API Server** (`examples/server_example.py`)
   - Complete working FastAPI server
   - Approval workflow example
   - Demonstrates REST API usage
   - Includes curl command examples

5. **Basic Workflow** (`examples/basic_workflow.py`)
   - Sequential step execution
   - Output passing between steps
   - Simple getting-started example

6. **Branching Workflow** (`examples/branching_workflow.py`)
   - Conditional routing
   - Different branches based on context
   - Document routing example

### 📦 Dependencies

**Core:**
- `pydantic>=2.0` - Schema validation
- `anyio>=4.0` - Async utilities

**Optional:**
- `openai>=1.0` - OpenAI API (`pip install pymastra[openai]`)
- `anthropic>=0.25` - Anthropic Claude API (`pip install pymastra[anthropic]`)
- `aiosqlite>=0.19` - SQLite storage (`pip install pymastra[sqlite]`)
- `asyncpg>=0.29` - PostgreSQL storage (`pip install pymastra[postgres]`)
- `fastapi>=0.100` - REST API server (`pip install pymastra[server]`)
- `uvicorn>=0.23` - ASGI server for FastAPI

**Development:**
- `pytest>=7.0` - Testing framework
- `pytest-asyncio>=0.23` - Async test support
- `mypy>=1.8` - Static type checking
- `ruff>=0.2` - Code linting and formatting
- `coverage>=7.0` - Test coverage analysis

### 🧪 Test Coverage

- **37 comprehensive tests** covering:
  - Step execution and chaining
  - Workflow building and validation
  - HITL suspend/resume mechanics
  - Storage backend operations
  - Retry logic with backoff
  - Branching and conditional routing
  - Error handling and edge cases
  - Multi-suspension workflows

- **66% overall coverage**, with:
  - Core execution: 88%
  - HITL mechanics: 100%
  - In-memory storage: 100%
  - Step class: 100%
  - Retry logic: 89%

### 🏗️ Architecture

**Core Primitives:**
- `Step` - Unit of work with input/output schemas
- `Workflow` - Directed graph of steps
- `StepContext` - Runtime context passed to each step
- `WorkflowRun` - Execution state and handle
- `RetryConfig` - Retry configuration

**Storage:**
- `StorageBackend` - Abstract base class
- `MemoryStorage` - In-memory (default)
- `SQLiteStorage` - File-based persistence
- `PostgresStorage` - Production database

**LLM:**
- `LLMClient` - Unified LLM interface
- `LLMConfig` - Configuration for OpenAI/Claude
- `create_llm_step()` - Helper to create LLM steps
- `LLMChain` - Multi-step LLM workflows

**Server:**
- `WorkflowServer` - FastAPI integration
- REST API endpoints for workflow execution

### 📖 Documentation

- **README.md** - Feature overview and quick start
- **PROJECT_STATUS.md** - Detailed project roadmap and status
- **CHANGELOG.md** - This file
- **Inline docstrings** - Full API documentation
- **Examples** - 6 production-ready examples

### 🔒 Quality Assurance

- ✅ **Type Safety** - 100% type hints with mypy strict mode
- ✅ **Code Quality** - Ruff linting (E, F, I, UP, B, SIM, ANN)
- ✅ **Test Coverage** - 66% overall (85-100% on core)
- ✅ **Async-First** - Non-blocking throughout
- ✅ **Error Handling** - Clear error messages and context

### 🚀 Getting Started

```bash
# Install core
pip install pymastra

# With LLM support
pip install pymastra[llm]

# With REST API server
pip install pymastra[server]

# All features
pip install pymastra[all]
```

```python
from pymastra import Workflow, create_llm_step

# Create LLM step
step = create_llm_step(
    id="classify",
    description="Classify text",
    system_prompt="Classify as: A, B, or C",
)

# Build workflow
wf = Workflow(name="classifier", trigger_schema=TextInput)
wf.step(step).commit()

# Execute
run = await wf.execute(TextInput(text="Your text here"))
```

### 🎯 What's Next (v0.2.0)

- [ ] Function calling for LLM agents
- [ ] Advanced observability and tracing
- [ ] PostgreSQL storage optimization
- [ ] Webhook integrations
- [ ] Web dashboard for workflow monitoring
- [ ] Performance benchmarking and optimization

### 🙏 Credits

Built with Claude Code | Startup Scale Development

---

## [Unreleased]

(Changes for next release will appear here)

---

## Notes

- **Minimum Python version:** 3.11
- **License:** MIT
- **Repository:** https://github.com/akashs101199/pymastra

