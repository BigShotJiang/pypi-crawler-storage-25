"""Performance benchmarks for Pymastra workflows.

Measures:
- Step execution time
- Workflow end-to-end time
- Memory usage
- Throughput (workflows/sec)
- Suspension/resumption overhead
"""

import asyncio
import psutil
import sys
import time
from pathlib import Path
from typing import Any

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    MemoryStorage,
    SQLiteStorage,
)


# ============================================================================
# Test schemas
# ============================================================================

class BenchmarkInput(BaseModel):
    """Input for benchmark."""

    value: int


class BenchmarkOutput(BaseModel):
    """Output from benchmark."""

    result: int


# ============================================================================
# Benchmark steps
# ============================================================================

async def fast_step(ctx: StepContext) -> BenchmarkOutput:
    """Very fast step (< 1ms)."""
    inp = ctx.trigger_data
    return BenchmarkOutput(result=inp.value)


async def medium_step(ctx: StepContext) -> BenchmarkOutput:
    """Medium speed step (10-50ms)."""
    inp = ctx.trigger_data
    await asyncio.sleep(0.01)  # 10ms
    return BenchmarkOutput(result=inp.value * 2)


async def slow_step(ctx: StepContext) -> BenchmarkOutput:
    """Slow step (100+ ms)."""
    inp = ctx.trigger_data
    await asyncio.sleep(0.1)  # 100ms
    return BenchmarkOutput(result=inp.value * 3)


async def io_step(ctx: StepContext) -> BenchmarkOutput:
    """Simulated I/O step."""
    inp = ctx.trigger_data
    # Simulate I/O operation
    await asyncio.sleep(0.05)
    return BenchmarkOutput(result=inp.value + 1)


# ============================================================================
# Benchmark suite
# ============================================================================

class BenchmarkSuite:
    """Runs performance benchmarks on workflows."""

    def __init__(self):
        """Initialize benchmark suite."""
        self.results = {}

    async def benchmark_simple_workflow(self, iterations: int = 100) -> dict[str, Any]:
        """Benchmark a simple single-step workflow.

        Args:
            iterations: Number of iterations

        Returns:
            Benchmark results
        """
        workflow = Workflow(
            name="simple_workflow",
            trigger_schema=BenchmarkInput,
            storage=MemoryStorage(),
        )

        step = Step(
            id="process",
            description="Process",
            input_schema=BenchmarkInput,
            output_schema=BenchmarkOutput,
            execute=fast_step,
        )

        workflow.step(step).commit()

        # Warm up
        await workflow.execute(BenchmarkInput(value=1))

        # Benchmark
        start_time = time.time()
        for i in range(iterations):
            await workflow.execute(BenchmarkInput(value=i))
        duration = time.time() - start_time

        return {
            "name": "Simple Workflow",
            "iterations": iterations,
            "total_time_sec": duration,
            "avg_time_ms": (duration / iterations) * 1000,
            "throughput_per_sec": iterations / duration,
        }

    async def benchmark_multi_step_workflow(self, iterations: int = 50) -> dict[str, Any]:
        """Benchmark a multi-step workflow.

        Args:
            iterations: Number of iterations

        Returns:
            Benchmark results
        """
        workflow = Workflow(
            name="multi_step_workflow",
            trigger_schema=BenchmarkInput,
            storage=MemoryStorage(),
        )

        step1 = Step(
            id="step1",
            description="Step 1",
            input_schema=BenchmarkInput,
            output_schema=BenchmarkOutput,
            execute=fast_step,
        )

        step2 = Step(
            id="step2",
            description="Step 2",
            input_schema=BenchmarkInput,
            output_schema=BenchmarkOutput,
            execute=medium_step,
        )

        step3 = Step(
            id="step3",
            description="Step 3",
            input_schema=BenchmarkInput,
            output_schema=BenchmarkOutput,
            execute=fast_step,
        )

        workflow.step(step1).then(step2).then(step3).commit()

        # Warm up
        await workflow.execute(BenchmarkInput(value=1))

        # Benchmark
        start_time = time.time()
        for i in range(iterations):
            await workflow.execute(BenchmarkInput(value=i))
        duration = time.time() - start_time

        return {
            "name": "Multi-Step Workflow (3 steps)",
            "iterations": iterations,
            "total_time_sec": duration,
            "avg_time_ms": (duration / iterations) * 1000,
            "throughput_per_sec": iterations / duration,
        }

    async def benchmark_storage_backends(self, iterations: int = 50) -> dict[str, Any]:
        """Benchmark different storage backends.

        Args:
            iterations: Number of iterations

        Returns:
            Benchmark results
        """
        results = {"name": "Storage Backend Comparison", "iterations": iterations, "backends": {}}

        for storage_name, storage in [
            ("In-Memory", MemoryStorage()),
            ("SQLite", SQLiteStorage(db_path=":memory:")),
        ]:
            workflow = Workflow(
                name="storage_benchmark",
                trigger_schema=BenchmarkInput,
                storage=storage,
            )

            step = Step(
                id="process",
                description="Process",
                input_schema=BenchmarkInput,
                output_schema=BenchmarkOutput,
                execute=fast_step,
            )

            workflow.step(step).commit()

            # Warm up
            await workflow.execute(BenchmarkInput(value=1))

            # Benchmark
            start_time = time.time()
            for i in range(iterations):
                await workflow.execute(BenchmarkInput(value=i))
            duration = time.time() - start_time

            results["backends"][storage_name] = {
                "total_time_sec": duration,
                "avg_time_ms": (duration / iterations) * 1000,
                "throughput_per_sec": iterations / duration,
            }

        return results

    async def benchmark_concurrent_workflows(self, num_concurrent: int = 10) -> dict[str, Any]:
        """Benchmark concurrent workflow execution.

        Args:
            num_concurrent: Number of concurrent workflows

        Returns:
            Benchmark results
        """
        workflow = Workflow(
            name="concurrent_workflow",
            trigger_schema=BenchmarkInput,
            storage=MemoryStorage(),
        )

        step = Step(
            id="process",
            description="Process",
            input_schema=BenchmarkInput,
            output_schema=BenchmarkOutput,
            execute=medium_step,
        )

        workflow.step(step).commit()

        # Benchmark
        start_time = time.time()

        tasks = [
            workflow.execute(BenchmarkInput(value=i))
            for i in range(num_concurrent)
        ]
        results = await asyncio.gather(*tasks)

        duration = time.time() - start_time

        return {
            "name": f"Concurrent Workflows ({num_concurrent})",
            "num_concurrent": num_concurrent,
            "total_time_sec": duration,
            "avg_time_ms": (duration / num_concurrent) * 1000,
            "throughput_per_sec": num_concurrent / duration,
        }

    async def benchmark_memory_usage(self) -> dict[str, Any]:
        """Benchmark memory usage.

        Returns:
            Memory usage statistics
        """
        process = psutil.Process()

        # Baseline
        baseline_mem = process.memory_info().rss / 1024 / 1024  # MB

        # Create large workflow
        workflow = Workflow(
            name="large_workflow",
            trigger_schema=BenchmarkInput,
            storage=MemoryStorage(),
        )

        # Add many steps
        prev_step = None
        for i in range(10):
            step = Step(
                id=f"step_{i}",
                description=f"Step {i}",
                input_schema=BenchmarkInput,
                output_schema=BenchmarkOutput,
                execute=fast_step,
            )
            if prev_step is None:
                workflow.step(step)
            else:
                workflow.then(step)
            prev_step = step

        workflow.commit()

        # Execute many times
        for i in range(100):
            await workflow.execute(BenchmarkInput(value=i))

        # Measure memory
        final_mem = process.memory_info().rss / 1024 / 1024  # MB
        used_mem = final_mem - baseline_mem

        return {
            "name": "Memory Usage",
            "baseline_mb": baseline_mem,
            "final_mb": final_mem,
            "used_mb": used_mem,
        }

    async def run_all(self) -> None:
        """Run all benchmarks."""
        print("\n" + "=" * 70)
        print("Pymastra Performance Benchmarks")
        print("=" * 70 + "\n")

        benchmarks = [
            ("Simple Workflow", self.benchmark_simple_workflow()),
            ("Multi-Step Workflow", self.benchmark_multi_step_workflow()),
            ("Storage Backends", self.benchmark_storage_backends()),
            ("Concurrent Workflows", self.benchmark_concurrent_workflows(num_concurrent=20)),
            ("Memory Usage", self.benchmark_memory_usage()),
        ]

        for name, coro in benchmarks:
            print(f"\n📊 {name}...")
            try:
                result = await coro
                self.results[name] = result
                self._print_result(result)
            except Exception as e:
                print(f"  ✗ Error: {e}")

        self._print_summary()

    def _print_result(self, result: dict[str, Any]) -> None:
        """Print benchmark result."""
        if "backends" in result:
            # Storage comparison
            for backend, stats in result["backends"].items():
                print(f"  {backend}:")
                print(f"    Avg time: {stats['avg_time_ms']:.2f}ms")
                print(f"    Throughput: {stats['throughput_per_sec']:.1f} workflows/sec")
        elif "used_mb" in result:
            # Memory usage
            print(f"  Memory used: {result['used_mb']:.2f} MB")
        else:
            # Standard metrics
            print(f"  Avg time: {result.get('avg_time_ms', 0):.2f}ms per execution")
            print(f"  Throughput: {result.get('throughput_per_sec', 0):.1f} workflows/sec")

    def _print_summary(self) -> None:
        """Print summary."""
        print("\n" + "=" * 70)
        print("Summary")
        print("=" * 70)

        print("\n🏆 Fastest:")
        if "Simple Workflow" in self.results:
            simple = self.results["Simple Workflow"]
            print(f"  {simple['avg_time_ms']:.2f}ms - Simple Workflow")

        print("\n⚡ Highest Throughput:")
        if "Simple Workflow" in self.results:
            simple = self.results["Simple Workflow"]
            print(f"  {simple['throughput_per_sec']:.1f} workflows/sec")

        print("\n" + "=" * 70 + "\n")


async def main():
    """Run benchmarks."""
    suite = BenchmarkSuite()
    await suite.run_all()


if __name__ == "__main__":
    asyncio.run(main())
