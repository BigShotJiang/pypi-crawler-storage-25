# Pymastra Getting Started Guide

Welcome to **Pymastra** — a Python-native workflow engine with Human-in-the-Loop support!

This guide will take you from zero to your first workflow in 5 minutes.

## What is Pymastra?

Pymastra lets you build **AI workflows** that combine:
- 🤖 LLM calls (Claude, GPT-4, etc.)
- 👥 Human approval/review
- 🔄 Automatic retries
- 💾 Persistent storage
- 🪝 External webhooks
- 📊 Built-in monitoring

Perfect for:
- Document classification with human review
- Support ticket routing
- Content approval workflows
- Data processing pipelines with validation
- Multi-step AI tasks

## Installation

### Quick Install

```bash
# Core library
pip install pymastra

# With LLM support
pip install pymastra[llm]

# With persistence
pip install pymastra[sqlite]

# Everything
pip install pymastra[all]
```

### Verify Installation

```python
from pymastra import Workflow, Step
print("✓ Pymastra installed successfully!")
```

## 5-Minute Tutorial

### Step 1: Define Your Workflow Schema

```python
from pydantic import BaseModel

class DocumentInput(BaseModel):
    title: str
    content: str

class ApprovalResult(BaseModel):
    approved: bool
    feedback: str = ""
```

### Step 2: Create Workflow Steps

```python
from pymastra import Step, StepContext

async def analyze_step(ctx: StepContext):
    """Analyze a document."""
    doc = ctx.trigger_data

    # Do your analysis
    analysis = {
        "length": len(doc.content),
        "type": "technical" if "code" in doc.content.lower() else "general"
    }

    return analysis

# Create the step
analyze = Step(
    id="analyze",
    description="Analyze the document",
    input_schema=DocumentInput,
    output_schema=dict,
    execute=analyze_step,
)
```

### Step 3: Build Your Workflow

```python
from pymastra import Workflow

workflow = Workflow(
    name="document_processor",
    trigger_schema=DocumentInput,
)

workflow.step(analyze).commit()
```

### Step 4: Execute

```python
import asyncio

async def main():
    doc = DocumentInput(
        title="Python Guide",
        content="Python is a programming language..."
    )

    run = await workflow.execute(doc)

    print(f"Status: {run.status}")
    print(f"Results: {run.outputs}")

asyncio.run(main())
```

## Real-World Example: Document Classification

Here's a complete example with **Human-in-the-Loop approval**:

```python
import asyncio
from pydantic import BaseModel
from pymastra import Workflow, Step, StepContext

# 1. Define schemas
class Document(BaseModel):
    title: str
    content: str

class Classification(BaseModel):
    category: str
    confidence: float

class Approval(BaseModel):
    approved: bool

# 2. Define steps
async def classify_step(ctx: StepContext):
    """Classify document (using simple heuristics)."""
    doc = ctx.trigger_data

    categories = {
        "legal": ["contract", "agreement", "terms"],
        "finance": ["invoice", "budget", "expense"],
        "hr": ["employee", "policy", "training"],
    }

    content_lower = doc.content.lower()

    for category, keywords in categories.items():
        if any(kw in content_lower for kw in keywords):
            return Classification(category=category, confidence=0.9)

    return Classification(category="general", confidence=0.5)

async def request_approval_step(ctx: StepContext):
    """Request human approval."""
    doc = ctx.trigger_data
    classification = ctx.outputs["classify"]

    # Pause for human review
    await ctx.suspend({
        "message": "Please review and approve",
        "title": doc.title,
        "classification": classification.category,
        "confidence": classification.confidence
    })

    # When human approves, this continues
    return Approval(approved=True)

async def process_step(ctx: StepContext):
    """Process the approved document."""
    doc = ctx.trigger_data
    approval = ctx.outputs["approval"]

    if approval.approved:
        return {"status": "processed", "message": "Document approved and processed"}
    else:
        return {"status": "rejected", "message": "Document was rejected"}

# 3. Build workflow
workflow = Workflow(
    name="document_workflow",
    trigger_schema=Document,
)

classify = Step(
    id="classify",
    description="Classify document",
    input_schema=Document,
    output_schema=Classification,
    execute=classify_step,
)

approval = Step(
    id="approval",
    description="Request approval",
    input_schema=Document,
    output_schema=Approval,
    execute=request_approval_step,
)

process = Step(
    id="process",
    description="Process document",
    input_schema=Document,
    output_schema=dict,
    execute=process_step,
)

workflow.step(classify).then(approval).then(process).commit()

# 4. Execute
async def main():
    doc = Document(
        title="Service Agreement",
        content="This is a legal contract between parties..."
    )

    run = await workflow.execute(doc)

    if run.status == "suspended":
        print("✋ Workflow paused - waiting for human approval")
        print(f"Context: {run.suspend_payload}")

        # Human approves
        final_run = await run.resume({"approved": True})
        print(f"✓ Approved! Final status: {final_run.status}")

    elif run.status == "completed":
        print(f"✓ Completed: {run.outputs}")

asyncio.run(main())
```

## Using LLM Integration

Pymastra makes it easy to add Claude or GPT-4:

```python
from pymastra import create_llm_step, LLMConfig

# Create an LLM-powered step
classify_step = create_llm_step(
    id="classify",
    description="Classify the document",
    system_prompt="""You are a document classifier.
    Classify the document as: legal, finance, hr, or general.
    Return: {"category": "...", "confidence": 0.0-1.0}""",
    llm_config=LLMConfig(
        provider="claude",
        model="claude-3-5-sonnet-20241022",
    ),
)

# Use in workflow
workflow.step(classify_step)...
```

## Using a Web Server with Dashboard

```python
from pymastra import server

# Create server with your workflows
app_server = server.create_server()
app_server.register_workflow("document_workflow", workflow)

# Get FastAPI app
app = app_server.get_app()

# Run: uvicorn main:app --reload
# Visit: http://localhost:8000/dashboard
```

## Storage Options

### Development (In-Memory)
```python
# Default - data in RAM, lost on restart
workflow = Workflow(name="test", trigger_schema=Input)
```

### Self-Hosted (SQLite)
```python
from pymastra import SQLiteStorage

storage = SQLiteStorage(db_path="workflows.db")
workflow = Workflow(name="app", trigger_schema=Input, storage=storage)
```

### Production (PostgreSQL)
```python
from pymastra import PostgresStorage

storage = PostgresStorage(
    dsn="postgresql://user:pass@host/pymastra"
)
workflow = Workflow(name="app", trigger_schema=Input, storage=storage)
```

## Step Chaining

### Sequential Execution
```python
workflow.step(step1).then(step2).then(step3).commit()
```

### Conditional Branching
```python
def should_approve(ctx):
    """Condition function."""
    return ctx.outputs["classify"].confidence > 0.8

workflow.step(classify)
workflow.branch(
    from_step="classify",
    condition=should_approve,
    to_step="process",
)
workflow.step(process).commit()
```

## Retries

Automatically retry failed steps:

```python
from pymastra import RetryConfig

step = Step(
    id="api_call",
    description="Call API",
    input_schema=Input,
    output_schema=Output,
    execute=my_function,
    retry=RetryConfig(
        max_attempts=3,
        delay_seconds=1.0,
        backoff="exponential"  # or "fixed"
    )
)
```

## Monitoring & Debugging

### View Run Details
```python
run = await workflow.execute(data)

print(f"Status: {run.status}")
print(f"Run ID: {run.run_id}")
print(f"Outputs: {run.outputs}")

if run.status == "suspended":
    print(f"Suspended at: {run.suspended_at_step}")
    print(f"Context: {run.suspend_payload}")
```

### Debugging Tools
```python
from pymastra import (
    print_workflow_structure,
    format_run_summary,
    get_metrics,
)

# Visualize workflow
print_workflow_structure(workflow)

# View run summary
print(format_run_summary(run))

# Get metrics
metrics = get_metrics()
print(metrics.get_summary())
```

## Webhooks

Trigger external services on events:

```python
from pymastra.webhooks import Webhook, get_webhook_registry
from pymastra.observability import EventType

registry = get_webhook_registry()

# Register webhook
webhook = Webhook(
    id="slack",
    url="https://hooks.slack.com/services/YOUR/WEBHOOK",
    events=[EventType.WORKFLOW_COMPLETE],
)
registry.register(webhook)

# Webhooks trigger automatically on events
```

## Common Patterns

### Pattern 1: Classification with Review

```
Input → Classify → [Manual Review] → Process → Output
```

### Pattern 2: Validation Pipeline

```
Input → Parse → Validate → [If Invalid: Review] → Save → Output
```

### Pattern 3: Multi-Approval

```
Input → Prepare → Approve1 → Approve2 → Execute → Output
```

### Pattern 4: Conditional Routing

```
Input → Analyze → [If High Priority] → Urgent Path
                   [If Normal] → Standard Path
```

## Next Steps

1. **Run Examples**
   ```bash
   # See examples directory
   python examples/basic_workflow.py
   python examples/document_classification.py
   ```

2. **Read Documentation**
   - [`DEBUGGING.md`](DEBUGGING.md) - Debug workflows
   - [`PERSISTENCE.md`](PERSISTENCE.md) - Storage options
   - [`PROJECT_STATUS.md`](PROJECT_STATUS.md) - Feature roadmap

3. **Check Examples**
   - `examples/basic_workflow.py` - Simple example
   - `examples/document_classification.py` - Real-world use case
   - `examples/server_with_dashboard.py` - Web interface
   - `examples/sqlite_persistence.py` - Database storage
   - `examples/agent_with_tools.py` - LLM with tools

4. **Run Benchmarks**
   ```bash
   python benchmarks/run_benchmarks.py
   ```

## Troubleshooting

### "Module not found: pymastra"
```bash
pip install pymastra
```

### "Cannot import: LLMClient"
```bash
# Install LLM support
pip install pymastra[llm]
```

### "Workflow must be committed"
```python
# Always call .commit() after building
workflow.step(step1).then(step2).commit()
```

### "ValidationError: Input data does not match schema"
```python
# Check your input data matches trigger_schema
print(workflow.trigger_schema.model_json_schema())
```

## Getting Help

- 📖 **Documentation**: See `DEBUGGING.md`, `PERSISTENCE.md`
- 💬 **Examples**: Check the `examples/` directory
- 🐛 **Issues**: Report at https://github.com/akashs101199/pymastra/issues
- 💡 **Ideas**: Start a discussion at https://github.com/akashs101199/pymastra/discussions

## What's Next?

### v0.2.0 (Coming Soon)
- Function calling for agents
- Advanced observability
- Webhook integrations
- Performance optimizations
- Production dashboards

### v1.0.0 (Roadmap)
- Stable API
- SaaS platform
- Cloud hosting
- Team collaboration
- Advanced analytics

## Architecture at a Glance

```
┌─────────────────────────────────────┐
│         Your Workflow               │
│  Step1 → Step2 → Step3 → Output     │
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│      Pymastra Engine                │
│  • Execution                        │
│  • Human-in-the-Loop               │
│  • Retry Logic                      │
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│      Storage & Integrations         │
│  • In-Memory                        │
│  • SQLite                          │
│  • PostgreSQL                      │
│  • Webhooks                        │
│  • LLMs (Claude, GPT-4)           │
└─────────────────────────────────────┘
```

---

**Happy building!** 🚀

Questions? Check the [examples](examples/) or file an [issue](https://github.com/akashs101199/pymastra/issues).
