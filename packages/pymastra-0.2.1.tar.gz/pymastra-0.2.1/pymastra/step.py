"""Step definition - unit of work in a workflow."""

from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.retry import RetryConfig


class Step:
    """A unit of work in a workflow.

    Steps are executed sequentially or conditionally in a workflow.
    Each step has input/output schemas for type safety.

    Attributes:
        id: Unique identifier for the step
        description: Human-readable description
        input_schema: Pydantic model for input validation
        output_schema: Pydantic model for output validation
        execute: Async function to execute the step
        retry: Retry configuration
    """

    def __init__(
        self,
        id: str,
        description: str,
        input_schema: type[BaseModel],
        output_schema: type[BaseModel],
        execute: Callable[[StepContext], Any],
        retry: RetryConfig | None = None,
    ) -> None:
        """Initialize a Step.

        Args:
            id: Unique step identifier
            description: Step description
            input_schema: Input Pydantic model
            output_schema: Output Pydantic model
            execute: Async function to execute
            retry: Retry configuration (optional)
        """
        self.id = id
        self.description = description
        self.input_schema = input_schema
        self.output_schema = output_schema
        self.execute = execute
        self.retry = retry or RetryConfig()

    async def __call__(self, ctx: StepContext) -> Any:
        """Execute the step.

        Args:
            ctx: Step execution context

        Returns:
            Step output
        """
        return await self.execute(ctx)
