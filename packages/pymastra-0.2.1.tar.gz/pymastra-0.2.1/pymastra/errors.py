"""Custom exceptions for Pymastra."""

from typing import Any


class PymaestraError(Exception):
    """Base exception for all Pymastra errors."""

    pass


class WorkflowValidationError(PymaestraError):
    """Raised when workflow configuration is invalid."""

    pass


class StepExecutionError(PymaestraError):
    """Raised when a step fails during execution."""

    pass


class SuspendError(PymaestraError):
    """Raised when a step needs to suspend for human input."""

    def __init__(self, message: str, payload: dict[str, Any] | None = None) -> None:
        """Initialize SuspendError.

        Args:
            message: Error message
            payload: Data to pass to human for review
        """
        super().__init__(message)
        self.payload = payload


class ResumeError(PymaestraError):
    """Raised when resuming a workflow fails."""

    pass


class StorageError(PymaestraError):
    """Raised when storage backend operations fail."""

    pass
