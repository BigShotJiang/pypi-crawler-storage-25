"""LLM integration for Pymastra.

Supports OpenAI and Claude APIs with a unified interface.
"""

import json
from typing import Any, Literal

try:
    import anthropic
except ImportError:
    anthropic = None  # type: ignore

try:
    import openai
except ImportError:
    openai = None  # type: ignore


LLMProvider = Literal["openai", "claude"]


class LLMConfig:
    """Configuration for LLM calls.

    Attributes:
        provider: "openai" or "claude"
        model: Model name (e.g., "gpt-4" or "claude-3-sonnet")
        api_key: API key for the provider
        temperature: Sampling temperature (0.0-1.0)
        max_tokens: Maximum tokens in response
    """

    def __init__(
        self,
        provider: LLMProvider = "claude",
        model: str = "claude-3-5-sonnet-20241022",
        api_key: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> None:
        """Initialize LLM configuration.

        Args:
            provider: LLM provider ("openai" or "claude")
            model: Model identifier
            api_key: API key (auto-read from env if not provided)
            temperature: Sampling temperature
            max_tokens: Max tokens in response
        """
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.temperature = temperature
        self.max_tokens = max_tokens

        # Validate provider
        if provider not in ("openai", "claude"):
            raise ValueError(f"Unknown provider: {provider}")

        # Validate imports
        if provider == "openai" and openai is None:
            raise ImportError("OpenAI library required. Install with: pip install openai")
        if provider == "claude" and anthropic is None:
            raise ImportError("Anthropic library required. Install with: pip install anthropic")


class LLMClient:
    """Unified client for LLM APIs."""

    def __init__(self, config: LLMConfig) -> None:
        """Initialize LLM client.

        Args:
            config: LLMConfig instance
        """
        self.config = config
        self.client: Any

        if config.provider == "openai":
            assert openai is not None
            self.client = openai.OpenAI(api_key=config.api_key)
        else:  # claude
            assert anthropic is not None
            self.client = anthropic.Anthropic(api_key=config.api_key)

    async def generate(
        self,
        prompt: str,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Generate text using LLM, optionally with tool calling.

        Args:
            prompt: The user prompt/message
            system: Optional system prompt/instructions
            tools: List of tool definitions for function calling
            **kwargs: Override config values (temperature, max_tokens, etc.)

        Returns:
            Dictionary with response content and optional tool calls

        Raises:
            ValueError: If API call fails
        """
        # Merge kwargs with config
        temperature = kwargs.get("temperature", self.config.temperature)
        max_tokens = kwargs.get("max_tokens", self.config.max_tokens)

        try:
            if self.config.provider == "openai":
                return await self._generate_openai(prompt, system, temperature, max_tokens, tools)
            else:  # claude
                return await self._generate_claude(prompt, system, temperature, max_tokens, tools)
        except Exception as e:
            raise ValueError(f"LLM generation failed: {e}") from e

    async def _generate_openai(
        self,
        prompt: str,
        system: str | None,
        temperature: float,
        max_tokens: int,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Generate using OpenAI API."""
        import asyncio

        def _call() -> dict[str, Any]:
            assert openai is not None
            assert self.client is not None
            messages: list[dict[str, Any]] = []

            if system:
                messages.append({"role": "system", "content": system})

            messages.append({"role": "user", "content": prompt})

            # Build request kwargs
            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }

            # Add tools if provided
            if tools:
                request_kwargs["tools"] = [{"type": "function", "function": tool} for tool in tools]

            response = self.client.chat.completions.create(**request_kwargs)

            # Extract response
            result: dict[str, Any] = {}
            message = response.choices[0].message

            # Check for tool calls
            if message.tool_calls:
                result["tool_calls"] = [
                    {
                        "tool": call.function.name,
                        "args": json.loads(call.function.arguments),
                    }
                    for call in message.tool_calls
                ]
            else:
                # Regular text response
                content = message.content
                if content is None:
                    raise ValueError("Empty response from OpenAI")
                result["content"] = content

            return result

        # Run sync function in thread pool for async context
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _call)

    async def _generate_claude(
        self,
        prompt: str,
        system: str | None,
        temperature: float,
        max_tokens: int,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Generate using Claude API."""
        import asyncio

        def _call() -> dict[str, Any]:
            assert anthropic is not None
            assert self.client is not None

            # Build request kwargs
            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "max_tokens": max_tokens,
                "system": system or "",
                "messages": [
                    {
                        "role": "user",
                        "content": prompt,
                    }
                ],
                "temperature": temperature,
            }

            # Add tools if provided
            if tools:
                request_kwargs["tools"] = tools

            response = self.client.messages.create(**request_kwargs)  # type: ignore[attr-defined]

            # Extract response
            result: dict[str, Any] = {}

            # Process response content blocks
            for block in response.content:
                if block.type == "text":
                    result["content"] = block.text
                elif block.type == "tool_use":
                    if "tool_calls" not in result:
                        result["tool_calls"] = []
                    result["tool_calls"].append(
                        {
                            "tool": block.name,
                            "args": block.input,
                        }
                    )

            return result

        # Run sync function in thread pool for async context
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _call)

    def count_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Args:
            text: Text to count tokens for

        Returns:
            Approximate token count
        """
        # Simple estimation: ~4 chars per token
        # For production, use provider-specific token counting
        return len(text) // 4
