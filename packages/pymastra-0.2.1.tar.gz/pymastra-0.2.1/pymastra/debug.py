"""Debugging utilities for Pymastra workflows."""

import json
from typing import Any

from pymastra.run import WorkflowRun


def format_run_summary(run: WorkflowRun) -> str:
    """Format a workflow run summary for debugging.

    Args:
        run: WorkflowRun to summarize

    Returns:
        Formatted string with run details
    """
    lines = [
        "╔ Workflow Run Summary",
        f"║ Run ID: {run.run_id}",
        f"║ Status: {run.status}",
    ]

    if run.suspended_at_step:
        lines.append(f"║ Suspended at: {run.suspended_at_step}")

    lines.append(f"║ Outputs: {len(run.outputs)} step(s)")
    for step_id, output in run.outputs.items():
        output_type = type(output).__name__
        lines.append(f"║   - {step_id}: {output_type}")

    if run.suspend_payload:
        lines.append(f"║ Suspension context: {len(run.suspend_payload)} key(s)")
        for key in run.suspend_payload:
            lines.append(f"║   - {key}")

    lines.append("╚")
    return "\n".join(lines)


def format_step_context(step_id: str, outputs: dict[str, Any], trigger_data: Any) -> str:
    """Format step execution context for debugging.

    Args:
        step_id: Current step ID
        outputs: Dictionary of outputs so far
        trigger_data: Original trigger data

    Returns:
        Formatted context string
    """
    lines = [
        f"╔ Step Context: {step_id}",
        "║ Available outputs from previous steps:",
    ]

    if outputs:
        for out_step_id, output in outputs.items():
            output_type = type(output).__name__
            lines.append(f"║   - {out_step_id}: {output_type}")
    else:
        lines.append("║   (no previous outputs)")

    lines.append(f"║ Trigger data: {type(trigger_data).__name__}")
    lines.append("╚")
    return "\n".join(lines)


def format_validation_error(
    step_id: str,
    schema_name: str,
    error_details: str,
    received_data: Any | None = None,
) -> str:
    """Format a validation error for better readability.

    Args:
        step_id: Step that had validation error
        schema_name: Name of schema that failed
        error_details: Detailed error message
        received_data: Data that failed validation

    Returns:
        Formatted error string
    """
    lines = [
        f"╔ Validation Error in Step: {step_id}",
        f"║ Expected schema: {schema_name}",
        "║",
        "║ Issues:",
    ]

    # Try to format error details nicely
    for line in error_details.split("\n"):
        if line.strip():
            lines.append(f"║   {line}")

    if received_data:
        lines.append("║")
        lines.append("║ Received:")
        try:
            data_str = json.dumps(received_data, indent=2, default=str)
            for line in data_str.split("\n"):
                lines.append(f"║   {line}")
        except Exception:
            lines.append(f"║   {received_data}")

    lines.append("╚")
    return "\n".join(lines)


def print_workflow_structure(workflow: Any) -> None:
    """Print workflow structure for debugging.

    Args:
        workflow: Workflow to debug
    """
    print(f"╔ Workflow: {workflow.name}")
    print(f"║ Committed: {workflow._committed}")
    print(f"║ Steps ({len(workflow.steps)}):")

    for i, step in enumerate(workflow.steps):
        print(f"║   {i + 1}. {step.id}")
        print(f"║      Description: {step.description}")
        print(f"║      Input: {step.input_schema.__name__}")
        print(f"║      Output: {step.output_schema.__name__}")
        if step.retry.max_attempts > 1:
            print(
                f"║      Retry: {step.retry.max_attempts} attempts ({step.retry.backoff} backoff)"
            )

    if workflow.branches:
        print("║ Branches:")
        for from_step, branch_list in workflow.branches.items():
            for _condition, to_step in branch_list:
                print(f"║   {from_step} -> {to_step} (conditional)")

    print("╚")
