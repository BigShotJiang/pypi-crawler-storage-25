"""Retry logic and configuration for step execution."""

import asyncio
from typing import Literal


class RetryConfig:
    """Configuration for retrying failed steps.

    Attributes:
        max_attempts: Maximum number of attempts (including first try)
        delay_seconds: Base delay between retries in seconds
        backoff: Type of backoff strategy ('fixed' or 'exponential')
        retry_on: List of exception types to retry on (None = all exceptions)
    """

    def __init__(
        self,
        max_attempts: int = 1,
        delay_seconds: float = 1.0,
        backoff: Literal["fixed", "exponential"] = "exponential",
        retry_on: list[type[Exception]] | None = None,
    ) -> None:
        """Initialize RetryConfig.

        Args:
            max_attempts: Maximum retry attempts (default 1, no retries)
            delay_seconds: Base delay between retries
            backoff: Backoff strategy ('fixed' or 'exponential')
            retry_on: Exception types to retry on
        """
        self.max_attempts = max(1, max_attempts)
        self.delay_seconds = delay_seconds
        self.backoff = backoff
        self.retry_on = retry_on

    def should_retry(self, exception: Exception) -> bool:
        """Check if an exception should trigger a retry.

        Args:
            exception: The exception that occurred

        Returns:
            True if should retry, False otherwise
        """
        if self.retry_on is None:
            return True
        return any(isinstance(exception, exc_type) for exc_type in self.retry_on)

    def get_delay(self, attempt: int) -> float:
        """Get delay for a specific attempt.

        Args:
            attempt: Attempt number (0-indexed)

        Returns:
            Delay in seconds
        """
        if self.backoff == "fixed":
            return self.delay_seconds
        # exponential backoff
        return float(self.delay_seconds * (2**attempt))

    async def wait(self, attempt: int) -> None:
        """Wait for the appropriate delay before retry.

        Args:
            attempt: Attempt number (0-indexed)
        """
        delay = self.get_delay(attempt)
        await asyncio.sleep(delay)
