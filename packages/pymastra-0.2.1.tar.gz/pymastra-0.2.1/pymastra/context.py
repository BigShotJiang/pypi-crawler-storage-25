"""StepContext passed to every step's execute function."""

from typing import Any

from pydantic import BaseModel

from pymastra.errors import SuspendError


class StepContext:
    """Runtime context passed to every step's execute function.

    Attributes:
        trigger_data: The original trigger payload (BaseModel instance).
        outputs: Dictionary of outputs from all previous steps, keyed by step_id.
        step_id: The current step's ID.
        run_id: Unique identifier for this workflow run.
        _suspend_fn: Internal callback to suspend execution.
    """

    def __init__(
        self,
        trigger_data: BaseModel,
        outputs: dict[str, BaseModel],
        step_id: str,
        run_id: str,
        suspend_fn: Any = None,
    ) -> None:
        """Initialize StepContext.

        Args:
            trigger_data: The original trigger payload.
            outputs: Dictionary of step outputs.
            step_id: Current step's ID.
            run_id: Workflow run ID.
            suspend_fn: Internal callback for suspension (optional).
        """
        self.trigger_data = trigger_data
        self.outputs = outputs
        self.step_id = step_id
        self.run_id = run_id
        self._suspend_fn = suspend_fn

    async def suspend(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Pause execution and wait for human input.

        Args:
            payload: Data to expose to human during suspension.

        Returns:
            Dictionary containing human input when resumed.

        Raises:
            SuspendError: Always raised to signal suspension to the workflow engine.
        """
        raise SuspendError(str(payload), payload=payload)
