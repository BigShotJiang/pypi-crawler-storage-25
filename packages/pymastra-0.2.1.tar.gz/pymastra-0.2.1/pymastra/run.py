"""WorkflowRun - execution state and handle for a running workflow."""

import uuid
from typing import Any

from pydantic import ValidationError

from pymastra.errors import ResumeError
from pymastra.storage import StorageBackend, WorkflowRunState


class WorkflowRun:
    """Represents a running or completed workflow execution.

    Tracks:
    - Execution status (running, suspended, completed, failed)
    - Outputs from each completed step
    - Suspension context for human review
    - Run metadata and identifiers

    Attributes:
        run_id: Unique run identifier
        workflow: The workflow being executed
        storage: Storage backend for persistence
        status: Current status (running, suspended, completed, failed)
        outputs: Dictionary of step outputs
        suspend_payload: Data provided when suspended
        suspended_at_step: Which step caused suspension
    """

    def __init__(
        self,
        run_id: str | None = None,
        workflow: Any = None,
        storage: StorageBackend | None = None,
        status: str = "running",
        outputs: dict[str, Any] | None = None,
        suspend_payload: dict[str, Any] | None = None,
        suspended_at_step: str | None = None,
    ) -> None:
        """Initialize a WorkflowRun.

        Args:
            run_id: Unique run ID (auto-generated if not provided)
            workflow: The workflow being executed
            storage: Storage backend for saving run state
            status: Initial status
            outputs: Initial outputs dictionary
            suspend_payload: Suspension context data
            suspended_at_step: Step that caused suspension
        """
        self.run_id = run_id or str(uuid.uuid4())
        self.workflow = workflow
        self.storage = storage
        self.status = status
        self.outputs = outputs or {}
        self.suspend_payload = suspend_payload
        self.suspended_at_step = suspended_at_step

    async def save(self, workflow_id: str = "unknown") -> None:
        """Save run state to storage.

        Args:
            workflow_id: ID of the workflow
        """
        if not self.storage:
            return

        state = WorkflowRunState(
            run_id=self.run_id,
            workflow_id=workflow_id,
            status=self.status,
            outputs=self.outputs,
            suspend_payload=self.suspend_payload,
            suspended_at_step=self.suspended_at_step,
        )
        await self.storage.save_run(state)

    async def resume(self, human_input: dict[str, Any]) -> "WorkflowRun":
        """Resume a suspended workflow with human input.

        Args:
            human_input: Human's response to suspension

        Returns:
            Updated WorkflowRun

        Raises:
            ResumeError: If resume fails
        """
        if self.status != "suspended":
            raise ResumeError(
                f"Cannot resume workflow run '{self.run_id}': "
                f"workflow is in '{self.status}' status, not 'suspended'.\n"
                f"Only suspended workflows can be resumed. "
                f"If the workflow is already completed or failed, resumption is not possible."
            )

        if not self.suspended_at_step:
            raise ResumeError(
                f"Cannot resume workflow run '{self.run_id}': "
                "the suspension step information is missing.\n"
                "This indicates a data integrity issue. "
                "The workflow may have been corrupted or loaded from an incomplete state."
            )

        if not self.workflow:
            raise ResumeError(
                f"Cannot resume workflow run '{self.run_id}': "
                "the workflow object is not available.\n"
                "The workflow instance must be set for resume to work. "
                "This typically happens when a run is loaded from storage "
                "without its corresponding workflow definition."
            )

        # Get the suspended step to validate human input
        suspended_step = None
        for step in self.workflow.steps:
            if step.id == self.suspended_at_step:
                suspended_step = step
                break

        if not suspended_step:
            available_steps = [s.id for s in self.workflow.steps]
            raise ResumeError(
                f"Cannot resume workflow run '{self.run_id}': "
                f"step '{self.suspended_at_step}' not found in workflow.\n"
                f"Available steps: {available_steps}\n"
                "This may indicate the workflow definition changed "
                "since the workflow was suspended."
            )

        # Validate human input against the step's output schema
        try:
            validated_input = suspended_step.output_schema(**human_input)
        except ValidationError as e:
            error_details = "\n".join(
                f"  - {err['loc'][0]}: {err['msg']} (expected {err['type']})" for err in e.errors()
            )
            raise ResumeError(
                f"Human input validation failed for workflow run '{self.run_id}'.\n"
                f"Step '{self.suspended_at_step}' expects:\n"
                f"  Schema: {suspended_step.output_schema.__name__}\n"
                f"Validation errors:\n{error_details}\n"
                f"Received: {human_input}"
            ) from e

        # Add validated input to outputs
        self.outputs[self.suspended_at_step] = validated_input

        # Resume execution from the next step
        result: WorkflowRun = await self.workflow._resume_execution(self)
        return result
