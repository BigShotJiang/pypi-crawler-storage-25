"""Workflow - directed graph of steps with execution orchestration."""

from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, ValidationError

from pymastra.context import StepContext
from pymastra.errors import StepExecutionError, SuspendError, WorkflowValidationError
from pymastra.run import WorkflowRun
from pymastra.step import Step
from pymastra.storage import MemoryStorage, StorageBackend


class Workflow:
    """A workflow is a directed graph of steps executed in sequence.

    Steps can branch conditionally based on outputs.
    Supports human-in-the-loop suspension and resume.

    Attributes:
        name: Workflow identifier
        trigger_schema: Pydantic model for trigger data
        steps: List of steps in the workflow
        branches: Conditional routing rules
        storage: Storage backend for run persistence
    """

    def __init__(
        self,
        name: str,
        trigger_schema: type[BaseModel],
        storage: StorageBackend | None = None,
    ) -> None:
        """Initialize a Workflow.

        Args:
            name: Workflow name/identifier
            trigger_schema: Pydantic model for input validation
            storage: Storage backend (defaults to MemoryStorage)
        """
        self.name = name
        self.trigger_schema = trigger_schema
        self.storage = storage or MemoryStorage()
        self.steps: list[Step] = []
        self.branches: dict[str, list[tuple[Callable[[StepContext], bool], str]]] = {}
        self._committed = False

    def step(self, step: Step) -> "Workflow":
        """Add a step to the workflow.

        Args:
            step: Step to add

        Returns:
            Self for chaining
        """
        self.steps.append(step)
        return self

    def then(self, step: Step) -> "Workflow":
        """Add a step after the previous one (alias for step).

        Args:
            step: Step to add

        Returns:
            Self for chaining
        """
        return self.step(step)

    def branch(
        self,
        from_step: str,
        condition: Callable[[StepContext], bool],
        to_step: str,
    ) -> "Workflow":
        """Add a conditional branch.

        Args:
            from_step: Source step ID
            condition: Async function that returns True to follow this branch
            to_step: Destination step ID

        Returns:
            Self for chaining
        """
        if from_step not in self.branches:
            self.branches[from_step] = []
        self.branches[from_step].append((condition, to_step))
        return self

    def commit(self) -> "Workflow":
        """Finalize and validate the workflow.

        Returns:
            Self

        Raises:
            WorkflowValidationError: If workflow is invalid
        """
        # Validate that all steps have unique IDs
        step_ids = [s.id for s in self.steps]
        if len(step_ids) != len(set(step_ids)):
            duplicates = [sid for sid in step_ids if step_ids.count(sid) > 1]
            raise WorkflowValidationError(
                f"Duplicate step IDs found in workflow '{self.name}': {duplicates}. "
                "Each step must have a unique ID."
            )

        # Validate that all branch destinations exist
        step_id_set = set(step_ids)
        for from_step, branch_list in self.branches.items():
            if from_step not in step_id_set:
                raise WorkflowValidationError(
                    f"Branch source step '{from_step}' not found in workflow '{self.name}'. "
                    f"Available steps: {sorted(step_id_set)}. "
                    "Did you mean one of these?"
                )
            for _, to_step in branch_list:
                if to_step not in step_id_set:
                    raise WorkflowValidationError(
                        f"Branch destination step '{to_step}' not found in workflow '{self.name}'. "
                        f"Available steps: {sorted(step_id_set)}. "
                        "Check that all branch destinations are added with .step() or .then()."
                    )

        self._committed = True
        return self

    async def execute(self, trigger_data: Any) -> WorkflowRun:
        """Execute the workflow with trigger data.

        Args:
            trigger_data: Input data (will be validated against trigger_schema)

        Returns:
            WorkflowRun with execution results

        Raises:
            WorkflowValidationError: If workflow is not committed or input invalid
            StepExecutionError: If a step fails
        """
        if not self._committed:
            raise WorkflowValidationError(
                f"Cannot execute workflow '{self.name}': workflow must be committed first. "
                "Call .commit() after building the workflow with .step() and .then()."
            )

        # Validate trigger data
        try:
            if isinstance(trigger_data, dict):
                validated_trigger = self.trigger_schema(**trigger_data)
            else:
                validated_trigger = trigger_data
        except ValidationError as e:
            error_details = "\n".join(f"  - {err['loc'][0]}: {err['msg']}" for err in e.errors())
            raise WorkflowValidationError(
                f"Trigger data validation failed for workflow '{self.name}'.\n"
                f"Expected schema: {self.trigger_schema.__name__}\n"
                f"Validation errors:\n{error_details}"
            ) from e

        # Create workflow run
        run = WorkflowRun(
            workflow=self,
            storage=self.storage,
            status="running",
        )

        # Execute steps starting from the first one
        return await self._execute_steps(run, validated_trigger)

    async def _execute_steps(self, run: WorkflowRun, trigger_data: Any) -> WorkflowRun:
        """Execute workflow steps sequentially.

        Args:
            run: Workflow run to execute
            trigger_data: Validated trigger data

        Returns:
            Updated WorkflowRun
        """
        current_step_idx = 0

        while current_step_idx < len(self.steps):
            step = self.steps[current_step_idx]

            # Execute step with retry logic
            try:
                result = await self._execute_step_with_retry(step, run, trigger_data)
                run.outputs[step.id] = result

            except SuspendError as e:
                # Handle suspension
                run.status = "suspended"
                run.suspend_payload = e.payload
                run.suspended_at_step = step.id
                await run.save(self.name)
                return run

            except Exception as e:
                # Handle execution error
                run.status = "failed"
                await run.save(self.name)
                raise StepExecutionError(
                    f"Step '{step.id}' in workflow '{self.name}' failed during execution.\n"
                    f"Description: {step.description}\n"
                    f"Error: {type(e).__name__}: {str(e)}\n"
                    f"Run ID: {run.run_id}\n"
                    f"Previous outputs: {list(run.outputs.keys())}"
                ) from e

            # Determine next step via branching
            next_step_idx = await self._get_next_step(step, current_step_idx, run, trigger_data)
            if next_step_idx is None:
                # No more steps
                break
            current_step_idx = next_step_idx

        # Workflow completed
        run.status = "completed"
        await run.save(self.name)
        return run

    async def _execute_step_with_retry(
        self, step: Step, run: WorkflowRun, trigger_data: Any
    ) -> Any:
        """Execute a step with retry logic.

        Args:
            step: Step to execute
            run: Current workflow run
            trigger_data: Trigger data

        Returns:
            Step output

        Raises:
            Exception: If all retries exhausted
        """
        attempt = 0
        last_exception = None

        while attempt < step.retry.max_attempts:
            try:
                # Create context
                ctx = StepContext(
                    trigger_data=trigger_data,
                    outputs=run.outputs,
                    step_id=step.id,
                    run_id=run.run_id,
                )

                # Execute step
                result = await step(ctx)
                return result

            except Exception as e:
                last_exception = e
                if not step.retry.should_retry(e):
                    raise
                attempt += 1
                if attempt < step.retry.max_attempts:
                    await step.retry.wait(attempt - 1)

        if last_exception:
            raise last_exception
        return None

    async def _get_next_step(
        self,
        current_step: Step,
        current_idx: int,
        run: WorkflowRun,
        trigger_data: Any,
    ) -> int | None:
        """Determine the next step to execute (with branching).

        Args:
            current_step: Currently executed step
            current_idx: Index of current step
            run: Current workflow run
            trigger_data: Trigger data

        Returns:
            Index of next step or None if workflow ends
        """
        # Check for branches from current step
        if current_step.id in self.branches:
            ctx = StepContext(
                trigger_data=trigger_data,
                outputs=run.outputs,
                step_id=current_step.id,
                run_id=run.run_id,
            )

            for condition, to_step_id in self.branches[current_step.id]:
                if condition(ctx):
                    # Find the destination step index
                    for idx, step in enumerate(self.steps):
                        if step.id == to_step_id:
                            return idx
                    return None

        # Default: next sequential step
        next_idx = current_idx + 1
        if next_idx < len(self.steps):
            return next_idx
        return None

    async def _resume_execution(self, run: WorkflowRun) -> WorkflowRun:
        """Resume execution after human input.

        Args:
            run: WorkflowRun with human input added

        Returns:
            Updated WorkflowRun
        """
        # Find the suspended step index
        suspended_idx = None
        for idx, step in enumerate(self.steps):
            if step.id == run.suspended_at_step:
                suspended_idx = idx
                break

        if suspended_idx is None:
            available_steps = [s.id for s in self.steps]
            raise StepExecutionError(
                f"Cannot resume workflow '{self.name}': suspended step "
                f"'{run.suspended_at_step}' not found.\n"
                f"Available steps: {available_steps}\n"
                f"This may indicate the workflow structure changed since suspension."
            )

        # Continue from next step
        run.status = "running"
        return await self._execute_steps(run, run.outputs.get("_trigger_data"))
