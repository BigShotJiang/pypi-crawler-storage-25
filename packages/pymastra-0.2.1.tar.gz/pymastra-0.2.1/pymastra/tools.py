"""Tool/function calling support for LLM agents."""

import inspect
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, create_model


class Tool:
    """A tool that an LLM agent can call.

    Wraps a Python function with schema information for the LLM.

    Attributes:
        name: Tool identifier
        description: What the tool does
        func: The Python function to execute
        input_schema: Pydantic model for input validation
    """

    def __init__(
        self,
        func: Callable[..., Any],
        name: str | None = None,
        description: str | None = None,
    ) -> None:
        """Initialize a Tool.

        Args:
            func: The function to wrap
            name: Tool name (defaults to function name)
            description: Tool description (defaults to function docstring)
        """
        self.func = func
        self.name = name or func.__name__
        self.description = description or (func.__doc__ or "").strip()

        # Extract input schema from function signature
        self.input_schema = self._build_input_schema()

    def _build_input_schema(self) -> type[BaseModel]:
        """Build Pydantic schema from function signature."""
        sig = inspect.signature(self.func)
        fields = {}

        for param_name, param in sig.parameters.items():
            if param_name == "self":
                continue

            # Get type annotation
            param_type = param.annotation
            if param_type == inspect.Parameter.empty:
                param_type = Any

            # Check if optional
            if param.default == inspect.Parameter.empty:
                fields[param_name] = (param_type, ...)
            else:
                fields[param_name] = (param_type, param.default)

        # Create Pydantic model dynamically
        return create_model(  # type: ignore[call-overload, no-any-return]
            f"{self.name}_input",
            **fields,
        )

    async def call(self, **kwargs: Any) -> Any:
        """Execute the tool.

        Args:
            **kwargs: Arguments to pass to the function

        Returns:
            Function result
        """
        # Validate input
        validated = self.input_schema(**kwargs)

        # Convert to dict for function call
        call_kwargs = validated.model_dump()

        # Execute function
        if inspect.iscoroutinefunction(self.func):
            return await self.func(**call_kwargs)
        else:
            return self.func(**call_kwargs)

    def to_dict(self) -> dict[str, Any]:
        """Convert tool to dictionary for LLM.

        Returns:
            Dictionary with tool schema for LLM
        """
        schema = self.input_schema.model_json_schema()

        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": schema.get("properties", {}),
                "required": schema.get("required", []),
            },
        }


class ToolRegistry:
    """Registry of tools available to LLM agents.

    Manages tool definitions and execution.
    """

    def __init__(self) -> None:
        """Initialize tool registry."""
        self.tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        """Register a tool.

        Args:
            tool: Tool to register
        """
        self.tools[tool.name] = tool

    def register_function(
        self,
        func: Callable[..., Any],
        name: str | None = None,
        description: str | None = None,
    ) -> Tool:
        """Register a Python function as a tool.

        Args:
            func: Function to register
            name: Tool name (defaults to function name)
            description: Tool description

        Returns:
            The registered Tool
        """
        tool = Tool(func, name=name, description=description)
        self.register(tool)
        return tool

    def get_tool(self, name: str) -> Tool | None:
        """Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool if found, None otherwise
        """
        return self.tools.get(name)

    def list_tools(self) -> list[dict[str, Any]]:
        """Get all tools as dictionaries for LLM.

        Returns:
            List of tool dictionaries
        """
        return [tool.to_dict() for tool in self.tools.values()]

    async def execute_tool(self, name: str, **kwargs: Any) -> Any:
        """Execute a tool by name.

        Args:
            name: Tool name
            **kwargs: Arguments for the tool

        Returns:
            Tool result

        Raises:
            ValueError: If tool not found
        """
        tool = self.get_tool(name)
        if not tool:
            raise ValueError(f"Tool '{name}' not found. Available tools: {list(self.tools.keys())}")

        try:
            return await tool.call(**kwargs)
        except Exception as e:
            raise ValueError(f"Tool '{name}' execution failed: {e}") from e


def tool(
    func: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
) -> Callable[[Callable[..., Any]], Tool] | Tool:
    """Decorator to mark a function as a tool.

    Args:
        func: Function to decorate (when used without arguments)
        name: Override function name
        description: Override function description

    Returns:
        Decorator function or Tool

    Example:
        @tool
        def get_weather(city: str) -> str:
            '''Get the weather for a city.'''
            # implementation
            return "sunny"

        @tool(name="weather", description="Get weather data")
        async def fetch_weather(city: str) -> dict:
            # implementation
            pass
    """

    def decorator(f: Callable[..., Any]) -> Tool:
        return Tool(f, name=name, description=description)

    # Handle both @tool and @tool() syntax
    if func is not None:
        return decorator(func)

    return decorator
