"""Pymastra — Python-native workflow engine with Human-in-the-Loop support."""

from pymastra.context import StepContext
from pymastra.debug import (
    format_run_summary,
    format_step_context,
    format_validation_error,
    print_workflow_structure,
)
from pymastra.errors import (
    PymaestraError,
    ResumeError,
    StepExecutionError,
    StorageError,
    SuspendError,
    WorkflowValidationError,
)
from pymastra.llm import LLMClient, LLMConfig, LLMProvider
from pymastra.llm_step import (
    LLMChain,
    LLMOutput,
    ToolCallOutput,
    create_llm_step,
    create_tool_calling_step,
)
from pymastra.observability import (
    Event,
    EventLogger,
    EventType,
    Metrics,
    Span,
    TraceContext,
    get_event_logger,
    get_metrics,
)
from pymastra.tools import Tool, ToolRegistry, tool

try:
    from pymastra.webhooks import Webhook, WebhookRegistry, get_webhook_registry
except ImportError:
    Webhook = None  # type: ignore
    WebhookRegistry = None  # type: ignore
    get_webhook_registry = None  # type: ignore

from pymastra.retry import RetryConfig
from pymastra.run import WorkflowRun
from pymastra.step import Step
from pymastra.storage import (
    MemoryStorage,
    PostgresStorage,
    SQLiteStorage,
    StorageBackend,
    WorkflowRunState,
)
from pymastra.workflow import Workflow

try:
    from pymastra import server
except ImportError:
    server = None  # type: ignore

__version__ = "0.2.0"

__all__ = [
    # Core primitives
    "Step",
    "Workflow",
    "StepContext",
    "WorkflowRun",
    # Retry
    "RetryConfig",
    # LLM
    "LLMClient",
    "LLMConfig",
    "LLMProvider",
    "create_llm_step",
    "LLMOutput",
    "LLMChain",
    # Tools & Function Calling
    "Tool",
    "ToolRegistry",
    "tool",
    "ToolCallOutput",
    "create_tool_calling_step",
    # Errors
    "PymaestraError",
    "WorkflowValidationError",
    "StepExecutionError",
    "SuspendError",
    "ResumeError",
    "StorageError",
    # Storage
    "StorageBackend",
    "WorkflowRunState",
    "MemoryStorage",
    "SQLiteStorage",
    "PostgresStorage",
    # Debugging
    "format_run_summary",
    "format_step_context",
    "format_validation_error",
    "print_workflow_structure",
    # Observability
    "EventType",
    "Event",
    "Span",
    "Metrics",
    "EventLogger",
    "TraceContext",
    "get_metrics",
    "get_event_logger",
    # Webhooks
    "Webhook",
    "WebhookRegistry",
    "get_webhook_registry",
]
