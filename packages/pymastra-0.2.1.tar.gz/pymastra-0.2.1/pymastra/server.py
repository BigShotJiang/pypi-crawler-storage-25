"""FastAPI server for Pymastra workflows.

Provides REST API for:
- Creating and executing workflows
- Checking run status
- Getting suspension data for human review
- Resuming suspended workflows
- Listing workflow runs
- Serving approval dashboard UI
"""

import contextlib
import os
from typing import Any

from fastapi import Body, Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from pymastra.run import WorkflowRun
from pymastra.storage import MemoryStorage, StorageBackend
from pymastra.workflow import Workflow

try:
    from slowapi import Limiter
    from slowapi.errors import RateLimitExceeded
    from slowapi.util import get_remote_address

    SLOWAPI_AVAILABLE = True
except ImportError:
    SLOWAPI_AVAILABLE = False
    Limiter = None  # type: ignore
    get_remote_address = None  # type: ignore
    RateLimitExceeded = None  # type: ignore


class ExecuteRequest(BaseModel):
    """Request to execute a workflow."""

    workflow_id: str
    """Workflow identifier"""
    data: dict[str, Any]
    """Trigger data for the workflow"""


class ExecuteResponse(BaseModel):
    """Response from workflow execution."""

    run_id: str
    """Unique run ID"""
    status: str
    """Current status: running, suspended, completed, failed"""
    outputs: dict[str, Any] | None = None
    """Outputs from completed steps"""
    suspend_payload: dict[str, Any] | None = None
    """Data if suspended, waiting for human input"""
    suspended_at_step: str | None = None
    """Which step is suspended"""


class ResumeRequest(BaseModel):
    """Request to resume a suspended workflow."""

    human_input: dict[str, Any]
    """Human's response/approval"""


class WorkflowServer:
    """FastAPI server for Pymastra workflows."""

    def __init__(
        self,
        storage: StorageBackend | None = None,
        api_key: str | None = None,
        auth_enabled: bool = False,
        rate_limit: int = 100,
        cors_origins: list[str] | None = None,
        debug: bool = False,
    ) -> None:
        """Initialize workflow server.

        Args:
            storage: Storage backend for runs (defaults to MemoryStorage)
            api_key: API key for authentication (default: env var PYMASTRA_API_KEY)
            auth_enabled: Enable API key authentication
            rate_limit: Rate limit in requests per minute (0 to disable)
            cors_origins: List of allowed CORS origins
            debug: Enable debug mode (not recommended for production)
        """
        self.app = FastAPI(title="Pymastra Workflow Server", version="0.2.0")
        self.storage = storage or MemoryStorage()
        self.workflows: dict[str, Workflow] = {}
        self.active_runs: dict[str, WorkflowRun] = {}
        self.debug = debug

        # Security configuration
        self.auth_enabled = auth_enabled
        self.api_key = api_key or os.environ.get("PYMASTRA_API_KEY")
        if auth_enabled and not self.api_key:
            raise ValueError(
                "auth_enabled=True but no api_key provided and PYMASTRA_API_KEY not set"
            )

        # Rate limiting setup
        self.rate_limit_enabled = rate_limit > 0 and SLOWAPI_AVAILABLE
        if SLOWAPI_AVAILABLE and rate_limit > 0:
            self.limiter = Limiter(key_func=get_remote_address)
            self.app.state.limiter = self.limiter
        else:
            self.limiter = None

        # CORS configuration
        if cors_origins is not None:
            self.app.add_middleware(
                CORSMiddleware,
                allow_origins=cors_origins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )

        # Try to mount static files for dashboard
        static_dir = self._get_static_dir()
        if static_dir and os.path.isdir(static_dir):
            with contextlib.suppress(Exception):
                self.app.mount(
                    "/static",
                    StaticFiles(directory=static_dir),
                    name="static",
                )

        # Setup routes
        self._setup_routes()

    def _verify_api_key(self, authorization: str | None = Header(None)) -> None:  # noqa: B008
        """Verify API key from Authorization header.

        Args:
            authorization: Authorization header value

        Raises:
            HTTPException: If authentication fails
        """
        if not self.auth_enabled:
            return

        if not authorization:
            raise HTTPException(
                status_code=401,
                detail="Missing Authorization header",
            )

        # Support both "Bearer <key>" and plain key formats
        token = authorization[7:] if authorization.startswith("Bearer ") else authorization

        if not token or token != self.api_key:
            raise HTTPException(
                status_code=401,
                detail="Invalid API key",
            )

    def _setup_routes(self) -> None:
        """Setup API routes."""

        @self.app.get("/health")
        async def health() -> dict[str, str]:
            """Health check endpoint."""
            return {"status": "healthy"}

        @self.app.get("/")
        async def root() -> FileResponse:
            """Serve the approval dashboard."""
            dashboard_path = self._get_dashboard_path()
            if dashboard_path and os.path.exists(dashboard_path):
                return FileResponse(dashboard_path, media_type="text/html")
            # Fallback to simple welcome page
            return FileResponse(
                path=os.devnull,
                media_type="text/html",
                headers={
                    "content": "<h1>Pymastra Workflow Server</h1>"
                    "<p>Access the dashboard at /dashboard</p>"
                },
            )

        @self.app.get("/dashboard")
        async def dashboard() -> FileResponse:
            """Serve the approval dashboard."""
            dashboard_path = self._get_dashboard_path()
            if dashboard_path and os.path.exists(dashboard_path):
                return FileResponse(dashboard_path, media_type="text/html")
            raise HTTPException(
                status_code=404,
                detail="Dashboard not found. Make sure static/dashboard.html exists.",
            )

        @self.app.get("/api/runs")
        async def list_runs(
            _: None = Depends(self._verify_api_key),
        ) -> dict[str, list[dict[str, Any]]]:
            """Get all active workflow runs.

            Returns:
                Dictionary with list of run information
            """
            if self.rate_limit_enabled:
                self.limiter.limit("100/minute")(lambda: None)()
            runs_info = []
            for run_id, run in self.active_runs.items():
                runs_info.append(
                    {
                        "run_id": run_id,
                        "status": run.status,
                        "outputs": run.outputs,
                        "suspend_payload": run.suspend_payload,
                        "suspended_at_step": run.suspended_at_step,
                    }
                )
            return {"runs": runs_info}

        @self.app.post("/workflows/execute")
        async def execute_workflow(
            request: ExecuteRequest,
            _: None = Depends(self._verify_api_key),
        ) -> ExecuteResponse:
            """Execute a workflow with trigger data.

            Args:
                request: ExecuteRequest with workflow_id and data

            Returns:
                ExecuteResponse with run status
            """
            if self.rate_limit_enabled:
                self.limiter.limit("100/minute")(lambda: None)()

            # Get workflow
            if request.workflow_id not in self.workflows:
                raise HTTPException(
                    status_code=404,
                    detail=f"Workflow {request.workflow_id} not found",
                )

            workflow = self.workflows[request.workflow_id]

            # Execute
            try:
                run = await workflow.execute(request.data)
                self.active_runs[run.run_id] = run

                return ExecuteResponse(
                    run_id=run.run_id,
                    status=run.status,
                    outputs=run.outputs if run.status == "completed" else None,
                    suspend_payload=run.suspend_payload,
                    suspended_at_step=run.suspended_at_step,
                )
            except Exception as e:
                # Sanitize error message in production
                detail = str(e) if self.debug else "Workflow execution failed"
                raise HTTPException(status_code=400, detail=detail) from e

        @self.app.get("/runs/{run_id}")
        async def get_run(
            run_id: str,
            _: None = Depends(self._verify_api_key),
        ) -> ExecuteResponse:
            """Get status of a workflow run.

            Args:
                run_id: The run ID

            Returns:
                ExecuteResponse with current run status
            """
            if self.rate_limit_enabled:
                self.limiter.limit("100/minute")(lambda: None)()

            if run_id not in self.active_runs:
                raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

            run = self.active_runs[run_id]

            return ExecuteResponse(
                run_id=run.run_id,
                status=run.status,
                outputs=run.outputs if run.status == "completed" else None,
                suspend_payload=run.suspend_payload,
                suspended_at_step=run.suspended_at_step,
            )

        @self.app.get("/runs/{run_id}/suspend_payload")
        async def get_suspend_payload(
            run_id: str,
            _: None = Depends(self._verify_api_key),
        ) -> dict[str, Any]:
            """Get suspension payload (data for human review).

            Args:
                run_id: The run ID

            Returns:
                Dictionary with suspension context
            """
            if self.rate_limit_enabled:
                self.limiter.limit("100/minute")(lambda: None)()

            if run_id not in self.active_runs:
                raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

            run = self.active_runs[run_id]

            if run.status != "suspended":
                raise HTTPException(
                    status_code=400,
                    detail=f"Run is not suspended (status: {run.status})",
                )

            if run.suspend_payload is None:
                raise HTTPException(
                    status_code=400,
                    detail="No suspension payload available",
                )

            return run.suspend_payload

        @self.app.post("/runs/{run_id}/resume")
        async def resume_run(
            run_id: str,
            request: ResumeRequest = Body(...),  # noqa: B008
            _: None = Depends(self._verify_api_key),
        ) -> ExecuteResponse:
            """Resume a suspended workflow with human input.

            Args:
                run_id: The run ID
                request: ResumeRequest with human_input

            Returns:
                ExecuteResponse with updated status
            """
            if self.rate_limit_enabled:
                self.limiter.limit("100/minute")(lambda: None)()

            if run_id not in self.active_runs:
                raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

            run = self.active_runs[run_id]

            if run.status != "suspended":
                raise HTTPException(
                    status_code=400,
                    detail=f"Run is not suspended (status: {run.status})",
                )

            # Resume
            try:
                resumed = await run.resume(request.human_input)
                self.active_runs[run_id] = resumed

                return ExecuteResponse(
                    run_id=resumed.run_id,
                    status=resumed.status,
                    outputs=resumed.outputs if resumed.status == "completed" else None,
                    suspend_payload=resumed.suspend_payload,
                    suspended_at_step=resumed.suspended_at_step,
                )
            except Exception as e:
                # Sanitize error message in production
                detail = str(e) if self.debug else "Resume failed"
                raise HTTPException(status_code=400, detail=detail) from e

    def _get_static_dir(self) -> str | None:
        """Find the static directory for dashboard files.

        Returns:
            Path to static directory if found, None otherwise
        """
        # Try multiple possible locations
        possible_paths = [
            "static",
            "./static",
            os.path.join(os.path.dirname(__file__), "..", "static"),
            os.path.join(os.getcwd(), "static"),
        ]

        for path in possible_paths:
            if os.path.isdir(path):
                return os.path.abspath(path)

        return None

    def _get_dashboard_path(self) -> str | None:
        """Get the path to the dashboard HTML file.

        Returns:
            Path to dashboard.html if found, None otherwise
        """
        static_dir = self._get_static_dir()
        if static_dir:
            dashboard_path = os.path.join(static_dir, "dashboard.html")
            if os.path.exists(dashboard_path):
                return dashboard_path

        return None

    def register_workflow(self, workflow_id: str, workflow: Workflow) -> None:
        """Register a workflow.

        Args:
            workflow_id: Identifier for the workflow
            workflow: Compiled Workflow instance
        """
        if not workflow._committed:
            raise ValueError("Workflow must be committed before registration")

        self.workflows[workflow_id] = workflow

    def get_app(self) -> FastAPI:
        """Get the FastAPI app instance.

        Returns:
            FastAPI application
        """
        return self.app


def create_server(
    storage: StorageBackend | None = None,
    api_key: str | None = None,
    auth_enabled: bool = False,
    rate_limit: int = 100,
    cors_origins: list[str] | None = None,
    debug: bool = False,
) -> WorkflowServer:
    """Create a workflow server instance.

    Args:
        storage: Storage backend (defaults to MemoryStorage)
        api_key: API key for authentication
        auth_enabled: Enable API key authentication
        rate_limit: Rate limit in requests per minute
        cors_origins: List of allowed CORS origins
        debug: Enable debug mode

    Returns:
        WorkflowServer instance
    """
    return WorkflowServer(
        storage=storage,
        api_key=api_key,
        auth_enabled=auth_enabled,
        rate_limit=rate_limit,
        cors_origins=cors_origins,
        debug=debug,
    )
