"""LLM-powered step for workflows."""

from typing import Any

from pydantic import BaseModel

from pymastra.context import StepContext
from pymastra.llm import LLMClient, LLMConfig
from pymastra.step import Step
from pymastra.tools import ToolRegistry


class LLMOutput(BaseModel):
    """Standard output from LLM step."""

    text: str
    """Generated text response"""
    tokens_used: int
    """Approximate tokens used"""


def create_llm_step(
    id: str,
    description: str,
    system_prompt: str,
    llm_config: LLMConfig | None = None,
    output_schema: type[BaseModel] = LLMOutput,
    **kwargs: Any,
) -> Step:
    """Create an LLM-powered step.

    Args:
        id: Step identifier
        description: Step description
        system_prompt: System prompt/instructions for the LLM
        llm_config: LLM configuration (defaults to Claude 3.5 Sonnet)
        output_schema: Pydantic schema for output validation
        **kwargs: Additional arguments passed to Step

    Returns:
        Step configured to use LLM

    Example:
        >>> step = create_llm_step(
        ...     id="classify",
        ...     description="Classify text",
        ...     system_prompt="You are a text classifier. Output: CATEGORY",
        ... )
    """
    # Default to Claude if not specified
    if llm_config is None:
        llm_config = LLMConfig(
            provider="claude",
            model="claude-3-5-sonnet-20241022",
        )

    # Create LLM client
    client = LLMClient(llm_config)

    async def execute_fn(ctx: StepContext) -> Any:
        """Execute LLM call."""
        # Get prompt from trigger data or use template
        if hasattr(ctx.trigger_data, "text"):
            user_prompt = ctx.trigger_data.text
        else:
            # Convert trigger data to string
            user_prompt = str(ctx.trigger_data)

        # Call LLM
        response = await client.generate(
            prompt=user_prompt,
            system=system_prompt,
        )
        response_text = str(response.get("content", ""))

        # Count tokens
        tokens = client.count_tokens(response_text)

        # Create output
        if output_schema == LLMOutput:
            return LLMOutput(text=response_text, tokens_used=tokens)
        else:
            # User provided custom schema - parse the response
            try:
                return output_schema(**{"text": response_text, "tokens_used": tokens})
            except (TypeError, ValueError):
                # If schema doesn't match, try with just text field
                return output_schema(text=response_text)

    return Step(
        id=id,
        description=description,
        input_schema=BaseModel,
        output_schema=output_schema,
        execute=execute_fn,
        **kwargs,
    )


class ToolCallOutput(BaseModel):
    """Output from an LLM step with tool calling."""

    content: str | None = None
    """Text response from LLM (if any)"""
    tool_calls: list[dict[str, Any]] = []
    """Tool calls made by LLM"""
    tokens_used: int = 0
    """Approximate tokens used"""


def create_tool_calling_step(
    id: str,
    description: str,
    system_prompt: str,
    tools: ToolRegistry,
    llm_config: LLMConfig | None = None,
    auto_execute: bool = True,
    **kwargs: Any,
) -> Step:
    """Create an LLM step with tool/function calling capability.

    The LLM can analyze the prompt and decide to call any of the provided tools.
    If auto_execute is True, tools will be executed automatically and results
    sent back to the LLM for continued reasoning.

    Args:
        id: Step identifier
        description: Step description
        system_prompt: System prompt/instructions for the LLM
        tools: ToolRegistry containing available tools
        llm_config: LLM configuration
        auto_execute: Whether to auto-execute called tools
        **kwargs: Additional arguments passed to Step

    Returns:
        Step configured for tool calling

    Example:
        >>> registry = ToolRegistry()
        >>> registry.register_function(
        ...     lambda x: x * 2,
        ...     name="double",
        ...     description="Double a number"
        ... )
        >>> step = create_tool_calling_step(
        ...     id="agent",
        ...     description="Agent with tools",
        ...     system_prompt="You are a helpful assistant with tools",
        ...     tools=registry
        ... )
    """
    if llm_config is None:
        llm_config = LLMConfig(provider="claude", model="claude-3-5-sonnet-20241022")

    client = LLMClient(llm_config)
    tool_definitions = tools.list_tools()

    async def execute_fn(ctx: StepContext) -> ToolCallOutput:
        """Execute LLM with tool calling."""
        # Get user prompt
        if hasattr(ctx.trigger_data, "text"):
            user_prompt = ctx.trigger_data.text
        else:
            user_prompt = str(ctx.trigger_data)

        # Initial LLM call with tools
        response = await client.generate(
            prompt=user_prompt,
            system=system_prompt,
            tools=tool_definitions,
        )

        # Handle tool calls if auto_execute is enabled
        if auto_execute and "tool_calls" in response:
            # Execute tools
            tool_results = []
            for tool_call in response["tool_calls"]:
                try:
                    result = await tools.execute_tool(tool_call["tool"], **tool_call["args"])
                    tool_results.append(
                        {
                            "tool": tool_call["tool"],
                            "args": tool_call["args"],
                            "result": result,
                        }
                    )
                except Exception as e:
                    tool_results.append(
                        {
                            "tool": tool_call["tool"],
                            "args": tool_call["args"],
                            "error": str(e),
                        }
                    )

            # Send tool results back to LLM for continued reasoning
            tool_results_lines = []
            for tr in tool_results:
                tool_name = tr["tool"]
                result = tr.get("result")
                error = tr.get("error")
                result_text = result if result else f"Error: {error}"
                tool_results_lines.append(f"- {tool_name}: {result_text}")

            tool_result_text = "Tool call results:\n" + "\n".join(tool_results_lines)

            # Second LLM call with tool results
            final_response = await client.generate(
                prompt=f"{user_prompt}\n\n{tool_result_text}",
                system=system_prompt,
                tools=None,  # Don't use tools in follow-up
            )

            return ToolCallOutput(
                content=final_response.get("content", ""),
                tool_calls=response.get("tool_calls", []),
                tokens_used=client.count_tokens(response.get("content", "") + tool_result_text),
            )

        # No tool calls, return response as-is
        return ToolCallOutput(
            content=response.get("content", ""),
            tool_calls=response.get("tool_calls", []),
            tokens_used=client.count_tokens(response.get("content", "")),
        )

    return Step(
        id=id,
        description=description,
        input_schema=BaseModel,
        output_schema=ToolCallOutput,
        execute=execute_fn,
        **kwargs,
    )


class LLMChain:
    """Chain multiple LLM steps together.

    Useful for multi-step reasoning tasks.
    """

    def __init__(self, name: str, llm_config: LLMConfig | None = None) -> None:
        """Initialize LLM chain.

        Args:
            name: Chain name
            llm_config: Shared LLM configuration for all steps
        """
        self.name = name
        self.llm_config = llm_config or LLMConfig()
        self.steps: dict[str, Step] = {}

    def add_step(
        self,
        id: str,
        description: str,
        system_prompt: str,
        output_schema: type[BaseModel] = LLMOutput,
    ) -> "LLMChain":
        """Add a step to the chain.

        Args:
            id: Step identifier
            description: Step description
            system_prompt: System prompt for this step
            output_schema: Output schema for this step

        Returns:
            Self for chaining
        """
        step = create_llm_step(
            id=id,
            description=description,
            system_prompt=system_prompt,
            llm_config=self.llm_config,
            output_schema=output_schema,
        )
        self.steps[id] = step
        return self

    def get_steps(self) -> list[Step]:
        """Get all steps in order."""
        return list(self.steps.values())
