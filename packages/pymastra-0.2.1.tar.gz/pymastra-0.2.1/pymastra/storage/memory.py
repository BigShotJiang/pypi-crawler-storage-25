"""In-memory storage backend for development and testing."""

from pymastra.storage.base import StorageBackend, WorkflowRunState


class MemoryStorage(StorageBackend):
    """In-memory storage backend using a simple dictionary.

    Perfect for development, testing, and single-process deployments.
    Data is lost when the process exits.
    """

    def __init__(self) -> None:
        """Initialize in-memory storage."""
        self._runs: dict[str, WorkflowRunState] = {}

    async def save_run(self, state: WorkflowRunState) -> None:
        """Save a workflow run to memory.

        Args:
            state: WorkflowRunState to save
        """
        self._runs[state.run_id] = state

    async def load_run(self, run_id: str) -> WorkflowRunState | None:
        """Load a workflow run from memory.

        Args:
            run_id: Run identifier

        Returns:
            WorkflowRunState if found, None otherwise
        """
        return self._runs.get(run_id)

    async def update_run(self, state: WorkflowRunState) -> None:
        """Update a workflow run in memory.

        Args:
            state: Updated WorkflowRunState
        """
        self._runs[state.run_id] = state

    async def delete_run(self, run_id: str) -> None:
        """Delete a workflow run from memory.

        Args:
            run_id: Run identifier
        """
        self._runs.pop(run_id, None)
