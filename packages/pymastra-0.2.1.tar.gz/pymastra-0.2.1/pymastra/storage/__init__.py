"""Storage backends for workflow run persistence."""

from pymastra.storage.base import StorageBackend, WorkflowRunState
from pymastra.storage.memory import MemoryStorage

__all__ = [
    "StorageBackend",
    "WorkflowRunState",
    "MemoryStorage",
]

# Optional imports for PostgreSQL and SQLite
try:
    from pymastra.storage.sqlite import SQLiteStorage

    __all__.append("SQLiteStorage")
except ImportError:
    SQLiteStorage = None  # type: ignore

try:
    from pymastra.storage.postgres import PostgresStorage

    __all__.append("PostgresStorage")
except ImportError:
    PostgresStorage = None  # type: ignore
