"""SQLite storage backend for workflow run persistence.

Provides file-based persistence for self-hosted deployments.
Perfect for development, testing, and small-scale production use.

Requires: pip install pymastra[sqlite]
"""

import json

try:
    import aiosqlite
except ImportError:
    aiosqlite = None  # type: ignore

from pymastra.storage.base import StorageBackend, WorkflowRunState


class SQLiteStorage(StorageBackend):
    """SQLite-based storage backend for workflow run persistence.

    Requires: pip install pymastra[sqlite]
    """

    def __init__(self, db_path: str = "pymastra.db") -> None:
        """Initialize SQLite storage.

        Args:
            db_path: Path to SQLite database file
        """
        if aiosqlite is None:
            raise ImportError(
                "aiosqlite is required for SQLiteStorage. "
                "Install with: pip install pymastra[sqlite]"
            )

        self.db_path = db_path
        self._initialized = False

    async def _ensure_table(self) -> None:
        """Create table and indexes if they don't exist."""
        if self._initialized:
            return

        async with aiosqlite.connect(self.db_path) as db:
            # Create main table
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS workflow_runs (
                    run_id TEXT PRIMARY KEY,
                    workflow_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    outputs TEXT NOT NULL,
                    suspend_payload TEXT,
                    suspended_at_step TEXT,
                    error TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            # Create indexes for common queries
            await db.execute("CREATE INDEX IF NOT EXISTS idx_status ON workflow_runs(status)")
            await db.execute(
                "CREATE INDEX IF NOT EXISTS idx_workflow_id ON workflow_runs(workflow_id)"
            )
            await db.execute(
                "CREATE INDEX IF NOT EXISTS idx_created_at ON workflow_runs(created_at)"
            )

            await db.commit()
        self._initialized = True

    async def save_run(self, state: WorkflowRunState) -> None:
        """Save a workflow run to SQLite.

        Args:
            state: WorkflowRunState to save
        """
        await self._ensure_table()

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT OR REPLACE INTO workflow_runs
                (run_id, workflow_id, status, outputs, suspend_payload,
                 suspended_at_step, error)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    state.run_id,
                    state.workflow_id,
                    state.status,
                    json.dumps(state.outputs),
                    json.dumps(state.suspend_payload) if state.suspend_payload else None,
                    state.suspended_at_step,
                    state.error,
                ),
            )
            await db.commit()

    async def load_run(self, run_id: str) -> WorkflowRunState | None:
        """Load a workflow run from SQLite.

        Args:
            run_id: Run identifier

        Returns:
            WorkflowRunState if found, None otherwise
        """
        await self._ensure_table()

        async with (
            aiosqlite.connect(self.db_path) as db,
            db.execute(
                "SELECT workflow_id, status, outputs, suspend_payload, "
                "suspended_at_step, error FROM workflow_runs WHERE run_id = ?",
                (run_id,),
            ) as cursor,
        ):
            row = await cursor.fetchone()
            if not row:
                return None

            return WorkflowRunState(
                run_id=run_id,
                workflow_id=row[0],
                status=row[1],
                outputs=json.loads(row[2]),
                suspend_payload=json.loads(row[3]) if row[3] else None,
                suspended_at_step=row[4],
                error=row[5],
            )

    async def update_run(self, state: WorkflowRunState) -> None:
        """Update a workflow run in SQLite.

        Args:
            state: Updated WorkflowRunState
        """
        await self.save_run(state)

    async def delete_run(self, run_id: str) -> None:
        """Delete a workflow run from SQLite.

        Args:
            run_id: Run identifier
        """
        await self._ensure_table()

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM workflow_runs WHERE run_id = ?", (run_id,))
            await db.commit()

    async def list_runs(
        self,
        status: str | None = None,
        workflow_id: str | None = None,
        limit: int = 100,
    ) -> list[WorkflowRunState]:
        """List workflow runs with optional filtering.

        Args:
            status: Filter by status (optional)
            workflow_id: Filter by workflow ID (optional)
            limit: Maximum number of runs to return

        Returns:
            List of WorkflowRunState objects
        """
        await self._ensure_table()

        query = (
            "SELECT run_id, workflow_id, status, outputs, "
            "suspend_payload, suspended_at_step, error "
            "FROM workflow_runs WHERE 1=1"
        )
        params: list[str | int] = []

        if status:
            query += " AND status = ?"
            params.append(status)

        if workflow_id:
            query += " AND workflow_id = ?"
            params.append(workflow_id)

        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        async with (
            aiosqlite.connect(self.db_path) as db,
            db.execute(query, params) as cursor,
        ):
            rows = await cursor.fetchall()
            return [
                WorkflowRunState(
                    run_id=row[0],
                    workflow_id=row[1],
                    status=row[2],
                    outputs=json.loads(row[3]),
                    suspend_payload=json.loads(row[4]) if row[4] else None,
                    suspended_at_step=row[5],
                    error=row[6],
                )
                for row in rows
            ]

    async def count_runs(self, status: str | None = None) -> int:
        """Count workflow runs, optionally filtered by status.

        Args:
            status: Filter by status (optional)

        Returns:
            Number of matching runs
        """
        await self._ensure_table()

        query = "SELECT COUNT(*) FROM workflow_runs WHERE 1=1"
        params: list[str] = []

        if status:
            query += " AND status = ?"
            params.append(status)

        async with (
            aiosqlite.connect(self.db_path) as db,
            db.execute(query, params) as cursor,
        ):
            result = await cursor.fetchone()
            return result[0] if result else 0
