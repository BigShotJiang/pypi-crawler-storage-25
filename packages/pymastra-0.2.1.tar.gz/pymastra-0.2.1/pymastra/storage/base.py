"""Abstract base class for workflow run storage."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class WorkflowRunState:
    """State of a workflow run for storage."""

    run_id: str
    workflow_id: str
    status: str  # "running", "suspended", "completed", "failed"
    outputs: dict[str, Any]
    suspend_payload: dict[str, Any] | None = None
    suspended_at_step: str | None = None
    error: str | None = None


class StorageBackend(ABC):
    """Abstract base class for workflow run storage."""

    @abstractmethod
    async def save_run(self, state: WorkflowRunState) -> None:
        """Save a workflow run state.

        Args:
            state: WorkflowRunState to save
        """
        pass

    @abstractmethod
    async def load_run(self, run_id: str) -> WorkflowRunState | None:
        """Load a workflow run by ID.

        Args:
            run_id: Run identifier

        Returns:
            WorkflowRunState if found, None otherwise
        """
        pass

    @abstractmethod
    async def update_run(self, state: WorkflowRunState) -> None:
        """Update a workflow run state.

        Args:
            state: Updated WorkflowRunState
        """
        pass

    @abstractmethod
    async def delete_run(self, run_id: str) -> None:
        """Delete a workflow run.

        Args:
            run_id: Run identifier
        """
        pass
