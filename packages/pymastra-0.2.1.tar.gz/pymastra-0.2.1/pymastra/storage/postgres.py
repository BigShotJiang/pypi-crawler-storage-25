"""PostgreSQL storage backend for workflow run persistence."""

import json
from typing import Any

try:
    import asyncpg
except ImportError:
    asyncpg = None  # type: ignore

from pymastra.storage.base import StorageBackend, WorkflowRunState


class PostgresStorage(StorageBackend):
    """PostgreSQL-based storage backend for production workflow persistence.

    Requires: pip install pymastra[postgres]
    """

    def __init__(
        self,
        dsn: str = "postgresql://user:password@localhost/pymastra",
    ) -> None:
        """Initialize PostgreSQL storage.

        Args:
            dsn: PostgreSQL connection string
        """
        if asyncpg is None:
            raise ImportError(
                "asyncpg is required for PostgresStorage. "
                "Install with: pip install pymastra[postgres]"
            )

        self.dsn = dsn
        self._pool: Any = None
        self._initialized = False

    async def _get_pool(self) -> Any:
        """Get or create database connection pool."""
        if self._pool is None:
            self._pool = await asyncpg.create_pool(self.dsn)
        return self._pool

    async def _ensure_table(self) -> None:
        """Create table if it doesn't exist."""
        if self._initialized:
            return

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS workflow_runs (
                    run_id TEXT PRIMARY KEY,
                    workflow_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    outputs JSONB NOT NULL,
                    suspend_payload JSONB,
                    suspended_at_step TEXT,
                    error TEXT,
                    created_at TIMESTAMP DEFAULT NOW(),
                    updated_at TIMESTAMP DEFAULT NOW()
                )
                """
            )
        self._initialized = True

    async def save_run(self, state: WorkflowRunState) -> None:
        """Save a workflow run to PostgreSQL.

        Args:
            state: WorkflowRunState to save
        """
        await self._ensure_table()

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO workflow_runs
                (run_id, workflow_id, status, outputs, suspend_payload,
                 suspended_at_step, error)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (run_id) DO UPDATE SET
                status = $3, outputs = $4, suspend_payload = $5,
                suspended_at_step = $6, error = $7, updated_at = NOW()
                """,
                state.run_id,
                state.workflow_id,
                state.status,
                json.dumps(state.outputs),
                json.dumps(state.suspend_payload) if state.suspend_payload else None,
                state.suspended_at_step,
                state.error,
            )

    async def load_run(self, run_id: str) -> WorkflowRunState | None:
        """Load a workflow run from PostgreSQL.

        Args:
            run_id: Run identifier

        Returns:
            WorkflowRunState if found, None otherwise
        """
        await self._ensure_table()

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT workflow_id, status, outputs, suspend_payload,
                suspended_at_step, error FROM workflow_runs WHERE run_id = $1
                """,
                run_id,
            )
            if not row:
                return None

            return WorkflowRunState(
                run_id=run_id,
                workflow_id=row["workflow_id"],
                status=row["status"],
                outputs=row["outputs"],
                suspend_payload=row["suspend_payload"],
                suspended_at_step=row["suspended_at_step"],
                error=row["error"],
            )

    async def update_run(self, state: WorkflowRunState) -> None:
        """Update a workflow run in PostgreSQL.

        Args:
            state: Updated WorkflowRunState
        """
        await self.save_run(state)

    async def delete_run(self, run_id: str) -> None:
        """Delete a workflow run from PostgreSQL.

        Args:
            run_id: Run identifier
        """
        await self._ensure_table()

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM workflow_runs WHERE run_id = $1",
                run_id,
            )
