"""Observability, tracing, and metrics for Pymastra workflows.

Provides structured logging, execution tracing, and metrics collection
for monitoring workflow performance and debugging.
"""

import asyncio
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

logger = logging.getLogger("pymastra")


class EventType(StrEnum):
    """Types of events in workflow execution."""

    WORKFLOW_START = "workflow.start"
    WORKFLOW_COMPLETE = "workflow.complete"
    WORKFLOW_FAILED = "workflow.failed"
    STEP_START = "step.start"
    STEP_COMPLETE = "step.complete"
    STEP_FAILED = "step.failed"
    STEP_SUSPENDED = "step.suspended"
    STEP_RESUMED = "step.resumed"
    TOOL_CALL = "tool.call"
    TOOL_RESULT = "tool.result"
    ERROR = "error"


@dataclass
class Span:
    """Execution span for tracking timing."""

    name: str
    """Span name (step ID, operation, etc.)"""
    start_time: float
    """Start time (seconds since epoch)"""
    end_time: float | None = None
    """End time (populated when span ends)"""
    duration_ms: float | None = None
    """Duration in milliseconds"""
    status: str = "pending"
    """Status: pending, success, error"""
    metadata: dict[str, Any] | None = None
    """Additional metadata"""

    def end(self, status: str = "success", metadata: dict[str, Any] | None = None) -> None:
        """End the span.

        Args:
            status: Completion status (success, error)
            metadata: Additional metadata to add
        """
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        self.status = status
        if metadata:
            if self.metadata is None:
                self.metadata = {}
            self.metadata.update(metadata)

    def to_dict(self) -> dict[str, Any]:
        """Convert span to dictionary."""
        return {
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "metadata": self.metadata or {},
        }


@dataclass
class Event:
    """Structured event for workflow monitoring."""

    type: EventType
    """Event type"""
    timestamp: float
    """Event timestamp"""
    run_id: str
    """Workflow run ID"""
    workflow_id: str
    """Workflow ID"""
    step_id: str | None = None
    """Step ID (if applicable)"""
    message: str = ""
    """Human-readable message"""
    data: dict[str, Any] | None = None
    """Event data"""
    duration_ms: float | None = None
    """Duration in milliseconds"""

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary."""
        return {
            "type": self.type.value,
            "timestamp": self.timestamp,
            "run_id": self.run_id,
            "workflow_id": self.workflow_id,
            "step_id": self.step_id,
            "message": self.message,
            "data": self.data or {},
            "duration_ms": self.duration_ms,
        }

    def to_json(self) -> str:
        """Convert event to JSON string."""
        return json.dumps(self.to_dict())


class Metrics:
    """Metrics collection for workflow execution.

    Tracks:
    - Workflow execution counts
    - Step execution times
    - Success/failure rates
    - Suspension counts
    """

    def __init__(self) -> None:
        """Initialize metrics."""
        self.workflows_started = 0
        self.workflows_completed = 0
        self.workflows_failed = 0
        self.workflows_suspended = 0

        self.steps_executed = 0
        self.steps_failed = 0
        self.steps_suspended = 0

        self.step_durations: dict[str, list[float]] = {}
        """Execution durations by step ID (in milliseconds)"""

        self.tool_calls = 0
        self.tool_failures = 0

    def record_workflow_start(self) -> None:
        """Record workflow start."""
        self.workflows_started += 1

    def record_workflow_complete(self) -> None:
        """Record workflow completion."""
        self.workflows_completed += 1

    def record_workflow_failed(self) -> None:
        """Record workflow failure."""
        self.workflows_failed += 1

    def record_workflow_suspended(self) -> None:
        """Record workflow suspension."""
        self.workflows_suspended += 1

    def record_step_executed(self, step_id: str, duration_ms: float) -> None:
        """Record step execution.

        Args:
            step_id: Step identifier
            duration_ms: Execution duration in milliseconds
        """
        self.steps_executed += 1
        if step_id not in self.step_durations:
            self.step_durations[step_id] = []
        self.step_durations[step_id].append(duration_ms)

    def record_step_failed(self) -> None:
        """Record step failure."""
        self.steps_failed += 1

    def record_step_suspended(self) -> None:
        """Record step suspension."""
        self.steps_suspended += 1

    def record_tool_call(self, success: bool = True) -> None:
        """Record tool call.

        Args:
            success: Whether the tool call succeeded
        """
        self.tool_calls += 1
        if not success:
            self.tool_failures += 1

    def get_step_stats(self, step_id: str) -> dict[str, float]:
        """Get statistics for a specific step.

        Args:
            step_id: Step identifier

        Returns:
            Dictionary with min, max, avg duration
        """
        durations = self.step_durations.get(step_id, [])
        if not durations:
            return {"count": 0, "min_ms": 0, "max_ms": 0, "avg_ms": 0}

        return {
            "count": len(durations),
            "min_ms": min(durations),
            "max_ms": max(durations),
            "avg_ms": sum(durations) / len(durations),
        }

    def get_summary(self) -> dict[str, Any]:
        """Get metrics summary.

        Returns:
            Dictionary with all metrics
        """
        success_rate = 0.0
        if self.workflows_started > 0:
            success_rate = self.workflows_completed / self.workflows_started * 100

        tool_success_rate = 0.0
        if self.tool_calls > 0:
            tool_success_rate = (self.tool_calls - self.tool_failures) / self.tool_calls * 100

        return {
            "workflows": {
                "started": self.workflows_started,
                "completed": self.workflows_completed,
                "failed": self.workflows_failed,
                "suspended": self.workflows_suspended,
                "success_rate_pct": success_rate,
            },
            "steps": {
                "executed": self.steps_executed,
                "failed": self.steps_failed,
                "suspended": self.steps_suspended,
            },
            "tools": {
                "calls": self.tool_calls,
                "failures": self.tool_failures,
                "success_rate_pct": tool_success_rate,
            },
            "step_timings": {
                step_id: self.get_step_stats(step_id) for step_id in self.step_durations
            },
        }


class EventLogger:
    """Logger for workflow events.

    Can be extended to send events to external monitoring systems
    (Datadog, New Relic, CloudWatch, etc.).
    """

    def __init__(self) -> None:
        """Initialize event logger."""
        self.events: list[Event] = []
        self.event_handlers: list[Callable[[Event], Any]] = []

    def register_handler(self, handler: Callable[[Event], Any]) -> None:
        """Register an event handler.

        Args:
            handler: Async function to handle events
        """
        self.event_handlers.append(handler)

    async def log_event(self, event: Event) -> None:
        """Log an event.

        Args:
            event: Event to log
        """
        self.events.append(event)

        # Log to standard logger
        logger.info(
            f"{event.type.value}: {event.message}",
            extra={
                "run_id": event.run_id,
                "workflow_id": event.workflow_id,
                "step_id": event.step_id,
            },
        )

        # Call registered handlers
        for handler in self.event_handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
            except Exception as e:
                logger.error(f"Event handler failed: {e}")

    def get_events(
        self,
        event_type: EventType | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ) -> list[Event]:
        """Get logged events with optional filtering.

        Args:
            event_type: Filter by event type
            run_id: Filter by run ID
            limit: Maximum number of events to return

        Returns:
            List of events
        """
        filtered = self.events

        if event_type:
            filtered = [e for e in filtered if e.type == event_type]

        if run_id:
            filtered = [e for e in filtered if e.run_id == run_id]

        return filtered[-limit:]

    def export_events(self) -> list[dict[str, Any]]:
        """Export all events as dictionaries.

        Returns:
            List of event dictionaries
        """
        return [e.to_dict() for e in self.events]


class TraceContext:
    """Context for collecting execution traces.

    Tracks spans and events for a complete workflow execution.
    """

    def __init__(self, run_id: str, workflow_id: str) -> None:
        """Initialize trace context.

        Args:
            run_id: Workflow run ID
            workflow_id: Workflow ID
        """
        self.run_id = run_id
        self.workflow_id = workflow_id
        self.spans: list[Span] = []
        self.events: list[Event] = []
        self.start_time = time.time()

    def create_span(self, name: str, metadata: dict[str, Any] | None = None) -> Span:
        """Create a new span.

        Args:
            name: Span name
            metadata: Span metadata

        Returns:
            Span object
        """
        span = Span(
            name=name,
            start_time=time.time(),
            metadata=metadata or {},
        )
        self.spans.append(span)
        return span

    def add_event(
        self,
        event_type: EventType,
        step_id: str | None = None,
        message: str = "",
        data: dict[str, Any] | None = None,
    ) -> Event:
        """Add an event.

        Args:
            event_type: Type of event
            step_id: Associated step ID
            message: Event message
            data: Event data

        Returns:
            Event object
        """
        event = Event(
            type=event_type,
            timestamp=time.time(),
            run_id=self.run_id,
            workflow_id=self.workflow_id,
            step_id=step_id,
            message=message,
            data=data,
        )
        self.events.append(event)
        return event

    def get_duration(self) -> float:
        """Get total execution duration.

        Returns:
            Duration in milliseconds
        """
        return (time.time() - self.start_time) * 1000

    def get_summary(self) -> dict[str, Any]:
        """Get trace summary.

        Returns:
            Dictionary with trace information
        """
        total_duration = self.get_duration()
        span_durations = [s.duration_ms for s in self.spans if s.duration_ms]

        return {
            "run_id": self.run_id,
            "workflow_id": self.workflow_id,
            "total_duration_ms": total_duration,
            "spans": len(self.spans),
            "events": len(self.events),
            "span_summary": {
                "count": len(span_durations),
                "min_ms": min(span_durations) if span_durations else 0,
                "max_ms": max(span_durations) if span_durations else 0,
                "avg_ms": (sum(span_durations) / len(span_durations) if span_durations else 0),
                "total_ms": sum(span_durations) if span_durations else 0,
            },
        }


# Global instances
_metrics = Metrics()
_event_logger = EventLogger()


def get_metrics() -> Metrics:
    """Get global metrics instance."""
    return _metrics


def get_event_logger() -> EventLogger:
    """Get global event logger instance."""
    return _event_logger
