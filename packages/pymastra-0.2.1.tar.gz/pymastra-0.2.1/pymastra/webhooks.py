"""Webhook integration for workflow events.

Allows workflows to trigger external webhooks when specific events occur.
Supports event filtering, retries, and payload transformation.
"""

import asyncio
import json
from typing import Any
from urllib.parse import urlparse

try:
    import aiohttp
except ImportError:
    aiohttp = None  # type: ignore

from pymastra.observability import EventType


def _validate_webhook_url(url: str) -> None:
    """Validate webhook URL to prevent SSRF attacks.

    Args:
        url: URL to validate

    Raises:
        ValueError: If URL is invalid or potentially dangerous
    """
    try:
        parsed = urlparse(url)
    except Exception as e:
        raise ValueError(f"Invalid URL: {e}") from e

    # Only allow http and https
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Invalid URL scheme '{parsed.scheme}'. Only http and https allowed.")

    # Prevent localhost/internal addresses
    hostname = parsed.hostname or ""
    hostname_lower = hostname.lower()

    blocked_patterns = [
        "localhost",
        "127.",
        "192.168.",
        "10.",
        "172.1",  # 172.16-172.31 range
        "169.254.",  # Link-local addresses
        "::1",  # IPv6 localhost
        "fc00:",  # IPv6 private
        "fe80:",  # IPv6 link-local
    ]

    for pattern in blocked_patterns:
        if hostname_lower.startswith(pattern):
            raise ValueError(
                f"URL hostname '{hostname}' is not allowed. Cannot target local/private addresses."
            )

    # Check for empty hostname
    if not hostname:
        raise ValueError("URL must have a valid hostname")


class Webhook:
    """Configuration for a webhook to trigger on events."""

    def __init__(
        self,
        id: str,
        url: str,
        events: list[EventType] | list[str],
        secret: str | None = None,
        headers: dict[str, str] | None = None,
        active: bool = True,
    ) -> None:
        """Initialize webhook configuration.

        Args:
            id: Webhook identifier
            url: Target URL to send webhook to
            events: List of event types that trigger this webhook
            secret: Optional secret for HMAC signing
            headers: Additional HTTP headers
            active: Whether the webhook is active

        Raises:
            ValueError: If URL is invalid or potentially dangerous (SSRF protection)
        """
        # Validate URL to prevent SSRF attacks
        _validate_webhook_url(url)

        self.id = id
        self.url = url
        self.events = [EventType(e) if isinstance(e, str) else e for e in events]
        self.secret = secret
        self.headers = headers or {}
        self.active = active

    def matches_event(self, event_type: EventType) -> bool:
        """Check if this webhook should trigger for an event.

        Args:
            event_type: Type of event

        Returns:
            True if webhook should trigger
        """
        if not self.active:
            return False
        return event_type in self.events

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "url": self.url,
            "events": [e.value for e in self.events],
            "active": self.active,
        }


class WebhookRegistry:
    """Registry for managing webhooks."""

    def __init__(self) -> None:
        """Initialize webhook registry."""
        if aiohttp is None:
            raise ImportError(
                "aiohttp is required for webhook support. "
                "Install with: pip install pymastra[webhooks]"
            )

        self.webhooks: dict[str, Webhook] = {}
        self.failed_deliveries: dict[str, list[dict[str, Any]]] = {}

    def register(self, webhook: Webhook) -> None:
        """Register a webhook.

        Args:
            webhook: Webhook to register
        """
        self.webhooks[webhook.id] = webhook

    def unregister(self, webhook_id: str) -> bool:
        """Unregister a webhook.

        Args:
            webhook_id: Webhook ID

        Returns:
            True if webhook was found and removed
        """
        return self.webhooks.pop(webhook_id, None) is not None

    def get_webhook(self, webhook_id: str) -> Webhook | None:
        """Get a webhook by ID.

        Args:
            webhook_id: Webhook ID

        Returns:
            Webhook if found, None otherwise
        """
        return self.webhooks.get(webhook_id)

    def list_webhooks(self, event_type: EventType | None = None) -> list[Webhook]:
        """List webhooks, optionally filtered by event type.

        Args:
            event_type: Filter by event type (optional)

        Returns:
            List of webhooks
        """
        webhooks = list(self.webhooks.values())
        if event_type:
            webhooks = [w for w in webhooks if w.matches_event(event_type)]
        return webhooks

    async def trigger(
        self,
        event_type: EventType,
        event_data: dict[str, Any],
        run_id: str,
        max_retries: int = 3,
    ) -> dict[str, Any]:
        """Trigger webhooks for an event.

        Args:
            event_type: Type of event
            event_data: Event data to send
            run_id: Workflow run ID
            max_retries: Maximum number of retries

        Returns:
            Dictionary with delivery results
        """
        matching_webhooks = self.list_webhooks(event_type)

        deliveries: dict[str, dict[str, Any]] = {}
        results: dict[str, Any] = {
            "event_type": event_type.value,
            "run_id": run_id,
            "webhooks_triggered": len(matching_webhooks),
            "deliveries": deliveries,
        }

        for webhook in matching_webhooks:
            delivery = await self._deliver_webhook(
                webhook,
                event_data,
                max_retries=max_retries,
            )
            deliveries[webhook.id] = delivery

            if not delivery["success"]:
                self._record_failure(webhook.id, delivery)

        return results

    async def _deliver_webhook(
        self,
        webhook: Webhook,
        event_data: dict[str, Any],
        max_retries: int = 3,
    ) -> dict[str, Any]:
        """Deliver a single webhook with retries.

        Args:
            webhook: Webhook to deliver
            event_data: Event data
            max_retries: Maximum retries

        Returns:
            Delivery result
        """
        assert aiohttp is not None

        payload = self._build_payload(webhook, event_data)

        for attempt in range(max_retries + 1):
            try:
                async with aiohttp.ClientSession() as session:
                    headers = {
                        "Content-Type": "application/json",
                        **webhook.headers,
                    }

                    if webhook.secret:
                        import hashlib
                        import hmac

                        signature = hmac.new(
                            webhook.secret.encode(),
                            payload.encode(),
                            hashlib.sha256,
                        ).hexdigest()
                        headers["X-Webhook-Signature"] = f"sha256={signature}"

                    async with session.post(
                        webhook.url,
                        data=payload,
                        headers=headers,
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as response:
                        if response.status < 300:
                            return {
                                "webhook_id": webhook.id,
                                "success": True,
                                "status_code": response.status,
                                "attempt": attempt + 1,
                            }

                        if attempt < max_retries:
                            # Exponential backoff
                            await asyncio.sleep(2**attempt)
                            continue

                        return {
                            "webhook_id": webhook.id,
                            "success": False,
                            "status_code": response.status,
                            "attempt": attempt + 1,
                            "error": f"HTTP {response.status}",
                        }

            except TimeoutError:
                if attempt < max_retries:
                    await asyncio.sleep(2**attempt)
                    continue

                return {
                    "webhook_id": webhook.id,
                    "success": False,
                    "attempt": attempt + 1,
                    "error": "Request timeout",
                }

            except Exception as e:
                if attempt < max_retries:
                    await asyncio.sleep(2**attempt)
                    continue

                return {
                    "webhook_id": webhook.id,
                    "success": False,
                    "attempt": attempt + 1,
                    "error": str(e),
                }

        return {
            "webhook_id": webhook.id,
            "success": False,
            "error": "Max retries exceeded",
        }

    def _build_payload(
        self,
        webhook: Webhook,
        event_data: dict[str, Any],
    ) -> str:
        """Build webhook payload.

        Args:
            webhook: Target webhook
            event_data: Event data

        Returns:
            JSON payload string
        """
        payload = {
            "webhook_id": webhook.id,
            "event": event_data,
            "timestamp": int(asyncio.get_event_loop().time() * 1000),
        }
        return json.dumps(payload)

    def _record_failure(
        self,
        webhook_id: str,
        delivery: dict[str, Any],
    ) -> None:
        """Record a failed delivery.

        Args:
            webhook_id: Webhook ID
            delivery: Delivery result
        """
        if webhook_id not in self.failed_deliveries:
            self.failed_deliveries[webhook_id] = []

        self.failed_deliveries[webhook_id].append(delivery)

        # Keep only last 100 failures per webhook
        if len(self.failed_deliveries[webhook_id]) > 100:
            self.failed_deliveries[webhook_id] = self.failed_deliveries[webhook_id][-100:]

    def get_failures(self, webhook_id: str | None = None) -> dict[str, list[Any]]:
        """Get recorded failures.

        Args:
            webhook_id: Specific webhook to query (optional)

        Returns:
            Dictionary with failure records
        """
        if webhook_id:
            return {webhook_id: self.failed_deliveries.get(webhook_id, [])}

        return self.failed_deliveries


# Global registry
_webhook_registry: WebhookRegistry | None = None


def get_webhook_registry() -> WebhookRegistry:
    """Get or create the global webhook registry."""
    global _webhook_registry
    if _webhook_registry is None:
        _webhook_registry = WebhookRegistry()
    return _webhook_registry
