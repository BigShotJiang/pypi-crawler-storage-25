# Security Policy

## Reporting Security Vulnerabilities

We take security seriously. If you discover a security vulnerability, please **do not** open a public issue. Instead, please email security@github.com with:

1. **Type of vulnerability** (e.g., injection, authentication bypass, credential leakage)
2. **Affected versions** (e.g., 0.2.0 and earlier)
3. **Description** with code examples demonstrating the issue
4. **Impact assessment** - What could an attacker do?
5. **Reproduction steps** - How to trigger the vulnerability
6. **Suggested fix** (if you have one)

We will:
- Acknowledge receipt within 48 hours
- Provide a timeline for a fix
- Work with you on disclosure timing
- Credit your discovery (unless you prefer anonymity)

## Security Considerations

### Authentication & Authorization

**Current Status**:
- No built-in authentication in core library
- Server module (`pymastra.server`) supports API key authentication
- All endpoints require API keys in production

**Best Practices**:
- Always run the server behind authentication
- Use environment variables for API keys (never hardcode)
- Rotate keys regularly
- Use HTTPS in production

### Input Validation

**Protected Areas**:
- All Pydantic models validate input schemas
- Step inputs validated against defined schemas
- Workflow triggers validated at execution
- Event data sanitized before logging

**Recommendations**:
- Validate all external inputs at system boundaries
- Use Pydantic for schema enforcement
- Treat user-provided code with caution

### Data Protection

**Considerations**:
- Workflow runs may contain sensitive data
- Storage backends should be protected with appropriate access controls
- SQLite files should have restricted file permissions (mode 0600)
- PostgreSQL connections should use SSL/TLS

**Best Practices**:
- Encrypt sensitive data at rest if needed
- Use appropriate database access controls
- Audit access to stored workflow runs
- Consider data retention policies

### Webhook Security

**Built-in Protections**:
- HMAC-SHA256 signatures on all webhook payloads
- Custom headers support for additional validation
- URL validation to prevent SSRF attacks
- Timeout on webhook delivery (10 seconds)
- Exponential backoff prevents overwhelming targets

**Configuration Requirements**:
- Always use webhook secrets in production
- Validate webhook signatures: `hmac.new(secret, msg, hashlib.sha256)`
- Verify webhook origin before processing
- Use HTTPS URLs for webhooks

**Example Validation**:
```python
import hmac
import hashlib

def verify_webhook(payload: str, signature: str, secret: str) -> bool:
    expected = hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(signature, expected)
```

### Error Handling

**Security Measures**:
- Error messages don't reveal system paths
- Database connection strings sanitized
- API responses don't expose internal stack traces
- Structured logging for audit trails

**Configuration**:
- Set `debug=False` in production
- Use custom error handlers for sensitive operations
- Log errors securely, don't expose to end users

### Dependencies

**Security Updates**:
- We monitor dependencies for vulnerabilities
- Use `safety` and `pip-audit` in CI/CD
- Update dependencies regularly
- Pin exact versions for reproducible deployments

**Checking Dependencies**:
```bash
# Check for known vulnerabilities
safety check
pip-audit

# Update all packages
pip list --outdated
```

### Type Safety

**Security Benefits**:
- 100% type hints prevent many runtime errors
- Mypy strict mode catches potential issues
- Pydantic validation at system boundaries
- Structured data reduces injection vulnerabilities

## Known Limitations

### v0.2.0 Known Issues

1. **LLM Integration**
   - LLM providers' API keys must be protected
   - Monitor token usage for cost control
   - Be cautious with system prompts that expose internals

2. **Tool/Function Calling**
   - Tools have full access to the Python runtime
   - Only register trusted functions as tools
   - LLMs can be tricked into calling tools unexpectedly

3. **Human-in-the-Loop**
   - Suspension payloads contain workflow context
   - Protect run_ids from unauthorized access
   - Validate all human-provided input

4. **Webhook Delivery**
   - Webhooks may retry on failure
   - Ensure webhook handlers are idempotent
   - Monitor webhook delivery logs

## Security Hardening Checklist

For production deployments:

- [ ] Use API key authentication
- [ ] Enable rate limiting (100 req/min per IP default)
- [ ] Use HTTPS for all connections
- [ ] Protect database credentials in environment variables
- [ ] Enable CORS only for trusted domains
- [ ] Validate all webhook URLs
- [ ] Configure HMAC secrets for webhooks
- [ ] Review error handling for information leakage
- [ ] Audit storage backend access controls
- [ ] Monitor authentication logs
- [ ] Keep dependencies updated
- [ ] Run regular security audits

## Example Secure Configuration

```python
from pymastra import Workflow
from pymastra.server import WorkflowServer
import os

# Load secrets from environment
API_KEY = os.environ.get("PYMASTRA_API_KEY")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET")
DATABASE_URL = os.environ.get("DATABASE_URL")

if not API_KEY:
    raise ValueError("PYMASTRA_API_KEY required in production")

# Configure server with security
server = WorkflowServer(
    auth_enabled=True,
    api_key=API_KEY,
    rate_limit=100,  # requests per minute
    cors_origins=["https://yourdomain.com"],  # Restrict CORS
    debug=False,  # Never debug in production
)

# Configure storage with credentials
from pymastra import PostgresStorage

storage = PostgresStorage(
    url=DATABASE_URL,
    # Connection string should be from environment only
)

# Register workflows
wf = Workflow(name="secure_workflow", ...)
server.register_workflow(wf)

# Configure webhooks
webhook = Webhook(
    url="https://external-service.com/webhook",
    secret=WEBHOOK_SECRET,  # From environment
    events=["workflow:completed"],
)
server.register_webhook(webhook)
```

## Response Timeframe

We will attempt to address security vulnerabilities as follows:

- **Critical** (CVSS 9.0-10.0): Within 24 hours
- **High** (CVSS 7.0-8.9): Within 3 days
- **Medium** (CVSS 4.0-6.9): Within 7 days
- **Low** (CVSS 0.1-3.9): Next minor release

Actual timelines may vary based on complexity and maintainer availability.

## Security Contact

For security issues: security@github.com (or maintainer email when updated)

## Version Support

| Version | Status | Support Until |
|---------|--------|---------------|
| 0.2.x   | Current | Latest only |
| 0.1.x   | EOL | 2026-06-06 |

Security fixes will be provided for the current version. We recommend always using the latest version.

## Acknowledgments

We appreciate responsible disclosure. Thank you to all security researchers who help keep Pymastra secure.
