"""Document Classification Workflow with Human-in-the-Loop.

Real business use case:
- Company receives 100+ documents daily
- Need to classify: Legal, Finance, HR, General
- Low-confidence classifications get human review
- Route to appropriate team based on classification

Demonstrates:
1. LLM integration for document classification
2. HITL for uncertain cases (low confidence)
3. Conditional branching based on confidence
4. Automatic routing to teams
"""

import asyncio
from typing import Literal

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    create_llm_step,
    LLMConfig,
)


class DocumentInput(BaseModel):
    """Input document to classify."""

    content: str
    """Document content to classify"""
    filename: str = "document"
    """Document filename for reference"""


class ClassificationResult(BaseModel):
    """Classification from LLM."""

    category: Literal["legal", "finance", "hr", "general"]
    """Document category"""
    confidence: Literal["high", "medium", "low"]
    """Confidence in classification"""
    reasoning: str
    """Why this classification"""


class HumanReviewResult(BaseModel):
    """Human review decision."""

    confirmed_category: Literal["legal", "finance", "hr", "general"]
    """Confirmed category after human review"""
    notes: str = ""
    """Human notes"""


class RoutingResult(BaseModel):
    """Final routing decision."""

    team: str
    """Team to route to"""
    priority: str
    """Priority level"""
    summary: str
    """Processing summary"""


async def main() -> None:
    """Run document classification workflow."""

    # LLM Configuration
    llm_config = LLMConfig(
        provider="claude",
        model="claude-3-5-sonnet-20241022",
        temperature=0.3,  # Low temp for consistent classification
        max_tokens=256,
    )

    # Step 1: Classify with LLM
    classify_step = create_llm_step(
        id="classify",
        description="Classify document type",
        system_prompt="""Classify the document into ONE category with confidence level.

Categories:
- LEGAL: Contracts, agreements, legal notices, compliance documents
- FINANCE: Invoices, financial statements, budget reports, payment docs
- HR: Employee records, payroll, benefits, recruitment, policy docs
- GENERAL: Other documents, announcements, general info

Respond in JSON format:
{
  "category": "legal|finance|hr|general",
  "confidence": "high|medium|low",
  "reasoning": "brief explanation"
}

Use LOW confidence when document could fit multiple categories.""",
        llm_config=llm_config,
        output_schema=ClassificationResult,
    )

    # Step 2: Human Review (only if low confidence)
    async def human_review_execute(ctx: StepContext) -> HumanReviewResult:
        """Human reviews and confirms classification."""
        classification = ctx.outputs["classify"]

        # Only suspend if confidence is low
        if classification.confidence != "low":
            # High/medium confidence - auto-confirm
            return HumanReviewResult(
                confirmed_category=classification.category,
                notes="Auto-confirmed by LLM confidence",
            )

        # Low confidence - ask human
        await ctx.suspend(
            {
                "message": "Please review this document classification",
                "document": ctx.trigger_data.filename,
                "llm_category": classification.category,
                "confidence": classification.confidence,
                "reasoning": classification.reasoning,
                "options": ["legal", "finance", "hr", "general"],
            }
        )

        # After resume, return empty - human_input becomes output
        return HumanReviewResult(confirmed_category="general")

    human_review_step = Step(
        id="human_review",
        description="Human review for uncertain classifications",
        input_schema=ClassificationResult,
        output_schema=HumanReviewResult,
        execute=human_review_execute,
    )

    # Step 3: Route to team
    async def routing_execute(ctx: StepContext) -> RoutingResult:
        """Route document to appropriate team."""
        review_result = ctx.outputs["human_review"]
        category = review_result.confirmed_category

        # Route based on category
        routing_map = {
            "legal": ("Legal Team", "high"),
            "finance": ("Finance Team", "high"),
            "hr": ("HR Team", "medium"),
            "general": ("Admin Team", "low"),
        }

        team, priority = routing_map[category]

        return RoutingResult(
            team=team,
            priority=priority,
            summary=f"Routed to {team} ({category.upper()})",
        )

    routing_step = Step(
        id="routing",
        description="Route to appropriate team",
        input_schema=HumanReviewResult,
        output_schema=RoutingResult,
        execute=routing_execute,
    )

    # Build workflow
    wf = Workflow(
        name="document_classifier",
        trigger_schema=DocumentInput,
    )

    wf.step(classify_step).then(human_review_step).then(routing_step).commit()

    # Test documents
    test_documents = [
        DocumentInput(
            filename="contract_2024.pdf",
            content="This Agreement between Company A and Company B...",
        ),
        DocumentInput(
            filename="invoice_march.xlsx",
            content="Invoice #INV-2024-001. Amount Due: $5,000...",
        ),
        DocumentInput(
            filename="employee_handbook.pdf",
            content="Employee Code of Conduct and Benefits Guide...",
        ),
        DocumentInput(
            filename="announcement.txt",
            content="Office will be closed on April 15 for maintenance...",
        ),
    ]

    print("\n" + "=" * 70)
    print("DOCUMENT CLASSIFICATION WORKFLOW")
    print("=" * 70)

    for doc in test_documents:
        print(f"\n📄 Processing: {doc.filename}")
        print(f"   Content: {doc.content[:60]}...")

        # Execute workflow
        run = await wf.execute(doc)

        if run.status == "suspended":
            # Low-confidence classification needs human review
            print(f"   ⏸️  Status: SUSPENDED (awaiting human review)")
            print(f"   📋 Suspension Payload:")
            if run.suspend_payload:
                print(f"      - Message: {run.suspend_payload.get('message')}")
                print(f"      - LLM Category: {run.suspend_payload.get('llm_category')}")
                print(f"      - Reasoning: {run.suspend_payload.get('reasoning')}")

            # Simulate human review - auto-confirm
            print(f"\n   👤 Human Review: Confirming category...")
            classification = run.outputs["classify"]
            human_input = {
                "confirmed_category": classification.category,
                "notes": "Confirmed by human reviewer",
            }

            resumed_run = await run.resume(human_input)

            if resumed_run.status == "completed":
                result = resumed_run.outputs["routing"]
                print(f"   ✅ Status: COMPLETED")
                print(f"   🎯 Team: {result.team}")
                print(f"   📊 Priority: {result.priority}")

        elif run.status == "completed":
            # High-confidence - auto-completed
            result = run.outputs["routing"]
            print(f"   ✅ Status: COMPLETED (auto-routed)")
            print(f"   🎯 Team: {result.team}")
            print(f"   📊 Priority: {result.priority}")
            classification = run.outputs["classify"]
            print(f"   📈 Confidence: {classification.confidence}")

        else:
            print(f"   ❌ Status: {run.status}")
            if run.error:
                print(f"   Error: {run.error}")

    print("\n" + "=" * 70)
    print("Classification workflow complete!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
