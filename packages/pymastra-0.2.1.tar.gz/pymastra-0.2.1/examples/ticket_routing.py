"""Support Ticket Routing Workflow with Critical Escalation.

Real business use case:
- Support tickets arrive continuously
- LLM analyzes: urgency, category, sentiment
- Critical tickets require manager approval before routing
- Routes to appropriate support team

Demonstrates:
1. Multi-step LLM analysis
2. HITL for critical decisions
3. Team-based routing
4. Realistic support workflow
"""

import asyncio
from typing import Literal

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    create_llm_step,
    LLMConfig,
)


class TicketInput(BaseModel):
    """Support ticket."""

    ticket_id: str
    """Ticket ID"""
    subject: str
    """Ticket subject"""
    message: str
    """Customer message"""


class AnalysisResult(BaseModel):
    """LLM analysis of ticket."""

    urgency: Literal["critical", "high", "medium", "low"]
    """Urgency level"""
    category: Literal["billing", "technical", "general", "feature_request"]
    """Support category"""
    sentiment: Literal["angry", "neutral", "satisfied"]
    """Customer sentiment"""
    summary: str
    """Brief summary"""


class ApprovalResult(BaseModel):
    """Manager approval result."""

    approved: bool
    """Whether approved for routing"""
    notes: str = ""
    """Manager notes"""


class RoutingResult(BaseModel):
    """Final routing."""

    team: str
    """Support team"""
    sla_hours: int
    """Response SLA in hours"""
    action: str
    """Action to take"""


async def main() -> None:
    """Run ticket routing workflow."""

    llm_config = LLMConfig(
        provider="claude",
        model="claude-3-5-sonnet-20241022",
        temperature=0.3,
    )

    # Step 1: Analyze ticket
    analyze_step = create_llm_step(
        id="analyze",
        description="Analyze support ticket",
        system_prompt="""Analyze this support ticket and respond in JSON:

{
  "urgency": "critical|high|medium|low",
  "category": "billing|technical|general|feature_request",
  "sentiment": "angry|neutral|satisfied",
  "summary": "one sentence summary"
}

Rules:
- CRITICAL: System down, data loss, major issue
- HIGH: Feature broken, workaround exists
- MEDIUM: Minor issue, user frustrated
- LOW: Question, feature request
- Detect ANGRY sentiment if customer uses caps, exclamation marks, complaints""",
        llm_config=llm_config,
        output_schema=AnalysisResult,
    )

    # Step 2: Manager approval for critical tickets
    async def approval_execute(ctx: StepContext) -> ApprovalResult:
        """Manager approves critical tickets before routing."""
        analysis = ctx.outputs["analyze"]

        # Only critical tickets need approval
        if analysis.urgency != "critical":
            return ApprovalResult(approved=True, notes="Auto-approved (not critical)")

        # Critical - ask manager
        ticket = ctx.trigger_data
        await ctx.suspend(
            {
                "message": "CRITICAL ticket requires manager approval",
                "ticket_id": ticket.ticket_id,
                "subject": ticket.subject,
                "urgency": analysis.urgency,
                "sentiment": analysis.sentiment,
                "summary": analysis.summary,
            }
        )

        return ApprovalResult(approved=False)  # Will be overridden by resume

    approval_step = Step(
        id="approval",
        description="Manager approval for critical tickets",
        input_schema=AnalysisResult,
        output_schema=ApprovalResult,
        execute=approval_execute,
    )

    # Step 3: Route to team
    async def routing_execute(ctx: StepContext) -> RoutingResult:
        """Route ticket to appropriate team."""
        analysis = ctx.outputs["analyze"]

        # Route by category
        if analysis.category == "billing":
            team = "Billing Team"
        elif analysis.category == "technical":
            team = "Technical Team"
        elif analysis.category == "feature_request":
            team = "Product Team"
        else:
            team = "General Support"

        # SLA by urgency
        sla_map = {
            "critical": 1,
            "high": 4,
            "medium": 24,
            "low": 48,
        }
        sla = sla_map[analysis.urgency]

        # Action by sentiment
        action = "Prioritize" if analysis.sentiment == "angry" else "Standard"

        return RoutingResult(
            team=team,
            sla_hours=sla,
            action=f"{action} response to {team}",
        )

    routing_step = Step(
        id="routing",
        description="Route to support team",
        input_schema=ApprovalResult,
        output_schema=RoutingResult,
        execute=routing_execute,
    )

    # Build workflow
    wf = Workflow(
        name="ticket_router",
        trigger_schema=TicketInput,
    )

    wf.step(analyze_step).then(approval_step).then(routing_step).commit()

    # Test tickets
    test_tickets = [
        TicketInput(
            ticket_id="TKT-001",
            subject="Database completely down",
            message="URGENT! Our database is completely offline! "
            "We can't process any transactions. This is a CRITICAL issue!",
        ),
        TicketInput(
            ticket_id="TKT-002",
            subject="Billing question",
            message="I have a question about my invoice from last month.",
        ),
        TicketInput(
            ticket_id="TKT-003",
            subject="Feature request",
            message="Would it be possible to add dark mode to the dashboard?",
        ),
        TicketInput(
            ticket_id="TKT-004",
            subject="Cannot login to account",
            message="I'm getting an error when trying to login. Says invalid credentials "
            "but I know my password is correct.",
        ),
    ]

    print("\n" + "=" * 70)
    print("SUPPORT TICKET ROUTING WORKFLOW")
    print("=" * 70)

    for ticket in test_tickets:
        print(f"\n🎫 Ticket: {ticket.ticket_id}")
        print(f"   Subject: {ticket.subject}")
        print(f"   Message: {ticket.message[:60]}...")

        # Execute workflow
        run = await wf.execute(ticket)

        if run.status == "suspended":
            # Critical ticket needs manager approval
            print(f"   ⏸️  Status: SUSPENDED (waiting for manager)")
            if run.suspend_payload:
                print(f"   🚨 Urgency: {run.suspend_payload.get('urgency')}")
                print(f"   📝 Summary: {run.suspend_payload.get('summary')}")

            # Simulate manager approval
            print(f"   👤 Manager approves critical ticket...")
            manager_decision = {"approved": True, "notes": "Approved - escalate to VP"}

            resumed_run = await run.resume(manager_decision)

            if resumed_run.status == "completed":
                result = resumed_run.outputs["routing"]
                print(f"   ✅ Status: COMPLETED")
                print(f"   🎯 Team: {result.team}")
                print(f"   ⏱️  SLA: {result.sla_hours} hours")
                print(f"   🔔 Action: {result.action}")

        elif run.status == "completed":
            # Non-critical - auto-routed
            analysis = run.outputs["analyze"]
            result = run.outputs["routing"]
            print(f"   ✅ Status: COMPLETED (auto-routed)")
            print(f"   🚨 Urgency: {analysis.urgency}")
            print(f"   🎯 Team: {result.team}")
            print(f"   ⏱️  SLA: {result.sla_hours} hours")
            print(f"   🔔 Action: {result.action}")

        else:
            print(f"   ❌ Status: {run.status}")

    print("\n" + "=" * 70)
    print("Ticket routing complete!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
