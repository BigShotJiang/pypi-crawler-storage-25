"""Example: Pymastra Server with Approval Dashboard.

Demonstrates:
- Running Pymastra server with FastAPI
- Building workflows with human-in-the-loop approval
- Using the built-in approval dashboard UI
- Resuming workflows from the dashboard

The dashboard provides:
- Real-time view of suspended workflows
- One-click approval/rejection
- Workflow execution history
- Run details and metadata

Run with: uvicorn examples.server_with_dashboard:app --reload

Then open: http://localhost:8000/dashboard
"""

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    server,
)


# ============================================================================
# Define schemas
# ============================================================================

class DocumentInput(BaseModel):
    """Input for document processing."""

    title: str
    content: str


class DocumentAnalysis(BaseModel):
    """Analysis result."""

    category: str
    summary: str


class ApprovalDecision(BaseModel):
    """Human approval decision."""

    approved: bool
    notes: str = ""


class FinalResult(BaseModel):
    """Final processing result."""

    title: str
    category: str
    processed: bool
    notes: str


# ============================================================================
# Define workflow steps
# ============================================================================

async def analyze_document(ctx: StepContext) -> DocumentAnalysis:
    """Analyze a document and classify it."""
    doc = ctx.trigger_data

    # Simulate document analysis
    categories = ["Legal", "Finance", "HR", "General"]
    content_lower = doc.content.lower()

    if any(word in content_lower for word in ["contract", "agreement", "legal"]):
        category = "Legal"
    elif any(word in content_lower for word in ["budget", "revenue", "invoice"]):
        category = "Finance"
    elif any(
        word in content_lower for word in ["employee", "salary", "hr", "hiring"]
    ):
        category = "HR"
    else:
        category = "General"

    return DocumentAnalysis(
        category=category,
        summary=f"Classified as {category}. {doc.content[:100]}...",
    )


async def request_approval(ctx: StepContext) -> ApprovalDecision:
    """Request human approval for the document."""
    doc = ctx.trigger_data
    analysis = ctx.outputs.get("analyze")

    # Suspend for human approval
    await ctx.suspend(
        {
            "message": "Please review and approve this document",
            "title": doc.title,
            "category": analysis.category,
            "summary": analysis.summary,
            "content_preview": doc.content[:200] + "...",
        }
    )

    # This code runs after human approval is provided
    return ApprovalDecision(approved=True)


async def process_document(ctx: StepContext) -> FinalResult:
    """Process the approved document."""
    doc = ctx.trigger_data
    analysis = ctx.outputs.get("analyze")
    approval = ctx.outputs.get("approval")

    return FinalResult(
        title=doc.title,
        category=analysis.category,
        processed=approval.approved,
        notes=approval.notes,
    )


# ============================================================================
# Build the workflow
# ============================================================================

# Create server instance
app_server = server.create_server()

# Create steps
analyze_step = Step(
    id="analyze",
    description="Analyze and classify the document",
    input_schema=DocumentInput,
    output_schema=DocumentAnalysis,
    execute=analyze_document,
)

approval_step = Step(
    id="approval",
    description="Request human approval",
    input_schema=DocumentInput,
    output_schema=ApprovalDecision,
    execute=request_approval,
)

process_step = Step(
    id="process",
    description="Process the approved document",
    input_schema=DocumentInput,
    output_schema=FinalResult,
    execute=process_document,
)

# Build workflow
document_workflow = Workflow(
    name="document_processing",
    trigger_schema=DocumentInput,
)
document_workflow.step(analyze_step).then(approval_step).then(process_step).commit()

# Register workflow
app_server.register_workflow("document_processing", document_workflow)

# Create another workflow for testing
async def quick_task(ctx: StepContext) -> dict:
    """Quick task workflow."""
    return {"result": "completed", "input": str(ctx.trigger_data)}


quick_step = Step(
    id="task",
    description="Quick task",
    input_schema=BaseModel,
    output_schema=dict,
    execute=quick_task,
)

quick_workflow = Workflow(name="quick_task", trigger_schema=BaseModel)
quick_workflow.step(quick_step).commit()
app_server.register_workflow("quick_task", quick_workflow)

# Get the FastAPI app
app = app_server.get_app()


# ============================================================================
# Custom routes for demonstration
# ============================================================================

@app.get("/")
async def root() -> dict:
    """Root endpoint."""
    return {
        "message": "Pymastra Workflow Server with Dashboard",
        "dashboard": "/dashboard",
        "documentation": "/docs",
        "workflows": list(app_server.workflows.keys()),
    }


@app.get("/workflows")
async def list_workflows() -> dict:
    """List available workflows."""
    return {
        "workflows": [
            {
                "id": wf_id,
                "name": wf.name,
                "description": f"Workflow with {len(wf.steps)} steps",
            }
            for wf_id, wf in app_server.workflows.items()
        ]
    }


# ============================================================================
# Usage Instructions
# ============================================================================

if __name__ == "__main__":
    import uvicorn

    print(
        """
╔════════════════════════════════════════════════════════════════════════════╗
║           Pymastra Workflow Server with Approval Dashboard                 ║
╚════════════════════════════════════════════════════════════════════════════╝

🚀 Starting server...

📊 Dashboard:     http://localhost:8000/dashboard
📚 API Docs:      http://localhost:8000/docs
🔍 ReDoc:         http://localhost:8000/redoc

════════════════════════════════════════════════════════════════════════════════

📋 Available Workflows:

1. document_processing - Analyze, approve, and process documents
   Workflow:
     1. Analyze document (auto) → DocumentAnalysis
     2. Request approval (HITL) → ApprovalDecision
     3. Process document (auto) → FinalResult

2. quick_task - Simple quick task workflow

════════════════════════════════════════════════════════════════════════════════

🎯 Quick Start:

1. Open the dashboard: http://localhost:8000/dashboard

2. Execute a workflow via curl:

   curl -X POST http://localhost:8000/workflows/execute \\
     -H "Content-Type: application/json" \\
     -d '{
       "workflow_id": "document_processing",
       "data": {
         "title": "Employment Agreement",
         "content": "This is an employment contract..."
       }
     }'

3. The workflow will suspend at the approval step.

4. In the dashboard, you'll see the suspended workflow.
   Click "Approve" to continue execution.

5. The workflow will then process and complete.

════════════════════════════════════════════════════════════════════════════════

📝 Example Workflows to Try:

Document Processing Workflow:
  curl -X POST http://localhost:8000/workflows/execute \\
    -H "Content-Type: application/json" \\
    -d '{
      "workflow_id": "document_processing",
      "data": {
        "title": "Legal Document",
        "content": "This is a contract agreement with legal terms and conditions..."
      }
    }'

Quick Task Workflow:
  curl -X POST http://localhost:8000/workflows/execute \\
    -H "Content-Type: application/json" \\
    -d '{
      "workflow_id": "quick_task",
      "data": {"test": "value"}
    }'

════════════════════════════════════════════════════════════════════════════════

Press Ctrl+C to stop the server.
"""
    )

    uvicorn.run(app, host="0.0.0.0", port=8000)
