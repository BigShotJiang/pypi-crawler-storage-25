"""Example: Observability, tracing, and metrics.

Demonstrates:
- Event logging for workflow execution
- Execution tracing with spans
- Metrics collection (counters, timings)
- Real-time monitoring dashboard
- Integration with monitoring systems

Run with: python examples/observability_demo.py
"""

import asyncio
import json
import time
from typing import Any

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
)
from pymastra.observability import (
    EventType,
    EventLogger,
    Metrics,
    TraceContext,
    get_metrics,
    get_event_logger,
)


# ============================================================================
# Define schemas
# ============================================================================

class DataInput(BaseModel):
    """Input for processing."""

    value: int
    operation: str = "process"


class ProcessOutput(BaseModel):
    """Processing result."""

    result: int
    processed_at: float


# ============================================================================
# Setup observability
# ============================================================================

metrics = get_metrics()
event_logger = get_event_logger()


async def log_to_console(event: Any) -> None:
    """Example event handler that logs to console."""
    data = event.to_dict() if hasattr(event, 'to_dict') else event
    print(f"  📊 {data['type']}: {data['message']}")


# Register the console logger
event_logger.register_handler(log_to_console)


# ============================================================================
# Define workflow steps
# ============================================================================

async def step1_process(ctx: StepContext) -> ProcessOutput:
    """First processing step."""
    # Create trace context for this step
    metrics.record_step_executed("process", duration_ms=100)

    # Simulate processing
    await asyncio.sleep(0.1)

    inp = ctx.trigger_data
    result = inp.value * 2

    return ProcessOutput(result=result, processed_at=time.time())


async def step2_validate(ctx: StepContext) -> ProcessOutput:
    """Validation step."""
    metrics.record_step_executed("validate", duration_ms=50)

    # Simulate processing
    await asyncio.sleep(0.05)

    process_output = ctx.outputs.get("process")

    # Validate result
    if process_output.result > 1000:
        metrics.record_step_failed()
        raise ValueError("Result too large")

    return process_output


async def step3_finalize(ctx: StepContext) -> ProcessOutput:
    """Final step."""
    metrics.record_step_executed("finalize", duration_ms=75)

    # Simulate processing
    await asyncio.sleep(0.075)

    return ctx.outputs.get("validate")


# ============================================================================
# Build workflow
# ============================================================================

workflow = Workflow(
    name="observability_demo",
    trigger_schema=DataInput,
)

process_step = Step(
    id="process",
    description="Process data",
    input_schema=DataInput,
    output_schema=ProcessOutput,
    execute=step1_process,
)

validate_step = Step(
    id="validate",
    description="Validate result",
    input_schema=DataInput,
    output_schema=ProcessOutput,
    execute=step2_validate,
)

finalize_step = Step(
    id="finalize",
    description="Finalize result",
    input_schema=DataInput,
    output_schema=ProcessOutput,
    execute=step3_finalize,
)

workflow.step(process_step).then(validate_step).then(finalize_step).commit()


# ============================================================================
# Main execution with observability
# ============================================================================

async def run_with_tracing(data: DataInput) -> None:
    """Run workflow with full tracing."""
    trace = TraceContext(run_id="demo-run-1", workflow_id=workflow.name)

    # Record workflow start
    metrics.record_workflow_start()
    await event_logger.log_event(
        event_logger.get_events()[0] if event_logger.events else None
        or type('Event', (), {
            'type': EventType.WORKFLOW_START,
            'message': f'Starting workflow: {workflow.name}',
            'run_id': trace.run_id,
            'workflow_id': trace.workflow_id,
            'step_id': None,
            'to_dict': lambda: {
                'type': EventType.WORKFLOW_START.value,
                'message': f'Starting workflow: {workflow.name}',
                'run_id': trace.run_id,
                'workflow_id': trace.workflow_id,
            }
        })()
    )

    try:
        print("\n" + "=" * 70)
        print(f"🚀 Workflow: {workflow.name}")
        print(f"📝 Input: {data}")
        print("=" * 70)

        # Execute workflow
        run = await workflow.execute(data)

        # Record workflow completion
        if run.status == "completed":
            metrics.record_workflow_complete()
        elif run.status == "failed":
            metrics.record_workflow_failed()
        elif run.status == "suspended":
            metrics.record_workflow_suspended()

        print("\n" + "=" * 70)
        print(f"✅ Workflow completed with status: {run.status}")
        print("=" * 70)

    except Exception as e:
        metrics.record_workflow_failed()
        print(f"\n❌ Workflow failed: {e}")

    # Print trace summary
    print("\n" + "=" * 70)
    print("📊 TRACE SUMMARY")
    print("=" * 70)
    summary = trace.get_summary()
    print(f"Duration: {summary['total_duration_ms']:.2f}ms")
    print(f"Events: {summary['events']}")
    print(f"Spans: {summary['spans']}")


async def main() -> None:
    """Run demonstration."""
    print("\n" + "=" * 70)
    print("Pymastra Observability & Metrics Demo")
    print("=" * 70)

    # Test cases
    test_cases = [
        DataInput(value=5, operation="process"),
        DataInput(value=10, operation="process"),
        DataInput(value=20, operation="process"),
    ]

    for i, test in enumerate(test_cases, 1):
        print(f"\n\n{'=' * 70}")
        print(f"TEST CASE {i}/{len(test_cases)}")
        print(f"{'=' * 70}")
        await run_with_tracing(test)

    # Print final metrics
    print("\n" + "=" * 70)
    print("📈 FINAL METRICS SUMMARY")
    print("=" * 70)

    metrics_summary = metrics.get_summary()

    print("\n📊 Workflows:")
    for key, value in metrics_summary["workflows"].items():
        if isinstance(value, float):
            print(f"  {key}: {value:.1f}")
        else:
            print(f"  {key}: {value}")

    print("\n📊 Steps:")
    for key, value in metrics_summary["steps"].items():
        print(f"  {key}: {value}")

    print("\n📊 Tools:")
    for key, value in metrics_summary["tools"].items():
        if isinstance(value, float):
            print(f"  {key}: {value:.1f}")
        else:
            print(f"  {key}: {value}")

    print("\n⏱️  Step Timings (milliseconds):")
    for step_id, stats in metrics_summary["step_timings"].items():
        if stats["count"] > 0:
            print(f"  {step_id}:")
            print(f"    Count: {stats['count']}")
            print(f"    Min: {stats['min_ms']:.2f}ms")
            print(f"    Max: {stats['max_ms']:.2f}ms")
            print(f"    Avg: {stats['avg_ms']:.2f}ms")

    print("\n📝 Events Logged:")
    print(f"  Total: {len(event_logger.events)}")

    if event_logger.events:
        print(f"  Types:")
        event_types = {}
        for event in event_logger.events:
            event_type = event.type.value
            event_types[event_type] = event_types.get(event_type, 0) + 1

        for event_type, count in event_types.items():
            print(f"    {event_type}: {count}")

    print("\n" + "=" * 70)
    print("Export metrics as JSON:")
    print("=" * 70)
    print(json.dumps(metrics_summary, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
