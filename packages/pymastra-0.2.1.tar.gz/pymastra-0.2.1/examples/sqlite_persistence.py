"""Example: Using SQLite for persistent workflow storage.

Demonstrates:
- Setting up SQLite storage backend
- Running workflows with persistence
- Resuming workflows from database
- Querying saved runs
- Migration from in-memory to SQLite

This is ideal for self-hosted deployments that need persistence
without a full database server.

Run with: python examples/sqlite_persistence.py
Or as server: uvicorn examples.sqlite_persistence:app --reload
"""

import asyncio
from pathlib import Path

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    SQLiteStorage,
    server,
)


# ============================================================================
# Define schemas
# ============================================================================

class NumberInput(BaseModel):
    """Input for number processing."""

    value: int
    operation: str = "double"


class ProcessResult(BaseModel):
    """Result of processing."""

    input_value: int
    operation: str
    result: int


class ApprovalInput(BaseModel):
    """Approval for the result."""

    approved: bool
    comment: str = ""


class FinalResult(BaseModel):
    """Final processing result."""

    input_value: int
    operation: str
    result: int
    approved: bool
    comment: str


# ============================================================================
# Define workflow steps
# ============================================================================

async def process_number(ctx: StepContext) -> ProcessResult:
    """Process a number based on the operation."""
    inp = ctx.trigger_data

    result = inp.value
    if inp.operation == "double":
        result = inp.value * 2
    elif inp.operation == "square":
        result = inp.value ** 2
    elif inp.operation == "factorial":
        import math
        result = math.factorial(inp.value)
    else:
        raise ValueError(f"Unknown operation: {inp.operation}")

    return ProcessResult(
        input_value=inp.value,
        operation=inp.operation,
        result=result,
    )


async def request_approval(ctx: StepContext) -> ApprovalInput:
    """Request human approval for the result."""
    inp = ctx.trigger_data
    process_result = ctx.outputs.get("process")

    # Suspend for human approval
    await ctx.suspend(
        {
            "message": "Please review and approve this result",
            "input": inp.value,
            "operation": inp.operation,
            "result": process_result.result,
        }
    )

    return ApprovalInput(approved=True)


async def finalize(ctx: StepContext) -> FinalResult:
    """Finalize the result based on approval."""
    inp = ctx.trigger_data
    process_result = ctx.outputs.get("process")
    approval = ctx.outputs.get("approval")

    return FinalResult(
        input_value=inp.value,
        operation=inp.operation,
        result=process_result.result,
        approved=approval.approved,
        comment=approval.comment,
    )


# ============================================================================
# Setup persistent storage
# ============================================================================

# Create SQLite storage in current directory
db_file = Path("pymastra_runs.db")
sqlite_storage = SQLiteStorage(str(db_file))

print(f"📦 Using SQLite database: {db_file.absolute()}")

# ============================================================================
# Build workflow with persistent storage
# ============================================================================

process_step = Step(
    id="process",
    description="Process the number",
    input_schema=NumberInput,
    output_schema=ProcessResult,
    execute=process_number,
)

approval_step = Step(
    id="approval",
    description="Request approval for the result",
    input_schema=NumberInput,
    output_schema=ApprovalInput,
    execute=request_approval,
)

finalize_step = Step(
    id="finalize",
    description="Finalize the result",
    input_schema=NumberInput,
    output_schema=FinalResult,
    execute=finalize,
)

# Build workflow with SQLite storage
workflow = Workflow(
    name="number_processor",
    trigger_schema=NumberInput,
    storage=sqlite_storage,
)
workflow.step(process_step).then(approval_step).then(finalize_step).commit()

# ============================================================================
# Setup FastAPI server with persistent storage
# ============================================================================

app_server = server.create_server(storage=sqlite_storage)
app_server.register_workflow("number_processor", workflow)
app = app_server.get_app()


@app.get("/")
async def root() -> dict:
    """Root endpoint with stats."""
    total = await sqlite_storage.count_runs()
    suspended = await sqlite_storage.count_runs(status="suspended")
    completed = await sqlite_storage.count_runs(status="completed")

    return {
        "message": "Pymastra Number Processor with SQLite Storage",
        "database": str(db_file.absolute()),
        "stats": {
            "total_runs": total,
            "suspended": suspended,
            "completed": completed,
        },
    }


@app.get("/api/stats")
async def stats() -> dict:
    """Get storage statistics."""
    statuses = ["running", "suspended", "completed", "failed"]
    counts = {}

    for status in statuses:
        counts[status] = await sqlite_storage.count_runs(status=status)

    return {
        "total_runs": await sqlite_storage.count_runs(),
        "by_status": counts,
        "database_file": str(db_file.absolute()),
    }


@app.get("/api/runs")
async def list_runs() -> dict:
    """List all workflow runs from the database."""
    runs = await sqlite_storage.list_runs(limit=50)

    return {
        "runs": [
            {
                "run_id": run.run_id,
                "workflow_id": run.workflow_id,
                "status": run.status,
                "suspended_at_step": run.suspended_at_step,
            }
            for run in runs
        ]
    }


# ============================================================================
# Standalone example
# ============================================================================

async def main() -> None:
    """Run example workflows and demonstrate persistence."""

    print("\n" + "=" * 70)
    print("Pymastra SQLite Persistence Example")
    print("=" * 70)

    # Test case 1: Execute a workflow
    print("\n1️⃣  Executing workflow: Double the number 5")
    print("-" * 70)

    inp1 = NumberInput(value=5, operation="double")
    run1 = await workflow.execute(inp1)

    print(f"Run ID: {run1.run_id}")
    print(f"Status: {run1.status}")
    print(f"Suspended at: {run1.suspended_at_step}")
    print(f"Context: {run1.suspend_payload}")

    # Test case 2: Load the run from database
    print("\n2️⃣  Loading run from SQLite database")
    print("-" * 70)

    loaded_run = await sqlite_storage.load_run(run1.run_id)
    if loaded_run:
        print(f"✓ Successfully loaded run from database")
        print(f"  Workflow: {loaded_run.workflow_id}")
        print(f"  Status: {loaded_run.status}")
        print(f"  Outputs: {loaded_run.outputs}")
    else:
        print("✗ Run not found in database")

    # Test case 3: Query runs by status
    print("\n3️⃣  Querying suspended workflows from database")
    print("-" * 70)

    suspended_runs = await sqlite_storage.list_runs(status="suspended", limit=10)
    print(f"Found {len(suspended_runs)} suspended workflow(s)")
    for run in suspended_runs:
        print(f"  - {run.run_id}: {run.workflow_id}")

    # Test case 4: Resume the workflow
    print("\n4️⃣  Resuming the workflow")
    print("-" * 70)

    resumed_run = await run1.resume({"approved": True, "comment": "Looks good!"})
    print(f"Resumed run status: {resumed_run.status}")
    if resumed_run.status == "completed":
        final = resumed_run.outputs.get("finalize")
        if final:
            print(f"✓ Result: {final.result}")

    # Test case 5: Run statistics
    print("\n5️⃣  Database statistics")
    print("-" * 70)

    total = await sqlite_storage.count_runs()
    suspended = await sqlite_storage.count_runs(status="suspended")
    completed = await sqlite_storage.count_runs(status="completed")

    print(f"Total runs: {total}")
    print(f"Suspended: {suspended}")
    print(f"Completed: {completed}")

    # Test case 6: Different operations
    print("\n6️⃣  Testing different operations")
    print("-" * 70)

    operations = [
        NumberInput(value=3, operation="square"),
        NumberInput(value=4, operation="double"),
    ]

    for op in operations:
        run = await workflow.execute(op)
        print(f"  {op.operation.upper()}({op.value}) → Suspended at: {run.suspended_at_step}")

    print("\n" + "=" * 70)
    print(f"Database file: {db_file.absolute()}")
    print(f"Run 'uvicorn examples.sqlite_persistence:app --reload' to start server")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
