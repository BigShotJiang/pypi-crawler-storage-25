#!/usr/bin/env python3
"""Production-ready Pymastra server with security best practices.

This example demonstrates:
- API key authentication
- Rate limiting
- CORS configuration
- Error sanitization
- Database persistence
- Structured logging
- Health checks
- Security headers
"""

import logging
import os
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None  # type: ignore

import uvicorn
from pydantic import BaseModel

from pymastra import Workflow, Step, StepContext
from pymastra.server import WorkflowServer
from pymastra.storage import SQLiteStorage, PostgresStorage


# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Define your workflow schemas
class ClassificationInput(BaseModel):
    """Input for document classification."""

    document: str
    confidence_threshold: float = 0.7


class ClassificationOutput(BaseModel):
    """Output from document classification."""

    category: str
    confidence: float


# Define workflow steps
async def classify_document(ctx: StepContext) -> ClassificationOutput:
    """Classify a document and request approval if low confidence.

    Args:
        ctx: Step context with input data

    Returns:
        ClassificationOutput with category and confidence
    """
    input_data = ctx.input

    # Simple classification (replace with actual LLM call)
    categories = ["Technical", "Business", "Legal", "Other"]
    category = categories[hash(input_data.document) % len(categories)]
    confidence = 0.95 - (hash(input_data.document) % 100) / 100

    # Request approval if confidence is low
    if confidence < input_data.confidence_threshold:
        await ctx.suspend({
            "message": "Low confidence classification",
            "document_preview": input_data.document[:200],
            "suggested_category": category,
            "confidence": confidence,
            "categories": categories,
        })
        # After resume, use human feedback
        if ctx.resume_input.get("approved"):
            category = ctx.resume_input.get("category", category)

    return ClassificationOutput(category=category, confidence=confidence)


async def log_result(ctx: StepContext) -> dict[str, Any]:
    """Log the classification result.

    Args:
        ctx: Step context with previous step outputs

    Returns:
        Logging confirmation
    """
    output = ctx.get_output("classify")

    logger.info(
        f"Classified document as {output.category} "
        f"(confidence: {output.confidence:.2%})"
    )

    return {
        "status": "logged",
        "category": output.category,
        "confidence": output.confidence,
    }


def load_configuration() -> dict[str, Any]:
    """Load configuration from environment variables.

    Returns:
        Configuration dictionary
    """
    # Load from .env file if exists
    if load_dotenv:
        load_dotenv()

    # API Security
    api_key = os.environ.get("PYMASTRA_API_KEY")
    if not api_key:
        raise ValueError(
            "PYMASTRA_API_KEY environment variable is required in production"
        )

    # Database configuration
    database_url = os.environ.get(
        "DATABASE_URL",
        "sqlite:///./data/workflows.db"
    )

    # CORS configuration
    cors_origins_str = os.environ.get("CORS_ORIGINS", "")
    cors_origins = [o.strip() for o in cors_origins_str.split(",")] if cors_origins_str else None

    # Server configuration
    config = {
        "api_key": api_key,
        "database_url": database_url,
        "cors_origins": cors_origins,
        "host": os.environ.get("PYMASTRA_HOST", "0.0.0.0"),
        "port": int(os.environ.get("PYMASTRA_PORT", "8000")),
        "workers": int(os.environ.get("PYMASTRA_WORKERS", "4")),
        "debug": os.environ.get("PYMASTRA_DEBUG", "false").lower() == "true",
        "rate_limit": int(os.environ.get("PYMASTRA_RATE_LIMIT", "100")),
    }

    return config


def create_storage(database_url: str) -> Any:
    """Create appropriate storage backend.

    Args:
        database_url: Database connection string

    Returns:
        Storage backend instance
    """
    if database_url.startswith("postgresql://"):
        logger.info("Using PostgreSQL storage backend")
        return PostgresStorage(url=database_url)
    elif database_url.startswith("sqlite://"):
        path = database_url.replace("sqlite:///", "")
        logger.info(f"Using SQLite storage backend: {path}")
        # Create directory if needed
        os.makedirs(os.path.dirname(path), exist_ok=True)
        return SQLiteStorage(path=path)
    else:
        raise ValueError(f"Unsupported database URL: {database_url}")


def create_workflow() -> Workflow:
    """Create the classification workflow.

    Returns:
        Compiled Workflow instance
    """
    wf = Workflow(
        name="document_classification",
        description="Classify documents with human-in-the-loop approval",
        trigger_schema=ClassificationInput,
    )

    # Step 1: Classify document
    classify_step = Step(
        id="classify",
        description="Classify document",
        input_schema=ClassificationInput,
        output_schema=ClassificationOutput,
        execute=classify_document,
    )

    # Step 2: Log result
    log_step = Step(
        id="log",
        description="Log classification result",
        output_schema=dict,
        execute=log_result,
    )

    # Build workflow
    wf.step(classify_step).then(log_step).commit()

    return wf


async def create_app() -> Any:
    """Create and configure the FastAPI application.

    Returns:
        FastAPI application instance with configured server
    """
    # Load configuration
    config = load_configuration()
    logger.info(f"Starting Pymastra server with config: {config}")

    # Create storage backend
    storage = create_storage(config["database_url"])

    # Create server with security configuration
    server = WorkflowServer(
        storage=storage,
        auth_enabled=True,
        api_key=config["api_key"],
        rate_limit=config["rate_limit"],
        cors_origins=config["cors_origins"],
        debug=config["debug"],
    )

    # Create and register workflow
    wf = create_workflow()
    server.register_workflow("classification", wf)

    logger.info("Workflow 'classification' registered")
    logger.info("API Key Authentication: Enabled")
    logger.info(f"Rate Limit: {config['rate_limit']} requests/minute")
    if config["cors_origins"]:
        logger.info(f"CORS Origins: {config['cors_origins']}")

    return server.get_app()


def main() -> None:
    """Run the production server."""
    config = load_configuration()

    # Create the app
    import asyncio
    app = asyncio.run(create_app())

    # Log startup info
    logger.info(f"Server starting on {config['host']}:{config['port']}")
    logger.info(f"Workers: {config['workers']}")
    logger.info(f"Debug mode: {config['debug']}")
    logger.info("API documentation available at /docs")
    logger.info("Approval dashboard available at /dashboard")

    # Start the server
    uvicorn.run(
        app,
        host=config["host"],
        port=config["port"],
        workers=config["workers"] if not config["debug"] else 1,
        log_level="info",
    )


if __name__ == "__main__":
    main()
