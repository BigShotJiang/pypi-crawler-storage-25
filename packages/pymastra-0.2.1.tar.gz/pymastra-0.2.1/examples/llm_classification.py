"""LLM-powered text classification example.

Demonstrates:
1. Creating LLM-powered steps
2. Using Claude to classify text
3. Integrating with workflow
4. Simple example < 50 lines (excluding comments)
"""

import asyncio

from pydantic import BaseModel

from pymastra import (
    Workflow,
    create_llm_step,
    LLMConfig,
)


class TextInput(BaseModel):
    """Input text to classify."""

    text: str


class ClassificationOutput(BaseModel):
    """Classification result."""

    category: str
    confidence: str
    reasoning: str


async def main() -> None:
    """Run LLM classification workflow."""

    # Configure LLM (uses Claude by default)
    llm_config = LLMConfig(
        provider="claude",
        model="claude-3-5-sonnet-20241022",
        temperature=0.3,  # Lower temp for consistent classification
    )

    # Create LLM-powered classification step
    classify_step = create_llm_step(
        id="classify",
        description="Classify text into categories",
        system_prompt="""You are a text classifier. Classify the input text into ONE of these categories:
        - NEWS: Current events, news articles
        - PRODUCT: Product reviews, descriptions
        - SUPPORT: Customer support requests
        - SPAM: Spam or irrelevant content

        Respond in JSON format: {"category": "...", "confidence": "high|medium|low", "reasoning": "..."}
        """,
        llm_config=llm_config,
        output_schema=ClassificationOutput,
    )

    # Build workflow
    wf = Workflow(name="text_classifier", trigger_schema=TextInput)
    wf.step(classify_step).commit()

    # Test examples
    test_texts = [
        "Apple releases new iPhone 15 with improved battery life",
        "This product is amazing! 5 stars!",
        "I need help with my account login",
        "Click here to win free money!!!",
    ]

    print("=" * 60)
    print("LLM CLASSIFICATION WORKFLOW")
    print("=" * 60)

    for text in test_texts:
        print(f"\n📝 Input: {text[:50]}...")

        # Execute workflow
        run = await wf.execute(TextInput(text=text))

        if run.status == "completed":
            result = run.outputs["classify"]
            print(f"✅ Status: {run.status}")
            print(f"   Category: {result.category}")
            print(f"   Confidence: {result.confidence}")
            print(f"   Reasoning: {result.reasoning}")
        else:
            print(f"❌ Status: {run.status}")
            if run.error:
                print(f"   Error: {run.error}")

    print("\n" + "=" * 60)
    print("Classification complete!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
