"""Example: Webhook integration with workflows.

Demonstrates:
- Registering webhooks for workflow events
- Triggering webhooks on specific events
- Webhook payload formatting
- Retry logic and failure tracking
- Integration with event logging

Note: This example uses mock webhooks. In production, you would
point webhooks to real external services.

Run with: python examples/webhooks_demo.py
"""

import asyncio
from typing import Any

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
)
from pymastra.webhooks import (
    Webhook,
    WebhookRegistry,
)
from pymastra.observability import EventType


# ============================================================================
# Define schemas
# ============================================================================

class DataInput(BaseModel):
    """Input for processing."""

    name: str
    value: int


class ProcessResult(BaseModel):
    """Processing result."""

    name: str
    result: int


# ============================================================================
# Setup webhooks
# ============================================================================

webhook_registry = WebhookRegistry()

# Register webhooks for different events
webhooks = [
    Webhook(
        id="slack-notifications",
        url="https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
        events=[
            EventType.WORKFLOW_START,
            EventType.WORKFLOW_COMPLETE,
        ],
        headers={
            "User-Agent": "Pymastra/0.1.0",
        },
    ),
    Webhook(
        id="error-tracking",
        url="https://api.sentry.io/webhook",
        events=[
            EventType.WORKFLOW_FAILED,
            EventType.STEP_FAILED,
        ],
    ),
    Webhook(
        id="metrics-collector",
        url="https://metrics.example.com/api/events",
        events=[
            EventType.STEP_COMPLETE,
        ],
    ),
]

for webhook in webhooks:
    webhook_registry.register(webhook)

print(f"✓ Registered {len(webhooks)} webhooks")


# ============================================================================
# Define workflow steps
# ============================================================================

async def process_step(ctx: StepContext) -> ProcessResult:
    """Process the input."""
    inp = ctx.trigger_data
    return ProcessResult(name=inp.name, result=inp.value * 2)


async def validate_step(ctx: StepContext) -> ProcessResult:
    """Validate the result."""
    return ctx.outputs.get("process")


# ============================================================================
# Build workflow
# ============================================================================

workflow = Workflow(
    name="webhook_demo",
    trigger_schema=DataInput,
)

process = Step(
    id="process",
    description="Process data",
    input_schema=DataInput,
    output_schema=ProcessResult,
    execute=process_step,
)

validate = Step(
    id="validate",
    description="Validate result",
    input_schema=DataInput,
    output_schema=ProcessResult,
    execute=validate_step,
)

workflow.step(process).then(validate).commit()


# ============================================================================
# Main execution
# ============================================================================

async def main() -> None:
    """Run demonstration."""
    print("\n" + "=" * 70)
    print("Pymastra Webhook Integration Demo")
    print("=" * 70)

    # Show registered webhooks
    print("\n📨 Registered Webhooks:")
    print("-" * 70)
    for wh in webhook_registry.list_webhooks():
        events = ", ".join(e.value for e in wh.events)
        print(f"  • {wh.id}")
        print(f"    URL: {wh.url}")
        print(f"    Events: {events}")
        print()

    # Show webhooks by event type
    print("\n🎯 Webhooks by Event Type:")
    print("-" * 70)
    for event_type in [
        EventType.WORKFLOW_START,
        EventType.WORKFLOW_COMPLETE,
        EventType.STEP_COMPLETE,
        EventType.WORKFLOW_FAILED,
    ]:
        matching = webhook_registry.list_webhooks(event_type)
        if matching:
            wh_ids = ", ".join(w.id for w in matching)
            print(f"  {event_type.value}: {wh_ids}")

    # Execute workflows and trigger webhooks
    print("\n" + "=" * 70)
    print("Executing Workflows and Triggering Webhooks")
    print("=" * 70)

    test_data = [
        DataInput(name="Operation A", value=5),
        DataInput(name="Operation B", value=10),
        DataInput(name="Operation C", value=15),
    ]

    for i, data in enumerate(test_data, 1):
        print(f"\n📝 Test Case {i}: {data.name}")
        print("-" * 70)

        # Simulate workflow start event
        event_data = {
            "workflow_id": workflow.name,
            "message": f"Starting workflow for {data.name}",
            "input": data.model_dump(),
        }

        print(f"\n🚀 Triggering WORKFLOW_START webhooks...")
        result = await webhook_registry.trigger(
            EventType.WORKFLOW_START,
            event_data,
            run_id=f"run-{i}",
        )

        print(f"  Webhooks triggered: {result['webhooks_triggered']}")
        for webhook_id, delivery in result["deliveries"].items():
            status = "✓" if delivery["success"] else "✗"
            print(f"    {status} {webhook_id}: {delivery.get('error', 'OK')}")

        # Execute workflow
        try:
            run = await workflow.execute(data)

            # Simulate workflow complete event
            event_data = {
                "workflow_id": workflow.name,
                "status": run.status,
                "outputs": {k: str(v) for k, v in run.outputs.items()},
            }

            print(f"\n✅ Triggering WORKFLOW_COMPLETE webhooks...")
            result = await webhook_registry.trigger(
                EventType.WORKFLOW_COMPLETE,
                event_data,
                run_id=f"run-{i}",
            )

            print(f"  Webhooks triggered: {result['webhooks_triggered']}")
            for webhook_id, delivery in result["deliveries"].items():
                status = "✓" if delivery["success"] else "✗"
                print(f"    {status} {webhook_id}: {delivery.get('error', 'OK')}")

        except Exception as e:
            print(f"\n❌ Workflow failed: {e}")

            # Simulate workflow failed event
            event_data = {
                "workflow_id": workflow.name,
                "error": str(e),
            }

            print(f"\n🚨 Triggering WORKFLOW_FAILED webhooks...")
            result = await webhook_registry.trigger(
                EventType.WORKFLOW_FAILED,
                event_data,
                run_id=f"run-{i}",
            )

            print(f"  Webhooks triggered: {result['webhooks_triggered']}")

    # Show webhook statistics
    print("\n" + "=" * 70)
    print("📊 Webhook Statistics")
    print("=" * 70)

    failures = webhook_registry.get_failures()
    total_failures = sum(len(f) for f in failures.values())

    print(f"\nTotal failed deliveries: {total_failures}")

    if failures:
        print("\nFailures by webhook:")
        for webhook_id, fail_list in failures.items():
            print(f"  {webhook_id}: {len(fail_list)} failures")
            if fail_list:
                latest = fail_list[-1]
                print(f"    Latest: {latest.get('error', 'Unknown error')}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
