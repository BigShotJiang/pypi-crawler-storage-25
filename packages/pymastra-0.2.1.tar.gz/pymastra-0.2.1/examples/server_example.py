"""Example FastAPI server with Pymastra workflows.

Demonstrates:
- Setting up workflow server
- Registering workflows
- Running the server
- Example curl commands

Run with: uvicorn examples.server_example:app --reload
Then test with curl commands in comments below
"""

from pydantic import BaseModel

from pymastra import (
    Workflow,
    Step,
    StepContext,
    create_llm_step,
    LLMConfig,
    server,
)


# Define schemas
class ApprovalRequest(BaseModel):
    """Request for approval."""

    title: str
    description: str


class DraftOutput(BaseModel):
    """Draft output."""

    draft: str


class ApprovalDecision(BaseModel):
    """Approval decision."""

    approved: bool


class FinalOutput(BaseModel):
    """Final output."""

    result: str


# Create server instance
server_instance = server.create_server()

# Configure LLM
llm_config = LLMConfig(
    provider="claude",
    model="claude-3-5-sonnet-20241022",
)

# Define workflow steps
async def draft_fn(ctx: StepContext) -> DraftOutput:
    """Generate draft."""
    req = ctx.trigger_data
    return DraftOutput(draft=f"Draft: {req.title} - {req.description}")


draft_step = Step(
    id="draft",
    description="Generate draft",
    input_schema=ApprovalRequest,
    output_schema=DraftOutput,
    execute=draft_fn,
)

# LLM-powered review step
review_step = create_llm_step(
    id="review",
    description="Review draft with LLM",
    system_prompt="You are a content reviewer. Provide feedback in JSON: {\"approved\": true/false}",
    llm_config=llm_config,
    output_schema=ApprovalDecision,
)


async def finalize_fn(ctx: StepContext) -> FinalOutput:
    """Finalize based on approval."""
    decision = ctx.outputs["review"]
    return FinalOutput(
        result="Approved and published" if decision.approved else "Needs revision"
    )


finalize_step = Step(
    id="finalize",
    description="Finalize based on decision",
    input_schema=ApprovalDecision,
    output_schema=FinalOutput,
    execute=finalize_fn,
)

# Build workflow
approval_workflow = Workflow(
    name="approval_workflow",
    trigger_schema=ApprovalRequest,
)
approval_workflow.step(draft_step).then(review_step).then(finalize_step).commit()

# Register workflow
server_instance.register_workflow("approval", approval_workflow)

# Get the FastAPI app
app = server_instance.get_app()


# Add example routes with documentation
@app.get("/")
async def root() -> dict[str, str]:
    """Root endpoint with instructions."""
    return {
        "message": "Pymastra Workflow Server",
        "documentation": "/docs",
        "workflows": ["approval"],
        "example_command": (
            "curl -X POST http://localhost:8000/workflows/execute "
            "-H 'Content-Type: application/json' "
            "-d '{\"workflow_id\": \"approval\", "
            "\"data\": {\"title\": \"Budget Review\", \"description\": \"Q2 Budget\"}'"
        ),
    }


@app.get("/workflows")
async def list_workflows() -> dict[str, list[str]]:
    """List available workflows."""
    return {"workflows": list(server_instance.workflows.keys())}


if __name__ == "__main__":
    import uvicorn

    print(
        """
    ╔═════════════════════════════════════════════════════════════════╗
    ║          Pymastra Workflow Server - Example                     ║
    ╚═════════════════════════════════════════════════════════════════╝

    To run this server:
        uvicorn examples.server_example:app --reload

    Then test these endpoints:

    1. Health check:
        curl http://localhost:8000/health

    2. List workflows:
        curl http://localhost:8000/workflows

    3. Execute workflow:
        curl -X POST http://localhost:8000/workflows/execute \\
          -H "Content-Type: application/json" \\
          -d '{"workflow_id": "approval", "data": {"title": "Budget Review", "description": "Q2 Budget"}}'

       Response:
        {
          "run_id": "...",
          "status": "completed",
          "outputs": {...}
        }

    4. Get run status:
        curl http://localhost:8000/runs/{run_id}

    5. Get suspension payload (if suspended):
        curl http://localhost:8000/runs/{run_id}/suspend_payload

    6. Resume suspended workflow:
        curl -X POST http://localhost:8000/runs/{run_id}/resume \\
          -H "Content-Type: application/json" \\
          -d '{"human_input": {"approved": true}}'

    Documentation available at:
        http://localhost:8000/docs

    """
    )

    uvicorn.run(app, host="0.0.0.0", port=8000)
