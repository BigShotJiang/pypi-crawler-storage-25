"""Example: LLM Agent with tool/function calling.

Demonstrates:
- Creating tools with function signatures
- Tool registry management
- LLM agent with function calling
- Auto-execution of tool calls and result handling

Run with: python examples/agent_with_tools.py
"""

import asyncio
import math

from pydantic import BaseModel

from pymastra import (
    Workflow,
    create_tool_calling_step,
    LLMConfig,
    ToolRegistry,
    tool,
)


# Define input/output schemas
class AgentQuery(BaseModel):
    """Input for the agent."""

    query: str


class AgentResult(BaseModel):
    """Output from the agent."""

    answer: str


# ============================================================================
# APPROACH 1: Using @tool decorator
# ============================================================================

@tool
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b


@tool
def multiply(x: float, y: float) -> float:
    """Multiply two numbers."""
    return x * y


@tool
def sqrt(value: float) -> float:
    """Calculate square root of a number."""
    if value < 0:
        raise ValueError("Cannot take square root of negative number")
    return math.sqrt(value)


# ============================================================================
# APPROACH 2: Using ToolRegistry.register_function
# ============================================================================

registry = ToolRegistry()

# Register the decorated tools
registry.register(add)
registry.register(multiply)
registry.register(sqrt)


# Register additional functions
def power(base: float, exponent: float) -> float:
    """Raise base to the power of exponent."""
    return base ** exponent


registry.register_function(power, description="Raise base to exponent power")


# ============================================================================
# Build the workflow with function-calling agent
# ============================================================================

async def main() -> None:
    """Run the agent workflow."""

    # Configure the LLM (use Claude for best tool-calling support)
    llm_config = LLMConfig(
        provider="claude",
        model="claude-3-5-sonnet-20241022",
    )

    # Create the agent step with tools
    agent_step = create_tool_calling_step(
        id="math_agent",
        description="Math agent that can perform calculations",
        system_prompt=(
            "You are a helpful math agent. You have access to tools for "
            "basic math operations. Use them to answer questions and "
            "solve math problems. Always show your work."
        ),
        tools=registry,
        llm_config=llm_config,
    )

    # Build workflow
    workflow = Workflow(
        name="agent_workflow",
        trigger_schema=AgentQuery,
    )
    workflow.step(agent_step).commit()

    # Test queries
    test_queries = [
        "What is 25 + 17?",
        "Calculate the square root of 144",
        "If I have 3 apples and get 4 more, then give away half, how many do I have?",
        "What is 2 to the power of 10?",
    ]

    print("=" * 70)
    print("Math Agent with Tool Calling")
    print("=" * 70)

    for query in test_queries:
        print(f"\n📝 Query: {query}")
        print("-" * 70)

        try:
            # Execute the workflow
            run = await workflow.execute(AgentQuery(query=query))

            if run.status == "completed":
                # Get the agent output
                agent_output = run.outputs.get("math_agent")
                if agent_output:
                    print(f"✓ Response: {agent_output.content}")

                    if agent_output.tool_calls:
                        print(f"\n  Tools called: {len(agent_output.tool_calls)}")
                        for call in agent_output.tool_calls:
                            print(f"    - {call['tool']}({call['args']})")

                    print(f"  Tokens used: ~{agent_output.tokens_used}")

            elif run.status == "suspended":
                print(f"⏸ Workflow suspended at: {run.suspended_at_step}")
            else:
                print(f"✗ Workflow status: {run.status}")

        except Exception as e:
            print(f"✗ Error: {e}")

    print("\n" + "=" * 70)
    print("Available tools in registry:")
    print("=" * 70)
    for tool_def in registry.list_tools():
        print(f"\n  {tool_def['name']}")
        print(f"    Description: {tool_def['description']}")
        if tool_def.get("input_schema", {}).get("properties"):
            props = tool_def["input_schema"]["properties"]
            print(f"    Parameters: {list(props.keys())}")


if __name__ == "__main__":
    asyncio.run(main())
