# Pymastra Debugging Guide

This guide helps you debug common issues with Pymastra workflows.

## Error Types

### WorkflowValidationError

Raised when the workflow configuration is invalid.

**Common causes:**
- Workflow not committed before execution
- Duplicate step IDs
- Branch points to non-existent steps
- Invalid trigger data

**Example:**
```python
workflow = Workflow(name="test", trigger_schema=InputSchema)
workflow.step(step1).step(step2).commit()

# This will raise WorkflowValidationError:
# "Cannot execute workflow 'test': workflow must be committed first"
await workflow.execute(data)  # ← Missing .commit()
```

**Fix:** Always call `.commit()` after building your workflow with `.step()` and `.then()`.

---

### StepExecutionError

Raised when a step fails during execution.

**Common causes:**
- Exception raised in step's execute function
- Step function returns wrong type
- Dependency error in step logic

**Example:**
```python
async def my_step(ctx: StepContext) -> OutputSchema:
    # This raises an exception
    result = 1 / 0  # ZeroDivisionError
    return OutputSchema(result=result)
```

**Fix:** Wrap step logic in try-except or add retry configuration:
```python
step = Step(
    id="my_step",
    description="Do something",
    input_schema=InputSchema,
    output_schema=OutputSchema,
    execute=my_step,
    retry=RetryConfig(max_attempts=3, backoff="exponential")
)
```

---

### SuspendError

Raised when a step suspends execution for human input.

**This is expected behavior.** When a step calls `ctx.suspend()`, the workflow pauses and waits for human input.

**Example:**
```python
async def approval_step(ctx: StepContext) -> ApprovalResult:
    # Do some processing
    draft = "Generated content..."

    # Wait for human approval
    await ctx.suspend({
        "message": "Please review the draft below",
        "draft": draft
    })

    # After human approves, the input comes back here
    return ApprovalResult(approved=True)
```

**Handle it in your application:**
```python
run = await workflow.execute(trigger_data)

if run.status == "suspended":
    # Show human the suspension context
    context = run.suspend_payload
    # ... get human approval ...

    # Resume the workflow
    final_run = await run.resume({"approved": True})
    print(final_run.status)  # "completed"
```

---

### ResumeError

Raised when resuming a suspended workflow fails.

**Common causes:**
- Trying to resume a non-suspended workflow
- Invalid human input (doesn't match output schema)
- Workflow definition changed since suspension
- Missing run state

**Example:**
```python
# This raises ResumeError:
# "Cannot resume workflow: human input validation failed"
await run.resume({"wrong_field": "value"})
```

**Fix:** Match the expected schema:
```python
# Check what schema is expected
print(format_run_summary(run))

# Provide matching input
await run.resume({"approved": True})
```

---

## Debugging Tools

### Print Workflow Structure

Understand what steps exist before running:

```python
from pymastra import print_workflow_structure

workflow = Workflow(name="my_workflow", trigger_schema=Input)
workflow.step(step1).then(step2).then(step3).commit()

print_workflow_structure(workflow)
```

**Output:**
```
╔ Workflow: my_workflow
║ Committed: True
║ Steps (3):
║   1. step1
║      Description: First step
║      Input: Input
║      Output: StepOneOutput
║   2. step2
║      Description: Process
║      Input: StepOneOutput
║      Output: StepTwoOutput
║   3. step3
║      Description: Final
║      Input: StepTwoOutput
║      Output: FinalOutput
╚
```

### Format Run Summary

See the state of a workflow run:

```python
from pymastra import format_run_summary

run = await workflow.execute(data)
print(format_run_summary(run))
```

**Output:**
```
╔ Workflow Run Summary
║ Run ID: 550e8400-e29b-41d4-a716-446655440000
║ Status: suspended
║ Suspended at: approval_step
║ Outputs: 1 step(s)
║   - initial_step: str
║ Suspension context: 2 key(s)
║   - message
║   - draft
╚
```

### Format Step Context

Debug what's available within a step:

```python
async def my_step(ctx: StepContext) -> Output:
    from pymastra import format_step_context

    print(format_step_context(ctx.step_id, ctx.outputs, ctx.trigger_data))
    # ... step logic ...
```

---

## Common Issues & Solutions

### Issue: "Trigger data validation failed"

**Cause:** The input data doesn't match the workflow's trigger schema.

**Solution:**
```python
# Check your trigger schema
from pymastra import format_validation_error

trigger_schema = Workflow.trigger_schema
print(trigger_schema.model_json_schema())

# Make sure your data matches
data = {
    "field1": "value1",
    "field2": 123,
}
workflow = Workflow(name="test", trigger_schema=MySchema)
run = await workflow.execute(data)
```

### Issue: "Step returns wrong type"

**Cause:** Step's execute function returns a value that doesn't match output_schema.

**Solution:**
```python
from pydantic import BaseModel

class Output(BaseModel):
    result: str
    count: int

async def my_step(ctx: StepContext) -> Output:
    # ✓ Correct: return Output instance
    return Output(result="success", count=42)

    # ✗ Wrong: return dict
    # return {"result": "success", "count": 42}

    # ✗ Wrong: return wrong type
    # return "success"
```

### Issue: "Cannot resume: suspended_at_step is missing"

**Cause:** The run state was corrupted or loaded improperly.

**Solution:**
```python
# Always preserve the exact run object from execution
run = await workflow.execute(data)

if run.status == "suspended":
    # Use the same run object to resume
    final = await run.resume(human_input)

    # Don't try to load it again from storage without the workflow context
```

---

## Best Practices

### 1. Always Commit Workflows

```python
workflow = Workflow(name="my_workflow", trigger_schema=Input)
workflow.step(step1).step(step2).commit()  # ← Don't forget!
```

### 2. Use Meaningful Step IDs

```python
# ✓ Clear intent
step = Step(id="extract_entities", ...)

# ✗ Vague
step = Step(id="step1", ...)
```

### 3. Add Detailed Descriptions

```python
step = Step(
    id="classify",
    description="Classify document as legal, finance, hr, or general",
    # ...
)
```

### 4. Handle Errors Explicitly

```python
try:
    run = await workflow.execute(data)
except WorkflowValidationError as e:
    print(f"Invalid workflow: {e}")
except StepExecutionError as e:
    print(f"Step failed: {e}")
```

### 5. Use Retry for Flaky Operations

```python
step = Step(
    id="api_call",
    description="Call external API",
    execute=api_call_fn,
    retry=RetryConfig(
        max_attempts=3,
        delay_seconds=1.0,
        backoff="exponential"
    )
)
```

### 6. Log Run Details

```python
run = await workflow.execute(data)

if run.status == "failed":
    print(f"Run {run.run_id} failed")
    print(format_run_summary(run))
    # Log to your monitoring system
elif run.status == "suspended":
    print(f"Run {run.run_id} suspended")
    print(json.dumps(run.suspend_payload, indent=2))
```

---

## Performance Debugging

### Check Which Steps Take Longest

```python
import time

async def timed_step(ctx: StepContext) -> Output:
    start = time.time()

    result = await some_operation()

    elapsed = time.time() - start
    print(f"Step took {elapsed:.2f}s")
    return Output(result=result)
```

### Profile Memory Usage

```python
import tracemalloc

tracemalloc.start()

run = await workflow.execute(data)

current, peak = tracemalloc.get_traced_memory()
print(f"Current: {current / 1024 / 1024:.1f}MB; Peak: {peak / 1024 / 1024:.1f}MB")
```

---

## Getting Help

If you encounter issues:

1. Check the error message carefully - Pymastra provides detailed context
2. Use the debugging tools above
3. Print workflow structure to verify your setup
4. Check that all schemas match
5. Review the examples: `examples/*.py`

For bugs or feature requests: https://github.com/akashs101199/pymastra/issues
