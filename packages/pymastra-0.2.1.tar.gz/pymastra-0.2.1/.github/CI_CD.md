# CI/CD Pipeline Documentation

Automated testing, building, and publishing pipeline for Pymastra.

## Overview

The CI/CD pipeline is configured with GitHub Actions to automatically:
- Run tests on every push and pull request
- Check code quality (type checking, linting, formatting)
- Scan dependencies for security vulnerabilities
- Build distribution packages
- Publish releases to PyPI (on version tags)

## Pipeline Structure

```
┌─────────────────────────────────────────────────┐
│  Push to main / Pull Request / Tag Release      │
└──────────────────┬──────────────────────────────┘
                   │
        ┌──────────┼──────────┐
        │          │          │
    ┌───▼──┐  ┌───▼──┐  ┌───▼──┐
    │ Test │  │Security│ (parallel)
    │      │  │Audit   │
    └───┬──┘  └───┬──┘
        │         │
        └────┬────┘
             │
        ┌────▼────┐
        │  Build   │ (runs after test passes)
        │Distribution
        └────┬────┘
             │
        ┌────▼────┐
        │ Publish  │ (only on version tags)
        │to PyPI   │
        └──────────┘
```

## Jobs

### 1. Test Job

**Triggers**: Every push to main/master, every pull request

**Python versions**: 3.11, 3.12 (matrix strategy)

**Steps**:
- ✅ Checkout code
- ✅ Set up Python
- ✅ Install dependencies (includes dev extras)
- ✅ Type checking with mypy --strict
- ✅ Linting with ruff check
- ✅ Format checking with ruff format
- ✅ Run pytest with coverage
- ✅ Upload coverage to Codecov

**Success criteria**:
- All tests pass
- Type checking passes
- Linting passes
- Coverage acceptable

### 2. Security Job

**Triggers**: Every push to main/master, every pull request

**Steps**:
- ✅ Checkout code
- ✅ Set up Python 3.11
- ✅ Install security tools (safety, pip-audit)
- ✅ Run safety check (dependency vulnerabilities)
- ✅ Run pip-audit (additional security scanning)

**Note**: Security job allows failures (`|| true`) to prevent blocking releases on warnings

### 3. Build Job

**Triggers**: After test and security jobs pass

**Needs**: test, security (both must pass)

**Steps**:
- ✅ Checkout code
- ✅ Set up Python 3.11
- ✅ Install build tools
- ✅ Build distribution (wheel + sdist)
- ✅ Verify built artifacts
- ✅ Test install from wheel
- ✅ Upload artifacts to GitHub

### 4. Publish Job

**Triggers**: Only on version tags (v*)

**Example tags**: v0.1.0, v0.2.0, v1.0.0, v0.3.0-rc1

**Needs**: build (must succeed)

**Steps**:
- ✅ Download build artifacts
- ✅ Publish to PyPI (using trusted publishing)
- ✅ Create GitHub Release
- ✅ Attach artifacts to release
- ✅ Auto-generate release notes

**Security**: Uses PyPA trusted publishing (no token storage needed)

## Usage

### Automatic Testing

Tests run automatically on:
- Every push to main/master
- Every pull request to main/master

### Manual Workflow Run

View status at: https://github.com/akashs101199/pymastra/actions

## Releasing a New Version

### 1. Update Version in Code

```bash
# Update version in pyproject.toml
# Update version in pymastra/__init__.py
# Update CHANGELOG.md
git add pyproject.toml pymastra/__init__.py CHANGELOG.md
git commit -m "chore: Bump version to v0.3.0"
git push origin main
```

### 2. Create Version Tag

```bash
# Create annotated tag
git tag -a v0.3.0 -m "Release v0.3.0"

# Push tag to remote
git push origin v0.3.0
```

### 3. Automated Release Process

The pipeline automatically:
1. Runs all tests on the tag
2. Builds distribution packages
3. Publishes to PyPI
4. Creates GitHub Release
5. Attaches artifacts

### Release Variants

**Stable Release**:
```bash
git tag -a v0.3.0 -m "Release v0.3.0"
git push origin v0.3.0
```

**Release Candidate**:
```bash
git tag -a v0.3.0-rc1 -m "Release candidate v0.3.0-rc1"
git push origin v0.3.0-rc1
```

**Alpha/Beta**:
```bash
git tag -a v0.3.0-alpha1 -m "Alpha release"
git push origin v0.3.0-alpha1
```

## PyPI Publishing

### Setup (One-time)

1. **Register on PyPI**: https://pypi.org/account/register/

2. **Verify PyPI account** (check email)

3. **Add trusted publisher** (GitHub):
   - Go to PyPI account settings
   - Add GitHub OIDC trusted publisher
   - Repository: akashs101199/pymastra
   - Workflow: CI/CD
   - Environment: release

### Auto-Publishing on Release

When you push a version tag:

```
git push origin v0.3.0
  │
  └─> GitHub Actions triggers CI/CD
      │
      ├─> Run tests (must pass)
      │
      └─> Build packages
          │
          └─> Publish to PyPI (automatic)
              │
              └─> Create GitHub Release
```

**Installation will work immediately**:
```bash
pip install pymastra==0.3.0
```

## Monitoring

### Check Pipeline Status

1. **GitHub Actions**: https://github.com/akashs101199/pymastra/actions
2. **View specific workflow**: Click on any commit/tag
3. **View job logs**: Click on a failed job for details

### Coverage

Coverage reports uploaded to Codecov (badge in README).

### Status Badges

```markdown
[![CI/CD](https://github.com/akashs101199/pymastra/actions/workflows/ci.yml/badge.svg)](https://github.com/akashs101199/pymastra/actions/workflows/ci.yml)
```

## Troubleshooting

### Tests Failing

1. Check GitHub Actions logs
2. Run locally: `pytest tests/ -v`
3. Check Python version compatibility
4. Look for flaky tests (intermittent failures)

### Type Checking Failing

Run locally: `mypy pymastra/ --strict`

Common issues:
- Missing type hints
- Incorrect type annotations
- Optional/Union types not handled

### Linting Failures

Run locally: `ruff check pymastra/`

Fix automatically: `ruff check pymastra/ --fix`

### Security Warnings

View details in GitHub Actions logs.

Options:
- Fix the vulnerability (preferred)
- Update dependency version
- Document known issue

### Build Artifacts

Failed builds won't have artifacts. Check logs for errors.

### PyPI Publishing Failed

Common causes:
- Package already exists (version conflict)
- Invalid distribution format
- Missing README/description
- Authentication issue

Check logs for details. May need manual intervention.

## Best Practices

### Before Merging

1. ✅ Tests pass locally
2. ✅ Mypy type checking passes
3. ✅ Ruff linting passes
4. ✅ Code coverage acceptable
5. ✅ No security warnings

### Version Numbering

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR.MINOR.PATCH** (e.g., 0.2.0)
- Major: Breaking changes
- Minor: New features (backward compatible)
- Patch: Bug fixes

### Release Checklist

```
□ Update version in pyproject.toml
□ Update version in pymastra/__init__.py
□ Update CHANGELOG.md with all changes
□ Commit changes: git commit -m "chore: Bump to v0.3.0"
□ Create tag: git tag -a v0.3.0 -m "Release v0.3.0"
□ Push tag: git push origin v0.3.0
□ Verify on GitHub Actions
□ Verify on PyPI
□ Create announcement/blog post
```

## Workflow Files

**Location**: `.github/workflows/ci.yml`

**Configuration**:
- Triggers: push to main/master, tags v*, pull requests
- Python versions: 3.11, 3.12
- Test framework: pytest with coverage
- Linting: ruff
- Type checking: mypy strict
- Security: safety + pip-audit
- Publishing: PyPA trusted publishing

## Security

### No Secrets Required

The pipeline uses **PyPA Trusted Publishing**:
- No API tokens stored in secrets
- Uses GitHub OIDC authentication
- Automatic credential rotation
- Industry best practice

### Dependency Security

- `safety` scans for known vulnerabilities
- `pip-audit` audits Python packages
- Failures non-blocking (warnings only)

## Advanced Configuration

### Running Locally

Simulate CI pipeline:

```bash
# Test job
mypy pymastra/ --strict
ruff check pymastra/
ruff format --check pymastra/
pytest tests/ -v --cov=pymastra

# Security job
pip install safety pip-audit
safety check
pip-audit

# Build job
pip install build
python -m build
```

### Custom Environments

Override environment variables in workflow:

```yaml
env:
  PYTHON_VERSION: "3.12"
  REGISTRY: ghcr.io
```

### Branch Protection Rules

Recommended GitHub settings:

```
Branch: main
├─ Require status checks to pass
│  ├─ test (3.11)
│  ├─ test (3.12)
│  ├─ security
│  └─ build
├─ Require code review
├─ Dismiss stale pull request approvals
└─ Include administrators
```

## Resources

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [PyPA Build](https://github.com/pypa/build)
- [PyPA Trusted Publishing](https://docs.pypi.org/trusted-publishers/)
- [Semantic Versioning](https://semver.org/)
- [mypy](http://mypy-lang.org/)
- [ruff](https://github.com/astral-sh/ruff)
- [pytest](https://pytest.org/)

## Questions?

See [CONTRIBUTING.md](../CONTRIBUTING.md) for contributing guidelines.
