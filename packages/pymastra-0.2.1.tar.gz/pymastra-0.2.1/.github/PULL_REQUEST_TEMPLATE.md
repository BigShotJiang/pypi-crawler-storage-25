## Description

Briefly describe what this PR does and why.

Fixes #(issue)

## Type of Change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Test improvement
- [ ] Refactoring

## Changes Made

What specific changes were made?

- ...
- ...
- ...

## Testing

How was this tested?

- [ ] Added new unit tests
- [ ] Updated existing tests
- [ ] All tests pass locally: `pytest`
- [ ] Type checking passes: `mypy pymastra/ --strict`
- [ ] Linting passes: `ruff check pymastra/`

**Test Coverage**: (e.g., "Added 5 tests covering normal case, edge cases, and error conditions")

**Manual Testing**: (Describe any manual testing performed)

## Documentation

- [ ] Updated CHANGELOG.md
- [ ] Added/updated docstrings
- [ ] Updated relevant .md files
- [ ] Added/updated example code
- [ ] No documentation needed

**Documentation Changes**:
(Describe what was documented)

## Breaking Changes

- [ ] No breaking changes
- [ ] Contains breaking changes (describe below)

**Breaking Change Description**: (if applicable)

## Checklist

- [ ] Code follows the style guidelines of this project (100 char lines, type hints, etc.)
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests passed locally with my changes
- [ ] Any dependent changes have been merged and published in downstream modules

## Performance Impact

- [ ] No performance impact
- [ ] Performance impact (describe below)

**Benchmark Results**: (if applicable)

```
# Include benchmark output here
```

## Screenshots / Demos

(Add screenshots or GIFs if applicable)

## Additional Notes

Any additional context or information reviewers should know?

## Reviewer Notes

(Leave this section for reviewers to fill in)
