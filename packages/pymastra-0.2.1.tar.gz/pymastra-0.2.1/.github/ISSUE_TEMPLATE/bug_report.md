---
name: Bug Report
about: Report a bug or issue with Pymastra
title: "[BUG] "
labels: bug
assignees: ''

---

## Description
A clear and concise description of what the bug is.

## To Reproduce

Steps to reproduce the behavior:

1. ...
2. ...
3. ...

## Minimal Code Example

```python
# Paste minimal code that reproduces the issue here
```

## Expected Behavior

A clear description of what you expected to happen.

## Actual Behavior

What actually happened instead.

## Error Message & Stack Trace

```
Paste the full error message and stack trace here
```

## Environment

- **Python Version**: (e.g., 3.11.2)
- **OS**: (e.g., macOS, Linux, Windows)
- **Pymastra Version**: (e.g., 0.2.0)
- **Installation Method**: (e.g., `pip install pymastra[all]`)
- **Other relevant packages**: (e.g., OpenAI 1.3.0, PostgreSQL 16)

## Installed Extras

Which extras did you install? (Check all that apply)
- [ ] `[sqlite]` - SQLite persistence
- [ ] `[postgres]` - PostgreSQL persistence
- [ ] `[openai]` - OpenAI LLM support
- [ ] `[anthropic]` - Anthropic Claude support
- [ ] `[server]` - FastAPI REST API server
- [ ] `[all]` - All extras

## Additional Context

Any other context about the problem? (e.g., recent changes, other libraries, debugging attempts)

## Screenshots / Logs

If applicable, add screenshots or log output that might help diagnose the issue.

## Frequency

Does this happen:
- [ ] Always
- [ ] Intermittently
- [ ] Only under specific conditions (describe below)

## Workaround

Have you found a workaround? (Describe it here)
