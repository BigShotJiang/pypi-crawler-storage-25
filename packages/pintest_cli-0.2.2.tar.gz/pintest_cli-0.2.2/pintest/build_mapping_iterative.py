#!/usr/bin/env python3
"""
Iteratively build test mapping database by running tests one-by-one.

This script is designed to be resumable - if it fails or is interrupted,
you can run it again and it will continue from where it left off.

Usage:
    python build_mapping_iterative.py --repo-root ~/workspace/myproject
    
    # Continue after interruption:
    python build_mapping_iterative.py --repo-root ~/workspace/myproject --resume
"""

import argparse
import subprocess
import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Set

# Add pintest to path
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))

from pintest.test_mapping_db_v2 import TestMappingDBV2
from pintest.pre_commit_hook import (
    collect_all_tests,
    find_unmapped_tests,
    ensure_docker_containers,
    run_preflight_scripts
)


def run_test_chunk_with_mapping(
    repo_root: Path,
    test_names: list,
    mapping_db_path: Path,
    verbose: bool = False
) -> tuple[Set[str], Set[str]]:
    """
    Run a chunk of tests with coverage and update mapping.
    
    Args:
        repo_root: Repository root directory
        test_names: List of test names to run
        mapping_db_path: Path to mapping database
        verbose: Print verbose output
    
    Returns:
        Tuple of (passed_tests, failed_tests)
    """
    # Run chunk of tests with coverage
    cmd = [
        sys.executable, "-m", "pytest",
        "--cov=src",
        "--cov-context=test",
        "--cov-append",
        "--cov-report=",
        "-v",
        "--tb=short",
    ] + test_names
    
    print(f"   Running: {' '.join(cmd[:6])} ... {len(test_names)} tests", flush=True)
    
    result = subprocess.run(
        cmd,
        cwd=repo_root,
        text=True
    )
    
    # Parse pytest exit code
    # 0 = all passed, 1 = some failed, 2+ = errors/interrupted
    passed = set()
    failed = set()
    
    if result.returncode == 0:
        # All tests passed
        passed = set(test_names)
    else:
        # Some failed - for mapping purposes, we still got coverage
        # Mark all as "passed" (meaning: we have coverage data for them)
        passed = set(test_names)
    
    # Find and use coverage data files
    coverage_file = repo_root / ".coverage"
    coverage_chunks = list(repo_root.glob(".coverage.*"))
    
    # Filter out empty files
    valid_chunks = []
    for chunk_file in coverage_chunks:
        try:
            import sqlite3
            conn = sqlite3.connect(chunk_file)
            cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            conn.close()
            if tables:  # Has tables, so it's valid
                valid_chunks.append(chunk_file)
        except:
            pass  # Skip invalid files
    
    # Try to combine if needed
    if valid_chunks and not coverage_file.exists():
        combine_cmd = [sys.executable, "-m", "coverage", "combine"]
        subprocess.run(
            combine_cmd,
            cwd=repo_root,
            text=True
        )
    
    # Update mapping database - try .coverage first, then fall back to chunks
    try:
        import_source = None
        
        if coverage_file.exists():
            # Check if .coverage is valid (has tables)
            import sqlite3
            try:
                conn = sqlite3.connect(coverage_file)
                cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
                conn.close()
                if tables:
                    import_source = coverage_file
            except:
                pass
        
        # If .coverage is empty/invalid, use the largest chunk file
        if not import_source and valid_chunks:
            # Sort by size, use largest
            import_source = max(valid_chunks, key=lambda f: f.stat().st_size)
            if verbose:
                print(f"    📌 Using chunk file: {import_source.name}")
        
        if import_source:
            with TestMappingDBV2(mapping_db_path) as db:
                db.import_from_coverage(import_source, incremental=True)
        else:
            if verbose:
                print(f"    ⚠️  No valid coverage file found")
    except Exception as e:
        if verbose:
            print(f"    ⚠️  Could not update mapping: {e}")
    
    return passed, failed


def build_mapping_iteratively(
    repo_root: Path,
    mapping_db: Path,
    test_dir: str = "unit_tests",
    verbose: bool = False
):
    """
    Build mapping database by running unmapped tests.
    Uses database queries to determine which tests still need mapping.
    Resumable by design - just run again and it continues from where it left off.
    
    Args:
        repo_root: Repository root directory
        mapping_db: Path to mapping database
        test_dir: Test directory to collect from (default: "unit_tests")
        verbose: Print verbose output
    """
    repo_root = repo_root.resolve()
    
    print("🏗️  Test Mapping Builder")
    print("=" * 80)
    print(f"Repository: {repo_root}")
    print(f"Mapping DB: {mapping_db}")
    
    # Ensure Docker and preflight checks
    print("\n🔧 Pre-checks...")
    if not ensure_docker_containers(repo_root, verbose):
        print("❌ Docker container check failed.")
        return 1
    
    if not run_preflight_scripts(repo_root, verbose):
        print("❌ Preflight checks failed.")
        return 1
    
    # Initialize mapping database
    with TestMappingDBV2(mapping_db) as db:
        db.initialize_schema()
    
    # Find unmapped tests by querying database
    print("\n🔍 Finding unmapped tests...")
    unmapped_tests = find_unmapped_tests(repo_root, mapping_db, test_dir, verbose)
    
    if not unmapped_tests:
        print("\n✅ All tests already mapped!")
        return 0
    
    # Determine if we need chunking (OS ARG_MAX limit protection)
    remaining_list = sorted(unmapped_tests)
    total_tests = len(remaining_list)
    chunk_size = 1000  # Safe threshold to avoid "Argument list too long"
    
    needs_chunking = total_tests > chunk_size
    
    print(f"\n📊 Test Statistics:")
    print(f"   Unmapped tests: {total_tests}")
    
    print(f"\n{'='*80}")
    if needs_chunking:
        num_chunks = (total_tests + chunk_size - 1) // chunk_size
        print(f"Running {total_tests} tests in {num_chunks} chunks of up to {chunk_size}...")
        print(f"💡 Each chunk updates the database immediately - safe to interrupt/resume")
    else:
        print(f"Running {total_tests} test(s) at once...")
    print(f"{'='*80}")
    print()
    
    # Run tests (in chunks if needed)
    all_passed = set()
    all_failed = set()
    
    try:
        if needs_chunking:
            # Run in chunks
            for i in range(0, total_tests, chunk_size):
                chunk = remaining_list[i:i + chunk_size]
                chunk_num = (i // chunk_size) + 1
                total_chunks = (total_tests + chunk_size - 1) // chunk_size
                
                print(f"📦 Chunk {chunk_num}/{total_chunks}: Running {len(chunk)} tests...", flush=True)
                
                try:
                    passed, failed = run_test_chunk_with_mapping(
                        repo_root,
                        chunk,
                        mapping_db,
                        verbose
                    )
                    
                    # Track for final statistics
                    all_passed.update(passed)
                    all_failed.update(failed)
                    
                    print(f"   ✓ Chunk {chunk_num} complete: {len(passed)} passed, {len(failed)} failed", flush=True)
                    
                except Exception as e:
                    print(f"   ❌ Chunk {chunk_num} failed: {e}", flush=True)
                    # Continue with next chunk
                    continue
        else:
            # Run all at once (small enough)
            print(f"Running {len(remaining_list)} tests with coverage...", flush=True)
            
            passed, failed = run_test_chunk_with_mapping(
                repo_root,
                remaining_list,
                mapping_db,
                verbose
            )
            
            # Track for final statistics
            all_passed.update(passed)
            all_failed.update(failed)
            
            print(f"\n✓ {len(passed)} passed, ✗ {len(failed)} failed")
    
    except KeyboardInterrupt:
        print(f"\n\n⚠️  Interrupted by user!")
        print(f"💡 Next time you run, it will automatically continue from where it left off")
        print(f"   (unmapped tests are determined by querying the database)")
        return 130
    
    # Final summary
    print(f"\n{'='*80}")
    print("✅ Mapping build complete!")
    print(f"{'='*80}")
    print(f"\n📈 Final Statistics:")
    print(f"   Successfully mapped: {len(all_passed)} tests")
    print(f"   Failed (skipped):    {len(all_failed)} tests")
    
    # Report failed tests
    if all_failed:
        print(f"\n❌ Failed Tests ({len(all_failed)}):")
        for test_name in sorted(all_failed)[:10]:  # Show first 10
            print(f"   - {test_name}")
        if len(all_failed) > 10:
            print(f"   ... and {len(all_failed) - 10} more")
    
    # Show mapping DB stats
    with TestMappingDBV2(mapping_db) as db:
        stats = db.get_stats()
        print(f"\n📊 Mapping Database:")
        print(f"   Total tests:    {stats['total_tests']}")
        print(f"   Total files:    {stats['total_files']}")
        print(f"   Total mappings: {stats['total_mappings']}")
    
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Iteratively build test mapping database"
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path.cwd(),
        help="Repository root directory (default: current directory)"
    )
    parser.add_argument(
        "--mapping-db",
        type=Path,
        help="Path to mapping database (default: <repo>/.test_mapping.db)"
    )
    parser.add_argument(
        "--test-dir",
        type=str,
        default="unit_tests",
        help="Test directory to collect from (default: unit_tests from pytest.ini)"
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    
    args = parser.parse_args()
    
    repo_root = args.repo_root.resolve()
    mapping_db = args.mapping_db or (repo_root / ".test_mapping.db")
    
    return build_mapping_iteratively(
        repo_root,
        mapping_db,
        args.test_dir,
        args.verbose
    )


if __name__ == "__main__":
    sys.exit(main())
