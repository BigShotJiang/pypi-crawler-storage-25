from __future__ import annotations

import os
from importlib.metadata import version as _pkg_version

import typer

from .. import self_upgrade
from . import self_cmd
from .activity import app as activity_app
from .categories import app as categories_app
from .config import app as config_app
from .contacts import app as contacts_app
from .doctor import doctor_cmd as _doctor_cmd
from .events import app as events_app
from .firm import app as firm_app
from .households import app as households_app
from .internals import app as internals_app
from .me import app as me_app
from .notes import app as notes_app
from .opportunities import app as opportunities_app
from .prefs import app as prefs_app
from .projects import app as projects_app
from .self_cmd import app as self_app
from .skills import app as skills_app
from .tasks import app as tasks_app
from .users import app as users_app
from .workflows import app as workflows_app


def _check_pending_upgrade_status() -> None:
    """Surface the outcome of a deferred self-upgrade swap, if any.

    The Windows deferred-swap helper writes ``wbox.upgrade.status`` next to
    the binary after the swap (or after timing out). On the next ``wbox``
    launch — that is, here — we read it, print a one-line summary to stderr,
    and unlink it. Never raises; a corrupt status file would otherwise nag
    the user every invocation.

    If a ``wbox.skills_upgrade.pending`` marker exists (#40) and the deferred
    swap succeeded, also invoke ``<new binary> skills upgrade`` so the skill
    template tracks the new binary. The marker is always cleared, even when
    the upgrade failed, so a stale marker doesn't drive future invocations.

    Resolves ``_default_install_root`` through the module reference so tests
    can monkeypatch it on :mod:`cli.self_cmd` and have the change take
    effect here.
    """
    install_root = self_cmd._default_install_root()
    status = self_upgrade._read_and_clear_upgrade_status(install_root)
    if status is None:
        # No status yet (deferred-swap helper hasn't completed, or no upgrade
        # in flight). Leave the skills-upgrade marker in place — clearing it
        # now would lose the signal if the user relaunches before the helper
        # writes its status file. Next launch will see the status and the
        # marker together.
        return
    pending_marker = install_root / self_upgrade._SKILLS_UPGRADE_PENDING_FILENAME
    marker_existed = pending_marker.exists()
    if marker_existed:
        try:
            pending_marker.unlink(missing_ok=True)
        except OSError:
            pass
    version = status.get("version") or "?"
    swap_ok = status.get("result") == "ok"
    if swap_ok:
        typer.echo(f"wbox: upgrade to v{version} completed.", err=True)
    else:
        reason = status.get("reason") or "unknown error"
        typer.echo(
            f"wbox: upgrade to v{version} failed ({reason}). Old binary still in place.",
            err=True,
        )

    if swap_ok and marker_existed:
        binary_path = install_root / self_upgrade._binary_name()
        rc = self_upgrade._invoke_skills_upgrade(binary_path)
        if rc != 0:
            typer.echo(
                f"wbox: `wbox skills upgrade` exited with code {rc}; "
                "re-run manually to refresh the skill template.",
                err=True,
            )

app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]}, 
    name="wbox",
    help="Wealthbox CRM CLI — interact with contacts, households, tasks, events, opportunities, and notes.",
    no_args_is_help=True,
)

@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-v", is_eager=True, help="Show version and exit."),
    brief: bool = typer.Option(
        False, "--brief",
        help="Strip *_html fields from output (also via WBOX_BRIEF=1). "
             "Wealthbox duplicates every text field as html ~3-5x larger; "
             "agents and pipelines almost never want it.",
    ),
) -> None:
    _check_pending_upgrade_status()
    if version:
        typer.echo(_pkg_version("wealthbox-cli"))
        raise typer.Exit()
    if brief:
        os.environ["WBOX_BRIEF"] = "1"


app.command(
    "doctor",
    help="Comprehensive health check: CLI version, auth, agent CLIs, skills, plugins, firm.",
)(_doctor_cmd)


app.add_typer(activity_app, name="activity")
app.add_typer(categories_app, name="categories")
app.add_typer(config_app, name="config")
app.add_typer(contacts_app, name="contacts")
app.add_typer(events_app, name="events")
app.add_typer(firm_app, name="firm")
app.add_typer(households_app, name="households")
app.add_typer(internals_app, name="internals", hidden=True)
app.add_typer(me_app, name="me")
app.add_typer(notes_app, name="notes")
app.add_typer(opportunities_app, name="opportunities")
app.add_typer(prefs_app, name="prefs")
app.add_typer(projects_app, name="projects")
app.add_typer(self_app, name="self")
app.add_typer(skills_app, name="skills")
app.add_typer(tasks_app, name="tasks")
app.add_typer(users_app, name="users")
app.add_typer(workflows_app, name="workflows")


if __name__ == "__main__":
    app()
