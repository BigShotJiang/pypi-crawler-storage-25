"""Precision-parameterized IEEE 754 / MPFR reference constants.

Each constant exposes two forms:
  - attribute access: ``ieee754.PI`` uses ``DEFAULT_BITS`` precision
  - call form:        ``ieee754.PI(bits=53)`` computes at requested precision

All results are returned as ``TDFloat`` dyadic-rational approximations of the
MPFR value at the requested precision. Results are cached per bit-count.
"""

from __future__ import annotations

from ..tdfloat import TDFloat
from ._mpfr_bridge import mpfr_to_tdfloat, _require_gmpy2
from ._precision import DEFAULT_BITS


class _PrecisionConstant:
    """A callable, cached reference constant computed via MPFR.

    The instance itself acts like a default-precision ``TDFloat`` for
    arithmetic and equality; call it to pick a specific precision.
    """

    __slots__ = ('_fn', '_name', '_cache')

    def __init__(self, fn, name: str):
        self._fn = fn
        self._name = name
        self._cache: dict[int, TDFloat] = {}

    def __call__(self, bits: int = DEFAULT_BITS) -> TDFloat:
        if bits not in self._cache:
            gmpy2 = _require_gmpy2()
            with gmpy2.context(precision=bits):
                self._cache[bits] = mpfr_to_tdfloat(self._fn(gmpy2))
        return self._cache[bits]

    def _default(self) -> TDFloat:
        return self(DEFAULT_BITS)

    def __repr__(self) -> str:
        return f"<ieee754.{self._name} @ {DEFAULT_BITS} bits>"

    def __str__(self) -> str:
        return str(self._default())

    def __float__(self) -> float:  return float(self._default())
    def __int__(self) -> int:      return int(self._default())
    def __neg__(self) -> TDFloat:  return -self._default()
    def __abs__(self) -> TDFloat:  return abs(self._default())
    def __add__(self, o):          return self._default() + _unwrap(o)
    def __radd__(self, o):         return _unwrap(o) + self._default()
    def __sub__(self, o):          return self._default() - _unwrap(o)
    def __rsub__(self, o):         return _unwrap(o) - self._default()
    def __mul__(self, o):          return self._default() * _unwrap(o)
    def __rmul__(self, o):         return _unwrap(o) * self._default()
    def __truediv__(self, o):      return self._default() / _unwrap(o)
    def __rtruediv__(self, o):     return _unwrap(o) / self._default()
    def __eq__(self, o):           return self._default() == _unwrap(o)
    def __lt__(self, o):           return self._default() < _unwrap(o)
    def __le__(self, o):           return self._default() <= _unwrap(o)
    def __gt__(self, o):           return self._default() > _unwrap(o)
    def __ge__(self, o):           return self._default() >= _unwrap(o)
    def __hash__(self):            return hash(self._default())


def _unwrap(x):
    return x._default() if isinstance(x, _PrecisionConstant) else x


PI          = _PrecisionConstant(lambda g: g.const_pi(),    'PI')
TAU         = _PrecisionConstant(lambda g: 2 * g.const_pi(),'TAU')
E           = _PrecisionConstant(lambda g: g.exp(1),        'E')
LN2         = _PrecisionConstant(lambda g: g.const_log2(),  'LN2')
LN10        = _PrecisionConstant(lambda g: g.log(10),       'LN10')
LOG2E       = _PrecisionConstant(lambda g: 1 / g.const_log2(), 'LOG2E')
LOG10E      = _PrecisionConstant(lambda g: g.log10(g.exp(1)),  'LOG10E')
SQRT2       = _PrecisionConstant(lambda g: g.sqrt(2),       'SQRT2')
SQRT3       = _PrecisionConstant(lambda g: g.sqrt(3),       'SQRT3')
PHI         = _PrecisionConstant(lambda g: (1 + g.sqrt(5)) / 2, 'PHI')
EULER_GAMMA = _PrecisionConstant(lambda g: g.const_euler(), 'EULER_GAMMA')
CATALAN     = _PrecisionConstant(lambda g: g.const_catalan(), 'CATALAN')

__all__ = [
    'PI', 'TAU', 'E', 'LN2', 'LN10', 'LOG2E', 'LOG10E',
    'SQRT2', 'SQRT3', 'PHI', 'EULER_GAMMA', 'CATALAN',
    'DEFAULT_BITS',
]
