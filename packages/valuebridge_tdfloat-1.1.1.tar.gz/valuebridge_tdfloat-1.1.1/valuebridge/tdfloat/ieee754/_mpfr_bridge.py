"""MPFR mpfr <-> TDFloat conversion.

Uses gmpy2.f2q to extract the exact dyadic rational of an MPFR value, then
builds a TDFloat from (numerator, denominator). gmpy2 is imported lazily so
the base library stays pure-Python if gmpy2 is not installed.
"""

from __future__ import annotations

from ..tdfloat import TDFloat


def _require_gmpy2():
    try:
        import gmpy2
    except ImportError as e:
        raise ImportError(
            "valuebridge.tdfloat.ieee754 requires gmpy2. "
            "Install with: pip install gmpy2"
        ) from e
    return gmpy2


def mpfr_to_tdfloat(m) -> TDFloat:
    """Convert an MPFR value to an exact TDFloat (dyadic rational)."""
    gmpy2 = _require_gmpy2()
    if m.is_nan():
        return TDFloat.NAN
    if m.is_infinite():
        return TDFloat.INF if m > 0 else TDFloat.NINF
    q = gmpy2.f2q(m, 0)
    p, d = q.numerator, q.denominator
    return TDFloat.from_frac(int(p), int(d))
