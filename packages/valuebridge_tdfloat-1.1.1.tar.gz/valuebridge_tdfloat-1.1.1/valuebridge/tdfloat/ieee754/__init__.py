"""
valuebridge.tdfloat.ieee754
===========================
MPFR-computed reference constants in IEEE 754 / MPFR semantics.

This submodule is parallel to the legacy ``valuebridge.tdfloat`` surface:
the legacy constants stay as exact rational definitions (``PI = 22/7`` etc.)
for backward compatibility, while this namespace exposes the mathematically
correct irrational values at user-selectable precision, computed via GNU MPFR
through the ``gmpy2`` binding.

Usage
-----
    from valuebridge.tdfloat import ieee754

    pi200 = ieee754.PI()          # default 200 bits
    pi53  = ieee754.PI(bits=53)   # IEEE 754 double precision
    area  = ieee754.PI * 5 * 5    # usable as a TDFloat-like value

Dependencies
------------
Requires ``gmpy2`` (a Python binding for GNU MPFR/GMP). Install as a dev
dependency; the base library remains pure-Python.
"""

from ._precision import DEFAULT_BITS
from ._mpfr_bridge import mpfr_to_tdfloat
from .constants import (
    PI, TAU, E, LN2, LN10, LOG2E, LOG10E,
    SQRT2, SQRT3, PHI, EULER_GAMMA, CATALAN,
)

__all__ = [
    'PI', 'TAU', 'E', 'LN2', 'LN10', 'LOG2E', 'LOG10E',
    'SQRT2', 'SQRT3', 'PHI', 'EULER_GAMMA', 'CATALAN',
    'DEFAULT_BITS', 'mpfr_to_tdfloat',
]
