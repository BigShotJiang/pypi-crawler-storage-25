"""Default precision for MPFR-computed reference constants."""

DEFAULT_BITS = 200
