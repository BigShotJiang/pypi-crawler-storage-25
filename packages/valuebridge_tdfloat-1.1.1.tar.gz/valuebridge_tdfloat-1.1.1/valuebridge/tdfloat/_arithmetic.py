"""
tdfloat._arithmetic
===================
Exact rational arithmetic on encoded half-step integers.

Every operation goes: encoded → (p,q) → exact integer arithmetic → encoded.
No Python float is ever used.
"""

from ._encoding import (
    _NAN, _PINF, _NINF, _SPECIALS,
    to_rational, from_rational,
)

# Try to use Rust-accelerated versions
try:
    from tdfloat_core import td_gcd, td_tddiv
    _RUST_ARITHMETIC = True
except ImportError:
    _RUST_ARITHMETIC = False
    td_tddiv = None

def _sign_of(encoded: int) -> int:
    return 1 if encoded < 0 and encoded not in _SPECIALS else 0

def _gcd(a: int, b: int) -> int:
    if _RUST_ARITHMETIC:
        # Use Rust GCD for unsigned integers only
        try:
            return td_gcd(a, b)
        except (OverflowError, ValueError):
            # Fall back to Python if Rust can't handle it
            while b: a, b = b, a % b
            return a
    while b: a, b = b, a % b
    return a

def _simplify(p: int, q: int) -> tuple:
    # Use Python _simplify to avoid overflow issues with large numbers
    # (Python uses arbitrary-precision integers)
    if q < 0: p, q = -p, -q
    g = _gcd(abs(p), q) if q else 1
    return p // g, q // g

def add(a: int, b: int) -> int:
    if _NAN in (a, b): return _NAN
    if a == _PINF: return _NAN if b == _NINF else _PINF
    if a == _NINF: return _NAN if b == _PINF else _NINF
    if b in (_PINF, _NINF): return b
    na, da = to_rational(a)
    nb, db = to_rational(b)
    p, q = _simplify(na * db + nb * da, da * db)
    return from_rational(p, q)

def sub(a: int, b: int) -> int:
    return add(a, neg(b))

def neg(a: int) -> int:
    if a == _NAN:  return _NAN
    if a == _PINF: return _NINF
    if a == _NINF: return _PINF
    return -a   # sign lives in Python int sign

def mul(a: int, b: int) -> int:
    if _NAN in (a, b): return _NAN
    if a in (_PINF, _NINF) or b in (_PINF, _NINF):
        sa = 1 if (a == _NINF or (a < 0 and a not in _SPECIALS)) else 0
        sb = 1 if (b == _NINF or (b < 0 and b not in _SPECIALS)) else 0
        return _NINF if (sa ^ sb) else _PINF
    na, da = to_rational(a)
    nb, db = to_rational(b)
    p, q = _simplify(na * nb, da * db)
    return from_rational(p, q)

def div(a: int, b: int) -> int:
    """Division using tddiv internally.
    Returns the full rational result: quotient + remainder/denominator as encoded value.
    """
    if _NAN in (a, b): return _NAN
    nb, db = to_rational(b)
    if nb == 0:
        # division by zero: return signed infinity based on sign of a
        na, da = to_rational(a)
        if na == 0: return _NAN   # 0/0 = nan
        return _NINF if na < 0 else _PINF

    # Use tddiv internally for exact three-term semantics
    quot_e, rem_e, den_e = divmod_td(a, b)

    # Reconstruct: result = quotient + remainder/denominator as a single encoded value
    if rem_e == 0:
        return quot_e

    # Extract the rational components
    # Note: divmod_td returns integers encoded as rationals with denominator 1
    p_q, q_q = to_rational(quot_e)  # quotient as integer
    p_r, q_r = to_rational(rem_e)  # remainder as integer
    p_d, q_d = to_rational(den_e)  # denominator as integer

    # Compute: result = quotient + remainder/denominator
    #                = (quotient * denominator + remainder) / denominator
    # Since q_q = q_r = q_d = 1 (they're all integers):
    num = p_q * p_d + p_r
    den = p_d
    p, q = _simplify(num, den)
    return from_rational(p, q)

def floordiv(a: int, b: int) -> int:
    """Floor division using tddiv internally.
    Returns only the quotient part (whole number).
    """
    if _NAN in (a, b) or b in (_PINF, _NINF): return _NAN
    nb, db = to_rational(b)
    if nb == 0: return _NAN

    # Use tddiv to get quotient directly
    quot_e, rem_e, den_e = divmod_td(a, b)
    return quot_e

def mod(a: int, b: int) -> int:
    """Modulo using tddiv internally.
    Computes: a mod b = a - b * floor(a/b)
    Returns the remainder from the division.
    """
    if _NAN in (a, b) or b in (_PINF, _NINF): return _NAN
    nb, db = to_rational(b)
    if nb == 0: return _NAN

    # Use tddiv to get quotient directly
    quot_e, rem_e, den_e = divmod_td(a, b)

    # Compute: a - b * quotient
    return sub(a, mul(b, quot_e))

def divmod_td(a: int, b: int) -> tuple:
    """Three-term division: returns (quotient, remainder, denominator).

    Semantics: a/b = quotient + remainder/denominator
    All three terms are encoded as half-step integers.

    Args:
        a, b: encoded half-step integers

    Returns:
        (quotient_enc, remainder_enc, denominator_enc) where each is encoded
    """
    if _NAN in (a, b): return (_NAN, _NAN, _NAN)
    if b in (_PINF, _NINF) or b == 0: return (_NAN, _NAN, _NAN)
    if a == 0: return (0, 0, 1)  # 0/b = (0, 0, 1)

    if _RUST_ARITHMETIC and td_tddiv is not None:
        return td_tddiv(a, b)

    # Pure Python fallback (less efficient but correct)
    na, da = to_rational(a)
    nb, db = to_rational(b)

    # a/b = (na/da) / (nb/db) = (na*db) / (da*nb)
    p = na * db
    q = da * nb

    # Reduce via GCD
    from math import gcd as py_gcd
    g = py_gcd(abs(p), abs(q))
    p, q = p // g, q // g

    # Ensure q is positive
    if q < 0:
        p, q = -p, -q

    # Get quotient and remainder
    quot = p // q
    rem = p % q

    # Encode all three terms
    sign_q = quot < 0
    quot_enc = from_rational(abs(quot), 1) if quot != 0 else 0
    if sign_q and quot != 0:
        quot_enc = -quot_enc if quot_enc >= 0 else quot_enc

    sign_r = rem < 0
    rem_enc = from_rational(abs(rem), 1) if rem != 0 else 0
    if sign_r and rem != 0:
        rem_enc = -rem_enc if rem_enc >= 0 else rem_enc

    den_enc = from_rational(q, 1)

    return (quot_enc, rem_enc, den_enc)

def eq(a: int, b: int) -> bool:
    if a in _SPECIALS or b in _SPECIALS:
        return a == b and a != _NAN
    na, da = to_rational(a)
    nb, db = to_rational(b)
    return na * db == nb * da

def lt(a: int, b: int) -> bool:
    if _NAN in (a, b): return False
    if a == _NINF: return b != _NINF
    if b == _PINF: return a != _PINF
    if a == _PINF or b == _NINF: return False
    na, da = to_rational(a)
    nb, db = to_rational(b)
    # na/da < nb/db  iff  na*db < nb*da  (both denominators positive)
    return na * db < nb * da

def abs_val(a: int) -> int:
    if a in _SPECIALS: return a
    return -a if a < 0 else a

def pow_int(a: int, n: int) -> int:
    """Integer power via repeated squaring."""
    if n < 0:
        return div(from_rational(1, 1), pow_int(a, -n))
    result = from_rational(1, 1)
    base   = a
    while n:
        if n & 1: result = mul(result, base)
        base = mul(base, base)
        n >>= 1
    return result

def isqrt_rational(p: int, q: int) -> tuple:
    """
    Integer square root of p/q as a rational.
    Returns (rp, rq) such that (rp/rq)^2 ≈ p/q.
    Uses Newton's method on integers.
    """
    if p < 0: return (0, 0)  # NaN
    if p == 0: return (0, 1)

    # sqrt(p/q) = sqrt(p*q) / q
    # We compute isqrt(p*q) then divide by q
    target = p * q
    # Scale up for precision: sqrt(target * 10^(2k)) = sqrt(target) * 10^k
    PREC = 80  # decimal digits of precision
    scale = 10 ** (PREC * 2)
    n = target * scale
    x = 1 << (n.bit_length() // 2 + 1)
    while True:
        x1 = (x + n // x) >> 1
        if x1 >= x: break
        x = x1
    # result = x / (sqrt(scale) * q) = x / (10^PREC * q)
    rp, rq = _simplify(x, (10 ** PREC) * q)
    return rp, rq

def sqrt(a: int) -> int:
    """Square root via exact rational Newton's method."""
    from ._encoding import _NAN, _PINF, _NINF
    if a == _NAN: return _NAN
    if a == _NINF: return _NAN
    if a == _PINF: return _PINF
    na, da = to_rational(a)
    if na < 0: return _NAN
    if na == 0: return from_rational(0, 1)
    rp, rq = isqrt_rational(na, da)
    return from_rational(rp, rq)
