"""
tdfloat._encoding
=================
The half-step symbol encoding from encoding_any_symbol.v

  position = 2 * rank + info_bit      encode_symbol
  rank     = position >> 1            decode_rank
  info_bit = position & 1             decode_info

The "." is the info_bit:
  info_bit = 0  →  integer axis   (even position, no dot)
  info_bit = 1  →  half-step axis (odd  position, has dot)
"""

# ── Layout ────────────────────────────────────────────────────────────
MAX_DOT_POS   = 77          # maximum fractional decimal places
DOT_POSITIONS = MAX_DOT_POS + 1   # 78 distinct scale values (0..77)

# Sentinel values for special numbers (outside the half-step line)
_NAN  = -1
_PINF = -2
_NINF = -3
_SPECIALS = (_NAN, _PINF, _NINF)


# ── The three primitives from encoding_any_symbol.v ──────────────────

def encode_symbol(rank: int, info_bit: int) -> int:
    """position = 2 * rank + info_bit"""
    return 2 * rank + (info_bit & 1)

def decode_rank(position: int) -> int:
    """rank = position // 2"""
    return position >> 1

def decode_info(position: int) -> int:
    """info_bit = position mod 2  (0=integer axis, 1=half-step axis)"""
    return position & 1


# ── Pack / unpack a float as (sign, abs_digits, dot_pos) ─────────────

def pack(sign: int, abs_digits: int, dot_pos: int) -> int:
    """
    Encode (sign, digits, dot_pos) as a single integer on the half-step line.
    sign=0 positive, sign=1 negative.
    dot_pos=0 means integer (no dot, info_bit=0).
    dot_pos>0 means fractional (dot present, info_bit=1).
    """
    assert 0 <= dot_pos <= MAX_DOT_POS, f"dot_pos {dot_pos} out of range"
    info_bit = 1 if dot_pos > 0 else 0
    rank     = abs_digits * DOT_POSITIONS + dot_pos
    position = encode_symbol(rank, info_bit)
    return -position if sign else position

def unpack(encoded: int) -> tuple:
    """Return (sign, abs_digits, dot_pos). sign=0 positive, 1 negative."""
    if encoded < 0:
        sign, position = 1, -encoded
    else:
        sign, position = 0, encoded
    rank               = decode_rank(position)
    dot_pos            = rank % DOT_POSITIONS
    abs_digits         = rank // DOT_POSITIONS
    return sign, abs_digits, dot_pos


# ── Exact rational ↔ encoded int ─────────────────────────────────────

def to_rational(encoded: int) -> tuple:
    """Return (numerator, denominator). numerator may be negative."""
    if encoded in _SPECIALS:
        return (0, 0)
    sign, digits, dot_pos = unpack(encoded)
    denom = 10 ** dot_pos
    return (-digits if sign else digits), denom

def from_rational(num: int, den: int) -> int:
    """Build encoded int from exact integer ratio num/den.
    Uses pure Python with arbitrary-precision integers to handle all rationals.
    """
    if den == 0:
        return _NAN
    if num == 0:
        return pack(0, 0, 0)

    sign = 1 if num < 0 else 0
    num  = abs(num)

    # Find shortest exact decimal representation up to MAX_DOT_POS
    for dot_pos in range(MAX_DOT_POS + 1):
        scaled = num * (10 ** dot_pos)
        if scaled % den == 0:
            return pack(sign, scaled // den, dot_pos)

    # Inexact — round to MAX_DOT_POS places
    scaled = num * (10 ** MAX_DOT_POS)
    digits = (scaled + den // 2) // den
    return pack(sign, digits, MAX_DOT_POS)


# ── String ↔ encoded int ──────────────────────────────────────────────

def from_str(s: str) -> int:
    """Parse decimal string to encoded int. No Python float used."""
    s = s.strip().lower()
    for alias, val in (('inf',_PINF),('+inf',_PINF),('-inf',_NINF),('nan',_NAN)):
        if s == alias: return val

    sign = 0
    if s.startswith('-'):  sign = 1; s = s[1:]
    elif s.startswith('+'): s = s[1:]

    exp10 = 0
    if 'e' in s:
        s, ep = s.split('e', 1); exp10 = int(ep)

    has_dot = '.' in s
    if has_dot:
        ipart, fpart = s.split('.', 1)
    else:
        ipart, fpart = s, ''

    ipart  = ipart or '0'
    digits = int(ipart + fpart) if (ipart + fpart) else 0

    raw_dot = len(fpart) - exp10

    if raw_dot < 0:
        digits  *= 10 ** (-raw_dot)
        dot_pos  = 0
    elif raw_dot > MAX_DOT_POS:
        excess   = raw_dot - MAX_DOT_POS
        digits   = (digits + 10**(excess-1)*5) // (10 ** excess)
        dot_pos  = MAX_DOT_POS
    else:
        dot_pos = raw_dot

    # Strip trailing fractional zeros, but preserve the dot presence
    min_dot = 1 if has_dot or exp10 < 0 else 0
    while dot_pos > min_dot and digits % 10 == 0:
        digits  //= 10
        dot_pos  -= 1

    return pack(sign, digits, dot_pos)

def to_str(encoded: int, max_digits: int = 40) -> str:
    """Convert encoded int to decimal string."""
    if encoded == _NAN:  return 'nan'
    if encoded == _PINF: return 'inf'
    if encoded == _NINF: return '-inf'
    sign, digits, dot_pos = unpack(encoded)
    s = '-' if sign else ''
    ds = str(digits)
    if dot_pos == 0:
        return s + ds + '.0' if False else s + ds  # integers: no trailing .0
    if len(ds) <= dot_pos:
        ds = '0' * (dot_pos - len(ds) + 1) + ds
    int_part  = ds[:-dot_pos] or '0'
    frac_part = ds[-dot_pos:].rstrip('0') or '0'
    return s + int_part + '.' + frac_part
