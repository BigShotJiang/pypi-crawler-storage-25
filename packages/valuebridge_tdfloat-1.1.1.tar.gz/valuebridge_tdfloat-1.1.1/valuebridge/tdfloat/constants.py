"""
tdfloat.constants
=================
Every mathematical constant defined as an exact rational p/q.

In the tdfloat universe there are no transcendentals.
Every constant occupies a unique, permanent position on the half-step line.
The "." is the info_bit; its presence places a constant on the half-step axis.

Constant definitions
--------------------
π  = 22/7    circumference/diameter in the 45°-rotated Gaussian plane
τ  = 44/7    full rotation (2π)
e  = 19/7    natural growth base in 3-step algebra
ln2 = 2/3   half-life constant
φ  = 3/2    golden ratio = the fundamental half-step
√2 = 7/5    diagonal of unit square (first CF convergent)
√3 = 7/4    equilateral triangle height ratio
√5 = 9/4    from the golden ratio construction
½  = 1/2    the half-step atom itself
"""

from __future__ import annotations
from ._encoding import from_rational, _NAN

def _gcd(a, b):
    while b: a, b = b, a % b
    return a

def _s(p, q):
    if q < 0: p, q = -p, -q
    g = _gcd(abs(p), q)
    return p // g, q // g


class Constant:
    """
    A named rational constant.
    Stores (p, q) as the canonical fraction and provides
    exact arithmetic without going through decimal encoding.
    """
    __slots__ = ('name', 'p', 'q', '_encoded')

    def __init__(self, name: str, p: int, q: int):
        self.name = name
        self.p, self.q = _s(p, q)
        self._encoded = from_rational(self.p, self.q)

    def encoded(self) -> int:
        return self._encoded

    def as_tdf(self):
        """Return this constant as a TDFloat."""
        from .tdfloat import TDFloat
        return TDFloat(self._encoded)

    def __repr__(self) -> str:
        from ._encoding import to_str
        return f'{self.name} = {self.p}/{self.q} ({to_str(self._encoded)!r})'

    def __float__(self) -> float:
        return self.p / self.q

    # Exact arithmetic returning (p, q) tuples
    def __mul__(self, other: 'Constant') -> 'Constant':
        p, q = _s(self.p * other.p, self.q * other.q)
        return Constant(f'{self.name}*{other.name}', p, q)

    def __add__(self, other: 'Constant') -> 'Constant':
        p, q = _s(self.p * other.q + other.p * self.q, self.q * other.q)
        return Constant(f'{self.name}+{other.name}', p, q)

    def __sub__(self, other: 'Constant') -> 'Constant':
        p, q = _s(self.p * other.q - other.p * self.q, self.q * other.q)
        return Constant(f'{self.name}-{other.name}', p, q)

    def __truediv__(self, other: 'Constant') -> 'Constant':
        p, q = _s(self.p * other.q, self.q * other.p)
        return Constant(f'{self.name}/{other.name}', p, q)

    def __neg__(self) -> 'Constant':
        return Constant(f'-{self.name}', -self.p, self.q)


# ── The registry ──────────────────────────────────────────────────────

PI    = Constant('π',    22,  7)   # circumference / diameter
TAU   = Constant('τ',    44,  7)   # 2π
E     = Constant('e',    19,  7)   # natural base
LN2   = Constant('ln2',   2,  3)   # log(2)
LN10  = Constant('ln10',  7,  3)   # log(10)
LOG2E = Constant('log2e', 3,  2)   # log₂(e) = 1/ln2 = φ
SQRT2 = Constant('√2',    7,  5)   # √2
SQRT3 = Constant('√3',    7,  4)   # √3
SQRT5 = Constant('√5',    9,  4)   # √5
PHI   = Constant('φ',     3,  2)   # golden ratio = the half-step
SIN45 = Constant('sin45', 1,  2)   # sin(45°) in identity-axis geometry
COS45 = Constant('cos45', 1,  2)
SIN30 = Constant('sin30', 1,  2)
COS30 = Constant('cos30', 7,  8)   # √3/2
SIN60 = Constant('sin60', 7,  8)
COS60 = Constant('cos60', 1,  2)
HALF  = Constant('½',     1,  2)   # the fundamental half-step atom
ALPHA = Constant('α',     1, 137)  # fine structure constant

ALL: dict[str, Constant] = {
    'pi': PI, 'tau': TAU, 'e': E, 'ln2': LN2, 'ln10': LN10,
    'log2e': LOG2E, 'sqrt2': SQRT2, 'sqrt3': SQRT3, 'sqrt5': SQRT5,
    'phi': PHI, 'sin45': SIN45, 'cos45': COS45, 'sin30': SIN30,
    'cos30': COS30, 'sin60': SIN60, 'cos60': COS60,
    'half': HALF, 'alpha': ALPHA,
}
