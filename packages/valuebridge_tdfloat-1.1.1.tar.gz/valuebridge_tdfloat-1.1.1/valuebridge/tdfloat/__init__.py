"""
tdfloat — Triadic Dot Float
============================
A floating-point library where every number is a single Python integer
on the half-step rational line.

The "." is the info_bit (from encoding_any_symbol.v):
  position = 2 * rank + info_bit
  info_bit = 0  →  integer axis   (no dot)
  info_bit = 1  →  half-step axis (has dot)

All arithmetic is exact rational arithmetic.
No IEEE 754 rounding. No transcendentals. No approximation.

Quick start
-----------
    from valuebridge.tdfloat import td, frac, TDFloat

    a = td('0.1')
    b = td('0.2')
    c = td('0.3')
    assert (a + b) + c == a + (b + c)   # always True

    print(TDFloat.PI)    # 22/7  (exact definition of π)
    print(TDFloat.E)     # 19/7
    print(TDFloat.PHI)   # 3/2   (the golden ratio = the half-step)

    from valuebridge.tdfloat.math import circle_area, circle_circumference
    r7 = td(7)
    print(circle_circumference(r7))   # 44  (exact integer!)
    print(circle_area(r7))            # 154 (exact integer!)

Constants
---------
All constants are exact rationals:
  π = 22/7,  τ = 44/7,  e = 19/7,  φ = 3/2,  √2 = 7/5,  ½ = 1/2
"""

from .tdfloat import TDFloat, td, frac, divmod_td
from . import math
from . import constants
from . import ieee754

# Expose constants at package level
PI    = TDFloat.PI
TAU   = TDFloat.TAU
E     = TDFloat.E
PHI   = TDFloat.PHI
SQRT2 = TDFloat.SQRT2
SQRT3 = TDFloat.SQRT3
HALF  = TDFloat.HALF
ZERO  = TDFloat.ZERO
ONE   = TDFloat.ONE
TWO   = TDFloat.TWO
NAN   = TDFloat.NAN
INF   = TDFloat.INF

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version('valuebridge-tdfloat')
    del _pkg_version
except Exception:
    __version__ = 'unknown'
__author__  = 'Tushar Dadlani'
__all__ = [
    'TDFloat', 'td', 'frac', 'divmod_td',
    'PI', 'TAU', 'E', 'PHI', 'SQRT2', 'SQRT3', 'HALF',
    'ZERO', 'ONE', 'TWO', 'NAN', 'INF',
    'math', 'constants', 'ieee754',
]
