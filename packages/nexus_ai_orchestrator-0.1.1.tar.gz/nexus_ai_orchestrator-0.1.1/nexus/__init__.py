"""
nexus-ai — Production-grade AI orchestration in 20 lines.

Wires together LangGraph (stateful execution), LlamaIndex (RAG),
MCP (tool protocols), and A2A (agent delegation) behind a single
clean API.

Quick start::

    import asyncio
    from nexus import Nexus, NexusConfig, LLMConfig, LLMProvider

    config = NexusConfig(llm=LLMConfig(provider=LLMProvider.ANTHROPIC, model="claude-sonnet-4-6"))

    async def main():
        async with await Nexus.create(config) as nexus:
            await nexus.ingest("./docs")
            print(await nexus.run("Summarise the key points from the docs"))

    asyncio.run(main())
"""

from nexus.core.orchestrator import Nexus
from nexus.core.config import (
    NexusConfig,
    LLMConfig,
    RAGConfig,
    MCPConfig,
    A2AConfig,
    MemoryConfig,
    LLMProvider,
    VectorStoreBackend,
    MemoryBackend,
)
from nexus.core.registry import ToolRegistry, ToolDefinition, ToolParameter, ToolSource
from nexus.core.exceptions import (
    NexusError,
    ConfigurationError,
    ToolNotFoundError,
    ToolExecutionError,
    ToolConflictError,
    MCPConnectionError,
    A2AConnectionError,
    OrchestratorError,
)
from nexus.tools.builtin import (
    web_search_tool,
    read_file_tool,
    write_file_tool,
    list_directory_tool,
    sql_query_tool,
)
from nexus.tools.sandbox import python_sandbox_tool
from nexus.tools.tool_adapter import from_openai_schema, from_anthropic_schema, from_langchain_tool
from nexus.agents.agent_card import AgentCard
from nexus.data.ingest import ingest_strings, ingest_web_pages
from nexus.utils.logging import configure_logging

__version__ = "0.1.1"

__all__ = [
    # Core
    "Nexus",
    "NexusConfig",
    "LLMConfig",
    "RAGConfig",
    "MCPConfig",
    "A2AConfig",
    "MemoryConfig",
    "LLMProvider",
    "VectorStoreBackend",
    "MemoryBackend",
    # Registry
    "ToolRegistry",
    "ToolDefinition",
    "ToolParameter",
    "ToolSource",
    # Exceptions
    "NexusError",
    "ConfigurationError",
    "ToolNotFoundError",
    "ToolExecutionError",
    "ToolConflictError",
    "MCPConnectionError",
    "A2AConnectionError",
    "OrchestratorError",
    # Built-in tools
    "web_search_tool",
    "read_file_tool",
    "write_file_tool",
    "list_directory_tool",
    "sql_query_tool",
    "python_sandbox_tool",
    # Adapters
    "from_openai_schema",
    "from_anthropic_schema",
    "from_langchain_tool",
    # Agents
    "AgentCard",
    # Data
    "ingest_strings",
    "ingest_web_pages",
    # Utils
    "configure_logging",
]
