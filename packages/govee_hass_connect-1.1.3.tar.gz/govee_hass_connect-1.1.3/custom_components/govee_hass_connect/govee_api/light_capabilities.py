from enum import IntFlag


class GoveeLightFeatures(IntFlag):
    """Govee Lights capabilities."""

    COLOR_RGB = 0x01
    COLOR_KELVIN_TEMPERATURE = 0x02
    BRIGHTNESS = 0x04
    SEGMENT_CONTROL = 0x08
    SCENES = 0x10


COMMON_FEATURES: GoveeLightFeatures = (
    GoveeLightFeatures.COLOR_RGB
    | GoveeLightFeatures.COLOR_KELVIN_TEMPERATURE
    | GoveeLightFeatures.BRIGHTNESS
)


class GoveeLightCapabilities:
    def __init__(
        self,
        features: GoveeLightFeatures,
        segments: list[bytes] = [],
        scenes: dict[str, bytes] = {},
    ) -> None:
        self.features = features
        self.segments = (
            segments if features & GoveeLightFeatures.SEGMENT_CONTROL else []
        )
        self.scenes = scenes if features & GoveeLightFeatures.SCENES else {}

    @property
    def segments_count(self) -> int:
        return len(self.segments)

    @property
    def available_scenes(self) -> list[str]:
        return list(self.scenes.keys())

    def __repr__(self) -> str:
        return f"GoveeLightCapabilities(features={self.features!r}, segments={self.segments!r}, scenes={self.scenes!r})"

    def __str__(self) -> str:
        return f"GoveeLightCapabilities(features={self.features!r}, segments={len(self.segments)}, scenes={len(self.scenes)})"


SEGMENT_CODES: list[bytes] = [
    b"\x01\x00",  # 1
    b"\x02\x00",  # 2
    b"\x04\x00",  # 3
    b"\x08\x00",  # 4
    b"\x10\x00",  # 5
    b"\x20\x00",  # 6
    b"\x40\x00",  # 7
    b"\x80\x00",  # 8
    b"\x00\x01",  # 9
    b"\x00\x02",  # 10
    b"\x00\x04",  # 11
    b"\x00\x08",  # 12
    b"\x00\x10",  # 13
    b"\x00\x20",  # 14
    b"\x00\x40",  # 15
]

SCENE_CODES: dict[str, bytes] = {
    "sunrise": b"\x00",
    "sunset": b"\x01",
    "movie": b"\x04",
    "dating": b"\x05",
    "romantic": b"\x07",
    "twinkle": b"\x08",
    "candlelight": b"\x09",
    "snowflake": b"\x0f",
    "energetic": b"\x10",
    "breathe": b"\x0a",
    "crossing": b"\x15",
}


def create_with_capabilities(
    rgb: bool, temperature: bool, brightness: bool, segments: int, scenes: bool
) -> GoveeLightCapabilities:
    features: GoveeLightFeatures = GoveeLightFeatures(0)
    segments_codes = []

    if rgb:
        features = features | GoveeLightFeatures.COLOR_RGB
    if temperature:
        features = features | GoveeLightFeatures.COLOR_KELVIN_TEMPERATURE
    if brightness:
        features = features | GoveeLightFeatures.BRIGHTNESS
    if segments > 0:
        features = features | GoveeLightFeatures.SEGMENT_CONTROL
        segments_codes = SEGMENT_CODES[:segments]

    if scenes:
        features = features | GoveeLightFeatures.SCENES

    return GoveeLightCapabilities(
        features, segments_codes, SCENE_CODES if scenes else {}
    )


BASIC_CAPABILITIES = create_with_capabilities(
    rgb=True, temperature=True, brightness=True, segments=0, scenes=True
)

ON_OFF_CAPABILITIES = create_with_capabilities(
    rgb=False, temperature=False, brightness=False, segments=0, scenes=False
)


GOVEE_LIGHT_CAPABILITIES: dict[str, GoveeLightCapabilities] = {
    # Models with common features
    "H1232": BASIC_CAPABILITIES,
    "H1250": BASIC_CAPABILITIES,
    "H1270": BASIC_CAPABILITIES,
    "H1310": BASIC_CAPABILITIES,
    "H1401": BASIC_CAPABILITIES,
    "H14A1": BASIC_CAPABILITIES,
    "H14C0": BASIC_CAPABILITIES,
    "H14C1": BASIC_CAPABILITIES,
    "H1630": BASIC_CAPABILITIES,
    "H16B0": BASIC_CAPABILITIES,
    "H16C0": BASIC_CAPABILITIES,
    "H1A43": BASIC_CAPABILITIES,
    "H1A45": BASIC_CAPABILITIES,
    "H2A40": BASIC_CAPABILITIES,
    "H2A41": BASIC_CAPABILITIES,
    "H3200": BASIC_CAPABILITIES,
    "H3500": BASIC_CAPABILITIES,
    "H3501": BASIC_CAPABILITIES,
    "H3510": BASIC_CAPABILITIES,
    "H3511": BASIC_CAPABILITIES,
    "H3751": BASIC_CAPABILITIES,
    "H6004": BASIC_CAPABILITIES,
    "H6006": BASIC_CAPABILITIES,  # Issue #133 - temp confirmed via Cloud API (2000-9000K)
    "H6008": BASIC_CAPABILITIES,
    "H600A": BASIC_CAPABILITIES,
    "H600D": BASIC_CAPABILITIES,
    "H601A": BASIC_CAPABILITIES,  # Issue #129
    "H6020": create_with_capabilities(True, True, True, 0, True),
    "H6022": BASIC_CAPABILITIES,
    "H6038": BASIC_CAPABILITIES,
    "H6039": create_with_capabilities(True, True, True, 12, True),
    "H6042": create_with_capabilities(True, True, True, 5, True),
    "H6043": create_with_capabilities(
        True, False, True, 10, True
    ),  # Issue #254 - TV Light Bars 2, no temp
    "H6046": create_with_capabilities(True, True, True, 10, True),
    "H6047": create_with_capabilities(True, True, True, 10, True),
    "H6048": create_with_capabilities(True, True, True, 24, True),
    "H6051": BASIC_CAPABILITIES,
    "H6052": BASIC_CAPABILITIES,
    "H6056": BASIC_CAPABILITIES,
    "H6059": BASIC_CAPABILITIES,
    "H605D": BASIC_CAPABILITIES,
    "H6061": BASIC_CAPABILITIES,
    "H6062": BASIC_CAPABILITIES,
    "H6063": create_with_capabilities(True, True, True, 0, False),
    "H6065": BASIC_CAPABILITIES,
    "H6066": BASIC_CAPABILITIES,
    "H6069": create_with_capabilities(True, False, True, 20, True),
    "H6067": BASIC_CAPABILITIES,
    "H606A": BASIC_CAPABILITIES,
    "H6072": create_with_capabilities(True, True, True, 8, True),
    "H6073": BASIC_CAPABILITIES,
    "H6076": create_with_capabilities(True, True, True, 7, True),
    "H6076A": BASIC_CAPABILITIES,
    "H6078": BASIC_CAPABILITIES,
    "H6079": BASIC_CAPABILITIES,
    "H607C": create_with_capabilities(True, True, True, 13, True),
    "H6087": create_with_capabilities(True, True, True, 12, True),
    "H6088": create_with_capabilities(True, True, True, 6, True),
    "H608A": BASIC_CAPABILITIES,
    "H608B": create_with_capabilities(True, True, True, 15, True),
    "H608C": BASIC_CAPABILITIES,
    "H608D": BASIC_CAPABILITIES,
    "H6093": create_with_capabilities(False, True, True, 0, True),
    "H6094": BASIC_CAPABILITIES,
    "H6095": create_with_capabilities(True, True, True, 0, True),
    "H609D": BASIC_CAPABILITIES,
    "H60A0": BASIC_CAPABILITIES,
    "H60A1": create_with_capabilities(True, True, True, 13, True),
    "H60A4": create_with_capabilities(True, True, True, 11, False),
    "H60A6": create_with_capabilities(True, True, True, 0, False),
    "H60B0": BASIC_CAPABILITIES,  # Issue #252 - segments TBD
    "H60B1": create_with_capabilities(True, True, True, 3, True),
    "H60B2": create_with_capabilities(True, True, True, 3, True),
    "H60C1": create_with_capabilities(True, True, True, 3, True),  # Issue #232
    "H610A": BASIC_CAPABILITIES,
    "H610B": BASIC_CAPABILITIES,
    "H610E": create_with_capabilities(True, True, True, 7, False),
    "H610F": create_with_capabilities(True, True, True, 7, False),
    "H6110": BASIC_CAPABILITIES,
    "H6117": BASIC_CAPABILITIES,
    "H6141": BASIC_CAPABILITIES,
    "H6143": BASIC_CAPABILITIES,
    "H6144": BASIC_CAPABILITIES,
    "H6159": BASIC_CAPABILITIES,
    "H615A": create_with_capabilities(True, True, True, 0, True),
    "H615B": create_with_capabilities(True, True, True, 0, True),
    "H615C": create_with_capabilities(True, True, True, 0, True),
    "H615D": create_with_capabilities(True, True, True, 0, True),
    "H615E": create_with_capabilities(True, True, True, 0, True),
    "H6163": BASIC_CAPABILITIES,
    "H6167": create_with_capabilities(True, True, True, 12, True),
    "H6168": BASIC_CAPABILITIES,
    "H616C": BASIC_CAPABILITIES,
    "H616D": create_with_capabilities(True, True, True, 15, True),
    "H616E": BASIC_CAPABILITIES,
    "H6172": BASIC_CAPABILITIES,
    "H6173": BASIC_CAPABILITIES,
    "H6175": BASIC_CAPABILITIES,
    "H6176": BASIC_CAPABILITIES,
    "H6182": BASIC_CAPABILITIES,
    "H618A": create_with_capabilities(True, True, True, 15, True),
    "H618C": create_with_capabilities(True, True, True, 15, True),
    "H618E": create_with_capabilities(True, True, True, 15, True),
    "H618F": create_with_capabilities(True, True, True, 15, True),
    "H618G": BASIC_CAPABILITIES,
    "H619A": create_with_capabilities(True, True, True, 10, True),
    "H619B": create_with_capabilities(True, True, True, 10, True),
    "H619C": create_with_capabilities(True, True, True, 10, True),
    "H619D": create_with_capabilities(True, True, True, 10, True),
    "H619E": create_with_capabilities(True, True, True, 10, True),
    "H619Z": BASIC_CAPABILITIES,
    "H61A0": BASIC_CAPABILITIES,
    "H61A1": BASIC_CAPABILITIES,
    "H61A2": BASIC_CAPABILITIES,
    "H61A3": BASIC_CAPABILITIES,
    "H61A5": BASIC_CAPABILITIES,
    "H61A8": BASIC_CAPABILITIES,
    "H61A9": BASIC_CAPABILITIES,
    "H61B1": BASIC_CAPABILITIES,
    "H61B2": BASIC_CAPABILITIES,
    "H61B3": create_with_capabilities(True, True, True, 15, True),
    "H61B6": create_with_capabilities(True, True, True, 0, True),
    "H61B8": create_with_capabilities(True, True, True, 40, True),
    "H61B9": create_with_capabilities(True, True, True, 0, True),
    "H61BA": BASIC_CAPABILITIES,
    "H61BC": BASIC_CAPABILITIES,
    "H61BE": BASIC_CAPABILITIES,
    "H61C2": BASIC_CAPABILITIES,
    "H61C3": BASIC_CAPABILITIES,
    "H61C5": BASIC_CAPABILITIES,
    "H61D3": create_with_capabilities(True, True, True, 15, True),
    "H61D5": BASIC_CAPABILITIES,
    "H61D6": BASIC_CAPABILITIES,
    "H61E0": BASIC_CAPABILITIES,
    "H61E1": BASIC_CAPABILITIES,
    "H61E5": create_with_capabilities(True, True, True, 12, True),
    "H61E6": create_with_capabilities(True, True, True, 15, True),
    "H61F2": create_with_capabilities(True, True, True, 4, True),
    "H61F5": create_with_capabilities(True, True, True, 10, True),
    "H61F6": create_with_capabilities(True, True, True, 20, True),
    "H6609": create_with_capabilities(True, True, True, 18, True),
    "H6630": BASIC_CAPABILITIES,
    "H6631": BASIC_CAPABILITIES,
    "H6640": create_with_capabilities(True, True, True, 14, True),
    "H6641": create_with_capabilities(True, True, True, 14, True),
    "H6671": BASIC_CAPABILITIES,
    "H6672": BASIC_CAPABILITIES,
    "H6800": BASIC_CAPABILITIES,
    "H6810": create_with_capabilities(True, True, True, 0, False),
    "H6811": BASIC_CAPABILITIES,
    "H6840": BASIC_CAPABILITIES,
    "H6841": BASIC_CAPABILITIES,
    "H6860": BASIC_CAPABILITIES,
    "H6861": BASIC_CAPABILITIES,
    "H6870": BASIC_CAPABILITIES,
    "H6871": create_with_capabilities(True, True, True, 0, True),
    "H7012": create_with_capabilities(False, False, True, 0, False),
    "H7013": create_with_capabilities(False, False, True, 0, False),
    "H7020": BASIC_CAPABILITIES,
    "H7021": BASIC_CAPABILITIES,
    "H7025": create_with_capabilities(True, False, True, 15, True),
    "H7026": create_with_capabilities(True, False, True, 30, True),
    "H7027": BASIC_CAPABILITIES,
    "H7028": BASIC_CAPABILITIES,
    "H702A": create_with_capabilities(
        True, True, True, 15, True
    ),  # Issue #245 - Outdoor S14 Bulb String Lights 2
    "H702B": create_with_capabilities(True, True, True, 0, True),
    "H702C": BASIC_CAPABILITIES,  # Issue #262 - segments TBD
    "H7030": BASIC_CAPABILITIES,
    "H7033": BASIC_CAPABILITIES,
    "H7037": BASIC_CAPABILITIES,
    "H7038": BASIC_CAPABILITIES,
    "H7039": create_with_capabilities(True, True, True, 45, True),
    "H703A": BASIC_CAPABILITIES,
    "H703B": BASIC_CAPABILITIES,
    "H7041": BASIC_CAPABILITIES,
    "H7042": BASIC_CAPABILITIES,
    "H7045": BASIC_CAPABILITIES,
    "H7046": BASIC_CAPABILITIES,
    "H7050": BASIC_CAPABILITIES,
    "H7051": BASIC_CAPABILITIES,
    "H7052": create_with_capabilities(True, True, True, 15, True),
    "H7053": create_with_capabilities(True, True, True, 0, True),
    "H7055": BASIC_CAPABILITIES,
    "H7056": BASIC_CAPABILITIES,
    "H7057": create_with_capabilities(True, True, True, 0, True),
    "H7058": create_with_capabilities(True, True, True, 0, True),
    "H705A": BASIC_CAPABILITIES,
    "H705B": BASIC_CAPABILITIES,
    "H705C": BASIC_CAPABILITIES,
    "H705D": create_with_capabilities(True, True, True, 9, True),
    "H705E": create_with_capabilities(True, True, True, 18, True),
    "H705F": create_with_capabilities(True, True, True, 27, True),
    "H7060": BASIC_CAPABILITIES,
    "H7061": BASIC_CAPABILITIES,
    "H7062": BASIC_CAPABILITIES,
    "H7063": BASIC_CAPABILITIES,
    "H7065": BASIC_CAPABILITIES,
    "H7066": BASIC_CAPABILITIES,
    "H7067": create_with_capabilities(True, True, True, 0, True),
    "H706A": BASIC_CAPABILITIES,
    "H706B": BASIC_CAPABILITIES,
    "H706C": BASIC_CAPABILITIES,
    "H7070": BASIC_CAPABILITIES,
    "H7071": BASIC_CAPABILITIES,
    "H7072": BASIC_CAPABILITIES,
    "H7073": BASIC_CAPABILITIES,
    "H7075": BASIC_CAPABILITIES,
    "H7076": create_with_capabilities(True, True, True, 15, True),
    "H707A": BASIC_CAPABILITIES,
    "H707B": BASIC_CAPABILITIES,
    "H707C": BASIC_CAPABILITIES,
    "H7086": create_with_capabilities(True, True, True, 0, True),
    "H7087": BASIC_CAPABILITIES,
    "H7093": create_with_capabilities(True, True, True, 2, True),
    "H7094": BASIC_CAPABILITIES,
    "H70A1": create_with_capabilities(True, True, True, 15, True),
    "H70A2": create_with_capabilities(True, True, True, 20, True),
    "H70A3": create_with_capabilities(True, True, True, 15, True),
    "H70B1": BASIC_CAPABILITIES,
    "H70B3": BASIC_CAPABILITIES,
    "H70B5": create_with_capabilities(True, True, True, 3, True),
    "H70B6": create_with_capabilities(True, True, True, 0, True),
    "H70B8": BASIC_CAPABILITIES,
    "H70BC": BASIC_CAPABILITIES,
    "H70C1": BASIC_CAPABILITIES,
    "H70C2": BASIC_CAPABILITIES,
    "H70C4": create_with_capabilities(True, True, True, 10, True),
    "H70C5": create_with_capabilities(True, True, True, 10, True),
    "H70C7": create_with_capabilities(True, True, True, 10, True),
    "H70C9": BASIC_CAPABILITIES,
    "H70D1": create_with_capabilities(True, True, True, 10, True),
    "H70D2": create_with_capabilities(True, True, True, 10, True),
    "H70D3": BASIC_CAPABILITIES,
    "H8015": BASIC_CAPABILITIES,
    "H801A": BASIC_CAPABILITIES,
    "H801B": BASIC_CAPABILITIES,
    "H801D": BASIC_CAPABILITIES,
    "H8022": BASIC_CAPABILITIES,
    "H8025": BASIC_CAPABILITIES,
    "H8026": BASIC_CAPABILITIES,
    "H802A": BASIC_CAPABILITIES,
    "H8048": BASIC_CAPABILITIES,
    "H8057": BASIC_CAPABILITIES,
    "H805A": create_with_capabilities(True, True, True, 0, True),
    "H805B": BASIC_CAPABILITIES,
    "H805C": create_with_capabilities(True, True, True, 9, True),
    "H8066": BASIC_CAPABILITIES,
    "H8069": BASIC_CAPABILITIES,
    "H8072": create_with_capabilities(True, True, True, 8, True),
    "H8076": BASIC_CAPABILITIES,
    "H8076A": BASIC_CAPABILITIES,
    "H807C": BASIC_CAPABILITIES,
    "H808A": create_with_capabilities(True, True, True, 5, True),
    "H80A1": create_with_capabilities(True, True, True, 14, True),
    "H80A4": BASIC_CAPABILITIES,
    "H80C4": BASIC_CAPABILITIES,
    "H80C5": create_with_capabilities(True, True, True, 10, True),
    "H80D1": BASIC_CAPABILITIES,  # Issue #261 - Icicle lights
    "H8630": BASIC_CAPABILITIES,
    "H8811": BASIC_CAPABILITIES,
    "H8840": BASIC_CAPABILITIES,
    "H8841": BASIC_CAPABILITIES,
}
