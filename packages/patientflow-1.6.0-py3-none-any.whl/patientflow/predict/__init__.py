"""Prediction module for patient flow forecasting.

This module provides functions for making predictions about future patient flow,
including emergency demand forecasting and other predictive analytics.
"""

# No exports - users import directly from submodules
__all__: list[str] = []
