#!/usr/bin/env python

# secret_move - List, copy and move secrets across keyrings with libsecret
# Copyright (C) 2026 Philippe Troin (F-i-f on Github)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import argparse
import os
import re
import sys

import secretstorage

if __name__ == '__main__':
    import _version
else:
    from . import _version

class SecretMove():
    def __init__(self, progname):
        self.progname        = progname
        self.connection      = secretstorage.dbus_init()

    def get_keyring(self, keyring_name):
        colls = list(filter(lambda x: x.get_label() == keyring_name, secretstorage.get_all_collections(self.connection)))
        if len(colls) != 1:
            print(f"{self.progname}: keyring not found: \"{keyring_name}\"", file=sys.stderr)
            return None
        return colls[0]

    def list_all_keyrings(self):
        """Lists all keyrings on the system."""
        collections = secretstorage.get_all_collections(self.connection)

        count = 0
        for c in collections:
            count += 1
            if c.collection_path != "/org/freedesktop/secrets/collection/session":
                print(c.get_label())
        if count == 0:
            print(f"{self.progname}: no keyrings found", file=sys.stderr)

        return True

    def print_secret_attributes(self, item, opt_verbose):
        if opt_verbose:
            attrs = item.get_attributes()
            for k, v in attrs.items():
                print(f"  {k}: {v}")
            if opt_verbose >= 2:
                print(f"  Secret: {item.get_secret()}")

    def list_labels(self, keyring_name, opt_verbose):
        """List all key labels of a keyring."""
        coll = self.get_keyring(keyring_name)
        if coll is None:
            return False
        for l in coll.get_all_items():
            print(l.get_label())
            self.print_secret_attributes(l, opt_verbose)
        return True

    def process_keyring_items(self, search_string, source_name, dest_name,
                              opt_dry_run     = False,
                              opt_verbose     = 0,
                              opt_move        = False,
                              opt_force       = False,
                              opt_quiet       = False,
                              opt_ignore_case = False,
                              opt_regex       = False):

        source_col = self.get_keyring(source_name)
        if source_col is None:
            return False
        dest_col = self.get_keyring(dest_name)
        if dest_col is None:
            return False

        # Define Matching Logic
        if opt_regex:
            anchored_pattern = f"^(?:{search_string})$"
            flags = re.IGNORECASE if opt_ignore_case else 0
            regex = re.compile(anchored_pattern, flags)
            is_match = lambda label: bool(regex.search(label))
        else:
            if opt_ignore_case:
                target = search_string.lower()
                is_match = lambda label: label.lower() == target
            else:
                is_match = lambda label: label == search_string

        # Iterate and Process
        items_matched = 0
        items_processed = 0
        if opt_dry_run:
            action_text = "would move" if opt_move else "would copy"
        else:
            action_text = "moving" if opt_move else "copying"

        dest_items = {i.get_label(): i for i in dest_col.get_all_items()}

        for item in source_col.get_all_items():
            label = item.get_label()

            if not is_match(label):
                continue

            items_matched += 1
            prefix = action_text

            # Overwrite protection
            if label in dest_items:
                if opt_force:
                    prefix += f" and {"overwrite" if opt_dry_run else "overwriting"}"
                else:
                    if not opt_quiet:
                        print(f"{self.progname}: skipping \"{label}\": already exists in \"{dest_name}\" (use -f to overwrite)")
                    continue

            if not opt_quiet:
                print(f"{self.progname}: {prefix}: \"{label}\"")
                self.print_secret_attributes(item, opt_verbose)

            if not opt_dry_run:
                if dest_col.is_locked():
                    dest_col.unlock()
                    if dest_col.is_locked():
                        raise PermissionError(f"Failed to unlock destination keyring \"{dest_name}\".")

                try:
                    dest_col.create_item(label, item.get_attributes(), item.get_secret())
                except Exception as e:
                    raise RuntimeError(f"Failed to create item \"{label}\" in destination: {e}")

                if opt_move:
                    item.delete()

            items_processed += 1

        if not opt_quiet:
            if opt_dry_run:
                print(f"{self.progname}: dry-run complete, would {"move" if opt_move else "copy"} {items_processed} keys (out of {items_matched} match(es))")
            else:
                print(f"{self.progname}: {"moved" if opt_move else "copied"} {items_processed} keys (out of {items_matched} match(es))")

        return True

class VersionAction(argparse.Action):
    def __call__(self, *args):
        print(f"""secret-move version {_version.version}

Copyright (C) 2026 Philippe Troin (F-i-f on GitHub).
secret-move comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under certain conditions.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.""")
        sys.exit(0)


def main(argv = sys.argv):
    progname = os.path.basename(argv[0])

    parser = argparse.ArgumentParser(prog=progname, description="List, copy and move secrets across libsecret keyrings.")
    parser.add_argument("-V", "--version", action=VersionAction, nargs=0, help="show version and copyright notice")

    subparsers = parser.add_subparsers(dest="command", required=True, help="command to execute")

    # Parser for shared options for all commands accessing a source keyring (list, move, copy)
    source_parser = argparse.ArgumentParser(add_help=False)
    source_parser.add_argument("-s", "--source",  default="Login", help="source keyring (default: login)")
    source_parser.add_argument("-v", "--verbose", action="count",  help="show item attributes, repeat a second time to show secrets")

    # Parser for shared options between move and copy
    copy_move_parser = argparse.ArgumentParser(parents=[source_parser], add_help=False)
    copy_move_parser.add_argument("-f", "--force",              action="store_true", help="overwrite existing items in destination")
    copy_move_parser.add_argument("-i", "--ignore-case",        action="store_true", help="case-insensitive matching")
    copy_move_parser.add_argument("-n", "--dry-run", "--no-do", action="store_true", help="dry-run mode")
    copy_move_parser.add_argument("-q", "--quiet",              action="store_true", help="suppress all output except errors")
    copy_move_parser.add_argument("-r", "--regex",              action="store_true", help="enable anchored regex matching")
    copy_move_parser.add_argument("dest",   metavar="DEST",                          help="destination keyring")
    copy_move_parser.add_argument("search", metavar="SEARCH",                        help="label to search for")

    # Command: copy
    subparsers.add_parser("copy", parents=[copy_move_parser], help="copy items between keyrings",
                          description="Copy items matching SEARCH from SOURCE to DEST keyrings.")

    # Command: keyrings
    subparsers.add_parser("keyrings", help="list all available keyrings",
                          description="List all available keyrings.")

    # Command: list
    subparsers.add_parser("list", parents=[source_parser], help="list all keys in a keyring",
                          description="List all keys in SOURCE keyring.")

    # Command: move
    subparsers.add_parser("move", parents=[copy_move_parser], help="move items between keyrings",
                          description="Move items matching SEARCH from SOURCE to DEST keyrings.")

    args = parser.parse_args(argv[1:])

    secret_move = SecretMove(progname)

    if args.command == "keyrings":
        ret = secret_move.list_all_keyrings()
    elif args.command == "list":
        ret = secret_move.list_labels(args.source, args.verbose)
    elif args.command in ("copy", "move"):
        kw = {
            'opt_move': args.command == "move"
        }
        for k in "dry_run", "verbose", "force", "quiet", "ignore_case", "regex":
            kw[f"opt_{k}"] = getattr(args, k)
        ret = secret_move.process_keyring_items(args.search, args.source, args.dest, **kw)
    else:
        raise AssertionError(f"unexpected command={args.command}")

    sys.exit(int(not ret))

if __name__ == "__main__":
    main(sys.argv)
