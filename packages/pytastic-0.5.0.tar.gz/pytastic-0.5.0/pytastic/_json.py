"""Internal JSON shim — uses orjson if installed, else stdlib json.

The chosen implementation is bound once at module load (no per-call branch).
`loads` and `dumps` below are the active functions.

Public API:
    loads(s)
    dumps(obj, indent=None)
"""
from __future__ import annotations
import json as _stdlib_json

try:
    import orjson as _orjson
    HAS_ORJSON = True
except ImportError:
    _orjson = None
    HAS_ORJSON = False


def _orjson_loads(s):
    if isinstance(s, str):
        s = s.encode()
    return _orjson.loads(s)


def _orjson_dumps(obj, indent=None):
    opt = _orjson.OPT_INDENT_2 if indent else 0
    return _orjson.dumps(obj, option=opt).decode()


def _stdlib_loads(s):
    return _stdlib_json.loads(s)


def _stdlib_dumps(obj, indent=None):
    return _stdlib_json.dumps(obj, indent=indent)


_LOADERS = {True: _orjson_loads, False: _stdlib_loads}
_DUMPERS = {True: _orjson_dumps, False: _stdlib_dumps}

loads = _LOADERS[HAS_ORJSON]
dumps = _DUMPERS[HAS_ORJSON]
