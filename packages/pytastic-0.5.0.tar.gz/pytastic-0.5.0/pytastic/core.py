from typing import Any, Type, Dict, TypeVar, Optional, Callable, Union, Iterable, Annotated, get_type_hints, get_origin, get_args
import importlib
try:
    from typing import NotRequired, Required
except ImportError:
    try:
        from typing_extensions import NotRequired, Required
    except ImportError:
        NotRequired = Required = object()
from pytastic.codegen import CodegenCompiler
from pytastic.exceptions import PytasticError, SchemaDefinitionError
from pytastic.schema import JsonSchemaGenerator, to_json_string
from pytastic.compiler import SchemaCompiler
from pytastic.utils import parse_constraints

T = TypeVar("T")


def _build_dot_schema(schema: Type) -> Optional[Dict[str, Any]]:
    """Build a nested {field: subtree_or_None} map from a TypedDict schema.

    Used by DotDict to know which attr names are declared fields (missing →
    None) vs. typos (missing → AttributeError).
    """
    try:
        hints = get_type_hints(schema, include_extras=True)
    except Exception:
        return None
    tree: Dict[str, Any] = {}
    for key, field_type in hints.items():
        if key == '_':
            continue
        ft = field_type
        if get_origin(ft) in (NotRequired, Required):
            ft = get_args(ft)[0]
        if get_origin(ft) is Annotated:
            ft = get_args(ft)[0]
        if hasattr(ft, '__annotations__') and hasattr(ft, '__total__'):
            tree[key] = _build_dot_schema(ft)
        else:
            tree[key] = None
    return tree


class DotDict(dict):
    """A dict subclass supporting attribute access. Nested dicts wrap recursively.

    When constructed with `_schema_keys` (a nested field map), missing *declared*
    fields return None and missing *undeclared* fields raise AttributeError
    (catches typos). Bare DotDict({...}) with no schema is strict: any missing
    key raises AttributeError.
    """
    def __init__(self, *args, _schema_keys: Optional[Dict[str, Any]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        object.__setattr__(self, '_dot_schema', _schema_keys)

    def __getattr__(self, key):
        if key.startswith('__') and key.endswith('__'):
            raise AttributeError(key)
        if key in self:
            value = self[key]
            if isinstance(value, dict) and not isinstance(value, DotDict):
                schema = self.__dict__.get('_dot_schema')
                sub = schema.get(key) if isinstance(schema, dict) else None
                value = DotDict(value, _schema_keys=sub)
                self[key] = value
            return value
        schema = self.__dict__.get('_dot_schema')
        if schema is None:
            raise AttributeError(key)
        if key in schema:
            return None
        raise AttributeError(f"'{key}' is not a declared field of this schema")

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, key):
        try:
            del self[key]
        except KeyError:
            raise AttributeError(key)


class Pytastic:
    """
    Main entry point for Pytastic validation.
    Functions as a registry and factory for validators.
    """
    def __init__(self):
        self.codegen = CodegenCompiler()
        self.compiler = SchemaCompiler()
        self._registry: Dict[str, Any] = {}
        self._attr_cache: Dict[str, Callable[[Any], Any]] = {}
        self._factories: Dict[str, Callable] = {}
        self._setters: Dict[str, Callable] = {}
        self._getters: Dict[str, Callable] = {}
        self._dumpers: Dict[str, Callable] = {}
        self._dot_schema_cache: Dict[Type, Optional[Dict[str, Any]]] = {}
        self._dump_plan_cache: Dict[Type, Dict[str, Any]] = {}

    @staticmethod
    def _resolve_callable(fn_or_path: Union[Callable, str]) -> Callable:
        """Resolve a callable or dotted import path string to a callable."""
        if callable(fn_or_path):
            return fn_or_path
        if isinstance(fn_or_path, str):
            parts = fn_or_path.rsplit('.', 1)
            if len(parts) != 2:
                raise SchemaDefinitionError(f"Import path must be 'module.attr', got '{fn_or_path}'")
            module_path, attr_name = parts
            module = importlib.import_module(module_path)
            fn = getattr(module, attr_name, None)
            if fn is None:
                raise SchemaDefinitionError(f"Cannot find '{attr_name}' in module '{module_path}'")
            return fn
        raise SchemaDefinitionError(f"Expected callable or import path string, got {type(fn_or_path)}")

    def factory(self, name: str, fn_or_path: Union[Callable, str]) -> None:
        """Register a factory function by name (pre-validation, receives the full input dict).
        Used in schemas as ``Annotated[T, "factory=name"]``.
        """
        self._factories[name] = self._resolve_callable(fn_or_path)

    def setter(self, name: str, fn_or_path: Union[Callable, str]) -> None:
        """Register a setter function by name (pre-validation, receives the field's value)."""
        self._setters[name] = self._resolve_callable(fn_or_path)

    def getter(self, name: str, fn_or_path: Union[Callable, str]) -> None:
        """Register a getter function by name (post-validation, receives the validated value).
        Use to hydrate a primitive into a richer type (e.g. ``str`` → ``date``).
        """
        self._getters[name] = self._resolve_callable(fn_or_path)

    def dumper(self, name: str, fn_or_path: Union[Callable, str]) -> None:
        """Register a dumper function by name (dump-time, receives the field's value).
        Used in schemas as ``Annotated[T, "dump=name"]`` and applied by ``vx.dump()``.
        """
        self._dumpers[name] = self._resolve_callable(fn_or_path)
        self._dump_plan_cache.clear()

    def register(self, schema: Type[T]) -> None:
        """
        Registers a schema (TypedDict) with Pytastic.
        Compiles the schema immediately using code generation.
        """
        validator = self.codegen.compile(schema, factories=self._factories, setters=self._setters, getters=self._getters, dumpers=self._dumpers)
        self._registry[schema.__name__] = validator

    def use(self, other: 'Pytastic', prefer: Optional['Pytastic'] = None) -> 'Pytastic':
        """
        Absorb factories, setters, getters, dumpers, and registered schemas from
        another Pytastic instance.

        On name collision in any registry, raises SchemaDefinitionError unless
        ``prefer`` is set to one of the two instances to pick a winner. Returns
        self for chaining.

        Args:
            other: Pytastic instance to absorb registrations from.
            prefer: On collision, which instance wins — must be self or other.
                    Default None raises SchemaDefinitionError on any collision.
        """
        if not isinstance(other, Pytastic):
            raise SchemaDefinitionError(f"use() expects a Pytastic instance, got {type(other).__name__}")
        if prefer is not None and prefer is not self and prefer is not other:
            raise SchemaDefinitionError("prefer must be None, the receiving instance, or the instance being absorbed")

        for label, own, incoming in (
            ("factory", self._factories, other._factories),
            ("setter", self._setters, other._setters),
            ("getter", self._getters, other._getters),
            ("dumper", self._dumpers, other._dumpers),
            ("schema", self._registry, other._registry),
        ):
            for name, value in incoming.items():
                if name in own and own[name] is not value:
                    if prefer is None:
                        raise SchemaDefinitionError(f"{label} '{name}' already registered — pass prefer= to resolve")
                    if prefer is self:
                        continue
                own[name] = value

        self._attr_cache.clear()
        self._dump_plan_cache.clear()
        return self

    def validate(self, schema: Type[T], data: Any, strip: bool = False, partial: Union[bool, Iterable[str]] = False, dot: bool = False, exclude_unset: bool = False, exclude_none: bool = False) -> T:
        """
        Validates data against a schema using code generation.

        Args:
            strip: If True, removes fields from data not defined in the schema.
                   For best performance, define strip=True in the schema's
                   Annotated metadata instead (compiled once, always fast).
            partial: If True, skips required field checks (all fields optional).
                     If iterable of strings, only listed fields are optional.
                     Does not fill defaults.
            dot: If True, returns a DotDict enabling dot-notation attribute access.
            exclude_unset: If True, only returns fields that were present in the
                           input data. Defaults are not injected for absent fields.
                           Explicit None values are preserved (user sent null).
            exclude_none: If True, removes any fields with None values from the
                          output after validation.
        """
        if isinstance(partial, (list, tuple, set)):
            partial = frozenset(partial)

        validator = self.codegen.compile(schema, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, factories=self._factories, setters=self._setters, getters=self._getters, dumpers=self._dumpers)
        result = validator(data)
        if dot:
            keys = self._dot_schema_cache.get(schema)
            if keys is None and schema not in self._dot_schema_cache:
                keys = _build_dot_schema(schema)
                self._dot_schema_cache[schema] = keys
            return DotDict(result, _schema_keys=keys)
        return result

    def patch(self, schema: Type[T], data: Any, strip: bool = False, dot: bool = False, exclude_none: bool = False) -> T:
        """
        Validates data for PATCH semantics: all fields optional, only provided
        fields returned. Shorthand for validate(partial=True, exclude_unset=True).

        Explicit None values are preserved unless exclude_none=True.
        """
        return self.validate(schema, data, strip=strip, partial=True, dot=dot, exclude_unset=True, exclude_none=exclude_none)

    def create(self, schema: Type[T], data: Any, strip: bool = False, partial: Union[bool, Iterable[str]] = False) -> 'DotDict':
        """
        Validates data and returns a DotDict instance with attribute access.
        Shorthand for validate(..., dot=True).
        """
        return self.validate(schema, data, strip=strip, partial=partial, dot=True)

    def dump(self, schema: Type[T], data: dict) -> dict:
        """
        Serialize data using alias mappings and dump callbacks defined in the schema.

        - Renames TypedDict keys to their alias names (``alias=...``).
        - Applies registered dump callables to field values (``dump=name``).
        - Recurses into nested TypedDicts.
        """
        plan = self._get_dump_plan(schema)
        # Fast path: no aliases, no dumpers, no nested schemas anywhere — return as-is.
        if plan is None:
            return data
        return self._apply_dump_plan(plan, data)

    def _apply_dump_plan(self, plan: Dict[str, Any], data: dict) -> dict:
        result = {}
        aliases = plan['aliases']
        dumpers = plan['dumpers']
        children = plan['children']
        for key, value in data.items():
            child = children.get(key)
            if child is not None and isinstance(value, dict):
                value = self._apply_dump_plan(child, value)
            dumper = dumpers.get(key)
            if dumper is not None:
                value = dumper(value)
            result[aliases.get(key, key)] = value
        return result

    def _get_dump_plan(self, schema: Type) -> Optional[Dict[str, Any]]:
        cached = self._dump_plan_cache.get(schema)
        if cached is not None or schema in self._dump_plan_cache:
            return cached
        plan = self._build_dump_plan(schema)
        self._dump_plan_cache[schema] = plan
        return plan

    def _build_dump_plan(self, schema: Type) -> Optional[Dict[str, Any]]:
        """Walk a TypedDict schema once and produce a dump plan:
            {'aliases': {key: alias}, 'dumpers': {key: callable}, 'children': {key: nested_plan}}
        Returns None when the schema has no dump-relevant metadata anywhere.
        """
        try:
            type_hints = get_type_hints(schema, include_extras=True)
        except Exception:
            return None
        aliases: Dict[str, str] = {}
        dumpers: Dict[str, Callable] = {}
        children: Dict[str, Dict[str, Any]] = {}

        for key, field_type in type_hints.items():
            if key == '_':
                continue
            ft = field_type
            if get_origin(ft) in (NotRequired, Required):
                ft = get_args(ft)[0]

            if get_origin(ft) is Annotated:
                ann_args = get_args(ft)
                inner = ann_args[0]
                constraint_str = ''
                for arg in ann_args[1:]:
                    if isinstance(arg, str):
                        constraint_str += arg + ';'
                if constraint_str:
                    parsed = parse_constraints(constraint_str)
                    if isinstance(parsed, dict):
                        if 'alias' in parsed:
                            aliases[key] = parsed['alias']
                        if 'dump' in parsed:
                            name = parsed['dump']
                            fn = self._dumpers.get(name)
                            if fn is None:
                                raise SchemaDefinitionError(f"dump callback '{name}' is not registered (use vx.dumper(name, fn))")
                            dumpers[key] = fn
                ft = inner
                if get_origin(ft) in (NotRequired, Required):
                    ft = get_args(ft)[0]

            if hasattr(ft, '__annotations__') and hasattr(ft, '__total__'):
                child_plan = self._build_dump_plan(ft)
                if child_plan is not None:
                    children[key] = child_plan

        if not aliases and not dumpers and not children:
            return None
        return {'aliases': aliases, 'dumpers': dumpers, 'children': children}

    def __getattr__(self, name: str) -> Callable[[Any], Any]:
        """
        Enables dynamic syntax: vx.UserSchema(data)
        """
        if name in self._attr_cache:
            return self._attr_cache[name]
            
        if name in self._registry:
            validator = self._registry[name]
            self._attr_cache[name] = validator
            return validator
        
        raise AttributeError(f"'Pytastic' object has no attribute '{name}'. Did you forget to register the schema?")

    def schema(self, schema: Type[T]) -> str:
        """
        Returns the JSON Schema definition for a model as a string.
        """
        validator = self.compiler.compile(schema)
        generator = JsonSchemaGenerator()
        json_dict = generator.generate(validator)
        return to_json_string(json_dict)
