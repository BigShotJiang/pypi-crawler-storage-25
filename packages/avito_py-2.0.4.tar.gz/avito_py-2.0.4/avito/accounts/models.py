"""Типизированные модели раздела accounts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from avito.accounts.enums import (
    AccountHierarchyRole,
    EmployeeItemStatus,
    OperationStatus,
    OperationType,
)
from avito.core.serialization import SerializableModel


@dataclass(slots=True, frozen=True)
class AccountProfile(SerializableModel):
    """Профиль авторизованного пользователя."""

    user_id: int | None
    name: str | None
    email: str | None
    phone: str | None


@dataclass(slots=True, frozen=True)
class AccountBalance(SerializableModel):
    """Баланс кошелька пользователя."""

    user_id: int | None
    real: float | None
    bonus: float | None
    total: float | None
    currency: str | None


@dataclass(slots=True, frozen=True)
class OperationRecord(SerializableModel):
    """Операция по аккаунту."""

    id: str | None
    created_at: datetime | None
    amount: float | None
    operation_type: OperationType | None
    status: OperationStatus | None
    description: str | None


@dataclass(slots=True, frozen=True)
class OperationsHistoryRequest:
    """Фильтр истории операций аккаунта."""

    date_from: str | None = None
    date_to: str | None = None
    limit: int | None = None
    offset: int | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует фильтр в JSON body."""

        return {
            key: value
            for key, value in {
                "dateFrom": self.date_from,
                "dateTo": self.date_to,
                "limit": self.limit,
                "offset": self.offset,
            }.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class OperationsHistoryResult(SerializableModel):
    """История операций пользователя."""

    operations: list[OperationRecord]
    total: int | None = None


@dataclass(slots=True, frozen=True)
class AhUserStatus(SerializableModel):
    """Статус пользователя в иерархии аккаунтов."""

    user_id: int | None
    is_active: bool | None
    role: AccountHierarchyRole | None


@dataclass(slots=True, frozen=True)
class Employee(SerializableModel):
    """Сотрудник иерархии аккаунтов."""

    employee_id: int | None
    user_id: int | None
    name: str | None
    phone: str | None
    email: str | None


@dataclass(slots=True, frozen=True)
class EmployeesResult(SerializableModel):
    """Список сотрудников иерархии."""

    items: list[Employee]
    total: int | None = None


@dataclass(slots=True, frozen=True)
class CompanyPhone(SerializableModel):
    """Телефон компании."""

    phone_id: int | None
    phone: str | None
    comment: str | None


@dataclass(slots=True, frozen=True)
class CompanyPhonesResult(SerializableModel):
    """Список телефонов компании."""

    items: list[CompanyPhone]


@dataclass(slots=True, frozen=True)
class EmployeeItemLinkRequest:
    """Запрос на привязку объявлений к сотруднику."""

    employee_id: int
    item_ids: list[int]
    source_employee_id: int | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос привязки в JSON body."""

        return {
            key: value
            for key, value in {
                "employeeId": self.employee_id,
                "itemIds": self.item_ids,
                "sourceEmployeeId": self.source_employee_id,
            }.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class EmployeeItemsRequest:
    """Запрос списка объявлений сотрудника."""

    employee_id: int
    limit: int | None = None
    offset: int | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует фильтр объявлений сотрудника."""

        return {
            key: value
            for key, value in {
                "employeeId": self.employee_id,
                "limit": self.limit,
                "offset": self.offset,
            }.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class EmployeeItem(SerializableModel):
    """Объявление сотрудника в иерархии."""

    item_id: int | None
    title: str | None
    status: EmployeeItemStatus | None
    price: float | None


@dataclass(slots=True, frozen=True)
class EmployeeItemsResult(SerializableModel):
    """Список объявлений сотрудника."""

    items: list[EmployeeItem]
    total: int | None = None


@dataclass(slots=True, frozen=True)
class AccountActionResult(SerializableModel):
    """Результат мутационной операции accounts."""

    success: bool
    message: str | None = None


__all__ = (
    "AccountActionResult",
    "AccountBalance",
    "AccountProfile",
    "AhUserStatus",
    "CompanyPhone",
    "CompanyPhonesResult",
    "Employee",
    "EmployeeItem",
    "EmployeeItemLinkRequest",
    "EmployeeItemsRequest",
    "EmployeeItemsResult",
    "EmployeesResult",
    "OperationRecord",
    "OperationsHistoryRequest",
    "OperationsHistoryResult",
)
