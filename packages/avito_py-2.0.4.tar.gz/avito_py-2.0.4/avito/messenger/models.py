"""Типизированные модели раздела messenger."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import BinaryIO

from avito.core.serialization import SerializableModel
from avito.messenger.enums import (
    MessageActionStatus,
    MessageDirection,
    MessageType,
    SpecialOfferCampaignStatus,
    SubscriptionStatus,
    WebhookStatus,
)


@dataclass(slots=True, frozen=True)
class ChatInfo(SerializableModel):
    """Информация о чате."""

    chat_id: str | None
    user_id: int | None
    title: str | None
    unread_count: int | None
    last_message_text: str | None


@dataclass(slots=True, frozen=True)
class ChatsResult(SerializableModel):
    """Список чатов."""

    items: list[ChatInfo]
    total: int | None = None


@dataclass(slots=True, frozen=True)
class SendMessageRequest:
    """Запрос отправки текстового сообщения."""

    message: str
    type: MessageType | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует сообщение для API."""

        return {
            key: value
            for key, value in {"message": self.message, "type": self.type}.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class SendImageMessageRequest:
    """Запрос отправки сообщения с изображением."""

    image_id: str
    caption: str | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует сообщение с изображением."""

        return {
            key: value
            for key, value in {"imageId": self.image_id, "caption": self.caption}.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class MessageInfo(SerializableModel):
    """Информация о сообщении чата."""

    message_id: str | None
    chat_id: str | None
    author_id: int | None
    text: str | None
    created_at: datetime | None
    direction: MessageDirection | None
    type: MessageType | None


@dataclass(slots=True, frozen=True)
class MessagesResult(SerializableModel):
    """Список сообщений чата."""

    items: list[MessageInfo]
    total: int | None = None


@dataclass(slots=True, frozen=True)
class MessageActionResult(SerializableModel):
    """Результат операции с сообщением или чатом."""

    success: bool
    message_id: str | None = None
    status: MessageActionStatus | None = None


@dataclass(slots=True, frozen=True)
class VoiceFile(SerializableModel):
    """Голосовое сообщение."""

    id: str | None
    url: str | None
    duration: int | None
    transcript: str | None


@dataclass(slots=True, frozen=True)
class VoiceFilesResult(SerializableModel):
    """Список голосовых сообщений."""

    items: list[VoiceFile]


@dataclass(slots=True, frozen=True)
class UploadImageResult(SerializableModel):
    """Результат загрузки изображения."""

    image_id: str | None
    url: str | None


@dataclass(slots=True, frozen=True)
class UploadImagesResult(SerializableModel):
    """Список загруженных изображений."""

    items: list[UploadImageResult]


@dataclass(slots=True, frozen=True)
class UploadImageFile:
    """Файл изображения для загрузки в мессенджер."""

    field_name: str
    filename: str
    content: bytes | BinaryIO
    content_type: str


@dataclass(slots=True, frozen=True)
class UploadImagesRequest:
    """Запрос загрузки изображений для сообщений."""

    files: list[UploadImageFile]

    def to_files(self) -> dict[str, object]:
        """Сериализует multipart-структуру для transport."""

        return {
            file.field_name: (file.filename, file.content, file.content_type) for file in self.files
        }


@dataclass(slots=True, frozen=True)
class SubscriptionInfo(SerializableModel):
    """Подписка webhook мессенджера."""

    url: str | None
    version: str | None
    status: SubscriptionStatus | None


@dataclass(slots=True, frozen=True)
class SubscriptionsResult(SerializableModel):
    """Список webhook-подписок."""

    items: list[SubscriptionInfo]


@dataclass(slots=True, frozen=True)
class UnsubscribeWebhookRequest:
    """Запрос отключения webhook."""

    url: str

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос отключения webhook."""

        return {"url": self.url}


@dataclass(slots=True, frozen=True)
class UpdateWebhookRequest:
    """Запрос включения webhook v3."""

    url: str
    secret: str | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос включения webhook."""

        return {
            key: value
            for key, value in {"url": self.url, "secret": self.secret}.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class WebhookActionResult(SerializableModel):
    """Результат операции с webhook."""

    success: bool
    status: WebhookStatus | None = None


@dataclass(slots=True, frozen=True)
class BlacklistRequest:
    """Запрос добавления пользователя в blacklist."""

    blacklisted_user_id: int

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос blacklist."""

        return {"blacklistedUserId": self.blacklisted_user_id}


@dataclass(slots=True, frozen=True)
class SpecialOfferAvailableRequest:
    """Запрос доступных объявлений для спецпредложений."""

    item_ids: list[int]

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос доступных объявлений."""

        return {"itemIds": self.item_ids}


@dataclass(slots=True, frozen=True)
class SpecialOfferAvailableItem(SerializableModel):
    """Доступное объявление для рассылки спецпредложений."""

    item_id: int | None
    title: str | None
    is_available: bool | None


@dataclass(slots=True, frozen=True)
class SpecialOfferAvailableResult(SerializableModel):
    """Результат получения доступных объявлений."""

    items: list[SpecialOfferAvailableItem]


@dataclass(slots=True, frozen=True)
class MultiCreateSpecialOfferRequest:
    """Запрос создания рассылки."""

    item_ids: list[int]
    message: str
    discount_percent: int | None = None

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос создания рассылки."""

        return {
            key: value
            for key, value in {
                "itemIds": self.item_ids,
                "message": self.message,
                "discountPercent": self.discount_percent,
            }.items()
            if value is not None
        }


@dataclass(slots=True, frozen=True)
class MultiCreateSpecialOfferResult(SerializableModel):
    """Результат создания рассылки."""

    campaign_id: str | None
    status: SpecialOfferCampaignStatus | None


@dataclass(slots=True, frozen=True)
class MultiConfirmSpecialOfferRequest:
    """Запрос подтверждения и оплаты рассылки."""

    campaign_id: str

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос подтверждения рассылки."""

        return {"campaignId": self.campaign_id}


@dataclass(slots=True, frozen=True)
class SpecialOfferStatsRequest:
    """Запрос статистики рассылки."""

    campaign_id: str

    def to_payload(self) -> dict[str, object]:
        """Сериализует запрос статистики рассылки."""

        return {"campaignId": self.campaign_id}


@dataclass(slots=True, frozen=True)
class SpecialOfferStatsResult(SerializableModel):
    """Статистика рассылки."""

    campaign_id: str | None
    sent_count: int | None
    delivered_count: int | None
    read_count: int | None


@dataclass(slots=True, frozen=True)
class TariffInfo(SerializableModel):
    """Информация о тарифе рассылок."""

    price: float | None
    currency: str | None
    daily_limit: int | None


__all__ = (
    "BlacklistRequest",
    "ChatInfo",
    "ChatsResult",
    "MessageActionResult",
    "MessageInfo",
    "MessagesResult",
    "MultiConfirmSpecialOfferRequest",
    "MultiCreateSpecialOfferRequest",
    "MultiCreateSpecialOfferResult",
    "SendImageMessageRequest",
    "SendMessageRequest",
    "SpecialOfferAvailableItem",
    "SpecialOfferAvailableRequest",
    "SpecialOfferAvailableResult",
    "SpecialOfferStatsRequest",
    "SpecialOfferStatsResult",
    "SubscriptionInfo",
    "SubscriptionsResult",
    "TariffInfo",
    "UnsubscribeWebhookRequest",
    "UpdateWebhookRequest",
    "UploadImageFile",
    "UploadImagesRequest",
    "UploadImageResult",
    "UploadImagesResult",
    "VoiceFile",
    "VoiceFilesResult",
    "WebhookActionResult",
)
