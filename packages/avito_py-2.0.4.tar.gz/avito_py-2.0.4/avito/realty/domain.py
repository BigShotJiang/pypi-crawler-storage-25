"""Доменные объекты пакета realty."""

from __future__ import annotations

from dataclasses import dataclass

from avito.core import ValidationError
from avito.core.domain import DomainObject
from avito.realty.client import RealtyAnalyticsClient, ShortTermRentClient
from avito.realty.models import (
    RealtyActionResult,
    RealtyAnalyticsInfo,
    RealtyBookingsQuery,
    RealtyBookingsResult,
    RealtyInterval,
    RealtyMarketPriceInfo,
    RealtyPricePeriod,
)


@dataclass(slots=True, frozen=True)
class RealtyListing(DomainObject):
    """Доменный объект объявления краткосрочной аренды."""

    item_id: int | str | None = None
    user_id: int | str | None = None

    def get_intervals(
        self,
        *,
        intervals: list[RealtyInterval],
        item_id: int | None = None,
    ) -> RealtyActionResult:
        """Выполняет публичную операцию `RealtyListing.get_intervals` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return ShortTermRentClient(self.transport).get_intervals(
            item_id=item_id or int(self._require_item_id()),
            intervals=intervals,
        )

    def update_base_params(
        self, *, min_stay_days: int, item_id: int | str | None = None
    ) -> RealtyActionResult:
        """Выполняет публичную операцию `RealtyListing.update_base_params` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return ShortTermRentClient(self.transport).update_base_params(
            item_id=item_id or self._require_item_id(),
            min_stay_days=min_stay_days,
        )

    def _require_item_id(self) -> str:
        if self.item_id is None:
            raise ValidationError("Для операции требуется `item_id`.")
        return str(self.item_id)


@dataclass(slots=True, frozen=True)
class RealtyBooking(DomainObject):
    """Доменный объект бронирований недвижимости."""

    item_id: int | str | None = None
    user_id: int | str | None = None

    def update_bookings_info(
        self,
        *,
        blocked_dates: list[str],
        user_id: int | str | None = None,
        item_id: int | str | None = None,
    ) -> RealtyActionResult:
        """Выполняет публичную операцию `RealtyBooking.update_bookings_info` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return ShortTermRentClient(self.transport).update_bookings_info(
            user_id=user_id or self._require_user_id(),
            item_id=item_id or self._require_item_id(),
            blocked_dates=blocked_dates,
        )

    def list_realty_bookings(
        self,
        *,
        date_start: str,
        date_end: str,
        with_unpaid: bool | None = None,
        user_id: int | str | None = None,
        item_id: int | str | None = None,
    ) -> RealtyBookingsResult:
        """Выполняет публичную операцию `RealtyBooking.list_realty_bookings` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return ShortTermRentClient(self.transport).list_realty_bookings(
            user_id=user_id or self._require_user_id(),
            item_id=item_id or self._require_item_id(),
            query=RealtyBookingsQuery(
                date_start=date_start,
                date_end=date_end,
                with_unpaid=with_unpaid,
            ),
        )

    def _require_item_id(self) -> str:
        if self.item_id is None:
            raise ValidationError("Для операции требуется `item_id`.")
        return str(self.item_id)

    def _require_user_id(self) -> str:
        if self.user_id is None:
            raise ValidationError("Для операции требуется `user_id`.")
        return str(self.user_id)


@dataclass(slots=True, frozen=True)
class RealtyPricing(DomainObject):
    """Доменный объект цен краткосрочной аренды."""

    item_id: int | str | None = None
    user_id: int | str | None = None

    def update_realty_prices(
        self,
        *,
        periods: list[RealtyPricePeriod],
        user_id: int | str | None = None,
        item_id: int | str | None = None,
    ) -> RealtyActionResult:
        """Выполняет публичную операцию `RealtyPricing.update_realty_prices` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return ShortTermRentClient(self.transport).update_realty_prices(
            user_id=user_id or self._require_user_id(),
            item_id=item_id or self._require_item_id(),
            periods=periods,
        )

    def _require_item_id(self) -> str:
        if self.item_id is None:
            raise ValidationError("Для операции требуется `item_id`.")
        return str(self.item_id)

    def _require_user_id(self) -> str:
        if self.user_id is None:
            raise ValidationError("Для операции требуется `user_id`.")
        return str(self.user_id)


@dataclass(slots=True, frozen=True)
class RealtyAnalyticsReport(DomainObject):
    """Доменный объект аналитики по недвижимости."""

    item_id: int | str | None = None
    user_id: int | str | None = None

    def get_market_price_correspondence(
        self,
        *,
        item_id: int | str | None = None,
        price: int | str,
    ) -> RealtyMarketPriceInfo:
        """Выполняет публичную операцию `RealtyAnalyticsReport.get_market_price_correspondence` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return RealtyAnalyticsClient(self.transport).get_market_price_correspondence(
            item_id=item_id or self._require_item_id(),
            price=price,
        )

    def get_report_for_classified(self, *, item_id: int | str | None = None) -> RealtyAnalyticsInfo:
        """Выполняет публичную операцию `RealtyAnalyticsReport.get_report_for_classified` и возвращает типизированную SDK-модель.

        Пустой результат возвращается как пустая коллекция или `None` согласно аннотации метода.

        Raises: AvitoError с полями operation, status, request_id, attempt, method и endpoint.
        """

        return RealtyAnalyticsClient(self.transport).get_report_for_classified(
            item_id=item_id or self._require_item_id()
        )

    def _require_item_id(self) -> str:
        if self.item_id is None:
            raise ValidationError("Для операции требуется `item_id`.")
        return str(self.item_id)


__all__ = (
    "RealtyAnalyticsReport",
    "RealtyBooking",
    "RealtyListing",
    "RealtyPricing",
)
