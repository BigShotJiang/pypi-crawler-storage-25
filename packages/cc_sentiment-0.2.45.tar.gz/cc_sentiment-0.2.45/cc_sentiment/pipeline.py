from __future__ import annotations

import re
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from functools import cached_property, partial
from pathlib import Path

import anyio
import anyio.to_thread

from cc_sentiment.engines import (
    NOOP_PROGRESS,
    NOOP_SNIPPET,
    EngineFactory,
    FrustrationFilter,
    InferenceEngine,
)
from cc_sentiment.models import (
    BucketKey,
    BucketMetrics,
    ConversationBucket,
    SentimentRecord,
    SentimentScore,
    SessionId,
    TranscriptMessage,
)
from cc_sentiment.repo import Repository
from cc_sentiment.transcripts import (
    CLAUDE_PROJECTS_DIR,
    ConversationBucketer,
    ParsedTranscript,
    TranscriptParser,
)

SNIPPET_FENCED_CODE = re.compile(r"```.*?```", re.DOTALL)
SNIPPET_INLINE_CODE = re.compile(r"`[^`]*`")
SNIPPET_LONG_PATH = re.compile(r"\S{40,}")
SNIPPET_WHITESPACE = re.compile(r"\s+")
SNIPPET_MAX_LEN = 80
STREAM_CHUNK_SIZE = 16


@dataclass(frozen=True)
class ScannedTranscript:
    path: Path
    mtime: float
    new_bucket_keys: tuple[BucketKey, ...]


@dataclass(frozen=True)
class ScanResult:
    transcripts: tuple[ScannedTranscript, ...]
    scored_by_path: Mapping[str, frozenset[BucketKey]]

    @cached_property
    def total_new_buckets(self) -> int:
        return sum(len(t.new_bucket_keys) for t in self.transcripts)

    @cached_property
    def paths(self) -> list[tuple[Path, float]]:
        return [(t.path, t.mtime) for t in self.transcripts]


class Pipeline:
    @staticmethod
    async def scan(repo: Repository) -> ScanResult:
        known = await anyio.to_thread.run_sync(repo.file_mtimes)
        scored_by_path = await anyio.to_thread.run_sync(repo.scored_buckets_for_all)
        raw = await anyio.to_thread.run_sync(
            partial(TranscriptParser.scan_bucket_keys, CLAUDE_PROJECTS_DIR, known_mtimes=known)
        )
        return ScanResult(
            transcripts=tuple(
                ScannedTranscript(
                    path=Path(path),
                    mtime=mtime,
                    new_bucket_keys=tuple(new_keys),
                )
                for path, mtime, keys in raw
                if (new_keys := [
                    k for k in keys
                    if k not in scored_by_path.get(str(path), frozenset())
                ])
            ),
            scored_by_path=scored_by_path,
        )

    @staticmethod
    def buckets_with_metrics(
        messages: tuple[TranscriptMessage, ...],
        scored_buckets: frozenset[BucketKey],
    ) -> tuple[list[ConversationBucket], dict[BucketKey, BucketMetrics]]:
        if not messages:
            return [], {}
        all_buckets = ConversationBucketer.bucket_messages(list(messages))

        by_session: dict[SessionId, list[ConversationBucket]] = {}
        for b in all_buckets:
            by_session.setdefault(b.session_id, []).append(b)

        metrics_by_key: dict[BucketKey, BucketMetrics] = {}
        for session_buckets in by_session.values():
            session_buckets.sort(key=lambda b: b.bucket_index)
            reads_so_far: set[str] = set()
            for bucket in session_buckets:
                metrics = BucketMetrics.from_messages_with_history(
                    bucket.messages, frozenset(reads_so_far)
                )
                metrics_by_key[
                    BucketKey(session_id=bucket.session_id, bucket_index=bucket.bucket_index)
                ] = metrics
                reads_so_far.update(
                    c.file_path
                    for m in bucket.messages
                    for c in m.tool_calls
                    if c.name == "Read" and c.file_path
                )

        new_buckets = [
            b for b in all_buckets
            if BucketKey(session_id=b.session_id, bucket_index=b.bucket_index)
            not in scored_buckets
        ]
        return new_buckets, metrics_by_key

    @staticmethod
    def clean_snippet(text: str) -> str:
        stripped = SNIPPET_FENCED_CODE.sub(" ", text)
        stripped = SNIPPET_INLINE_CODE.sub(" ", stripped)
        stripped = "\n".join(
            line for line in stripped.splitlines() if not line.lstrip().startswith(">")
        )
        stripped = SNIPPET_LONG_PATH.sub(" ", stripped)
        cleaned = SNIPPET_WHITESPACE.sub(" ", stripped).strip()
        if not cleaned:
            return ""
        return cleaned[:SNIPPET_MAX_LEN - 1] + "…" if len(cleaned) > SNIPPET_MAX_LEN else cleaned

    @classmethod
    def snippet_for(cls, bucket: ConversationBucket, score: int) -> str:
        if score == 1 and (matched := FrustrationFilter.matched_user_message(bucket)) is not None:
            if cleaned := cls.clean_snippet(matched):
                return cleaned
        for msg in bucket.messages:
            if msg.role != "user":
                continue
            if cleaned := cls.clean_snippet(msg.content):
                return cleaned
        return ""

    @staticmethod
    def to_record(
        bucket: ConversationBucket, score: SentimentScore, metrics: BucketMetrics
    ) -> SentimentRecord:
        return SentimentRecord(
            time=bucket.bucket_start,
            conversation_id=bucket.session_id,
            bucket_index=bucket.bucket_index,
            sentiment_score=score,
            read_edit_ratio=metrics.read_edit_ratio,
            edits_without_prior_read_ratio=metrics.edits_without_prior_read_ratio,
            write_edit_ratio=metrics.write_edit_ratio,
            tool_calls_per_turn=metrics.tool_calls_per_turn,
            subagent_count=metrics.subagent_count,
            turn_count=metrics.turn_count,
            thinking_present=metrics.thinking_present,
            thinking_chars=metrics.thinking_chars,
            cc_version=metrics.cc_version,
            claude_model=metrics.claude_model,
        )

    @classmethod
    async def score_transcript(
        cls,
        parsed: ParsedTranscript,
        classifier: InferenceEngine,
        scored_buckets: frozenset[BucketKey] = frozenset(),
        on_bucket: Callable[[int], None] = NOOP_PROGRESS,
        on_snippet: Callable[[str, int], Awaitable[None]] = NOOP_SNIPPET,
        on_records: Callable[[list[SentimentRecord]], None] = lambda _: None,
    ) -> list[SentimentRecord]:
        new_buckets, metrics_by_key = cls.buckets_with_metrics(
            parsed.messages, scored_buckets
        )
        if not new_buckets:
            return []

        all_records: list[SentimentRecord] = []
        for start in range(0, len(new_buckets), STREAM_CHUNK_SIZE):
            chunk = new_buckets[start:start + STREAM_CHUNK_SIZE]
            scores = await classifier.score(chunk, on_progress=on_bucket)
            for bucket, score in zip(chunk, scores):
                if snippet := cls.snippet_for(bucket, int(score)):
                    await on_snippet(snippet, int(score))
            chunk_records = [
                cls.to_record(
                    bucket,
                    score,
                    metrics_by_key[BucketKey(
                        session_id=bucket.session_id, bucket_index=bucket.bucket_index
                    )],
                )
                for bucket, score in zip(chunk, scores)
            ]
            all_records.extend(chunk_records)
            on_records(chunk_records)

        return all_records

    @classmethod
    async def run(
        cls,
        repo: Repository,
        scan: ScanResult,
        engine: str = "omlx",
        model_repo: str | None = None,
        on_records: Callable[[list[SentimentRecord]], None] = lambda _: None,
        on_bucket: Callable[[int], None] = NOOP_PROGRESS,
        on_engine_log: Callable[[str], None] | None = None,
        on_snippet: Callable[[str, int], Awaitable[None]] = NOOP_SNIPPET,
        on_transcript_complete: Callable[[list[SentimentRecord]], None] = lambda _: None,
    ) -> list[SentimentRecord]:
        classifier = await EngineFactory.build(engine, model_repo, on_engine_log)

        try:
            if not scan.transcripts:
                return []

            all_records: list[SentimentRecord] = []

            async for parsed in TranscriptParser.stream_transcripts(scan.paths):
                scored = scan.scored_by_path.get(str(parsed.path), frozenset())
                records = await cls.score_transcript(
                    parsed, classifier, scored,
                    on_bucket=on_bucket, on_snippet=on_snippet,
                    on_records=on_records,
                )
                all_records.extend(records)
                await anyio.to_thread.run_sync(
                    repo.save_records, str(parsed.path), parsed.mtime, records
                )
                if records:
                    on_transcript_complete(records)

            return all_records
        finally:
            await classifier.close()
