"""Version helpers for the XRTM meta-package."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("xrtm")
except PackageNotFoundError:  # pragma: no cover - editable source tree fallback
    __version__ = "0.3.0"

__all__ = ["__version__"]
