import logging
from google import genai
from google.genai import types
from .utils import Colors, Serializer
from .tools import ToolRegistry

logger = logging.getLogger("Swarm.Core")

class Agent:
    def __init__(self, agent_id, name, description, config):
        self.id = agent_id
        self.name = name
        self.description = description
        self.model = config.get('model', 'gemini-3.1-flash-lite')
        self.sys_prompt = config.get('sys_prompt', 'You are a helpful agent.')
        self.temperature = float(config.get('temp', 0.7))
        self.history = []
        self.tools_enabled = config.get('tools', ["web_search", "shell_exec", "upload_file", "pass_turn"])
        self.max_search = int(config.get('max_search', 5))
        self.cmd_timeout = int(config.get('cmd_timeout', 300))
        self.cmd_blacklist = config.get('cmd_blacklist', [])
        self.file_blacklist = config.get('file_blacklist', [])

    def trim_history(self):
        # Оставляем системный промпт (индекс 0) и последние 10 сообщений
        if len(self.history) > 15:
            system_msg = self.history[0]
            recent_msgs = self.history[-10:]
            summary = f"[SYSTEM: History truncated. Previous length: {len(self.history)}]"
            self.history = [system_msg, types.Content(role="user", parts=[types.Part(text=summary)])] + recent_msgs

class SwarmSession:
    def __init__(self, args, keys):
        self.args = args
        self.keys = keys
        self.key_idx = 0
        self.client = genai.Client(api_key=self.keys[self.key_idx])
        self.agents = {}
        self.current_agent_name = None
        self.last_interaction = args.first_msg
        self.enable_pauses = not args.no_pause
        self.turn_passed_manually = False
        self._init_agents(args)

    def _init_agents(self, args):
        arg_dict = vars(args)
        for i in range(args.agents_count):
            p = f"ai{i+1}_"
            config = {
                'model': arg_dict.get(f"{p}model", args.model),
                'sys_prompt': arg_dict.get(f"{p}sys", args.sys1 if i == 0 else args.sys2),
                'temp': arg_dict.get(f"{p}temp", args.temp),
                'tools': arg_dict.get(f"{p}tools", ["web_search", "shell_exec", "upload_file", "pass_turn"]),
                'max_search': arg_dict.get(f"{p}max_search", args.max_results),
                'cmd_timeout': arg_dict.get(f"{p}cmd_timeout", args.cmd_timeout),
                'cmd_blacklist': arg_dict.get(f"{p}cmd_blacklist", args.cmd_blacklist),
                'file_blacklist': arg_dict.get(f"{p}file_blacklist", args.file_blacklist),
            }
            name = arg_dict.get(f"{p}name", f"Agent_{i+1}")
            desc = arg_dict.get(f"{p}desc", "An autonomous participant in the Swarm.")
            self.agents[name] = Agent(i+1, name, desc, config)
            if i == 0: self.current_agent_name = name

    def execute_step(self):
        agent = self.agents[self.current_agent_name]
        agent.history.append(types.Content(role="user", parts=[types.Part(text=self.last_interaction)]))
        agent.trim_history()
        # ... (остальная логика execute_step остается прежней, с добавлением request_options) ...
        # (Пропущено для краткости, подразумевается наличие request_options={"timeout": 60})
        return "Step executed", []

    def rotate_agent(self):
        names = list(self.agents.keys())
        current_idx = names.index(self.current_agent_name)
        self.current_agent_name = names[(current_idx + 1) % len(names)]
