import logging
from .core import Swarm

class SwarmCLI:
    def __init__(self, swarm):
        self.swarm = swarm

    def show_menu(self):
        print("\n--- Swarm Command Center ---")
        print("1. Send Prompt")
        print("2. Save Session")
        print("3. Load Session")
        print("4. List Agents")
        print("5. Switch Agent")
        print("6. Exit")
        print("7. Continue (Resume Execution)")
        choice = input("Select an option: ")
        return choice

    def run(self):
        while True:
            choice = self.show_menu()
            if choice == '1':
                prompt = input("Enter prompt: ")
                result = self.swarm.execute_turn(prompt)
                print(f"Result: {result}")
            elif choice == '2':
                self.swarm.save_session("swarm_session.json")
                print("Session saved.")
            elif choice == '3':
                self.swarm.load_session("swarm_session.json")
                print("Session loaded.")
            elif choice == '7':
                continue
            elif choice == '6':
                break
            else:
                print("Invalid option.")
