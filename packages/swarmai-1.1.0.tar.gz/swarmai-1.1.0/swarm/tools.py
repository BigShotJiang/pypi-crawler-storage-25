import ast
import operator
import logging

class ToolRegistry:
    _tools = {}

    @classmethod
    def register(cls, name, description):
        def decorator(func):
            cls._tools[name] = {"func": func, "description": description}
            return func
        return decorator

    @classmethod
    def get_tool_definitions(cls):
        return {name: tool["description"] for name, tool in cls._tools.items()}

    @classmethod
    def execute(cls, name, **kwargs):
        if name in cls._tools:
            try:
                return cls._tools[name]["func"](**kwargs)
            except Exception as e:
                return f"Tool execution error: {e}"
        return "Error: Tool not found."

@ToolRegistry.register(name="calculator", description="Perform safe math calculations. Input: expression (str)")
def calculator(expression: str):
    allowed_operators = {
        ast.Add: operator.add, 
        ast.Sub: operator.sub, 
        ast.Mult: operator.mul, 
        ast.Div: operator.truediv,
        ast.Pow: operator.pow
    }
    try:
        node = ast.parse(expression, mode='eval').body
        def eval_node(node):
            if isinstance(node, ast.Constant): # В python 3.8+ это Constant
                return node.value
            if isinstance(node, ast.BinOp):
                return allowed_operators[type(node.op)](eval_node(node.left), eval_node(node.right))
            if isinstance(node, ast.UnaryOp):
                if isinstance(node.op, ast.USub):
                    return -eval_node(node.operand)
            raise ValueError("Unsupported operation")
        return eval_node(node)
    except Exception as e:
        return f"Calculation error: {e}"
