import json
import logging

class Colors:
    SYS = "\033[94m"
    AI_COLORS = ["\033[92m", "\033[93m", "\033[95m", "\033[96m"]
    BOLD = "\033[1m"
    RESET = "\033[0m"
    ERR = "\033[91m"
    MENU = "\033[36m"
    REPORT = "\033[35m"

class Serializer:
    @staticmethod
    def serialize_history(history):
        # Преобразование истории в сериализуемый вид
        return [h.model_dump() for h in history]

    @staticmethod
    def deserialize_history(data):
        # Преобразование обратно в объекты types.Content
        from google.genai import types
        return [types.Content(**h) for h in data]

    @staticmethod
    def save(path, data):
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logging.error(f"Ошибка сохранения сессии: {e}")

    @staticmethod
    def load(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"Ошибка загрузки сессии: {e}")
            return {}

def setup_logger(level):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO))
    return logging.getLogger("Swarm")

def smart_sleep(seconds, enabled=True):
    import time
    if enabled: time.sleep(seconds)
