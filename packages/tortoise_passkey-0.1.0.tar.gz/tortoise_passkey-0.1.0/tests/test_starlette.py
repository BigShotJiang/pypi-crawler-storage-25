"""Tests for the Starlette integration."""

from __future__ import annotations

from base64 import urlsafe_b64encode
from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient
from starlette.applications import Starlette
from starlette.responses import JSONResponse

from tests.models import DemoUser
from tortoise_passkey.config import PasskeyConfig
from tortoise_passkey.integrations.starlette import passkey_routes
from tortoise_passkey.models import PasskeyCredential
from tortoise_passkey.service import AuthenticationResult, PasskeyService

FAKE_CREDENTIAL_ID = b"\x01\x02\x03\x04\x05\x06\x07\x08"
FAKE_CREDENTIAL_ID_B64 = urlsafe_b64encode(FAKE_CREDENTIAL_ID).rstrip(b"=").decode()
FAKE_PUBLIC_KEY = b"\x10\x20\x30\x40\x50"


@dataclass
class FakeVerifiedRegistration:
    credential_id: bytes = FAKE_CREDENTIAL_ID
    credential_public_key: bytes = FAKE_PUBLIC_KEY
    sign_count: int = 0
    aaguid: str = "00000000-0000-0000-0000-000000000000"
    credential_device_type: str = "multi_device"
    credential_backed_up: bool = True


@dataclass
class FakeVerifiedAuthentication:
    credential_id: bytes = FAKE_CREDENTIAL_ID
    new_sign_count: int = 1
    credential_device_type: str = "multi_device"
    credential_backed_up: bool = True
    user_verified: bool = True


def _fake_options() -> MagicMock:
    opts = MagicMock()
    opts.challenge = b"fake-challenge"
    return opts


def _registration_credential() -> dict[str, Any]:
    return {
        "id": FAKE_CREDENTIAL_ID_B64,
        "rawId": FAKE_CREDENTIAL_ID_B64,
        "type": "public-key",
        "response": {"attestationObject": "fake", "clientDataJSON": "fake"},
    }


def _authentication_credential() -> dict[str, Any]:
    return {
        "id": FAKE_CREDENTIAL_ID_B64,
        "rawId": FAKE_CREDENTIAL_ID_B64,
        "type": "public-key",
        "response": {
            "authenticatorData": "fake",
            "clientDataJSON": "fake",
            "signature": "fake",
        },
    }


def _make_app(
    *,
    service: PasskeyService,
    user: DemoUser | None,
) -> Starlette:
    async def get_user(request):
        return user

    async def on_authenticated(request, result: AuthenticationResult):
        return JSONResponse(
            {
                "user_id": str(result.user.pk),
                "credential_id": result.credential.credential_id_b64,
            }
        )

    return Starlette(
        routes=passkey_routes(
            service, get_user=get_user, on_authenticated=on_authenticated
        )
    )


def _make_service() -> PasskeyService:
    return PasskeyService(
        PasskeyConfig(
            user_model="models.DemoUser",
            rp_id="example.com",
            rp_name="Test App",
            origin="https://example.com",
        )
    )


@pytest.fixture
async def user() -> DemoUser:
    return await DemoUser.create(email="u@example.com", display_name="u")


@pytest.fixture
def service() -> PasskeyService:
    return _make_service()


async def _client(app: Starlette) -> AsyncClient:
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://test")


class TestRegisterRoutes:
    async def test_begin_requires_auth(self, service):
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.post("/passkey/register/begin")
        assert resp.status_code == 401

    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value='{"x":1}')
    async def test_begin_returns_options(self, mock_to_json, mock_gen, service, user):
        mock_gen.return_value = _fake_options()
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.post("/passkey/register/begin")
        assert resp.status_code == 200
        body = resp.json()
        assert body["options"] == {"x": 1}
        assert isinstance(body["challenge_id"], str)

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_creates_credential(
        self, mock_to_json, mock_gen, mock_verify, service, user
    ):
        mock_gen.return_value = _fake_options()
        mock_verify.return_value = FakeVerifiedRegistration()
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            begin = await client.post("/passkey/register/begin")
            challenge_id = begin.json()["challenge_id"]
            resp = await client.post(
                "/passkey/register/complete",
                json={
                    "credential": _registration_credential(),
                    "challenge_id": challenge_id,
                    "name": "Laptop",
                },
            )
        assert resp.status_code == 201
        body = resp.json()
        assert body["id"] == FAKE_CREDENTIAL_ID_B64
        assert body["name"] == "Laptop"

    async def test_complete_missing_body(self, service, user):
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.post("/passkey/register/complete", json={})
        assert resp.status_code == 400

    async def test_complete_expired_challenge(self, service, user):
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.post(
                "/passkey/register/complete",
                json={
                    "credential": _registration_credential(),
                    "challenge_id": "nope",
                },
            )
        assert resp.status_code == 400
        assert "Challenge" in resp.json()["detail"]


class TestAuthenticateRoutes:
    async def _seed_credential(self, user: DemoUser) -> PasskeyCredential:
        return await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )

    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value='{"x":1}')
    async def test_begin_anonymous(self, mock_to_json, mock_gen, service):
        mock_gen.return_value = _fake_options()
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.post("/passkey/authenticate/begin")
        assert resp.status_code == 200
        assert "challenge_id" in resp.json()

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_invokes_callback(
        self, mock_to_json, mock_gen, mock_verify, service, user
    ):
        mock_gen.return_value = _fake_options()
        mock_verify.return_value = FakeVerifiedAuthentication()
        await self._seed_credential(user)
        # user=None for the begin call so it's a discoverable flow
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            begin = await client.post("/passkey/authenticate/begin")
            challenge_id = begin.json()["challenge_id"]
            resp = await client.post(
                "/passkey/authenticate/complete",
                json={
                    "credential": _authentication_credential(),
                    "challenge_id": challenge_id,
                },
            )
        assert resp.status_code == 200
        body = resp.json()
        assert body["user_id"] == str(user.pk)
        assert body["credential_id"] == FAKE_CREDENTIAL_ID_B64

    async def test_complete_missing_body(self, service):
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.post("/passkey/authenticate/complete", json={})
        assert resp.status_code == 400

    async def test_complete_expired_challenge(self, service):
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.post(
                "/passkey/authenticate/complete",
                json={
                    "credential": _authentication_credential(),
                    "challenge_id": "nope",
                },
            )
        assert resp.status_code == 401


class TestCredentialRoutes:
    async def test_list_requires_auth(self, service):
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.get("/passkey/credentials")
        assert resp.status_code == 401

    async def test_list_returns_credentials(self, service, user):
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
            name="Phone",
        )
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.get("/passkey/credentials")
        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 1
        assert body[0]["id"] == FAKE_CREDENTIAL_ID_B64
        assert body[0]["name"] == "Phone"

    async def test_delete_requires_auth(self, service):
        app = _make_app(service=service, user=None)
        async with await _client(app) as client:
            resp = await client.delete(f"/passkey/credentials/{FAKE_CREDENTIAL_ID_B64}")
        assert resp.status_code == 401

    async def test_delete_removes_credential(self, service, user):
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.delete(f"/passkey/credentials/{FAKE_CREDENTIAL_ID_B64}")
        assert resp.status_code == 204
        assert await PasskeyCredential.filter(user_id=str(user.pk)).count() == 0

    async def test_delete_not_found(self, service, user):
        app = _make_app(service=service, user=user)
        async with await _client(app) as client:
            resp = await client.delete("/passkey/credentials/does-not-exist")
        assert resp.status_code == 404
