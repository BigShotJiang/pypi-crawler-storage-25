"""Test-only user model for tortoise-passkey tests."""

from __future__ import annotations

from tortoise import fields
from tortoise.models import Model


class DemoUser(Model):
    """Minimal user model used by the test suite."""

    id = fields.IntField(primary_key=True)
    email = fields.CharField(max_length=255, unique=True)
    display_name = fields.CharField(max_length=255, default="")
    is_active = fields.BooleanField(default=True)

    class Meta:
        table = "test_users"
