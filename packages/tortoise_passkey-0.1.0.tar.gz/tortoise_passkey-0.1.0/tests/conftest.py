"""Shared pytest fixtures for tortoise-passkey tests."""

from __future__ import annotations

import pytest
import pytest_asyncio
from tortoise.context import tortoise_test_context

from tortoise_passkey import config as config_module
from tortoise_passkey.events import emitter


@pytest_asyncio.fixture(scope="function", autouse=True)
async def init_db():
    """Initialize an in-memory SQLite database for each test."""
    async with tortoise_test_context(
        modules=["tests.models", "tortoise_passkey.models"],
        db_url="sqlite://:memory:",
    ) as ctx:
        yield ctx


@pytest.fixture(autouse=True)
def _clear_events():
    emitter.clear()
    yield
    emitter.clear()


@pytest.fixture(autouse=True)
def _clear_config():
    config_module._config = None
    yield
    config_module._config = None
