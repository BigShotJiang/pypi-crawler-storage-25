"""Tests for the PasskeyService."""

from __future__ import annotations

import json
from base64 import urlsafe_b64encode
from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from tests.models import DemoUser
from tortoise_passkey.challenge_memory import InMemoryChallengeBackend
from tortoise_passkey.config import PasskeyConfig
from tortoise_passkey.events import emitter
from tortoise_passkey.exceptions import (
    PasskeyAuthenticationError,
    PasskeyError,
    PasskeyRegistrationError,
)
from tortoise_passkey.models import PasskeyCredential
from tortoise_passkey.service import AuthenticationResult, PasskeyService


def make_config(**overrides: object) -> PasskeyConfig:
    defaults: dict[str, object] = {
        "user_model": "models.DemoUser",
        "rp_id": "example.com",
        "rp_name": "Test App",
        "origin": "https://example.com",
        "challenge_ttl": 300,
    }
    defaults.update(overrides)
    return PasskeyConfig(**defaults)  # type: ignore[arg-type]


async def _create_user(email: str = "user@example.com") -> DemoUser:
    return await DemoUser.create(email=email, display_name=email)


FAKE_CREDENTIAL_ID = b"\x01\x02\x03\x04\x05\x06\x07\x08"
FAKE_CREDENTIAL_ID_B64 = urlsafe_b64encode(FAKE_CREDENTIAL_ID).rstrip(b"=").decode()
FAKE_PUBLIC_KEY = b"\x10\x20\x30\x40\x50"
FAKE_AAGUID = "00000000-0000-0000-0000-000000000000"


@dataclass
class FakeVerifiedRegistration:
    credential_id: bytes = FAKE_CREDENTIAL_ID
    credential_public_key: bytes = FAKE_PUBLIC_KEY
    sign_count: int = 0
    aaguid: str = FAKE_AAGUID
    credential_device_type: str = "multi_device"
    credential_backed_up: bool = True


@dataclass
class FakeVerifiedAuthentication:
    credential_id: bytes = FAKE_CREDENTIAL_ID
    new_sign_count: int = 1
    credential_device_type: str = "multi_device"
    credential_backed_up: bool = True
    user_verified: bool = True


def _fake_registration_options() -> MagicMock:
    opts = MagicMock()
    opts.challenge = b"fake-challenge-registration"
    return opts


def _fake_authentication_options() -> MagicMock:
    opts = MagicMock()
    opts.challenge = b"fake-challenge-authentication"
    return opts


def _fake_registration_credential() -> dict[str, Any]:
    return {
        "id": FAKE_CREDENTIAL_ID_B64,
        "rawId": FAKE_CREDENTIAL_ID_B64,
        "type": "public-key",
        "response": {"attestationObject": "fake", "clientDataJSON": "fake"},
    }


def _fake_authentication_credential() -> dict[str, Any]:
    return {
        "id": FAKE_CREDENTIAL_ID_B64,
        "rawId": FAKE_CREDENTIAL_ID_B64,
        "type": "public-key",
        "response": {
            "authenticatorData": "fake",
            "clientDataJSON": "fake",
            "signature": "fake",
        },
    }


class TestPasskeyRegistration:
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value='{"mock": true}')
    async def test_begin_returns_options(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_registration_options()
        user = await _create_user()
        svc = PasskeyService(make_config())
        result = await svc.begin_registration(user)
        assert "options" in result
        assert "challenge_id" in result
        mock_gen.assert_called_once()

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_stores_credential(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_registration_options()
        mock_verify.return_value = FakeVerifiedRegistration()
        user = await _create_user()
        svc = PasskeyService(make_config())

        reg = await svc.begin_registration(user)
        passkey = await svc.complete_registration(
            user,
            credential=_fake_registration_credential(),
            challenge_id=reg["challenge_id"],
            name="My Key",
        )

        assert isinstance(passkey, PasskeyCredential)
        assert passkey.user_id == str(user.pk)
        assert passkey.credential_id_b64 == FAKE_CREDENTIAL_ID_B64
        assert bytes(passkey.public_key) == FAKE_PUBLIC_KEY
        assert passkey.name == "My Key"
        assert passkey.credential_device_type == "multi_device"
        assert passkey.credential_backed_up is True

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_emits_event(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_registration_options()
        mock_verify.return_value = FakeVerifiedRegistration()
        user = await _create_user()
        svc = PasskeyService(make_config())
        events: list[dict[str, Any]] = []

        @emitter.on("passkey_registered")
        async def handler(**kwargs: Any) -> None:
            events.append(kwargs)

        reg = await svc.begin_registration(user)
        await svc.complete_registration(
            user,
            credential=_fake_registration_credential(),
            challenge_id=reg["challenge_id"],
        )
        assert len(events) == 1
        assert events[0]["user"].pk == user.pk

    async def test_complete_expired_challenge(self):
        user = await _create_user()
        svc = PasskeyService(make_config())
        with pytest.raises(PasskeyRegistrationError, match="Challenge expired"):
            await svc.complete_registration(
                user,
                credential=_fake_registration_credential(),
                challenge_id="nonexistent",
            )

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_user_mismatch(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_registration_options()
        user1 = await _create_user("a@example.com")
        user2 = await _create_user("b@example.com")
        svc = PasskeyService(make_config())

        reg = await svc.begin_registration(user1)
        with pytest.raises(PasskeyRegistrationError, match="does not belong"):
            await svc.complete_registration(
                user2,
                credential=_fake_registration_credential(),
                challenge_id=reg["challenge_id"],
            )

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_invalid_response(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_registration_options()
        mock_verify.side_effect = Exception("Invalid attestation")
        user = await _create_user()
        svc = PasskeyService(make_config())

        reg = await svc.begin_registration(user)
        with pytest.raises(PasskeyRegistrationError, match="verification failed"):
            await svc.complete_registration(
                user,
                credential=_fake_registration_credential(),
                challenge_id=reg["challenge_id"],
            )

    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_begin_excludes_existing(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_registration_options()
        user = await _create_user()
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )

        svc = PasskeyService(make_config())
        await svc.begin_registration(user)

        assert len(mock_gen.call_args.kwargs["exclude_credentials"]) == 1

    async def test_begin_no_rp_id(self):
        user = await _create_user()
        svc = PasskeyService(make_config(rp_id=""))
        with pytest.raises(PasskeyRegistrationError, match="rp_id"):
            await svc.begin_registration(user)

    async def test_begin_no_rp_name(self):
        user = await _create_user()
        svc = PasskeyService(make_config(rp_name=""))
        with pytest.raises(PasskeyRegistrationError, match="rp_name"):
            await svc.begin_registration(user)

    @patch("webauthn.verify_registration_response")
    @patch("webauthn.generate_registration_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_accepts_json_string(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_registration_options()
        mock_verify.return_value = FakeVerifiedRegistration()
        user = await _create_user()
        svc = PasskeyService(make_config())

        reg = await svc.begin_registration(user)
        passkey = await svc.complete_registration(
            user,
            credential=json.dumps(_fake_registration_credential()),
            challenge_id=reg["challenge_id"],
        )
        assert isinstance(passkey, PasskeyCredential)


class TestPasskeyAuthentication:
    async def _setup(self) -> tuple[DemoUser, PasskeyCredential]:
        user = await _create_user()
        cred = await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
            aaguid=FAKE_AAGUID,
            credential_device_type="multi_device",
            credential_backed_up=True,
        )
        return user, cred

    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value='{"mock": true}')
    async def test_begin_returns_options(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_authentication_options()
        svc = PasskeyService(make_config())
        result = await svc.begin_authentication()
        assert "options" in result
        assert "challenge_id" in result

    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_begin_with_user_limits_credentials(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_authentication_options()
        user, _ = await self._setup()
        svc = PasskeyService(make_config())
        await svc.begin_authentication(user=user)
        assert len(mock_gen.call_args.kwargs["allow_credentials"]) == 1

    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_begin_without_user_is_discoverable(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_authentication_options()
        svc = PasskeyService(make_config())
        await svc.begin_authentication()
        assert "allow_credentials" not in mock_gen.call_args.kwargs

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_returns_authentication_result(
        self, mock_to_json, mock_gen, mock_verify
    ):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.return_value = FakeVerifiedAuthentication()
        user, cred = await self._setup()
        svc = PasskeyService(make_config())

        auth_opts = await svc.begin_authentication()
        result = await svc.complete_authentication(
            credential=_fake_authentication_credential(),
            challenge_id=auth_opts["challenge_id"],
        )

        assert isinstance(result, AuthenticationResult)
        assert result.user.pk == user.pk
        assert result.credential.credential_id_b64 == cred.credential_id_b64

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_updates_sign_count(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.return_value = FakeVerifiedAuthentication(new_sign_count=5)
        _, cred = await self._setup()
        svc = PasskeyService(make_config())

        auth_opts = await svc.begin_authentication()
        await svc.complete_authentication(
            credential=_fake_authentication_credential(),
            challenge_id=auth_opts["challenge_id"],
        )

        await cred.refresh_from_db()
        assert cred.sign_count == 5

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_updates_last_used(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.return_value = FakeVerifiedAuthentication()
        _, cred = await self._setup()
        assert cred.last_used_at is None
        svc = PasskeyService(make_config())

        auth_opts = await svc.begin_authentication()
        await svc.complete_authentication(
            credential=_fake_authentication_credential(),
            challenge_id=auth_opts["challenge_id"],
        )

        await cred.refresh_from_db()
        assert cred.last_used_at is not None

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_emits_event(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.return_value = FakeVerifiedAuthentication()
        user, _ = await self._setup()
        svc = PasskeyService(make_config())
        events: list[dict[str, Any]] = []

        @emitter.on("passkey_authenticated")
        async def handler(**kwargs: Any) -> None:
            events.append(kwargs)

        auth_opts = await svc.begin_authentication()
        await svc.complete_authentication(
            credential=_fake_authentication_credential(),
            challenge_id=auth_opts["challenge_id"],
        )

        assert len(events) == 1
        assert events[0]["user"].pk == user.pk

    async def test_complete_expired_challenge(self):
        svc = PasskeyService(make_config())
        with pytest.raises(PasskeyAuthenticationError, match="Challenge expired"):
            await svc.complete_authentication(
                credential=_fake_authentication_credential(),
                challenge_id="nonexistent",
            )

    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_unknown_credential(self, mock_to_json, mock_gen):
        mock_gen.return_value = _fake_authentication_options()
        svc = PasskeyService(make_config())
        auth_opts = await svc.begin_authentication()
        with pytest.raises(PasskeyAuthenticationError, match="Unknown credential"):
            await svc.complete_authentication(
                credential=_fake_authentication_credential(),
                challenge_id=auth_opts["challenge_id"],
            )

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_inactive_user(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.return_value = FakeVerifiedAuthentication()
        user, _ = await self._setup()
        user.is_active = False
        await user.save(update_fields=["is_active"])
        svc = PasskeyService(make_config())

        auth_opts = await svc.begin_authentication()
        with pytest.raises(PasskeyAuthenticationError, match="inactive"):
            await svc.complete_authentication(
                credential=_fake_authentication_credential(),
                challenge_id=auth_opts["challenge_id"],
            )

    @patch("webauthn.verify_authentication_response")
    @patch("webauthn.generate_authentication_options")
    @patch("webauthn.options_to_json", return_value="{}")
    async def test_complete_invalid_response(self, mock_to_json, mock_gen, mock_verify):
        mock_gen.return_value = _fake_authentication_options()
        mock_verify.side_effect = Exception("Bad signature")
        await self._setup()
        svc = PasskeyService(make_config())

        auth_opts = await svc.begin_authentication()
        with pytest.raises(PasskeyAuthenticationError, match="verification failed"):
            await svc.complete_authentication(
                credential=_fake_authentication_credential(),
                challenge_id=auth_opts["challenge_id"],
            )


class TestCredentialManagement:
    async def test_list_credentials(self):
        user = await _create_user()
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )
        svc = PasskeyService(make_config())
        creds = await svc.list_credentials(user)
        assert len(creds) == 1

    async def test_list_credentials_empty(self):
        user = await _create_user()
        svc = PasskeyService(make_config())
        assert await svc.list_credentials(user) == []

    async def test_delete_credential(self):
        user = await _create_user()
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )
        svc = PasskeyService(make_config())
        await svc.delete_credential(user, FAKE_CREDENTIAL_ID_B64)
        assert await PasskeyCredential.filter(user_id=str(user.pk)).count() == 0

    async def test_delete_credential_not_found(self):
        user = await _create_user()
        svc = PasskeyService(make_config())
        with pytest.raises(PasskeyError, match="not found"):
            await svc.delete_credential(user, "nope")

    async def test_delete_credential_wrong_user(self):
        user1 = await _create_user("a@example.com")
        user2 = await _create_user("b@example.com")
        await PasskeyCredential.create(
            user_id=str(user1.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )
        svc = PasskeyService(make_config())
        with pytest.raises(PasskeyError, match="not found"):
            await svc.delete_credential(user2, FAKE_CREDENTIAL_ID_B64)

    async def test_delete_emits_event(self):
        user = await _create_user()
        await PasskeyCredential.create(
            user_id=str(user.pk),
            credential_id=FAKE_CREDENTIAL_ID,
            credential_id_b64=FAKE_CREDENTIAL_ID_B64,
            public_key=FAKE_PUBLIC_KEY,
            sign_count=0,
        )
        svc = PasskeyService(make_config())
        events: list[dict[str, Any]] = []

        @emitter.on("passkey_deleted")
        async def handler(**kwargs: Any) -> None:
            events.append(kwargs)

        await svc.delete_credential(user, FAKE_CREDENTIAL_ID_B64)
        assert events == [{"user": user, "credential_id": FAKE_CREDENTIAL_ID_B64}]


class TestServiceConfig:
    def test_default_challenge_backend_is_memory(self):
        svc = PasskeyService(make_config())
        assert isinstance(svc.challenge_backend, InMemoryChallengeBackend)

    def test_explicit_challenge_backend(self):
        cfg = make_config()
        cb = InMemoryChallengeBackend(cfg)
        svc = PasskeyService(cfg, challenge_backend=cb)
        assert svc.challenge_backend is cb

    def test_no_user_model_configured(self):
        svc = PasskeyService(PasskeyConfig(rp_id="example.com"))
        with pytest.raises(PasskeyError, match="user_model not configured"):
            svc._resolve_user_model()

    async def test_begin_authentication_no_rp_id(self):
        svc = PasskeyService(make_config(rp_id=""))
        with pytest.raises(PasskeyAuthenticationError, match="rp_id"):
            await svc.begin_authentication()
