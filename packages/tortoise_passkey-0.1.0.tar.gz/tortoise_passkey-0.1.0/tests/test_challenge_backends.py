"""Tests for WebAuthn challenge storage backends."""

from __future__ import annotations

import asyncio
import time

from tortoise_passkey.challenge import ChallengeData
from tortoise_passkey.challenge_database import DatabaseChallengeBackend
from tortoise_passkey.challenge_memory import InMemoryChallengeBackend
from tortoise_passkey.config import PasskeyConfig


def make_config(**overrides: object) -> PasskeyConfig:
    defaults: dict[str, object] = {"challenge_ttl": 300}
    defaults.update(overrides)
    return PasskeyConfig(**defaults)  # type: ignore[arg-type]


def make_challenge_data(
    challenge: bytes = b"test-challenge-bytes",
    user_id: str | None = "user-123",
) -> ChallengeData:
    return ChallengeData(
        challenge=challenge,
        user_id=user_id,
        created_at=time.monotonic(),
    )


class TestInMemoryChallengeBackend:
    async def test_store_and_retrieve(self):
        backend = InMemoryChallengeBackend(make_config())
        await backend.store("chal-1", make_challenge_data())
        retrieved = await backend.retrieve("chal-1")
        assert retrieved is not None
        assert retrieved.challenge == b"test-challenge-bytes"
        assert retrieved.user_id == "user-123"

    async def test_retrieve_not_found(self):
        backend = InMemoryChallengeBackend(make_config())
        assert await backend.retrieve("nope") is None

    async def test_retrieve_expired_returns_none(self):
        backend = InMemoryChallengeBackend(make_config(challenge_ttl=1))
        data = ChallengeData(
            challenge=b"expired",
            user_id="u1",
            created_at=time.monotonic() - 2,
        )
        await backend.store("chal-expired", data)
        assert await backend.retrieve("chal-expired") is None

    async def test_delete(self):
        backend = InMemoryChallengeBackend(make_config())
        await backend.store("chal-del", make_challenge_data())
        await backend.delete("chal-del")
        assert await backend.retrieve("chal-del") is None

    async def test_delete_nonexistent_is_noop(self):
        backend = InMemoryChallengeBackend(make_config())
        await backend.delete("nope")  # must not raise

    async def test_cleanup_expired(self):
        backend = InMemoryChallengeBackend(make_config(challenge_ttl=1))
        await backend.store(
            "expired",
            ChallengeData(challenge=b"old", user_id="u", created_at=time.monotonic() - 2),
        )
        await backend.store("fresh", make_challenge_data())
        removed = await backend.cleanup_expired()
        assert removed == 1
        assert await backend.retrieve("expired") is None
        assert await backend.retrieve("fresh") is not None

    async def test_store_with_none_user_id(self):
        backend = InMemoryChallengeBackend(make_config())
        await backend.store("anon", make_challenge_data(user_id=None))
        retrieved = await backend.retrieve("anon")
        assert retrieved is not None
        assert retrieved.user_id is None


class TestDatabaseChallengeBackend:
    async def test_store_and_retrieve(self):
        backend = DatabaseChallengeBackend(make_config())
        await backend.store("chal-1", make_challenge_data())
        retrieved = await backend.retrieve("chal-1")
        assert retrieved is not None
        assert retrieved.challenge == b"test-challenge-bytes"
        assert retrieved.user_id == "user-123"

    async def test_retrieve_not_found(self):
        backend = DatabaseChallengeBackend(make_config())
        assert await backend.retrieve("nope") is None

    async def test_retrieve_expired_returns_none(self):
        backend = DatabaseChallengeBackend(make_config(challenge_ttl=0))
        await backend.store("chal-expired", make_challenge_data())
        await asyncio.sleep(0.01)
        assert await backend.retrieve("chal-expired") is None

    async def test_delete(self):
        backend = DatabaseChallengeBackend(make_config())
        await backend.store("chal-del", make_challenge_data())
        await backend.delete("chal-del")
        assert await backend.retrieve("chal-del") is None

    async def test_delete_nonexistent_is_noop(self):
        backend = DatabaseChallengeBackend(make_config())
        await backend.delete("nope")

    async def test_cleanup_expired(self):
        backend = DatabaseChallengeBackend(make_config(challenge_ttl=0))
        await backend.store("old", make_challenge_data())
        await asyncio.sleep(0.01)
        assert await backend.cleanup_expired() >= 1

    async def test_store_with_none_user_id(self):
        backend = DatabaseChallengeBackend(make_config())
        await backend.store("anon", make_challenge_data(user_id=None))
        retrieved = await backend.retrieve("anon")
        assert retrieved is not None
        assert retrieved.user_id is None
