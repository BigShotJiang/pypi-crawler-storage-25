# Quickstart

This page walks you through the smallest possible end-to-end integration:
configure the library, register a passkey for a user, and authenticate with
it.

## 1. Configure the library

Call `configure()` once at application startup. The RP ID and origin must match
the domain your users connect from — WebAuthn refuses credentials otherwise.

```python
from tortoise_passkey import PasskeyConfig, configure

configure(
    PasskeyConfig(
        user_model="models.User",       # "app_label.ModelName" from Tortoise
        rp_id="example.com",            # your site's domain (no scheme, no port)
        rp_name="Example App",          # human-readable name shown in prompts
        origin="https://example.com",   # full origin — the browser sends this
    )
)
```

See [Configuration](configuration.md) for every option and the validation
rules.

## 2. Initialize Tortoise

Include `tortoise_passkey.models` so the credential tables exist:

```python
from tortoise import Tortoise

await Tortoise.init(
    db_url="sqlite://db.sqlite3",
    modules={"models": ["app.models", "tortoise_passkey.models"]},
)
await Tortoise.generate_schemas()
```

## 3. Register a passkey

Registration is a two-step ceremony. The server generates options and a
challenge, the browser talks to the authenticator, and the browser posts the
credential back.

```python
from tortoise_passkey import PasskeyService

service = PasskeyService()

# --- Step A: begin registration (server → browser) ---
user = await User.get(email="alice@example.com")
begin = await service.begin_registration(user)
# send begin["options"] (JSON string) to the browser, keep begin["challenge_id"]

# --- Step B: complete registration (browser → server) ---
# The browser posts the credential returned by navigator.credentials.create()
passkey = await service.complete_registration(
    user,
    credential=request_body["credential"],       # dict or JSON string
    challenge_id=request_body["challenge_id"],
    name="Alice's laptop",                        # optional label
)
```

On the browser side, call `navigator.credentials.create({ publicKey: options })`
with the parsed `options` object, then `POST` the resulting credential back.

## 4. Authenticate with a passkey

```python
# --- Step A: begin authentication ---
# Pass `user=None` to allow a discoverable passkey (the browser picks the
# credential and the user). Pass a user to scope to that user's credentials.
begin = await service.begin_authentication(user=None)

# --- Step B: complete authentication ---
result = await service.complete_authentication(
    credential=request_body["credential"],
    challenge_id=request_body["challenge_id"],
)

# result.user is the resolved user, result.credential is the PasskeyCredential
# used. You issue your own session cookie / JWT from here.
```

## 5. Manage credentials

```python
creds = await service.list_credentials(user)
await service.delete_credential(user, credential_id_b64="abc...")
```

## What next?

- If you are on Starlette, skip the hand-wiring and use the
  [route factory](../guide/starlette.md).
- For multi-instance deployments, switch to the
  [database challenge backend](../guide/challenge-backends.md#database-backend).
- Subscribe to [events](../guide/events.md) to audit or react to the ceremony.