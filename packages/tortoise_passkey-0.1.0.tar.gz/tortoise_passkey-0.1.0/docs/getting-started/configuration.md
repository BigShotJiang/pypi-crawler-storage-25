# Configuration

All configuration lives on a single dataclass, `PasskeyConfig`. You can set it
globally with `configure()` or pass an instance to `PasskeyService(config=...)`
per service.

## The full config

```python
from tortoise_passkey import PasskeyConfig, configure

configure(
    PasskeyConfig(
        user_model="models.User",
        rp_id="example.com",
        rp_name="Example App",
        origin="https://example.com",
        challenge_ttl=300,
        user_verification="preferred",
        attestation="none",
        authenticator_attachment="",
    )
)
```

## Options

| Field                      | Type               | Default       | Meaning                                                                                          |
|----------------------------|--------------------|---------------|--------------------------------------------------------------------------------------------------|
| `user_model`               | `str`              | `""`          | Fully-qualified Tortoise model path (`"app_label.ModelName"`). **Required** for authentication.  |
| `rp_id`                    | `str`              | `""`          | Relying Party ID — the registrable domain (no scheme, no port). **Required** for ceremonies.     |
| `rp_name`                  | `str`              | `""`          | Human-readable RP name shown in the authenticator UI. **Required** for registration.             |
| `origin`                   | `str \| list[str]` | `""`          | Full origin(s) the browser will report. **Required** for ceremonies.                             |
| `challenge_ttl`            | `int` (seconds)    | `300`         | How long a challenge stays valid.                                                                |
| `user_verification`        | `"required" \| "preferred" \| "discouraged"` | `"preferred"` | How strict the authenticator must be about verifying the user (PIN, biometrics).                 |
| `attestation`              | `"none" \| "indirect" \| "direct" \| "enterprise"` | `"none"`       | Attestation conveyance preference. Leave at `"none"` unless you have a specific compliance need. |
| `authenticator_attachment` | `"" \| "platform" \| "cross-platform"` | `""`          | Restrict to platform authenticators (Touch ID, Windows Hello) or roaming keys, or allow both (`""`). |

## RP ID, origin, and scope

The RP ID and origin are the two anchors of WebAuthn security. They must match
what the browser sees:

- **`rp_id`** is a registrable suffix of the site's hostname.
  `example.com` is valid for `https://example.com` and `https://app.example.com`,
  but not for `https://other.com`.
- **`origin`** is the full origin string the browser sends. Pass a list when
  you run the same app on multiple hostnames (e.g. `app.example.com` and
  `admin.example.com`).

!!! warning "Local development"
    For localhost, use `rp_id="localhost"` and `origin="http://localhost:8000"`
    (adjust the port). WebAuthn allows non-HTTPS only for `localhost`.

## User verification

| Value          | When to use                                                           |
|----------------|-----------------------------------------------------------------------|
| `required`     | Step-up auth, sensitive operations. Forces PIN/biometric.             |
| `preferred`    | Default. Asks for UV when possible but accepts credentials without.   |
| `discouraged`  | Rare. When you only want presence, not identity, e.g. 2FA.            |

## Per-service overrides

You can also scope the config to a single service instance — useful when the
same app serves multiple RPs or subdomains:

```python
from tortoise_passkey import PasskeyConfig, PasskeyService

admin_service = PasskeyService(
    PasskeyConfig(
        user_model="models.User",
        rp_id="admin.example.com",
        rp_name="Example Admin",
        origin="https://admin.example.com",
    )
)
```

## Validation

Call `config.validate()` to fail fast on misconfiguration:

```python
config = PasskeyConfig(user_verification="maybe")  # invalid
config.validate()
# raises ConfigurationError("user_verification must be 'required', 'preferred', or 'discouraged'")
```

The library does **not** validate `user_verification`, `attestation`, or
`authenticator_attachment` automatically when you call `configure()` — call
`validate()` yourself during startup if you want a hard failure.