# Installation

`tortoise-passkey` requires **Python 3.13+** and **Tortoise ORM 0.21+**.

## Base install

```bash
pip install tortoise-passkey
```

This pulls in `tortoise-orm` and `webauthn` — everything you need to run
registration and authentication ceremonies programmatically.

## Optional extras

=== "Starlette"

    Install the Starlette route factory extras for the HTTP integration:

    ```bash
    pip install "tortoise-passkey[starlette]"
    ```

=== "Development"

    For contributing or running the test suite:

    ```bash
    pip install "tortoise-passkey[dev]"
    ```

=== "Docs"

    To build this documentation site locally:

    ```bash
    pip install "tortoise-passkey[docs]"
    mkdocs serve
    ```

## Registering the models with Tortoise

Add `tortoise_passkey.models` to the `modules` list when you initialize
Tortoise so the `PasskeyCredential` and `WebAuthnChallenge` tables get created:

```python
from tortoise import Tortoise

await Tortoise.init(
    db_url="sqlite://db.sqlite3",
    modules={
        "models": ["app.models", "tortoise_passkey.models"],
    },
)
await Tortoise.generate_schemas()
```

!!! note "Schema management"
    `generate_schemas()` is fine for development, but use your usual migration
    tool (for example [aerich](https://github.com/tortoise/aerich)) in
    production so the credential tables are versioned like the rest of your
    schema.

## What gets created

Two tables are added:

| Table                               | Stores                                        |
|-------------------------------------|-----------------------------------------------|
| `tortoise_passkey_credentials`      | Registered WebAuthn credentials per user.     |
| `tortoise_passkey_webauthn_challenges` | Short-lived challenges (only used by the database challenge backend). |

The `WebAuthnChallenge` table is only exercised when you opt into the
[database challenge backend](../guide/challenge-backends.md#database-backend);
the default in-memory backend keeps challenges in process memory.