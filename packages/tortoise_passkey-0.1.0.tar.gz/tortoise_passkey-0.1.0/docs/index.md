# tortoise-passkey

**WebAuthn / passkey support for [Tortoise ORM](https://tortoise.github.io/).**

`tortoise-passkey` provides a high-level `PasskeyService` that wraps the
[`webauthn`](https://github.com/duo-labs/py_webauthn) library and persists
credentials through Tortoise ORM models. It ships with a pluggable challenge
storage layer, a lightweight async event emitter, and a ready-made Starlette
route factory so you can add passkey sign-in to an existing app in a few lines
of code.

## Features

- :material-key-variant: **Registration and authentication ceremonies** for
  WebAuthn level 2 credentials, including discoverable (passkey-first) flows.
- :material-database: **Tortoise ORM models** for credentials and challenges,
  ready to include in `Tortoise.init()`.
- :material-swap-horizontal: **Pluggable challenge backends** — an in-memory
  backend for single-instance apps, a database-backed backend for distributed
  deployments, or your own.
- :material-broadcast: **Async event emitter** that fires on registration,
  authentication, deletion, and failure — plug in audit logs, metrics, or
  notifications without touching the service layer.
- :material-rocket-launch: **Starlette integration** exposing six HTTP routes
  that cover the full ceremony, while staying token-agnostic.
- :material-check-all: **Typed, async-first, framework-thin** — `py.typed`
  shipped, no middleware magic, no global session assumptions.

## How it fits together

```mermaid
flowchart LR
    Browser -- "begin" --> Service
    Service -- "store challenge" --> Backend[(Challenge backend)]
    Service -- "options" --> Browser
    Browser -- "credential + challenge_id" --> Service
    Service -- "verify" --> WebAuthn["py_webauthn"]
    Service -- "persist" --> DB[("PasskeyCredential (Tortoise)")]
    Service -- "emit" --> Events[(Event emitter)]
```

The `PasskeyService` orchestrates the ceremony; the challenge backend keeps the
short-lived server challenge; Tortoise ORM stores the long-lived credential;
and the event emitter lets you react to lifecycle events.

## Where to go next

<div class="grid cards" markdown>

-   :material-download: **[Installation](getting-started/installation.md)**

    Install the package and optional integrations.

-   :material-lightning-bolt: **[Quickstart](getting-started/quickstart.md)**

    Register and authenticate your first passkey in a few minutes.

-   :material-cog: **[Configuration](getting-started/configuration.md)**

    RP ID, origin, user verification, attestation.

-   :material-book-open-variant: **[Guide](guide/registration.md)**

    The ceremonies, backends, events, and the Starlette integration.

-   :material-api: **[API reference](reference/service.md)**

    Auto-generated from the source docstrings.

</div>