# Challenge backends

A WebAuthn challenge is a short-lived, single-use nonce the server generates
at the start of a ceremony and verifies at the end. The library stores it
through a pluggable `ChallengeBackend` so you can match the storage to your
deployment topology.

## The protocol

Any object that implements this `Protocol` can be used:

```python
from typing import Protocol
from tortoise_passkey import ChallengeData

class ChallengeBackend(Protocol):
    async def store(self, challenge_id: str, data: ChallengeData) -> None: ...
    async def retrieve(self, challenge_id: str) -> ChallengeData | None: ...
    async def delete(self, challenge_id: str) -> None: ...
    async def cleanup_expired(self) -> int: ...
```

`ChallengeData` is a frozen dataclass with the raw `challenge` bytes, the
associated `user_id` (or `None` for discoverable flows), and `created_at`
(monotonic seconds).

## In-memory backend

The default. Challenges are kept in a process-local dictionary, expired
automatically on read (or via `cleanup_expired()`).

```python
from tortoise_passkey import InMemoryChallengeBackend, PasskeyService

service = PasskeyService(challenge_backend=InMemoryChallengeBackend())
```

**Use it when:**

- You run a single application process.
- You are happy to lose in-flight challenges on restart (users just retry).
- You do not need to share challenges across instances.

**Avoid it when:**

- You are behind a load balancer without sticky sessions — the `begin` and
  `complete` requests may hit different processes.

## Database backend

Persists challenges in the `tortoise_passkey_webauthn_challenges` table. Any
application instance can complete a ceremony started by any other.

```python
from tortoise_passkey import DatabaseChallengeBackend, PasskeyService

service = PasskeyService(challenge_backend=DatabaseChallengeBackend())
```

**Use it when:**

- You run multiple instances of your app behind a load balancer.
- You want challenges to survive restarts.
- You do not want to introduce a Redis dependency just for this.

**Housekeeping:** expired rows are deleted on read, but you should schedule a
periodic cleanup job (e.g. hourly) to sweep challenges that were never
completed:

```python
# In a background task / scheduled job
from tortoise_passkey import DatabaseChallengeBackend

removed = await DatabaseChallengeBackend().cleanup_expired()
logger.info("purged %d expired passkey challenges", removed)
```

## Writing your own backend

Implement the four async methods. A Redis-backed example — note the use of
base64-encoded JSON rather than pickle, since the challenge bytes are the
only non-JSON-native field:

```python
import base64
import json
from redis.asyncio import Redis
from tortoise_passkey import ChallengeData, PasskeyConfig, get_config


class RedisChallengeBackend:
    def __init__(self, redis: Redis, config: PasskeyConfig | None = None) -> None:
        self._redis = redis
        self._config = config

    @property
    def config(self) -> PasskeyConfig:
        return self._config or get_config()

    def _key(self, challenge_id: str) -> str:
        return f"passkey:challenge:{challenge_id}"

    async def store(self, challenge_id: str, data: ChallengeData) -> None:
        payload = json.dumps({
            "challenge": base64.b64encode(data.challenge).decode(),
            "user_id": data.user_id,
            "created_at": data.created_at,
        })
        await self._redis.set(
            self._key(challenge_id), payload, ex=self.config.challenge_ttl,
        )

    async def retrieve(self, challenge_id: str) -> ChallengeData | None:
        raw = await self._redis.get(self._key(challenge_id))
        if raw is None:
            return None
        payload = json.loads(raw)
        return ChallengeData(
            challenge=base64.b64decode(payload["challenge"]),
            user_id=payload["user_id"],
            created_at=payload["created_at"],
        )

    async def delete(self, challenge_id: str) -> None:
        await self._redis.delete(self._key(challenge_id))

    async def cleanup_expired(self) -> int:
        return 0  # Redis TTLs handle expiry
```

Plug it in:

```python
service = PasskeyService(challenge_backend=RedisChallengeBackend(redis))
```

## Pick a backend

```mermaid
flowchart TD
    A{Multi-instance?} -- No --> B[InMemoryChallengeBackend]
    A -- Yes --> C{Have Redis?}
    C -- Yes --> D[Write a RedisChallengeBackend]
    C -- No --> E[DatabaseChallengeBackend]
```