# Registration

Registration is the two-step WebAuthn ceremony that enrolls a new passkey for
a user. The user must already exist in your system and be authenticated by
some other means (password, magic link, SSO) before they can register their
first passkey.

## Flow overview

```mermaid
sequenceDiagram
    participant B as Browser
    participant S as PasskeyService
    participant CB as Challenge backend
    participant DB as PasskeyCredential table

    B->>S: POST /register/begin (user from session)
    S->>CB: store(challenge_id, challenge)
    S-->>B: options (JSON) + challenge_id
    Note over B: navigator.credentials.create({publicKey: options})
    B->>S: POST /register/complete {credential, challenge_id}
    S->>CB: retrieve + delete(challenge_id)
    S->>S: webauthn.verify_registration_response(...)
    S->>DB: create PasskeyCredential
    S-->>B: passkey record (id, name, created_at)
```

## begin_registration

```python
begin = await service.begin_registration(user)
# {
#   "options": "<JSON string: PublicKeyCredentialCreationOptions>",
#   "challenge_id": "<opaque token>",
# }
```

The service:

1. Loads the user's existing credentials and adds them to `excludeCredentials`,
   so the authenticator refuses to create a duplicate on the same device.
2. Builds `AuthenticatorSelectionCriteria` from
   [user verification](../getting-started/configuration.md#user-verification)
   and `authenticator_attachment` settings.
3. Resident key is always **required** — this library is built for
   passkeys, not server-side credentials.
4. Stores a fresh challenge in the
   [challenge backend](challenge-backends.md) with a 5-minute default TTL.

### The user object

`begin_registration` reads the following attributes on the user:

- `user.pk` — primary key, stringified and used as the WebAuthn `userHandle`.
- `user.email` — used as `user_name` (what the credential is filed under in
  password managers). Falls back to `str(user.pk)` if missing.
- `user.display_name` — used as `user_display_name`. Falls back to `user_name`.

No other attributes are required. Any user model works as long as it has
these.

## complete_registration

```python
passkey = await service.complete_registration(
    user,
    credential=body["credential"],      # dict or JSON string
    challenge_id=body["challenge_id"],
    name="Work laptop",                 # optional, free-form label
)
```

The service:

1. Pops the challenge from the backend (one-shot — you cannot replay it).
2. Verifies the challenge belongs to the same user that started the ceremony.
3. Calls `webauthn.verify_registration_response(...)` — any failure raises
   `PasskeyRegistrationError`.
4. Persists the credential: `credential_id`, `credential_id_b64`, `public_key`,
   `sign_count`, `aaguid`, device type, backup state, and any transports the
   browser reported.
5. Emits a `passkey_registered` [event](events.md).

On failure, a `passkey_registration_failed` event is emitted with a `reason`
so you can log or alert.

## Errors you may see

| Exception                   | When                                                       |
|-----------------------------|------------------------------------------------------------|
| `PasskeyRegistrationError`  | Missing RP ID / origin, challenge expired, wrong user, or `webauthn` rejected the response. |
| `PasskeyError`              | `webauthn` package is not installed.                       |

## Browser side (sketch)

```javascript
const begin = await fetch("/passkey/register/begin", {method: "POST"}).then(r => r.json());

const cred = await navigator.credentials.create({
  publicKey: {
    ...begin.options,
    challenge: base64urlToBuffer(begin.options.challenge),
    user: {...begin.options.user, id: base64urlToBuffer(begin.options.user.id)},
    excludeCredentials: (begin.options.excludeCredentials || []).map(c => ({
      ...c, id: base64urlToBuffer(c.id),
    })),
  },
});

await fetch("/passkey/register/complete", {
  method: "POST",
  headers: {"Content-Type": "application/json"},
  body: JSON.stringify({
    challenge_id: begin.challenge_id,
    credential: serializeCredential(cred),  // your b64url serializer
    name: "My key",
  }),
});
```

The ArrayBuffer ↔ base64url conversions are standard WebAuthn boilerplate —
most teams use [`@simplewebauthn/browser`](https://simplewebauthn.dev/) on the
client side for this.