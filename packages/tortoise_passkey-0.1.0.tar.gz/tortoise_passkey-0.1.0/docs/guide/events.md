# Events

The library exposes a small async event emitter — similar in spirit to Node's
`EventEmitter` — so you can react to the passkey lifecycle without wrapping or
subclassing the service.

## Quick example

```python
from tortoise_passkey import on

@on("passkey_registered")
async def log_registration(user, credential):
    logger.info("user %s registered passkey %s", user.pk, credential.credential_id_b64)

@on("passkey_authenticated")
async def mark_login(user, credential):
    await AuditLog.create(user=user, event="passkey_login")
```

Handlers are **async**. They are invoked sequentially, in registration order,
by the emitter.

## Emitted events

| Event                             | Kwargs                                  | When                                                       |
|-----------------------------------|-----------------------------------------|------------------------------------------------------------|
| `passkey_registered`              | `user`, `credential`                    | After `complete_registration` succeeds.                    |
| `passkey_registration_failed`     | `user`, `reason`                        | `complete_registration` raised — reason is a string hint.  |
| `passkey_authenticated`           | `user`, `credential`                    | After `complete_authentication` succeeds.                  |
| `passkey_authentication_failed`   | `credential_id`, `reason`               | `complete_authentication` raised; `credential_id` may be `None`. |
| `passkey_deleted`                 | `user`, `credential_id`                 | After `delete_credential` succeeds.                        |

`credential` is the full `PasskeyCredential` model instance; `credential_id`
on failures and deletions is the base64url-encoded credential ID (a string).

## Registering handlers

Three equivalent ways:

=== "Decorator"

    ```python
    from tortoise_passkey import on

    @on("passkey_authenticated")
    async def handler(user, credential):
        ...
    ```

=== "Explicit `add_listener`"

    ```python
    from tortoise_passkey import add_listener

    async def handler(user, credential):
        ...

    add_listener("passkey_authenticated", handler)
    ```

=== "Directly on the emitter"

    ```python
    from tortoise_passkey import emitter

    @emitter.on("passkey_authenticated")
    async def handler(user, credential):
        ...
    ```

Use `remove_listener(event_name, handler)` to detach a specific handler, or
`emitter.clear(event_name)` to drop them all (useful in tests).

## Error handling

By default the emitter **swallows** exceptions from handlers and logs them —
a failing audit log handler should not block an otherwise-successful
authentication.

If you want strict behavior (one bad handler = the whole ceremony fails),
create your own emitter with `propagate_errors=True`:

```python
from tortoise_passkey import EventEmitter

strict = EventEmitter(propagate_errors=True)

@strict.on("passkey_registered")
async def handler(user, credential):
    raise RuntimeError("boom")
```

Be aware: the global `emitter` object used by `PasskeyService` is the lenient
one. Rebind the global `emit` only if you know what you are doing.

## Common patterns

### Metrics

```python
from tortoise_passkey import on

@on("passkey_authenticated")
async def count_success(user, credential):
    metrics.counter("passkey.authenticated").inc()

@on("passkey_authentication_failed")
async def count_failure(credential_id, reason):
    metrics.counter("passkey.failed", tags={"reason": reason}).inc()
```

### Rate-limited alerting

```python
@on("passkey_authentication_failed")
async def alert(credential_id, reason):
    if reason == "sign_count_mismatch":  # possible clone
        await alert_service.page(f"Possible cloned authenticator: {credential_id}")
```

### Post-registration welcome

```python
@on("passkey_registered")
async def welcome(user, credential):
    await email.send(
        to=user.email,
        subject="New passkey added",
        body=f"A new passkey ('{credential.name}') was added to your account.",
    )
```