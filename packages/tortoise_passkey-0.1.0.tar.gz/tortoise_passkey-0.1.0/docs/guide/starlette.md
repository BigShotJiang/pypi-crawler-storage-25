# Starlette integration

`tortoise_passkey.integrations.starlette.passkey_routes` is a small factory
that returns six ready-to-mount `Route` objects covering the full ceremony.
It stays deliberately token-agnostic: you plug in two callbacks describing
how your app resolves the current user and how a successful authentication
becomes a response.

## Install

```bash
pip install "tortoise-passkey[starlette]"
```

## Minimal example

```python
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from tortoise_passkey import PasskeyConfig, PasskeyService, configure
from tortoise_passkey.integrations.starlette import passkey_routes


configure(PasskeyConfig(
    user_model="models.User",
    rp_id="example.com",
    rp_name="Example App",
    origin="https://example.com",
))

service = PasskeyService()


async def get_user(request):
    """Resolve the current user from your own session/JWT/cookie."""
    token = request.cookies.get("session")
    return await resolve_user_from_token(token) if token else None


async def on_authenticated(request, result):
    """Issue your own session token after a successful authentication."""
    token = issue_session(result.user)
    response = JSONResponse({
        "user_id": str(result.user.pk),
        "credential_id": result.credential.credential_id_b64,
    })
    response.set_cookie("session", token, httponly=True, secure=True, samesite="lax")
    return response


app = Starlette(routes=passkey_routes(
    service,
    get_user=get_user,
    on_authenticated=on_authenticated,
))
```

## Routes

With the default `prefix="/passkey"`:

| Method   | Path                                  | Auth required?    | Body / path params              | Response                                  |
|----------|---------------------------------------|-------------------|---------------------------------|-------------------------------------------|
| `POST`   | `/passkey/register/begin`             | Yes (`get_user`)  | —                               | `{options, challenge_id}`                 |
| `POST`   | `/passkey/register/complete`          | Yes               | `{credential, challenge_id, name?}` | `201` `{id, name, created_at}`            |
| `POST`   | `/passkey/authenticate/begin`         | Optional          | —                               | `{options, challenge_id}`                 |
| `POST`   | `/passkey/authenticate/complete`      | No                | `{credential, challenge_id}`    | whatever `on_authenticated` returns       |
| `GET`    | `/passkey/credentials`                | Yes               | —                               | `[{id, name, created_at, last_used_at}]`  |
| `DELETE` | `/passkey/credentials/{credential_id}` | Yes              | `credential_id` in path         | `204`                                     |

Change the prefix with `passkey_routes(..., prefix="/api/passkey")`.

## The callbacks

### `get_user(request) -> user | None`

Async. Must return `None` for unauthenticated requests (the routes will
respond with `401`). Called on every route — including
`authenticate/begin`, where returning `None` is fine and signals a
discoverable (passkey-first) flow.

### `on_authenticated(request, result) -> Response`

Async. Called only after `authenticate/complete` succeeds. Receives the
Starlette `Request` and an `AuthenticationResult`. Issue a session cookie,
return a JWT, redirect to a landing page — whatever fits your app.

Errors raised inside `on_authenticated` propagate normally; the library does
not swallow them.

## Error responses

The routes translate library exceptions to HTTP:

| Condition                                | Status | Body                   |
|------------------------------------------|--------|------------------------|
| `get_user` returned `None` (protected route) | `401`  | `{"detail": "Authentication required"}` |
| Missing `credential` or `challenge_id`   | `400`  | `{"detail": "credential and challenge_id are required"}` |
| `PasskeyRegistrationError`               | `400`  | `{"detail": "<message>"}` |
| `PasskeyAuthenticationError`             | `401`  | `{"detail": "<message>"}` |
| `PasskeyError` on delete (not found)     | `404`  | `{"detail": "<message>"}` |

## Mounting alongside your own routes

`passkey_routes` returns a plain `list[Route]`. Combine it with your own:

```python
from starlette.routing import Mount, Route

app = Starlette(routes=[
    Route("/", homepage),
    *passkey_routes(service, get_user=get_user, on_authenticated=on_authenticated),
    Mount("/api", routes=api_routes),
])
```