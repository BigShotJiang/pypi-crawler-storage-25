# Authentication

Authentication verifies that the user possesses the private key bound to a
credential that has already been registered. The library supports both
**user-scoped** authentication (the app already knows who is signing in) and
**discoverable** authentication (the browser picks a passkey, the server finds
the user from it).

## Flow overview

```mermaid
sequenceDiagram
    participant B as Browser
    participant S as PasskeyService
    participant CB as Challenge backend
    participant DB as PasskeyCredential table

    B->>S: POST /authenticate/begin (user optional)
    S->>CB: store(challenge_id, challenge)
    S-->>B: options + challenge_id
    Note over B: navigator.credentials.get({publicKey: options})
    B->>S: POST /authenticate/complete {credential, challenge_id}
    S->>CB: retrieve + delete(challenge_id)
    S->>DB: find credential by credential_id_b64
    S->>S: webauthn.verify_authentication_response(...)
    S->>DB: update sign_count + last_used_at
    S-->>B: AuthenticationResult(user, credential)
```

## Discoverable vs user-scoped

```python
# Discoverable (passkey-first) — recommended for login screens
begin = await service.begin_authentication(user=None)

# User-scoped — when you know who is signing in (e.g. step-up auth)
begin = await service.begin_authentication(user=alice)
```

Difference in behavior:

| Mode              | `allowCredentials` in options | Use when |
|-------------------|-------------------------------|----------|
| `user=None`       | Empty (browser picks any discoverable passkey) | Login page; user not yet known. |
| `user=<object>`   | Populated from the user's registered credentials | Step-up auth; forcing a specific account. |

Discoverable flows rely on the fact that the library always registers with
`residentKey=REQUIRED`, so every credential it stores is discoverable.

## begin_authentication

```python
begin = await service.begin_authentication(user=None)
# {"options": "<JSON>", "challenge_id": "..."}
```

## complete_authentication

```python
result = await service.complete_authentication(
    credential=body["credential"],
    challenge_id=body["challenge_id"],
)
# AuthenticationResult(user=<your user>, credential=<PasskeyCredential>)
```

The service:

1. Pops the challenge (one-shot).
2. Looks up the credential by `credential_id_b64`.
3. Verifies the signature and challenge with `webauthn.verify_authentication_response(...)`.
4. Updates `sign_count` and `last_used_at` on the credential row.
5. Resolves the user via the configured `user_model` (Tortoise registry).
6. Refuses inactive users (`user.is_active is False`).
7. Emits `passkey_authenticated` on success, `passkey_authentication_failed`
   on any failure.

## Returning a session

The library is deliberately token-agnostic. `AuthenticationResult` contains
the authenticated user and the credential — you produce the cookie, JWT, or
session record:

```python
result = await service.complete_authentication(
    credential=body["credential"],
    challenge_id=body["challenge_id"],
)

session_token = issue_session(result.user)
response.set_cookie("session", session_token, httponly=True, secure=True)
```

If you use Starlette, the [integration](starlette.md) lets you plug in an
`on_authenticated(request, result)` callback for this exact concern.

## Errors

| Exception                     | When                                                                 |
|-------------------------------|----------------------------------------------------------------------|
| `PasskeyAuthenticationError`  | Missing RP ID / origin, challenge expired, credential unknown, user not found, user inactive, or signature verification failed. |
| `PasskeyError`                | `webauthn` package is not installed.                                 |

## Sign count and cloning detection

`sign_count` is returned by the authenticator and must be strictly increasing
across uses of the same credential. `py_webauthn` flags a decrease as a
possible cloned authenticator. The library re-raises that as
`PasskeyAuthenticationError` — on your side, treat it as a strong signal to
invalidate the credential.

Note that many platform authenticators (iCloud Keychain, Google Password
Manager) always return `sign_count=0`. That is normal, not a clone.