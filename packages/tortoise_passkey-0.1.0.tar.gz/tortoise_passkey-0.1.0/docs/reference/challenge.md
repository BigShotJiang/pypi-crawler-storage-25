# Challenge backends

The challenge storage protocol and its built-in implementations.

## Protocol

::: tortoise_passkey.challenge
    options:
      members:
        - ChallengeBackend
        - ChallengeData
      show_root_heading: false

## In-memory backend

::: tortoise_passkey.challenge_memory
    options:
      members:
        - InMemoryChallengeBackend
      show_root_heading: false

## Database backend

::: tortoise_passkey.challenge_database
    options:
      members:
        - DatabaseChallengeBackend
      show_root_heading: false