# Models

Tortoise ORM models. Register `tortoise_passkey.models` in `Tortoise.init(modules=...)`
so the tables are created.

::: tortoise_passkey.models
    options:
      members:
        - PasskeyCredential
        - WebAuthnChallenge
      show_root_heading: false