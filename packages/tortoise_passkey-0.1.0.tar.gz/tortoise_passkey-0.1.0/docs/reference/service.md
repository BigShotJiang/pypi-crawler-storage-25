# `PasskeyService`

High-level service orchestrating registration and authentication.

::: tortoise_passkey.service
    options:
      members:
        - PasskeyService
        - AuthenticationResult
      show_root_heading: false