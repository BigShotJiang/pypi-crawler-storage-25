# Configuration

::: tortoise_passkey.config
    options:
      members:
        - PasskeyConfig
        - configure
        - get_config
      show_root_heading: false