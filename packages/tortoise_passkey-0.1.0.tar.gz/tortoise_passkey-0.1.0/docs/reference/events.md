# Events

::: tortoise_passkey.events
    options:
      members:
        - EventEmitter
        - emitter
        - on
        - emit
        - add_listener
        - remove_listener
      show_root_heading: false