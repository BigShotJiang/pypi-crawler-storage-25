# Starlette integration

Requires the `starlette` extra:

```bash
pip install "tortoise-passkey[starlette]"
```

::: tortoise_passkey.integrations.starlette
    options:
      members:
        - passkey_routes
      show_root_heading: false