# Exceptions

All exceptions inherit from `TortoisePasskeyError`.

::: tortoise_passkey.exceptions
    options:
      members:
        - TortoisePasskeyError
        - ConfigurationError
        - PasskeyError
        - PasskeyRegistrationError
        - PasskeyAuthenticationError
        - EventError
      show_root_heading: false