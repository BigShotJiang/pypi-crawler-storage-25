"""Starlette integration for tortoise-passkey.

Exposes an HTTP route factory that wires the :class:`PasskeyService` ceremony
(registration begin/complete, authentication begin/complete, credential
listing and deletion) into a Starlette app.

The library is deliberately token-agnostic: the caller plugs in two async
callbacks describing how their app resolves the current user and how a
successful authentication should be turned into a response (e.g. by setting
a session cookie or issuing JWTs).

Usage::

    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from tortoise_passkey import PasskeyService
    from tortoise_passkey.integrations.starlette import passkey_routes

    svc = PasskeyService()

    async def current_user(request):
        # resolve the logged-in user from your session/cookies/JWT
        ...

    async def on_authenticated(request, result):
        # issue your own session/token here
        return JSONResponse({"user_id": str(result.user.pk)})

    routes = passkey_routes(
        svc, get_user=current_user, on_authenticated=on_authenticated
    )
    app = Starlette(routes=routes)
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from tortoise_passkey.exceptions import (
    PasskeyAuthenticationError,
    PasskeyError,
    PasskeyRegistrationError,
)
from tortoise_passkey.service import AuthenticationResult, PasskeyService

if TYPE_CHECKING:
    from starlette.requests import Request


__all__ = ["passkey_routes"]


GetUser = Callable[["Request"], Awaitable[Any | None]]
OnAuthenticated = Callable[["Request", AuthenticationResult], Awaitable[Response]]


def _unauthorized() -> Response:
    return JSONResponse({"detail": "Authentication required"}, status_code=401)


async def _json_body(request: Request) -> dict[str, Any]:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return {}
    return body if isinstance(body, dict) else {}


def passkey_routes(
    service: PasskeyService,
    *,
    get_user: GetUser,
    on_authenticated: OnAuthenticated,
    prefix: str = "/passkey",
) -> list[Route]:
    """Build Starlette routes for the passkey ceremony.

    Args:
        service: Configured :class:`PasskeyService` instance.
        get_user: Async callable ``(request) -> user | None`` that resolves the
            logged-in user. Must return ``None`` when the request is
            unauthenticated. Required for registration and credential
            management; optional for authentication-begin (allows discoverable
            flows when the user is not yet known).
        on_authenticated: Async callable ``(request, AuthenticationResult) ->
            Response`` invoked after a successful authentication. The caller
            is responsible for issuing session cookies or tokens.
        prefix: URL prefix for all routes. Default ``/passkey``.

    Returns:
        A list of :class:`starlette.routing.Route` to mount on a Starlette app.
    """

    async def register_begin(request: Request) -> Response:
        user = await get_user(request)
        if user is None:
            return _unauthorized()
        try:
            result = await service.begin_registration(user)
        except PasskeyRegistrationError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=400)
        return JSONResponse(
            {"options": json.loads(result["options"]), "challenge_id": result["challenge_id"]}
        )

    async def register_complete(request: Request) -> Response:
        user = await get_user(request)
        if user is None:
            return _unauthorized()
        body = await _json_body(request)
        credential = body.get("credential")
        challenge_id = body.get("challenge_id")
        if not credential or not challenge_id:
            return JSONResponse(
                {"detail": "credential and challenge_id are required"}, status_code=400
            )
        name = body.get("name", "") or ""
        try:
            passkey = await service.complete_registration(
                user,
                credential=credential,
                challenge_id=challenge_id,
                name=name,
            )
        except PasskeyRegistrationError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=400)
        return JSONResponse(
            {
                "id": passkey.credential_id_b64,
                "name": passkey.name,
                "created_at": passkey.created_at.isoformat(),
            },
            status_code=201,
        )

    async def authenticate_begin(request: Request) -> Response:
        user = await get_user(request)
        try:
            result = await service.begin_authentication(user=user)
        except PasskeyAuthenticationError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=400)
        return JSONResponse(
            {"options": json.loads(result["options"]), "challenge_id": result["challenge_id"]}
        )

    async def authenticate_complete(request: Request) -> Response:
        body = await _json_body(request)
        credential = body.get("credential")
        challenge_id = body.get("challenge_id")
        if not credential or not challenge_id:
            return JSONResponse(
                {"detail": "credential and challenge_id are required"}, status_code=400
            )
        try:
            result = await service.complete_authentication(
                credential=credential,
                challenge_id=challenge_id,
            )
        except PasskeyAuthenticationError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=401)
        return await on_authenticated(request, result)

    async def list_credentials(request: Request) -> Response:
        user = await get_user(request)
        if user is None:
            return _unauthorized()
        creds = await service.list_credentials(user)
        return JSONResponse(
            [
                {
                    "id": c.credential_id_b64,
                    "name": c.name,
                    "created_at": c.created_at.isoformat(),
                    "last_used_at": c.last_used_at.isoformat() if c.last_used_at else None,
                }
                for c in creds
            ]
        )

    async def delete_credential(request: Request) -> Response:
        user = await get_user(request)
        if user is None:
            return _unauthorized()
        credential_id = request.path_params["credential_id"]
        try:
            await service.delete_credential(user, credential_id)
        except PasskeyError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=404)
        return Response(status_code=204)

    return [
        Route(f"{prefix}/register/begin", register_begin, methods=["POST"]),
        Route(f"{prefix}/register/complete", register_complete, methods=["POST"]),
        Route(f"{prefix}/authenticate/begin", authenticate_begin, methods=["POST"]),
        Route(f"{prefix}/authenticate/complete", authenticate_complete, methods=["POST"]),
        Route(f"{prefix}/credentials", list_credentials, methods=["GET"]),
        Route(
            f"{prefix}/credentials/{{credential_id}}",
            delete_credential,
            methods=["DELETE"],
        ),
    ]
