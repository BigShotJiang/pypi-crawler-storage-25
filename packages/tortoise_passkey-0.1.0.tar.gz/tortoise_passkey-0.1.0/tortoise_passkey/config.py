"""Global configuration for tortoise-passkey."""

from __future__ import annotations

from dataclasses import dataclass

from tortoise_passkey.exceptions import ConfigurationError


@dataclass
class PasskeyConfig:
    """Configuration for tortoise-passkey."""

    user_model: str = ""

    challenge_ttl: int = 300  # 5 minutes
    rp_id: str = ""
    rp_name: str = ""
    origin: str | list[str] = ""
    user_verification: str = "preferred"  # "required", "preferred", "discouraged"
    attestation: str = "none"  # "none", "indirect", "direct", "enterprise"
    authenticator_attachment: str = ""  # "", "platform", "cross-platform"

    def validate(self) -> None:
        """Validate config. Raises ConfigurationError."""
        if self.challenge_ttl <= 0:
            raise ConfigurationError("challenge_ttl must be positive")
        if self.user_verification not in ("required", "preferred", "discouraged"):
            raise ConfigurationError(
                "user_verification must be 'required', 'preferred', or 'discouraged'"
            )
        if self.attestation not in ("none", "indirect", "direct", "enterprise"):
            raise ConfigurationError(
                "attestation must be 'none', 'indirect', 'direct', or 'enterprise'"
            )
        if self.authenticator_attachment not in ("", "platform", "cross-platform"):
            raise ConfigurationError(
                "authenticator_attachment must be '', 'platform', or 'cross-platform'"
            )


_config: PasskeyConfig | None = None


def configure(config: PasskeyConfig) -> None:
    """Set the global passkey configuration."""
    global _config
    _config = config


def get_config() -> PasskeyConfig:
    """Get the global passkey configuration, creating a default if needed."""
    global _config
    if _config is None:
        _config = PasskeyConfig()
    return _config
