"""Exceptions for tortoise-passkey."""

from __future__ import annotations


class TortoisePasskeyError(Exception):
    """Base exception for tortoise-passkey."""


class ConfigurationError(TortoisePasskeyError):
    """Raised when configuration is invalid."""


class PasskeyError(TortoisePasskeyError):
    """Base exception for passkey/WebAuthn errors."""


class PasskeyRegistrationError(PasskeyError):
    """Raised when passkey registration fails."""


class PasskeyAuthenticationError(PasskeyError):
    """Raised when passkey authentication fails."""


class EventError(TortoisePasskeyError):
    """Raised when an event handler fails and errors are propagated."""

    def __init__(self, event_name: str, handler_name: str, original: BaseException) -> None:
        self.event_name = event_name
        self.handler_name = handler_name
        self.original = original
        super().__init__(
            f"event handler {handler_name!r} for {event_name!r} failed: {original!r}"
        )
