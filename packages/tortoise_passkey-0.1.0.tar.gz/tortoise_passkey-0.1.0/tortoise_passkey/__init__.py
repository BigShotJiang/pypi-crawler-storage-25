"""WebAuthn passkey support for Tortoise ORM."""

from tortoise_passkey.challenge import ChallengeBackend, ChallengeData
from tortoise_passkey.challenge_database import DatabaseChallengeBackend
from tortoise_passkey.challenge_memory import InMemoryChallengeBackend
from tortoise_passkey.config import PasskeyConfig, configure, get_config
from tortoise_passkey.events import (
    EventEmitter,
    add_listener,
    emit,
    emitter,
    on,
    remove_listener,
)
from tortoise_passkey.exceptions import (
    ConfigurationError,
    PasskeyAuthenticationError,
    PasskeyError,
    PasskeyRegistrationError,
    TortoisePasskeyError,
)
from tortoise_passkey.models import PasskeyCredential, WebAuthnChallenge
from tortoise_passkey.service import AuthenticationResult, PasskeyService

__all__ = [
    "AuthenticationResult",
    "ChallengeBackend",
    "ChallengeData",
    "ConfigurationError",
    "DatabaseChallengeBackend",
    "EventEmitter",
    "InMemoryChallengeBackend",
    "PasskeyAuthenticationError",
    "PasskeyConfig",
    "PasskeyCredential",
    "PasskeyError",
    "PasskeyRegistrationError",
    "PasskeyService",
    "TortoisePasskeyError",
    "WebAuthnChallenge",
    "add_listener",
    "configure",
    "emit",
    "emitter",
    "get_config",
    "on",
    "remove_listener",
]
