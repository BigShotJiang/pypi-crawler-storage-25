"""Plivo audio-stream transport for livekit-agents — drop-in `liblivekit_ffi`.

Importing this module:
  1. Sets `LIVEKIT_LIB_PATH` to the bundled FFI library so stock
     `livekit-rtc` ctypes-loads our Plivo-backed `liblivekit_ffi.{so,dylib}`.
  2. If no gateway is detected on the configured Worker port, auto-spawns
     the bundled `livekit-gateway` binary as a background subprocess
     and tears it down at Python exit. Disable with `LKG_NO_AUTO_GATEWAY=1`
     (e.g. when running the gateway as a systemd service or container).
  3. Defaults `LIVEKIT_URL=ws://localhost:7880` so stock livekit-agents
     dials our local gateway with no extra config.

Usage:
    import livekit_gateway      # MUST come before any livekit import
    from livekit import rtc, agents   # transparently uses our gateway

Env vars (read here):
    LKG_NO_AUTO_GATEWAY=1         opt out of auto-spawn (default: spawn if needed)
    LKG_GATEWAY_LOG=/path/to/log  where the spawned gateway's stdout/stderr goes
                                  (default: /tmp/lkg_gateway.log on POSIX)
    LIVEKIT_AGENT_WS_ADDR         (default 0.0.0.0:7880) — gateway agent listener
    LIVEKIT_URL                   (auto-set to ws://localhost:7880 if unset)

Env vars consumed by the gateway binary (set them BEFORE import):
    PLIVO_WS_ADDR                 (default 0.0.0.0:8080)
    PLIVO_AUTH_ID
    PLIVO_AUTH_TOKEN
    PLIVO_AUTO_HANGUP             "true"/"false" (default false)
    PLIVO_PUBLIC_HOST             host advertised in Plivo <Stream> XML
    PAIR_TIMEOUT_SECS             (default 30)
    RUST_LOG                      tracing filter for the gateway process
"""
from __future__ import annotations

import atexit
import os
import platform
import socket
import subprocess
import sys
import time
from pathlib import Path

_LIB_DIR = Path(__file__).resolve().parent / "lib"
_BIN_DIR = Path(__file__).resolve().parent / "bin"

_EXT_BY_PLATFORM = {
    "darwin": "dylib",
    "linux": "so",
}

_platform = sys.platform
if _platform not in _EXT_BY_PLATFORM:
    raise ImportError(
        f"livekit_gateway: unsupported platform '{_platform}' "
        f"(supported: {list(_EXT_BY_PLATFORM)})"
    )

_LIB_PATH = _LIB_DIR / f"liblivekit_ffi.{_EXT_BY_PLATFORM[_platform]}"

if not _LIB_PATH.exists():
    raise ImportError(
        f"livekit_gateway: bundled FFI library not found at {_LIB_PATH}. "
        "Did `pip install` skip the build hook? Try reinstalling from sdist or "
        "run `pip install -e ./python` from the source tree."
    )

# 1. Wire stock livekit-rtc to our .so.
os.environ.setdefault("LIVEKIT_LIB_PATH", str(_LIB_PATH))


def _gateway_binary() -> Path:
    name = "livekit-gateway.exe" if platform.system() == "Windows" else "livekit-gateway"
    return _BIN_DIR / name


def _worker_port() -> int:
    # LIVEKIT_AGENT_WS_ADDR can be "host:port" or just ":port"; we parse the port.
    addr = os.environ.get("LIVEKIT_AGENT_WS_ADDR", "0.0.0.0:7880")
    try:
        return int(addr.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return 7880


def _port_listening(port: int, host: str = "127.0.0.1", timeout: float = 0.2) -> bool:
    """Return True if `host:port` accepts a TCP connection."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _livekit_url_is_remote() -> bool:
    """If LIVEKIT_URL points at a non-local host, the user is managing
    the gateway elsewhere — don't auto-spawn."""
    url = os.environ.get("LIVEKIT_URL", "")
    if not url:
        return False
    return not any(
        marker in url for marker in ("localhost", "127.0.0.1", "::1", "0.0.0.0")
    )


def _spawn_gateway() -> subprocess.Popen | None:
    binary = _gateway_binary()
    if not binary.exists():
        print(
            f"livekit_gateway: gateway binary missing at {binary}; "
            "skipping auto-spawn. Run the gateway manually with "
            "`livekit-gateway` or set LKG_NO_AUTO_GATEWAY=1.",
            file=sys.stderr,
        )
        return None

    log_path = Path(os.environ.get("LKG_GATEWAY_LOG", "/tmp/lkg_gateway.log"))
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass

    log_fh = open(log_path, "ab", buffering=0)
    # start_new_session=True detaches from the Python tty session so SIGINT
    # to the agent doesn't immediately kill the gateway — we manage its
    # lifetime explicitly via atexit. stdin closed so it can't block on input.
    proc = subprocess.Popen(
        [str(binary)],
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )

    # Wait up to 5 seconds for the gateway to bind its agent-worker port.
    port = _worker_port()
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        if _port_listening(port):
            break
        time.sleep(0.05)
    else:
        print(
            f"livekit_gateway: gateway did not bind port {port} within 5s; "
            f"check the log at {log_path}",
            file=sys.stderr,
        )

    def _shutdown_gateway(p: subprocess.Popen = proc) -> None:
        if p.poll() is not None:
            return
        try:
            p.terminate()
            try:
                p.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                p.kill()
        except OSError:
            pass

    atexit.register(_shutdown_gateway)
    return proc


_spawned_gateway_proc: subprocess.Popen | None = None


def _is_gateway_shim() -> bool:
    """Skip auto-spawn when *this* process is the gateway shim itself.

    The console_script `livekit-gateway` and `python -m livekit_gateway.gateway`
    both import this module before `gateway.main` runs `os.execv` to replace
    the Python process with the bundled binary. Without this check, the
    auto-spawn below fires a *background* gateway, then `gateway.main` execs
    a *foreground* gateway, and the second one to bind dies with
    `Address already in use` on port 8080 (or 7880).

    The README's Production section documents `livekit-gateway` as the way
    to start the gateway — it must work without `LKG_NO_AUTO_GATEWAY=1`.
    """
    if not sys.argv:
        return False
    arg0 = os.path.basename(sys.argv[0])
    if arg0 in ("livekit-gateway", "livekit-gateway.exe"):
        # console_script entry: sys.argv[0] is the wrapper script's filename.
        return True
    # `python -m livekit_gateway.gateway`: during runpy's package import
    # (i.e. while *this* file runs) sys.argv[0] is still "-m", so we can't
    # use it. sys.orig_argv preserves the pre-processed command line —
    # available since Python 3.10. Older Pythons fall through and the user
    # has to set LKG_NO_AUTO_GATEWAY=1 manually for the -m form.
    orig = getattr(sys, "orig_argv", None) or []
    for i in range(len(orig) - 1):
        if orig[i] == "-m" and orig[i + 1] in (
            "livekit_gateway.gateway",
            "livekit_gateway",
        ):
            return True
    return False


# 2. Auto-spawn the gateway if needed.
if (
    os.environ.get("LKG_NO_AUTO_GATEWAY", "").lower() not in ("1", "true", "yes")
    and not _is_gateway_shim()
):
    if _livekit_url_is_remote():
        # User pointed LIVEKIT_URL at a remote gateway — they own its lifetime.
        pass
    elif _port_listening(_worker_port()):
        # Gateway already running (perhaps started as a service) — reuse it.
        pass
    else:
        _spawned_gateway_proc = _spawn_gateway()

# 3. Default LIVEKIT_URL so stock livekit-agents dials our local gateway.
os.environ.setdefault("LIVEKIT_URL", f"ws://localhost:{_worker_port()}")
# Loopback gateway doesn't verify the JWT; provide harmless defaults so
# livekit-agents doesn't error out on missing API_KEY/SECRET when the user
# never wires those env vars (they're only required for real LiveKit cloud).
os.environ.setdefault("LIVEKIT_API_KEY", "plivo-lk")
os.environ.setdefault("LIVEKIT_API_SECRET", "unused")

__version__ = "0.1.2"
__all__ = ["__version__"]
