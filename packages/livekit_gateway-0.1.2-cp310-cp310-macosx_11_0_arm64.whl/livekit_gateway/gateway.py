"""Shim that execs the bundled `livekit-gateway` binary.

Usage:
    python -m livekit_gateway.gateway      # via `python -m`
    livekit-gateway                            # via console_scripts entry_point

Environment variables read by the binary:
    PLIVO_XML_ADDR           default 0.0.0.0:5000
    PLIVO_WS_ADDR            default 0.0.0.0:8080  (Plivo + FFI WS)
    LIVEKIT_AGENT_WS_ADDR            default 0.0.0.0:7880  (livekit-agents Worker proto)
    PLIVO_PUBLIC_HOST        host:port advertised in <Stream> XML
    PLIVO_AUTH_ID          Plivo Account auth-id (REST hangup)
    PLIVO_AUTH_TOKEN       Plivo Account auth-token
    PLIVO_AUTO_HANGUP            "true"/"false", default false
    PAIR_TIMEOUT_SECS    default 30
    RUST_LOG                              tracing-subscriber filter
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path


def _bin_path() -> Path:
    name = "livekit-gateway.exe" if platform.system() == "Windows" else "livekit-gateway"
    return Path(__file__).resolve().parent / "bin" / name


def main() -> int:
    binary = _bin_path()
    if not binary.exists():
        print(
            f"livekit_gateway: gateway binary missing at {binary}\n"
            "the wheel may have been built for a different platform, "
            "or the install was interrupted.",
            file=sys.stderr,
        )
        return 1
    # Replace the Python process with the gateway binary so signals + stdio
    # flow through naturally. The forwarded argv[1:] lets callers add flags
    # if the binary grows any (none today; configuration is env-var only).
    os.execv(str(binary), [str(binary)] + sys.argv[1:])
    return 0  # unreachable


if __name__ == "__main__":
    sys.exit(main())
