#!/usr/bin/env python3
"""
ERPBlox AI MCP — stdio proxy for connecting AI clients to Odoo.

Translates stdio JSON-RPC (MCP protocol) to HTTP calls against
the ERPBlox AI Studio MCP endpoint in Odoo.

Environment variables:
    ODOO_URL    - Odoo base URL (default: http://localhost:8069)
    MCP_API_KEY - MCP API key (required, generate in Odoo Settings > AI Studio > MCP API Keys)

Usage with Claude Desktop / Claude Code:
    Add to config (claude_desktop_config.json or .mcp.json):
    {
      "mcpServers": {
        "odoo": {
          "command": "uvx",
          "args": ["erpblox-ai-mcp"],
          "env": {
            "ODOO_URL": "http://localhost:8069",
            "MCP_API_KEY": "mcp-xxxx..."
          }
        }
      }
    }
"""
import json
import os
import sys
import urllib.request
import urllib.error


ODOO_URL = os.environ.get('ODOO_URL', 'http://localhost:8069')
MCP_API_KEY = os.environ.get('MCP_API_KEY', '')
MCP_ENDPOINT = ODOO_URL.rstrip('/') + '/mcp/v1'


def send_to_odoo(message):
    """Send MCP message to Odoo and return response."""
    data = json.dumps(message).encode('utf-8')
    req = urllib.request.Request(
        MCP_ENDPOINT,
        data=data,
        headers={
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % MCP_API_KEY,
        },
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = resp.read().decode('utf-8')
            if body:
                return json.loads(body)
            return None
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        return {
            "jsonrpc": "2.0",
            "id": message.get('id'),
            "error": {"code": -32000, "message": "HTTP %d: %s" % (e.code, body[:200])},
        }
    except Exception as e:
        return {
            "jsonrpc": "2.0",
            "id": message.get('id'),
            "error": {"code": -32000, "message": str(e)},
        }


def main():
    if not MCP_API_KEY:
        sys.stderr.write("Error: MCP_API_KEY environment variable is required\n")
        sys.stderr.write("Generate a key in Odoo: Settings > AI Studio > MCP API Keys\n")
        sys.exit(1)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue

        response = send_to_odoo(message)
        if response:
            sys.stdout.write(json.dumps(response) + '\n')
            sys.stdout.flush()


if __name__ == '__main__':
    main()
