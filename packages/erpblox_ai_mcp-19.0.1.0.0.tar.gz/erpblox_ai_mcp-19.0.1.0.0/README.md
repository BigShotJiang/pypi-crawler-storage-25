# ERPBlox AI MCP

MCP (Model Context Protocol) stdio proxy for connecting **Claude Code**, **Claude Desktop**, **Cursor**, and other MCP clients to **Odoo** with [ERPBlox AI Studio](https://erpblox.com).

## Prerequisites

1. Install **ERPBlox AI Studio** module in Odoo 19
2. Enable **MCP Server** in Settings → AI Studio → MCP Server
3. Generate an **MCP API Key** in Settings → AI Studio → MCP API Keys

## Quick Setup

### Claude Desktop / Claude Code

Add to your config file:

- **Claude Desktop**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Claude Code**: `.mcp.json` in project root
- **Cursor**: `.cursor/mcp.json`

```json
{
  "mcpServers": {
    "odoo": {
      "command": "uvx",
      "args": ["erpblox-ai-mcp"],
      "env": {
        "ODOO_URL": "http://localhost:8069",
        "MCP_API_KEY": "mcp-your-key-here"
      }
    }
  }
}
```

### Claude.ai (Web)

No proxy needed — connect directly via Settings → Connectors → Add custom connector:

```
URL: https://your-odoo-domain.com/mcp/v1
```

## Available Tools

| Category | Tools |
|----------|-------|
| **Schema** | list_models, describe_model, model_summary |
| **Query** | read_records, count_records, aggregate_data |
| **AI** | ask_question, find_models, build_domain, generate_chart, generate_kpi, summarize_record, extract_document, translate_text, generate_code |
| **Mutation** | create_record, update_record, delete_record, execute_method |
| **Portal** | save_portal_page, get_portal_page |

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ODOO_URL` | No | `http://localhost:8069` | Odoo server URL |
| `MCP_API_KEY` | Yes | — | MCP API key from Odoo Settings |

## Links

- [ERPBlox](https://erpblox.com)
- [ERPBlox AI Studio on Odoo Apps](https://apps.odoo.com/apps/modules/19.0/erpblox_ai_studio/)
