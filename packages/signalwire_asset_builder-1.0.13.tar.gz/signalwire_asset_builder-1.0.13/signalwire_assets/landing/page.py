"""
Landing page assembler.

``build_page`` takes a page-data dict (title + sections array) and returns a
complete, self-contained HTML string.  ``build_batch`` processes every JSON
file in a directory.

Section-level options:
  - ``"bg": "pattern-name"`` adds a background texture (dots, grid, noise,
    hex, diagonal, orbs, dots-orbs, grid-orbs, logo, nebula). Some section types
    have defaults (hero: dots-orbs, features: dots, comparison: grid,
    steps: hex, cta: logo-slow, anatomy: diagonal).
  - Features sections accept ``"card_bg": "pattern-name"`` for per-card patterns.

Icons: comparison checkmarks/xmarks, callout icons, and pricing checkmarks
use bundled Font Awesome Pro SVGs (currentColor). No emoji.

Social links: Discord, GitHub, LinkedIn appear in navbar and footer.
"""

import json
import os

_ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
import re
from importlib import resources as _pkg_resources

from .css import COMPONENT_CSS
from .renderers import _esc, _render_cta, SECTION_RENDERERS
from .tokens import generate_css, load_tokens


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_COPY_SVG_JS = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'

def _load_social_svg(name):
    """Load a social icon SVG from bundled assets, clean it for inline use."""
    import re as _re
    p = os.path.join(_ASSETS, name)
    if not os.path.exists(p):
        return ""
    with open(p) as f:
        svg = f.read()
    svg = _re.sub(r'<\?xml[^?]*\?>', '', svg)
    svg = _re.sub(r'<!DOCTYPE[^>]*>', '', svg)
    svg = _re.sub(r'<!--.*?-->', '', svg, flags=_re.DOTALL)
    svg = svg.strip()
    # Inject width/height for consistent sizing
    svg = svg.replace('<svg ', '<svg width="20" height="20" ', 1)
    return svg

_SOCIAL_DISCORD = _load_social_svg("discord-icon-svgrepo-com.svg")
_SOCIAL_GITHUB = _load_social_svg("github-repo-git-octocat-svgrepo-com.svg")
_SOCIAL_LINKEDIN = _load_social_svg("linkedin-svgrepo-com.svg")

_SOCIAL_LINKS_HTML = f"""<div class="lp-social">
  <a href="https://discord.gg/aUg4wc7Dkr" target="_blank" rel="noopener" title="Join our Discord">{_SOCIAL_DISCORD}</a>
  <a href="https://github.com/signalwire" target="_blank" rel="noopener" title="GitHub">{_SOCIAL_GITHUB}</a>
  <a href="https://www.linkedin.com/company/signalwire/" target="_blank" rel="noopener" title="LinkedIn">{_SOCIAL_LINKEDIN}</a>
</div>"""

_DEFAULT_CTA_BUTTONS = [
    {"text": "Get Started Free", "url": "https://signalwire.com/signup", "style": "primary"},
    {"text": "Read the Docs", "url": "https://developer.signalwire.com", "style": "secondary"},
]

_DEFAULT_NAV_LINKS = [
    {"text": "Docs", "url": "https://developer.signalwire.com"},
    {"text": "Pricing", "url": "https://signalwire.com/pricing"},
    {"text": "GitHub", "url": "https://github.com/signalwire"},
]

_DEFAULT_FOOTER = {
    "copyright": "SignalWire, Inc.",
    "links": [
        {"text": "Privacy Policy", "url": "https://signalwire.com/legal/privacy-policy"},
        {"text": "Legal", "url": "https://signalwire.com/company/legal"},
        {"text": "Contact", "url": "https://signalwire.com/company/contact"},
    ],
}


# ---------------------------------------------------------------------------
# Bundled SVG loader
# ---------------------------------------------------------------------------

def _load_bundled_svg(name):
    ref = _pkg_resources.files("signalwire_assets").joinpath("assets", name)
    svg = ref.read_text()
    svg = re.sub(r'<\?xml[^?]*\?>\s*', '', svg)
    svg = re.sub(r'<!DOCTYPE[^>]*>\s*', '', svg)
    return svg.strip()


# ---------------------------------------------------------------------------
# Tracking script helpers
# ---------------------------------------------------------------------------

def _tracking_scripts(tracking):
    """Return (gtm_html, fullstory_html, hubspot_html) from a tracking dict."""
    if not tracking:
        return "", "", ""

    hs = ""
    if tracking.get("hubspot_portal_id", "PLACEHOLDER") != "PLACEHOLDER":
        hs = f'<script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/{tracking["hubspot_portal_id"]}.js"></script>'

    gtm = ""
    gtm_ids = tracking.get("gtm_ids", [])
    if gtm_ids:
        calls = "".join(f"gtm('{gid}');" for gid in gtm_ids)
        gtm = ("<script>"
               "function gtm(id){"
               "(function(w,d,s,l,i){"
               "w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});"
               "var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';"
               "j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;"
               "f.parentNode.insertBefore(j,f);"
               "})(window,document,'script','dataLayer',id);}"
               f"{calls}"
               "</script>")

    fs = ""
    fs_org = tracking.get("fullstory_org", "")
    if fs_org:
        fs = ("<script>"
              f"window['_fs_host']='fullstory.com';window['_fs_script']='edge.fullstory.com/s/fs.js';window['_fs_org']='{fs_org}';window['_fs_namespace']='FS';"
              "(function(m,n,e,t,l,o,g,y){"
              "if(e in m){if(m.console&&m.console.log){m.console.log('FullStory namespace conflict.');}return;}"
              "g=m[e]=function(a,b,s){g.q?g.q.push([a,b,s]):g._api(a,b,s);};g.q=[];"
              "o=n.createElement(t);o.async=1;o.crossOrigin='anonymous';o.src='https://'+_fs_script;"
              "y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);"
              "g.identify=function(i,v,s){g(l,{uid:i},s);if(v)g(l,v,s)};g.setUserVars=function(v,s){g(l,v,s)};g.event=function(i,v,s){g('event',{n:i,p:v},s)};"
              "g.anonymize=function(){g.identify(!!0)};"
              "g.shutdown=function(){g('rec',!1)};g.restart=function(){g('rec',!0)};"
              "g.log=function(a,b){g('log',[a,b])};"
              "g.consent=function(a){g('consent',!arguments.length||a)};"
              "g.identifyAccount=function(i,v){o='account';v=v||{};v.acctId=i;g(o,v)};"
              "g.clearUserCookie=function(){};"
              "g.setVars=function(n,p){g('setVars',[n,p])};"
              "g._w={};y='XMLHttpRequest';g._w[y]=m[y];y='fetch';g._w[y]=m[y];"
              "if(m[y])m[y]=function(){return g._w[y].apply(this,arguments)};"
              "g._v='1.3.0';"
              "})(window,document,window['_fs_namespace'],'script','user');"
              "</script>")

    return gtm, fs, hs


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_page(
    page_data,
    tokens=None,
    *,
    token_css=None,
    cta_buttons=None,
    nav_links=None,
    footer=None,
    tracking=None,
    logo_white_svg=None,
    logo_black_svg=None,
):
    """Assemble a complete, self-contained HTML landing page.

    Parameters
    ----------
    page_data : dict
        Must contain ``"title"`` and ``"sections"`` (list of typed section
        dicts).
    tokens : dict, optional
        DTCG token dict.  Loaded from the bundled asset when *None*.
        Ignored when *token_css* is provided.
    token_css : str, optional
        Pre-generated CSS custom properties (from build_design.py).
        When provided, skips regeneration from DTCG.  This is the
        preferred path for local builds where build_design.py is the
        single CSS generator.
    cta_buttons : list[dict], optional
        Each dict has ``text``, ``url``, ``style`` (``"primary"`` or
        ``"secondary"``).
    nav_links : list[dict], optional
        Each dict has ``text`` and ``url``.
    footer : dict, optional
        ``{"copyright": str, "links": [{"text": str, "url": str}, ...]}``.
    tracking : dict, optional
        Keys: ``gtm_ids`` (list), ``fullstory_org`` (str),
        ``hubspot_portal_id`` (str).
    logo_white_svg : str, optional
        Raw SVG markup for the white-text logo (dark backgrounds).
    logo_black_svg : str, optional
        Raw SVG markup for the black-text logo (light backgrounds).
    """
    if token_css is not None:
        css_text = token_css
    else:
        tokens = load_tokens(tokens)
        css_text = generate_css(tokens)

    if cta_buttons is None:
        cta_buttons = _DEFAULT_CTA_BUTTONS
    if nav_links is None:
        nav_links = _DEFAULT_NAV_LINKS
    if footer is None:
        footer = _DEFAULT_FOOTER

    logo_white = logo_white_svg or _load_bundled_svg("signalwire-full-logo-white-text.svg")
    logo_black = logo_black_svg or _load_bundled_svg("signalwire-full-logo-black-text.svg")

    title = page_data.get("title", "SignalWire")
    sections = page_data.get("sections", [])
    effects = page_data.get("effects", {})  # global effect defaults

    # CTA HTML
    cta_html = '<div class="lp-cta-row">'
    for btn in cta_buttons:
        cls = "lp-btn lp-btn--primary" if btn["style"] == "primary" else "lp-btn lp-btn--secondary"
        cta_html += f'<a href="{btn["url"]}" class="{cls}">{_esc(btn["text"])}</a>'
    cta_html += "</div>"

    # Nav
    nav_html = ""
    for link in nav_links:
        # Skip GitHub from text links (it's in the social icons now)
        if link.get("url", "").startswith("https://github.com"):
            continue
        nav_html += f'<a href="{link["url"]}">{_esc(link["text"])}</a>'

    # Footer
    footer_links = "".join(f'<a href="{l["url"]}">{_esc(l["text"])}</a>' for l in footer["links"])

    # Sections
    body_sections = ""
    has_cta = False
    for s in sections:
        stype = s.get("type", "text")
        renderer = SECTION_RENDERERS.get(stype, SECTION_RENDERERS["text"])
        html = renderer(s, cta_html)
        # Add scroll reveal to content sections (not hero, not logos)
        if stype not in ("hero", "logos"):
            html = html.replace('class="lp-section"', 'class="lp-section lp-reveal"', 1)
            html = html.replace('class="lp-section lp-section--stats"', 'class="lp-section lp-section--stats lp-reveal"', 1)
            html = html.replace('class="lp-section lp-section--logos"', 'class="lp-section lp-section--logos"', 1)
            html = html.replace('class="lp-section lp-section--cta"', 'class="lp-section lp-section--cta lp-reveal"', 1)
        # Per-section background pattern
        # Explicit "bg" field in JSON takes priority, otherwise use defaults by section type
        _DEFAULT_BG = {
            "hero": "dots-orbs",
            "features": "dots",
            "comparison": "grid",
            "steps": "hex",
            "cta": "logo-slow",
            "anatomy": "diagonal",
        }
        bg = s.get("bg") or _DEFAULT_BG.get(stype)
        if bg:
            html = html.replace('class="lp-section', f'class="lp-section sw-bg-{bg}', 1)
        # Interactive effects (opt-in per section via JSON fields)
        _FX_FIELDS = {
            "glow": "data-fx-glow",
            "tilt": "data-fx-tilt",
            "magnetic": "data-fx-magnetic",
            "parallax": "data-fx-parallax",
            "reveal_bg": "data-fx-reveal-bg",
            "typing": "data-fx-typing",
        }
        fx_attrs = ""
        for field, attr in _FX_FIELDS.items():
            val = s.get(field) or effects.get(field)
            if val:
                if isinstance(val, bool) and val:
                    fx_attrs += f' {attr}'
                elif isinstance(val, (int, float)):
                    fx_attrs += f' {attr}="{val}"'
                elif isinstance(val, str):
                    fx_attrs += f' {attr}="{_re.sub(r"[^a-zA-Z0-9_.#, ()-]", "", val)}"'
        if fx_attrs:
            html = html.replace('<section ', f'<section{fx_attrs} ', 1)
        body_sections += html + "\n"
        if stype in ("cta", "contact"):
            has_cta = True

    # Auto-add closing CTA if none specified
    if not has_cta:
        body_sections += _render_cta({"headline": "Ready to build?"}, cta_html) + "\n"

    # Tracking
    gtm, fs, hs = _tracking_scripts(tracking)

    return f"""<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_esc(title)} | SignalWire</title>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;600;700&family=Lexend:wght@300;400;500;600;700&family=Outfit:wght@400;500;600&family=JetBrains+Mono&display=swap" rel="stylesheet">
<style>
{css_text}
{COMPONENT_CSS}
</style>
{gtm}{fs}{hs}
</head>
<body>

<nav class="lp-navbar">
  <div class="lp-container lp-navbar__inner">
    <a href="https://signalwire.com" class="lp-navbar__logo">
      <span id="logo-dark">{logo_white}</span>
      <span id="logo-light" style="display:none">{logo_black}</span>
    </a>
    <div class="lp-navbar__links">
      {nav_html}
      <a href="{cta_buttons[0]["url"]}" class="lp-navbar__cta">{_esc(cta_buttons[0]["text"])}</a>
      <button id="theme-toggle" onclick="toggleTheme()">&#x1F319;</button>
      <div class="lp-navbar__social">
        <a href="https://discord.gg/aUg4wc7Dkr" target="_blank" rel="noopener" title="Join our Discord">{_SOCIAL_DISCORD}</a>
        <a href="https://github.com/signalwire" target="_blank" rel="noopener" title="GitHub">{_SOCIAL_GITHUB}</a>
        <a href="https://www.linkedin.com/company/signalwire/" target="_blank" rel="noopener" title="LinkedIn">{_SOCIAL_LINKEDIN}</a>
      </div>
      <button class="lp-navbar__burger" onclick="document.querySelector('.lp-navbar__mobile').classList.toggle('lp-navbar__mobile--open')" aria-label="Menu">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
      </button>
    </div>
  </div>
  <div class="lp-navbar__mobile">
    <a href="{cta_buttons[0]["url"]}" class="lp-btn lp-btn--primary" style="width:100%;justify-content:center">{_esc(cta_buttons[0]["text"])}</a>
  </div>
</nav>
<div class="lp-accent-bar"></div>

{body_sections}

<div class="lp-accent-bar"></div>
<footer class="lp-footer">
  <div class="lp-container lp-footer__inner">
    <span>&copy; {_esc(footer["copyright"])}</span>
    {_SOCIAL_LINKS_HTML}
    <div class="lp-footer__links">{footer_links}</div>
  </div>
</footer>

<script>
function lpCopy(btn){{var code=btn.parentElement.querySelector("code");var text=code.textContent;navigator.clipboard.writeText(text).then(function(){{btn.innerHTML="\u2713";btn.classList.add("lp-copy-btn--done");setTimeout(function(){{btn.innerHTML='{_COPY_SVG_JS}';btn.classList.remove("lp-copy-btn--done")}},2000)}})}}
function lpCopyTerminal(btn){{var body=btn.closest(".lp-terminal").querySelector(".lp-terminal__body:not([style*='display:none'])");if(!body)body=btn.closest("pre");var text=body.textContent;navigator.clipboard.writeText(text).then(function(){{btn.innerHTML="\u2713";btn.classList.add("lp-copied");setTimeout(function(){{btn.innerHTML='{_COPY_SVG_JS}';btn.classList.remove("lp-copied")}},2000)}})}}
function lpTab(btn){{var term=btn.closest(".lp-terminal");term.querySelectorAll(".lp-tab__btn").forEach(function(b){{b.classList.remove("lp-tab--active")}});btn.classList.add("lp-tab--active");term.querySelectorAll(".lp-tab__panel").forEach(function(p){{p.style.display="none"}});document.getElementById(btn.dataset.tab).style.display="block"}}
function applyTheme(t){{document.documentElement.setAttribute("data-theme",t);var d=t!=="light";document.getElementById("logo-dark").style.display=d?"":"none";document.getElementById("logo-light").style.display=d?"none":"";document.getElementById("theme-toggle").textContent=d?"\\uD83C\\uDF19":"\\u2600\\uFE0F"}}
function toggleTheme(){{var n=document.documentElement.getAttribute("data-theme")==="light"?"dark":"light";localStorage.setItem("sw-theme",n);applyTheme(n)}}
(function(){{var s=localStorage.getItem("sw-theme");if(s)applyTheme(s)}})();
var _ro=new IntersectionObserver(function(e){{e.forEach(function(i){{if(i.isIntersecting){{i.target.classList.add("lp-visible");_ro.unobserve(i.target);}}}});}},{{threshold:0.1,rootMargin:"0px 0px -40px 0px"}});document.querySelectorAll(".lp-reveal").forEach(function(el){{_ro.observe(el);}});
/* Interactive effects */
if(!window.matchMedia("(prefers-reduced-motion:reduce)").matches){{
  /* Cursor glow */
  document.querySelectorAll("[data-fx-glow]").forEach(function(el){{
    var c=el.dataset.fxGlow;
    if(c&&c!=="true")el.style.setProperty("--glow-color",c);
    el.addEventListener("mousemove",function(e){{
      var r=el.getBoundingClientRect();
      el.style.setProperty("--glow-x",(e.clientX-r.left)+"px");
      el.style.setProperty("--glow-y",(e.clientY-r.top)+"px");
    }});
  }});
  /* Card tilt */
  document.querySelectorAll("[data-fx-tilt]").forEach(function(sec){{
    var cards=sec.querySelectorAll(".lp-feature-card,.lp-pricing-tier");
    cards.forEach(function(card){{
      card.addEventListener("mousemove",function(e){{
        var r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
        var rx=(y-0.5)*-4,ry=(x-0.5)*4;
        card.style.transform="perspective(800px) rotateX("+rx+"deg) rotateY("+ry+"deg) scale(1.02)";
      }});
      card.addEventListener("mouseleave",function(){{card.style.transform="";}});
    }});
  }});
  /* Magnetic buttons */
  document.querySelectorAll("[data-fx-magnetic]").forEach(function(sec){{
    var btns=sec.querySelectorAll(".lp-btn");
    btns.forEach(function(btn){{
      sec.addEventListener("mousemove",function(e){{
        var r=btn.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
        var dx=e.clientX-cx,dy=e.clientY-cy,dist=Math.sqrt(dx*dx+dy*dy);
        if(dist<120){{var pull=Math.max(0,(120-dist)/120)*3;btn.style.transform="translate("+dx/dist*pull+"px,"+dy/dist*pull+"px)";}}
        else{{btn.style.transform="";}}
      }});
      sec.addEventListener("mouseleave",function(){{btn.style.transform="";}});
    }});
  }});
  /* Parallax on scroll */
  var pxEls=document.querySelectorAll("[data-fx-parallax]");
  if(pxEls.length){{
    window.addEventListener("scroll",function(){{
      var st=window.pageYOffset;
      pxEls.forEach(function(el){{
        var rate=parseFloat(el.dataset.fxParallax)||0.3;
        var r=el.getBoundingClientRect(),off=(r.top+r.height/2-window.innerHeight/2)*rate;
        var after=el.querySelector(":scope > :last-child");
        if(el.style)el.style.setProperty("--px-offset",off+"px");
      }});
    }},{{passive:true}});
  }}
  /* Code typing burst */
  document.querySelectorAll("[data-fx-typing]").forEach(function(sec){{
    var code=sec.querySelector(".lp-code__block code");
    if(!code)return;
    var full=code.textContent,i=0,speed=2;
    code.textContent="";
    var tObs=new IntersectionObserver(function(entries){{
      if(entries[0].isIntersecting){{
        tObs.disconnect();
        var iv=setInterval(function(){{i+=speed;code.textContent=full.slice(0,i);if(i>=full.length){{clearInterval(iv);sec.classList.add("lp-typing-done");}}}},8);
      }}
    }},{{threshold:0.3}});
    tObs.observe(sec);
  }});
}}
</script>
</body>
</html>"""


def build_batch(content_dir, output_dir, **kwargs):
    """Build every ``*.json`` file in *content_dir* into *output_dir*.

    Extra *kwargs* are forwarded to :func:`build_page` (e.g. ``tokens``,
    ``cta_buttons``, ``tracking``).

    Returns the number of pages built.
    """
    os.makedirs(output_dir, exist_ok=True)
    built = 0
    for name in sorted(os.listdir(content_dir)):
        if not name.endswith(".json"):
            continue
        with open(os.path.join(content_dir, name)) as f:
            page_data = json.load(f)
        html = build_page(page_data, **kwargs)
        out_name = os.path.splitext(name)[0] + ".html"
        with open(os.path.join(output_dir, out_name), "w") as f:
            f.write(html)
        built += 1
    return built
