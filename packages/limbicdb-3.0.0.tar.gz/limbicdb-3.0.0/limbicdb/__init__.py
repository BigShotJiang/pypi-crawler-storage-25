"""
LimbicDB Python SDK
Debuggable memory layer for AI agents
"""

from .memory import Memory

__version__ = "3.0.0"
__author__ = "Kousoyu"