"""
This module provides functionality for statistical testing of multiple simulations.

The main function is :py:func:`run_statistical_tests`. It allows running multiple statistical tests
matching the provided filter criteria. Statistical tests check if scalar results of the simulations
are the same as the saved baseline results. The baseline results can be found in the statistics folder
of the simulation project.
"""

import glob
import logging
import math
import pandas
import re
import shutil
import subprocess

try:
    from omnetpp.scave.results import *
except (ImportError, ModuleNotFoundError):
    pass

from opp_repl.simulation import *
from opp_repl.test.fingerprint import *
from opp_repl.test.simulation import *

_logger = logging.getLogger(__name__)
_append_args = [
    "--record-eventlog=false",
    "--output-scalar-precision=17",
    "--output-vector-precision=17",
    "--**.param-recording=false",
    "--output-scalar-file=${resultdir}/${inifile}-${configname}-#${repetition}.sca",
    "--output-vector-file=${resultdir}/${inifile}-${configname}-#${repetition}.vec"
]

def _read_scalar_result_file(file_name):
    df = read_result_files(file_name)
    df = get_scalars(df, include_runattrs=True)
    df = df if df.empty else df[["experiment", "measurement", "replication", "module", "name", "value"]]
    return df

def _write_diff_file(a_file_name, b_file_name, diff_file_name):
    diff_command = ["diff", a_file_name, b_file_name]
    with open(diff_file_name, "w") as file:
        subprocess.call(diff_command, stdout=file)

def _symmetric_relative_error(old, new):
    denom = abs(old) + abs(new)
    if denom == 0:
        return 0.0
    return 2 * (new - old) / denom

def _unbounded_relative_error(old, new):
    e = _symmetric_relative_error(old, new)
    if e >= 2:
        return float("inf")
    if e <= -2:
        return float("-inf")
    return 2.0 * math.atanh(e / 2.0)

def _remove_attr_lines(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Variables to track state
    new_lines = []
    in_attr_block = False
    attr_block_found = False

    for line in lines:
        if line.startswith('attr '):
            if not attr_block_found:
                if not in_attr_block:
                    in_attr_block = True
                new_lines.append(line)
            else:
                in_attr_block = False
        else:
            if in_attr_block:
                attr_block_found = True
            in_attr_block = False
            new_lines.append(line)

    with open(file_path, 'w') as file:
        file.writelines(new_lines)

class StatisticalTestTask(SimulationTestTask):
    def __init__(self, simulation_config=None, run_number=0, name="statistical test", task_result_class=SimulationTestTaskResult, **kwargs):
        super().__init__(simulation_task=SimulationTask(simulation_config=simulation_config, run_number=run_number, name=name, **kwargs), task_result_class=task_result_class, **kwargs)
        self.locals = locals()
        self.locals.pop("self")
        self.kwargs = kwargs

    def get_result_file_name(self, extension):
        simulation_config = self.simulation_task.simulation_config
        return f"{simulation_config.ini_file}-{simulation_config.config}-#{self.simulation_task.run_number}.{extension}"

    def check_simulation_task_result(self, simulation_task_result, baseline_simulation_project=None, result_name_filter=None, exclude_result_name_filter=None, result_module_filter=None, exclude_result_module_filter=None, full_match=False, relative_error_threshold=None, **kwargs):
        simulation_config = self.simulation_task.simulation_config
        simulation_project = simulation_config.simulation_project
        baseline_project = baseline_simulation_project or simulation_project
        working_directory = simulation_config.working_directory
        current_scalar_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("sca")))
        current_vector_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("vec")))
        current_index_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("vci")))
        if os.path.exists(current_vector_result_file_name):
            run_command_with_logging(["opp_scavetool", "x", "--precision=17", "--type", "sth", "-w", current_scalar_result_file_name, current_vector_result_file_name, "-o", current_scalar_result_file_name])
            os.remove(current_vector_result_file_name)
        else:
            run_command_with_logging(["opp_scavetool", "x", "--precision=17", "--type", "sth", "-w", current_scalar_result_file_name, "-o", current_scalar_result_file_name])
        if os.path.exists(current_index_result_file_name):
            os.remove(current_index_result_file_name)
        _remove_attr_lines(current_scalar_result_file_name)
        stored_scalar_result_file_name = baseline_project.get_full_path(os.path.join(baseline_project.statistics_folder, working_directory, self.get_result_file_name("sca")))
        _logger.debug(f"Reading result file {current_scalar_result_file_name}")
        current_df = _read_scalar_result_file(current_scalar_result_file_name)
        scalar_result_diff_file_name = re.sub(r".sca$", ".diff", stored_scalar_result_file_name)
        if os.path.exists(scalar_result_diff_file_name):
            os.remove(scalar_result_diff_file_name)
        if os.path.exists(stored_scalar_result_file_name):
            _logger.debug(f"Reading result file {stored_scalar_result_file_name}")
            stored_df = _read_scalar_result_file(stored_scalar_result_file_name)
            if not current_df.equals(stored_df):
                _write_diff_file(stored_scalar_result_file_name, current_scalar_result_file_name, scalar_result_diff_file_name)
                _logger.debug(f"Writing diff file {scalar_result_diff_file_name}")
                if current_df.empty:
                    task_result = self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="FAIL", reason="Current statistical results are empty")
                elif stored_df.empty:
                    task_result = self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="FAIL", reason="Stored statistical results are empty")
                else:
                    merged = stored_df.merge(current_df, on=['experiment', 'measurement', 'replication', 'module', 'name'], how='outer', suffixes=('_stored', '_current'))
                    df = merged[
                        (merged['value_stored'].isna() & merged['value_current'].notna()) |
                        (merged['value_stored'].notna() & merged['value_current'].isna()) |
                        (merged['value_stored'] != merged['value_current'])].dropna(subset=['value_stored', 'value_current'], how='all').copy()
                    df["relative_error"] = df.apply(lambda row: _unbounded_relative_error(row["value_stored"], row["value_current"]), axis=1)
                    df = df[df.apply(lambda row: matches_filter(row["name"], result_name_filter, exclude_result_name_filter, full_match) and \
                                                 matches_filter(row["module"], result_module_filter, exclude_result_module_filter, full_match), axis=1)]
                    if relative_error_threshold is not None:
                        df_before_threshold = df
                        df = df[df["relative_error"].abs() >= relative_error_threshold]
                    if df.empty:
                        if relative_error_threshold is not None and not df_before_threshold.empty:
                            max_error = df_before_threshold["relative_error"].abs().max()
                            return self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="PASS", reason=f"All differences below relative error threshold {relative_error_threshold} (max relative error {max_error:.6g})")
                        return self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="PASS", reason="All differences filtered out")
                    sorted_df = df.loc[df["relative_error"].abs().sort_values(ascending=False).index]
                    scalar_result_csv_file_name = re.sub(r".sca$", ".csv", stored_scalar_result_file_name)
                    _logger.debug(f"Writing CSV file {scalar_result_csv_file_name}")
                    sorted_df.to_csv(scalar_result_csv_file_name, float_format="%.17g")
                    id = df["relative_error"].idxmax()
                    if math.isnan(id):
                        id = next(iter(df.index), None)
                    reason = df.loc[id].to_string()
                    reason = re.sub(r" +", " = ", reason)
                    reason = re.sub(r"\n", ", ", reason)
                    task_result = self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="FAIL", reason=reason)
            else:
                task_result = self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="PASS")
        else:
            task_result = self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="ERROR", reason="Stored statistical results are not found")
        if os.path.exists(current_scalar_result_file_name):
            os.remove(current_scalar_result_file_name)
        return task_result

def get_statistical_test_sim_time_limit(simulation_config, run_number=0):
    return simulation_config.sim_time_limit

def get_statistical_test_tasks(sim_time_limit=get_statistical_test_sim_time_limit, run_number=0, **kwargs):
    """
    Returns multiple statistical test tasks matching the provided filter criteria. The returned tasks can be run by
    calling the :py:meth:`run <opp_repl.common.task.MultipleTasks.run>` method.

    Parameters:
        kwargs (dict):
            The filter criteria parameters are inherited from the :py:meth:`get_simulation_tasks <opp_repl.simulation.task.get_simulation_tasks>` method.

    Returns (:py:class:`MultipleTestTasks`):
        an object that contains a list of :py:class:`StatisticalTestTask` objects matching the provided filter criteria.
        The result can be run (and re-run) without providing additional parameters.
    """
    return get_simulation_tasks(name="statistical test", run_number=run_number, sim_time_limit=sim_time_limit, simulation_task_class=StatisticalTestTask, multiple_simulation_tasks_class=MultipleSimulationTestTasks, **kwargs)

def run_statistical_tests(append_args=[], **kwargs):
    """
    Runs one or more statistical tests that match the provided filter criteria.

    Parameters:
        kwargs (dict):
            The filter criteria parameters are inherited from the :py:func:`get_statistical_test_tasks` function.

    Returns (:py:class:`MultipleSimulationTestTaskResults`):
        an object that contains a list of :py:class:`SimulationTestTaskResult` objects. Each object describes the result of running one test task.
    """
    multiple_statistical_test_tasks = get_statistical_test_tasks(**kwargs)
    return multiple_statistical_test_tasks.run(append_args=append_args + _append_args, **kwargs)

class StatisticalResultsUpdateTask(SimulationUpdateTask):
    def __init__(self, simulation_config=None, run_number=0, name="statistical results update", **kwargs):
        super().__init__(simulation_task=SimulationTask(simulation_config=simulation_config, run_number=run_number, name=name, **kwargs), simulation_config=simulation_config, run_number=run_number, name=name, **kwargs)
        self.locals = locals()
        self.locals.pop("self")
        self.kwargs = kwargs

    def get_result_file_name(self, extension):
        simulation_config = self.simulation_task.simulation_config
        return f"{simulation_config.ini_file}-{simulation_config.config}-#{self.simulation_task.run_number}.{extension}"

    def run_protected(self, baseline_simulation_project=None, **kwargs):
        simulation_config = self.simulation_task.simulation_config
        simulation_project = simulation_config.simulation_project
        baseline_project = baseline_simulation_project or simulation_project
        working_directory = simulation_config.working_directory
        target_results_directory = baseline_project.get_full_path(os.path.join(baseline_project.statistics_folder, working_directory))
        os.makedirs(target_results_directory, exist_ok=True)
        update_result = super().run_protected(**kwargs)
        stored_scalar_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("sca")))
        if update_result.result == "INSERT" or update_result.result == "UPDATE":
            shutil.copy(stored_scalar_result_file_name, target_results_directory)
        if os.path.exists(stored_scalar_result_file_name):
            os.remove(stored_scalar_result_file_name)
        return update_result

    def check_simulation_task_result(self, simulation_task_result, baseline_simulation_project=None, result_name_filter=None, exclude_result_name_filter=None, result_module_filter=None, exclude_result_module_filter=None, full_match=False, **kwargs):
        simulation_config = self.simulation_task.simulation_config
        simulation_project = simulation_config.simulation_project
        baseline_project = baseline_simulation_project or simulation_project
        working_directory = simulation_config.working_directory
        current_scalar_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("sca")))
        current_vector_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("vec")))
        current_index_result_file_name = simulation_project.get_full_path(os.path.join(working_directory, "results", self.get_result_file_name("vci")))
        if os.path.exists(current_vector_result_file_name):
            run_command_with_logging(["opp_scavetool", "x", "--precision=17", "--type", "sth", "-w", current_scalar_result_file_name, current_vector_result_file_name, "-o", current_scalar_result_file_name])
            os.remove(current_vector_result_file_name)
        else:
            run_command_with_logging(["opp_scavetool", "x", "--precision=17", "--type", "sth", "-w", current_scalar_result_file_name, "-o", current_scalar_result_file_name])
        if os.path.exists(current_index_result_file_name):
            os.remove(current_index_result_file_name)
        _remove_attr_lines(current_scalar_result_file_name)
        stored_scalar_result_file_name = baseline_project.get_full_path(os.path.join(baseline_project.statistics_folder, working_directory, self.get_result_file_name("sca")))
        _logger.debug(f"Reading result file {current_scalar_result_file_name}")
        current_df = _read_scalar_result_file(current_scalar_result_file_name)
        scalar_result_diff_file_name = re.sub(r".sca$", ".diff", stored_scalar_result_file_name)
        if os.path.exists(scalar_result_diff_file_name):
            os.remove(scalar_result_diff_file_name)
        if not os.path.exists(stored_scalar_result_file_name):
            return self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="INSERT")
        else:
            _logger.debug(f"Reading result file {stored_scalar_result_file_name}")
            stored_df = _read_scalar_result_file(stored_scalar_result_file_name)
            if not current_df.equals(stored_df):
                _write_diff_file(stored_scalar_result_file_name, current_scalar_result_file_name, scalar_result_diff_file_name)
                return self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="UPDATE")
            else:
                return self.task_result_class(task=self, simulation_task_result=simulation_task_result, result="KEEP")

def get_update_statistical_result_tasks(run_number=0, **kwargs):
    """
    Returns multiple update statistical results tasks matching the provided filter criteria. The returned tasks can be run by
    calling the :py:meth:`run <opp_repl.common.task.MultipleTasks.run>` method.

    Parameters:
        kwargs (dict):
            The filter criteria parameters are inherited from the :py:meth:`get_simulation_tasks <opp_repl.simulation.task.get_simulation_tasks>` method.

    Returns (:py:class:`MultipleUpdateTasks`):
        an object that contains a list of :py:class:`StatisticalResultsUpdateTask` objects matching the provided filter criteria.
        The result can be run (and re-run) without providing additional parameters.
    """
    return get_simulation_tasks(run_number=run_number, multiple_simulation_tasks_class=MultipleSimulationUpdateTasks, simulation_task_class=StatisticalResultsUpdateTask, **kwargs)

def update_statistical_test_results(sim_time_limit=get_statistical_test_sim_time_limit, append_args=[], **kwargs):
    """
    Updates the stored statistical results for one or more chart tests that match the provided filter criteria.

    Parameters:
        kwargs (dict):
            The filter criteria parameters are inherited from the :py:func:`get_update_statistical_result_tasks` function.

    Returns (:py:class:`MultipleUpdateTaskResults`):
        an object that contains a list of :py:class:`UpdateTaskResult` objects. Each object describes the result of running one update task.
    """
    multiple_update_statistical_result_tasks = get_update_statistical_result_tasks(sim_time_limit=sim_time_limit, **kwargs)
    return multiple_update_statistical_result_tasks.run(sim_time_limit=sim_time_limit, append_args=append_args + _append_args, **kwargs)
