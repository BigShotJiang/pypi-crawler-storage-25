import argparse
import logging
import os
import re
import sys
import time

from opp_repl.simulation import *
from opp_repl.test import *

__sphinx_mock__ = True # ignore this module in documentation

_logger = logging.getLogger(__name__)

class LongTask(Task):
    def run_protected(self, **kwargs):
        _logger.info("Started")
        for i in range(0, 10):
            if self.cancel:
                break
            time.sleep(1)
        _logger.info("Finished")
        return self.task_result_class(task=self, result="CANCEL" if self.cancel else "DONE", reason="Task completed")

class LongExternalTask(Task):
    def run_protected(self, **kwargs):
        _logger.info("Started")
        run_command_with_logging(["sleep", "10"])
        run_command_with_logging(["echo", "Hello"])
        _logger.info("Finished")
        return Task.run_protected(self, **kwargs)

def run_long_task():
    return LongTask().run()

def run_long_external_task():
    return LongExternalTask().run()

def run_long_multiple_tasks():
    return MultipleTasks(tasks=[LongTask(), LongTask(), LongTask()], pass_keyboard_interrupt=True).run()

def run_long_multiple_external_tasks():
    return MultipleTasks(tasks=[LongExternalTask(), LongExternalTask(), LongExternalTask()], pass_keyboard_interrupt=True).run()

def run_long_nested_multiple_tasks():
    return MultipleTasks(tasks=[MultipleTasks(tasks=[LongTask(), LongTask(), LongTask()], pass_keyboard_interrupt=True), MultipleTasks(tasks=[LongTask(), LongTask(), LongTask()], pass_keyboard_interrupt=True)], concurrent=False).run()

def run_long_nested_multiple_external_tasks():
    return MultipleTasks(tasks=[MultipleTasks(tasks=[LongExternalTask(), LongExternalTask(), LongExternalTask()], pass_keyboard_interrupt=True), MultipleTasks(tasks=[LongExternalTask(), LongExternalTask(), LongExternalTask()], pass_keyboard_interrupt=True)], concurrent=False).run()

# TODO
# running simulations
# running smoke tests
# running fingerprint tests
#
# dimensions:
#  - current project vs selected project
#  - debug vs release
#  - build vs no-build
#  - include filter and exclude filter (working directory, ini file, config, run number)
#  - sim time limit, cpu time limit
#  - sequential vs. concurrent
#  - localhost vs. cluster
#  - native environment vs specific nix environment

class SimulationSelfTestTask(TestTask):
    def __init__(self, simulation_project, action="Running simulation self test", **kwargs):
        super().__init__(simulation_project=simulation_project, action=action, **kwargs)
        self.simulation_project = simulation_project

    def get_parameters_string(self, **kwargs):
        return self.simulation_project.get_name()

    def run_protected(self, **kwargs):
        simulation_task_results = run_simulations(**self.kwargs)
        return TaskResult(task=self, result=simulation_task_results.result)

class SmokeTestSelfTestTask(TestTask):
    def __init__(self, simulation_project, action="Running smoke test self test", **kwargs):
        super().__init__(simulation_project=simulation_project, action=action, **kwargs)
        self.simulation_project = simulation_project

    def get_parameters_string(self, **kwargs):
        return self.simulation_project.get_name()

    def run_protected(self, **kwargs):
        smoke_test_task_results = run_smoke_tests(**self.kwargs)
        return TestTaskResult(task=self, result=smoke_test_task_results.result)

class FingerprintTestSelfTestTask(TestTask):
    def __init__(self, simulation_project, action="Running fingerprint test self test", **kwargs):
        super().__init__(simulation_project=simulation_project, action=action, **kwargs)
        self.simulation_project = simulation_project

    def get_parameters_string(self, **kwargs):
        return self.simulation_project.get_name()

    def run_protected(self, **kwargs):
        update_correct_fingerprint_task_results = update_fingerprint_test_results(**self.kwargs)
        fingerprint_test_task_results = run_fingerprint_tests(**self.kwargs)
        repeated_update_correct_fingerprint_task_results = update_fingerprint_test_results(**self.kwargs)
        repeated_fingerprint_test_task_results = run_fingerprint_tests(**self.kwargs)
        return TestTaskResult(task=self, result=fingerprint_test_task_results.result)

class SimulationProjectSelfTestTasks(MultipleTestTasks):
    def __init__(self, simulation_project, name="simulation project self test", **kwargs):
        super().__init__(tasks = [SimulationSelfTestTask(simulation_project=simulation_project, concurrent=True, **kwargs),
                                  SmokeTestSelfTestTask(simulation_project=simulation_project, concurrent=True, **kwargs),
                                  FingerprintTestSelfTestTask(simulation_project=simulation_project, concurrent=False, **kwargs)],
                         simulation_project=simulation_project, name=name, concurrent=False, **kwargs)
        self.simulation_project = simulation_project

class MultipleSelfTestTasks(MultipleTestTasks):
    def __init__(self, name="self test", **kwargs):
        super().__init__(tasks=[SimulationProjectSelfTestTasks(simulation_project=get_simulation_project("aloha", None), sim_time_limit="90min", **kwargs),
                                SimulationProjectSelfTestTasks(simulation_project=get_simulation_project("tictoc", None), sim_time_limit="1s", **kwargs)],
                         name=name, concurrent=False, **kwargs)

def parse_arguments():
    description = "Runs the self test on the OMNeT++ sample projects."
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("-m", "--mode", choices=["debug", "release"], help="specifies the build mode of the projects")
    parser.add_argument("-f", "--filter", default=None, help="includes simulations that match the specified generic filter")
    parser.add_argument("--exclude-filter", default=None, help="exclude simulations that match the specified generic filter")
    parser.add_argument("-r", "--run-filter", default=None, help="includes simulations having the specified run numbers")
    parser.add_argument("--exclude-run-filter", default=None, help="exclude simulations having the specified run numbers")
    parser.add_argument("-l", "--log-level", choices=["ERROR", "WARN", "INFO", "DEBUG"], default="WARN", help="specifies the log level for the root logging category")
    parser.add_argument("--external-command-log-level", choices=["ERROR", "WARN", "INFO", "DEBUG"], default="WARN", help="specifies the log level for the external command logging categories")
    return parser.parse_args(sys.argv[1:])

def process_arguments(args):
    kwargs = {k: v for k, v in vars(args).items() if v is not None}
    return kwargs

def define_self_test_projects():
    define_simulation_project("aloha", root_folder_environment_variable="__omnetpp_root_dir", root_folder_environment_variable_relative_folder="samples/aloha")
    define_simulation_project("tictoc", root_folder_environment_variable="__omnetpp_root_dir", root_folder_environment_variable_relative_folder="samples/tictoc")

def run_self_tests_main():
    args = parse_arguments()
    kwargs = process_arguments(args)
    initialize_logging(args.log_level, args.external_command_log_level)
    define_self_test_projects()
    self_test_task_results = MultipleSelfTestTasks(**kwargs).run(**kwargs)
    print(self_test_task_results)
    sys.exit(0 if (self_test_task_results is None or self_test_task_results.is_all_results_expected()) else 1)

class TaskSelfTestTask(Task):
    def run_protected(self, **kwargs):
        time.sleep(0)
        return super().run_protected(**kwargs)

def test_tasks(**kwargs):
    TaskSelfTestTask(name="T", action="simulation").run(**kwargs)
    tasks = [TaskSelfTestTask(name="A", action="simulation", **kwargs), TaskSelfTestTask(name="B", action="simulation", **kwargs)]
    multiple_tasks = MultipleTasks(tasks=tasks, name="main task", **kwargs)
    multiple_tasks.run(**kwargs)
    tasks1 = [TaskSelfTestTask(name="A", action="compile", **kwargs), TaskSelfTestTask(name="B", action="compile", **kwargs), TaskSelfTestTask(name="C", action="compile", **kwargs), TaskSelfTestTask(name="D", action="compile", **kwargs)]
    tasks2 = [TaskSelfTestTask(name="X", action="link", **kwargs), TaskSelfTestTask(name="Y", action="link", **kwargs), TaskSelfTestTask(name="Z", action="link", **kwargs)]
    multiple_tasks1 = MultipleTasks(tasks=tasks1, name="compile task", **kwargs)
    multiple_tasks2 = MultipleTasks(tasks=tasks2, name="link task", **kwargs)
    multiple_tasks = MultipleTasks(tasks=[multiple_tasks1, multiple_tasks2], name="main task", **kwargs)
    multiple_tasks.run(**kwargs)
    tested_task = TaskSelfTestTask(name="X", action="simulate", **kwargs)
    task_test_task = TaskTestTask(name="test", tested_task=tested_task, **kwargs)
    task_test_task.run(**kwargs)
