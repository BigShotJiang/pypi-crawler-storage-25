"""ptc infra tls — manage TLS certificates for local clusters."""

import platform
import subprocess
import sys
import textwrap
from pathlib import Path
from typing import IO, Optional

from radicli import Arg
from wasabi.printer import Printer

from ...cli import cli


class FilePrinter(Printer):
    """Printer that writes to an arbitrary file object.

    Drop-in replacement for wasabi.Printer with an ``output`` parameter.
    Wasabi's Printer hardcodes builtins.print (i.e. stdout); this subclass
    redirects all output to the given file.
    TODO: upstream ``output`` support into wasabi.Printer itself.
    """

    def __init__(self, output: IO[str] = sys.stdout, **kwargs) -> None:
        super().__init__(**kwargs)
        self._output = output

    def text(self, *args, **kwargs):
        """Temporarily redirect stdout so wasabi writes to our file."""
        import builtins

        _orig = builtins.print

        def _print(*a, **kw):
            kw["file"] = self._output
            _orig(*a, **kw)

        builtins.print = _print
        try:
            return super().text(*args, **kwargs)
        finally:
            builtins.print = _orig


msg = FilePrinter(output=sys.stderr)

DEFAULT_NAMESPACE = "ellf"
CERT_MANAGER_NAMESPACE = "cert-manager"
CA_ISSUER_NAME = "prodigy-teams-selfsigned"
CA_CERT_NAME = "prodigy-teams-ca"
CA_SECRET_NAME = "prodigy-teams-ca-keypair"
LOCAL_CA_ISSUER_NAME = "prodigy-teams-local-ca"
LEAF_CERT_NAME = "prodigy-teams-tls"
LEAF_SECRET_NAME = "prodigy-teams-tls"
CA_COMMON_NAME = "Prodigy Teams Local CA"


def _kubectl_apply(manifest: str) -> None:
    subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=manifest,
        check=True,
        text=True,
        capture_output=True,
    )


def _kubectl_get_jsonpath(
    resource: str, namespace: str, jsonpath: str
) -> Optional[str]:
    result = subprocess.run(
        [
            "kubectl",
            "get",
            resource,
            "-n",
            namespace,
            "-o",
            f"jsonpath={jsonpath}",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _wait_for_cert(name: str, namespace: str, timeout: int = 60) -> bool:
    """Wait for a cert-manager Certificate to become Ready."""
    result = subprocess.run(
        [
            "kubectl",
            "wait",
            f"certificate/{name}",
            "-n",
            namespace,
            "--for=condition=Ready",
            f"--timeout={timeout}s",
        ],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _create_self_signed_ca() -> None:
    """Create the self-signed bootstrap issuer and CA certificate."""
    manifest = textwrap.dedent(f"""\
        apiVersion: cert-manager.io/v1
        kind: ClusterIssuer
        metadata:
          name: {CA_ISSUER_NAME}
        spec:
          selfSigned: {{}}
        ---
        apiVersion: cert-manager.io/v1
        kind: Certificate
        metadata:
          name: {CA_CERT_NAME}
          namespace: {CERT_MANAGER_NAMESPACE}
        spec:
          isCA: true
          secretName: {CA_SECRET_NAME}
          issuerRef:
            name: {CA_ISSUER_NAME}
            kind: ClusterIssuer
          commonName: "{CA_COMMON_NAME}"
          duration: 87600h
        ---
        apiVersion: cert-manager.io/v1
        kind: ClusterIssuer
        metadata:
          name: {LOCAL_CA_ISSUER_NAME}
        spec:
          ca:
            secretName: {CA_SECRET_NAME}
    """)
    _kubectl_apply(manifest)
    msg.good(f"Self-signed CA created (ClusterIssuer: {LOCAL_CA_ISSUER_NAME})")
    if not _wait_for_cert(CA_CERT_NAME, CERT_MANAGER_NAMESPACE):
        msg.warn(f"CA certificate {CA_CERT_NAME} did not become Ready in time")


def _issue_leaf_cert(fqdn: str, namespace: str) -> None:
    """Issue a leaf certificate for the cluster FQDN."""
    manifest = textwrap.dedent(f"""\
        apiVersion: cert-manager.io/v1
        kind: Certificate
        metadata:
          name: {LEAF_CERT_NAME}
          namespace: {namespace}
        spec:
          secretName: {LEAF_SECRET_NAME}
          issuerRef:
            name: {LOCAL_CA_ISSUER_NAME}
            kind: ClusterIssuer
          dnsNames:
            - {fqdn}
          ipAddresses:
            - "127.0.0.1"
          duration: 8760h
          renewBefore: 720h
    """)
    _kubectl_apply(manifest)
    if not _wait_for_cert(LEAF_CERT_NAME, namespace):
        msg.warn(f"Leaf certificate {LEAF_CERT_NAME} did not become Ready in time")
    msg.good(f"Certificate issued for {fqdn} (Secret: {LEAF_SECRET_NAME})")


def _update_ingress_tls(fqdn: str, namespace: str) -> None:
    """Patch the broker ingress to use the TLS secret."""
    import json

    subprocess.run(
        [
            "kubectl",
            "patch",
            "ingress",
            "ellf-broker",
            "-n",
            namespace,
            "--type=json",
            "-p",
            (
                f'[{{"op":"add","path":"/spec/tls",'
                f'"value":[{{"hosts":[{json.dumps(fqdn)}],'
                f'"secretName":"{LEAF_SECRET_NAME}"}}]}}]'
            ),
        ],
        check=True,
        text=True,
        capture_output=True,
    )
    msg.good("Ingress updated — broker now serving HTTPS")


def _fetch_ca_pem(dest: Path) -> Path:
    """Extract the CA public cert from the cluster and write it to dest."""
    ca_b64 = _kubectl_get_jsonpath(
        f"secret/{CA_SECRET_NAME}",
        CERT_MANAGER_NAMESPACE,
        "{.data.ca\\.crt}",
    )
    if not ca_b64:
        msg.fail(f"Could not read CA cert from secret {CA_SECRET_NAME}")
        raise SystemExit(1)
    import base64

    ca_pem = base64.b64decode(ca_b64)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(ca_pem)
    msg.good(f"CA certificate written to {dest}")
    return dest


def _get_trust_commands_linux(ca_path: Path) -> list[str]:
    """Return shell commands needed to trust the CA on Linux."""
    commands: list[str] = []
    # System trust store (requires sudo)
    sys_dest = "/usr/local/share/ca-certificates/prodigy-teams-ca.crt"
    commands.append(f"sudo cp {ca_path} {sys_dest}")
    commands.append("sudo update-ca-certificates")
    # Chrome/Chromium NSS database
    nssdb = Path.home() / ".pki" / "nssdb"
    if nssdb.exists():
        commands.append(
            f'certutil -d sql:{nssdb} -A -t "C,," -n "{CA_COMMON_NAME}" -i {ca_path}'
        )
    # Firefox per-profile NSS databases
    firefox_dir = Path.home() / ".mozilla" / "firefox"
    if firefox_dir.exists():
        for cert_db in firefox_dir.glob("*/cert9.db"):
            profile_dir = cert_db.parent
            commands.append(
                f'certutil -d sql:{profile_dir} -A -t "C,," '
                f'-n "{CA_COMMON_NAME}" -i {ca_path}'
            )
    return commands


def _get_trust_commands_darwin(ca_path: Path) -> list[str]:
    """Return shell commands needed to trust the CA on macOS.

    The System keychain covers Safari, Chrome, Arc, Edge, and Firefox on
    recent macOS — the per-app trust stores defer to it.
    """
    return [
        f"sudo security add-trusted-cert -d -r trustRoot "
        f"-k /Library/Keychains/System.keychain {ca_path}"
    ]


def _get_trust_commands(ca_path: Path) -> list[str]:
    """Return shell commands to trust the CA on the current platform."""
    system = platform.system()
    if system == "Linux":
        return _get_trust_commands_linux(ca_path)
    elif system == "Darwin":
        return _get_trust_commands_darwin(ca_path)
    elif system == "Windows":
        raise NotImplementedError("Windows CA trust installation not yet implemented")
    else:
        raise NotImplementedError(f"Unsupported platform: {system}")


def _print_trust_commands(ca_path: Path, output_format: str = "human") -> None:
    """Print the trust commands in the requested format."""
    commands = _get_trust_commands(ca_path)
    if output_format == "json":
        import json

        print(json.dumps({"ca_path": str(ca_path), "commands": commands}))
    elif output_format == "shell":
        print("#!/usr/bin/env bash")
        print("set -euo pipefail")
        for cmd in commands:
            print(cmd)
    else:
        msg.info(
            "Run the following to trust the CA:\n\n" + "    " + "\n    ".join(commands)
        )


def _self_signed(fqdn: str, namespace: str) -> None:
    """Create a self-signed CA and leaf cert, update ingress."""
    _create_self_signed_ca()
    _issue_leaf_cert(fqdn, namespace)
    _update_ingress_tls(fqdn, namespace)


def _run_via_ssh(host: str, command: str) -> str:
    """Run a command on a remote host via SSH and return stdout."""
    result = subprocess.run(
        ["ssh", host, command],
        check=True,
        text=True,
        capture_output=True,
    )
    return result.stdout


@cli.subcommand(
    "infra",
    "tls",
    self_signed=Arg("--self-signed", help="Create a self-signed CA and certificate"),
    trust=Arg(
        "--trust",
        help="SSH host to fetch CA from and install into local trust store",
    ),
    setup=Arg(
        "--setup",
        help="SSH host: create certs remotely, then fetch and trust the CA locally",
    ),
    status=Arg("--status", help="Show current TLS configuration"),
    fqdn=Arg("--fqdn", help="Certificate FQDN (default: localhost)"),
    namespace=Arg("--namespace", help="Kubernetes namespace"),
    output=Arg("--output", help="Output format for trust commands: human, json, shell"),
)
def tls(
    self_signed: bool = False,
    trust: Optional[str] = None,
    setup: Optional[str] = None,
    status: bool = False,
    fqdn: str = "localhost",
    namespace: str = DEFAULT_NAMESPACE,
    output: str = "human",
) -> None:
    """Manage TLS certificates for local cluster access.

    Use --self-signed when you have direct kubectl access to the cluster.
    Use --setup HOST to do everything from your laptop over SSH.
    Use --trust HOST to fetch and install an existing CA from a remote cluster.
    """
    if status:
        _show_status(namespace)
        return
    if setup:
        _setup_via_ssh(setup, fqdn=fqdn, namespace=namespace, output=output)
        return
    if self_signed:
        _self_signed(fqdn=fqdn, namespace=namespace)
        ca_path = _fetch_ca_pem(Path.home() / ".prodigy-teams" / "ca.crt")
        _print_trust_commands(ca_path, output_format=output)
        return
    if trust:
        _trust_via_ssh(trust, output=output)
        return
    msg.warn(
        "No action specified. Use --self-signed, --setup HOST, --trust HOST, or --status."
    )


def _setup_via_ssh(host: str, fqdn: str, namespace: str, output: str = "human") -> None:
    """SSH into host, create certs, copy CA back, print trust commands."""
    import os

    msg.info(f"Connecting to {host}...")
    # When ellf-cli is installed in a venv on the remote rather than system-
    # wide, system `python3` can't import ellf_cli. Allow the user to point us
    # at a specific interpreter on the remote via $ELLF_REMOTE_PYTHON.
    remote_python = os.environ.get("ELLF_REMOTE_PYTHON", "python3")
    remote_cmd = (
        f'KUBECONFIG=~/.kube/config {remote_python} -c "'
        f"from ellf_cli.commands.infra.tls import _self_signed; "
        f"_self_signed(fqdn='{fqdn}', namespace='{namespace}')"
        f'"'
    )
    try:
        _run_via_ssh(host, remote_cmd)
    except subprocess.CalledProcessError as e:
        msg.fail(f"Remote command failed:\n{e.stderr}")
        raise SystemExit(1)
    _trust_via_ssh(host, output=output)


def _trust_via_ssh(host: str, output: str = "human") -> None:
    """Fetch the CA cert from a remote cluster via SSH and print trust commands."""
    msg.info(f"Fetching CA certificate from {host}...")
    import base64

    ca_b64 = (
        _run_via_ssh(
            host,
            f"KUBECONFIG=~/.kube/config kubectl get secret {CA_SECRET_NAME}"
            f" -n {CERT_MANAGER_NAMESPACE}"
            f" -o jsonpath='{{.data.ca\\.crt}}'",
        )
        .strip()
        .strip("'")
    )
    if not ca_b64:
        msg.fail("Could not read CA cert from remote cluster")
        raise SystemExit(1)
    ca_pem = base64.b64decode(ca_b64)
    ca_path = Path.home() / ".prodigy-teams" / "ca.crt"
    ca_path.parent.mkdir(parents=True, exist_ok=True)
    ca_path.write_bytes(ca_pem)
    msg.good(f"CA certificate written to {ca_path}")
    _print_trust_commands(ca_path, output_format=output)


def _show_status(namespace: str) -> None:
    """Show current TLS configuration."""
    # Check ClusterIssuer
    result = subprocess.run(
        ["kubectl", "get", "clusterissuer", LOCAL_CA_ISSUER_NAME],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        msg.good(f"ClusterIssuer: {LOCAL_CA_ISSUER_NAME}")
    else:
        msg.warn("No self-signed CA ClusterIssuer found")
    # Check leaf certificate
    expiry = _kubectl_get_jsonpath(
        f"certificate/{LEAF_CERT_NAME}",
        namespace,
        "{.status.notAfter}",
    )
    if expiry:
        msg.good(f"Certificate: {LEAF_CERT_NAME} (expires {expiry})")
    else:
        msg.warn(f"No certificate {LEAF_CERT_NAME} found")
    # Check ingress TLS
    tls_secret = _kubectl_get_jsonpath(
        "ingress/prodigy-teams-broker",
        namespace,
        "{.spec.tls[0].secretName}",
    )
    if tls_secret:
        msg.good(f"Ingress TLS: {tls_secret}")
    else:
        msg.info("Ingress: no TLS configured (serving HTTP)")
