"""ellf infra register — register a cluster with PAM."""

import json
from pathlib import Path

import srsly
from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import BrokerCreating, BrokerUpdating

from ...cli import cli
from ...messages import Messages

CLOUD_PROVIDERS = ("gcp", "k3s", "aws")


@cli.subcommand(
    "infra",
    "register",
    name=Arg("--name", help="Human-readable name for the cluster"),
    domain=Arg(
        "--domain", help="Public FQDN of the cluster (e.g. cluster.example.com)"
    ),
    cloud_provider=Arg(
        "--cloud-provider",
        help=f"Cloud provider: {', '.join(CLOUD_PROVIDERS)}",
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def register(
    name: str,
    domain: str,
    cloud_provider: str,
    as_json: bool = False,
) -> None:
    """Register a new cluster with PAM and write credentials to cluster-creds.json."""
    from .._state import get_auth_state, get_root_cfg, get_saved_settings

    if cloud_provider not in CLOUD_PROVIDERS:
        msg.fail(
            f"Unknown cloud provider '{cloud_provider}'. "
            f"Choose from: {', '.join(CLOUD_PROVIDERS)}"
        )
        raise SystemExit(1)
    auth = get_auth_state()
    client = auth.client
    org_id = auth.org_id
    # Idempotent on (org_id, name): list and filter client-side rather than
    # `broker.read(name=...)`, which has historically returned the wrong record
    # when the name doesn't disambiguate (no LIMIT 1 / ORDER BY guarantees in
    # the PAM-side query). Address-based lookup also doesn't work as a
    # disambiguator because two clusters with the same human-readable domain
    # are valid (e.g. two `localhost`-served dev clusters in the same org).
    # page_size is capped at 100 server-side; iterate pages so this still
    # works in larger orgs.
    existing = next(
        (
            b
            for b in client.broker.all(page_size=100)
            if b.name == name and b.org_id == org_id
        ),
        None,
    )
    if existing is None:
        body = BrokerCreating(
            name=name,
            org_id=org_id,
            address=domain,
            cloud_provider=cloud_provider,
            public_key="",
            state="creating",
            cloud={},
        )
        broker = client.broker.create(body)
    else:
        update_body = BrokerUpdating(
            id=existing.id,
            name=name,
            address=domain,
            cloud_provider=cloud_provider,
            state="creating",
            cloud={},
        )
        broker = client.broker.update(update_body)
    creds = client.broker.credentials(broker_id=broker.id)
    creds_data = {
        "broker_id": str(creds.broker_id),
        "container_sa_key": creds.secrets.container_sa_key,
        "container_registry": creds.image.registry,
        "prodigy_license_key": creds.secrets.prodigy_license_key,
        "target_broker_version": creds.image.broker_version,
        "target_cpl_version": creds.image.cpl_version,
    }
    creds_path = Path("cluster-creds.json")
    srsly.write_json(creds_path, creds_data)
    # Persist the broker id locally so subsequent `ellf` commands resolve the
    # cluster identity from saved-defaults instead of looking it up by address
    # (which is brittle when the user later sets `broker_host` to a tunnel URL
    # like `https://localhost:8443` that doesn't match the registered domain).
    settings = get_saved_settings()
    prior_broker_id = settings.broker_id
    settings.broker_id = broker.id
    settings.save(get_root_cfg().saved_settings_path)
    # Any cached broker access token from a previous broker_id is now stale.
    # The cache is keyed by broker_host; if the broker behind that host has
    # changed identity (re-registered cluster, name reused, tear-down + redeploy),
    # the cached token will be rejected with 401 by the new broker.
    if prior_broker_id is not None and prior_broker_id != broker.id:
        secrets = auth.secrets
        secrets.broker_tokens.clear()
        secrets.save(get_root_cfg().secrets_path)
        msg.info("  Cleared stale broker token cache (broker_id changed)")
    if as_json:
        print(json.dumps(creds_data, indent=2))
    else:
        action = "updated existing" if existing else "registered new"
        msg.good(f"Cluster {action} with PAM")
        msg.info(f"  Broker ID:    {creds.broker_id}")
        msg.info(f"  Wrote credentials to {creds_path}")
