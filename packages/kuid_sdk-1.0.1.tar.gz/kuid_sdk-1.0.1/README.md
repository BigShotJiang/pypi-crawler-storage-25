# KUID SDK for Python

Official Python SDK for the KUID API.

## Install

```bash
pip install kuid-sdk
```

## Quick start

```python
from kuid_sdk import KuidClient

client = KuidClient("YOUR_API_KEY")
address = client.get_address("AO-LUA-CAC-KDIA")

print(address.to_dict())
print(client.get_navigation_url(address.latitude, address.longitude))
```

## Normalized response

```python
{
    "kuid": "AO-LUA-CAC-KDIA",
    "address": "Avenida Deolinda Rodrigues",
    "latitude": -8.82,
    "longitude": 13.24,
}
```

## Features

- `KuidClient` as the main entrypoint.
- `get_address(kuid)` with KUID validation.
- In-memory cache with a 5 minute TTL.
- Typed exceptions for invalid input, API failures, network failures, and parsing issues.
- `get_navigation_url(lat, lng)` helper.

## Error handling

```python
from kuid_sdk import InvalidKuidError, KuidApiError, KuidClient

client = KuidClient("YOUR_API_KEY")

try:
    client.get_address("AO-LUA-CAC-KDIA")
except InvalidKuidError as error:
    print(error)
except KuidApiError as error:
    print(error.status_code, error)
```

## Run the example

```bash
set KUID_API_KEY=YOUR_API_KEY
python examples/basic_usage.py
```

## Run tests

```bash
python -m unittest discover -s tests
```

## Build for PyPI

```bash
python -m pip install -e .[dev]
python -m build
python -m twine check dist/*
```

## Publish to PyPI

```bash
python -m twine upload dist/*
```
