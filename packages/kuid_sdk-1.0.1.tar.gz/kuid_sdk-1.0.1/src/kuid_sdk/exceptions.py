class KuidError(Exception):
    """Base exception raised by the KUID SDK."""


class InvalidKuidError(KuidError):
    """Raised when a KUID does not match the expected format."""

    def __init__(self, kuid: str) -> None:
        super().__init__(
            f"Invalid KUID format: {kuid}. Expected format: AA-BBB-CCC-1234."
        )


class KuidApiError(KuidError):
    """Raised when the API returns a non-success response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(message)


class KuidNetworkError(KuidError):
    """Raised when an HTTP request fails before a valid response is received."""


class KuidParseError(KuidError):
    """Raised when the API response cannot be normalized."""
