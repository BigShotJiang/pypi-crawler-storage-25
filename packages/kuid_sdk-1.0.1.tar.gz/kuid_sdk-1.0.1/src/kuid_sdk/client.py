from __future__ import annotations

import re
import time
from typing import Any, Optional

import requests
from requests import Response, Session
from requests.exceptions import RequestException

from .exceptions import (
    InvalidKuidError,
    KuidApiError,
    KuidError,
    KuidNetworkError,
    KuidParseError,
)
from .models import KuidAddress

DEFAULT_BASE_URL = "https://kuidapi.ndeas.cloud/api/v1"
KUID_REGEX = re.compile(r"^[A-Z]{2}-[A-Z]{3}-[A-Z]{3}-[A-Z0-9]{4}$")


class _CacheEntry:
    def __init__(self, value: KuidAddress, expires_at: float) -> None:
        self.value = value
        self.expires_at = expires_at

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires_at


class KuidClient:
    """Main SDK entrypoint for interacting with the KUID API."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        session: Optional[Session] = None,
        cache_ttl_seconds: int = 300,
        timeout: int = 10,
    ) -> None:
        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()
        self.cache_ttl_seconds = cache_ttl_seconds
        self.timeout = timeout
        self._cache: dict[str, _CacheEntry] = {}

        if not self.api_key:
            raise KuidError("API key cannot be empty.")

    def get_address(self, kuid: str) -> KuidAddress:
        """Fetch and normalize an address by its KUID."""
        normalized_kuid = kuid.strip().upper()
        self._validate_kuid(normalized_kuid)
        self._evict_expired_entries()

        cached = self._cache.get(normalized_kuid)
        if cached and not cached.is_expired:
            return cached.value

        try:
            response = self.session.get(
                f"{self.base_url}/addresses/{normalized_kuid}/",
                headers={
                    "Authorization": f"ApiKey {self.api_key}",
                    "Accept": "application/json",
                },
                timeout=self.timeout,
            )
        except RequestException as error:
            raise KuidNetworkError(f"Request failed: {error}") from error

        if not response.ok:
            raise KuidApiError(
                response.status_code,
                self._build_api_error_message(response),
            )

        payload = self._decode_json(response)
        address = self._normalize(payload)
        self._cache[normalized_kuid] = _CacheEntry(
            value=address,
            expires_at=time.time() + self.cache_ttl_seconds,
        )
        return address

    def is_valid(self, kuid: str) -> bool:
        """Return True when the KUID matches the expected format."""
        return bool(KUID_REGEX.fullmatch(kuid.strip().upper()))

    def get_navigation_url(self, lat: Optional[float], lng: Optional[float]) -> str:
        """Return a Google Maps navigation URL for the provided coordinates."""
        if lat is None or lng is None:
            raise KuidError("Latitude and longitude are required for navigation URLs.")
        return f"https://maps.google.com/?q={lat},{lng}"

    def clear_cache(self) -> None:
        """Clear all cached addresses from memory."""
        self._cache.clear()

    def _validate_kuid(self, kuid: str) -> None:
        if not KUID_REGEX.fullmatch(kuid):
            raise InvalidKuidError(kuid)

    def _evict_expired_entries(self) -> None:
        expired_keys = [
            key for key, entry in self._cache.items() if entry.is_expired
        ]
        for key in expired_keys:
            self._cache.pop(key, None)

    def _decode_json(self, response: Response) -> Any:
        try:
            return response.json()
        except ValueError as error:
            raise KuidParseError(f"Invalid JSON response: {error}") from error

    def _normalize(self, payload: Any) -> KuidAddress:
        if not isinstance(payload, dict):
            raise KuidParseError("Expected a JSON object response.")

        kuid = payload.get("kuid")
        description = payload.get("description")
        latest_location = payload.get("latest_location")

        if not isinstance(kuid, str) or not isinstance(description, str):
            raise KuidParseError(
                "Response missing required fields: kuid or description."
            )

        latitude: Optional[float] = None
        longitude: Optional[float] = None

        if latest_location is not None:
            if not isinstance(latest_location, dict):
                raise KuidParseError("latest_location must be an object.")

            latitude = self._to_float(latest_location.get("latitude"))
            longitude = self._to_float(latest_location.get("longitude"))

        return KuidAddress(
            kuid=kuid,
            address=description,
            latitude=latitude,
            longitude=longitude,
        )

    def _to_float(self, value: Any) -> Optional[float]:
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        raise KuidParseError(f"Expected numeric coordinate, got {value!r}.")

    def _build_api_error_message(self, response: Response) -> str:
        if not response.text:
            return f"API request failed with status {response.status_code}."

        try:
            payload = response.json()
        except ValueError:
            return f"API request failed with status {response.status_code}."

        if isinstance(payload, dict):
            detail = payload.get("detail") or payload.get("message") or payload.get("error")
            if isinstance(detail, str) and detail.strip():
                return (
                    f"API request failed with status {response.status_code}: {detail}"
                )

        return f"API request failed with status {response.status_code}."


class Kuid(KuidClient):
    """Backward-compatible alias for earlier SDK naming."""
