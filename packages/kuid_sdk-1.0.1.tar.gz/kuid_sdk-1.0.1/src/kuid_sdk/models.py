from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class KuidAddress:
    """Normalized KUID address payload returned by the SDK."""

    kuid: str
    address: str
    latitude: Optional[float]
    longitude: Optional[float]

    def to_dict(self) -> dict[str, object]:
        """Return the address as a serializable normalized payload."""
        return {
            "kuid": self.kuid,
            "address": self.address,
            "latitude": self.latitude,
            "longitude": self.longitude,
        }
