import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from kuid_sdk import (
    InvalidKuidError,
    KuidApiError,
    KuidClient,
    KuidNetworkError,
    KuidParseError,
)


class FakeResponse:
    def __init__(self, status_code=200, payload=None, text=None):
        self.status_code = status_code
        self._payload = payload
        self.text = text if text is not None else ""

    @property
    def ok(self):
        return 200 <= self.status_code < 300

    def json(self):
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


class FakeSession:
    def __init__(self, response=None, error=None):
        self.response = response
        self.error = error
        self.calls = 0

    def get(self, *args, **kwargs):
        self.calls += 1
        if self.error is not None:
            raise self.error
        return self.response


class KuidClientTests(unittest.TestCase):
    def test_rejects_invalid_kuid(self):
        client = KuidClient("api-key")

        with self.assertRaises(InvalidKuidError):
            client.get_address("invalid")

    def test_normalizes_successful_response(self):
        session = FakeSession(
            response=FakeResponse(
                payload={
                    "kuid": "AO-LUA-CAC-KDIA",
                    "description": "Avenida Deolinda Rodrigues",
                    "latest_location": {
                        "latitude": -8.82,
                        "longitude": 13.24,
                    },
                }
            )
        )
        client = KuidClient("api-key", session=session)

        address = client.get_address("AO-LUA-CAC-KDIA")

        self.assertEqual(address.kuid, "AO-LUA-CAC-KDIA")
        self.assertEqual(address.address, "Avenida Deolinda Rodrigues")
        self.assertEqual(address.latitude, -8.82)
        self.assertEqual(address.longitude, 13.24)

    def test_uses_cache_within_ttl(self):
        session = FakeSession(
            response=FakeResponse(
                payload={
                    "kuid": "AO-LUA-CAC-KDIA",
                    "description": "Avenida Deolinda Rodrigues",
                    "latest_location": None,
                }
            )
        )
        client = KuidClient("api-key", session=session)

        first = client.get_address("AO-LUA-CAC-KDIA")
        second = client.get_address("AO-LUA-CAC-KDIA")

        self.assertEqual(session.calls, 1)
        self.assertEqual(first, second)

    def test_raises_api_error_for_non_success_status(self):
        session = FakeSession(
            response=FakeResponse(
                status_code=404,
                payload={"detail": "Not found"},
                text='{"detail":"Not found"}',
            )
        )
        client = KuidClient("api-key", session=session)

        with self.assertRaises(KuidApiError) as context:
            client.get_address("AO-LUA-CAC-KDIA")

        self.assertEqual(context.exception.status_code, 404)

    def test_raises_network_error_on_request_failure(self):
        import requests

        session = FakeSession(error=requests.exceptions.Timeout("timed out"))
        client = KuidClient("api-key", session=session)

        with self.assertRaises(KuidNetworkError):
            client.get_address("AO-LUA-CAC-KDIA")

    def test_raises_parse_error_for_invalid_payload(self):
        session = FakeSession(response=FakeResponse(payload=["unexpected"]))
        client = KuidClient("api-key", session=session)

        with self.assertRaises(KuidParseError):
            client.get_address("AO-LUA-CAC-KDIA")


if __name__ == "__main__":
    unittest.main()
