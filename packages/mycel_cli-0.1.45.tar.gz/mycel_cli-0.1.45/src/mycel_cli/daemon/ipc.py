from __future__ import annotations

import json
import os
import socket
import hashlib
import tempfile
from collections.abc import Callable
from pathlib import Path
from threading import Event
from typing import Any, TypeAlias

from mycel_cli.daemon import paths as daemon_paths
from mycel_cli.daemon.inbox_cache import read_for_hook


Handler = Callable[[dict[str, Any]], dict[str, Any]]
SocketAddress: TypeAlias = str | tuple[str, int]


class DaemonIpcUnavailable(RuntimeError):
    pass


def socket_path() -> Path:
    root = daemon_paths.mycel_home()
    candidate = root / "run" / "daemon.sock"
    if len(str(candidate).encode()) < 100:
        return candidate
    digest = hashlib.sha256(str(root).encode()).hexdigest()[:16]
    return (
        Path(tempfile.gettempdir())
        / "mycel"
        / _user_namespace()
        / digest
        / "daemon.sock"
    )


def _user_namespace() -> str:
    uid = getattr(os, "getuid", None)
    if uid is not None:
        return str(uid())
    seed = f"{Path.home()}:{os.getenv('USERNAME') or os.getenv('USER') or ''}"
    return hashlib.sha256(seed.encode()).hexdigest()[:16]


def request(
    op: str,
    *,
    timeout: float = 0.2,
    path: Path | None = None,
    **params: Any,
) -> dict[str, Any]:
    payload = {"op": op, **params}
    family, target, _path_target = _endpoint(path)
    try:
        with socket.socket(family, socket.SOCK_STREAM) as client:
            client.settimeout(timeout)
            client.connect(target)
            client.sendall(json.dumps(payload, ensure_ascii=False).encode() + b"\n")
            data = _recv_line(client)
    except OSError as exc:
        raise DaemonIpcUnavailable(str(exc)) from exc
    response = json.loads(data.decode())
    if not isinstance(response, dict):
        raise DaemonIpcUnavailable("daemon IPC response must be a JSON object")
    return response


def serve(
    *,
    stop_event: Event,
    ready_event: Event | None = None,
    path: Path | None = None,
    handler: Handler | None = None,
) -> None:
    family, target, path_target = _endpoint(path)
    if path_target is not None:
        path_target.parent.mkdir(parents=True, exist_ok=True)
        path_target.parent.chmod(0o700)
        _remove_stale_socket(path_target)
    server = socket.socket(family, socket.SOCK_STREAM)
    try:
        if family == socket.AF_INET:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(target)
        if path_target is not None:
            path_target.chmod(0o600)
        server.listen()
        server.settimeout(0.1)
        if ready_event is not None:
            ready_event.set()
        while not stop_event.is_set():
            try:
                conn, _ = server.accept()
            except TimeoutError:
                continue
            with conn:
                try:
                    response = _handle_request(conn, handler or _default_handler)
                except Exception as exc:
                    response = {"status": "error", "message": str(exc)}
                try:
                    conn.sendall(
                        json.dumps(response, ensure_ascii=False).encode() + b"\n"
                    )
                except OSError:
                    continue
    finally:
        server.close()
        if path_target is not None:
            path_target.unlink(missing_ok=True)


def _default_handler(payload: dict[str, Any]) -> dict[str, Any]:
    if payload.get("op") != "drain_for_hook":
        return {"status": "error", "message": "unknown daemon IPC operation"}
    local_id = str(payload.get("local_id") or "")
    if not local_id:
        return {"status": "error", "message": "local_id is required"}
    now = payload.get("now")
    stale_after_seconds = payload.get("stale_after_seconds")
    kwargs: dict[str, Any] = {}
    if now is not None:
        kwargs["now"] = float(now)
    if stale_after_seconds is not None:
        kwargs["stale_after_seconds"] = float(stale_after_seconds)
    return read_for_hook(local_id, **kwargs)


def _handle_request(conn: socket.socket, handler: Handler) -> dict[str, Any]:
    payload = json.loads(_recv_line(conn).decode())
    if not isinstance(payload, dict):
        return {"status": "error", "message": "daemon IPC request must be an object"}
    return handler(payload)


def _recv_line(conn: socket.socket) -> bytes:
    chunks: list[bytes] = []
    while True:
        chunk = conn.recv(4096)
        if not chunk:
            break
        chunks.append(chunk)
        if b"\n" in chunk:
            break
    return b"".join(chunks).split(b"\n", 1)[0]


def _endpoint(path: Path | None = None) -> tuple[int, SocketAddress, Path | None]:
    if _supports_unix_socket():
        target = path or socket_path()
        return socket.AF_UNIX, str(target), target
    if path is not None:
        raise DaemonIpcUnavailable("path daemon IPC requires Unix domain sockets")
    return socket.AF_INET, ("127.0.0.1", _tcp_port()), None


def _supports_unix_socket() -> bool:
    return hasattr(socket, "AF_UNIX")


def _tcp_port() -> int:
    root = daemon_paths.mycel_home()
    digest = hashlib.sha256(str(root).encode()).hexdigest()
    return 20000 + (int(digest[:8], 16) % 20000)


def _remove_stale_socket(path: Path) -> None:
    if not path.exists():
        return
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.05)
            probe.connect(str(path))
    except OSError:
        path.unlink()
        return
    raise RuntimeError(f"daemon IPC socket already in use: {path}")
