from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Mapping

from mycel_cli.group.terminal import get_terminal, freeform_terminal_type_from_env
from mycel_cli.daemon.paths import pending_surface_path, surface_path
from mycel_cli.debug_log import log_debug_event


@dataclass(frozen=True)
class SurfaceRef:
    local_id: str
    terminal_type: str
    target_id: str
    wrapper_pid: int
    wrapper_start_time: float
    registered_at: float
    terminal_context: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class PendingSurfaceRef:
    token: str
    provider: str
    terminal_type: str
    target_id: str
    wrapper_pid: int
    wrapper_start_time: float
    registered_at: float
    terminal_context: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class _ResolvedSurface:
    terminal_type: str
    target_id: str
    wrapper_pid: int
    wrapper_start_time: float
    terminal_context: dict[str, str]


def register_from_env(
    env: Mapping[str, str], *, pid: int | None = None
) -> SurfaceRef | None:
    local_id = str(env.get("MYCEL_LOCAL_ID") or "")
    if not local_id:
        log_debug_event("surface", "surface.register.skipped", reason="no-local-id")
        return None
    if is_group_process(env):
        log_debug_event(
            "surface",
            "surface.register.skipped",
            local_id=local_id,
            reason="group-process",
        )
        return None
    resolved = _resolve_current_surface(
        env,
        marker_id=local_id,
        log_event="surface.register.skipped",
        local_id=local_id,
        pid=pid,
    )
    if resolved is None:
        return None
    ref = SurfaceRef(
        local_id=local_id,
        terminal_type=resolved.terminal_type,
        target_id=resolved.target_id,
        wrapper_pid=resolved.wrapper_pid,
        wrapper_start_time=resolved.wrapper_start_time,
        registered_at=time.time(),
        terminal_context=resolved.terminal_context,
    )
    path = surface_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(ref), ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)
    log_debug_event(
        "surface",
        "surface.registered",
        local_id=local_id,
        details={
            "terminal_type": resolved.terminal_type,
            "target_id": resolved.target_id,
        },
    )
    return ref


def register_pending_from_env(
    env: Mapping[str, str], *, pid: int | None = None
) -> PendingSurfaceRef | None:
    token = str(env.get("MYCEL_BOOTSTRAP_SURFACE_ID") or "")
    provider = str(env.get("MYCEL_PROVIDER") or "")
    if not token or not provider:
        return None
    if is_group_process(env):
        return None
    resolved = _resolve_current_surface(
        env,
        marker_id=token,
        log_event="surface.pending.skipped",
        pid=pid,
    )
    if resolved is None:
        return None
    ref = PendingSurfaceRef(
        token=token,
        provider=provider,
        terminal_type=resolved.terminal_type,
        target_id=resolved.target_id,
        wrapper_pid=resolved.wrapper_pid,
        wrapper_start_time=resolved.wrapper_start_time,
        registered_at=time.time(),
        terminal_context=resolved.terminal_context,
    )
    path = pending_surface_path(token)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(ref), ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)
    log_debug_event(
        "surface",
        "surface.pending.registered",
        details={"provider": provider, "terminal_type": resolved.terminal_type},
    )
    return ref


def _resolve_current_surface(
    env: Mapping[str, str],
    *,
    marker_id: str,
    log_event: str,
    local_id: str | None = None,
    pid: int | None = None,
) -> _ResolvedSurface | None:
    terminal_type = freeform_terminal_type_from_env(env)
    if terminal_type is None:
        log_debug_event(
            "surface",
            log_event,
            local_id=local_id,
            reason="unsupported-terminal",
            details={"term_program": env.get("TERM_PROGRAM")},
        )
        return None
    wrapper_pid = os.getpid() if pid is None else pid
    terminal = get_terminal(terminal_type)
    prepare = getattr(terminal, "prepare_freeform_surface", None)
    if callable(prepare):
        try:
            prepare(marker_id)
        except (OSError, subprocess.SubprocessError) as exc:
            log_debug_event(
                "surface",
                log_event,
                local_id=local_id,
                reason="surface-prepare-failed",
                details={"terminal_type": terminal_type, "error": str(exc)},
            )
            return None
    target_id = terminal.resolve_target_id(wrapper_pid, local_id=marker_id)
    if target_id is None:
        log_debug_event(
            "surface",
            log_event,
            local_id=local_id,
            reason="target-not-resolved",
            details={"terminal_type": terminal_type, "pid": wrapper_pid},
        )
        return None
    return _ResolvedSurface(
        terminal_type=terminal_type,
        target_id=target_id,
        wrapper_pid=wrapper_pid,
        wrapper_start_time=process_start_time(wrapper_pid),
        terminal_context=_terminal_context_from_env(terminal_type, env),
    )


def claim_pending_from_env(local_id: str, env: Mapping[str, str]) -> SurfaceRef | None:
    token = str(env.get("MYCEL_BOOTSTRAP_SURFACE_ID") or "")
    if not token:
        return None
    path = pending_surface_path(token)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        ref = SurfaceRef(
            local_id=local_id,
            terminal_type=str(payload["terminal_type"]),
            target_id=str(payload["target_id"]),
            wrapper_pid=int(payload["wrapper_pid"]),
            wrapper_start_time=float(payload["wrapper_start_time"]),
            registered_at=time.time(),
            terminal_context={
                str(key): str(value)
                for key, value in dict(payload.get("terminal_context") or {}).items()
            },
        )
        _assert_same_process(ref.wrapper_pid, ref.wrapper_start_time)
        _assert_same_target(ref)
    except Exception as exc:
        path.unlink(missing_ok=True)
        log_debug_event(
            "surface",
            "surface.pending.claim_failed",
            local_id=local_id,
            reason=str(exc) or exc.__class__.__name__,
        )
        return None
    target = surface_path(local_id)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(ref), ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, target)
    target.chmod(0o600)
    path.unlink(missing_ok=True)
    log_debug_event(
        "surface",
        "surface.pending.claimed",
        local_id=local_id,
        details={"terminal_type": ref.terminal_type, "target_id": ref.target_id},
    )
    return ref


def lookup(local_id: str) -> SurfaceRef | None:
    path = surface_path(local_id)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        ref = SurfaceRef(
            local_id=str(payload["local_id"]),
            terminal_type=str(payload["terminal_type"]),
            target_id=str(payload["target_id"]),
            wrapper_pid=int(payload["wrapper_pid"]),
            wrapper_start_time=float(payload["wrapper_start_time"]),
            registered_at=float(payload["registered_at"]),
            terminal_context={
                str(key): str(value)
                for key, value in dict(payload.get("terminal_context") or {}).items()
            },
        )
        _assert_same_process(ref.wrapper_pid, ref.wrapper_start_time)
        _assert_same_target(ref)
    except Exception as exc:
        reason = str(exc) or exc.__class__.__name__
        path.unlink(missing_ok=True)
        log_debug_event(
            "surface",
            "surface.lookup.dropped",
            local_id=local_id,
            reason=reason,
        )
        return None
    return ref


def drop(local_id: str) -> None:
    surface_path(local_id).unlink(missing_ok=True)
    log_debug_event("surface", "surface.dropped", local_id=local_id)


def unregister_from_env(
    env: Mapping[str, str],
    *,
    pid: int | None = None,
    start_time: float | None = None,
) -> None:
    local_id = str(env.get("MYCEL_LOCAL_ID") or "")
    if not local_id:
        return
    path = surface_path(local_id)
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        path.unlink(missing_ok=True)
        return
    wrapper_pid = os.getpid() if pid is None else pid
    wrapper_start_time = (
        process_start_time(wrapper_pid) if start_time is None else start_time
    )
    if (
        int(payload.get("wrapper_pid") or -1) == wrapper_pid
        and abs(float(payload.get("wrapper_start_time") or -1) - wrapper_start_time)
        < 0.5
    ):
        path.unlink(missing_ok=True)


def unregister_pending_from_env(env: Mapping[str, str]) -> None:
    token = str(env.get("MYCEL_BOOTSTRAP_SURFACE_ID") or "")
    if token:
        pending_surface_path(token).unlink(missing_ok=True)


def is_group_process(env: Mapping[str, str]) -> bool:
    return bool(env.get("MYCEL_GROUP_ID") or env.get("MYCEL_USER_SESSION"))


def _terminal_context_from_env(
    terminal_type: str, env: Mapping[str, str]
) -> dict[str, str]:
    names = {
        "kitty": ("KITTY_LISTEN_ON",),
        "cmux": ("CMUX_SOCKET_PATH",),
    }.get(terminal_type, ())
    return {name: str(env[name]) for name in names if env.get(name)}


def process_start_time(pid: int) -> float:
    proc_stat = Path("/proc") / str(pid) / "stat"
    if proc_stat.exists():
        ticks = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
        boot_time = _linux_boot_time()
        stat_fields = proc_stat.read_text(encoding="utf-8").split()
        return boot_time + (int(stat_fields[21]) / ticks)
    completed = subprocess.run(
        ["ps", "-o", "lstart=", "-p", str(pid)],
        text=True,
        capture_output=True,
        check=False,
    )
    text = completed.stdout.strip()
    if completed.returncode != 0 or not text:
        raise RuntimeError(f"process {pid} is not running")
    return datetime.strptime(text, "%a %b %d %H:%M:%S %Y").timestamp()


def _assert_same_process(pid: int, start_time: float) -> None:
    os.kill(pid, 0)
    if abs(process_start_time(pid) - start_time) >= 0.5:
        raise RuntimeError("surface wrapper process identity changed")


def _assert_same_target(ref: SurfaceRef) -> None:
    # @@@surface-proof - runtime surfaces are valid only while the terminal backend can rediscover the same target.
    with terminal_context_env(ref.terminal_context):
        terminal = get_terminal(ref.terminal_type)
        target_exists = getattr(terminal, "target_exists", None)
        if callable(target_exists):
            if not bool(target_exists(ref.target_id)):
                raise RuntimeError("surface terminal target disappeared")
            return
        current_target = terminal.resolve_target_id(ref.wrapper_pid)
        if current_target != ref.target_id:
            raise RuntimeError("surface terminal target changed")


class terminal_context_env:
    def __init__(self, values: Mapping[str, str]) -> None:
        self._values = values
        self._previous: dict[str, str | None] = {}

    def __enter__(self) -> None:
        for key, value in self._values.items():
            self._previous[key] = os.environ.get(key)
            os.environ[key] = value

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        for key, value in self._previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _linux_boot_time() -> float:
    for line in Path("/proc/stat").read_text(encoding="utf-8").splitlines():
        if line.startswith("btime "):
            return float(line.split()[1])
    raise RuntimeError("could not read Linux boot time")
