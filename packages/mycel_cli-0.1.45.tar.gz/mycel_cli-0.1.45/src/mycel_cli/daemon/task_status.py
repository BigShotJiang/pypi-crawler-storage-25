from __future__ import annotations

import json
import os
from typing import Any

from mycel_cli.daemon.paths import task_status_path


def read_task_status(task_name: str) -> dict[str, Any] | None:
    path = task_status_path(task_name)
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    if not isinstance(payload, dict):
        return None
    return payload


def write_task_status(task_name: str, payload: dict[str, Any]) -> None:
    path = task_status_path(task_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)
