from __future__ import annotations

import json
import os
import threading
import time
from typing import Any

from mycel_sdk.errors import ApiError, ConnectionClosed, ReplayOverflow

from .inbox_cache import (
    append_notifications,
    notification_fingerprint,
    status_path,
    unread_watermark_ordered,
    write_unread_watermark,
)
from ..debug_log import log_debug_event
from .wake import attempt_wake

TERMINAL_API_STATUS_CODES = frozenset({401, 403, 404})


def stream_once(
    client: Any,
    *,
    local_id: str,
    since_seq: int | None = None,
    backend_base_url: str | None = None,
) -> dict[str, Any]:
    started_at = time.time()
    _write_status(
        local_id,
        {
            "state": "streaming",
            "backend_base_url": backend_base_url,
            "last_stream_started_at": started_at,
            "last_event_at": None,
            "last_error": None,
        },
    )
    try:
        frame = next(client.notifications.stream(since_seq=since_seq))
    except Exception as exc:
        _write_status(
            local_id,
            {
                "state": "streaming",
                "backend_base_url": backend_base_url,
                "last_stream_started_at": started_at,
                "last_event_at": None,
                "last_error": str(exc),
            },
        )
        raise
    return _ingest_stream_frame(
        local_id,
        frame,
        backend_base_url=backend_base_url,
        started_at=started_at,
    )


def drain_once(
    client: Any,
    *,
    local_id: str,
    backend_base_url: str | None = None,
) -> dict[str, Any]:
    started_at = time.time()
    _write_status(
        local_id,
        {
            "state": "active",
            "backend_base_url": backend_base_url,
            "last_drain_started_at": started_at,
            "last_event_at": None,
            "last_error": None,
        },
    )
    try:
        payload = client.notifications.drain()
    except Exception as exc:
        _write_status(
            local_id,
            {
                "state": "active",
                "backend_base_url": backend_base_url,
                "last_drain_started_at": started_at,
                "last_event_at": None,
                "last_error": str(exc),
            },
        )
        raise
    fresh = startup_catchup_ingest(local_id, payload)
    finished_at = time.time()
    _write_status(
        local_id,
        {
            "state": "active",
            "backend_base_url": backend_base_url,
            "last_drain_started_at": started_at,
            "last_event_at": finished_at if fresh else None,
            "last_error": None,
        },
    )
    return {
        "local_id": local_id,
        "count": len(fresh),
        "last_seq": _last_seq(payload),
    }


def reconnect_drain_once(
    client: Any,
    *,
    local_id: str,
    backend_base_url: str | None = None,
) -> dict[str, Any]:
    started_at = time.time()
    _write_status(
        local_id,
        {
            "state": "reconnecting",
            "backend_base_url": backend_base_url,
            "last_drain_started_at": started_at,
            "last_event_at": None,
            "last_error": None,
        },
    )
    try:
        payload = client.notifications.drain()
    except Exception as exc:
        _write_status(
            local_id,
            {
                "state": "reconnecting",
                "backend_base_url": backend_base_url,
                "last_drain_started_at": started_at,
                "last_event_at": None,
                "last_error": str(exc),
            },
        )
        raise
    fresh = reconnect_catchup_ingest(local_id, payload)
    finished_at = time.time()
    last_seq = _last_seq(payload)
    _write_status(
        local_id,
        {
            "state": "reconnecting",
            "backend_base_url": backend_base_url,
            "last_drain_started_at": started_at,
            "last_event_at": finished_at if fresh else None,
            "last_seq": last_seq,
            "last_error": None,
        },
    )
    return {
        "local_id": local_id,
        "count": len(fresh),
        "last_seq": last_seq,
    }


def run_loop(
    client: Any,
    *,
    local_id: str,
    backend_base_url: str | None = None,
    stop_event: threading.Event | None = None,
) -> None:
    startup_drained = False
    consecutive_errors = 0
    last_seq: int | None = None
    while not _is_stopped(stop_event):
        try:
            if _is_stopped(stop_event):
                return
            if not startup_drained:
                result = drain_once(
                    client,
                    local_id=local_id,
                    backend_base_url=backend_base_url,
                )
                last_seq = result["last_seq"]
                startup_drained = True
            last_seq = stream_forever(
                client,
                local_id=local_id,
                since_seq=last_seq,
                backend_base_url=backend_base_url,
                stop_event=stop_event,
            )
            consecutive_errors = 0
        except ReplayOverflow:
            if _is_stopped(stop_event):
                return
            try:
                result = reconnect_drain_once(
                    client,
                    local_id=local_id,
                    backend_base_url=backend_base_url,
                )
            except Exception as exc:
                consecutive_errors = _handle_loop_error(
                    local_id=local_id,
                    backend_base_url=backend_base_url,
                    exc=exc,
                    consecutive_errors=consecutive_errors,
                )
                if consecutive_errors is None:
                    return
                continue
            last_seq = result["last_seq"]
            consecutive_errors = 0
        except Exception as exc:
            consecutive_errors = _handle_loop_error(
                local_id=local_id,
                backend_base_url=backend_base_url,
                exc=exc,
                consecutive_errors=consecutive_errors,
            )
            if consecutive_errors is None:
                return


def _is_stopped(stop_event: threading.Event | None) -> bool:
    return stop_event is not None and stop_event.is_set()


def stream_forever(
    client: Any,
    *,
    local_id: str,
    since_seq: int | None = None,
    backend_base_url: str | None = None,
    stop_event: threading.Event | None = None,
) -> int | None:
    current_seq = since_seq
    started_at = time.time()
    _write_status(
        local_id,
        {
            "state": "streaming",
            "backend_base_url": backend_base_url,
            "last_stream_started_at": started_at,
            "last_event_at": None,
            "last_seq": current_seq,
            "last_error": None,
        },
    )
    try:
        stream_kwargs: dict[str, Any] = {"since_seq": since_seq}
        if stop_event is not None:
            stream_kwargs.update(timeout=1.0, should_stop=stop_event.is_set)
        for frame in client.notifications.stream(**stream_kwargs):
            result = _ingest_stream_frame(
                local_id,
                frame,
                backend_base_url=backend_base_url,
                started_at=started_at,
            )
            current_seq = result["last_seq"]
    except ConnectionClosed:
        return current_seq
    return current_seq


def _ingest_stream_frame(
    local_id: str,
    frame: dict[str, Any],
    *,
    backend_base_url: str | None,
    started_at: float,
) -> dict[str, Any]:
    last_seq = _frame_seq(frame)
    payload = {"notifications": [_notification_from_stream_frame(frame)]}
    fresh = live_ingest(local_id, payload)
    finished_at = time.time()
    _write_status(
        local_id,
        {
            "state": "streaming",
            "backend_base_url": backend_base_url,
            "last_stream_started_at": started_at,
            "last_event_at": finished_at if fresh else None,
            "last_seq": last_seq,
            "last_error": None,
        },
    )
    return {
        "local_id": local_id,
        "count": len(fresh),
        "last_seq": last_seq,
    }


def _is_terminal_error(exc: Exception) -> bool:
    return isinstance(exc, ApiError) and exc.status_code in TERMINAL_API_STATUS_CODES


def _handle_loop_error(
    *,
    local_id: str,
    backend_base_url: str | None,
    exc: Exception,
    consecutive_errors: int,
) -> int | None:
    if _is_terminal_error(exc):
        _write_status(
            local_id,
            {
                "state": "dead",
                "backend_base_url": backend_base_url,
                "last_error_at": time.time(),
                "last_event_at": None,
                "last_error": str(exc),
            },
        )
        return None
    next_count = consecutive_errors + 1
    _write_status(
        local_id,
        {
            "state": "degraded",
            "backend_base_url": backend_base_url,
            "last_error_at": time.time(),
            "last_event_at": None,
            "last_error": str(exc),
            "consecutive_error_count": next_count,
        },
    )
    time.sleep(1.0)
    return next_count


def _write_status(local_id: str, payload: dict[str, Any]) -> None:
    path = status_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)


def live_ingest(local_id: str, payload: dict[str, Any] | None) -> list[dict[str, Any]]:
    fresh = _diff_and_append(local_id, payload)
    if fresh:
        attempt_wake(local_id, fresh)
    return fresh


def startup_catchup_ingest(
    local_id: str, payload: dict[str, Any] | None
) -> list[dict[str, Any]]:
    return _diff_and_append(local_id, payload)


def reconnect_catchup_ingest(
    local_id: str, payload: dict[str, Any] | None
) -> list[dict[str, Any]]:
    fresh = _diff_and_append(local_id, payload)
    if fresh:
        attempt_wake(local_id, fresh)
    return fresh


def _diff_and_append(
    local_id: str, payload: dict[str, Any] | None
) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        raise RuntimeError("notification response did not return a JSON object")
    notifications = payload.get("notifications") or []
    if not isinstance(notifications, list):
        raise RuntimeError("notification response returned invalid notifications")
    fresh, current = _fresh_notifications(
        local_id, [dict(item) for item in notifications]
    )
    fresh.sort(key=lambda item: int(item.get("seq") or 0))
    append_notifications(local_id, fresh)
    if fresh:
        log_debug_event(
            "inbox",
            "inbox.appended",
            local_id=local_id,
            details={"count": len(fresh)},
        )
    deduped_count = len(notifications) - len(fresh)
    if deduped_count:
        log_debug_event(
            "inbox",
            "inbox.deduped",
            local_id=local_id,
            details={"count": deduped_count},
        )
    write_unread_watermark(local_id, current)
    return fresh


def _notification_from_stream_frame(frame: dict[str, Any]) -> dict[str, Any]:
    metadata = frame.get("metadata")
    if not isinstance(metadata, dict):
        raise RuntimeError("notification stream frame did not include metadata")
    notification = dict(metadata)
    notification["seq"] = _frame_seq(frame)
    if frame.get("fingerprint") is not None:
        notification["fingerprint"] = str(frame["fingerprint"])
    return notification


def _frame_seq(frame: dict[str, Any]) -> int:
    return int(frame["seq"])


def _last_seq(payload: dict[str, Any]) -> int | None:
    notifications = payload.get("notifications") if isinstance(payload, dict) else None
    if not isinstance(notifications, list):
        return None
    values = [
        int(item["seq"])
        for item in notifications
        if isinstance(item, dict) and item.get("seq") is not None
    ]
    if not values:
        return None
    return max(values)


def _fresh_notifications(
    local_id: str, notifications: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[str]]:
    current = [notification_fingerprint(item) for item in notifications]
    previous_ordered = unread_watermark_ordered(local_id)
    previous = set(previous_ordered)
    fresh = [
        item for item in notifications if notification_fingerprint(item) not in previous
    ]
    if not notifications:
        return fresh, []
    return fresh, [*previous_ordered, *current]
