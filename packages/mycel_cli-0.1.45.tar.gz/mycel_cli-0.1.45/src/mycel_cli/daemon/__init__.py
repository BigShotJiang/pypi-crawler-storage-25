"""Local daemon helpers for cel."""
