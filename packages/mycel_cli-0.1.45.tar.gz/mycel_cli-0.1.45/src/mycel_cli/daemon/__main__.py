from __future__ import annotations

from mycel_cli.daemon.main import run_daemon


run_daemon()
