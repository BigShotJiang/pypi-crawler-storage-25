from __future__ import annotations

import json
import os
import time
from collections.abc import Iterable
from typing import Any

from mycel_cli.daemon.paths import (
    cursor_path,
    inbox_path,
    subscriber_status_path as status_path,
    subscriber_watermark_path as watermark_path,
)

MAX_UNREAD_WATERMARK_FINGERPRINTS = 512


def append_notifications(local_id: str, notifications: list[dict[str, Any]]) -> None:
    if not notifications:
        return
    path = inbox_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for item in notifications:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    path.chmod(0o600)


def unread_watermark(local_id: str) -> set[str]:
    return set(unread_watermark_ordered(local_id))


def unread_watermark_ordered(local_id: str) -> list[str]:
    path = watermark_path(local_id)
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    values = payload.get("fingerprints") if isinstance(payload, dict) else None
    if not isinstance(values, list):
        return []
    return [str(item) for item in values]


def write_unread_watermark(local_id: str, fingerprints: Iterable[str]) -> None:
    path = watermark_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    ordered = list(dict.fromkeys(fingerprints))[-MAX_UNREAD_WATERMARK_FINGERPRINTS:]
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps({"fingerprints": ordered}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, path)
    path.chmod(0o600)


def notification_fingerprint(notification: dict[str, Any]) -> str:
    message_id = notification.get("message_id")
    if message_id is not None:
        stable_message = {
            "chat_id": notification.get("chat_id"),
            "message_id": message_id,
            "notification_type": notification.get("notification_type"),
        }
        return json.dumps(
            stable_message,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    server_fingerprint = notification.get("fingerprint")
    if server_fingerprint is not None:
        return str(server_fingerprint)
    stable = {
        "chat_id": notification.get("chat_id"),
        "event_type": notification.get("event_type"),
        "message_id": notification.get("message_id"),
        "message_seq": notification.get("message_seq"),
        "notification_type": notification.get("notification_type"),
        "relationship_id": notification.get("relationship_id"),
        "request_id": notification.get("request_id"),
        "sender_name": notification.get("sender_name"),
        "unread_count": notification.get("unread_count"),
    }
    return json.dumps(stable, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def read_for_hook(
    local_id: str,
    *,
    now: float | None = None,
    stale_after_seconds: float = 90.0,
) -> dict[str, Any]:
    notifications = _read_new_notifications(local_id)
    if notifications:
        return {"status": "ok", "notifications": notifications}
    stale = _stale_status_message(
        local_id,
        now=time.time() if now is None else now,
        stale_after_seconds=stale_after_seconds,
    )
    if stale:
        return {"status": "stale", "notifications": [], "message": stale}
    return {"status": "ok", "notifications": []}


def _read_new_notifications(local_id: str) -> list[dict[str, Any]]:
    path = inbox_path(local_id)
    if not path.exists():
        return []
    offset = _read_cursor(local_id)
    size = path.stat().st_size
    if offset > size:
        offset = 0
    notifications: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        handle.seek(offset)
        for line in handle:
            text = line.strip()
            if not text:
                continue
            payload = json.loads(text)
            if isinstance(payload, dict):
                notifications.append(payload)
        next_offset = handle.tell()
    _write_cursor(local_id, next_offset)
    return notifications


def _read_cursor(local_id: str) -> int:
    path = cursor_path(local_id)
    if not path.exists():
        return 0
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    return int(payload.get("offset") or 0)


def _write_cursor(local_id: str, offset: int) -> None:
    path = cursor_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"offset": offset}) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)


def _stale_status_message(
    local_id: str, *, now: float, stale_after_seconds: float
) -> str | None:
    path = status_path(local_id)
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    if payload.get("state") == "streaming" and not payload.get("last_error"):
        return None
    latest = (
        payload.get("last_stream_started_at")
        or payload.get("last_drain_started_at")
        or payload.get("last_error_at")
        or payload.get("last_event_at")
    )
    if latest is None:
        return f"local Mycel inbox subscriber is stale for {local_id}"
    if now - float(latest) > stale_after_seconds:
        return f"local Mycel inbox subscriber is stale for {local_id}"
    return None
