from __future__ import annotations

import json
import os
import time
from typing import Any

from mycel_cli.daemon.paths import debug_config_path, debug_log_path

_SECRET_KEYS = frozenset(
    {
        "auth_token",
        "token",
        "password",
        "secret",
        "authorization",
        "api_key",
    }
)


def debug_enabled() -> bool:
    path = debug_config_path()
    if not path.exists():
        return False
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    return bool(payload.get("enabled"))


def set_debug_enabled(enabled: bool) -> None:
    path = debug_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"enabled": enabled}, ensure_ascii=False) + "\n")
    os.replace(tmp, path)
    path.chmod(0o600)


def log_debug_event(
    component: str,
    event: str,
    *,
    local_id: str | None = None,
    chat_id: str | None = None,
    message_id: str | None = None,
    reason: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    if not debug_enabled():
        return
    payload = {
        "ts": time.time(),
        "component": component,
        "event": event,
    }
    if local_id:
        payload["local_id"] = local_id
    if chat_id:
        payload["chat_id"] = chat_id
    if message_id:
        payload["message_id"] = message_id
    if reason:
        payload["reason"] = reason
    if details:
        payload["details"] = _sanitize(details)
    path = debug_log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
    path.chmod(0o600)


def _sanitize(value: Any) -> Any:
    if isinstance(value, dict):
        clean = {}
        for key, item in value.items():
            if str(key).lower() in _SECRET_KEYS:
                continue
            clean[str(key)] = _sanitize(item)
        return clean
    if isinstance(value, list):
        return [_sanitize(item) for item in value]
    if isinstance(value, str) and len(value) > 240:
        return value[:237] + "..."
    return value
