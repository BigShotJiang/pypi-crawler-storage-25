"""CLI surface for local Mycel daemon and inbox lifecycle."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import typer

from mycel_cli.binding_resolver import resolve_binding
from mycel_cli.config import base_url_line, effective_base_url
from mycel_cli.daemon.inbox_context import read_inbox_context
from mycel_cli.daemon.paths import debug_config_path, debug_log_path
from mycel_cli.daemon.service import (
    group_loop_summary,
    identity_backend_summary,
    identity_summary,
    freeform_surface_summary,
    subscriber_summary,
)
from mycel_cli.debug_log import debug_enabled, set_debug_enabled
from mycel_cli.group._cli import spawn as _spawn_mod
from mycel_cli.group._cli.authority import authorize_operation
from mycel_cli.group._cli.helpers import is_daemon_running, require_global
from mycel_cli.group._cli.spawn import launch_daemon
from mycel_cli.providers.stop_hooks import (
    install_stop_hooks,
    remove_stop_hooks,
    stop_hook_status,
)
from mycel_cli.group._process.processes import request_termination, wait_for_exit
from mycel_cli.group._state.globals_ import load_global, new_global, save_global
from mycel_cli.group._state.groups import delete_all, list_groups, load_group
from mycel_cli.group._state.roles import (
    find_supervisor,
    iter_reviewers,
    iter_workers,
)
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group.agent_types import PROVIDER_ORDER
from mycel_cli.group.workflow_policy import OperationName
from mycel_cli.identity_store import IdentityStore
from mycel_cli.providers.hooks import (
    ensure_provider_hooks,
    provider_hook_status,
    remove_provider_hooks,
)

_log = logging.getLogger("mycel_cli.self")

_rich_markup_mode = None if not sys.stdout.isatty() else "rich"

self_app = typer.Typer(
    help="manage the local Mycel daemon and inbox",
    rich_markup_mode=_rich_markup_mode,
)
self_inbox_app = typer.Typer(
    help="read local inbox notifications",
    rich_markup_mode=_rich_markup_mode,
)
self_debug_app = typer.Typer(
    help="turn local debug tracing on or off",
    rich_markup_mode=_rich_markup_mode,
)
self_app.add_typer(self_inbox_app, name="inbox")
self_app.add_typer(self_debug_app, name="debug")


@self_app.command("start", help="Start the local Mycel daemon.")
def self_start(
    foreground: bool = typer.Option(
        False, "-f", "--foreground", help="前台运行本地 Mycel 服务"
    ),
) -> None:
    authorize_operation(OperationName.SELF_START)
    _ensure_provider_hooks()
    install_stop_hooks("all")
    global_state = load_global()
    if global_state is None:
        global_state = new_global()
    if is_daemon_running(global_state):
        typer.echo("Mycel daemon 已在运行", err=True)
        raise typer.Exit(1)
    launch_daemon(global_state, foreground)


@self_app.command("stop", help="Stop the local Mycel daemon.")
def self_stop() -> None:
    authorize_operation(OperationName.SELF_STOP)
    _stop_daemon_from_global(require_global())
    typer.echo("Mycel daemon 已停止。")


@self_app.command(
    "uninstall", help="Stop the local Mycel daemon and remove installed hooks."
)
def self_uninstall() -> None:
    authorize_operation(OperationName.SELF_UNINSTALL)
    global_state = load_global()
    if global_state is not None:
        _stop_daemon_from_global(global_state)
    _remove_mycel_hooks()
    typer.echo("Mycel hooks removed.")


@self_app.command("status", help="Show local Mycel daemon status.")
def self_status() -> None:
    global_state = load_global()
    base_url = effective_base_url()
    owner_line = _owner_summary_line()
    if global_state is None:
        typer.echo(
            "\n".join(["Mycel daemon 未启动。", owner_line, base_url_line(base_url)])
        )
        return

    daemon_running = is_daemon_running(global_state)
    if global_state.get("stopped"):
        state_label = "已锁定 (stopped)"
    elif daemon_running:
        state_label = "运行中"
    else:
        state_label = "异常 (本地服务未运行)"

    lines = [f"状态: {state_label}", owner_line, base_url_line(base_url)]
    pid = global_state.get("daemon_pid")
    if pid:
        lines.append(
            f"Daemon PID: {pid}" + (" (运行中)" if daemon_running else " (已退出)")
        )
    lines.append(identity_summary())
    lines.append(identity_backend_summary())
    lines.append(subscriber_summary(daemon_running=daemon_running))
    lines.append(freeform_surface_summary())
    lines.append(group_loop_summary(daemon_running=daemon_running))
    lines.append(_hook_summary_line())

    groups = []
    for name in list_groups():
        group = load_group(name)
        if group is None:
            continue
        groups.append((name, group))

    if not groups:
        lines.append("")
        lines.append(
            "没有 group。用 cel group create 创建；group id 来自后端 chat id。"
        )
    else:
        lines.append("")
        for name, group in groups:
            workers = [worker["session"] for worker in iter_workers(group)]
            supervisor = find_supervisor(group)
            tasks = list_tasks(name)
            done = sum(1 for task in tasks if task["status"] == "completed")
            running = sum(1 for task in tasks if task["status"] == "in_progress")
            pending = sum(1 for task in tasks if task["status"] == "pending")
            workers_text = ", ".join(workers) if workers else "无"
            supervisor_text = supervisor["session"] if supervisor else "(unclaimed)"
            lines.append(
                f"  {name} — supervisor: {supervisor_text} | workers: {workers_text} | tasks: {done} done, {running} running, {pending} pending ({len(tasks)} total)"
            )

    typer.echo("\n".join(lines))


def _hook_summary_line() -> str:
    inbox = ", ".join(
        f"{provider} {_installed_label(provider_hook_status(provider=provider))}"
        for provider in PROVIDER_ORDER
    )
    stop_status = stop_hook_status()
    stop = ", ".join(
        f"{provider} {_installed_label(stop_status[provider])}"
        for provider in PROVIDER_ORDER
    )
    return f"Hooks: inbox {inbox} | stop {stop}"


def _owner_summary_line() -> str:
    owner_id = IdentityStore.from_env().current_user_id()
    if owner_id is None:
        return "Owner: not logged in (run cel login <email-or-username>)"
    return f"Owner: logged in as {owner_id}"


def _installed_label(status: dict) -> str:
    return "installed" if status.get("installed") else "missing"


@self_debug_app.command("on", help="Enable local JSONL debug tracing.")
def self_debug_on() -> None:
    set_debug_enabled(True)
    typer.echo("Debug: on")
    typer.echo(f"Log: {debug_log_path()}")


@self_debug_app.command("off", help="Disable local JSONL debug tracing.")
def self_debug_off() -> None:
    set_debug_enabled(False)
    typer.echo("Debug: off")


@self_debug_app.command("status", help="Show local debug tracing status.")
def self_debug_status() -> None:
    state = "on" if debug_enabled() else "off"
    typer.echo(f"Debug: {state}")
    typer.echo(f"Config: {debug_config_path()}")
    typer.echo(f"Log: {debug_log_path()}")


@self_debug_app.command("tail", help="Print recent local debug trace lines.")
def self_debug_tail(
    lines: int = typer.Option(80, "--lines", "-n", help="number of lines to print"),
) -> None:
    path = debug_log_path()
    if not path.exists():
        return
    content = path.read_text(encoding="utf-8").splitlines()
    typer.echo("\n".join(content[-lines:]))


@self_debug_app.command("doctor", help="Show one-shot local runtime debug context.")
def self_debug_doctor(
    lines: int = typer.Option(20, "--lines", "-n", help="debug trace lines to include"),
) -> None:
    state = "on" if debug_enabled() else "off"
    global_state = load_global() or {}
    daemon_running = is_daemon_running(global_state)
    output = [
        f"Debug: {state}",
        f"Config: {debug_config_path()}",
        f"Log: {debug_log_path()}",
        identity_summary(),
        subscriber_summary(daemon_running=daemon_running),
        freeform_surface_summary(),
        group_loop_summary(daemon_running=daemon_running),
        _hook_summary_line(),
    ]
    path = debug_log_path()
    if path.exists() and lines > 0:
        output.append("")
        output.append(f"Recent Debug Lines ({lines}):")
        output.extend(path.read_text(encoding="utf-8").splitlines()[-lines:])
    typer.echo("\n".join(output))


@self_app.command(
    "reset", help="Stop the local Mycel daemon and clear local group state."
)
def self_reset() -> None:
    authorize_operation(OperationName.SELF_RESET)
    global_state = load_global()

    for group_id in list_groups():
        try:
            group = load_group(group_id)
        except Exception as exc:
            _log.warning(
                "self reset: failed to load group %r, skipping surface close: %s",
                group_id,
                exc,
            )
            continue
        if group is None:
            continue
        supervisor = find_supervisor(group)
        if supervisor:
            _spawn_mod.kill_and_close_worker(supervisor, group)
        for worker in iter_workers(group):
            _spawn_mod.kill_and_close_worker(worker, group)
        try:
            reviewers = list(iter_reviewers(group_id))
        except ValueError as exc:
            _log.warning(
                "self reset: failed to iter reviewers for %r: %s",
                group_id,
                exc,
            )
            reviewers = []
        for reviewer in reviewers:
            _spawn_mod.kill_and_close_worker(reviewer, group)

    if global_state is not None:
        _stop_daemon_from_global(global_state)

    delete_all()

    from mycel_cli.group._workflow.constants import DAEMON_STATE_FILE

    DAEMON_STATE_FILE.unlink(missing_ok=True)

    typer.echo("Mycel daemon 已重置，所有状态已清除。")


def _stop_daemon_or_fail(pid: object) -> None:
    request_termination(pid)
    if wait_for_exit(pid):
        return
    typer.echo(f"Daemon PID {pid} did not exit after stop request.", err=True)
    raise typer.Exit(1)


def _stop_daemon_from_global(global_state: dict) -> None:
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        _stop_daemon_or_fail(daemon_pid)
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    save_global(global_state)


@self_inbox_app.command("read", help="Read local inbox notifications.")
def self_inbox_read() -> None:
    binding = resolve_binding(
        store=IdentityStore.from_env(),
        cwd=Path.cwd(),
        provider=None,
        interactive=False,
    )
    local_id = str(binding["local_id"])
    typer.echo(read_inbox_context(local_id), nl=False)


def _remove_mycel_hooks() -> dict[str, dict]:
    return {
        "provider_hooks": {
            provider: remove_provider_hooks(provider=provider)
            for provider in PROVIDER_ORDER
        },
        "stop_hooks": remove_stop_hooks(),
    }


def _ensure_provider_hooks() -> None:
    for item in PROVIDER_ORDER:
        ensure_provider_hooks(provider=item)
