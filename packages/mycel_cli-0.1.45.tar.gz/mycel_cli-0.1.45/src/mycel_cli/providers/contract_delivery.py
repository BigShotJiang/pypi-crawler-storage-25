from __future__ import annotations


def codex_initial_prompt_bundle(
    *, bootstrap_prompt: str, append_system_prompt: str
) -> str:
    """Build the Codex initial prompt when no native system-prompt channel exists."""
    if not append_system_prompt.strip():
        return bootstrap_prompt
    # @@@provider-contract-delivery - Codex lacks Claude's append-system-prompt
    # file channel, so we name the delivery mode and pass one bundled prompt.
    return (
        append_system_prompt.rstrip()
        + "\n\n--- Mycel group bootstrap ---\n\n"
        + bootstrap_prompt.lstrip()
    )
