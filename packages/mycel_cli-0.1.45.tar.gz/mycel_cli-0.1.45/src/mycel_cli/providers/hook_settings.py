from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

PROVIDER_CONFIG_DIRS = {
    "codex": ".codex",
    "claude": ".claude",
}
PROVIDER_SETTINGS_FILES = {
    "codex": "hooks.json",
    "claude": "settings.json",
}


def provider_config_home() -> Path:
    return Path(
        os.getenv("MYCEL_PROVIDER_CONFIG_HOME") or os.getenv("HOME") or Path.home()
    ).expanduser()


def provider_dir(provider: str, home: Path) -> Path:
    try:
        dirname = PROVIDER_CONFIG_DIRS[provider]
    except KeyError as exc:
        raise RuntimeError(f"unsupported provider: {provider}") from exc
    return home / dirname


def provider_settings_path(provider: str, home: Path) -> Path:
    try:
        filename = PROVIDER_SETTINGS_FILES[provider]
    except KeyError as exc:
        raise RuntimeError(f"unsupported provider: {provider}") from exc
    return provider_dir(provider, home) / filename


def codex_config_path(home: Path) -> Path:
    return provider_dir("codex", home) / "config.toml"


def load_json_object(path: Path, *, label: str) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{label} must be valid JSON: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError(f"{label} must be a JSON object: {path}")
    return payload


def write_json_object(path: Path, payload: dict[str, Any]) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if path.exists() and path.read_text(encoding="utf-8") == text:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def ensure_codex_hooks_feature(path: Path) -> None:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    lines = text.splitlines()
    section_start = None
    section_end = len(lines)
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "[features]":
            section_start = index
            continue
        if (
            section_start is not None
            and stripped.startswith("[")
            and stripped.endswith("]")
        ):
            section_end = index
            break
    feature_line = "codex_hooks = true"
    if section_start is None:
        next_lines = list(lines)
        if next_lines and next_lines[-1].strip():
            next_lines.append("")
        next_lines.extend(["[features]", feature_line])
    else:
        next_lines = list(lines)
        for index in range(section_start + 1, section_end):
            key = next_lines[index].split("=", 1)[0].strip()
            if key == "codex_hooks":
                next_lines[index] = feature_line
                break
        else:
            next_lines.insert(section_end, feature_line)
    next_text = "\n".join(next_lines) + "\n"
    if next_text == text:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(next_text, encoding="utf-8")
