"""Internal CLI package.

Split out of `mycel_cli.group.cli` by responsibility:

- `constants` — static help text, regexes, allowed-status sets
- `contracts` — Worker/Supervisor/Reviewer system-prompt and bootstrap builders
- `helpers` — parse / validate / resolve helpers used by command dispatch
- `spawn`   — Claude-session spawn, readiness wait, terminal close, daemon launch
- `dispatch`, `dispatch_task`, `dispatch_worker`, `dispatch_supervisor`,
  `dispatch_reviewer` — group-scoped verb routing

`mycel_cli.group.cli` owns the `cel group` Typer app; the root app wiring lives in
`mycel_cli.typer_app`.
"""
