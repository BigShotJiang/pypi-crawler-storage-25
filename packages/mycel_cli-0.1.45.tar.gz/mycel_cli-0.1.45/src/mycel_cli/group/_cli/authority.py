"""Central collaborative authority / invariant validation layer.

This layer resolves the current actor from cel env, applies typed command
policies, and validates workflow invariants around task / group transitions.
"""

from __future__ import annotations

from dataclasses import dataclass

import typer

from mycel_cli.group._cli.helpers import (
    require_group_active,
    require_group_event_processing_active,
    require_reviewer_event_coverage,
)
from mycel_cli.group._cli.identity_env import (
    current_mycel_identity,
    resolve_current_user_session,
)
from mycel_cli.group._state.roles import RoleRecord, get_role
from mycel_cli.group.workflow_policy import (
    ActorIdentity,
    ActorRole,
    CollaborativeOperationPolicy,
    COLLABORATIVE_OPERATION_POLICIES,
    GROUP_STOP_POLICY,
    GroupReviewTransition,
    OperationName,
    TaskReviewTransition,
    get_task_review_transition,
    get_task_status_command_policy,
    task_status_mutation_allowed,
)


@dataclass(frozen=True)
class AuthorizationDecision:
    actor: ActorIdentity
    task_review_transition: TaskReviewTransition | None = None
    group_review_transition: GroupReviewTransition | None = None


def resolve_actor_identity(group_id: str) -> ActorIdentity:
    ident = current_mycel_identity()
    user_session = resolve_current_user_session(group_id)
    if user_session is None:
        if ident.operator_role == ActorRole.OPERATOR.value:
            return ActorIdentity(
                role=ActorRole.OPERATOR,
                source="human_cli",
            )
        return ActorIdentity(
            role=ActorRole.HUMAN,
            source="human_cli",
        )
    try:
        role_record = get_role(group_id, user_session)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    role_view = RoleRecord.from_mapping(role_record)
    return ActorIdentity(
        role=ActorRole(role_view.role),
        group_id=group_id,
        user_session=user_session,
        source="user_env",
    )


def resolve_global_actor_identity() -> ActorIdentity:
    ident = current_mycel_identity()
    if not ident.has_mycel_env():
        return ActorIdentity(
            role=ActorRole.HUMAN,
            source="human_cli",
        )
    if ident.operator_role == ActorRole.OPERATOR.value:
        return ActorIdentity(
            role=ActorRole.OPERATOR,
            source="human_cli",
        )
    if not ident.group_id or not ident.user_session:
        typer.echo("当前 cel env 不完整，无法识别操作者。", err=True)
        raise typer.Exit(1)
    try:
        role_record = get_role(ident.group_id, ident.user_session)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    role_view = RoleRecord.from_mapping(role_record)
    return ActorIdentity(
        role=ActorRole(role_view.role),
        group_id=ident.group_id,
        user_session=ident.user_session,
        source="user_env",
    )


def _deny(intent: OperationName, actor: ActorIdentity) -> None:
    if actor.role == ActorRole.HUMAN:
        who = "当前 shell"
    else:
        who = f"{actor.role.value} {actor.user_session}"
    typer.echo(
        f"{who} 无权执行 {intent.value}。",
        err=True,
    )
    raise typer.Exit(1)


def _task_transition_hint(
    *,
    group_id: str,
    tasks: list[dict],
    target_status: str,
) -> str | None:
    task_ids = ",".join(str(task.get("id")) for task in tasks)
    statuses = {str(task.get("status") or "") for task in tasks}
    if len(statuses) != 1:
        return f"先拆开处理不同状态的 task：cel group {group_id} task list"
    source_status = next(iter(statuses))
    command = f"cel group {group_id} task update --tasks {task_ids}"
    if source_status == "proposed":
        return (
            "当前是 proposed，下一步是提交设计审查："
            f"{command} --status pending --rationale <file>"
        )
    if source_status == "pending":
        return f"当前是 pending，下一步是进入执行：{command} --status in_progress"
    if source_status == "in_progress" and target_status == "completed":
        return (
            "当前是 in_progress，完成需要提交完成审查："
            f"{command} --status completed --rationale <file>"
        )
    return None


def _require_policy(
    intent: OperationName, actor: ActorIdentity
) -> CollaborativeOperationPolicy:
    policy = COLLABORATIVE_OPERATION_POLICIES[intent]
    if actor.role not in policy.allowed_roles:
        _deny(intent, actor)
    return policy


def authorize_operation(
    operation: OperationName,
    *,
    group_id: str | None = None,
) -> ActorIdentity:
    actor = (
        resolve_actor_identity(group_id)
        if group_id is not None
        else resolve_global_actor_identity()
    )
    _require_policy(operation, actor)
    return actor


def authorize_task_operation(
    group_id: str,
    group: dict,
    *,
    operation: OperationName,
    target_status: str | None = None,
    needs_review: bool = False,
    tasks: list[dict] | None = None,
    patch_keys: set[str] | None = None,
) -> AuthorizationDecision:
    actor = resolve_actor_identity(group_id)
    _require_policy(operation, actor)

    if operation == OperationName.TASK_UPDATE:
        require_group_active(group_id, group)

    if actor.role == ActorRole.REVIEWER:
        extra_keys = set(patch_keys or set()) - {"status"}
        if extra_keys:
            typer.echo(
                "reviewer 只能用 task update --status ... 对已有审批事项行权，"
                f"不能更新字段: {', '.join(sorted(extra_keys))}",
                err=True,
            )
            raise typer.Exit(1)
        if target_status is None:
            typer.echo("reviewer 的 task update 必须带 --status。", err=True)
            raise typer.Exit(1)
        return AuthorizationDecision(actor=actor)

    review_transition = (
        get_task_review_transition(target_status) if needs_review else None
    )
    command_policy = (
        get_task_status_command_policy(target_status) if needs_review else None
    )
    if review_transition is not None and command_policy is not None:
        require_group_event_processing_active(
            group_id,
            group,
            command=f"task update --status {target_status}",
        )
        if tasks is not None:
            invalid = [
                f"#{task['id']}[{task.get('status')}]"
                for task in tasks
                if task.get("status") != command_policy.required_source_status.value
            ]
            if invalid:
                message = (
                    f"task update --status {review_transition.target_status.value} requires tasks currently in "
                    f"{command_policy.required_source_status.value}: "
                    + ", ".join(invalid)
                )
                hint = _task_transition_hint(
                    group_id=group_id,
                    tasks=tasks,
                    target_status=str(target_status),
                )
                if hint:
                    message += "\n" + hint
                typer.echo(message, err=True)
                raise typer.Exit(1)
        if actor.role not in command_policy.command_roles:
            _deny(operation, actor)
        require_reviewer_event_coverage(
            group_id,
            command_policy.review_event_type.value,
        )
    elif target_status is not None and tasks is not None:
        invalid = [
            f"#{task['id']}[{task.get('status')}]"
            for task in tasks
            if not task_status_mutation_allowed(
                actor_role=actor.role,
                source_status=task.get("status"),
                target_status=target_status,
            )
        ]
        if invalid:
            message = (
                f"{actor.role.value} 无权将 task 状态改为 {target_status}: "
                + ", ".join(invalid)
            )
            hint = _task_transition_hint(
                group_id=group_id,
                tasks=tasks,
                target_status=str(target_status),
            )
            if hint:
                message += "\n" + hint
            typer.echo(message, err=True)
            raise typer.Exit(1)

    return AuthorizationDecision(
        actor=actor,
        task_review_transition=review_transition,
    )


def authorize_group_stop(
    group_id: str,
    group: dict,
    *,
    force: bool,
) -> AuthorizationDecision:
    actor = resolve_actor_identity(group_id)
    intent = OperationName.GROUP_STOP_FORCE if force else OperationName.GROUP_STOP
    _require_policy(intent, actor)
    if force:
        return AuthorizationDecision(
            actor=actor,
            group_review_transition=GroupReviewTransition(),
        )

    if actor.role == ActorRole.REVIEWER:
        require_group_event_processing_active(
            group_id,
            group,
            command="group stop",
        )
        return AuthorizationDecision(
            actor=actor,
            group_review_transition=GroupReviewTransition(),
        )

    require_group_event_processing_active(
        group_id,
        group,
        command="group stop",
    )
    if actor.role not in GROUP_STOP_POLICY.command_roles:
        _deny(intent, actor)
    require_reviewer_event_coverage(
        group_id,
        GroupReviewTransition().review_event_type.value,
    )
    return AuthorizationDecision(
        actor=actor,
        group_review_transition=GroupReviewTransition(),
    )
