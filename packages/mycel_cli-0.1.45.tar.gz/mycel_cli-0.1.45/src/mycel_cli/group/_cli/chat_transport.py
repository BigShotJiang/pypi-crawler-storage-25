"""Thin Mycel chat transport adapter for group-scoped messages."""

from __future__ import annotations

from typing import Any

from mycel_sdk import Client

from mycel_cli.identity_store import IdentityStore


class ScopedUnreadConflict(RuntimeError):
    pass


def unread_bodies_from_sender(
    *, group_id: str, viewer: dict, sender: dict
) -> list[str]:
    unread_by_sender = unread_bodies_from_senders(
        group_id=group_id, viewer=viewer, senders=[sender]
    )
    return unread_by_sender[0][1] if unread_by_sender else []


def unread_bodies_from_senders(
    *, group_id: str, viewer: dict, senders: list[dict]
) -> list[tuple[dict, list[str]]]:
    client, chat_id = group_chat_for(group_id=group_id, sender=viewer, recipient=viewer)
    sender_by_user_id = {user_id_for(sender): sender for sender in senders}
    bodies_by_user_id: dict[str, list[str]] = {
        user_id: [] for user_id in sender_by_user_id
    }
    other_sender_ids: set[str] = set()
    for message in client.messages.unread(chat_id) or []:
        message_sender_id = str(message.get("sender_id") or "").strip()
        if message_sender_id not in sender_by_user_id:
            if message_sender_id:
                other_sender_ids.add(message_sender_id)
            continue
        body = _body(message)
        if body:
            bodies_by_user_id[message_sender_id].append(body)
    found = [
        (sender_by_user_id[user_id], bodies)
        for user_id, bodies in bodies_by_user_id.items()
        if bodies
    ]
    if found and other_sender_ids:
        others = ", ".join(sorted(other_sender_ids))
        raise ScopedUnreadConflict(
            "其它 unread message 仍在当前 chat 中，不能只读取当前 sender 后推进 cursor: "
            f"{others}"
        )
    if found:
        client.messages.mark_read(chat_id)
    return found


def mark_group_read(*, group_id: str, viewer: dict) -> None:
    client, chat_id = group_chat_for(group_id=group_id, sender=viewer, recipient=viewer)
    client.messages.mark_read(chat_id)


def addressed_inbox_bodies(
    *,
    group_id: str,
    viewer: dict,
    excluded_senders: list[dict],
) -> list[str]:
    client, chat_id = group_chat_for(group_id=group_id, sender=viewer, recipient=viewer)
    viewer_user_id = user_id_for(viewer)
    excluded_sender_user_ids = {user_id_for(sender) for sender in excluded_senders}
    bodies: list[str] = []
    for message in client.messages.unread(chat_id) or []:
        sender_user_id = str(message.get("sender_id") or "").strip()
        if sender_user_id in excluded_sender_user_ids:
            continue
        addressed_to = [
            str(item) for item in message.get("addressed_to_user_ids") or []
        ]
        if viewer_user_id not in addressed_to:
            continue
        body = _body(message)
        if body:
            bodies.append(body)
    return bodies


def _body(message: dict[str, Any]) -> str:
    return str(message.get("content") or message.get("text") or "").strip()


def group_chat_for(
    *, group_id: str, sender: dict, recipient: dict
) -> tuple[Client, str]:
    source_identity = identity_for(sender)
    require_user_id(recipient)
    client = Client(
        auth_token=str(source_identity["auth_token"]),
        base_url=str(source_identity["base_url"]),
    )
    return client, group_id


def describe_group_route(*, chat_id: str, sender: dict, recipient: dict) -> str:
    source_identity = identity_for(sender)
    target_identity = identity_for(recipient)
    return (
        f"Resolved: chat_id={chat_id}, "
        f"from user_id={_user_id_from_identity(source_identity, sender)} "
        f"(local_id={source_identity['local_id']}, session={sender.get('session')}), "
        f"to user_id={_user_id_from_identity(target_identity, recipient)} "
        f"(local_id={target_identity['local_id']}, session={recipient.get('session')})."
    )


def require_user_id(user: dict) -> None:
    user_id_for(user)


def user_id_for(user: dict) -> str:
    return _user_id_from_identity(identity_for(user), user)


def _user_id_from_identity(identity: dict, user: dict) -> str:
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no user_id")
    return user_id


def identity_for(user: dict) -> dict:
    local_id = str(user.get("local_id") or "").strip()
    if not local_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no Mycel identity")
    identity = IdentityStore.from_env().get_identity(local_id)
    return {"local_id": local_id, **identity}
