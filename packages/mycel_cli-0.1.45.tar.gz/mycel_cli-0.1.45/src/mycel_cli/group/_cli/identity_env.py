"""Minimal cel user environment helpers.

Environment identity answers two questions:

    MYCEL_LOCAL_ID: which Mycel user this process speaks as
    MYCEL_GROUP_ID + MYCEL_USER_SESSION: which group role this process occupies
"""

from __future__ import annotations

import os
import shlex
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

import typer

ENV_MYCEL_GROUP_ID = "MYCEL_GROUP_ID"
ENV_MYCEL_USER_SESSION = "MYCEL_USER_SESSION"
ENV_MYCEL_LOCAL_ID = "MYCEL_LOCAL_ID"
ENV_MYCEL_OPERATOR_ROLE = "MYCEL_OPERATOR_ROLE"
ENV_MYCEL_CLI_BIN = "MYCEL_CLI_BIN"


@dataclass(frozen=True)
class MycelProcessIdentity:
    group_id: str | None = None
    user_session: str | None = None
    local_id: str | None = None
    operator_role: str | None = None

    def has_mycel_env(self) -> bool:
        return bool(self.group_id or self.user_session or self.operator_role)


def current_mycel_identity() -> MycelProcessIdentity:
    return MycelProcessIdentity(
        group_id=os.environ.get(ENV_MYCEL_GROUP_ID) or None,
        user_session=os.environ.get(ENV_MYCEL_USER_SESSION) or None,
        local_id=os.environ.get(ENV_MYCEL_LOCAL_ID) or None,
        operator_role=os.environ.get(ENV_MYCEL_OPERATOR_ROLE) or None,
    )


def build_user_env(
    *,
    group_id: str,
    user_session: str,
    local_id: str,
) -> dict[str, str]:
    cli_path = shutil.which("cel")
    cli_bin = (
        Path(cli_path).resolve().parent if cli_path else Path(sys.executable).parent
    )
    env = {
        ENV_MYCEL_GROUP_ID: group_id,
        ENV_MYCEL_USER_SESSION: user_session,
        ENV_MYCEL_LOCAL_ID: local_id,
        ENV_MYCEL_CLI_BIN: str(cli_bin),
    }
    for passthrough in ("MYCEL_HOME", "HOME"):
        value = os.environ.get(passthrough)
        if value:
            env[passthrough] = value
    pythonpath = os.environ.get("PYTHONPATH")
    if pythonpath:
        entries: list[str] = []
        cwd = Path.cwd()
        for entry in pythonpath.split(os.pathsep):
            if not entry:
                continue
            path = Path(entry)
            if not path.is_absolute():
                path = (cwd / path).resolve()
            entries.append(str(path))
        if entries:
            env["PYTHONPATH"] = os.pathsep.join(entries)
    return env


def shell_env_prefix(env: dict[str, str] | None) -> str:
    if not env:
        return ""
    exports = [
        f"export {key}={shlex.quote(value)}"
        for key, value in env.items()
        if key != ENV_MYCEL_CLI_BIN
    ]
    cli_bin = env.get(ENV_MYCEL_CLI_BIN)
    if cli_bin:
        exports.append(f"export {ENV_MYCEL_CLI_BIN}={shlex.quote(cli_bin)}")
        exports.append(f'export PATH="${ENV_MYCEL_CLI_BIN}:$PATH"')
    exports = "; ".join(exports)
    return exports + "; "


def resolve_current_user_session(group_id: str) -> str | None:
    ident = current_mycel_identity()
    if not ident.has_mycel_env():
        return None
    if ident.group_id != group_id:
        typer.echo(
            f"当前 cel user 属于 group '{ident.group_id or 'unknown'}'，"
            f"不是 '{group_id}'。",
            err=True,
        )
        raise typer.Exit(1)
    if not ident.user_session:
        typer.echo(
            f"当前 user 缺少 {ENV_MYCEL_USER_SESSION}，"
            "请获取正确环境变量后重启该 user。",
            err=True,
        )
        raise typer.Exit(1)
    return ident.user_session
