"""Provider session read adapters used by group workflow code.

This module intentionally stays small: group workflow needs to read the latest
assistant reply from a provider session, while durable communication still goes
through Mycel chat. Sending, waking, and terminal control live in their own
provider/daemon boundaries.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from mycel_cli.group._state.roles import (
    role_agent_type,
    role_jsonl_path,
    role_thread_id,
)


@dataclass(frozen=True)
class AgentMessage:
    """Single assistant reply from an agent session."""

    text: str
    ts: str | None = None
    """Raw ISO8601 timestamp string from the source, preserved verbatim.

    Deliberately `str`, not `datetime`: provider logs may use timestamp spellings
    that do not round-trip byte-identically through Python datetime formatting.
    """

    turn_id: str | None = None
    """Opaque, provider-specific identifier for cross-referencing turns."""


class Agent(Protocol):
    """Provider read surface used by group workflow checks."""

    def last_message(self, session: str) -> AgentMessage | None:
        """Return the most recent assistant reply for `session`, or None.

        None means no retrievable message: session log missing, malformed,
        empty, or no assistant entries yet. Query method — never raises;
        all errors collapse to None. Idempotent and non-consuming.

        `session` is an agent-specific identifier (CC session name or
        UUID, Codex thread_id, etc.). The concrete `Agent` implementation
        interprets it.
        """
        ...


def agent_last_message(role_record: dict[str, Any]) -> AgentMessage | None:
    """Dispatch to the per-agent `last_message` for a `RoleRecord` dict.

    Lazy-imports `mycel_cli.group.agents.*` to avoid pulling concrete agent runtimes
    into the state layer's import graph.
    """
    session = str(role_record.get("session") or "")
    jsonl_path = role_jsonl_path(role_record)
    thread_id = role_thread_id(role_record)
    agent_type = role_agent_type(role_record)

    if agent_type == "codex":
        from mycel_cli.group.agents.codex import CodexAgent

        return CodexAgent().last_message(
            session,
            session_id=thread_id,
            jsonl_path=jsonl_path,
        )

    from mycel_cli.group.agents.cc import CCAgent

    return CCAgent().last_message(
        session,
        jsonl_path=jsonl_path,
    )
