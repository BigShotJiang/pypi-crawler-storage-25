"""Concrete `Agent` implementations.

Each submodule hosts one implementation of `mycel_cli.group.agent.Agent`:

- `cc` — Claude Code
- `codex` — OpenAI Codex CLI
"""
