"""Claude Code implementation of `mycel_cli.group.agent.Agent`.

The adapter reuses the worker JSONL discovery/read helpers so group workflow
code and direct worker reads interpret Claude Code transcripts the same way.
Tests and non-cmux environments may pass `jsonl_path` directly; normal runtime
paths still discover the transcript from the session.
"""

from __future__ import annotations

from pathlib import Path

from mycel_cli.group.agent import AgentMessage
from mycel_cli.group.worker import read_last_message, resolve_worker


class CCAgent:
    """Read the latest Claude Code assistant message for a group session."""

    name = "claude-code"

    def last_message(
        self,
        session: str,
        *,
        jsonl_path: Path | str | None = None,
    ) -> AgentMessage | None:
        """Return the most recent assistant reply for a CC session.

        Resolution order for the JSONL file:

        1. If `jsonl_path` is provided explicitly, use it directly. This is
           the test/non-cmux path described in the module docstring.
        2. Otherwise call `resolve_worker(session)` to discover the JSONL
           via the `ps` + cmux env var path used by the rest of mycel_cli.group.

        Returns None for any failure mode — missing file, malformed file,
        no assistant entries yet, or unreachable session. Query method,
        never raises.
        """
        if jsonl_path is not None:
            path = Path(jsonl_path)
        else:
            info = resolve_worker(session, None)
            if info.jsonl_path is None:
                return None
            path = info.jsonl_path

        result = read_last_message(path)
        if not result.get("ok"):
            return None

        return AgentMessage(
            text=result["message"],
            ts=result.get("timestamp") or None,
        )
