"""Group state package split by responsibility.

Modules in this package own their specific state primitives directly: groups,
roles, tasks, reviewers, messages, transcript, paths, and workflow metadata.
"""
