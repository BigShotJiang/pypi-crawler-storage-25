"""Per-group supervisor-worker dialogue record (append-only JSONL).

  ~/.mycel/groups/<name>.json          # group state (schema unchanged)
  ~/.mycel/groups/<name>/transcript.jsonl   # dialogue record

Write points:
  - cli.send / cli.wake   → sup_to_worker, kind=send|wake
  - daemon stop handler   → worker_to_sup, kind=stop_reply

Observability guarantee: `append_transcript` catches all errors and logs them
at WARNING. It never raises. The observed system must not be broken by a
failure to observe it.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from mycel_cli.group._state.groups import _group_resource_dir

_log = logging.getLogger("mycel_cli.group._state.transcript")

Direction = Literal["sup_to_worker", "worker_to_sup"]
Kind = Literal["send", "wake", "stop_reply"]


@dataclass(frozen=True)
class TranscriptEntry:
    ts: str
    direction: Direction
    worker: str
    content: str
    kind: Kind

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @classmethod
    def from_json(cls, raw: str) -> "TranscriptEntry":
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("transcript entry must be an object")
        keys = set(data)
        expected = {"ts", "direction", "worker", "content", "kind"}
        if keys != expected:
            raise ValueError(f"invalid transcript keys: {sorted(keys)!r}")
        direction = str(data["direction"])
        kind = str(data["kind"])
        if direction not in {"sup_to_worker", "worker_to_sup"}:
            raise ValueError(f"invalid transcript direction: {direction!r}")
        if kind not in {"send", "wake", "stop_reply"}:
            raise ValueError(f"invalid transcript kind: {kind!r}")
        return cls(
            ts=str(data["ts"]),
            direction=direction,  # type: ignore[arg-type]
            worker=str(data["worker"]),
            content=str(data["content"]),
            kind=kind,  # type: ignore[arg-type]
        )


def _transcript_file(group_name: str) -> Path:
    return _group_resource_dir(group_name) / "transcript.jsonl"


def _parse_iso_utc(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def append_transcript(
    group_name: str,
    *,
    direction: str,
    worker: str,
    content: str,
    kind: str,
) -> None:
    """Append one entry to a group's transcript. Never raises.

    All failures (schema validation, filesystem, encoding) are caught and
    logged. Callers must not rely on successful persistence.
    """
    try:
        entry = TranscriptEntry(
            ts=datetime.now(timezone.utc).isoformat(),
            direction=direction,  # type: ignore[arg-type]
            worker=worker,
            content=content,
            kind=kind,  # type: ignore[arg-type]
        )
        d = _group_resource_dir(group_name)
        d.mkdir(parents=True, exist_ok=True)
        with open(_transcript_file(group_name), "a", encoding="utf-8") as f:
            f.write(entry.to_json() + "\n")
    except Exception as e:
        _log.warning(
            "Failed to append transcript (group=%s, kind=%s): %s",
            group_name,
            kind,
            e,
        )


def read_transcript(
    group_name: str,
    *,
    worker: str | None = None,
    tail: int | None = None,
    since: str | None = None,
) -> list[TranscriptEntry]:
    """Return transcript entries oldest-first, with optional filters.

    - worker: cel only entries where `worker` matches
    - since:  cel only entries with ts >= since (ISO8601, tolerant of Z suffix)
    - tail:   cel only the last N entries (applied after worker/since)

    Missing file → []. Malformed lines are skipped silently.
    """
    f = _transcript_file(group_name)
    if not f.exists():
        return []

    try:
        raw_lines = f.read_text(encoding="utf-8").splitlines()
    except OSError as e:
        _log.warning("Failed to read transcript for %s: %s", group_name, e)
        return []

    since_dt = _parse_iso_utc(since) if since else None

    entries: list[TranscriptEntry] = []
    for raw in raw_lines:
        if not raw.strip():
            continue
        try:
            entry = TranscriptEntry.from_json(raw)
        except Exception:
            # Partial writes or schema-skew lines are ignored silently.
            continue
        if worker is not None and entry.worker != worker:
            continue
        if since_dt is not None:
            entry_dt = _parse_iso_utc(entry.ts)
            if entry_dt is None or entry_dt < since_dt:
                continue
        entries.append(entry)

    if tail is not None and tail > 0:
        entries = entries[-tail:]
    return entries
