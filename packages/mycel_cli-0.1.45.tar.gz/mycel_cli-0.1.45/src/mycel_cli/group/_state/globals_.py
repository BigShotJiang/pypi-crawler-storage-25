"""Global daemon state (~/.mycel/global.json)."""

from __future__ import annotations

import json
from typing import Any

from filelock import FileLock

from mycel_cli.group._state import paths as _paths
from mycel_cli.group._state.paths import atomic_write_text, _ensure_dirs


def _global_lock_file():
    return _paths.GLOBAL_FILE.with_suffix(_paths.GLOBAL_FILE.suffix + ".lock")


def _global_lock() -> FileLock:
    return FileLock(str(_global_lock_file()))


def load_global() -> dict[str, Any] | None:
    if not _paths.GLOBAL_FILE.exists():
        return None
    with _global_lock():
        if not _paths.GLOBAL_FILE.exists():
            return None
        return json.loads(_paths.GLOBAL_FILE.read_text(encoding="utf-8"))


def save_global(state: dict[str, Any]) -> None:
    _ensure_dirs()
    with _global_lock():
        atomic_write_text(
            _paths.GLOBAL_FILE, json.dumps(state, ensure_ascii=False, indent=2)
        )


def delete_global() -> None:
    if _paths.GLOBAL_FILE.exists():
        with _global_lock():
            if _paths.GLOBAL_FILE.exists():
                _paths.GLOBAL_FILE.unlink()


def new_global() -> dict[str, Any]:
    return {
        "daemon_pid": None,
    }
