"""Shared agent-type helpers.

`cel` currently supports two interactive agent providers:
- Claude Code (`claude-code`)
- Codex CLI (`codex`)
"""

from __future__ import annotations

DEFAULT_AGENT_TYPE = "claude-code"
VALID_AGENT_TYPES = frozenset({"claude-code", "codex"})
PROVIDER_ORDER = ("codex", "claude")
VALID_PROVIDERS = frozenset(PROVIDER_ORDER)


def normalize_agent_type(agent_type: str | None) -> str:
    if not agent_type:
        return DEFAULT_AGENT_TYPE
    raw = agent_type.strip().lower()
    if raw in {"claude", "claude-code", "cc"}:
        return "claude-code"
    if raw == "codex":
        return "codex"
    raise ValueError(f"Unsupported agent type: {agent_type}")


def agent_type_from_provider(provider: str) -> str:
    if provider == "claude":
        return "claude-code"
    if provider == "codex":
        return "codex"
    raise ValueError(f"Unsupported provider: {provider}")


def provider_from_agent_type(agent_type: str) -> str:
    resolved = normalize_agent_type(agent_type)
    if resolved == "claude-code":
        return "claude"
    if resolved == "codex":
        return "codex"
    raise ValueError(f"Unsupported agent type: {agent_type}")


def providers_for_agent_types(agent_types: set[str] | None) -> list[str]:
    requested = {
        provider_from_agent_type(agent)
        for agent in (agent_types or {DEFAULT_AGENT_TYPE})
    }
    return [provider for provider in PROVIDER_ORDER if provider in requested]


def resolve_provider_selection(provider: str) -> list[str]:
    if provider == "all":
        return list(PROVIDER_ORDER)
    if provider in VALID_PROVIDERS:
        return [provider]
    raise RuntimeError(f"unsupported provider: {provider}")
