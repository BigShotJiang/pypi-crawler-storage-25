"""Local process and host integration helpers."""
