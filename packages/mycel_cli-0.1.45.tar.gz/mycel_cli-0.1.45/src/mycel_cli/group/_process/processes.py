"""Process lifecycle helpers for the local cel daemon."""

from __future__ import annotations

import ctypes
import os
import signal
import time
from ctypes import wintypes

_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
_PROCESS_TERMINATE = 0x0001
_STILL_ACTIVE = 259


def _coerce_pid(pid: object) -> int | None:
    try:
        resolved = int(pid)
    except (TypeError, ValueError):
        return None
    if resolved <= 0:
        return None
    return resolved


def _windows_pid_exists(pid: int) -> bool:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = kernel32.OpenProcess(
        _PROCESS_QUERY_LIMITED_INFORMATION,
        False,
        pid,
    )
    if not handle:
        return False
    try:
        exit_code = wintypes.DWORD()
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return False
        return exit_code.value == _STILL_ACTIVE
    finally:
        kernel32.CloseHandle(handle)


def pid_exists(pid: object) -> bool:
    resolved = _coerce_pid(pid)
    if resolved is None:
        return False
    if os.name == "nt":
        return _windows_pid_exists(resolved)
    try:
        os.kill(resolved, 0)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return False


def request_termination(pid: object) -> None:
    resolved = _coerce_pid(pid)
    if resolved is None:
        return
    if os.name == "nt":
        _windows_request_termination(resolved)
        return
    try:
        os.kill(resolved, signal.SIGTERM)
    except (ProcessLookupError, OSError):
        pass


def _windows_request_termination(pid: int) -> None:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = kernel32.OpenProcess(_PROCESS_TERMINATE, False, pid)
    if not handle:
        return
    try:
        kernel32.TerminateProcess(handle, 1)
    finally:
        kernel32.CloseHandle(handle)


def wait_for_exit(pid: object, *, timeout: float = 6.0) -> bool:
    resolved = _coerce_pid(pid)
    if resolved is None:
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _reap_exited_child(resolved):
            return True
        if not pid_exists(resolved):
            return True
        time.sleep(0.1)
    return _reap_exited_child(resolved) or not pid_exists(resolved)


def _reap_exited_child(pid: int) -> bool:
    if os.name == "nt":
        return False
    try:
        reaped_pid, _status = os.waitpid(pid, os.WNOHANG)
    except ChildProcessError:
        return False
    return reaped_pid == pid
