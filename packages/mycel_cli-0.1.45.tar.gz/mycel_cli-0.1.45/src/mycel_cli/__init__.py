"""CLI package layered on top of mycel_sdk."""
