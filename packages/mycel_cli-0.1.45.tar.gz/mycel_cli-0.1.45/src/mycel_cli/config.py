"""Configuration for cel."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .binding_resolver import resolve_binding
from .identity_store import IdentityStore
from .daemon import paths as daemon_paths

DEFAULT_BASE_URL = "https://mycel.nextmind.space"


@dataclass(frozen=True)
class CliConfig:
    base_url: str
    auth_token: str | None
    local_id: str | None = None
    created_by_user_id: str | None = None


def _global_config_path() -> Path:
    return daemon_paths.mycel_home() / "config.json"


def load_global_config() -> dict[str, Any]:
    path = _global_config_path()
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return {}
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise RuntimeError(f"Mycel config must be a JSON object: {path}")
    return dict(payload)


def save_global_config(payload: dict[str, Any]) -> None:
    path = _global_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    os.replace(tmp, path)
    path.chmod(0o600)


def effective_base_url() -> dict[str, str]:
    env_url = str(os.getenv("MYCEL_BASE_URL") or "").strip()
    if env_url:
        return {"base_url": env_url, "source": "env"}
    config_url = str(load_global_config().get("base_url") or "").strip()
    if config_url:
        return {"base_url": config_url, "source": "config"}
    return {"base_url": DEFAULT_BASE_URL, "source": "source-default"}


def base_url_line(base_url: dict[str, str]) -> str:
    return f"Base URL: {base_url['base_url']} ({base_url['source']})"


def load_cli_config(*, cwd: Path | None = None) -> CliConfig:
    binding = resolve_binding(
        store=IdentityStore.from_env(),
        cwd=cwd or Path.cwd(),
        provider=None,
        interactive=False,
    )
    env_url = str(os.getenv("MYCEL_BASE_URL") or "").strip()
    return CliConfig(
        base_url=env_url or str(binding["base_url"]),
        auth_token=str(binding["auth_token"]),
        local_id=str(binding["local_id"]),
        created_by_user_id=_optional_str(binding.get("created_by_user_id")),
    )


def load_identity_config(local_id: str) -> CliConfig:
    identity = IdentityStore.from_env().get_identity(local_id)
    env_url = str(os.getenv("MYCEL_BASE_URL") or "").strip()
    return CliConfig(
        base_url=env_url or str(identity["base_url"]),
        auth_token=str(identity["auth_token"]),
        local_id=local_id,
        created_by_user_id=_optional_str(identity.get("created_by_user_id")),
    )


def load_owner_config() -> CliConfig:
    user = IdentityStore.from_env().current_user()
    env_url = str(os.getenv("MYCEL_BASE_URL") or "").strip()
    return CliConfig(
        base_url=env_url or str(user["base_url"]),
        auth_token=str(user["auth_token"]),
        created_by_user_id=_optional_str(user.get("user_id")),
    )


def _optional_str(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None
