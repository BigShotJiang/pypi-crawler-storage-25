"""
Result/Reference storage models for NoETL.

MCP-compatible pointer system for efficient data passing between steps.
Data is stored externally and only lightweight pointers are passed through
the event log and context.

Storage Tiers (aligned with RisingWave 3-tier hierarchy):
- memory: In-process (<10KB, step-scoped)
- kv: NATS KV (<1MB, execution-scoped)
- disk: Local SSD/NVMe cache backed by cloud (>=1MB; phase 1)
- s3/gcs: Cloud storage, durable (large blobs; S3-compatible endpoints supported)
- db: PostgreSQL (queryable intermediate data)

Scopes:
- step: Cleaned up when step completes
- execution: Cleaned up when playbook completes
- workflow: Persists across nested playbook calls
- forever: Never auto-cleaned (permanent storage)

Phase 0 (this release) removes the `object` (NATS Object Store) tier.
See `docs/features/noetl_storage_and_streaming_alignment.md` for the
full mapping and phasing.
"""

from typing import Optional, Dict, Any, List, Literal, Union
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field, field_validator
from enum import Enum
import uuid


class StoreTier(str, Enum):
    """Storage tier for result data."""
    MEMORY = "memory"       # In-process memory (fastest, step-scoped)
    KV = "kv"              # NATS KV (< 1MB, execution-scoped)
    DISK = "disk"          # Local SSD/NVMe cache + async cloud spill (>= 1MB)
    S3 = "s3"              # S3-compatible durable blobs (SeaweedFS, RustFS, AWS S3)
    GCS = "gcs"            # Google Cloud Storage
    DB = "db"              # PostgreSQL (queryable)
    DUCKDB = "duckdb"      # DuckDB (local analytics)
    EVENTLOG = "eventlog"  # Event log inline (default for small results)


# Back-compat shim: `"object"` was the NATS Object Store tier, removed in phase 0.
# Inbound ResultRef / payload envelopes carrying `store: "object"` are mapped to
# `"disk"` with a one-time deprecation warning per process.
_OBJECT_DEPRECATION_LOGGED = False


def _normalize_store_value(value):
    """Map deprecated tier names to current ones. One-time warn per process."""
    global _OBJECT_DEPRECATION_LOGGED
    if isinstance(value, str) and value.lower() == "object":
        if not _OBJECT_DEPRECATION_LOGGED:
            import logging
            logging.getLogger(__name__).warning(
                "[storage] DEPRECATED: store='object' (NATS Object Store) is removed; "
                "rewriting to 'disk'. See docs/features/noetl_storage_and_streaming_alignment.md"
            )
            _OBJECT_DEPRECATION_LOGGED = True
        return "disk"
    return value


class Scope(str, Enum):
    """Lifecycle scope for result data."""
    STEP = "step"           # Cleaned up when step completes
    EXECUTION = "execution" # Cleaned up when playbook completes
    WORKFLOW = "workflow"   # Persists across nested playbook calls
    PERMANENT = "permanent" # Never auto-cleaned (permanent storage)


class ResultRefMeta(BaseModel):
    """Metadata for ResultRef."""
    content_type: str = Field(default="application/json")
    bytes: int = Field(default=0, description="Size in bytes")
    sha256: Optional[str] = Field(default=None, description="Content hash")
    schema_digest: Optional[str] = Field(default=None, description="Logical payload schema digest")
    row_count: Optional[int] = Field(default=None, description="Row count for tabular payloads")
    media_type: Optional[str] = Field(default=None, description="Canonical media type for payload bytes")
    compression: str = Field(default="none", description="Compression: gzip, lz4, none")
    encoding: str = Field(default="utf-8")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    accessed_at: Optional[datetime] = Field(default=None)
    access_count: int = Field(default=0)


# Legacy alias
TempRefMeta = ResultRefMeta


class IpcHint(BaseModel):
    """Best-effort same-node shared-memory hint for a durable payload ref."""

    kind: Literal["arrow_ipc"] = Field(default="arrow_ipc")
    shm_name: str = Field(..., description="Shared-memory region or mmap path")
    schema_digest: str = Field(..., description="Arrow schema digest")
    byte_length: int = Field(..., ge=0)
    row_count: Optional[int] = Field(default=None, ge=0)
    producer: Optional[str] = Field(default=None)
    node_id: Optional[str] = Field(
        default=None,
        description="Producer node identity; consumers skip IPC attach when it differs from their node",
    )
    lease_expires_at: Optional[datetime] = Field(default=None)
    media_type: str = Field(default="application/vnd.apache.arrow.stream")

    def is_expired(self, *, now: Optional[datetime] = None) -> bool:
        if self.lease_expires_at is None:
            return False
        check_time = now or datetime.now(timezone.utc)
        if check_time.tzinfo is None:
            check_time = check_time.replace(tzinfo=timezone.utc)
        expires_at = self.lease_expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        return check_time > expires_at


class ResultRef(BaseModel):
    """
    MCP-compatible result reference pointer.

    The ResultRef is a lightweight pointer that can be:
    - Serialized to JSON for event payloads
    - Passed between steps via templates
    - Resolved to actual data on demand

    URI format: noetl://execution/<eid>/result/<step>/<id>

    Access in templates:
    - {{ step_name.result }}       - Full result (triggers resolution)
    - {{ step_name.field_name }}   - Extracted field (no resolution)
    - {{ step_name.accumulated }}  - Accumulated results manifest
    - {{ step_name._ref }}         - Raw reference URI
    """
    kind: Literal["result_ref", "temp_ref"] = Field(default="result_ref")
    ref: str = Field(
        ...,
        description="Logical URI: noetl://execution/<eid>/result/<step>/<id>"
    )
    store: StoreTier = Field(
        default=StoreTier.KV,
        description="Storage tier where data resides"
    )
    scope: Scope = Field(
        default=Scope.EXECUTION,
        description="Lifecycle scope"
    )
    expires_at: Optional[datetime] = Field(
        default=None,
        description="TTL expiration timestamp (None for forever scope)"
    )
    meta: ResultRefMeta = Field(default_factory=ResultRefMeta)
    preview: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Truncated sample for UI/debugging (max 1KB)"
    )
    extracted: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Extracted fields from output.select (available without resolution)"
    )
    correlation: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Loop/pagination/retry tracking keys"
    )
    ipc: Optional[IpcHint] = Field(
        default=None,
        description="Optional Tier 1.5 same-node IPC hint; durable ref remains authoritative"
    )
    # Accumulation fields
    is_accumulated: bool = Field(default=False, description="Is part of accumulation")
    accumulation_index: Optional[int] = Field(default=None, description="Index in accumulation")
    accumulation_manifest_ref: Optional[str] = Field(default=None, description="Parent manifest ref")

    @field_validator('ref')
    @classmethod
    def validate_ref_format(cls, v: str) -> str:
        """Validate ref URI format."""
        if not v.startswith("noetl://"):
            raise ValueError("ResultRef ref must start with noetl://")
        return v

    @field_validator('store', mode='before')
    @classmethod
    def _map_deprecated_store(cls, v):
        """Map deprecated 'object' tier to 'disk' at parse time."""
        return _normalize_store_value(v)

    @classmethod
    def create(
        cls,
        execution_id: str,
        name: str,
        store: StoreTier = StoreTier.KV,
        scope: Scope = Scope.EXECUTION,
        ttl_seconds: Optional[int] = None,
        meta: Optional[ResultRefMeta] = None,
        correlation: Optional[Dict[str, Any]] = None,
        extracted: Optional[Dict[str, Any]] = None,
        ipc: Optional[IpcHint] = None,
    ) -> "ResultRef":
        """Factory method to create a new ResultRef."""
        ref_id = str(uuid.uuid4())[:8]
        ref = f"noetl://execution/{execution_id}/result/{name}/{ref_id}"

        expires_at = None
        # For forever scope, never set expiry
        if scope != Scope.PERMANENT and ttl_seconds and ttl_seconds > 0:
            expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)

        return cls(
            ref=ref,
            store=store,
            scope=scope,
            expires_at=expires_at,
            meta=meta or ResultRefMeta(),
            correlation=correlation,
            extracted=extracted,
            ipc=ipc,
        )

    def is_expired(self) -> bool:
        """Check if this ResultRef has expired."""
        # Forever scope never expires
        if self.scope == Scope.PERMANENT:
            return False
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    def to_key(self) -> str:
        """Convert ref URI to a storage key (safe for KV/Object stores)."""
        return self.ref.replace("noetl://", "").replace("/", "_")

    @classmethod
    def from_key(cls, key: str, store: StoreTier = StoreTier.KV) -> str:
        """Convert storage key back to ref URI."""
        return "noetl://" + key.replace("_", "/")


# Legacy alias for backwards compatibility
TempRef = ResultRef


class ManifestPart(BaseModel):
    """Single part in a manifest."""
    ref: Union[str, Dict[str, Any]] = Field(
        ..., description="Reference to part data (TempRef URI or inline dict)"
    )
    index: int = Field(..., description="Part order index")
    bytes_size: int = Field(default=0, description="Part size in bytes")
    meta: Optional[Dict[str, Any]] = Field(default=None)


class Manifest(BaseModel):
    """
    Manifest for aggregated results (pagination, loops).

    Instead of merging large datasets in memory, a manifest
    references the parts for streaming access.

    URI format: noetl://execution/<eid>/manifest/<name>/<id>
    """
    kind: Literal["manifest"] = Field(default="manifest")
    ref: str = Field(
        ...,
        description="Logical URI for the manifest itself"
    )
    execution_id: str = Field(..., description="Execution this manifest belongs to")
    strategy: Literal["append", "replace", "merge", "concat"] = Field(
        default="append",
        description="How to combine parts"
    )
    merge_path: Optional[str] = Field(
        default=None,
        description="JSONPath for nested array merge (e.g., $.data.items)"
    )
    parts: List[ManifestPart] = Field(default_factory=list)
    total_parts: int = Field(default=0)
    total_bytes: int = Field(default=0)
    source_step: Optional[str] = Field(default=None)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = Field(default=None)
    correlation: Optional[Dict[str, Any]] = Field(default=None)
    metadata: Optional[Dict[str, Any]] = Field(default=None)

    @classmethod
    def create(
        cls,
        execution_id: str,
        name: str,
        strategy: str = "append",
        merge_path: Optional[str] = None,
        source_step: Optional[str] = None,
        correlation: Optional[Dict[str, Any]] = None
    ) -> "Manifest":
        """Factory method to create a new Manifest."""
        ref_id = str(uuid.uuid4())[:8]
        ref = f"noetl://execution/{execution_id}/manifest/{name}/{ref_id}"

        return cls(
            ref=ref,
            execution_id=execution_id,
            strategy=strategy,
            merge_path=merge_path,
            source_step=source_step,
            correlation=correlation
        )

    def add_part(
        self,
        part_ref: Union[str, TempRef, Dict[str, Any]],
        bytes_size: int = 0,
        meta: Optional[Dict[str, Any]] = None
    ) -> ManifestPart:
        """Add a part to the manifest."""
        if isinstance(part_ref, TempRef):
            ref_value = part_ref.ref
        elif isinstance(part_ref, dict):
            ref_value = part_ref
        else:
            ref_value = part_ref

        part = ManifestPart(
            ref=ref_value,
            index=len(self.parts),
            bytes_size=bytes_size,
            meta=meta
        )
        self.parts.append(part)
        self.total_parts = len(self.parts)
        self.total_bytes += bytes_size
        return part

    def mark_complete(self):
        """Mark the manifest as complete."""
        self.completed_at = datetime.now(timezone.utc)
        self.total_parts = len(self.parts)


# Type aliases for convenience
AnyRef = Union[ResultRef, Manifest, Dict[str, Any], str]


__all__ = [
    "StoreTier",
    "Scope",
    "ResultRefMeta",
    "IpcHint",
    "ResultRef",
    "ManifestPart",
    "Manifest",
    "AnyRef",
    # Legacy aliases
    "TempRefMeta",
    "TempRef",
]
