from datetime import datetime, timedelta, timezone

import pytest

import noetl.server.auto_resume as auto_resume


@pytest.mark.asyncio
async def test_wait_for_dependencies_ready_retries_until_healthy(monkeypatch):
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_READINESS_TIMEOUT_SECONDS", 3.0)
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_READINESS_POLL_SECONDS", 1.0)

    attempts = {"count": 0}

    async def _fake_check():
        attempts["count"] += 1
        if attempts["count"] < 3:
            return False, {"postgres": "down", "nats": "down", "workers": "0"}
        return True, {"postgres": "ok", "nats": "ok", "workers": "1"}

    sleep_calls: list[float] = []

    async def _fake_sleep(seconds: float):
        sleep_calls.append(seconds)

    monkeypatch.setattr(auto_resume, "_check_recovery_dependencies", _fake_check)
    monkeypatch.setattr(auto_resume.asyncio, "sleep", _fake_sleep)

    ready = await auto_resume._wait_for_dependencies_ready()
    assert ready is True
    assert attempts["count"] == 3
    assert sleep_calls == [1.0, 1.0]


@pytest.mark.asyncio
async def test_recover_interrupted_parent_execution_restart_mode(monkeypatch):
    candidate = {
        "execution_id": 42,
        "path": "tests/fixtures/playbooks/hello_world/hello_world",
        "catalog_id": 99,
        "result": {"kind": "data", "data": {"result": {"workload": {"a": 1}}}},
        "created_at": "2026-03-05T00:00:00Z",
    }
    monkeypatch.setattr(auto_resume, "get_recovery_candidates", lambda: _async_value([candidate]))
    monkeypatch.setattr(auto_resume, "get_execution_status", lambda _eid: _async_value("running"))
    monkeypatch.setattr(auto_resume, "_restart_execution", lambda _cand: _async_value("84"))

    calls = []

    async def _fake_mark(exec_id, reason, meta_extra=None, payload_extra=None):
        calls.append(
            {
                "exec_id": exec_id,
                "reason": reason,
                "meta_extra": meta_extra,
                "payload_extra": payload_extra,
            }
        )
        return True

    monkeypatch.setattr(auto_resume, "mark_execution_cancelled", _fake_mark)

    await auto_resume._recover_interrupted_parent_executions(mode="restart")

    assert len(calls) == 1
    assert calls[0]["exec_id"] == 42
    assert calls[0]["meta_extra"]["restarted_execution_id"] == "84"
    assert calls[0]["payload_extra"]["restarted_execution_id"] == "84"


@pytest.mark.asyncio
async def test_recover_interrupted_parent_execution_cancel_mode(monkeypatch):
    candidate = {
        "execution_id": 100,
        "path": "tests/fixtures/playbooks/hello_world/hello_world",
        "catalog_id": 1,
        "result": {},
        "created_at": "2026-03-05T00:00:00Z",
    }
    monkeypatch.setattr(auto_resume, "get_recovery_candidates", lambda: _async_value([candidate]))
    monkeypatch.setattr(auto_resume, "get_execution_status", lambda _eid: _async_value("running"))

    restarted = {"called": 0}

    async def _fake_restart(_candidate):
        restarted["called"] += 1
        return "new-id"

    monkeypatch.setattr(auto_resume, "_restart_execution", _fake_restart)

    cancelled = {"called": 0}

    async def _fake_mark(*_args, **_kwargs):
        cancelled["called"] += 1
        return True

    monkeypatch.setattr(auto_resume, "mark_execution_cancelled", _fake_mark)

    await auto_resume._recover_interrupted_parent_executions(mode="cancel")

    assert restarted["called"] == 0
    assert cancelled["called"] == 1


@pytest.mark.asyncio
async def test_recover_interrupted_parent_execution_skips_fresh_and_recovers_stale(monkeypatch):
    fresh_candidate = {
        "execution_id": 100,
        "path": "fresh",
        "catalog_id": 1,
        "result": {},
        "created_at": "2026-03-24T20:48:11Z",
        "latest_event_at": "2026-03-24T20:48:14Z",
        "latest_event_type": "command.issued",
    }
    stale_candidate = {
        "execution_id": 101,
        "path": "stale",
        "catalog_id": 1,
        "result": {},
        "created_at": "2026-03-24T20:00:00Z",
        "latest_event_at": "2026-03-24T20:05:00Z",
        "latest_event_type": "command.started",
    }
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_MAX_CANDIDATES", 1)
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_MIN_STALE_SECONDS", 180.0)
    monkeypatch.setattr(
        auto_resume,
        "get_recovery_candidates",
        lambda: _async_value([fresh_candidate, stale_candidate]),
    )
    monkeypatch.setattr(auto_resume, "get_execution_status", lambda _eid: _async_value("running"))
    monkeypatch.setattr(auto_resume, "_restart_execution", lambda _cand: _async_value("202"))

    cancelled = []

    async def _fake_mark(exec_id, reason, meta_extra=None, payload_extra=None):
        cancelled.append(exec_id)
        return True

    monkeypatch.setattr(auto_resume, "mark_execution_cancelled", _fake_mark)

    await auto_resume._recover_interrupted_parent_executions(mode="restart")

    assert cancelled == [101]


def test_should_recover_candidate_skips_pending_only_command_issued(monkeypatch):
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_MIN_STALE_SECONDS", 0.0)
    candidate = {
        "created_at": "2026-03-24T20:48:11Z",
        "latest_event_at": "2026-03-24T20:48:14Z",
        "latest_event_type": "command.issued",
    }

    should_recover = auto_resume._should_recover_candidate(
        candidate,
        now=datetime(2026, 3, 24, 21, 0, 0, tzinfo=timezone.utc),
    )

    assert should_recover is False


def test_should_recover_candidate_skips_recent_inflight_execution(monkeypatch):
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_MIN_STALE_SECONDS", 180.0)
    now = datetime(2026, 3, 24, 21, 0, 0, tzinfo=timezone.utc)
    candidate = {
        "created_at": (now - timedelta(seconds=120)).isoformat(),
        "latest_event_at": (now - timedelta(seconds=90)).isoformat(),
        "latest_event_type": "command.started",
    }

    should_recover = auto_resume._should_recover_candidate(candidate, now=now)

    assert should_recover is False


def test_should_recover_candidate_allows_stale_inflight_execution(monkeypatch):
    monkeypatch.setattr(auto_resume, "_AUTO_RESUME_MIN_STALE_SECONDS", 180.0)
    now = datetime(2026, 3, 24, 21, 0, 0, tzinfo=timezone.utc)
    candidate = {
        "created_at": (now - timedelta(minutes=10)).isoformat(),
        "latest_event_at": (now - timedelta(minutes=5)).isoformat(),
        "latest_event_type": "command.started",
    }

    should_recover = auto_resume._should_recover_candidate(candidate, now=now)

    assert should_recover is True


async def _async_value(value):
    return value


class _FakeCursor:
    def __init__(self, row):
        self._row = row

    async def execute(self, _query, _params=None):
        return None

    async def fetchone(self):
        return self._row


class _FakeCursorCtx:
    def __init__(self, cursor):
        self._cursor = cursor

    async def __aenter__(self):
        return self._cursor

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _FakeConn:
    def __init__(self, row):
        self._row = row

    def cursor(self, row_factory=None):
        return _FakeCursorCtx(_FakeCursor(self._row))


class _FakeConnCtx:
    def __init__(self, row):
        self._row = row

    async def __aenter__(self):
        return _FakeConn(self._row)

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _CancelCursor:
    def __init__(self):
        self.query = ""
        self.executed = []

    async def execute(self, query, params=None):
        self.query = query
        self.executed.append((query, params))

    async def fetchone(self):
        if "SELECT catalog_id" in self.query:
            return {"catalog_id": 5}
        return None


class _CancelConn:
    def __init__(self, cursor):
        self._cursor = cursor
        self.commits = 0

    def cursor(self, row_factory=None):
        return _FakeCursorCtx(self._cursor)

    async def commit(self):
        self.commits += 1


class _CancelConnCtx:
    def __init__(self, conn):
        self._conn = conn

    async def __aenter__(self):
        return self._conn

    async def __aexit__(self, exc_type, exc, tb):
        return False


@pytest.mark.asyncio
async def test_mark_execution_cancelled_enqueues_outbox_before_drain(monkeypatch):
    cursor = _CancelCursor()
    conn = _CancelConn(cursor)
    enqueued = []

    async def fake_enqueue(_cur, event):
        enqueued.append(event)

    async def fake_drain():
        assert conn.commits == 1

    async def fake_snowflake_id():
        return 9001

    monkeypatch.setattr(auto_resume, "get_pool_connection", lambda *args, **kwargs: _CancelConnCtx(conn))
    monkeypatch.setattr(auto_resume, "get_snowflake_id", fake_snowflake_id)
    monkeypatch.setattr(auto_resume, "_enqueue_auto_resume_outbox", fake_enqueue)
    monkeypatch.setattr(auto_resume, "_drain_auto_resume_outbox", fake_drain)

    ok = await auto_resume.mark_execution_cancelled(
        7,
        "restart replacement created",
        meta_extra={"restarted_execution_id": "8"},
        payload_extra={"restarted_execution_id": "8"},
    )

    assert ok is True
    assert enqueued[0]["event_id"] == 9001
    assert enqueued[0]["event_type"] == "execution.cancelled"
    assert enqueued[0]["execution_id"] == 7
    assert enqueued[0]["catalog_id"] == 5
    assert enqueued[0]["result"]["context"]["restarted_execution_id"] == "8"
    assert enqueued[0]["meta"]["auto_resume"] is True


@pytest.mark.asyncio
async def test_get_execution_status_treats_workflow_completed_as_completed(monkeypatch):
    row = {"event_type": "workflow.completed", "status": "COMPLETED"}
    monkeypatch.setattr(auto_resume, "get_pool_connection", lambda *args, **kwargs: _FakeConnCtx(row))

    status = await auto_resume.get_execution_status(123)

    assert status == "completed"


@pytest.mark.asyncio
async def test_get_execution_status_treats_workflow_failed_as_failed(monkeypatch):
    row = {"event_type": "workflow.failed", "status": "FAILED"}
    monkeypatch.setattr(auto_resume, "get_pool_connection", lambda *args, **kwargs: _FakeConnCtx(row))

    status = await auto_resume.get_execution_status(456)

    assert status == "failed"
