"""Internal helper to load generated proto modules from the bundled `proto/` directory.

Adds the proto subdirectory to ``sys.path`` once and re-exports the modules so
callers can `from qubecore_client._proto import qubecore_pb2, qubecore_pb2_grpc`.
"""
import sys
from pathlib import Path

_proto_path = str(Path(__file__).parent / "proto")
if _proto_path not in sys.path:
    sys.path.insert(0, _proto_path)

import qubecore_pb2  # noqa: E402
import qubecore_pb2_grpc  # noqa: E402

__all__ = ["qubecore_pb2", "qubecore_pb2_grpc"]
