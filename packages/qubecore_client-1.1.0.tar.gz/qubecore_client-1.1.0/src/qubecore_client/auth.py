import grpc

from qubecore_client._proto import qubecore_pb2, qubecore_pb2_grpc


def _stub(address: str) -> tuple[grpc.Channel, qubecore_pb2_grpc.QubeCoreStub]:
    channel = grpc.insecure_channel(address)
    return channel, qubecore_pb2_grpc.QubeCoreStub(channel)


def login(address: str, username: str, password: str) -> tuple[str, str]:
    """QubeCore gRPC Login. (access_token, refresh_token) 반환."""
    channel, stub = _stub(address)
    try:
        resp = stub.Login(qubecore_pb2.LoginRequest(username=username, password=password))
    finally:
        channel.close()
    if not resp.success:
        raise RuntimeError(resp.message)
    return resp.access_token, resp.refresh_token


def refresh_token(address: str, token: str) -> tuple[str, str]:
    """refresh_token으로 새 (access_token, refresh_token)을 발급."""
    channel, stub = _stub(address)
    try:
        resp = stub.RefreshToken(qubecore_pb2.RefreshTokenRequest(refresh_token=token))
    finally:
        channel.close()
    if not resp.success:
        raise RuntimeError(resp.message)
    return resp.access_token, resp.refresh_token


def logout(address: str, access_token: str) -> None:
    """서버에 Logout 알림 (토큰 삭제는 호출자 책임)."""
    channel, stub = _stub(address)
    try:
        stub.Logout(
            qubecore_pb2.LogoutRequest(),
            metadata=[("authorization", f"Bearer {access_token}")],
        )
    finally:
        channel.close()


def is_token_expired(token: str) -> bool:
    """서명 검증 없이 exp 클레임만 확인. 만료됐거나 파싱 불가하면 True."""
    try:
        from jose import JWTError, jwt
        jwt.decode(token, None, options={"verify_signature": False, "verify_exp": True})
        return False
    except JWTError:
        return True
