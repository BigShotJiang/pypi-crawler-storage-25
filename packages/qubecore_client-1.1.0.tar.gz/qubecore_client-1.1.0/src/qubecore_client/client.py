import json
from collections.abc import Iterator
from typing import Any, Required, TypedDict, cast

import grpc

from qubecore_client._proto import qubecore_pb2, qubecore_pb2_grpc


class JobStatusDict(TypedDict):
    job_id: str
    status: str
    priority: int
    submitted_at: str
    started_at: str
    finished_at: str
    error: str


class GateResultDict(TypedDict):
    counts: dict[str, int]
    s11: dict[str, Any]
    qubit_mapping: dict[str, Any]


class JobResultDict(TypedDict, total=False):
    job_id: Required[str]
    status: Required[str]
    results: list[GateResultDict]
    calibration_result: dict[str, Any]


class UserInfoDict(TypedDict):
    user_id: str
    username: str
    role: str
    created_at: str


class JobSummaryDict(TypedDict):
    job_id: str
    type: str
    status: str
    priority: int
    submitted_at: str
    finished_at: str


class MyJobsDict(TypedDict):
    total: int
    jobs: list[JobSummaryDict]


class CouplingPairDict(TypedDict):
    qubit_a: int
    qubit_b: int


class BackendInfoDict(TypedDict):
    name: str
    num_qubits: int
    coupling_map: list[CouplingPairDict]
    native_gates: list[str]
    qasm_supported_gates: list[str]


class QubitCharacterizationDict(TypedDict):
    index: int
    t1: float
    t2: float
    frequency: float


class CharacterizationDict(TypedDict):
    last_calibrated: str
    qubits: list[QubitCharacterizationDict]


class WiDescanParams(TypedDict, total=False):
    qubit: Required[str]
    freq_span: Required[float]
    n_freqs: Required[int]
    shots: Required[int]


class PunchoutParams(TypedDict, total=False):
    qubit: Required[str]
    freq_span: Required[float]
    n_freqs: Required[int]
    amps: Required[list[float]]
    shots: Required[int]


class ChevronParams(TypedDict, total=False):
    qubit: Required[str]
    freq_span: Required[float]
    n_freqs: Required[int]
    x_twidth: Required[list[float]]
    shots: Required[int]
    center_freq: float


class AmpRabiParams(TypedDict, total=False):
    qubit: Required[str]
    n_amps: Required[int]
    shots: Required[int]
    target_twidth: float
    prior_fit_params: list[float]
    amp_range_min: float
    amp_range_max: float


class TimeRabiParams(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]
    x_twidth: list[float]
    target_amplitude: float


class RamseyParams(TypedDict, total=False):
    qubit: Required[str]
    delay_interval: Required[list[float]]
    shots: Required[int]
    framsey_offsets: list[float]


class T1Params(TypedDict):
    qubit: str
    delay_interval: list[float]
    shots: int


class StackX90Params(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]
    stages: list[dict[str, Any]]


class DragAlphaParams(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]
    alphas: list[float]


class BlobReadoutFreqParams(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]
    dfreads: list[float]


class ReadoutFidelityParams(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]


class GateFidelityParams(TypedDict, total=False):
    qubit: Required[str]
    shots: Required[int]
    lengths: list[int]
    n_seeds: int
    seed_base: int


class QubeClient:

    def __init__(
        self,
        address: str = "localhost:50051",
        token: str | None = None,
        timeout: float | None = 30.0,
    ) -> None:
        self._channel = grpc.insecure_channel(address)
        self._stub = qubecore_pb2_grpc.QubeCoreStub(self._channel)
        self._token = token
        self._timeout = timeout

    def set_token(self, token: str) -> None:
        self._token = token

    def _metadata(self) -> list[tuple[str, str]]:
        if self._token:
            return [("authorization", f"Bearer {self._token}")]
        return []

    def _call(self, rpc: Any, request: Any, **kwargs: Any) -> Any:
        return rpc(request, metadata=self._metadata(), timeout=self._timeout, **kwargs)

    def _submit_calibration(self, request: Any, priority: int | None) -> str:
        if priority is not None:
            request.priority = priority
        resp = self._call(self._stub.SubmitCalibrationJob, request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.job_id)

    @staticmethod
    def _validate_priority(priority: int | None) -> None:
        if priority is not None and priority not in (1, 2, 3, 4):
            raise ValueError(f"priority must be 1–4, got {priority}")

    def submit_gate_job(
        self,
        gate_circuits: list[str],
        shots: int,
        priority: int | None = None,
        optimization_level: int | None = None,
    ) -> str:
        """Submit a batch of gate-level circuits for execution. Returns the job_id.

        Each element of ``gate_circuits`` is a circuit string in one of the
        supported formats — the server detects the format by its leading
        marker and dispatches to the matching converter:

        - **OpenQASM 2.0** — starts with ``OPENQASM 2``
        - **OpenQASM 3.0** — starts with ``OPENQASM 3``
        - **QIR** (LLVM IR) — contains markers such as ``__quantum__``,
          ``target triple``, or ``; ModuleID`` in the first 2 KB.
          Only text IR (``.ll``) is supported; binary bitcode (``.bc``) is not.
        - **JSON** — starts with ``{`` or ``[`` (pulse-level program)

        ``optimization_level`` is ignored for QIR input.
        """
        self._validate_priority(priority)
        request = qubecore_pb2.SubmitGateJobRequest(
            gate_circuits=gate_circuits,
            shots=shots,
        )
        if priority is not None:
            request.priority = priority
        if optimization_level is not None:
            request.optimization_level = optimization_level

        resp = self._call(self._stub.SubmitGateJob, request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.job_id)

    def submit_pulse_job(
        self,
        pulse_circuits: list[str],
        shots: int,
        priority: int | None = None,
    ) -> str:
        self._validate_priority(priority)
        request = qubecore_pb2.SubmitPulseJobRequest(
            pulse_circuits=pulse_circuits,
            shots=shots,
        )
        if priority is not None:
            request.priority = priority

        resp = self._call(self._stub.SubmitPulseJob, request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.job_id)

    def submit_reset_job(
        self,
        qubits: list[str],
        shots: int,
        priority: int | None = None,
    ) -> str:
        self._validate_priority(priority)
        request = qubecore_pb2.SubmitResetJobRequest(
            qubits=qubits,
            shots=shots,
        )
        if priority is not None:
            request.priority = priority

        resp = self._call(self._stub.SubmitResetJob, request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.job_id)

    def submit_widescan_job(self, params: WiDescanParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(
                widescan=qubecore_pb2.WiDescanParams(
                    qubit=params["qubit"], freq_span=params["freq_span"],
                    n_freqs=params["n_freqs"], shots=params["shots"],
                )
            ),
            priority,
        )

    def submit_punchout_job(self, params: PunchoutParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(
                punchout=qubecore_pb2.PunchoutParams(
                    qubit=params["qubit"], freq_span=params["freq_span"],
                    n_freqs=params["n_freqs"], amps=params["amps"], shots=params["shots"],
                )
            ),
            priority,
        )

    def submit_chevron_job(self, params: ChevronParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.ChevronParams(
            qubit=params["qubit"], freq_span=params["freq_span"],
            n_freqs=params["n_freqs"], shots=params["shots"],
        )
        proto_params.x_twidth.extend(params["x_twidth"])
        if "center_freq" in params:
            proto_params.center_freq = params["center_freq"]
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(chevron=proto_params), priority
        )

    def submit_amp_rabi_job(self, params: AmpRabiParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.AmpRabiParams(
            qubit=params["qubit"], n_amps=params["n_amps"], shots=params["shots"],
            amp_range_min=params.get("amp_range_min", 0.0),
            amp_range_max=params.get("amp_range_max", 1.0),
        )
        if "target_twidth" in params:
            proto_params.target_twidth = params["target_twidth"]
        if "prior_fit_params" in params:
            proto_params.prior_fit_params_json = json.dumps(params["prior_fit_params"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(amp_rabi=proto_params), priority
        )

    def submit_time_rabi_job(self, params: TimeRabiParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.TimeRabiParams(qubit=params["qubit"], shots=params["shots"])
        if "x_twidth" in params:
            proto_params.x_twidth.extend(params["x_twidth"])
        if "target_amplitude" in params:
            proto_params.target_amplitude = params["target_amplitude"]
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(time_rabi=proto_params), priority
        )

    def submit_ramsey_job(self, params: RamseyParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.RamseyParams(
            qubit=params["qubit"], delay_interval=params["delay_interval"], shots=params["shots"],
        )
        if "framsey_offsets" in params:
            proto_params.framsey_offsets.extend(params["framsey_offsets"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(ramsey=proto_params), priority
        )

    def submit_t1_job(self, params: T1Params, priority: int | None = None) -> str:
        self._validate_priority(priority)
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(
                t1=qubecore_pb2.T1Params(
                    qubit=params["qubit"], delay_interval=params["delay_interval"], shots=params["shots"],
                )
            ),
            priority,
        )

    def submit_stack_x90_job(self, params: StackX90Params, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.StackX90Params(qubit=params["qubit"], shots=params["shots"])
        if "stages" in params:
            proto_params.stages_json = json.dumps(params["stages"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(stack_x90=proto_params), priority
        )

    def submit_drag_alpha_job(self, params: DragAlphaParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.DragAlphaParams(qubit=params["qubit"], shots=params["shots"])
        if "alphas" in params:
            proto_params.alphas.extend(params["alphas"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(drag_alpha=proto_params), priority
        )

    def submit_blob_readout_freq_job(self, params: BlobReadoutFreqParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.BlobReadoutFreqParams(qubit=params["qubit"], shots=params["shots"])
        if "dfreads" in params:
            proto_params.dfreads.extend(params["dfreads"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(blob_readout_freq=proto_params), priority
        )

    def submit_readout_fidelity_job(self, params: ReadoutFidelityParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.ReadoutFidelityParams(qubit=params["qubit"], shots=params["shots"])
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(readout_fidelity=proto_params), priority
        )

    def submit_gate_fidelity_job(self, params: GateFidelityParams, priority: int | None = None) -> str:
        self._validate_priority(priority)
        proto_params = qubecore_pb2.GateFidelityParams(qubit=params["qubit"], shots=params["shots"])
        if "lengths" in params:
            proto_params.lengths.extend(params["lengths"])
        if "n_seeds" in params:
            proto_params.n_seeds = params["n_seeds"]
        if "seed_base" in params:
            proto_params.seed_base = params["seed_base"]
        return self._submit_calibration(
            qubecore_pb2.SubmitCalibrationJobRequest(gate_fidelity=proto_params), priority
        )

    def get_job_status(self, job_id: str) -> JobStatusDict:
        resp = self._call(self._stub.GetJobStatus, qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.found:
            raise ValueError(resp.message)
        return {
            "job_id":       resp.job_id,
            "status":       resp.status,
            "priority":     resp.priority,
            "submitted_at": resp.submitted_at,
            "started_at":   resp.started_at,
            "finished_at":  resp.finished_at,
            "error":        resp.error,
        }

    def get_job_result(self, job_id: str) -> JobResultDict:
        resp = self._call(self._stub.GetJobResult, qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.found:
            raise ValueError(resp.message)

        if resp.status in ("PENDING", "RUNNING"):
            raise ValueError(f"[{resp.status}] {resp.message or 'job is not yet complete'}")
        if resp.status in ("FAILED", "CANCELLED"):
            raise RuntimeError(f"[{resp.status}] {resp.message or 'job did not complete successfully'}")

        result: JobResultDict = {
            "job_id": resp.job_id,
            "status": resp.status,
        }

        if resp.calibration_result_json:
            try:
                result["calibration_result"] = json.loads(resp.calibration_result_json)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid calibration_result_json from server: {e}") from e
        else:
            result["results"] = []
            for r in resp.results:
                try:
                    result["results"].append(self._parse_gate_result_json(
                        counts_json=r.counts_json,
                        s11_json=r.s11_json,
                        qubit_mapping_json=r.qubit_mapping_json,
                    ))
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid result JSON from server: {e}") from e

        return result

    def stream_gate_job(
        self,
        circuit_template: str,
        params_list: list[dict[str, float]],
        shots: int,
        priority: int | None = None,
        optimization_level: int | None = None,
    ) -> Iterator[GateResultDict]:
        """Run the same gate circuit repeatedly with different parameter sets.

        ``circuit_template`` is a string with Python ``str.format`` placeholders
        (e.g. ``"... rx({theta}) q[0] ..."``). The same format support as
        :meth:`submit_gate_job` applies — OpenQASM 2.0, OpenQASM 3.0, QIR, or
        JSON — provided the placeholders survive the format. Plain-text
        templates (QASM 2.0 / 3.0) work most naturally.
        """
        self._validate_priority(priority)

        def _requests() -> Iterator[Any]:
            for i, params in enumerate(params_list):
                req = qubecore_pb2.StreamGateJobRequest(
                    params=params,
                    shots=shots,
                )
                if i == 0:
                    req.circuit_template = circuit_template
                    if priority is not None:
                        req.priority = priority
                    if optimization_level is not None:
                        req.optimization_level = optimization_level
                yield req

        for response in self._stub.StreamGateJob(
            _requests(), metadata=self._metadata(), timeout=self._timeout
        ):
            if not response.success:
                raise RuntimeError(response.error)
            try:
                yield self._parse_gate_result_json(
                    counts_json=response.result.counts_json,
                    s11_json=response.result.s11_json,
                    qubit_mapping_json=response.result.qubit_mapping_json,
                )
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid stream result JSON from server: {e}") from e

    def cancel_job(self, job_id: str) -> str:
        resp = self._call(self._stub.CancelJob, qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.message)

    def get_me(self) -> UserInfoDict:
        resp = self._call(self._stub.GetMe, qubecore_pb2.GetMeRequest())
        return {
            "user_id":    resp.user_id,
            "username":   resp.username,
            "role":       resp.role,
            "created_at": resp.created_at,
        }

    def get_my_jobs(self, page: int = 1, page_size: int = 20) -> MyJobsDict:
        if page < 1:
            raise ValueError(f"page must be >= 1, got {page}")
        resp = self._call(
            self._stub.GetMyJobs,
            qubecore_pb2.GetMyJobsRequest(
                limit=page_size,
                offset=(page - 1) * page_size,
            ),
        )
        return {
            "total": resp.total,
            "jobs": [
                {
                    "job_id":       j.job_id,
                    "type":         j.type,
                    "status":       j.status,
                    "priority":     j.priority,
                    "submitted_at": j.submitted_at,
                    "finished_at":  j.finished_at,
                }
                for j in resp.jobs
            ],
        }

    def get_backend_info(self) -> BackendInfoDict:
        resp = self._call(self._stub.GetBackendInfo, qubecore_pb2.BackendRequest())
        return {
            "name":                 resp.name,
            "num_qubits":           resp.num_qubits,
            "coupling_map":         [{"qubit_a": p.qubit_a, "qubit_b": p.qubit_b} for p in resp.coupling_map],
            "native_gates":         list(resp.native_gates),
            "qasm_supported_gates": list(resp.qasm_supported_gates),
        }

    def get_characterization(self) -> CharacterizationDict:
        resp = self._call(self._stub.GetCharacterization, qubecore_pb2.BackendRequest())
        return {
            "last_calibrated": resp.last_calibrated,
            "qubits": [
                {"index": q.index, "t1": q.t1, "t2": q.t2, "frequency": q.frequency}
                for q in resp.qubits
            ],
        }

    def update_characterization(self, qubits: list[str] | None = None) -> str:
        request = qubecore_pb2.UpdateCharacterizationRequest(
            qubits=qubits or [],
        )
        resp = self._call(self._stub.UpdateCharacterization, request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return cast(str, resp.message)

    def close(self) -> None:
        self._channel.close()

    def __del__(self) -> None:
        try:
            self._channel.close()
        except Exception:
            pass

    def __enter__(self) -> "QubeClient":
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> bool | None:
        self.close()
        return None

    @staticmethod
    def _parse_gate_result_json(
        counts_json: str,
        s11_json: str,
        qubit_mapping_json: str,
    ) -> GateResultDict:
        return {
            "counts":        json.loads(counts_json) if counts_json else {},
            "s11":           json.loads(s11_json) if s11_json else {},
            "qubit_mapping": json.loads(qubit_mapping_json) if qubit_mapping_json else {},
        }
