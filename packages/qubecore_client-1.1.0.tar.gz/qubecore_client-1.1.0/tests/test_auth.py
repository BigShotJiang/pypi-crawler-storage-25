"""Tests for qubecore_client.auth module."""
from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_stub_response(**kwargs):
    """Return a MagicMock with attribute access for the given kwargs."""
    resp = MagicMock()
    for k, v in kwargs.items():
        setattr(resp, k, v)
    return resp


# ---------------------------------------------------------------------------
# login()
# ---------------------------------------------------------------------------

class TestLogin:
    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_login_success(self, mock_channel_factory):
        """login() returns (access_token, refresh_token) on success."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()
        mock_stub.Login.return_value = _make_stub_response(
            success=True,
            message="ok",
            access_token="acc123",
            refresh_token="ref456",
        )

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import login
            acc, ref = login("localhost:50051", "alice", "secret")

        assert acc == "acc123"
        assert ref == "ref456"
        mock_channel.close.assert_called_once()

    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_login_failure_raises(self, mock_channel_factory):
        """login() raises RuntimeError when success=False."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()
        mock_stub.Login.return_value = _make_stub_response(
            success=False,
            message="bad credentials",
        )

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import login
            with pytest.raises(RuntimeError, match="bad credentials"):
                login("localhost:50051", "alice", "wrong")

        mock_channel.close.assert_called_once()

    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_login_closes_channel_on_exception(self, mock_channel_factory):
        """login() closes the channel even when the RPC itself raises."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()
        mock_stub.Login.side_effect = Exception("network error")

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import login
            with pytest.raises(Exception, match="network error"):
                login("localhost:50051", "alice", "secret")

        mock_channel.close.assert_called_once()


# ---------------------------------------------------------------------------
# refresh_token()
# ---------------------------------------------------------------------------

class TestRefreshToken:
    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_refresh_success(self, mock_channel_factory):
        """refresh_token() returns rotated access/refresh tokens on success."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()
        mock_stub.RefreshToken.return_value = _make_stub_response(
            success=True,
            access_token="new_acc_token",
            refresh_token="new_ref_token",
        )

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import refresh_token
            access_token, refresh_tok = refresh_token("localhost:50051", "ref_tok")

        assert access_token == "new_acc_token"
        assert refresh_tok == "new_ref_token"
        mock_channel.close.assert_called_once()

    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_refresh_failure_raises(self, mock_channel_factory):
        """refresh_token() raises RuntimeError on failure."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()
        mock_stub.RefreshToken.return_value = _make_stub_response(
            success=False,
            message="token expired",
        )

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import refresh_token
            with pytest.raises(RuntimeError, match="token expired"):
                refresh_token("localhost:50051", "bad_ref_tok")

        mock_channel.close.assert_called_once()


# ---------------------------------------------------------------------------
# logout()
# ---------------------------------------------------------------------------

class TestLogout:
    @patch("qubecore_client.auth.grpc.insecure_channel")
    def test_logout_calls_rpc(self, mock_channel_factory):
        """logout() calls Logout RPC with correct authorization metadata."""
        mock_channel = MagicMock()
        mock_channel_factory.return_value = mock_channel

        mock_stub = MagicMock()

        with patch("qubecore_client.auth.qubecore_pb2_grpc.QubeCoreStub", return_value=mock_stub):
            from qubecore_client.auth import logout
            logout("localhost:50051", "my_token")

        mock_stub.Logout.assert_called_once()
        call_kwargs = mock_stub.Logout.call_args
        metadata = call_kwargs.kwargs.get("metadata") or call_kwargs.args[1]
        assert ("authorization", "Bearer my_token") in metadata
        mock_channel.close.assert_called_once()


# ---------------------------------------------------------------------------
# is_token_expired()
# ---------------------------------------------------------------------------

class TestIsTokenExpired:
    def _make_jwt(self, exp_offset: int) -> str:
        """Create a real JWT with exp = now + exp_offset seconds."""
        from jose import jwt as jose_jwt
        payload = {"sub": "user1", "exp": int(time.time()) + exp_offset}
        return jose_jwt.encode(payload, "secret", algorithm="HS256")

    def test_valid_token_returns_false(self):
        """A non-expired token returns False."""
        from qubecore_client.auth import is_token_expired
        token = self._make_jwt(3600)
        assert is_token_expired(token) is False

    def test_expired_token_returns_true(self):
        """An already-expired token returns True."""
        from qubecore_client.auth import is_token_expired
        token = self._make_jwt(-1)
        assert is_token_expired(token) is True

    def test_garbage_string_returns_true(self):
        """Unparseable input is treated as expired."""
        from qubecore_client.auth import is_token_expired
        assert is_token_expired("not.a.jwt") is True

    def test_empty_string_returns_true(self):
        """Empty string is treated as expired."""
        from qubecore_client.auth import is_token_expired
        assert is_token_expired("") is True
