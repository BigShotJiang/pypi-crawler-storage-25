"""Tests for qubecore_client.client.QubeClient."""
from __future__ import annotations

import json
from unittest.mock import MagicMock, call, patch

import pytest

from qubecore_client.client import QubeClient
from qubecore_client._proto import qubecore_pb2


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def client():
    """Return a QubeClient with _stub replaced by a MagicMock."""
    c = QubeClient("localhost:50051", token="test_token")
    c._stub = MagicMock()
    return c


@pytest.fixture()
def client_no_token():
    """Return a QubeClient without a token."""
    c = QubeClient("localhost:50051")
    c._stub = MagicMock()
    return c


def _resp(**kwargs):
    r = MagicMock()
    for k, v in kwargs.items():
        setattr(r, k, v)
    return r


# ---------------------------------------------------------------------------
# _metadata
# ---------------------------------------------------------------------------

class TestMetadata:
    def test_with_token(self, client):
        assert client._metadata() == [("authorization", "Bearer test_token")]

    def test_without_token(self, client_no_token):
        assert client_no_token._metadata() == []

    def test_set_token(self, client_no_token):
        client_no_token.set_token("new_tok")
        assert client_no_token._metadata() == [("authorization", "Bearer new_tok")]


# ---------------------------------------------------------------------------
# submit_gate_job
# ---------------------------------------------------------------------------

class TestSubmitGateJob:
    def test_success_returns_job_id(self, client):
        client._stub.SubmitGateJob.return_value = _resp(success=True, job_id="g-001", message="")
        jid = client.submit_gate_job(["OPENQASM 3;"], shots=100)
        assert jid == "g-001"

    def test_with_priority_and_optimization(self, client):
        client._stub.SubmitGateJob.return_value = _resp(success=True, job_id="g-002", message="")
        client.submit_gate_job(["OPENQASM 3;"], shots=50, priority=2, optimization_level=1)
        req = client._stub.SubmitGateJob.call_args.args[0]
        assert req.priority == 2
        assert req.optimization_level == 1

    def test_failure_raises_runtime_error(self, client):
        client._stub.SubmitGateJob.return_value = _resp(success=False, job_id="", message="queue full")
        with pytest.raises(RuntimeError, match="queue full"):
            client.submit_gate_job(["OPENQASM 3;"], shots=100)

    def test_metadata_passed(self, client):
        client._stub.SubmitGateJob.return_value = _resp(success=True, job_id="g-003", message="")
        client.submit_gate_job(["OPENQASM 3;"], shots=10)
        _, kwargs = client._stub.SubmitGateJob.call_args
        assert ("authorization", "Bearer test_token") in kwargs["metadata"]

    @pytest.mark.parametrize(
        "fmt,circuit",
        [
            ("qasm2", 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; h q[0]; measure q[0]->c[0];'),
            ("qasm3", 'OPENQASM 3; include "stdgates.inc"; qubit[1] q; bit[1] c; h q[0]; c[0] = measure q[0];'),
            ("qir",   "; ModuleID = 'bell'\ntarget triple = \"x86_64-unknown-linux-gnu\"\ndefine void @main() { call void @__quantum__qis__h__body(); ret void }"),
            ("json",  '[{"name":"X90","qubit":"qubit_0"},{"name":"read","qubit":"qubit_0"}]'),
        ],
    )
    def test_circuit_string_forwarded_unchanged(self, client, fmt, circuit):
        """The client must forward the circuit string verbatim regardless of format —
        format detection happens server-side, not in the SDK."""
        client._stub.SubmitGateJob.return_value = _resp(success=True, job_id=f"g-{fmt}", message="")
        jid = client.submit_gate_job([circuit], shots=10)
        assert jid == f"g-{fmt}"
        req = client._stub.SubmitGateJob.call_args.args[0]
        assert list(req.gate_circuits) == [circuit]


# ---------------------------------------------------------------------------
# submit_pulse_job
# ---------------------------------------------------------------------------

class TestSubmitPulseJob:
    def test_success(self, client):
        client._stub.SubmitPulseJob.return_value = _resp(success=True, job_id="p-001", message="")
        jid = client.submit_pulse_job(["pulse_data"], shots=200)
        assert jid == "p-001"

    def test_failure_raises(self, client):
        client._stub.SubmitPulseJob.return_value = _resp(success=False, job_id="", message="error")
        with pytest.raises(RuntimeError, match="error"):
            client.submit_pulse_job(["pulse_data"], shots=200)

    def test_priority_set(self, client):
        client._stub.SubmitPulseJob.return_value = _resp(success=True, job_id="p-002", message="")
        client.submit_pulse_job(["pulse_data"], shots=10, priority=2)
        req = client._stub.SubmitPulseJob.call_args.args[0]
        assert req.priority == 2


# ---------------------------------------------------------------------------
# submit_reset_job
# ---------------------------------------------------------------------------

class TestSubmitResetJob:
    def test_success(self, client):
        client._stub.SubmitResetJob.return_value = _resp(success=True, job_id="r-001", message="")
        jid = client.submit_reset_job(["q0", "q1"], shots=50)
        assert jid == "r-001"

    def test_failure_raises(self, client):
        client._stub.SubmitResetJob.return_value = _resp(success=False, job_id="", message="bad qubits")
        with pytest.raises(RuntimeError, match="bad qubits"):
            client.submit_reset_job(["q0"], shots=50)


# ---------------------------------------------------------------------------
# submit_widescan_job / submit_punchout_job
# ---------------------------------------------------------------------------

class TestSubmitWiDescanJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-001", message="")
        jid = client.submit_widescan_job({"qubit": "qubit_0", "freq_span": 100_000_000.0, "n_freqs": 200, "shots": 100})
        assert jid == "c-001"

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="widescan err")
        with pytest.raises(RuntimeError, match="widescan err"):
            client.submit_widescan_job({"qubit": "qubit_0", "freq_span": 100_000_000.0, "n_freqs": 200, "shots": 100})


class TestSubmitPunchoutJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-002", message="")
        jid = client.submit_punchout_job({
            "qubit": "qubit_0", "freq_span": 20_000_000.0,
            "n_freqs": 20, "amps": [0.01, 0.05, 0.1], "shots": 100,
        })
        assert jid == "c-002"

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="punchout err")
        with pytest.raises(RuntimeError, match="punchout err"):
            client.submit_punchout_job({
                "qubit": "qubit_0", "freq_span": 20_000_000.0,
                "n_freqs": 20, "amps": [0.01, 0.05, 0.1], "shots": 100,
            })


class TestSubmitChevronJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-003", message="")
        jid = client.submit_chevron_job({
            "qubit": "qubit_0", "freq_span": 1e6,
            "n_freqs": 20, "x_twidth": [1e-8, 2e-8], "shots": 100,
        })
        assert jid == "c-003"

    def test_with_optional_center_freq(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-003", message="")
        client.submit_chevron_job({
            "qubit": "qubit_0", "freq_span": 1e6, "n_freqs": 20,
            "x_twidth": [1e-8], "shots": 50, "center_freq": 5.0e9,
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert req.chevron.center_freq == 5.0e9

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="chevron err")
        with pytest.raises(RuntimeError, match="chevron err"):
            client.submit_chevron_job({
                "qubit": "qubit_0", "freq_span": 1e6,
                "n_freqs": 10, "x_twidth": [1e-8], "shots": 100,
            })


class TestSubmitAmpRabiJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-004", message="")
        jid = client.submit_amp_rabi_job({
            "qubit": "qubit_0", "n_amps": 10, "shots": 100,
        })
        assert jid == "c-004"

    def test_with_optional_fields(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-004", message="")
        client.submit_amp_rabi_job({
            "qubit": "qubit_0", "n_amps": 10,
            "shots": 100, "prior_fit_params": [1.0, 2.0],
            "amp_range_min": 0.1, "amp_range_max": 0.9,
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert req.amp_rabi.amp_range_min == pytest.approx(0.1)
        assert req.amp_rabi.amp_range_max == pytest.approx(0.9)

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="amp_rabi err")
        with pytest.raises(RuntimeError, match="amp_rabi err"):
            client.submit_amp_rabi_job({
                "qubit": "qubit_0", "n_amps": 10, "shots": 100,
            })


class TestSubmitTimeRabiJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-005", message="")
        jid = client.submit_time_rabi_job({
            "qubit": "qubit_0", "shots": 100, "x_twidth": [1e-8, 2e-8, 3e-8],
        })
        assert jid == "c-005"

    def test_with_optional_target_amplitude(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-005", message="")
        client.submit_time_rabi_job({
            "qubit": "qubit_0", "shots": 50, "x_twidth": [1e-8],
            "target_amplitude": 0.5,
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert req.time_rabi.target_amplitude == pytest.approx(0.5)

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="time_rabi err")
        with pytest.raises(RuntimeError, match="time_rabi err"):
            client.submit_time_rabi_job({
                "qubit": "qubit_0", "shots": 100,
            })


class TestSubmitRamseyJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-006", message="")
        jid = client.submit_ramsey_job({
            "qubit": "qubit_0", "delay_interval": [1e-7, 2e-7], "shots": 100,
        })
        assert jid == "c-006"

    def test_with_optional_framsey_offsets(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-006", message="")
        client.submit_ramsey_job({
            "qubit": "qubit_0", "delay_interval": [1e-7], "shots": 50,
            "framsey_offsets": [0.0, 0.5],
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert list(req.ramsey.framsey_offsets) == [0.0, 0.5]

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="ramsey err")
        with pytest.raises(RuntimeError, match="ramsey err"):
            client.submit_ramsey_job({
                "qubit": "qubit_0", "delay_interval": [1e-7], "shots": 100,
            })


class TestSubmitT1Job:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-007", message="")
        jid = client.submit_t1_job({
            "qubit": "qubit_0", "delay_interval": [1e-6, 5e-6, 1e-5], "shots": 100,
        })
        assert jid == "c-007"

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="t1 err")
        with pytest.raises(RuntimeError, match="t1 err"):
            client.submit_t1_job({
                "qubit": "qubit_0", "delay_interval": [1e-6], "shots": 100,
            })


class TestSubmitStackX90Job:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-008", message="")
        jid = client.submit_stack_x90_job({"qubit": "qubit_0", "shots": 100})
        assert jid == "c-008"

    def test_with_optional_stages(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-008", message="")
        stages = [{"amp": 0.5, "phase": 0.0}]
        client.submit_stack_x90_job({
            "qubit": "qubit_0", "shots": 100, "stages": stages,
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert json.loads(req.stack_x90.stages_json) == stages

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="stack_x90 err")
        with pytest.raises(RuntimeError, match="stack_x90 err"):
            client.submit_stack_x90_job({"qubit": "qubit_0", "shots": 100})


class TestSubmitDragAlphaJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-009", message="")
        jid = client.submit_drag_alpha_job({"qubit": "qubit_0", "shots": 100})
        assert jid == "c-009"

    def test_with_optional_alphas(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-009", message="")
        client.submit_drag_alpha_job({
            "qubit": "qubit_0", "shots": 50, "alphas": [-0.5, 0.0, 0.5],
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert list(req.drag_alpha.alphas) == [-0.5, 0.0, 0.5]

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="drag_alpha err")
        with pytest.raises(RuntimeError, match="drag_alpha err"):
            client.submit_drag_alpha_job({"qubit": "qubit_0", "shots": 100})


class TestSubmitBlobReadoutFreqJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-010", message="")
        jid = client.submit_blob_readout_freq_job({"qubit": "qubit_0", "shots": 100})
        assert jid == "c-010"

    def test_with_optional_dfreads(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-010", message="")
        client.submit_blob_readout_freq_job({
            "qubit": "qubit_0", "shots": 50, "dfreads": [-1e6, 0.0, 1e6],
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert list(req.blob_readout_freq.dfreads) == [-1e6, 0.0, 1e6]

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="blob err")
        with pytest.raises(RuntimeError, match="blob err"):
            client.submit_blob_readout_freq_job({"qubit": "qubit_0", "shots": 100})


class TestSubmitReadoutFidelityJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-011", message="")
        jid = client.submit_readout_fidelity_job({"qubit": "qubit_0", "shots": 1000})
        assert jid == "c-011"

    def test_proto_fields_set(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-011", message="")
        client.submit_readout_fidelity_job({"qubit": "qubit_0", "shots": 500})
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert req.readout_fidelity.qubit == "qubit_0"
        assert req.readout_fidelity.shots == 500

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="rf err")
        with pytest.raises(RuntimeError, match="rf err"):
            client.submit_readout_fidelity_job({"qubit": "qubit_0", "shots": 100})


class TestSubmitGateFidelityJob:
    def test_success(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-012", message="")
        jid = client.submit_gate_fidelity_job({"qubit": "qubit_0", "shots": 100})
        assert jid == "c-012"

    def test_with_optional_lengths_and_seeds(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-012", message="")
        client.submit_gate_fidelity_job({
            "qubit": "qubit_0", "shots": 100, "lengths": [1, 2, 4, 8], "n_seeds": 5, "seed_base": 42,
        })
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert list(req.gate_fidelity.lengths) == [1, 2, 4, 8]
        assert req.gate_fidelity.n_seeds == 5
        assert req.gate_fidelity.seed_base == 42

    def test_without_optional_params(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=True, job_id="c-012", message="")
        client.submit_gate_fidelity_job({"qubit": "qubit_0", "shots": 100})
        req = client._stub.SubmitCalibrationJob.call_args.args[0]
        assert list(req.gate_fidelity.lengths) == []
        assert req.gate_fidelity.n_seeds == 0

    def test_failure_raises(self, client):
        client._stub.SubmitCalibrationJob.return_value = _resp(success=False, job_id="", message="gf err")
        with pytest.raises(RuntimeError, match="gf err"):
            client.submit_gate_fidelity_job({"qubit": "qubit_0", "shots": 100})


# ---------------------------------------------------------------------------
# get_job_status
# ---------------------------------------------------------------------------

class TestGetJobStatus:
    def test_success(self, client):
        client._stub.GetJobStatus.return_value = _resp(
            found=True,
            job_id="j-1",
            status="DONE",
            priority=1,
            submitted_at="2024-01-01T00:00:00Z",
            started_at="2024-01-01T00:01:00Z",
            finished_at="2024-01-01T00:02:00Z",
            error="",
        )
        result = client.get_job_status("j-1")
        assert result["job_id"] == "j-1"
        assert result["status"] == "DONE"

    def test_not_found_raises_value_error(self, client):
        client._stub.GetJobStatus.return_value = _resp(found=False, message="not found")
        with pytest.raises(ValueError, match="not found"):
            client.get_job_status("missing")


# ---------------------------------------------------------------------------
# get_job_result
# ---------------------------------------------------------------------------

class TestGetJobResult:
    def _gate_result_mock(self, counts, s11=None, mapping=None):
        r = MagicMock()
        r.counts_json = json.dumps(counts)
        r.s11_json = json.dumps(s11 or {})
        r.qubit_mapping_json = json.dumps(mapping or {})
        return r

    def test_gate_result(self, client):
        resp = _resp(
            found=True,
            job_id="j-2",
            status="COMPLETED",
            calibration_result_json="",
            message="",
        )
        resp.results = [self._gate_result_mock({"00": 50, "11": 50})]
        client._stub.GetJobResult.return_value = resp

        result = client.get_job_result("j-2")
        assert result["job_id"] == "j-2"
        assert result["results"][0]["counts"] == {"00": 50, "11": 50}

    def test_calibration_result(self, client):
        cal_data = {"T1": 45.3}
        resp = _resp(
            found=True,
            job_id="j-3",
            status="COMPLETED",
            calibration_result_json=json.dumps(cal_data),
            message="",
        )
        resp.results = []
        client._stub.GetJobResult.return_value = resp

        result = client.get_job_result("j-3")
        assert result["calibration_result"] == cal_data
        assert "results" not in result

    def test_not_found_raises(self, client):
        client._stub.GetJobResult.return_value = _resp(found=False, message="gone")
        with pytest.raises(ValueError, match="gone"):
            client.get_job_result("x")

    def test_invalid_calibration_json_raises(self, client):
        resp = _resp(
            found=True,
            job_id="j-4",
            status="COMPLETED",
            calibration_result_json="{bad json",
            message="",
        )
        resp.results = []
        client._stub.GetJobResult.return_value = resp
        with pytest.raises(ValueError, match="Invalid calibration_result_json"):
            client.get_job_result("j-4")


# ---------------------------------------------------------------------------
# cancel_job
# ---------------------------------------------------------------------------

class TestCancelJob:
    def test_success(self, client):
        client._stub.CancelJob.return_value = _resp(success=True, message="cancelled")
        msg = client.cancel_job("j-10")
        assert msg == "cancelled"

    def test_failure_raises(self, client):
        client._stub.CancelJob.return_value = _resp(success=False, message="cannot cancel")
        with pytest.raises(RuntimeError, match="cannot cancel"):
            client.cancel_job("j-10")


# ---------------------------------------------------------------------------
# get_me
# ---------------------------------------------------------------------------

class TestGetMe:
    def test_returns_user_info(self, client):
        client._stub.GetMe.return_value = _resp(
            user_id="u-1",
            username="alice",
            role="user",
            created_at="2024-01-01",
        )
        info = client.get_me()
        assert info["username"] == "alice"
        assert info["role"] == "user"


# ---------------------------------------------------------------------------
# get_my_jobs
# ---------------------------------------------------------------------------

class TestGetMyJobs:
    def test_pagination_offset(self, client):
        resp = MagicMock()
        resp.total = 0
        resp.jobs = []
        client._stub.GetMyJobs.return_value = resp
        client.get_my_jobs(page=3, page_size=10)
        req = client._stub.GetMyJobs.call_args.args[0]
        assert req.limit == 10
        assert req.offset == 20  # (3-1)*10

    def test_returns_job_list(self, client):
        job = _resp(
            job_id="j-5",
            type="GATE",
            status="DONE",
            priority=1,
            submitted_at="2024-01-01",
            finished_at="2024-01-02",
        )
        resp = MagicMock()
        resp.total = 1
        resp.jobs = [job]
        client._stub.GetMyJobs.return_value = resp
        result = client.get_my_jobs()
        assert result["total"] == 1
        assert result["jobs"][0]["job_id"] == "j-5"


# ---------------------------------------------------------------------------
# get_backend_info
# ---------------------------------------------------------------------------

class TestGetBackendInfo:
    def test_returns_backend_info(self, client):
        coupling = _resp(qubit_a=0, qubit_b=1)
        resp = _resp(
            name="QPU-A",
            num_qubits=2,
            native_gates=["CZ", "RZ"],
            qasm_supported_gates=["cx", "h"],
        )
        resp.coupling_map = [coupling]
        client._stub.GetBackendInfo.return_value = resp

        info = client.get_backend_info()
        assert info["name"] == "QPU-A"
        assert info["num_qubits"] == 2
        assert info["coupling_map"] == [{"qubit_a": 0, "qubit_b": 1}]


# ---------------------------------------------------------------------------
# get_characterization
# ---------------------------------------------------------------------------

class TestGetCharacterization:
    def test_returns_characterization(self, client):
        q = _resp(index=0, t1=45.0, t2=30.0, frequency=5.0)
        resp = _resp(last_calibrated="2024-01-01")
        resp.qubits = [q]
        client._stub.GetCharacterization.return_value = resp

        result = client.get_characterization()
        assert result["last_calibrated"] == "2024-01-01"
        assert result["qubits"][0]["t1"] == 45.0


# ---------------------------------------------------------------------------
# update_characterization
# ---------------------------------------------------------------------------

class TestUpdateCharacterization:
    def test_all_qubits_success(self, client):
        client._stub.UpdateCharacterization.return_value = _resp(success=True, message="updated: all qubits")
        msg = client.update_characterization(qubits=None)
        assert msg == "updated: all qubits"
        req = client._stub.UpdateCharacterization.call_args.args[0]
        assert list(req.qubits) == []

    def test_specific_qubits_passes_list(self, client):
        client._stub.UpdateCharacterization.return_value = _resp(success=True, message="updated: qubit_0")
        msg = client.update_characterization(qubits=["qubit_0"])
        assert msg == "updated: qubit_0"
        req = client._stub.UpdateCharacterization.call_args.args[0]
        assert list(req.qubits) == ["qubit_0"]

    def test_failure_raises(self, client):
        client._stub.UpdateCharacterization.return_value = _resp(success=False, message="err")
        with pytest.raises(RuntimeError, match="err"):
            client.update_characterization()


# ---------------------------------------------------------------------------
# stream_gate_job
# ---------------------------------------------------------------------------

class TestStreamGateJob:
    def _make_stream_response(self, counts):
        resp = MagicMock()
        resp.success = True
        resp.error = ""
        resp.result.counts_json = json.dumps(counts)
        resp.result.s11_json = json.dumps({})
        resp.result.qubit_mapping_json = json.dumps({})
        return resp

    def test_yields_results(self, client):
        stream_resps = [
            self._make_stream_response({"00": 40, "11": 60}),
            self._make_stream_response({"01": 50, "10": 50}),
        ]
        client._stub.StreamGateJob.return_value = iter(stream_resps)

        results = list(client.stream_gate_job(
            circuit_template="template",
            params_list=[{"theta": 0.1}, {"theta": 0.2}],
            shots=100,
        ))
        assert len(results) == 2
        assert results[0]["counts"] == {"00": 40, "11": 60}

    def test_failure_raises(self, client):
        resp = MagicMock()
        resp.success = False
        resp.error = "stream error"
        client._stub.StreamGateJob.return_value = iter([resp])

        with pytest.raises(RuntimeError, match="stream error"):
            list(client.stream_gate_job("template", [{"theta": 0.0}], shots=10))

    @pytest.mark.parametrize(
        "fmt,template",
        [
            ("qasm2", 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; rx({theta}) q[0]; measure q[0]->c[0];'),
            ("qasm3", 'OPENQASM 3; include "stdgates.inc"; qubit[1] q; bit[1] c; rx({theta}, q[0]); c[0] = measure q[0];'),
            ("qir",   "; ModuleID = 'bell'\ndefine void @main() { call void @__quantum__qis__h__body(); ret void }"),
            ("json",  '[{"name":"X90","qubit":"qubit_0","param":{theta}}]'),
        ],
    )
    def test_circuit_template_forwarded_unchanged(self, client, fmt, template):
        """circuit_template is forwarded verbatim as the first StreamGateJobRequest."""
        sent_requests = []

        def capture_and_respond(request_iter, **kwargs):
            for req in request_iter:
                sent_requests.append(req)
            return iter([self._make_stream_response({"00": 100})])

        client._stub.StreamGateJob.side_effect = capture_and_respond
        list(client.stream_gate_job(
            circuit_template=template,
            params_list=[{"theta": 0.5}],
            shots=10,
        ))
        assert sent_requests, "No StreamGateJobRequest was sent"
        assert sent_requests[0].circuit_template == template


# ---------------------------------------------------------------------------
# context manager / close
# ---------------------------------------------------------------------------

class TestContextManager:
    def test_close_called_on_exit(self):
        c = QubeClient("localhost:50051")
        c._stub = MagicMock()
        c._channel = MagicMock()
        with c:
            pass
        c._channel.close.assert_called_once()

    def test_close_called_on_exception(self):
        c = QubeClient("localhost:50051")
        c._stub = MagicMock()
        c._channel = MagicMock()
        with pytest.raises(ValueError):
            with c:
                raise ValueError("boom")
        c._channel.close.assert_called_once()


# ---------------------------------------------------------------------------
# _parse_gate_result_json (static method)
# ---------------------------------------------------------------------------

class TestParseGateResultJson:
    def test_full_json(self):
        result = QubeClient._parse_gate_result_json(
            counts_json='{"00": 100}',
            s11_json='{"q0": -20.0}',
            qubit_mapping_json='{"0": "q0"}',
        )
        assert result["counts"] == {"00": 100}
        assert result["s11"] == {"q0": -20.0}
        assert result["qubit_mapping"] == {"0": "q0"}

    def test_empty_strings_return_empty_dicts(self):
        result = QubeClient._parse_gate_result_json("", "", "")
        assert result == {"counts": {}, "s11": {}, "qubit_mapping": {}}
