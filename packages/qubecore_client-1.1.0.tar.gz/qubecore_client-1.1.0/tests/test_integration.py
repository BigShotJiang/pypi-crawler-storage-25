"""Integration tests for qubecore-client.

These tests require a running QubeCore gRPC server at localhost:50051.

Tests marked with @pytest.mark.hardware require actual QPU execution and
are skipped by default. Run with `-m hardware` to include them.
"""
from __future__ import annotations

import time
import uuid

import pytest

from qubecore_client import QubeClient, is_token_expired, login, logout, refresh_token

GRPC_ADDRESS = "localhost:50051"
ADMIN_USER = "admin"
ADMIN_PASS = "admin"

# A parametric single-qubit circuit for streaming tests
PARAMETRIC_CIRCUIT = (
    'OPENQASM 2.0;\n'
    'include "qelib1.inc";\n'
    'qreg q[1];\n'
    'creg c[1];\n'
    'rx({theta}) q[0];\n'
    'measure q[0]->c[0];'
)

# Bell state circuit for result consistency tests
BELL_CIRCUIT = (
    'OPENQASM 2.0;\n'
    'include "qelib1.inc";\n'
    'qreg q[2];\n'
    'creg c[2];\n'
    'h q[0];\n'
    'cx q[0],q[1];\n'
    'measure q->c;'
)

VALID_STATUSES = {"PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"}


# ---------------------------------------------------------------------------
# 1. Real gRPC connection tests
# ---------------------------------------------------------------------------

class TestLogin:
    def test_login_admin_success(self):
        """login() with valid credentials returns non-empty token strings."""
        access_token, refresh_tok = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
        assert isinstance(access_token, str) and len(access_token) > 0
        assert isinstance(refresh_tok, str) and len(refresh_tok) > 0

    def test_login_wrong_password_raises(self):
        """login() with wrong password raises RuntimeError."""
        with pytest.raises(RuntimeError):
            login(GRPC_ADDRESS, ADMIN_USER, "wrongpassword")

    def test_is_token_expired_valid_token(self):
        """A freshly issued token should not be expired."""
        access_token, _ = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
        assert is_token_expired(access_token) is False

    def test_refresh_token_returns_new_access_token(self):
        """refresh_token() with valid refresh token returns a new access token."""
        _, refresh_tok = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
        new_access, new_refresh = refresh_token(GRPC_ADDRESS, refresh_tok)
        assert isinstance(new_access, str) and len(new_access) > 0
        assert isinstance(new_refresh, str) and len(new_refresh) > 0


# ---------------------------------------------------------------------------
# 2. QubeClient real calls
# ---------------------------------------------------------------------------

class TestQubeClientCalls:
    def test_get_me_returns_admin_info(self, admin_client: QubeClient):
        """get_me() returns dict with username=admin and role=admin."""
        me = admin_client.get_me()
        assert me["username"] == "admin"
        assert me["role"] == "admin"

    def test_get_backend_info(self, admin_client: QubeClient):
        """get_backend_info() returns non-empty name and positive num_qubits."""
        info = admin_client.get_backend_info()
        assert isinstance(info["name"], str) and info["name"] != ""
        assert isinstance(info["num_qubits"], int) and info["num_qubits"] > 0

    def test_get_characterization(self, admin_client: QubeClient):
        """get_characterization() returns last_calibrated str and qubits list."""
        char = admin_client.get_characterization()
        assert isinstance(char["last_calibrated"], str)
        assert isinstance(char["qubits"], list)

    def test_submit_gate_job_returns_valid_uuid(self, admin_client: QubeClient):
        """submit_gate_job() returns a valid UUID string."""
        circuit = (
            'OPENQASM 2.0;\n'
            'include "qelib1.inc";\n'
            'qreg q[1];\n'
            'creg c[1];\n'
            'measure q[0]->c[0];'
        )
        job_id = admin_client.submit_gate_job([circuit], shots=10)
        assert isinstance(job_id, str) and len(job_id) > 0
        # Should be a valid UUID
        parsed = uuid.UUID(job_id)
        assert str(parsed) == job_id

    def test_get_job_status(self, admin_client: QubeClient):
        """get_job_status() returns status in known set."""
        circuit = (
            'OPENQASM 2.0;\n'
            'include "qelib1.inc";\n'
            'qreg q[1];\n'
            'creg c[1];\n'
            'measure q[0]->c[0];'
        )
        job_id = admin_client.submit_gate_job([circuit], shots=10)
        status_info = admin_client.get_job_status(job_id)
        assert status_info["job_id"] == job_id
        assert status_info["status"] in VALID_STATUSES

    def test_get_my_jobs(self, admin_client: QubeClient):
        """get_my_jobs() returns total >= 0 and jobs as list."""
        result = admin_client.get_my_jobs(page=1, page_size=10)
        assert isinstance(result["total"], int) and result["total"] >= 0
        assert isinstance(result["jobs"], list)

    def test_submit_pulse_job_returns_valid_uuid(self, admin_client: QubeClient):
        """submit_pulse_job() returns a valid UUID string."""
        job_id = admin_client.submit_pulse_job(["pulse_data_placeholder"], shots=10)
        assert isinstance(job_id, str) and len(job_id) > 0
        parsed = uuid.UUID(job_id)
        assert str(parsed) == job_id

    def test_submit_widescan_job_returns_valid_uuid(self, admin_client: QubeClient):
        """submit_widescan_job({...}) returns a valid UUID string."""
        job_id = admin_client.submit_widescan_job({
            "qubit": "qubit_0", "freq_span": 100_000_000.0, "n_freqs": 200, "shots": 100,
        })
        assert isinstance(job_id, str) and len(job_id) > 0
        parsed = uuid.UUID(job_id)
        assert str(parsed) == job_id

    def test_cancel_job(self, admin_client: QubeClient):
        """submit_gate_job followed by cancel_job → success or already-terminal state."""
        import grpc as _grpc

        # Submit a batch to increase the chance one stays PENDING long enough to cancel
        job_ids = [
            admin_client.submit_gate_job([BELL_CIRCUIT], shots=10)
            for _ in range(3)
        ]
        cancelled_any = False
        for job_id in job_ids:
            try:
                admin_client.cancel_job(job_id)
                status_info = admin_client.get_job_status(job_id)
                if status_info["status"] == "CANCELLED":
                    cancelled_any = True
                    break
            except (_grpc.RpcError, RuntimeError, ValueError):
                # Job may have already completed — acceptable
                pass

        if not cancelled_any:
            pytest.skip(
                "All submitted jobs completed before cancel could be issued — "
                "consider a slower backend or increasing job count"
            )

    def test_get_job_result_returns_dict(self, admin_client: QubeClient):
        """get_job_result() on a submitted job returns a dict with job_id and status."""
        job_id = admin_client.submit_gate_job([BELL_CIRCUIT], shots=10)
        # 잡이 DB에 등록될 때까지 상태 폴링
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            try:
                admin_client.get_job_status(job_id)
                break
            except ValueError:
                time.sleep(0.1)
        try:
            result = admin_client.get_job_result(job_id)
            assert isinstance(result, dict)
            assert result["job_id"] == job_id
            assert "status" in result
        except (ValueError, RuntimeError) as e:
            # PENDING/RUNNING 상태에서 서버 메시지를 ValueError로 전달받는 것은 정상
            msg = str(e).lower()
            assert "pending" in msg or "running" in msg or "not" in msg or "found" in msg, (
                f"Unexpected error from get_job_result: {e}"
            )

    def test_submit_reset_job_returns_valid_uuid(self, admin_client: QubeClient):
        """submit_reset_job() returns a valid UUID string."""
        job_id = admin_client.submit_reset_job(["qubit_0"], shots=10)
        assert isinstance(job_id, str) and len(job_id) > 0
        parsed = uuid.UUID(job_id)
        assert str(parsed) == job_id


    def test_update_characterization_admin_all_qubits(self, admin_client: QubeClient):
        """update_characterization(qubits=None) as admin → triggers measurement, returns message."""
        msg = admin_client.update_characterization(qubits=None)
        assert isinstance(msg, str) and len(msg) > 0

    def test_update_characterization_admin_specific_qubits(self, admin_client: QubeClient):
        """update_characterization(qubits=["qubit_0"]) → message contains qubit name."""
        msg = admin_client.update_characterization(qubits=["qubit_0"])
        assert isinstance(msg, str) and "qubit_0" in msg


# ---------------------------------------------------------------------------
# 3. Token lifecycle
# ---------------------------------------------------------------------------

class TestTokenLifecycle:
    def test_login_use_refresh_use_again(self):
        """Login → use token → refresh → use new token — full lifecycle."""
        access_token, refresh_tok = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)

        # Use original access token
        with QubeClient(address=GRPC_ADDRESS, token=access_token) as client:
            me = client.get_me()
            assert me["username"] == "admin"

        # Refresh
        new_access, refresh_tok = refresh_token(GRPC_ADDRESS, refresh_tok)
        assert isinstance(new_access, str) and len(new_access) > 0
        assert isinstance(refresh_tok, str) and len(refresh_tok) > 0

        # Use refreshed token
        with QubeClient(address=GRPC_ADDRESS, token=new_access) as client:
            me = client.get_me()
            assert me["username"] == "admin"

    def test_logout_does_not_raise(self):
        """logout() should complete without raising (stateless JWT server)."""
        access_token, _ = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
        # Should not raise; server may not revoke JWT but the call should succeed
        logout(GRPC_ADDRESS, access_token)

    def test_token_still_valid_after_logout(self):
        """After logout the access token is still accepted (stateless JWT)."""
        access_token, _ = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
        logout(GRPC_ADDRESS, access_token)

        with QubeClient(address=GRPC_ADDRESS, token=access_token) as client:
            me = client.get_me()
            assert me["username"] == "admin"

    def test_expired_refresh_token_requires_relogin(self):
        """An expired/invalid refresh token must raise — caller must re-login."""
        import grpc as _grpc

        fake_expired_refresh = (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
            ".eyJzdWIiOiJhZG1pbiIsInR5cGUiOiJyZWZyZXNoIiwiZXhwIjoxfQ"
            ".invalidsignature"
        )
        with pytest.raises((_grpc.RpcError, Exception)):
            refresh_token(GRPC_ADDRESS, fake_expired_refresh)


# ---------------------------------------------------------------------------
# 4. Streaming (StreamGateJob) — requires hardware
# ---------------------------------------------------------------------------

@pytest.mark.hardware
class TestStreamGateJob:
    def test_stream_two_param_sets_returns_two_results(self, admin_client: QubeClient):
        """StreamGateJob with 2 param sets yields exactly 2 results in order."""
        params_list = [
            {"theta": 0.0},
            {"theta": 3.14159},
        ]
        results = list(
            admin_client.stream_gate_job(
                circuit_template=PARAMETRIC_CIRCUIT,
                params_list=params_list,
                shots=100,
            )
        )
        assert len(results) == 2
        for result in results:
            assert "counts" in result
            assert isinstance(result["counts"], dict)


# ---------------------------------------------------------------------------
# 5. Result consistency — requires hardware
# ---------------------------------------------------------------------------

@pytest.mark.hardware
class TestResultConsistency:
    def _wait_for_terminal(
        self,
        client: QubeClient,
        job_id: str,
        timeout: float = 120.0,
        poll_interval: float = 2.0,
    ) -> str:
        """Poll until job reaches a terminal state (COMPLETED or FAILED)."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            info = client.get_job_status(job_id)
            if info["status"] in ("COMPLETED", "FAILED"):
                return info["status"]
            time.sleep(poll_interval)
        raise TimeoutError(f"Job {job_id} did not finish within {timeout}s")

    def test_bell_circuit_three_submissions_all_complete(self, admin_client: QubeClient):
        """Submit Bell state circuit 3 times; all should reach COMPLETED or FAILED."""
        job_ids = []
        for _ in range(3):
            job_id = admin_client.submit_gate_job([BELL_CIRCUIT], shots=100)
            job_ids.append(job_id)

        for job_id in job_ids:
            status = self._wait_for_terminal(admin_client, job_id)
            assert status in ("COMPLETED", "FAILED"), (
                f"Job {job_id} stuck in non-terminal state"
            )

    def test_completed_bell_circuit_has_valid_counts(self, admin_client: QubeClient):
        """A COMPLETED Bell job should have count keys like '00', '11'."""
        job_id = admin_client.submit_gate_job([BELL_CIRCUIT], shots=100)

        deadline = time.monotonic() + 120.0
        status = None
        while time.monotonic() < deadline:
            info = admin_client.get_job_status(job_id)
            status = info["status"]
            if status in ("COMPLETED", "FAILED"):
                break
            time.sleep(2.0)

        if status == "COMPLETED":
            result = admin_client.get_job_result(job_id)
            assert "results" in result
            assert len(result["results"]) > 0
            counts = result["results"][0]["counts"]
            assert isinstance(counts, dict)
            # All count keys should be bitstrings
            for key in counts:
                assert all(ch in "01" for ch in key), (
                    f"Unexpected count key: {key!r}"
                )
        elif status == "FAILED":
            pytest.skip("Job FAILED — hardware not available")
        else:
            pytest.fail(f"Job {job_id} did not finish within timeout")
