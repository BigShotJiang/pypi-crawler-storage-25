"""Shared fixtures for integration tests."""
from __future__ import annotations

import pytest

from qubecore_client import QubeClient, login

GRPC_ADDRESS = "localhost:50051"
ADMIN_USER = "admin"
ADMIN_PASS = "admin"


@pytest.fixture(scope="session")
def admin_token() -> str:
    """Login as admin and return the access token."""
    access_token, _ = login(GRPC_ADDRESS, ADMIN_USER, ADMIN_PASS)
    return access_token


@pytest.fixture(scope="session")
def admin_client(admin_token: str) -> QubeClient:
    """Return a QubeClient authenticated as admin."""
    client = QubeClient(address=GRPC_ADDRESS, token=admin_token, timeout=60.0)
    yield client
    client.close()
