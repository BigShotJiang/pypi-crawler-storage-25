"""Local SQLite store for fail-safe trace persistence."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


def _default_db_path() -> str:
    """Return the default database path (~/.agenteval/traces.db)."""
    base = os.environ.get("AGENTEVAL_DATA_DIR") or str(Path.home() / ".agenteval")
    base = os.path.expanduser(base)  # resolve ~ to actual home directory
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "traces.db")


class LocalStore:
    """Thread-safe SQLite store for traces.

    Every trace logged via the SDK is persisted here *before* the network
    call so that data is never lost, even when the central endpoint is
    unreachable.
    """

    _DDL = """
    CREATE TABLE IF NOT EXISTS traces (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        trace_id    TEXT NOT NULL,
        agent_name  TEXT DEFAULT '',
        agent_input TEXT DEFAULT '',
        agent_output TEXT DEFAULT '',
        latency_ms  INTEGER DEFAULT 0,
        tokens_used INTEGER DEFAULT 0,
        test_status TEXT DEFAULT 'NEW',
        error_message TEXT DEFAULT '',
        project_id  TEXT DEFAULT 'default',
        synced      INTEGER DEFAULT 0,
        created_at  TEXT DEFAULT (datetime('now')),
        span_id     TEXT DEFAULT '',
        parent_span_id TEXT DEFAULT '',
        latency_threshold INTEGER,
        session_id  TEXT DEFAULT '',
        has_pii     INTEGER DEFAULT 0,
        pii_types   TEXT DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_traces_synced ON traces(synced);
    CREATE INDEX IF NOT EXISTS idx_traces_trace_id ON traces(trace_id);
    """

    _MIGRATIONS = [
        "ALTER TABLE traces ADD COLUMN span_id TEXT DEFAULT ''",
        "ALTER TABLE traces ADD COLUMN parent_span_id TEXT DEFAULT ''",
        "ALTER TABLE traces ADD COLUMN latency_threshold INTEGER",
        "ALTER TABLE traces ADD COLUMN session_id TEXT DEFAULT ''",
        "ALTER TABLE traces ADD COLUMN has_pii INTEGER DEFAULT 0",
        "ALTER TABLE traces ADD COLUMN pii_types TEXT DEFAULT ''",
        "CREATE INDEX IF NOT EXISTS idx_traces_session_id ON traces(session_id)",
    ]

    def __init__(self, db_path: Optional[str] = None) -> None:
        self._db_path = db_path or _default_db_path()
        self._lock = threading.Lock()
        self._ensure_schema()

    @property
    def path(self) -> str:
        """Return the path to the SQLite database file."""
        return self._db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _ensure_schema(self) -> None:
        with self._lock:
            conn = self._connect()
            try:
                conn.executescript(self._DDL)
                for stmt in self._MIGRATIONS:
                    try:
                        conn.execute(stmt)
                        conn.commit()
                    except sqlite3.OperationalError:
                        pass  # column already exists
            finally:
                conn.close()

    def save(self, trace: Dict[str, Any]) -> int:
        """Persist a trace dict locally. Returns the rowid."""
        with self._lock:
            conn = self._connect()
            try:
                # Normalize PII types to a comma-separated string
                pii_raw = trace.get("client_pii_types") or trace.get("pii_types") or []
                pii_str = ",".join(pii_raw) if isinstance(pii_raw, list) else str(pii_raw)
                has_pii = 1 if (trace.get("client_has_pii") or trace.get("has_pii") or pii_str) else 0

                cur = conn.execute(
                    """INSERT INTO traces
                       (trace_id, agent_name, agent_input, agent_output,
                        latency_ms, tokens_used, test_status, error_message,
                        project_id, synced, span_id, parent_span_id,
                        latency_threshold, session_id, has_pii, pii_types)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)""",
                    (
                        trace.get("trace_id", ""),
                        trace.get("agent_name", ""),
                        trace.get("agent_input", ""),
                        trace.get("agent_output", ""),
                        trace.get("latency_ms", 0),
                        trace.get("tokens_used", 0),
                        trace.get("test_status", "NEW"),
                        trace.get("error_message", ""),
                        trace.get("project_id", "default"),
                        trace.get("span_id", ""),
                        trace.get("parent_span_id", ""),
                        trace.get("latency_threshold"),
                        trace.get("session_id", ""),
                        has_pii,
                        pii_str,
                    ),
                )
                conn.commit()
                return cur.lastrowid  # type: ignore[return-value]
            finally:
                conn.close()

    def mark_synced(self, rowid: int) -> None:
        """Mark a trace as successfully synced to the central endpoint."""
        with self._lock:
            conn = self._connect()
            try:
                conn.execute("UPDATE traces SET synced = 1 WHERE id = ?", (rowid,))
                conn.commit()
            finally:
                conn.close()

    def get_unsynced(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Return up to *limit* traces that haven't been synced yet."""
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT * FROM traces WHERE synced = 0 ORDER BY id ASC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()

    def get_recent(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return the most recent *limit* traces (synced or not)."""
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT * FROM traces ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()

    def count(self, synced_only: bool = False) -> int:
        """Return total trace count."""
        clause = "WHERE synced = 1" if synced_only else ""
        with self._lock:
            conn = self._connect()
            try:
                row = conn.execute(f"SELECT COUNT(*) FROM traces {clause}").fetchone()
                return row[0] if row else 0
            finally:
                conn.close()

    def clear(self) -> int:
        """Delete all traces. Returns number of rows deleted."""
        with self._lock:
            conn = self._connect()
            try:
                cur = conn.execute("DELETE FROM traces")
                conn.commit()
                return cur.rowcount
            finally:
                conn.close()

    def get_by_trace_id(self, trace_id: str) -> List[Dict[str, Any]]:
        """Return all spans for a given trace_id, ordered by id (creation order)."""
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT * FROM traces WHERE trace_id = ? ORDER BY id ASC",
                    (trace_id,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()

    def get_case_traces(self, case_id: str) -> List[Dict[str, Any]]:
        """Return all traces belonging to a case/investigation.

        Looks up by trace_id first, then finds related traces that were
        created within a short time window with the same project_id.
        This handles multi-agent systems where different agents may
        produce different trace_ids for the same logical case.
        """
        with self._lock:
            conn = self._connect()
            try:
                # 1. Direct match on trace_id
                direct = conn.execute(
                    "SELECT * FROM traces WHERE trace_id = ? ORDER BY id ASC",
                    (case_id,),
                ).fetchall()

                if not direct:
                    return []

                # 2. Find time window and project from the direct matches
                first = dict(direct[0])
                project_id = first.get("project_id", "default")
                created_at = first.get("created_at", "")
                first_id = first["id"]

                # 3. Find related traces: same project, created within
                #    10 seconds of the first span, different trace_id
                related = conn.execute(
                    """SELECT * FROM traces
                       WHERE project_id = ?
                         AND trace_id != ?
                         AND id BETWEEN ? AND ? + 50
                         AND abs(julianday(created_at) - julianday(?)) < ?
                       ORDER BY id ASC""",
                    (project_id, case_id, max(1, first_id - 5), first_id + 50,
                     created_at, 10.0 / 86400),
                ).fetchall()

                # Combine and deduplicate by id
                seen_ids = set()
                result = []
                for row in list(direct) + list(related):
                    d = dict(row)
                    if d["id"] not in seen_ids:
                        seen_ids.add(d["id"])
                        result.append(d)
                result.sort(key=lambda r: r["id"])
                return result
            finally:
                conn.close()

    @property
    def path(self) -> str:
        return self._db_path
