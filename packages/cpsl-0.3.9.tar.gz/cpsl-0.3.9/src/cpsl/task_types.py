"""Task descriptor and handle types for @cpsl.task()."""

from __future__ import annotations

import asyncio
import functools
import json
import re
from datetime import timedelta
from typing import Any, Callable, Type, TYPE_CHECKING

if TYPE_CHECKING:
    from .runner import Runner
    from .session import Session

_TASK_ATTR = "_cpsl_task"


class TaskHandle:
    """Handle to a submitted background task.

    Example::

        handle = await my_task.submit(session=session)
        status = await handle.status()  # "pending", "running", "completed", ...
        await handle.cancel()           # cancel if not yet running

    Attributes:
        task_id: Unique identifier for the submitted task.
    """

    __slots__ = ("task_id", "_runner")

    def __init__(self, task_id: str, runner: Runner) -> None:
        self.task_id = task_id
        self._runner = runner

    async def status(self) -> str:
        """Return the current task status.

        Returns one of ``"pending"``, ``"claimed"``, ``"running"``,
        ``"completed"``, ``"failed"``, ``"retry"``, ``"cancelled"``,
        ``"scheduled"``, or ``"timeout"``.
        """
        from .clients.capsule import GetTaskRequest
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._runner._task_stub.get_task,
            GetTaskRequest(task_id=self.task_id, version_id=self._runner._version_id),
        )
        return _proto_status_to_str(resp.task.status)

    async def cancel(self) -> None:
        """Cancel the task if it hasn't started running yet.

        Only cancels tasks in ``"pending"``, ``"scheduled"``, or
        ``"retry"`` status. Running tasks are not interrupted.
        """
        from .clients.capsule import CancelTasksRequest, GetTaskRequest
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._runner._task_stub.get_task,
            GetTaskRequest(task_id=self.task_id, version_id=self._runner._version_id),
        )
        if resp.task and _proto_status_to_str(resp.task.status) in ("pending", "scheduled", "retry"):
            await asyncio.get_running_loop().run_in_executor(
                None, self._runner._task_stub.cancel_tasks,
                CancelTasksRequest(
                    app_id=self._runner._app_id,
                    task_name=resp.task.task_name,
                    kwargs_filter_json=resp.task.kwargs_json or b'{}',
                    version_id=self._runner._version_id,
                ),
            )


class TaskDescriptor:
    """A background task registered with ``@app.task()`` or ``@cpsl.task()``.

    Call ``.submit()`` to run immediately or ``.schedule()`` to run after
    a delay.  Use ``.find()``, ``.count()``, and ``.cancel()`` to query
    and manage submitted tasks.

    Example::

        @app.task(retries=2, timeout=60)
        async def send_email(session: cpsl.Session, to: str, body: str):
            ...

        handle = await send_email.submit(session=session, to="a@b.c", body="Hi")
        status = await handle.status()
    """

    def __init__(
        self,
        fn: Callable,
        retries: int = 0,
        timeout: int = 0,
        lock: str | None = None,
        retry_for: list[Type[Exception]] | None = None,
        callback_url: str | None = None,
        functional: bool = False,
    ) -> None:
        self._fn = fn
        self._name = fn.__name__
        self._is_async = asyncio.iscoroutinefunction(fn)
        self._retries = retries
        self._timeout = timeout
        self._lock_template = lock
        self._retry_for = retry_for or []
        self._callback_url = callback_url
        self._functional = functional
        self._instance: Any = None
        self._runner: Runner | None = None

    def _bind(self, instance: Any, runner: Runner) -> None:
        self._instance = instance
        self._runner = runner

    def _resolve_lock(self, kwargs: dict) -> str:
        if not self._lock_template:
            return ""
        return re.sub(
            r"\{(\w+)\}",
            lambda m: str(kwargs.get(m.group(1), "")),
            self._lock_template,
        )

    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if self._functional:
            if self._is_async:
                return await self._fn(*args, **kwargs)
            return await asyncio.get_running_loop().run_in_executor(
                None, functools.partial(self._fn, *args, **kwargs),
            )
        if self._is_async:
            return await self._fn(self._instance, *args, **kwargs)
        return await asyncio.get_running_loop().run_in_executor(
            None, functools.partial(self._fn, self._instance, *args, **kwargs),
        )

    def _build_request(self, session: Any, kwargs: dict, scheduled_at: str = "") -> Any:
        from .clients.capsule import SubmitTaskRequest
        runner = self._require_runner()
        # user_id/version_id come from the runtime env so tasks submitted
        # from inside the app dispatch to the correct owner's inbox rather
        # than the coarse serve channel.
        return SubmitTaskRequest(
            app_id=runner._app_id,
            user_id=runner._user_id,
            version_id=runner._version_id,
            task_name=self._name,
            session_id=session.id if session else "",
            kwargs_json=json.dumps(kwargs).encode(),
            max_retries=self._retries,
            lock_key=self._resolve_lock(kwargs),
            scheduled_at=scheduled_at,
            timeout=self._timeout,
        )

    async def submit(self, session: Session | None = None, **kwargs: Any) -> TaskHandle:
        """Submit the task for immediate background execution.

        Args:
            session: Bind the task to a chat session so the handler
                receives a hydrated ``Session`` as its first argument.
            **kwargs: Forwarded to the task handler as keyword arguments.

        Returns:
            A :class:`TaskHandle` for polling status or cancelling.

        Example::

            handle = await my_task.submit(session=session, label="job-1")
            await session.show_task(handle, message="Working...")
        """
        runner = self._require_runner()
        req = self._build_request(session, kwargs)
        resp = await asyncio.get_running_loop().run_in_executor(
            None, runner._task_stub.submit_task, req,
        )
        return TaskHandle(resp.task_id, runner)

    async def schedule(
        self, session: Session | None = None, delay: str | timedelta | None = None, **kwargs: Any
    ) -> TaskHandle:
        """Schedule the task to run after a delay.

        Args:
            session: Bind the task to a chat session.
            delay: ``timedelta`` or shorthand string -- ``"5s"``,
                ``"30m"``, ``"1h"``, ``"3d"``.
            **kwargs: Forwarded to the task handler as keyword arguments.

        Example::

            handle = await my_task.schedule(session=session, delay="30m")
        """
        from datetime import datetime, timezone

        runner = self._require_runner()
        scheduled_at = ""
        if delay is not None:
            if isinstance(delay, str):
                delay = _parse_delay(delay)
            scheduled_at = (datetime.now(timezone.utc) + delay).isoformat()

        req = self._build_request(session, kwargs, scheduled_at)
        resp = await asyncio.get_running_loop().run_in_executor(
            None, runner._task_stub.submit_task, req,
        )
        return TaskHandle(resp.task_id, runner)

    async def find(
        self, status: str | None = None, session_id: str | None = None,
        limit: int = 100, offset: int = 0, **kwargs: Any,
    ) -> list[dict]:
        from .clients.capsule import FindTasksRequest
        runner = self._require_runner()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, runner._task_stub.find_tasks,
            FindTasksRequest(
                app_id=runner._app_id,
                task_name=self._name,
                status=_str_to_proto_status(status) if status else 0,
                session_id=session_id or "",
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                limit=limit,
                offset=offset,
                version_id=runner._version_id,
            ),
        )
        return [_task_record_to_dict(t) for t in resp.tasks]

    async def count(self, status: str | None = None, **kwargs: Any) -> int:
        from .clients.capsule import CountTasksRequest
        runner = self._require_runner()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, runner._task_stub.count_tasks,
            CountTasksRequest(
                app_id=runner._app_id,
                task_name=self._name,
                status=_str_to_proto_status(status) if status else 0,
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                version_id=runner._version_id,
            ),
        )
        return resp.count

    async def cancel(self, status: str | None = None, **kwargs: Any) -> int:
        from .clients.capsule import CancelTasksRequest
        runner = self._require_runner()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, runner._task_stub.cancel_tasks,
            CancelTasksRequest(
                app_id=runner._app_id,
                task_name=self._name,
                status=_str_to_proto_status(status) if status else 0,
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                version_id=runner._version_id,
            ),
        )
        return resp.cancelled

    def _require_runner(self) -> Runner:
        if self._runner is None:
            raise RuntimeError("task not bound to a runner — is the app booted?")
        return self._runner


class GlobalTaskQuery:
    """Cross-cutting task query: self.tasks.find(), self.tasks.count(), etc."""

    def __init__(self, runner: Runner) -> None:
        self._runner = runner

    async def find(
        self, status: str | None = None, limit: int = 100, offset: int = 0, **kwargs: Any
    ) -> list[dict]:
        from .clients.capsule import FindTasksRequest
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._runner._task_stub.find_tasks,
            FindTasksRequest(
                app_id=self._runner._app_id,
                status=_str_to_proto_status(status) if status else 0,
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                limit=limit,
                offset=offset,
                version_id=self._runner._version_id,
            ),
        )
        return [_task_record_to_dict(t) for t in resp.tasks]

    async def count(self, status: str | None = None, **kwargs: Any) -> int:
        from .clients.capsule import CountTasksRequest
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._runner._task_stub.count_tasks,
            CountTasksRequest(
                app_id=self._runner._app_id,
                status=_str_to_proto_status(status) if status else 0,
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                version_id=self._runner._version_id,
            ),
        )
        return resp.count

    async def cancel(self, status: str | None = None, **kwargs: Any) -> int:
        from .clients.capsule import CancelTasksRequest
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._runner._task_stub.cancel_tasks,
            CancelTasksRequest(
                app_id=self._runner._app_id,
                status=_str_to_proto_status(status) if status else 0,
                kwargs_filter_json=json.dumps(kwargs).encode() if kwargs else b'{}',
                version_id=self._runner._version_id,
            ),
        )
        return resp.cancelled

    async def get(self, task_id: str) -> dict | None:
        from .clients.capsule import GetTaskRequest
        try:
            resp = await asyncio.get_running_loop().run_in_executor(
                None, self._runner._task_stub.get_task,
                GetTaskRequest(task_id=task_id, version_id=self._runner._version_id),
            )
            return _task_record_to_dict(resp.task)
        except Exception:
            return None


def _parse_delay(s: str) -> timedelta:
    m = re.match(r"^(\d+)\s*(d|h|m|s)$", s.strip())
    if not m:
        raise ValueError(f"invalid delay: {s!r} (expected '3d', '1h', '30m', '5s')")
    n, unit = int(m.group(1)), m.group(2)
    return {"d": timedelta(days=n), "h": timedelta(hours=n),
            "m": timedelta(minutes=n), "s": timedelta(seconds=n)}[unit]


def _task_record_to_dict(t: Any) -> dict:
    return {
        "task_id": t.task_id,
        "app_id": t.app_id,
        "task_name": t.task_name,
        "session_id": t.session_id,
        "kwargs": json.loads(t.kwargs_json) if t.kwargs_json else {},
        "status": _proto_status_to_str(t.status),
        "attempt": t.attempt,
        "max_retries": t.max_retries,
        "timeout": t.timeout,
        "error": t.error,
        "created_at": t.created_at,
        "started_at": t.started_at,
        "completed_at": t.completed_at,
        "scheduled_at": t.scheduled_at,
    }


_STATUS_TO_STR = {}
_STR_TO_STATUS = {}


def _init_status_maps():
    from .clients.capsule import TaskStatus
    global _STATUS_TO_STR, _STR_TO_STATUS
    pairs = [
        (TaskStatus.PENDING, "pending"), (TaskStatus.CLAIMED, "claimed"),
        (TaskStatus.RUNNING, "running"), (TaskStatus.COMPLETED, "completed"),
        (TaskStatus.FAILED, "failed"), (TaskStatus.RETRY, "retry"),
        (TaskStatus.CANCELLED, "cancelled"), (TaskStatus.SCHEDULED, "scheduled"),
        (TaskStatus.TIMEOUT, "timeout"),
    ]
    _STATUS_TO_STR = {k: v for k, v in pairs}
    _STR_TO_STATUS = {v: k for k, v in pairs}


def _proto_status_to_str(s: int) -> str:
    if not _STATUS_TO_STR:
        _init_status_maps()
    return _STATUS_TO_STR.get(s, "unknown")


def _str_to_proto_status(s: str | None) -> int:
    if s is None:
        return 0
    if not _STR_TO_STATUS:
        _init_status_maps()
    return _STR_TO_STATUS.get(s, 0)
