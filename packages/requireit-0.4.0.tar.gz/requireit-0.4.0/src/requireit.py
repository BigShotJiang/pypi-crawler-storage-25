from __future__ import annotations

import importlib
from collections.abc import Callable
from collections.abc import Collection
from collections.abc import Iterable
from collections.abc import Sized
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version
from typing import Any

import numpy as np
from numpy.typing import ArrayLike
from numpy.typing import DTypeLike
from numpy.typing import NDArray

try:
    __version__ = version("requireit")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"


class RequireItError(Exception):
    """Base class for exceptions raised from this module."""


class ValidationError(RequireItError):
    """Error to indicate that a validation has failed."""


def argparse_type(validator: Callable) -> Callable:
    """Adapt a requireit validator for use as an argparse `type=` callable.

    Example
    -------
    >>> import argparse
    >>> parser = argparse.ArgumentParser()
    >>> _ = parser.add_argument(
    ...     "--n", type=argparse_type(lambda x: require_positive(int(x)))
    ... )
    >>> parser.parse_args(["--n", "1"]).n
    '1'

    >>> try:
    ...     parser.parse_args(["--n", "0"])
    ... except SystemExit as e:
    ...     e.code
    ...
    2
    """
    import argparse

    def _type(value: Any) -> Any:
        try:
            validator(value)
        except ValidationError as error:
            raise argparse.ArgumentTypeError(str(error)) from None
        return value

    return _type


def require_one_of(
    value: Any, *, allowed: Iterable[Any], name: str | None = None
) -> Any:
    """Require `value` is contained in `allowed`"""
    name = name or "value"

    try:
        collection_of_allowed: Collection = set(allowed)
        in_collection = value in collection_of_allowed
    except TypeError:
        collection_of_allowed = list(allowed)
        in_collection = value in collection_of_allowed

    if not in_collection:
        allowed_str = ", ".join(sorted(repr(x) for x in collection_of_allowed))
        raise ValidationError(f"{name} must be one of {allowed_str}")
    return value


def require_not_one_of(
    value: Any, *, forbidden: Iterable[Any], name: str | None = None
) -> Any:
    """Require `value` is not contained in `forbidden`"""
    name = name or "value"

    try:
        collection_of_forbidden: Collection = set(forbidden)
        in_collection = value in collection_of_forbidden
    except TypeError:
        collection_of_forbidden = list(forbidden)
        in_collection = value in collection_of_forbidden

    if in_collection:
        forbidden_str = ", ".join(sorted(repr(x) for x in collection_of_forbidden))
        raise ValidationError(f"{name} must not be one of {forbidden_str}")
    return value


def require_contains(
    collection: Collection[Any],
    *,
    required: Collection[Any] | None = None,
    name: str | None = None,
):
    """Require `collection` contains required values."""
    name = name or "collection"

    missing = set(required) - set(collection) if required is not None else set()

    if missing:
        missing_values = ", ".join(sorted(missing))
        raise ValidationError(f"{name} must contain {missing_values}")

    return collection


def require_between(
    value: ArrayLike,
    a_min: float | None = None,
    a_max: float | None = None,
    *,
    inclusive_min: bool = True,
    inclusive_max: bool = True,
    name: str | None = None,
) -> ArrayLike:
    """Validate that a value lies within a specified interval.

    Parameters
    ----------
    value : scalar or array-like
        The input value(s) to be validated.
    a_min : float or None, optional
        Minimum allowable value. If ``None``, no lower bound is applied.
    a_max : float or None, optional
        Maximum allowable value. If ``None``, no upper bound is applied.
    inclusive_min : bool, optional
        If ``True`` (default), the lower bound is inclusive (``>=``).
        If ``False``, the lower bound is strict (``>``).
    inclusive_max : bool, optional
        If ``True`` (default), the upper bound is inclusive (``<=``).
        If ``False``, the upper bound is strict (``<``).
    name : str, optional
        Variable name used in error messages.

    Returns
    -------
    value : scalar or array-like
        The validated value.

    Raises
    ------
    ValidationError
        If any element of ``value`` violates the specified bounds.

    Examples
    --------
    >>> require_between([0, 1], a_min=0.0, inclusive_min=True)
    [0, 1]
    >>> require_between([0, 1], a_min=0.0, inclusive_min=False)
    Traceback (most recent call last):
    ...
    requireit.ValidationError: value must be > 0.0
    """
    name = name or "value"

    arr = np.asarray(value)

    if a_min is not None:
        cmp: Callable = np.less if inclusive_min else np.less_equal
        op = ">=" if inclusive_min else ">"
        if np.any(cmp(arr, a_min)):
            raise ValidationError(f"{name} must be {op} {a_min}")

    if a_max is not None:
        cmp = np.greater if inclusive_max else np.greater_equal
        op = "<=" if inclusive_max else "<"
        if np.any(cmp(arr, a_max)):
            raise ValidationError(f"{name} must be {op} {a_max}")

    return value


def require_positive(value: ArrayLike, name: str | None = None) -> ArrayLike:
    """Require `value > 0`"""
    return require_between(value, a_min=0.0, a_max=None, inclusive_min=False, name=name)


def require_nonnegative(value: ArrayLike, name: str | None = None) -> ArrayLike:
    """Require `value >= 0`"""
    return require_between(value, a_min=0.0, a_max=None, inclusive_min=True, name=name)


def require_negative(value: ArrayLike, name: str | None = None) -> ArrayLike:
    """Require `value < 0`"""
    return require_between(value, a_min=None, a_max=0.0, inclusive_max=False, name=name)


def require_nonpositive(value: ArrayLike, name: str | None = None) -> ArrayLike:
    """Require `value <= 0`"""
    return require_between(value, a_min=None, a_max=0.0, inclusive_max=True, name=name)


def require_array(
    array: NDArray,
    *,
    dtype: DTypeLike | None = None,
    shape: tuple[int, ...] | None = None,
    writable: bool | None = None,
    contiguous: bool | None = None,
    name: str | None = None,
):
    """Validate an array to satisfy requirements.

    Parameters
    ----------
    array : ndarray
        The array to be validated.
    dtype : data-type, optional
        The required data type.
    shape : tuple of int, optional
        The required shape.
    writable : bool, optional
        Require the array to be writable.
    contiguous : bool, optional
        Require the array to be c-contiguous.
    name : str, optional
        Variable name used in error messages.

    Returns
    -------
    array : ndarray
        The validated array.

    Raises
    ------
    ValidationError
        If the array is invalid.

    Examples
    --------
    >>> import numpy as np
    >>> require_array(np.array([1, 2, 3, 4]), shape=(2, 2))
    Traceback (most recent call last):
    ...
    requireit.ValidationError: array must have shape (2, 2)
    """
    name = name or "array"

    if shape is not None and array.shape != shape:
        raise ValidationError(f"{name} must have shape {shape}")

    if dtype is not None and array.dtype != np.dtype(dtype):
        raise ValidationError(f"{name} must have dtype {dtype}")

    if writable and not array.flags.writeable:
        raise ValidationError(f"{name} must be writable")

    if contiguous and not array.flags.c_contiguous:
        raise ValidationError(f"{name} must be contiguous")

    return array


def require_path_string(path: Any, *, name: str | None = None) -> str:
    """Validate that a value is a string intended to be used as a path.

    This function verifies only that the provided value is a non-empty string
    that doesn't contain null characters. It does *not* check whether the
    path exists, is readable, is writable, or is valid on any particular
    operating system.

    Parameters
    ----------
    path : any
        Value to validate.
    name : str, optional
        Variable name used in error messages.

    Returns
    -------
    str
        The original value, guaranteed to be a string that could possibly
        be used as a file path.

    Raises
    ------
    ValidationError
        If ``path`` cannot be used as a file path.

    Examples
    --------
    >>> require_path_string("data/input.txt")
    'data/input.txt'
    >>> require_path_string("")
    Traceback (most recent call last):
    ...
    requireit.ValidationError: path must not be empty
    """
    name = name or "path"

    if not isinstance(path, str):
        raise ValidationError(f"{name} must be a string")
    if path == "":
        raise ValidationError(f"{name} must not be empty")
    if "\x00" in path:
        raise ValidationError(f"{name} must not contain null characters")

    return path


def require_greater_than(value: Any, lower: Any, *, name: str | None = None) -> Any:
    """Require `value > lower`"""
    return require_between(value, a_min=lower, inclusive_min=False, name=name)


def require_greater_than_or_equal(
    value: Any, lower: Any, *, name: str | None = None
) -> Any:
    """Require `value >= lower`"""
    return require_between(value, a_min=lower, inclusive_min=True, name=name)


def require_less_than(value: Any, upper: Any, *, name: str | None = None) -> Any:
    """Require `value < upper`"""
    return require_between(value, a_max=upper, inclusive_max=False, name=name)


def require_less_than_or_equal(
    value: Any, upper: Any, *, name: str | None = None
) -> Any:
    """Require `value <= upper`"""
    return require_between(value, a_max=upper, inclusive_max=True, name=name)


def _length_of(value, *, name: str | None):
    name = name or "value"
    try:
        return len(value)
    except TypeError as err:
        raise ValidationError(f"{name} must have a length") from err


def require_length_between(
    value: Sized,
    minimum: int | None = None,
    maximum: int | None = None,
    *,
    inclusive_min: bool = True,
    inclusive_max: bool = True,
    name: str | None = None,
):
    """Require `len(value)` falls within a specified range.

    Parameters
    ----------
    value : Sized
        Object with a defined length.
    minimum : int, optional
        Minimum allowed length.
    maximum : int, optional
        Maximum allowed length.
    inclusive_min : bool, optional
        If True, require `len(value) >= minimum`. Otherwise `> minimum`.
    inclusive_max : bool, optional
        If True, require `len(value) <= maximum`. Otherwise `< maximum`.
    name : str, optional
        Name used in error messages.

    Returns
    -------
    value
        The validated object.

    Raises
    ------
    ValidationError
        If the object does not have the required length or has no length.
    """
    name = name or "value"

    length = _length_of(value, name=name)

    if minimum is not None:
        is_ok = length >= minimum if inclusive_min else length > minimum
        op = ">=" if inclusive_min else ">"
        if not is_ok:
            raise ValidationError(f"{name} must have length {op} {minimum}")

    if maximum is not None:
        is_ok = length <= maximum if inclusive_max else length < maximum
        op = "<=" if inclusive_max else "<"
        if not is_ok:
            raise ValidationError(f"{name} must have length {op} {maximum}")

    return value


def require_length(value: Any, length: int, *, name: str | None = None):
    """Require `len(value) == length`"""
    name = name or "value"

    if _length_of(value, name=name) != length:
        raise ValidationError(f"{name} must have length {length}")
    return value


def require_length_at_least(value: Any, length: int, *, name: str | None = None):
    """Require `len(value) >= length`"""
    return require_length_between(
        value, minimum=length, maximum=None, inclusive_min=True, name=name
    )


def require_length_at_most(value: Any, length: int, *, name: str | None = None):
    """Require `len(value) <= length`"""
    return require_length_between(
        value, minimum=None, maximum=length, inclusive_max=True, name=name
    )


def import_package(name: str):
    try:
        return importlib.import_module(name)
    except ModuleNotFoundError:
        raise ValidationError(f"{name} must be installed") from None
