from typing import Any

from django.core.cache import cache


class CacheTranslation:

    key = "CacheTranslation"
    # Suppressed strings expire after 30 days. After expiry the string is treated
    # as genuinely new again: the next translate() call will re-queue it and
    # log_microcopy_job() will re-insert it into the sheet.
    SUPPRESSED_TTL = 30 * 24 * 60 * 60  # 30 days in seconds

    def get_key(self, *keys):
        return "-".join([self.key] + list(keys))

    @property
    def translation(self) -> dict[str, Any]:
        res = cache.get(self.get_key("translation")) or {}
        return res

    @translation.setter
    def translation(self, value: dict[str, Any]):
        cache.set(self.get_key("translation"), value or {})

    @property
    def queue(self) -> list[str]:
        res = cache.get(self.get_key("queue")) or []
        return res

    @queue.setter
    def queue(self, value: list[str]):
        cache.set(self.get_key("queue"), value or [])

    @property
    def suppressed(self) -> list[str]:
        res = cache.get(self.get_key("suppressed")) or []
        return res

    @suppressed.setter
    def suppressed(self, value: list[str]):
        cache.set(self.get_key("suppressed"), value or [], self.SUPPRESSED_TTL)

    @property
    def headers(self) -> list[str]:
        res = cache.get(self.get_key("headers")) or []
        return res

    @headers.setter
    def headers(self, value: list[str]):
        cache.set(self.get_key("headers"), value or [])

    def add_to_queue(self, *texts: str):
        self.queue = list(set(self.queue + list(texts)))

    def add_to_suppressed(self, *texts: str):
        self.suppressed = list(set(self.suppressed + list(texts)))

    def remove_from_suppressed(self, *texts: str):
        suppressed = set(texts)
        self.suppressed = [text for text in self.suppressed if text not in suppressed]

    def clear_suppressed(self):
        self.suppressed = []

    def update_translations(self, translations: dict, headers: list = []):
        self.translation = translations

        if headers:
            self.headers = headers

    def update_headers(self, headers: list):
        self.headers = headers

    @classmethod
    def get_default_cache_model(cls):
        return cls()
