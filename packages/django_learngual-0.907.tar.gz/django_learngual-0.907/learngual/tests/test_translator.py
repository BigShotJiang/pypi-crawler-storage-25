from unittest.mock import MagicMock

import pytest

from iam_service.learngual.cache_models import CacheTranslation
from iam_service.learngual.translator import Translator


@pytest.fixture(autouse=True)
def reset_translation_cache():
    cache_model = CacheTranslation.get_default_cache_model()
    cache_model.translation = {}
    cache_model.headers = []
    cache_model.queue = []
    cache_model.clear_suppressed()
    yield
    cache_model.translation = {}
    cache_model.headers = []
    cache_model.queue = []
    cache_model.clear_suppressed()


@pytest.fixture
def translator():
    instance = Translator.__new__(Translator)
    instance.sheet_id = "sheet-id"
    instance.sheet_name = "sheet-name"
    instance.gc = MagicMock()
    instance.remove_duplicate_rows = MagicMock()
    instance._resolve_log_microcopy_caller_location = MagicMock(
        return_value="/tmp/test_translator.py:1"
    )
    return instance


def test_cache_translation_suppressed_helpers():
    cache_model = CacheTranslation.get_default_cache_model()

    cache_model.add_to_suppressed("Deleted", "Deleted", "Another")

    assert set(cache_model.suppressed) == {"Deleted", "Another"}

    cache_model.remove_from_suppressed("Deleted")

    assert cache_model.suppressed == ["Another"]

    cache_model.clear_suppressed()

    assert cache_model.suppressed == []


def test_force_load_translations_does_not_auto_suppress_removed_keys(translator):
    """
    Removed keys should NOT be auto-suppressed anymore.
    Only explicit LEARNGUAL_SUPPRESS_MICROCOPY entries are suppressed.

    force_load_translations() no longer manages the queue - it only loads from sheet.
    Queue management is handled by log_microcopy_job() which filters items already in sheet.
    """
    cache_model = CacheTranslation.get_default_cache_model()
    cache_model.translation = {
        "Keep": {"KO": "keep-ko"},
        "Delete": {"KO": "delete-ko"},
    }
    cache_model.headers = ["EN", "KO"]
    cache_model.queue = ["Delete", "Queued"]

    worksheet = MagicMock()
    worksheet.get_all_values.return_value = [["EN", "KO"], ["Keep", "keep-ko"]]
    sheet = MagicMock()
    sheet.worksheet.return_value = worksheet
    translator.gc.open_by_key.return_value = sheet

    translations = translator.force_load_translations()

    assert translations == {"Keep": {"KO": "keep-ko"}}
    assert cache_model.translation == {"Keep": {"KO": "keep-ko"}}
    # Queue is NOT modified by force_load_translations anymore
    assert cache_model.queue == ["Delete", "Queued"]
    # "Delete" should NOT be auto-suppressed anymore
    assert "Delete" not in cache_model.suppressed


def test_force_load_translations_unsuppresses_reappeared_sheet_rows(translator):
    """
    If a string reappears in the sheet, it should be removed from suppressed list.
    This handles the case where explicit suppression was manually removed.
    """
    cache_model = CacheTranslation.get_default_cache_model()
    cache_model.translation = {"ReAdded": {"KO": "old-ko"}}
    cache_model.headers = ["EN", "KO"]
    cache_model.suppressed = ["ReAdded", "StillSuppressed"]

    worksheet = MagicMock()
    worksheet.get_all_values.return_value = [
        ["EN", "KO"],
        ["ReAdded", "new-ko"],
    ]
    sheet = MagicMock()
    sheet.worksheet.return_value = worksheet
    translator.gc.open_by_key.return_value = sheet

    translator.force_load_translations()

    assert "ReAdded" not in cache_model.suppressed
    assert "StillSuppressed" in cache_model.suppressed


def test_log_microcopy_skips_explicitly_suppressed_strings(translator, settings):
    """
    Microcopy in LEARNGUAL_SUPPRESS_MICROCOPY should be skipped.
    """
    cache_model = CacheTranslation.get_default_cache_model()
    cache_model.headers = ["EN", "KO"]
    settings.LEARNGUAL_SUPPRESS_MICROCOPY = ["Explicit suppress"]

    translator.log_microcopy("Explicit suppress")

    assert cache_model.queue == []
    assert "Explicit suppress" not in cache_model.translation


def test_log_microcopy_queues_non_suppressed_strings(translator, settings):
    """
    Microcopy NOT in LEARNGUAL_SUPPRESS_MICROCOPY should be queued normally.
    """
    cache_model = CacheTranslation.get_default_cache_model()
    cache_model.headers = ["EN", "KO", "DE"]
    settings.LEARNGUAL_SUPPRESS_MICROCOPY = '["Other string"]'

    translator.log_microcopy("  New string  ")

    assert cache_model.queue == ["New string"]
    assert cache_model.translation["New string"] == {"KO": "", "DE": ""}


def test_explicit_suppression_list_with_items(translator, settings):
    """Method should convert list setting to set."""
    settings.LEARNGUAL_SUPPRESS_MICROCOPY = ["String1", "String2", "String3"]
    result = translator._get_explicit_suppression_list()
    assert result == {"String1", "String2", "String3"}


def test_explicit_suppression_list_empty(translator, settings):
    """Empty list should return empty set."""
    settings.LEARNGUAL_SUPPRESS_MICROCOPY = []
    result = translator._get_explicit_suppression_list()
    assert result == set()
