"""Regression suite for the ``PermissionManager.retrieve_permission``
stale-while-serve cache (the `users/me` 40s fix).

The defect this pins: the per-request payment permission lookup had NO HTTP
timeout, so a slow payment-service blocked the calling request indefinitely
(40s `users/me`). The fix:

* 5s request timeout (``SERVICE_REQUEST_TIMEOUT``).
* freshness window = ``cache_timeout`` (default **10s**, unchanged): within
  it the cached copy is returned with NO network call (rate-limit/usage
  counters stay as fresh as before).
* Redis entry TTL = ``PERMISSION_STALE_RETENTION`` (**10 min**): a stale copy
  survives this long so it can be served when a refresh times out.
* stale + refresh timeout/transient-fail -> serve the stale copy (no hang,
  no 5xx).
* cold miss (nothing cached) -> retry up to ``PERMISSION_MAX_RETRIES`` (3),
  then raise (unchanged contract — nothing to serve).
* "invalid service key" / "account does not exist" -> raise immediately,
  NO retry, NO stale serve.
* legacy pre-SWR raw cache entries -> treated as stale (safe rollout).

If any of these regress, `users/me` (and every permission lookup) can hang
again or serve wrong/stale-forever data — these tests must break first.
"""
from __future__ import annotations

from unittest.mock import patch

import pytest
from django.core.cache import cache
from requests import exceptions

from iam_service.learngual import utils
from iam_service.learngual.utils import PERMISSION_MAX_RETRIES, PermissionManager

BASE = "https://payment.example.com"
PID = "acc-123"
URL_PATH = f"/payment/v1/service/permissions/{PID}/"
PERM = {"metadata": {"storage": {"value": 5000}, "request_count": {"value": 7}}}


@pytest.fixture(autouse=True)
def _clear_cache():
    cache.clear()
    yield
    cache.clear()


def _resp(*, ok=True, json_data=None, detail=None, content=b"x"):
    class _R:
        def __init__(self):
            self.ok = ok
            self.content = content

        def json(self):
            if json_data is not None:
                return json_data
            if detail is not None:
                return {"detail": detail}
            raise exceptions.JSONDecodeError("no json", "", 0)

    return _R()


def _get(dot_path=None, cache_timeout=None):
    kw = dict(base_url=BASE, permission_id=PID, service="payment", dot_path=dot_path)
    if cache_timeout is not None:
        kw["cache_timeout"] = cache_timeout
    return PermissionManager().retrieve_permission(**kw)


def _envelope(data, age_seconds):
    """Pre-seed the cache as if fetched ``age_seconds`` ago."""
    from django.utils import timezone

    cache.set(
        URL_PATH,
        {"data": data, "cached_at": timezone.now().timestamp() - age_seconds},
        timeout=utils.PERMISSION_STALE_RETENTION,
    )


# --------------------------------------------------------------------------- #
# cold miss
# --------------------------------------------------------------------------- #


def test_cold_miss_success_caches_envelope():
    with patch.object(utils.requests, "get", return_value=_resp(json_data=PERM)) as g:
        assert _get() == PERM
    assert g.call_count == 1
    # stored as the new envelope, not a raw dict
    env = cache.get(URL_PATH)
    assert set(env) == {"data", "cached_at"} and env["data"] == PERM


def test_cold_miss_dot_path_extraction():
    with patch.object(utils.requests, "get", return_value=_resp(json_data=PERM)):
        assert _get(dot_path="metadata.storage.value") == 5000


def test_cold_miss_all_retries_fail_raises():
    with patch.object(
        utils.requests, "get", side_effect=exceptions.Timeout("slow")
    ) as g:
        with pytest.raises(exceptions.RequestException):
            _get()
    assert g.call_count == PERMISSION_MAX_RETRIES  # 3 tries, then give up


# --------------------------------------------------------------------------- #
# freshness window (cache_timeout, default 10s) — no network
# --------------------------------------------------------------------------- #


def test_fresh_hit_no_network():
    _envelope(PERM, age_seconds=2)  # within default 10s
    with patch.object(utils.requests, "get") as g:
        assert _get() == PERM
    g.assert_not_called()


# --------------------------------------------------------------------------- #
# stale (older than cache_timeout, still within Redis TTL)
# --------------------------------------------------------------------------- #


def test_stale_refresh_success_updates_cache():
    _envelope({"old": True}, age_seconds=30)  # > 10s freshness
    with patch.object(utils.requests, "get", return_value=_resp(json_data=PERM)) as g:
        assert _get() == PERM
    assert g.call_count == 1
    assert cache.get(URL_PATH)["data"] == PERM  # rewritten + age reset


def test_stale_refresh_timeout_serves_stale_no_raise():
    stale = {"stale": True, "metadata": {}}
    _envelope(stale, age_seconds=30)
    with patch.object(
        utils.requests, "get", side_effect=exceptions.Timeout("slow")
    ) as g:
        assert _get() == stale  # served stale, no exception
    assert g.call_count == 1  # stale path does NOT retry


def test_stale_refresh_5xx_serves_stale():
    stale = {"stale": True}
    _envelope(stale, age_seconds=30)
    with patch.object(
        utils.requests, "get", return_value=_resp(ok=False, content=b"502")
    ):
        assert _get() == stale


# --------------------------------------------------------------------------- #
# fatal — immediate raise, no retry, no stale serve
# --------------------------------------------------------------------------- #


def test_fatal_invalid_service_key_raises_immediately_no_retry():
    with patch.object(
        utils.requests,
        "get",
        return_value=_resp(ok=False, detail="Invalid service key"),
    ) as g:
        with pytest.raises(exceptions.RequestException):
            _get()
    assert g.call_count == 1  # NOT PERMISSION_MAX_RETRIES


def test_fatal_account_missing_raises_even_with_stale_present():
    _envelope({"stale": True}, age_seconds=30)
    with patch.object(
        utils.requests,
        "get",
        return_value=_resp(ok=False, detail="account does not exist"),
    ) as g:
        with pytest.raises(exceptions.RequestException):
            _get()
    assert g.call_count == 1  # definitive: no stale serve, no retry


# --------------------------------------------------------------------------- #
# legacy pre-SWR raw cache entry -> treated as stale (safe rollout)
# --------------------------------------------------------------------------- #


def test_legacy_raw_entry_treated_as_stale_and_refreshes():
    cache.set(URL_PATH, {"legacy": True}, timeout=utils.PERMISSION_STALE_RETENTION)
    with patch.object(utils.requests, "get", return_value=_resp(json_data=PERM)) as g:
        assert _get() == PERM
    assert g.call_count == 1
    assert cache.get(URL_PATH)["data"] == PERM  # migrated to envelope


def test_legacy_raw_entry_served_as_stale_on_timeout():
    cache.set(URL_PATH, {"legacy": True}, timeout=utils.PERMISSION_STALE_RETENTION)
    with patch.object(utils.requests, "get", side_effect=exceptions.Timeout("x")):
        assert _get() == {"legacy": True}  # usable stale fallback


# --------------------------------------------------------------------------- #
# empty/falsy permission is NEVER cache-served (pre-SWR `if not data:`).
# Regression for iam #1298 test_api_subscribe_requirement: a renewed
# subscription must take effect on the very next call, not be masked by a
# cached empty {} for the freshness window.
# --------------------------------------------------------------------------- #


def test_empty_permission_never_cache_served_refetched_immediately():
    with patch.object(utils.requests, "get", return_value=_resp(json_data={})) as g1:
        assert _get(dot_path="metadata.subscription_expired.value") is None
    assert g1.call_count == 1
    # The {} got cached, but is falsy -> must NOT be served. A now-active
    # permission must be re-fetched on the very next call.
    active = {"metadata": {"subscription_expired": {"value": False}}}
    with patch.object(
        utils.requests, "get", return_value=_resp(json_data=active)
    ) as g2:
        assert _get(dot_path="metadata.subscription_expired.value") is False
    assert g2.call_count == 1  # re-fetched, NOT served from the empty cache


def test_empty_permission_does_not_short_circuit_as_fresh():
    # Two consecutive {} responses: each call must hit the network (the
    # empty doc is never treated as a fresh/stale cache hit).
    with patch.object(utils.requests, "get", return_value=_resp(json_data={})) as g:
        _get()
        _get()
    assert g.call_count == 2
