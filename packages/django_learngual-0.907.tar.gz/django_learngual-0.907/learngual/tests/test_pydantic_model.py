"""Tests for iam_service.learngual.pydantic_model.

Covers:
- MediaFileSchema `file_id` field (default, explicit set, round-trip,
  backwards-compat with old payloads that don't carry the key).
- DEFAULT_FILE_SCHEMA constant shape (6-signature compatible).
- ProfilePhotoSchema / CoverPhotoSchema inherit `file_id`.
- _DELETED_FILE_SCHEMA in trash/tasks/json_cleanup.py is the same dict
  (backwards-compat alias).
"""
from __future__ import annotations

from iam_service.learngual.pydantic_model import (
    DEFAULT_FILE_SCHEMA,
    CoverPhotoSchema,
    MediaFileSchema,
    ProfilePhotoSchema,
)
from iam_service.learngual.services.media_helper import _MEDIA_SIGNATURE

# ---------------------------------------------------------------------------
# MediaFileSchema.file_id
# ---------------------------------------------------------------------------


def test_media_file_schema_file_id_defaults_to_none():
    """A freshly-constructed schema has file_id=None (not set automatically)."""
    schema = MediaFileSchema()
    assert schema.file_id is None
    assert schema.id == "0"


def test_media_file_schema_file_id_explicit_value_kept():
    """Caller can set file_id; the value round-trips through model_dump."""
    schema = MediaFileSchema(id="abc-123", file_id="abc-123")
    assert schema.file_id == "abc-123"
    dumped = schema.model_dump()
    assert dumped["file_id"] == "abc-123"


def test_media_file_schema_load_payload_without_file_id_succeeds():
    """Old payloads that don't include the key still load — backwards-compat."""
    legacy_payload = {
        "id": "real-id-xyz",
        "url": "https://example.com/file.jpg",
        "name": "file.jpg",
        "size": 1024,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
        # no file_id
    }
    schema = MediaFileSchema(**legacy_payload)
    assert schema.id == "real-id-xyz"
    assert schema.file_id is None  # defaults applied silently


def test_media_file_schema_masked_payload_carries_file_id():
    """A masked payload (id='0' + file_id='abc') loads with both values intact."""
    masked_payload = {
        "id": "0",
        "file_id": "real-id-xyz",
        "url": "https://example.com/default-avatar.png",
        "mimetype": "image/png",
    }
    schema = MediaFileSchema(**masked_payload)
    assert schema.id == "0"
    assert schema.file_id == "real-id-xyz"


def test_media_file_schema_dump_round_trip_preserves_file_id():
    """model_dump → MediaFileSchema(**dumped) must preserve file_id."""
    original = MediaFileSchema(id="0", file_id="persistent-ref-1")
    rebuilt = MediaFileSchema(**original.model_dump())
    assert rebuilt.file_id == original.file_id
    assert rebuilt.id == original.id


# ---------------------------------------------------------------------------
# Subclasses inherit file_id
# ---------------------------------------------------------------------------


def test_profile_photo_schema_inherits_file_id():
    schema = ProfilePhotoSchema(file_id="account-photo-1")
    assert schema.file_id == "account-photo-1"


def test_cover_photo_schema_inherits_file_id():
    schema = CoverPhotoSchema(file_id="account-cover-1")
    assert schema.file_id == "account-cover-1"


# ---------------------------------------------------------------------------
# DEFAULT_FILE_SCHEMA
# ---------------------------------------------------------------------------


def test_default_file_schema_has_signature_keys():
    """Every key of the 6-field _MEDIA_SIGNATURE must be present so
    MediaHelper.extract_media_ids / replace_media_objects still recognise the
    placeholder as a media object."""
    for key in _MEDIA_SIGNATURE:
        assert key in DEFAULT_FILE_SCHEMA, f"missing signature key: {key!r}"


def test_default_file_schema_id_is_zero():
    """The placeholder always has id='0' (the visible-state marker for absent)."""
    assert DEFAULT_FILE_SCHEMA["id"] == "0"


def test_default_file_schema_loads_into_media_file_schema():
    """The placeholder must be a valid MediaFileSchema payload."""
    schema = MediaFileSchema(**DEFAULT_FILE_SCHEMA)
    assert schema.id == "0"
    assert schema.file_id is None  # placeholder doesn't itself carry a ref


def test_default_file_schema_immutability_via_copy():
    """Spreading DEFAULT_FILE_SCHEMA with additional keys (the mixin pattern)
    must not mutate the canonical constant."""
    snapshot = dict(DEFAULT_FILE_SCHEMA)
    spread = {**DEFAULT_FILE_SCHEMA, "file_id": "x"}
    # The spread copy carries file_id; the canonical doesn't.
    assert spread["file_id"] == "x"
    assert "file_id" not in DEFAULT_FILE_SCHEMA
    # Canonical untouched.
    assert DEFAULT_FILE_SCHEMA == snapshot


# ---------------------------------------------------------------------------
# Backwards-compat alias in trash/tasks/json_cleanup
# ---------------------------------------------------------------------------


def test_deleted_file_schema_alias_is_same_dict():
    """_DELETED_FILE_SCHEMA in json_cleanup must reference DEFAULT_FILE_SCHEMA
    (single source of truth — no duplicate definitions)."""
    from iam_service.trash.tasks.json_cleanup import _DELETED_FILE_SCHEMA

    assert _DELETED_FILE_SCHEMA is DEFAULT_FILE_SCHEMA
