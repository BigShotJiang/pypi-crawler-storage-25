"""DRF serializer mixins for nested media file state.

Two mixins, one purpose: keep nested media objects in API responses /
write payloads consistent with the canonical state in the ``FileMedia``
table, without touching the stored JSON.

Read side (``NestedFileStateMixin``)
-----------------------------------
After ``super().to_representation()`` produces the response dict, the mixin
walks it recursively via ``MediaHelper.replace_media_objects`` and rewrites
every signature-matched media object using the state map prebuilt by
:func:`~iam_service.learngual.services.nested_file_state.fetch_nested_file_state`
(stashed in ``self.context["nested_file_state"]`` by the view).

Recognition is by signature — a dict counts as a media object iff it
contains the 6 canonical keys ``{id, url, name, size, mimetype,
convertion_status}``.  This means:

* Profile photos, course thumbnails, Lecture.body audio/video items,
  notification thumbnails, room icons — all handled by one walk.
* Serializer field renames don't matter (we don't read keys by name).
* Polymorphic Lecture bodies don't need a special mixin variant.

Write side (``NormalizeMediaWriteMixin``)
-----------------------------------------
On the way in, the mixin walks the client-supplied payload via
``MediaHelper.normalize_media_payloads`` and applies the ``file_id``
round-trip rule per media object:

* ``id`` non-"0" → trust id, drop file_id (informational only).
* ``id == "0"`` + ``file_id`` present and the FileMedia still exists →
  restore the reference: set ``id = file_id``, drop file_id.
* ``id == "0"`` + ``file_id`` present but the FileMedia was permanently
  deleted → drop file_id, save verbatim (no dangling reference).
* ``id == "0"`` + ``file_id`` missing → save verbatim (overwrite path;
  old pre-``file_id`` clients land here naturally).

The existence check is a single batch query per request, using the per-
service ``NestedFileStateConfig.file_media_qs``.  DB errors propagate —
a write that can't verify references must abort.
"""
from __future__ import annotations

import logging
from typing import Any

from ..services.media_helper import normalize_media_payloads, replace_media_objects
from ..services.nested_file_state import NestedFileStateConfig

logger = logging.getLogger("learngual.serializers.mixins")


class NestedFileStateMixin:
    """DRF serializer mixin that rewrites nested media objects in the response.

    Pattern of use:

    1. The view runs ``fetch_nested_file_state(page, account=..., enterprise=...)``
       AFTER pagination and stashes the result in serializer context under
       ``nested_file_state``.
    2. The serializer inherits this mixin and binds a service-specific
       ``nested_file_config`` (typically via a subclass like
       ``IamNestedFileMixin``).
    3. ``super().to_representation()`` produces the response payload.
    4. This mixin walks the payload recursively, finds every media object
       by signature, and applies the state rule for that object's id:

       * id not in state → leave it alone (no FileMedia row exists or the
         id is the ``"0"`` placeholder).
       * ``state[id]`` is ``None`` → swap the object for
         ``{**default_schema, "file_id": id}`` (trash placeholder; the
         ``file_id`` preserves the persistent reference for a PATCH
         round-trip — see ``normalize_media_object``).
       * ``state[id]`` is a dict → merge ``{**obj, **state[id],
         "file_id": id}`` so fresh ``url`` / ``convertion_status`` etc.
         override the stored JSON.

    The DB is never written to; only the outgoing response is rewritten.

    Each service exports a thin subclass with its config baked in
    (``IamNestedFileMixin``, ``ElearningNestedFileMixin``, ...).
    """

    nested_file_config: NestedFileStateConfig
    """Per-service config singleton.  Bound by the service-specific
    subclass.  The mixin only reads ``.default_schema`` from it; everything
    else (the state map, the walker itself) is signature-based."""

    def to_representation(self, instance: Any) -> Any:
        data = super().to_representation(instance)
        try:
            config = self.nested_file_config
            default_schema = config.default_schema
        except AttributeError:
            # Misconfigured serializer (no config bound).  Log once and
            # return the response unchanged — failing the request over a
            # config typo would be worse than serving fresh-but-unmasked
            # URLs.
            logger.warning(
                "NestedFileStateMixin: %s has no nested_file_config; "
                "returning response unchanged.",
                type(self).__name__,
            )
            return data

        # Preferred path: the view pre-resolved the state for the whole
        # paginated page (one FileMedia query / page) and stashed it in
        # context.  Use it verbatim — efficient and unchanged.
        state = self.context.get("nested_file_state") or {}

        if not state:
            # Self-sufficient safety-net: the view did NOT pre-inject state
            # (custom retrieve, manual serializer construction, an endpoint
            # group / service that never wired the view mixin, a nested
            # serializer rendered outside its own view, …).  Resolve it
            # straight from the serialised payload so file gating
            # (trash → placeholder+file_id ; permanently-deleted →
            # placeholder ; restore → fresh) holds UNIFORMLY for every
            # file-carrying entity, serializer and endpoint group, in
            # every service — regardless of view wiring.
            state = self._resolve_nested_file_state_lazily(data, config)
            if not state:
                return data

        result = replace_media_objects(
            data,
            state=state,
            default_schema=default_schema,
        )
        # Signal the global NestedFileStateJSONRenderer that this payload is
        # already gated, so it skips a second resolve (keeps the efficient
        # / batched path single-query). Best-effort: request may be absent.
        request = self.context.get("request")
        if request is not None:
            try:
                request._nested_file_state_applied = True
            except Exception:
                pass
        return result

    def _resolve_nested_file_state_lazily(
        self, data: Any, config: NestedFileStateConfig
    ) -> dict:
        """Build the state map from the already-serialised ``data`` itself.

        Best-effort: any failure logs and yields ``{}`` (caller then returns
        the response unchanged) — gating must never 500 a read.
        """
        try:
            from ..services.media_helper import extract_media_ids
            from ..services.nested_file_state import build_file_state

            ids = extract_media_ids(data, include_file_id=True)
            if not ids:
                return {}
            request = self.context.get("request")
            account = enterprise = None
            if request is not None:
                user = getattr(request, "user", None)
                if user is not None and not getattr(user, "is_anonymous", False):
                    account = getattr(user, "account", None)
                enterprise = getattr(request, "enterprise", None)
            return build_file_state(
                ids, config=config, account=account, enterprise=enterprise
            )
        except Exception:
            logger.warning(
                "NestedFileStateMixin: lazy state resolve failed for %s; "
                "returning response unchanged.",
                type(self).__name__,
                exc_info=True,
            )
            return {}


class NormalizeMediaWriteMixin:
    """DRF serializer mixin that normalises nested media objects on write.

    Apply to any serializer that accepts a payload containing nested media
    objects (profile photos, course thumbnails, Lecture.body audio/video
    items, Room.group_icon, polymorphic Question.data, ...).

    After DRF parses the incoming ``data`` (but before ``super()``'s
    validation), the mixin walks ``data`` recursively via
    ``MediaHelper.normalize_media_payloads`` so the ``file_id`` round-trip
    rule is applied uniformly:

    * ``id`` non-"0" → trust id; drop ``file_id`` (informational only).
    * ``id == "0"`` + ``file_id`` present + FileMedia still exists →
      restore the reference (set ``id = file_id``, drop ``file_id``).
    * ``id == "0"`` + ``file_id`` present + FileMedia permanently deleted
      → drop ``file_id``, save verbatim (no dangling reference).
    * ``id == "0"`` + ``file_id`` missing → save verbatim (explicit clear).

    The existence check is a single batch query against
    ``config.file_media_qs``.  Per-serializer opt-in keeps call sites
    visible and auditable — ``grep NormalizeMediaWriteMixin`` lists every
    write site that participates.

    Race-safety: ``to_internal_value`` is a pure transform on its ``data``
    argument and immediately delegates to ``super()``.  No module-level
    mutable state.  Concurrent requests are independent calls.  Database
    races on the same row are the pre-existing Django write concern,
    unchanged by this mixin.
    """

    nested_file_config: NestedFileStateConfig
    """Per-service config singleton (same one the read-side mixin uses).
    Bound by the service-specific subclass.  Provides
    ``file_media_qs`` for the batch existence check."""

    def to_internal_value(self, data: Any) -> Any:
        config = getattr(self, "nested_file_config", None)
        if config is None:
            logger.warning(
                "NormalizeMediaWriteMixin: %s has no nested_file_config; "
                "skipping payload normalisation.",
                type(self).__name__,
            )
            return super().to_internal_value(data)

        file_media_qs = getattr(config, "file_media_qs", None)
        normalised = normalize_media_payloads(
            data,
            file_media_qs=file_media_qs,
        )
        return super().to_internal_value(normalised)
