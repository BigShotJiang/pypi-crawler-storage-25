"""Global JSON renderer that enforces nested-file gating on EVERY response.

This is the universal safety-net for the file trash/delete/restore contract:
a trashed or permanently-deleted FileMedia must never be leaked with its
real ``id`` / storage ``url`` inside *any* payload, and a trashed (still
recoverable) file must always carry the ``file_id`` beacon — regardless of
whether the serializer inherits :class:`NestedFileStateMixin` or the view
pre-injected ``nested_file_state``.

Why a renderer (vs. per-serializer mixin only):

* It runs on the **final, fully-rendered** response payload, so it covers
  every serializer, every endpoint group (Instructor / InstructorEnterprise
  / Personal / Enterprise) and every service — including the ~100+ existing
  serializers that never inherited the mixin and any future one. No
  per-serializer wiring can make that guarantee; this can.
* It operates on the **whole** payload once → a single ``build_file_state``
  query per response even for big paginated lists (list-friendly; strictly
  better than a per-row lazy path).
* It is **idempotent**: an already-gated object (placeholder + ``file_id``)
  re-resolves to the same state via the beacon, so layering it on top of
  the serializer mixin / batched view path is safe.
* It is **best-effort**: any failure logs and renders the original payload.
  Gating must never 500 a read.

Hybrid efficiency: when a serializer's :class:`NestedFileStateMixin` (or
the batched view path) has already applied gating it sets
``request._nested_file_state_applied = True``; this renderer then skips the
re-resolve so those endpoints keep their single, pre-batched query.

Each service binds its own config in a thin subclass and registers it in
``REST_FRAMEWORK['DEFAULT_RENDERER_CLASSES']``::

    class LearnNestedFileJSONRenderer(NestedFileStateJSONRenderer):
        nested_file_config = LEARN_NESTED_FILE_CONFIG
"""
from __future__ import annotations

import logging
from typing import Any

from rest_framework.renderers import JSONRenderer

from ..services.media_helper import extract_media_ids, replace_media_objects
from ..services.nested_file_state import NestedFileStateConfig, build_file_state

logger = logging.getLogger("learngual.serializers.renderers")


class NestedFileStateJSONRenderer(JSONRenderer):
    """Apply file-state gating to every JSON response. See module docstring.

    Bind ``nested_file_config`` in a per-service subclass.
    """

    nested_file_config: NestedFileStateConfig | None = None

    def render(self, data, accepted_media_type=None, renderer_context=None):
        try:
            data = self._gate(data, renderer_context)
        except Exception:
            logger.warning(
                "NestedFileStateJSONRenderer: gating failed; rendering "
                "original payload unchanged.",
                exc_info=True,
            )
        return super().render(data, accepted_media_type, renderer_context)

    def _gate(self, data: Any, renderer_context: dict | None) -> Any:
        config = self.nested_file_config
        if config is None or not data:
            return data

        rc = renderer_context or {}
        request = rc.get("request")

        # A serializer mixin / batched view path already gated this payload
        # → don't pay for a second resolve (preserve the efficient path).
        if request is not None and getattr(
            request, "_nested_file_state_applied", False
        ):
            return data

        ids = extract_media_ids(data, include_file_id=True)
        if not ids:
            return data

        account = enterprise = None
        if request is not None:
            user = getattr(request, "user", None)
            if user is not None and not getattr(user, "is_anonymous", False):
                account = getattr(user, "account", None)
            enterprise = getattr(request, "enterprise", None)

        state = build_file_state(
            ids, config=config, account=account, enterprise=enterprise
        )
        if not state:
            return data
        return replace_media_objects(
            data, state=state, default_schema=config.default_schema
        )
