"""Regression tests for the global ``NestedFileStateJSONRenderer``.

This renderer is the UNIVERSAL safety-net that closed the gating
loophole: it gates trashed/deleted files in EVERY JSON response
regardless of whether the serializer inherited the mixin or the view
pre-injected state (the ~100+ serializers / custom retrieves that never
did). If it regresses, trashed files leak again — these tests must break
first.

Pinned contract:
* tri-state through the renderer: active -> fresh+id/file_id ; trashed
  -> placeholder + ``file_id`` beacon ; permanently-deleted ->
  placeholder, NO beacon
* recurses nested dicts/lists and paginated ``{count,results:[...]}``
* ONE ``build_file_state`` call per response (whole payload at once —
  list-friendly), not per row
* skip when a serializer mixin already gated
  (``request._nested_file_state_applied``)
* idempotent: gating an already-gated payload yields the same result
* best-effort: no config / resolver raises -> ORIGINAL payload bytes,
  never an exception (gating must never 500 a read)
* no media ids -> untouched passthrough
"""
from __future__ import annotations

import json
from typing import Any

from iam_service.learngual.serializers.renderers import NestedFileStateJSONRenderer
from iam_service.learngual.services.nested_file_state import NestedFileStateConfig

DEFAULT_FILE_SCHEMA: dict[str, Any] = {
    "id": "0",
    "url": "https://cdn.example.com/default.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


def _media(id_: str, **extra) -> dict[str, Any]:
    return {
        "id": id_,
        "url": f"https://stored.example.com/{id_}.jpg",
        "name": f"{id_}.jpg",
        "size": 1024,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
        **extra,
    }


class _Req:
    def __init__(self, applied: bool = False):
        self.user = None
        self.enterprise = None
        if applied:
            self._nested_file_state_applied = True


def _renderer(*, trashed=None, missing=None, raises=False, no_config=False):
    """A renderer subclass bound to a controllable mock config.

    ``trashed`` ids -> trashed_at set ; ``missing`` ids -> not returned by
    the query (=> PERMANENTLY_DELETED) ; everything else -> active.
    """
    trashed = set(trashed or ())
    missing = set(missing or ())
    calls = {"n": 0}

    def fake_qs(ids):
        calls["n"] += 1
        if raises:
            raise RuntimeError("DB down")

        class _R:
            def __init__(self, pk):
                self.pk = pk
                self.id = pk
                self.trashed_at = "2026-01-01" if pk in trashed else None
                self.upload = type("U", (), {"name": f"u/{pk}"})()
                self.thumbnail = None
                self.mimetype = "image/jpeg"
                self.convertion_status = "DONE"
                self.duration = None
                self.size = 5

        return [_R(str(i)) for i in ids if str(i) not in missing]

    cfg = NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=lambda m, *, account_type=None, enterprise_id=None: f"sig://{m.pk}",
        presign_thumb=lambda m: None,
    )

    class _R(NestedFileStateJSONRenderer):
        nested_file_config = None if no_config else cfg

    r = _R()
    r._calls = calls  # type: ignore[attr-defined]
    return r


def _render(renderer, data, request=None):
    out = renderer.render(data, None, {"request": request} if request else {})
    return json.loads(out)


# --------------------------------------------------------------------------- #
# Tri-state gating through the renderer
# --------------------------------------------------------------------------- #


def test_renderer_gates_trashed_active_and_permanently_deleted():
    r = _renderer(trashed={"trf"}, missing={"delf"})
    data = {
        "active": _media("actf"),
        "trashed": _media("trf"),
        "deleted": _media("delf"),
    }
    out = _render(r, data, _Req())
    # active -> fresh + canonical id/file_id
    assert out["active"]["id"] == "actf" and out["active"]["file_id"] == "actf"
    assert out["active"]["url"] == "sig://actf"
    # trashed -> placeholder + beacon (recoverable)
    assert out["trashed"]["id"] == "0" and out["trashed"]["file_id"] == "trf"
    # permanently deleted -> placeholder, NO beacon
    assert out["deleted"]["id"] == "0"
    assert out["deleted"].get("file_id") in (None, "")
    # one query for the whole response
    assert r._calls["n"] == 1  # type: ignore[attr-defined]


def test_renderer_recurses_lists_and_paginated_results():
    r = _renderer(trashed={"t1"})
    data = {
        "count": 2,
        "next": None,
        "results": [
            {"body": {"data": [{"file": _media("t1")}, {"file": _media("ok")}]}},
            {"thumbnail": _media("ok")},
        ],
    }
    out = _render(r, data, _Req())
    blocks = out["results"][0]["body"]["data"]
    assert blocks[0]["file"]["id"] == "0" and blocks[0]["file"]["file_id"] == "t1"
    assert blocks[1]["file"]["id"] == "ok"
    assert out["results"][1]["thumbnail"]["id"] == "ok"
    assert r._calls["n"] == 1  # type: ignore[attr-defined]


# --------------------------------------------------------------------------- #
# Skip-flag (hybrid efficiency) + idempotency
# --------------------------------------------------------------------------- #


def test_renderer_skips_when_serializer_mixin_already_gated():
    r = _renderer(trashed={"trf"})
    data = {"thumbnail": _media("trf")}  # a real (un-gated) object
    out = _render(r, data, _Req(applied=True))
    # Skipped → payload rendered as-is (NOT gated), and no DB resolve.
    assert out["thumbnail"]["id"] == "trf"
    assert r._calls["n"] == 0  # type: ignore[attr-defined]


def test_renderer_is_idempotent_on_already_gated_payload():
    r = _renderer(trashed={"trf"})
    once = _render(r, {"t": _media("trf")}, _Req())
    # Feed the already-gated payload back through (no skip-flag).
    twice = _render(_renderer(trashed={"trf"}), once, _Req())
    assert twice["t"]["id"] == "0" and twice["t"]["file_id"] == "trf"
    assert twice == once  # stable: beacon re-resolves to the same state


# --------------------------------------------------------------------------- #
# Best-effort: never 500 a read
# --------------------------------------------------------------------------- #


def test_renderer_no_config_passthrough_no_exception():
    r = _renderer(no_config=True)
    data = {"thumbnail": _media("anything")}
    out = _render(r, data, _Req())
    assert out == data  # unchanged, no raise


def test_renderer_resolver_error_returns_original_payload():
    r = _renderer(raises=True)
    data = {"thumbnail": _media("x")}
    out = _render(r, data, _Req())  # must NOT raise
    assert out == data


def test_renderer_no_media_ids_passthrough():
    r = _renderer()
    data = {"meta": {"a": 1}, "items": ["x", "y"], "count": 2}
    out = _render(r, data, _Req())
    assert out == data
    assert r._calls["n"] == 0  # type: ignore[attr-defined]


def test_renderer_handles_empty_and_none_payload():
    r = _renderer()
    assert _render(r, {}, _Req()) == {}
    # DRF JSONRenderer renders None as empty bytes (no body); gating must
    # short-circuit on falsy data and never raise.
    assert r.render(None, None, {"request": _Req()}) == b""
    assert r._calls["n"] == 0  # type: ignore[attr-defined]  # no resolve on empties
