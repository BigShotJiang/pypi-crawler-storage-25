"""Regression tests for the SELF-SUFFICIENT NestedFileStateMixin path.

Root cause of the original "Lecture/Question file gating worked for
Course but not them" bug: gating only happened when the *view*
pre-injected ``context['nested_file_state']``; serializers/views that
didn't (custom retrieve, manual serializer build, an endpoint group that
never wired the view mixin) leaked trashed/deleted files.

The fix made the mixin self-sufficient: when the view did NOT pre-inject
state, ``to_representation`` resolves it lazily from the serialised
payload itself (``build_file_state``), and sets
``request._nested_file_state_applied`` so the global renderer skips a
redundant second resolve.

These tests pin that behaviour so it cannot silently regress:

* no ``context['nested_file_state']`` + media in payload  -> lazily
  resolved & gated (config.file_media_qs IS invoked)
* pre-injected state still used verbatim (lazy path NOT taken)
* both paths set ``request._nested_file_state_applied = True``
* payload with no media ids -> untouched, flag NOT set (renderer may
  still inspect — nothing to do)
* best-effort: a raising ``file_media_qs`` in the lazy path -> original
  payload returned, NO exception, flag NOT set
* missing ``nested_file_config`` -> graceful no-op (covered in
  test_mixins.py; re-pinned here for the lazy entrypoint)
"""
from __future__ import annotations

from typing import Any

from iam_service.learngual.serializers.mixins import NestedFileStateMixin
from iam_service.learngual.services.nested_file_state import NestedFileStateConfig

DEFAULT_FILE_SCHEMA: dict[str, Any] = {
    "id": "0",
    "url": "https://cdn.example.com/default.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


def _media(id_: str, **extra) -> dict[str, Any]:
    return {
        "id": id_,
        "url": f"https://stored.example.com/{id_}.jpg",
        "name": f"{id_}.jpg",
        "size": 1024,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
        **extra,
    }


class _Req:
    """Minimal request stand-in; the mixin sets the skip-flag on it."""

    def __init__(self):
        self.user = None
        self.enterprise = None


def _lazy_config(*, trashed: set[str] | None = None, raises: bool = False):
    trashed = trashed or set()
    calls: list[set] = []

    def fake_qs(ids):
        if raises:
            raise RuntimeError("DB exploded")
        calls.append({str(i) for i in ids})

        class _R:
            def __init__(self, pk):
                self.pk = pk
                self.id = pk
                self.trashed_at = "2026-01-01" if pk in trashed else None
                self.upload = type("U", (), {"name": f"u/{pk}"})()
                self.thumbnail = None
                self.mimetype = "image/jpeg"
                self.convertion_status = "DONE"
                self.duration = None
                self.size = 9

        return [_R(str(i)) for i in ids]

    cfg = NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=lambda m, *, account_type=None, enterprise_id=None: f"sig://{m.pk}",
        presign_thumb=lambda m: None,
    )
    cfg.file_media_qs.calls = calls  # type: ignore[attr-defined]
    return cfg


def _mixin(*, config, context, rendered):
    class _Parent:
        def to_representation(self, instance):
            return rendered

    class _Mixed(NestedFileStateMixin, _Parent):
        pass

    obj = _Mixed()
    obj.nested_file_config = config
    obj.context = context
    return obj


# --------------------------------------------------------------------------- #
# Lazy resolution (view did NOT pre-inject state)
# --------------------------------------------------------------------------- #


def test_lazy_resolves_and_gates_trashed_file_without_context_state():
    cfg = _lazy_config(trashed={"trf"})
    req = _Req()
    obj = _mixin(
        config=cfg,
        context={"request": req},  # NOTE: no 'nested_file_state'
        rendered={"thumbnail": _media("trf")},
    )
    out = obj.to_representation(object())
    # Trashed -> placeholder + file_id beacon (recoverable).
    assert out["thumbnail"]["id"] == "0"
    assert out["thumbnail"]["file_id"] == "trf"
    # Lazy path actually hit the DB factory.
    assert cfg.file_media_qs.calls == [{"trf"}]  # type: ignore[attr-defined]
    # Skip-flag set so the global renderer won't re-resolve.
    assert getattr(req, "_nested_file_state_applied", False) is True


def test_lazy_active_file_merges_fresh_and_sets_beacon():
    cfg = _lazy_config()
    req = _Req()
    obj = _mixin(
        config=cfg,
        context={"request": req},
        rendered={"f": _media("act", url="https://OLD/stale.jpg")},
    )
    out = obj.to_representation(object())
    assert out["f"]["id"] == "act"
    assert out["f"]["file_id"] == "act"
    assert out["f"]["url"] == "sig://act"  # fresh url replaced the stale one
    assert getattr(req, "_nested_file_state_applied", False) is True


def test_preinjected_state_used_verbatim_lazy_not_taken():
    cfg = _lazy_config()  # would mark active; pre-injected says trashed
    req = _Req()
    obj = _mixin(
        config=cfg,
        context={"request": req, "nested_file_state": {"abc": None}},
        rendered={"f": _media("abc")},
    )
    out = obj.to_representation(object())
    assert out["f"]["id"] == "0" and out["f"]["file_id"] == "abc"
    # Pre-injected path → lazy file_media_qs NEVER called.
    assert cfg.file_media_qs.calls == []  # type: ignore[attr-defined]
    assert getattr(req, "_nested_file_state_applied", False) is True


def test_no_media_ids_payload_untouched_and_flag_not_set():
    cfg = _lazy_config()
    req = _Req()
    payload = {"title": "no media here", "count": 3}
    obj = _mixin(config=cfg, context={"request": req}, rendered=dict(payload))
    out = obj.to_representation(object())
    assert out == payload
    assert cfg.file_media_qs.calls == []  # type: ignore[attr-defined]
    assert getattr(req, "_nested_file_state_applied", False) is False


def test_lazy_best_effort_on_qs_error_returns_unchanged_no_raise():
    cfg = _lazy_config(raises=True)
    req = _Req()
    original = {"thumbnail": _media("x")}
    obj = _mixin(
        config=cfg, context={"request": req}, rendered={"thumbnail": _media("x")}
    )
    out = obj.to_representation(object())  # must NOT raise
    assert out == original  # untouched
    assert getattr(req, "_nested_file_state_applied", False) is False


def test_missing_config_graceful_noop_even_on_lazy_entry(caplog):
    class _Parent:
        def to_representation(self, instance):
            return {"thumbnail": _media("y")}

    class _Mixed(NestedFileStateMixin, _Parent):
        pass

    obj = _Mixed()
    obj.context = {"request": _Req()}  # no nested_file_config bound
    out = obj.to_representation(object())
    assert out == {"thumbnail": _media("y")}  # unchanged, no crash


def test_lazy_handles_missing_request_in_context():
    """No request object → lazy still gates; flag-set is best-effort."""
    cfg = _lazy_config(trashed={"z"})
    obj = _mixin(config=cfg, context={}, rendered={"a": _media("z")})
    out = obj.to_representation(object())
    assert out["a"]["id"] == "0" and out["a"]["file_id"] == "z"
