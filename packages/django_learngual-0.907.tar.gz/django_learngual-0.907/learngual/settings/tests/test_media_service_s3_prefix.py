"""Tests for the MEDIA_SERVICE_S3_PREFIX setting.

The shared presigner reads ``settings.MEDIA_SERVICE_S3_PREFIX`` when
building S3 object keys on behalf of media-service.  These tests verify:

- The setting is present at the Django config level.
- The default value is ``"media/media"`` (media-service's actual location).
- The shared presigner uses the setting when constructing CDN URLs.
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

from django.conf import settings
from django.test import override_settings

# ---------------------------------------------------------------------------
# Setting is bound at the Django config level
# ---------------------------------------------------------------------------


def test_media_service_s3_prefix_setting_exists():
    """Default value must be 'media/media' (matches the media-service S3
    layout, see media-service/core/utils/storages.py:268)."""
    assert hasattr(settings, "MEDIA_SERVICE_S3_PREFIX")
    # Default applied when env var is unset.
    assert settings.MEDIA_SERVICE_S3_PREFIX in ("media/media",)


# ---------------------------------------------------------------------------
# Shared presigner uses the setting
# ---------------------------------------------------------------------------


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="learngual-bucket",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presigner_uses_default_prefix_in_cdn_url():
    """With the default setting, the CDN URL embeds 'media/media' as the
    folder — matching media-service's actual S3 layout."""
    from iam_service.learngual.services.presign import _presign_s3

    field = SimpleNamespace(name="audios/x.wav", url="fallback")
    url = _presign_s3(field)
    # Expect ``https://<cdn>/<bucket>/media/media/<key>``.
    assert url == "https://cdn.example.com/learngual-bucket/media/media/audios/x.wav"


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="learngual-bucket",
    MEDIA_SERVICE_S3_PREFIX="custom/path",
)
def test_presigner_honours_setting_override():
    """A per-environment override of MEDIA_SERVICE_S3_PREFIX is reflected in
    the emitted URL — confirms the setting is the single source of truth."""
    from iam_service.learngual.services.presign import _presign_s3

    field = SimpleNamespace(name="x.wav", url="fallback")
    url = _presign_s3(field)
    assert url == "https://cdn.example.com/learngual-bucket/custom/path/x.wav"


@override_settings(
    AWS_S3_DOMAIN=None,
    AWS_S3_ENDPOINT_URL="http://minio:9000",
    AWS_STORAGE_BUCKET_NAME="learngual-bucket",
    AWS_ACCESS_KEY_ID="key",
    AWS_SECRET_ACCESS_KEY="secret",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presigner_uses_prefix_for_boto3_minio_path():
    """In the dev/MinIO branch the setting still controls the object key
    that's signed."""
    from iam_service.learngual.services.presign import _presign_s3

    field = SimpleNamespace(name="audios/x.wav", url="fallback")
    with patch("iam_service.learngual.services.presign.boto3.client") as mock_client:
        mock_client.return_value.generate_presigned_url.return_value = (
            "http://minio:9000/presigned"
        )
        _presign_s3(field)
    params = mock_client.return_value.generate_presigned_url.call_args.kwargs["Params"]
    assert params["Key"] == "media/media/audios/x.wav"
