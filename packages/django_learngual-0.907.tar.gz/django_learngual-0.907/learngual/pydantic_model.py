from typing import Any, Literal

from django.utils import timezone
from pydantic import AnyHttpUrl, Field, field_validator

from .interface import BaseModel, BaseTypeModel


class SocialMediaLinksSchema(BaseModel):
    facebook: AnyHttpUrl | None = Field(None)
    instagram: AnyHttpUrl | None = Field(None)
    linkedin: AnyHttpUrl | None = Field(None)
    twitter: AnyHttpUrl | None = Field(None)
    website: AnyHttpUrl | None = Field(None)


"""
Account settings link
"""


class AccountSettingsSchema:
    class Base(BaseTypeModel):
        type: Literal["DEFAULT"] = "DEFAULT"
        social_links: SocialMediaLinksSchema = Field(
            default_factory=SocialMediaLinksSchema
        )

    class EnterpriseSettings(Base, BaseTypeModel):

        type: Literal["ENTERPRISE"] = "ENTERPRISE"
        who_can_view_your_profile: Literal[
            "Enterprise members only",
            "Enterprise members and public viewers",
            "Public viewers",
        ] = Field("Enterprise members only")
        show_statistics: bool = Field(False)
        show_available_course_languages: bool = Field(False)
        show_social_media_links: bool = Field(False)
        show_courses: bool = Field(False)

    class InstructorSettings(Base):
        type: Literal["INSTRUCTOR"] = "INSTRUCTOR"
        who_can_view_your_profile: Literal[
            "Friends",
            "Students only",
            "Instructors only",
            "Students and instructors",
            "All enterprise",
        ] = Field("Friends")
        show_statistics: bool = Field(True)
        show_available_course_languages: bool = Field(True)
        show_social_media_links: bool = Field(True)
        show_courses: bool = Field(True)
        show_affiliates: bool = Field(True)

    class PersonalSettings(Base):
        who_can_view_your_profile: Literal[
            "Friends",
            "All affiliated accounts",
            "Public",
            "Students and enterprise",
            "Students and instructors",
        ] = Field("Friends")
        show_evaluations: bool = Field(True)
        show_achievements: bool = Field(True)
        show_affiliate: bool = Field(True)
        show_courses: bool = Field(True)
        exercises_per_week: int = Field(0)

        type: Literal["PERSONAL"] = "PERSONAL"

    class DeveloperSettings(Base):
        type: Literal["DEVELOPER"] = "DEVELOPER"


class MediaFileSchema(BaseTypeModel):
    id: str = Field(
        "0",
        description=(
            "Visible-state marker for the media file. '0' means the client is "
            "currently shown the placeholder (e.g. because the underlying "
            "FileMedia is trashed). Any other value means the client is shown "
            "the real file. Use `file_id` to keep the persistent reference "
            "across a PATCH round-trip when this is '0'."
        ),
    )
    file_id: str | None = Field(
        None,
        description=(
            "Persistent reference to the underlying FileMedia id. Carried "
            "through the response when `id` is '0' (e.g. file is in trash) so "
            "a PATCH that echoes the payload back doesn't drop the link. "
            "On a normal read with no masking, `file_id` mirrors `id`. The "
            "write-side normaliser uses it to restore `id` when the file "
            "still exists, and drops it when the file has been permanently "
            "deleted."
        ),
    )
    name: str | None = Field(
        None,
        description=(
            "Display name of the media file (matches the FileMedia.name "
            "column and the `name` key in the media-service Retrieve "
            "response).  Required for MediaHelper's signature recognition "
            "(one of the 6 keys that identify a dict as a media object)."
        ),
    )
    url: str = Field(
        "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/default-avatar.png",
        description="Direct URL to access the media file",
    )
    thumbnail_url: str | None = Field(
        None, description="Optional thumbnail URL for the media file"
    )
    uploaded_by: dict[str, Any] | None = Field(
        None,
        description="Information about the user who uploaded the media file",
    )
    stream_url: str | None = Field(
        None, description="Optional streaming URL for the media file"
    )
    mimetype: str = Field(
        default="image/png",
        description="MIME type of the media file (e.g., image/jpeg, video/mp4)",
    )
    size: float | int = Field(
        default=0,
        ge=0,
        description="Size of the media file in bytes. Must be a non-negative integer",
    )
    convertion_status: str | None = Field(
        None,
        description="Status of the media file conversion (e.g., 'pending', 'completed')",
    )
    duration: timezone.timedelta | None = Field(
        None, description="Duration of the media file (if applicable)"
    )
    course_count: int = Field(
        default=0,
        ge=0,
        description="Number of courses associated with the media file",
    )
    last_used: timezone.datetime | None = Field(
        None, description="Timestamp when the media file was last used"
    )
    created_at: timezone.datetime | None = Field(
        None, description="Timestamp when the media file was created"
    )
    updated_at: timezone.datetime | None = Field(
        None, description="Timestamp when the media file was last updated"
    )

    @field_validator("duration", mode="before")
    @classmethod
    def remove_space(cls, value: str | None) -> str | None:
        if value is not None:
            return value.strip()


class DeveloperProfilePhotoSchema(MediaFileSchema):
    url: str = Field(
        "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/Developer.png",
        description="Direct URL to access the media file",
    )


class ProfilePhotoSchema(MediaFileSchema):
    url: str = Field(
        "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/default-avatar.png",
        description="Direct URL to access the media file",
    )


class CoverPhotoSchema(MediaFileSchema):
    url: str = Field(
        "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/default-cover-photo.png",
        description="Direct URL to access the media file",
    )


# Canonical "this slot is empty/deleted" placeholder for a nested media field.
# All six _MEDIA_SIGNATURE keys are present so MediaHelper still recognises
# the slot as a media object; ``id`` is "0" to signal absence.
#
# Used by:
#   * the trash JSON-cleanup task (hard-delete fallback when a file is gone)
#   * the read-side NestedFileStateMixin (swap when the underlying FileMedia
#     is in trash; the mixin tacks on a ``file_id`` key with the original id
#     to preserve the reference across a PATCH round-trip)
#   * any other consumer that needs the canonical empty-file shape
DEFAULT_FILE_SCHEMA: dict = {
    "id": "0",
    "url": "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/default-avatar.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
    "uploaded_media_url": None,
}
