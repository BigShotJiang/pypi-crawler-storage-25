"""Service-agnostic, inline ``FilemediaCourses.reference_data`` reconciler.

Shared across services (elearning-service authoring + iam-service trash/restore).
Bound to a service's own ``FilemediaCourses`` model via
:class:`ReferenceTrackingConfig` (same config-binding pattern as
``learngual.services.nested_file_state``).

Design / rationale: see plan ``lucky-squishing-aurora.md``. Key ideas:

* ``reference_data`` is the per-``(course, file)`` map
  ``{model_key: {instance_id: count}}``.  Updates are **partial** — only the
  ``(model_key, instance_id)`` cells owned by the reconciled instances are
  touched; other entities' entries are never clobbered.
* A row whose ``reference_count`` reaches 0 is **hard-deleted**.  Soft-trash
  (3-state ``trashed_at`` / ``trashed_by_parent``) is applied **only** to
  non-empty rows and **only** for course/file-scoped trash
  (:func:`soft_trash_fmc`) — ``reference_data`` is preserved there for lossless
  restore.  Empty rows are hard-deleted even on course/file trash.
* Restore is **upsert/recompute** — never assume the row survived.
* Concurrency: every mutation locks the affected rows with
  ``SELECT … FOR UPDATE`` in ``pk`` order inside ``transaction.atomic()``.

The carrier model (Lecture / Question / Test / Course / FileMedia, per
service) exposes the small interface documented on
:class:`ReferenceCarrierProtocol`.  The reusable
:class:`ReferenceTrackingQuerySetMixin` wires every queryset/bulk path
(``bulk_create`` / ``bulk_update`` / ``update`` / ``delete``) to it so there
are no scattered call sites.
"""
from __future__ import annotations

import logging
from collections import Counter, defaultdict
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from enum import Enum

from django.db import transaction
from django.utils import timezone

logger = logging.getLogger(__name__)

#: ``.update(**kw)`` keys that drive trash state.
TRASH_FIELDS = ("trashed_at", "trashed_by_parent")


def calc_reference_count(reference_data: dict) -> int:
    """Sum of every positive per-instance count across all model keys."""
    if not isinstance(reference_data, dict):
        return 0
    total = 0
    for model_instances in reference_data.values():
        if not isinstance(model_instances, dict):
            continue
        for count in model_instances.values():
            try:
                c = int(count)
            except (TypeError, ValueError):
                continue
            if c > 0:
                total += c
    return total


def extract_file_id(schema) -> str:
    """File id from a FileSchema-shaped dict/object (``""`` if none)."""
    if isinstance(schema, dict):
        return str(schema.get("id") or "")
    return str(getattr(schema, "id", "") or "")


# A real FileSchema dump always carries id+url+size+mimetype. Requiring
# ``mimetype`` (and url) avoids false positives from unrelated dicts that
# merely happen to have id/url/size. MUST stay in lockstep with elearning
# ``extract_media_id_occurrences`` (which delegates here) and the backfill
# scan, or the inline⇄backfill zero-delta invariant breaks.
_FILE_SCHEMA_KEYS = frozenset({"id", "url", "size", "mimetype"})

#: container keys whose subtree is never a file payload — never recurse into
#: them (perf + avoids pathological false positives in unrelated blobs).
#: Internal optimization, distinct from the caller-facing ``exclude``.
_WALK_PRUNE_KEYS = frozenset({"qa_generation", "staging_data", "metadata_schema"})


def _compile_exclude(exclude: dict | None):
    """Compile a ``{field: values}`` exclude map into a single predicate
    ``(file_dict) -> bool`` **once**, so the recursion never iterates the
    map per node.

    The realistic case is a single field (e.g. ``{"id": {...}}``) → a bare
    set-membership closure with **no loop at all** (faster + simpler than a
    precompiled regex, since these are exact id matches, not patterns). The
    multi-field branch is the only fallback (rare).
    """
    if not exclude:
        return None
    items = [(f, frozenset(map(str, v))) for f, v in exclude.items()]
    if len(items) == 1:
        field, values = items[0]
        return lambda o: str(o.get(field)) in values
    return lambda o: any(str(o.get(f)) in v for f, v in items)


def _walk_file_dicts(obj, out: list, is_excluded=None) -> None:
    """Collect file-schema dicts from a nested payload.

    ``is_excluded`` is a precompiled predicate (see :func:`_compile_exclude`);
    a matched file object for which it returns True is dropped during the
    walk itself (cheaper than count-then-filter).
    """
    if type(obj) is dict:
        if _FILE_SCHEMA_KEYS <= obj.keys():
            # Matched a file object — drop if excluded, else record and DON'T
            # recurse into it (its values are scalars; descending only risks
            # mis-detecting nested blobs / double-counting).
            if is_excluded is None or not is_excluded(obj):
                out.append(obj)
            return
        for k, v in obj.items():
            if k not in _WALK_PRUNE_KEYS:
                _walk_file_dicts(v, out, is_excluded)
    elif type(obj) in (list, tuple):
        for item in obj:
            _walk_file_dicts(item, out, is_excluded)


def extract_file_occurrences(payload, exclude: dict | None = None) -> dict:
    """``{file_id: occurrence_count}`` over a nested payload.

    ``exclude`` (``{field: values}``, e.g. ``{"id": trashed_ids}``) is
    compiled **once** into a predicate and applied during the walk. Same
    file-object predicate as elearning ``extract_media_id_occurrences``
    (which delegates here) and the backfill scan so inline ⇄ backfill stay
    consistent.
    """
    found: list = []
    _walk_file_dicts(payload, found, _compile_exclude(exclude))
    # No "0"/empty guard needed: the strict id+url+size+mimetype predicate +
    # key-exclude in _walk_file_dicts gate detection, and every consumer
    # filters ids down to *active* FileMedia (``_reference_active_filemedia``
    # / the config's ``trashed_or_missing_filemedia`` / backfill's active_fids
    # prune), which already drop "0", "" and unknown ids.
    return dict(Counter(extract_file_id(d) for d in found))


class Intent(str, Enum):
    """Why the reconcile is running (informational; algorithm is unified)."""

    AUTHORING = "authoring"
    TRASH = "trash"
    RESTORE = "restore"


class TrashStyle(str, Enum):
    """How a carrier's trash/restore maps onto FilemediaCourses rows."""

    #: Lecture / Question / Test — entity contributes to shared rows; trash ==
    #: AUTHORING removal of that instance (strip + hard-delete on zero),
    #: restore == AUTHORING re-add (upsert from the live entity).
    CONTENT = "content"
    #: Course — trash soft-trashes every row of the course; restore un-trashes.
    COURSE_SCOPE = "course_scope"
    #: FileMedia — trash soft-trashes every row for the filemedia_id; restore
    #: un-trashes (lossless: reference_data was preserved).
    FILE_SCOPE = "file_scope"


@dataclass(frozen=True)
class Contribution:
    """Desired truth for ONE ``(course, model_key, instance)``.

    ``file_counts == {}`` means the instance references no (live) file — used
    for deletion / trash of a content entity (strip its cells everywhere).
    """

    course_id: int
    model_key: str
    instance_id: str
    file_counts: dict  # {file_id(str): count(int>0)}


@dataclass
class ReferenceSyncResult:
    created: int = 0
    updated: int = 0
    deleted: int = 0

    def __add__(self, other: ReferenceSyncResult) -> ReferenceSyncResult:
        return ReferenceSyncResult(
            self.created + other.created,
            self.updated + other.updated,
            self.deleted + other.deleted,
        )


@dataclass(frozen=True)
class ReferenceTrackingConfig:
    """Per-service binding.

    Args:
        base_queryset: zero-arg callable returning a **with-trash**
            ``FilemediaCourses`` queryset (MUST include soft-trashed rows — the
            reconcile has to see and revive them). e.g.
            ``lambda: FilemediaCourses.objects.with_trash()`` (elearning) or
            ``lambda: FilemediaCourses.objects.all()`` (iam, managed=False).
        fmc_model: the service's ``FilemediaCourses`` model class.
        trashed_or_missing_filemedia: optional callable mapping an iterable of
            filemedia ids → the subset that is trashed or absent. Those
            ``(course, filemedia)`` rows are owned by the file trash/restore
            lifecycle and are excluded from authoring mutation.
        calc_reference_count: override hook (defaults to module function).
    """

    base_queryset: Callable[[], object]
    fmc_model: type
    trashed_or_missing_filemedia: Callable[[Iterable], set] | None = None
    calc_reference_count: Callable[[dict], int] = calc_reference_count


# --------------------------------------------------------------------------- #
# Core reconcile
# --------------------------------------------------------------------------- #


def _exclude_trashed_filemedia(
    config: ReferenceTrackingConfig, filemedia_ids: set
) -> set:
    if not filemedia_ids or config.trashed_or_missing_filemedia is None:
        return set()
    try:
        return {str(x) for x in config.trashed_or_missing_filemedia(filemedia_ids)}
    except Exception:  # best-effort: never break the write path
        logger.exception("reference_tracking: trashed_or_missing_filemedia failed")
        return set()


def _pairs_q(pairs: set):
    """OR of ``(course_id, filemedia_id)`` matches, grouped by course."""
    from django.db.models import Q

    by_course: dict = defaultdict(set)
    for course_id, fid in pairs:
        by_course[course_id].add(fid)
    q = Q()
    for course_id, fids in by_course.items():
        q |= Q(course_id=course_id, filemedia_id__in=list(fids))
    return q


def apply_reference_updates(
    config: ReferenceTrackingConfig,
    contributions: Sequence[Contribution],
    *,
    intent: Intent = Intent.AUTHORING,
    used_by_id=None,
) -> ReferenceSyncResult:
    """Reconcile ``reference_data`` for the given contributions.

    Unified algorithm for AUTHORING add/edit/remove and RESTORE: make every
    affected row reflect exactly the reconciled instances' current live file
    references, partial-merging only those instances' cells, upserting missing
    ``(course, file)`` rows, un-trashing rows that regain an active reference,
    and **hard-deleting** rows whose ``reference_count`` hits 0.
    """
    contributions = list(contributions or [])
    if not contributions:
        return ReferenceSyncResult()

    # desired[(course, file)][model_key][instance_id] = count
    desired: dict = defaultdict(lambda: defaultdict(dict))
    # per course: {(model_key, instance_id): {file_id: count}}
    reconciled: dict = defaultdict(dict)

    for c in contributions:
        course_id = int(c.course_id)
        iid = str(c.instance_id)
        clean = {
            str(fid): int(cnt)
            for fid, cnt in (c.file_counts or {}).items()
            if fid and int(cnt) > 0
        }
        reconciled[course_id][(c.model_key, iid)] = clean
        for fid, cnt in clean.items():
            desired[(course_id, str(fid))][c.model_key][iid] = cnt

    course_ids = {cid for cid, _ in desired} | set(reconciled)
    base = config.base_queryset()

    # --- Universe of rows to touch ----------------------------------------- #
    target_pairs = set(desired.keys())
    stale_pairs: set = set()
    for course_id, by_key in reconciled.items():
        ids_by_key: dict = defaultdict(list)
        for (mk, iid) in by_key:
            ids_by_key[mk].append(iid)
        for mk, iids in ids_by_key.items():
            lookup = {
                "course_id": course_id,
                f"reference_data__{mk}__has_any_keys": iids,
            }
            for fid in base.filter(**lookup).values_list("filemedia_id", flat=True):
                stale_pairs.add((course_id, str(fid)))

    all_pairs = target_pairs | stale_pairs
    if not all_pairs:
        return ReferenceSyncResult()

    # Exclude (course, filemedia) whose FileMedia is trashed/deleted — owned by
    # the file trash/restore lifecycle.
    trashed_fids = _exclude_trashed_filemedia(config, {fid for _, fid in all_pairs})
    if trashed_fids:
        all_pairs = {p for p in all_pairs if p[1] not in trashed_fids}
        target_pairs = {p for p in target_pairs if p[1] not in trashed_fids}
    if not all_pairs:
        return ReferenceSyncResult()

    result = ReferenceSyncResult()
    fmc_model = config.fmc_model

    with transaction.atomic():
        # Upsert placeholders for any missing desired pair (race-safe).
        existing_keys = {
            (int(c), str(f))
            for c, f in base.filter(
                course_id__in={c for c, _ in target_pairs},
                filemedia_id__in={f for _, f in target_pairs},
            ).values_list("course_id", "filemedia_id")
        }
        missing = [
            fmc_model(
                course_id=course_id,
                filemedia_id=fid,
                reference_data={},
                reference_count=0,
                trashed_at=None,
                trashed_by_parent=None,
            )
            for (course_id, fid) in target_pairs
            if (course_id, fid) not in existing_keys
        ]
        if missing:
            fmc_model.objects.bulk_create(
                missing, batch_size=1000, ignore_conflicts=True
            )

        rows = list(
            base.filter(course_id__in=course_ids)
            .filter(_pairs_q(all_pairs))
            .select_for_update()
            .order_by("pk")
        )

        to_update = []
        delete_ids = []
        now = timezone.now()

        for fmc in rows:
            key = (int(fmc.course_id), str(fmc.filemedia_id))
            data = (
                dict(fmc.reference_data) if isinstance(fmc.reference_data, dict) else {}
            )
            changed = False

            for (mk, iid), file_counts in reconciled.get(key[0], {}).items():
                desired_count = file_counts.get(key[1])
                model_dict = dict(data.get(mk, {}))
                if desired_count and desired_count > 0:
                    if model_dict.get(iid) != desired_count:
                        model_dict[iid] = desired_count
                        changed = True
                elif iid in model_dict:
                    model_dict.pop(iid, None)
                    changed = True
                if model_dict:
                    data[mk] = model_dict
                elif mk in data:
                    data.pop(mk, None)
                    changed = True

            new_count = config.calc_reference_count(data)

            if new_count <= 0:
                if fmc.pk:
                    delete_ids.append(fmc.pk)
                continue

            was_trashed = fmc.trashed_at is not None or bool(fmc.trashed_by_parent)
            if changed or was_trashed or int(fmc.reference_count or 0) != new_count:
                fmc.reference_data = data
                fmc.reference_count = new_count
                fmc.trashed_at = None
                fmc.trashed_by_parent = None
                fmc.date_time = now
                if used_by_id is not None:
                    fmc.used_by_id = used_by_id
                to_update.append(fmc)

        if to_update:
            fmc_model.objects.bulk_update(
                to_update,
                fields=[
                    "reference_data",
                    "reference_count",
                    "trashed_at",
                    "trashed_by_parent",
                    "date_time",
                    "used_by",
                ],
                batch_size=1000,
            )
            result.updated += len(to_update)
        if delete_ids:
            fmc_model.objects.filter(id__in=delete_ids).delete()
            result.deleted += len(delete_ids)
        result.created += len(missing)

    logger.info(
        "reference_tracking.apply_reference_updates: intent=%s "
        "contributions=%d created=%d updated=%d deleted=%d",
        intent.value,
        len(contributions),
        result.created,
        result.updated,
        result.deleted,
    )
    return result


# --------------------------------------------------------------------------- #
# Course / File scoped trash + restore (reference_data preserved)
# --------------------------------------------------------------------------- #


def _scope_q(course_ids, filemedia_ids):
    from django.db.models import Q

    q = Q()
    if course_ids:
        q |= Q(course_id__in=list(course_ids))
    if filemedia_ids:
        q |= Q(filemedia_id__in=list(filemedia_ids))
    return q


def soft_trash_fmc(
    config: ReferenceTrackingConfig,
    *,
    course_ids: Iterable | None = None,
    filemedia_ids: Iterable | None = None,
    trashed_by_parent: bool = True,
) -> ReferenceSyncResult:
    """Course/File-scoped trash.

    Empty rows (``reference_count <= 0``) are **hard-deleted** (nothing to
    preserve); non-empty *active* rows are soft-trashed with ``reference_data``
    untouched (lossless restore). Already-trashed rows are left as-is so an
    independently-trashed row's ``trashed_by_parent`` is not downgraded
    (3-state safe).
    """
    course_ids = list(course_ids or [])
    filemedia_ids = list(filemedia_ids or [])
    if not course_ids and not filemedia_ids:
        return ReferenceSyncResult()

    result = ReferenceSyncResult()
    base = config.base_queryset()
    scope = _scope_q(course_ids, filemedia_ids)
    with transaction.atomic():
        deleted, _ = base.filter(scope, reference_count__lte=0).delete()
        result.deleted += deleted or 0
        result.updated += base.filter(
            scope, reference_count__gt=0, trashed_at__isnull=True
        ).update(trashed_at=timezone.now(), trashed_by_parent=trashed_by_parent)
    logger.info(
        "reference_tracking.soft_trash_fmc: courses=%d files=%d "
        "soft_trashed=%d empty_deleted=%d",
        len(course_ids),
        len(filemedia_ids),
        result.updated,
        result.deleted,
    )
    return result


def untrash_fmc(
    config: ReferenceTrackingConfig,
    *,
    course_ids: Iterable | None = None,
    filemedia_ids: Iterable | None = None,
) -> int:
    """Course/File-scoped restore — revive rows soft-trashed *via parent
    cascade* (``trashed_by_parent=True``).

    Independently-trashed rows (``trashed_by_parent=False``) stay trashed
    (mirrors the content-tree restore cascade). Lossless: ``reference_data``
    was preserved by :func:`soft_trash_fmc`; rows that were empty
    (hard-deleted on trash) had nothing to restore.
    """
    course_ids = list(course_ids or [])
    filemedia_ids = list(filemedia_ids or [])
    if not course_ids and not filemedia_ids:
        return 0
    base = config.base_queryset()
    scope = _scope_q(course_ids, filemedia_ids)
    with transaction.atomic():
        n = base.filter(scope, trashed_at__isnull=False, trashed_by_parent=True).update(
            trashed_at=None, trashed_by_parent=None
        )
    logger.info(
        "reference_tracking.untrash_fmc: courses=%d files=%d untrashed=%d",
        len(course_ids),
        len(filemedia_ids),
        n,
    )
    return n


# --------------------------------------------------------------------------- #
# QuerySet mixin — the single, reusable hook for every bulk/queryset path
# --------------------------------------------------------------------------- #


class ReferenceCarrierProtocol:
    """Interface a carrier model must provide for the mixin to work.

    Implement as ``classmethod`` / class attributes on the carrier (elearning:
    on ``LearnNestedFileCarrierMixin``; iam: on a small mixin for the
    managed=False mirrors). If ``reference_tracking_config`` returns ``None``
    the mixin is a no-op for that model.
    """

    #: TrashStyle for this carrier.
    REFERENCE_TRASH_STYLE: TrashStyle = TrashStyle.CONTENT
    #: ``.update(**kw)`` keys (besides trash fields) that change file content.
    REFERENCE_FILE_FIELDS: tuple = ()
    #: Inline if affected rows ≤ this; else dispatch the async backfill.
    REFERENCE_SYNC_THRESHOLD: int = 200

    @classmethod
    def reference_tracking_config(cls):  # pragma: no cover - interface
        """Return a :class:`ReferenceTrackingConfig` or ``None`` (disabled)."""
        return None

    @classmethod
    def build_reference_contributions(
        cls, instances, *, removed: bool = False
    ):  # pragma: no cover - interface
        """Contributions for ``instances`` (``removed`` → ``file_counts={}``)."""
        raise NotImplementedError

    @classmethod
    def reference_scope_ids(cls, instances):  # pragma: no cover - interface
        """COURSE_SCOPE → course ids; FILE_SCOPE → filemedia ids."""
        return [getattr(i, "pk", i) for i in instances]

    @classmethod
    def reference_async_fallback(cls, instances) -> None:  # pragma: no cover
        """Dispatch the kept async backfill for large ops (optional)."""
        return None


def _safe(fn, *a, **kw):
    """Run a side-effect best-effort: log, never raise into the caller."""
    try:
        return fn(*a, **kw)
    except Exception:
        logger.exception("reference_tracking: side-effect failed")
        return None


class ReferenceTrackingQuerySetMixin:
    """Compose into a carrier's QuerySet (``class QuerySet_(mixin, Base,
    models.QuerySet)``).

    Overrides every signal-bypassing path so reference tracking is automatic
    and centralized. Best-effort: a tracking failure never breaks the caller.
    """

    # -- helpers --------------------------------------------------------- #

    def _ref_config(self):
        fn = getattr(self.model, "reference_tracking_config", None)
        return fn() if fn else None

    def _ref_style(self) -> TrashStyle:
        return getattr(self.model, "REFERENCE_TRASH_STYLE", TrashStyle.CONTENT)

    def _is_scope(self) -> bool:
        return self._ref_style() in (
            TrashStyle.COURSE_SCOPE,
            TrashStyle.FILE_SCOPE,
        )

    def _too_large(self, instances) -> bool:
        try:
            n = len(instances)
        except TypeError:
            n = len(list(instances))
        return n > int(getattr(self.model, "REFERENCE_SYNC_THRESHOLD", 200))

    def _scope_kwargs(self, instances) -> dict:
        ids = _safe(self.model.reference_scope_ids, instances) or []
        if self._ref_style() is TrashStyle.COURSE_SCOPE:
            return {"course_ids": ids}
        return {"filemedia_ids": ids}

    def _track(self, instances, *, removed: bool, intent: Intent) -> None:
        """Route one carrier op to the right reconcile primitive."""
        cfg = self._ref_config()
        if cfg is None or not instances:
            return

        # Scoped trash/restore (Course / FileMedia) — cheap bulk SQL, always
        # inline, reference_data preserved.
        if self._is_scope() and intent in (Intent.TRASH, Intent.RESTORE):
            kw = self._scope_kwargs(instances)
            if not any(kw.values()):
                return
            if intent is Intent.RESTORE:
                _safe(untrash_fmc, cfg, **kw)
            else:
                _safe(soft_trash_fmc, cfg, **kw)
            return

        # Contributions path (CONTENT for any intent; Course AUTHORING edits).
        if self._too_large(instances):
            _safe(self.model.reference_async_fallback, instances)
            logger.info(
                "reference_tracking: %s rows over threshold — deferred to "
                "backfill (model=%s)",
                len(instances) if hasattr(instances, "__len__") else "?",
                self.model.__name__,
            )
            return
        contribs = _safe(
            self.model.build_reference_contributions, instances, removed=removed
        )
        if contribs:
            _safe(apply_reference_updates, cfg, contribs, intent=intent)

    # -- overrides ------------------------------------------------------- #

    def bulk_create(self, objs, *args, **kwargs):
        objs = list(objs)
        created = super().bulk_create(objs, *args, **kwargs)
        if self._ref_config() is not None and created:
            self._track(created, removed=False, intent=Intent.AUTHORING)
        return created

    def bulk_update(self, objs, fields, *args, **kwargs):
        objs = list(objs)
        res = super().bulk_update(objs, fields, *args, **kwargs)
        if self._ref_config() is None or not objs:
            return res
        touched = set(fields or [])
        file_fields = set(getattr(self.model, "REFERENCE_FILE_FIELDS", ()))
        if touched & file_fields:
            self._track(objs, removed=False, intent=Intent.AUTHORING)
        elif touched & set(TRASH_FIELDS):
            trashing = [o for o in objs if getattr(o, "trashed_at", None)]
            restoring = [o for o in objs if not getattr(o, "trashed_at", None)]
            if trashing:
                self._track(trashing, removed=True, intent=Intent.TRASH)
            if restoring:
                self._track(restoring, removed=False, intent=Intent.RESTORE)
        return res

    def update(self, **kwargs):
        if self._ref_config() is None:
            return super().update(**kwargs)

        keys = set(kwargs)
        file_fields = set(getattr(self.model, "REFERENCE_FILE_FIELDS", ()))
        is_trash = "trashed_at" in keys
        is_file = bool(keys & file_fields)
        if not is_trash and not is_file:
            return super().update(**kwargs)

        snapshot = list(self.all())  # before the SQL UPDATE
        res = super().update(**kwargs)
        if not snapshot:
            return res

        if is_trash:
            if kwargs.get("trashed_at") is None:
                self._track(snapshot, removed=False, intent=Intent.RESTORE)
            else:
                self._track(snapshot, removed=True, intent=Intent.TRASH)
        else:  # file field changed via .update() — recompute from fresh rows
            refreshed = list(
                self.model._base_manager.filter(pk__in=[o.pk for o in snapshot])
            )
            self._track(
                refreshed or snapshot,
                removed=False,
                intent=Intent.AUTHORING,
            )
        return res

    def delete(self, *args, **kwargs):
        cfg = self._ref_config()
        # Build contributions BEFORE the rows vanish (relations must still be
        # resolvable). COURSE_SCOPE/FILE_SCOPE permanent delete already
        # FK-cascades FMC → nothing to do.
        contribs = None
        if cfg is not None and not self._is_scope():
            snapshot = list(self.all())
            if snapshot and not self._too_large(snapshot):
                contribs = _safe(
                    self.model.build_reference_contributions,
                    snapshot,
                    removed=True,
                )
            elif snapshot:
                _safe(self.model.reference_async_fallback, snapshot)
        res = super().delete(*args, **kwargs)
        if contribs:
            _safe(apply_reference_updates, cfg, contribs, intent=Intent.AUTHORING)
        return res
