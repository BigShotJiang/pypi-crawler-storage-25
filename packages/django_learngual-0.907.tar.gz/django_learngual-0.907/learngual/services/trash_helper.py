from __future__ import annotations

from typing import Literal, TypedDict

import requests

from .. import service_requests
from ..utils import get_base_url

TrashMimetype = Literal[
    "course",
    "image",
    "video",
    "audio",
    "lesson",
    "module",
    "lecture",
    "test",
]


class TrashItemEntry(TypedDict):
    id: str
    mimetype: TrashMimetype


class TrashHelper:
    @classmethod
    def trash_items(
        cls,
        owner_account_id: str,
        items: list[TrashItemEntry],
        affiliate_account_id: str | None = None,
    ) -> requests.Response:
        """Send a POST request to the IAM service ``trash-items`` endpoint.

        Args:
            owner_account_id: The account that owns the items being trashed.
            items: List of ``{"id": ..., "mimetype": ...}`` entries to trash.
            affiliate_account_id: Optional instructor account ID.  When supplied the
                request takes the affiliate path — the IAM service will verify
                membership and active contract before trashing.

        Returns:
            The :class:`requests.Response` from the IAM service (HTTP 201 on success).
        """
        sr = service_requests.ServiceRequest(get_base_url("iam"), service="iam")
        payload: dict = {
            "owner_account_id": owner_account_id,
            "items": items,
        }
        if affiliate_account_id is not None:
            payload["affiliate_account_id"] = affiliate_account_id
        return sr.post("trash-items", json=payload)
