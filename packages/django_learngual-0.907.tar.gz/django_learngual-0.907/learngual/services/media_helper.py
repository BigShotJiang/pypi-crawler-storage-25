"""Media helper utilities for extracting and removing embedded file objects
from arbitrarily nested data structures (e.g. Lesson/Lecture body JSON).

Strategy
--------
A *media object* is identified by the presence of all six signature fields
at the same nesting level::

    {"id", "url", "name", "size", "mimetype", "convertion_status"}

The helpers use :func:`flatten_dict` to collapse the nested structure into
dot-path keys, detect every prefix whose child keys satisfy the signature,
then operate on those prefixes before calling :func:`unflatten_dict` to
reconstruct the original shape.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable, Iterable
from typing import Any

logger = logging.getLogger("learngual.media_helper")

# Minimum set of keys that must all be present at the same nesting level for
# a dict to be considered a media/file object.
_MEDIA_SIGNATURE: frozenset[str] = frozenset(
    {"id", "url", "name", "size", "mimetype", "convertion_status"}
)

# Tri-state sentinel for the read-side resolver / mixin. A media id maps to:
#   * a dict          -> file is ACTIVE (fresh url/status to merge in)
#   * None             -> file is TRASHED (recoverable) -> placeholder + file_id
#   * PERMANENTLY_DELETED -> no FileMedia row at all     -> placeholder, NO file_id
# Convention (per product): id=="0" with a truthy file_id == trashed;
# id=="0" with falsy/absent file_id == permanently deleted. The resolver
# emits this sentinel for referenced ids that have no FileMedia row so the
# mixin renders the "permanently deleted" shape immediately — no window where
# a dangling/deleted file is still shown, regardless of any async cleanup.
PERMANENTLY_DELETED: str = "__learngual_permanently_deleted__"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _group_by_prefix(flat: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Group flat dot-path keys by their immediate parent prefix.

    Example::

        {"a.b.id": 1, "a.b.url": "x", "a.c": 2}
        → {"a.b": {"id": 1, "url": "x"}, "a": {"c": 2}}

    Args:
        flat: A flattened dict produced by :func:`flatten_dict`.

    Returns:
        Mapping of parent-prefix → {leaf_key: value}.
    """
    groups: dict[str, dict[str, Any]] = defaultdict(dict)
    for key, value in flat.items():
        if "." in key:
            prefix, leaf = key.rsplit(".", 1)
        else:
            prefix, leaf = "__root__", key
        groups[prefix][leaf] = value
    return dict(groups)


def _find_media_prefixes(flat: dict[str, Any]) -> dict[str, str]:
    """Return a mapping of dot-path prefix → media object ``id`` for every
    media object detected in *flat*.

    Args:
        flat: A flattened dict produced by :func:`flatten_dict`.

    Returns:
        ``{prefix: media_id}`` for all detected media objects.
    """
    groups = _group_by_prefix(flat)
    result: dict[str, str] = {}
    for prefix, leaves in groups.items():
        if _MEDIA_SIGNATURE.issubset(leaves.keys()):
            media_id = leaves.get("id")
            if media_id:
                result[prefix] = str(media_id)
    return result


def _collect_media_from_any(
    data: Any,
    exclude: frozenset[str] = frozenset({"0"}),
    *,
    include_file_id: bool = False,
) -> list[str]:
    """Recursively walk *data* (dict, list, or scalar) and return every media
    object ID encountered, including objects nested inside lists.

    Unlike :func:`extract_media_ids`, this helper does **not** deduplicate;
    deduplication is handled by the caller.

    Args:
        data: Any value — dict, list, or scalar.
        exclude: Set of ``id`` strings to skip entirely.  Defaults to
            ``{"0"}`` which filters out placeholder/unset IDs.
        include_file_id: When True, also yield the ``file_id`` of every
            signature-matched media object whose own ``id`` is in *exclude*
            (typically ``"0"`` — the placeholder).  This recovers the
            persistent FileMedia reference from a stale masked row (the
            "round-trip beacon" pattern).  Default False preserves the
            old behaviour for callers that only care about active refs.

    Returns:
        List of media ``id`` (and optionally ``file_id``) strings in
        first-encountered order, potentially containing duplicates.
    """
    ids: list[str] = []
    if isinstance(data, dict):
        if _MEDIA_SIGNATURE.issubset(data.keys()):
            media_id = data.get("id")
            media_id_str = "" if media_id is None else str(media_id)
            if media_id_str and media_id_str not in exclude:
                ids.append(media_id_str)
            elif include_file_id:
                # The own ``id`` is a placeholder; check for a persistent
                # ``file_id`` beacon pointing at the underlying FileMedia.
                fid = data.get("file_id")
                fid_str = "" if fid is None else str(fid)
                if fid_str and fid_str not in exclude:
                    ids.append(fid_str)
            # Do not recurse into the media object's own sub-keys.
        else:
            for value in data.values():
                ids.extend(
                    _collect_media_from_any(
                        value, exclude, include_file_id=include_file_id
                    )
                )
    elif isinstance(data, list):
        for item in data:
            ids.extend(
                _collect_media_from_any(item, exclude, include_file_id=include_file_id)
            )
    return ids


def _remove_from_any(
    data: Any,
    target_ids: frozenset[str],
    replacement: Any,
) -> Any:
    """Recursively rebuild *data*, replacing or removing every media object
    whose ``id`` is in *target_ids*.

    Works for media objects nested at any depth, including objects that are
    direct elements inside a list.

    Args:
        data: Any value — dict, list, or scalar.
        target_ids: Frozen set of media ``id`` strings to remove.
        replacement: The value to substitute when a media object matches.
            Pass ``...`` (Ellipsis) to signal the caller to omit the item
            entirely (key dropped from dicts, element removed from lists).

    Returns:
        Rebuilt value.  Returns ``...`` when the item should be omitted from
        its parent container.
    """
    if isinstance(data, dict):
        if _MEDIA_SIGNATURE.issubset(data.keys()):
            # This node is a media object — check if it should be removed.
            media_id = str(data.get("id", ""))
            if media_id in target_ids:
                return replacement
            return data  # Not targeted — keep intact.
        # Regular dict — recurse into each value.
        result: dict[str, Any] = {}
        for key, value in data.items():
            new_value = _remove_from_any(value, target_ids, replacement)
            if new_value is not ...:
                result[key] = new_value
        return result
    elif isinstance(data, list):
        result_list: list[Any] = []
        for item in data:
            new_item = _remove_from_any(item, target_ids, replacement)
            if new_item is not ...:
                result_list.append(new_item)
        return result_list
    return data  # Scalar — pass through unchanged.


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_media_ids(
    data: dict[str, Any],
    exclude: set[str] | frozenset[str] = frozenset({"0"}),
    *,
    include_file_id: bool = False,
) -> list[str]:
    """Extract all media object IDs embedded anywhere in *data*.

    Recursively walks the nested structure — including through list elements —
    and identifies every sub-dict that satisfies the media signature.

    Args:
        data: Arbitrary nested dict (e.g. a Lesson/Lecture ``body`` JSON
            field).  Media objects may appear as dict values at any depth
            **or** as direct elements inside a list.
        exclude: Set of ``id`` strings to ignore.  Defaults to ``{"0"}``
            which filters out placeholder/unset IDs.  Pass an empty set to
            include all IDs.
        include_file_id: When True, also yield the ``file_id`` of every
            signature-matched media object whose own ``id`` is filtered
            out by *exclude* (typically ``"0"`` — the placeholder).  Used
            by the read-side resolver so a stale masked row
            (``id="0", file_id="abc"``) still surfaces ``"abc"`` for state
            resolution, enabling auto-recovery if the underlying file is
            no longer trashed.  Default ``False`` preserves the original
            behaviour for callers (e.g. trash cleanup) that only care
            about ``id``.

    Returns:
        Deduplicated list of media ``id`` (and optionally ``file_id``)
        strings found in *data*, in first-encountered order.

    Example::

        body = {
            "blocks": [
                {"type": "audio", "file": {"id": "abc", "url": "...",
                                            "name": "track.wav", "size": 84906.0,
                                            "mimetype": "audio/x-wav",
                                            "convertion_status": "DEFAULT"}},
            ],
            "attachments": [
                {"id": "xyz", "url": "...", "name": "sheet.pdf", "size": 10_000.0,
                 "mimetype": "application/pdf", "convertion_status": "DEFAULT"},
            ],
        }
        extract_media_ids(body)  # → ["abc", "xyz"]

        # Stale masked row → file_id is recovered when include_file_id=True.
        masked = {"thumb": {"id": "0", "file_id": "abc",
                            "url": "default", "name": None, "size": 0,
                            "mimetype": "image/png", "convertion_status": None}}
        extract_media_ids(masked, include_file_id=True)  # → ["abc"]
        extract_media_ids(masked)                        # → []
    """
    if not data:
        return []

    _exclude = frozenset(str(i) for i in exclude)
    seen: set[str] = set()
    ids: list[str] = []
    for media_id in _collect_media_from_any(
        data, _exclude, include_file_id=include_file_id
    ):
        if media_id not in seen:
            seen.add(media_id)
            ids.append(media_id)
    return ids


def remove_media_by_ids(
    data: dict[str, Any],
    ids: list[str] | set[str],
    *,
    replacement: Any = None,
) -> dict[str, Any]:
    """Remove (or replace) media objects whose ``id`` is in *ids*.

    Recursively walks *data* — including through list elements at any depth —
    and replaces every matching media object with *replacement* (default
    ``None``).  Use ``replacement=...`` (Ellipsis) to omit the key/element
    entirely instead of substituting a value.

    Args:
        data: Arbitrary nested dict to process.  Media objects may be nested
            inside dicts **or** appear as direct elements inside lists.
        ids: Collection of media ``id`` strings to remove.
        replacement: Value to substitute for each matched media object.
            Defaults to ``None``; pass ``...`` (Ellipsis) to remove the key
            from its parent dict or the element from its parent list entirely.

    Returns:
        New dict with matching media objects replaced/removed.

    Example::

        data = {"lesson": {"audio": {"id": "abc", "url": "...", ...}}}
        result = remove_media_by_ids(data, ["abc"])
        # → {"lesson": {"audio": None}}

        result = remove_media_by_ids(data, ["abc"], replacement=...)
        # → {"lesson": {}}

        data = {"files": [{"id": "abc", ...}, {"id": "xyz", ...}]}
        result = remove_media_by_ids(data, ["abc"], replacement=...)
        # → {"files": [{"id": "xyz", ...}]}
    """
    if not data or not ids:
        return data

    # Normalise pydantic-model input to a plain nested dict before walking.
    # Carrier fields like ``Lecture.body`` are PydanticModelField, so
    # ``instance.body`` yields a model instance (e.g. LectureBodySchema),
    # not a dict.  Without this, ``_remove_from_any`` (dict/list/scalar
    # only) returns the model untouched and the ``not isinstance(rebuilt,
    # dict)`` guard below would discard the ENTIRE body as ``{}`` —
    # corrupting the stored JSON.  ``model_dump`` recursively plain-ifies
    # the whole tree; by_alias/json mode match how the field persists.
    if not isinstance(data, (dict, list)) and hasattr(data, "model_dump"):
        try:
            data = data.model_dump(mode="json", by_alias=True)
        except Exception as exc:  # noqa: BLE001 - never corrupt on dump failure
            logger.warning(
                "remove_media_by_ids: model_dump failed (%s); "
                "leaving data untouched to avoid corruption",
                exc.__class__.__name__,
            )
            return data

    _target_ids = frozenset(str(i) for i in ids)
    rebuilt = _remove_from_any(data, _target_ids, replacement)
    # Guard: if the root dict itself was a targeted media object it may have
    # been replaced by a non-dict sentinel — return {} to honour the return type.
    if not isinstance(rebuilt, dict):
        return {}
    return rebuilt


def diff_media_ids(
    old_data: dict[str, Any],
    new_data: dict[str, Any],
    exclude: set[str] | frozenset[str] = frozenset({"0"}),
) -> tuple[list[str], list[str]]:
    """Compare media objects between *old_data* and *new_data*.

    Args:
        old_data: The previous version of the nested dict.
        new_data: The updated version of the nested dict.
        exclude: Set of ``id`` strings to ignore on both sides.  Defaults to
            ``{"0"}`` which filters out placeholder/unset IDs.  Pass an empty
            set to include all IDs.

    Returns:
        A tuple of ``(added_ids, removed_ids)`` where:

        - **added_ids**: IDs present in *new_data* but not in *old_data*.
        - **removed_ids**: IDs present in *old_data* but not in *new_data*.

    Example::

        old = {"file": {"id": "abc", "url": "...", "name": "a.wav",
                        "size": 1, "mimetype": "audio/wav", "convertion_status": "DEFAULT"}}
        new = {"file": {"id": "xyz", "url": "...", "name": "b.wav",
                        "size": 2, "mimetype": "audio/wav", "convertion_status": "DEFAULT"}}
        diff_media_ids(old, new)  # → (["xyz"], ["abc"])
    """
    old_ids_in_order = extract_media_ids(old_data, exclude)
    new_ids_in_order = extract_media_ids(new_data, exclude)

    old_ids = set(old_ids_in_order)
    new_ids = set(new_ids_in_order)

    # Keep deterministic output by preserving first-seen order from each side.
    added = [i for i in new_ids_in_order if i not in old_ids]
    removed = [i for i in old_ids_in_order if i not in new_ids]

    return added, removed


# ---------------------------------------------------------------------------
# Internal: per-id replacement walker
# ---------------------------------------------------------------------------


def _replace_from_any(
    data: Any,
    rule: Callable[[dict[str, Any]], dict[str, Any] | None],
) -> Any:
    """Recursively rebuild *data*, applying *rule* to every signature-matched
    media object.

    *rule* receives the original media-object dict and returns the replacement
    dict (or ``None`` to leave the object unchanged). Non-media dicts are
    recursed into; lists are walked element-by-element; scalars pass through.

    Returns a rebuilt value — the input is never mutated.
    """
    if isinstance(data, dict):
        if _MEDIA_SIGNATURE.issubset(data.keys()):
            replacement = rule(data)
            return data if replacement is None else replacement
        return {k: _replace_from_any(v, rule) for k, v in data.items()}
    if isinstance(data, list):
        return [_replace_from_any(item, rule) for item in data]
    return data


# ---------------------------------------------------------------------------
# Public: per-id replacement (read-side mixin uses this)
# ---------------------------------------------------------------------------


def replace_media_objects(
    data: Any,
    *,
    state: dict[str, dict[str, Any] | None],
    default_schema: dict[str, Any],
) -> Any:
    """Walk *data* recursively, rewriting every media object by id according
    to *state*.

    For each signature-matched dict (tri-state, per the id/file_id convention):

    * If its lookup key is not in *state* → leave it untouched.
    * If ``state[key]`` is ``None`` → **trashed**: swap for
      ``{**default_schema, "file_id": key}`` (id:"0" + ``file_id`` beacon, so
      a later restore auto-recovers and a PATCH round-trip keeps the ref).
    * If ``state[key]`` is ``PERMANENTLY_DELETED`` → **permanently deleted**:
      swap for ``{**default_schema}`` with **no** ``file_id`` (id:"0", no
      beacon — nothing to recover).
    * Otherwise (a dict) → **active**: merge
      ``{**obj, **state[key], "id": key, "file_id": key}`` so the fresh
      url/status override the stored JSON and a stale masked row recovers.

    Non-media dicts and lists are recursed into; the input is never mutated.

    Args:
        data: Arbitrary nested dict / list / scalar (typically the serialised
            response of a DRF serializer).
        state: Map of media-id → fresh-state-dict-or-None. None signals "the
            FileMedia is trashed; swap for the placeholder".
        default_schema: The id:"0" placeholder dict for the current service
            (e.g. ``DEFAULT_FILE_SCHEMA``). Carried verbatim into trash swaps
            (with ``file_id`` appended).

    Returns:
        Rebuilt value with media objects replaced according to *state*.
    """
    if not data or not state:
        return data

    def _rule(obj: dict[str, Any]) -> dict[str, Any] | None:
        try:
            pid = str(obj.get("id") or "")
            fid_beacon = str(obj.get("file_id") or "")
        except Exception as exc:  # defensive: id is something exotic
            logger.warning(
                "replace_media_objects: malformed id (%s); leaving object untouched",
                exc.__class__.__name__,
            )
            return None

        # Choose the lookup key: real id wins; file_id beacon is the
        # fallback when the stored object is in the placeholder state.
        # This lets a stale masked row ({id:"0", file_id:"abc"}) still
        # resolve against the underlying FileMedia and auto-recover on
        # the next GET if the file was restored.
        if pid and pid != "0":
            key = pid
        elif fid_beacon and fid_beacon != "0":
            key = fid_beacon
        else:
            return None

        if key not in state:
            return None
        fresh = state[key]
        if fresh is None:
            # Trashed (recoverable) → placeholder + file_id beacon.
            return {**default_schema, "file_id": key}
        if fresh == PERMANENTLY_DELETED:
            # No FileMedia row → permanently deleted. Clean placeholder with
            # NO file_id (drops any stale beacon) so it reads as "deleted",
            # not "trashed", per the id/file_id convention.
            return {k: v for k, v in default_schema.items() if k != "file_id"}
        # Active → restore the canonical reference. Set ``id``/``file_id``
        # from the matched key so a stale masked row recovers to real form.
        return {**obj, **fresh, "id": key, "file_id": key}

    return _replace_from_any(data, _rule)


# ---------------------------------------------------------------------------
# Public: write-side payload normalisation (PATCH round-trip safety)
# ---------------------------------------------------------------------------


def normalize_media_object(
    payload: Any,
    *,
    existing_file_ids: Iterable[str] | None = None,
) -> Any:
    """Translate a SINGLE client-supplied media object back to its canonical
    stored shape, applying the ``file_id`` round-trip rule.

    Rules (in order):

    1. ``id`` non-"0" → trust ``id``; drop ``file_id`` (informational only).
    2. ``id == "0"`` and ``file_id`` present and non-"0" and the underlying
       FileMedia still exists (its id appears in *existing_file_ids*) →
       restore the reference: set ``id = file_id``, drop ``file_id``.
       The trash state (if any) is re-applied by the read-side mixin on the
       next GET.
    3. ``id == "0"`` and ``file_id`` present but the FileMedia no longer
       exists (permanently deleted) → drop ``file_id`` and save the payload
       verbatim. Preserving a dangling reference would corrupt the row.
    4. ``id == "0"`` and ``file_id`` missing (or ``"0"``) → save verbatim.
       This is the explicit-clear path; old clients that don't know about
       ``file_id`` naturally land here.

    The presence/absence of ``file_id`` is the client signal: keep it to
    preserve the reference, omit it to overwrite/clear.

    Args:
        payload: A single media-object dict (or Pydantic instance with
            ``model_dump``). Non-dicts and falsy values are returned
            unchanged.
        existing_file_ids: Iterable of file ids confirmed present in the
            FileMedia table (any state: trashed or active). Computed once
            per request by :func:`normalize_media_payloads`. If ``None``,
            the existence check is skipped (rule 2 fires whenever
            ``file_id`` is non-"0", treating all file_ids as still existing).
            ``None`` is only safe in tests; production writes should always
            pass a real set.

    Returns:
        The normalised dict. ``file_id`` is never present in the output.
    """
    if not payload:
        return payload
    if not isinstance(payload, dict):
        try:
            if hasattr(payload, "model_dump"):
                payload = payload.model_dump()
            else:
                return payload
        except Exception as exc:
            logger.warning(
                "normalize_media_object: model_dump failed (%s); leaving payload untouched",
                exc.__class__.__name__,
            )
            return payload

    try:
        pid = str(payload.get("id") or "")
        fid = str(payload.get("file_id") or "")
    except Exception as exc:
        logger.warning(
            "normalize_media_object: malformed id/file_id (%s); leaving payload untouched",
            exc.__class__.__name__,
        )
        return payload

    if pid and pid != "0":
        # Rule 1: trust id, drop file_id.
        return {k: v for k, v in payload.items() if k != "file_id"}

    if fid and fid != "0":
        # Rule 2 or 3: round-trip preservation vs dangling reference.
        if existing_file_ids is None or fid in existing_file_ids:
            out = {**payload, "id": fid}
            out.pop("file_id", None)
            return out
        # Rule 3: file permanently deleted → drop file_id, save verbatim.
        return {k: v for k, v in payload.items() if k != "file_id"}

    # Rule 4: explicit clear / overwrite.
    return {k: v for k, v in payload.items() if k != "file_id"}


def normalize_media_payloads(
    data: Any,
    *,
    file_media_qs: Callable[[Iterable[str]], Any] | None = None,
) -> Any:
    """Recursively walk *data*, applying :func:`normalize_media_object` to
    every signature-matched media object. Used by write serializers via
    ``NormalizeMediaWriteMixin``.

    Two-pass implementation, one DB query per request:

    1. Walk via :func:`extract_media_ids` to collect every ``file_id``
       referenced in a masked round-trip candidate.
    2. ONE batch query: ``file_media_qs(ids)`` → ``existing_file_ids``.
    3. Walk again, applying ``normalize_media_object(node,
       existing_file_ids=...)`` to every node.

    Args:
        data: Arbitrary nested dict / list / scalar (typically the client's
            PATCH body).
        file_media_qs: Callable that, given an iterable of file ids, returns
            a queryset (or iterable) of objects with a ``pk`` attribute for
            every id that still exists in the FileMedia table. When ``None``
            the existence check is skipped — only safe in tests.

    Returns:
        Rebuilt value with every media object normalised. The input is
        never mutated.
    """
    if not data:
        return data

    # Pass 1: collect candidate file_ids (only those that would be used in
    # the round-trip-preservation branch — i.e. id == "0" and file_id set).
    candidate_ids: set[str] = set()

    def _collect(obj: dict[str, Any]) -> dict[str, Any] | None:
        try:
            pid = str(obj.get("id") or "")
            fid = str(obj.get("file_id") or "")
        except Exception:
            return None
        if (not pid or pid == "0") and fid and fid != "0":
            candidate_ids.add(fid)
        return None  # don't replace yet; we're just scanning

    _replace_from_any(data, _collect)

    # Pass 2: single batch existence check, if we have anything to check.
    existing_file_ids: frozenset[str] | None
    if candidate_ids and file_media_qs is not None:
        existing_qs = file_media_qs(candidate_ids)
        existing_file_ids = frozenset(
            str(getattr(obj, "pk", None) or getattr(obj, "id", None))
            for obj in existing_qs
            if (getattr(obj, "pk", None) or getattr(obj, "id", None))
        )
    elif candidate_ids and file_media_qs is None:
        # Misconfiguration: dangling-reference protection is off. Log once
        # per call, then proceed optimistically (preserve all candidates).
        logger.warning(
            "normalize_media_payloads: file_media_qs is None; "
            "skipping existence check (preserving %d file_id reference(s) "
            "without verification)",
            len(candidate_ids),
        )
        existing_file_ids = None
    else:
        existing_file_ids = frozenset()

    # Pass 3: apply normalisation with the existence info.
    def _rule(obj: dict[str, Any]) -> dict[str, Any] | None:
        normalised = normalize_media_object(obj, existing_file_ids=existing_file_ids)
        # _replace_from_any expects None to mean "no change"; we return the
        # normalised dict unconditionally because normalize_media_object may
        # have stripped file_id even when nothing else changed.
        return normalised if normalised is not obj else None

    return _replace_from_any(data, _rule)
