"""Regression tests for ``build_file_state`` — the reusable file-state core.

``build_file_state`` was extracted from ``fetch_nested_file_state`` so the
self-sufficient ``NestedFileStateMixin`` and the global
``NestedFileStateJSONRenderer`` resolve gating identically to the batched
view path. These tests pin the EXACT tri-state contract so any behaviour
drift ("it worked before") breaks here:

* active FileMedia (``trashed_at is None``)  -> fresh-fields dict
* trashed FileMedia (``trashed_at`` set)     -> ``None`` (recoverable;
  mixin/renderer swap to placeholder + ``file_id`` beacon)
* no FileMedia row for a referenced id       -> ``PERMANENTLY_DELETED``
  (placeholder, NO beacon — gone forever)
* ``"0"`` / falsy ids filtered (never queried, never in the map)
* account/enterprise reduced to primitives once and forwarded to presign
* ``fetch_nested_file_state`` delegates to ``build_file_state`` (the
  refactor must stay behaviour-preserving)
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any

from iam_service.learngual.services.media_helper import PERMANENTLY_DELETED
from iam_service.learngual.services.nested_file_state import (
    NestedFileStateConfig,
    build_file_state,
    fetch_nested_file_state,
)

DEFAULT_FILE_SCHEMA = {
    "id": "0",
    "url": "https://cdn.example.com/default.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


def _row(pk: str, *, trashed: bool = False) -> Any:
    return SimpleNamespace(
        pk=pk,
        id=pk,
        trashed_at="2026-01-01T00:00:00Z" if trashed else None,
        upload=SimpleNamespace(name=f"uploads/{pk}.jpg"),
        thumbnail=None,
        mimetype="image/jpeg",
        convertion_status="DONE",
        duration=None,
        size=2048,
    )


def _config(rows: list[Any]) -> NestedFileStateConfig:
    # NestedFileStateConfig is frozen → capture query calls on the
    # fake_qs function object (mutable), read via cfg.file_media_qs.calls.
    calls: list[set] = []

    def fake_qs(ids):
        calls.append({str(i) for i in ids})
        idset = {str(i) for i in ids}
        return [r for r in rows if str(r.pk) in idset]

    fake_qs.calls = calls  # type: ignore[attr-defined]
    return NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=lambda m, *, account_type=None, enterprise_id=None: (
            f"signed://{m.pk}?at={account_type}&eid={enterprise_id}"
        ),
        presign_thumb=lambda m: None,
    )


# --------------------------------------------------------------------------- #
# Tri-state contract
# --------------------------------------------------------------------------- #


def test_active_file_yields_fresh_fields_dict():
    cfg = _config([_row("aaa")])
    state = build_file_state(["aaa"], config=cfg)
    assert set(state) == {"aaa"}
    fresh = state["aaa"]
    assert isinstance(fresh, dict)
    assert fresh["url"] == "signed://aaa?at=None&eid=None"
    assert fresh["mimetype"] == "image/jpeg"
    assert fresh["convertion_status"] == "DONE"
    assert fresh["size"] == 2048
    assert "thumbnail_url" in fresh and "duration" in fresh


def test_trashed_file_yields_none_recoverable():
    cfg = _config([_row("trsh", trashed=True)])
    state = build_file_state(["trsh"], config=cfg)
    assert state == {"trsh": None}


def test_missing_file_row_yields_permanently_deleted():
    # id referenced but FileMedia row absent (hard-deleted) -> sentinel.
    cfg = _config([])  # query returns nothing
    state = build_file_state(["gone"], config=cfg)
    assert state == {"gone": PERMANENTLY_DELETED}


def test_mixed_active_trashed_missing_in_one_call():
    cfg = _config([_row("act"), _row("tr", trashed=True)])
    state = build_file_state(["act", "tr", "missing"], config=cfg)
    assert isinstance(state["act"], dict)
    assert state["tr"] is None
    assert state["missing"] is PERMANENTLY_DELETED


# --------------------------------------------------------------------------- #
# Id filtering / no-op
# --------------------------------------------------------------------------- #


def test_zero_and_falsy_ids_filtered_never_queried():
    cfg = _config([_row("real")])
    state = build_file_state(["0", "", None, "real"], config=cfg)
    assert state.keys() == {"real"}
    # "0"/""/None must not reach the query.
    assert cfg.file_media_qs.calls == [{"real"}]  # type: ignore[attr-defined]


def test_empty_ids_returns_empty_no_query():
    cfg = _config([_row("x")])
    assert build_file_state([], config=cfg) == {}
    assert build_file_state(["0", None, ""], config=cfg) == {}
    assert cfg.file_media_qs.calls == []  # type: ignore[attr-defined]


def test_ids_deduplicated_single_query():
    cfg = _config([_row("d")])
    build_file_state(["d", "d", "d"], config=cfg)
    assert cfg.file_media_qs.calls == [{"d"}]  # type: ignore[attr-defined]


# --------------------------------------------------------------------------- #
# account / enterprise -> primitives forwarded to presign
# --------------------------------------------------------------------------- #


def test_account_enterprise_reduced_to_primitives():
    cfg = _config([_row("p")])
    account = SimpleNamespace(type="ENTERPRISE")
    enterprise = SimpleNamespace(id="ent-9")
    state = build_file_state(["p"], config=cfg, account=account, enterprise=enterprise)
    assert state["p"]["url"] == "signed://p?at=ENTERPRISE&eid=ent-9"


# --------------------------------------------------------------------------- #
# Refactor invariant: fetch_nested_file_state delegates to build_file_state
# --------------------------------------------------------------------------- #


def test_fetch_delegates_to_build_file_state_same_result():
    rows = [_row("img"), _row("vid", trashed=True)]
    cfg = _config(rows)
    # The carrier-row walk finds the same two ids -> identical state map.
    carrier = [{"thumbnail": _media_obj("img"), "preview_video": _media_obj("vid")}]
    via_fetch = fetch_nested_file_state(
        carrier, ("thumbnail", "preview_video"), config=cfg
    )
    via_build = build_file_state(["img", "vid"], config=_config(rows))
    assert via_fetch == via_build
    assert via_fetch["img"] and via_fetch["vid"] is None


def _media_obj(id_: str) -> dict[str, Any]:
    return {
        "id": id_,
        "url": f"https://s/{id_}.jpg",
        "name": f"{id_}.jpg",
        "size": 1,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
    }
