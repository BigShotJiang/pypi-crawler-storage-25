"""Tests for TrashHelper.trash_items.

The outgoing HTTP request is intercepted at the Session level and routed
through the Django APIClient, so the full view logic, permission checks, and
database writes all execute for real.  No business logic is mocked.
"""
from __future__ import annotations

import datetime
from unittest.mock import MagicMock, patch
from urllib.parse import urlparse

import pytest
from rest_framework.test import APIClient

from iam_service.accounts.v1.tests.factories import AccountFactory
from iam_service.learngual import service_requests as _sr
from iam_service.learngual.services.trash_helper import TrashHelper
from iam_service.services.models.elearning.users import (
    CourseContract,
    InstructorTeam,
    Team,
)
from iam_service.trash.models import Trash
from iam_service.trash.tests.fixtures import (
    CourseFactory,
    FileMediaFactory,
    LanguageFactory,
    TrashFactory,
)
from iam_service.users.models import User
from iam_service.utilities.choices import TrashMimeType

pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixture: route outgoing service requests through Django
# ---------------------------------------------------------------------------


@pytest.fixture()
def service_client():
    """Django APIClient authenticated as a service user."""
    _service_user = User(id="service", username="service")
    _service_user.is_service = True
    client = APIClient()
    client.force_authenticate(_service_user)
    return client


@pytest.fixture(autouse=True)
def route_to_django(service_client):
    """Patch the requests Session so every outgoing POST is handled by Django.

    The URL is parsed to extract the path; the Django test client processes the
    request through the real view stack and real database, then the response is
    wrapped in a minimal requests.Response-compatible object so callers of
    TrashHelper work unchanged.
    """

    def _fake_post(url, data=None, json=None, **kwargs):
        path = urlparse(url).path
        django_response = service_client.post(path, data=json or data, format="json")
        mock_resp = MagicMock()
        mock_resp.status_code = django_response.status_code
        mock_resp.ok = 200 <= django_response.status_code < 300
        mock_resp.json.return_value = (
            django_response.data if hasattr(django_response, "data") else {}
        )
        return mock_resp

    with patch.object(_sr.requests, "post", side_effect=_fake_post):
        yield


# ---------------------------------------------------------------------------
# Data helpers (mirrors test_drf_endpoints.py)
# ---------------------------------------------------------------------------


def _make_enterprise():
    account = AccountFactory.ActiveEnterprise()
    account.owner.is_active = True
    account.owner.save()
    return account


def _make_instructor():
    account = AccountFactory.ActiveInstructor()
    account.owner.is_active = True
    account.owner.save()
    return account


def _make_affiliate_setup():
    enterprise = _make_enterprise()
    instructor = _make_instructor()
    team = Team.objects.create(account=enterprise, owner=enterprise.owner)
    InstructorTeam.objects.create(account=instructor, team=team)
    CourseContract.objects.create(
        account=instructor,
        team=team,
        owner=instructor.owner,
        status=CourseContract.ACTIVE,
        start_date=datetime.date.today(),
        end_date=datetime.date.today() + datetime.timedelta(days=365),
    )
    return enterprise, instructor, team


def _course_for(account):
    lang = LanguageFactory.Base()
    return CourseFactory.Base(account=account, owner=account.owner, language=lang)


# ---------------------------------------------------------------------------
# Owner path
# ---------------------------------------------------------------------------


class TestTrashHelperOwnerPath:
    def test_returns_201_on_success(self):
        account = _make_enterprise()
        course = _course_for(account)
        resp = TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert resp.status_code == 201
        assert resp.ok is True

    def test_course_created_in_database(self):
        account = _make_enterprise()
        course = _course_for(account)
        TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert Trash.objects.filter(
            account=account,
            instance_id=str(course.pk),
            mimetype=TrashMimeType.COURSE,
        ).exists()

    def test_trash_row_trashed_by_is_null_on_owner_path(self):
        """trashed_by is NULL on owner path — no affiliate override."""
        account = _make_enterprise()
        course = _course_for(account)
        TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        trash = Trash.objects.get(
            account=account,
            instance_id=str(course.pk),
            mimetype=TrashMimeType.COURSE,
        )
        assert trash.trashed_by is None

    def test_multiple_items_all_written_to_database(self):
        account = _make_enterprise()
        course1 = _course_for(account)
        course2 = _course_for(account)
        TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[
                {"id": str(course1.pk), "mimetype": TrashMimeType.COURSE},
                {"id": str(course2.pk), "mimetype": TrashMimeType.COURSE},
            ],
        )
        assert (
            Trash.objects.filter(account=account, mimetype=TrashMimeType.COURSE).count()
            == 2
        )

    def test_multiple_mimetypes_all_written_to_database(self):
        """Three FileMedia items trashed as IMAGE/AUDIO/VIDEO — sequential PKs, no instance_id collision."""
        account = _make_enterprise()
        image = FileMediaFactory.Base(account=account, owner=account.owner)
        audio = FileMediaFactory.Base(account=account, owner=account.owner)
        video = FileMediaFactory.Base(account=account, owner=account.owner)

        TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[
                {"id": str(image.pk), "mimetype": TrashMimeType.IMAGE},
                {"id": str(audio.pk), "mimetype": TrashMimeType.AUDIO},
                {"id": str(video.pk), "mimetype": TrashMimeType.VIDEO},
            ],
        )
        assert Trash.objects.filter(account=account).count() == 3

    def test_unknown_owner_returns_404(self):
        resp = TrashHelper.trash_items(
            owner_account_id="nonexistent-id",
            items=[{"id": "1", "mimetype": TrashMimeType.COURSE}],
        )
        assert resp.status_code == 404
        assert resp.ok is False
        assert "Account not found" in resp.json()["errors"][0]["detail"]

    def test_item_not_owned_by_account_returns_403(self):
        owner = _make_enterprise()
        other = _make_enterprise()
        course = _course_for(other)
        resp = TrashHelper.trash_items(
            owner_account_id=owner.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert resp.status_code == 403
        assert resp.ok is False
        assert not Trash.objects.filter(
            instance_id=str(course.pk), mimetype=TrashMimeType.COURSE
        ).exists()
        detail = resp.json()["errors"][0]["detail"]
        assert "do not belong" in detail
        assert TrashMimeType.COURSE in detail

    def test_inactive_owner_returns_403(self):
        account = _make_enterprise()
        account.owner.is_active = False
        account.owner.save()
        course = _course_for(account)
        resp = TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert resp.status_code == 403
        assert "permission to manage trash" in resp.json()["errors"][0]["detail"]

    def test_already_trashed_item_is_idempotent(self):
        account = _make_enterprise()
        course = _course_for(account)
        TrashFactory.Base(
            account=account,
            trashed_by=account,
            name=course.name,
            instance_id=str(course.pk),
            model_name="services.Course",
            mimetype=TrashMimeType.COURSE,
        )
        resp = TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert resp.status_code == 201
        # Verify idempotency: only 1 Trash row exists (no duplicate created)
        assert (
            Trash.objects.filter(
                account=account,
                instance_id=str(course.pk),
                mimetype=TrashMimeType.COURSE,
            ).count()
            == 1
        )

    def test_no_duplicate_rows_written_on_error(self):
        account = _make_enterprise()
        other = _make_enterprise()
        course = _course_for(other)  # wrong owner

        TrashHelper.trash_items(
            owner_account_id=account.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
        )
        assert Trash.objects.filter(account=account).count() == 0


# ---------------------------------------------------------------------------
# Affiliate path
# ---------------------------------------------------------------------------


class TestTrashHelperAffiliatePath:
    def test_returns_201_on_success(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 201
        assert resp.ok is True

    def test_trash_row_owned_by_enterprise(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        course = _course_for(enterprise)
        TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert Trash.objects.filter(
            account=enterprise,
            instance_id=str(course.pk),
            mimetype=TrashMimeType.COURSE,
        ).exists()

    def test_trash_row_trashed_by_is_instructor(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        course = _course_for(enterprise)
        TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        trash = Trash.objects.get(
            account=enterprise,
            instance_id=str(course.pk),
            mimetype=TrashMimeType.COURSE,
        )
        assert trash.trashed_by_id == instructor.id

    def test_non_enterprise_owner_returns_403(self):
        instructor_owner = _make_instructor()
        affiliate = _make_instructor()
        course = _course_for(instructor_owner)
        resp = TrashHelper.trash_items(
            owner_account_id=instructor_owner.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=affiliate.id,
        )
        assert resp.status_code == 403
        assert "must be an enterprise" in resp.json()["errors"][0]["detail"]

    def test_unknown_affiliate_returns_404(self):
        enterprise = _make_enterprise()
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id="nonexistent-instructor",
        )
        assert resp.status_code == 404
        assert "Affiliate account not found" in resp.json()["errors"][0]["detail"]

    def test_instructor_not_in_team_returns_403(self):
        enterprise = _make_enterprise()
        instructor = _make_instructor()  # no team membership
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 403
        assert (
            "not an instructor in this enterprise" in resp.json()["errors"][0]["detail"]
        )

    def test_pending_contract_returns_403(self):
        enterprise = _make_enterprise()
        instructor = _make_instructor()
        team = Team.objects.create(account=enterprise, owner=enterprise.owner)
        InstructorTeam.objects.create(account=instructor, team=team)
        CourseContract.objects.create(
            account=instructor,
            team=team,
            owner=instructor.owner,
            status=CourseContract.PENDING,
            start_date=datetime.date.today(),
            end_date=datetime.date.today() + datetime.timedelta(days=365),
        )
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 403
        assert "does not have an active contract" in resp.json()["errors"][0]["detail"]

    def test_terminated_contract_returns_403(self):
        enterprise = _make_enterprise()
        instructor = _make_instructor()
        team = Team.objects.create(account=enterprise, owner=enterprise.owner)
        InstructorTeam.objects.create(account=instructor, team=team)
        CourseContract.objects.create(
            account=instructor,
            team=team,
            owner=instructor.owner,
            status=CourseContract.TERMINATE,
            start_date=datetime.date.today(),
            end_date=datetime.date.today() + datetime.timedelta(days=365),
        )
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 403
        assert "does not have an active contract" in resp.json()["errors"][0]["detail"]

    def test_item_owned_by_different_enterprise_returns_403(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        other = _make_enterprise()
        course = _course_for(other)  # belongs to different enterprise
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 403
        assert "do not belong" in resp.json()["errors"][0]["detail"]
        assert not Trash.objects.filter(
            instance_id=str(course.pk), account=enterprise
        ).exists()

    def test_inactive_instructor_returns_403(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        instructor.owner.is_active = False
        instructor.owner.save()
        course = _course_for(enterprise)
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 403
        assert "permission to manage trash" in resp.json()["errors"][0]["detail"]

    def test_already_trashed_item_is_idempotent(self):
        enterprise, instructor, _ = _make_affiliate_setup()
        course = _course_for(enterprise)
        TrashFactory.Base(
            account=enterprise,
            trashed_by=enterprise,
            name=course.name,
            instance_id=str(course.pk),
            model_name="services.Course",
            mimetype=TrashMimeType.COURSE,
        )
        resp = TrashHelper.trash_items(
            owner_account_id=enterprise.id,
            items=[{"id": str(course.pk), "mimetype": TrashMimeType.COURSE}],
            affiliate_account_id=instructor.id,
        )
        assert resp.status_code == 201
        # Verify idempotency: only 1 Trash row exists (no duplicate created)
        assert (
            Trash.objects.filter(
                account=enterprise,
                instance_id=str(course.pk),
                mimetype=TrashMimeType.COURSE,
            ).count()
            == 1
        )
