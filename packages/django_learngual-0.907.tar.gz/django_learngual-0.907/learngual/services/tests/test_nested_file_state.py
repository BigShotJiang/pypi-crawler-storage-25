"""Tests for iam_service.learngual.services.nested_file_state.

Covers the bulk resolver:
- Empty inputs (no rows / no fields) → empty state, no DB hit
- Queryset path uses .values() (only JSON columns loaded)
- List/page path iterates instances; PydanticModelField → model_dump
- No candidate ids → no DB hit
- Trashed FileMedia → state value is None
- Non-trashed FileMedia → state value is full fresh dict
- Deeply-nested JSON (Lecture.body shape) → ids found via MediaHelper walk
- account/enterprise object extraction (.type, .id primitives)
- DB error during file_media_qs → exception propagates (write must abort)
- Custom presign override on the config is used
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from iam_service.learngual.services.nested_file_state import (
    NestedFileStateConfig,
    fetch_nested_file_state,
)

# ---------------------------------------------------------------------------
# Test fixtures: minimal stand-ins for the moving parts
# ---------------------------------------------------------------------------


DEFAULT_FILE_SCHEMA = {
    "id": "0",
    "url": "https://cdn.example.com/default.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


# A complete media object that satisfies the 6-field signature.
def _media(id_: str, **extra) -> dict[str, Any]:
    return {
        "id": id_,
        "url": f"https://stored.example.com/{id_}.jpg",
        "name": f"{id_}.jpg",
        "size": 1024,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
        **extra,
    }


def _file_media_row(
    pk: str,
    *,
    trashed: bool = False,
    mimetype: str = "image/jpeg",
    upload_name: str = "uploads/x.jpg",
    thumbnail_name: str | None = None,
) -> Any:
    """Minimal stand-in for a FileMedia row from the queryset."""
    return SimpleNamespace(
        pk=pk,
        id=pk,
        trashed_at="2024-01-01T00:00:00Z" if trashed else None,
        upload=SimpleNamespace(name=upload_name),
        thumbnail=(SimpleNamespace(name=thumbnail_name) if thumbnail_name else None),
        mimetype=mimetype,
        convertion_status="DONE",
        duration=None,
        size=1024,
    )


def _make_config(rows_for_query: list[Any]) -> NestedFileStateConfig:
    """Build a config whose file_media_qs returns the supplied rows."""

    def fake_qs(ids):
        # Real queryset behaviour: filter to only the requested ids.
        ids_set = {str(i) for i in ids}
        return [r for r in rows_for_query if str(r.pk) in ids_set]

    return NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        # Stub presigners so we can assert on what's passed without depending
        # on Django settings.
        presign=lambda media, *, account_type=None, enterprise_id=None: (
            f"presigned://main/{media.pk}" f"/at={account_type}/eid={enterprise_id}"
        ),
        presign_thumb=lambda media: (
            f"presigned://thumb/{media.pk}"
            if getattr(media, "thumbnail", None)
            else None
        ),
    )


# ---------------------------------------------------------------------------
# Empty inputs
# ---------------------------------------------------------------------------


def test_empty_rows_returns_empty_and_no_db_hit():
    calls = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    config = NestedFileStateConfig(
        file_media_qs=fake_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    assert fetch_nested_file_state([], ("thumbnail",), config=config) == {}
    assert fetch_nested_file_state(None, ("thumbnail",), config=config) == {}
    assert calls == []


def test_empty_nested_file_fields_returns_empty_no_db_hit():
    """If no columns are scannable, nothing to do."""
    calls = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    config = NestedFileStateConfig(
        file_media_qs=fake_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    rows = [SimpleNamespace(thumbnail={})]
    assert fetch_nested_file_state(rows, (), config=config) == {}
    assert calls == []


def test_rows_with_no_media_returns_empty_no_db_hit():
    """Rows present, columns scanned, but no media objects → no query."""
    calls = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    config = NestedFileStateConfig(
        file_media_qs=fake_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    rows = [
        SimpleNamespace(thumbnail={}),  # empty dict
        SimpleNamespace(thumbnail=None),
    ]
    assert fetch_nested_file_state(rows, ("thumbnail",), config=config) == {}
    assert calls == []


def test_id_zero_placeholders_skipped():
    """Stored placeholder values (id='0') are not real ids — no DB hit."""
    calls = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    config = NestedFileStateConfig(
        file_media_qs=fake_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    rows = [SimpleNamespace(thumbnail=_media("0"))]
    assert fetch_nested_file_state(rows, ("thumbnail",), config=config) == {}
    assert calls == []


# ---------------------------------------------------------------------------
# List/page path — basic walk and state shape
# ---------------------------------------------------------------------------


def test_single_row_with_one_media_returns_fresh_state():
    """Non-trashed FileMedia → state value is a dict of fresh fields."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)

    assert "abc" in state
    fresh = state["abc"]
    assert fresh is not None
    assert fresh["url"] == "presigned://main/abc/at=None/eid=None"
    assert fresh["mimetype"] == "image/jpeg"
    assert fresh["convertion_status"] == "DONE"
    assert fresh["size"] == 1024


def test_trashed_file_media_returns_none_state():
    """Trashed FileMedia → state[id] is None (mixin will swap to placeholder)."""
    file_rows = [_file_media_row("abc", trashed=True)]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)

    assert state == {"abc": None}


def test_mixed_trashed_and_active_yields_correct_state_per_id():
    """A page that references both trashed and active files produces a state
    map with both kinds of entries."""
    file_rows = [
        _file_media_row("active-1"),
        _file_media_row("trashed-2", trashed=True),
    ]
    config = _make_config(file_rows)
    rows = [
        SimpleNamespace(thumbnail=_media("active-1")),
        SimpleNamespace(thumbnail=_media("trashed-2")),
    ]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)

    assert state["trashed-2"] is None
    assert state["active-1"] is not None
    assert state["active-1"]["url"] == "presigned://main/active-1/at=None/eid=None"


def test_multiple_columns_on_same_row():
    """Multiple file-carrying columns on one row are all walked."""
    file_rows = [_file_media_row("a"), _file_media_row("b")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("a"), preview_video=_media("b"))]

    state = fetch_nested_file_state(rows, ("thumbnail", "preview_video"), config=config)

    assert set(state) == {"a", "b"}


def test_same_id_across_multiple_rows_deduplicated_in_query():
    """Two rows referencing the same FileMedia produce ONE query with one id."""
    queried_ids: list[set[str]] = []

    def fake_qs(ids):
        queried_ids.append(set(map(str, ids)))
        return [_file_media_row("shared")]

    config = NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=lambda media, *, account_type=None, enterprise_id=None: "u",
        presign_thumb=lambda media: None,
    )
    rows = [
        SimpleNamespace(thumbnail=_media("shared")),
        SimpleNamespace(thumbnail=_media("shared")),
    ]

    fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert len(queried_ids) == 1
    assert queried_ids[0] == {"shared"}


def test_exactly_one_db_query_per_call_regardless_of_row_count():
    """With N rows referencing N distinct files, file_media_qs is called once."""
    file_rows = [_file_media_row(f"f-{i}") for i in range(10)]
    call_count = 0

    def fake_qs(ids):
        nonlocal call_count
        call_count += 1
        return [r for r in file_rows if r.pk in set(map(str, ids))]

    config = NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=lambda media, *, account_type=None, enterprise_id=None: "u",
        presign_thumb=lambda media: None,
    )
    rows = [SimpleNamespace(thumbnail=_media(f"f-{i}")) for i in range(10)]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert len(state) == 10
    assert call_count == 1


# ---------------------------------------------------------------------------
# Deeply-nested / polymorphic columns (Lecture.body shape)
# ---------------------------------------------------------------------------


def test_resolver_emits_stream_url_for_video_via_real_presign():
    """End-to-end: with the package's real ``presign_media_url`` plugged
    into the config, the resolver's state map carries the media-service
    stream-endpoint URL for video files (not a direct S3 URL)."""
    from django.test import override_settings

    from iam_service.learngual.services.presign import (
        presign_media_url,
        presign_thumbnail_url,
    )

    file_row = SimpleNamespace(
        pk="vid-1",
        id="vid-1",
        trashed_at=None,
        upload=SimpleNamespace(name="videos/movie.mp4"),
        thumbnail=SimpleNamespace(name="videos/movie-thumb.jpg"),
        mimetype="video/mp4",
        convertion_status="DONE",
        duration=None,
        size=5_000_000,
    )

    config = NestedFileStateConfig(
        file_media_qs=lambda ids: [file_row],
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=presign_media_url,  # real implementation
        presign_thumb=presign_thumbnail_url,  # real implementation
    )
    rows = [SimpleNamespace(preview_video=_media("vid-1"))]
    account = SimpleNamespace(type="ENTERPRISE")

    with override_settings(
        LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/"
    ):
        state = fetch_nested_file_state(
            rows,
            ("preview_video",),
            config=config,
            account=account,
        )

    fresh = state["vid-1"]
    assert fresh is not None
    # The main url MUST be the account-scoped stream endpoint, not S3.
    assert "/enterprise/files/vid-1/stream/" in fresh["url"], fresh["url"]
    assert "/stream/" in fresh["url"]
    # The thumbnail is still direct (always an image), no /stream/ on it.
    assert "/stream/" not in (fresh["thumbnail_url"] or "")


def test_resolver_emits_stream_url_for_audio_via_real_presign():
    """Same property for audio: account-scoped stream endpoint, not S3."""
    from django.test import override_settings

    from iam_service.learngual.services.presign import (
        presign_media_url,
        presign_thumbnail_url,
    )

    file_row = SimpleNamespace(
        pk="aud-1",
        id="aud-1",
        trashed_at=None,
        upload=SimpleNamespace(name="audios/track.wav"),
        thumbnail=None,
        mimetype="audio/x-wav",
        convertion_status="CONVERTING",  # still converting
        duration=None,
        size=84_906,
    )

    config = NestedFileStateConfig(
        file_media_qs=lambda ids: [file_row],
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=presign_media_url,
        presign_thumb=presign_thumbnail_url,
    )
    rows = [SimpleNamespace(media=_media("aud-1"))]
    account = SimpleNamespace(type="PERSONAL")

    with override_settings(
        LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/"
    ):
        state = fetch_nested_file_state(
            rows,
            ("media",),
            config=config,
            account=account,
        )

    fresh = state["aud-1"]
    assert fresh is not None
    # Personal stream route — no /enterprise/ or /instructor/ segment.
    assert "/files/aud-1/stream/" in fresh["url"]
    assert "/enterprise/" not in fresh["url"]
    assert "/instructor/" not in fresh["url"]


def test_resolver_emits_direct_s3_for_image_via_real_presign():
    """Counterpoint to the stream tests: images route to direct S3, not stream."""
    from django.test import override_settings

    from iam_service.learngual.services.presign import (
        presign_media_url,
        presign_thumbnail_url,
    )

    file_row = SimpleNamespace(
        pk="img-1",
        id="img-1",
        trashed_at=None,
        upload=SimpleNamespace(
            name="profiles/avatar.jpg",
            url="https://fallback.example.com/avatar.jpg",
        ),
        thumbnail=None,
        mimetype="image/jpeg",
        convertion_status="DONE",
        duration=None,
        size=1024,
    )

    config = NestedFileStateConfig(
        file_media_qs=lambda ids: [file_row],
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=presign_media_url,
        presign_thumb=presign_thumbnail_url,
    )
    rows = [SimpleNamespace(profile_photo=_media("img-1"))]

    with override_settings(
        AWS_S3_DOMAIN="cdn.example.com",
        AWS_STORAGE_BUCKET_NAME="learngual-bucket",
        MEDIA_SERVICE_S3_PREFIX="media/media",
    ):
        state = fetch_nested_file_state(
            rows,
            ("profile_photo",),
            config=config,
            account=SimpleNamespace(type="PERSONAL"),
        )

    fresh = state["img-1"]
    assert fresh is not None
    # Image → direct CDN URL with media-service prefix; NOT a stream URL.
    assert fresh["url"] == (
        "https://cdn.example.com/learngual-bucket/media/media/profiles/avatar.jpg"
    )
    assert "/stream/" not in fresh["url"]


def test_resolver_recovers_file_id_beacon_from_stale_masked_row():
    """A stored masked row (id='0', file_id='abc') must surface 'abc' in the
    state map so the read-side mixin can auto-recover on the next GET if
    the underlying file has been restored or remains trashed."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [
        SimpleNamespace(
            thumbnail={
                "id": "0",
                "file_id": "abc",
                "url": "stored-default",
                "name": None,
                "size": 0,
                "mimetype": "image/png",
                "convertion_status": None,
            }
        )
    ]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)

    # file_id was recovered → state has the FileMedia's fresh data.
    assert "abc" in state
    assert state["abc"] is not None


def test_resolver_skips_fully_cleared_placeholder_no_db_hit():
    """id='0' + no file_id (or file_id='0') → no FileMedia to look up."""
    calls = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    config = NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    rows = [
        SimpleNamespace(
            thumbnail={
                "id": "0",
                # no file_id key at all
                "url": "stored-default",
                "name": None,
                "size": 0,
                "mimetype": "image/png",
                "convertion_status": None,
            }
        )
    ]
    out = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert out == {}
    assert calls == []  # no DB hit


def test_deeply_nested_polymorphic_body_finds_media_via_signature():
    """A Lecture-shaped body with media buried in list items is walked correctly."""
    body = {
        "blocks": [
            {"type": "text", "content": "intro"},
            {"type": "audio", "file": _media("aud-1")},
            {"type": "video", "file": _media("vid-1")},
            {"type": "practice", "answer_url": "https://x"},  # no media
        ]
    }
    file_rows = [_file_media_row("aud-1"), _file_media_row("vid-1")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(body=body)]

    state = fetch_nested_file_state(rows, ("body",), config=config)

    assert set(state) == {"aud-1", "vid-1"}
    assert state["aud-1"] is not None
    assert state["vid-1"] is not None


def test_pydantic_value_via_model_dump():
    """A column value that's a Pydantic instance (not dict) is normalised."""

    class FakePydantic:
        def __init__(self, data):
            self._data = data

        def model_dump(self):
            return self._data

    file_rows = [_file_media_row("pyd-1")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=FakePydantic(_media("pyd-1")))]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert "pyd-1" in state


def test_dict_rows_supported():
    """A list of plain dicts (e.g. from values()) is also acceptable input."""
    file_rows = [_file_media_row("dr-1")]
    config = _make_config(file_rows)
    rows = [{"thumbnail": _media("dr-1")}]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert "dr-1" in state


# ---------------------------------------------------------------------------
# Account / enterprise primitive extraction
# ---------------------------------------------------------------------------


def test_account_type_extracted_and_forwarded_to_presigner():
    """The resolver pulls .type off the account and passes it through."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    account = SimpleNamespace(type="ENTERPRISE")
    state = fetch_nested_file_state(
        rows, ("thumbnail",), config=config, account=account
    )

    assert state["abc"]["url"] == "presigned://main/abc/at=ENTERPRISE/eid=None"


def test_enterprise_id_extracted_when_instructor_under_enterprise():
    """The resolver pulls .id off the enterprise object."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    account = SimpleNamespace(type="INSTRUCTOR")
    enterprise = SimpleNamespace(id="ent-9")
    state = fetch_nested_file_state(
        rows,
        ("thumbnail",),
        config=config,
        account=account,
        enterprise=enterprise,
    )

    assert state["abc"]["url"] == "presigned://main/abc/at=INSTRUCTOR/eid=ent-9"


def test_enterprise_pk_fallback_if_no_id_attribute():
    """If the enterprise duck-type only has .pk, that's used too."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    account = SimpleNamespace(type="INSTRUCTOR")
    enterprise = SimpleNamespace(pk="ent-pk-1", id=None)
    state = fetch_nested_file_state(
        rows,
        ("thumbnail",),
        config=config,
        account=account,
        enterprise=enterprise,
    )

    assert state["abc"]["url"] == "presigned://main/abc/at=INSTRUCTOR/eid=ent-pk-1"


def test_no_account_means_primitives_are_none():
    """Without an account, account_type and enterprise_id are both None."""
    file_rows = [_file_media_row("abc")]
    config = _make_config(file_rows)
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert "at=None" in state["abc"]["url"]
    assert "eid=None" in state["abc"]["url"]


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


def test_db_error_in_file_media_qs_propagates():
    """A DB exception during the batch query is NOT swallowed.

    A read that can't fetch state must fail loudly — silently degrading
    to "no swap" would leak trashed URLs.
    """

    def failing_qs(ids):
        raise RuntimeError("database connection lost")

    config = NestedFileStateConfig(
        file_media_qs=failing_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    rows = [SimpleNamespace(thumbnail=_media("abc"))]

    with pytest.raises(RuntimeError, match="database"):
        fetch_nested_file_state(rows, ("thumbnail",), config=config)


def test_pydantic_model_dump_failure_is_logged_and_skipped():
    """If model_dump raises, the column is skipped silently (warning logged).

    The rest of the page still resolves normally.
    """

    class BadPydantic:
        def model_dump(self):
            raise RuntimeError("boom")

    file_rows = [_file_media_row("good")]
    config = _make_config(file_rows)
    rows = [
        SimpleNamespace(thumbnail=BadPydantic()),  # bad → skipped
        SimpleNamespace(thumbnail=_media("good")),  # still resolved
    ]

    state = fetch_nested_file_state(rows, ("thumbnail",), config=config)
    assert "good" in state


# ---------------------------------------------------------------------------
# Custom presigner override on the config
# ---------------------------------------------------------------------------


def test_config_presign_override_is_used():
    """A service that ships its own presigner via config.presign sees that
    function called, not the package default."""
    captured: list[tuple] = []

    def my_presign(media, *, account_type=None, enterprise_id=None):
        captured.append(("main", media.pk, account_type, enterprise_id))
        return f"custom://{media.pk}"

    def my_thumb(media):
        captured.append(("thumb", media.pk))
        return f"thumb://{media.pk}"

    file_rows = [_file_media_row("x", thumbnail_name="t.jpg")]
    config = NestedFileStateConfig(
        file_media_qs=lambda ids: file_rows,
        default_schema=DEFAULT_FILE_SCHEMA,
        presign=my_presign,
        presign_thumb=my_thumb,
    )
    rows = [SimpleNamespace(thumbnail=_media("x"))]

    state = fetch_nested_file_state(
        rows,
        ("thumbnail",),
        config=config,
        account=SimpleNamespace(type="PERSONAL"),
    )

    assert state["x"]["url"] == "custom://x"
    assert state["x"]["thumbnail_url"] == "thumb://x"
    assert ("main", "x", "PERSONAL", None) in captured
    assert ("thumb", "x") in captured
