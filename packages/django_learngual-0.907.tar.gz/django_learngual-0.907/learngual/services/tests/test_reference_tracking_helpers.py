"""Regression tests for the PURE reference-tracking helpers.

These helpers decide which file ids a carrier "references" and how
``reference_count`` is derived. Their exact behaviour was tuned through
explicit review feedback and MUST stay in lockstep with elearning
``extract_media_id_occurrences`` and the backfill scan (the inline ⇄
backfill zero-delta invariant). Pin it so a change can't silently shift
counts:

* ``calc_reference_count`` — sum of positive per-instance counts only
* ``extract_file_id`` — dict/obj id, ``""`` when absent
* ``extract_file_occurrences``:
  - STRICT predicate: a dict is a file object only if it has ALL of
    id+url+size+mimetype (mimetype required → no false positives from
    unrelated id/url/size dicts)
  - duplicates counted (Counter), aggregated across the whole payload
  - found at any depth in dict/list/tuple; the matched file object is
    NOT descended into
  - prune keys (qa_generation/staging_data/metadata_schema) subtree is
    never walked
  - ``exclude={field: values}`` drops matching file objects during the
    walk (single-field and multi-field)
* ``Intent`` / ``TrashStyle`` / ``Contribution`` contract constants
"""
from __future__ import annotations

from types import SimpleNamespace

from iam_service.learngual.services.reference_tracking import (
    Contribution,
    Intent,
    TrashStyle,
    calc_reference_count,
    extract_file_id,
    extract_file_occurrences,
)


def _f(id_: str, **extra) -> dict:
    """A strict file-schema dict (id+url+size+mimetype)."""
    return {
        "id": id_,
        "url": f"https://s/{id_}.jpg",
        "size": 10,
        "mimetype": "image/jpeg",
        **extra,
    }


# --------------------------------------------------------------------------- #
# calc_reference_count
# --------------------------------------------------------------------------- #


def test_calc_reference_count_sums_positive_counts():
    rd = {"Lecture": {"1": 2, "2": 1}, "CourseThumbnail": {"5": 1}}
    assert calc_reference_count(rd) == 4


def test_calc_reference_count_ignores_zero_negative_and_non_int():
    rd = {"Lecture": {"1": 0, "2": -3, "3": "x", "4": 2}, "X": "notadict"}
    assert calc_reference_count(rd) == 2


def test_calc_reference_count_safe_on_garbage():
    assert calc_reference_count(None) == 0
    assert calc_reference_count("nope") == 0
    assert calc_reference_count({}) == 0


# --------------------------------------------------------------------------- #
# extract_file_id
# --------------------------------------------------------------------------- #


def test_extract_file_id_dict_and_object_and_missing():
    assert extract_file_id({"id": "abc"}) == "abc"
    assert extract_file_id({"id": None}) == ""
    assert extract_file_id({}) == ""
    assert extract_file_id(SimpleNamespace(id="z")) == "z"
    assert extract_file_id(SimpleNamespace()) == ""


# --------------------------------------------------------------------------- #
# extract_file_occurrences — strict predicate
# --------------------------------------------------------------------------- #


def test_only_full_signature_dicts_count_mimetype_required():
    payload = {
        "real": _f("R"),
        # missing mimetype -> NOT a file object (the key anti-false-positive)
        "fake": {"id": "F", "url": "u", "size": 1},
        "alsofake": {"id": "G"},
    }
    assert extract_file_occurrences(payload) == {"R": 1}


def test_duplicates_counted_and_aggregated_across_payload():
    payload = {
        "a": _f("X"),
        "b": [_f("X"), _f("Y")],
        "c": {"deep": {"nested": _f("X")}},
    }
    assert extract_file_occurrences(payload) == {"X": 3, "Y": 1}


def test_found_in_list_and_tuple_at_any_depth():
    payload = {"blocks": [{"file": _f("L1")}, ({"file": _f("L2")},)]}
    assert extract_file_occurrences(payload) == {"L1": 1, "L2": 1}


def test_matched_file_object_not_descended_into():
    # A scalar inside the file object that looks id-ish must not be
    # re-counted; the walker stops at a matched file object.
    payload = {
        "file": _f(
            "ONLY",
            thumbnail={"id": "x", "url": "u", "size": 1, "mimetype": "image/png"},
        )
    }
    # The nested dict is INSIDE a matched file object → not walked.
    assert extract_file_occurrences(payload) == {"ONLY": 1}


def test_prune_keys_subtree_never_walked():
    hidden = _f("HID")
    payload = {
        "qa_generation": {"x": hidden},
        "staging_data": [hidden],
        "metadata_schema": hidden,
        "body": _f("SEEN"),
    }
    assert extract_file_occurrences(payload) == {"SEEN": 1}


# --------------------------------------------------------------------------- #
# extract_file_occurrences — exclude predicate
# --------------------------------------------------------------------------- #


def test_exclude_single_field_drops_matching_files():
    payload = {"a": _f("keep"), "b": _f("drop"), "c": _f("drop")}
    out = extract_file_occurrences(payload, exclude={"id": {"drop"}})
    assert out == {"keep": 1}


def test_exclude_multi_field_any_match_drops():
    payload = {
        "a": _f("k", mimetype="image/jpeg"),
        "b": _f("x", mimetype="video/mp4"),
        "c": _f("y"),
    }
    # Drop if id in {y} OR mimetype in {video/mp4}.
    out = extract_file_occurrences(
        payload, exclude={"id": {"y"}, "mimetype": {"video/mp4"}}
    )
    assert out == {"k": 1}


def test_exclude_none_is_noop():
    payload = {"a": _f("p")}
    assert extract_file_occurrences(payload, exclude=None) == {"p": 1}
    assert extract_file_occurrences(payload, exclude={}) == {"p": 1}


# --------------------------------------------------------------------------- #
# Contract constants (names are part of the cross-service contract)
# --------------------------------------------------------------------------- #


def test_intent_and_trashstyle_values_pinned():
    assert {i.value for i in Intent} == {"authoring", "trash", "restore"}
    assert {t.value for t in TrashStyle} == {
        "content",
        "course_scope",
        "file_scope",
    }


def test_contribution_is_frozen_and_holds_truth():
    c = Contribution(7, "Lecture", "33", {"f1": 2})
    assert (c.course_id, c.model_key, c.instance_id) == (7, "Lecture", "33")
    assert c.file_counts == {"f1": 2}
    import dataclasses

    try:
        c.course_id = 9  # frozen → must raise
        raised = False
    except dataclasses.FrozenInstanceError:
        raised = True
    assert raised
