"""Tests for iam_service.learngual.services.presign.

Covers the canonical media URL builder:
- infer_media_type: mimetype + extension classification
- _build_stream_url: account-scoped path templates, host prefix, fallbacks
- _presign_s3: AWS_S3_DOMAIN CDN path, MinIO presign, error fallback
- presign_media_url: video/audio → stream; image → direct S3
- presign_thumbnail_url: always direct S3
- Error handling: missing media / mimetype / upload / pk
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

from django.test import override_settings

from iam_service.learngual.services.presign import (
    AccountType,
    _build_stream_url,
    _presign_s3,
    infer_media_type,
    presign_media_url,
    presign_thumbnail_url,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _fake_field(name: str | None, url: str = "https://fallback.example.com/x") -> Any:
    """Minimal stand-in for a Django FieldFile."""
    return SimpleNamespace(name=name, url=url)


def _fake_media(
    *,
    id_: str = "abc-123",
    mimetype: str | None = "image/jpeg",
    upload_name: str | None = "uploads/photo.jpg",
    thumbnail_name: str | None = None,
) -> Any:
    """Minimal stand-in for a FileMedia row with attributes the presigner reads."""
    return SimpleNamespace(
        id=id_,
        mimetype=mimetype,
        upload=_fake_field(upload_name) if upload_name else None,
        thumbnail=_fake_field(thumbnail_name) if thumbnail_name else None,
    )


# ---------------------------------------------------------------------------
# infer_media_type
# ---------------------------------------------------------------------------


def test_infer_media_type_video_by_mimetype():
    assert infer_media_type("video/mp4", None) == "video"
    assert infer_media_type("video/webm", "doesnt-matter") == "video"


def test_infer_media_type_audio_by_mimetype():
    assert infer_media_type("audio/x-wav", None) == "audio"
    assert infer_media_type("audio/mpeg", "x.mp3") == "audio"


def test_infer_media_type_image_returns_none():
    """Images don't get routed to the stream branch."""
    assert infer_media_type("image/jpeg", "x.jpg") is None
    assert infer_media_type("image/png", None) is None


def test_infer_media_type_unknown_mimetype_falls_back_to_extension():
    """No mimetype → check filename extension."""
    assert infer_media_type(None, "song.mp3") == "audio"
    assert infer_media_type(None, "film.mp4") == "video"
    assert infer_media_type(None, "doc.pdf") is None


def test_infer_media_type_extension_without_dot_recognised():
    """Some upload paths strip the leading dot."""
    assert infer_media_type(None, "filemp3") is None  # not a real ext
    # The function checks both ext and ext_no_dot — strict file path with ext.
    assert infer_media_type(None, "file.mp3") == "audio"


def test_infer_media_type_no_inputs_returns_none():
    assert infer_media_type(None, None) is None
    assert infer_media_type("", "") is None


# ---------------------------------------------------------------------------
# _build_stream_url — account-scoped path templates
# ---------------------------------------------------------------------------


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_personal_uses_files_path():
    """PERSONAL → /media/<v>/files/<pk>/stream/."""
    media = _fake_media(id_="my-id")
    url = _build_stream_url(media, AccountType.PERSONAL, None)
    assert url is not None
    assert "/media/" in url
    assert "/files/my-id/stream/" in url
    assert "/instructor/" not in url
    assert "/enterprise/" not in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_enterprise_uses_enterprise_path():
    """ENTERPRISE → /media/<v>/enterprise/files/<pk>/stream/."""
    media = _fake_media(id_="ent-id")
    url = _build_stream_url(media, AccountType.ENTERPRISE, None)
    assert url is not None
    assert "/enterprise/files/ent-id/stream/" in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_instructor_without_enterprise():
    """INSTRUCTOR alone → /media/<v>/instructor/files/<pk>/stream/."""
    media = _fake_media(id_="inst-id")
    url = _build_stream_url(media, AccountType.INSTRUCTOR, None)
    assert url is not None
    assert "/instructor/files/inst-id/stream/" in url
    assert "/instructor/" in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_instructor_with_enterprise_id():
    """INSTRUCTOR + enterprise_id → /media/<v>/instructor/<eid>/files/<pk>/stream/."""
    media = _fake_media(id_="inst-id")
    url = _build_stream_url(media, AccountType.INSTRUCTOR, enterprise_id="ent-789")
    assert url is not None
    assert "/instructor/ent-789/files/inst-id/stream/" in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_accepts_account_type_as_string():
    """Caller can pass the string form (not just the enum)."""
    media = _fake_media(id_="abc")
    url = _build_stream_url(media, "ENTERPRISE", None)
    assert url is not None
    assert "/enterprise/files/abc/stream/" in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_no_account_type_falls_back_to_personal():
    """When account_type is None, falls back to PERSONAL (instead of returning None)."""
    media = _fake_media(id_="x")
    url = _build_stream_url(media, None, None)
    assert url is not None
    assert "/files/x/stream/" in url
    assert "/instructor/" not in url
    assert "/enterprise/" not in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_build_stream_url_unknown_role_logs_and_falls_back_to_personal():
    """An unknown account_type triggers a warning + PERSONAL fallback."""
    media = _fake_media(id_="x")
    url = _build_stream_url(media, "ROBOT", None)
    assert url is not None
    assert "/files/x/stream/" in url


def test_build_stream_url_no_pk_returns_none():
    """A media-like object without an id can't form a URL."""
    media = SimpleNamespace(id=None, pk=None)
    assert _build_stream_url(media, AccountType.PERSONAL, None) is None


@override_settings(
    LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/",
    MEDIA_SERVICE_STREAM_VERSION="v1",
)
def test_build_stream_url_version_setting_overrides_default():
    """MEDIA_SERVICE_STREAM_VERSION='v1' makes the URL use /media/v1/..."""
    media = _fake_media(id_="x")
    url = _build_stream_url(media, AccountType.PERSONAL, None)
    assert url is not None
    assert "/media/v1/files/x/stream/" in url
    assert "/media/v2/" not in url


# ---------------------------------------------------------------------------
# _presign_s3 — CDN path / MinIO presign / fallbacks
# ---------------------------------------------------------------------------


def test_presign_s3_no_field_returns_none():
    assert _presign_s3(None) is None
    assert _presign_s3(SimpleNamespace(name=None)) is None
    assert _presign_s3(SimpleNamespace(name="")) is None


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="my-bucket",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_s3_cdn_path_uses_aws_s3_domain():
    """When AWS_S3_DOMAIN is set, emit an unsigned CDN URL with the media-service prefix."""
    field = _fake_field("audios/track.wav")
    url = _presign_s3(field)
    assert url == "https://cdn.example.com/my-bucket/media/media/audios/track.wav"


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="my-bucket",
    MEDIA_SERVICE_S3_PREFIX="custom/prefix",
)
def test_presign_s3_cdn_path_honours_prefix_override():
    """MEDIA_SERVICE_S3_PREFIX customises the folder."""
    field = _fake_field("files/x.jpg")
    url = _presign_s3(field)
    assert url == "https://cdn.example.com/my-bucket/custom/prefix/files/x.jpg"


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="my-bucket",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_s3_cdn_path_strips_leading_slash_on_key():
    """field.name may start with '/' — the URL should still be well-formed."""
    field = _fake_field("/audios/track.wav")
    url = _presign_s3(field)
    assert "//audios" not in url  # no double slash
    assert url.endswith("/media/media/audios/track.wav")


@override_settings(
    AWS_S3_DOMAIN=None,
    AWS_S3_ENDPOINT_URL="http://minio:9000",
    AWS_STORAGE_BUCKET_NAME="my-bucket",
    AWS_ACCESS_KEY_ID="key",
    AWS_SECRET_ACCESS_KEY="secret",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_s3_minio_path_calls_boto3_generate_presigned_url():
    """Without AWS_S3_DOMAIN, the package presigns via boto3 against MinIO."""
    field = _fake_field("audios/track.wav")
    with patch("iam_service.learngual.services.presign.boto3.client") as mock_client:
        mock_client.return_value.generate_presigned_url.return_value = (
            "http://minio:9000/presigned?sig=xyz"
        )
        url = _presign_s3(field)
    assert url == "http://minio:9000/presigned?sig=xyz"
    # boto3 was called with the correct key (media-service prefix + name).
    call_kwargs = mock_client.return_value.generate_presigned_url.call_args.kwargs
    assert call_kwargs["Params"]["Bucket"] == "my-bucket"
    assert call_kwargs["Params"]["Key"] == "media/media/audios/track.wav"


@override_settings(
    AWS_S3_DOMAIN=None,
    AWS_S3_ENDPOINT_URL="http://minio:9000",
    AWS_STORAGE_BUCKET_NAME="my-bucket",
    AWS_ACCESS_KEY_ID="key",
    AWS_SECRET_ACCESS_KEY="secret",
)
def test_presign_s3_boto3_error_falls_back_to_field_url():
    """If boto3 presigning raises, the package falls back to ``field.url``."""
    field = _fake_field("x.jpg", url="https://fallback.example.com/x.jpg")
    with patch(
        "iam_service.learngual.services.presign.boto3.client",
        side_effect=RuntimeError("boom"),
    ):
        url = _presign_s3(field)
    assert url == "https://fallback.example.com/x.jpg"


# ---------------------------------------------------------------------------
# presign_media_url — branch selection
# ---------------------------------------------------------------------------


def test_presign_media_url_none_input_returns_none():
    assert presign_media_url(None) is None


def test_presign_media_url_no_upload_returns_none():
    media = SimpleNamespace(id="x", mimetype="image/png", upload=None)
    assert presign_media_url(media) is None


def test_presign_media_url_no_mimetype_returns_none():
    media = _fake_media(mimetype=None)
    assert presign_media_url(media) is None


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="b",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_media_url_image_uses_direct_s3():
    """Images route through _presign_s3 (direct CDN URL)."""
    media = _fake_media(mimetype="image/png", upload_name="profiles/x.png")
    url = presign_media_url(media)
    assert url == "https://cdn.example.com/b/media/media/profiles/x.png"


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_presign_media_url_video_routes_to_stream_endpoint():
    """Video files route through _build_stream_url."""
    media = _fake_media(id_="vid-1", mimetype="video/mp4", upload_name="vids/x.mp4")
    url = presign_media_url(media, account_type=AccountType.PERSONAL)
    assert url is not None
    assert "/files/vid-1/stream/" in url
    # NOT a direct S3 URL.
    assert "cdn." not in url
    assert ".s3." not in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_presign_media_url_audio_routes_to_stream_endpoint():
    """Audio files route through _build_stream_url."""
    media = _fake_media(id_="aud-1", mimetype="audio/x-wav", upload_name="audios/y.wav")
    url = presign_media_url(media, account_type=AccountType.ENTERPRISE)
    assert url is not None
    assert "/enterprise/files/aud-1/stream/" in url


@override_settings(LEARNGUAL_AUTH_RETRIEVE_URL="https://media.learngual.com/iam/v1/")
def test_presign_media_url_instructor_enterprise_routes_correctly():
    """Instructor under enterprise gets the longest path template."""
    media = _fake_media(id_="aud-1", mimetype="audio/x-wav", upload_name="audios/y.wav")
    url = presign_media_url(
        media, account_type=AccountType.INSTRUCTOR, enterprise_id="ent-9"
    )
    assert url is not None
    assert "/instructor/ent-9/files/aud-1/stream/" in url


# ---------------------------------------------------------------------------
# presign_thumbnail_url — always direct S3
# ---------------------------------------------------------------------------


def test_presign_thumbnail_url_none_input_returns_none():
    assert presign_thumbnail_url(None) is None


def test_presign_thumbnail_url_no_thumbnail_returns_none():
    """A media without a thumbnail field returns None."""
    media = _fake_media(thumbnail_name=None)
    assert presign_thumbnail_url(media) is None


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="b",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_thumbnail_url_video_thumbnail_uses_direct_s3():
    """Even for a video parent, the thumbnail goes direct to S3 (it IS an image)."""
    media = _fake_media(
        mimetype="video/mp4",
        upload_name="vids/x.mp4",
        thumbnail_name="vids/x.jpg",
    )
    url = presign_thumbnail_url(media)
    assert url == "https://cdn.example.com/b/media/media/vids/x.jpg"
    # NOT a stream URL.
    assert "/stream/" not in url


@override_settings(
    AWS_S3_DOMAIN="cdn.example.com",
    AWS_STORAGE_BUCKET_NAME="b",
    MEDIA_SERVICE_S3_PREFIX="media/media",
)
def test_presign_thumbnail_url_image_thumbnail_also_direct_s3():
    """An image's thumbnail is just another image."""
    media = _fake_media(
        mimetype="image/jpeg",
        upload_name="profiles/x.jpg",
        thumbnail_name="profiles/x-thumb.jpg",
    )
    url = presign_thumbnail_url(media)
    assert url == "https://cdn.example.com/b/media/media/profiles/x-thumb.jpg"
