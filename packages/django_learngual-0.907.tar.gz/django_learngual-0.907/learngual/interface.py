import json
from abc import abstractmethod
from typing import Any, ClassVar, Literal

from django.utils import timezone
from drf_spectacular.extensions import OpenApiSerializerFieldExtension
from drf_spectacular.plumbing import build_array_type
from pydantic import BaseModel as _BaseModel


class TrashableItemInterface:
    """Interface for models that support soft-delete (trash) behaviour.

    Requires the model to also inherit from TrashModelMixin so the
    ``trashed_at``, ``trashed_by_parent`` and ``trashed_by`` fields exist.
    """

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_in_trash(self) -> bool:
        """Return True when this instance has been moved to trash."""
        return self.trashed_at is not None

    # ------------------------------------------------------------------
    # Trash / restore
    # ------------------------------------------------------------------

    def trash(self, by_parent: bool = False, trashed_by=None) -> None:
        """Move this item to trash.

        Args:
            by_parent: Set to True when the item is being trashed because
                its parent was trashed (cascade trash).
            trashed_by: The Account that initiated the trash action.
                Only used if the concrete model defines a ``trashed_by`` field.
        """
        self.trashed_at = timezone.now()
        self.trashed_by_parent = by_parent
        # Set trashed_by only if the concrete model has the field defined.
        if trashed_by is not None and hasattr(self, "trashed_by"):
            self.trashed_by = trashed_by
        self.save()
        # Cascade trash to children
        for child in self.get_children():
            if hasattr(child, "trash") and not child.is_in_trash:
                child.trash(by_parent=True, trashed_by=trashed_by)

    def restore(self) -> None:
        """Restore this item from trash.

        Also restores children that were trashed by this parent.
        """
        self.trashed_at = None
        self.trashed_by_parent = False
        # Clear trashed_by only if the concrete model has the field defined.
        if hasattr(self, "trashed_by"):
            self.trashed_by = None
        self.save()
        # Restore children that were cascaded from this parent
        for child in self.get_children():
            if (
                hasattr(child, "restore")
                and child.is_in_trash
                and child.trashed_by_parent
            ):
                child.restore()

    def delete(self, using=None, keep_parents=False):
        """Override delete to permanently remove the item.

        Call ``trash()`` instead to soft-delete.
        """
        return super().delete(using=using, keep_parents=keep_parents)

    # ------------------------------------------------------------------
    # Abstract helpers – implement in each concrete model
    # ------------------------------------------------------------------

    @abstractmethod
    def get_parent(self):
        """Return the parent object of this instance, or None."""
        raise NotImplementedError

    @abstractmethod
    def get_children(self) -> list:
        """Return a list / queryset of child objects for this instance."""
        raise NotImplementedError


class BaseModel(_BaseModel, OpenApiSerializerFieldExtension):
    target_class: ClassVar[str]
    is_list: ClassVar[bool | None] = None

    @classmethod
    def map_serializer_field(cls, auto_schema, direction):
        if cls.is_list:
            # Return schema for an array of objects
            return build_array_type(cls.model_json_schema())
        else:
            # Return schema for a single object
            return cls.model_json_schema()

    @classmethod
    def replace_ref(
        cls, defs: dict, schema: dict | list
    ) -> dict[str, Any] | list | Any:
        """Function replace all ref with thier object

        Args:
            defs (dict): _description_
            schema (dict | list): _description_

        Returns:
            dict[str,Any]|list|Any: _description_
        """
        if type(schema) == list:
            return [cls.replace_ref(defs, value) for value in schema]
        elif type(schema) == dict:
            if schema.get("$ref"):
                return defs.get(schema.get("$ref"), schema)
            else:
                return {
                    key: (
                        cls.replace_ref(defs, value)
                        if type(value) in [list, dict]
                        else value
                    )
                    for key, value in schema.items()
                }
        return schema

    @classmethod
    def get_defs(cls, data: dict) -> dict[str, Any]:
        res = {f"#/$defs/{key}": value for key, value in data.get("$defs", {}).items()}
        return cls.replace_ref(res, res)

    @classmethod
    def model_json_schema(cls, *args, **kwargs) -> dict[str, Any]:
        """Generate jsonschema of the model.

        Returns:
            dict[str,Any]: _description_
        """
        data = super().model_json_schema(*args, **kwargs)
        defs: dict = cls.get_defs(data)
        res = cls.replace_ref(defs=defs, schema=data)
        return res

    @classmethod
    def model_json_schema_no_defs(cls, *args, **kwargs) -> dict[str, Any]:
        """Generate jsonschema of the model.

        Returns:
            dict[str,Any]:
        """
        data = super().model_json_schema(*args, **kwargs)
        defs: dict = cls.get_defs(data)
        res = cls.replace_ref(defs=defs, schema=data)
        res.pop("$defs", None)
        return res

    def dict_plain(self) -> dict:
        return json.loads(self.model_dump_json())


class BaseModelNoDefs(BaseModel):
    @classmethod
    def model_json_schema(cls, *args, **kwargs) -> dict[str, Any]:
        """Generate jsonschema of the model.

        Returns:
            dict[str,Any]: _description_
        """
        data = super().model_json_schema(*args, **kwargs)
        defs: dict = cls.get_defs(data)
        res = cls.replace_ref(defs=defs, schema=data)
        res.pop("$defs", None)
        return res

    def dict_plain(self) -> dict:
        return json.loads(self.model_dump_json())


class BaseTypeModel(BaseModelNoDefs):
    type: Literal["--none--"] = "--none--"

    @classmethod
    @property
    def object_type(cls) -> str:
        """return the type

        Returns:
            str: _description_
        """
        try:
            return cls.model_fields["type"].default
        except AttributeError:
            return "unknown"
