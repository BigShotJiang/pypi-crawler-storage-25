"""Tests for the keyword-based sentiment engine."""

from news_server.sentiment import compute_trend, score_text, score_to_label


class TestScoreText:
    def test_bullish_text(self):
        s = score_text("Apple beats expectations with record revenue surge")
        assert s > 0.3

    def test_bearish_text(self):
        s = score_text("Company faces investigation amid layoffs and decline")
        assert s < -0.3

    def test_neutral_text(self):
        s = score_text("The company released its quarterly report today")
        assert -0.15 <= s <= 0.15

    def test_empty_text(self):
        assert score_text("") == 0.0

    def test_mixed_text(self):
        s = score_text("Stock surges after beating estimates but faces investigation")
        # Has both bullish and bearish terms — score should be moderate
        assert -0.8 < s < 0.8


class TestScoreToLabel:
    def test_very_bullish(self):
        assert score_to_label(0.6) == "very_bullish"

    def test_bullish(self):
        assert score_to_label(0.25) == "bullish"

    def test_neutral(self):
        assert score_to_label(0.0) == "neutral"

    def test_bearish(self):
        assert score_to_label(-0.25) == "bearish"

    def test_very_bearish(self):
        assert score_to_label(-0.6) == "very_bearish"


class TestComputeTrend:
    def test_improving(self):
        scores = [-0.5, -0.3, 0.0, 0.3, 0.5]
        assert compute_trend(scores) == "improving"

    def test_deteriorating(self):
        scores = [0.5, 0.3, 0.0, -0.3, -0.5]
        assert compute_trend(scores) == "deteriorating"

    def test_stable(self):
        scores = [0.1, 0.05, 0.1, 0.05, 0.1]
        assert compute_trend(scores) == "stable"

    def test_single_score(self):
        assert compute_trend([0.5]) == "stable"

    def test_empty(self):
        assert compute_trend([]) == "stable"
