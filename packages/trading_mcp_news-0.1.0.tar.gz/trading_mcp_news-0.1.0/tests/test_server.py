"""Tests for all 4 News & Sentiment MCP tools."""

import httpx
import pytest

from news_server.providers import _circuit
from news_server.server import (
    _news_cache,
    get_earnings_sentiment,
    get_news,
    get_sentiment_score,
    get_trending_tickers,
)


# ═══════════════════════════════════════════════════════════════════
# Tool 1: get_news
# ═══════════════════════════════════════════════════════════════════


class TestGetNews:
    @pytest.mark.asyncio
    async def test_get_news_happy_path(self, mock_routes, finnhub_news_response):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_news("AAPL")
        assert "articles" in result
        assert len(result["articles"]) == 3
        assert (
            result["articles"][0]["title"]
            == "Apple beats expectations with record revenue growth in Q4"
        )
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_news_with_sentiment(self, mock_routes, finnhub_news_response):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_news("AAPL", include_sentiment=True)
        assert "overallSentiment" in result
        assert "score" in result["overallSentiment"]
        assert "label" in result["overallSentiment"]
        # First article is very bullish
        assert result["articles"][0]["sentiment"]["score"] > 0

    @pytest.mark.asyncio
    async def test_get_news_without_sentiment(self, mock_routes, finnhub_news_response):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_news("AAPL", include_sentiment=False)
        assert "overallSentiment" not in result
        assert "sentiment" not in result["articles"][0]

    @pytest.mark.asyncio
    async def test_get_news_all_providers_fail(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(500)
        )
        result = await get_news("AAPL")
        assert "error" in result
        assert "Unable to fetch news" in result["error"]

    @pytest.mark.asyncio
    async def test_get_news_rate_limited(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(429)
        )
        result = await get_news("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_news_invalid_input(self):
        result = await get_news("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_get_news_no_api_key(self, monkeypatch):
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await get_news("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_news_respects_limit(self, mock_routes, finnhub_news_response):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_news("AAPL", limit=2)
        assert len(result["articles"]) == 2


# ═══════════════════════════════════════════════════════════════════
# Tool 2: get_sentiment_score
# ═══════════════════════════════════════════════════════════════════


class TestGetSentimentScore:
    @pytest.mark.asyncio
    async def test_get_sentiment_score_happy_path(
        self, mock_routes, finnhub_news_response
    ):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_sentiment_score("AAPL")
        assert "score" in result
        assert "label" in result
        assert "trend" in result
        assert result["sampleSize"] == 3
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_sentiment_score_different_windows(
        self, mock_routes, finnhub_news_response
    ):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        for window in ("1d", "3d", "7d", "30d"):
            result = await get_sentiment_score("AAPL", window=window)
            assert result["window"] == window

    @pytest.mark.asyncio
    async def test_get_sentiment_score_no_articles(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=[])
        )
        result = await get_sentiment_score("AAPL")
        assert result["score"] == 0.0
        assert result["label"] == "neutral"
        assert result["sampleSize"] == 0

    @pytest.mark.asyncio
    async def test_get_sentiment_score_all_providers_fail(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(500)
        )
        result = await get_sentiment_score("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_sentiment_score_invalid_input(self):
        result = await get_sentiment_score("")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_sentiment_score_invalid_window(self):
        result = await get_sentiment_score("AAPL", window="2w")
        assert "error" in result
        assert "Invalid window" in result["error"]

    @pytest.mark.asyncio
    async def test_get_sentiment_score_no_api_key(self, monkeypatch):
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await get_sentiment_score("AAPL")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 3: get_trending_tickers
# ═══════════════════════════════════════════════════════════════════


class TestGetTrendingTickers:
    @pytest.mark.asyncio
    async def test_get_trending_crypto(self, mock_routes, coingecko_trending_response):
        mock_routes.get("https://api.coingecko.com/api/v3/search/trending").mock(
            return_value=httpx.Response(200, json=coingecko_trending_response)
        )
        result = await get_trending_tickers(market="crypto")
        assert "tickers" in result
        assert len(result["tickers"]) == 3
        assert result["tickers"][0]["symbol"] == "BTC"

    @pytest.mark.asyncio
    async def test_get_trending_stocks(
        self,
        mock_routes,
        finnhub_general_news_response,
    ):
        mock_routes.get("https://finnhub.io/api/v1/news").mock(
            return_value=httpx.Response(200, json=finnhub_general_news_response)
        )
        result = await get_trending_tickers(market="stocks")
        assert "tickers" in result
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_trending_all(
        self,
        mock_routes,
        finnhub_general_news_response,
        coingecko_trending_response,
    ):
        mock_routes.get("https://finnhub.io/api/v1/news").mock(
            return_value=httpx.Response(200, json=finnhub_general_news_response)
        )
        mock_routes.get("https://api.coingecko.com/api/v3/search/trending").mock(
            return_value=httpx.Response(200, json=coingecko_trending_response)
        )
        result = await get_trending_tickers(market="all")
        assert "tickers" in result

    @pytest.mark.asyncio
    async def test_get_trending_all_fail(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/news").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://api.coingecko.com/api/v3/search/trending").mock(
            return_value=httpx.Response(500)
        )
        # Trending gracefully returns empty list when providers fail
        result = await get_trending_tickers(market="all")
        assert result["tickers"] == []

    @pytest.mark.asyncio
    async def test_get_trending_invalid_market(self):
        result = await get_trending_tickers(market="forex")
        assert "error" in result
        assert "Invalid market" in result["error"]

    @pytest.mark.asyncio
    async def test_get_trending_no_api_key(self, monkeypatch):
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        monkeypatch.setenv("COINGECKO_API_KEY", "")
        result = await get_trending_tickers(market="all")
        # Gracefully returns empty — doesn't crash
        assert "tickers" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 4: get_earnings_sentiment
# ═══════════════════════════════════════════════════════════════════


class TestGetEarningsSentiment:
    @pytest.mark.asyncio
    async def test_get_earnings_sentiment_happy_path(
        self,
        mock_routes,
        finnhub_earnings_response,
        finnhub_news_response,
    ):
        mock_routes.get("https://finnhub.io/api/v1/calendar/earnings").mock(
            return_value=httpx.Response(200, json=finnhub_earnings_response)
        )
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        result = await get_earnings_sentiment("AAPL")
        assert result["symbol"] == "AAPL"
        assert result["lastEarningsDate"] == "2024-10-31"
        assert "preSentiment" in result
        assert "postSentiment" in result
        assert "score" in result["preSentiment"]
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_earnings_sentiment_no_earnings(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/calendar/earnings").mock(
            return_value=httpx.Response(200, json={"earningsCalendar": []})
        )
        result = await get_earnings_sentiment("XYZ")
        assert "error" in result
        assert "No earnings data" in result["error"]

    @pytest.mark.asyncio
    async def test_get_earnings_sentiment_all_fail(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/calendar/earnings").mock(
            return_value=httpx.Response(500)
        )
        result = await get_earnings_sentiment("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_earnings_sentiment_invalid_input(self):
        result = await get_earnings_sentiment("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_get_earnings_sentiment_no_api_key(self, monkeypatch):
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await get_earnings_sentiment("AAPL")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Cache behavior
# ═══════════════════════════════════════════════════════════════════


class TestCache:
    @pytest.mark.asyncio
    async def test_cache_hit(self, mock_routes, finnhub_news_response):
        route = mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(200, json=finnhub_news_response)
        )
        r1 = await get_news("AAPL")
        r2 = await get_news("AAPL")
        assert r1["articleCount"] == r2["articleCount"]
        assert route.call_count == 1


# ═══════════════════════════════════════════════════════════════════
# Circuit breaker
# ═══════════════════════════════════════════════════════════════════


class TestCircuitBreaker:
    @pytest.mark.asyncio
    async def test_circuit_breaker_trips(self, mock_routes):
        mock_routes.get("https://finnhub.io/api/v1/company-news").mock(
            return_value=httpx.Response(500)
        )
        for _ in range(3):
            _news_cache.clear()
            await get_news("AAPL")

        assert _circuit.is_open("finnhub") is True
