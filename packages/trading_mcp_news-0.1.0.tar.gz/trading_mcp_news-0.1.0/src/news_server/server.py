"""News & Sentiment MCP server — 4 tools for financial news and sentiment."""

from datetime import datetime, timedelta, timezone

from fastmcp import FastMCP

from trading_mcp_shared.cache import TTLCacheWrapper

from news_server.providers import NewsProviderPool, _resolve_from_date
from news_server.sentiment import compute_trend, score_text, score_to_label

mcp = FastMCP("News & Sentiment")

_pool = NewsProviderPool()

# ── Caches ───────────────────────────────────────────────────────

_news_cache = TTLCacheWrapper(maxsize=256, ttl=900)  # 15 minutes
_sentiment_cache = TTLCacheWrapper(maxsize=256, ttl=900)
_trending_cache = TTLCacheWrapper(maxsize=32, ttl=900)
_earnings_cache = TTLCacheWrapper(maxsize=128, ttl=900)

# ── Valid enums ──────────────────────────────────────────────────

_VALID_WINDOWS = {"1d", "3d", "7d", "30d"}
_VALID_MARKETS = {"stocks", "crypto", "all"}
_WINDOW_DAYS = {"1d": 1, "3d": 3, "7d": 7, "30d": 30}


def _attach_sentiment(
    articles: list[dict], include: bool
) -> tuple[list[dict], float | None]:
    """Score each article and compute overall sentiment."""
    if not include or not articles:
        return articles, None

    scores = []
    for article in articles:
        text = f"{article.get('title', '')} {article.get('summary', '')}"
        s = score_text(text)
        scores.append(s)
        article["sentiment"] = {
            "score": round(s, 4),
            "label": score_to_label(s),
            "model": "keyword-v1",
        }

    overall = sum(scores) / len(scores) if scores else 0.0
    return articles, round(overall, 4)


# ── Tool 1: get_news ────────────────────────────────────────────


@mcp.tool()
async def get_news(
    symbol: str,
    from_date: str = "7d",
    limit: int = 10,
    include_sentiment: bool = True,
) -> dict:
    """Fetch recent news articles for a specific ticker or topic.

    Args:
        symbol: Ticker symbol or topic keyword e.g. "AAPL", "federal reserve", "bitcoin"
        from_date: Start date ISO 8601 or relative "7d", "30d". Defaults to "7d".
        limit: Max articles (max 50). Defaults to 10.
        include_sentiment: Whether to attach per-article sentiment score. Defaults to true.
    """
    try:
        symbol = symbol.strip()
        if not symbol:
            return {"error": "Symbol or topic is required."}
        limit = max(1, min(limit, 50))

        cache_key = f"news:{symbol}:{from_date}:{limit}:{include_sentiment}"
        cached = _news_cache.get(cache_key)
        if cached is not None:
            return cached

        resolved_from = _resolve_from_date(from_date)
        to_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        articles = await _pool.fetch_news(symbol, resolved_from, to_date, limit)
        articles, overall_score = _attach_sentiment(articles, include_sentiment)

        result: dict = {
            "query": symbol,
            "articles": articles,
            "articleCount": len(articles),
        }
        if include_sentiment and overall_score is not None:
            result["overallSentiment"] = {
                "score": overall_score,
                "label": score_to_label(overall_score),
                "articleCount": len(articles),
            }

        _news_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[news] error: {e}")
        return {"error": f"Unable to fetch news for '{symbol}' — {e}"}


# ── Tool 2: get_sentiment_score ──────────────────────────────────


@mcp.tool()
async def get_sentiment_score(
    symbol: str,
    window: str = "7d",
) -> dict:
    """Get aggregated sentiment score for a ticker over a time window.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "BTC"
        window: Time window: "1d", "3d", "7d", "30d". Defaults to "7d".
    """
    try:
        symbol = symbol.strip().upper()
        if not symbol:
            return {"error": "Symbol is required."}
        if window not in _VALID_WINDOWS:
            return {
                "error": f"Invalid window '{window}'. Must be one of: {', '.join(sorted(_VALID_WINDOWS))}"
            }

        cache_key = f"sentiment:{symbol}:{window}"
        cached = _sentiment_cache.get(cache_key)
        if cached is not None:
            return cached

        days = _WINDOW_DAYS[window]
        from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime(
            "%Y-%m-%d"
        )
        to_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        articles = await _pool.fetch_news(symbol, from_date, to_date, 50)

        if not articles:
            result = {
                "symbol": symbol,
                "window": window,
                "score": 0.0,
                "label": "neutral",
                "trend": "stable",
                "sampleSize": 0,
            }
            _sentiment_cache.set(cache_key, result)
            return result

        scores = []
        for article in articles:
            text = f"{article.get('title', '')} {article.get('summary', '')}"
            scores.append(score_text(text))

        avg_score = round(sum(scores) / len(scores), 4)
        result = {
            "symbol": symbol,
            "window": window,
            "score": avg_score,
            "label": score_to_label(avg_score),
            "trend": compute_trend(scores),
            "sampleSize": len(scores),
        }

        _sentiment_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[news] error: {e}")
        return {"error": f"Unable to compute sentiment for '{symbol}' — {e}"}


# ── Tool 3: get_trending_tickers ─────────────────────────────────


@mcp.tool()
async def get_trending_tickers(
    market: str = "all",
    limit: int = 10,
) -> dict:
    """Get currently trending tickers based on news volume spike.

    Args:
        market: Market filter: "stocks", "crypto", "all". Defaults to "all".
        limit: Number of results. Defaults to 10.
    """
    try:
        if market not in _VALID_MARKETS:
            return {
                "error": f"Invalid market '{market}'. Must be one of: {', '.join(sorted(_VALID_MARKETS))}"
            }
        limit = max(1, min(limit, 50))

        cache_key = f"trending:{market}:{limit}"
        cached = _trending_cache.get(cache_key)
        if cached is not None:
            return cached

        tickers: list[dict] = []

        if market in ("stocks", "all"):
            try:
                articles = await _pool.fetch_general_news("general", 50)
                symbol_counts: dict[str, int] = {}
                symbol_scores: dict[str, list[float]] = {}
                for a in articles:
                    for sym in a.get("symbols", []):
                        if sym:
                            symbol_counts[sym] = symbol_counts.get(sym, 0) + 1
                            text = f"{a.get('title', '')} {a.get('summary', '')}"
                            symbol_scores.setdefault(sym, []).append(score_text(text))
                for sym, count in sorted(
                    symbol_counts.items(), key=lambda x: x[1], reverse=True
                )[:limit]:
                    scores = symbol_scores.get(sym, [0])
                    avg = sum(scores) / len(scores)
                    tickers.append(
                        {
                            "symbol": sym,
                            "name": "",
                            "newsCount": count,
                            "sentimentScore": round(avg, 4),
                            "volumeSpike": count,
                        }
                    )
            except Exception:
                pass

        if market in ("crypto", "all"):
            try:
                trending = await _pool.fetch_trending_crypto(limit)
                for coin in trending:
                    tickers.append(
                        {
                            "symbol": coin["symbol"],
                            "name": coin.get("name", ""),
                            "newsCount": 0,
                            "sentimentScore": 0.0,
                            "volumeSpike": coin.get("score", 0),
                        }
                    )
            except Exception:
                pass

        result = {"tickers": tickers[:limit], "market": market}

        _trending_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[news] error: {e}")
        return {"error": f"Unable to fetch trending tickers — {e}"}


# ── Tool 4: get_earnings_sentiment ───────────────────────────────


@mcp.tool()
async def get_earnings_sentiment(symbol: str) -> dict:
    """Get pre/post earnings sentiment analysis for a ticker.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "MSFT"
    """
    try:
        symbol = symbol.strip().upper()
        if not symbol:
            return {"error": "Symbol is required."}

        cache_key = f"earnings_sentiment:{symbol}"
        cached = _earnings_cache.get(cache_key)
        if cached is not None:
            return cached

        calendar = await _pool.fetch_earnings_calendar(symbol)

        if not calendar:
            return {
                "symbol": symbol,
                "error": f"No earnings data found for {symbol}.",
            }

        last_earnings = calendar[0]
        earnings_date = last_earnings.get("date", "")
        if not earnings_date:
            return {"symbol": symbol, "error": "No earnings date available."}

        earnings_dt = datetime.fromisoformat(earnings_date)
        pre_from = (earnings_dt - timedelta(days=7)).strftime("%Y-%m-%d")
        pre_to = earnings_date
        post_from = earnings_date
        post_to = (earnings_dt + timedelta(days=7)).strftime("%Y-%m-%d")

        pre_articles = await _pool.fetch_news(symbol, pre_from, pre_to, 30)
        post_articles = await _pool.fetch_news(symbol, post_from, post_to, 30)

        def _compute_sentiment(articles: list[dict]) -> dict:
            if not articles:
                return {"score": 0.0, "label": "neutral", "sampleSize": 0}
            scores = [
                score_text(f"{a.get('title', '')} {a.get('summary', '')}")
                for a in articles
            ]
            avg = round(sum(scores) / len(scores), 4)
            return {
                "score": avg,
                "label": score_to_label(avg),
                "sampleSize": len(scores),
            }

        result = {
            "symbol": symbol,
            "lastEarningsDate": earnings_date,
            "preSentiment": _compute_sentiment(pre_articles),
            "postSentiment": _compute_sentiment(post_articles),
        }

        _earnings_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[news] error: {e}")
        return {"error": f"Unable to fetch earnings sentiment for '{symbol}' — {e}"}


def main() -> None:
    mcp.run()
