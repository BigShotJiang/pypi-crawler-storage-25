"""News & Sentiment MCP server."""
