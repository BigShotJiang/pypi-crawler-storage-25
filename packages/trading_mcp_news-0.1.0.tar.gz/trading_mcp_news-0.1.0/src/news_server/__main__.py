"""Entry point: uv run python -m news_server"""

from news_server.server import mcp

mcp.run()
