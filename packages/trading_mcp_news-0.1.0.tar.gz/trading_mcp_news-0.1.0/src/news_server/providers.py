"""News data providers with failover."""

import os
import time
from datetime import datetime, timedelta, timezone

import httpx

from trading_mcp_shared.errors import ProviderError, RateLimitError

_TIMEOUT = 5.0


# ── Circuit breaker (same pattern as market_data) ────────────────


class CircuitBreaker:
    def __init__(self, threshold: int = 3, window: float = 60.0):
        self._threshold = threshold
        self._window = window
        self._failures: dict[str, list[float]] = {}

    def record_failure(self, provider: str) -> None:
        now = time.monotonic()
        fails = self._failures.setdefault(provider, [])
        fails.append(now)
        cutoff = now - self._window
        self._failures[provider] = [t for t in fails if t > cutoff]

    def is_open(self, provider: str) -> bool:
        fails = self._failures.get(provider, [])
        cutoff = time.monotonic() - self._window
        recent = [t for t in fails if t > cutoff]
        self._failures[provider] = recent
        return len(recent) >= self._threshold

    def reset(self, provider: str) -> None:
        self._failures.pop(provider, None)


_circuit = CircuitBreaker()


def _finnhub_key() -> str:
    return os.environ.get("FINNHUB_API_KEY", "")


def _coingecko_key() -> str:
    return os.environ.get("COINGECKO_API_KEY", "")


async def _request(
    client: httpx.AsyncClient,
    provider: str,
    url: str,
    params: dict | None = None,
    headers: dict | None = None,
) -> dict | list:
    resp = await client.get(url, params=params, headers=headers, timeout=_TIMEOUT)
    if resp.status_code == 429:
        raise RateLimitError(provider)
    if resp.status_code != 200:
        raise ProviderError(provider, f"HTTP {resp.status_code}", resp.status_code)
    return resp.json()


# ── Finnhub news ─────────────────────────────────────────────────


def _resolve_from_date(from_str: str) -> str:
    """Convert relative date strings like '7d' to ISO date, or pass through."""
    if not from_str:
        return (datetime.now(timezone.utc) - timedelta(days=7)).strftime("%Y-%m-%d")
    if from_str.endswith("d"):
        try:
            days = int(from_str[:-1])
            return (datetime.now(timezone.utc) - timedelta(days=days)).strftime(
                "%Y-%m-%d"
            )
        except ValueError:
            pass
    return from_str


async def _finnhub_company_news(
    client: httpx.AsyncClient,
    symbol: str,
    from_date: str,
    to_date: str,
    limit: int,
) -> list[dict]:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/company-news",
        params={
            "symbol": symbol.upper(),
            "from": from_date,
            "to": to_date,
            "token": key,
        },
    )
    articles = []
    for item in (data if isinstance(data, list) else [])[:limit]:
        articles.append(
            {
                "title": item.get("headline", ""),
                "summary": item.get("summary", ""),
                "url": item.get("url", ""),
                "source": item.get("source", ""),
                "publishedAt": datetime.fromtimestamp(
                    item.get("datetime", 0), tz=timezone.utc
                ).isoformat(),
                "symbols": [item.get("related", symbol.upper())],
            }
        )
    return articles


async def _finnhub_general_news(
    client: httpx.AsyncClient,
    category: str,
    limit: int,
) -> list[dict]:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/news",
        params={"category": category, "token": key},
    )
    articles = []
    for item in (data if isinstance(data, list) else [])[:limit]:
        articles.append(
            {
                "title": item.get("headline", ""),
                "summary": item.get("summary", ""),
                "url": item.get("url", ""),
                "source": item.get("source", ""),
                "publishedAt": datetime.fromtimestamp(
                    item.get("datetime", 0), tz=timezone.utc
                ).isoformat(),
                "symbols": [],
            }
        )
    return articles


# ── Finnhub earnings ─────────────────────────────────────────────


async def _finnhub_earnings_calendar(
    client: httpx.AsyncClient,
    symbol: str,
) -> list[dict]:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    one_year_ago = (datetime.now(timezone.utc) - timedelta(days=365)).strftime(
        "%Y-%m-%d"
    )
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/calendar/earnings",
        params={
            "symbol": symbol.upper(),
            "from": one_year_ago,
            "to": today,
            "token": key,
        },
    )
    return data.get("earningsCalendar", []) if isinstance(data, dict) else []


# ── CoinGecko news (trending coins as proxy) ────────────────────


async def _coingecko_trending(
    client: httpx.AsyncClient,
    limit: int,
) -> list[dict]:
    headers = {}
    key = _coingecko_key()
    if key:
        headers["x-cg-demo-key"] = key
    data = await _request(
        client,
        "coingecko",
        "https://api.coingecko.com/api/v3/search/trending",
        headers=headers,
    )
    results = []
    for coin_wrapper in (data.get("coins") or [])[:limit]:
        coin = coin_wrapper.get("item", {})
        results.append(
            {
                "symbol": (coin.get("symbol") or "").upper(),
                "name": coin.get("name", ""),
                "market_cap_rank": coin.get("market_cap_rank"),
                "score": coin.get("score", 0),
            }
        )
    return results


# ── NewsProviderPool ─────────────────────────────────────────────


class NewsProviderPool:
    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient()
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def _try_providers(
        self,
        providers: list[tuple[str, object]],
        *args: object,
    ) -> object:
        last_err: Exception | None = None
        for name, fn in providers:
            if _circuit.is_open(name):
                continue
            try:
                client = await self._get_client()
                result = await fn(client, *args)
                _circuit.reset(name)
                return result
            except Exception as exc:
                _circuit.record_failure(name)
                last_err = exc
        raise ProviderError("all", f"All providers failed: {last_err}")

    async def fetch_news(
        self,
        symbol: str,
        from_date: str,
        to_date: str,
        limit: int,
    ) -> list[dict]:
        providers = [("finnhub", _finnhub_company_news)]
        return await self._try_providers(providers, symbol, from_date, to_date, limit)

    async def fetch_general_news(self, category: str, limit: int) -> list[dict]:
        providers = [("finnhub", _finnhub_general_news)]
        return await self._try_providers(providers, category, limit)

    async def fetch_earnings_calendar(self, symbol: str) -> list[dict]:
        providers = [("finnhub", _finnhub_earnings_calendar)]
        return await self._try_providers(providers, symbol)

    async def fetch_trending_crypto(self, limit: int) -> list[dict]:
        providers = [("coingecko", _coingecko_trending)]
        return await self._try_providers(providers, limit)
