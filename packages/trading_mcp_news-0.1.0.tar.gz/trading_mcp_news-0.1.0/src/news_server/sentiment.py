"""Keyword-weighted sentiment engine — no ML dependencies in Stage 1.

Scores text from -1.0 (very bearish) to +1.0 (very bullish).
Transparent and explainable: every score traces back to matched terms.
Stage 2 upgrade path: swap for embeddings-based model.
"""

import re

# ── Term lists with weights ──────────────────────────────────────
# weight magnitude: 1.0 = strong signal, 0.5 = moderate, 0.3 = weak

_BULLISH_TERMS: list[tuple[str, float]] = [
    ("beat expectations", 1.0),
    ("beat estimates", 1.0),
    ("raised guidance", 1.0),
    ("record high", 1.0),
    ("strong growth", 0.8),
    ("record revenue", 0.8),
    ("record profit", 0.8),
    ("all-time high", 0.8),
    ("buyback", 0.7),
    ("stock split", 0.7),
    ("dividend increase", 0.7),
    ("upgrade", 0.7),
    ("outperform", 0.7),
    ("buy rating", 0.7),
    ("strong buy", 0.8),
    ("surge", 0.6),
    ("rally", 0.6),
    ("soar", 0.6),
    ("bullish", 0.6),
    ("breakout", 0.5),
    ("growth", 0.3),
    ("gain", 0.3),
    ("positive", 0.3),
    ("recovery", 0.4),
    ("momentum", 0.3),
    ("upbeat", 0.4),
    ("optimistic", 0.4),
    ("exceeded", 0.5),
    ("beat", 0.5),
    ("profit", 0.3),
    ("expansion", 0.3),
]

_BEARISH_TERMS: list[tuple[str, float]] = [
    ("lowered guidance", 1.0),
    ("missed expectations", 1.0),
    ("missed estimates", 1.0),
    ("debt warning", 1.0),
    ("bankruptcy", 1.0),
    ("fraud", 1.0),
    ("investigation", 0.8),
    ("sec probe", 0.9),
    ("downgrade", 0.7),
    ("underperform", 0.7),
    ("sell rating", 0.7),
    ("strong sell", 0.8),
    ("layoffs", 0.7),
    ("restructuring", 0.5),
    ("recall", 0.7),
    ("lawsuit", 0.6),
    ("decline", 0.5),
    ("bearish", 0.6),
    ("crash", 0.8),
    ("plunge", 0.7),
    ("tumble", 0.6),
    ("slump", 0.5),
    ("miss", 0.5),
    ("loss", 0.4),
    ("negative", 0.3),
    ("warning", 0.4),
    ("concern", 0.3),
    ("risk", 0.2),
    ("volatile", 0.2),
    ("uncertainty", 0.3),
    ("deficit", 0.4),
]


def score_text(text: str) -> float:
    """Score a single piece of text. Returns float in [-1.0, 1.0]."""
    lower = text.lower()

    bull_score = 0.0
    bear_score = 0.0

    for term, weight in _BULLISH_TERMS:
        count = len(re.findall(re.escape(term), lower))
        bull_score += count * weight

    for term, weight in _BEARISH_TERMS:
        count = len(re.findall(re.escape(term), lower))
        bear_score += count * weight

    total = bull_score + bear_score
    if total == 0:
        return 0.0

    raw = (bull_score - bear_score) / total
    return max(-1.0, min(1.0, raw))


def score_to_label(score: float) -> str:
    """Convert numeric score to human label."""
    if score >= 0.5:
        return "very_bullish"
    if score >= 0.15:
        return "bullish"
    if score > -0.15:
        return "neutral"
    if score > -0.5:
        return "bearish"
    return "very_bearish"


def compute_trend(scores: list[float]) -> str:
    """Determine trend from a time-ordered list of scores.

    Compares the mean of the first half to the second half.
    """
    if len(scores) < 2:
        return "stable"
    mid = len(scores) // 2
    first_half = sum(scores[:mid]) / mid
    second_half = sum(scores[mid:]) / len(scores[mid:])
    diff = second_half - first_half
    if diff > 0.1:
        return "improving"
    if diff < -0.1:
        return "deteriorating"
    return "stable"
