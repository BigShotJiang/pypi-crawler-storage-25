"""Riched package."""

