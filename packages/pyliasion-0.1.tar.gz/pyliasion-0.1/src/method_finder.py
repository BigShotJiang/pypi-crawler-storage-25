from dataclasses import dataclass
from typing import Any

do = dir(object())

@dataclass
class Field[T: object]:
	name: str
	tp: T

def findField(clz: type) -> list[Field]:
	for name, value in clz.__dict__.items():
		if name.startswith('__'): continue
		if name in do: continue
		print(name, value)

	for name, tp in clz.__annotations__.items():
		print(name, tp)

