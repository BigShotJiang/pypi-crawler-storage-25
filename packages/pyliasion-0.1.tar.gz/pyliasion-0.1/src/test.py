from decorations import ts
from method_finder import findField


@ts('some.ts')
class Some:
	x: int
	y: float

	def f(self):
		return 0

findField(Some)