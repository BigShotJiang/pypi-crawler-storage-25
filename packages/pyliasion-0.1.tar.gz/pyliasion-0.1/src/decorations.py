def language(lang: str):
	def deco(f):
		f.__language__ = lang
		return f
	return deco

@language('typescript')
def ts(file: str):
	def deco(clz: type):
		clz.__is_stub__ = True
		clz.__language__ = 'typescript'
		return clz
	return deco

@language('javascript')
def ts(file: str):
	def deco(clz: type):
		clz.__is_stub__ = True
		clz.__language__ = 'javascript'
		return clz
	return deco