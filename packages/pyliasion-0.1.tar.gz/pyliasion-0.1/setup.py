from setuptools import setup

setup(
	name = 'pyliasion',
	version = '0.1',
)