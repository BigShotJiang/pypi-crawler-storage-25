import importlib.util

def check_dependencies(*packages):
    """
    Check if required packages are installed.
    Throws a descriptive error if not.
    """
    missing = []
    for pkg in packages:
        if importlib.util.find_spec(pkg) is None:
            missing.append(pkg)

    if missing:
        missing_str = ", ".join(missing)
        raise ImportError(
            f"Missing required packages for unifiedefficientloader: {missing_str}. "
            f"Please install them using: pip install {missing_str}"
        )

# Pre-check torch as it is the foundation of most of these tools
check_dependencies("torch")

from .memory_efficient_loader import UnifiedSafetensorsLoader, MemoryEfficientSafeOpen
from .incremental_writer import IncrementalSafetensorsWriter
from .unified_data_loader import UnifiedDataLoader
from .tensor_utils import dict_to_tensor, tensor_to_dict, torch_to_st_dtype, st_to_torch_dtype
from .pinned_transfer import transfer_to_gpu_pinned, set_verbose, get_pinned_transfer_stats, reset_pinned_transfer_stats
from .gpu_buffer_pool import GpuBufferPool
from .pinned_buffer_pool import PinnedBufferPool
from .logging_utils import (
    setup_logging,
    MINIMAL_LEVEL,
    NORMAL_LEVEL,
    VERBOSE_LEVEL,
    DEBUG_LEVEL,
    debug,
    verbose,
    normal,
    info,
    minimal,
    warning,
    error
)

__all__ = [
    "UnifiedSafetensorsLoader",
    "IncrementalSafetensorsWriter",
    "UnifiedDataLoader",
    "MemoryEfficientSafeOpen",
    "dict_to_tensor",
    "tensor_to_dict",
    "torch_to_st_dtype",
    "st_to_torch_dtype",
    "transfer_to_gpu_pinned",
    "set_verbose",
    "get_pinned_transfer_stats",
    "reset_pinned_transfer_stats",
    "GpuBufferPool",
    "PinnedBufferPool",
    "setup_logging",
    "MINIMAL_LEVEL",
    "NORMAL_LEVEL",
    "VERBOSE_LEVEL",
    "DEBUG_LEVEL",
    "debug",
    "verbose",
    "normal",
    "info",
    "minimal",
    "warning",
    "error",
]
