import json
import logging
import mimetypes
import os
import pkgutil
from functools import partial

import dash
import flask
import plotly
# import dash_renderer
#import dash_core_components as dcc
from dash import *
from dash import dcc
from dash._utils import format_tag, stringify_id
from dash.version import __version__

from .utilities import APP_ID, BASE_API_URL, is_authenticated

logger = logging.getLogger(__name__)

# Dash internal endpoints that should return 400 on errors (not 500)
# These are endpoints managed by Dash framework, not custom app routes
DASH_INTERNAL_ENDPOINTS = [
    '/_dash-update-component',    # POST - callback execution (CRITICAL)
    '/_dash-layout',              # GET - layout retrieval (HIGH)
    '/_dash-dependencies',        # GET - callback info (MEDIUM)
    '/_dash-component-suites',    # GET - component JS/CSS (MEDIUM)
]

class OAPDash(dash.Dash):
    static_files = {
        'css': [
            'main.wrapper.css'
        ]
    }

    def __init__(self, **kwargs):
        self.route = kwargs.pop('route')
        self.app_id = ''
        self.run_id = ''
        self.in_store_id = '_in_'
        self.out_store_id = '_out_'

        route_prefix = f'/{self.route}' if self.route else ''
        # assume this is not set by user
        kwargs['requests_pathname_prefix'] = f'{route_prefix}/'

        super(OAPDash, self).__init__(**kwargs)

    def init_app(self, app=None):
        """
        called when the app is initiated, called only once
        register api endpoints, custom static resources, and error handlers
        """
        super(OAPDash, self).init_app(app)

        # register manifest files
        self._add_url("opsramp-analytics-utils/<string:file_name>", self.serve_resource)

    def _is_dash_internal_request(self):
        """
        Check if the current Flask request is to a Dash internal endpoint.

        Returns:
            bool: True if request path matches a Dash internal endpoint pattern
        """
        try:
            path = flask.request.path
            return any(pattern in path for pattern in DASH_INTERNAL_ENDPOINTS)
        except RuntimeError:
            # Outside request context
            return False

    def _register_error_handlers(self):
        """
        Register Flask error handlers for graceful error responses on Dash internal endpoints.

        This method (ITOM-113203):
        - Catches exceptions on Dash internal endpoints (/_dash-update-component, etc.)
        - Returns HTTP 400 with JSON error response instead of HTTP 500
        - Preserves debug mode behavior for development
        - Re-raises exceptions for non-Dash endpoints to preserve existing behavior
        """

        @self.server.errorhandler(Exception)
        def handle_exception(e):
            """
            Global exception handler that only intercepts Dash internal endpoint errors.
            """
            # Preserve Dash debug mode behavior for development
            dev_tools = getattr(self, '_dev_tools', {})
            if isinstance(dev_tools, dict) and dev_tools.get('ui', False):
                raise e

            # Only handle Dash internal endpoint errors
            if self._is_dash_internal_request():
                logger.warning(
                    f"Dash internal endpoint error [{flask.request.path}]: "
                    f"{type(e).__name__}: {str(e)}"
                )
                return flask.jsonify({
                    'error': 'Bad Request',
                    'message': 'Invalid or malformed request'
                }), 400

            # Re-raise for non-Dash endpoints to preserve existing behavior
            raise e

    def index(self, *args, **kwargs):  # pylint: disable=unused-argument
        logger.info("verifying authentication")
        print("verifying authentication")
        is_auth = is_authenticated()
        if ('path' in kwargs and 'server/status' in kwargs['path'] ):
            logger.info("server is up and running")
            print("server is up and running")
            return 'server is up and running', 200
        elif is_auth:
            if is_auth == 'no_reports_view_permission':
                logger.info("Access denied: You are authenticated but lack the required reports permissions.")
                print("Access denied: You are authenticated but lack the required reports permissions.")
                return flask.Response('Access denied: You are authenticated but lack the required reports permissions.', status=403)

            logger.info("authentication is successful")
            print("authentication is successful")
            # resp = self._index(args, kwargs)
            resp = super(OAPDash, self).index(*args, **kwargs)
            return resp
        else:
            # return flask.Response('Not authorized', status=401)
            redirect_url = BASE_API_URL + f'/tenancy/web/login?cb=/loginResponse.do'
            logger.info("authentication is failed, redirecting to login url is %s", redirect_url)
            print("authentication is failed, redirecting to login url is ", redirect_url)
            return flask.redirect(redirect_url, code=302)

    def serve_resource(self, file_name):
        if file_name == 'main.css':
            return self._serve_main_css()
        else:
            extension = "." + file_name.split(".")[-1]
            mimetype = mimetypes.types_map.get(extension, "application/octet-stream")

            return flask.Response(
                pkgutil.get_data('dash_core_components', file_name), mimetype=mimetype
            )

    def _serve_main_css(self):
        body = ''

        # TODO: external css files using requests
        external_links = self.config.external_stylesheets

        # oap css files
        for file_path in self.static_files['css']:
            body += pkgutil.get_data('analytics_sdk', 'analysis-wrapper/'+file_path).decode("utf-8")
        body = body.replace('url(/static/media', f'url({self.config.requests_pathname_prefix}wrapper-static/media')

        # custom css files
        for resource in self.css.get_all_css():
            file_name = resource['asset_path']
            body += open(self.config.assets_folder+'/'+file_name).read()

        response = flask.Response(body, mimetype='text/css')

        return response

    def get_component_ids(self, layout):
        component_ids = []
        for component in layout._traverse():
            component_id = stringify_id(getattr(component, "id", None))
            component_ids.append(component_id)

        return component_ids

    def _layout_value(self):
        """
        add custom stores
        """
        _layout = self._layout() if self._layout_is_function else self._layout                        

        component_ids = self.get_component_ids(_layout)
        
        if self.in_store_id not in component_ids:
            _layout.children.append(dcc.Store(id="dummy-store"))
            if self.in_store_id is not None:
                _layout.children.append(dcc.Store(id=self.out_store_id, storage_type="local"))
            if self.out_store_id is not None:
                _layout.children.append(dcc.Store(id=self.in_store_id, storage_type="local"))
            _layout.children.append(dcc.Store(id='op-filter-start-date', storage_type="local"))
            _layout.children.append(dcc.Store(id='op-filter-end-date'))

        return _layout

    def _generate_css_dist_html(self):
        return f'<link rel="stylesheet" href="{self.config.requests_pathname_prefix}opsramp-analytics-utils/main.css">'