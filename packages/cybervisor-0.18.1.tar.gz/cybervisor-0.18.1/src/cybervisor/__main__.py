from cybervisor.cli import main

raise SystemExit(main())
