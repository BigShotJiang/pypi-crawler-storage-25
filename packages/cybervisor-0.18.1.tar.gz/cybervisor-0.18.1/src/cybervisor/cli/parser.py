"""Argument parser and prompt resolution."""

from __future__ import annotations

import argparse
import sys

_EXIT_CODES_EPILOG = """Exit codes:
  0   Success (pipeline completed)
  1   General error (config error, agent failure, etc.)
  2   Configuration validation error
  130 Interrupted (SIGINT/SIGTERM received)"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cybervisor", epilog=_EXIT_CODES_EPILOG, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", action="store_true", help="Show version and exit")
    parser.add_argument("--quiet", action="store_true", help="Suppress non-error stderr output for all commands")

    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Run the cybervisor pipeline")
    _add_run_arguments(run_parser)

    init_parser = subparsers.add_parser("init", help="Create a cybervisor.yaml scaffold")
    init_parser.add_argument("--template", default=None, choices=["simple", "speckit"], help="Select the scaffold template explicitly (accepted values: simple, speckit)")

    def _init_error(message: str) -> None:
        init_parser.exit(status=1, message=message)

    init_parser.error = _init_error  # type: ignore[method-assign, assignment]
    init_parser.add_argument("--force", action="store_true", help="Replace an existing cybervisor.yaml explicitly")
    serve_parser = subparsers.add_parser("serve", help="Start the cybervisor daemon server")
    serve_parser.add_argument("--host", default=None, help="Host to bind the server to (default: ~/.cybervisor/config.yaml server.host or 127.0.0.1)")
    serve_parser.add_argument("--port", type=int, default=None, help="Port to bind the server to (default: ~/.cybervisor/config.yaml server.port or 8765)")
    serve_parser.add_argument("--background", action="store_true", help="Run the server in the background")
    sandbox_parser = subparsers.add_parser("sandbox", help="Launch cybervisor daemon in an isolated Docker container")
    sandbox_parser.add_argument("--host", default="127.0.0.1", help="Host address to bind on the host machine (default: 127.0.0.1)")
    sandbox_parser.add_argument("--port", type=int, default=8765, help="Host port to expose (default: 8765)")
    sandbox_parser.add_argument("--background", action="store_true", help="Run container in background")
    sandbox_parser.add_argument("--image", default="ghcr.io/crzidea/cybervisor:latest", help="Docker image to use (default: ghcr.io/crzidea/cybervisor:latest)")
    sandbox_parser.add_argument("--no-pull", action="store_true", help="Skip automatic image pull; use local image as-is")
    sandbox_parser.add_argument("--name", default=None, help="Container name (default: cybervisor-sandbox-<cwd_hash>)")
    subparsers.add_parser("doctor", help="Verify LLM verifier credentials")
    validate_parser = subparsers.add_parser("validate", help="Validate one or more cybervisor config files")
    validate_parser.add_argument("paths", nargs="*", help="Config file paths to validate")
    validate_parser.add_argument(
        "--show-guidance",
        action="store_true",
        help="Print generated contract guidance prompts for contract-enabled stages",
    )
    docs_parser = subparsers.add_parser(
        "docs",
        help="Read canonical cybervisor documentation",
        usage="cybervisor docs <document>",
        description="Read canonical cybervisor documentation by document identifier.",
    )
    docs_parser.add_argument("document", nargs="?", help="Document identifier to read")
    use_parser = subparsers.add_parser("use", help="Set the global default runtime agent")
    use_parser.add_argument("agent_tool", help="Agent tool to remember in ~/.cybervisor/config.yaml")
    subparsers.add_parser("restore-skills", help="Restore disabled skills from backup")

    # status subcommand
    status_parser = subparsers.add_parser("status", help="Ping the daemon and report connectivity")
    status_parser.add_argument("task_id", nargs="?", default=None, help="Task ID to query (optional)")
    status_parser.add_argument("--host", default=None, help="Host to connect to")
    status_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # submit subcommand
    submit_parser = subparsers.add_parser("submit", help="Submit a task to the daemon for async execution")
    submit_parser.add_argument("prompt", nargs="?", default=None, help="Task description to execute")
    submit_parser.add_argument("--config", default="cybervisor.yaml", help="Path to cybervisor.yaml")
    submit_parser.add_argument("--start-stage", default=None, help="Stage name to skip to and begin execution at")
    submit_parser.add_argument("--end-after", default=None, help="Stage name to stop at (stage executes; stop can be updated via end)")
    submit_parser.add_argument("--end-before", default=None, help="Stage name to stop before")
    submit_parser.add_argument("--task-id", default=None, help="Explicit task ID (auto-generated if omitted)")
    submit_parser.add_argument("--host", default=None, help="Host to connect to")
    submit_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # attach subcommand
    attach_parser = subparsers.add_parser("attach", help="Reconnect to a running or completed task")
    attach_parser.add_argument("task_id", nargs="?", default=None, help="Task ID to attach to (optional — defaults to active task in current directory)")
    attach_parser.add_argument("--host", default=None, help="Host to connect to")
    attach_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # cancel subcommand
    cancel_parser = subparsers.add_parser("cancel", help="Cancel an active task")
    cancel_parser.add_argument("task_id", nargs="?", default=None, help="Task ID to cancel (optional — defaults to active task in current directory)")
    cancel_parser.add_argument("--host", default=None, help="Host to connect to")
    cancel_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # logs subcommand
    logs_parser = subparsers.add_parser("logs", help="Dump buffered events as JSON Lines")
    logs_parser.add_argument("task_id", help="Task ID to dump logs for")
    logs_parser.add_argument("--host", default=None, help="Host to connect to")
    logs_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # end subcommand
    end_parser = subparsers.add_parser("end", help="Set the end stage for a running task")
    end_parser.add_argument("task_id", nargs="?", default=None, help="Task ID to target (optional — defaults to active task in current directory)")
    end_parser.add_argument("--after", default=None, help="Stage name to stop after (stage executes, then pipeline halts)")
    end_parser.add_argument("--before", default=None, help="Stage name to stop before (named stage is skipped)")
    end_parser.add_argument("--host", default=None, help="Host to connect to")
    end_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # completion subcommand
    completion_parser = subparsers.add_parser("completion", help="Generate shell completion script")
    completion_parser.add_argument("shell", nargs="?", default="bash", choices=["bash"], help="Shell type (default: bash)")

    return parser


def _add_run_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("prompt", nargs="?", help="Task description to execute")
    parser.add_argument("--config", default="cybervisor.yaml", help="Path to config YAML")
    parser.add_argument("--start-stage", help="Stage name to skip to and begin execution at")
    parser.add_argument("--end-after", help="Stage name to stop at (stage executes; stop can be updated via end)")
    parser.add_argument("--end-before", help="Stage name to stop before")


def _prepare_argv(argv: list[str] | None) -> list[str]:
    raw_args = list(argv) if argv is not None else sys.argv[1:]
    if not raw_args:
        if argv is None and not sys.stdin.isatty():
            return ["run"]
        return raw_args

    first = raw_args[0]
    if first in {
        "run",
        "init",
        "doctor",
        "validate",
        "docs",
        "use",
        "serve",
        "sandbox",
        "status",
        "submit",
        "attach",
        "cancel",
        "logs",
        "end",
        "restore-skills",
        "completion",
        "-h",
        "--help",
        "--version",
    }:
        return raw_args
    return ["run", *raw_args]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse arguments, extracting --quiet before argparse to avoid subparser conflicts."""
    # Attempt argcomplete-based tab completion before parsing.
    try:
        import argcomplete  # type: ignore[import-not-found]
    except ImportError:
        argcomplete = None

    raw_args = list(argv) if argv is not None else sys.argv[1:]
    quiet = False

    # Extract --quiet from raw_args before passing to _prepare_argv.
    if raw_args:
        cleaned: list[str] = []
        for arg in raw_args:
            if arg == "--quiet":
                quiet = True
                continue
            cleaned.append(arg)
        processed = _prepare_argv(cleaned)
    else:
        # No arguments provided. Handle bare invocation with piped stdin.
        if argv is None and not sys.stdin.isatty():
            parser = build_parser()
            namespace = parser.parse_args(["run"])
            namespace.quiet = False
            return namespace
        parser = build_parser()
        namespace = parser.parse_args(raw_args)
        namespace.quiet = False
        return namespace

    parser = build_parser()
    if argcomplete is not None:
        from cybervisor.cli.completions import register_completers

        register_completers(parser)
    namespace = parser.parse_args(processed)
    namespace.quiet = quiet
    return namespace


def _resolve_prompt(args: argparse.Namespace) -> tuple[str, str | None]:
    prompt = getattr(args, "prompt", None)
    if isinstance(prompt, str):
        return prompt, "positional prompt"

    stdin = sys.stdin
    try:
        stdin_is_tty = stdin.isatty()
    except OSError:
        stdin_is_tty = True

    if not stdin_is_tty:
        try:
            stdin_prompt = stdin.read()
        except OSError:
            return "", None
        if stdin_prompt.strip():
            return stdin_prompt, "stdin"

    return "", None
