"""Bash completion support for cybervisor CLI.

Provides both argcomplete integration (eval-based) and a static
completion script generator (source-based).
"""

from __future__ import annotations

import argparse

from yaml import YAMLError


def complete_agent_tools(
    prefix: str, action: argparse.Action, parser: argparse.ArgumentParser, parsed_args: argparse.Namespace
) -> list[str]:
    """Complete agent tool names from the adapter registry."""
    try:
        from cybervisor.adapters.registry import supported_agent_names

        return [name for name in supported_agent_names() if name.startswith(prefix)]
    except (ImportError, KeyError):
        return []


def complete_stage_names(
    prefix: str, action: argparse.Action, parser: argparse.ArgumentParser, parsed_args: argparse.Namespace
) -> list[str]:
    """Complete stage names from cybervisor.yaml in the current directory."""
    try:
        from cybervisor.config import load_config

        config = load_config("cybervisor.yaml")
        return [s.name for s in config.stages if s.name.startswith(prefix)]
    except (FileNotFoundError, YAMLError, ValueError, KeyError):
        return []


def complete_documents(
    prefix: str, action: argparse.Action, parser: argparse.ArgumentParser, parsed_args: argparse.Namespace
) -> list[str]:
    """Complete document identifiers."""
    try:
        from cybervisor.cli.docs import list_document_ids

        return [d for d in list_document_ids() if d.startswith(prefix)]
    except (ImportError, AttributeError):
        return []


def register_completers(parser: argparse.ArgumentParser) -> None:
    """Attach argcomplete completers to parser arguments.

    Safe to call even when argcomplete is not installed — the completer
    functions are only invoked by argcomplete at completion time.
    """
    try:
        import argcomplete  # type: ignore[import-not-found]
    except ImportError:
        return

    for action in parser._actions:
        if not isinstance(action, argparse._SubParsersAction):
            continue
        for _name, subparser in action.choices.items():
            for sub_action in subparser._actions:
                _wire_action_completer(sub_action, subparser)
        break

    argcomplete.autocomplete(parser)


def _wire_action_completer(action: argparse.Action, parser: argparse.ArgumentParser) -> None:
    """Wire a completer function to a single argparse action by dest name."""
    try:
        import argcomplete
    except ImportError:
        return

    dest = getattr(action, "dest", None)
    if dest == "agent_tool":
        argcomplete.add_completer(action, completer=complete_agent_tools)
    elif dest in ("start_stage", "end_after", "end_before"):
        argcomplete.add_completer(action, completer=complete_stage_names)
    elif dest == "document":
        argcomplete.add_completer(action, completer=complete_documents)
    elif dest == "template":
        choices = getattr(action, "choices", None)
        if choices:
            argcomplete.add_completer(action, completer=lambda *a, **kw: list(choices))


def generate_bash_completion(parser: argparse.ArgumentParser | None = None) -> str:
    """Generate a standalone bash completion script for cybervisor.

    Covers all subcommands and their static flags/choices. Dynamic
    completions (stage names, task IDs) fall back to the default
    file-completion handler.
    """
    subcommands = [
        "run", "init", "serve", "sandbox", "doctor", "validate",
        "docs", "use", "restore-skills", "status", "submit",
        "attach", "cancel", "logs", "end", "completion",
    ]

    global_flags = ["--version", "--quiet", "-h", "--help"]

    subcommand_flags: dict[str, list[str]] = {
        "run": ["--config", "--start-stage", "--end-after", "--end-before", "-h", "--help"],
        "init": ["--template", "--force", "-h", "--help"],
        "serve": ["--host", "--port", "--background", "-h", "--help"],
        "sandbox": ["--host", "--port", "--background", "--image", "--no-pull", "--name", "-h", "--help"],
        "doctor": ["-h", "--help"],
        "validate": ["--show-guidance", "-h", "--help"],
        "docs": ["-h", "--help"],
        "use": ["-h", "--help"],
        "restore-skills": ["-h", "--help"],
        "status": ["--host", "--port", "-h", "--help"],
        "submit": ["--config", "--start-stage", "--end-after", "--end-before", "--task-id", "--host", "--port", "-h", "--help"],
        "attach": ["--host", "--port", "-h", "--help"],
        "cancel": ["--host", "--port", "-h", "--help"],
        "logs": ["--host", "--port", "-h", "--help"],
        "end": ["--after", "--before", "--host", "--port", "-h", "--help"],
        "completion": ["-h", "--help"],
    }

    template_choices: list[str] = ["simple", "speckit"]
    shell_choices: list[str] = ["bash"]

    if parser is None:
        try:
            from cybervisor.cli.parser import build_parser

            parser = build_parser()
        except Exception:
            parser = None

    if parser is not None:
        for action in parser._actions:
            if not isinstance(action, argparse._SubParsersAction):
                continue
            sub_choices = action.choices
            init_parser = sub_choices.get("init")
            if init_parser is not None:
                for init_action in init_parser._actions:
                    if getattr(init_action, "dest", None) == "template" and init_action.choices:
                        template_choices = list(init_action.choices)
            completion_parser = sub_choices.get("completion")
            if completion_parser is not None:
                for comp_action in completion_parser._actions:
                    if getattr(comp_action, "dest", None) == "shell" and comp_action.choices:
                        shell_choices = list(comp_action.choices)
            break

    lines = [
        "# bash completion for cybervisor",
        "_cybervisor() {",
        "  local cur prev words cword",
        "  _init_completion || return",
        "",
        "  local subcommands='" + " ".join(subcommands) + "'",
        "  local global_flags='" + " ".join(global_flags) + "'",
        "",
        "  # Determine subcommand",
        "  local subcommand=",
        "  for ((i=1; i < ${#words[@]}; i++)); do",
        "    if [[ ${words[i]} != -* ]]; then",
        "      subcommand=${words[i]}",
        "      break",
        "    fi",
        "  done",
        "",
        "  # Complete subcommands and global flags",
        '  if [[ -z "$subcommand" ]]; then',
        "    case $cur in",
        "      -*) COMPREPLY=($(compgen -W '$global_flags' -- $cur)) ;;",
        "      *)  COMPREPLY=($(compgen -W '$subcommands' -- $cur)) ;;",
        "    esac",
        "    return",
        "  fi",
        "",
    ]

    lines.append("  # Subcommand-specific flag completion")
    lines.append("  case $subcommand in")
    for cmd in subcommands:
        flags = subcommand_flags.get(cmd, [])
        flags_str = " ".join(flags)
        lines.append(f"    {cmd})")
        lines.append("      case $cur in")
        lines.append(f"        -*) COMPREPLY=($(compgen -W '{flags_str}' -- $cur)) ;;")
        if cmd == "init":
            lines.append("      esac")
            lines.append("      case $prev in")
            template_str = " ".join(template_choices)
            lines.append(f"        --template) COMPREPLY=($(compgen -W '{template_str}' -- $cur)) ;;")
        elif cmd == "completion":
            lines.append("      esac")
            lines.append("      case $prev in")
            shell_str = " ".join(shell_choices)
            lines.append(f"        completion) COMPREPLY=($(compgen -W '{shell_str}' -- $cur)) ;;")
        else:
            lines.append("      esac")
        lines.append("      ;;")
    lines.append("  esac")
    lines.append("}")
    lines.append("")
    lines.append("complete -F _cybervisor cybervisor")

    return "\n".join(lines) + "\n"