"""Instance lock and runtime file management for the CLI."""

from __future__ import annotations

import json
import os
from pathlib import Path



_INSTANCE_LOCK_PATH = ".cybervisor/instance.lock"


def _instance_lock_path() -> Path:
    return Path(_INSTANCE_LOCK_PATH)


def _read_instance_lock() -> dict[str, object] | None:
    lock_path = _instance_lock_path()
    if not lock_path.exists():
        return None
    try:
        content = lock_path.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            return data
        return None
    except (json.JSONDecodeError, OSError):
        return None


def _write_instance_lock(pid: int) -> None:
    lock_path = _instance_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": pid,
        "cwd": os.getcwd(),
        "started_at": __import__("datetime").datetime.now().isoformat(),
    }
    # Use O_CREAT | O_EXCL for atomic lock acquisition
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    fd = os.open(lock_path, flags, 0o644)
    try:
        os.write(fd, json.dumps(payload).encode("utf-8"))
    finally:
        os.close(fd)


def _remove_instance_lock() -> None:
    _instance_lock_path().unlink(missing_ok=True)


def _is_instance_alive(lock: dict[str, object]) -> bool:
    pid = lock.get("pid")
    if not isinstance(pid, int):
        return False
    cwd = lock.get("cwd")
    if not isinstance(cwd, str):
        return False
    # Check if cwd matches current directory
    if os.getcwd() != cwd:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _check_single_instance() -> bool:
    from cybervisor.logging import CybervisorLogger

    logger = CybervisorLogger()
    lock = _read_instance_lock()
    if lock is not None and _is_instance_alive(lock):
        pid = lock.get("pid")
        logger.log_to_stderr(
            f"Another cybervisor instance (pid={pid}) is already running in this directory. Exiting to prevent concurrent execution.",
            "error",
        )
        return False
    # Remove stale lock if present
    _remove_instance_lock()
    try:
        _write_instance_lock(os.getpid())
    except OSError as exc:
        logger.log_to_stderr(f"Failed to acquire instance lock: {exc}. Another instance may have been started concurrently.", "error")
        return False
    return True


def _runtime_dir() -> Path:
    return Path(".cybervisor")


def _process_id_file() -> Path:
    return _runtime_dir() / "process-id"


def _process_group_file() -> Path:
    return _runtime_dir() / "process-group-id"


def _process_group_id() -> int | None:
    if not hasattr(os, "getpgid"):
        return None
    return os.getpgid(os.getpid())


def _write_runtime_files() -> None:
    runtime_dir = _runtime_dir()
    runtime_dir.mkdir(parents=True, exist_ok=True)
    process_group_id = _process_group_id()
    _process_id_file().write_text(f"{os.getpid()}\n", encoding="utf-8")
    if process_group_id is not None:
        _process_group_file().write_text(f"{process_group_id}\n", encoding="utf-8")


def _remove_runtime_files() -> None:
    _process_id_file().unlink(missing_ok=True)
    _process_group_file().unlink(missing_ok=True)
