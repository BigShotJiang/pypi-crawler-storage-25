"""Daemon-related CLI commands: serve, status, submit, attach, cancel, logs, end."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cybervisor.client import (
    run_attach_command,
    run_cancel_command,
    run_end_command,
    run_logs_command,
    run_status_command,
    run_submit_command,
)
from cybervisor.logging import CybervisorLogger

if TYPE_CHECKING:
    import argparse


async def _run_status_command(args: argparse.Namespace) -> int:
    return await run_status_command(host=args.host, port=args.port, task_id=args.task_id or None)


async def _run_submit_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger(quiet=args.quiet)
    if args.end_after is not None and args.end_before is not None:
        logger.log_to_stderr(
            "Invalid stage selection: --end-after and --end-before cannot be used together.",
            "error",
        )
        return 1
    return await run_submit_command(
        prompt=args.prompt,
        host=args.host,
        port=args.port,
        task_id=args.task_id,
        config_path=args.config,
        start_stage=args.start_stage,
        end_after=args.end_after,
        end_before=args.end_before,
    )


async def _run_attach_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import _find_running_task_in_cwd as _find, _resolve_config as _resolve

    logger = CybervisorLogger(quiet=args.quiet)
    task_id = args.task_id
    if task_id is None:
        daemon_config = _resolve(args.host, args.port)
        reachable, running_in_cwd = await _find(daemon_config)
        if not reachable:
            logger.log_to_stderr(f"Daemon not reachable at ws://{daemon_config.host}:{daemon_config.port}", "error")
            return 1
        if not running_in_cwd:
            logger.log_to_stderr("No active task to attach to.", "error")
            return 1
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor attach <task-id>' to target a specific task.",
                "error",
            )
            return 1
        task_id = running_in_cwd[0].get("task_id")
        if task_id is None:
            logger.log_to_stderr("No active task to attach to.", "error")
            return 1
    return await run_attach_command(task_id=task_id, host=args.host, port=args.port)


async def _run_cancel_command(args: argparse.Namespace) -> int:
    return await run_cancel_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_logs_command(args: argparse.Namespace) -> int:
    return await run_logs_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_end_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger(quiet=args.quiet)
    after = args.after
    before = args.before
    if after is not None and before is not None:
        logger.log_to_stderr("--after and --before cannot be used together.", "error")
        return 1
    if after is None and before is None:
        logger.log_to_stderr("Either --after or --before is required.", "error")
        return 1
    return await run_end_command(
        task_id=args.task_id,
        after=after,
        before=before,
        host=args.host,
        port=args.port,
    )


async def _run_serve_command(args: argparse.Namespace) -> int:
    from cybervisor.server import serve as run_serve

    logger = CybervisorLogger(quiet=args.quiet)
    try:
        await run_serve(
            host=args.host,
            port=args.port,
            background=args.background,
            logger=logger,
        )
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logger.log_to_stderr(f"Server error: {exc}", "error")
        return 1