"""Standalone CLI commands: doctor, use, docs, validate, serve-sandbox, restore-skills."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cybervisor.config import StrictValidationError, format_validation_issue, render_contract_guidance
from cybervisor.logging import CybervisorLogger

if TYPE_CHECKING:
    import argparse


def _run_serve_sandbox_command(args: argparse.Namespace) -> int:
    from cybervisor.cli.serve_sandbox import run_serve_sandbox

    logger = CybervisorLogger(quiet=args.quiet)
    try:
        return run_serve_sandbox(args, logger)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logger.log_to_stderr(f"Sandbox error: {exc}", "error")
        return 1


def _run_doctor_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import diagnose_global_llm_readiness

    logger = CybervisorLogger(quiet=args.quiet)
    result = diagnose_global_llm_readiness(timeout=15.0)
    if result.is_ready:
        logger.log_to_stderr(f"Doctor: verifier ready — {result.summary}", "info")
        logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "info")
        if result.status == "rate_limited":
            logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "info")
        return result.exit_code

    state = "needs attention" if result.failure_category == "remote_probe" else "blocked"
    logger.log_to_stderr(f"Doctor: verifier {state} — {result.summary}", "error")
    logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "error")
    logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "error")
    return result.exit_code


def _run_use_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import update_global_agent_tool
    from cybervisor.global_config import GlobalConfigError

    logger = CybervisorLogger(quiet=args.quiet)
    try:
        agent_tool, config_path = update_global_agent_tool(args.agent_tool)
    except GlobalConfigError as exc:
        logger.log_to_stderr(f"Failed to save runtime agent: {exc}", "error")
        return 1
    logger.log_to_stderr(f"Saved global runtime agent '{agent_tool}' to {config_path}.", "info")
    return 0


async def _run_docs_command_impl(args: argparse.Namespace) -> int:
    from cybervisor.cli import _resolve_docs_source_path
    from cybervisor.cli.docs import _resolve_docs_document, _render_docs_usage, _read_docs_source

    logger = CybervisorLogger(quiet=args.quiet)
    if not args.document:
        logger.log_to_stderr(_render_docs_usage(), "error")
        return 1
    document, error_message = _resolve_docs_document(args.document)
    if document is None:
        logger.log_to_stderr(error_message or _render_docs_usage(), "error")
        return 1
    try:
        source_path = _resolve_docs_source_path(document)
        contents = _read_docs_source(document)
    except FileNotFoundError as exc:
        logger.log_to_stderr(str(exc), "error")
        return 1
    print(f"SOURCE: {source_path}")
    print()
    print(contents, end="")
    return 0


def _run_validate_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import validate_config_file

    logger = CybervisorLogger(quiet=args.quiet)
    paths: list[str] = list(args.paths) if args.paths else ["cybervisor.yaml"]
    failures = 0
    for raw_path in paths:
        display_path = __import__("pathlib").Path(raw_path).resolve()
        try:
            resolved_path, config = validate_config_file(raw_path)
        except FileNotFoundError as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        except StrictValidationError as exc:
            issue_lines = "\n".join(f"  - {format_validation_issue(issue)}" for issue in exc.issues)
            logger.log_to_stderr(f"INVALID {exc.path.resolve()}\n{issue_lines}", "error")
            failures += 1
            continue
        except Exception as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        logger.log_to_stderr(f"VALID {resolved_path.resolve()}", "info")
        if args.show_guidance:
            for stage in config.stages:
                if stage.contract is None:
                    continue
                guidance = render_contract_guidance(stage.name, stage.contract).rstrip()
                logger.log_to_stderr(f"GUIDANCE {stage.name}:\n\n{guidance}\n", "info")
    return 0 if failures == 0 else 1


def _run_restore_skills_command(args: argparse.Namespace) -> int:
    from cybervisor.skills import restore_all_skills

    logger = CybervisorLogger(quiet=args.quiet)
    restore_all_skills()
    logger.log_to_stderr("Skills restored.", "info")
    return 0