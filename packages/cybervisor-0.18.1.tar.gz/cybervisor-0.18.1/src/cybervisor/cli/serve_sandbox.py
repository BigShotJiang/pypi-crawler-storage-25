"""Docker sandbox orchestration for sandbox subcommand."""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
from pathlib import Path

from cybervisor.logging import CybervisorLogger

# Environment variables to forward into the container for API key access.
_FORWARDED_ENV_VARS: tuple[str, ...] = (
    "ANTHROPIC_API_KEY",
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "CYBERVISOR_LLM_API_KEY",
    "CYBERVISOR_LLM_BASE_URL",
    "CYBERVISOR_LLM_MODEL",
)



def _generate_container_name(cwd: str | Path) -> str:
    """Generate a unique container name from the current working directory hash."""
    cwd_str = str(Path(cwd).resolve())
    cwd_hash = hashlib.sha256(cwd_str.encode()).hexdigest()[:12]
    return f"cybervisor-sandbox-{cwd_hash}"


def _normalize_path_for_docker(path: str | Path) -> str:
    """Normalize a path for Docker volume mount syntax.

    On Windows, converts drive-letter paths (C:\\foo) to /c/foo style
    and replaces backslashes with forward slashes.
    On other platforms, returns the resolved absolute path as a string.
    """
    resolved = str(Path(path).resolve())

    if sys.platform == "win32":
        # Convert C:\foo to /c/foo
        match = re.match(r"^([A-Za-z]):(.*)", resolved)
        if match:
            drive = match.group(1).lower()
            rest = match.group(2).replace("\\", "/")
            return f"/{drive}{rest}"
        return resolved.replace("\\", "/")

    return resolved


def _is_port_in_use(host: str, port: int) -> bool:
    """Check if a port is already in use on the given host."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        try:
            sock.bind((host, port))
            return False
        except OSError:
            return True


def check_docker_available(logger: CybervisorLogger) -> bool:
    """Check if Docker CLI is available and operational.

    Returns True if Docker is available, False otherwise.
    """
    docker_path = shutil.which("docker")
    if docker_path is None:
        logger.log_to_stderr(
            "Docker is not installed or not on PATH. "
            "Install Docker and verify with `docker --version`.",
            "error",
        )
        return False

    try:
        result = subprocess.run(
            [docker_path, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            logger.log_to_stderr(
                f"Docker check failed: {result.stderr.strip()}",
                "error",
            )
            return False
    except (subprocess.TimeoutExpired, OSError) as exc:
        logger.log_to_stderr(
            f"Failed to run Docker: {exc}",
            "error",
        )
        return False

    return True


def _build_docker_run_args(
    args: argparse.Namespace,
    cwd: str | Path,
    uid: int | None,
    gid: int | None,
    host_home: str,
) -> list[str]:
    """Construct the docker run command arguments.

    Args:
        args: Parsed CLI arguments with host, port, background, image, name.
        cwd: Current working directory to mount at the same path inside the container.
        uid: Host user ID for --user mapping (None on Windows).
        gid: Host group ID for --user mapping (None on Windows).
        host_home: Host user home directory path.

    Returns:
        List of string arguments for subprocess.run (docker binary + run args + command).
    """
    docker_path = shutil.which("docker")
    assert docker_path is not None  # Checked by caller

    run_args: list[str] = [docker_path, "run"]

    # Auto-remove container on exit in foreground mode.
    if not args.background:
        run_args.append("--rm")

    # Container name.
    container_name = args.name or _generate_container_name(cwd)
    run_args.extend(["--name", container_name])

    # UID/GID mapping (skipped on Windows where os.getuid is unavailable).
    if uid is not None and gid is not None:
        run_args.extend(["--user", f"{uid}:{gid}"])

    # Volume mounts.
    # 1. Current working directory -> same path inside container.
    workspace_host = _normalize_path_for_docker(cwd)
    run_args.extend(["-v", f"{workspace_host}:{workspace_host}"])

    # 2. Host home directory -> same path inside container.
    #    Mounting the entire home dir ensures all agent config
    #    (.claude.json, .claude/, .gemini/, .npm/, .cybervisor/) are
    #    naturally available at the same absolute path.
    host_home_normalized = _normalize_path_for_docker(host_home)
    run_args.extend(["-v", f"{host_home_normalized}:{host_home}"])

    # 3. /etc/passwd and /etc/group read-only for name resolution inside container.
    passwd_path = Path("/etc/passwd")
    group_path = Path("/etc/group")
    if passwd_path.exists():
        run_args.extend(["-v", f"{passwd_path}:/etc/passwd:ro"])
    if group_path.exists():
        run_args.extend(["-v", f"{group_path}:/etc/group:ro"])

    # Working directory inside container (same path as on host).
    run_args.extend(["--workdir", str(Path(cwd).resolve())])

    # Host networking: container shares the host's network stack.
    run_args.append("--network=host")

    # Environment variables.
    run_args.extend(["-e", f"HOST_HOME={host_home}"])
    run_args.extend(["-e", f"HOME={host_home}"])

    # Forward API key environment variables.
    # Use -e KEY (without value) so Docker inherits from the client environment.
    # This avoids leaking secrets into /proc/<pid>/cmdline.
    for env_var in _FORWARDED_ENV_VARS:
        if os.environ.get(env_var) is not None:
            run_args.extend(["-e", env_var])

    # Docker image.
    run_args.append(args.image)

    # Command inside container: cybervisor serve with host port settings.
    run_args.extend(["cybervisor", "serve", "--host", str(args.host), "--port", str(args.port)])

    return run_args


def _image_exists_locally(image: str, logger: CybervisorLogger) -> bool:
    """Check if a Docker image exists in the local image store.

    Returns True if the image is present locally, False otherwise.
    """
    docker_path = shutil.which("docker")
    assert docker_path is not None

    try:
        result = subprocess.run(
            [docker_path, "image", "inspect", image],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def _pull_image(image: str, logger: CybervisorLogger) -> bool:
    """Pull a Docker image from the registry.

    Always attempts docker pull regardless of local presence.
    Returns True on success, False on failure.
    """
    docker_path = shutil.which("docker")
    assert docker_path is not None

    logger.log_to_stderr(f"Pulling image '{image}'...", "info")
    try:
        result = subprocess.run(
            [docker_path, "pull", image],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            logger.log_to_stderr(f"Successfully pulled image '{image}'", "info")
            return True
        logger.log_to_stderr(
            f"Failed to pull image '{image}': {result.stderr.strip()}",
            "error",
        )
        return False
    except subprocess.TimeoutExpired:
        logger.log_to_stderr(
            f"Pulling image '{image}' timed out after 300 seconds.",
            "error",
        )
        return False
    except OSError as exc:
        logger.log_to_stderr(
            f"Failed to pull image '{image}': {exc}",
            "error",
        )
        return False


def _cleanup_container(container_name: str, logger: CybervisorLogger) -> None:
    """Gracefully stop and remove a container by name."""
    docker_path = shutil.which("docker")
    if docker_path is None:
        return

    try:
        # Send SIGTERM via docker stop.
        subprocess.run(
            [docker_path, "stop", container_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (subprocess.TimeoutExpired, OSError):
        # Force kill if stop times out.
        try:
            subprocess.run(
                [docker_path, "kill", container_name],
                capture_output=True,
                text=True,
                timeout=10,
            )
        except (subprocess.TimeoutExpired, OSError):
            pass

    # Remove container if it still exists (for background mode).
    try:
        subprocess.run(
            [docker_path, "rm", "-f", container_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError):
        pass


def _get_container_logs(container_name: str, logger: CybervisorLogger) -> None:
    """Fetch and display container logs on failure."""
    docker_path = shutil.which("docker")
    if docker_path is None:
        return

    try:
        result = subprocess.run(
            [docker_path, "logs", container_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.stdout:
            for line in result.stdout.strip().splitlines()[-20:]:
                logger.log_to_stderr(f"  container stdout: {line}", "error")
        if result.stderr:
            for line in result.stderr.strip().splitlines()[-20:]:
                logger.log_to_stderr(f"  container stderr: {line}", "error")
    except (subprocess.TimeoutExpired, OSError):
        pass


def run_serve_sandbox(args: argparse.Namespace, logger: CybervisorLogger) -> int:
    """Execute the sandbox command: launch cybervisor in a Docker container.

    Args:
        args: Parsed CLI arguments.
        logger: Logger instance.

    Returns:
        Exit code (0 for success, 1 for error, 130 for interrupt).
    """
    # Preflight: Docker availability.
    if not check_docker_available(logger):
        return 1

    # Preflight: port conflict check.
    if _is_port_in_use(args.host, args.port):
        logger.log_to_stderr(
            f"Port {args.host}:{args.port} is already in use. "
            "Choose a different port with --port or stop the conflicting service.",
            "error",
        )
        return 1

    # Resolve host identity.
    uid: int | None = os.getuid() if hasattr(os, "getuid") else None
    gid: int | None = os.getgid() if hasattr(os, "getgid") else None
    host_home = str(Path.home())
    cwd = str(Path.cwd())

    # Container name for cleanup reference.
    container_name = args.name or _generate_container_name(cwd)

    # Pull image or verify local availability.
    if getattr(args, "no_pull", False):
        if not _image_exists_locally(args.image, logger):
            logger.log_to_stderr(
                f"Image '{args.image}' not found locally and --no-pull was specified",
                "error",
            )
            return 1
    else:
        pull_ok = _pull_image(args.image, logger)
        if not pull_ok:
            if _image_exists_locally(args.image, logger):
                logger.log_to_stderr(
                    f"Pull failed; falling back to local image '{args.image}'",
                    "warning",
                )
            else:
                logger.log_to_stderr(
                    f"Image '{args.image}' not found locally and pull failed",
                    "error",
                )
                return 1

    # Build docker run command.
    docker_args = _build_docker_run_args(args, cwd, uid, gid, host_home)

    logger.log_to_stderr(f"cybervisor {__import__('cybervisor').__version__}", "info")
    logger.log_to_stderr(
        f"Starting sandbox container '{container_name}' on {args.host}:{args.port}...",
        "info",
    )

    # Set up signal handler for graceful shutdown.
    # Use Popen so the signal handler can forward signals to the docker child.
    shutdown_requested = False
    fg_proc: subprocess.Popen[str] | None = None

    def _signal_handler(signum: int, _frame: object) -> None:
        nonlocal shutdown_requested
        shutdown_requested = True
        # Forward the signal to the docker child process so it doesn't hang.
        if fg_proc is not None and fg_proc.poll() is None:
            try:
                fg_proc.send_signal(signum)
            except OSError:
                pass

    original_sigint = signal.signal(signal.SIGINT, _signal_handler)
    original_sigterm = signal.signal(signal.SIGTERM, _signal_handler)

    try:
        if args.background:
            # Background mode: start container detached.
            run_cmd = docker_args.copy()
            # Insert -d after "run"
            run_cmd.insert(run_cmd.index("run") + 1, "-d")
            bg_result = subprocess.run(run_cmd, capture_output=True, text=True, timeout=60)

            if bg_result.returncode != 0:
                logger.log_to_stderr(
                    f"Failed to start container: {bg_result.stderr.strip()}",
                    "error",
                )
                return 1

            container_id = bg_result.stdout.strip()
            logger.log_to_stderr(
                f"Container started in background (ID: {container_id[:12]}). "
                f"Use `docker stop {container_name}` to stop.",
                "info",
            )
            if shutdown_requested:
                logger.log_to_stderr("Interrupted after container start. Stopping container...", "info")
                _cleanup_container(container_name, logger)
                return 130
            return 0
        else:
            # Foreground mode: run container attached, with --rm for auto-cleanup.
            fg_proc = subprocess.Popen(docker_args, text=True)
            returncode = fg_proc.wait()

            if shutdown_requested:
                logger.log_to_stderr("Interrupted. Stopping container...", "info")
                # Container should be stopping due to --rm, but ensure cleanup.
                _cleanup_container(container_name, logger)
                return 130

            if returncode != 0:
                logger.log_to_stderr(
                    f"Container exited with code {returncode}.",
                    "error",
                )
                # Attempt to show logs (container may still exist briefly).
                _get_container_logs(container_name, logger)
                return 1

            return 0
    except subprocess.TimeoutExpired:
        logger.log_to_stderr("Container start timed out.", "error")
        _cleanup_container(container_name, logger)
        return 1
    except OSError as exc:
        logger.log_to_stderr(f"Failed to start container: {exc}", "error")
        _cleanup_container(container_name, logger)
        return 1
    finally:
        signal.signal(signal.SIGINT, original_sigint)
        signal.signal(signal.SIGTERM, original_sigterm)