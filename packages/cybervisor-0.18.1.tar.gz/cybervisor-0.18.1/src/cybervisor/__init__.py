"""cybervisor package."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import tomllib


def _read_version_from_pyproject() -> str:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    with pyproject_path.open("rb") as pyproject_file:
        project = tomllib.load(pyproject_file)["project"]
    package_version = project.get("version")
    if not isinstance(package_version, str):
        msg = "project.version must be a string in pyproject.toml"
        raise RuntimeError(msg)
    return package_version


try:
    __version__ = version("cybervisor")
except PackageNotFoundError:
    __version__ = _read_version_from_pyproject()
