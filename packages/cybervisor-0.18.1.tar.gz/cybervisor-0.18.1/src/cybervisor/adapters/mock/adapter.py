from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

from cybervisor.adapters.base import BaseAdapter, CompletedProcessHandle
from cybervisor.adapters.types import AdapterDescriptor, LaunchRequest, PreflightRequirements, RunningProcess
from cybervisor.stream_logging import CanonicalLogEvent

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from cybervisor.config import PipelineConfig


class MockAdapter(BaseAdapter):
    descriptor = AdapterDescriptor(
        name="mock",
        display_name="Mock Agent",
        directory=Path(__file__).resolve().parent,
    )

    def parse_output_line(self, line: str) -> list[CanonicalLogEvent]:
        if not line:
            return []
        return [CanonicalLogEvent(kind="plain_text", text=line)]

    def flush_pending_events(self) -> list[CanonicalLogEvent]:
        return []

    def should_suppress_event(self, event: CanonicalLogEvent, saw_hook_feedback: bool) -> bool:
        del event, saw_hook_feedback
        return False

    def preflight_requirements(self) -> PreflightRequirements:
        return PreflightRequirements()

    def start(self, request: LaunchRequest) -> RunningProcess:
        time.sleep(0.05)
        output = "Stage completed successfully"
        stage_name = request.stage_name

        # Lazily load the workspace's PipelineConfig from cybervisor.yaml.
        # MockAdapter is a module-level singleton with no constructor parameters,
        # so config must be loaded at start()-time. Derive the workspace from the
        # log_file path (".cybervisor/logs/stages/<stage>.jsonl") so this works
        # regardless of the current working directory.
        config: PipelineConfig | None = None
        workspace: Path = Path.cwd()
        try:
            log_path = Path(request.log_file)
            # Walk up from the log file to find .cybervisor/, then go to its parent.
            for parent in log_path.parents:
                if parent.name == ".cybervisor":
                    workspace = parent.parent
                    break

            # Avoid circular import by importing here.
            from cybervisor.config import load_config

            config = load_config(workspace / "cybervisor.yaml", cwd=workspace)
        except Exception:
            # If the config can't be loaded (absent file, parse error, etc.),
            # degrade gracefully: skip contract artifact emission rather than crashing.
            _logger.debug("MockAdapter could not load pipeline config; skipping contract artifact emission")
            config = None

        # Support the legacy mock_artifact_payload.yaml for backward compatibility
        # with existing tests; it takes priority over contract-driven writing.
        mock_payload = workspace / ".cybervisor/mock_artifact_payload.yaml"
        if mock_payload.exists():
            self._write_from_payload(stage_name, mock_payload, workspace)
        elif config is not None:
            self._write_contract_artifact_for_stage(stage_name, config, workspace)

        Path(request.log_file).parent.mkdir(parents=True, exist_ok=True)
        Path(request.log_file).write_text(output + "\n", encoding="utf-8")
        request.logger.log_to_stderr(f"[{stage_name}][mock] {output}")
        return CompletedProcessHandle(output=output, exit_code=0, delay_seconds=0.05)

    def _write_contract_artifact_for_stage(
        self, stage_name: str, config: PipelineConfig, workspace: Path
    ) -> None:
        """Write a passing contract artifact for stages that produce named artifact files.

        A stage emits an artifact when it has a contract with at least one route.
        Routing-only stages (those whose contract routes all point to a next_stage
        without injecting fields) do not emit artifact files.
        """
        from cybervisor.config import contract_artifact_path

        stage_config = None
        for stage in config.stages:
            if stage.name == stage_name:
                stage_config = stage
                break

        if stage_config is None:
            return

        contract = stage_config.contract
        if contract is None:
            return

        if not contract.routes:
            return

        # Routing-only stages: every route redirects to a *different* stage
        # (next_stage != current stage) with no injected fields. These do not
        # emit an artifact file. Stages that self-loop or have no next_stage
        # (terminal stages) emit artifacts.
        is_routing_only = all(
            route.next_stage is not None and route.next_stage != stage_name and not route.injections
            for route in contract.routes.values()
        )
        if is_routing_only:
            return

        # Resolve relative artifact path against the workspace directory.
        artifact_path = (workspace / contract_artifact_path(stage_name)).resolve()
        artifact_path.parent.mkdir(parents=True, exist_ok=True)
        # Use the first route key (deterministic insertion order) as the status.
        first_status = next(iter(contract.routes))
        artifact_path.write_text(f"Status: {first_status}\n", encoding="utf-8")

    def _write_from_payload(self, stage_name: str, payload_file: Path, workspace: Path) -> None:
        """Write the contract artifact from the legacy payload file."""
        from cybervisor.config import contract_artifact_path

        artifact_path = (workspace / contract_artifact_path(stage_name)).resolve()
        artifact_path.parent.mkdir(parents=True, exist_ok=True)
        artifact_path.write_text(payload_file.read_text(encoding="utf-8"), encoding="utf-8")
