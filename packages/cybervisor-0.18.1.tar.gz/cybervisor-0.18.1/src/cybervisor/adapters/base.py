from __future__ import annotations

import os
import subprocess
import threading
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from cybervisor.adapters.types import (
    AdapterDescriptor,
    AdapterExecutionResult,
    AdapterOutcome,
    AdapterStatus,
    AgentAdapter as _AgentAdapter,
    LaunchRequest,
    PreflightRequirements,
    RunningProcess,
)
from cybervisor.stream_logging import CanonicalLogEvent, render_canonical_event

AgentAdapter = _AgentAdapter

if TYPE_CHECKING:
    from cybervisor.core_hooks.common import HookDecision


class BaseAdapter(ABC, AgentAdapter):
    descriptor: AdapterDescriptor

    @classmethod
    def lifecycle_states(cls) -> tuple[AdapterStatus, AdapterStatus, AdapterStatus, AdapterStatus]:
        return (
            AdapterStatus.PREPARED,
            AdapterStatus.RUNNING,
            AdapterStatus.COMPLETED,
            AdapterStatus.FAILED,
        )

    @classmethod
    def normalized_outcomes(cls) -> tuple[AdapterOutcome, AdapterOutcome, AdapterOutcome]:
        return (
            AdapterOutcome.STARTED,
            AdapterOutcome.SUCCEEDED,
            AdapterOutcome.FAILED,
        )

    def lifecycle_status(self) -> AdapterStatus:
        return self.lifecycle_states()[0]

    def running_status(self) -> AdapterStatus:
        return self.lifecycle_states()[1]

    def completed_status(self) -> AdapterStatus:
        return self.lifecycle_states()[2]

    def failed_status(self) -> AdapterStatus:
        return self.lifecycle_states()[3]

    def start_outcome(self) -> AdapterOutcome:
        return self.normalized_outcomes()[0]

    def success_outcome(self) -> AdapterOutcome:
        return self.normalized_outcomes()[1]

    def failure_outcome(self) -> AdapterOutcome:
        return self.normalized_outcomes()[2]

    @abstractmethod
    def start(self, request: LaunchRequest) -> RunningProcess:
        raise NotImplementedError

    def status(self) -> AdapterStatus:
        return self.lifecycle_status()

    def run(self) -> AdapterStatus:
        return self.running_status()

    def complete_status(self) -> AdapterStatus:
        return self.completed_status()

    def fail_status(self) -> AdapterStatus:
        return self.failed_status()

    def prepare(self) -> AdapterExecutionResult:
        return AdapterExecutionResult(lifecycle=self.lifecycle_status(), outcome=self.start_outcome())

    def running(self) -> AdapterExecutionResult:
        return AdapterExecutionResult(lifecycle=self.running_status(), outcome=self.start_outcome())

    def complete(self, *, exit_code: int | None = None, output: str = "") -> AdapterExecutionResult | AdapterStatus:
        if exit_code is None:
            return self.completed_status()
        return AdapterExecutionResult(
            lifecycle=self.completed_status(),
            outcome=self.success_outcome(),
            exit_code=exit_code,
            output=output,
        )

    def fail(
        self,
        *,
        exit_code: int | None = None,
        output: str = "",
        error: str | None = None,
    ) -> AdapterExecutionResult | AdapterStatus:
        if exit_code is None and not output and error is None:
            return self.failed_status()
        return AdapterExecutionResult(
            lifecycle=self.failed_status(),
            outcome=self.failure_outcome(),
            exit_code=exit_code,
            output=output,
            error=error,
        )

    def complete_result(self, *, exit_code: int, output: str) -> AdapterExecutionResult:
        result = self.complete(exit_code=exit_code, output=output)
        assert isinstance(result, AdapterExecutionResult)
        return result

    def fail_result(self, *, exit_code: int | None, output: str = "", error: str | None = None) -> AdapterExecutionResult:
        result = self.fail(exit_code=exit_code, output=output, error=error)
        assert isinstance(result, AdapterExecutionResult)
        return result

    def lifecycle_from_exit_code(self, exit_code: int) -> AdapterStatus:
        return self.completed_status() if exit_code == 0 else self.failed_status()

    def outcome_from_exit_code(self, exit_code: int) -> AdapterOutcome:
        return self.success_outcome() if exit_code == 0 else self.failure_outcome()

    def run_result(self, exit_code: int, output: str, error: str | None = None) -> AdapterExecutionResult:
        if exit_code == 0:
            return self.complete_result(exit_code=exit_code, output=output)
        return self.fail_result(exit_code=exit_code, output=output, error=error)

    def supports_runtime_contract(self) -> bool:
        return True

    def upgrade_runtime_contract(self) -> BaseAdapter:
        return self

    def log_execution_result(self, logger: Any, stage_name: str, result: AdapterExecutionResult) -> None:
        details = [f"lifecycle={result.lifecycle.value}", f"outcome={result.outcome.value}"]
        if result.exit_code is not None:
            details.append(f"exit_code={result.exit_code}")
        if result.error:
            details.append(f"error={result.error}")
        logger.log_to_stderr(f"[{stage_name}][{self.descriptor.name}] Adapter result: {', '.join(details)}")

    def parse_output_line(self, line: str) -> list[CanonicalLogEvent]:
        if not line:
            return []
        return [CanonicalLogEvent(kind="plain_text", text=line)]

    def flush_pending_events(self) -> list[CanonicalLogEvent]:
        return []

    def should_suppress_event(self, event: CanonicalLogEvent, saw_hook_feedback: bool) -> bool:
        del event, saw_hook_feedback
        return False

    def preflight_requirements(self) -> PreflightRequirements:
        return PreflightRequirements()

    def project_skills_dir(self) -> Path | None:
        """Return the project-local skills directory for this adapter, or None."""
        return None

    def settings_path(self) -> Path | None:
        return None

    def install_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        del runtime_config_path
        return payload

    def remove_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        del runtime_config_path
        return payload

    def install_tool_use_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        """Install tool-use hook settings for write protection. Default no-op."""
        del runtime_config_path
        return payload

    def remove_tool_use_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        """Remove tool-use hook settings for write protection. Default no-op."""
        del runtime_config_path
        return payload

    def requires_native_hook_settings(self) -> bool:
        return self.descriptor.capabilities.supports_hooks

    def uses_hook_listener(self) -> bool:
        return self.descriptor.capabilities.supports_hooks and self.requires_native_hook_settings()

    @property
    def disallowed_tools(self) -> list[str]:
        return []

    def evaluate_reply(
        self,
        config_path: Path,
        *,
        reply_text: str,
        session_id: str | None = None,
    ) -> HookDecision:
        del config_path, reply_text, session_id
        raise NotImplementedError("This adapter does not implement post-reply hook evaluation")

    def _is_container(self) -> bool:
        """Detect if we are running inside a container."""
        if os.path.exists("/.dockerenv"):
            return True
        try:
            with open("/proc/self/cgroup", "r", encoding="utf-8") as f:
                for line in f:
                    if "docker" in line or "containerd" in line:
                        return True
        except (FileNotFoundError, PermissionError):
            pass
        return False


class CompletedProcessHandle:
    def __init__(self, output: str, exit_code: int = 0, delay_seconds: float = 0.0) -> None:
        self.pid: int | None = None
        self.process_group_id: int | None = None
        self._output = output
        self._exit_code = exit_code
        self._delay_seconds = delay_seconds

    def wait(self) -> tuple[int, str]:
        if self._delay_seconds > 0:
            time.sleep(self._delay_seconds)
        return self._exit_code, self._output


class StreamingSubprocessHandle:
    def __init__(self, process: subprocess.Popen[str], request: LaunchRequest, adapter: BaseAdapter) -> None:
        self._process = process
        self._request = request
        self._adapter = adapter
        self._lock = threading.Lock()
        self.pid: int | None = process.pid
        self.process_group_id: int | None = (
            os.getpgid(process.pid) if process.pid is not None and hasattr(os, "getpgid") else None
        )

    def wait(self, timeout: float | None = None) -> tuple[int, str]:
        transcript_parts: list[str] = []
        saw_hook_feedback = False
        log_path = Path(self._request.log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        assert self._process.stdout is not None

        def _log_events(events: list[CanonicalLogEvent]) -> None:
            nonlocal saw_hook_feedback
            for event in events:
                if event.kind == "hook_feedback":
                    saw_hook_feedback = True
                if self._adapter.should_suppress_event(event, saw_hook_feedback):
                    continue
                rendered = render_canonical_event(event)
                if rendered:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][{self._adapter.descriptor.name}] {rendered}"
                    )

        with self._lock:
            with log_path.open("w", encoding="utf-8") as log_handle:
                for line in self._process.stdout:
                    transcript_parts.append(line)
                    log_handle.write(line)
                    _log_events(self._adapter.parse_output_line(line.rstrip()))
                _log_events(self._adapter.flush_pending_events())
        exit_code = self._process.wait(timeout=timeout)
        return exit_code, "".join(transcript_parts).rstrip("\n")


class BaseSubprocessAdapter(BaseAdapter, AgentAdapter):
    @abstractmethod
    def build_command(self, request: LaunchRequest) -> list[str]:
        raise NotImplementedError

    def start(self, request: LaunchRequest) -> RunningProcess:
        Path(request.log_file).parent.mkdir(parents=True, exist_ok=True)
        command = self.build_command(request)
        if os.name != "nt":
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
        else:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
        if process.stdin is not None:
            try:
                process.stdin.write(request.prompt)
                process.stdin.close()
            except OSError:
                pass
        return StreamingSubprocessHandle(process=process, request=request, adapter=cast(BaseAdapter, self))
