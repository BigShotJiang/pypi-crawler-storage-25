from __future__ import annotations

import logging
from pathlib import Path

import os
import subprocess

from cybervisor.adapters.base import BaseAdapter
from cybervisor.adapters.codex.app_server import CodexAppServerHandle
from cybervisor.adapters.codex.stream import parse_codex_output_line
from cybervisor.adapters.types import (
    AdapterCapabilities,
    AdapterDescriptor,
    LaunchRequest,
    PreflightRequirements,
    RunningProcess,
)
from cybervisor.core_hooks.common import (
    HookDecision,
    active_stage_contract,
    active_stage_prompt,
    contract_blocking_decision,
    contract_repair_message,
    format_verifier_payload,
    get_stop_verifier_prompt,
    hook_log_path,
    is_final_stage_attempt,
    log_hook_event,
    parse_decision,
    post,
    recover_structured_output,
    resolve_verifier_settings,
    validate_stage_contract_artifact,
)
from cybervisor.stream_logging import CanonicalLogEvent

_CODEX_BINARY_MESSAGE = "Codex requires the `codex` CLI on PATH. Install it and verify with `codex --version`."
_CODEX_APP_SERVER_MESSAGE = (
    "Codex requires direct app-server protocol support through the Codex CLI. Ensure `codex app-server` is available."
)


class CodexPreflightRequirements(PreflightRequirements):
    def missing_binary_message(self, binary: str) -> str:
        if binary == "codex":
            return _CODEX_BINARY_MESSAGE
        return f"Required tool '{binary}' was not found on PATH. Install it and verify with `{binary} --version`."

    def unsupported_environment_message(self) -> str:
        return _CODEX_APP_SERVER_MESSAGE


class CodexAdapter(BaseAdapter):
    descriptor = AdapterDescriptor(
        name="codex",
        display_name="Codex",
        directory=Path(__file__).resolve().parent,
        capabilities=AdapterCapabilities(supports_hooks=True, supports_structured_streams=True),
    )

    @property
    def disallowed_tools(self) -> list[str]:
        return ["AskUserQuestion"]

    def project_skills_dir(self) -> Path | None:
        return Path(".agents/skills")

    def build_command(self, request: LaunchRequest) -> list[str]:
        del request
        return ["codex", "app-server", "--listen", "stdio://"]

    # CodexAdapter.start() must NOT delegate to BaseSubprocessAdapter.start().
    # BaseSubprocessAdapter.start() writes the prompt to stdin and then closes it,
    # which would break the Codex app-server JSON-RPC transport that requires
    # continuous stdin access for the duration of the process.
    def start(self, request: LaunchRequest) -> RunningProcess:
        Path(request.log_file).parent.mkdir(parents=True, exist_ok=True)
        command = self.build_command(request)
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            start_new_session=(os.name != "nt"),
        )
        return CodexAppServerHandle(process=process, request=request)

    def parse_output_line(self, line: str) -> list[CanonicalLogEvent]:
        return parse_codex_output_line(line)

    def flush_pending_events(self) -> list[CanonicalLogEvent]:
        return []

    def should_suppress_event(self, event: CanonicalLogEvent, saw_hook_feedback: bool) -> bool:
        return event.kind == "completed" and event.status == "success" and saw_hook_feedback

    def preflight_requirements(self) -> PreflightRequirements:
        return CodexPreflightRequirements(required_binaries=("codex",), requires_verifier_config=True)

    def is_supported_environment(self) -> bool:
        try:
            result = subprocess.run(
                ["codex", "app-server", "--help"],
                capture_output=True,
                text=True,
                check=False,
            )
        except OSError:
            return False
        return result.returncode == 0

    def settings_path(self) -> Path | None:
        return None

    def requires_native_hook_settings(self) -> bool:
        return False

    def install_hook_settings(self, payload: dict[str, object], runtime_config_path: Path) -> dict[str, object]:
        del runtime_config_path
        return payload

    def remove_hook_settings(self, payload: dict[str, object], runtime_config_path: Path) -> dict[str, object]:
        del runtime_config_path
        return payload

    def evaluate_reply(
        self,
        config_path: Path,
        *,
        reply_text: str,
        session_id: str | None = None,
    ) -> HookDecision:
        # Codex uses the app-server protocol, not CLI flags.
        # Tool restrictions cannot be passed via the protocol currently.
        if self.disallowed_tools:
            logging.getLogger(__name__).debug(
                "Codex app-server protocol does not support tool restrictions; "
                "skipping tool disabling for: %s",
                ", ".join(self.disallowed_tools),
            )

        normalized_reply = reply_text.strip()
        if not normalized_reply:
            raise RuntimeError("Codex ACP did not capture a final assistant reply before verifier evaluation")

        api_endpoint, api_key, model = resolve_verifier_settings()
        log_path = hook_log_path(config_path)
        normalized_session_id = session_id.strip() if isinstance(session_id, str) and session_id.strip() else None
        agent_tool = self.descriptor.name

        contract = active_stage_contract(config_path)
        if contract is not None:
            artifact_payload, artifact_error = validate_stage_contract_artifact(config_path)
            if artifact_error is not None:
                artifact_error = contract_repair_message(contract, artifact_error)
                decision = contract_blocking_decision(agent_tool, artifact_error)
                log_hook_event(
                    log_path,
                    "codex_contract_validation_failed",
                    "Codex ACP stage contract was missing or invalid.",
                    agent_tool=agent_tool,
                    config_path=config_path,
                    hook_input=normalized_reply,
                    decision=decision.as_payload(),
                    error=artifact_error,
                    session_id=normalized_session_id,
                    notify_listener=False,
                )
                return decision
            if artifact_payload is not None:
                log_hook_event(
                    log_path,
                    "codex_contract_validation_passed",
                    "Codex ACP stage contract validated successfully.",
                    agent_tool=agent_tool,
                    config_path=config_path,
                    hook_input=normalized_reply,
                    session_id=normalized_session_id,
                    notify_listener=False,
                )
                return HookDecision(action="approve", reason="stage_contract_valid")

        if contract is None and is_final_stage_attempt(config_path):
            decision = HookDecision(
                action="approve",
                reason="final_attempt_reached_allowing_stop_without_hook_block",
            )
            log_hook_event(
                log_path,
                "codex_final_attempt_bypass",
                "Final allowed Codex ACP attempt reached; allowing stop without verifier blocking.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=normalized_reply,
                decision=decision.as_payload(),
                session_id=normalized_session_id,
                notify_listener=False,
            )
            return decision

        if not api_key:
            raise RuntimeError("Codex ACP verifier unavailable: llm.api_key is not configured")

        verifier_input = format_verifier_payload(
            agent_tool=agent_tool,
            stage_prompt=active_stage_prompt(config_path),
            final_response=normalized_reply,
        )
        log_hook_event(
            log_path,
            "codex_verifier_request_started",
            "Submitting Codex ACP reply to verifier.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=normalized_reply,
            session_id=normalized_session_id,
            notify_listener=False,
        )
        decision, verifier_output = recover_structured_output(
            api_endpoint=api_endpoint,
            api_key=api_key,
            model=model,
            initial_messages=[
                {
                    "role": "system",
                    "content": get_stop_verifier_prompt(config_path),
                },
                {"role": "user", "content": verifier_input},
            ],
            parser=parse_decision,
            regeneration_system_prompt="Regenerate as VALID JSON only. No prose. Keys: decision ('approve'|'block'), reason (string).",
            log_path=log_path,
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=normalized_reply,
            notify_listener=False,
            post_fn=post,
        )
        log_hook_event(
            log_path,
            "codex_verifier_decision",
            "Verifier evaluated the Codex ACP reply.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=normalized_reply,
            verifier_output=verifier_output,
            decision=decision.as_payload(),
            session_id=normalized_session_id,
            notify_listener=False,
        )
        return decision
