from __future__ import annotations

import asyncio
import json
import os
import queue
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from cybervisor.adapters.codex._app_helpers import (
    _extract_reply_text,
    _json_rpc_message,
    _json_rpc_notification_method,
    _json_rpc_response_id,
    _payload_summary,
    _text_input,
    _tool_item_id,
    notification_to_events,
)
from cybervisor.core_hooks.common import continuation_message_for_decision
from cybervisor.stream_logging import render_canonical_event

__all__ = [
    "CodexAppServerResult",
    "CodexAppServerHandle",
    "notification_to_events",
]


_HOOK_CONFIG_PATH = Path(".cybervisor/hooks/hook_config.json")
_REQUEST_TIMEOUT_SECONDS = 30
_NOTIFICATION_TIMEOUT_SECONDS = 30
_TURN_IDLE_GRACE_SECONDS = 180


class _ReaderThread(threading.Thread):
    def __init__(
        self,
        stdout: Any,
        log_path: Path,
        transcript_parts: list[str],
        notifications: queue.Queue[dict[str, Any]],
        responses: queue.Queue[dict[str, Any]],
    ) -> None:
        super().__init__(name="codex-app-server-reader", daemon=True)
        self._stdout = stdout
        self._log_path = log_path
        self._transcript_parts = transcript_parts
        self._notifications = notifications
        self._responses = responses

    def run(self) -> None:
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("w", encoding="utf-8") as log_handle:
            for raw_line in self._stdout:
                self._transcript_parts.append(raw_line)
                log_handle.write(raw_line)
                log_handle.flush()
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    self._notifications.put({"method": "error", "params": {"message": line}})
                    continue
                if not isinstance(payload, dict):
                    continue
                if _json_rpc_response_id(payload) is not None:
                    self._responses.put(payload)
                    continue
                method = _json_rpc_notification_method(payload)
                if method is not None:
                    self._notifications.put(payload)


class _CodexAppServerTransport:
    def __init__(self, process: subprocess.Popen[str], request: Any) -> None:
        self._process = process
        self._message_id = 0
        self._transcript_parts: list[str] = []
        self._notifications: queue.Queue[dict[str, Any]] = queue.Queue()
        self._responses: queue.Queue[dict[str, Any]] = queue.Queue()
        self._last_notification: dict[str, Any] | None = None
        assert process.stdout is not None
        self._reader = _ReaderThread(
            process.stdout,
            Path(request.log_file),
            self._transcript_parts,
            self._notifications,
            self._responses,
        )
        self._reader.start()

    @property
    def transcript(self) -> str:
        return "".join(self._transcript_parts).rstrip("\n")

    @property
    def process_exit_code(self) -> int | None:
        return self._process.poll()

    def _next_id(self) -> int:
        self._message_id += 1
        return self._message_id

    def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        assert self._process.stdin is not None
        message_id = self._next_id()
        self._process.stdin.write(_json_rpc_message(message_id, method, params) + "\n")
        self._process.stdin.flush()

        while True:
            try:
                payload = self._responses.get(timeout=_REQUEST_TIMEOUT_SECONDS)
            except queue.Empty as exc:
                process_state = self._process.poll()
                suffix = f"; process exited with code {process_state}" if process_state is not None else ""
                raise RuntimeError(
                    f"Timed out waiting for Codex app-server response to '{method}' after {_REQUEST_TIMEOUT_SECONDS}s{suffix}"
                ) from exc
            if _json_rpc_response_id(payload) != message_id:
                continue
            if "error" in payload:
                raise RuntimeError(str(payload["error"]))
            result = payload.get("result")
            if not isinstance(result, dict):
                raise RuntimeError(f"Codex app-server request '{method}' returned a non-object result")
            return result

    def wait_for_notification(self) -> dict[str, Any]:
        import queue

        try:
            payload = self._notifications.get(timeout=_NOTIFICATION_TIMEOUT_SECONDS)
        except queue.Empty as exc:
            process_state = self._process.poll()
            last_seen = _payload_summary(self._last_notification) if self._last_notification is not None else "none"
            suffix = f"; process exited with code {process_state}" if process_state is not None else ""
            raise RuntimeError(
                "Timed out waiting for Codex app-server notification "
                f"after {_NOTIFICATION_TIMEOUT_SECONDS}s; last notification={last_seen}{suffix}"
            ) from exc
        self._last_notification = payload
        return payload

    def close(self) -> int:
        if self._process.stdin is not None and not self._process.stdin.closed:
            self._process.stdin.close()
        return self._process.wait()


@dataclass
class CodexAppServerResult:
    exit_code: int
    output: str
    transport_exit_code: int


class CodexAppServerHandle:
    def __init__(self, process: subprocess.Popen[str], request: Any) -> None:
        self._process = process
        self._request = request
        self._logged_tool_item_ids: set[str] = set()
        self.pid: int | None = process.pid
        self.process_group_id: int | None = (
            os.getpgid(process.pid) if process.pid is not None and hasattr(os, "getpgid") else None
        )

    def _log_notification(self, payload: dict[str, Any]) -> None:
        tool_item_id = _tool_item_id(payload)
        for event in notification_to_events(payload):
            if event.kind == "completed" and event.status == "success":
                continue
            if event.kind == "tool_call" and tool_item_id is not None:
                if tool_item_id in self._logged_tool_item_ids:
                    continue
                self._logged_tool_item_ids.add(tool_item_id)
            rendered = render_canonical_event(event)
            if rendered:
                self._request.logger.log_to_stderr(f"[{self._request.stage_name}][codex] {rendered}")

    async def _await_thread_started(self, transport: _CodexAppServerTransport) -> str:
        while True:
            payload = transport.wait_for_notification()
            self._log_notification(payload)
            method = _json_rpc_notification_method(payload)
            if method != "thread/started":
                continue
            params = payload.get("params")
            thread = params.get("thread") if isinstance(params, dict) else None
            thread_id = thread.get("id") if isinstance(thread, dict) else None
            if isinstance(thread_id, str) and thread_id.strip():
                return thread_id
            raise RuntimeError("Codex app-server emitted thread/started without a thread id")

    async def _run_turn(self, transport: _CodexAppServerTransport, *, session_id: str, prompt: str) -> str:
        active_message_id: str | None = None
        active_message_phase = ""
        streamed_reply_parts: list[str] = []
        completed_reply_text = ""
        idle_deadline = asyncio.get_running_loop().time() + _TURN_IDLE_GRACE_SECONDS
        warned_about_idle = False

        transport.request(
            "turn/start",
            {
                "threadId": session_id,
                "input": _text_input(prompt),
                "cwd": str(Path.cwd().resolve()),
                "approvalPolicy": "never",
            },
        )
        while True:
            try:
                payload = transport.wait_for_notification()
            except RuntimeError as exc:
                if transport.process_exit_code is None and asyncio.get_running_loop().time() < idle_deadline:
                    if not warned_about_idle:
                        self._request.logger.log_to_stderr(
                            f"[{self._request.stage_name}][codex] app-server is still active after {_NOTIFICATION_TIMEOUT_SECONDS}s without notifications; waiting longer before failing",
                            "warning",
                        )
                        warned_about_idle = True
                    continue
                if completed_reply_text and transport.process_exit_code == 0:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] app-server exited after assistant completion without turn/completed; using completed reply",
                        "warning",
                    )
                    return completed_reply_text
                streamed_reply = "".join(streamed_reply_parts).strip()
                if streamed_reply and transport.process_exit_code == 0:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] app-server exited after streaming assistant reply without turn/completed; using streamed reply",
                        "warning",
                    )
                    return streamed_reply
                raise exc
            self._log_notification(payload)
            idle_deadline = asyncio.get_running_loop().time() + _TURN_IDLE_GRACE_SECONDS
            warned_about_idle = False
            method = _json_rpc_notification_method(payload)
            params = payload.get("params")
            if method == "item/started" and isinstance(params, dict):
                item = params.get("item")
                if isinstance(item, dict) and item.get("type") == "agentMessage":
                    item_id = item.get("id")
                    if isinstance(item_id, str) and item_id.strip():
                        active_message_id = item_id
                        phase = item.get("phase")
                        active_message_phase = phase.strip() if isinstance(phase, str) else ""
                        streamed_reply_parts = []
            if method == "item/agentMessage/delta" and isinstance(params, dict):
                item_id = params.get("itemId")
                delta = params.get("delta")
                if (
                    isinstance(item_id, str)
                    and item_id.strip()
                    and isinstance(delta, str)
                    and delta
                ):
                    if active_message_id is None:
                        active_message_id = item_id
                    if item_id != active_message_id:
                        active_message_id = item_id
                        streamed_reply_parts = []
                    streamed_reply_parts.append(delta)
                continue
            if method == "item/completed" and isinstance(params, dict):
                item = params.get("item")
                if isinstance(item, dict) and item.get("type") == "agentMessage":
                    phase = item.get("phase")
                    phase_name = phase.strip() if isinstance(phase, str) else ""
                    item_id = item.get("id")
                    if isinstance(item_id, str) and item_id.strip():
                        active_message_id = item_id
                    if phase_name:
                        active_message_phase = phase_name
                    text = item.get("text")
                    if isinstance(text, str) and text.strip() and phase_name != "commentary":
                        completed_reply_text = text.strip()
                    streamed_reply = "".join(streamed_reply_parts).strip()
                    if (
                        not completed_reply_text
                        and streamed_reply
                        and active_message_phase != "commentary"
                        and transport.process_exit_code == 0
                    ):
                        self._request.logger.log_to_stderr(
                            f"[{self._request.stage_name}][codex] app-server completed assistant message without turn/completed; using streamed reply",
                            "warning",
                        )
                        return streamed_reply
            if method != "turn/completed":
                continue
            if not isinstance(params, dict):
                continue
            if params.get("threadId") != session_id:
                continue
            reply_text = _extract_reply_text(params)
            if not reply_text:
                if completed_reply_text:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] turn completed without embedded reply; using assistant message collected earlier",
                        "warning",
                    )
                    return completed_reply_text
                streamed_reply = "".join(streamed_reply_parts).strip()
                if streamed_reply and active_message_phase != "commentary":
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] turn completed without embedded reply; using assistant message collected earlier",
                        "warning",
                    )
                    return streamed_reply
                raise RuntimeError("Codex app-server completed a turn without a final assistant reply")
            return reply_text

    async def _run(self) -> CodexAppServerResult:
        transport = _CodexAppServerTransport(self._process, self._request)
        init_params: dict[str, Any] = {
            "clientInfo": {
                "name": "cybervisor",
                "version": "1",
            }
        }
        if self._request.model is not None:
            init_params["model"] = self._request.model
        transport.request("initialize", init_params)
        thread_response = transport.request(
            "thread/start",
            {
                "cwd": str(Path.cwd().resolve()),
                "approvalPolicy": "never",
                "sandbox": "workspace-write",
            },
        )
        thread = thread_response.get("thread")
        if not isinstance(thread, dict):
            raise RuntimeError("Codex app-server missing thread object from thread/start")
        session_id = thread.get("id")
        if not isinstance(session_id, str) or not session_id.strip():
            raise RuntimeError("Codex app-server missing thread id from thread/start")

        started_thread_id = await self._await_thread_started(transport)
        if started_thread_id != session_id:
            raise RuntimeError("Codex app-server thread/start response did not match thread/started notification")

        final_reply = ""
        next_prompt = self._request.prompt
        attempts = 0

        while True:
            from cybervisor.adapters.registry import get_adapter

            attempts += 1
            final_reply = await self._run_turn(transport, session_id=session_id, prompt=next_prompt)
            decision = get_adapter("codex").evaluate_reply(
                _HOOK_CONFIG_PATH.resolve(),
                reply_text=final_reply,
                session_id=session_id,
            )
            if not decision.is_blocking:
                break
            continuation_reason = decision.reason.strip() if decision.reason.strip() else "Continue autonomously."
            self._request.logger.log_to_stderr(
                f"[{self._request.stage_name}][codex] verifier requested continuation ({continuation_reason})"
            )
            next_prompt = continuation_message_for_decision(decision)
            if attempts >= 25:
                raise RuntimeError("Codex app-server exceeded the maximum continuation loops for one stage attempt")

        transport_exit_code = transport.close()
        if transport_exit_code != 0:
            self._request.logger.log_to_stderr(
                f"[{self._request.stage_name}][codex] app-server exited with code {transport_exit_code} after approval; treating the stage as success",
                "warning",
            )
        output = transport.transcript or final_reply
        return CodexAppServerResult(exit_code=0, output=output, transport_exit_code=transport_exit_code)

    def wait(self) -> tuple[int, str]:
        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(self._run())
        finally:
            loop.close()
        return result.exit_code, result.output