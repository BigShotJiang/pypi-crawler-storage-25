from __future__ import annotations

import json

from cybervisor.adapters.codex.app_server import notification_to_events
from cybervisor.stream_logging import CanonicalLogEvent, canonicalize_message_text


def _string_value(value: object) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _parse_item_event(item: object, *, event_type: str) -> list[CanonicalLogEvent]:
    if not isinstance(item, dict):
        return []

    item_type = _string_value(item.get("type"))
    if item_type == "agent_message":
        message_text = _string_value(item.get("text"))
        if message_text:
            return canonicalize_message_text(message_text, as_hook_feedback=False)
        return []

    if item_type == "function_call":
        name = _string_value(item.get("name"))
        arguments = item.get("arguments")
        if isinstance(arguments, dict) and name:
            return [CanonicalLogEvent(kind="tool_call", tool_name=name, tool_input=arguments)]
        if name:
            return [CanonicalLogEvent(kind="tool_call", tool_name=name)]
        return []

    if item_type == "function_result":
        return [CanonicalLogEvent(kind="tool_result")]

    if item_type == "command_execution":
        command = _string_value(item.get("command"))
        if event_type == "item.started":
            if command:
                return [CanonicalLogEvent(kind="tool_call", tool_name="Bash", tool_input={"command": command})]
            return [CanonicalLogEvent(kind="tool_call", tool_name="Bash")]
        if event_type == "item.completed":
            exit_code = item.get("exit_code")
            if isinstance(exit_code, int) and exit_code != 0:
                if command:
                    return [CanonicalLogEvent(kind="plain_text", text=f"command failed exit_code={exit_code}: {command}")]
                return [CanonicalLogEvent(kind="plain_text", text=f"command failed exit_code={exit_code}")]
            return []

    return []


def parse_codex_output_line(line: str) -> list[CanonicalLogEvent]:
    if not line:
        return []
    try:
        payload = json.loads(line)
    except json.JSONDecodeError:
        return [CanonicalLogEvent(kind="plain_text", text=line)]

    if not isinstance(payload, dict):
        return [CanonicalLogEvent(kind="plain_text", text=line)]

    method = payload.get("method")
    if method:
        events = notification_to_events(payload)
        if events:
            return events

    event_type = _string_value(payload.get("type")) or ""
    if event_type == "thread.started":
        thread_id = _string_value(payload.get("thread_id"))
        parts = (f"thread_id={thread_id}",) if thread_id else ()
        return [CanonicalLogEvent(kind="session_start", summary_parts=parts)]
    if event_type in {"turn.started", "turn.completed"}:
        return []
    if event_type == "task.started":
        stage = str(payload.get("stage") or "")
        suffix = f" stage={stage}" if stage else ""
        return [CanonicalLogEvent(kind="plain_text", text=f"task.started{suffix}")]
    if event_type in {"item.started", "item.completed"}:
        return _parse_item_event(payload.get("item"), event_type=event_type)
    if event_type == "task.completed":
        result = payload.get("result")
        if result is None:
            return [CanonicalLogEvent(kind="completed", summary_parts=("success",), status="success")]
        return [CanonicalLogEvent(kind="completed", summary_parts=(str(result),), status="success")]
    if event_type == "error":
        message = str(payload.get("message") or "Codex execution failed")
        return [CanonicalLogEvent(kind="plain_text", text=f"error: {message}")]
    return [CanonicalLogEvent(kind="plain_text", text=line)]
