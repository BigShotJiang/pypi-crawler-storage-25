"""Codex app-server helper functions for JSON-RPC parsing and event conversion."""

from __future__ import annotations

import json
from typing import Any, cast

from cybervisor.stream_logging import CanonicalLogEvent, canonicalize_message_text


def _json_rpc_message(message_id: int, method: str, params: dict[str, Any]) -> str:
    return json.dumps({"jsonrpc": "2.0", "id": message_id, "method": method, "params": params})


def _json_rpc_notification_method(payload: dict[str, Any]) -> str | None:
    method = payload.get("method")
    return method if isinstance(method, str) and method.strip() else None


def _json_rpc_response_id(payload: dict[str, Any]) -> int | None:
    response_id = payload.get("id")
    return response_id if isinstance(response_id, int) else None


def _text_input(text: str) -> list[dict[str, str]]:
    return [{"type": "text", "text": text}]


def _phase_sort_key(phase: object) -> int:
    if phase == "final_answer":
        return 1
    if phase == "commentary":
        return 0
    return -1


def _extract_reply_text(turn_payload: dict[str, Any]) -> str:
    turn = turn_payload.get("turn")
    if not isinstance(turn, dict):
        return ""
    items = turn.get("items")
    if not isinstance(items, list):
        return ""

    agent_messages: list[tuple[int, str]] = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") != "agentMessage":
            continue
        text = item.get("text")
        if not isinstance(text, str) or not text.strip():
            continue
        agent_messages.append((_phase_sort_key(item.get("phase")), text.strip()))

    if not agent_messages:
        return ""
    agent_messages.sort(key=lambda item: item[0], reverse=True)
    return agent_messages[0][1]


def _string_value(value: object) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _tool_call_payload(item: dict[str, Any]) -> tuple[str, dict[str, Any] | None] | None:
    item_type = _string_value(item.get("type"))
    if item_type in {"functionCall", "function_call", "toolCall", "tool_call", "customToolCall", "custom_tool_call"}:
        name = _string_value(item.get("name")) or _string_value(item.get("toolName")) or "Tool"
        raw_input = item.get("arguments")
        if raw_input is None:
            raw_input = item.get("input")
        if raw_input is None:
            raw_input = item.get("rawInput")
        if raw_input is None:
            raw_input = item.get("parameters")
        if raw_input is None:
            raw_input = item.get("params")
        if raw_input is None:
            raw_input = item.get("payload")
        if isinstance(raw_input, str):
            try:
                decoded = json.loads(raw_input)
            except json.JSONDecodeError:
                decoded = None
            raw_input = decoded if isinstance(decoded, dict) else {"input": raw_input}
        if raw_input is None:
            for key in ("file_path", "path", "command", "pattern"):
                value = item.get(key)
                if value is not None:
                    raw_input = {key: value}
                    break
        if not isinstance(raw_input, dict):
            raw_input = None
        return name, raw_input

    if item_type == "commandExecution":
        command = _string_value(item.get("command"))
        raw_input = {"command": command} if command is not None else None
        return "Bash", raw_input

    return None


def _file_change_event(item: dict[str, Any]) -> CanonicalLogEvent | None:
    if _string_value(item.get("type")) != "fileChange":
        return None

    changes = item.get("changes")
    if not isinstance(changes, list) or not changes:
        return CanonicalLogEvent(kind="tool_call", tool_name="FileChange")

    first_change = changes[0]
    if not isinstance(first_change, dict):
        return CanonicalLogEvent(kind="tool_call", tool_name="FileChange")

    path = _string_value(first_change.get("path"))
    kind = _string_value(first_change.get("kind"))

    tool_name = "FileChange"
    if kind in {"create", "created", "add", "added"}:
        tool_name = "Write"
    elif kind in {"update", "updated", "modify", "modified", "edit", "edited"}:
        tool_name = "Edit"
    elif kind in {"delete", "deleted", "remove", "removed"}:
        tool_name = "Delete"

    tool_input: dict[str, Any] = {}
    if path is not None:
        tool_input["file_path"] = path
    if len(changes) > 1:
        tool_input["count"] = len(changes)
    if kind is not None and tool_name == "FileChange":
        tool_input["kind"] = kind

    if tool_input:
        return CanonicalLogEvent(kind="tool_call", tool_name=tool_name, tool_input=cast(dict[object, object], tool_input))
    return CanonicalLogEvent(kind="tool_call", tool_name=tool_name)


def _special_item_event(item: dict[str, Any]) -> CanonicalLogEvent | None:
    item_type = _string_value(item.get("type"))
    if item_type == "mcpToolCall":
        server = _string_value(item.get("server"))
        tool = _string_value(item.get("tool"))
        tool_input: dict[str, Any] = {}
        if server is not None:
            tool_input["server"] = server
        if tool is not None:
            tool_input["tool"] = tool
        return CanonicalLogEvent(kind="tool_call", tool_name="MCP", tool_input=cast(dict[object, object], tool_input))
    if item_type == "collabToolCall":
        tool = _string_value(item.get("tool"))
        sender_thread_id = _string_value(item.get("senderThreadId"))
        receiver_thread_id = _string_value(item.get("receiverThreadId"))
        new_thread_id = _string_value(item.get("newThreadId"))
        tool_input = {}
        if tool is not None:
            tool_input["tool"] = tool
        if sender_thread_id is not None:
            tool_input["sender_thread_id"] = sender_thread_id
        if receiver_thread_id is not None:
            tool_input["receiver_thread_id"] = receiver_thread_id
        if new_thread_id is not None:
            tool_input["new_thread_id"] = new_thread_id
        return CanonicalLogEvent(kind="tool_call", tool_name="Collab", tool_input=cast(dict[object, object], tool_input))
    if item_type == "webSearch":
        query = _string_value(item.get("query"))
        action = item.get("action")
        tool_input = {}
        if query is not None:
            tool_input["query"] = query
        if isinstance(action, dict):
            action_type = _string_value(action.get("type"))
            if action_type is not None:
                tool_input["action"] = action_type
        return CanonicalLogEvent(kind="tool_call", tool_name="WebSearch", tool_input=cast(dict[object, object], tool_input))
    if item_type == "imageView":
        path = _string_value(item.get("path"))
        tool_input = {"path": path} if path is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ImageView", tool_input=cast(dict[object, object], tool_input))
    if item_type == "enteredReviewMode":
        review = _string_value(item.get("review"))
        tool_input = {"review": review} if review is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ReviewStart", tool_input=cast(dict[object, object], tool_input))
    if item_type == "exitedReviewMode":
        review = _string_value(item.get("review"))
        tool_input = {"review": review} if review is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ReviewEnd", tool_input=cast(dict[object, object], tool_input))
    return None


def _tool_item_id(payload: dict[str, Any]) -> str | None:
    method = _json_rpc_notification_method(payload)
    params = payload.get("params")
    if method not in {"item/started", "item/completed"} or not isinstance(params, dict):
        return None
    item = params.get("item")
    if not isinstance(item, dict):
        return None
    if _tool_call_payload(item) is None and _file_change_event(item) is None and _special_item_event(item) is None:
        return None
    item_id = item.get("id")
    return item_id.strip() if isinstance(item_id, str) and item_id.strip() else None


def notification_to_events(payload: dict[str, Any]) -> list[CanonicalLogEvent]:
    method = _json_rpc_notification_method(payload)
    params = payload.get("params")
    if method is None or not isinstance(params, dict):
        return []

    if method == "thread/started":
        thread = params.get("thread")
        thread_id = thread.get("id") if isinstance(thread, dict) else None
        parts = (f"thread_id={thread_id}",) if isinstance(thread_id, str) and thread_id else ()
        return [CanonicalLogEvent(kind="session_start", summary_parts=parts)]

    if method == "turn/completed":
        reply_text = _extract_reply_text(params)
        if reply_text:
            return [CanonicalLogEvent(kind="completed", summary_parts=(reply_text,), status="success")]
        return [CanonicalLogEvent(kind="completed", summary_parts=("success",), status="success")]

    if method == "error":
        message = params.get("message")
        if isinstance(message, str) and message.strip():
            return [CanonicalLogEvent(kind="plain_text", text=f"error: {message.strip()}")]

    if method not in {"item/started", "item/completed"}:
        return []
    item = params.get("item")
    if not isinstance(item, dict):
        return []
    if item.get("type") == "agentMessage":
        text = item.get("text")
        if isinstance(text, str) and text.strip():
            return canonicalize_message_text(text.strip(), as_hook_feedback=False)
        return []
    tool_call = _tool_call_payload(item)
    if tool_call is not None:
        title, raw_input = tool_call
        if isinstance(raw_input, dict):
            return [CanonicalLogEvent(kind="tool_call", tool_name=title, tool_input=cast(dict[object, object], raw_input))]
        return [CanonicalLogEvent(kind="tool_call", tool_name=title)]
    file_change_event = _file_change_event(item)
    if file_change_event is not None:
        return [file_change_event]
    special_item_event = _special_item_event(item)
    if special_item_event is not None:
        return [special_item_event]
    return []


def _payload_summary(payload: dict[str, Any]) -> str:
    method = _json_rpc_notification_method(payload)
    if method is not None:
        return method
    response_id = _json_rpc_response_id(payload)
    if response_id is not None:
        return f"response id={response_id}"
    return "unknown payload"