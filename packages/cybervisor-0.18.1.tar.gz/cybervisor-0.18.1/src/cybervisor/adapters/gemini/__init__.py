from cybervisor.adapters.gemini.adapter import GeminiAdapter

_GEMINI_TOOL_NAME_MAP = {
    "read_file": "Read",
    "ReadFile": "Read",
    "write_file": "Write",
    "WriteFile": "Write",
    "edit": "Edit",
    "Edit": "Edit",
    "glob": "Glob",
    "FindFiles": "Glob",
    "grep": "Grep",
    "Grep": "Grep",
    "shell": "Bash",
    "Shell": "Bash",
    "write_todos": "TodoWrite",
    "WriteTodos": "TodoWrite",
}

__all__ = ["GeminiAdapter"]
