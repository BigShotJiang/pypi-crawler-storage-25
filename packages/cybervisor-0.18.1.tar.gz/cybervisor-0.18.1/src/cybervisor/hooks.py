from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from cybervisor.adapters.registry import get_adapter
from cybervisor.config import (
    HookConfig,
    StageContractConfig,
    contract_artifact_path,
    render_contract_guidance,
)

_logger = logging.getLogger(__name__)

HOOK_CONFIG_NAME = "hook_config.json"
STOP_HOOK_VERIFIER_PROMPT_NAME = "stop-hook-verifier.md"
HOOK_SOCKET_NAME = "hook-events.sock"
SNAPSHOT_FILE_SUFFIX = ".snapshot.json"



def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    content = path.read_text(encoding="utf-8").strip()
    if not content:
        return {}
    try:
        payload = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in settings file {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"Settings file must contain a JSON object: {path}")
    return payload


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    """Write JSON payload atomically by writing to a temp file then renaming.

    Falls back to direct write on OSError (e.g. cross-device rename).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(payload, indent=2) + "\n"
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp_path.write_text(content, encoding="utf-8")
        tmp_path.replace(path)
    except OSError:
        _logger.debug("Atomic rename failed for %s, falling back to direct write", path)
        path.write_text(content, encoding="utf-8")
    finally:
        # Clean up temp file if it still exists (e.g. replace succeeded but
        # left the tmp on some edge case, or replace failed before rename).
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass


def _snapshot_path(runtime_dir: Path, agent_tool: str) -> Path:
    return runtime_dir / f"{agent_tool}{SNAPSHOT_FILE_SUFFIX}"


def _persist_settings_snapshot(runtime_dir: Path, agent_tool: str, settings_path: Path) -> None:
    snapshot_path = _snapshot_path(runtime_dir, agent_tool)
    if snapshot_path.exists():
        return

    snapshot_payload = {
        "settings_path": str(settings_path),
        "existed_before_run": settings_path.exists(),
        "original_content": settings_path.read_text(encoding="utf-8") if settings_path.exists() else None,
    }
    _atomic_write_json(snapshot_path, snapshot_payload)


def _restore_settings_snapshot(runtime_dir: Path, agent_tool: str) -> str:
    snapshot_path = _snapshot_path(runtime_dir, agent_tool)
    if not snapshot_path.exists():
        return "skipped"

    payload = _load_json(snapshot_path)
    settings_path = Path(str(payload["settings_path"]))
    existed_before_run = bool(payload.get("existed_before_run"))
    original_content = payload.get("original_content")
    if existed_before_run:
        if not isinstance(original_content, str):
            raise ValueError(f"Snapshot missing original_content for {settings_path}")
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(original_content, encoding="utf-8")
        snapshot_path.unlink(missing_ok=True)
        return "restored"

    if settings_path.exists():
        settings_path.unlink(missing_ok=True)
    if settings_path.parent.exists() and not any(settings_path.parent.iterdir()):
        settings_path.parent.rmdir()
    snapshot_path.unlink(missing_ok=True)
    return "deleted-created-file"


def _runtime_dir() -> Path:
    return Path(".cybervisor/hooks")


def _runtime_hook_config_path(runtime_dir: Path) -> Path:
    return runtime_dir / HOOK_CONFIG_NAME


def hook_socket_path() -> Path:
    return Path(".cybervisor") / HOOK_SOCKET_NAME


def _serialize_stage_contract_for_stage(stage_name: str, contract: StageContractConfig | None) -> dict[str, Any] | None:
    if contract is None:
        return None
    return {
        "workspace_root": str(Path.cwd().resolve()),
        "artifact_path": str(contract_artifact_path(stage_name)),
        "guidance": render_contract_guidance(stage_name, contract),
        "allowed_statuses": list(contract.allowed_statuses),
        "field_descriptions": dict(contract.field_descriptions),
        "field_examples": dict(contract.field_examples),
        "routes": {
            status: {
                "next_stage": route.next_stage,
                "injections": list(route.injections),
                "description": route.description,
            }
            for status, route in contract.routes.items()
        },
    }


def _write_hook_runtime_config(
    runtime_dir: Path,
    agent_tool: str,
    *,
    active_stage_name: str | None = None,
    active_stage_prompt: str | None = None,
    active_stage_contract: StageContractConfig | None = None,
    active_stage_attempt: int | None = None,
    active_stage_max_retries: int | None = None,
    read_only_paths: list[str] | None = None,
) -> None:
    # Verifier settings are resolved from ~/.cybervisor/config.yaml at hook runtime.
    # Keep the hook metadata file non-secret even though the broader pipeline still
    # carries HookConfig as part of loaded configuration.
    payload: dict[str, Any] = {
        "agent_tool": agent_tool,
        "socket_path": str(hook_socket_path()),
        "workspace_root": str(Path.cwd().resolve()),
        "active_stage_name": active_stage_name,
        "active_stage_prompt": active_stage_prompt,
        "active_stage_contract": (
            _serialize_stage_contract_for_stage(active_stage_name, active_stage_contract)
            if active_stage_name is not None
            else None
        ),
        "active_stage_attempt": active_stage_attempt,
        "active_stage_max_retries": active_stage_max_retries,
        "keep_artifacts": [],
        "read_only_paths": read_only_paths or [],
    }
    path = _runtime_hook_config_path(runtime_dir)
    _atomic_write_json(path, payload)


def set_active_stage_contract(
    agent_tool: str,
    stage_name: str | None,
    stage_prompt: str | None,
    contract: StageContractConfig | None,
    *,
    attempt: int | None = None,
    max_retries: int | None = None,
    keep_artifacts: list[str] | None = None,
    read_only_paths: list[str] | None = None,
) -> None:
    adapter = get_adapter(agent_tool)
    if not adapter.descriptor.capabilities.supports_hooks:
        return

    if keep_artifacts is None:
        keep_artifacts = []

    effective_read_only_paths = read_only_paths or []

    runtime_dir = _runtime_dir()
    config_path = _runtime_hook_config_path(runtime_dir)
    if not config_path.exists():
        return

    payload = _load_json(config_path)
    # Ensure workspace_root is preserved even if the file was written before this field existed.
    if "workspace_root" not in payload:
        payload["workspace_root"] = str(Path.cwd().resolve())
    # Reset to empty list first (failure-before-teardown isolation), then overwrite.
    payload["keep_artifacts"] = []
    payload["active_stage_name"] = stage_name
    payload["active_stage_prompt"] = stage_prompt
    payload["active_stage_contract"] = (
        _serialize_stage_contract_for_stage(stage_name, contract)
        if stage_name is not None
        else None
    )
    payload["active_stage_attempt"] = attempt
    payload["active_stage_max_retries"] = max_retries
    payload["keep_artifacts"] = keep_artifacts
    payload["read_only_paths"] = effective_read_only_paths
    _atomic_write_json(config_path, payload)

    # Install or remove the tool-use hook based on whether this stage has read_only_paths.
    if adapter.requires_native_hook_settings():
        settings_path = adapter.settings_path()
        if settings_path is not None and settings_path.exists():
            settings_payload = _load_json(settings_path)
            if effective_read_only_paths:
                settings_payload = adapter.install_tool_use_hook_settings(settings_payload, config_path)
            else:
                settings_payload = adapter.remove_tool_use_hook_settings(settings_payload, config_path)
            _atomic_write_json(settings_path, settings_payload)


def _cleanup_runtime_files(runtime_dir: Path, agent_tool: str | None = None) -> None:
    """Remove runtime files for a specific agent.

    When agent_tool is specified, the agent's snapshot is NOT removed so it can still
    be restored by its own remove_hooks call (e.g. if remove_hooks was called for a
    different adapter first). Shared files (runtime config, socket) are always removed.
    """
    config_path = _runtime_hook_config_path(runtime_dir)
    if config_path.exists():
        config_path.unlink(missing_ok=True)

    socket_path = hook_socket_path()
    if socket_path.exists():
        socket_path.unlink(missing_ok=True)

    # Always remove the agent's snapshot unless agent_tool is specified and we want to
    # preserve it for the agent's own later remove_hooks call. When agent_tool is None,
    # all snapshots are removed (cleanup-all case).
    if agent_tool is None:
        try:
            for f in runtime_dir.iterdir():
                if f.name.endswith(SNAPSHOT_FILE_SUFFIX):
                    f.unlink()
        except OSError as exc:
            _logger.debug("Error iterating runtime directory during cleanup: %s", exc)

    try:
        if runtime_dir.exists() and not any(runtime_dir.iterdir()):
            runtime_dir.rmdir()
    except OSError as exc:
        _logger.debug("Error removing runtime directory during cleanup: %s", exc)

    try:
        cybervisor_dir = runtime_dir.parent
        if cybervisor_dir.exists() and not any(cybervisor_dir.iterdir()):
            cybervisor_dir.rmdir()
    except OSError as exc:
        _logger.debug("Error removing cybervisor directory during cleanup: %s", exc)


def inject_hooks(agent_tool: str, config: HookConfig) -> None:
    adapter = get_adapter(agent_tool)
    if not adapter.descriptor.capabilities.supports_hooks:
        return

    if not adapter.requires_native_hook_settings():
        runtime_dir = _runtime_dir()
        runtime_dir.mkdir(parents=True, exist_ok=True)
        _write_hook_runtime_config(runtime_dir, agent_tool)
        return

    settings_path = adapter.settings_path()
    if settings_path is None:
        return
    payload = _load_json(settings_path)

    runtime_dir = _runtime_dir()
    try:
        runtime_dir.mkdir(parents=True, exist_ok=True)
        _write_hook_runtime_config(runtime_dir, agent_tool)
        runtime_config_path = _runtime_hook_config_path(runtime_dir)
        _persist_settings_snapshot(runtime_dir, agent_tool, settings_path)
        updated_payload = adapter.install_hook_settings(payload, runtime_config_path)
        _atomic_write_json(settings_path, updated_payload)
    except Exception:
        try:
            _restore_settings_snapshot(runtime_dir, agent_tool)
        except Exception as restore_exc:
            _logger.debug("Failed to restore settings snapshot: %s", restore_exc)
        _cleanup_runtime_files(runtime_dir, agent_tool)
        raise


def remove_hooks(agent_tool: str) -> str:
    adapter = get_adapter(agent_tool)
    if not adapter.descriptor.capabilities.supports_hooks:
        return "skipped"

    runtime_dir = _runtime_dir()
    runtime_config_path = _runtime_hook_config_path(runtime_dir)
    if not adapter.requires_native_hook_settings():
        _cleanup_runtime_files(runtime_dir)
        return "skipped"

    settings_path = adapter.settings_path()
    if settings_path is not None and settings_path.exists():
        payload = _load_json(settings_path)
        updated_payload = adapter.remove_hook_settings(payload, runtime_config_path)
        updated_payload = adapter.remove_tool_use_hook_settings(updated_payload, runtime_config_path)
        _atomic_write_json(settings_path, updated_payload)
    restore_result = _restore_settings_snapshot(runtime_dir, agent_tool)
    _cleanup_runtime_files(runtime_dir, agent_tool)
    return restore_result
