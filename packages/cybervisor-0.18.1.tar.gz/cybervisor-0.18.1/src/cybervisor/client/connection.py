"""WebSocket client connection, configuration, and event streaming."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import AsyncIterator

from websockets.asyncio.client import ClientConnection, connect

from cybervisor.global_config import GlobalServerConfig, load_global_config
from cybervisor.server_events import ServerEvent

CONNECT_TIMEOUT = 5.0


@dataclass(frozen=True, slots=True)
class ClientConfig:
    """Configuration for WebSocket client connections."""

    host: str
    port: int
    connect_timeout_seconds: float = CONNECT_TIMEOUT


def _default_config() -> ClientConfig:
    """Load server config from global config with defaults."""
    try:
        cfg = load_global_config()
        server: GlobalServerConfig = cfg.server
    except Exception:  # pragma: no cover
        server = GlobalServerConfig()
    return ClientConfig(host=server.host, port=server.port)


def _resolve_config(host: str | None, port: int | None) -> ClientConfig:
    """Resolve host/port from CLI args or global config defaults."""
    default = _default_config()
    return ClientConfig(
        host=host if host is not None else default.host,
        port=port if port is not None else default.port,
        connect_timeout_seconds=default.connect_timeout_seconds,
    )


async def _connect(uri: str, timeout: float) -> ClientConnection:
    """Open a WebSocket connection with a timeout."""

    async def _open_with_timeout() -> ClientConnection:
        ws = await connect(uri, open_timeout=timeout, close_timeout=2.0)
        return ws

    try:
        ws = await asyncio.wait_for(_open_with_timeout(), timeout=timeout)
        return ws
    except asyncio.TimeoutError as exc:
        raise ConnectionError(f"Connection timeout ({timeout}s) to {uri}") from exc
    except OSError as exc:
        raise ConnectionError(f"Cannot connect to {uri}: {exc}") from exc


async def _receive_events(ws: ClientConnection) -> AsyncIterator[ServerEvent]:
    """Yield parsed ServerEvent objects from a WebSocket connection."""
    try:
        async for raw in ws:
            try:
                data = json.loads(raw) if isinstance(raw, str) else json.loads(raw.decode("utf-8"))
                yield ServerEvent.from_dict(data)
            except (json.JSONDecodeError, KeyError):
                # Skip malformed messages
                continue
    except asyncio.CancelledError:
        # Task was cancelled (e.g., by asyncio.wait_for timeout). The WebSocket
        # will be closed by the caller's finally block. Return normally so the
        # caller can return the accumulated exit code instead of propagating the
        # cancellation.
        return
