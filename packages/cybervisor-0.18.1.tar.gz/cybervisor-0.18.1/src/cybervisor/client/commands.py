"""Daemon client command implementations."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from typing import Any, cast


from cybervisor.client.connection import ClientConfig
from cybervisor.server_events import EventType


def _resolve_config(host: str | None, port: int | None) -> ClientConfig:
    """Resolve host/port from CLI args or global config defaults."""
    from cybervisor.client import _default_config as __default_config
    default = __default_config()
    return ClientConfig(
        host=host if host is not None else default.host,
        port=port if port is not None else default.port,
        connect_timeout_seconds=default.connect_timeout_seconds,
    )


# ---------------------------------------------------------------------------
# ping
# ---------------------------------------------------------------------------


async def ping_daemon(config: ClientConfig, task_id: str | None = None) -> tuple[bool, list[dict[str, Any]]]:
    """Ping the daemon and retrieve active task snapshots.

    Args:
        task_id: If provided, retrieve only the snapshot for this specific task.
                 If None, retrieve all running task snapshots.
    Returns (reachable, tasks) where:
    - reachable: True if daemon responded with PONG, False otherwise
    - tasks: list of active task snapshot dicts from the pong, or [] if unreachable
              or if the daemon predates this feature (pong has no tasks field)
    """
    uri = f"ws://{config.host}:{config.port}"
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events
    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, []

    try:
        await ws.send(json.dumps({"type": EventType.PING.value, "task_id": task_id or ""}))
        async for event in __receive_events(ws):
            if event.type == EventType.PONG.value:
                return True, event.tasks if event.tasks is not None else []
            return False, []
        return False, []
    except Exception:  # pragma: no cover
        return False, []
    finally:
        await ws.close()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


async def run_status_command(host: str | None, port: int | None, task_id: str | None = None) -> int:
    """Run the status command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, ping_daemon

    config = _cli_resolve_config(host, port)
    reachable, tasks = await ping_daemon(config, task_id=task_id)
    if not reachable:
        print(f"Daemon not reachable at ws://{config.host}:{config.port}")
        return 1

    running_tasks = [t for t in tasks if t.get("status") == "running"]

    if task_id is not None:
        matched = [t for t in running_tasks if t.get("task_id") == task_id]
        if not matched:
            print("Task not found.")
            return 1
        task = matched[0]
        active_stage = task.get("active_stage")
        stage_label = active_stage if active_stage is not None else "initializing"
        cwd = task.get("cwd", "unknown")
        end_stage = task.get("end_stage")
        end_before = task.get("end_before")
        bounds = []
        if end_stage:
            bounds.append(f"end_stage={end_stage}")
        if end_before:
            bounds.append(f"end_before={end_before}")
        bounds_str = f", bounds: {', '.join(bounds)}" if bounds else ""
        print(f"Task: {task.get('task_id')} (stage: {stage_label}, cwd: {cwd}{bounds_str})")
    else:
        MAX_STATUS_TASKS = 20
        displayed = running_tasks[:MAX_STATUS_TASKS]
        if displayed:
            for task in displayed:
                active_stage = task.get("active_stage")
                stage_label = active_stage if active_stage is not None else "initializing"
                cwd = task.get("cwd", "unknown")
                end_stage = task.get("end_stage")
                end_before = task.get("end_before")
                bounds = []
                if end_stage:
                    bounds.append(f"end_stage={end_stage}")
                if end_before:
                    bounds.append(f"end_before={end_before}")
                bounds_str = f", bounds: {', '.join(bounds)}" if bounds else ""
                print(f"Running task: {task.get('task_id')} (stage: {stage_label}, cwd: {cwd}{bounds_str})")
        if len(running_tasks) > MAX_STATUS_TASKS:
            print("...")
        if not running_tasks:
            print("No active tasks.")

    print(f"Daemon reachable at ws://{config.host}:{config.port}")
    return 0


# ---------------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------------


async def run_submit_command(
    prompt: str,
    host: str | None,
    port: int | None,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
    end_after: str | None = None,
    end_before: str | None = None,
) -> int:
    """Run the submit command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, submit_and_stream

    config = _cli_resolve_config(host, port)
    try:
        return await submit_and_stream(
            prompt=prompt,
            config=config,
            task_id=task_id,
            config_path=config_path,
            start_stage=start_stage,
            end_after=end_after,
            end_before=end_before,
        )
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# attach
# ---------------------------------------------------------------------------


async def run_attach_command(task_id: str | None, host: str | None, port: int | None) -> int:
    """Run the attach command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, _find_running_task_in_cwd as __find_running_task_in_cwd, attach_and_stream as __attach_and_stream

    config = _cli_resolve_config(host, port)
    resolved_task_id = task_id
    if resolved_task_id is None:
        reachable, running_in_cwd = await __find_running_task_in_cwd(config)
        if not reachable:
            print(f"Daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
            return 1
        if not running_in_cwd:
            print("No active task to attach to.", file=__import__("sys").stderr)
            return 1
        if len(running_in_cwd) > 1:
            print("Multiple tasks are running in this directory. Use 'cybervisor attach <task-id>' to target a specific task.", file=__import__("sys").stderr)
            return 1
        resolved_task_id = cast(str | None, running_in_cwd[0].get("task_id"))
        if resolved_task_id is None:
            print("No active task to attach to.", file=__import__("sys").stderr)
            return 1
    try:
        return await __attach_and_stream(task_id=resolved_task_id, config=config)
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


async def _cancel_task_impl(task_id: str | None, config: ClientConfig) -> tuple[bool, str]:
    """Cancel an active task."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.CANCEL.value,
        "cwd": os.getcwd(),
    }
    if task_id:
        msg["task_id"] = task_id

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in __receive_events(ws):
            if event.type == EventType.PIPELINE_ABORT.value:
                return True, "Task cancelled"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_cancel_command(task_id: str | None, host: str | None, port: int | None) -> int:
    """Run the cancel command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config

    config = _cli_resolve_config(host, port)
    success, message = await _cancel_task_impl(task_id, config)
    if success:
        print(message)
        return 0
    print(message, file=sys.stderr)
    return 1


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


async def dump_task_logs(task_id: str, config: ClientConfig) -> int:
    """Dump all buffered events for a task as JSON Lines."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        await ws.send(json.dumps(msg))
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}
        async for event in __receive_events(ws):
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data = event.to_dict()
                chunk_buffer[chunk_id][chunk_data.get("chunk_index", 0)] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            print(json.dumps(e))
                    del chunk_buffer[chunk_id]
                continue
            if event.type == EventType.EVENT_REPLAY.value and event.events:
                for e in event.events:
                    print(json.dumps(e))
        return 0
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_logs_command(task_id: str, host: str | None, port: int | None) -> int:
    """Run the logs command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config

    config = _cli_resolve_config(host, port)
    return await dump_task_logs(task_id, config)


# ---------------------------------------------------------------------------
# end
# ---------------------------------------------------------------------------


async def update_end_stage(task_id: str | None, *, after: str | None = None, before: str | None = None, config: ClientConfig) -> tuple[bool, str]:
    """Update the end stage of a running task."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.SET_STOP_STAGE.value,
        "cwd": os.getcwd(),
    }
    if after is not None:
        msg["stage"] = after
    if before is not None:
        msg["end_before"] = before
    if task_id:
        msg["task_id"] = task_id

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in __receive_events(ws):
            if event.type == EventType.STOP_STAGE_UPDATED.value:
                return True, f"Updated end stage to: {event.stage}"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_end_command(
    task_id: str | None,
    after: str | None,
    before: str | None,
    host: str | None,
    port: int | None,
) -> int:
    """Run the end command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config

    config = _cli_resolve_config(host, port)
    success, message = await update_end_stage(task_id, after=after, before=before, config=config)
    if success:
        print(message)
        return 0
    print(message, file=sys.stderr)
    return 1