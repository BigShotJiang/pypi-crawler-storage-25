"""Streaming helpers for daemon client: submit, attach, event reassembly, task lookup."""

from __future__ import annotations

import json
import os
import sys
import uuid
from typing import Any

from websockets.asyncio.client import ClientConnection

from cybervisor.client.connection import ClientConfig
from cybervisor.client.rendering import render_event
from cybervisor.logging import CybervisorLogger
from cybervisor.server_events import EventType, ServerEvent


def _reassemble_events(event: ServerEvent) -> list[ServerEvent]:
    """Reassemble an event_replay ServerEvent into its child ServerEvents."""
    if event.type != EventType.EVENT_REPLAY.value:
        return [event]

    events = event.events
    if not events:
        return []

    return [ServerEvent.from_dict(e) for e in events]


async def submit_and_stream(
    prompt: str,
    config: ClientConfig,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
    end_after: str | None = None,
    end_before: str | None = None,
) -> int:
    """Submit a task and stream events until completion."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"
    resolved_task_id = task_id or uuid.uuid4().hex[:12]
    print(f"Task created: {resolved_task_id}", file=sys.stderr)

    task_logger = CybervisorLogger()
    task_logger.log_to_json(
        task_logger.make_entry(
            stage_name="Task",
            status="TaskCreated",
            message=f"Task created: {resolved_task_id}",
            task_id=resolved_task_id,
        ),
        ".cybervisor/logs/cybervisor.log.jsonl",
    )

    msg: dict[str, Any] = {
        "type": EventType.RUN.value,
        "task_id": resolved_task_id,
        "prompt": prompt,
        "cwd": os.getcwd(),
    }
    if config_path:
        msg["config_path"] = config_path
    if start_stage:
        msg["start_stage"] = start_stage
    if end_after:
        msg["end_stage"] = end_after
    if end_before:
        msg["end_before"] = end_before

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        exit_code = 1
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}

        async for event in __receive_events(ws):
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data: dict[str, Any] = event.to_dict()
                chunk_buffer[chunk_id][chunk_data.get("chunk_index", 0)] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            se = ServerEvent.from_dict(e)
                            level, line = render_event(se)
                            if level == "stdout" and line is not None:
                                print(line)
                            elif level == "stderr" and line is not None:
                                print(line, file=__import__("sys").stderr)
                            if se.type == EventType.RUN_COMPLETE.value:
                                exit_code = 0 if se.success else 1
                            if se.type == EventType.ERROR.value:
                                code = se.code or "?"
                                message = se.message or "unknown error"
                                print(f"[ERROR] {code}: {message}", file=sys.stderr)
                                return 1
                    del chunk_buffer[chunk_id]
                continue

            if event.type == EventType.EVENT_REPLAY.value:
                reassembled = _reassemble_events(event)
                for e in reassembled:
                    level, line = render_event(e)
                    if level == "stdout" and line is not None:
                        print(line)
                    elif level == "stderr" and line is not None:
                        print(line, file=__import__("sys").stderr)
                    if e.type == EventType.RUN_COMPLETE.value:
                        exit_code = 0 if e.success else 1
                    if e.type == EventType.ERROR.value:
                        code = e.code or "?"
                        message = e.message or "unknown error"
                        print(f"[ERROR] {code}: {message}", file=sys.stderr)
                        return 1
                continue

            level, line = render_event(event)
            if level == "stdout" and line is not None:
                print(line)
            elif level == "stderr" and line is not None:
                print(line, file=__import__("sys").stderr)

            if event.type == EventType.RUN_COMPLETE.value:
                return 0 if event.success else 1
            if event.type == EventType.PIPELINE_ABORT.value:
                return 1
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                print(f"[ERROR] {code}: {message}", file=sys.stderr)
                return 1

        return exit_code

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        exit_code = await send_and_listen(ws)
        return exit_code
    except StopAsyncIteration:
        return exit_code
    except Exception as exc:
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def attach_and_stream(task_id: str, config: ClientConfig) -> int:
    """Reconnect to a task and stream events until completion."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        _exit_code = [1]
        _run_complete_seen = [False]
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}

        async def handle_chunk(received_events: list[dict[str, Any]]) -> None:
            for e in received_events:
                se = ServerEvent.from_dict(e)
                level, line = render_event(se)
                if level == "stdout" and line is not None:
                    print(line)
                elif level == "stderr" and line is not None:
                    print(line, file=__import__("sys").stderr)
                if se.type == EventType.RUN_COMPLETE.value:
                    _exit_code[0] = 0 if se.success else 1
                    _run_complete_seen[0] = True

        try:
            async for event in __receive_events(ws):
                if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                    chunk_id = event.chunk_id or ""
                    if not chunk_id:
                        continue
                    if chunk_id not in chunk_buffer:
                        chunk_buffer[chunk_id] = {}
                    chunk_data: dict[str, Any] = event.to_dict()
                    idx = chunk_data.get("chunk_index", 0)
                    chunk_buffer[chunk_id][idx] = chunk_data
                    chunk_count = chunk_data.get("chunk_count", 1)
                    if len(chunk_buffer[chunk_id]) == chunk_count:
                        sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                        received = [evt for _, chunk in sorted_chunks for evt in chunk.get("events", [])]
                        await handle_chunk(received)
                        del chunk_buffer[chunk_id]
                        if _run_complete_seen[0]:
                            return _exit_code[0]
                    continue

                if event.type == EventType.EVENT_REPLAY.value:
                    reassembled = _reassemble_events(event)
                    received = [e.to_dict() for e in reassembled]
                    await handle_chunk(received)
                    if _run_complete_seen[0]:
                        return _exit_code[0]
                    continue

                level, line = render_event(event)
                if level == "stdout" and line is not None:
                    print(line)
                elif level == "stderr" and line is not None:
                    print(line, file=__import__("sys").stderr)
                if event.type == EventType.RUN_COMPLETE.value:
                    return 0 if event.success else 1
            return _exit_code[0]
        except StopAsyncIteration:
            return _exit_code[0]

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        return await send_and_listen(ws)
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def find_active_task(config: ClientConfig) -> str | None:
    """Ping daemon and return the task_id of the single running task in current CWD."""
    from cybervisor.client import ping_daemon

    reachable, tasks = await ping_daemon(config)
    if not reachable:
        return None
    current_cwd = os.path.realpath(os.getcwd())
    running_in_cwd = [t for t in tasks if t.get("status") == "running"
                      and os.path.realpath(t.get("cwd", "")) == current_cwd]
    if len(running_in_cwd) == 0:
        return None
    if len(running_in_cwd) > 1:
        raise ValueError("Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.")
    return running_in_cwd[0].get("task_id")


async def _find_running_task_in_cwd(
    config: ClientConfig,
) -> tuple[bool, list[dict[str, Any]] | None]:
    """Ping daemon and return running tasks in current CWD."""
    from cybervisor.client import ping_daemon

    reachable, all_tasks = await ping_daemon(config)
    if not reachable:
        return False, None
    current_cwd = os.path.realpath(os.getcwd())
    running_in_cwd = [
        t
        for t in all_tasks
        if t.get("status") == "running" and os.path.realpath(t.get("cwd", "")) == current_cwd
    ]
    return True, running_in_cwd