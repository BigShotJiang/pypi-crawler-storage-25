"""Shared constants with no internal imports — safe to import from any module."""

from typing import Literal

DEFAULT_ENDPOINT = "https://api.openai.com/v1"
DEFAULT_MODEL = "auto"
AgentToolType = Literal["gemini", "claude", "mock", "codex"]