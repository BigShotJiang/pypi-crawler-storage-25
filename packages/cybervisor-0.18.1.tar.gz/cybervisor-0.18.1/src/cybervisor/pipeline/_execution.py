"""Stage execution and hook-block draining logic for PipelineRunner."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.types import LaunchRequest
from cybervisor.config import StageConfig
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline._cleanup import _cleanup_stage, _get_child_pids
from cybervisor.pipeline._interrupt import PipelineInterrupted, _is_interrupt_exit_code
from cybervisor.signals import SignalHandler

StageEventCallback = Callable[[dict[str, Any]], None]


def _emit_stage_event(callback: StageEventCallback | None, event: dict[str, Any]) -> None:
    if callback is not None:
        callback(event)


def _pop_hook_block(
    hook_listener: HookEventListener | None,
    agent_tool: str | None,
    *,
    wait_for_pending: bool = False,
) -> dict[str, object] | None:
    import time

    if hook_listener is None:
        return None

    hook_block = hook_listener.pop_blocking_decision(agent_tool)
    if hook_block is not None or not wait_for_pending:
        return hook_block

    deadline = time.monotonic() + 0.25
    while time.monotonic() < deadline:
        time.sleep(0.01)
        hook_block = hook_listener.pop_blocking_decision(agent_tool)
        if hook_block is not None:
            return hook_block
    return None


def execute_stage(
    stage: StageConfig,
    stage_prompt: str,
    attempt: int,
    agent: AgentAdapter,
    logger: CybervisorLogger,
    signal_handler: SignalHandler | None,
    hook_listener: HookEventListener | None,
    pipeline_start_time: float,
    stage_event_callback: StageEventCallback | None,
    stage_models: dict[str, str] | None,
    log_file: str,
) -> tuple[bool, str | None, dict[str, object] | None, int | None, dict[str, object] | None, bool]:
    """Execute a single pipeline stage attempt.

    Returns (passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener).
    """
    from cybervisor.pipeline.artifacts import (
        _clean_contract_artifacts_dir,
    )
    from cybervisor.pipeline.contract import (
        _artifact_status_value,
        _format_contract_artifact_output,
        _stage_log_path,
        _validate_stage_artifact,
    )
    from cybervisor.config import contract_artifact_path

    stage_output_log = _stage_log_path(stage.name)
    passed = False
    failure_error: str | None = None
    artifact_payload: dict[str, object] | None = None
    exit_code: int | None = None
    hook_block: dict[str, object] | None = None
    default_hook_listener_usage = bool(agent.descriptor.capabilities.supports_hooks)
    uses_hook_listener = bool(
        getattr(agent, "uses_hook_listener", lambda: default_hook_listener_usage)()
    )
    output = ""
    try:
        if hook_listener is not None and uses_hook_listener:
            hook_listener.clear_pending_blocks(agent.descriptor.name)
        _clean_contract_artifacts_dir(pipeline_start_time=pipeline_start_time, current_stage_name=stage.name)
        _cleanup_stage(stage, Path.cwd())
        if agent.descriptor.capabilities.supports_hooks:
            from cybervisor.pipeline import set_active_stage_contract as _set_active_stage_contract

            _set_active_stage_contract(
                agent.descriptor.name,
                stage.name,
                stage_prompt,
                stage.contract,
                attempt=attempt,
                max_retries=stage.max_retries,
                keep_artifacts=stage.keep_artifacts,
                read_only_paths=stage.read_only_paths,
            )
        running_process = agent.start(
            LaunchRequest(
                prompt=stage_prompt,
                stage_name=stage.name,
                log_file=stage_output_log,
                logger=logger,
                model=(stage_models or {}).get(stage.name),
            )
        )
        if signal_handler is not None:
            signal_handler.set_pid(running_process.pid, running_process.process_group_id)
            if running_process.pid is not None:
                child_pids = _get_child_pids(running_process.pid)
                if child_pids:
                    signal_handler.register_child_pids(child_pids)
        exit_code, output = running_process.wait()
        if signal_handler is not None and signal_handler.interrupted:
            raise PipelineInterrupted(stage.name, attempt, exit_code)
        if _is_interrupt_exit_code(exit_code):
            raise PipelineInterrupted(stage.name, attempt, exit_code)
    except PipelineInterrupted:
        logger.log_to_stderr(f"[{stage.name}] Interrupted during attempt {attempt}", "warning")
        logger.log_to_json(
            logger.make_entry(
                stage.name,
                "Interrupted",
                "Stage interrupted by user",
                agent_tool=agent.descriptor.name,
                attempt=attempt,
                exit_status=exit_code,
                log_path=stage_output_log,
            ),
            log_file,
        )
        raise
    except Exception as exc:
        if signal_handler is not None and signal_handler.interrupted:
            raise PipelineInterrupted(stage.name, attempt, exit_code) from exc
        failure_error = f"Stage execution failed: {exc}"
    else:
        execution_result = agent.run_result(exit_code, output)
        passed = execution_result.lifecycle == agent.completed_status()
        agent.log_execution_result(logger, stage.name, execution_result)
        hook_block = (
            _pop_hook_block(
                hook_listener,
                agent.descriptor.name,
                wait_for_pending=passed or stage.contract is not None,
            )
            if uses_hook_listener
            else None
        )
        if hook_block is not None:
            passed = False
            reason = hook_block.get("reason")
            details = "Hook blocked agent completion"
            if isinstance(reason, str) and reason:
                details = f"{details}: {reason}"
            failure_error = details
        elif stage.contract is not None:
            artifact_payload, artifact_error = _validate_stage_artifact(stage.name, stage.contract)
            if artifact_error is not None:
                passed = False
                failure_error = f"Stage artifact validation failed: {artifact_error}"
            elif artifact_payload is not None:
                passed = True
                failure_error = None
                artifact_status = _artifact_status_value(artifact_payload)
                route = stage.contract.routes.get(artifact_status) if artifact_status is not None else None
                logger.log_to_stderr(_format_contract_artifact_output(stage.name, artifact_payload, route))
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Execution", "").timestamp,
                        "stage_name": stage.name,
                        "status": "ArtifactValidated",
                        "message": "Validated stage artifact",
                        "artifact_path": str(contract_artifact_path(stage.name)),
                        "artifact_status": artifact_status,
                        "artifact_payload": artifact_payload,
                    },
                    log_file,
                )
                _emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "artifact_validated",
                        "stage_name": stage.name,
                        "artifact_status": artifact_status or "",
                    },
                )
        elif not passed and failure_error is None and exit_code != 0:
            failure_error = f"Agent exited with code {exit_code}"
    finally:
        if signal_handler is not None:
            try:
                signal_handler.terminate_descendants()
            except Exception:
                pass
            signal_handler.set_pid(None)
            signal_handler.clear_child_pids()
        if agent.descriptor.capabilities.supports_hooks:
            _set_active_stage_contract(agent.descriptor.name, None, None, None, keep_artifacts=[], read_only_paths=[])

    return passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener


def drain_hook_block(
    stage: StageConfig,
    agent: AgentAdapter,
    logger: CybervisorLogger,
    hook_listener: HookEventListener | None,
    stage_event_callback: StageEventCallback | None,
    passed: bool,
    failure_error: str | None,
    artifact_payload: dict[str, object] | None,
    hook_block: dict[str, object] | None,
    uses_hook_listener: bool,
    log_file: str,
) -> tuple[bool, str | None, dict[str, object] | None, dict[str, object] | None]:
    """Drain remaining hook blocks after stage execution.

    Returns (passed, failure_error, artifact_payload, hook_block).
    """
    from cybervisor.pipeline.contract import (
        _artifact_status_value,
        _format_contract_artifact_output,
        _validate_stage_artifact,
    )
    from cybervisor.config import contract_artifact_path

    if not uses_hook_listener:
        return passed, failure_error, artifact_payload, hook_block

    queue_drained = True
    drain_limit = 10
    for _ in range(drain_limit):
        next_block = _pop_hook_block(
            hook_listener,
            agent.descriptor.name,
            wait_for_pending=False,
        )
        if next_block is None:
            break
        hook_block = next_block
    else:
        queue_drained = False

    if hook_block is not None:
        if stage.contract is not None:
            artifact_payload, artifact_error = _validate_stage_artifact(stage.name, stage.contract)
            if artifact_error is not None:
                passed = False
                failure_error = f"Stage artifact validation failed: {artifact_error}"
                artifact_payload = None
            else:
                hook_block = None
                passed = True
                failure_error = None
                assert artifact_payload is not None
                artifact_status = _artifact_status_value(artifact_payload)
                route = stage.contract.routes.get(artifact_status) if artifact_status is not None else None
                logger.log_to_stderr(_format_contract_artifact_output(stage.name, artifact_payload, route))
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Execution", "").timestamp,
                        "stage_name": stage.name,
                        "status": "ArtifactValidated",
                        "message": "Validated stage artifact (drain re-check)",
                        "artifact_path": str(contract_artifact_path(stage.name)),
                        "artifact_status": artifact_status,
                        "artifact_payload": artifact_payload,
                    },
                    log_file,
                )
                _emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "artifact_validated",
                        "stage_name": stage.name,
                        "artifact_status": artifact_status or "",
                    },
                )
        elif queue_drained:
            hook_block = None
            passed = True
            failure_error = None

    return passed, failure_error, artifact_payload, hook_block