"""Pipeline runner: stage loop, retry logic, and end-stage references."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cybervisor.adapters.base import AgentAdapter
from cybervisor.config import StageConfig, render_contract_guidance
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline._execution import (
    StageEventCallback,
    _emit_stage_event,
    drain_hook_block,
    execute_stage,
)
from cybervisor.pipeline._interrupt import (
    EndStageRef,
    PipelineInterrupted,
)
from cybervisor.pipeline._routing import (
    build_injection_appendix,
    build_prompt_context,
    build_read_only_paths_section,
    resolve_next_stage,
    update_stage_context_from_artifact,
)
from cybervisor.signals import SignalHandler


class PipelineRunner:
    def __init__(self, log_file: str = ".cybervisor/logs/cybervisor.log.jsonl") -> None:
        self.log_file = log_file

    def run(
        self,
        prompt: str | None,
        stages: list[StageConfig],
        agent: AgentAdapter,
        logger: CybervisorLogger,
        signal_handler: SignalHandler | None = None,
        hook_listener: HookEventListener | None = None,
        start_stage_name: str | None = None,
        end_after_name: str | None = None,
        end_before_stage_name: str | None = None,
        end_stage_ref: EndStageRef | None = None,
        end_before_ref: EndStageRef | None = None,
        stage_event_callback: StageEventCallback | None = None,
        stage_models: dict[str, str] | None = None,
    ) -> bool:
        from cybervisor.pipeline.artifacts import (
            _artifact_file_path,
            _artifact_runtime_root,
            _cleanup_artifact_dir,
        )
        from cybervisor.pipeline.contract import (
            _render_prompt,
            _stage_log_path,
        )

        stage_lookup = {stage.name: index for index, stage in enumerate(stages)}

        if end_after_name is not None and end_after_name not in stage_lookup:
            raise ValueError(f"Unknown end_after_name '{end_after_name}'. Valid stages are: {', '.join(stage_lookup.keys())}")
        if end_before_stage_name is not None and end_before_stage_name not in stage_lookup:
            raise ValueError(
                f"Unknown end_before_stage_name '{end_before_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}"
            )
        if start_stage_name is not None and start_stage_name not in stage_lookup:
            raise ValueError(f"Unknown start_stage_name '{start_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}")
        if end_after_name is not None and end_before_stage_name is not None:
            raise ValueError("--end-after and --end-before cannot be used together.")

        retry_counts = [0 for _ in stages]
        iteration_counts = [0 for _ in stages]
        current_index = 0

        if start_stage_name is not None:
            current_index = stage_lookup[start_stage_name]
        did_reset = current_index == 0
        pipeline_start_time = time.time()
        if did_reset:
            workspace_path = Path.cwd()
            cybervisor_dir = workspace_path / ".cybervisor"
            cybervisor_dir.mkdir(exist_ok=True)
            pipeline_marker = cybervisor_dir / ".pipeline_start"
            pipeline_marker.write_text(f"{pipeline_start_time}\n", encoding="utf-8")

            _cleanup_artifact_dir(
                _artifact_runtime_root(),
                skip_if_files_present=True,
                pipeline_start_time=None,
            )
            _cleanup_artifact_dir(
                _artifact_file_path("").parent,
                skip_if_files_present=True,
                pipeline_start_time=None,
            )

        if end_after_name is not None:
            end_index = stage_lookup[end_after_name]
            if current_index > end_index:
                raise ValueError(f"Invalid sequence: start stage '{start_stage_name}' occurs after end stage '{end_after_name}', so pipeline cannot realistically reach the end stage.")
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry("Startup", "TargetedStart", "").timestamp,
                    "stage_name": "Startup",
                    "status": "TargetedStart",
                    "message": "Starting pipeline at requested stage",
                    "requested_stage_name": start_stage_name,
                    "effective_stage_name": stages[current_index].name,
                    "total_stage_count": len(stages),
                },
                self.log_file,
            )
        elif end_before_stage_name is not None:
            end_before_index = stage_lookup[end_before_stage_name]
            if current_index > end_before_index:
                raise ValueError(
                    f"Invalid sequence: start stage '{start_stage_name}' occurs after exclusive end stage '{end_before_stage_name}', so pipeline cannot stop before that stage."
                )
            if current_index == end_before_index:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry("Startup", "TargetedEndBefore", "").timestamp,
                        "stage_name": "Startup",
                        "status": "TargetedEndBefore",
                        "message": "Skipping pipeline execution because start stage matches exclusive end boundary",
                        "requested_stage_name": end_before_stage_name,
                        "effective_stage_name": stages[current_index].name,
                        "total_stage_count": len(stages),
                    },
                    self.log_file,
                )
                return True

        stage_context: dict[str, str] = {}
        stage_appendices: dict[str, str] = {}

        while current_index < len(stages):
            if end_before_stage_name is not None and stages[current_index].name == end_before_stage_name:
                break
            current_end_before = end_before_ref.get() if end_before_ref is not None else None
            if current_end_before is not None and stages[current_index].name == current_end_before:
                break
            stage = stages[current_index]
            attempt = retry_counts[current_index] + 1
            if retry_counts[current_index] == 0:
                iteration_counts[current_index] += 1
            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt - 1)
            if stage.max_iterations > 0 and iteration_counts[current_index] > stage.max_iterations:
                next_stage_name = stage.max_iterations_next_stage
                next_index: int | None = None
                if next_stage_name is not None and next_stage_name in stage_lookup:
                    next_index = stage_lookup[next_stage_name]
                else:
                    next_index = current_index + 1
                logger.log_to_stderr(
                    f"[{stage.name}] Max iterations exceeded "
                    f"({iteration_counts[current_index]}/{stage.max_iterations}), "
                    f"routing to {stages[next_index].name if next_index < len(stages) else 'end'}",
                    "warning",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "MaxIterationsExceeded", "").timestamp,
                        "stage_name": stage.name,
                        "status": "MaxIterationsExceeded",
                        "message": "Stage iteration count exceeded max_iterations; forcing route",
                        "decision_source": "max_iterations_exceeded",
                        "max_iterations": stage.max_iterations,
                        "iteration_count": iteration_counts[current_index],
                        "next_stage": stages[next_index].name if next_index < len(stages) else None,
                    },
                    self.log_file,
                )
                _emit_stage_event(stage_event_callback, {
                    "event_type": "max_iterations_exceeded",
                    "stage_name": stage.name,
                    "max_iterations": stage.max_iterations,
                    "iteration_count": iteration_counts[current_index],
                    "next_stage": stages[next_index].name if next_index < len(stages) else None,
                })
                current_end_stage = end_stage_ref.get() if end_stage_ref is not None else end_after_name
                current_end_before = end_before_ref.get() if end_before_ref is not None else None
                if current_end_stage is not None and next_index > stage_lookup[current_end_stage]:
                    break
                if next_index >= len(stages):
                    return True
                current_index = next_index
                continue
            if attempt > stage.max_retries:
                logger.log_to_stderr(f"[{stage.name}] Exhausted retries", "error")
                logger.log_to_json(
                    logger.make_entry(stage.name, "Failed", "Retries exhausted"),
                    self.log_file,
                )
                _emit_stage_event(stage_event_callback, {
                    "event_type": "stage_failed",
                    "stage_name": stage.name,
                    "attempt": attempt,
                    "error": "Retries exhausted",
                })
                return False

            if stage.max_iterations > 0:
                logger.log_to_stderr(f"[{stage.name}] Running attempt {attempt} (iteration {iteration_counts[current_index]}/{stage.max_iterations})")
            else:
                logger.log_to_stderr(f"[{stage.name}] Running attempt {attempt}")
            prepared_result = agent.prepare()
            running_result = agent.running()
            json_entry: dict[str, Any] = {
                "timestamp": logger.make_entry(stage.name, "Running", "").timestamp,
                "stage_name": stage.name,
                "status": "Running",
                "message": f"attempt={attempt}",
                "adapter_lifecycle": prepared_result.lifecycle.value,
                "adapter_outcome": prepared_result.outcome.value,
            }
            if stage.max_iterations > 0:
                json_entry["iteration_count"] = iteration_counts[current_index]
                json_entry["max_iterations"] = stage.max_iterations
            logger.log_to_json(json_entry, self.log_file)
            stage_start_event: dict[str, Any] = {
                "event_type": "stage_start",
                "stage_name": stage.name,
                "attempt": attempt,
                "max_retries": stage.max_retries,
            }
            if stage.max_iterations > 0:
                stage_start_event["iteration_count"] = iteration_counts[current_index]
                stage_start_event["max_iterations"] = stage.max_iterations
            _emit_stage_event(stage_event_callback, stage_start_event)
            agent.log_execution_result(logger, stage.name, prepared_result)
            agent.log_execution_result(logger, stage.name, running_result)

            context = build_prompt_context(prompt, stage.name, stage_context)
            stage_prompt, missing_keys = _render_prompt(stage.prompt_template, context)
            appended_context = stage_appendices.get(stage.name, "")
            if appended_context:
                stage_prompt = f"{stage_prompt.rstrip()}\n\n{appended_context}"
            read_only_section = build_read_only_paths_section(stage.read_only_paths)
            if read_only_section:
                stage_prompt = f"{stage_prompt.rstrip()}\n\n{read_only_section}"
            if stage.contract is not None:
                stage_prompt = f"{stage_prompt.rstrip()}\n\n{render_contract_guidance(stage.name, stage.contract)}"
            if missing_keys:
                missing = ", ".join(sorted(missing_keys))
                logger.log_to_stderr(
                    f"[{stage.name}] Missing template placeholders defaulted to empty: {missing}",
                    "warning",
                )

            passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener = execute_stage(
                stage, stage_prompt, attempt, agent, logger, signal_handler,
                hook_listener, pipeline_start_time, stage_event_callback, stage_models,
                self.log_file,
            )

            passed, failure_error, artifact_payload, hook_block = drain_hook_block(
                stage, agent, logger, hook_listener, stage_event_callback,
                passed, failure_error, artifact_payload, hook_block, uses_hook_listener,
                self.log_file,
            )

            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt, exit_code)

            if not passed:
                retry_counts[current_index] += 1
                logger.log_to_stderr(f"[{stage.name}] Failed on attempt {attempt}", "warning")
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Failed",
                        "Stage failed, retrying",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=_stage_log_path(stage.name),
                    ),
                    self.log_file,
                )
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Execution",
                        "Stage attempt finished",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=_stage_log_path(stage.name),
                    ),
                    self.log_file,
                )
                _emit_stage_event(stage_event_callback, {
                    "event_type": "stage_retry",
                    "stage_name": stage.name,
                    "attempt": attempt,
                    "max_retries": stage.max_retries,
                    "error": failure_error or "Stage failed",
                })
                continue

            from cybervisor.pipeline.artifacts import _backup_stage_artifacts

            _backup_stage_artifacts(
                stage_name=stage.name,
                backup_artifacts=stage.backup_artifacts,
                logger=logger,
                log_file=self.log_file,
                timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%S"),
            )

            next_index, status, decision_source, inject_sections = resolve_next_stage(
                stages,
                stage_lookup,
                current_index,
                artifact_payload,
            )
            if decision_source == "contract_missing_route":
                logger.log_to_stderr(
                    f"[{stage.name}] Artifact status '{status}' has no matching contract route. Add an explicit route such as contract.routes.approved.",
                    "error",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Failed", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Failed",
                        "message": "Contract artifact status has no matching route",
                        "artifact_status": status,
                    },
                    self.log_file,
                )
                return False
            if decision_source == "contract_invalid_route":
                logger.log_to_stderr(
                    f"[{stage.name}] Contract route references unknown stage. Check your cybervisor.yaml routes.",
                    "error",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Failed", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Failed",
                        "message": "Contract route references unknown stage",
                        "artifact_status": status,
                    },
                    self.log_file,
                )
                return False
            if decision_source == "invalid_next_stage":
                logger.log_to_stderr(
                    f"[{stage.name}] next_stage references an unknown stage. Check your cybervisor.yaml.",
                    "error",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Failed", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Failed",
                        "message": "next_stage references unknown stage",
                    },
                    self.log_file,
                )
                return False
            if artifact_payload is not None:
                update_stage_context_from_artifact(stage, artifact_payload, stage_context, inject_sections)
            stage_appendices.pop(stage.name, None)

            if decision_source == "contract_route" and artifact_payload is not None and next_index is not None:
                stage_appendices[stages[next_index].name] = build_injection_appendix(
                    artifact_payload,
                    inject_sections,
                )
            elif next_index is not None and next_index < len(stages):
                stage_appendices.pop(stages[next_index].name, None)

            retry_counts[current_index] = 0

            logger.log_to_stderr(f"[{stage.name}] Success")
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Success",
                    "Stage completed",
                    agent_tool=agent.descriptor.name,
                ),
                self.log_file,
            )
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Execution",
                    "Stage attempt finished",
                    agent_tool=agent.descriptor.name,
                    attempt=attempt,
                    exit_status=exit_code,
                    log_path=_stage_log_path(stage.name),
                ),
                self.log_file,
            )
            _emit_stage_event(stage_event_callback, {
                "event_type": "stage_complete",
                "stage_name": stage.name,
                "success": True,
                "attempt": attempt,
            })
            current_end_stage = end_stage_ref.get() if end_stage_ref is not None else end_after_name
            if current_end_stage is not None and current_end_stage == stage.name:
                logger.log_to_stderr(f"[{stage.name}] Reached requested end_after, stopping pipeline.")
                logger.log_to_json(
                    logger.make_entry(stage.name, "Execution", "Reached requested end_after, stopping pipeline."),
                    self.log_file,
                )
                break
            if artifact_payload is not None and status is not None:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Routing", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Routing",
                        "message": "Resolved next stage from contract status",
                        "artifact_status": status,
                        "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                        "decision_source": decision_source,
                    },
                    self.log_file,
                )
                _emit_stage_event(stage_event_callback, {
                    "event_type": "routing_decision",
                    "stage_name": stage.name,
                    "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                    "decision_source": decision_source,
                })
            if decision_source == "contract_terminal":
                return True

            if next_index is None:
                return True
            current_index = next_index

        return True