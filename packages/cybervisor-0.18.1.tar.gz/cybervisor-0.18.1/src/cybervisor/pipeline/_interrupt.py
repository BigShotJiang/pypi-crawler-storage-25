"""End-stage reference, pipeline interruption, and exit-code classification."""

from __future__ import annotations

import signal
import threading


class EndStageRef:
    """Thread-safe mutable reference for dynamic end stage updates.

    Allows the daemon to update the end stage mid-pipeline via set_stop_stage,
    which the PipelineRunner checks at each stage boundary.
    """

    def __init__(self, initial_value: str | None = None) -> None:
        self._value = initial_value
        self._lock = threading.Lock()

    def get(self) -> str | None:
        with self._lock:
            return self._value

    def set(self, value: str | None) -> None:
        with self._lock:
            self._value = value


class PipelineInterrupted(Exception):
    def __init__(self, stage_name: str, attempt: int, exit_code: int | None = None) -> None:
        self.stage_name = stage_name
        self.attempt = attempt
        self.exit_code = exit_code
        detail = f" during attempt {attempt}" if attempt > 0 else ""
        status = f" (exit_code={exit_code})" if exit_code is not None else ""
        super().__init__(f"Pipeline interrupted in stage '{stage_name}'{detail}{status}")


def _is_interrupt_exit_code(exit_code: int | None) -> bool:
    if exit_code is None:
        return False
    if exit_code == 130:
        return True
    return exit_code in (-signal.SIGINT, -signal.SIGTERM)