"""Routing logic for determining the next pipeline stage."""

from __future__ import annotations


from cybervisor.config import StageConfig


def resolve_next_stage(
    stages: list[StageConfig],
    stage_lookup: dict[str, int],
    current_index: int,
    artifact_payload: dict[str, object] | None,
) -> tuple[int | None, str | None, str, list[str]]:
    """Resolve the next stage index from contract routing or linear fallback.

    Returns (next_index, status, decision_source, inject_sections).
    """
    from cybervisor.pipeline.contract import (
        _artifact_status_value,
        _resolve_contract_status,
    )

    stage = stages[current_index]
    status: str | None = None
    decision_source = "linear_fallback"

    if artifact_payload is not None:
        status = _artifact_status_value(artifact_payload)
        if status is None:
            return None, None, "contract_missing_status", []
        if stage.contract is not None:
            resolved_status = _resolve_contract_status(stage.contract, status)
            route = stage.contract.routes.get(resolved_status) if resolved_status is not None else None
            if route is None:
                return None, status, "contract_missing_route", []
            if route.next_stage is None:
                return None, resolved_status, "contract_terminal", list(route.injections)
            if route.next_stage not in stage_lookup:
                return None, resolved_status, "contract_invalid_route", list(route.injections)
            return stage_lookup[route.next_stage], resolved_status, "contract_route", list(route.injections)

    if stage.next_stage is not None:
        if stage.next_stage not in stage_lookup:
            return None, status, "invalid_next_stage", []
        return stage_lookup[stage.next_stage], status, "success_route", []

    return current_index + 1, status, decision_source, []


def update_stage_context_from_artifact(
    stage: StageConfig,
    artifact_payload: dict[str, object],
    stage_context: dict[str, str],
    inject_sections: list[str],
) -> None:
    """Update stage context with artifact field values."""
    from cybervisor.pipeline.contract import (
        _artifact_field_context_key,
        _normalized_artifact_payload,
        _stage_context_key,
        _stringify_context_value,
    )

    stage_key = _stage_context_key(stage.name)
    normalized_payload = _normalized_artifact_payload(artifact_payload)

    for section, raw_value in normalized_payload.items():
        if section in {"status", "Status"}:
            continue
        context_key = _artifact_field_context_key(section)
        rendered_value = _stringify_context_value(raw_value)
        stage_context[f"{stage_key}_contract_{context_key}"] = rendered_value
        if section in inject_sections:
            stage_context[f"latest_contract_{context_key}"] = rendered_value


def build_injection_appendix(artifact_payload: dict[str, object], inject_sections: list[str]) -> str:
    """Build the injection appendix from contract artifact payload."""
    from cybervisor.pipeline.contract import (
        _format_injected_contract_value,
        _stringify_context_value,
    )

    if not inject_sections:
        return ""

    parts: list[str] = []
    for section in inject_sections:
        value = _stringify_context_value(artifact_payload.get(section))
        if not value:
            continue
        formatted = _format_injected_contract_value(section, value)
        if formatted:
            parts.append(formatted)

    if not parts:
        return ""
    return "Latest routed contract context:\n\n" + "\n\n".join(parts)


def build_read_only_paths_section(read_only_paths: list[str]) -> str:
    """Build the read-only paths section for stage prompts."""
    if not read_only_paths:
        return ""
    lines = ["The following paths are read-only for this stage. Do not modify files matching these patterns:"]
    for pattern in read_only_paths:
        lines.append(f"- {pattern}")
    return "\n".join(lines)


def build_prompt_context(
    prompt: str | None,
    stage_name: str,
    stage_context: dict[str, str],
) -> dict[str, str]:
    """Build the prompt context dictionary for template rendering."""
    context: dict[str, str] = {
        "objective": prompt if prompt is not None else "",
        "stage_name": stage_name,
    }
    context.update(stage_context)
    return context