"""Stage cleanup helpers: file/directory removal and process-tree inspection."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

import psutil

from cybervisor.config import StageConfig


def _cleanup_stage(stage: StageConfig, workspace_root: Path) -> None:
    """Remove files at declared cleanup paths before a stage's agent starts.

    For directories: removes all contents (files, symlinks, and subdirectories)
    recursively, preserving only the directory itself. For regular files or
    symlinks: removes them directly. Missing paths are skipped. Deletion
    errors are caught and logged as warnings — the pipeline must not crash.
    """
    if not stage.cleanup:
        return
    logger = logging.getLogger(__name__)
    resolved_root = workspace_root.resolve()
    for raw_path in stage.cleanup:
        target = resolved_root / raw_path
        resolved = target.resolve()
        # Validate traversal safety (should have been caught at config time,
        # but double-check at runtime)
        if not resolved.is_relative_to(resolved_root):
            logger.warning(
                "cleanup entry '%s' resolves outside workspace root; skipping",
                raw_path,
            )
            continue
        if not target.exists() and not target.is_symlink():
            logger.debug("cleanup entry '%s' does not exist; skipping", raw_path)
            continue
        if target.is_dir() and not target.is_symlink():
            for entry in target.iterdir():
                try:
                    if entry.is_dir() and not entry.is_symlink():
                        shutil.rmtree(entry)
                        logger.debug("cleanup removed directory tree: %s", entry)
                    else:
                        entry.unlink()
                        logger.debug("cleanup removed file: %s", entry)
                except OSError as exc:
                    logger.warning(
                        "cleanup failed to remove '%s': %s", entry, exc
                    )
        elif target.is_file() or target.is_symlink():
            try:
                target.unlink()
                logger.debug("cleanup removed file: %s", target)
            except OSError as exc:
                logger.warning(
                    "cleanup failed to remove '%s': %s", target, exc
                )


def _get_child_pids(parent_pid: int) -> list[int]:
    try:
        parent = psutil.Process(parent_pid)
        return [child.pid for child in parent.children(recursive=True)]
    except (ProcessLookupError, psutil.NoSuchProcess, psutil.AccessDenied):
        return []