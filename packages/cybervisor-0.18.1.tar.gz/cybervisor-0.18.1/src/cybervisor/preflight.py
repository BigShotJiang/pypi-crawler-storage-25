from __future__ import annotations

import shutil

from cybervisor.adapters.registry import get_adapter
from cybervisor.config import PipelineConfig


def run_preflight(agent_tool: str, config: PipelineConfig) -> list[str]:
    errors: list[str] = []
    adapter = get_adapter(agent_tool)
    requirements = adapter.preflight_requirements()

    for binary in requirements.required_binaries:
        if shutil.which(binary) is None:
            message_factory = getattr(requirements, "missing_binary_message", None)
            if callable(message_factory):
                errors.append(str(message_factory(binary)))
            else:
                errors.append(
                    (
                        f"Required tool '{binary}' was not found on PATH. "
                        f"Install it and verify with `{binary} --version`."
                    )
                )

    if requirements.requires_verifier_config and not config.hook.api_key:
        errors.append(
            (
                "Verifier API key is required for non-mock execution. "
                "Set `llm.api_key` in ~/.cybervisor/config.yaml."
            )
        )

    environment_check = getattr(adapter, "is_supported_environment", None)
    environment_message = getattr(requirements, "unsupported_environment_message", None)
    if callable(environment_check) and callable(environment_message) and not bool(environment_check()):
        errors.append(str(environment_message()))

    return errors
