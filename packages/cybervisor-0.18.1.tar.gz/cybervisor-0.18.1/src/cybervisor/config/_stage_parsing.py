"""Stage and contract parsing helpers for cybervisor configuration."""

from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Any

from cybervisor.config._types import (
    DEFAULT_TEMPLATE,
    STAGE_KNOWN_FIELDS,
    StageConfig,
    StageContractConfig,
    StageRouteConfig,
)

__all__ = [
    "STAGE_KNOWN_FIELDS",
    "_load_backup_artifacts",
    "_load_stage",
    "_load_stage_contract",
    "_validate_stage_definitions",
]


def _validate_injection_name(stage_name: str, status: str, raw_value: object) -> str:
    section = str(raw_value).strip()
    if not section:
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must not contain empty values")
    if section == "status":
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must not include reserved field 'status'")
    return section


def _validate_route_description(stage_name: str, status: str, raw_value: object) -> str:
    description = str(raw_value).strip()
    if not description:
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' description must be a non-empty string")
    return description


def _validate_field_description_name(stage_name: str, raw_name: object, *, context: str) -> str:
    field_name = str(raw_name).strip()
    if not field_name:
        raise ValueError(f"Stage '{stage_name}' {context} must not contain empty field names")
    if field_name == "status":
        raise ValueError(f"Stage '{stage_name}' {context} must not include reserved field 'status'")
    return field_name


def _validate_field_description_text(stage_name: str, field_name: str, raw_description: object) -> str:
    description = str(raw_description).strip()
    if not description:
        raise ValueError(
            f"Stage '{stage_name}' contract field description for '{field_name}' must be a non-empty string"
        )
    return description


def _load_field_descriptions(stage_name: str, raw_mapping: object, *, context: str) -> dict[str, str]:
    if raw_mapping is None:
        return {}
    if not isinstance(raw_mapping, dict):
        raise ValueError(f"Stage '{stage_name}' {context} must be a mapping")
    field_descriptions: dict[str, str] = {}
    for raw_field_name, raw_description in raw_mapping.items():
        field_name = _validate_field_description_name(stage_name, raw_field_name, context=context)
        field_descriptions[field_name] = _validate_field_description_text(stage_name, field_name, raw_description)
    return field_descriptions


def _load_field_definitions(
    stage_name: str,
    raw_mapping: object,
    *,
    context: str,
) -> tuple[dict[str, str], dict[str, list[str]]]:
    if raw_mapping is None:
        return {}, {}
    if not isinstance(raw_mapping, dict):
        raise ValueError(f"Stage '{stage_name}' {context} must be a mapping")

    descriptions: dict[str, str] = {}
    examples: dict[str, list[str]] = {}
    for raw_field_name, raw_definition in raw_mapping.items():
        field_name = _validate_field_description_name(stage_name, raw_field_name, context=context)
        if isinstance(raw_definition, str):
            descriptions[field_name] = _validate_field_description_text(stage_name, field_name, raw_definition)
            continue
        if not isinstance(raw_definition, dict):
            raise ValueError(f"Stage '{stage_name}' {context} entry for '{field_name}' must be a mapping or string")
        description = _validate_field_description_text(stage_name, field_name, raw_definition.get("description", ""))
        descriptions[field_name] = description
        example_values: list[str] = []
        single_example = raw_definition.get("example")
        if single_example is not None:
            rendered = str(single_example).strip()
            if rendered:
                example_values.append(rendered)
        raw_examples = raw_definition.get("examples", [])
        if raw_examples:
            if not isinstance(raw_examples, list):
                raise ValueError(f"Stage '{stage_name}' {context} entry for '{field_name}' examples must be a list")
            for raw_example in raw_examples:
                rendered = str(raw_example).strip()
                if rendered:
                    example_values.append(rendered)
        if example_values:
            examples[field_name] = example_values
    return descriptions, examples


def _load_backup_artifacts(stage_name: str, raw_list: object) -> list[str]:
    if raw_list is None:
        return []
    if not isinstance(raw_list, list):
        raise ValueError(f"Stage '{stage_name}' backup_artifacts must be a list")
    seen: set[str] = set()
    result: list[str] = []
    for entry in raw_list:
        if not isinstance(entry, str):
            raise ValueError(f"Stage '{stage_name}' backup_artifacts entries must be strings, got {type(entry).__name__}")
        if not entry:
            raise ValueError(f"Stage '{stage_name}' backup_artifacts entries must not be empty strings")
        if entry not in seen:
            seen.add(entry)
            result.append(entry)
    return result


def _load_stage_contract(stage_name: str, contract_raw: dict[str, Any]) -> StageContractConfig:
    removed_fields = {"allowed_statuses", "artifact_path", "artifact_kind", "input_bindings", "prompt_file"}
    present_removed_fields = sorted(removed_fields.intersection(contract_raw))
    if present_removed_fields:
        keys = ", ".join(present_removed_fields)
        raise ValueError(
            f"Stage '{stage_name}' contract no longer supports {keys}; use fixed .cybervisor/contracts paths instead"
        )

    field_descriptions = _load_field_descriptions(stage_name, contract_raw.get("field_descriptions", {}), context="contract field_descriptions")
    field_examples: dict[str, list[str]] = {}
    contract_fields_descriptions, contract_fields_examples = _load_field_definitions(
        stage_name,
        contract_raw.get("fields", {}),
        context="contract fields",
    )
    field_descriptions.update(contract_fields_descriptions)
    field_examples.update(contract_fields_examples)
    richer_contract_descriptions, richer_contract_examples = _load_field_definitions(
        stage_name,
        contract_raw.get("field_definitions", {}),
        context="contract field_definitions",
    )
    field_descriptions.update(richer_contract_descriptions)
    field_examples.update(richer_contract_examples)

    routes_raw = contract_raw.get("routes", {})
    if not isinstance(routes_raw, dict):
        raise ValueError(f"Stage '{stage_name}' contract routes must be a mapping")
    routes: dict[str, StageRouteConfig] = {}
    for raw_status, raw_route in routes_raw.items():
        status = str(raw_status).strip()
        if not status:
            raise ValueError(f"Stage '{stage_name}' contract routes must use non-empty status keys")
        if raw_route is None:
            raw_route = {}
        if not isinstance(raw_route, dict):
            raise ValueError(
                f"Stage '{stage_name}' contract route '{status}' must be a mapping with next_stage and injections"
            )
        next_stage_raw = raw_route.get("next_stage")
        target = str(next_stage_raw).strip() if next_stage_raw is not None else None
        if target == "":
            target = None
        description_raw = raw_route.get("description")
        description = None
        if description_raw is not None:
            description = _validate_route_description(stage_name, status, description_raw)
        injections_raw = raw_route.get("injections", [])
        if not isinstance(injections_raw, list):
            raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must be a list")
        injections: list[str] = []
        for raw_section in injections_raw:
            section = _validate_injection_name(stage_name, status, raw_section)
            if section not in injections:
                injections.append(section)
            if section not in field_descriptions:
                raise ValueError(
                    f"Stage '{stage_name}' contract route '{status}' injects '{section}' without a field description"
                )
        routes[status] = StageRouteConfig(
            next_stage=target,
            injections=injections,
            description=description,
        )

    allowed_statuses = list(routes)
    return StageContractConfig(
        allowed_statuses=allowed_statuses,
        routes=routes,
        field_descriptions=field_descriptions,
        field_examples=field_examples,
    )


def _load_stage(stage_raw: dict[str, Any]) -> StageConfig:
    import os
    import warnings

    name = str(stage_raw.get("name", "")).strip()
    if not name:
        raise ValueError("Each stage must have a non-empty name")
    unknown_fields = set(stage_raw.keys()) - STAGE_KNOWN_FIELDS
    if unknown_fields:
        raise ValueError(
            f"Stage '{name}' contains unknown field(s): {', '.join(sorted(unknown_fields))}. "
            "Run 'cybervisor docs cybervisor.yaml' for configuration guidelines."
        )
    has_authored_prompt_template = "prompt_template" in stage_raw and stage_raw.get("prompt_template") is not None
    prompt_template = str(stage_raw.get("prompt_template") or DEFAULT_TEMPLATE)
    max_retries = int(stage_raw.get("max_retries", 3))
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")
    next_stage_raw = stage_raw.get("next_stage")
    next_stage = str(next_stage_raw).strip() if next_stage_raw is not None else None
    if next_stage == "":
        next_stage = None
    contract_raw = stage_raw.get("contract")
    contract: StageContractConfig | None = None
    if contract_raw is not None:
        if next_stage is not None:
            raise ValueError(
                f"Stage '{name}' must not define next_stage when contract routing is enabled; move success routing into contract.routes.approved"
            )
        if not isinstance(contract_raw, dict):
            raise ValueError(f"Stage '{name}' contract must be a mapping")
        contract = _load_stage_contract(name, contract_raw)
    keep_artifacts_raw = stage_raw.get("keep_artifacts")
    keep_artifacts: list[str] = []
    if keep_artifacts_raw is not None:
        if not isinstance(keep_artifacts_raw, list):
            raise ValueError(f"Stage '{name}' keep_artifacts must be a list")
        seen: set[str] = set()
        for entry in keep_artifacts_raw:
            if not isinstance(entry, str):
                raise ValueError(f"Stage '{name}' keep_artifacts entries must be strings, got {type(entry).__name__}")
            if not entry:
                raise ValueError(f"Stage '{name}' keep_artifacts entries must not be empty strings")
            if entry not in seen:
                seen.add(entry)
                keep_artifacts.append(entry)
    backup_artifacts_raw = stage_raw.get("backup_artifacts")
    backup_artifacts: list[str] = _load_backup_artifacts(name, backup_artifacts_raw)
    cleanup_raw = stage_raw.get("cleanup")
    cleanup: list[str] = []
    if cleanup_raw is not None:
        if not isinstance(cleanup_raw, list):
            raise ValueError(f"Stage '{name}' cleanup must be a list")
        seen_paths: set[str] = set()
        for entry in cleanup_raw:
            if not isinstance(entry, str):
                raise ValueError(f"Stage '{name}' cleanup entries must be strings, got {type(entry).__name__}")
            if not entry:
                raise ValueError(f"Stage '{name}' cleanup entries must not be empty strings")
            if Path(entry).is_absolute():
                raise ValueError(f"Stage '{name}' cleanup entry '{entry}' must be a relative path")
            resolved = (Path.cwd() / entry).resolve()
            if not resolved.is_relative_to(Path.cwd().resolve()):
                raise ValueError(f"Stage '{name}' cleanup entry '{entry}' resolves outside the workspace root")
            if entry not in seen_paths:
                seen_paths.add(entry)
                cleanup.append(entry)
        for cp in cleanup:
            cp_resolved = (Path.cwd() / cp).resolve()
            contracts_resolved = (Path.cwd() / ".cybervisor/contracts").resolve()
            hooks_resolved = (Path.cwd() / ".cybervisor/hooks").resolve()
            if cp_resolved == contracts_resolved or str(cp_resolved).startswith(str(contracts_resolved) + os.sep):
                warnings.warn(
                    f"Stage '{name}' cleanup entry '{cp}' targets .cybervisor/contracts/ which is managed by the existing contract artifact cleanup mechanism",
                    stacklevel=2,
                )
            if cp_resolved == hooks_resolved or str(cp_resolved).startswith(str(hooks_resolved) + os.sep):
                warnings.warn(
                    f"Stage '{name}' cleanup entry '{cp}' targets .cybervisor/hooks/ which contains the hook runtime config; deleting it would break hook execution",
                    stacklevel=2,
                )
        for cp in cleanup:
            cp_resolved = (Path.cwd() / cp).resolve()
            for ka in keep_artifacts:
                ka_resolved = (Path.cwd() / ka).resolve()
                if cp_resolved == ka_resolved or str(ka_resolved).startswith(str(cp_resolved) + os.sep):
                    warnings.warn(
                        f"Stage '{name}' cleanup entry '{cp}' is a parent of keep_artifacts entry '{ka}'; cleanup removes ALL files regardless of keep_artifacts",
                        stacklevel=2,
                    )
    max_iterations_raw = stage_raw.get("max_iterations", 0)
    max_iterations = int(max_iterations_raw) if max_iterations_raw is not None else 0
    if max_iterations < 0:
        raise ValueError(f"Stage '{name}' max_iterations must be >= 0")
    max_iterations_next_stage_raw = stage_raw.get("max_iterations_next_stage")
    max_iterations_next_stage: str | None = None
    if max_iterations_next_stage_raw is not None:
        max_iterations_next_stage = str(max_iterations_next_stage_raw).strip()
        if not max_iterations_next_stage:
            max_iterations_next_stage = None
    if max_iterations > 0 and max_iterations_next_stage is None:
        warnings.warn(
            f"Stage '{name}' has max_iterations={max_iterations} but no max_iterations_next_stage; "
            "runtime will fall back to sequential advance on iteration exhaustion",
            stacklevel=2,
        )
    if max_iterations == 0:
        max_iterations_next_stage = None
    read_only_paths_raw = stage_raw.get("read_only_paths")
    read_only_paths: list[str] = []
    if read_only_paths_raw is not None:
        if not isinstance(read_only_paths_raw, list):
            raise ValueError(f"Stage '{name}' read_only_paths must be a list")
        for entry in read_only_paths_raw:
            if not isinstance(entry, str):
                raise ValueError(f"Stage '{name}' read_only_paths entries must be strings, got {type(entry).__name__}")
            if not entry:
                raise ValueError(f"Stage '{name}' read_only_paths entries must not be empty strings")
            if Path(entry).is_absolute():
                raise ValueError(f"Stage '{name}' read_only_paths entry '{entry}' must be a relative path, not absolute")
            if ".." in Path(entry).parts:
                raise ValueError(f"Stage '{name}' read_only_paths entry '{entry}' must not contain path traversal ('..')")
            if entry not in read_only_paths:
                read_only_paths.append(entry)
        for rop in read_only_paths:
            for ka in keep_artifacts:
                if rop == ka or fnmatch.fnmatch(ka, rop):
                    warnings.warn(
                        f"Stage '{name}' read_only_paths entry '{rop}' conflicts with keep_artifacts entry '{ka}'; "
                        "the hook will block writes to keep_artifacts paths that match read_only_paths patterns",
                        stacklevel=2,
                    )
    return StageConfig(
        name=name,
        prompt_template=prompt_template,
        has_authored_prompt_template=has_authored_prompt_template,
        max_retries=max_retries,
        next_stage=next_stage,
        contract=contract,
        keep_artifacts=keep_artifacts,
        backup_artifacts=backup_artifacts,
        cleanup=cleanup,
        max_iterations=max_iterations,
        max_iterations_next_stage=max_iterations_next_stage,
        read_only_paths=read_only_paths,
    )


def _validate_stage_definitions(stages: list[StageConfig]) -> None:
    stage_names: list[str] = [stage.name for stage in stages]
    unique_names = set(stage_names)
    if len(unique_names) != len(stage_names):
        raise ValueError("Stage names must be unique when loading configuration")

    for stage in stages:
        if stage.next_stage is not None and stage.next_stage not in unique_names:
            raise ValueError(
                f"Stage '{stage.name}' next_stage target '{stage.next_stage}' does not match any configured stage"
            )
        if stage.max_iterations_next_stage is not None and stage.max_iterations_next_stage not in unique_names:
            raise ValueError(
                f"Stage '{stage.name}' max_iterations_next_stage target '{stage.max_iterations_next_stage}' does not match any configured stage"
            )
        contract = stage.contract
        if contract is None:
            continue
        if not contract.routes:
            raise ValueError(
                f"Stage '{stage.name}' contract must define explicit routes; add contract.routes.approved to advance on approval"
            )
        for route in contract.routes.values():
            if route.next_stage is not None and route.next_stage not in unique_names:
                raise ValueError(
                    f"Stage '{stage.name}' contract route target '{route.next_stage}' does not match any configured stage"
                )