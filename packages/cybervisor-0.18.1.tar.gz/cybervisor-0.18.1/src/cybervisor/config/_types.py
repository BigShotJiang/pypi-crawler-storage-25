"""Dataclasses, constants, and formatting helpers for cybervisor configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re

from cybervisor._constants import DEFAULT_ENDPOINT, DEFAULT_MODEL

STAGE_KNOWN_FIELDS = frozenset({"name", "prompt_template", "max_retries", "next_stage", "contract", "keep_artifacts", "backup_artifacts", "cleanup", "max_iterations", "max_iterations_next_stage", "read_only_paths"})

DEFAULT_STAGE_NAMES = ["Spec", "Review Spec", "Implement", "Review Code", "Verify"]
DEFAULT_TEMPLATE = "Execute stage '{stage_name}' for objective: {objective}"
DEFAULT_ALLOWED_STATUSES = ["approved", "changes_requested"]
CONTRACT_ROOT = Path(".cybervisor/contracts")
CONTRACT_ARTIFACTS_DIR = CONTRACT_ROOT / "artifacts"
CONTRACT_PROMPTS_DIR = CONTRACT_ROOT / "prompts"


@dataclass(slots=True)
class StageConfig:
    name: str
    prompt_template: str = DEFAULT_TEMPLATE
    has_authored_prompt_template: bool = False
    max_retries: int = 3
    next_stage: str | None = None
    contract: "StageContractConfig | None" = None
    keep_artifacts: list[str] = field(default_factory=list)
    backup_artifacts: list[str] = field(default_factory=list)
    cleanup: list[str] = field(default_factory=list)
    max_iterations: int = 0
    max_iterations_next_stage: str | None = None
    read_only_paths: list[str] = field(default_factory=list)


@dataclass(slots=True)
class StageRouteConfig:
    next_stage: str | None = None
    injections: list[str] = field(default_factory=list)
    description: str | None = None


@dataclass(slots=True)
class StageContractConfig:
    allowed_statuses: list[str] = field(default_factory=lambda: list(DEFAULT_ALLOWED_STATUSES))
    routes: dict[str, StageRouteConfig] = field(default_factory=dict)
    field_descriptions: dict[str, str] = field(default_factory=dict)
    field_examples: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class HookConfig:
    api_endpoint: str = DEFAULT_ENDPOINT
    api_key: str = ""
    model: str = DEFAULT_MODEL


@dataclass(slots=True)
class PipelineConfig:
    hook: HookConfig = field(default_factory=HookConfig)
    stages: list[StageConfig] = field(default_factory=lambda: [StageConfig(name=n) for n in DEFAULT_STAGE_NAMES])
    disabled_skills: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    category: str
    message: str
    remediation: str
    stage_name: str | None = None
    status: str | None = None
    field_name: str | None = None


class StrictValidationError(ValueError):
    def __init__(self, path: Path, issues: list[ValidationIssue]) -> None:
        self.path = path
        self.issues = issues
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        return "\n".join(format_validation_issue(issue) for issue in self.issues)


def contract_artifact_path(stage_name: str) -> Path:
    return CONTRACT_ARTIFACTS_DIR / f"{stage_name}.yaml"


def contract_prompt_path(stage_name: str) -> Path:
    return CONTRACT_PROMPTS_DIR / f"{stage_name}.md"


def _display_field_name(field_name: str) -> str:
    if field_name == "status":
        return "Status"
    return field_name.replace("_", " ").title()


def _contract_field_names_by_status(contract: StageContractConfig) -> dict[str, list[str]]:
    return {status: list(route.injections) for status, route in contract.routes.items()}


def _contract_field_names(contract: StageContractConfig) -> list[str]:
    field_names: list[str] = []
    seen_fields: set[str] = set()
    for route_field_names in _contract_field_names_by_status(contract).values():
        for field_name in route_field_names:
            if field_name in seen_fields:
                continue
            seen_fields.add(field_name)
            field_names.append(field_name)
    return field_names


def _field_example_lines(contract: StageContractConfig, field_name: str) -> list[str]:
    examples = contract.field_examples.get(field_name, [])
    if examples:
        return str(examples[0]).splitlines()
    description = contract.field_descriptions.get(field_name, f"Provide {field_name}.")
    return str(description).splitlines()


def format_validation_issue(issue: ValidationIssue) -> str:
    context_parts: list[str] = []
    if issue.stage_name is not None:
        context_parts.append(f"stage={issue.stage_name}")
    if issue.status is not None:
        context_parts.append(f"status={issue.status}")
    if issue.field_name is not None:
        context_parts.append(f"field={issue.field_name}")
    prefix = f"[{'; '.join(context_parts)}] " if context_parts else ""
    return f"{prefix}{issue.message} Remediation: {issue.remediation}"


def _text_mentions_status(text: str, status: str) -> bool:
    token_pattern = rf"(?<![A-Za-z0-9_]){re.escape(status)}(?![A-Za-z0-9_])"
    return re.search(token_pattern, text) is not None


def render_contract_guidance(stage_name: str, contract: StageContractConfig) -> str:
    artifact_path = contract_artifact_path(stage_name)
    field_names_by_status = _contract_field_names_by_status(contract)
    field_names = _contract_field_names(contract)

    lines = [f"Write `{artifact_path}` as YAML that matches the selected `Status` route exactly."]

    if field_names:
        lines.extend(["", "Field descriptions:"])
        for field_name in field_names:
            description = contract.field_descriptions.get(field_name)
            if description:
                lines.append(f"- `{field_name}`: {description}")

    lines.extend(["", "Full examples:"])
    for status, route in contract.routes.items():
        route_field_names = field_names_by_status[status]
        lines.extend(
            [
                "",
                f"If `Status` is `{status}`, a complete example looks like:",
                "",
                "```yaml",
                f"{_display_field_name('status')}: {status}",
            ]
        )
        if route_field_names:
            for field_name in route_field_names:
                lines.append(f"{_display_field_name(field_name)}: |")
                for line in _field_example_lines(contract, field_name):
                    lines.append(f"  {line}")
        lines.append("```")

    lines.extend(["", "Instructions:"])
    lines.append(f"- `Status` must be one of: {', '.join(contract.allowed_statuses)}")
    for status, route in contract.routes.items():
        route_field_names = field_names_by_status[status]
        if route_field_names:
            rendered_fields = ", ".join(route_field_names)
            lines.append(f"- if `Status` is `{status}`, provide non-empty strings only for: {rendered_fields}")
        else:
            lines.append(f"- if `Status` is `{status}`, do not add any injected fields beyond `Status`")
        if route.description:
            lines.append(f"- `{status}`: {route.description}")
        if route.next_stage is not None:
            lines.append(f"- `{status}` routes to `{route.next_stage}`")
    lines.append("- do not include fields from another route")
    lines.append("- this stage must write valid YAML and keep any required injected fields concise and actionable")
    return "\n".join(lines) + "\n"