"""Configuration loading, validation, and resolution entry points."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from cybervisor._constants import AgentToolType
from cybervisor.config._stage_parsing import _load_stage, _validate_stage_definitions
from cybervisor.config._types import (
    DEFAULT_STAGE_NAMES,
    HookConfig,
    PipelineConfig,
    StageConfig,
    StrictValidationError,
    ValidationIssue,
    _contract_field_names,
    _contract_field_names_by_status,
    _text_mentions_status,
)
from cybervisor.global_config import GlobalConfigError, _validate_agent_tool, load_global_config


def _validate_agent_tool_local(value: str) -> AgentToolType:
    try:
        return _validate_agent_tool(value)
    except GlobalConfigError as exc:
        raise ValueError(str(exc)) from exc


def _load_hook_config_from_global_config(*, cwd: Path | None = None) -> HookConfig:
    try:
        global_config = load_global_config(cwd=cwd)
    except GlobalConfigError as exc:
        raise ValueError(str(exc)) from exc
    return HookConfig(
        api_endpoint=global_config.llm.base_url,
        api_key=global_config.llm.api_key,
        model=global_config.llm.model,
    )


def _validate_hook_config_is_env_only(raw_hook: dict[str, Any]) -> None:
    forbidden = {"api_endpoint", "api_key", "model"}
    present = forbidden.intersection(raw_hook.keys())
    if present:
        keys = ", ".join(sorted(present))
        raise ValueError(f"'hook' must not set {keys}; use ~/.cybervisor/config.yaml instead")



def _load_raw_config(config_path: Path) -> dict[str, Any]:
    suffix = config_path.suffix.lower()

    if suffix in {".yaml", ".yml"}:
        loaded = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if loaded is None:
            return {}
        if not isinstance(loaded, dict):
            raise ValueError("Configuration file root must be a YAML mapping")
        if not all(isinstance(k, str) for k in loaded.keys()):
            raise ValueError("Configuration file mapping keys must be strings")
        return dict(loaded)

    raise ValueError(f"Unsupported config file type: {config_path.suffix} (expected .yaml/.yml)")


def resolve_config_path(path: str | Path) -> Path:
    config_path = Path(path)
    if config_path.exists():
        return config_path
    if config_path.suffix == "":
        for ext in (".yaml", ".yml"):
            candidate = config_path.with_suffix(ext)
            if candidate.exists():
                return candidate
    return config_path


def collect_strict_validation_issues(*, config_path: Path, config: PipelineConfig) -> list[ValidationIssue]:
    del config_path
    issues: list[ValidationIssue] = []
    for stage in config.stages:
        contract = stage.contract
        if contract is None:
            continue

        configured_statuses = set(contract.routes)
        field_names_by_status = _contract_field_names_by_status(contract)
        configured_field_names = set(_contract_field_names(contract))

        for status, route in contract.routes.items():
            for field_name in route.injections:
                if contract.field_examples.get(field_name):
                    continue
                issues.append(
                    ValidationIssue(
                        category="contract_shape",
                        stage_name=stage.name,
                        status=status,
                        field_name=field_name,
                        message=f"Injected field `{field_name}` needs a configured full example for strict validation.",
                        remediation=(
                            f"Add `contract.fields[{field_name!r}].example` or `examples` so guidance can render "
                            "a complete YAML example."
                        ),
                    )
                )

            if route.description is not None:
                for described_status in configured_statuses:
                    if described_status == status:
                        continue
                    if _text_mentions_status(route.description, described_status):
                        issues.append(
                            ValidationIssue(
                                category="guidance_sync",
                                stage_name=stage.name,
                                status=status,
                                message=(
                                    f"Route description for `{status}` must not mention unrelated status `{described_status}`."
                                ),
                                remediation=(
                                    "Keep each route description focused on its own status and routing outcome only."
                                ),
                            )
                        )
                for unrelated_field_name in configured_field_names.difference(field_names_by_status[status]):
                    if _text_mentions_status(route.description, unrelated_field_name):
                        issues.append(
                            ValidationIssue(
                                category="guidance_sync",
                                stage_name=stage.name,
                                status=status,
                                field_name=unrelated_field_name,
                                message=(
                                    f"Route description for `{status}` must not imply unrelated field `{unrelated_field_name}`."
                                ),
                                remediation=(
                                    "Keep each route description aligned with only the fields that route injects and the routing decision it represents."
                                ),
                            )
                        )

    return issues


def validate_config_file(path: str | Path) -> tuple[Path, PipelineConfig]:
    from cybervisor.config._types import render_contract_guidance

    config_path = resolve_config_path(path)
    config = load_config(config_path)
    for stage in config.stages:
        if stage.contract is None:
            continue
        render_contract_guidance(stage.name, stage.contract)
    issues = collect_strict_validation_issues(config_path=config_path, config=config)
    if issues:
        raise StrictValidationError(config_path, issues)
    return config_path, config


def validate_prompt_templates(config: PipelineConfig) -> list[str]:
    offending: list[str] = []
    for stage in config.stages:
        if stage.has_authored_prompt_template:
            continue
        if "{objective}" in stage.prompt_template:
            offending.append(stage.name)
    return offending


def config_supports_promptless_run(config: PipelineConfig, *, start_stage_name: str | None = None) -> tuple[bool, list[str]]:
    effective_stages = config.stages
    if start_stage_name is not None:
        start_index = next(index for index, stage in enumerate(config.stages) if stage.name == start_stage_name)
        effective_stages = config.stages[start_index:]
    missing_objective_stages = validate_prompt_templates(PipelineConfig(hook=config.hook, stages=effective_stages))
    return not missing_objective_stages, missing_objective_stages


def load_config(path: str | Path, *, cwd: Path | None = None) -> PipelineConfig:
    config_path = resolve_config_path(path)

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    raw = _load_raw_config(config_path)

    pipeline_raw = raw.get("pipeline", {})
    hook_raw = raw.get("hook", {})
    stages_raw = raw.get("stages", [])
    if not isinstance(pipeline_raw, dict):
        raise ValueError("'pipeline' must be a mapping")
    if not isinstance(hook_raw, dict):
        raise ValueError("'hook' must be a mapping")
    if not isinstance(stages_raw, list):
        raise ValueError("'stages' must be a list")

    if "agent_tool" in pipeline_raw:
        raise ValueError(
            "'pipeline.agent_tool' is no longer supported; select an agent locally with `cybervisor use <agent_tool>`"
        )
    _validate_hook_config_is_env_only(hook_raw)
    hook = _load_hook_config_from_global_config(cwd=cwd)

    if len(stages_raw) == 0:
        pipeline_stages = pipeline_raw.get("stages")
        if pipeline_stages is not None:
            raise ValueError(
                "Stages must be declared at the top-level `stages` key, not under `pipeline.stages`. "
                "Move your stage definitions to the top-level `stages:` list in your cybervisor.yaml."
            )
        stages = [StageConfig(name=n) for n in DEFAULT_STAGE_NAMES]
    else:
        if not all(isinstance(stage, dict) for stage in stages_raw):
            raise ValueError("Each stage must be a mapping")
        stages = [_load_stage(stage) for stage in stages_raw]
    _validate_stage_definitions(stages)

    disabled_skills_raw = raw.get("disabled_skills", [])
    disabled_skills: list[str] = []
    if disabled_skills_raw is not None:
        if not isinstance(disabled_skills_raw, list):
            raise ValueError("'disabled_skills' must be a list")
        for entry in disabled_skills_raw:
            if not isinstance(entry, str):
                raise ValueError(f"'disabled_skills' entries must be strings, got {type(entry).__name__}")
            skill_name = entry.strip()
            if not skill_name:
                continue
            if "/" in skill_name or "\\" in skill_name:
                raise ValueError(f"'disabled_skills' entry '{entry}' must not contain path separators")
            if skill_name == "." or skill_name == "..":
                raise ValueError(f"'disabled_skills' entry '{entry}' must be a valid skill name, not a directory traversal")
            disabled_skills.append(skill_name)

    if "protected_paths" in raw:
        raise ValueError(
            "The 'protected_paths' key has been renamed to 'read_only_paths' and moved under stages. "
            "Please update your cybervisor.yaml to use per-stage 'read_only_paths' lists."
        )

    if "read_only_paths" in raw:
        raise ValueError(
            "The top-level 'read_only_paths' key is no longer supported. "
            "Please move 'read_only_paths' into individual stage definitions in your cybervisor.yaml. "
            "For example:\n\n"
            "  stages:\n"
            "    - name: Spec\n"
            "      read_only_paths:\n"
            "        - \"src/**\"\n"
            "        - \"pyproject.toml\"\n"
        )

    return PipelineConfig(hook=hook, stages=stages, disabled_skills=disabled_skills)