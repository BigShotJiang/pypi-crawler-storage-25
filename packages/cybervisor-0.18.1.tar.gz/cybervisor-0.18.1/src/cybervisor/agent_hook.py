from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

from cybervisor.core_hooks import common as _common
from cybervisor.core_hooks.runner import run_hook, run_tool_use_hook

_logger = logging.getLogger(__name__)


def main() -> None:
    """Entry point for cybervisor-agent-hook CLI."""
    import argparse

    parser = argparse.ArgumentParser(description="Standalone Agent Hook for Cybervisor")
    parser.add_argument("--config", required=True, help="Path to hook runtime configuration")
    parser.add_argument("--mode", choices=["stop", "tool-use"], default="stop", help="Hook mode: 'stop' (default) for agent completion, 'tool-use' for PreToolUse/BeforeToolCall")

    args, _unknown = parser.parse_known_args()

    config_path = Path(args.config)

    # Read stdin
    input_data = sys.stdin.read()

    try:
        if args.mode == "tool-use":
            output = run_tool_use_hook(config_path, input_data)
        else:
            output = run_hook(config_path, input_data)
        sys.stdout.write(json.dumps(output) + "\n")
    except Exception as exc:
        # Fallback if run_hook fails. Emit an error event through the socket so
        # the pipeline always sees a reason, then return the fallback block.
        agent_tool_for_fallback: str | None = None
        try:
            runtime_config = _common.load_hook_runtime_config(config_path)
            raw_agent_tool = runtime_config.get("agent_tool")
            if isinstance(raw_agent_tool, str) and raw_agent_tool:
                agent_tool_for_fallback = raw_agent_tool
            raw_socket_path = runtime_config.get("socket_path")
            socket_path = raw_socket_path if isinstance(raw_socket_path, str) and raw_socket_path else None
            if socket_path:
                error_event = {
                    "timestamp": _common.utc_now(),
                    "event": "fallback_error_emitted",
                    "message": f"Hook entrypoint error: {exc}",
                    "agent_tool": agent_tool_for_fallback,
                    "error": str(exc),
                }
                _common.send_hook_event(socket_path, error_event)
        except Exception as socket_exc:
            _logger.debug("Failed to emit fallback error event via socket: %s", socket_exc)

        if args.mode == "tool-use":
            from cybervisor.core_hooks.runner import _tool_use_block
            error_fallback = _tool_use_block(agent_tool_for_fallback or "", f"cli_entrypoint_error:{exc}")
        else:
            # In stop mode, if the config file is missing the pipeline has
            # ended and cleaned up. Approve the stop — blocking would only
            # delay an already-completed pipeline.
            if isinstance(exc, FileNotFoundError):
                error_fallback = {"decision": "approve", "reason": "pipeline_ended_config_removed"}
            else:
                error_fallback = {"decision": "block", "reason": f"cli_entrypoint_error:{exc}"}
        sys.stdout.write(json.dumps(error_fallback) + "\n")
        sys.exit(0)  # Agents expect 0 for clean hook execution even when blocking.


if __name__ == "__main__":
    main()
