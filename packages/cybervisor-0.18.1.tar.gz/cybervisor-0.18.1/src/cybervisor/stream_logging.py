from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

_THINK_TAG_PATTERN = re.compile(r"<think>(.*?)</think>", re.DOTALL | re.IGNORECASE)
_MAX_TOOL_VALUE_LENGTH = 80
_OMITTED_TOOL_FIELDS = {"content", "old_string", "new_string", "contents", "text", "todos"}

CanonicalEventKind = Literal[
    "plain_text",
    "session_start",
    "thinking",
    "reply",
    "tool_call",
    "tool_result",
    "hook_feedback",
    "completed",
]


@dataclass(frozen=True)
class CanonicalLogEvent:
    kind: CanonicalEventKind
    text: str | None = None
    tool_name: str | None = None
    tool_input: dict[object, object] | None = None
    summary_parts: tuple[str, ...] = field(default_factory=tuple)
    status: str | None = None


def _collapse_whitespace(value: str) -> str:
    return " ".join(value.split())


def _normalize_multiline_text(value: str) -> str:
    lines = [_collapse_whitespace(line) for line in value.splitlines()]
    normalized_lines: list[str] = []
    previous_blank = False
    for line in lines:
        if line:
            normalized_lines.append(line)
            previous_blank = False
            continue
        if not previous_blank:
            normalized_lines.append("")
        previous_blank = True
    while normalized_lines and normalized_lines[0] == "":
        normalized_lines.pop(0)
    while normalized_lines and normalized_lines[-1] == "":
        normalized_lines.pop()
    return "\n".join(normalized_lines)


def _prefix_multiline_text(prefix: str, value: str) -> str:
    normalized = _normalize_multiline_text(value)
    if not normalized:
        return prefix
    lines = normalized.splitlines()
    return "\n".join([f"{prefix} {lines[0]}", *[f"  {line}" if line else "" for line in lines[1:]]])


def _summarize_hook_feedback(value: str) -> str:
    normalized = _normalize_multiline_text(value)
    if not normalized:
        return "hook feedback received"
    line_count = len(normalized.splitlines())
    char_count = len(normalized)
    return f"hook feedback received ({line_count} lines, {char_count} chars)"


def _render_reply_text(prefix: str, value: str) -> str:
    normalized = _normalize_multiline_text(value)
    if not normalized:
        return prefix
    if "\n" not in normalized:
        return f"{prefix} {normalized}"
    body = "\n".join(f"  {line}" if line else "" for line in normalized.splitlines())
    return f"{prefix}\n\n{body}\n"


def canonicalize_message_text(message_text: str, *, as_hook_feedback: bool) -> list[CanonicalLogEvent]:
    if as_hook_feedback:
        return [CanonicalLogEvent(kind="hook_feedback", text=message_text)]

    think_matches = [match.strip() for match in _THINK_TAG_PATTERN.findall(message_text) if match.strip()]
    visible_text = _THINK_TAG_PATTERN.sub(" ", message_text).strip()

    events: list[CanonicalLogEvent] = []
    if think_matches:
        events.append(CanonicalLogEvent(kind="thinking", text="\n\n".join(think_matches)))
    if visible_text:
        events.append(CanonicalLogEvent(kind="reply", text=visible_text))
    if events:
        return events

    normalized_text = _normalize_multiline_text(message_text)
    if normalized_text:
        return [CanonicalLogEvent(kind="plain_text", text=normalized_text)]
    return []


def _format_tool_call_name(tool_name: object) -> str | None:
    if isinstance(tool_name, str) and tool_name.strip():
        return tool_name.strip()
    return None


def _truncate_tool_value(value: str, max_length: int = _MAX_TOOL_VALUE_LENGTH) -> str:
    collapsed = _collapse_whitespace(value)
    if len(collapsed) <= max_length:
        return collapsed
    return collapsed[: max_length - 3].rstrip() + "..."


def _format_tool_field(name: str, value: object, *, indent: bool = False) -> str | None:
    if isinstance(value, str):
        rendered_value = value if name.endswith("_path") or name in {"path", "command"} else _truncate_tool_value(value)
        if not rendered_value or not rendered_value.strip():
            return None
        if indent:
            return f"{name}: {rendered_value}"
        if name == "pattern" or any(char.isspace() for char in rendered_value):
            escaped = rendered_value.replace('"', '\\"')
            return f'{name}="{escaped}"'
        return f"{name}={rendered_value}"
    if isinstance(value, bool):
        return f"{name}={str(value).lower()}"
    if isinstance(value, (int, float)):
        return f"{name}={value}"
    return None


def _summarize_generic_tool_input(tool_input: dict[object, object]) -> str | None:
    fields: list[str] = []
    for key, value in tool_input.items():
        if not isinstance(key, str) or key in _OMITTED_TOOL_FIELDS:
            continue
        rendered = _format_tool_field(key, value)
        if rendered is None:
            continue
        fields.append(rendered)
        if len(fields) == 2:
            break
    return " ".join(fields) if fields else None


def _summarize_tool_input(tool_name: str | None, tool_input: object) -> str | None:
    if not isinstance(tool_input, dict):
        return None

    if tool_name == "Read":
        read_fields: list[str] = []
        file_path = _format_tool_field("file_path", tool_input.get("file_path") or tool_input.get("path"))
        if file_path:
            read_fields.append(file_path)
        offset = tool_input.get("offset")
        if isinstance(offset, (int, float)):
            read_fields.append(f"offset={offset}")
        limit = tool_input.get("limit")
        if isinstance(limit, (int, float)):
            read_fields.append(f"limit={limit}")
        return " ".join(read_fields) if read_fields else None
    if tool_name == "Write":
        write_fields: list[str] = []
        file_path = _format_tool_field("file_path", tool_input.get("file_path") or tool_input.get("path"))
        if file_path:
            write_fields.append(file_path)
        content = tool_input.get("content")
        if isinstance(content, str):
            write_fields.append(f"content_length={len(content)}")
        return " ".join(write_fields) if write_fields else None
    if tool_name == "Edit":
        raw_pairs: list[tuple[str, object]] = []
        file_path_val = tool_input.get("file_path") or tool_input.get("path")
        if file_path_val is not None:
            raw_pairs.append(("file_path", file_path_val))
        for hint_key in ("replace_all", "insert_line", "view_range", "instruction"):
            val = tool_input.get(hint_key)
            if val is not None:
                raw_pairs.append((hint_key, val))
        if not raw_pairs:
            return None
        multiline = len(raw_pairs) > 2
        fields = [f for n, v in raw_pairs if (f := _format_tool_field(n, v, indent=multiline)) is not None]
        if multiline:
            return "\n".join(fields) if fields else None
        return " ".join(fields) if fields else None
    if tool_name == "Glob":
        return _format_tool_field("pattern", tool_input.get("pattern"))
    if tool_name == "Grep":
        grep_pairs: list[tuple[str, object]] = []
        pattern_val = tool_input.get("pattern")
        if pattern_val is not None:
            grep_pairs.append(("pattern", pattern_val))
        for key in ("path", "dir_path", "include", "include_pattern", "glob"):
            val = tool_input.get(key)
            if val is not None:
                grep_pairs.append((key, val))
        if not grep_pairs:
            return None
        multiline = len(grep_pairs) > 2
        grep_fields = [f for n, v in grep_pairs if (f := _format_tool_field(n, v, indent=multiline)) is not None]
        if multiline:
            return "\n".join(grep_fields) if grep_fields else None
        return " ".join(grep_fields) if grep_fields else None
    if tool_name == "Bash":
        bash_fields: list[str] = []
        description = _format_tool_field("description", tool_input.get("description"), indent=True)
        if description:
            bash_fields.append(description)
        command = _format_tool_field("command", tool_input.get("command"), indent=True)
        if command:
            bash_fields.append(command)
        return "\n".join(bash_fields) if bash_fields else None
    if tool_name == "TodoWrite":
        todos = tool_input.get("todos")
        if isinstance(todos, list):
            return f"todos={len(todos)}"
        return None
    if tool_name == "WebFetch":
        wf_fields: list[str] = []
        url = _format_tool_field("url", tool_input.get("url"))
        if url:
            wf_fields.append(url)
        prompt = _format_tool_field("prompt", tool_input.get("prompt"))
        if prompt:
            wf_fields.append(prompt)
        return " ".join(wf_fields) if wf_fields else None
    if tool_name == "Skill":
        skill_fields: list[str] = []
        skill = _format_tool_field("skill", tool_input.get("skill"))
        if skill:
            skill_fields.append(skill)
        args = _format_tool_field("args", tool_input.get("args"))
        if args:
            skill_fields.append(args)
        return " ".join(skill_fields) if skill_fields else None
    if tool_name == "litellm_web_search":
        return _format_tool_field("query", tool_input.get("query"))
    if tool_name == "NotebookEdit":
        nb_fields: list[str] = []
        notebook_path = _format_tool_field("notebook_path", tool_input.get("notebook_path"))
        if notebook_path:
            nb_fields.append(notebook_path)
        edit_mode = _format_tool_field("edit_mode", tool_input.get("edit_mode"))
        if edit_mode:
            nb_fields.append(edit_mode)
        cell_number = tool_input.get("cell_number")
        if isinstance(cell_number, (int, float)):
            nb_fields.append(f"cell_number={cell_number}")
        return " ".join(nb_fields) if nb_fields else None
    if tool_name == "MCP":
        mcp_fields: list[str] = []
        server = _format_tool_field("server", tool_input.get("server"))
        if server:
            mcp_fields.append(server)
        tool = _format_tool_field("tool", tool_input.get("tool"))
        if tool:
            mcp_fields.append(tool)
        return " ".join(mcp_fields) if mcp_fields else None
    if tool_name == "WebSearch":
        return _format_tool_field("query", tool_input.get("query"))

    return _summarize_generic_tool_input(tool_input)


def render_canonical_event(event: CanonicalLogEvent) -> str | None:
    if event.kind == "plain_text":
        return event.text
    if event.kind == "thinking":
        return _prefix_multiline_text("thinking:", event.text or "")
    if event.kind == "reply":
        return _render_reply_text("reply:", event.text or "")
    if event.kind == "hook_feedback":
        return _summarize_hook_feedback(event.text or "")
    if event.kind == "tool_call":
        tool_summary = _summarize_tool_input(event.tool_name, event.tool_input)
        if event.tool_name:
            if tool_summary:
                if "\n" in tool_summary:
                    indented = "\n".join(f"  {line}" for line in tool_summary.splitlines())
                    return f"tool call: {event.tool_name}\n{indented}"
                return f"tool call: {event.tool_name} {tool_summary}"
            return f"tool call: {event.tool_name}"
        return "tool call"
    if event.kind == "tool_result":
        return "tool result received"
    if event.kind == "session_start":
        return "session started" + (f" ({', '.join(event.summary_parts)})" if event.summary_parts else "")
    if event.kind == "completed":
        return "completed" + (f" ({', '.join(event.summary_parts)})" if event.summary_parts else "")
    return None


def render_agent_output_for_stderr(tool_name: str, line: str) -> str | None:
    from cybervisor.adapters.registry import get_adapter

    try:
        adapter = get_adapter(tool_name)
    except ValueError:
        return line

    rendered_events = [render_canonical_event(event) for event in adapter.parse_output_line(line)]
    visible_events = [rendered for rendered in rendered_events if rendered]
    if not visible_events:
        return None
    return "\n".join(visible_events)
