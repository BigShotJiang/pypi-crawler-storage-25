"""Background auto-upgrade check for cybervisor."""

from __future__ import annotations

import logging
import sys
import threading

import httpx

from cybervisor import __version__

_logger = logging.getLogger(__name__)
_PYPI_URL = "https://pypi.org/pypi/cybervisor/json"


def _is_hook_runner() -> bool:
    """Detect if the current process is the hook runner entry point."""
    if sys.argv and len(sys.argv) > 0:
        argv0 = sys.argv[0]
        if argv0.endswith("cybervisor-agent-hook"):
            return True
    return False


def _latest_pypi_version() -> str | None:
    """Query PyPI for the latest cybervisor version. Returns None on any failure."""
    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.get(_PYPI_URL)
            response.raise_for_status()
            data = response.json()
            info = data.get("info", {})
            version = info.get("version")
            if isinstance(version, str) and version:
                return version
    except Exception:
        # PyPI query failure is intentionally non-blocking; logged at debug
        # with traceback so it's visible when troubleshooting but silent by default.
        _logger.debug("Failed to query PyPI for latest version", exc_info=True)
    return None


def _should_upgrade(current: str, latest: str) -> bool:
    """Compare two PEP 440 version strings."""
    # Simple tuple comparison for numeric dotted versions.
    # Sufficient for early development; full PEP 440 parsing not required.
    def _parse(v: str) -> tuple[int, ...]:
        parts: list[int] = []
        for part in v.split("."):
            # Take only leading digits
            digits = ""
            for ch in part:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            if digits:
                parts.append(int(digits))
            else:
                parts.append(0)
        return tuple(parts)

    try:
        return _parse(latest) > _parse(current)
    except Exception:
        # Version comparison failure safely defaults to no-upgrade (return False)
        # rather than crashing the upgrade check or blocking the main workflow.
        return False


def _check_and_upgrade_impl() -> None:
    """Internal: check PyPI and log a notice if an upgrade is available. Runs entirely in background."""
    if _is_hook_runner():
        return

    latest = _latest_pypi_version()
    if latest is None:
        return

    if not _should_upgrade(__version__, latest):
        _logger.debug("cybervisor is up to date (%s)", __version__)
        return

    _logger.info(
        "Newer version available: %s (current: %s). Run `uv tool upgrade cybervisor` or `pip install --upgrade cybervisor` to update.",
        latest,
        __version__,
    )


def check_for_updates() -> None:
    """Check PyPI for a newer version and log a notice if found.

    Spawns a daemon thread that handles the check (HTTP request),
    so the caller never blocks. Silently ignores all errors.
    """
    if _is_hook_runner():
        return

    thread = threading.Thread(target=_check_and_upgrade_impl, daemon=True)
    thread.start()
