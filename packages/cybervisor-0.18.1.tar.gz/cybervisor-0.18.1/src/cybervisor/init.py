from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files
from importlib.resources.abc import Traversable
from pathlib import Path

from cybervisor.global_config import global_config_path
from cybervisor.logging import CybervisorLogger


@dataclass(frozen=True, slots=True)
class InitFile:
    path: Path
    contents: str


_INIT_YAML_GUIDANCE_COMMENT = "# For guidance on editing this file, run: `cybervisor docs cybervisor.yaml`\n"


def _with_init_guidance(item: InitFile) -> InitFile:
    if item.path.name != "cybervisor.yaml":
        return item
    if item.contents.startswith(_INIT_YAML_GUIDANCE_COMMENT):
        return item
    return InitFile(path=item.path, contents=f"{_INIT_YAML_GUIDANCE_COMMENT}{item.contents}")


def _iter_scaffold_files(directory: Traversable, prefix: Path) -> list[InitFile]:
    init_files: list[InitFile] = []
    for child in directory.iterdir():
        child_prefix = prefix / child.name
        if child.is_dir():
            init_files.extend(_iter_scaffold_files(child, child_prefix))
            continue
        init_files.append(_with_init_guidance(InitFile(path=child_prefix, contents=child.read_text(encoding="utf-8"))))
    return init_files


def scaffold_init_files(base_dir: Path, scaffold_name: str) -> list[InitFile]:
    scaffold_dir = files("cybervisor.assets.init").joinpath(scaffold_name)
    return sorted(_iter_scaffold_files(scaffold_dir, base_dir), key=lambda item: str(item.path))


def _select_init_files(base_dir: Path, *, template_override: str | None = None) -> tuple[str, list[InitFile]]:
    selected_template = template_override or "simple"
    return selected_template, scaffold_init_files(base_dir, selected_template)


def run_init(
    *,
    template: str | None = None,
    force: bool = False,
    base_dir: Path | None = None,
    logger: CybervisorLogger | None = None,
) -> int:
    target_dir = base_dir or Path.cwd()
    resolved_dir = target_dir.resolve()
    init_logger = logger or CybervisorLogger()
    scaffold_kind, targets = _select_init_files(resolved_dir, template_override=template)
    config_target = next(item for item in targets if item.path.name == "cybervisor.yaml")
    other_targets = [item for item in targets if item.path.name != "cybervisor.yaml"]
    config_exists = config_target.path.exists()
    blocking_conflicts = [item.path for item in other_targets if item.path.exists()]

    if blocking_conflicts:
        joined = "\n".join(str(path) for path in blocking_conflicts)
        init_logger.log_to_stderr(
            "Refusing to overwrite existing scaffold support files:\n" + joined,
            "error",
        )
        return 1

    if config_exists and not force:
        init_logger.log_to_stderr(
            "Preserved existing cybervisor.yaml. Re-run with --force to replace it explicitly.",
            "info",
        )
        return 0

    if config_exists and force:
        init_logger.log_to_stderr(
            f"Replacing existing cybervisor.yaml with the {scaffold_kind} template.",
            "info",
        )

    write_targets = [config_target, *other_targets] if not config_exists or force else other_targets
    for item in write_targets:
        item.path.parent.mkdir(parents=True, exist_ok=True)
        item.path.write_text(item.contents, encoding="utf-8")

    written = "\n".join(str(item.path.relative_to(resolved_dir)) for item in write_targets)
    init_logger.log_to_stderr(
        (
            f"Created {scaffold_kind} cybervisor scaffold:\n"
            f"{written}\n\n"
            f"Next steps:\n"
            f"- Set a global default agent with `cybervisor use <agent_tool>`\n"
            f"- Configure verifier settings in {global_config_path()}"
        ),
        "info",
    )
    return 0
