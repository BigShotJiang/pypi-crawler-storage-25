from __future__ import annotations

from pathlib import Path


def _normalize_workspace_config_path(config_path: str) -> str | None:
    normalized = config_path.strip()
    if not normalized:
        return None
    candidate = Path(normalized)
    if candidate.is_absolute():
        return None
    if any(part == ".." for part in candidate.parts):
        return None
    return normalized