"""Daemon configuration dataclass, lock-path utilities, and instance locking."""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import fcntl
except ImportError:
    fcntl = None  # type: ignore[assignment]

from cybervisor import __version__


# Instance lock path for daemon
DAEMON_LOCK_PATH = ".cybervisor/daemon.lock"


def _daemon_lock_path() -> Path:
    return Path(DAEMON_LOCK_PATH)


def _read_daemon_lock() -> dict[str, object] | None:
    lock_path = _daemon_lock_path()
    if not lock_path.exists():
        return None
    try:
        content = lock_path.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            return data
    except (json.JSONDecodeError, OSError):
        return None
    return None


def _is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _is_daemon_lock_alive(lock: dict[str, object]) -> bool:
    pid = lock.get("pid")
    if not isinstance(pid, int):
        return False
    cwd = lock.get("cwd")
    if not isinstance(cwd, str):
        return False
    if os.getcwd() != cwd:
        return False
    return _is_pid_running(pid)


@dataclass(slots=True)
class DaemonConfig:
    """Server daemon configuration."""

    host: str = "127.0.0.1"
    port: int = 8765
    reconnect_ttl_seconds: float = 300.0
    max_event_buffer: int = 1000
    ping_interval_seconds: float = 30.0
    ping_timeout_seconds: float = 10.0


def _can_steal_flock(lock_path: Path) -> bool:
    """Try to acquire an exclusive flock on an existing lock file.

    Returns True if the flock was acquired (original holder is gone).
    This handles the Docker PID-1 case where os.kill(1, 0) always
    succeeds even after the original process has exited.
    """
    if fcntl is None:
        return False
    try:
        test_fd = os.open(lock_path, os.O_RDWR)
    except OSError:
        return False
    try:
        fcntl.flock(test_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        # Another process holds the flock — lock is truly alive
        try:
            os.close(test_fd)
        except OSError:
            pass
        return False
    # We got the flock — release it so the caller can unlink and retry
    try:
        fcntl.flock(test_fd, fcntl.LOCK_UN)
    except OSError:
        pass
    try:
        os.close(test_fd)
    except OSError:
        pass
    return True


def _acquire_instance_lock() -> tuple[bool, int | None]:
    """Acquire daemon instance lock.

    Returns (acquired, lock_fd). If acquired is True, lock_fd holds the open fd.
    """
    from datetime import datetime, timezone

    lock_path = _daemon_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        "pid": os.getpid(),
        "cwd": os.getcwd(),
        "started_at": datetime.now(tz=timezone.utc).isoformat(),
        "version": __version__,
    }

    for _attempt in range(3):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            # Lock file exists — check if holder is alive
            lock = _read_daemon_lock()
            if lock is not None and _is_daemon_lock_alive(lock):
                # The PID appears alive, but inside containers PID 1 always
                # exists even after the original process exits.  Verify with
                # flock: if we can acquire an exclusive lock the original
                # holder has released it (OS releases flock on process exit)
                # and the lock is stale regardless of the PID check.
                if not _can_steal_flock(lock_path):
                    return False, None
            # Stale lock — try to remove and retry
            try:
                lock_path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                return False, None
            time.sleep(0.2)
            continue
        except OSError:
            return False, None

        # We created the file; acquire flock as secondary guard (if available)
        if fcntl is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                # Another process holds the flock — remove our empty file and retry
                try:
                    os.close(fd)
                except OSError:
                    pass
                try:
                    lock_path.unlink(missing_ok=True)
                except OSError:
                    pass
                time.sleep(0.2)
                continue

        try:
            os.write(fd, json.dumps(payload).encode("utf-8"))
        except OSError:
            try:
                if fcntl is not None:
                    fcntl.flock(fd, fcntl.LOCK_UN)
            except OSError:
                pass
            try:
                os.close(fd)
            except OSError:
                pass
            return False, None
        return True, fd

    return False, None


def _release_instance_lock(lock_fd: int | None) -> None:
    """Release the daemon instance lock.

    Holds an exclusive flock during the unlink to close the TOCTOU race
    where another process could acquire the lock between the PID check
    and the unlink. The fd is closed only after unlink completes.
    """
    if lock_fd is None:
        return
    lock_path = _daemon_lock_path()
    # Use blocking flock — we own the fd so this should always succeed.
    if fcntl is not None:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
        except OSError:
            pass
    try:
        lock = _read_daemon_lock()
        if lock is not None:
            pid = lock.get("pid")
            cwd = lock.get("cwd")
            if pid == os.getpid() and cwd == os.getcwd():
                lock_path.unlink(missing_ok=True)
    finally:
        if fcntl is not None:
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except OSError:
                pass
        try:
            os.close(lock_fd)
        except OSError:
            pass