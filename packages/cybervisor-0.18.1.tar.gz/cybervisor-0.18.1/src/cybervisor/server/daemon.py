"""Daemon server WebSocket server class and entry point."""

from __future__ import annotations

import asyncio
try:
    import fcntl
except ImportError:
    fcntl = None  # type: ignore[assignment]
import json
import os
import signal
import sys
from datetime import datetime, timezone
from typing import Any

import websockets.asyncio.server as ws_server

from cybervisor import __version__
from cybervisor.global_config import GlobalConfig, load_global_config
from cybervisor.logging import CybervisorLogger
from cybervisor.server_events import ServerEvent
from cybervisor.server._daemon_config import (
    DAEMON_LOCK_PATH,
    DaemonConfig,
    _acquire_instance_lock,
    _daemon_lock_path,
    _is_daemon_lock_alive,
    _is_pid_running,
    _read_daemon_lock,
    _release_instance_lock,
)

__all__ = [
    "DAEMON_LOCK_PATH",
    "DEFAULT_CONFIG_PATH",
    "DaemonConfig",
    "DaemonServer",
    "_daemon_lock_path",
    "_is_daemon_lock_alive",
    "_is_pid_running",
    "_read_daemon_lock",
    "serve",
]
from cybervisor.server.tasks import DeliverySuppressedError, StaleExecutionError, TaskRegistry, TaskState


DEFAULT_CONFIG_PATH = "cybervisor.yaml"


class DaemonServer:
    """WebSocket daemon server for cybervisor task execution."""

    def __init__(
        self,
        config: DaemonConfig,
        global_config: GlobalConfig,
        logger: CybervisorLogger,
    ) -> None:
        self.config = config
        self.global_config = global_config
        self.logger = logger
        self._registry = TaskRegistry(max_event_buffer=config.max_event_buffer)
        self._server: ws_server.Server | None = None
        self._shutdown_event = asyncio.Event()
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._instance_lock_fd: int | None = None

    async def start(self) -> None:
        """Start the WebSocket server."""
        self.logger.log_to_stderr(f"cybervisor {__version__}", "info")
        self._write_daemon_log("daemon_start", {"host": self.config.host, "port": self.config.port})
        self._server = await ws_server.serve(
            self._handle_connection,
            self.config.host,
            self.config.port,
            ping_interval=self.config.ping_interval_seconds,
            ping_timeout=self.config.ping_timeout_seconds,
        )
        self.logger.log_to_stderr(f"Daemon listening on ws://{self.config.host}:{self.config.port}", "info")

    async def stop(self) -> None:
        """Stop the WebSocket server gracefully."""
        self.logger.log_to_stderr("Daemon shutting down...", "info")
        self._shutdown_event.set()
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        tasks_snapshot = set(self._background_tasks)
        for task in tasks_snapshot:
            task.cancel()
        if tasks_snapshot:
            await asyncio.gather(*tasks_snapshot, return_exceptions=True)
        self._release_instance_lock()
        self._write_daemon_log("daemon_stop", {})

    def _write_daemon_log(self, event: str, data: dict[str, Any]) -> None:
        entry = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "event": event,
            **data,
        }
        self.logger.log_to_json(entry, ".cybervisor/logs/cybervisor.log.jsonl")

    async def _handle_ping(self, websocket: Any, message: dict[str, Any]) -> None:
        """Handle a ping message and return task snapshots."""
        from cybervisor.server import handlers as _handlers

        task_snapshots: list[dict[str, Any]] = []
        task_ids = await self._registry.get_task_ids()
        self._write_daemon_log("debug_ping", {"task_ids": task_ids})
        for tid in task_ids:
            task_state = await self._registry.get_task(tid)
            if task_state is None:
                continue
            ping_task_id = message.get("task_id")
            if ping_task_id and tid != ping_task_id:
                continue
            if task_state.completed:
                status = "completed"
            elif task_state.cancelled:
                status = "cancelled"
            else:
                status = "running"
            snapshot: dict[str, Any] = {
                "task_id": task_state.task_id,
                "active_stage": task_state.active_stage,
                "attempt": task_state.attempt,
                "status": status,
                "cwd": task_state.cwd,
                "end_stage": task_state.end_stage,
                "end_before": task_state.end_before,
            }
            task_snapshots.append(snapshot)
        await _handlers._handle_pong(websocket, task_snapshots)

    async def _handle_run(self, websocket: Any, message: dict[str, Any]) -> None:
        """Handle a run message."""
        from cybervisor.server import handlers as _handlers
        await _handlers._handle_run(self, websocket, message)

    async def _handle_set_stop_stage(self, websocket: Any, message: dict[str, Any]) -> None:
        """Handle a set_stop_stage message."""
        from cybervisor.server import handlers as _handlers
        await _handlers._handle_set_stop_stage(self, websocket, message)

    async def _handle_cancel(self, websocket: Any, message: dict[str, Any]) -> None:
        """Handle a cancel message."""
        from cybervisor.server import handlers as _handlers
        await _handlers._handle_cancel(self, websocket, message)

    async def _handle_resume(self, websocket: Any, message: dict[str, Any]) -> bool:
        """Handle a resume message. Returns True if the connection loop should break."""
        from cybervisor.server import handlers as _handlers

        await _handlers._handle_resume(self, websocket, message)
        task_id = message.get("task_id")
        task_state_ref = await self._registry.get_task(task_id or "")
        if task_state_ref is not None:
            async with task_state_ref._connection_lock:
                no_more = task_state_ref._no_more_live_events
            if no_more:
                return True
        return False

    async def _handle_connection(self, websocket: Any) -> None:
        """Handle a new WebSocket connection."""
        from cybervisor.server import handlers as _handlers

        client_id = id(websocket)
        self._write_daemon_log("client_connect", {"client_id": client_id})
        self.logger.log_to_stderr(f"Client connected: {client_id}", "info")
        connection_task_id: str | None = None

        try:
            async for raw_message in websocket:
                if raw_message is None:
                    continue
                try:
                    message = json.loads(raw_message)
                except json.JSONDecodeError:
                    await _handlers._send_error(websocket, "", "invalid_message", "Invalid JSON")
                    continue

                msg_type = message.get("type")
                task_id = message.get("task_id")

                # Track which task this connection is controlling
                if msg_type in ("run", "resume"):
                    connection_task_id = task_id

                if msg_type == "ping":
                    await self._handle_ping(websocket, message)
                    continue

                if msg_type == "run":
                    await self._handle_run(websocket, message)
                    continue

                if msg_type == "set_stop_stage":
                    await self._handle_set_stop_stage(websocket, message)
                    continue

                if msg_type == "cancel":
                    await self._handle_cancel(websocket, message)
                    continue

                if msg_type == "resume":
                    should_break = await self._handle_resume(websocket, message)
                    if should_break:
                        break
                    continue

                await _handlers._send_error(websocket, task_id or "", "invalid_message", f"Unknown message type: {msg_type}")

        except Exception:
            self.logger.log_to_stderr(f"WebSocket connection error for client {client_id}", "warning")
        finally:
            await _handlers._clear_live_connection(self, websocket, connection_task_id)
            self._write_daemon_log("client_disconnect", {"client_id": client_id})

    async def _send_to_websocket(
        self,
        websocket: Any,
        event: ServerEvent,
        task_state: TaskState | None = None,
        *,
        suppress_if_aborted: bool = False,
    ) -> None:
        """Send an event to the WebSocket, handling chunking if needed."""
        from cybervisor.server_events import EventType, chunk_payload

        if task_state is not None and suppress_if_aborted and task_state.abort_sent:
            raise DeliverySuppressedError()
        payload = event.to_dict()
        if payload.get("type") == EventType.EVENT_REPLAY.value:
            events_to_chunk = payload.get("events", [])
            if events_to_chunk:
                chunks = chunk_payload(events_to_chunk)
                if not (len(chunks) == 1 and chunks[0]["type"] == EventType.EVENT_REPLAY.value):
                    for chunk in chunks:
                        chunk["task_id"] = event.task_id
                        chunk["timestamp"] = event.timestamp
                        await websocket.send(json.dumps(chunk))
                    return
        await websocket.send(event.to_json())

    async def _deliver_task_event(
        self,
        task_state: TaskState,
        event: ServerEvent,
        *,
        append: bool = True,
        suppress_if_aborted: bool = False,
        expected_generation: int | None = None,
    ) -> None:
        """Buffer an event and deliver it to the task's current live websocket if allowed."""
        if expected_generation is not None and expected_generation != task_state.execution_generation:
            raise StaleExecutionError()
        if append:
            await task_state.events.append_async(event)
        websocket = task_state.live_websocket
        if websocket is None:
            return
        await self._send_to_websocket(
            websocket,
            event,
            task_state,
            suppress_if_aborted=suppress_if_aborted,
        )

    async def _finalize_task_failure(self, task_state: TaskState, code: str, message: str) -> None:
        """Emit terminal failure events and free the task slot for new runs on the same connection."""
        from cybervisor.server_events import error, run_complete

        task_state.completed = True
        task_state.success = False
        error_evt = error(task_state.task_id, code, message)
        await self._deliver_task_event(task_state, error_evt)
        complete_evt = run_complete(task_state.task_id, False)
        await self._deliver_task_event(task_state, complete_evt)
        task_state.live_websocket = None
        await self._registry.remove_task(task_state.task_id)

    async def _run_resume_replay(self, websocket: Any, task_state: TaskState) -> None:
        from cybervisor.server_events import EventType, chunk_payload, event_replay

        events = await task_state.events.get_all_async()
        event_dicts = [e.to_dict() for e in events]
        live_resume = not task_state.completed
        if event_dicts:
            chunks = chunk_payload(event_dicts)
            if len(chunks) == 1 and chunks[0]["type"] == EventType.EVENT_REPLAY.value:
                await websocket.send(event_replay(task_state.task_id, event_dicts, live_resume).to_json())
                return
            timestamp = datetime.now(tz=timezone.utc).isoformat()
            chunk_id = f"{task_state.task_id}_{task_state.connection_generation}"
            for chunk in chunks:
                chunk["task_id"] = task_state.task_id
                chunk["chunk_id"] = chunk_id
                chunk["timestamp"] = timestamp
                chunk["live_resume"] = live_resume
                await websocket.send(json.dumps(chunk))
            return
        await websocket.send(event_replay(task_state.task_id, [], live_resume).to_json())

    async def _switch_live_connection(self, task_state: TaskState, websocket: Any) -> None:
        async with task_state._connection_lock:
            task_state.live_websocket = websocket
            task_state.connection_generation += 1
            await self._registry.update_last_activity(task_state.task_id)
            await self._run_resume_replay(websocket, task_state)
            task_state._no_more_live_events = True

    async def _detach_execution(self, task_state: TaskState, generation: int) -> None:
        if generation != task_state.execution_generation:
            return
        async with task_state._connection_lock:
            task_state.live_websocket = None
            task_state.connection_generation += 1
        await self._registry.update_last_activity(task_state.task_id)
        task_state.run_task = None

    async def _append_task_event(self, task_id: str, event: ServerEvent) -> None:
        """Append an event to the task's event buffer for resume replay with FIFO eviction."""
        task_state = await self._registry.get_task(task_id)
        if task_state is not None:
            await task_state.events.append_async(event)

    def _acquire_instance_lock(self) -> bool:
        """Acquire daemon instance lock."""
        acquired, fd = _acquire_instance_lock()
        if acquired:
            self._instance_lock_fd = fd
        return acquired

    def _release_instance_lock(self) -> None:
        """Release the daemon instance lock."""
        lock_fd = self._instance_lock_fd
        self._instance_lock_fd = None
        _release_instance_lock(lock_fd)


async def serve(
    host: str | None = None,
    port: int | None = None,
    background: bool = False,
    logger: CybervisorLogger | None = None,
) -> None:
    """Entry point for the daemon server."""
    from ._cleanup import _cleanup_abandoned_tasks

    if logger is None:
        logger = CybervisorLogger()

    # Handle daemonization early, before any async operations
    if background:
        # Double-fork for proper Unix daemonization
        try:
            # First fork
            pid = os.fork()
            if pid > 0:
                # Parent exits
                os._exit(0)
        except OSError as exc:
            logger.log_to_stderr(f"First fork failed: {exc}", "error")
            return

        # Create new session and detach from terminal
        try:
            os.setsid()
        except OSError:
            pass

        try:
            # Second fork to prevent acquiring a new controlling terminal
            pid = os.fork()
            if pid > 0:
                os._exit(0)
        except OSError as exc:
            logger.log_to_stderr(f"Second fork failed: {exc}", "error")
            return

        # Redirect standard file descriptors to /dev/null
        devnull_fd = os.open("/dev/null", os.O_RDWR)
        try:
            os.dup2(devnull_fd, sys.stdin.fileno())
            os.dup2(devnull_fd, sys.stdout.fileno())
            os.dup2(devnull_fd, sys.stderr.fileno())
        finally:
            os.close(devnull_fd)

    # Load global config first to get server settings
    try:
        global_config = load_global_config()
    except Exception as exc:
        logger.log_to_stderr(f"Failed to load global config: {exc}", "error")
        return

    daemon_config = DaemonConfig(
        host=host if host is not None else global_config.server.host,
        port=port if port is not None else global_config.server.port,
        reconnect_ttl_seconds=global_config.server.reconnect_ttl_seconds,
        max_event_buffer=global_config.server.max_event_buffer,
    )

    server = DaemonServer(daemon_config, global_config, logger)

    # Acquire instance lock
    if not server._acquire_instance_lock():
        logger.log_to_stderr(f"Another daemon instance is already running. Check {DAEMON_LOCK_PATH}.", "error")
        return

    # Handle shutdown signals
    shutdown_event = asyncio.Event()

    def shutdown_handler(signum: int) -> None:
        logger.log_to_stderr(f"Received signal {signum}, shutting down...", "info")
        shutdown_event.set()

    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signum, shutdown_handler, signum)
        except (NotImplementedError, ValueError):
            # Windows doesn't support add_signal_handler
            pass

    try:
        await server.start()

        # Start background cleanup task
        cleanup_task = asyncio.create_task(_cleanup_abandoned_tasks(server._registry, daemon_config.reconnect_ttl_seconds, logger))
        server._background_tasks.add(cleanup_task)
        cleanup_task.add_done_callback(server._background_tasks.discard)

        await shutdown_event.wait()
    except Exception as exc:
        logger.log_to_stderr(f"Daemon error: {exc}", "error")
    finally:
        await server.stop()
