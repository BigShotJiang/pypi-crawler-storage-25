"""cybervisor.server — Daemon WebSocket server package."""

from __future__ import annotations

from cybervisor.server.daemon import (
    DEFAULT_CONFIG_PATH,
    DaemonServer,
    serve,
)
from cybervisor.server._daemon_config import (
    DAEMON_LOCK_PATH,
    DaemonConfig,
    _daemon_lock_path,
    _is_daemon_lock_alive,
    _is_pid_running,
    _read_daemon_lock,
)
from cybervisor.server._path import _normalize_workspace_config_path
from cybervisor.server.handlers import (
    _cleanup_abandoned_tasks,
    _clear_live_connection,
    _execute_task,
    _handle_cancel,
    _handle_pong,
    _handle_resume,
    _handle_run,
    _handle_set_stop_stage,
    _run_pipeline_sync,
    _send_error,
)
from cybervisor.server.tasks import (
    DeliverySuppressedError,
    EventRingBuffer,
    StaleExecutionError,
    TaskRegistry,
    TaskState,
)

__all__ = [
    "DaemonConfig",
    "DaemonServer",
    "DEFAULT_CONFIG_PATH",
    "DeliverySuppressedError",
    "EventRingBuffer",
    "StaleExecutionError",
    "TaskRegistry",
    "TaskState",
    "DAEMON_LOCK_PATH",
    "_cleanup_abandoned_tasks",
    "_clear_live_connection",
    "_daemon_lock_path",
    "_execute_task",
    "_handle_cancel",
    "_handle_pong",
    "_handle_resume",
    "_handle_run",
    "_handle_set_stop_stage",
    "_is_daemon_lock_alive",
    "_is_pid_running",
    "_normalize_workspace_config_path",
    "_read_daemon_lock",
    "_run_pipeline_sync",
    "_send_error",
    "serve",
]
