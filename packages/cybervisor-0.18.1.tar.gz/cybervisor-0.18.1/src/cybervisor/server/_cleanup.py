"""Periodic cleanup of abandoned daemon tasks."""

from __future__ import annotations

import asyncio

from cybervisor.logging import CybervisorLogger
from cybervisor.server.tasks import TaskRegistry


async def _cleanup_abandoned_tasks(
    registry: TaskRegistry,
    ttl_seconds: float,
    logger: CybervisorLogger,
) -> None:
    """Periodically cleanup abandoned tasks."""
    while True:
        await asyncio.sleep(ttl_seconds / 2)
        removed = await registry.cleanup_abandoned(ttl_seconds)
        for task_id in removed:
            logger.log_to_stderr(f"Removed abandoned task: {task_id}", "warning")
