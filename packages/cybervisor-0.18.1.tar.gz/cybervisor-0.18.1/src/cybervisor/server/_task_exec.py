"""Task execution helpers extracted from the daemon server handlers."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from websockets.asyncio.server import ServerConnection

from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.registry import get_adapter
from cybervisor.config import load_config
from cybervisor.global_config import GlobalConfig
from cybervisor.hooks import hook_socket_path, inject_hooks, remove_hooks
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline import EndStageRef, PipelineInterrupted, PipelineRunner
from cybervisor.server_events import (
    artifact_validated,
    error,
    pipeline_abort,
    routing_decision,
    run_complete,
    stage_complete,
    stage_failed,
    stage_retry,
    stage_start,
)
from cybervisor.server.daemon import DaemonServer
from cybervisor.server.tasks import DeliverySuppressedError, StaleExecutionError, TaskState
from cybervisor.server_signals import ServerSignalHandler
from cybervisor.signals import SignalHandler
from cybervisor.skills import move_disabled_skills, restore_all_skills, restore_skills

_logger = logging.getLogger(__name__)


async def _send_error(websocket: Any, task_id: str, code: str, message: str) -> None:
    """Send an error event to the WebSocket."""
    await websocket.send(error(task_id, code, message).to_json())


async def _clear_live_connection(server: DaemonServer, websocket: ServerConnection, task_id: str | None) -> None:
    """Clear the live websocket reference when a client disconnects."""
    if task_id is None:
        return
    task_state = await server._registry.get_task(task_id)
    if task_state is None:
        return
    async with task_state._connection_lock:
        if task_state.live_websocket is websocket:
            task_state.live_websocket = None
            task_state.connection_generation += 1
    await server._registry.update_last_activity(task_id)


async def _execute_task(
    server: DaemonServer,
    global_config: GlobalConfig,
    logger: CybervisorLogger,
    task_state: TaskState,
) -> None:
    """Execute a task using the PipelineRunner."""
    from cybervisor.preflight import run_preflight

    task_id = task_state.task_id
    execution_generation = task_state.execution_generation
    await server._registry.update_last_activity(task_id)
    hook_listener: HookEventListener | None = None
    hooks_installed = False
    moved_skills: list[tuple[Path, Path]] = []

    try:
        try:
            config = load_config(task_state.config_path)
        except FileNotFoundError as exc:
            await server._finalize_task_failure(task_state, "server_error", f"Config not found: {exc}")
            return

        try:
            agent_tool = global_config.agent_tool
        except AttributeError as exc:
            logging.error("Failed to resolve agent: %s", exc, exc_info=True)
            await server._finalize_task_failure(task_state, "server_error", f"Failed to resolve agent: {exc}")
            return

        # Recover skills from any previous unclean shutdown.
        restore_all_skills()

        agent: AgentAdapter = get_adapter(agent_tool)

        # Move disabled project-local skills before the pipeline starts.
        moved_skills = move_disabled_skills(
            agent.descriptor.name,
            agent.project_skills_dir(),
            config.disabled_skills,
        )

        preflight_errors = run_preflight(agent_tool, config)
        if preflight_errors:
            restore_skills(moved_skills)
            await server._finalize_task_failure(task_state, "server_error", f"Preflight failed: {preflight_errors[0]}")
            return

        task_logger = CybervisorLogger()
        signal_handler = SignalHandler(task_logger, log_file=".cybervisor/logs/cybervisor.log.jsonl")
        server_signal_handler = ServerSignalHandler(signal_handler)
        server_signal_handler.set_cancel_event(task_state.cancel_event)
        task_state.server_signal_handler = server_signal_handler
        if agent.descriptor.capabilities.supports_hooks:
            try:
                hook_listener = HookEventListener(task_logger, socket_path=hook_socket_path())
                hook_listener.start()
                inject_hooks(agent_tool, config.hook)
                hooks_installed = True
            except Exception:
                logging.error("Hook installation failed", exc_info=True)
                if hook_listener is not None:
                    hook_listener.stop()
                restore_skills(moved_skills)
                raise

        loop = asyncio.get_running_loop()

        if task_state.end_stage is not None and task_state.end_stage_ref is not None:
            task_state.end_stage_ref.set(task_state.end_stage)
        if task_state.end_before is not None and task_state.end_before_ref is not None:
            task_state.end_before_ref.set(task_state.end_before)

        stage_models = global_config.stage_models if global_config.stage_models else None

        def stage_event_callback(event: dict[str, Any]) -> None:
            with task_state._state_lock:
                if task_state.abort_sent:
                    return
            event_type = event.get("event_type")
            if event_type == "stage_start":
                task_state.active_stage = event["stage_name"]
                evt = stage_start(
                    task_id,
                    event["stage_name"],
                    event["attempt"],
                    event["max_retries"],
                    iteration_count=event.get("iteration_count"),
                    max_iterations=event.get("max_iterations"),
                )
            elif event_type == "stage_complete":
                evt = stage_complete(task_id, event["stage_name"], event["success"], event["attempt"])
            elif event_type == "stage_retry":
                evt = stage_retry(task_id, event["stage_name"], event["attempt"], event["max_retries"], event["error"])
            elif event_type == "stage_failed":
                evt = stage_failed(task_id, event["stage_name"], event["attempt"], event["error"])
            elif event_type == "artifact_validated":
                evt = artifact_validated(task_id, event["stage_name"], event["artifact_status"])
            elif event_type == "routing_decision":
                evt = routing_decision(task_id, event["stage_name"], event["next_stage"], event["decision_source"])
            else:
                return
            future = asyncio.run_coroutine_threadsafe(
                server._deliver_task_event(
                    task_state,
                    evt,
                    suppress_if_aborted=True,
                    expected_generation=execution_generation,
                ),
                loop,
            )

            def _consume_result(done_future: Any) -> None:
                try:
                    done_future.result()
                except (DeliverySuppressedError, StaleExecutionError):
                    pass

            future.add_done_callback(_consume_result)

            # Update last activity to prevent abandoned task cleanup during stage execution
            asyncio.run_coroutine_threadsafe(
                server._registry.update_last_activity(task_id),
                loop,
            )
        success = await loop.run_in_executor(
            None,
            _run_pipeline_sync,
            task_state,
            task_state.prompt,
            config.stages,
            agent,
            task_logger,
            signal_handler,
            task_state.start_stage,
            task_state.end_stage_ref,
            stage_event_callback,
            hook_listener,
            task_state.end_before,
            task_state.end_before_ref,
            stage_models,
        )

        if execution_generation != task_state.execution_generation:
            return

        if task_state.cancel_event.is_set():
            task_state.completed = True
            task_state.success = False
            with task_state._state_lock:
                should_send_abort = not task_state.abort_sent
            if should_send_abort:
                abort_evt = pipeline_abort(task_id, "cancelled_by_client", task_state.active_stage)
                await server._deliver_task_event(task_state, abort_evt)
            await asyncio.sleep(0)
            complete_evt = run_complete(task_id, False)
            await server._deliver_task_event(task_state, complete_evt)
            task_state.live_websocket = None
            await server._registry.remove_task(task_id)
            return

        task_state.completed = True
        task_state.success = success
        evt = run_complete(task_id, success)
        await server._deliver_task_event(task_state, evt)
        task_state.live_websocket = None
        await server._registry.remove_task(task_id)

    except PipelineInterrupted:
        if execution_generation != task_state.execution_generation:
            return
        task_state.completed = True
        task_state.success = False
        with task_state._state_lock:
            should_send_abort = not task_state.abort_sent
        if should_send_abort:
            abort_evt = pipeline_abort(task_id, "interrupted", task_state.active_stage)
            await server._deliver_task_event(task_state, abort_evt)
        complete_evt = run_complete(task_id, False)
        await server._deliver_task_event(task_state, complete_evt)
        task_state.live_websocket = None
        await server._registry.remove_task(task_id)
    except Exception as exc:
        logging.error("Task execution failed", exc_info=True)
        if execution_generation != task_state.execution_generation:
            return
        await server._finalize_task_failure(task_state, "server_error", str(exc))
    finally:
        if hook_listener is not None:
            hook_listener.stop()
        if hooks_installed:
            try:
                restore_result = remove_hooks(agent_tool)
                logger.log_to_json(
                    task_logger.make_entry(
                        "system",
                        "Cleanup",
                        "Removed runtime hooks",
                        cleanup_result=restore_result,
                    ),
                    ".cybervisor/logs/cybervisor.log.jsonl",
                )
            except Exception as exc:
                logging.error("Failed to remove runtime hooks: %s", exc, exc_info=True)
        restore_skills(moved_skills)
        await server._detach_execution(task_state, execution_generation)


def _run_pipeline_sync(
    task_state: Any,
    prompt: str,
    stages: list[Any],  # StageConfig list
    agent: AgentAdapter,
    task_logger: CybervisorLogger,
    signal_handler: SignalHandler,
    start_stage_name: str | None,
    end_stage_ref: EndStageRef | None = None,
    stage_event_callback: Any = None,
    hook_listener: HookEventListener | None = None,
    end_before_stage_name: str | None = None,
    end_before_ref: EndStageRef | None = None,
    stage_models: dict[str, str] | None = None,
) -> bool:
    """Synchronous wrapper to run PipelineRunner in executor."""
    if task_state.cancel_event.is_set():
        raise PipelineInterrupted("", 0)
    runner = PipelineRunner()
    try:
        result = runner.run(
            prompt,
            stages,
            agent,
            task_logger,
            signal_handler=signal_handler,
            start_stage_name=start_stage_name,
            end_stage_ref=end_stage_ref,
            stage_event_callback=stage_event_callback,
            hook_listener=hook_listener,
            end_before_stage_name=end_before_stage_name,
            end_before_ref=end_before_ref,
            stage_models=stage_models,
        )
    except PipelineInterrupted:
        return False
    if task_state.cancel_event.is_set():
        raise PipelineInterrupted("", 0)
    return result