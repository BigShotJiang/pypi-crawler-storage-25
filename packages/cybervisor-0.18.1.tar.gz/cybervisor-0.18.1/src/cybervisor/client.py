"""cybervisor.client — Daemon WebSocket client commands.

This module re-exports from the split submodules in cybervisor.client/.
For internal use, import directly from the submodules.
"""

from __future__ import annotations

from cybervisor.client.commands import (
    _cancel_task_impl,
    _find_running_task_in_cwd,
    _resolve_config,
    attach_and_stream,
    dump_task_logs,
    find_active_task,
    ping_daemon,
    run_attach_command,
    run_cancel_command,
    run_end_command,
    run_logs_command,
    run_status_command,
    run_submit_command,
    submit_and_stream,
    update_end_stage,
)
from cybervisor.client.connection import (
    ClientConfig,
    _connect,
    _default_config,
    _receive_events,
)
from cybervisor.client.rendering import render_event
from cybervisor.server_events import ServerEvent

# Re-export as 'cancel_task' for backward compatibility
cancel_task = _cancel_task_impl

__all__ = [
    "attach_and_stream",
    "cancel_task",
    "ClientConfig",
    "_connect",
    "_default_config",
    "_find_running_task_in_cwd",
    "_receive_events",
    "_resolve_config",
    "dump_task_logs",
    "find_active_task",
    "ping_daemon",
    "render_event",
    "run_attach_command",
    "run_cancel_command",
    "run_end_command",
    "run_logs_command",
    "run_status_command",
    "run_submit_command",
    "ServerEvent",
    "submit_and_stream",
    "update_end_stage",
]
