from __future__ import annotations

import json
from pathlib import Path
from collections.abc import Callable
from typing import TypeVar

import httpx

from cybervisor.core_hooks.common import (
    HOOK_HTTP_TIMEOUT_SECONDS,
    HOOK_USER_AGENT,
    VerifierRequestError,
    VerifierResponseShapeError,
    chat_completions_url,
    recover_structured_output,
)

TStructured = TypeVar("TStructured")


def _post(api_endpoint: str, api_key: str, model: str, messages: list[dict[str, str]]) -> str:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": HOOK_USER_AGENT,
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        with httpx.Client(timeout=HOOK_HTTP_TIMEOUT_SECONDS) as client:
            response = client.post(
                chat_completions_url(api_endpoint),
                headers=headers,
                json={"model": model, "messages": messages},
            )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            raise VerifierRequestError(f"verifier server error ({exc.response.status_code})") from exc
        raise
    except httpx.TimeoutException as exc:
        raise VerifierRequestError("verifier request timed out") from exc
    except httpx.NetworkError as exc:
        raise VerifierRequestError(f"verifier network error: {exc}") from exc

    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise VerifierResponseShapeError("invalid JSON in LLM response") from exc
    choices = payload.get("choices", [])
    if not choices:
        raise VerifierResponseShapeError("missing choices in LLM response")
    message = choices[0].get("message", {})
    content = message.get("content", "")
    if not isinstance(content, str) or not content.strip():
        raise VerifierResponseShapeError("missing content in LLM response")
    return content


def _recover_structured_output(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    initial_messages: list[dict[str, str]],
    parser: Callable[[str], TStructured],
    regeneration_system_prompt: str,
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    notify_listener: bool = True,
    post_fn: Callable[[str, str, str, list[dict[str, str]]], str] | None = None,
) -> tuple[TStructured, str]:
    return recover_structured_output(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model=model,
        initial_messages=initial_messages,
        parser=parser,
        regeneration_system_prompt=regeneration_system_prompt,
        log_path=log_path,
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=hook_input,
        notify_listener=notify_listener,
        post_fn=post_fn if post_fn is not None else _post,
    )