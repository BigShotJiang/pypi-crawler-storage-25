"""cybervisor.core_hooks.common — Backward-compatible re-exports from submodules.

This module is kept for backward compatibility. New code should import
directly from cybervisor.core_hooks submodules or cybervisor.core_hooks.
"""

from __future__ import annotations

# Explicit re-exports to avoid circular import issues
from cybervisor.core_hooks.contracts import (
    active_stage_contract,
    contract_prompt_guidance,
    contract_repair_message,
    is_final_stage_attempt,
    resolve_artifact_path,
    validate_stage_contract_artifact,
)
from cybervisor.core_hooks.streaming import (
    AUTONOMY_DENY_MESSAGE,
    HookDecision,
    active_stage_prompt,
    append_hook_event,
    blocking_decision,
    collapse_whitespace,
    continuation_message_for_decision,
    contract_blocking_decision,
    dedupe_subsumed_segments,
    extract_json_string_field,
    format_contract_verifier_payload,
    format_verifier_payload,
    hook_log_path,
    json_default,
    load_hook_runtime_config,
    log_hook_event,
    normalize_hook_verifier_input,
    parse_decision,
    parse_hook_payload,
    resolve_verifier_settings,
    send_hook_event,
    socket_path_from_config,
    strip_fences,
    strip_prompt_prefix,
    utc_now,
)
from cybervisor.core_hooks.verifier import (
    DEFAULT_ENDPOINT,
    DEFAULT_MODEL,
    HOOK_HTTP_TIMEOUT_SECONDS,
    HOOK_USER_AGENT,
    STRUCTURED_RETRY_ATTEMPTS,
    VERIFIER_REQUEST_RETRY_ATTEMPTS,
    VerifierRequestError,
    VerifierResponseShapeError,
    chat_completions_url,
    get_stop_verifier_prompt,
    post,
    recover_structured_output,
    request_verifier_text,
)


__all__ = [
    # constants
    "AUTONOMY_DENY_MESSAGE",
    "DEFAULT_ENDPOINT",
    "DEFAULT_MODEL",
    "HOOK_HTTP_TIMEOUT_SECONDS",
    "HOOK_USER_AGENT",
    "STRUCTURED_RETRY_ATTEMPTS",
    "VERIFIER_REQUEST_RETRY_ATTEMPTS",
    # verifier
    "VerifierRequestError",
    "VerifierResponseShapeError",
    "chat_completions_url",
    "get_stop_verifier_prompt",
    "post",
    "recover_structured_output",
    "request_verifier_text",
    # contracts
    "active_stage_contract",
    "contract_prompt_guidance",
    "contract_repair_message",
    "is_final_stage_attempt",
    "resolve_artifact_path",
    "validate_stage_contract_artifact",
    # streaming
    "HookDecision",
    "active_stage_prompt",
    "append_hook_event",
    "blocking_decision",
    "collapse_whitespace",
    "continuation_message_for_decision",
    "contract_blocking_decision",
    "dedupe_subsumed_segments",
    "extract_json_string_field",
    "format_contract_verifier_payload",
    "format_verifier_payload",
    "hook_log_path",
    "json_default",
    "load_hook_runtime_config",
    "log_hook_event",
    "normalize_hook_verifier_input",
    "parse_decision",
    "parse_hook_payload",
    "resolve_verifier_settings",
    "send_hook_event",
    "socket_path_from_config",
    "strip_fences",
    "strip_prompt_prefix",
    "utc_now",
]
