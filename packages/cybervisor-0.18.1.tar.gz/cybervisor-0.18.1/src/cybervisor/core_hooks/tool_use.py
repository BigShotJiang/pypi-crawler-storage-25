from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path
from typing import Any

from cybervisor.core_hooks.common import load_hook_runtime_config as _load_hook_runtime_config

# ---------------------------------------------------------------------------
# Tool-use hook (PreToolUse / BeforeToolCall)
# ---------------------------------------------------------------------------

_CLAUDE_WRITE_TOOLS: frozenset[str] = frozenset({"Write", "Edit", "NotebookEdit", "Bash"})
_GEMINI_WRITE_TOOLS: frozenset[str] = frozenset({"Write", "Edit", "NotebookEdit", "Bash"})

_BASH_WRITE_PATTERNS: list[tuple[str, str]] = [
    # Matches: > path, >> path
    (r">\s*(\S+)", "redirect_write"),
    (r">>\s*(\S+)", "redirect_append"),
    # Matches: sed -i and variants
    (r"\bsed\s+\S*\s*-i\b", "sed_inplace"),
    # Matches: tee [-flags] path (handles tee -a, tee --append, etc.)
    (r"\btee\s+(?:--?\S+\s+)*(\S+)", "tee_write"),
]


def _resolve_target_path(tool_name: str, tool_input: dict[str, Any], workspace_root: str) -> str | None:
    """Extract the target file path from a write-tool call.

    Returns the absolute resolved path, or None if no path can be extracted.
    """
    if tool_name == "NotebookEdit":
        file_path = tool_input.get("notebook_path")
    elif tool_name in ("Write", "Edit"):
        file_path = tool_input.get("file_path")
    else:
        return None
    if isinstance(file_path, str) and file_path.strip():
        return str((Path(workspace_root) / file_path).resolve())
    return None


def _extract_bash_write_paths(command: str, workspace_root: str) -> tuple[list[str], bool]:
    """Extract file paths targeted by write patterns in a Bash command.

    Returns a tuple of (resolved absolute paths, has_unresolved_write).
    has_unresolved_write is True when a write pattern was detected but no
    target path could be extracted (e.g., ``sed -i`` without a capturable
    filename).  Callers should block conservatively when this flag is True.
    """
    paths: list[str] = []
    has_unresolved_write = False
    for pattern, _label in _BASH_WRITE_PATTERNS:
        for match in re.finditer(pattern, command):
            target = match.group(1) if match.lastindex else None
            if target:
                resolved = str((Path(workspace_root) / target).resolve())
                paths.append(resolved)
            else:
                has_unresolved_write = True
    return paths, has_unresolved_write


def _is_path_read_only(target_path: str, read_only_patterns: list[str], workspace_root: str) -> bool:
    """Check if a target path matches any read_only_paths pattern.

    Uses fnmatch for glob support (not PurePath.match, which lacks ** in Python 3.11).
    """
    target = Path(target_path).resolve()
    root = Path(workspace_root).resolve()

    for pattern in read_only_patterns:
        # Resolve the pattern relative to workspace root for matching
        full_pattern = str(root / pattern)
        if fnmatch.fnmatch(str(target), full_pattern):
            return True
    return False


def run_tool_use_hook(config_path: Path, input_data: str) -> dict[str, Any]:
    """Entry point for the PreToolUse / BeforeToolCall hook.

    Reads the tool-call JSON from stdin, checks write operations against
    read_only_paths, and returns an agent-specific allow/block decision.
    """
    try:
        runtime_config = _load_hook_runtime_config(config_path)
    except (FileNotFoundError, ValueError):
        return {"decision": "allow"}

    read_only_paths: list[str] = runtime_config.get("read_only_paths", [])
    if not isinstance(read_only_paths, list):
        read_only_paths = []

    if not read_only_paths:
        return {"decision": "allow"}

    workspace_root_raw = runtime_config.get("workspace_root", str(Path.cwd().resolve()))
    workspace_root: str = str(workspace_root_raw) if isinstance(workspace_root_raw, str) and workspace_root_raw.strip() else str(Path.cwd().resolve())

    agent_tool = runtime_config.get("agent_tool", "")
    if not isinstance(agent_tool, str):
        agent_tool = ""

    # Parse the input JSON
    try:
        payload = json.loads(input_data)
    except json.JSONDecodeError:
        return _tool_use_allow(agent_tool)

    if not isinstance(payload, dict):
        return _tool_use_allow(agent_tool)

    tool_name = payload.get("tool_name", "")
    if not isinstance(tool_name, str):
        return _tool_use_allow(agent_tool)

    tool_input = payload.get("tool_input", {})
    if not isinstance(tool_input, dict):
        tool_input = {}

    # Determine if this is a write tool
    write_tools = _CLAUDE_WRITE_TOOLS if agent_tool == "claude" else _GEMINI_WRITE_TOOLS
    if tool_name not in write_tools:
        # Read tool — always allow
        return _tool_use_allow(agent_tool)

    # Handle Bash specially — inspect the command for write patterns
    if tool_name == "Bash":
        command = tool_input.get("command", "")
        if not isinstance(command, str):
            # Conservative: block if command is not a string
            return _tool_use_block(agent_tool, "Bash command could not be parsed; blocking to prevent writes to read-only paths.")

        write_paths, has_unresolved_write = _extract_bash_write_paths(command, workspace_root)
        if has_unresolved_write:
            # Write pattern detected but target path could not be extracted — block conservatively
            return _tool_use_block(agent_tool, "Bash command contains a write pattern (e.g., sed -i) but the target path could not be resolved; blocking to prevent writes to read-only paths.")
        if not write_paths:
            # No write patterns detected — allow the Bash call
            return _tool_use_allow(agent_tool)

        for target in write_paths:
            if _is_path_read_only(target, read_only_paths, workspace_root):
                rel = str(Path(target).relative_to(Path(workspace_root).resolve())) if Path(target).is_relative_to(Path(workspace_root).resolve()) else target
                return _tool_use_block(agent_tool, f"Path {rel} is protected by read_only_paths for this stage.")

        # All write targets are outside protected paths — allow
        return _tool_use_allow(agent_tool)

    # Write / Edit / NotebookEdit — extract the file path
    target_path: str | None = _resolve_target_path(tool_name, tool_input, workspace_root)
    if target_path is None:
        # Can't resolve path — conservative block
        return _tool_use_block(agent_tool, f"Could not resolve target path for {tool_name}; blocking to prevent writes to read-only paths.")

    if _is_path_read_only(target_path, read_only_paths, workspace_root):
        rel = str(Path(target_path).relative_to(Path(workspace_root).resolve())) if Path(target_path).is_relative_to(Path(workspace_root).resolve()) else target_path
        return _tool_use_block(agent_tool, f"Path {rel} is protected by read_only_paths for this stage.")

    return _tool_use_allow(agent_tool)


def _tool_use_allow(agent_tool: str) -> dict[str, Any]:
    """Return an allow decision in the agent-specific output format."""
    if agent_tool == "claude":
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "allow",
            }
        }
    return {"decision": "allow"}


def _tool_use_block(agent_tool: str, reason: str) -> dict[str, Any]:
    """Return a block/deny decision in the agent-specific output format."""
    if agent_tool == "claude":
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }
    return {"decision": "deny", "reason": reason, "systemMessage": reason}