"""Assets used by the `cybervisor init` scaffold."""
