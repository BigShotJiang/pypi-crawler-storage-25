from __future__ import annotations

import shlex
import sys
from pathlib import Path


def build_hook_command(runtime_config_path: Path, *, mode: str = "stop") -> str:
    python_executable = shlex.quote(sys.executable)
    config_argument = shlex.quote(str(runtime_config_path))
    if mode == "stop":
        return f"{python_executable} -m cybervisor.agent_hook --config {config_argument}"
    return f"{python_executable} -m cybervisor.agent_hook --config {config_argument} --mode {mode}"
