from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal
from urllib.parse import urlparse

import httpx

from cybervisor.global_config import DEFAULT_ENDPOINT, DEFAULT_MODEL, GlobalConfigError, GlobalLLMConfig, load_global_config

DoctorStatus = Literal[
    "ready",
    "missing_config",
    "missing_api_key",
    "invalid_config",
    "unauthorized",
    "forbidden",
    "connection_failed",
    "timeout",
    "rate_limited",
    "endpoint_error",
    "unusable_response",
]
DoctorFailureCategory = Literal["none", "local_config", "remote_probe"]
DoctorExitCode = Literal[0, 1]


@dataclass(frozen=True, slots=True)
class DoctorResult:
    status: DoctorStatus
    is_ready: bool
    summary: str
    remediation: str
    failure_category: DoctorFailureCategory
    remote_probe_attempted: bool
    exit_code: DoctorExitCode
    status_code: int | None = None
    detail: str | None = None

    def to_output(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["scope"] = "verifier_readiness"
        return payload


@dataclass(frozen=True, slots=True)
class DoctorProbeResult:
    response: httpx.Response | None = None
    transport_error: httpx.HTTPError | None = None
    remote_probe_attempted: bool = False
    request_url: str | None = None


LOCAL_CONFIG_REMEDIATION = "Fix ~/.cybervisor/config.yaml so the verifier `llm` settings are valid, then run `cybervisor doctor` again."
MISSING_CONFIG_REMEDIATION = "Add an `llm` section to ~/.cybervisor/config.yaml and run `cybervisor doctor` again."
API_KEY_REMEDIATION = "Set llm.api_key in ~/.cybervisor/config.yaml and run `cybervisor doctor` again."
BASE_URL_REMEDIATION = "Set llm.base_url in ~/.cybervisor/config.yaml to a valid OpenAI-compatible endpoint and run `cybervisor doctor` again."
MODEL_REMEDIATION = "Set llm.model in ~/.cybervisor/config.yaml to a non-empty model name or use `auto`, then run `cybervisor doctor` again."
AUTH_REMEDIATION = "Update llm.api_key in ~/.cybervisor/config.yaml and run `cybervisor doctor` again."
TIMEOUT_REMEDIATION = "Verify the verifier endpoint is reachable from this machine and try again."
ENDPOINT_REMEDIATION = "Check llm.base_url and llm.model in ~/.cybervisor/config.yaml and try again."
FORBIDDEN_REMEDIATION = "Check that the verifier credentials are allowed to use the configured model and endpoint, then run `cybervisor doctor` again."
UNUSABLE_RESPONSE_REMEDIATION = "Check that the verifier endpoint is OpenAI-compatible and returns a valid response, then run `cybervisor doctor` again."
READY_REMEDIATION = "Verifier configuration is ready."


def _result(
    status: DoctorStatus,
    *,
    is_ready: bool,
    summary: str,
    remediation: str,
    failure_category: DoctorFailureCategory,
    remote_probe_attempted: bool,
    status_code: int | None = None,
    detail: str | None = None,
) -> DoctorResult:
    return DoctorResult(
        status=status,
        is_ready=is_ready,
        summary=summary,
        remediation=remediation,
        failure_category=failure_category,
        remote_probe_attempted=remote_probe_attempted,
        exit_code=0 if is_ready else 1,
        status_code=status_code,
        detail=detail,
    )


def _missing_config_result() -> DoctorResult:
    return _result(
        status="missing_config",
        is_ready=False,
        summary="No verifier configuration was found in ~/.cybervisor/config.yaml.",
        remediation=MISSING_CONFIG_REMEDIATION,
        failure_category="local_config",
        remote_probe_attempted=False,
    )


def _normalize_base_url(raw_base_url: str) -> str | None:
    candidate = raw_base_url.strip()
    if not candidate:
        return None
    parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"}:
        return None
    if not parsed.netloc:
        return None
    normalized_path = parsed.path.rstrip("/")
    return parsed._replace(path=normalized_path).geturl()


def _is_missing_verifier_config(config: GlobalLLMConfig) -> bool:
    return config.base_url == DEFAULT_ENDPOINT and config.model == DEFAULT_MODEL


def _is_blank(value: str) -> bool:
    return not value.strip()


def _is_valid_model(value: str) -> bool:
    return not _is_blank(value)


def _is_valid_base_url(value: str) -> bool:
    return _normalize_base_url(value) is not None


def _classify_local_config(config: GlobalLLMConfig) -> DoctorResult | None:
    if _is_blank(config.api_key):
        return _result(
            status="missing_api_key",
            is_ready=False,
            summary="llm.api_key is missing or empty.",
            remediation=API_KEY_REMEDIATION,
            failure_category="local_config",
            remote_probe_attempted=False,
        )
    if _is_blank(config.base_url):
        return _result(
            status="invalid_config",
            is_ready=False,
            summary="llm.base_url is missing or empty.",
            remediation=BASE_URL_REMEDIATION,
            failure_category="local_config",
            remote_probe_attempted=False,
            detail="base_url_missing",
        )
    if _is_missing_verifier_config(config):
        return _missing_config_result()
    if not _is_valid_base_url(config.base_url):
        return _result(
            status="invalid_config",
            is_ready=False,
            summary="llm.base_url is missing or invalid.",
            remediation=BASE_URL_REMEDIATION,
            failure_category="local_config",
            remote_probe_attempted=False,
            detail="base_url_invalid",
        )
    if not _is_valid_model(config.model):
        return _result(
            status="invalid_config",
            is_ready=False,
            summary="llm.model is missing or empty.",
            remediation=MODEL_REMEDIATION,
            failure_category="local_config",
            remote_probe_attempted=False,
            detail="model_missing",
        )
    return None


def _response_looks_usable(response: httpx.Response) -> bool:
    try:
        payload = response.json()
    except ValueError:
        return False
    if not isinstance(payload, dict):
        return False
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        return False
    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        return False
    message = first_choice.get("message")
    if not isinstance(message, dict):
        return False
    content = message.get("content")
    return isinstance(content, str)


def _probe_success_result(response: httpx.Response) -> DoctorResult:
    if not _response_looks_usable(response):
        return _result(
            status="unusable_response",
            is_ready=False,
            summary="Verifier endpoint returned an unusable response.",
            remediation=UNUSABLE_RESPONSE_REMEDIATION,
            failure_category="remote_probe",
            remote_probe_attempted=True,
            status_code=response.status_code,
            detail="invalid_response_shape",
        )
    return _result(
        status="ready",
        is_ready=True,
        summary="Verifier configuration is ready.",
        remediation=READY_REMEDIATION,
        failure_category="none",
        remote_probe_attempted=True,
        status_code=response.status_code,
    )


def _classify_response(response: httpx.Response) -> DoctorResult:
    if response.status_code == 401:
        return _result(
            status="unauthorized",
            is_ready=False,
            summary="Verifier credentials were rejected (401 Unauthorized).",
            remediation=AUTH_REMEDIATION,
            failure_category="remote_probe",
            remote_probe_attempted=True,
            status_code=401,
        )
    if response.status_code == 403:
        return _result(
            status="forbidden",
            is_ready=False,
            summary="Verifier credentials were rejected (403 Forbidden).",
            remediation=FORBIDDEN_REMEDIATION,
            failure_category="remote_probe",
            remote_probe_attempted=True,
            status_code=403,
        )
    if response.status_code == 429:
        return _result(
            status="rate_limited",
            is_ready=True,
            summary="Verifier endpoint is reachable but currently rate limited (429).",
            remediation="Wait for the rate limit window to reset before running a verifier-backed pipeline.",
            failure_category="none",
            remote_probe_attempted=True,
            status_code=429,
        )
    if response.is_success:
        return _probe_success_result(response)
    return _result(
        status="endpoint_error",
        is_ready=False,
        summary=f"Verifier endpoint returned an unexpected status ({response.status_code}).",
        remediation=ENDPOINT_REMEDIATION,
        failure_category="remote_probe",
        remote_probe_attempted=True,
        status_code=response.status_code,
    )


def _classify_http_error(exc: httpx.HTTPError, *, timeout: float) -> DoctorResult:
    if isinstance(exc, httpx.TimeoutException):
        return _result(
            status="timeout",
            is_ready=False,
            summary=f"Verifier endpoint timed out after {timeout:g}s.",
            remediation=TIMEOUT_REMEDIATION,
            failure_category="remote_probe",
            remote_probe_attempted=True,
        )
    if isinstance(exc, httpx.ConnectError):
        reason = str(exc) or "connection failed"
        return _result(
            status="connection_failed",
            is_ready=False,
            summary=f"Could not reach the verifier endpoint ({reason}).",
            remediation=BASE_URL_REMEDIATION,
            failure_category="remote_probe",
            remote_probe_attempted=True,
            detail=reason,
        )
    return _result(
        status="endpoint_error",
        is_ready=False,
        summary="Verifier request failed.",
        remediation=ENDPOINT_REMEDIATION,
        failure_category="remote_probe",
        remote_probe_attempted=True,
        detail=exc.__class__.__name__,
    )


def _probe_payload(config: GlobalLLMConfig) -> dict[str, object]:
    payload: dict[str, object] = {
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 5,
    }
    if config.model.strip() and config.model != DEFAULT_MODEL:
        payload["model"] = config.model
    return payload


def _probe_verifier(config: GlobalLLMConfig, *, timeout: float) -> DoctorProbeResult:
    payload = _probe_payload(config)
    client = httpx.Client(timeout=timeout)
    request_url = f"{config.base_url.rstrip('/')}/chat/completions"
    try:
        response = client.post(
            request_url,
            json=payload,
            headers={"Authorization": f"Bearer {config.api_key}"},
        )
        return DoctorProbeResult(
            response=response,
            remote_probe_attempted=True,
            request_url=request_url,
        )
    except httpx.HTTPError as exc:
        return DoctorProbeResult(
            transport_error=exc,
            remote_probe_attempted=True,
            request_url=request_url,
        )
    finally:
        client.close()


def diagnose_global_llm_readiness(*, timeout: float = 15.0) -> DoctorResult:
    try:
        config = load_global_llm_config()
    except (GlobalConfigError, ValueError) as exc:
        return _result(
            status="invalid_config",
            is_ready=False,
            summary=f"Failed to load verifier config: {exc}",
            remediation=LOCAL_CONFIG_REMEDIATION,
            failure_category="local_config",
            remote_probe_attempted=False,
            detail=str(exc),
        )

    return diagnose_llm_connectivity(config, timeout=timeout)


def load_global_llm_config() -> GlobalLLMConfig:
    """Load the LLM configuration from ~/.cybervisor/config.yaml."""
    return load_global_config().llm


def diagnose_llm_connectivity(config: GlobalLLMConfig, *, timeout: float = 15.0) -> DoctorResult:
    validation_error = _classify_local_config(config)
    if validation_error is not None:
        return validation_error

    probe_result = _probe_verifier(config, timeout=timeout)
    if probe_result.transport_error is not None:
        return _classify_http_error(probe_result.transport_error, timeout=timeout)
    assert probe_result.response is not None, "probe_verifier returned None response after passing local config validation"
    return _classify_response(probe_result.response)


def verify_llm_connectivity(config: GlobalLLMConfig, *, timeout: float = 15.0) -> tuple[bool, str]:
    result = diagnose_llm_connectivity(config, timeout=timeout)
    return result.is_ready, "" if result.is_ready else result.summary
