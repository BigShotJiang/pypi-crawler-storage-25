# Runtime and Daemon (Developer Reference)

> **Audience: Developers** — Contributors extending the runtime, adapters, or hook system.

## Pipeline Lifecycle

For `gemini`, `claude`, and `codex` runs, `cybervisor` performs the following lifecycle:

1. Performs preflight checks.
2. Restores any skills left in `.cybervisor/backups/skills/` from a previous unclean shutdown (see [Skill Disable/Restore in User Guide](runtime-user.md#skill-disablerestore)).
3. Moves skills listed in `disabled_skills` from the project-local skills directory to `.cybervisor/backups/skills/<adapter>/`.
4. Writes shared hook runtime metadata into `.cybervisor/hooks/`.
5. Persists an exact settings snapshot in `.cybervisor/hooks/`.
6. Patches the active tool settings file so the selected agent invokes the packaged `cybervisor-agent-hook` entry point (verifier/stop hook only; the tool-use hook for write protection is managed per-stage, not at pipeline start).
7. For each stage, before the agent starts: if the stage defines `read_only_paths`, installs the `PreToolUse` (Claude Code) or `BeforeToolCall` (Gemini CLI) hook to block write-tool calls targeting those paths; if the stage has no `read_only_paths`, removes the tool-use hook so the stage runs without it. This per-stage lifecycle means design stages get write protection while implementation stages run without the hook.
8. Starts the agent in a dedicated process group when supported. For Claude and Gemini adapters, the prompt is written to the agent subprocess's stdin rather than passed as a CLI argument (avoiding shell argument length limits). For Codex, the prompt is delivered through the app-server JSON-RPC protocol, which requires continuous stdin access.
9. Uses the runtime hook to classify autonomy decisions as `approve` or `block`, then adapts those into the selected tool's native hook output so the agent continues autonomously.
10. If the active stage declares a contract, uses the same hook runtime to block completion until the required artifact exists and is structurally valid.
11. Streams agent output into stderr and the stage log file.
12. Re-validates contract artifacts after agent exit, then routes by contract status or explicit `next_stage` when configured.
13. Terminates the agent's descendant processes via `SignalHandler.terminate_descendants()`: sends SIGTERM to the process group (or individual PID on Windows), waits up to 2 seconds, sends SIGKILL to survivors, then falls back to individually tracked child PIDs. This runs in the `execute_stage()` finally block, after the agent exits but before PID tracking is cleared.
14. Restores moved skills from `.cybervisor/backups/skills/` to their original project-local directories.
15. After the full pipeline loop, runs `SignalHandler.terminate_remaining_descendants()` as a safety net (CLI mode only; the daemon path relies on per-stage cleanup because it may host concurrent tasks): walks the process tree via `psutil.Process(os.getpid()).children(recursive=True)` to discover and terminate any orphans that escaped stage-level cleanup.
16. Restores settings and removes runtime files on success, failure, or interrupt.

## Adapter Compatibility

- **Gemini**: Prompt delivery via stdin is best-effort. If the Gemini CLI does not consume stdin, the prompt may be silently lost. There is no `--prompt` CLI fallback. If you encounter empty prompt behavior with Gemini, verify that the version of Gemini CLI you are running supports reading from stdin in `--output-format stream-json` mode with `--yolo`.
- **Codex**: The Codex app-server transport requires continuous stdin access for JSON-RPC messages. The Codex adapter does not use the stdin-prompt-write path and instead communicates through the app-server protocol.

## Run-Daemon Coordination

When `cybervisor run` is invoked (both bare-prompt and explicit `run` subcommand), it checks whether the daemon is reachable before acquiring the local `.cybervisor/instance.lock`. If the daemon is reachable and has any active task (status: `"running"`), `run` exits `1` with a message showing the running task ID and stage, directing the user to `attach` or `cancel`. This prevents `run` instances from executing concurrently with daemon-submitted tasks in the same directory. When the daemon is unreachable, `run` falls back to the standard `.cybervisor/instance.lock` mechanism.

**CWD normalization:** Task matching resolves symlinks and normalizes paths (including trailing slashes). This means `/workspace`, `/workspace/`, and symlinked paths to the same directory all resolve to the same canonical path, ensuring nested task detection is not bypassed by symlinks or trailing slashes.

## Generated Artifacts

- `.cybervisor/logs/cybervisor.log.jsonl`: structured run log
- `.cybervisor/logs/stages/<stage_name>.jsonl`: captured transcript per stage
- `.cybervisor/backups/<stage_name>/<timestamp>/`: versioned backups of stage artifacts after successful completion; each timestamped directory preserves one run's artifacts; never wiped by the artifact reset step
- `.cybervisor/contracts/artifacts/*.yaml`: optional stage-result artifacts for contract-enabled stages; before each stage execution, all top-level files in this directory (except the current stage's own artifact) are removed so agents are not confused by stale artifacts from prior stages — nested subdirectories are preserved
- generated contract guidance is derived from each stage's `contract.routes` and contract field definitions in `cybervisor.yaml`

## Client Subcommand Reference (Daemon Mode)

- **`cybervisor status`** — sends a `ping` message; exits `0` if the daemon is reachable, `1` otherwise. When the daemon is reachable, it reads the extended `pong` response containing active task snapshots (protocol v2) and prints running task IDs and stages. Tasks with status `"completed"` or `"cancelled"` are excluded from the display. For tasks registered but not yet started (active_stage is `null`), the output renders `"initializing"`.
- **`cybervisor submit`** — sends a `run` message; streams all pipeline events and returns the pipeline exit code on `run_complete`. Accepts a positional prompt argument or reads the task description from stdin when no argument is given (e.g., `printf "task" | cybervisor submit`). If both a positional argument and piped stdin are present, the positional argument takes precedence. Empty or whitespace-only stdin with no positional argument produces a non-zero exit with the message "No prompt provided via argument or stdin."
- **`cybervisor attach`** — sends a `resume` message; when `task_id` is omitted, pings the daemon to find running tasks in the current directory and auto-resolves to the sole one (errors with "No active task to attach to." if zero tasks; errors with "Multiple tasks are running in this directory." if more than one); replays buffered events (handling chunked payloads automatically), then subscribes to live events until the task reaches a terminal state.
- **`cybervisor cancel`** — sends a `cancel` message; when `task_id` is omitted, the daemon uses the client-provided `cwd` to find and cancel the running task in the current directory (same disambiguation rules as `attach`); the daemon responds with `pipeline_abort` followed by `run_complete` on the canceler's own connection. The client exits `0` on `pipeline_abort`, `1` on error.
- **`cybervisor logs`** — sends a `resume` message; drains all buffered events and outputs each as a JSON line to stdout.
- **`cybervisor end`** — sends a `set_stop_stage` message; accepts `--after <stage>` (stop after this stage executes, same as the old `--stage` flag) or `--before <stage>` (stop before this stage starts, skipping it); `--after` and `--before` are mutually exclusive. An optional positional `task_id` explicitly targets a specific task; when omitted, the daemon uses the client-provided `cwd` to find the running task in the current directory. Both `--after` and `--before` are updatable mid-run via the daemon's `set_stop_stage` message — the runner checks the `EndStageRef` dynamically at each stage transition, so a subsequent `end` command can change the stop point while the pipeline is running. This mid-run update capability is daemon-mode only; direct `run` mode has no `EndStageRef` wiring and the `--end-after`/`--end-before` flags are fixed at invocation.

All client commands accept `--host` and `--port` to override the daemon address. Defaults come from `~/.cybervisor/config.yaml` (`server.host`, `server.port`). The connection timeout is 5 seconds; commands exit `1` with a "daemon not reachable" message on timeout or connection failure.