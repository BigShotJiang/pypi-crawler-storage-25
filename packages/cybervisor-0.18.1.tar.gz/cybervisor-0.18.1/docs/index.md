# cybervisor Documentation

> **Audience: All** — New and experienced users, operators, and contributors.

This directory contains all user-facing and contributor-facing documentation for `cybervisor`. Each document declares its audience at the top (Users, Developers, or All).

## New Users — Start Here

1. Read the [project README](../README.md) for a high-level overview, installation, and quick start.
2. Follow the [Getting Started](getting-started.md) tutorial for a guided first run.
3. If something goes wrong, check [Troubleshooting](troubleshooting.md).

## Architecture Overview

For the repository layout and package structure, see [Development](development.md). For component-specific runtime details:

- CLI commands, daemon usage, and skill management: [Runtime and Daemon — User Guide](runtime-user.md)
- Pipeline internals, adapter details, and generated artifacts: [Runtime and Daemon — Developer Reference](runtime-internals.md)
- Daemon WebSocket protocol and message schema: [WebSocket Protocol](websocket-protocol.md)
- Pipeline stages, contracts, and routing design: [Pipeline Authoring Guide](pipeline-authoring.md)
- Smoke tests, mock adapter, Docker, and sandbox: [Testing and Sandbox](testing.md)

## User Guides

| Document | What it covers |
|----------|---------------|
| [Getting Started](getting-started.md) | Step-by-step tutorial from install to first pipeline run |
| [Configuration Reference](configuration.md) | `cybervisor.yaml`, `~/.cybervisor/config.yaml`, stage fields, CLI commands |
| [Pipeline Authoring Guide](pipeline-authoring.md) | Designing stages, contracts, routing, and agent prompts |
| [Runtime and Daemon — User Guide](runtime-user.md) | Daemon commands, client interaction, skill disable/restore, signals |
| [Updating](updating.md) | Install, upgrade, and migration workflows |
| [Shell Completions](completions.md) | Bash tab completion setup and comparison |
| [Troubleshooting](troubleshooting.md) | Common issues and resolutions |
| [Testing and Sandbox](testing.md) | Smoke tests, mock adapter, Docker test environment, sandbox internals |

## Developer Guides

| Document | What it covers |
|----------|---------------|
| [Runtime and Daemon — Developer Reference](runtime-internals.md) | Pipeline lifecycle, adapter compatibility, generated artifacts |
| [Testing and Sandbox](testing.md) | Mock API server, Docker test environment, sandbox internals |
| [Updating — Developer Reference](updating-dev.md) | Repo update and release publishing |
| [Development](development.md) | Repository layout, local setup, tests, and release workflow |
| [Adding an Adapter](contributing/adding-an-adapter.md) | Maintainer contract for new coding-agent adapters |
| [WebSocket Protocol](websocket-protocol.md) | Daemon message schema, connection lifecycle, chunking |