# Troubleshooting cybervisor

> **Audience: Users** — Pipeline operators encountering issues.

## Installation and Setup

### `cybervisor: command not found`

`uv` did not install the tool onto your PATH, or your shell has not reloaded.

```bash
# Confirm uv's tool bin directory is on PATH
echo $PATH | grep -q "\.local/bin" || echo 'Add export PATH="$HOME/.local/bin:$PATH" to your shell profile'

# Reinstall and verify
uv tool install cybervisor
cybervisor --version
```

---

## Verifier and Credentials

### `Doctor: verifier blocked`

`~/.cybervisor/config.yaml` is missing or the `llm.api_key` field is absent.

```bash
mkdir -p ~/.cybervisor
cat > ~/.cybervisor/config.yaml <<'EOF'
agent_tool: claude
llm:
  api_key: sk-your-key-here
EOF
chmod 600 ~/.cybervisor/config.yaml
```

### `Doctor: verifier needs attention`

The API key is present but the remote endpoint rejected it (401 Unauthorized).

- Check that `llm.api_key` is valid and has not expired.
- If using a custom `base_url`, confirm the endpoint is reachable: `curl -I "$BASE_URL/models" -H "Authorization: Bearer $API_KEY"`.

---

## Pipeline Execution

### `A task is already running in this directory`

Another pipeline is active in the same working directory.

**Option A — Attach to the running task:**

```bash
cybervisor attach
```

**Option B — Cancel it:**

```bash
cybervisor cancel
```

**Option C — If you are sure nothing is running, remove stale locks:**

```bash
rm .cybervisor/instance.lock
```

If the daemon is running, also check:

```bash
cybervisor status
```

### Agent exits immediately with no output

- Confirm the selected agent is installed: `claude --version`, `gemini --version`, or `codex --version`.
- Check preflight output at the top of the run for missing prerequisites.
- For Gemini specifically, verify stdin consumption works in your CLI version; some versions require the prompt to be passed differently.

### Hook verifier returns `block` on every invocation

The verifier LLM is rejecting the hook decisions. Common causes:

- The verifier model is too restrictive. Try a different model in `~/.cybervisor/config.yaml`.
- The stage contract artifact is malformed. Inspect the artifact under `.cybervisor/contracts/artifacts/` and compare it to the expected schema.
- The hook verifier endpoint is unreachable. Check `cybervisor doctor`.

For testing with deterministic approvals, use the mock LLM API:

```bash
python3 scripts/.e2e_mock_llm_api.py --hook-mode allow &
# Then point llm.base_url at the printed URL
```

---

## Daemon Mode

### `Daemon not reachable at ws://127.0.0.1:8765`

The daemon is not running, or it is bound to a different host/port.

```bash
# Check if the daemon process exists
ps aux | grep "cybervisor serve"

# Start it explicitly
cybervisor serve

# Or with custom binding
cybervisor serve --host 0.0.0.0 --port 9000
```

When using custom ports, pass `--host` and `--port` to every client command:

```bash
cybervisor status --host 127.0.0.1 --port 9000
```

### `nested_task_rejected` when submitting

You submitted a new task from a directory that already has a running daemon task. Submit from a different directory, or cancel the existing task first.

---

## Skills and Settings

### Skills were not restored after a crash

If cybervisor was killed with SIGKILL or the machine powered off, the restore step may not have run.

Automatic recovery happens at the start of the next run. If you need to force it manually:

```bash
cybervisor restore-skills
```

Check `.cybervisor/backups/skills/` for orphaned skill directories and move them back to `.claude/skills/`, `.gemini/skills/`, or `.agents/skills/` manually if needed.

### Settings snapshot was not restored

If `.gemini/settings.json` or `.claude/settings.json` still contains cybervisor hook entries after a crash:

1. Look in `.cybervisor/hooks/` for the snapshot file (e.g., `settings_snapshot.json`).
2. Manually restore it to the tool's settings path, or remove the cybervisor hook entry.

---

## Write Protection (`read_only_paths`)

### Agent is blocked from writing to a file

If the agent reports "Path X is protected by the pipeline (read_only_paths)", the file matches a pattern in the current stage's `read_only_paths` in `cybervisor.yaml`.

- Check your stage's `read_only_paths` patterns — they use glob pattern matching resolved relative to the workspace root (e.g., `src/**` matches all files under `src/`).
- If the block is unexpected, verify the pattern isn't too broad. For example, `**/*.py` blocks all Python files project-wide.
- Bash commands with file-write patterns (`>`, `>>`, `sed -i`, `tee`) are blocked conservatively — if a write target cannot be resolved, the entire call is blocked. Restructure the command to make the target path explicit.

### `read_only_paths` is not blocking writes

- Confirm `read_only_paths` is set on the relevant stage in `cybervisor.yaml` (it is a per-stage field, not a top-level field or a `~/.cybervisor/config.yaml` field).
- Empty or absent `read_only_paths` for a stage means no write protection is installed for that stage. The `PreToolUse`/`BeforeToolCall` hook is only installed when the list is non-empty.
- The `Stop` / `AfterAgent` verifier hook is independent of `read_only_paths` and does not gate tool calls.
- **Enforcement scope:** `read_only_paths` is enforced at the hook level only — it intercepts tool calls made by the agent process. External processes, direct filesystem writes outside the agent session, or shell commands that bypass the agent's tool-use layer are not blocked.

---

## Configuration Validation

### `cybervisor validate` fails with route errors

Common issues:

- A contract stage defines a top-level `next_stage` — contract stages must use `contract.routes` only.
- An `injections` field is not declared in `contract.fields`.
- A route key does not match any `Status` value guidance in the prompt template.

Run with `--show-guidance` to preview the exact instructions generated for the agent:

```bash
cybervisor validate --show-guidance
```

### Contract route references unknown stage

If a `next_stage` value in `contract.routes` or a stage-level `next_stage` references a stage name that does not exist in the `stages` list, `cybervisor validate` catches this at config load time and raises a descriptive error. Fix the typo in `cybervisor.yaml` and re-run `cybervisor validate`.

The pipeline runner also has defense-in-depth handling: if an invalid `next_stage` reaches the runtime, the runner logs an error and aborts gracefully instead of crashing.

---

## Process Cleanup

### Agent-spawned processes remain after pipeline finishes

cybervisor terminates descendant processes at two points: after each stage (process group kill plus individual PID fallback) and after the full pipeline (process-tree sweep). If a process survives both:

- Check `.cybervisor/logs/cybervisor.log.jsonl` for entries with `"status": "Cleanup"` — these show which PIDs were targeted and whether SIGTERM/SIGKILL was sent.
- A process that called `setpgid` or `setsid` to leave the agent's process group and was then reparented to init (because its parent exited) may not be discoverable by the pipeline-level sweep. This is a known limitation.
- To check for remaining processes: `ps aux | grep -E 'vite|npm|node'` or use `psutil` to walk the process tree from the cybervisor process.

### Cleanup logs show "already exited" messages

This is normal and expected. When a process exits between discovery and termination, cybervisor logs a warning and continues. These messages confirm best-effort cleanup is working correctly.

---

## Encoding and Locale

### Encoding issues in agent output

If agent subprocess output contains garbled characters or encoding error messages:

- Set `PYTHONIOENCODING=utf-8` before running cybervisor:
  ```bash
  export PYTHONIOENCODING=utf-8
  cybervisor "your prompt"
  ```
- Verify your locale supports UTF-8: `locale charmap` should report `UTF-8`.

---

## Still stuck?

Open an issue at https://github.com/crzidea/cybervisor/issues with:

- `cybervisor --version`
- The output of `cybervisor doctor`
- The relevant stage log from `.cybervisor/logs/stages/`
- The contents of `cybervisor.yaml` (redact any sensitive prompts)
