from __future__ import annotations

import json
import re
import subprocess
import sys
from datetime import datetime
from importlib import import_module, resources
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

from .article_print import ArticleExtractionError, fetch_article, render_article_markdown
from .builder import build_paper
from .config import DEFAULT_CONFIG_PATH, ConfigError, MorningPaperConfig, load_config, render_default_config
from .renderers import TypewriterRendererUnavailable, _load_weasyprint, write_custom_markdown, _safe_filename


REPO_ROOT = Path(__file__).resolve().parents[2]
DOCS_URL = "https://github.com/dmthepm/morning-paper"
ROADMAP_URL = f"{DOCS_URL}/blob/main/ROADMAP.md"
PYPI_JSON_URL = "https://pypi.org/pypi/morning-paper/json"
ROADMAP_COMMANDS = {"add", "status", "remove", "list"}
HELP_TEXT = f"""Morning Paper — your morning newspaper, built from your own sources.

Commands:
  init              Create a starter config
  build             Build today's paper from configured sources
  print <url>       Print a single article right now
  doctor            Check config, dependencies, and renderer status
  --version         Show installed version

Coming soon:
  add <url|file>    Add content to tomorrow's paper
  status            Show what's staged and estimated page count

Config: {DEFAULT_CONFIG_PATH}
Docs:   {DOCS_URL}
"""
SCRIPT_MAP = {
    "pass1": REPO_ROOT / "scripts" / "run_pass1.py",
    "pass2": REPO_ROOT / "scripts" / "run_pass2.py",
    "pass3": REPO_ROOT / "scripts" / "run_pass3.py",
    "assemble": REPO_ROOT / "scripts" / "assemble_brief.py",
    "render": REPO_ROOT / "scripts" / "build_live_brief.py",
    "digest": REPO_ROOT / "scripts" / "send_brief_digest.py",
}


def _version_key(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", value or "")
    return tuple(int(part) for part in parts) or (0,)


def _fetch_latest_pypi_version() -> str | None:
    try:
        response = requests.get(PYPI_JSON_URL, timeout=2)
        response.raise_for_status()
        payload = response.json()
    except Exception:
        return None
    info = payload.get("info") if isinstance(payload, dict) else None
    version = info.get("version") if isinstance(info, dict) else None
    return str(version).strip() if version else None


def _print_update_notice() -> None:
    from . import __version__

    latest = _fetch_latest_pypi_version()
    if not latest or _version_key(latest) <= _version_key(__version__):
        return
    print(f"update available: {latest} (you have {__version__})")
    print("run: pip install --upgrade morning-paper")


def _pretty_install_hint_lines() -> list[str]:
    lines = ['recommended install: pip install "morning-paper[pretty]"']
    if sys.platform == "darwin":
        lines.append("macOS may also need: brew install pango gdk-pixbuf")
    elif sys.platform.startswith("linux"):
        lines.append("Linux may also need system libraries for WeasyPrint (for example pango/cairo packages)")
    elif sys.platform.startswith("win"):
        lines.append("Windows typewriter support is best-effort today; portable mode is more reliable")
    return lines


def run_script(script: Path, args: list[str]) -> int:
    if not script.exists():
        print(
            "This command requires the private Morning Brief harness. "
            "Use `morning-paper init` and `morning-paper build` instead.",
            file=sys.stderr,
        )
        return 1
    cmd = [sys.executable, str(script), *args]
    return subprocess.call(cmd, cwd=REPO_ROOT)


def doctor() -> int:
    missing: list[str] = []
    required_modules = [
        "morning_paper.cli",
        "morning_paper.article_print",
        "morning_paper.builder",
        "morning_paper.config",
        "morning_paper.extractors",
        "morning_paper.image_tools",
        "morning_paper.renderers",
        "morning_paper.sources",
    ]
    for module_name in required_modules:
        try:
            import_module(module_name)
        except Exception:
            missing.append(module_name)
    try:
        resource = resources.files("morning_paper").joinpath("resources", "typewriter.md")
        if not resource.is_file():
            missing.append("morning_paper/resources/typewriter.md")
    except Exception:
        missing.append("morning_paper/resources/typewriter.md")
    if missing:
        print("doctor: missing required files:", file=sys.stderr)
        for item in missing:
            print(f"- {item}", file=sys.stderr)
        return 1
    _, renderer_error = _load_weasyprint()
    if renderer_error:
        print("doctor: ok")
        print("renderer: typewriter unavailable")
        print("status: fallback-only install; high-quality print output is not available yet")
        for line in _pretty_install_hint_lines():
            print(line)
        _print_update_notice()
        return 0
    print("doctor: ok")
    print("renderer: typewriter ready")
    print("status: high-quality print path available")
    _print_update_notice()
    return 0


def init_command(args: list[str]) -> int:
    config_path = DEFAULT_CONFIG_PATH
    force = False
    index = 0
    while index < len(args):
        arg = args[index]
        if arg in {"-h", "--help"}:
            print("usage: morning-paper init [--config PATH] [--force]")
            return 0
        if arg == "--config" and index + 1 < len(args):
            config_path = Path(args[index + 1]).expanduser().resolve()
            index += 2
            continue
        if arg == "--force":
            force = True
            index += 1
            continue
        print(f"unknown init argument: {arg}", file=sys.stderr)
        return 2
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if config_path.exists() and not force:
        print(f"config already exists: {config_path}", file=sys.stderr)
        print("use --force to overwrite", file=sys.stderr)
        return 1
    config_path.write_text(render_default_config(), encoding="utf-8")
    print(json.dumps({"config": str(config_path), "created": True}, indent=2))
    return 0


def build_command(args: list[str]) -> int:
    config_path = DEFAULT_CONFIG_PATH
    date = None
    index = 0
    while index < len(args):
        arg = args[index]
        if arg in {"-h", "--help"}:
            print("usage: morning-paper build [--config PATH] [--date YYYY-MM-DD]")
            return 0
        if arg == "--config" and index + 1 < len(args):
            config_path = Path(args[index + 1]).expanduser().resolve()
            index += 2
            continue
        if arg == "--date" and index + 1 < len(args):
            date = args[index + 1]
            index += 2
            continue
        print(f"unknown build argument: {arg}", file=sys.stderr)
        return 2
    if not config_path.exists():
        print(f"missing config: {config_path}", file=sys.stderr)
        print("run `morning-paper init` first or pass --config", file=sys.stderr)
        return 1
    try:
        config = load_config(config_path)
    except ConfigError as exc:
        print(f"invalid config: {exc}", file=sys.stderr)
        return 1
    try:
        result = build_paper(config, date_str=date)
    except TypewriterRendererUnavailable as exc:
        print(str(exc), file=sys.stderr)
        return 1
    for warning in result.get("warnings", []):
        print(f"warning: {warning}", file=sys.stderr)
    print(json.dumps(result, indent=2))
    return 0


def _load_print_config(config_path: Path) -> tuple[MorningPaperConfig, bool]:
    if config_path.exists():
        return load_config(config_path), True
    return MorningPaperConfig(), False


def print_command(args: list[str]) -> int:
    config_path = DEFAULT_CONFIG_PATH
    date = None
    title = None
    urls: list[str] = []
    index = 0
    while index < len(args):
        arg = args[index]
        if arg in {"-h", "--help"}:
            print("usage: morning-paper print <url> [<url> ...] [--config PATH] [--date YYYY-MM-DD] [--title TITLE]")
            return 0
        if arg == "--config" and index + 1 < len(args):
            config_path = Path(args[index + 1]).expanduser().resolve()
            index += 2
            continue
        if arg == "--date" and index + 1 < len(args):
            date = args[index + 1]
            index += 2
            continue
        if arg == "--title" and index + 1 < len(args):
            title = args[index + 1]
            index += 2
            continue
        urls.append(arg)
        index += 1
    if not urls:
        print("print requires at least one URL", file=sys.stderr)
        return 2
    try:
        config, has_user_config = _load_print_config(config_path)
    except ConfigError as exc:
        print(f"invalid config: {exc}", file=sys.stderr)
        return 1
    if not has_user_config:
        print("using built-in defaults for one-off print", file=sys.stderr)
        print("run `morning-paper init` to customize feeds, timezone, and output paths", file=sys.stderr)
    try:
        articles = [fetch_article(url, extractor_name=config.article_extractor) for url in urls]
    except ArticleExtractionError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    target_date = date or datetime.now(ZoneInfo(config.timezone)).date().isoformat()
    bundle_title = title or articles[0].title
    slug = _safe_filename(bundle_title)[:48] or "article-print"
    try:
        outputs, warnings = write_custom_markdown(
            config,
            render_article_markdown(
                config,
                articles,
                date_str=target_date,
                images_dir=config.outputs.directory / target_date / slug / "_article_images",
            ),
            date_str=target_date,
            slug=slug,
            metadata={"mode": "print", "urls": urls, "article_count": len(articles)},
        )
    except TypewriterRendererUnavailable as exc:
        print(str(exc), file=sys.stderr)
        return 1
    for warning in warnings:
        print(f"warning: {warning}", file=sys.stderr)
    print(
        json.dumps(
            {
                "date": target_date,
                "mode": "print",
                "article_count": len(articles),
                "warnings": warnings,
                "outputs": {key: str(value) for key, value in outputs.items() if key != "dir"},
                "output_dir": str(outputs["dir"]),
            },
            indent=2,
        )
    )
    return 0


def smoke() -> int:
    script = REPO_ROOT / "scripts" / "smoke_test.sh"
    if not script.exists():
        print(
            "This command requires the private Morning Brief harness. "
            "Use `morning-paper init` and `morning-paper build` instead.",
            file=sys.stderr,
        )
        return 1
    return subprocess.call(["bash", str(script)], cwd=REPO_ROOT)


def print_help() -> int:
    print(HELP_TEXT.rstrip())
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in {"-V", "--version", "version"}:
        from . import __version__

        print(__version__)
        return 0
    if not argv or argv[0] in {"-h", "--help", "help"}:
        return print_help()

    command, extra = argv[0], argv[1:]

    if command == "init":
        return init_command(extra)
    if command == "build":
        return build_command(extra)
    if command == "print":
        return print_command(extra)
    if command in SCRIPT_MAP:
        return run_script(SCRIPT_MAP[command], extra)
    if command == "doctor":
        return doctor()
    if command == "smoke":
        return smoke()
    if command in ROADMAP_COMMANDS:
        print(f'"{command}" is planned for v0.2. See {ROADMAP_URL}', file=sys.stderr)
        return 2
    print(f"unknown command: {command}", file=sys.stderr)
    print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
