#Requires -Version 5.0

Write-Host "=== CellSense Installer ===" -ForegroundColor Cyan
Write-Host ""

# Check Python
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Host "Error: Python is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Install it from https://www.python.org/downloads/"
    exit 1
}

# Check Python >= 3.10
$versionCheck = python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" 2>&1
if ($LASTEXITCODE -ne 0) {
    $pyver = python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
    Write-Host "Error: Python 3.10 or higher is required (found $pyver)." -ForegroundColor Red
    exit 1
}

$pyVersion = python --version
Write-Host "$pyVersion found." -ForegroundColor Green

# Check pip
python -m pip --version | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Error: pip is not available." -ForegroundColor Red
    Write-Host "Install it with: python -m ensurepip"
    exit 1
}

Write-Host "pip found." -ForegroundColor Green

# Check JupyterLab
python -m pip show jupyterlab | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Error: JupyterLab is not installed." -ForegroundColor Red
    Write-Host "Install it with: pip install jupyterlab"
    exit 1
}

Write-Host "JupyterLab found." -ForegroundColor Green
Write-Host ""
Write-Host "Installing CellSense..."
Write-Host ""

python -m pip install .
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Error: Installation failed." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "CellSense installed successfully." -ForegroundColor Green
Write-Host "Start JupyterLab with: jupyter lab"
