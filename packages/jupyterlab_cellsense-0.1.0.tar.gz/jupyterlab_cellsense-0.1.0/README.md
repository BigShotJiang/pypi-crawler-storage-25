# CellSense

Ghost-text inline code completion for JupyterLab, powered by local or remote AI models.

---

## Overview

### What is this?

CellSense is a JupyterLab 4 extension that adds FIM (Fill-In-Middle) inline completions to your notebooks and file editor. As you type, it silently assembles context from your current cell, surrounding cells, and related files across your workspace — then requests a ghost-text suggestion from your chosen model. Press Tab to accept.

![CellSense ghost-text suggestion appearing in a notebook cell](assets/screenshots/AutoCompleteSuggestion.png)

### Features

- **Ghost-text completions** — inline suggestions appear as you type, accepted with Tab
- **Multi-file retrieval** — Indexes your workspace and surfaces relevant code chunks automatically
- **Recent State Aware** - Maintains a state of recently read and editted code chunks to provide rich context to your completions
- **Import tracking** — resolves local imports and injects relevant signatures into the prompt
- **Multi-cell context** — walks outward from your cursor through surrounding cells within a configurable token budget
- **Flexible providers** — works with Ollama (local) or any OpenAI-compatible API (OpenAI, vLLM, LM Studio, Azure, etc.)
- **Multiple model families** — first-class prompt support for DeepSeek Coder, Codestral, CodeLlama, StarCoder2, and Qwen2.5-Coder
- **In-JupyterLab settings** — configure everything from a sidebar panel without touching config files

### Why use it?

Most notebook completion tools treat each cell in isolation, or at best are aware of the surrounding cells in the currently open notebook. The quality of a completion is determined by the quality of context given to the model. CellSense is built around the idea that the most accurate completions come from a model that understands the current task, the tools at your disposal, and your typical coding style. It achieves this through three design principles:

**Local awareness** — Your utility functions, domain classes, and project-specific abstractions will never appear in any model's training data. CellSense addresses this by traversing your import tree and injecting the relevant function and class signatures directly into the prompt. The model reasons about your actual code, not a generic approximation of it.

![CellSense completing code using a local utility class](assets/screenshots/LocalUtilityAware.png)

**Recent state** — When working through a problem, the files you have been reading and editing are almost always the most relevant to your current task. CellSense maintains a rolling state of recently visited and modified code chunks, so the context reflects where your attention has actually been — not just what happens to be open in the active tab.

**Relevant chunk retrieval** — Beyond recency, CellSense indexes your workspace and retrieves code chunks that are lexically related to what you are currently writing. This surfaces patterns and solutions from elsewhere in your project that a cell-local view would miss entirely.

Together, these give the model a view of your work that is closer to your own mental model — without requiring any manual context management on your part. It can run entirely on local hardware if you use Ollama, with no data ever leaving your machine.

---

## Installation

### Prerequisites

- Python 3.10 or higher
- JupyterLab 4.0 or higher
- For local inference: [Ollama](https://ollama.com) installed and running
- For cloud inference: an API key for an OpenAI-compatible provider

### Install

#### Option 1 — pip (recommended)

```bash
pip install jupyterlab-cellsense
```

#### Option 2 — Clone the repo and run the install script

Clone the repository, then run the script for your platform from inside the project directory:

**macOS / Linux**
```bash
git clone https://github.com/arunkarthik11/CellSense.git
cd CellSense
./install.sh
```

**Windows (Command Prompt)**
```bat
git clone https://github.com/arunkarthik11/CellSense.git
cd CellSense
install.bat
```

**Windows (PowerShell)**
```powershell
git clone https://github.com/arunkarthik11/CellSense.git
cd CellSense
.\install.ps1
```

> Note: On first run, PowerShell may require you to allow script execution:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

#### Option 3 — GitHub release

Download the `.whl` file from the [latest release](https://github.com/arunkarthik11/CellSense/releases/latest) and install it directly:

```bash
pip install jupyterlab_cellsense-<version>-py3-none-any.whl
```

#### Option 4 — pip with git

Install the latest commit directly from GitHub without cloning:

```bash
pip install git+https://github.com/arunkarthik11/CellSense.git
```

### Verify installation

```bash
jupyter labextension list
```

You should see `jupyterlab-cellsense` in the output. Then start JupyterLab:

```bash
jupyter lab
```

---

## Quick Start

1. Start Ollama and pull a FIM model:
   ```bash
   ollama pull qwen2.5-coder:14b
   ```
2. Launch JupyterLab and open a notebook.
3. Open the CellSense panel from the left sidebar.
4. Confirm the provider is set to **Ollama** and the model matches what you pulled.
5. Click **Save & Apply**.
6. Start typing in a cell — a ghost-text suggestion will appear after a short pause. Press **Tab** to accept.

![CellSense settings panel configured with Ollama and qwen2.5-coder](assets/screenshots/BasicSettingsConfiguration.png)

---

## Configuration

Open the CellSense settings panel from the left sidebar, or via the Command Palette (`Ctrl+Shift+C` / `Cmd+Shift+C`) → **CellSense Settings**.

![CellSense advanced settings panel showing completion and retrieval options](assets/screenshots/AdvancedSettings.png)

### Available Options

#### Provider

| Option | Values | Default | Description |
|--------|--------|---------|-------------|
| `provider` | `ollama`, `openai_compatible` | `ollama` | Which backend to use for completions |

#### Ollama

| Option | Default | Description |
|--------|---------|-------------|
| `base_url` | `http://localhost:11434` | Address of your Ollama server |
| `model_family` | `deepseek-coder` | FIM prompt format — must match your model. Options: `deepseek-coder`, `codestral`, `codellama`, `starcoder2`, `qwen2.5-coder`, `other` |
| `model` | `deepseek-coder:6.7b` | Full Ollama model tag |

#### OpenAI Compatible

| Option | Default | Description |
|--------|---------|-------------|
| `base_url` | `https://api.openai.com/v1` | API endpoint — change for vLLM, LM Studio, Codestral, etc. |
| `api_key` | *Provided API KEY* | API key — The API key provided by the Model Provider |
| `model` | `gpt-4o-mini` | Model identifier |

#### Completion

| Option | Default | Description |
|--------|---------|-------------|
| `debounce_ms` | `500` | Milliseconds of idle time before a completion request is sent |
| `max_context_tokens` | `1500` | Token budget for cell-walking — cells are included outward from your cursor until this limit is reached |
| `max_tokens` | `256` | Maximum tokens the model can generate per completion |
| `one_line_completions` | `false` | Restrict suggestions to a single line. This is generally faster and more accurate, but generates fewer tokens. |

![One-line completion mode enabled in the advanced settings panel](assets/screenshots/OneLineCompletions.png)

#### Retrieval (RAG)

| Option | Default | Description |
|--------|---------|-------------|
| `enabled` | `true` | Enable BM25 workspace retrieval to inject relevant code chunks into the prompt |
| `top_k` | `3` | Number of code chunks retrieved from the workspace index (1–20) |
| `token_budget` | `2000` | Maximum tokens allocated to retrieved context |

**Warning**: If you are using an external model provider who trains on your data, be aware that enabling RAG could retrieve code chunks from your repository or workspace root to enrich the context. This means that context from other files could also be sent. If this is not something you are comfortable with, either switch to a provider who allows you to disable training or disable RAG for this feature. However, this would still traverse the import tree and retrieve the relevant signatures.

---

## Usage

### Basic Workflow

1. Open a notebook and start typing code in a cell.
2. Pause briefly — CellSense will assemble context from your notebook and workspace, then request a completion.
3. A ghost-text suggestion appears inline.
4. Press **Tab** to accept the full suggestion.
5. To dismiss without accepting, keep typing or press **Escape**.

![CellSense inline completion in a Python file](assets/screenshots/PythonFileCompatible.png)

### Commands / UI Elements

| Element | How to access |
|---------|---------------|
| Settings sidebar panel | Left sidebar icon |
| CellSense Settings (full dialog) | Command Palette → "CellSense Settings" |
| Accept completion | Tab |
| Dismiss completion | Escape or continue typing |

The settings panel is divided into three sections:

- **Basic Settings** — provider selection, model configuration
- **Advanced: Completion** — debounce, token budgets, one-line mode
- **Advanced: Retrieval** — enable/disable RAG, top-K, token budget

Click **Save & Apply** after making changes. Settings take effect immediately without restarting JupyterLab.

---

## Examples

### Using Ollama with Codestral

1. Pull the model: `ollama pull codestral`
2. In the settings panel, set **Provider** to `Ollama`, **Model Family** to `codestral`, and **Model** to `codestral`.
3. Save & Apply.

### Using an OpenAI-compatible local server (LM Studio)

1. Start your LM Studio server.
2. Set **Provider** to `OpenAI Compatible`, **Base URL** to `http://localhost:1234/v1`, leave **API Key** blank, and set **Model** to the model name shown in LM Studio.
3. Save & Apply.

### Disabling retrieval for faster completions

In the settings panel, expand **Advanced: Retrieval** and toggle **Enable Retrieval** off. This skips the BM25 workspace index and sends only the notebook cell context.

---

## Troubleshooting

**No completions appear**
- Check the health endpoint in the browser: `http://localhost:8888/cellsense/health`
- If using Ollama, confirm it is running: `ollama list` and check that the right port is provided
- Verify the model name in settings exactly matches the tag in Ollama.

**Completions are slow**
- Reduce `max_tokens` (try 64–128).
- Reduce `max_context_tokens` to limit the amount of notebook context sent.
- Enable One Line completions
- Disable retrieval if your workspace is large.

**Tab key doesn't accept**
- Ensure the cell is in edit mode (click inside the cell first).
- Check that JupyterLab's inline completer is enabled: **Settings → Inline Completer → Enable**.

**`jupyter labextension list` doesn't show CellSense**
- Run `pip show jupyterlab-cellsense` to confirm the package is installed in the active environment.
- Ensure you're running `jupyter lab` from the same environment where you ran `pip install`.

**PowerShell script is blocked**
- Run: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` and try again.

---

## Compatibility

| Component | Version |
|-----------|---------|
| JupyterLab | 4.0+ |
| Python | 3.10+ |
| Jupyter Server | 2.x |
| Ollama | Any recent version |

**Supported model families**

| Family | Example models |
|--------|---------------|
| DeepSeek Coder | `deepseek-coder:6.7b`, `deepseek-coder:33b` |
| Codestral | `codestral` |
| CodeLlama | `codellama:7b`, `codellama:13b` |
| StarCoder2 | `starcoder2:3b`, `starcoder2:7b` |
| Qwen2.5-Coder | `qwen2.5-coder:7b` |
| Generic FIM | Any FIM model not listed above |
| OpenAI compatible | `gpt-4o-mini`, vLLM-served models, LM Studio, etc. |

---

## Contributing

Contributions are welcome. Please open an issue before submitting a pull request for significant changes.

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes and open a pull request against `master`

For bug reports and feature requests, use the [issue tracker](https://github.com/arunkarthik11/CellSense/issues).

---

## Inspirations

**[Fill-In-Middle (FIM)](https://arxiv.org/abs/2207.14255)** — Bavarian et al., OpenAI, 2022. The foundational technique CellSense uses to structure every prompt: the model is given a prefix and a suffix and asked to generate the text that belongs in between, rather than simply continuing from the end of a document.

**[StarCoder](https://arxiv.org/abs/2305.06161)** — Li et al., 2023. StarCoder popularised open, openly licensed FIM-capable code models and established the `<fim_prefix>` / `<fim_suffix>` / `<fim_middle>` token conventions that CellSense's prompt templates are built around.

**[JupyterLab](https://github.com/jupyterlab/jupyterlab)** — CellSense is built directly on JupyterLab 4's `IInlineCompletionProvider` API for ghost-text suggestions and the `jupyter_server` extension system for server-side request handling. None of this required patching JupyterLab internals — both are stable, public extension points.

### Related projects

If you are looking for a **chat-based** AI coding assistant for JupyterLab rather than inline completions, [NotebookIntelligence](https://github.com/notebook-intelligence/notebook-intelligence) is an awesome tool. CellSense focuses exclusively on rich context based ghost-text completion; the two tools are complementary.

---

## License

CellSense is licensed under the [GNU General Public License v3.0](LICENSE.md).
