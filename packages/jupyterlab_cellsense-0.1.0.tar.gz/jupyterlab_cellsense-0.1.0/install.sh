#!/usr/bin/env bash
set -euo pipefail

echo "=== CellSense Installer ==="
echo ""

# Check Python 3
if ! command -v python3 &>/dev/null; then
    echo "Error: Python 3 is not installed or not in PATH."
    echo "Install it from https://www.python.org/downloads/"
    exit 1
fi

# Check Python >= 3.10
if ! python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"; then
    python_version=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    echo "Error: Python 3.10 or higher is required (found $python_version)."
    exit 1
fi

echo "Python $(python3 --version) found."

# Check pip
if ! python3 -m pip --version &>/dev/null; then
    echo "Error: pip is not available."
    echo "Install it with: python3 -m ensurepip"
    exit 1
fi

echo "pip found."

# Check JupyterLab
if ! python3 -m pip show jupyterlab &>/dev/null; then
    echo "Error: JupyterLab is not installed."
    echo "Install it with: pip install jupyterlab"
    exit 1
fi

echo "JupyterLab found."
echo ""
echo "Installing CellSense..."
echo ""

python3 -m pip install .

echo ""
echo "CellSense installed successfully."
echo "Start JupyterLab with: jupyter lab"
