"""End-to-end smoke test for the BM25 retrieval pipeline."""
from __future__ import annotations

import json
import os
import shutil

import pytest


CONFIG = {
    "MAX_FILES_TO_INDEX": 1000,
    "MAX_CHUNKS_PER_FILE": 200,
    "TOP_K_CHUNKS": 3,
    "CACHE_INVALIDATE_DISTANCE": 80,
    "RETRIEVED_CONTEXT_TOKEN_BUDGET": 2000,
}


@pytest.fixture()
def workspace(tmp_path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")

    (pkg / "util.py").write_text(
        "DEFAULT_SLUG = 'untitled'\n"
        "MAX_RETRIES = 3\n"
        "TIMEOUT = 30\n"
        "\n"
        "class Helper:\n"
        "    def serialize(self, obj):\n"
        "        return str(obj)\n"
        "\n"
        "    def deserialize(self, s):\n"
        "        return eval(s)\n"
        "\n"
        "def slugify(text):\n"
        "    return text.lower().replace(' ', '-')\n"
    )

    (pkg / "main.py").write_text(
        "def run():\n"
        "    pass\n"
    )

    notebooks = tmp_path / "notebooks"
    notebooks.mkdir()
    nb = {
        "cells": [
            {
                "cell_type": "code",
                "source": "%matplotlib inline\ndef analyze_data(df):\n    return df.describe()\n",
            },
            {
                "cell_type": "markdown",
                "source": "# Header",
            },
            {
                "cell_type": "code",
                "source": (
                    "df = pd.read_csv('data.csv')\n"
                    "df = df.dropna()\n"
                    "df['col'] = df['col'].astype(str)\n"
                    "df['length'] = df['col'].apply(len)\n"
                    "result = df[df['length'] > 5]\n"
                ),
            },
        ],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    (notebooks / "explore.ipynb").write_text(json.dumps(nb))

    (tmp_path / ".gitignore").write_text("secrets/\n")

    secrets = tmp_path / "secrets"
    secrets.mkdir()
    (secrets / "leak.py").write_text("def should_not_be_indexed():\n    pass\n")

    yield tmp_path

    shutil.rmtree(tmp_path, ignore_errors=True)


def _make_config(workspace_root):
    return {**CONFIG, "WORKSPACE_ROOT": str(workspace_root)}


def test_full_pipeline(workspace):
    import cellsense.backend.retrieval.init as rmod

    # Reset module globals
    rmod._index_manager = None
    rmod._retriever = None
    rmod._cursor_cache = None
    rmod._ready = False
    rmod._observer = None

    cfg = _make_config(workspace)
    from cellsense.backend.retrieval.bm25_retriever import BM25Retriever
    from cellsense.backend.retrieval.chunker import walk_workspace
    from cellsense.backend.retrieval.cursor_cache import CursorCache
    from cellsense.backend.retrieval.index_manager import IndexManager

    im = IndexManager(str(workspace))
    im.open()
    rmod._index_manager = im
    rmod.ensure_gitignore(str(workspace))

    retriever = BM25Retriever()
    rmod._retriever = retriever
    rmod._cursor_cache = CursorCache()

    # Build index synchronously
    rebuild_needed, reason = im.needs_rebuild()
    assert rebuild_needed

    chunks = walk_workspace(str(workspace), cfg["MAX_FILES_TO_INDEX"], cfg["MAX_CHUNKS_PER_FILE"])
    im.write_chunks(chunks)
    rows = im.load_all_chunks()
    retriever.build(rows)
    rmod._ready = True

    assert rmod._ready is True

    all_chunks = im.load_all_chunks()
    assert len(all_chunks) >= 5

    full_chunks = im.fetch_by_ids([r[0] for r in all_chunks])
    paths = [c["file_path"] for c in full_chunks]

    # No secrets/ chunks
    assert not any("secrets" in p for p in paths)

    # Method chunks have parent_class='Helper'
    helper_methods = [c for c in full_chunks if c["parent_class"] == "Helper"]
    assert len(helper_methods) >= 2

    # Notebook function chunk is indexed
    notebook_chunks = [c for c in full_chunks if c["file_path"].endswith(".ipynb")]
    assert any("analyze_data" in c["chunk_text"] for c in notebook_chunks)

    # Module-scope globals are indexed (DEFAULT_SLUG = 'untitled' etc.)
    module_scope_chunks = [c for c in full_chunks if c["chunk_type"] == "module_scope"]
    assert len(module_scope_chunks) >= 1
    assert any("DEFAULT_SLUG" in c["chunk_text"] for c in module_scope_chunks)

    # Notebook cell chunk for non-functional code (the df = pd.read_csv(...) cell)
    cell_chunks = [c for c in full_chunks if c["chunk_type"] == "cell"]
    assert len(cell_chunks) >= 1
    assert any("read_csv" in c["chunk_text"] for c in cell_chunks)

    # Query
    result = rmod.get_retrieved_context(
        prefix="def serialize(",
        suffix="",
        config=cfg,
    )
    assert "util.py" in result
    assert "serialize" in result
    assert "In class: Helper" in result

    # Modify util.py — add new method, flush manually
    util_path = str(workspace / "pkg" / "util.py")
    with open(util_path, "a") as f:
        f.write("\n    def transform(self, x):\n        return x\n")

    from cellsense.backend.retrieval.chunker import chunk_file
    new_chunks = chunk_file(util_path, max_chunks=200)
    im.update_files([util_path], new_chunks)
    rows2 = im.load_all_chunks()
    full2 = im.fetch_by_ids([r[0] for r in rows2])
    assert any("transform" in c["chunk_text"] for c in full2)

    # Invalidation sentinel
    sentinel = os.path.join(str(workspace), ".plugin_index", ".invalidate")
    open(sentinel, "w").close()
    rebuild, msg = im.needs_rebuild()
    assert rebuild is True
    assert "external invalidation" in msg
    assert not os.path.exists(sentinel)

    im.close()


def test_gitignore_written(workspace):
    import cellsense.backend.retrieval.init as rmod
    rmod.ensure_gitignore(str(workspace))
    gitignore = workspace / ".gitignore"
    assert ".plugin_index/" in gitignore.read_text()


def test_cursor_cache_overlap():
    from cellsense.backend.retrieval.cursor_cache import CursorCache

    cache = CursorCache()

    # Populate with a serialize-related query
    serialize_query = "def serialize self obj return str obj class Helper method"
    cache.put(serialize_query, [1, 2, 3])

    # Nearly identical query (cursor barely moved — one token added) → cache hit
    nearby_query = "def serialize self obj return str obj class Helper method result"
    assert cache.get(nearby_query) == [1, 2, 3]

    # Completely different query (unrelated code) → cache miss
    unrelated_query = "import pandas read csv dataframe dropna groupby aggregate"
    assert cache.get(unrelated_query) is None

    # Empty query → cache miss
    assert cache.get("") is None
