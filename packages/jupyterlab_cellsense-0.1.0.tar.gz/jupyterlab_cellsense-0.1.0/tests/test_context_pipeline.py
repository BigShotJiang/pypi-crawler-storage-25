"""Task 9 — Backend integration tests for the multi-file context pipeline.

Tests the schema (Task 6), disk reader (Task 7), and assembler (Task 8)
end-to-end without requiring a running Jupyter server.
"""
from __future__ import annotations

import json
import sys
import importlib.util
from pathlib import Path
from typing import Any

import pytest

# ---------------------------------------------------------------------------
# Loader helpers — we load the new modules directly to avoid the pre-existing
# circular import in cellsense/__init__.py.
# ---------------------------------------------------------------------------

ROOT = Path(__file__).parent.parent


def _load(dotted: str, rel: str):
    path = ROOT / rel
    spec = importlib.util.spec_from_file_location(dotted, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[dotted] = m
    spec.loader.exec_module(m)
    return m


schema_mod = _load(
    "cellsense.backend.schemas.completion_request",
    "cellsense/backend/schemas/completion_request.py",
)
CompletionRequest = schema_mod.CompletionRequest
ContextFileEntry = schema_mod.ContextFileEntry
AnchorRange = schema_mod.AnchorRange
parse_context_files_lenient = schema_mod.parse_context_files_lenient

reader_mod = _load(
    "cellsense.backend.context.file_reader",
    "cellsense/backend/context/file_reader.py",
)
read_context_slice = reader_mod.read_context_slice

assembler_mod = _load(
    "cellsense.backend.context.assembler",
    "cellsense/backend/context/assembler.py",
)
assemble_context = assembler_mod.assemble_context
FileContextBlock = assembler_mod.FileContextBlock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_root(tmp_path):
    return tmp_path


@pytest.fixture()
def plain_file(tmp_root):
    p = tmp_root / "sample.py"
    lines = [f"line_{i:03d} = {i}" for i in range(100)]
    p.write_text("\n".join(lines))
    return p


@pytest.fixture()
def notebook_file(tmp_root):
    nb = {
        "nbformat": 4,
        "nbformat_minor": 5,
        "cells": [
            {"cell_type": "code", "source": "# cell 0\nprint('hello')"},
            {"cell_type": "code", "source": "\n".join(f"cell1_line_{i}" for i in range(20))},
            {"cell_type": "code", "source": ["cell2_line_0\n", "cell2_line_1\n", "cell2_line_2"]},
        ],
    }
    p = tmp_root / "notebook.ipynb"
    p.write_text(json.dumps(nb))
    return p


def _make_request(context_files=None, **kwargs) -> CompletionRequest:
    defaults: dict[str, Any] = dict(prefix="x = ", suffix="\n", language="python")
    defaults.update(kwargs)
    if context_files is not None:
        defaults["context_files"] = context_files
    return CompletionRequest(**defaults)


def _disk_entry(path: str, start: int, end: int, kind="file", cell=None, rank=0, signal="viewed"):
    anchor = AnchorRange(start_line=start, end_line=end, cell_index=cell)
    return ContextFileEntry(path=path, kind=kind, signal=signal, recency_rank=rank,
                            anchor=anchor, source="disk")


def _inline_entry(path: str, content: str, start: int, end: int, kind="file",
                  cell=None, rank=0, signal="edited"):
    anchor = AnchorRange(start_line=start, end_line=end, cell_index=cell)
    return ContextFileEntry(path=path, kind=kind, signal=signal, recency_rank=rank,
                            anchor=anchor, source="inline", content=content)


# ===========================================================================
# Task 9 test cases
# ===========================================================================


class TestSchemaValidation:
    """Task 6 acceptance criteria."""

    def test_old_client_no_context_files(self):
        req = _make_request()
        assert req.context_files == []

    def test_valid_entries_accepted(self, plain_file, tmp_root):
        entries = [_disk_entry(str(plain_file.relative_to(tmp_root)), 0, 10)]
        req = _make_request(context_files=entries)
        assert len(req.context_files) == 1

    def test_malformed_entry_skipped(self, tmp_root):
        raw = [
            {"path": "a.py", "kind": "file", "signal": "viewed", "recency_rank": 0,
             "anchor": {"start_line": 0, "end_line": 10}, "source": "disk"},
            {"path": "bad.py", "kind": "file", "signal": "viewed", "recency_rank": 0,
             "anchor": {"start_line": -5, "end_line": 10}, "source": "disk"},  # invalid
            {"path": "b.py", "kind": "file", "signal": "viewed", "recency_rank": 1,
             "anchor": {"start_line": 0, "end_line": 5}, "source": "disk"},
        ]
        entries = parse_context_files_lenient(raw)
        assert len(entries) == 2
        assert all(e.path in ("a.py", "b.py") for e in entries)

    def test_disk_with_content_dropped(self, caplog):
        import logging
        with caplog.at_level(logging.WARNING):
            entry = ContextFileEntry(
                path="f.py", kind="file", signal="viewed", recency_rank=0,
                anchor=AnchorRange(start_line=0, end_line=5),
                source="disk", content="should be ignored"
            )
        assert entry.content is None
        assert "ignoring content" in caplog.text

    def test_inline_requires_content(self):
        with pytest.raises(Exception):
            ContextFileEntry(
                path="f.py", kind="file", signal="edited", recency_rank=0,
                anchor=AnchorRange(start_line=0, end_line=5),
                source="inline"  # no content!
            )


class TestDiskReader:
    """Task 7 acceptance criteria."""

    def test_plain_file_slice(self, plain_file, tmp_root):
        result = read_context_slice(
            str(plain_file.relative_to(tmp_root)), "file", None, 10, 20, tmp_root
        )
        assert result is not None
        lines = result.split("\n")
        assert len(lines) == 11  # 10..20 inclusive
        assert "line_010" in lines[0]
        assert "line_020" in lines[-1]

    def test_notebook_cell_slice(self, notebook_file, tmp_root):
        # cell 1 has 20 lines; read lines 0-10
        result = read_context_slice(
            str(notebook_file.relative_to(tmp_root)), "notebook", 1, 0, 10, tmp_root
        )
        assert result is not None
        assert "cell1_line_0" in result
        assert "cell1_line_10" in result

    def test_notebook_cell_index_none_returns_none(self, notebook_file, tmp_root):
        result = read_context_slice(
            str(notebook_file.relative_to(tmp_root)), "notebook", None, 0, 5, tmp_root
        )
        assert result is None

    def test_missing_file_returns_none(self, tmp_root):
        result = read_context_slice("nonexistent.py", "file", None, 0, 10, tmp_root)
        assert result is None

    def test_path_traversal_rejected(self, tmp_root):
        result = read_context_slice(
            "../../etc/passwd", "file", None, 0, 5, tmp_root
        )
        assert result is None

    def test_large_file_returns_none(self, tmp_root):
        big = tmp_root / "big.py"
        big.write_bytes(b"x" * (3 * 1024 * 1024))  # 3 MB > 2 MB cap
        result = read_context_slice(str(big.relative_to(tmp_root)), "file", None, 0, 5, tmp_root)
        assert result is None

    def test_notebook_out_of_range_cell(self, notebook_file, tmp_root):
        result = read_context_slice(
            str(notebook_file.relative_to(tmp_root)), "notebook", 99, 0, 5, tmp_root
        )
        assert result is None

    def test_notebook_list_source(self, notebook_file, tmp_root):
        # cell 2 uses list-of-strings format
        result = read_context_slice(
            str(notebook_file.relative_to(tmp_root)), "notebook", 2, 0, 2, tmp_root
        )
        assert result is not None
        assert "cell2_line_0" in result


class TestAssembler:
    """Task 8 acceptance criteria."""

    def test_old_client_no_context_files(self, tmp_root):
        req = _make_request()
        ctx = assemble_context(req, tmp_root)
        assert ctx.file_context_blocks == []
        assert ctx.dropped_files == []

    def test_inline_dirty_file(self, tmp_root):
        content = "def foo():\n    pass\n"
        req = _make_request(context_files=[
            _inline_entry("dirty.py", content, 0, 1)
        ])
        ctx = assemble_context(req, tmp_root)
        assert len(ctx.file_context_blocks) == 1
        assert ctx.file_context_blocks[0].text == content

    def test_disk_read_clean_file(self, plain_file, tmp_root):
        req = _make_request(context_files=[
            _disk_entry(str(plain_file.relative_to(tmp_root)), 0, 5)
        ])
        ctx = assemble_context(req, tmp_root)
        assert len(ctx.file_context_blocks) == 1
        assert "line_000" in ctx.file_context_blocks[0].text

    def test_edited_before_viewed(self, tmp_root):
        viewed = _inline_entry("viewed.py", "a" * 100, 0, 10, signal="viewed", rank=0)
        edited = _inline_entry("edited.py", "b" * 100, 0, 10, signal="edited", rank=2)
        req = _make_request(context_files=[viewed, edited])
        ctx = assemble_context(req, tmp_root)
        assert len(ctx.file_context_blocks) == 2
        assert ctx.file_context_blocks[0].signal == "edited"
        assert ctx.file_context_blocks[1].signal == "viewed"

    def test_budget_drops_low_priority(self, tmp_root):
        budget = 5000
        chunk = "x" * 2000  # per-file cap = 40% * 5000 = 2000 chars
        entries = [
            _inline_entry(f"f{i}.py", chunk, 0, 10, signal="viewed", rank=i)
            for i in range(5)
        ]
        req = _make_request(context_files=entries)
        ctx = assemble_context(req, tmp_root, char_budget=budget)
        # f0: 2000 chars used, remaining 3000
        # f1: 2000 chars used, remaining 1000
        # f2: truncated to 1000 chars, remaining 0
        # f3, f4: dropped
        used = len(ctx.file_context_blocks)
        dropped = len(ctx.dropped_files)
        assert used + dropped == 5
        assert used <= 3   # at most 3 files fit (last one truncated)
        assert dropped >= 2

    def test_truncation_keeps_tail(self, tmp_root):
        # Content that exceeds remaining budget should be tail-truncated
        content = "START\n" + "middle\n" * 1000 + "END"
        budget = 100
        entries = [_inline_entry("big.py", content, 0, 1000)]
        req = _make_request(context_files=entries)
        ctx = assemble_context(req, tmp_root, char_budget=budget)
        assert len(ctx.file_context_blocks) == 1
        block = ctx.file_context_blocks[0]
        assert len(block.text) <= budget
        assert "END" in block.text  # tail preserved
        assert "START" not in block.text

    def test_path_traversal_rejected(self, tmp_root):
        entry = _disk_entry("../../etc/passwd", 0, 5)
        req = _make_request(context_files=[entry])
        ctx = assemble_context(req, tmp_root)
        assert ctx.file_context_blocks == []
        assert "../../etc/passwd" in ctx.dropped_files

    def test_notebook_cell_slice(self, notebook_file, tmp_root):
        entry = _disk_entry(
            str(notebook_file.relative_to(tmp_root)),
            start=0, end=5, kind="notebook", cell=1
        )
        req = _make_request(context_files=[entry])
        ctx = assemble_context(req, tmp_root)
        assert len(ctx.file_context_blocks) == 1
        assert "cell1_line_0" in ctx.file_context_blocks[0].text

    def test_disk_failure_does_not_break_request(self, tmp_root):
        good = _inline_entry("good.py", "good content", 0, 5)
        bad = _disk_entry("nonexistent.py", 0, 10)
        req = _make_request(context_files=[good, bad])
        ctx = assemble_context(req, tmp_root)
        assert len(ctx.file_context_blocks) == 1
        assert ctx.file_context_blocks[0].path == "good.py"
        assert "nonexistent.py" in ctx.dropped_files

    def test_five_small_files_all_included(self, tmp_root):
        entries = [
            _inline_entry(f"f{i}.py", "x" * 500, 0, 10, signal="viewed", rank=i)
            for i in range(5)
        ]
        req = _make_request(context_files=entries)
        ctx = assemble_context(req, tmp_root, char_budget=24_000)
        assert len(ctx.file_context_blocks) == 5
        assert ctx.dropped_files == []
