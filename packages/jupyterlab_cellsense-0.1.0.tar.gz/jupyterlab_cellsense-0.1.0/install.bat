@echo off
setlocal enabledelayedexpansion

echo === CellSense Installer ===
echo.

:: Check Python
where python >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH.
    echo Install it from https://www.python.org/downloads/
    exit /b 1
)

:: Check Python >= 3.10
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 (
    for /f "tokens=*" %%v in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"') do set pyver=%%v
    echo Error: Python 3.10 or higher is required ^(found !pyver!^).
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version') do echo %%v found.

:: Check pip
python -m pip --version >nul 2>&1
if errorlevel 1 (
    echo Error: pip is not available.
    echo Install it with: python -m ensurepip
    exit /b 1
)

echo pip found.

:: Check JupyterLab
python -m pip show jupyterlab >nul 2>&1
if errorlevel 1 (
    echo Error: JupyterLab is not installed.
    echo Install it with: pip install jupyterlab
    exit /b 1
)

echo JupyterLab found.
echo.
echo Installing CellSense...
echo.

python -m pip install .
if errorlevel 1 (
    echo.
    echo Error: Installation failed.
    exit /b 1
)

echo.
echo CellSense installed successfully.
echo Start JupyterLab with: jupyter lab

endlocal
