from cellsense._version import __version__
from cellsense.backend.extension import CellSenseApp


def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "jupyterlab-cellsense"}]


def _jupyter_server_extension_points():
    return [{"module": "cellsense.backend.extension", "app": CellSenseApp}]


def _jupyter_server_extension_paths():
    return _jupyter_server_extension_points()


__all__ = [
    "__version__",
    "_jupyter_labextension_paths",
    "_jupyter_server_extension_points",
]
