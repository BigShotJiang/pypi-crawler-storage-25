"use strict";
(self["webpackChunkjupyterlab_cellsense"] = self["webpackChunkjupyterlab_cellsense"] || []).push([["lib_index_js"],{

/***/ "./lib/client.js"
/*!***********************!*\
  !*** ./lib/client.js ***!
  \***********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchCompletion: () => (/* binding */ fetchCompletion),
/* harmony export */   fetchHealth: () => (/* binding */ fetchHealth),
/* harmony export */   postConfig: () => (/* binding */ postConfig)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


const NAMESPACE = 'cellsense';
async function _request(endpoint, init = {}) {
    var _a, _b;
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, NAMESPACE, endpoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(url, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    const text = await response.text();
    let data;
    try {
        data = JSON.parse(text);
    }
    catch (_c) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, text);
    }
    if (!response.ok) {
        const d = data;
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, (_b = (_a = d === null || d === void 0 ? void 0 : d.message) !== null && _a !== void 0 ? _a : d === null || d === void 0 ? void 0 : d.error) !== null && _b !== void 0 ? _b : text);
    }
    return data;
}
async function fetchCompletion(req) {
    return _request('complete', {
        method: 'POST',
        body: JSON.stringify(req),
        headers: { 'Content-Type': 'application/json' }
    });
}
async function fetchHealth() {
    return _request('health');
}
async function postConfig(req) {
    await _request('config', {
        method: 'POST',
        body: JSON.stringify(req),
        headers: { 'Content-Type': 'application/json' }
    });
}


/***/ },

/***/ "./lib/completion/ContextRequestBuilder.js"
/*!*************************************************!*\
  !*** ./lib/completion/ContextRequestBuilder.js ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildContextFiles: () => (/* binding */ buildContextFiles)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tracker_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../tracker/types */ "./lib/tracker/types.js");



function sliceLines(text, startLine, endLine) {
    const lines = text.split('\n');
    return lines.slice(startLine, endLine + 1).join('\n');
}
function buildContextFiles(tracker, activeFilePath, docManager, options) {
    var _a, _b, _c, _d, _e;
    try {
        const maxFiles = (_a = options === null || options === void 0 ? void 0 : options.maxFiles) !== null && _a !== void 0 ? _a : _tracker_types__WEBPACK_IMPORTED_MODULE_2__.MAX_CONTEXT_FILES_SENT;
        const halfSlice = Math.floor(((_b = options === null || options === void 0 ? void 0 : options.sliceLines) !== null && _b !== void 0 ? _b : _tracker_types__WEBPACK_IMPORTED_MODULE_2__.DEFAULT_SLICE_LINES) / 2);
        const now = Date.now();
        const tenMinutesAgo = now - 10 * 60 * 1000;
        const ranked = tracker.getRanked(maxFiles + 1);
        const candidates = ranked.filter(fc => fc.path !== activeFilePath);
        const result = [];
        for (let i = 0; i < Math.min(candidates.length, maxFiles); i++) {
            const fc = candidates[i];
            const signal = fc.lastEditedAt && fc.lastEditedAt > tenMinutesAgo ? 'edited' : 'viewed';
            // Pick anchor range
            let anchorStart;
            let anchorEnd;
            let cellIndex = null;
            if (signal === 'edited' && fc.lastEditRange) {
                anchorStart = fc.lastEditRange.startLine;
                anchorEnd = fc.lastEditRange.endLine;
                cellIndex = (_c = fc.lastEditRange.cellIndex) !== null && _c !== void 0 ? _c : null;
            }
            else if (fc.lastViewportRange) {
                anchorStart = fc.lastViewportRange.startLine;
                anchorEnd = fc.lastViewportRange.endLine;
                cellIndex = (_d = fc.lastViewportRange.cellIndex) !== null && _d !== void 0 ? _d : null;
            }
            else if (fc.lastCursor) {
                anchorStart = fc.lastCursor.line;
                anchorEnd = fc.lastCursor.line;
                cellIndex = (_e = fc.lastCursor.cellIndex) !== null && _e !== void 0 ? _e : null;
            }
            else {
                continue;
            }
            // Expand to DEFAULT_SLICE_LINES centered on midpoint
            const mid = Math.floor((anchorStart + anchorEnd) / 2);
            const expandedStart = Math.max(0, mid - halfSlice);
            const expandedEnd = mid + halfSlice;
            // Determine source
            const isDirtyInline = fc.isDirty && fc.isOpen;
            let content;
            if (isDirtyInline) {
                try {
                    const widget = docManager.findWidget(fc.path);
                    if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel) {
                        const idx = cellIndex !== null && cellIndex !== void 0 ? cellIndex : 0;
                        const cell = widget.content.widgets[idx];
                        if (cell) {
                            content = sliceLines(cell.model.sharedModel.getSource(), expandedStart, expandedEnd);
                        }
                    }
                    else if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditorWidget) {
                        const src = widget.context.model.sharedModel.getSource();
                        content = sliceLines(src, expandedStart, expandedEnd);
                    }
                }
                catch (_f) {
                    // Fall back to disk if inline read fails
                }
            }
            result.push({
                path: fc.path,
                kind: fc.kind,
                signal,
                recency_rank: i,
                anchor: {
                    cell_index: cellIndex,
                    start_line: expandedStart,
                    end_line: expandedEnd
                },
                source: content !== undefined ? 'inline' : 'disk',
                ...(content !== undefined ? { content } : {})
            });
        }
        return result;
    }
    catch (err) {
        console.warn('[CellSense] buildContextFiles error:', err);
        return [];
    }
}


/***/ },

/***/ "./lib/context.js"
/*!************************!*\
  !*** ./lib/context.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assembleContext: () => (/* binding */ assembleContext)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _import_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./import_state */ "./lib/import_state.js");



// 1 token ≈ 4 chars for code. Rough heuristic avoids a 600KB tiktoken WASM dep.
function estimateTokens(text) {
    return Math.ceil(text.length / 4);
}
function markdownToComment(source) {
    return source
        .split('\n')
        .map(line => `# ${line}`)
        .join('\n');
}
function detectLanguage(context) {
    var _a, _b, _c, _d, _e, _f, _g;
    if (context.widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel) {
        const np = context.widget;
        return (_c = (_b = (_a = np.sessionContext) === null || _a === void 0 ? void 0 : _a.kernelPreference) === null || _b === void 0 ? void 0 : _b.language) !== null && _c !== void 0 ? _c : 'python';
    }
    if (context.widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditorWidget) {
        const fe = context.widget;
        const mime = (_e = (_d = fe.content.model) === null || _d === void 0 ? void 0 : _d.mimeType) !== null && _e !== void 0 ? _e : '';
        if (mime.includes('python'))
            return 'python';
        if (mime.includes('typescript'))
            return 'typescript';
        if (mime.includes('javascript'))
            return 'javascript';
        const path = (_g = (_f = fe.context) === null || _f === void 0 ? void 0 : _f.path) !== null && _g !== void 0 ? _g : '';
        if (path.endsWith('.py'))
            return 'python';
        if (path.endsWith('.ts') || path.endsWith('.tsx'))
            return 'typescript';
        if (path.endsWith('.js') || path.endsWith('.jsx'))
            return 'javascript';
    }
    return 'python';
}
function assembleContext(request, context, maxTokens) {
    var _a, _b;
    const language = detectLanguage(context);
    // File editor: request.text is the full document — scan it for import state
    if (!(context.widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel)) {
        const fe = context.widget;
        const sm = new _import_state__WEBPACK_IMPORTED_MODULE_2__.ImportStateMachine();
        sm.parseContent(request.text);
        return {
            prefix: request.text.substring(0, request.offset),
            suffix: request.text.substring(request.offset),
            language,
            importPhaseComplete: sm.importPhaseComplete,
            imports: sm.imports,
            file_path: (_b = (_a = fe.context) === null || _a === void 0 ? void 0 : _a.path) !== null && _b !== void 0 ? _b : ''
        };
    }
    // Notebook: scan each cell with its own state machine (so incomplete multi-line
    // imports in one cell don't bleed into the next), but carry importPhaseComplete
    // forward so that once a code line has been seen, all subsequent cells collect
    // imports from every line rather than waiting for another code line.
    const np = context.widget;
    const allImports = [];
    let importPhaseComplete = false;
    for (const cell of np.content.widgets) {
        const model = cell.model.sharedModel;
        if (model.cell_type === 'code') {
            const cellSm = new _import_state__WEBPACK_IMPORTED_MODULE_2__.ImportStateMachine();
            cellSm.parseContent(model.source);
            for (const imp of cellSm.imports)
                allImports.push(imp);
            if (cellSm.importPhaseComplete)
                importPhaseComplete = true;
        }
    }
    const activeCell = np.content.activeCell;
    if (!activeCell) {
        return {
            prefix: request.text.substring(0, request.offset),
            suffix: request.text.substring(request.offset),
            language,
            importPhaseComplete,
            imports: allImports,
            file_path: np.context.path
        };
    }
    // request.text is the active cell's source; request.offset is cursor position within it
    let prefix = request.text.substring(0, request.offset);
    let suffix = request.text.substring(request.offset);
    const activeCellIndex = np.content.activeCellIndex;
    const numCells = np.content.widgets.length;
    for (let d = 1; d < numCells; d++) {
        if (estimateTokens(prefix + suffix) >= maxTokens)
            break;
        const aboveIdx = activeCellIndex - d;
        const belowIdx = activeCellIndex + d;
        if (aboveIdx < 0 && belowIdx >= numCells)
            break;
        if (aboveIdx >= 0) {
            const model = np.content.widgets[aboveIdx].model.sharedModel;
            let src = null;
            if (model.cell_type === 'code')
                src = model.source;
            else if (model.cell_type === 'markdown')
                src = markdownToComment(model.source);
            if (src)
                prefix = src + '\n' + prefix;
        }
        if (belowIdx < numCells) {
            const model = np.content.widgets[belowIdx].model.sharedModel;
            let src = null;
            if (model.cell_type === 'code')
                src = model.source;
            else if (model.cell_type === 'markdown')
                src = markdownToComment(model.source);
            if (src)
                suffix = suffix + '\n' + src;
        }
    }
    return {
        prefix,
        suffix,
        language,
        importPhaseComplete,
        imports: allImports,
        file_path: np.context.path
    };
}


/***/ },

/***/ "./lib/import_state.js"
/*!*****************************!*\
  !*** ./lib/import_state.js ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ImportStateMachine: () => (/* binding */ ImportStateMachine)
/* harmony export */ });
class ImportStateMachine {
    constructor() {
        this.inImport = false;
        this.parenDepth = 0;
        this.importPhaseComplete = false;
        this.imports = [];
        this._pendingLines = [];
    }
    processLine(line) {
        const trimmed = line.trim();
        if (this.inImport) {
            this._pendingLines.push(line);
            for (const ch of line) {
                if (ch === '(')
                    this.parenDepth++;
                else if (ch === ')')
                    this.parenDepth--;
            }
            const stripped = line.trimEnd();
            if (this.parenDepth <= 0 && !stripped.endsWith('\\')) {
                this.inImport = false;
                this.parenDepth = 0;
                this.imports.push(this._pendingLines.join('\n'));
                this._pendingLines = [];
            }
            return;
        }
        if (trimmed === '' || trimmed.startsWith('#'))
            return;
        if (trimmed.startsWith('import ') || trimmed.startsWith('from ')) {
            this.inImport = true;
            this._pendingLines = [line];
            for (const ch of line) {
                if (ch === '(')
                    this.parenDepth++;
                else if (ch === ')')
                    this.parenDepth--;
            }
            const stripped = line.trimEnd();
            if (this.parenDepth <= 0 && !stripped.endsWith('\\')) {
                this.inImport = false;
                this.parenDepth = 0;
                this.imports.push(this._pendingLines.join('\n'));
                this._pendingLines = [];
            }
            return;
        }
        // Non-empty, non-comment, non-import line — trigger the phase, but keep
        // scanning so imports that appear later in the same cell are still collected.
        this.importPhaseComplete = true;
    }
    parseContent(content) {
        for (const line of content.split('\n')) {
            this.processLine(line);
        }
    }
}


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/completer */ "webpack/sharing/consume/default/@jupyterlab/completer");
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./provider */ "./lib/provider.js");
/* harmony import */ var _settings_widget__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./settings_widget */ "./lib/settings_widget.js");
/* harmony import */ var _client__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./client */ "./lib/client.js");
/* harmony import */ var _tracker_FileTracker__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./tracker/FileTracker */ "./lib/tracker/FileTracker.js");
/* harmony import */ var _tracker_token__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./tracker/token */ "./lib/tracker/token.js");













const PLUGIN_ID = 'jupyterlab-cellsense:plugin';
// JupyterLab inline-completer icon with a 4-point AI sparkle at top-right
const cellSenseIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'jupyterlab-cellsense:icon',
    svgstr: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-icon="completer:inline">
    <g transform="translate(0, 4) scale(0.75)">
      <path class="jp-icon4" fill="#bbbbbb" d="M17 15H3v2h14v-2Zm0-8h-6v2h6V7ZM3 13h18v-2H3v2Zm0 8h18v-2H3v2Z"/>
      <path class="jp-icon1" fill="#616161" d="M3 3v2h18V3H3ZM3 7v2h8V7H3Z"/>
    </g>
    <path class="jp-icon1" fill="#616161" d="M19.5 2.25L20.25 4.5L22.5 5.25L20.25 6L19.5 8.25L18.75 6L16.5 5.25L18.75 4.5Z"/>
  </svg>`,
});
const trackerPlugin = {
    id: 'jupyterlab-cellsense:file-tracker',
    autoStart: true,
    requires: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_6__.INotebookTracker, _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_5__.IEditorTracker],
    provides: _tracker_token__WEBPACK_IMPORTED_MODULE_12__.IFileTracker,
    activate: (_app, labShell, notebookTracker, editorTracker) => {
        return new _tracker_FileTracker__WEBPACK_IMPORTED_MODULE_11__.FileTracker({ labShell, notebookTracker, editorTracker });
    }
};
const plugin = {
    id: PLUGIN_ID,
    description: 'FIM ghost-text inline completion for JupyterLab',
    autoStart: true,
    requires: [_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__.ICompletionProviderManager, _tracker_token__WEBPACK_IMPORTED_MODULE_12__.IFileTracker, _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_4__.IDocumentManager],
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_7__.ISettingRegistry, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, completionManager, fileTracker, docManager, settingRegistry, palette) => {
        const provider = new _provider__WEBPACK_IMPORTED_MODULE_8__.CellSenseProvider(fileTracker, docManager);
        completionManager.registerInlineProvider(provider);
        if (!settingRegistry)
            return;
        settingRegistry
            .load(PLUGIN_ID)
            .then(settings => {
            const apply = () => {
                var _a, _b;
                const c = settings.get('completion').composite;
                provider.updateSettings((_a = c === null || c === void 0 ? void 0 : c.debounce_ms) !== null && _a !== void 0 ? _a : 500, (_b = c === null || c === void 0 ? void 0 : c.max_context_tokens) !== null && _b !== void 0 ? _b : 1500);
                applyProviderConfig(settings);
            };
            apply();
            settings.changed.connect(apply);
            const sidebar = new _settings_widget__WEBPACK_IMPORTED_MODULE_9__.CellSenseSettingsSidebarWidget(settings);
            sidebar.id = 'jupyterlab-cellsense-settings-sidebar';
            sidebar.title.icon = cellSenseIcon;
            app.shell.add(sidebar, 'left', { rank: 600 });
            app.commands.addCommand('jupyterlab-cellsense:open-settings', {
                label: 'CellSense Settings',
                execute: () => {
                    const widget = new _settings_widget__WEBPACK_IMPORTED_MODULE_9__.CellSenseSettingsWidget(settings);
                    const main = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content: widget });
                    app.shell.add(main, 'main');
                    app.shell.activateById(main.id);
                }
            });
            if (palette) {
                palette.addItem({
                    command: 'jupyterlab-cellsense:open-settings',
                    category: 'CellSense'
                });
            }
        })
            .catch(reason => {
            console.error('[CellSense] Failed to load settings:', reason);
        });
    }
};
function applyProviderConfig(settings) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    const providerType = (_a = settings.get('provider').composite) !== null && _a !== void 0 ? _a : 'ollama';
    let base_url;
    let api_key;
    let model;
    let model_family;
    if (providerType === 'openai_compatible') {
        const s = settings.get('openai_compatible').composite;
        base_url = (_b = s === null || s === void 0 ? void 0 : s.base_url) !== null && _b !== void 0 ? _b : 'https://api.openai.com/v1';
        api_key = (_c = s === null || s === void 0 ? void 0 : s.api_key) !== null && _c !== void 0 ? _c : '';
        model = (_d = s === null || s === void 0 ? void 0 : s.model) !== null && _d !== void 0 ? _d : 'gpt-4o-mini';
        model_family = 'other';
    }
    else {
        const s = settings.get('ollama').composite;
        base_url = (_e = s === null || s === void 0 ? void 0 : s.base_url) !== null && _e !== void 0 ? _e : 'http://localhost:11434';
        model_family = (_f = s === null || s === void 0 ? void 0 : s.model_family) !== null && _f !== void 0 ? _f : 'deepseek-coder';
        model = (_g = s === null || s === void 0 ? void 0 : s.model) !== null && _g !== void 0 ? _g : 'deepseek-coder:6.7b';
        api_key = '';
    }
    const completion = settings.get('completion').composite;
    const retrieval = settings.get('retrieval').composite;
    (0,_client__WEBPACK_IMPORTED_MODULE_10__.postConfig)({
        provider_type: providerType,
        base_url,
        api_key,
        model,
        model_family,
        max_tokens: (_h = completion === null || completion === void 0 ? void 0 : completion.max_tokens) !== null && _h !== void 0 ? _h : 256,
        one_line_completions: (_j = completion === null || completion === void 0 ? void 0 : completion.one_line_completions) !== null && _j !== void 0 ? _j : false,
        retrieval_enabled: (_k = retrieval === null || retrieval === void 0 ? void 0 : retrieval.enabled) !== null && _k !== void 0 ? _k : true,
        retrieval_top_k: (_l = retrieval === null || retrieval === void 0 ? void 0 : retrieval.top_k) !== null && _l !== void 0 ? _l : 3,
        retrieval_token_budget: (_m = retrieval === null || retrieval === void 0 ? void 0 : retrieval.token_budget) !== null && _m !== void 0 ? _m : 2000,
    }).catch(reason => console.warn('[CellSense] Failed to push provider config:', reason));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([trackerPlugin, plugin]);


/***/ },

/***/ "./lib/provider.js"
/*!*************************!*\
  !*** ./lib/provider.js ***!
  \*************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CellSenseProvider: () => (/* binding */ CellSenseProvider)
/* harmony export */ });
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./context */ "./lib/context.js");
/* harmony import */ var _client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./client */ "./lib/client.js");
/* harmony import */ var _completion_ContextRequestBuilder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./completion/ContextRequestBuilder */ "./lib/completion/ContextRequestBuilder.js");



class CellSenseProvider {
    constructor(fileTracker, docManager) {
        this.name = 'CellSense';
        this.identifier = 'jupyterlab-cellsense';
        this._debouncerDelay = 500;
        this._maxContextTokens = 1500;
        this._fileTracker = fileTracker;
        this._docManager = docManager;
    }
    // JupyterLab reads this once at registerInlineProvider() time.
    // debouncerDelay: built-in debounce duration. timeout: fetch deadline.
    get schema() {
        return {
            default: {
                debouncerDelay: this._debouncerDelay,
                timeout: 10000
            }
        };
    }
    updateSettings(debounceMs, maxContextTokens) {
        this._debouncerDelay = debounceMs;
        this._maxContextTokens = maxContextTokens;
    }
    async fetch(request, context) {
        var _a;
        const empty = { items: [] };
        const assembled = (0,_context__WEBPACK_IMPORTED_MODULE_0__.assembleContext)(request, context, this._maxContextTokens);
        if (!assembled.prefix && !assembled.suffix)
            return empty;
        const contextFiles = (0,_completion_ContextRequestBuilder__WEBPACK_IMPORTED_MODULE_2__.buildContextFiles)(this._fileTracker, assembled.file_path, this._docManager);
        let response;
        try {
            response = await (0,_client__WEBPACK_IMPORTED_MODULE_1__.fetchCompletion)({
                prefix: assembled.prefix,
                suffix: assembled.suffix,
                language: assembled.language,
                ...(assembled.importPhaseComplete
                    ? { imports: assembled.imports, file_path: assembled.file_path }
                    : {}),
                ...(contextFiles.length > 0 ? { context_files: contextFiles } : {})
            });
        }
        catch (error) {
            // Silent failure — ghost text simply does not appear on backend errors
            console.warn('[CellSense] fetch error:', error);
            return empty;
        }
        const completion = (_a = response.completion) === null || _a === void 0 ? void 0 : _a.trim();
        if (!completion)
            return empty;
        return { items: [{ insertText: completion }] };
    }
}


/***/ },

/***/ "./lib/settings_widget.js"
/*!********************************!*\
  !*** ./lib/settings_widget.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CellSenseSettingsSidebarWidget: () => (/* binding */ CellSenseSettingsSidebarWidget),
/* harmony export */   CellSenseSettingsWidget: () => (/* binding */ CellSenseSettingsWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);


const MODEL_DEFAULTS = {
    'deepseek-coder': 'deepseek-coder:6.7b',
    'codestral': 'codestral:22b-v0.1',
    'codellama': 'codellama:7b-code',
    'starcoder2': 'starcoder2:3b',
    'qwen2.5-coder': 'qwen2.5-coder:7b',
    'other': '',
};
function readOllama(settings) {
    var _a, _b, _c;
    const s = settings.get('ollama').composite;
    return {
        base_url: (_a = s === null || s === void 0 ? void 0 : s.base_url) !== null && _a !== void 0 ? _a : 'http://localhost:11434',
        model_family: (_b = s === null || s === void 0 ? void 0 : s.model_family) !== null && _b !== void 0 ? _b : 'deepseek-coder',
        model: (_c = s === null || s === void 0 ? void 0 : s.model) !== null && _c !== void 0 ? _c : 'deepseek-coder:6.7b',
    };
}
function readOpenAI(settings) {
    var _a, _b, _c;
    const s = settings.get('openai_compatible').composite;
    return {
        base_url: (_a = s === null || s === void 0 ? void 0 : s.base_url) !== null && _a !== void 0 ? _a : 'https://api.openai.com/v1',
        api_key: (_b = s === null || s === void 0 ? void 0 : s.api_key) !== null && _b !== void 0 ? _b : '',
        model: (_c = s === null || s === void 0 ? void 0 : s.model) !== null && _c !== void 0 ? _c : 'gpt-4o-mini',
    };
}
function readCompletion(settings) {
    var _a, _b, _c, _d;
    const s = settings.get('completion').composite;
    return {
        debounce_ms: (_a = s === null || s === void 0 ? void 0 : s.debounce_ms) !== null && _a !== void 0 ? _a : 500,
        max_context_tokens: (_b = s === null || s === void 0 ? void 0 : s.max_context_tokens) !== null && _b !== void 0 ? _b : 1500,
        max_tokens: (_c = s === null || s === void 0 ? void 0 : s.max_tokens) !== null && _c !== void 0 ? _c : 256,
        one_line_completions: (_d = s === null || s === void 0 ? void 0 : s.one_line_completions) !== null && _d !== void 0 ? _d : false,
    };
}
function readRetrieval(settings) {
    var _a, _b, _c;
    const s = settings.get('retrieval').composite;
    return {
        enabled: (_a = s === null || s === void 0 ? void 0 : s.enabled) !== null && _a !== void 0 ? _a : true,
        top_k: (_b = s === null || s === void 0 ? void 0 : s.top_k) !== null && _b !== void 0 ? _b : 3,
        token_budget: (_c = s === null || s === void 0 ? void 0 : s.token_budget) !== null && _c !== void 0 ? _c : 2000,
    };
}
function SettingsForm({ settings, }) {
    const [provider, setProvider] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => { var _a; return (_a = settings.get('provider').composite) !== null && _a !== void 0 ? _a : 'ollama'; });
    const [ollama, setOllama] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => readOllama(settings));
    const [openai, setOpenai] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => readOpenAI(settings));
    const [completion, setCompletion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => readCompletion(settings));
    const [retrieval, setRetrieval] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => readRetrieval(settings));
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('idle');
    const [basicOpen, setBasicOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [advancedOpen, setAdvancedOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [completionOpen, setCompletionOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [retrievalOpen, setRetrievalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleFamilyChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((family) => {
        setOllama(prev => {
            var _a;
            return ({
                ...prev,
                model_family: family,
                model: (_a = MODEL_DEFAULTS[family]) !== null && _a !== void 0 ? _a : prev.model,
            });
        });
    }, []);
    const handleSave = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        setStatus('saving');
        try {
            await settings.set('provider', provider);
            await settings.set('ollama', ollama);
            await settings.set('openai_compatible', openai);
            await settings.set('completion', completion);
            await settings.set('retrieval', retrieval);
            setStatus('saved');
            setTimeout(() => setStatus('idle'), 2000);
        }
        catch (_a) {
            setStatus('error');
        }
    }, [settings, provider, ollama, openai, completion, retrieval]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jc-Settings-collapsibleHeader", onClick: () => setBasicOpen(o => !o), "aria-expanded": basicOpen },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-collapsibleTitle" }, "Basic Settings"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jc-Settings-chevron${basicOpen ? ' jc-Settings-chevron--open' : ''}` }, "\u25B6")),
            basicOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Provider"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Choose your Provider. Set Ollama for Local Completions"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jc-Settings-select", value: provider, onChange: e => setProvider(e.target.value) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "ollama" }, "Ollama"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "openai_compatible" }, "OpenAI Compatible"))),
                provider === 'ollama' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Base URL"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Address of your Ollama server"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", value: ollama.base_url, onChange: e => setOllama({ ...ollama, base_url: e.target.value }) })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Model Family"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Choose the closest Model family"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jc-Settings-select", value: ollama.model_family, onChange: e => handleFamilyChange(e.target.value) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "deepseek-coder" }, "DeepSeek Coder"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "codestral" }, "Codestral"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "codellama" }, "CodeLlama"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "starcoder2" }, "StarCoder2"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "qwen2.5-coder" }, "Qwen2.5-Coder"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "other" }, "Other (generic FIM)"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Model Tag"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" },
                            "Full Ollama model tag as shown by ",
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", null, "ollama list"),
                            ", e.g. deepseek-coder:6.7b."),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", value: ollama.model, onChange: e => setOllama({ ...ollama, model: e.target.value }) })))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Base URL"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "API endpoint"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", value: openai.base_url, onChange: e => setOpenai({ ...openai, base_url: e.target.value }) })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "API Key"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Your provider's secret key. Leave blank for local servers that don't require one."),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "password", value: openai.api_key, onChange: e => setOpenai({ ...openai, api_key: e.target.value }) })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Model Name"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Model identifier sent with each request, e.g. gpt-4o-mini or deepseek-coder-v2."),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", value: openai.model, onChange: e => setOpenai({ ...openai, model: e.target.value }) }))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jc-Settings-collapsibleHeader", onClick: () => setAdvancedOpen(o => !o), "aria-expanded": advancedOpen },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-collapsibleTitle" }, "Advanced Settings"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jc-Settings-chevron${advancedOpen ? ' jc-Settings-chevron--open' : ''}` }, "\u25B6")),
            advancedOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-collapsibleBody" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jc-Settings-collapsibleHeader", onClick: () => setCompletionOpen(o => !o), "aria-expanded": completionOpen },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-collapsibleTitle" }, "Completion"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jc-Settings-chevron${completionOpen ? ' jc-Settings-chevron--open' : ''}` }, "\u25B6")),
                    completionOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Debounce (ms)"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "How long to wait after you stop typing before requesting a completion. Raise this if suggestions feel too eager."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "number", min: 0, value: completion.debounce_ms, onChange: e => setCompletion({ ...completion, debounce_ms: Math.max(0, parseInt(e.target.value) || 0) }) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Max Context Tokens (from the current file)"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Cells above and below the cursor are included until this token budget is spent."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "number", min: 256, value: completion.max_context_tokens, onChange: e => setCompletion({ ...completion, max_context_tokens: Math.max(256, parseInt(e.target.value) || 256) }) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-toggleRow" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-checkbox", type: "checkbox", checked: completion.one_line_completions, onChange: e => setCompletion({ ...completion, one_line_completions: e.target.checked }) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-toggleLabel" }, "One line completions")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Limit completions to a single line. Useful for inline suggestions that should not span multiple lines.")),
                        !completion.one_line_completions && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Max output tokens"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Longest completion the model can return. Lower values are faster; raise if suggestions cut off."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "number", min: 32, value: completion.max_tokens, onChange: e => setCompletion({ ...completion, max_tokens: Math.max(32, parseInt(e.target.value) || 32) }) })))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jc-Settings-collapsibleHeader", onClick: () => setRetrievalOpen(o => !o), "aria-expanded": retrievalOpen },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-collapsibleTitle" }, "Retrieval"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jc-Settings-chevron${retrievalOpen ? ' jc-Settings-chevron--open' : ''}` }, "\u25B6")),
                    retrievalOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-toggleRow" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-checkbox", type: "checkbox", checked: retrieval.enabled, onChange: e => setRetrieval({ ...retrieval, enabled: e.target.checked }) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-toggleLabel" }, "Enable RAG")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Disable this for faster completions and reduced token usage")),
                        retrieval.enabled && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Top-K chunks"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "How many code snippets are retrieved from your workspace files."),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "number", min: 1, max: 20, value: retrieval.top_k, onChange: e => setRetrieval({ ...retrieval, top_k: Math.min(20, Math.max(1, parseInt(e.target.value) || 1)) }) })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jc-Settings-label" }, "Context token budget"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jc-Settings-hint" }, "Token budget for retrieved snippets. Reduce if completions feel slow on large workspaces."),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "jc-Settings-input", type: "number", min: 256, value: retrieval.token_budget, onChange: e => setRetrieval({ ...retrieval, token_budget: Math.max(256, parseInt(e.target.value) || 256) }) })))))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jc-Settings-footer" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jc-Settings-saveBtn", disabled: status === 'saving', onClick: handleSave }, status === 'saving' ? 'Saving…' : 'Save & Apply'),
            status === 'saved' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-status jc-Settings-status--ok" }, "Saved!")),
            status === 'error' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jc-Settings-status jc-Settings-status--err" }, "Failed to save settings")))));
}
class CellSenseSettingsWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(settings) {
        super();
        this._settings = settings;
        this.addClass('jc-SettingsWidget');
        this.title.label = 'CellSense';
        this.title.caption = 'CellSense Settings';
        this.title.closable = true;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SettingsForm, { settings: this._settings });
    }
}
class CellSenseSettingsSidebarWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(settings) {
        super();
        this._settings = settings;
        this.addClass('jc-SettingsWidget');
        this.title.caption = 'CellSense Settings';
        this.title.closable = false;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SettingsForm, { settings: this._settings });
    }
}


/***/ },

/***/ "./lib/tracker/CursorWatcher.js"
/*!**************************************!*\
  !*** ./lib/tracker/CursorWatcher.js ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CursorWatcher: () => (/* binding */ CursorWatcher)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ViewWatcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ViewWatcher */ "./lib/tracker/ViewWatcher.js");




class CursorWatcher {
    constructor(labShell, tracker) {
        this._currentDisposables = [];
        this._cellEditorDisposable = null;
        labShell.currentChanged.connect((_, args) => {
            this._detach();
            if (args.newValue) {
                this._attach(args.newValue, tracker);
            }
        });
    }
    _detach() {
        for (const d of this._currentDisposables)
            d.dispose();
        this._currentDisposables = [];
    }
    _attach(widget, tracker) {
        const path = (0,_ViewWatcher__WEBPACK_IMPORTED_MODULE_3__.getWidgetPath)(widget);
        if (!path)
            return;
        if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel) {
            this._attachNotebook(widget, path, tracker);
        }
        else if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditorWidget) {
            this._attachFileEditor(widget, path, tracker);
        }
    }
    _attachNotebook(panel, path, tracker) {
        const onCellChanged = () => {
            this._replaceCellEditorListener(panel, path, tracker);
        };
        panel.content.activeCellChanged.connect(onCellChanged);
        this._currentDisposables.push(new _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__.DisposableDelegate(() => panel.content.activeCellChanged.disconnect(onCellChanged)));
        this._replaceCellEditorListener(panel, path, tracker);
    }
    _replaceCellEditorListener(panel, path, tracker) {
        if (this._cellEditorDisposable) {
            this._cellEditorDisposable.dispose();
            this._cellEditorDisposable = null;
        }
        const cell = panel.content.activeCell;
        if (!(cell === null || cell === void 0 ? void 0 : cell.editor))
            return;
        const cellIndex = panel.content.activeCellIndex;
        const editor = cell.editor;
        const onSelection = () => {
            const pos = editor.getCursorPosition();
            tracker.upsert(path, {
                lastCursor: { cellIndex, line: pos.line, column: pos.column }
            });
        };
        editor.model.selections.changed.connect(onSelection);
        this._cellEditorDisposable = new _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__.DisposableDelegate(() => editor.model.selections.changed.disconnect(onSelection));
        this._currentDisposables.push(this._cellEditorDisposable);
    }
    _attachFileEditor(widget, path, tracker) {
        const editor = widget.content.editor;
        if (!editor)
            return;
        const onSelection = () => {
            const pos = editor.getCursorPosition();
            tracker.upsert(path, {
                lastCursor: { line: pos.line, column: pos.column }
            });
        };
        editor.model.selections.changed.connect(onSelection);
        this._currentDisposables.push(new _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__.DisposableDelegate(() => editor.model.selections.changed.disconnect(onSelection)));
    }
}


/***/ },

/***/ "./lib/tracker/EditWatcher.js"
/*!************************************!*\
  !*** ./lib/tracker/EditWatcher.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EditWatcher: () => (/* binding */ EditWatcher)
/* harmony export */ });
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./types */ "./lib/tracker/types.js");



function deltaToLineRange(delta, source) {
    let offset = 0;
    let firstNonRetain = -1;
    let lastNonRetain = 0;
    for (const op of delta) {
        if (op.retain !== undefined) {
            offset += op.retain;
        }
        else {
            if (firstNonRetain < 0)
                firstNonRetain = offset;
            if (op.insert !== undefined) {
                lastNonRetain = offset + op.insert.length;
                offset += op.insert.length;
            }
            else if (op.delete !== undefined) {
                lastNonRetain = offset;
            }
        }
    }
    if (firstNonRetain < 0)
        firstNonRetain = 0;
    const lines = source.split('\n');
    let charCount = 0;
    let startLine = 0;
    let endLine = 0;
    for (let i = 0; i < lines.length; i++) {
        const lineEnd = charCount + lines[i].length + 1;
        if (charCount <= firstNonRetain && firstNonRetain < lineEnd)
            startLine = i;
        if (charCount <= lastNonRetain && lastNonRetain <= lineEnd)
            endLine = i;
        if (charCount > lastNonRetain)
            break;
        charCount = lineEnd;
    }
    return { startLine, endLine };
}
class EditWatcher {
    constructor(notebookTracker, editorTracker, tracker) {
        this._debounceTimers = new Map();
        notebookTracker.widgetAdded.connect((_, panel) => {
            this._hookNotebook(panel, tracker);
        });
        editorTracker.widgetAdded.connect((_, widget) => {
            if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_0__.FileEditorWidget) {
                this._hookFileEditor(widget, tracker);
            }
        });
    }
    _hookNotebook(panel, tracker) {
        var _a;
        const path = panel.context.path;
        const disposables = [];
        const attached = new Set();
        const attachCell = (cellIndex) => {
            if (attached.has(cellIndex))
                return;
            attached.add(cellIndex);
            const cell = panel.content.widgets[cellIndex];
            if (!cell)
                return;
            const shared = cell.model.sharedModel;
            const onChange = (_source, change) => {
                const ev = change;
                const src = shared.getSource();
                const range = ev.changes
                    ? deltaToLineRange(ev.changes, src)
                    : { startLine: 0, endLine: src.split('\n').length - 1 };
                this._scheduleUpdate(path, tracker, () => {
                    tracker.upsert(path, {
                        lastEditedAt: Date.now(),
                        lastEditRange: { cellIndex, ...range },
                        isDirty: true,
                        kind: 'notebook'
                    });
                });
            };
            shared.changed.connect(onChange);
            disposables.push(new _lumino_disposable__WEBPACK_IMPORTED_MODULE_1__.DisposableDelegate(() => shared.changed.disconnect(onChange)));
        };
        const attachAllCells = () => {
            for (let i = 0; i < panel.content.widgets.length; i++) {
                attachCell(i);
            }
        };
        attachAllCells();
        (_a = panel.model) === null || _a === void 0 ? void 0 : _a.cells.changed.connect(attachAllCells);
        panel.context.model.stateChanged.connect((_, change) => {
            if (change.name === 'dirty') {
                tracker.upsert(path, { isDirty: panel.context.model.dirty });
            }
        });
        panel.disposed.connect(() => {
            for (const d of disposables)
                d.dispose();
        });
    }
    _hookFileEditor(widget, tracker) {
        const path = widget.context.path;
        const shared = widget.context.model.sharedModel;
        const onChange = (_source, change) => {
            const ev = change;
            const src = shared.getSource();
            const range = ev.changes
                ? deltaToLineRange(ev.changes, src)
                : { startLine: 0, endLine: src.split('\n').length - 1 };
            this._scheduleUpdate(path, tracker, () => {
                tracker.upsert(path, {
                    lastEditedAt: Date.now(),
                    lastEditRange: range,
                    isDirty: true,
                    kind: 'file'
                });
            });
        };
        shared.changed.connect(onChange);
        widget.context.model.stateChanged.connect((_, change) => {
            if (change.name === 'dirty') {
                tracker.upsert(path, { isDirty: widget.context.model.dirty });
            }
        });
        widget.disposed.connect(() => {
            shared.changed.disconnect(onChange);
        });
    }
    _scheduleUpdate(path, tracker, fn) {
        const existing = this._debounceTimers.get(path);
        if (existing !== undefined)
            clearTimeout(existing);
        const t = setTimeout(() => {
            this._debounceTimers.delete(path);
            fn();
        }, _types__WEBPACK_IMPORTED_MODULE_2__.EDIT_DEBOUNCE_MS);
        this._debounceTimers.set(path, t);
    }
}


/***/ },

/***/ "./lib/tracker/FileTracker.js"
/*!************************************!*\
  !*** ./lib/tracker/FileTracker.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileTracker: () => (/* binding */ FileTracker)
/* harmony export */ });
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./types */ "./lib/tracker/types.js");
/* harmony import */ var _ViewWatcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ViewWatcher */ "./lib/tracker/ViewWatcher.js");
/* harmony import */ var _EditWatcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./EditWatcher */ "./lib/tracker/EditWatcher.js");
/* harmony import */ var _CursorWatcher__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CursorWatcher */ "./lib/tracker/CursorWatcher.js");
/* harmony import */ var _ViewportWatcher__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ViewportWatcher */ "./lib/tracker/ViewportWatcher.js");






class FileTracker {
    constructor(options) {
        this._files = new Map();
        this._stateChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        this._debounceTimer = null;
        const { labShell, notebookTracker, editorTracker } = options;
        new _ViewWatcher__WEBPACK_IMPORTED_MODULE_2__.ViewWatcher(labShell, this);
        new _EditWatcher__WEBPACK_IMPORTED_MODULE_3__.EditWatcher(notebookTracker, editorTracker, this);
        new _CursorWatcher__WEBPACK_IMPORTED_MODULE_4__.CursorWatcher(labShell, this);
        new _ViewportWatcher__WEBPACK_IMPORTED_MODULE_5__.ViewportWatcher(labShell, this);
    }
    get stateChanged() {
        return this._stateChanged;
    }
    getRanked(limit) {
        const now = Date.now();
        const entries = Array.from(this._files.values());
        for (const fc of entries) {
            fc.engagementScore = this._computeScore(fc, now);
        }
        entries.sort((a, b) => b.engagementScore - a.engagementScore);
        return limit !== undefined ? entries.slice(0, limit) : entries;
    }
    get(path) {
        var _a;
        return (_a = this._files.get(path)) !== null && _a !== void 0 ? _a : null;
    }
    evict(path) {
        this._files.delete(path);
        this._emitStateChanged();
    }
    upsert(path, updates) {
        const existing = this._files.get(path);
        if (existing) {
            Object.assign(existing, updates);
        }
        else {
            this._files.set(path, {
                path,
                kind: 'file',
                lastViewedAt: Date.now(),
                lastEditedAt: null,
                lastCursor: null,
                lastEditRange: null,
                lastViewportRange: null,
                isDirty: false,
                isOpen: true,
                engagementScore: 0,
                ...updates
            });
            this._evictIfNeeded();
        }
        this._emitStateChanged();
    }
    emitStateChanged() {
        this._emitStateChanged();
    }
    _computeScore(fc, now) {
        const recency = (t) => t === null ? 0 : Math.exp(-(now - t) / _types__WEBPACK_IMPORTED_MODULE_1__.HALF_LIFE_MS);
        const score = 2.0 * recency(fc.lastEditedAt) + 1.0 * recency(fc.lastViewedAt);
        return fc.isOpen ? Math.max(score, 0.1) : score;
    }
    _evictIfNeeded() {
        if (this._files.size <= _types__WEBPACK_IMPORTED_MODULE_1__.MAX_TRACKED_FILES)
            return;
        const now = Date.now();
        const entries = Array.from(this._files.entries());
        entries.sort(([, a], [, b]) => this._computeScore(a, now) - this._computeScore(b, now));
        const toEvict = entries.slice(0, this._files.size - _types__WEBPACK_IMPORTED_MODULE_1__.MAX_TRACKED_FILES);
        for (const [path] of toEvict) {
            this._files.delete(path);
        }
    }
    _emitStateChanged() {
        if (this._debounceTimer !== null)
            return;
        this._debounceTimer = setTimeout(() => {
            this._debounceTimer = null;
            this._stateChanged.emit();
        }, _types__WEBPACK_IMPORTED_MODULE_1__.STATE_CHANGED_DEBOUNCE_MS);
    }
}


/***/ },

/***/ "./lib/tracker/ViewWatcher.js"
/*!************************************!*\
  !*** ./lib/tracker/ViewWatcher.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ViewWatcher: () => (/* binding */ ViewWatcher),
/* harmony export */   getWidgetKind: () => (/* binding */ getWidgetKind),
/* harmony export */   getWidgetPath: () => (/* binding */ getWidgetPath)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./types */ "./lib/tracker/types.js");



function getWidgetPath(widget) {
    if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel)
        return widget.context.path;
    if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditorWidget && widget.context)
        return widget.context.path;
    return null;
}
function getWidgetKind(widget) {
    if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel)
        return 'notebook';
    const path = getWidgetPath(widget);
    if (path !== null)
        return 'file';
    return null;
}
class ViewWatcher {
    constructor(labShell, tracker) {
        this._state = 'idle';
        labShell.currentChanged.connect((_, args) => {
            this._onCurrentChanged(args.oldValue, args.newValue, tracker);
        });
    }
    _onCurrentChanged(oldWidget, newWidget, tracker) {
        // Handle old widget leaving
        if (this._state !== 'idle' && oldWidget && this._state.widget === oldWidget) {
            this._state.cleanup();
            const path = getWidgetPath(oldWidget);
            if (path) {
                // Snapshot final state — cursor/viewport watchers handle their own snapshot
                // Just ensure isOpen is kept until disposed
            }
            this._state = 'idle';
        }
        if (!newWidget)
            return;
        const path = getWidgetPath(newWidget);
        const kind = getWidgetKind(newWidget);
        if (!path || !kind)
            return;
        // Set up pending state
        const cleanupFns = [];
        const promote = () => {
            cleanup();
            tracker.upsert(path, {
                lastViewedAt: Date.now(),
                kind,
                isOpen: true
            });
        };
        const timer = setTimeout(promote, _types__WEBPACK_IMPORTED_MODULE_2__.DWELL_THRESHOLD_MS);
        cleanupFns.push(() => clearTimeout(timer));
        const onInteraction = () => {
            promote();
        };
        const node = newWidget.node;
        const events = ['keydown', 'mousedown', 'wheel'];
        for (const ev of events) {
            node.addEventListener(ev, onInteraction, { once: true, passive: true });
        }
        cleanupFns.push(() => {
            for (const ev of events) {
                node.removeEventListener(ev, onInteraction);
            }
        });
        const cleanup = () => {
            for (const fn of cleanupFns)
                fn();
        };
        this._state = { widget: newWidget, timer, cleanup };
        // Track widget disposal to mark isOpen = false
        newWidget.disposed.connect(() => {
            if (this._state !== 'idle' && this._state.widget === newWidget) {
                this._state.cleanup();
                this._state = 'idle';
            }
            tracker.upsert(path, { isOpen: false });
        });
    }
}


/***/ },

/***/ "./lib/tracker/ViewportWatcher.js"
/*!****************************************!*\
  !*** ./lib/tracker/ViewportWatcher.js ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ViewportWatcher: () => (/* binding */ ViewportWatcher)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./types */ "./lib/tracker/types.js");
/* harmony import */ var _ViewWatcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ViewWatcher */ "./lib/tracker/ViewWatcher.js");
/* harmony import */ var _adapters_CodeMirrorViewportAdapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./adapters/CodeMirrorViewportAdapter */ "./lib/tracker/adapters/CodeMirrorViewportAdapter.js");





const adapter = new _adapters_CodeMirrorViewportAdapter__WEBPACK_IMPORTED_MODULE_4__.CodeMirrorViewportAdapter();
function getActiveCellByViewport(notebook) {
    const node = notebook.content.node;
    const midY = node.scrollTop + node.clientHeight / 2;
    const cells = notebook.content.widgets;
    for (let i = 0; i < cells.length; i++) {
        const cellNode = cells[i].node;
        const top = cellNode.offsetTop;
        const bottom = top + cellNode.offsetHeight;
        if (midY >= top && midY <= bottom)
            return i;
    }
    return notebook.content.activeCellIndex;
}
class ViewportWatcher {
    constructor(labShell, tracker) {
        this._scrollDisposables = [];
        this._debounceTimer = null;
        labShell.currentChanged.connect((_, args) => {
            this._detach();
            if (args.newValue) {
                this._attach(args.newValue, tracker);
            }
        });
    }
    _detach() {
        for (const d of this._scrollDisposables)
            d.dispose();
        this._scrollDisposables = [];
        if (this._debounceTimer !== null) {
            clearTimeout(this._debounceTimer);
            this._debounceTimer = null;
        }
    }
    _attach(widget, tracker) {
        const path = (0,_ViewWatcher__WEBPACK_IMPORTED_MODULE_3__.getWidgetPath)(widget);
        if (!path)
            return;
        if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel) {
            this._attachNotebook(widget, path, tracker);
        }
        else if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditorWidget) {
            this._attachFileEditor(widget, path, tracker);
        }
    }
    _attachNotebook(panel, path, tracker) {
        const update = () => {
            this._scheduleUpdate(() => {
                const cellIndex = getActiveCellByViewport(panel);
                const cell = panel.content.widgets[cellIndex];
                if (!(cell === null || cell === void 0 ? void 0 : cell.editor))
                    return;
                const range = adapter.getVisibleRange(cell.editor);
                if (range) {
                    tracker.upsert(path, {
                        lastViewportRange: { cellIndex, ...range }
                    });
                }
            });
        };
        const handler = () => update();
        panel.content.node.addEventListener('scroll', handler, { passive: true });
        this._scrollDisposables.push({
            dispose: () => panel.content.node.removeEventListener('scroll', handler)
        });
    }
    _attachFileEditor(widget, path, tracker) {
        const editor = widget.content.editor;
        if (!editor)
            return;
        const d = adapter.onScroll(editor, () => {
            this._scheduleUpdate(() => {
                const range = adapter.getVisibleRange(editor);
                if (range) {
                    tracker.upsert(path, { lastViewportRange: range });
                }
            });
        });
        this._scrollDisposables.push(d);
    }
    _scheduleUpdate(fn) {
        if (this._debounceTimer !== null)
            clearTimeout(this._debounceTimer);
        this._debounceTimer = setTimeout(() => {
            this._debounceTimer = null;
            fn();
        }, _types__WEBPACK_IMPORTED_MODULE_2__.VIEWPORT_DEBOUNCE_MS);
    }
}


/***/ },

/***/ "./lib/tracker/adapters/CodeMirrorViewportAdapter.js"
/*!***********************************************************!*\
  !*** ./lib/tracker/adapters/CodeMirrorViewportAdapter.js ***!
  \***********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeMirrorViewportAdapter: () => (/* binding */ CodeMirrorViewportAdapter)
/* harmony export */ });
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_1__);


class CodeMirrorViewportAdapter {
    getVisibleRange(editor) {
        if (!(editor instanceof _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.CodeMirrorEditor))
            return null;
        const view = editor.editor;
        if (!view)
            return null;
        const ranges = view.visibleRanges;
        if (ranges.length === 0)
            return null;
        const from = ranges[0].from;
        const to = ranges[ranges.length - 1].to;
        const fromLine = view.state.doc.lineAt(from).number - 1;
        const toLine = view.state.doc.lineAt(to).number - 1;
        return { startLine: fromLine, endLine: toLine };
    }
    onScroll(editor, callback) {
        if (!(editor instanceof _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.CodeMirrorEditor)) {
            return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_1__.DisposableDelegate(() => { });
        }
        const view = editor.editor;
        const handler = () => callback();
        view.scrollDOM.addEventListener('scroll', handler, { passive: true });
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_1__.DisposableDelegate(() => view.scrollDOM.removeEventListener('scroll', handler));
    }
}


/***/ },

/***/ "./lib/tracker/token.js"
/*!******************************!*\
  !*** ./lib/tracker/token.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IFileTracker: () => (/* binding */ IFileTracker)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);

// eslint-disable-next-line @typescript-eslint/no-redeclare
const IFileTracker = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyterlab-cellsense:IFileTracker');


/***/ },

/***/ "./lib/tracker/types.js"
/*!******************************!*\
  !*** ./lib/tracker/types.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_SLICE_LINES: () => (/* binding */ DEFAULT_SLICE_LINES),
/* harmony export */   DWELL_THRESHOLD_MS: () => (/* binding */ DWELL_THRESHOLD_MS),
/* harmony export */   EDIT_DEBOUNCE_MS: () => (/* binding */ EDIT_DEBOUNCE_MS),
/* harmony export */   GLOBAL_CONTEXT_CHAR_BUDGET: () => (/* binding */ GLOBAL_CONTEXT_CHAR_BUDGET),
/* harmony export */   HALF_LIFE_MS: () => (/* binding */ HALF_LIFE_MS),
/* harmony export */   MAX_CONTEXT_FILES_SENT: () => (/* binding */ MAX_CONTEXT_FILES_SENT),
/* harmony export */   MAX_TRACKED_FILES: () => (/* binding */ MAX_TRACKED_FILES),
/* harmony export */   STATE_CHANGED_DEBOUNCE_MS: () => (/* binding */ STATE_CHANGED_DEBOUNCE_MS),
/* harmony export */   VIEWPORT_DEBOUNCE_MS: () => (/* binding */ VIEWPORT_DEBOUNCE_MS)
/* harmony export */ });
// Constants shared with backend
const DWELL_THRESHOLD_MS = 2000;
const MAX_TRACKED_FILES = 8;
const MAX_CONTEXT_FILES_SENT = 5;
const DEFAULT_SLICE_LINES = 20;
const VIEWPORT_DEBOUNCE_MS = 150;
const EDIT_DEBOUNCE_MS = 250;
const GLOBAL_CONTEXT_CHAR_BUDGET = 16000;
const HALF_LIFE_MS = 5 * 60 * 1000;
const STATE_CHANGED_DEBOUNCE_MS = 500;


/***/ }

}]);
//# sourceMappingURL=lib_index_js.20450246ffcb8cd0d8f5.js.map