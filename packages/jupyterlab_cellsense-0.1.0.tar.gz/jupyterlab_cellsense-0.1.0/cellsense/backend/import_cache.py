"""Import normalization, hashing, and in-process API context cache.

Cache key: (workspace_root, file_path, import_hash)

Invalidation is implicit: changed imports → new hash → cache miss.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path


_WORKSPACE_MARKERS = ("pyproject.toml", ".git", "setup.py", "requirements.txt")


def _find_workspace_root(file_path: str | None, jupyter_root: str | None) -> str:
    if jupyter_root:
        return str(Path(jupyter_root).resolve())

    if file_path:
        directory = Path(file_path).parent.resolve()
        candidate = directory
        while True:
            for marker in _WORKSPACE_MARKERS:
                if (candidate / marker).exists():
                    return str(candidate)
            parent = candidate.parent
            if parent == candidate:
                break
            candidate = parent
        return str(directory)

    return str(Path.cwd())


def _normalize_one(raw: str) -> str:
    """Collapse whitespace and canonicalize a single import statement."""
    # Join multiline: collapse all runs of whitespace (including newlines) to one space
    line = re.sub(r"\s+", " ", raw.strip())
    # Remove padding inside parentheses
    line = re.sub(r"\(\s+", "(", line)
    line = re.sub(r"\s+\)", ")", line)
    # Strip trailing commas before closing paren (multiline import artefact)
    line = re.sub(r",\s*\)", ")", line)
    # Normalize comma spacing
    line = re.sub(r"\s*,\s*", ", ", line)
    # Normalize spacing around 'as' keyword (aliases)
    line = re.sub(r"\s+as\s+", " as ", line)
    return line


def normalize_imports(imports: list[str]) -> list[str]:
    """Normalize a list of import strings and sort for order-stable hashing."""
    normalized = [_normalize_one(imp) for imp in imports]
    normalized = [n for n in normalized if n]
    normalized.sort()
    return normalized


def hash_imports(normalized: list[str]) -> str:
    """Return the sha256 hex digest of the sorted, normalized import list."""
    return hashlib.sha256("\n".join(normalized).encode()).hexdigest()


class ImportContextCache:
    """In-process dict cache: (workspace_root, file_path, import_hash) → api_context."""

    def __init__(self) -> None:
        self._store: dict[tuple[str, str, str], dict[str, str]] = {}

    def get(self, workspace_root: str, file_path: str, import_hash: str) -> dict[str, str] | None:
        return self._store.get((workspace_root, file_path, import_hash))

    def put(self, workspace_root: str, file_path: str, import_hash: str, api_context: dict[str, str]) -> None:
        self._store[(workspace_root, file_path, import_hash)] = api_context

    def find_workspace_root(self, file_path: str | None, jupyter_root: str | None = None) -> str:
        return _find_workspace_root(file_path, jupyter_root)
