"""PromptBuilder + CompletionInputs.

A fresh ``PromptBuilder`` is instantiated per request. It carries no state,
so concurrent requests cannot interfere with each other. It only orchestrates
— populating a typed ``CompletionInputs`` and handing it to the configured
``ModelCompletor``. The actual prompt string is constructed inside the completor.

``CompletionInputs`` is the typed parameter object that lets the backend
absorb new fields (signatures in Phase 2, context_chunks in Phase 3) without
churning every ``ModelCompletor`` signature.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from cellsense.backend.models.base import BuiltPrompt, ModelCompletor
    from cellsense.backend.context.assembler import FileContextBlock


@dataclass
class CompletionInputs:
    prefix: str
    suffix: str
    file_path: str
    language: str = "python"
    signatures: dict[str, str] = field(default_factory=dict)
    context_chunks: 'List[FileContextBlock]' = field(default_factory=list)
    retrieved_chunks: 'List[FileContextBlock]' = field(default_factory=list)


class PromptBuilder:
    def __init__(self, model_family: "ModelCompletor") -> None:
        self._family = model_family

    def build(self, prefix: str, suffix: str, one_line_completions: bool = False, **kwargs) -> "BuiltPrompt":
        inputs = CompletionInputs(prefix=prefix, suffix=suffix, **kwargs)
        built = self._family.build_prompt(inputs)
        if one_line_completions:
            from cellsense.backend.models.base import BuiltPrompt
            extra = [w for w in ["\n", "\\n"] if w not in built.stop_words]
            if extra:
                built = BuiltPrompt(text=built.text, stop_words=built.stop_words + extra)
        return built
