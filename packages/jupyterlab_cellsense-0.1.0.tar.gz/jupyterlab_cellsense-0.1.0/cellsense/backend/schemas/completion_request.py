"""Pydantic v2 models for the extended completion request schema (Phase 3)."""
from __future__ import annotations

import logging
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

log = logging.getLogger(__name__)

GLOBAL_CONTEXT_CHAR_BUDGET = 16_000


class AnchorRange(BaseModel):
    cell_index: Optional[int] = None
    start_line: int = Field(ge=0)
    end_line: int = Field(ge=0)

    @field_validator('end_line')
    @classmethod
    def end_after_start(cls, v: int, info: object) -> int:
        data = getattr(info, 'data', {})
        start = data.get('start_line')
        if start is not None and v < start:
            raise ValueError('end_line must be >= start_line')
        return v


class ContextFileEntry(BaseModel):
    path: str
    kind: Literal['notebook', 'file']
    signal: Literal['edited', 'viewed']
    recency_rank: int = Field(ge=0)
    anchor: AnchorRange
    source: Literal['disk', 'inline']
    content: Optional[str] = None

    @model_validator(mode='after')
    def content_matches_source(self) -> 'ContextFileEntry':
        if self.source == 'inline' and self.content is None:
            raise ValueError('content required when source is inline')
        if self.source == 'disk' and self.content is not None:
            log.warning(
                "context_files entry has source='disk' but content was provided — ignoring content"
            )
            object.__setattr__(self, 'content', None)
        return self


class CompletionRequest(BaseModel):
    # Existing fields
    prefix: str
    suffix: str
    language: str = 'python'
    imports: List[str] = Field(default_factory=list)
    file_path: str = ''
    # New: multi-file context
    context_files: List[ContextFileEntry] = Field(default_factory=list)


def parse_context_files_lenient(raw: list) -> List[ContextFileEntry]:
    """Parse context_files entries one-by-one; drop malformed ones instead of failing."""
    entries: List[ContextFileEntry] = []
    for i, item in enumerate(raw):
        try:
            entries.append(ContextFileEntry(**item))
        except Exception as exc:
            log.warning("Dropping malformed context_files[%d]: %s", i, exc)
    return entries
