"""Context assembler: combines import-based context with file-based context.

Budget enforcement:
- Import context chars are charged first.
- File slices are sorted edited-before-viewed, then by recency_rank ascending.
- No single file may consume more than 40% of the total budget.
- If a slice exceeds remaining budget it is tail-truncated (recent edits are at the bottom).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from cellsense.backend.context.file_reader import read_context_slice_cached
from cellsense.backend.schemas.completion_request import (
    GLOBAL_CONTEXT_CHAR_BUDGET,
    CompletionRequest,
    ContextFileEntry,
)

log = logging.getLogger(__name__)

_SIGNAL_ORDER = {'edited': 0, 'viewed': 1}
_PER_FILE_BUDGET_FRACTION = 0.40


@dataclass
class FileContextBlock:
    path: str
    signal: str
    text: str
    start_line: int
    end_line: int
    cell_index: Optional[int]


@dataclass
class AssembledContext:
    import_context: str
    file_context_blocks: List[FileContextBlock] = field(default_factory=list)
    total_chars: int = 0
    dropped_files: List[str] = field(default_factory=list)


def assemble_context(
    request: CompletionRequest,
    server_root: Path,
    import_context: str = '',
    char_budget: int = GLOBAL_CONTEXT_CHAR_BUDGET,
) -> AssembledContext:
    result = AssembledContext(import_context=import_context)
    result.total_chars = len(import_context)
    remaining = char_budget - result.total_chars

    per_file_cap = int(char_budget * _PER_FILE_BUDGET_FRACTION)

    # Sort: edited before viewed; then by recency_rank ascending
    sorted_files: List[ContextFileEntry] = sorted(
        request.context_files,
        key=lambda e: (_SIGNAL_ORDER.get(e.signal, 99), e.recency_rank),
    )

    for entry in sorted_files:
        if remaining <= 0:
            result.dropped_files.append(entry.path)
            continue

        if entry.source == 'inline':
            text = entry.content or ''
        else:
            text = read_context_slice_cached(
                path=entry.path,
                kind=entry.kind,
                cell_index=entry.anchor.cell_index,
                start_line=entry.anchor.start_line,
                end_line=entry.anchor.end_line,
                server_root=server_root,
            ) or ''

        if not text:
            result.dropped_files.append(entry.path)
            continue

        # Apply per-file cap — keep the tail (most recent context is at bottom)
        if len(text) > per_file_cap:
            text = text[-per_file_cap:]

        # Apply remaining budget — keep the tail
        if len(text) > remaining:
            text = text[-remaining:]

        result.file_context_blocks.append(
            FileContextBlock(
                path=entry.path,
                signal=entry.signal,
                text=text,
                start_line=entry.anchor.start_line,
                end_line=entry.anchor.end_line,
                cell_index=entry.anchor.cell_index,
            )
        )
        remaining -= len(text)
        result.total_chars += len(text)

    result.dropped_files.extend(
        e.path for e in sorted_files
        if e.path not in {b.path for b in result.file_context_blocks}
        and e.path not in result.dropped_files
    )

    log.info(
        "context assembled: n_received=%d n_used=%d n_dropped=%d "
        "total_chars=%d import_chars=%d",
        len(request.context_files),
        len(result.file_context_blocks),
        len(result.dropped_files),
        result.total_chars,
        len(import_context),
    )

    return result


def render_file_context_blocks(blocks: List[FileContextBlock]) -> str:
    """Render file context blocks as an XML-like string for the prompt."""
    if not blocks:
        return ''
    parts: List[str] = []
    for b in blocks:
        cell_attr = f' cell="{b.cell_index}"' if b.cell_index is not None else ''
        parts.append(
            f'<file path="{b.path}" signal="{b.signal}" '
            f'lines="{b.start_line}-{b.end_line}"{cell_attr}>\n'
            f'{b.text}\n'
            f'</file>'
        )
    return '\n'.join(parts)
