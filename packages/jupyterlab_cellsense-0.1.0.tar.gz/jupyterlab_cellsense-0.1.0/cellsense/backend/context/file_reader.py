"""Disk reader for context_files entries with source='disk'."""
from __future__ import annotations

import json
import logging
from functools import lru_cache
from pathlib import Path
from typing import Literal, Optional

log = logging.getLogger(__name__)

MAX_FILE_READ_BYTES = 2 * 1024 * 1024  # 2 MB


def read_context_slice(
    path: str,
    kind: Literal['notebook', 'file'],
    cell_index: Optional[int],
    start_line: int,
    end_line: int,
    server_root: Path,
) -> Optional[str]:
    """Read the requested line range from disk.

    Returns None if the file cannot be read (missing, permission denied, parse
    error, path traversal) or falls outside the size cap.
    """
    try:
        return _read(path, kind, cell_index, start_line, end_line, server_root)
    except Exception as exc:
        log.warning("Unexpected error reading context file %r: %s", path, exc)
        return None


def _resolve_path(path: str, server_root: Path) -> Optional[Path]:
    p = Path(path)
    if not p.is_absolute():
        p = (server_root / p).resolve()
    else:
        p = p.resolve()

    # Security: reject path traversal outside server_root
    try:
        p.relative_to(server_root.resolve())
    except ValueError:
        log.info("Path traversal rejected: %r", path)
        return None

    return p


def _read(
    path: str,
    kind: str,
    cell_index: Optional[int],
    start_line: int,
    end_line: int,
    server_root: Path,
) -> Optional[str]:
    resolved = _resolve_path(path, server_root)
    if resolved is None:
        return None

    try:
        size = resolved.stat().st_size
    except FileNotFoundError:
        log.info("Context file not found: %r", resolved)
        return None
    except PermissionError:
        log.info("Permission denied reading context file: %r", resolved)
        return None

    if size > MAX_FILE_READ_BYTES:
        log.info("Context file too large (%d bytes), skipping: %r", size, resolved)
        return None

    if kind == 'notebook':
        return _read_notebook_cell(resolved, cell_index, start_line, end_line)
    else:
        return _read_plain_file(resolved, start_line, end_line)


def _read_plain_file(resolved: Path, start_line: int, end_line: int) -> Optional[str]:
    try:
        text = resolved.read_text(encoding='utf-8', errors='replace')
    except FileNotFoundError:
        log.info("Context file not found: %r", resolved)
        return None
    except PermissionError:
        log.info("Permission denied: %r", resolved)
        return None

    lines = text.splitlines()
    return '\n'.join(lines[start_line: end_line + 1])


def _read_notebook_cell(
    resolved: Path, cell_index: Optional[int], start_line: int, end_line: int
) -> Optional[str]:
    if cell_index is None:
        return None

    try:
        raw = resolved.read_text(encoding='utf-8', errors='replace')
        nb = json.loads(raw)
    except FileNotFoundError:
        log.info("Notebook not found: %r", resolved)
        return None
    except PermissionError:
        log.info("Permission denied: %r", resolved)
        return None
    except json.JSONDecodeError as exc:
        log.info("Notebook JSON parse error %r: %s", resolved, exc)
        return None

    cells = nb.get('cells', [])
    if cell_index >= len(cells):
        log.info("cell_index %d out of range (notebook has %d cells): %r", cell_index, len(cells), resolved)
        return None

    cell_source = cells[cell_index].get('source', '')
    if isinstance(cell_source, list):
        cell_source = ''.join(cell_source)

    lines = cell_source.splitlines()
    return '\n'.join(lines[start_line: end_line + 1])


@lru_cache(maxsize=64)
def _cached_read(
    resolved: Path,
    mtime: float,
    kind: str,
    cell_index: Optional[int],
    start_line: int,
    end_line: int,
) -> Optional[str]:
    """LRU-cached inner read, keyed by (path, mtime, params)."""
    server_root = resolved.parent  # already resolved; pass itself as root so check passes
    return _read(str(resolved), kind, cell_index, start_line, end_line, server_root)


def read_context_slice_cached(
    path: str,
    kind: Literal['notebook', 'file'],
    cell_index: Optional[int],
    start_line: int,
    end_line: int,
    server_root: Path,
) -> Optional[str]:
    """Cached version — resolves path and checks mtime before hitting the cache."""
    resolved = _resolve_path(path, server_root)
    if resolved is None:
        return None
    try:
        mtime = resolved.stat().st_mtime
    except OSError:
        return None
    return _cached_read(resolved, mtime, kind, cell_index, start_line, end_line)
