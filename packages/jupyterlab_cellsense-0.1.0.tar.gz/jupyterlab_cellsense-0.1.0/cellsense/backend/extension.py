"""Jupyter Server extension app for CellSense.

Reads provider configuration from server-side traitlets (so credentials never
travel from the frontend), instantiates the provider + registry once, and
registers the two HTTP handlers under ``/cellsense/``.

Configuration (place in jupyter_server_config.py):

    c.CellSenseApp.provider_type = "ollama"
    c.CellSenseApp.provider_base_url = "http://localhost:11434"
    c.CellSenseApp.provider_model = "deepseek-coder:6.7b"
    # c.CellSenseApp.provider_api_key = "..."   # for hosted providers
"""
from __future__ import annotations

import httpx
from jupyter_server.extension.application import ExtensionApp
from jupyter_server.utils import url_path_join
from traitlets import Float, Int, Unicode

from cellsense.backend.handlers import CompleteHandler, ConfigHandler, HealthHandler
from cellsense.backend.import_cache import ImportContextCache
from cellsense.backend.providers import build_provider
from cellsense.backend.registry import default_registry


class CellSenseApp(ExtensionApp):
    name = "cellsense"
    extension_url = "/cellsense"

    provider_type = Unicode(
        "ollama",
        config=True,
        help="Provider transport: 'ollama', 'openai_compatible', or 'anthropic'.",
    )
    provider_base_url = Unicode(
        "http://localhost:11434",
        config=True,
        help="Base URL for the model provider.",
    )
    provider_api_key = Unicode(
        "",
        config=True,
        help="API key for hosted providers. Leave empty for local Ollama.",
    )
    provider_model = Unicode(
        "deepseek-coder:6.7b",
        config=True,
        help="Model identifier passed to the provider.",
    )
    request_timeout_s = Float(
        30.0,
        config=True,
        help="Per-request timeout for upstream provider calls (seconds).",
    )
    max_completion_tokens = Int(
        256,
        config=True,
        help="Upper bound on generated completion length (tokens).",
    )
    retrieval_max_files = Int(100, config=True)
    retrieval_max_chunks_per_file = Int(200, config=True)
    retrieval_top_k = Int(3, config=True)
    retrieval_cache_invalidate_distance = Int(80, config=True)
    retrieval_token_budget = Int(2000, config=True)

    def initialize_settings(self) -> None:
        self.http_client = httpx.AsyncClient(timeout=self.request_timeout_s)
        self.registry = default_registry()
        self.provider = build_provider(
            kind=self.provider_type,
            base_url=self.provider_base_url,
            api_key=self.provider_api_key,
            model=self.provider_model,
            max_tokens=self.max_completion_tokens,
            client=self.http_client,
        )
        jupyter_root = getattr(self.serverapp, "root_dir", None)
        retrieval_config = {
            "MAX_FILES_TO_INDEX": self.retrieval_max_files,
            "MAX_CHUNKS_PER_FILE": self.retrieval_max_chunks_per_file,
            "TOP_K_CHUNKS": self.retrieval_top_k,
            "CACHE_INVALIDATE_DISTANCE": self.retrieval_cache_invalidate_distance,
            "RETRIEVED_CONTEXT_TOKEN_BUDGET": self.retrieval_token_budget,
            "WORKSPACE_ROOT": jupyter_root or "",
        }
        self.settings.update({
            "cellsense_provider": self.provider,
            "cellsense_registry": self.registry,
            "cellsense_model_name": self.provider_model,
            "cellsense_http_client": self.http_client,
            "cellsense_max_tokens": self.max_completion_tokens,
            "cellsense_import_cache": ImportContextCache(),
            "cellsense_jupyter_root": jupyter_root,
            "cellsense_retrieval_config": retrieval_config,
        })

        if jupyter_root:
            from cellsense.backend.retrieval.init import initialize_retrieval
            initialize_retrieval(jupyter_root, retrieval_config)

    def initialize_handlers(self) -> None:
        base = self.settings["base_url"]
        self.handlers.extend([
            (url_path_join(base, "cellsense", "health"), HealthHandler),
            (url_path_join(base, "cellsense", "complete"), CompleteHandler),
            (url_path_join(base, "cellsense", "config"), ConfigHandler),
        ])

    async def stop_extension(self) -> None:
        await self.http_client.aclose()
        from cellsense.backend.retrieval.init import shutdown_retrieval
        shutdown_retrieval()
