"""HTTP handlers for CellSense.

Two endpoints in Phase 1:

  GET  /cellsense/health    — liveness + configured-model echo
  POST /cellsense/complete  — FIM completion request

Authentication is enforced by Jupyter Server's standard XSRF/auth machinery
via @web.authenticated. The frontend reaches these routes through the same
authenticated session it already uses for kernel traffic.
"""
from __future__ import annotations

import json
from pathlib import Path

import httpx
from jupyter_server.base.handlers import JupyterHandler
from tornado import web

from cellsense.backend.context.assembler import assemble_context
from cellsense.backend.import_cache import ImportContextCache, hash_imports, normalize_imports
from cellsense.backend.import_resolver import get_candidate_roots, resolve_local_imports
from cellsense.backend.prompt_builder import PromptBuilder
from cellsense.backend.providers import build_provider
from cellsense.backend.registry import default_registry
from cellsense.backend.schemas.completion_request import (
    CompletionRequest,
    parse_context_files_lenient,
)
from cellsense.backend.signature_extractor import build_signatures_context


class ConfigHandler(JupyterHandler):
    @web.authenticated
    async def post(self) -> None:
        try:
            payload = json.loads(self.request.body or b"{}")
        except json.JSONDecodeError:
            raise web.HTTPError(400, "Request body must be valid JSON.")

        provider_type = payload.get("provider_type", "ollama")
        base_url = payload.get("base_url", "")
        api_key = payload.get("api_key", "")
        model = payload.get("model", "")
        model_family = payload.get("model_family", "")
        max_tokens = payload.get("max_tokens", self.settings.get("cellsense_max_tokens", 256))
        one_line_completions = payload.get("one_line_completions", self.settings.get("cellsense_one_line_completions", False))
        retrieval_enabled = payload.get("retrieval_enabled", True)
        retrieval_top_k = payload.get("retrieval_top_k", 3)
        retrieval_token_budget = payload.get("retrieval_token_budget", 2000)

        if not isinstance(provider_type, str) or not isinstance(model, str):
            raise web.HTTPError(400, "Invalid config payload.")
        if not isinstance(max_tokens, int) or max_tokens < 32:
            raise web.HTTPError(400, "max_tokens must be an integer >= 32.")

        http_client = self.settings.get("cellsense_http_client")

        try:
            new_provider = build_provider(
                kind=provider_type,
                base_url=base_url,
                api_key=api_key,
                model=model,
                max_tokens=max_tokens,
                client=http_client,
            )
        except Exception as exc:
            raise web.HTTPError(400, f"Failed to build provider: {exc}")

        # Use model_family for registry lookup when provided and specific;
        # fall back to the full model name for substring matching.
        registry_key = model_family if model_family and model_family != "other" else model

        self.settings["cellsense_provider"] = new_provider
        self.settings["cellsense_model_name"] = registry_key
        self.settings["cellsense_max_tokens"] = max_tokens
        self.settings["cellsense_one_line_completions"] = bool(one_line_completions)

        existing_retrieval = self.settings.get("cellsense_retrieval_config") or {}
        if retrieval_enabled and existing_retrieval:
            self.settings["cellsense_retrieval_config"] = {
                **existing_retrieval,
                "TOP_K_CHUNKS": retrieval_top_k,
                "RETRIEVED_CONTEXT_TOKEN_BUDGET": retrieval_token_budget,
            }
        elif not retrieval_enabled:
            self.settings["cellsense_retrieval_config"] = None

        self.set_header("Content-Type", "application/json")
        self.write(json.dumps({"ok": True}))


class HealthHandler(JupyterHandler):
    @web.authenticated
    async def get(self) -> None:
        provider = self.settings.get("cellsense_provider")
        registry = self.settings.get("cellsense_registry")
        model_name = self.settings.get("cellsense_model_name", "")
        ready = provider is not None and registry is not None
        family = registry.get(model_name).get_model_family() if ready else None
        self.set_header("Content-Type", "application/json")
        self.write(json.dumps({
            "ok": ready,
            "model": model_name,
            "family": family,
        }))


class CompleteHandler(JupyterHandler):
    @web.authenticated
    async def post(self) -> None:
        try:
            payload = json.loads(self.request.body or b"{}")
        except json.JSONDecodeError:
            raise web.HTTPError(400, "Request body must be valid JSON.")

        prefix = payload.get("prefix", "")
        suffix = payload.get("suffix", "")
        language = payload.get("language", "python")
        imports = payload.get("imports", None)
        file_path = payload.get("file_path", None)
        raw_context_files = payload.get("context_files", [])

        self.log.debug(f"imports: {imports}")

        if not isinstance(prefix, str) or not isinstance(suffix, str):
            raise web.HTTPError(400, "'prefix' and 'suffix' must be strings.")
        if imports is not None and not isinstance(imports, list):
            raise web.HTTPError(400, "'imports' must be a list of strings.")
        if file_path is not None and not isinstance(file_path, str):
            raise web.HTTPError(400, "'file_path' must be a string.")
        if not isinstance(raw_context_files, list):
            raw_context_files = []

        # Parse context_files leniently — drop bad entries, don't 400 the request
        context_files = parse_context_files_lenient(raw_context_files)

        provider = self.settings["cellsense_provider"]
        registry = self.settings["cellsense_registry"]
        model_name = self.settings["cellsense_model_name"]

        api_context: dict[str, str] | None = None
        import_context_str = ""

        if imports is not None:
            cache: ImportContextCache = self.settings["cellsense_import_cache"]
            jupyter_root: str | None = self.settings.get("cellsense_jupyter_root")

            normalized = normalize_imports(imports)
            import_hash = hash_imports(normalized)
            workspace_root = cache.find_workspace_root(file_path, jupyter_root)

            api_context = cache.get(workspace_root, file_path or "", import_hash)
            if api_context is not None:
                self.log.debug(
                    "cache hit — workspace=%r file=%r hash=%s",
                    workspace_root, file_path, import_hash[:8],
                )
            else:
                self.log.debug(
                    "cache miss — resolving imports workspace=%r file=%r hash=%s",
                    workspace_root, file_path, import_hash[:8],
                )
                resolved = resolve_local_imports(normalized, workspace_root, file_path)
                candidate_roots = get_candidate_roots(workspace_root, file_path)
                api_context = build_signatures_context(resolved, candidate_roots)
                cache.put(workspace_root, file_path or "", import_hash, api_context)

        family = registry.get(model_name)
        signatures = api_context if api_context else {}

        # Build a temporary CompletionRequest for context assembly
        from cellsense.backend.schemas.completion_request import CompletionRequest as CR
        cr = CR(
            prefix=prefix,
            suffix=suffix,
            language=language,
            imports=imports or [],
            file_path=file_path or "",
            context_files=context_files,
        )

        server_root = Path(self.settings.get("cellsense_jupyter_root") or ".")
        assembled = assemble_context(cr, server_root=server_root, import_context=import_context_str)

        retrieved_chunks = []
        retrieval_config = self.settings.get("cellsense_retrieval_config")
        if retrieval_config:
            from cellsense.backend.retrieval.init import get_retrieved_context
            retrieved_chunks = get_retrieved_context(prefix, suffix, retrieval_config)

        one_line_completions = self.settings.get("cellsense_one_line_completions", False)
        builder = PromptBuilder(family)
        built = builder.build(
            prefix=prefix,
            suffix=suffix,
            file_path=file_path,
            language=language,
            signatures=signatures,
            context_chunks=assembled.file_context_blocks,
            retrieved_chunks=retrieved_chunks,
            one_line_completions=one_line_completions,
        )

        try:
            completion = await provider.complete(built)
            completion = family.post_process(completion)
        except httpx.HTTPStatusError as exc:
            self.log.warning(
                "Provider returned %s: %s",
                exc.response.status_code, exc.response.text[:500],
            )
            raise web.HTTPError(502, "Upstream provider error.")
        except httpx.HTTPError as exc:
            self.log.warning("Provider transport error: %s", exc)
            raise web.HTTPError(502, "Upstream provider unreachable.")

        self.set_header("Content-Type", "application/json")
        self.write(json.dumps({"completion": completion}))
