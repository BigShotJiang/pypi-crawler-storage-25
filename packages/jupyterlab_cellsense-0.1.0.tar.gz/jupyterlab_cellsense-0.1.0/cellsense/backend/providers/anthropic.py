"""AnthropicProvider: native Messages API, overrides build_request and handle_response."""
from __future__ import annotations

from cellsense.backend.models.base import BuiltPrompt
from cellsense.backend.providers.base import CompletionProvider
from cellsense.backend.providers.registry import ProviderRegistry


@ProviderRegistry.add_to_registry("anthropic")
class AnthropicProvider(CompletionProvider):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        if not self.base_url:
            self.base_url = "https://api.anthropic.com"

    def endpoint(self) -> str:
        return f"{self.base_url}/v1/messages"

    def headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

    def build_request(self, prompt: BuiltPrompt) -> dict:
        return {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "stop_sequences": prompt.stop_words or [],
            "messages": [{"role": "user", "content": prompt.text}],
        }

    def handle_response(self, response: dict) -> str:
        for block in response.get("content") or []:
            if block.get("type") == "text":
                return block.get("text") or ""
        return ""
