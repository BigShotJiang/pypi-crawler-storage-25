"""CompletionProvider abstract base — transport-only contract.

Provider and ModelCompletor are independent axes, by deliberate design. The same
model (e.g. Codestral) can be served by Ollama, by Mistral's OpenAI-compatible
endpoint, by llama.cpp's server, etc. Conflating the two would cause a
combinatorial subclass explosion.

The default ``build_request`` and ``handle_response`` target the
OpenAI-compatible ``/v1/completions`` shape because the majority of
providers (Ollama, llama.cpp, LM Studio, Mistral, Groq, Fireworks, etc.)
speak it. Subclasses override only when the wire protocol genuinely differs.
"""
from __future__ import annotations

from abc import ABC

import httpx

from cellsense.backend.models.base import BuiltPrompt


class CompletionProvider(ABC):
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        max_tokens: int,
        client: httpx.AsyncClient,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.client = client

    def endpoint(self) -> str:
        return f"{self.base_url}/v1/completions"

    def headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def build_request(self, prompt: BuiltPrompt) -> dict:
        return {
            "model": self.model,
            "prompt": prompt.text,
            "stop": prompt.stop_words or None,
            "max_tokens": self.max_tokens,
            "temperature": 0,
            "stream": False,
        }

    def handle_response(self, response: dict) -> str:
        choices = response.get("choices") or []
        if not choices:
            return ""
        choice = choices[0]
        # OpenAI legacy completions: {"text": ...}
        # Some compat servers tunnel through chat: {"message": {"content": ...}}
        if "text" in choice:
            return choice.get("text") or ""
        message = choice.get("message") or {}
        return message.get("content") or ""

    async def execute(self, request: dict) -> dict:
        resp = await self.client.post(
            self.endpoint(),
            headers=self.headers(),
            json=request,
        )
        resp.raise_for_status()
        return resp.json()

    async def complete(self, prompt: BuiltPrompt) -> str:
        request = self.build_request(prompt)
        response = await self.execute(request)
        return self.handle_response(response)

    @classmethod
    def from_config(
        cls,
        *,
        base_url: str,
        api_key: str,
        model: str,
        max_tokens: int,
        client: httpx.AsyncClient,
        **_ignored,
    ) -> "CompletionProvider":
        """Construct a provider from a flat config dict.

        The base implementation passes the five standard fields through.
        Providers with non-standard config (e.g. AWS Bedrock) override this
        entirely, extracting their own fields from **_ignored and raising
        descriptively for any missing required fields.
        """
        return cls(
            base_url=base_url,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
            client=client,
        )
