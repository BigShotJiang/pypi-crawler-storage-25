"""ProviderRegistry: maps a provider kind string to a CompletionProvider class.

Provider modules import this module to register themselves via
@ProviderRegistry.registry(). No provider module is imported here at the
top level, so there is no circular dependency.

Unlike ModelFamilyRegistry (which stores instances), ProviderRegistry stores
classes — providers are stateful and must be instantiated at call time with
runtime config via each class's from_config() classmethod.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cellsense.backend.providers.base import CompletionProvider


class ProviderRegistry:
    _auto_registered: list[tuple[type[CompletionProvider], list[str]]] = []

    def __init__(self) -> None:
        self._kinds: dict[str, type[CompletionProvider]] = {}

    @classmethod
    def add_to_registry(cls, *kinds: str):
        """Return a decorator that queues a provider class under the given kind strings.

        Usage:
            @ProviderRegistry.registry("ollama")
            class OllamaProvider(CompletionProvider): ...

            @ProviderRegistry.registry("openai", "openai_compatible")
            class OpenAICompatProvider(CompletionProvider): ...
        """
        if not kinds:
            raise ValueError("@ProviderRegistry.registry() requires at least one kind string.")
        def decorator(provider_cls: type[CompletionProvider]) -> type[CompletionProvider]:
            normalized = [k.lower().replace("-", "_") for k in kinds]
            cls._auto_registered.append((provider_cls, normalized))
            return provider_cls
        return decorator

    def _register(self, provider_cls: type[CompletionProvider], kinds: list[str]) -> None:
        for kind in kinds:
            self._kinds[kind] = provider_cls

    def get_class(self, kind: str) -> type[CompletionProvider]:
        normalized = kind.lower().replace("-", "_")
        provider_cls = self._kinds.get(normalized)
        if provider_cls is None:
            raise ValueError(
                f"Unknown provider kind: {kind!r}. "
                f"Registered kinds: {sorted(self._kinds)}"
            )
        return provider_cls

    def build(self, kind: str, **config) -> CompletionProvider:
        return self.get_class(kind).from_config(**config)


def default_provider_registry() -> ProviderRegistry:
    # Importing these modules executes their @ProviderRegistry.registry()
    # decorators, populating _auto_registered before we iterate below.
    from cellsense.backend.providers import anthropic, ollama  # noqa: F401

    registry = ProviderRegistry()
    for provider_cls, kinds in ProviderRegistry._auto_registered:
        registry._register(provider_cls, kinds)
    return registry
