"""Provider registry, factory, and re-exports."""
from __future__ import annotations

import httpx

from cellsense.backend.providers.anthropic import AnthropicProvider
from cellsense.backend.providers.base import CompletionProvider
from cellsense.backend.providers.ollama import OllamaProvider
from cellsense.backend.providers.openai_compatible import OpenAICompatProvider
from cellsense.backend.providers.registry import ProviderRegistry, default_provider_registry


def build_provider(
    *,
    kind: str,
    base_url: str,
    api_key: str,
    model: str,
    max_tokens: int,
    client: httpx.AsyncClient,
) -> CompletionProvider:
    return default_provider_registry().build(
        kind,
        base_url=base_url,
        api_key=api_key,
        model=model,
        max_tokens=max_tokens,
        client=client,
    )


__all__ = [
    "CompletionProvider",
    "OpenAICompatProvider",
    "OllamaProvider",
    "AnthropicProvider",
    "ProviderRegistry",
    "default_provider_registry",
    "build_provider",
]
