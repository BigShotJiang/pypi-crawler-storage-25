"""OpenAI-compatible provider — uses base defaults verbatim.

Covers any server exposing /v1/completions in the OpenAI legacy shape:
LM Studio, Groq, Fireworks, Mistral's hosted API, llama.cpp's server, vLLM, etc.
"""
from __future__ import annotations

from cellsense.backend.providers.base import CompletionProvider
from cellsense.backend.providers.registry import ProviderRegistry


@ProviderRegistry.add_to_registry("openai", "openai_compatible")
class OpenAICompatProvider(CompletionProvider):
    pass
