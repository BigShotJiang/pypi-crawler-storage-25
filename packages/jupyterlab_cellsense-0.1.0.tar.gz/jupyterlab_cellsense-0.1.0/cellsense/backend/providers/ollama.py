"""Ollama provider — Ollama exposes an OpenAI-compatible /v1/completions endpoint."""
from __future__ import annotations

from cellsense.backend.providers.base import CompletionProvider
from cellsense.backend.providers.registry import ProviderRegistry


@ProviderRegistry.add_to_registry("ollama")
class OllamaProvider(CompletionProvider):

    def endpoint(self) -> str:
        return f"{self.base_url}/api/generate"
    
    def build_request(self, prompt: BuiltPrompt) -> dict:
        request = super().build_request(prompt)
        request["raw"] = True
        request["options"] = {
            "num_predict": self.max_tokens,
            "temperature": 0,
        }
        return request
    
    def handle_response(self, response: dict) -> str:
        return response.get("response") or ""
