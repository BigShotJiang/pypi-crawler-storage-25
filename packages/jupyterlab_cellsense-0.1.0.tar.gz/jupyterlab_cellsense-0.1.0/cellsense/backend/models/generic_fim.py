"""GenericFIMCompletor: StarCoder-style FIM tokens. Used as the registry fallback.

StarCoderCompletor is a thin subclass that shares the same token layout but
registers under its own family prefix so Ollama tag strings like
``starcoder2:3b`` resolve correctly.
"""
from __future__ import annotations

from cellsense.backend.models.base import FIMTokens, ModelCompletor
from cellsense.backend.registry import ModelCompletorRegistry


class GenericFIMCompletor(ModelCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "generic_fim"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(
            prefix="<fim_prefix>",
            suffix="<fim_suffix>",
            middle="<fim_middle>",
        )    

@ModelCompletorRegistry.add_to_registry()
class StarCoderCompletor(GenericFIMCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "starcoder"

    def stop_words(self) -> list[str]:
        rv = super().stop_words()
        rv.extend(["<|endoftext|>", 
                "<fim_prefix>", "<fim_suffix>", "<fim_middle>", "<fim_pad>"
                "<file_sep>", "<repo_name>",
                "<jupyter_start>", "<jupyter_text>", "<jupyter_code>", "<jupyter_output>", "<jupyter_script>", "<empty_output>"])
        return rv

    def get_context_file_marker(self) -> str:
        return "<file_sep>"
    
    def build_signature_context_block(self, signatures: dict[str, str]) -> str:
        """Use <file_sep> token — in StarCoder2's training distribution."""
        if not signatures:
            return ""
        parts = []
        for filepath, content in signatures.items():
            parts.append(f"<file_sep>{filepath}\n{content}")
        return self.trim_context_to_budget("\n\n".join(parts) + "<file_sep>")


