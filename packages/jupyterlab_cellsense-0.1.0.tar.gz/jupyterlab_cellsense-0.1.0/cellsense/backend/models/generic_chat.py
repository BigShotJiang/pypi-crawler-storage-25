"""GenericChatCompletor: instruction-style FIM prompt for chat models.

Used as the registry fallback when no named completor matches. Formats the
prefix/suffix as a natural-language instruction that any instruction-finetuned
model can follow, unlike raw FIM tokens which require specific training.

post_process strips leading acknowledgement text that smaller or less-trained
models may emit before the actual code.
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from cellsense.backend.models.base import FIMTokens, BuiltPrompt, ModelCompletor

if TYPE_CHECKING:
    from cellsense.backend.prompt_builder import CompletionInputs

_ACK_LINE_RE = re.compile(
    r"^(sure|of course|certainly|here|i'll|i will|no problem|happy|let me|"
    r"the middle|below|to complete|absolutely|great)[^\n]*$",
    re.IGNORECASE,
)

_CODE_FENCE_RE = re.compile(r"```[^\n]*\n(.*?)```", re.DOTALL)


class GenericChatCompletor(ModelCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "generic_chat"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(prefix="", suffix="", middle="")

    def stop_words(self) -> list[str]:
        return ["\n\n", "\\n\\n"]

    def build_prompt(self, inputs: "CompletionInputs") -> BuiltPrompt:
        preamble = self.build_context(
            signatures=inputs.signatures,
            recent_context=inputs.context_chunks,
            retrieved_context=inputs.retrieved_chunks,
        )
        text = (
            f"{preamble}"
            f"Prefix: {inputs.prefix}\n"
            f"Middle: _______\n"
            f"Suffix: {inputs.suffix}\n\n"
            f"Complete the middle portion of the code. No acknowledgement needed"
        )
        return BuiltPrompt(text=text, stop_words=self.stop_words())

    def post_process(self, completion: str) -> str:
        # Prefer extracting content from a markdown code fence if present.
        fence_match = _CODE_FENCE_RE.search(completion)
        if fence_match:
            return fence_match.group(1).rstrip("\n")

        # Strip leading acknowledgement lines and surrounding blank lines.
        lines = completion.splitlines()
        start = 0
        for i, line in enumerate(lines):
            stripped = line.strip()
            if not stripped or _ACK_LINE_RE.match(stripped):
                start = i + 1
            else:
                break
        return "\n".join(lines[start:])
