"""CodeLlamaCompletor: <PRE>...<SUF>...<MID> tokens."""
from __future__ import annotations

from cellsense.backend.models.base import FIMTokens, ModelCompletor
from cellsense.backend.registry import ModelCompletorRegistry


@ModelCompletorRegistry.add_to_registry(patterns=["codellama", "code-llama"])
class CodeLlamaCompletor(ModelCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "codellama"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(prefix="<PRE>", suffix="<SUF>", middle="<MID>")

    def stop_words(self) -> list[str]:
        rv = super().stop_words()
        rv.extend(["<EOT>", "/s", "<MID>", "<PRE>", "<SUF>"])
        return rv
