"""DeepSeekCompletor: <｜fim▁begin｜>...<｜fim▁hole｜>...<｜fim▁end｜> tokens."""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from cellsense.backend.models.base import BuiltPrompt, FIMTokens, ModelCompletor
from cellsense.backend.registry import ModelCompletorRegistry

if TYPE_CHECKING:
    from cellsense.backend.prompt_builder import CompletionInputs


@ModelCompletorRegistry.add_to_registry()
class DeepSeekCompletor(ModelCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "deepseek"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(
            prefix="<｜fim▁begin｜>",
            suffix="<｜fim▁hole｜>",
            middle="<｜fim▁end｜>",
        )

    def stop_words(self) -> list[str]:
        rv = super().stop_words()
        rv.extend([
            "<｜eos_token｜>", "<|EOT|>", "<|end_of_sentence|>",
            "<｜fim▁begin｜>","<｜fim▁hole｜>","<｜fim▁end｜>"
        ])
        return rv
    
    def get_context_file_marker(self) -> str:
        return "# File:"

    def build_signature_context_block(self, signatures: dict[str, str]) -> str:
        if not signatures:
            return ""
        parts = []
        for filepath, content in signatures.items():
            filename = Path(filepath).name
            parts.append(f"# {filename}\n{content}")
        return self.trim_context_to_budget("\n\n".join(parts))

    def build_prompt(self, inputs: "CompletionInputs") -> BuiltPrompt:
        tokens = self.fim_tokens()
        current_file_path = inputs.file_path or "Current File"
        preamble = self.build_context(
            signatures=inputs.signatures,
            recent_context=inputs.context_chunks,
            retrieved_context=inputs.retrieved_chunks,
        )

        text = f"{preamble}\
            {self.get_context_file_marker()}{current_file_path}\n\
            {tokens.prefix}{inputs.prefix}{tokens.middle}{inputs.suffix}{tokens.suffix}"
        return BuiltPrompt(text=text, stop_words=self.stop_words())
