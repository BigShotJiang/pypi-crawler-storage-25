"""CodestralCompletor: Suffix-Prefix-Middle layout with [PREFIX] / [SUFFIX] tokens."""
from __future__ import annotations

from cellsense.backend.models.base import BuiltPrompt, FIMTokens, ModelCompletor
from cellsense.backend.prompt_builder import CompletionInputs
from cellsense.backend.registry import ModelCompletorRegistry


@ModelCompletorRegistry.add_to_registry()
class CodestralCompletor(ModelCompletor):
    @classmethod
    def get_model_family(cls) -> str:
        return "codestral"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(prefix="[PREFIX]", suffix="[SUFFIX]", middle="")

    def stop_words(self) -> list[str]:
        rv = super().stop_words()
        rv.extend(["[PREFIX]", "[SUFFIX]", "</s>"])
        return rv

    def build_prompt(self, inputs: CompletionInputs) -> BuiltPrompt:
        # Codestral's FIM training places the suffix before the prefix; the
        # model continues directly after [PREFIX]{prefix}.
        # Context block goes before [SUFFIX] as a separate synthetic file.
        tokens = self.fim_tokens()
        current_file_path = inputs.file_path or "Current File"
        preamble = self.build_context(
            signatures=inputs.signatures,
            recent_context=inputs.context_chunks,
            retrieved_context=inputs.retrieved_chunks,
        )

        text = f"{preamble}\
            {self.get_context_file_marker()}{current_file_path}\n\
            {tokens.suffix}{inputs.suffix}{tokens.prefix}{inputs.prefix}"
        return BuiltPrompt(text=text, stop_words=self.stop_words())
