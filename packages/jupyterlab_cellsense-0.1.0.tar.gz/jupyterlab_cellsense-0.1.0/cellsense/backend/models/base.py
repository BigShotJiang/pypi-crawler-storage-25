"""ModelCompletor abstract base — Template Method for FIM prompt construction.

The base class defines the structural contract every completor obeys
(``get_model_id``, ``get_model_family``, ``fim_tokens``, ``stop_words``,
``build_context_block``, ``build_prompt``) and provides a default
Prefix-Suffix-Middle (PSM) layout that covers StarCoder, DeepSeek,
CodeLlama, Qwen, etc. Completors that genuinely diverge — Codestral uses
Suffix-Prefix-Middle — override only ``build_prompt``.

``build_context_block`` converts extracted import signatures into the
model-family-specific context format that gets prepended before the FIM
tokens. Subclasses override it to use special tokens (e.g. ``<file_sep>``
for StarCoder/Codestral) that are in their training distribution.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from cellsense.backend.prompt_builder import CompletionInputs
    from cellsense.backend.context.assembler import FileContextBlock


@dataclass(frozen=True)
class FIMTokens:
    prefix: str
    suffix: str
    middle: str


@dataclass(frozen=True)
class BuiltPrompt:
    text: str
    stop_words: list[str]


_CONTEXT_BUDGET_CHARS = 2000  # ~500 tokens at 4 chars/token


class ModelCompletor(ABC):
    @classmethod
    def get_model_id(cls) -> str | None:
        return None

    @classmethod
    @abstractmethod
    def get_model_family(cls) -> str: ...

    @abstractmethod
    def fim_tokens(self) -> FIMTokens: ...

    def stop_words(self) -> list[str]:
        return ["\n\n", "\\n\\n", self.get_context_file_marker()]

    def build_signature_context_block(self, signatures: dict[str, str]) -> str:
        """Return a context block to prepend before the FIM tokens.

        Default: plain text comment blocks — safe fallback for CodeLlama and
        models without a file-sep special token.
        Subclasses override to use model-family-specific token formats.
        Returns empty string when signatures is empty.
        """
        if not signatures:
            return ""
        sections = []
        for filepath, content in signatures.items():
            header = f"# Signatures of {Path(filepath).name} (method bodies excluded)"
            sections.append(header + "\n\n" + content)
        return self.trim_context_to_budget("\n\n".join(sections))
    
    def trim_context_to_budget(self, text: str, max_chars: int = _CONTEXT_BUDGET_CHARS) -> str:
        """Trim text to a character budget as a rough token-count proxy.

        Prefers trimming at section (double-newline) boundaries so the surviving
        signatures remain syntactically complete.
        """
        if len(text) <= max_chars:
            return text
        truncated = text[:max_chars]
        last_section = truncated.rfind(self.get_context_file_marker())
        return truncated[:last_section]
    
    def build_file_context_block(self, blocks: 'List[FileContextBlock]') -> str:
        """Render multi-file context blocks using the same file separator as import signatures.

        Default: plain text with file headers — safe for all models.
        Subclasses may override to use model-specific tokens.
        """
        if not blocks:
            return ""
        parts = []
        for b in blocks:
            file_context = f"{self.get_context_file_marker()}{Path(b.path).name}"
            parts.append(f"{file_context}\n{b.text}")
        return "\n\n".join(parts)
    
    def build_context(
        self,
        signatures: dict[str, str],
        recent_context: 'List[FileContextBlock]',
        retrieved_context: 'List[FileContextBlock]',
    ) -> str:
        import_ctx = self.build_signature_context_block(signatures)
        recent_file_ctx = self.build_file_context_block(recent_context)
        retrieved_file_ctx = self.build_file_context_block(retrieved_context)

        preamble_parts = []
        if import_ctx:
            preamble_parts.append(import_ctx)
        if retrieved_file_ctx:
            preamble_parts.append(retrieved_file_ctx)
        if recent_file_ctx:
            preamble_parts.append(recent_file_ctx)

        context = "\n\n".join(preamble_parts)
        if context:
            context += "\n\n"
        return context

    def get_context_file_marker(self) -> str:
        return "# File:"

    def post_process(self, completion: str) -> str:
        return completion

    def build_prompt(self, inputs: "CompletionInputs") -> BuiltPrompt:
        tokens = self.fim_tokens()
        current_file_path = inputs.file_path or "Current File"
        preamble = self.build_context(
            signatures=inputs.signatures,
            recent_context=inputs.context_chunks,
            retrieved_context=inputs.retrieved_chunks,
        )

        text = f"{preamble}\
            {self.get_context_file_marker()}{current_file_path}\n\
                {tokens.prefix}{inputs.prefix}{tokens.suffix}{inputs.suffix}{tokens.middle}"
        return BuiltPrompt(text=text, stop_words=self.stop_words())
