'''
QwenCompletor uses Qwen2.5-Coder's distinct pipe-delimited FIM tokens
(``<|fim_prefix|>`` / ``<|fim_suffix|>`` / ``<|fim_middle|>``).
'''
from __future__ import annotations

from cellsense.backend.models.base import FIMTokens, ModelCompletor
from cellsense.backend.registry import ModelCompletorRegistry

@ModelCompletorRegistry.add_to_registry()
class QwenCompletor(ModelCompletor):


    @classmethod
    def get_model_family(cls) -> str:
        return "qwen"

    def fim_tokens(self) -> FIMTokens:
        return FIMTokens(
            prefix="<|fim_prefix|>",
            suffix="<|fim_suffix|>",
            middle="<|fim_middle|>",
        )

    def stop_words(self) -> list[str]:
        rv = super().stop_words()
        rv.extend(["<|endoftext|>", 
                "<|im_start|>","<|im_end|>", 
                "<|fim_prefix|>", "<|fim_suffix|>", "<|fim_pad|>",
                "<|repo_name|>", "<|file_sep|>"])
        return rv

    def get_context_file_marker(self) -> str:
        return "<|file_sep|>"

    def build_signature_context_block(self, signatures: dict[str, str]) -> str:
        if not signatures:
            return ""
        parts = []
        for filepath, content in signatures.items():
            parts.append(f"<|file_sep|>{filepath}\n{content}")
        return self.trim_context_to_budget("\n\n".join(parts))