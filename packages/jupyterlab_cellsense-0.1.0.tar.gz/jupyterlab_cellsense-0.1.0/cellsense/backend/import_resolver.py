"""Local import resolution.

Parses raw import strings and resolves them to workspace-local file paths.
Stdlib and third-party imports are silently skipped (not resolvable in workspace).

Resolution order:
  1. Relative imports (from . / from ..)
  2. workspace_root, workspace_root/src, notebook_directory
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ResolvedImport:
    """A workspace-local import resolved to a concrete file path."""
    file_path: Path
    module_name: str
    symbols: list[str]       # requested names; empty list = whole module
    wildcard: bool           # True for `from foo import *`
    aliases: dict[str, str]  # {local_name: source_name}


def module_to_parts(module: str) -> list[str]:
    """Split a dotted module name into path parts."""
    return module.split(".") if module else []


def find_module_file(base: Path, parts: list[str]) -> Path | None:
    """Locate .py or package __init__.py for a dotted module under base."""
    if not parts:
        init = base / "__init__.py"
        return init if init.is_file() else None
    path = base.joinpath(*parts)
    direct = path.with_suffix(".py")
    if direct.is_file():
        return direct
    pkg = path / "__init__.py"
    if pkg.is_file():
        return pkg
    return None


def find_reexport_source_file(
    module: str,
    source_sym: str,
    level: int,
    current_file: Path,
    candidate_roots: list[Path],
) -> Path | None:
    """Resolve the file that contains source_sym for a one-hop re-export."""
    if level > 0:
        base = current_file.parent
        for _ in range(level - 1):
            base = base.parent
        if module:
            return find_module_file(base, module_to_parts(module))
        # `from . import sym` — sym may itself be a submodule file
        return find_module_file(base, [source_sym])
    parts = module_to_parts(module)
    for root in candidate_roots:
        found = find_module_file(root, parts)
        if found:
            return found
    return None


def get_candidate_roots(workspace_root: str, file_path: str | None) -> list[Path]:
    """Return candidate source roots for module resolution."""
    ws = Path(workspace_root).resolve()
    src = ws / "src"
    roots: list[Path] = [ws, src]
    if file_path:
        nb_dir = Path(file_path).resolve().parent
        if nb_dir not in (ws, src):
            roots.append(nb_dir)
    return roots


def _parse_imports(raw: str) -> list[tuple[str, list[str], dict[str, str], bool, int]]:
    """Parse a raw import string into (module, symbols, aliases, wildcard, level) tuples."""
    try:
        tree = ast.parse(raw.strip())
    except SyntaxError:
        return []
    results = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            module = node.module or ""
            level = node.level or 0
            symbols: list[str] = []
            aliases: dict[str, str] = {}
            wildcard = False
            for alias in node.names:
                if alias.name == "*":
                    wildcard = True
                else:
                    symbols.append(alias.name)
                    if alias.asname:
                        aliases[alias.asname] = alias.name
            results.append((module, symbols, aliases, wildcard, level))
        elif isinstance(node, ast.Import):
            for alias in node.names:
                a: dict[str, str] = {alias.asname: alias.name} if alias.asname else {}
                results.append((alias.name, [], a, False, 0))
    return results


def _resolve_relative(
    level: int,
    module: str,
    symbols: list[str],
    aliases: dict[str, str],
    wildcard: bool,
    file_path: Path,
) -> list[ResolvedImport]:
    base = file_path.parent
    for _ in range(level - 1):
        base = base.parent

    if module:
        found = find_module_file(base, module_to_parts(module))
        if found is None:
            return []
        return [ResolvedImport(file_path=found, module_name=module,
                               symbols=symbols, wildcard=wildcard, aliases=aliases)]

    # `from . import X, Y` — each symbol may be a submodule
    results: list[ResolvedImport] = []
    leftover: list[str] = []
    for sym in symbols:
        submod = find_module_file(base, [sym])
        if submod:
            results.append(ResolvedImport(file_path=submod, module_name=sym,
                                          symbols=[], wildcard=False, aliases={}))
        else:
            leftover.append(sym)
    if leftover or wildcard:
        init = base / "__init__.py"
        if init.is_file():
            sub_aliases = {k: v for k, v in aliases.items() if v in leftover}
            results.append(ResolvedImport(file_path=init, module_name="",
                                          symbols=leftover, wildcard=wildcard,
                                          aliases=sub_aliases))
    return results


def _resolve_absolute(
    module: str,
    symbols: list[str],
    aliases: dict[str, str],
    wildcard: bool,
    candidate_roots: list[Path],
) -> list[ResolvedImport]:
    if not module:
        return []
    parts = module_to_parts(module)
    for root in candidate_roots:
        found = find_module_file(root, parts)
        if found:
            return [ResolvedImport(file_path=found, module_name=module,
                                   symbols=symbols, wildcard=wildcard, aliases=aliases)]
    return []


def resolve_local_imports(
    imports: list[str],
    workspace_root: str,
    file_path: str | None,
) -> list[ResolvedImport]:
    """Parse and resolve import strings; return only workspace-local imports.

    Stdlib and third-party imports are silently skipped — they are not
    resolvable under any of the candidate workspace source roots.
    """
    candidate_roots = get_candidate_roots(workspace_root, file_path)
    fp: Path | None = Path(file_path).resolve() if file_path else None

    resolved: list[ResolvedImport] = []
    for raw in imports:
        for module, symbols, aliases, wildcard, level in _parse_imports(raw):
            if level > 0:
                if fp is None:
                    continue
                resolved.extend(_resolve_relative(level, module, symbols, aliases, wildcard, fp))
            else:
                resolved.extend(_resolve_absolute(module, symbols, aliases, wildcard, candidate_roots))
    return resolved
