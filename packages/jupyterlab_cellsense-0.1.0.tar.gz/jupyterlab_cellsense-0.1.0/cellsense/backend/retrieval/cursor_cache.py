"""Cursor-position cache: skip BM25 when query context barely changed."""
from __future__ import annotations

import re
import threading

_OVERLAP_THRESHOLD = 0.75


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", text)


class CursorCache:
    def __init__(self) -> None:
        self._last_tokens: frozenset[str] = frozenset()
        self._last_ids: list[int] = []
        self._lock = threading.Lock()

    def get(self, query: str) -> list[int] | None:
        new_tokens = frozenset(_tokenize(query))
        with self._lock:
            old_tokens = self._last_tokens
            ids = self._last_ids
        if not old_tokens or not new_tokens:
            return None
        overlap = len(new_tokens & old_tokens) / max(len(new_tokens), len(old_tokens))
        return list(ids) if overlap >= _OVERLAP_THRESHOLD else None

    def put(self, query: str, ids: list[int]) -> None:
        tokens = frozenset(_tokenize(query))
        with self._lock:
            self._last_tokens = tokens
            self._last_ids = list(ids)
