"""Filesystem watcher: debounce changes and trigger partial BM25 rebuilds."""
from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Callable

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from cellsense.backend.retrieval.chunker import IGNORE_DIRS

if TYPE_CHECKING:
    from cellsense.backend.retrieval.bm25_retriever import BM25Retriever
    from cellsense.backend.retrieval.index_manager import IndexManager

log = logging.getLogger(__name__)

_DEBOUNCE_SECONDS = 2.0
_INDEXABLE_EXTS = {".py", ".ipynb"}


def _is_indexable(path: str) -> bool:
    return any(path.endswith(ext) for ext in _INDEXABLE_EXTS)


def _in_ignored_dir(path: str) -> bool:
    parts = path.replace("\\", "/").split("/")
    return any(p in IGNORE_DIRS for p in parts)


class WorkspaceWatcher(FileSystemEventHandler):
    def __init__(
        self,
        index_manager: "IndexManager",
        retriever: "BM25Retriever",
    ) -> None:
        super().__init__()
        self._index_manager = index_manager
        self._retriever = retriever
        self._dirty: set[str] = set()
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None

    def _schedule_flush(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
        self._timer = threading.Timer(_DEBOUNCE_SECONDS, self._flush)
        self._timer.daemon = True
        self._timer.start()

    def _add_dirty(self, path: str) -> None:
        if _in_ignored_dir(path):
            return
        if not _is_indexable(path):
            return
        with self._lock:
            self._dirty.add(path)
        self._schedule_flush()

    def on_modified(self, event) -> None:
        if event.is_directory:
            return
        self._add_dirty(event.src_path)

    def on_created(self, event) -> None:
        if event.is_directory:
            return
        self._add_dirty(event.src_path)

    def on_deleted(self, event) -> None:
        if event.is_directory:
            return
        self._add_dirty(event.src_path)

    def on_moved(self, event) -> None:
        if event.is_directory:
            return
        if _is_indexable(event.src_path):
            self._add_dirty(event.src_path)
        if _is_indexable(event.dest_path):
            self._add_dirty(event.dest_path)

    def _flush(self) -> None:
        with self._lock:
            paths = list(self._dirty)
            self._dirty.clear()

        if not paths:
            return

        from cellsense.backend.retrieval.chunker import chunk_file

        new_chunks = []
        for path in paths:
            try:
                new_chunks.extend(chunk_file(path, max_chunks=200))
            except Exception:
                log.exception("chunk_file failed for %s", path)

        try:
            self._index_manager.update_files(paths, new_chunks)
            rows = self._index_manager.load_all_chunks()
            self._retriever.build(rows)
        except Exception:
            log.exception("_flush failed during index update")


def start_watcher(
    workspace_root: str,
    index_manager: "IndexManager",
    retriever: "BM25Retriever",
) -> Observer:
    handler = WorkspaceWatcher(index_manager, retriever)
    observer = Observer()
    observer.schedule(handler, workspace_root, recursive=True)
    observer.daemon = True
    observer.start()
    return observer
