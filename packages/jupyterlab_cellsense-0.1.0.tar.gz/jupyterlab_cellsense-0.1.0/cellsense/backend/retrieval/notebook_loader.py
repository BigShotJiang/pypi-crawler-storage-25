"""Extract Python source from .ipynb notebooks."""
from __future__ import annotations

import json


def _clean_cell_source(src: str | list) -> str:
    if isinstance(src, list):
        src = "".join(src)
    cleaned = [
        line for line in src.splitlines()
        if not (line.lstrip() and line.lstrip()[0] in ("%", "!", "?"))
    ]
    return "\n".join(cleaned)


def load_notebook_cells(path: str) -> list[str] | None:
    """Return cleaned source for each code cell, or None on parse failure."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            nb = json.load(f)
    except Exception:
        return None

    return [
        _clean_cell_source(cell.get("source", ""))
        for cell in nb.get("cells", [])
        if cell.get("cell_type") == "code"
    ]


def load_notebook_as_source(path: str) -> str | None:
    cells = load_notebook_cells(path)
    if cells is None:
        return None
    parts: list[str] = []
    for idx, src in enumerate(cells):
        parts.append(f"# --- cell {idx} ---")
        parts.append(src)
    return "\n".join(parts)
