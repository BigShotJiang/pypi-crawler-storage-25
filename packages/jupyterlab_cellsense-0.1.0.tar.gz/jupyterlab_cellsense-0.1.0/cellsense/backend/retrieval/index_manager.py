"""SQLite-backed persistence layer for BM25 chunk index."""
from __future__ import annotations

import logging
import os
import sqlite3
import threading

from cellsense.backend.retrieval.chunker import Chunk

log = logging.getLogger(__name__)

_INDEX_DIR = ".plugin_index"
_DB_NAME = "index.db"
_SENTINEL = ".invalidate"


class IndexManager:
    def __init__(self, workspace_root: str) -> None:
        self._workspace_root = workspace_root
        self._index_dir = os.path.join(workspace_root, _INDEX_DIR)
        self._db_path = os.path.join(self._index_dir, _DB_NAME)
        self._conn: sqlite3.Connection | None = None
        self._write_lock = threading.Lock()

    def open(self) -> None:
        os.makedirs(self._index_dir, exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _init_schema(self) -> None:
        assert self._conn is not None
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS chunks (
                id           INTEGER PRIMARY KEY,
                file_path    TEXT NOT NULL,
                start_line   INTEGER,
                end_line     INTEGER,
                chunk_text   TEXT NOT NULL,
                chunk_type   TEXT,
                parent_class TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_chunks_file_path ON chunks(file_path);
            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT
            );
        """)
        self._conn.commit()

    def _get_meta(self, key: str) -> str | None:
        assert self._conn is not None
        row = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def _set_meta(self, key: str, value: str) -> None:
        assert self._conn is not None
        self._conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (key, value)
        )

    def needs_rebuild(self) -> tuple[bool, str]:
        assert self._conn is not None
        sentinel = os.path.join(self._index_dir, _SENTINEL)
        if os.path.exists(sentinel):
            os.remove(sentinel)
            return True, "external invalidation requested"

        status = self._get_meta("status")
        if status is None:
            return True, "no existing index"
        if status == "dirty":
            return True, "previous write did not complete cleanly"
        return False, ""

    def write_chunks(self, chunks: list[Chunk]) -> None:
        assert self._conn is not None
        with self._write_lock:
            self._set_meta("status", "dirty")
            self._conn.execute("DELETE FROM chunks")
            self._conn.executemany(
                "INSERT INTO chunks (file_path, start_line, end_line, chunk_text, chunk_type, parent_class) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                [
                    (c.file_path, c.start_line, c.end_line, c.chunk_text, c.chunk_type, c.parent_class)
                    for c in chunks
                ],
            )
            self._set_meta("status", "clean")
            import time
            self._set_meta("last_built", str(time.time()))
            self._conn.commit()

    def update_files(self, file_paths: list[str], new_chunks: list[Chunk]) -> None:
        if not file_paths and not new_chunks:
            return
        assert self._conn is not None
        with self._write_lock:
            if file_paths:
                placeholders = ",".join("?" * len(file_paths))
                self._conn.execute(
                    f"DELETE FROM chunks WHERE file_path IN ({placeholders})", file_paths
                )
            if new_chunks:
                self._conn.executemany(
                    "INSERT INTO chunks (file_path, start_line, end_line, chunk_text, chunk_type, parent_class) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    [
                        (c.file_path, c.start_line, c.end_line, c.chunk_text, c.chunk_type, c.parent_class)
                        for c in new_chunks
                    ],
                )
            self._conn.commit()

    def load_all_chunks(self) -> list[tuple[int, str]]:
        assert self._conn is not None
        rows = self._conn.execute("SELECT id, chunk_text FROM chunks").fetchall()
        return [(r[0], r[1]) for r in rows]

    def fetch_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        assert self._conn is not None
        placeholders = ",".join("?" * len(ids))
        rows = self._conn.execute(
            f"SELECT id, file_path, start_line, end_line, chunk_text, chunk_type, parent_class "
            f"FROM chunks WHERE id IN ({placeholders})",
            ids,
        ).fetchall()
        return [dict(r) for r in rows]
