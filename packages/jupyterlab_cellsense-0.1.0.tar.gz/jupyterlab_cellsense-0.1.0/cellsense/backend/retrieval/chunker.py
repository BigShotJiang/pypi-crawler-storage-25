"""AST-based chunker for .py and .ipynb files.

Chunk types:
  'function'     — top-level function or async function
  'method'       — method inside a class
  'module_scope' — non-function/class code at module level
  'cell'         — merged/split notebook cell content (non-functional code)
"""
from __future__ import annotations

import ast
import logging
import os
from dataclasses import dataclass

import pathspec

from cellsense.backend.retrieval.notebook_loader import load_notebook_cells

log = logging.getLogger(__name__)

IGNORE_DIRS = {
    ".git", "__pycache__", ".venv", "venv", "env", "node_modules",
    ".tox", "dist", "build", "eggs", ".eggs", ".plugin_index",
}

MIN_MODULE_LINES = 3   # minimum non-blank lines to emit a module_scope chunk
MIN_CELL_LINES = 5     # minimum non-blank lines before merging with adjacent segment
MAX_CELL_LINES = 60    # maximum lines per cell chunk before splitting


@dataclass
class Chunk:
    file_path: str
    start_line: int
    end_line: int
    chunk_text: str
    chunk_type: str          # 'function' | 'method' | 'module_scope' | 'cell'
    parent_class: str | None


def _non_blank(lines: list[str]) -> int:
    return sum(1 for ln in lines if ln.strip())


def _extract_py_chunks(
    source: str,
    file_path: str,
    max_chunks: int,
    line_offset: int = 0,
) -> tuple[list[Chunk], set[int]]:
    """Extract function/method chunks from source. Returns (chunks, covered_1-indexed_line_nos)."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return [], set()

    lines = source.splitlines()
    chunks: list[Chunk] = []
    covered: set[int] = set()

    for node in ast.iter_child_nodes(tree):
        if len(chunks) >= max_chunks:
            break
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for ln in range(node.lineno, node.end_lineno + 1):
                covered.add(ln)
            text = "\n".join(lines[node.lineno - 1: node.end_lineno])
            chunks.append(Chunk(
                file_path=file_path,
                start_line=node.lineno + line_offset,
                end_line=node.end_lineno + line_offset,
                chunk_text=text,
                chunk_type="function",
                parent_class=None,
            ))
        elif isinstance(node, ast.ClassDef):
            for ln in range(node.lineno, node.end_lineno + 1):
                covered.add(ln)
            class_name = node.name
            for child in node.body:
                if len(chunks) >= max_chunks:
                    break
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = "\n".join(lines[child.lineno - 1: child.end_lineno])
                    text = f"# In class: {class_name}\n" + text
                    chunks.append(Chunk(
                        file_path=file_path,
                        start_line=child.lineno + line_offset,
                        end_line=child.end_lineno + line_offset,
                        chunk_text=text,
                        chunk_type="method",
                        parent_class=class_name,
                    ))

    return chunks, covered


def _module_scope_chunks(source: str, file_path: str, covered: set[int]) -> list[Chunk]:
    """Collect contiguous uncovered lines as module_scope chunks."""
    lines = source.splitlines()
    chunks: list[Chunk] = []
    run: list[str] = []
    run_start: int | None = None

    def flush(end_lineno: int) -> None:
        if run and _non_blank(run) >= MIN_MODULE_LINES:
            chunks.append(Chunk(
                file_path=file_path,
                start_line=run_start,  # type: ignore[arg-type]
                end_line=end_lineno,
                chunk_text="\n".join(run),
                chunk_type="module_scope",
                parent_class=None,
            ))

    for i, line in enumerate(lines, start=1):
        if i in covered:
            flush(i - 1)
            run = []
            run_start = None
        else:
            if run_start is None:
                run_start = i
            run.append(line)

    flush(len(lines))
    return chunks


def _emit_cell_chunks(
    segments: list[tuple[int, list[str]]],
    file_path: str,
) -> list[Chunk]:
    """Merge short segments and split long ones into 'cell' chunks."""
    chunks: list[Chunk] = []
    pending_lines: list[str] = []
    pending_start: int | None = None

    def flush_pending() -> None:
        if pending_lines and _non_blank(pending_lines) > 0:
            chunks.append(Chunk(
                file_path=file_path,
                start_line=pending_start,  # type: ignore[arg-type]
                end_line=pending_start + len(pending_lines) - 1,  # type: ignore[operator]
                chunk_text="\n".join(pending_lines),
                chunk_type="cell",
                parent_class=None,
            ))

    def emit_lines(start: int, lns: list[str]) -> None:
        for i in range(0, len(lns), MAX_CELL_LINES):
            sub = lns[i: i + MAX_CELL_LINES]
            if _non_blank(sub) > 0:
                chunks.append(Chunk(
                    file_path=file_path,
                    start_line=start + i,
                    end_line=start + i + len(sub) - 1,
                    chunk_text="\n".join(sub),
                    chunk_type="cell",
                    parent_class=None,
                ))

    for seg_start, seg_lines in segments:
        if _non_blank(seg_lines) < MIN_CELL_LINES:
            if pending_start is None:
                pending_start = seg_start
            pending_lines.extend(seg_lines)
        else:
            if pending_lines:
                flush_pending()
                pending_lines = []
                pending_start = None
            if len(seg_lines) > MAX_CELL_LINES:
                emit_lines(seg_start, seg_lines)
            else:
                chunks.append(Chunk(
                    file_path=file_path,
                    start_line=seg_start,
                    end_line=seg_start + len(seg_lines) - 1,
                    chunk_text="\n".join(seg_lines),
                    chunk_type="cell",
                    parent_class=None,
                ))

    if pending_lines:
        flush_pending()

    return chunks


def _chunk_notebook(file_path: str, max_chunks: int) -> list[Chunk]:
    cells = load_notebook_cells(file_path)
    if cells is None:
        return []

    chunks: list[Chunk] = []
    cell_segments: list[tuple[int, list[str]]] = []
    line_offset = 0  # cumulative lines seen (separator comment counts as 1)

    for cell_src in cells:
        cell_lines = cell_src.splitlines()
        # +1 to skip the separator comment line
        cell_base = line_offset + 1

        func_chunks, covered = _extract_py_chunks(
            cell_src, file_path, max_chunks - len(chunks), line_offset=cell_base - 1
        )
        chunks.extend(func_chunks)

        # Collect non-function lines as a cell segment
        non_func: list[str] = []
        seg_start: int | None = None
        for i, line in enumerate(cell_lines, start=1):
            if i not in covered:
                if seg_start is None:
                    seg_start = cell_base + i - 1
                non_func.append(line)

        if non_func and _non_blank(non_func) > 0:
            cell_segments.append((seg_start or cell_base, non_func))

        line_offset = cell_base + len(cell_lines)

    chunks.extend(_emit_cell_chunks(cell_segments, file_path))
    return chunks


def chunk_file(file_path: str, max_chunks: int) -> list[Chunk]:
    if file_path.endswith(".ipynb"):
        return _chunk_notebook(file_path, max_chunks)

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        return []
    except Exception:
        return []

    func_chunks, covered = _extract_py_chunks(source, file_path, max_chunks)
    chunks = list(func_chunks)

    if len(chunks) < max_chunks:
        chunks.extend(_module_scope_chunks(source, file_path, covered))

    return chunks[:max_chunks]


def walk_workspace(
    workspace_root: str,
    max_files: int,
    max_chunks_per_file: int,
) -> list[Chunk]:
    gitignore_path = os.path.join(workspace_root, ".gitignore")
    spec = None
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            spec = pathspec.PathSpec.from_lines("gitwildmatch", f)

    all_chunks: list[Chunk] = []
    files_visited = 0

    for dirpath, dirnames, filenames in os.walk(workspace_root):
        dirnames[:] = [
            d for d in dirnames
            if d not in IGNORE_DIRS and not d.startswith(".")
        ]

        for fname in filenames:
            if not (fname.endswith(".py") or fname.endswith(".ipynb")):
                continue

            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, workspace_root)

            if spec and spec.match_file(rel_path):
                continue

            if files_visited >= max_files:
                log.warning(
                    "BM25 indexer hit MAX_FILES_TO_INDEX=%d; remaining files will not be indexed.",
                    max_files,
                )
                return all_chunks

            files_visited += 1
            all_chunks.extend(chunk_file(full_path, max_chunks_per_file))

    return all_chunks
