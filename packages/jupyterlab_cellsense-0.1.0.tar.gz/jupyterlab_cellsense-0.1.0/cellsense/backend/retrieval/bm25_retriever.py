"""In-memory BM25 index over chunk corpus."""
from __future__ import annotations

import logging
import re
import threading

from rank_bm25 import BM25Okapi

log = logging.getLogger(__name__)


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", text)


class BM25Retriever:
    def __init__(self) -> None:
        self._bm25: BM25Okapi | None = None
        self._id_map: list[int] = []
        self._lock = threading.Lock()

    def build(self, rows: list[tuple[int, str]]) -> None:
        if not rows:
            with self._lock:
                self._bm25 = None
                self._id_map = []
            return
        tokenized = [tokenize(text) for _, text in rows]
        id_map = [row_id for row_id, _ in rows]
        bm25 = BM25Okapi(tokenized)
        with self._lock:
            self._bm25 = bm25
            self._id_map = id_map

    def query(self, text: str, top_k: int = 3) -> list[int]:
        with self._lock:
            bm25 = self._bm25
            id_map = list(self._id_map)

        if bm25 is None:
            return []

        tokens = tokenize(text)
        if not tokens:
            return []

        try:
            scores = bm25.get_scores(tokens)
            top_n = min(top_k, len(id_map))
            indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_n]
            return [id_map[i] for i in indices]
        except Exception:
            log.exception("BM25 query failed")
            return []
