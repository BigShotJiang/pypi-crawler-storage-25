"""Wires together all retrieval components at plugin startup."""
from __future__ import annotations

import logging
import os
import shutil
import threading
from typing import Any, List

from cellsense.backend.context.assembler import FileContextBlock
from cellsense.backend.retrieval.bm25_retriever import BM25Retriever
from cellsense.backend.retrieval.chunker import walk_workspace
from cellsense.backend.retrieval.cursor_cache import CursorCache
from cellsense.backend.retrieval.index_manager import IndexManager
from cellsense.backend.retrieval.query_builder import build_query
from cellsense.backend.retrieval.watcher import start_watcher

log = logging.getLogger(__name__)

_index_manager: IndexManager | None = None
_retriever: BM25Retriever | None = None
_cursor_cache: CursorCache | None = None
_ready: bool = False
_observer = None


def ensure_gitignore(workspace_root: str) -> None:
    gitignore = os.path.join(workspace_root, ".gitignore")
    entry = ".plugin_index/\n"
    if os.path.exists(gitignore):
        with open(gitignore, "r", encoding="utf-8") as f:
            content = f.read()
        if ".plugin_index/" not in content:
            with open(gitignore, "a", encoding="utf-8") as f:
                f.write(entry)
    else:
        with open(gitignore, "w", encoding="utf-8") as f:
            f.write(entry)


def _build_index(workspace_root: str, config: dict[str, Any]) -> None:
    global _ready, _observer
    try:
        assert _index_manager is not None
        assert _retriever is not None

        rebuild_needed, reason = _index_manager.needs_rebuild()
        if rebuild_needed:
            log.info("Building workspace index: %s", reason)
            chunks = walk_workspace(
                workspace_root,
                max_files=config["MAX_FILES_TO_INDEX"],
                max_chunks_per_file=config["MAX_CHUNKS_PER_FILE"],
            )
            _index_manager.write_chunks(chunks)
            log.info("Index built: %d chunks", len(chunks))
        else:
            log.info("Loading existing index from db")

        rows = _index_manager.load_all_chunks()
        _retriever.build(rows)
        _ready = True

        _observer = start_watcher(workspace_root, _index_manager, _retriever)
    except Exception:
        log.exception("Retrieval initialization failed; completions will skip retrieval")


def initialize_retrieval(workspace_root: str, config: dict[str, Any]) -> None:
    global _index_manager, _retriever, _cursor_cache

    _index_manager = IndexManager(workspace_root)
    _index_manager.open()
    ensure_gitignore(workspace_root)

    _retriever = BM25Retriever()
    _cursor_cache = CursorCache()

    t = threading.Thread(target=_build_index, args=(workspace_root, config), daemon=True)
    t.start()


def shutdown_retrieval() -> None:
    global _observer, _index_manager
    if _observer is not None:
        try:
            _observer.stop()
            _observer.join(timeout=2.0)
        except Exception:
            log.exception("Error stopping observer")
    if _index_manager is not None:
        try:
            _index_manager.close()
        except Exception:
            log.exception("Error closing index manager")


def on_plugin_uninstall(workspace_root: str) -> None:
    index_dir = os.path.join(workspace_root, ".plugin_index")
    if os.path.exists(index_dir):
        shutil.rmtree(index_dir)


def get_retrieved_context(prefix: str, suffix: str, config: dict[str, Any]) -> List[FileContextBlock]:
    global _ready, _index_manager, _retriever, _cursor_cache
    try:
        if not _ready:
            return []

        query = build_query(prefix, suffix)
        if not query:
            return []

        assert _cursor_cache is not None
        ids = _cursor_cache.get(query)
        if ids is None:
            assert _retriever is not None
            ids = _retriever.query(query, top_k=config["TOP_K_CHUNKS"])
            _cursor_cache.put(query, ids)

        if not ids:
            return []

        assert _index_manager is not None
        chunks = _index_manager.fetch_by_ids(ids)
        if not chunks:
            return []

        workspace_root = config.get("WORKSPACE_ROOT", "")
        budget = config["RETRIEVED_CONTEXT_TOKEN_BUDGET"]
        running_tokens = 0
        blocks: List[FileContextBlock] = []

        for chunk in chunks:
            rel = os.path.relpath(chunk["file_path"], start=workspace_root) if workspace_root else chunk["file_path"]
            text = chunk["chunk_text"]
            block_tokens = len(text) // 4

            if running_tokens == 0:
                # Always include first chunk, truncating if necessary
                if block_tokens > budget:
                    text = text[: budget * 4]
                blocks.append(FileContextBlock(
                    path=rel,
                    signal="retrieved",
                    text=text,
                    start_line=chunk["start_line"],
                    end_line=chunk["end_line"],
                    cell_index=None,
                ))
                running_tokens += len(text) // 4
            else:
                if running_tokens + block_tokens > budget:
                    break
                blocks.append(FileContextBlock(
                    path=rel,
                    signal="retrieved",
                    text=text,
                    start_line=chunk["start_line"],
                    end_line=chunk["end_line"],
                    cell_index=None,
                ))
                running_tokens += block_tokens

        log.debug("Retrieved %d chunks for completion", len(blocks))
        return blocks
    except Exception:
        log.exception("get_retrieved_context failed")
        return []
