"""Build the BM25 query string from cursor prefix and suffix."""
from __future__ import annotations


def build_query(
    prefix: str,
    suffix: str,
    prefix_lines: int = 15,
    suffix_lines: int = 5,
) -> str:

    prefix_window_lines = prefix.splitlines()[-prefix_lines:] if prefix else []
    prefix_window = "\n".join(prefix_window_lines)

    suffix_window_lines = suffix.splitlines()[:suffix_lines] if suffix else []
    suffix_window = "\n".join(suffix_window_lines)

    parts = [p for p in (prefix_window, suffix_window) if p]
    return "\n".join(parts)
