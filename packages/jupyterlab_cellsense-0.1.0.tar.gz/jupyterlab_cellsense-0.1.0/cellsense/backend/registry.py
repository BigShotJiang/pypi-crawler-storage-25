"""ModelFamilyRegistry: maps a model identifier string to a ModelCompletor.

Lookup order, per design:
  1. Exact match on the configured model name (via ``get_model_id``).
  2. Longest substring match among registered family patterns (via
     ``get_model_family``). Patterns are sorted by length descending so the
     most specific match wins. Required because Ollama tags include version
     suffixes like ``deepseek-coder:6.7b`` or ``codestral:22b-v0.1-q4_K_M``.
  3. Fallback to ``GenericFIMCompletor`` so unrecognised models degrade
     gracefully rather than erroring.

Classes decorated with ``@ModelFamilyRegistry.registry()`` are auto-registered
when their module is first imported. ``default_registry()`` triggers those
imports and builds a ready-to-use registry.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cellsense.backend.models.base import ModelCompletor


class ModelCompletorRegistry:
    _auto_registered: list[tuple[type[ModelCompletor], list[str] | None]] = []

    def __init__(self, fallback: "ModelCompletor") -> None:
        self._exact: dict[str, ModelCompletor] = {}
        self._patterns: list[tuple[str, ModelCompletor]] = []
        self._fallback = fallback

    @classmethod
    def add_to_registry(cls, patterns: list[str] | None = None):
        """Return a decorator that queues a ModelCompletor subclass for registration."""
        def decorator(completor_cls: type[ModelCompletor]):
            cls._auto_registered.append((completor_cls, patterns))
            return completor_cls
        return decorator

    def _register(self, completor: "ModelCompletor", patterns: list[str] | None = None) -> None:
        model_id = completor.get_model_id()
        if model_id is not None:
            self._exact[model_id] = completor
            return
        entries = patterns if patterns is not None else [completor.get_model_family()]
        for p in entries:
            self._patterns.append((p.lower(), completor))

    def get(self, model_id: str | None) -> "ModelCompletor":
        if not model_id:
            return self._fallback
        if model_id in self._exact:
            return self._exact[model_id]
        lower = model_id.lower()
        for pattern, completor in self._patterns:
            if pattern in lower:
                return completor
        return self._fallback


def default_registry() -> ModelCompletorRegistry:
    # Importing these modules executes their @ModelFamilyRegistry.registry()
    # decorators, populating _auto_registered before we iterate it below.
    from cellsense.backend.models import codestral, deepseek, codellama, generic_fim, qwen, generic_chat  # noqa: F401
    from cellsense.backend.models.generic_chat import GenericChatCompletor

    registry = ModelCompletorRegistry(fallback=GenericChatCompletor())
    for completor_cls, patterns in ModelCompletorRegistry._auto_registered:
        registry._register(completor_cls(), patterns)
    # Longest pattern first so get() returns the most specific match on first hit.
    registry._patterns.sort(key=lambda t: len(t[0]), reverse=True)
    return registry
