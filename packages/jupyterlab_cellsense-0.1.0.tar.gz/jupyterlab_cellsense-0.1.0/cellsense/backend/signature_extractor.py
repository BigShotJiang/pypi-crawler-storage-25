"""AST-based signature extraction for locally resolved imports.

Uses the Python ast module only — no runtime execution, no importlib.
Extracts function/class signatures with type hints and docstrings.
Performs one-hop re-export traversal.
"""
from __future__ import annotations

import ast
from pathlib import Path

from cellsense.backend.import_resolver import (
    ResolvedImport,
    find_module_file,
    find_reexport_source_file,
    module_to_parts,
)


def _annotation_str(node: ast.expr | None) -> str:
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return ""


def _args_str(args: ast.arguments, skip_implicit_self: bool = False) -> str:
    """Format an argument list, optionally skipping the leading self/cls."""
    all_pos = args.posonlyargs + args.args
    n_pos = len(all_pos)
    n_defaults = len(args.defaults)
    default_start = n_pos - n_defaults
    n_posonlyargs = len(args.posonlyargs)

    start_idx = 0
    if skip_implicit_self and all_pos and all_pos[0].arg in ("self", "cls"):
        start_idx = 1

    parts: list[str] = []
    for i in range(start_idx, n_pos):
        arg = all_pos[i]
        ann = _annotation_str(arg.annotation)
        argstr = f"{arg.arg}: {ann}" if ann else arg.arg
        if i >= default_start:
            try:
                default_str = ast.unparse(args.defaults[i - default_start])
            except Exception:
                default_str = "..."
            argstr = f"{argstr} = {default_str}"
        parts.append(argstr)
        # Insert / separator after the last positional-only arg (if still visible)
        if i == n_posonlyargs - 1 and n_posonlyargs > 0 and i >= start_idx:
            parts.append("/")

    if args.vararg:
        ann = _annotation_str(args.vararg.annotation)
        parts.append(f"*{args.vararg.arg}" + (f": {ann}" if ann else ""))
    elif args.kwonlyargs:
        parts.append("*")

    for i, arg in enumerate(args.kwonlyargs):
        ann = _annotation_str(arg.annotation)
        argstr = f"{arg.arg}: {ann}" if ann else arg.arg
        kw_default = args.kw_defaults[i]
        if kw_default is not None:
            try:
                default_str = ast.unparse(kw_default)
            except Exception:
                default_str = "..."
            argstr = f"{argstr} = {default_str}"
        parts.append(argstr)

    if args.kwarg:
        ann = _annotation_str(args.kwarg.annotation)
        parts.append(f"**{args.kwarg.arg}" + (f": {ann}" if ann else ""))

    return ", ".join(parts)


def _first_docline(body: list[ast.stmt]) -> str | None:
    """Return the first non-empty line of a docstring, if present."""
    if (body and isinstance(body[0], ast.Expr) and
            isinstance(body[0].value, ast.Constant) and
            isinstance(body[0].value.value, str)):
        doc = body[0].value.value.strip()
        first = doc.split("\n")[0].strip()
        return first if first else None
    return None


_SHOW_DUNDER = frozenset({
    "__init__", "__call__",
    "__getitem__", "__setitem__", "__delitem__",
    "__len__", "__contains__",
    "__enter__", "__exit__",
    "__iter__", "__next__",
})


def _format_func(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    indent: str = "",
    is_method: bool = False,
) -> str:
    args = _args_str(node.args, skip_implicit_self=is_method)
    sig = f"{indent}{node.name}({args})"
    if node.returns:
        sig += f" -> {_annotation_str(node.returns)}"
    doc = _first_docline(node.body)
    if doc:
        sig += f'\n{indent}    """{doc}"""'
    return sig


def _format_class(node: ast.ClassDef, indent: str = "") -> str:
    lines = [f"{indent}class {node.name}:"]
    doc = _first_docline(node.body)
    if doc:
        lines.append(f'{indent}    """{doc}"""')
    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not item.name.startswith("_") or item.name in _SHOW_DUNDER:
                lines.append(_format_func(item, indent=indent + "    ", is_method=True))
    if len(lines) == 1 + (1 if doc else 0):
        lines.append(f"{indent}    ...")
    return "\n".join(lines)


def _get_all(tree: ast.Module) -> list[str] | None:
    """Return __all__ if defined at module level, else None."""
    for node in tree.body:
        if (isinstance(node, ast.Assign) and
                len(node.targets) == 1 and
                isinstance(node.targets[0], ast.Name) and
                node.targets[0].id == "__all__" and
                isinstance(node.value, (ast.List, ast.Tuple))):
            return [
                elt.value for elt in node.value.elts
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
            ]
    return None


def _public_names(tree: ast.Module) -> list[str]:
    """Collect all non-underscore top-level definition names."""
    names: list[str] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not node.name.startswith("_"):
                names.append(node.name)
        elif isinstance(node, ast.ClassDef):
            if not node.name.startswith("_"):
                names.append(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and not target.id.startswith("_"):
                    names.append(target.id)
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and not node.target.id.startswith("_"):
                names.append(node.target.id)
    return names


def _find_definition(tree: ast.Module, name: str) -> ast.stmt | None:
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
        if isinstance(node, ast.ClassDef) and node.name == name:
            return node
    return None


def _find_reexport(
    tree: ast.Module,
    name: str,
    current_file: Path,
    candidate_roots: list[Path],
) -> tuple[Path, str] | None:
    """One-hop: return (source_file, source_symbol) if name is re-exported here."""
    for node in tree.body:
        if not isinstance(node, ast.ImportFrom):
            continue
        for alias in node.names:
            local = alias.asname or alias.name
            if local != name:
                continue
            src_sym = alias.name
            src_file = find_reexport_source_file(
                module=node.module or "",
                source_sym=src_sym,
                level=node.level or 0,
                current_file=current_file,
                candidate_roots=candidate_roots,
            )
            if src_file:
                return src_file, src_sym
    return None


def _extract_name_sig(
    tree: ast.Module,
    name: str,
    file_path: Path,
    candidate_roots: list[Path],
    indent: str = "",
) -> str | None:
    """Extract the signature for name, following one hop of re-export if needed."""
    node = _find_definition(tree, name)

    if node is None:
        reexport = _find_reexport(tree, name, file_path, candidate_roots)
        if reexport:
            src_file, src_sym = reexport
            try:
                src_tree = ast.parse(src_file.read_text(encoding="utf-8", errors="replace"))
                node = _find_definition(src_tree, src_sym)
            except (OSError, SyntaxError):
                pass

    if node is None:
        return None
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return _format_func(node, indent=indent)
    if isinstance(node, ast.ClassDef):
        return _format_class(node, indent=indent)
    return None


def _load_tree(file_path: Path) -> ast.Module | None:
    try:
        return ast.parse(file_path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, SyntaxError):
        return None


def build_signatures_context(
    resolved_imports: list[ResolvedImport],
    candidate_roots: list[Path],
) -> dict[str, str]:
    """Build a map of file_path → stringified signatures from resolved local imports.

    Groups multiple imports from the same file into a single entry.
    Returns an empty dict if no local signatures could be extracted.
    """
    if not resolved_imports:
        return {}

    # Deduplicate: group symbols by file, preserving first-seen order.
    groups: dict[Path, tuple[list[str], bool]] = {}
    for ri in resolved_imports:
        if ri.file_path not in groups:
            groups[ri.file_path] = (list(ri.symbols), ri.wildcard)
        else:
            existing_syms, existing_wc = groups[ri.file_path]
            merged = existing_syms + [s for s in ri.symbols if s not in existing_syms]
            groups[ri.file_path] = (merged, existing_wc or ri.wildcard)

    result: dict[str, str] = {}
    for file_path, (symbols, wildcard) in groups.items():
        tree = _load_tree(file_path)
        if tree is None:
            continue

        if wildcard or not symbols:
            target_names = _get_all(tree) or _public_names(tree)
        else:
            target_names = symbols

        sigs: list[str] = []
        for name in target_names:
            sig = _extract_name_sig(tree, name, file_path, candidate_roots)
            if sig:
                sigs.append(sig)

        if sigs:
            result[str(file_path)] = "\n\n".join(sigs)

    return result
