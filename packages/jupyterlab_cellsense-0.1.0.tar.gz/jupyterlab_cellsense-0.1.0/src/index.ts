import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin,
  ILabShell
} from '@jupyterlab/application';

import { ICommandPalette, MainAreaWidget } from '@jupyterlab/apputils';
import { LabIcon } from '@jupyterlab/ui-components';
import { ICompletionProviderManager } from '@jupyterlab/completer';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { IEditorTracker } from '@jupyterlab/fileeditor';
import { INotebookTracker } from '@jupyterlab/notebook';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { CellSenseProvider } from './provider';
import { CellSenseSettingsWidget, CellSenseSettingsSidebarWidget } from './settings_widget';
import { postConfig } from './client';
import { FileTracker } from './tracker/FileTracker';
import { IFileTracker } from './tracker/token';

const PLUGIN_ID = 'jupyterlab-cellsense:plugin';

// JupyterLab inline-completer icon with a 4-point AI sparkle at top-right
const cellSenseIcon = new LabIcon({
  name: 'jupyterlab-cellsense:icon',
  svgstr: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-icon="completer:inline">
    <g transform="translate(0, 4) scale(0.75)">
      <path class="jp-icon4" fill="#bbbbbb" d="M17 15H3v2h14v-2Zm0-8h-6v2h6V7ZM3 13h18v-2H3v2Zm0 8h18v-2H3v2Z"/>
      <path class="jp-icon1" fill="#616161" d="M3 3v2h18V3H3ZM3 7v2h8V7H3Z"/>
    </g>
    <path class="jp-icon1" fill="#616161" d="M19.5 2.25L20.25 4.5L22.5 5.25L20.25 6L19.5 8.25L18.75 6L16.5 5.25L18.75 4.5Z"/>
  </svg>`,
});

const trackerPlugin: JupyterFrontEndPlugin<IFileTracker> = {
  id: 'jupyterlab-cellsense:file-tracker',
  autoStart: true,
  requires: [ILabShell, INotebookTracker, IEditorTracker],
  provides: IFileTracker,
  activate: (
    _app: JupyterFrontEnd,
    labShell: ILabShell,
    notebookTracker: INotebookTracker,
    editorTracker: IEditorTracker
  ): IFileTracker => {
    return new FileTracker({ labShell, notebookTracker, editorTracker });
  }
};

const plugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  description: 'FIM ghost-text inline completion for JupyterLab',
  autoStart: true,
  requires: [ICompletionProviderManager, IFileTracker, IDocumentManager],
  optional: [ISettingRegistry, ICommandPalette],
  activate: (
    app: JupyterFrontEnd,
    completionManager: ICompletionProviderManager,
    fileTracker: IFileTracker,
    docManager: IDocumentManager,
    settingRegistry: ISettingRegistry | null,
    palette: ICommandPalette | null
  ) => {
    const provider = new CellSenseProvider(fileTracker, docManager);
    completionManager.registerInlineProvider(provider);

    if (!settingRegistry) return;

    settingRegistry
      .load(PLUGIN_ID)
      .then(settings => {
        const apply = () => {
          const c = settings.get('completion').composite as {
            debounce_ms?: number;
            max_context_tokens?: number;
          };
          provider.updateSettings(
            c?.debounce_ms ?? 500,
            c?.max_context_tokens ?? 1500
          );

          applyProviderConfig(settings);
        };
        apply();
        settings.changed.connect(apply);

        const sidebar = new CellSenseSettingsSidebarWidget(settings);
        sidebar.id = 'jupyterlab-cellsense-settings-sidebar';
        sidebar.title.icon = cellSenseIcon;
        app.shell.add(sidebar, 'left', { rank: 600 });

        app.commands.addCommand('jupyterlab-cellsense:open-settings', {
          label: 'CellSense Settings',
          execute: () => {
            const widget = new CellSenseSettingsWidget(settings);
            const main = new MainAreaWidget({ content: widget });
            app.shell.add(main, 'main');
            app.shell.activateById(main.id);
          }
        });

        if (palette) {
          palette.addItem({
            command: 'jupyterlab-cellsense:open-settings',
            category: 'CellSense'
          });
        }
      })
      .catch(reason => {
        console.error('[CellSense] Failed to load settings:', reason);
      });
  }
};

function applyProviderConfig(settings: ISettingRegistry.ISettings): void {
  const providerType = (settings.get('provider').composite as string) ?? 'ollama';

  let base_url: string;
  let api_key: string;
  let model: string;
  let model_family: string;

  if (providerType === 'openai_compatible') {
    const s = settings.get('openai_compatible').composite as {
      base_url?: string;
      api_key?: string;
      model?: string;
    };
    base_url = s?.base_url ?? 'https://api.openai.com/v1';
    api_key = s?.api_key ?? '';
    model = s?.model ?? 'gpt-4o-mini';
    model_family = 'other';
  } else {
    const s = settings.get('ollama').composite as {
      base_url?: string;
      model_family?: string;
      model?: string;
    };
    base_url = s?.base_url ?? 'http://localhost:11434';
    model_family = s?.model_family ?? 'deepseek-coder';
    model = s?.model ?? 'deepseek-coder:6.7b';
    api_key = '';
  }

  const completion = settings.get('completion').composite as {
    max_tokens?: number;
    one_line_completions?: boolean;
  } | null;
  const retrieval = settings.get('retrieval').composite as {
    enabled?: boolean;
    top_k?: number;
    token_budget?: number;
  } | null;

  postConfig({
    provider_type: providerType,
    base_url,
    api_key,
    model,
    model_family,
    max_tokens: completion?.max_tokens ?? 256,
    one_line_completions: completion?.one_line_completions ?? false,
    retrieval_enabled: retrieval?.enabled ?? true,
    retrieval_top_k: retrieval?.top_k ?? 3,
    retrieval_token_budget: retrieval?.token_budget ?? 2000,
  }).catch(reason => console.warn('[CellSense] Failed to push provider config:', reason));
}

export default [trackerPlugin, plugin];
