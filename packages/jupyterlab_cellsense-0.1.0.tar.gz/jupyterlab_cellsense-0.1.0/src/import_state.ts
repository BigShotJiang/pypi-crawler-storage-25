export class ImportStateMachine {
  inImport = false;
  parenDepth = 0;
  importPhaseComplete = false;
  readonly imports: string[] = [];

  private _pendingLines: string[] = [];

  processLine(line: string): void {
    const trimmed = line.trim();

    if (this.inImport) {
      this._pendingLines.push(line);
      for (const ch of line) {
        if (ch === '(') this.parenDepth++;
        else if (ch === ')') this.parenDepth--;
      }
      const stripped = line.trimEnd();
      if (this.parenDepth <= 0 && !stripped.endsWith('\\')) {
        this.inImport = false;
        this.parenDepth = 0;
        this.imports.push(this._pendingLines.join('\n'));
        this._pendingLines = [];
      }
      return;
    }

    if (trimmed === '' || trimmed.startsWith('#')) return;

    if (trimmed.startsWith('import ') || trimmed.startsWith('from ')) {
      this.inImport = true;
      this._pendingLines = [line];
      for (const ch of line) {
        if (ch === '(') this.parenDepth++;
        else if (ch === ')') this.parenDepth--;
      }
      const stripped = line.trimEnd();
      if (this.parenDepth <= 0 && !stripped.endsWith('\\')) {
        this.inImport = false;
        this.parenDepth = 0;
        this.imports.push(this._pendingLines.join('\n'));
        this._pendingLines = [];
      }
      return;
    }

    // Non-empty, non-comment, non-import line — trigger the phase, but keep
    // scanning so imports that appear later in the same cell are still collected.
    this.importPhaseComplete = true;
  }

  parseContent(content: string): void {
    for (const line of content.split('\n')) {
      this.processLine(line);
    }
  }
}
