import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';

import { ContextFilePayload } from './tracker/types';

const NAMESPACE = 'cellsense';

export interface ICompleteRequest {
  prefix: string;
  suffix: string;
  language: string;
  imports?: string[];
  file_path?: string;
  context_files?: ContextFilePayload[];
}

export interface ICompleteResponse {
  completion: string;
}

export interface IHealthResponse {
  ok: boolean;
  model: string;
  family: string | null;
}

export interface IConfigRequest {
  provider_type: string;
  base_url: string;
  api_key: string;
  model: string;
  model_family: string;
  max_tokens: number;
  one_line_completions: boolean;
  retrieval_enabled: boolean;
  retrieval_top_k: number;
  retrieval_token_budget: number;
}

async function _request<T>(endpoint: string, init: RequestInit = {}): Promise<T> {
  const settings = ServerConnection.makeSettings();
  const url = URLExt.join(settings.baseUrl, NAMESPACE, endpoint);

  let response: Response;
  try {
    response = await ServerConnection.makeRequest(url, init, settings);
  } catch (error) {
    throw new ServerConnection.NetworkError(error as TypeError);
  }

  const text = await response.text();
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new ServerConnection.ResponseError(response, text);
  }

  if (!response.ok) {
    const d = data as Record<string, string>;
    throw new ServerConnection.ResponseError(
      response,
      d?.message ?? d?.error ?? text
    );
  }

  return data as T;
}

export async function fetchCompletion(req: ICompleteRequest): Promise<ICompleteResponse> {
  return _request<ICompleteResponse>('complete', {
    method: 'POST',
    body: JSON.stringify(req),
    headers: { 'Content-Type': 'application/json' }
  });
}

export async function fetchHealth(): Promise<IHealthResponse> {
  return _request<IHealthResponse>('health');
}

export async function postConfig(req: IConfigRequest): Promise<void> {
  await _request<void>('config', {
    method: 'POST',
    body: JSON.stringify(req),
    headers: { 'Content-Type': 'application/json' }
  });
}
