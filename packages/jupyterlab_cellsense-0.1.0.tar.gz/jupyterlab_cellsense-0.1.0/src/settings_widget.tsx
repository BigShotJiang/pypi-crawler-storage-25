import React, { useState, useCallback } from 'react';
import { ReactWidget } from '@jupyterlab/apputils';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

const MODEL_DEFAULTS: Record<string, string> = {
  'deepseek-coder': 'deepseek-coder:6.7b',
  'codestral': 'codestral:22b-v0.1',
  'codellama': 'codellama:7b-code',
  'starcoder2': 'starcoder2:3b',
  'qwen2.5-coder': 'qwen2.5-coder:7b',
  'other': '',
};

interface OllamaConfig {
  [key: string]: string;
  base_url: string;
  model_family: string;
  model: string;
}

interface OpenAIConfig {
  [key: string]: string;
  base_url: string;
  api_key: string;
  model: string;
}

interface CompletionConfig {
  [key: string]: number | boolean;
  debounce_ms: number;
  max_context_tokens: number;
  max_tokens: number;
  one_line_completions: boolean;
}

interface RetrievalConfig {
  [key: string]: number | boolean;
  enabled: boolean;
  top_k: number;
  token_budget: number;
}

function readOllama(settings: ISettingRegistry.ISettings): OllamaConfig {
  const s = settings.get('ollama').composite as Partial<OllamaConfig> | null;
  return {
    base_url: s?.base_url ?? 'http://localhost:11434',
    model_family: s?.model_family ?? 'deepseek-coder',
    model: s?.model ?? 'deepseek-coder:6.7b',
  };
}

function readOpenAI(settings: ISettingRegistry.ISettings): OpenAIConfig {
  const s = settings.get('openai_compatible').composite as Partial<OpenAIConfig> | null;
  return {
    base_url: s?.base_url ?? 'https://api.openai.com/v1',
    api_key: s?.api_key ?? '',
    model: s?.model ?? 'gpt-4o-mini',
  };
}

function readCompletion(settings: ISettingRegistry.ISettings): CompletionConfig {
  const s = settings.get('completion').composite as Partial<CompletionConfig> | null;
  return {
    debounce_ms: s?.debounce_ms ?? 500,
    max_context_tokens: s?.max_context_tokens ?? 1500,
    max_tokens: s?.max_tokens ?? 256,
    one_line_completions: s?.one_line_completions ?? false,
  };
}

function readRetrieval(settings: ISettingRegistry.ISettings): RetrievalConfig {
  const s = settings.get('retrieval').composite as Partial<RetrievalConfig> | null;
  return {
    enabled: s?.enabled ?? true,
    top_k: s?.top_k ?? 3,
    token_budget: s?.token_budget ?? 2000,
  };
}

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

function SettingsForm({
  settings,
}: {
  settings: ISettingRegistry.ISettings;
}): JSX.Element {
  const [provider, setProvider] = useState<string>(
    () => (settings.get('provider').composite as string) ?? 'ollama'
  );
  const [ollama, setOllama] = useState<OllamaConfig>(() => readOllama(settings));
  const [openai, setOpenai] = useState<OpenAIConfig>(() => readOpenAI(settings));
  const [completion, setCompletion] = useState<CompletionConfig>(() => readCompletion(settings));
  const [retrieval, setRetrieval] = useState<RetrievalConfig>(() => readRetrieval(settings));
  const [status, setStatus] = useState<SaveStatus>('idle');
  const [basicOpen, setBasicOpen] = useState(true);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [completionOpen, setCompletionOpen] = useState(false);
  const [retrievalOpen, setRetrievalOpen] = useState(false);

  const handleFamilyChange = useCallback((family: string) => {
    setOllama(prev => ({
      ...prev,
      model_family: family,
      model: MODEL_DEFAULTS[family] ?? prev.model,
    }));
  }, []);

  const handleSave = useCallback(async () => {
    setStatus('saving');
    try {
      await settings.set('provider', provider);
      await settings.set('ollama', ollama);
      await settings.set('openai_compatible', openai);
      await settings.set('completion', completion);
      await settings.set('retrieval', retrieval);
      setStatus('saved');
      setTimeout(() => setStatus('idle'), 2000);
    } catch {
      setStatus('error');
    }
  }, [settings, provider, ollama, openai, completion, retrieval]);

  return (
    <div className="jc-Settings">
      {/* Basic Settings */}
      <div className="jc-Settings-section">
        <button
          className="jc-Settings-collapsibleHeader"
          onClick={() => setBasicOpen(o => !o)}
          aria-expanded={basicOpen}
        >
          <span className="jc-Settings-collapsibleTitle">Basic Settings</span>
          <span className={`jc-Settings-chevron${basicOpen ? ' jc-Settings-chevron--open' : ''}`}>▶</span>
        </button>
        {basicOpen && (
          <>
            <div className="jc-Settings-row">
              <label className="jc-Settings-label">Provider</label>
              <p className="jc-Settings-hint">Choose your Provider. Set Ollama for Local Completions</p>
              <select
                className="jc-Settings-select"
                value={provider}
                onChange={e => setProvider(e.target.value)}
              >
                <option value="ollama">Ollama</option>
                <option value="openai_compatible">OpenAI Compatible</option>
              </select>
            </div>

            {provider === 'ollama' ? (
              <>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">Base URL</label>
                  <p className="jc-Settings-hint">Address of your Ollama server</p>
                  <input
                    className="jc-Settings-input"
                    value={ollama.base_url}
                    onChange={e => setOllama({ ...ollama, base_url: e.target.value })}
                  />
                </div>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">Model Family</label>
                  <p className="jc-Settings-hint">Choose the closest Model family</p>
                  <select
                    className="jc-Settings-select"
                    value={ollama.model_family}
                    onChange={e => handleFamilyChange(e.target.value)}
                  >
                    <option value="deepseek-coder">DeepSeek Coder</option>
                    <option value="codestral">Codestral</option>
                    <option value="codellama">CodeLlama</option>
                    <option value="starcoder2">StarCoder2</option>
                    <option value="qwen2.5-coder">Qwen2.5-Coder</option>
                    <option value="other">Other (generic FIM)</option>
                  </select>
                </div>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">Model Tag</label>
                  <p className="jc-Settings-hint">Full Ollama model tag as shown by <code>ollama list</code>, e.g. deepseek-coder:6.7b.</p>
                  <input
                    className="jc-Settings-input"
                    value={ollama.model}
                    onChange={e => setOllama({ ...ollama, model: e.target.value })}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">Base URL</label>
                  <p className="jc-Settings-hint">API endpoint</p>
                  <input
                    className="jc-Settings-input"
                    value={openai.base_url}
                    onChange={e => setOpenai({ ...openai, base_url: e.target.value })}
                  />
                </div>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">API Key</label>
                  <p className="jc-Settings-hint">Your provider's secret key. Leave blank for local servers that don't require one.</p>
                  <input
                    className="jc-Settings-input"
                    type="password"
                    value={openai.api_key}
                    onChange={e => setOpenai({ ...openai, api_key: e.target.value })}
                  />
                </div>
                <div className="jc-Settings-row">
                  <label className="jc-Settings-label">Model Name</label>
                  <p className="jc-Settings-hint">Model identifier sent with each request, e.g. gpt-4o-mini or deepseek-coder-v2.</p>
                  <input
                    className="jc-Settings-input"
                    value={openai.model}
                    onChange={e => setOpenai({ ...openai, model: e.target.value })}
                  />
                </div>
              </>
            )}
          </>
        )}
      </div>

      {/* Advanced Settings (collapsible) */}
      <div className="jc-Settings-section">
        <button
          className="jc-Settings-collapsibleHeader"
          onClick={() => setAdvancedOpen(o => !o)}
          aria-expanded={advancedOpen}
        >
          <span className="jc-Settings-collapsibleTitle">Advanced Settings</span>
          <span className={`jc-Settings-chevron${advancedOpen ? ' jc-Settings-chevron--open' : ''}`}>▶</span>
        </button>

        {advancedOpen && (
          <div className="jc-Settings-collapsibleBody">
            {/* Completion */}
            <div className="jc-Settings-section">
              <button
                className="jc-Settings-collapsibleHeader"
                onClick={() => setCompletionOpen(o => !o)}
                aria-expanded={completionOpen}
              >
                <span className="jc-Settings-collapsibleTitle">Completion</span>
                <span className={`jc-Settings-chevron${completionOpen ? ' jc-Settings-chevron--open' : ''}`}>▶</span>
              </button>
              {completionOpen && (
                <>
                  <div className="jc-Settings-row">
                    <label className="jc-Settings-label">Debounce (ms)</label>
                    <p className="jc-Settings-hint">How long to wait after you stop typing before requesting a completion. Raise this if suggestions feel too eager.</p>
                    <input
                      className="jc-Settings-input"
                      type="number"
                      min={0}
                      value={completion.debounce_ms}
                      onChange={e =>
                        setCompletion({ ...completion, debounce_ms: Math.max(0, parseInt(e.target.value) || 0) })
                      }
                    />
                  </div>
                  <div className="jc-Settings-row">
                    <label className="jc-Settings-label">Max Context Tokens (from the current file)</label>
                    <p className="jc-Settings-hint">Cells above and below the cursor are included until this token budget is spent.</p>
                    <input
                      className="jc-Settings-input"
                      type="number"
                      min={256}
                      value={completion.max_context_tokens}
                      onChange={e =>
                        setCompletion({ ...completion, max_context_tokens: Math.max(256, parseInt(e.target.value) || 256) })
                      }
                    />
                  </div>
                  <div className="jc-Settings-row">
                    <label className="jc-Settings-toggleRow">
                      <input
                        className="jc-Settings-checkbox"
                        type="checkbox"
                        checked={completion.one_line_completions as boolean}
                        onChange={e => setCompletion({ ...completion, one_line_completions: e.target.checked })}
                      />
                      <span className="jc-Settings-toggleLabel">One line completions</span>
                    </label>
                    <p className="jc-Settings-hint">Limit completions to a single line. Useful for inline suggestions that should not span multiple lines.</p>
                  </div>
                  {!completion.one_line_completions && (
                    <div className="jc-Settings-row">
                      <label className="jc-Settings-label">Max output tokens</label>
                      <p className="jc-Settings-hint">Longest completion the model can return. Lower values are faster; raise if suggestions cut off.</p>
                      <input
                        className="jc-Settings-input"
                        type="number"
                        min={32}
                        value={completion.max_tokens}
                        onChange={e =>
                          setCompletion({ ...completion, max_tokens: Math.max(32, parseInt(e.target.value) || 32) })
                        }
                      />
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Retrieval */}
            <div className="jc-Settings-section">
              <button
                className="jc-Settings-collapsibleHeader"
                onClick={() => setRetrievalOpen(o => !o)}
                aria-expanded={retrievalOpen}
              >
                <span className="jc-Settings-collapsibleTitle">Retrieval</span>
                <span className={`jc-Settings-chevron${retrievalOpen ? ' jc-Settings-chevron--open' : ''}`}>▶</span>
              </button>
              {retrievalOpen && (
                <>
                  <div className="jc-Settings-row">
                    <label className="jc-Settings-toggleRow">
                      <input
                        className="jc-Settings-checkbox"
                        type="checkbox"
                        checked={retrieval.enabled}
                        onChange={e => setRetrieval({ ...retrieval, enabled: e.target.checked })}
                      />
                      <span className="jc-Settings-toggleLabel">Enable RAG</span>
                    </label>
                    <p className="jc-Settings-hint">Disable this for faster completions and reduced token usage</p>
                  </div>
                  {retrieval.enabled && (
                    <>
                      <div className="jc-Settings-row">
                        <label className="jc-Settings-label">Top-K chunks</label>
                        <p className="jc-Settings-hint">How many code snippets are retrieved from your workspace files.</p>
                        <input
                          className="jc-Settings-input"
                          type="number"
                          min={1}
                          max={20}
                          value={retrieval.top_k}
                          onChange={e =>
                            setRetrieval({ ...retrieval, top_k: Math.min(20, Math.max(1, parseInt(e.target.value) || 1)) })
                          }
                        />
                      </div>
                      <div className="jc-Settings-row">
                        <label className="jc-Settings-label">Context token budget</label>
                        <p className="jc-Settings-hint">Token budget for retrieved snippets. Reduce if completions feel slow on large workspaces.</p>
                        <input
                          className="jc-Settings-input"
                          type="number"
                          min={256}
                          value={retrieval.token_budget}
                          onChange={e =>
                            setRetrieval({ ...retrieval, token_budget: Math.max(256, parseInt(e.target.value) || 256) })
                          }
                        />
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="jc-Settings-footer">
        <button
          className="jc-Settings-saveBtn"
          disabled={status === 'saving'}
          onClick={handleSave}
        >
          {status === 'saving' ? 'Saving…' : 'Save & Apply'}
        </button>
        {status === 'saved' && (
          <span className="jc-Settings-status jc-Settings-status--ok">Saved!</span>
        )}
        {status === 'error' && (
          <span className="jc-Settings-status jc-Settings-status--err">
            Failed to save settings
          </span>
        )}
      </div>
    </div>
  );
}

export class CellSenseSettingsWidget extends ReactWidget {
  private _settings: ISettingRegistry.ISettings;

  constructor(settings: ISettingRegistry.ISettings) {
    super();
    this._settings = settings;
    this.addClass('jc-SettingsWidget');
    this.title.label = 'CellSense';
    this.title.caption = 'CellSense Settings';
    this.title.closable = true;
  }

  protected render(): JSX.Element {
    return <SettingsForm settings={this._settings} />;
  }
}

export class CellSenseSettingsSidebarWidget extends ReactWidget {
  private _settings: ISettingRegistry.ISettings;

  constructor(settings: ISettingRegistry.ISettings) {
    super();
    this._settings = settings;
    this.addClass('jc-SettingsWidget');
    this.title.caption = 'CellSense Settings';
    this.title.closable = false;
  }

  protected render(): JSX.Element {
    return <SettingsForm settings={this._settings} />;
  }
}
