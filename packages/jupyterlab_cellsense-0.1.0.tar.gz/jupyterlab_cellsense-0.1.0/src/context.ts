import { NotebookPanel } from '@jupyterlab/notebook';
import { FileEditorWidget } from '@jupyterlab/fileeditor';
import { CompletionHandler, IInlineCompletionContext } from '@jupyterlab/completer';

import { ImportStateMachine } from './import_state';

// 1 token ≈ 4 chars for code. Rough heuristic avoids a 600KB tiktoken WASM dep.
function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

function markdownToComment(source: string): string {
  return source
    .split('\n')
    .map(line => `# ${line}`)
    .join('\n');
}

export interface IAssembledContext {
  prefix: string;
  suffix: string;
  language: string;
  importPhaseComplete: boolean;
  imports: string[];
  file_path: string;
}

function detectLanguage(context: IInlineCompletionContext): string {
  if (context.widget instanceof NotebookPanel) {
    const np = context.widget as NotebookPanel;
    return np.sessionContext?.kernelPreference?.language ?? 'python';
  }
  if (context.widget instanceof FileEditorWidget) {
    const fe = context.widget as FileEditorWidget;
    const mime = fe.content.model?.mimeType ?? '';
    if (mime.includes('python')) return 'python';
    if (mime.includes('typescript')) return 'typescript';
    if (mime.includes('javascript')) return 'javascript';
    const path = fe.context?.path ?? '';
    if (path.endsWith('.py')) return 'python';
    if (path.endsWith('.ts') || path.endsWith('.tsx')) return 'typescript';
    if (path.endsWith('.js') || path.endsWith('.jsx')) return 'javascript';
  }
  return 'python';
}

export function assembleContext(
  request: CompletionHandler.IRequest,
  context: IInlineCompletionContext,
  maxTokens: number
): IAssembledContext {
  const language = detectLanguage(context);

  // File editor: request.text is the full document — scan it for import state
  if (!(context.widget instanceof NotebookPanel)) {
    const fe = context.widget as FileEditorWidget;
    const sm = new ImportStateMachine();
    sm.parseContent(request.text);
    return {
      prefix: request.text.substring(0, request.offset),
      suffix: request.text.substring(request.offset),
      language,
      importPhaseComplete: sm.importPhaseComplete,
      imports: sm.imports,
      file_path: fe.context?.path ?? ''
    };
  }

  // Notebook: scan each cell with its own state machine (so incomplete multi-line
  // imports in one cell don't bleed into the next), but carry importPhaseComplete
  // forward so that once a code line has been seen, all subsequent cells collect
  // imports from every line rather than waiting for another code line.
  const np = context.widget as NotebookPanel;
  const allImports: string[] = [];
  let importPhaseComplete = false;
  for (const cell of np.content.widgets) {
    const model = cell.model.sharedModel;
    if (model.cell_type === 'code') {
      const cellSm = new ImportStateMachine();
      cellSm.parseContent(model.source);
      for (const imp of cellSm.imports) allImports.push(imp);
      if (cellSm.importPhaseComplete) importPhaseComplete = true;
    }
  }

  const activeCell = np.content.activeCell;
  if (!activeCell) {
    return {
      prefix: request.text.substring(0, request.offset),
      suffix: request.text.substring(request.offset),
      language,
      importPhaseComplete,
      imports: allImports,
      file_path: np.context.path
    };
  }

  // request.text is the active cell's source; request.offset is cursor position within it
  let prefix = request.text.substring(0, request.offset);
  let suffix = request.text.substring(request.offset);

  const activeCellIndex = np.content.activeCellIndex;
  const numCells = np.content.widgets.length;

  for (let d = 1; d < numCells; d++) {
    if (estimateTokens(prefix + suffix) >= maxTokens) break;

    const aboveIdx = activeCellIndex - d;
    const belowIdx = activeCellIndex + d;
    if (aboveIdx < 0 && belowIdx >= numCells) break;

    if (aboveIdx >= 0) {
      const model = np.content.widgets[aboveIdx].model.sharedModel;
      let src: string | null = null;
      if (model.cell_type === 'code') src = model.source;
      else if (model.cell_type === 'markdown') src = markdownToComment(model.source);
      if (src) prefix = src + '\n' + prefix;
    }

    if (belowIdx < numCells) {
      const model = np.content.widgets[belowIdx].model.sharedModel;
      let src: string | null = null;
      if (model.cell_type === 'code') src = model.source;
      else if (model.cell_type === 'markdown') src = markdownToComment(model.source);
      if (src) suffix = suffix + '\n' + src;
    }
  }

  return {
    prefix,
    suffix,
    language,
    importPhaseComplete,
    imports: allImports,
    file_path: np.context.path
  };
}
