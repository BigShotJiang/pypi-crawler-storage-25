import { INotebookTracker, NotebookPanel } from '@jupyterlab/notebook';
import { IEditorTracker, FileEditorWidget } from '@jupyterlab/fileeditor';
import { ISharedFile } from '@jupyter/ydoc';
import { DisposableDelegate, IDisposable } from '@lumino/disposable';

import { FileTracker } from './FileTracker';
import { EDIT_DEBOUNCE_MS } from './types';

function deltaToLineRange(
  delta: Array<{ retain?: number; insert?: string; delete?: number }>,
  source: string
): { startLine: number; endLine: number } {
  let offset = 0;
  let firstNonRetain = -1;
  let lastNonRetain = 0;

  for (const op of delta) {
    if (op.retain !== undefined) {
      offset += op.retain;
    } else {
      if (firstNonRetain < 0) firstNonRetain = offset;
      if (op.insert !== undefined) {
        lastNonRetain = offset + op.insert.length;
        offset += op.insert.length;
      } else if (op.delete !== undefined) {
        lastNonRetain = offset;
      }
    }
  }

  if (firstNonRetain < 0) firstNonRetain = 0;

  const lines = source.split('\n');
  let charCount = 0;
  let startLine = 0;
  let endLine = 0;

  for (let i = 0; i < lines.length; i++) {
    const lineEnd = charCount + lines[i].length + 1;
    if (charCount <= firstNonRetain && firstNonRetain < lineEnd) startLine = i;
    if (charCount <= lastNonRetain && lastNonRetain <= lineEnd) endLine = i;
    if (charCount > lastNonRetain) break;
    charCount = lineEnd;
  }

  return { startLine, endLine };
}

export class EditWatcher {
  private _debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();

  constructor(
    notebookTracker: INotebookTracker,
    editorTracker: IEditorTracker,
    tracker: FileTracker
  ) {
    notebookTracker.widgetAdded.connect((_, panel) => {
      this._hookNotebook(panel, tracker);
    });

    editorTracker.widgetAdded.connect((_, widget) => {
      if (widget instanceof FileEditorWidget) {
        this._hookFileEditor(widget, tracker);
      }
    });
  }

  private _hookNotebook(panel: NotebookPanel, tracker: FileTracker): void {
    const path = panel.context.path;
    const disposables: IDisposable[] = [];
    const attached = new Set<number>();

    const attachCell = (cellIndex: number) => {
      if (attached.has(cellIndex)) return;
      attached.add(cellIndex);

      const cell = panel.content.widgets[cellIndex];
      if (!cell) return;
      const shared = cell.model.sharedModel;

      const onChange = (_source: object, change: object) => {
        const ev = change as { changes?: Array<{ retain?: number; insert?: string; delete?: number }> };
        const src = shared.getSource();
        const range = ev.changes
          ? deltaToLineRange(ev.changes, src)
          : { startLine: 0, endLine: src.split('\n').length - 1 };

        this._scheduleUpdate(path, tracker, () => {
          tracker.upsert(path, {
            lastEditedAt: Date.now(),
            lastEditRange: { cellIndex, ...range },
            isDirty: true,
            kind: 'notebook'
          });
        });
      };

      shared.changed.connect(onChange);
      disposables.push(new DisposableDelegate(() => shared.changed.disconnect(onChange)));
    };

    const attachAllCells = () => {
      for (let i = 0; i < panel.content.widgets.length; i++) {
        attachCell(i);
      }
    };

    attachAllCells();

    panel.model?.cells.changed.connect(attachAllCells);

    panel.context.model.stateChanged.connect((_, change) => {
      if (change.name === 'dirty') {
        tracker.upsert(path, { isDirty: panel.context.model.dirty });
      }
    });

    panel.disposed.connect(() => {
      for (const d of disposables) d.dispose();
    });
  }

  private _hookFileEditor(widget: FileEditorWidget, tracker: FileTracker): void {
    const path = widget.context.path;
    const shared = widget.context.model.sharedModel as ISharedFile;

    const onChange = (_source: object, change: object) => {
      const ev = change as { changes?: Array<{ retain?: number; insert?: string; delete?: number }> };
      const src = shared.getSource();
      const range = ev.changes
        ? deltaToLineRange(ev.changes, src)
        : { startLine: 0, endLine: src.split('\n').length - 1 };

      this._scheduleUpdate(path, tracker, () => {
        tracker.upsert(path, {
          lastEditedAt: Date.now(),
          lastEditRange: range,
          isDirty: true,
          kind: 'file'
        });
      });
    };

    shared.changed.connect(onChange);

    widget.context.model.stateChanged.connect((_, change) => {
      if (change.name === 'dirty') {
        tracker.upsert(path, { isDirty: widget.context.model.dirty });
      }
    });

    widget.disposed.connect(() => {
      shared.changed.disconnect(onChange);
    });
  }

  private _scheduleUpdate(path: string, tracker: FileTracker, fn: () => void): void {
    const existing = this._debounceTimers.get(path);
    if (existing !== undefined) clearTimeout(existing);
    const t = setTimeout(() => {
      this._debounceTimers.delete(path);
      fn();
    }, EDIT_DEBOUNCE_MS);
    this._debounceTimers.set(path, t);
  }
}
