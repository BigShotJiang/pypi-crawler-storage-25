import { ILabShell } from '@jupyterlab/application';
import { NotebookPanel } from '@jupyterlab/notebook';
import { FileEditorWidget } from '@jupyterlab/fileeditor';
import { Widget } from '@lumino/widgets';

import { FileTracker } from './FileTracker';
import { DWELL_THRESHOLD_MS } from './types';

type ViewState = 'idle' | { widget: Widget; timer: ReturnType<typeof setTimeout>; cleanup: () => void };

export function getWidgetPath(widget: Widget): string | null {
  if (widget instanceof NotebookPanel) return widget.context.path;
  if (widget instanceof FileEditorWidget && widget.context) return widget.context.path;
  return null;
}

export function getWidgetKind(widget: Widget): 'notebook' | 'file' | null {
  if (widget instanceof NotebookPanel) return 'notebook';
  const path = getWidgetPath(widget);
  if (path !== null) return 'file';
  return null;
}

export class ViewWatcher {
  private _state: ViewState = 'idle';

  constructor(labShell: ILabShell, tracker: FileTracker) {
    labShell.currentChanged.connect((_, args) => {
      this._onCurrentChanged(args.oldValue, args.newValue, tracker);
    });
  }

  private _onCurrentChanged(
    oldWidget: Widget | null,
    newWidget: Widget | null,
    tracker: FileTracker
  ): void {
    // Handle old widget leaving
    if (this._state !== 'idle' && oldWidget && this._state.widget === oldWidget) {
      this._state.cleanup();

      const path = getWidgetPath(oldWidget);
      if (path) {
        // Snapshot final state — cursor/viewport watchers handle their own snapshot
        // Just ensure isOpen is kept until disposed
      }
      this._state = 'idle';
    }

    if (!newWidget) return;

    const path = getWidgetPath(newWidget);
    const kind = getWidgetKind(newWidget);
    if (!path || !kind) return;

    // Set up pending state
    const cleanupFns: Array<() => void> = [];

    const promote = () => {
      cleanup();
      tracker.upsert(path, {
        lastViewedAt: Date.now(),
        kind,
        isOpen: true
      });
    };

    const timer = setTimeout(promote, DWELL_THRESHOLD_MS);
    cleanupFns.push(() => clearTimeout(timer));

    const onInteraction = () => {
      promote();
    };

    const node = newWidget.node;
    const events = ['keydown', 'mousedown', 'wheel'] as const;
    for (const ev of events) {
      node.addEventListener(ev, onInteraction, { once: true, passive: true });
    }
    cleanupFns.push(() => {
      for (const ev of events) {
        node.removeEventListener(ev, onInteraction);
      }
    });

    const cleanup = () => {
      for (const fn of cleanupFns) fn();
    };

    this._state = { widget: newWidget, timer, cleanup };

    // Track widget disposal to mark isOpen = false
    newWidget.disposed.connect(() => {
      if (this._state !== 'idle' && this._state.widget === newWidget) {
        this._state.cleanup();
        this._state = 'idle';
      }
      tracker.upsert(path, { isOpen: false });
    });
  }
}
