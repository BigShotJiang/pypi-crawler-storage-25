import { CodeEditor } from '@jupyterlab/codeeditor';
import { CodeMirrorEditor } from '@jupyterlab/codemirror';
import { DisposableDelegate, IDisposable } from '@lumino/disposable';

import { LineRange } from '../types';

export interface IViewportAdapter {
  getVisibleRange(editor: CodeEditor.IEditor): LineRange | null;
  onScroll(editor: CodeEditor.IEditor, callback: () => void): IDisposable;
}

export class CodeMirrorViewportAdapter implements IViewportAdapter {
  getVisibleRange(editor: CodeEditor.IEditor): LineRange | null {
    if (!(editor instanceof CodeMirrorEditor)) return null;
    const view = editor.editor;
    if (!view) return null;

    const ranges = view.visibleRanges;
    if (ranges.length === 0) return null;

    const from = ranges[0].from;
    const to = ranges[ranges.length - 1].to;
    const fromLine = view.state.doc.lineAt(from).number - 1;
    const toLine = view.state.doc.lineAt(to).number - 1;
    return { startLine: fromLine, endLine: toLine };
  }

  onScroll(editor: CodeEditor.IEditor, callback: () => void): IDisposable {
    if (!(editor instanceof CodeMirrorEditor)) {
      return new DisposableDelegate(() => {});
    }
    const view = editor.editor;
    const handler = () => callback();
    view.scrollDOM.addEventListener('scroll', handler, { passive: true });
    return new DisposableDelegate(() =>
      view.scrollDOM.removeEventListener('scroll', handler)
    );
  }
}
