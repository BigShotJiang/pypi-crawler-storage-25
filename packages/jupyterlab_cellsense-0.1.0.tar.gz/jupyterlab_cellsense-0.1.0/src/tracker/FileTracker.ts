import { ILabShell } from '@jupyterlab/application';
import { INotebookTracker } from '@jupyterlab/notebook';
import { IEditorTracker } from '@jupyterlab/fileeditor';
import { Signal, ISignal } from '@lumino/signaling';

import { IFileTracker } from './token';
import {
  FileContext,
  MAX_TRACKED_FILES,
  HALF_LIFE_MS,
  STATE_CHANGED_DEBOUNCE_MS
} from './types';
import { ViewWatcher } from './ViewWatcher';
import { EditWatcher } from './EditWatcher';
import { CursorWatcher } from './CursorWatcher';
import { ViewportWatcher } from './ViewportWatcher';

interface FileTrackerOptions {
  labShell: ILabShell;
  notebookTracker: INotebookTracker;
  editorTracker: IEditorTracker;
}

export class FileTracker implements IFileTracker {
  private _files = new Map<string, FileContext>();
  private _stateChanged = new Signal<IFileTracker, void>(this);
  private _debounceTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(options: FileTrackerOptions) {
    const { labShell, notebookTracker, editorTracker } = options;

    new ViewWatcher(labShell, this);
    new EditWatcher(notebookTracker, editorTracker, this);
    new CursorWatcher(labShell, this);
    new ViewportWatcher(labShell, this);
  }

  get stateChanged(): ISignal<IFileTracker, void> {
    return this._stateChanged;
  }

  getRanked(limit?: number): FileContext[] {
    const now = Date.now();
    const entries = Array.from(this._files.values());

    for (const fc of entries) {
      fc.engagementScore = this._computeScore(fc, now);
    }

    entries.sort((a, b) => b.engagementScore - a.engagementScore);
    return limit !== undefined ? entries.slice(0, limit) : entries;
  }

  get(path: string): FileContext | null {
    return this._files.get(path) ?? null;
  }

  evict(path: string): void {
    this._files.delete(path);
    this._emitStateChanged();
  }

  upsert(path: string, updates: Partial<FileContext>): void {
    const existing = this._files.get(path);
    if (existing) {
      Object.assign(existing, updates);
    } else {
      this._files.set(path, {
        path,
        kind: 'file',
        lastViewedAt: Date.now(),
        lastEditedAt: null,
        lastCursor: null,
        lastEditRange: null,
        lastViewportRange: null,
        isDirty: false,
        isOpen: true,
        engagementScore: 0,
        ...updates
      });
      this._evictIfNeeded();
    }
    this._emitStateChanged();
  }

  emitStateChanged(): void {
    this._emitStateChanged();
  }

  private _computeScore(fc: FileContext, now: number): number {
    const recency = (t: number | null) =>
      t === null ? 0 : Math.exp(-(now - t) / HALF_LIFE_MS);

    const score =
      2.0 * recency(fc.lastEditedAt) + 1.0 * recency(fc.lastViewedAt);
    return fc.isOpen ? Math.max(score, 0.1) : score;
  }

  private _evictIfNeeded(): void {
    if (this._files.size <= MAX_TRACKED_FILES) return;

    const now = Date.now();
    const entries = Array.from(this._files.entries());
    entries.sort(
      ([, a], [, b]) => this._computeScore(a, now) - this._computeScore(b, now)
    );

    const toEvict = entries.slice(0, this._files.size - MAX_TRACKED_FILES);
    for (const [path] of toEvict) {
      this._files.delete(path);
    }
  }

  private _emitStateChanged(): void {
    if (this._debounceTimer !== null) return;
    this._debounceTimer = setTimeout(() => {
      this._debounceTimer = null;
      this._stateChanged.emit();
    }, STATE_CHANGED_DEBOUNCE_MS);
  }
}
