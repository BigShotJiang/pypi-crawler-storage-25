import { ILabShell } from '@jupyterlab/application';
import { NotebookPanel } from '@jupyterlab/notebook';
import { FileEditorWidget } from '@jupyterlab/fileeditor';
import { Widget } from '@lumino/widgets';
import { DisposableDelegate, IDisposable } from '@lumino/disposable';

import { FileTracker } from './FileTracker';
import { getWidgetPath } from './ViewWatcher';

export class CursorWatcher {
  private _currentDisposables: IDisposable[] = [];

  constructor(labShell: ILabShell, tracker: FileTracker) {
    labShell.currentChanged.connect((_, args) => {
      this._detach();
      if (args.newValue) {
        this._attach(args.newValue, tracker);
      }
    });
  }

  private _detach(): void {
    for (const d of this._currentDisposables) d.dispose();
    this._currentDisposables = [];
  }

  private _attach(widget: Widget, tracker: FileTracker): void {
    const path = getWidgetPath(widget);
    if (!path) return;

    if (widget instanceof NotebookPanel) {
      this._attachNotebook(widget, path, tracker);
    } else if (widget instanceof FileEditorWidget) {
      this._attachFileEditor(widget, path, tracker);
    }
  }

  private _attachNotebook(panel: NotebookPanel, path: string, tracker: FileTracker): void {
    const onCellChanged = () => {
      this._replaceCellEditorListener(panel, path, tracker);
    };

    panel.content.activeCellChanged.connect(onCellChanged);
    this._currentDisposables.push(
      new DisposableDelegate(() => panel.content.activeCellChanged.disconnect(onCellChanged))
    );

    this._replaceCellEditorListener(panel, path, tracker);
  }

  private _cellEditorDisposable: IDisposable | null = null;

  private _replaceCellEditorListener(panel: NotebookPanel, path: string, tracker: FileTracker): void {
    if (this._cellEditorDisposable) {
      this._cellEditorDisposable.dispose();
      this._cellEditorDisposable = null;
    }

    const cell = panel.content.activeCell;
    if (!cell?.editor) return;
    const cellIndex = panel.content.activeCellIndex;
    const editor = cell.editor;

    const onSelection = () => {
      const pos = editor.getCursorPosition();
      tracker.upsert(path, {
        lastCursor: { cellIndex, line: pos.line, column: pos.column }
      });
    };

    editor.model.selections.changed.connect(onSelection);
    this._cellEditorDisposable = new DisposableDelegate(
      () => editor.model.selections.changed.disconnect(onSelection)
    );
    this._currentDisposables.push(this._cellEditorDisposable);
  }

  private _attachFileEditor(widget: FileEditorWidget, path: string, tracker: FileTracker): void {
    const editor = widget.content.editor;
    if (!editor) return;

    const onSelection = () => {
      const pos = editor.getCursorPosition();
      tracker.upsert(path, {
        lastCursor: { line: pos.line, column: pos.column }
      });
    };

    editor.model.selections.changed.connect(onSelection);
    this._currentDisposables.push(
      new DisposableDelegate(() => editor.model.selections.changed.disconnect(onSelection))
    );
  }
}
