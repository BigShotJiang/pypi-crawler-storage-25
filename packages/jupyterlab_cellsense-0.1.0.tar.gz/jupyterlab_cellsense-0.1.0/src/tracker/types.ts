export interface CursorAnchor {
  cellIndex?: number;
  line: number;
  column: number;
}

export interface LineRange {
  cellIndex?: number;
  startLine: number;
  endLine: number;
}

export interface FileContext {
  path: string;
  kind: 'notebook' | 'file';
  lastViewedAt: number;
  lastEditedAt: number | null;
  lastCursor: CursorAnchor | null;
  lastEditRange: LineRange | null;
  lastViewportRange: LineRange | null;
  isDirty: boolean;
  isOpen: boolean;
  engagementScore: number;
}

// Wire format for context_files payload
export interface AnchorPayload {
  cell_index: number | null;
  start_line: number;
  end_line: number;
}

export interface ContextFilePayload {
  path: string;
  kind: 'notebook' | 'file';
  signal: 'edited' | 'viewed';
  recency_rank: number;
  anchor: AnchorPayload;
  source: 'disk' | 'inline';
  content?: string;
}

// Constants shared with backend
export const DWELL_THRESHOLD_MS = 2000;
export const MAX_TRACKED_FILES = 8;
export const MAX_CONTEXT_FILES_SENT = 5;
export const DEFAULT_SLICE_LINES = 20;
export const VIEWPORT_DEBOUNCE_MS = 150;
export const EDIT_DEBOUNCE_MS = 250;
export const GLOBAL_CONTEXT_CHAR_BUDGET = 16000;
export const HALF_LIFE_MS = 5 * 60 * 1000;
export const STATE_CHANGED_DEBOUNCE_MS = 500;
