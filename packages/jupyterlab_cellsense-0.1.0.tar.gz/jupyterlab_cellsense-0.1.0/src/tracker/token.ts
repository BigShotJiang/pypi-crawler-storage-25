import { Token } from '@lumino/coreutils';
import { ISignal } from '@lumino/signaling';
import { FileContext } from './types';

export interface IFileTracker {
  getRanked(limit?: number): FileContext[];
  get(path: string): FileContext | null;
  evict(path: string): void;
  readonly stateChanged: ISignal<IFileTracker, void>;
}

// eslint-disable-next-line @typescript-eslint/no-redeclare
export const IFileTracker = new Token<IFileTracker>('jupyterlab-cellsense:IFileTracker');
