import { ILabShell } from '@jupyterlab/application';
import { NotebookPanel } from '@jupyterlab/notebook';
import { FileEditorWidget } from '@jupyterlab/fileeditor';
import { Widget } from '@lumino/widgets';
import { IDisposable } from '@lumino/disposable';

import { FileTracker } from './FileTracker';
import { VIEWPORT_DEBOUNCE_MS } from './types';
import { getWidgetPath } from './ViewWatcher';
import { CodeMirrorViewportAdapter } from './adapters/CodeMirrorViewportAdapter';

const adapter = new CodeMirrorViewportAdapter();

function getActiveCellByViewport(notebook: NotebookPanel): number {
  const node = notebook.content.node;
  const midY = node.scrollTop + node.clientHeight / 2;
  const cells = notebook.content.widgets;
  for (let i = 0; i < cells.length; i++) {
    const cellNode = cells[i].node;
    const top = cellNode.offsetTop;
    const bottom = top + cellNode.offsetHeight;
    if (midY >= top && midY <= bottom) return i;
  }
  return notebook.content.activeCellIndex;
}

export class ViewportWatcher {
  private _scrollDisposables: IDisposable[] = [];
  private _debounceTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(labShell: ILabShell, tracker: FileTracker) {
    labShell.currentChanged.connect((_, args) => {
      this._detach();
      if (args.newValue) {
        this._attach(args.newValue, tracker);
      }
    });
  }

  private _detach(): void {
    for (const d of this._scrollDisposables) d.dispose();
    this._scrollDisposables = [];
    if (this._debounceTimer !== null) {
      clearTimeout(this._debounceTimer);
      this._debounceTimer = null;
    }
  }

  private _attach(widget: Widget, tracker: FileTracker): void {
    const path = getWidgetPath(widget);
    if (!path) return;

    if (widget instanceof NotebookPanel) {
      this._attachNotebook(widget, path, tracker);
    } else if (widget instanceof FileEditorWidget) {
      this._attachFileEditor(widget, path, tracker);
    }
  }

  private _attachNotebook(panel: NotebookPanel, path: string, tracker: FileTracker): void {
    const update = () => {
      this._scheduleUpdate(() => {
        const cellIndex = getActiveCellByViewport(panel);
        const cell = panel.content.widgets[cellIndex];
        if (!cell?.editor) return;
        const range = adapter.getVisibleRange(cell.editor);
        if (range) {
          tracker.upsert(path, {
            lastViewportRange: { cellIndex, ...range }
          });
        }
      });
    };

    const handler = () => update();
    panel.content.node.addEventListener('scroll', handler, { passive: true });
    this._scrollDisposables.push({
      dispose: () => panel.content.node.removeEventListener('scroll', handler)
    } as IDisposable);
  }

  private _attachFileEditor(widget: FileEditorWidget, path: string, tracker: FileTracker): void {
    const editor = widget.content.editor;
    if (!editor) return;

    const d = adapter.onScroll(editor, () => {
      this._scheduleUpdate(() => {
        const range = adapter.getVisibleRange(editor);
        if (range) {
          tracker.upsert(path, { lastViewportRange: range });
        }
      });
    });

    this._scrollDisposables.push(d);
  }

  private _scheduleUpdate(fn: () => void): void {
    if (this._debounceTimer !== null) clearTimeout(this._debounceTimer);
    this._debounceTimer = setTimeout(() => {
      this._debounceTimer = null;
      fn();
    }, VIEWPORT_DEBOUNCE_MS);
  }
}
