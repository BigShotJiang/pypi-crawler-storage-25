import { IDocumentManager } from '@jupyterlab/docmanager';
import { NotebookPanel } from '@jupyterlab/notebook';
import { FileEditorWidget } from '@jupyterlab/fileeditor';
import { ISharedFile } from '@jupyter/ydoc';

import { IFileTracker } from '../tracker/token';
import {
  ContextFilePayload,
  MAX_CONTEXT_FILES_SENT,
  DEFAULT_SLICE_LINES
} from '../tracker/types';

function sliceLines(text: string, startLine: number, endLine: number): string {
  const lines = text.split('\n');
  return lines.slice(startLine, endLine + 1).join('\n');
}

export function buildContextFiles(
  tracker: IFileTracker,
  activeFilePath: string,
  docManager: IDocumentManager,
  options?: { maxFiles?: number; sliceLines?: number }
): ContextFilePayload[] {
  try {
    const maxFiles = options?.maxFiles ?? MAX_CONTEXT_FILES_SENT;
    const halfSlice = Math.floor((options?.sliceLines ?? DEFAULT_SLICE_LINES) / 2);
    const now = Date.now();
    const tenMinutesAgo = now - 10 * 60 * 1000;

    const ranked = tracker.getRanked(maxFiles + 1);
    const candidates = ranked.filter(fc => fc.path !== activeFilePath);

    const result: ContextFilePayload[] = [];

    for (let i = 0; i < Math.min(candidates.length, maxFiles); i++) {
      const fc = candidates[i];

      const signal: 'edited' | 'viewed' =
        fc.lastEditedAt && fc.lastEditedAt > tenMinutesAgo ? 'edited' : 'viewed';

      // Pick anchor range
      let anchorStart: number;
      let anchorEnd: number;
      let cellIndex: number | null = null;

      if (signal === 'edited' && fc.lastEditRange) {
        anchorStart = fc.lastEditRange.startLine;
        anchorEnd = fc.lastEditRange.endLine;
        cellIndex = fc.lastEditRange.cellIndex ?? null;
      } else if (fc.lastViewportRange) {
        anchorStart = fc.lastViewportRange.startLine;
        anchorEnd = fc.lastViewportRange.endLine;
        cellIndex = fc.lastViewportRange.cellIndex ?? null;
      } else if (fc.lastCursor) {
        anchorStart = fc.lastCursor.line;
        anchorEnd = fc.lastCursor.line;
        cellIndex = fc.lastCursor.cellIndex ?? null;
      } else {
        continue;
      }

      // Expand to DEFAULT_SLICE_LINES centered on midpoint
      const mid = Math.floor((anchorStart + anchorEnd) / 2);
      const expandedStart = Math.max(0, mid - halfSlice);
      const expandedEnd = mid + halfSlice;

      // Determine source
      const isDirtyInline = fc.isDirty && fc.isOpen;

      let content: string | undefined;

      if (isDirtyInline) {
        try {
          const widget = docManager.findWidget(fc.path);
          if (widget instanceof NotebookPanel) {
            const idx = cellIndex ?? 0;
            const cell = widget.content.widgets[idx];
            if (cell) {
              content = sliceLines(cell.model.sharedModel.getSource(), expandedStart, expandedEnd);
            }
          } else if (widget instanceof FileEditorWidget) {
            const src = (widget.context.model.sharedModel as ISharedFile).getSource();
            content = sliceLines(src, expandedStart, expandedEnd);
          }
        } catch {
          // Fall back to disk if inline read fails
        }
      }

      result.push({
        path: fc.path,
        kind: fc.kind,
        signal,
        recency_rank: i,
        anchor: {
          cell_index: cellIndex,
          start_line: expandedStart,
          end_line: expandedEnd
        },
        source: content !== undefined ? 'inline' : 'disk',
        ...(content !== undefined ? { content } : {})
      });
    }

    return result;
  } catch (err) {
    console.warn('[CellSense] buildContextFiles error:', err);
    return [];
  }
}
