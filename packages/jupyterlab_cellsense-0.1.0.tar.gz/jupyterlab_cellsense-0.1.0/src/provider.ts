import {
  CompletionHandler,
  IInlineCompletionContext,
  IInlineCompletionItem,
  IInlineCompletionList,
  IInlineCompletionProvider
} from '@jupyterlab/completer';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { assembleContext } from './context';
import { fetchCompletion } from './client';
import { IFileTracker } from './tracker/token';
import { buildContextFiles } from './completion/ContextRequestBuilder';

export class CellSenseProvider
  implements IInlineCompletionProvider<IInlineCompletionItem>
{
  readonly name = 'CellSense';
  readonly identifier = 'jupyterlab-cellsense';

  private _debouncerDelay = 500;
  private _maxContextTokens = 1500;
  private _fileTracker: IFileTracker;
  private _docManager: IDocumentManager;

  constructor(fileTracker: IFileTracker, docManager: IDocumentManager) {
    this._fileTracker = fileTracker;
    this._docManager = docManager;
  }

  // JupyterLab reads this once at registerInlineProvider() time.
  // debouncerDelay: built-in debounce duration. timeout: fetch deadline.
  get schema(): ISettingRegistry.IProperty {
    return {
      default: {
        debouncerDelay: this._debouncerDelay,
        timeout: 10000
      }
    };
  }

  updateSettings(debounceMs: number, maxContextTokens: number): void {
    this._debouncerDelay = debounceMs;
    this._maxContextTokens = maxContextTokens;
  }

  async fetch(
    request: CompletionHandler.IRequest,
    context: IInlineCompletionContext
  ): Promise<IInlineCompletionList<IInlineCompletionItem>> {
    const empty: IInlineCompletionList<IInlineCompletionItem> = { items: [] };

    const assembled = assembleContext(request, context, this._maxContextTokens);
    if (!assembled.prefix && !assembled.suffix) return empty;

    const contextFiles = buildContextFiles(
      this._fileTracker,
      assembled.file_path,
      this._docManager
    );

    let response: { completion: string };
    try {
      response = await fetchCompletion({
        prefix: assembled.prefix,
        suffix: assembled.suffix,
        language: assembled.language,
        ...(assembled.importPhaseComplete
          ? { imports: assembled.imports, file_path: assembled.file_path }
          : {}),
        ...(contextFiles.length > 0 ? { context_files: contextFiles } : {})
      });
    } catch (error) {
      // Silent failure — ghost text simply does not appear on backend errors
      console.warn('[CellSense] fetch error:', error);
      return empty;
    }

    const completion = response.completion?.trim();
    if (!completion) return empty;

    return { items: [{ insertText: completion }] };
  }
}
