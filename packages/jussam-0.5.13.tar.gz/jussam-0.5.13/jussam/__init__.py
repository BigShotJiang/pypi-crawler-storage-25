import os
os.environ["_HOSSAM_IMPORT_VIA"] = "jussam"

import hossam as _hossam
from hossam import *

try:
    __all__ = _hossam.__all__
except AttributeError:
    __all__ = [name for name in dir(_hossam) if not name.startswith("_")]

try:
    __version__ = _hossam.__version__
except AttributeError:
    __version__ = "unknown"

# 안내 메시지 (블릿 리스트)
messages = [
    "📦 연세대학교 주영아 교수가 제작한 라이브러리를 사용중입니다.",
    "📧 Email(1): j.purplerose@yonsei.ac.kr",
    "📧 Email(2): j.purplerose@gmail.com",
    "📝 Website: https://juyounga.kr/",
]

for msg in messages:
    print(f"{msg}")