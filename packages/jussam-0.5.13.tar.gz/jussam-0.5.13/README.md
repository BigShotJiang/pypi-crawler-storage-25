---
title: 🎓 Jussam Data Helper
---

# 🎓 Jussam Data Helper

[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-0.1.3-green.svg)](https://pypi.org/project/jussam/)

**jussam**은 데이터 분석, 시각화, 통계 처리를 위한 종합 헬퍼 라이브러리입니다.

연세대학교에서 진행 중인 머신러닝 및 데이터 분석 수업을 위해 개발되었으며, 주영아 교수의 강의에서 활용됩니다.

## ✨ 주요 특징

- 📊 **풍부한 시각화**: 25+ 시각화 함수 (Seaborn/Matplotlib 기반)
- 🎯 **통계 분석**: 회귀, 분류, 시계열 분석 도구
- 🤖 **머신 러닝**: 예측, 분류, 군집 학습 모델 구축 및 성능 평가
- 📦 **샘플 데이터**: 학습용 데이터셋 즉시 로드
- 🔧 **데이터 전처리**: 결측치 처리, 이상치 탐지, 스케일링
- 📈 **교육용 최적화**: 데이터 분석 교육에 특화된 설계


## 📦 설치

```bash
pip install --upgrade jussam
```

**요구사항**: Python 3.11.9

### 주요 모듈

각 모듈은 "hello statistics"을 의미하는 **hs_**로 시작합니다.

- **hs_plot**: 25+ 시각화 함수 (선 그래프, 산점도, 히스토그램, 박스플롯, 히트맵 등)
- **hs_stats**: 회귀/분류 분석, 교차검증, 정규성 검정, 상관분석 등
- **hs_prep**: 결측치 처리, 이상치 탐지, 스케일링, 인코딩 등의 데이터 전처리 기능
- **hs_timeserise**: 시계열 분석 기능 지원
- **hs_gis**: GIS 데이터 로드 및 시각화 (대한민국 지도 지원)
- **hs_util**: 예쁜 테이블 출력, 그리드 서치 등
- **hs_cluster**: 군집분석, PCA 등
- **hs_reg**: 머신러닝 예측 분석 유틸리티
- **hs_cls**: 머신러닝 분류 분석 유틸리티 (예정)

## 📄 라이선스

이 프로젝트는 MIT 라이선스를 따릅니다. 자유롭게 사용, 수정, 배포할 수 있습니다.
