from __future__ import annotations

import httpx

from .models import (
    AsyncResearchResponse,
    CancelResponse,
    JobStatus,
    ResearchRequestList,
    ResearchRequestRequest,
    ResearchResponse,
    SearchRequestRequest,
)


class SyncResearchResearchAPI:
    """Synchronous API endpoints for Research."""

    def __init__(self, client: httpx.Client):
        """Initialize sync sub-client with shared httpx client."""
        self._client = client

    def list(
        self,
        ordering: str | None = None,
        search: str | None = None,
    ) -> list[ResearchRequestList]:
        """
        List research history

        List research history for the current API key.
        """
        url = "/apix/research/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "search": search,
            }.items() if v is not None
        }
        response = self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return [ResearchRequestList.model_validate(item) for item in response.json()]


    def cancel_create(self, uuid: str) -> CancelResponse:
        """
        Cancel job

        Cancel a queued or running research/search job.
        """
        url = f"/apix/research/{uuid}/cancel/"
        response = self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return CancelResponse.model_validate(response.json())


    def results_retrieve(self, uuid: str) -> ResearchResponse:
        """
        Get results

        Get full results of a completed research/search job.
        """
        url = f"/apix/research/{uuid}/results/"
        response = self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ResearchResponse.model_validate(response.json())


    def status_retrieve(self, uuid: str) -> JobStatus:
        """
        Get job status

        Poll status of an async research/search job.
        """
        url = f"/apix/research/{uuid}/status/"
        response = self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return JobStatus.model_validate(response.json())


    def research_create(self, data: ResearchRequestRequest) -> AsyncResearchResponse:
        """
        Execute research (async)

        Queue full pipeline: search → crawl → LLM summarize. Returns 202 with
        job_id.
        """
        url = "/apix/research/research/"
        response = self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return AsyncResearchResponse.model_validate(response.json())


    def search_create(self, data: SearchRequestRequest) -> AsyncResearchResponse:
        """
        Execute search (async)

        Queue Serper search. Returns 202 with job_id for polling, or 200 if sync
        fallback.
        """
        url = "/apix/research/search/"
        response = self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return AsyncResearchResponse.model_validate(response.json())


