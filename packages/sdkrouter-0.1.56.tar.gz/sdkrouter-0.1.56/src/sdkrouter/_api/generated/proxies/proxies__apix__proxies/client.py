from __future__ import annotations

import httpx

from .models import (
    PaginatedProxyAssignmentList,
    PaginatedProxyList,
    PaginatedProxyRotationList,
    PaginatedProxyTestList,
    PatchedProxyAssignmentRequest,
    PatchedProxyRequest,
    PatchedProxyRotationRequest,
    PatchedProxyTestRequest,
    Proxy,
    ProxyAssignment,
    ProxyAssignmentRequest,
    ProxyRequest,
    ProxyRotation,
    ProxyRotationRequest,
    ProxyTest,
    ProxyTestRequest,
)


class ProxiesProxiesAPI:
    """API endpoints for Proxies."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def assignments_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedProxyAssignmentList]:
        """
        ViewSet for ProxyAssignment.
        """
        url = "/apix/proxies/assignments/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedProxyAssignmentList.model_validate(response.json())


    async def assignments_create(self, data: ProxyAssignmentRequest) -> ProxyAssignment:
        """
        ViewSet for ProxyAssignment.
        """
        url = "/apix/proxies/assignments/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyAssignment.model_validate(response.json())


    async def assignments_retrieve(self, id: str) -> ProxyAssignment:
        """
        ViewSet for ProxyAssignment.
        """
        url = f"/apix/proxies/assignments/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyAssignment.model_validate(response.json())


    async def assignments_update(
        self,
        id: str,
        data: ProxyAssignmentRequest,
    ) -> ProxyAssignment:
        """
        ViewSet for ProxyAssignment.
        """
        url = f"/apix/proxies/assignments/{id}/"
        response = await self._client.put(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyAssignment.model_validate(response.json())


    async def assignments_partial_update(
        self,
        id: str,
        data: PatchedProxyAssignmentRequest | None = None,
    ) -> ProxyAssignment:
        """
        ViewSet for ProxyAssignment.
        """
        url = f"/apix/proxies/assignments/{id}/"
        _json = data.model_dump(mode="json", exclude_unset=True, exclude_none=True) if data else None
        response = await self._client.patch(url, json=_json)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyAssignment.model_validate(response.json())


    async def assignments_destroy(self, id: str) -> None:
        """
        ViewSet for ProxyAssignment.
        """
        url = f"/apix/proxies/assignments/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def assignments_active_retrieve(self) -> ProxyAssignment:
        """
        Get active assignments

        Get active assignments.
        """
        url = "/apix/proxies/assignments/active/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyAssignment.model_validate(response.json())


    async def proxies_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedProxyList]:
        """
        ViewSet for Proxy.
        """
        url = "/apix/proxies/proxies/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedProxyList.model_validate(response.json())


    async def proxies_create(self, data: ProxyRequest) -> Proxy:
        """
        ViewSet for Proxy.
        """
        url = "/apix/proxies/proxies/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_retrieve(self, id: str) -> Proxy:
        """
        ViewSet for Proxy.
        """
        url = f"/apix/proxies/proxies/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_update(self, id: str, data: ProxyRequest) -> Proxy:
        """
        ViewSet for Proxy.
        """
        url = f"/apix/proxies/proxies/{id}/"
        response = await self._client.put(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_partial_update(
        self,
        id: str,
        data: PatchedProxyRequest | None = None,
    ) -> Proxy:
        """
        ViewSet for Proxy.
        """
        url = f"/apix/proxies/proxies/{id}/"
        _json = data.model_dump(mode="json", exclude_unset=True, exclude_none=True) if data else None
        response = await self._client.patch(url, json=_json)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_destroy(self, id: str) -> None:
        """
        ViewSet for Proxy.
        """
        url = f"/apix/proxies/proxies/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def proxies_by_country_retrieve(self) -> Proxy:
        """
        Get proxies by country

        Get proxies by country code.
        """
        url = "/apix/proxies/proxies/by_country/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_healthy_retrieve(self) -> Proxy:
        """
        Get healthy proxies

        Get healthy proxies.
        """
        url = "/apix/proxies/proxies/healthy/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_korean_retrieve(self) -> Proxy:
        """
        Get Korean proxies

        Get Korean proxies.
        """
        url = "/apix/proxies/proxies/korean/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def proxies_performance_stats_retrieve(self) -> Proxy:
        """
        Get performance stats

        Get overall performance statistics.
        """
        url = "/apix/proxies/proxies/performance_stats/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Proxy.model_validate(response.json())


    async def rotations_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedProxyRotationList]:
        """
        ViewSet for ProxyRotation.
        """
        url = "/apix/proxies/rotations/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedProxyRotationList.model_validate(response.json())


    async def rotations_create(self, data: ProxyRotationRequest) -> ProxyRotation:
        """
        ViewSet for ProxyRotation.
        """
        url = "/apix/proxies/rotations/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyRotation.model_validate(response.json())


    async def rotations_retrieve(self, id: str) -> ProxyRotation:
        """
        ViewSet for ProxyRotation.
        """
        url = f"/apix/proxies/rotations/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyRotation.model_validate(response.json())


    async def rotations_update(self, id: str, data: ProxyRotationRequest) -> ProxyRotation:
        """
        ViewSet for ProxyRotation.
        """
        url = f"/apix/proxies/rotations/{id}/"
        response = await self._client.put(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyRotation.model_validate(response.json())


    async def rotations_partial_update(
        self,
        id: str,
        data: PatchedProxyRotationRequest | None = None,
    ) -> ProxyRotation:
        """
        ViewSet for ProxyRotation.
        """
        url = f"/apix/proxies/rotations/{id}/"
        _json = data.model_dump(mode="json", exclude_unset=True, exclude_none=True) if data else None
        response = await self._client.patch(url, json=_json)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyRotation.model_validate(response.json())


    async def rotations_destroy(self, id: str) -> None:
        """
        ViewSet for ProxyRotation.
        """
        url = f"/apix/proxies/rotations/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def rotations_available_proxies_retrieve(self, id: str) -> ProxyRotation:
        """
        Get available proxies for rotation

        Get proxies matching the rotation criteria.
        """
        url = f"/apix/proxies/rotations/{id}/available_proxies/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyRotation.model_validate(response.json())


    async def tests_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedProxyTestList]:
        """
        ViewSet for ProxyTest.
        """
        url = "/apix/proxies/tests/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedProxyTestList.model_validate(response.json())


    async def tests_create(self, data: ProxyTestRequest) -> ProxyTest:
        """
        ViewSet for ProxyTest.
        """
        url = "/apix/proxies/tests/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyTest.model_validate(response.json())


    async def tests_retrieve(self, id: str) -> ProxyTest:
        """
        ViewSet for ProxyTest.
        """
        url = f"/apix/proxies/tests/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyTest.model_validate(response.json())


    async def tests_update(self, id: str, data: ProxyTestRequest) -> ProxyTest:
        """
        ViewSet for ProxyTest.
        """
        url = f"/apix/proxies/tests/{id}/"
        response = await self._client.put(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyTest.model_validate(response.json())


    async def tests_partial_update(
        self,
        id: str,
        data: PatchedProxyTestRequest | None = None,
    ) -> ProxyTest:
        """
        ViewSet for ProxyTest.
        """
        url = f"/apix/proxies/tests/{id}/"
        _json = data.model_dump(mode="json", exclude_unset=True, exclude_none=True) if data else None
        response = await self._client.patch(url, json=_json)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ProxyTest.model_validate(response.json())


    async def tests_destroy(self, id: str) -> None:
        """
        ViewSet for ProxyTest.
        """
        url = f"/apix/proxies/tests/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


