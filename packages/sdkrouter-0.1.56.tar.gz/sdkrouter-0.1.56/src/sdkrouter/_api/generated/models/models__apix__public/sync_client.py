from __future__ import annotations

import httpx

from .models import (
    PaginatedProviderSummaryList,
    PaginatedPublicModelListList,
    PublicModelDetail,
    PublicShortcut,
    PublicStatsResponse,
    ResolveRequestRequest,
    ResolveResponse,
)


class SyncModelsPublicAPI:
    """Synchronous API endpoints for Public."""

    def __init__(self, client: httpx.Client):
        """Initialize sync sub-client with shared httpx client."""
        self._client = client

    def models_list(
        self,
        is_free: bool | None = None,
        min_context: int | None = None,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        provider: str | None = None,
        search: str | None = None,
        supports_image: bool | None = None,
        supports_json_mode: bool | None = None,
        supports_streaming: bool | None = None,
        supports_tools: bool | None = None,
        supports_vision: bool | None = None,
    ) -> list[PaginatedPublicModelListList]:
        """
        List models

        Paginated list of active LLM models.
        """
        url = "/apix/public/models/"
        _params = {
            k: v for k, v in {
                "is_free": is_free,
                "min_context": min_context,
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "provider": provider,
                "search": search,
                "supports_image": supports_image,
                "supports_json_mode": supports_json_mode,
                "supports_streaming": supports_streaming,
                "supports_tools": supports_tools,
                "supports_vision": supports_vision,
            }.items() if v is not None
        }
        response = self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedPublicModelListList.model_validate(response.json())


    def models_retrieve(self, model_id: str) -> PublicModelDetail:
        """
        Get model details

        Detailed info about a model.
        """
        url = f"/apix/public/models/{model_id}/"
        response = self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PublicModelDetail.model_validate(response.json())


    def models_providers_list(
        self,
        is_free: bool | None = None,
        min_context: int | None = None,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        provider: str | None = None,
        search: str | None = None,
        supports_image: bool | None = None,
        supports_json_mode: bool | None = None,
        supports_streaming: bool | None = None,
        supports_tools: bool | None = None,
        supports_vision: bool | None = None,
    ) -> list[PaginatedProviderSummaryList]:
        """
        List providers

        Provider summary with model counts.
        """
        url = "/apix/public/models/providers/"
        _params = {
            k: v for k, v in {
                "is_free": is_free,
                "min_context": min_context,
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "provider": provider,
                "search": search,
                "supports_image": supports_image,
                "supports_json_mode": supports_json_mode,
                "supports_streaming": supports_streaming,
                "supports_tools": supports_tools,
                "supports_vision": supports_vision,
            }.items() if v is not None
        }
        response = self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedProviderSummaryList.model_validate(response.json())


    def models_resolve_create(self, data: ResolveRequestRequest) -> ResolveResponse:
        """
        Resolve alias

        Resolve a model alias (@cheap, @smart+tools) to a concrete model ID.
        """
        url = "/apix/public/models/resolve/"
        response = self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ResolveResponse.model_validate(response.json())


    def models_stats_retrieve(self) -> PublicStatsResponse:
        """
        Aggregate statistics

        Stats, available presets, capabilities, and categories.
        """
        url = "/apix/public/models/stats/"
        response = self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PublicStatsResponse.model_validate(response.json())


    def shortcuts_list(
        self,
        ordering: str | None = None,
        search: str | None = None,
    ) -> list[PublicShortcut]:
        """
        List shortcuts

        Active model shortcuts.
        """
        url = "/apix/public/shortcuts/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "search": search,
            }.items() if v is not None
        }
        response = self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return [PublicShortcut.model_validate(item) for item in response.json()]


    def shortcuts_retrieve(self, slug: str) -> PublicShortcut:
        """
        Public read-only model shortcuts.
        """
        url = f"/apix/public/shortcuts/{slug}/"
        response = self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PublicShortcut.model_validate(response.json())


