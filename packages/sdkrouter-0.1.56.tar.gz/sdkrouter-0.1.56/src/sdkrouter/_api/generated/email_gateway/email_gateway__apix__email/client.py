from __future__ import annotations

import httpx

from .models import (
    EmailAccountCreateRequest,
    EmailAccountList,
    EmailMessageList,
    EmailSendRequest,
    EmailSendResponse,
    TestConnectionResponse,
)


class EmailGatewayEmailAPI:
    """API endpoints for Email."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def accounts_list(self) -> list[EmailAccountList]:
        url = "/apix/email/accounts/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return [EmailAccountList.model_validate(item) for item in response.json()]


    async def accounts_destroy(self, id: str) -> None:
        url = f"/apix/email/accounts/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def accounts_test_create(self, id: str) -> TestConnectionResponse:
        url = f"/apix/email/accounts/{id}/test/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return TestConnectionResponse.model_validate(response.json())


    async def accounts_create_create(
        self,
        data: EmailAccountCreateRequest,
    ) -> EmailAccountList:
        url = "/apix/email/accounts/create/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return EmailAccountList.model_validate(response.json())


    async def messages_list(self) -> list[EmailMessageList]:
        url = "/apix/email/messages/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return [EmailMessageList.model_validate(item) for item in response.json()]


    async def send_create(self, data: EmailSendRequest) -> EmailSendResponse:
        url = "/apix/email/send/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return EmailSendResponse.model_validate(response.json())


