"""Type definitions for SDK resources."""

from .cdn import CDNFile, CDNUploadRequest
from .models import ModelInfo, ModelPricing
from .ocr import OCRRequest, OCRResponse
from .parsed import ParsedChatCompletion, ParsedChoice, ParsedMessage, SDKRouterMeta
from .shortlinks import ShortLink, ShortLinkCreateRequest
from .vision import VisionAnalyzeRequest, VisionAnalyzeResponse
from .deepgram import (
    DeepgramConfig,
    DeepgramResults,
    DeepgramMetadata,
    DeepgramError,
    DeepgramWord,
    DeepgramAlternative,
    DeepgramChannel,
    TranscriptSegment,
    TranscriptWord,
    StreamReady,
    StreamDone,
    StreamError,
)

__all__ = [
    # CDN
    "CDNFile",
    "CDNUploadRequest",
    # Models
    "ModelInfo",
    "ModelPricing",
    # OCR
    "OCRRequest",
    "OCRResponse",
    # Parsed (structured output)
    "ParsedChatCompletion",
    "ParsedChoice",
    "ParsedMessage",
    "SDKRouterMeta",
    # Shortlinks
    "ShortLink",
    "ShortLinkCreateRequest",
    # Vision
    "VisionAnalyzeRequest",
    "VisionAnalyzeResponse",
    # Deepgram streaming
    "DeepgramConfig",
    "DeepgramResults",
    "DeepgramMetadata",
    "DeepgramError",
    "DeepgramWord",
    "DeepgramAlternative",
    "DeepgramChannel",
    "TranscriptSegment",
    "TranscriptWord",
    "StreamReady",
    "StreamDone",
    "StreamError",
]
