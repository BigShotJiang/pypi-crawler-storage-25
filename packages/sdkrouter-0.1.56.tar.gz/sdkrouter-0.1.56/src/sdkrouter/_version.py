"""Version information."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("sdkrouter")
except PackageNotFoundError:
    __version__ = "0.1.33"  # fallback for dev installs
