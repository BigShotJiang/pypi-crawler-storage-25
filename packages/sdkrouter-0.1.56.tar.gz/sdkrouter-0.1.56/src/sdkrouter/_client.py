"""Backward-compatible re-export from client package.

All logic lives in sdkrouter/client/ now.
This file exists so existing `from sdkrouter._client import ...` still works.
"""

from .client import SDKRouter, AsyncSDKRouter
from .client._helpers import merge_provider_extra_body as _merge_provider_extra_body, parse_completion as _parse_completion

__all__ = ["SDKRouter", "AsyncSDKRouter", "_merge_provider_extra_body", "_parse_completion"]
