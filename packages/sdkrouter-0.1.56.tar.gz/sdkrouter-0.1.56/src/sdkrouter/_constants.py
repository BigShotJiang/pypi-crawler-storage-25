"""SDK constants and defaults."""

# Environment variable names
ENV_API_KEY = "SDKROUTER_API_KEY"
ENV_OPENROUTER_KEY = "OPENROUTER_API_KEY"
ENV_LLM_URL = "SDKROUTER_LLM_URL"
ENV_API_URL = "SDKROUTER_API_URL"
ENV_AUDIO_URL = "SDKROUTER_AUDIO_URL"
ENV_TELEGRAM_URL = "SDKROUTER_TELEGRAM_URL"

# Default URLs (production)
HOMEPAGE_URL = "https://sdkrouter.com"
DEFAULT_LLM_URL = "https://llm.sdkrouter.com"
DEFAULT_API_URL = "https://api.sdkrouter.com"
DEFAULT_AUDIO_URL = "https://audio.sdkrouter.com"
DEFAULT_TELEGRAM_URL = "https://telegram.sdkrouter.com"

# Dev URLs (localhost)
DEV_LLM_URL = "http://localhost:8001"
DEV_API_URL = "http://localhost:8000"
DEV_AUDIO_URL = "http://localhost:8001"
DEV_TELEGRAM_URL = "http://localhost:8003"

# Direct provider URLs (bypass self-hosted)
OPENROUTER_URL = "https://openrouter.ai/api/v1"
OPENAI_DIRECT_URL = "https://api.openai.com/v1"

# Default settings
DEFAULT_TIMEOUT = 60.0
DEFAULT_CONNECT_TIMEOUT = 5.0
DEFAULT_UPLOAD_TIMEOUT = 300.0  # 5 min for file uploads (CDN, etc.)
DEFAULT_MAX_RETRIES = 2
