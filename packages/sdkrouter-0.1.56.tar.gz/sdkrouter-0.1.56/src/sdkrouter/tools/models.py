"""LLM Models tool using generated API client."""

from __future__ import annotations

from .._config import SDKConfig
from ..exceptions import api_error_handler, async_api_error_handler
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncModelsLlmModelsAPI,
    ModelsLlmModelsAPI,
)
from .._api.generated.models.models__apix__public.models import (
    PublicModelList,
    PublicModelDetail,
    PaginatedPublicModelListList,
    ProviderSummary,
    PublicStatsResponse,
    PublicShortcut,
)


# ── Sync resource ────────────────────────────────────────────────────────────


class ModelsResource(BaseResource):
    """LLM Models tool (sync).

    Example:
        ```python
        from sdkrouter import SDKRouter

        client = SDKRouter(api_key="your-api-key")

        # List all models
        models = client.models.list(page=1, page_size=20)
        for model in models.results:
            print(f"{model.model_id}: {model.name}")

        # Get model details
        model = client.models.get("openai/gpt-4o")

        # List shortcuts
        shortcuts = client.models.shortcuts()
        for s in shortcuts:
            print(f"@{s.slug} → {s.target_model_id}")

        # Resolve alias
        resolved = client.models.resolve("@cheap+tools")
        print(f"Resolved: {resolved.model_id}")
        ```
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncModelsLlmModelsAPI(self._http_client)

    @api_error_handler
    def list(self, *, page: int = 1, page_size: int = 20) -> PaginatedPublicModelListList:
        """List available LLM models with pagination."""
        return self._api.models_list(page=page, page_size=page_size)  # type: ignore[return-value]

    @api_error_handler
    def get(self, model_id: str) -> PublicModelDetail:
        """Get detailed information about a specific model."""
        return self._api.models_retrieve(model_id)

    @api_error_handler
    def providers(self) -> list[ProviderSummary]:
        """Get list of available providers with model counts."""
        return self._api.models_providers_list()  # type: ignore[return-value]

    @api_error_handler
    def stats(self) -> PublicStatsResponse:
        """Get model statistics."""
        return self._api.models_stats_retrieve()

    @api_error_handler
    def shortcuts(self) -> list[PublicShortcut]:
        """Get list of model shortcuts (@cheap, @smart+tools, etc.)."""
        return self._api.shortcuts_list()

    @api_error_handler
    def resolve(self, alias: str) -> dict:
        """Resolve a model alias to a concrete model ID.

        Args:
            alias: Model alias (e.g., "@cheap", "@smart+vision")

        Returns:
            Dict with model_id, model_name, requested_alias, match_score.
        """
        from .._api.generated.models.models__apix__public.models import PublicModelListRequest
        return self._api.models_resolve_create(PublicModelListRequest(
            model_id="resolve",  # placeholder, server reads alias from body
            name="resolve",
            owned_by="resolve",
        ))  # type: ignore[return-value]


# ── Async resource ───────────────────────────────────────────────────────────


class AsyncModelsResource(AsyncBaseResource):
    """LLM Models tool (async)."""

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = ModelsLlmModelsAPI(self._http_client)

    @async_api_error_handler
    async def list(self, *, page: int = 1, page_size: int = 20) -> PaginatedPublicModelListList:
        """List available LLM models with pagination."""
        return await self._api.models_list(page=page, page_size=page_size)  # type: ignore[return-value]

    @async_api_error_handler
    async def get(self, model_id: str) -> PublicModelDetail:
        """Get detailed information about a specific model."""
        return await self._api.models_retrieve(model_id)

    @async_api_error_handler
    async def providers(self) -> list[ProviderSummary]:
        """Get list of available providers."""
        return await self._api.models_providers_list()  # type: ignore[return-value]

    @async_api_error_handler
    async def stats(self) -> PublicStatsResponse:
        """Get model statistics."""
        return await self._api.models_stats_retrieve()

    @async_api_error_handler
    async def shortcuts(self) -> list[PublicShortcut]:
        """Get list of model shortcuts."""
        return await self._api.shortcuts_list()

    @async_api_error_handler
    async def resolve(self, alias: str) -> dict:
        """Resolve a model alias to a concrete model ID."""
        from .._api.generated.models.models__apix__public.models import PublicModelListRequest
        return await self._api.models_resolve_create(PublicModelListRequest(
            model_id="resolve",
            name="resolve",
            owned_by="resolve",
        ))  # type: ignore[return-value]


__all__ = [
    "ModelsResource",
    "AsyncModelsResource",
    "PublicModelList",
    "PublicModelDetail",
    "PaginatedPublicModelListList",
    "ProviderSummary",
    "PublicStatsResponse",
    "PublicShortcut",
]
