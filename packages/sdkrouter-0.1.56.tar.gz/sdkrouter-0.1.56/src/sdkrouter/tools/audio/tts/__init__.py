"""Text-to-Speech (TTS) providers.

Supports:
- OpenAI TTS (REST API with streaming)
"""

from .openai import (
    OpenAITTS,
    AsyncOpenAITTS,
)

__all__ = [
    "OpenAITTS",
    "AsyncOpenAITTS",
]
