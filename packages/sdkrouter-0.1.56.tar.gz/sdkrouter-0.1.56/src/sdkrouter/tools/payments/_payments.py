"""Payments invoices domain — sync and async mixins."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from ...exceptions import api_error_handler, async_api_error_handler
from ..._api.generated.payments.payments__apix__payments.models import (
    InvoiceCreateRequest,
    InvoiceDetail,
    InvoiceResponse,
    PaginatedInvoiceDetailList,
)


class _PaymentsMixin:
    """Sync payment invoice methods."""

    _api: Any

    @api_error_handler
    def create(
        self,
        *,
        amount_usd: float | Decimal | str,
        network: str | None = None,
        exchange: str | None = None,
        customer_id: str,
        project_slug: str,
        description: str | None = None,
    ) -> InvoiceResponse:
        """Create a new payment invoice."""
        request = InvoiceCreateRequest(
            amount_usd=str(amount_usd),
            network=network,
            exchange=exchange,
            customer_id=customer_id,
            project_slug=project_slug,
            description=description,
        )
        return self._api.invoices_create_create(request)

    @api_error_handler
    def list(self, *, page: int = 1, page_size: int = 20) -> PaginatedInvoiceDetailList:
        """List invoices."""
        return self._api.invoices_list(page=page, page_size=page_size)

    @api_error_handler
    def get(self, invoice_id: str) -> InvoiceDetail:
        """Get invoice details."""
        return self._api.invoices_retrieve(invoice_id)


class _AsyncPaymentsMixin:
    """Async payment invoice methods."""

    _api: Any

    @async_api_error_handler
    async def create(
        self,
        *,
        amount_usd: float | Decimal | str,
        network: str | None = None,
        exchange: str | None = None,
        customer_id: str,
        project_slug: str,
        description: str | None = None,
    ) -> InvoiceResponse:
        """Create a new payment invoice."""
        request = InvoiceCreateRequest(
            amount_usd=str(amount_usd),
            network=network,
            exchange=exchange,
            customer_id=customer_id,
            project_slug=project_slug,
            description=description,
        )
        return await self._api.invoices_create_create(request)

    @async_api_error_handler
    async def list(self, *, page: int = 1, page_size: int = 20) -> PaginatedInvoiceDetailList:
        """List invoices."""
        return await self._api.invoices_list(page=page, page_size=page_size)

    @async_api_error_handler
    async def get(self, invoice_id: str) -> InvoiceDetail:
        """Get invoice details."""
        return await self._api.invoices_retrieve(invoice_id)
