"""Payments credentials domain — sync and async mixins.

NOTE: Credentials API has been removed from the backend.
These mixins are kept as empty stubs for backwards compatibility.
"""

from __future__ import annotations


class _CredentialsMixin:
    """Sync credentials methods (removed from API)."""


class _AsyncCredentialsMixin:
    """Async credentials methods (removed from API)."""
