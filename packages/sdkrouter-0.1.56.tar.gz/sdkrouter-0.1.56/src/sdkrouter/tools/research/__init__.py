"""Web Research tool — synchronous and asynchronous research resources.

Provides Serper web search, full research pipeline (search + crawl + LLM),
async job queuing with polling, and job management.

Example::

    from sdkrouter import SDKRouter

    client = SDKRouter(api_key="sk_live_xxx")

    # Quick search
    result = client.research.search("latest AI developments")
    print(result.search_results)

    # Full research (search + crawl + summarize)
    report = client.research.research("Python async patterns", wait=True)
    print(report.summary)

    # Fire-and-forget
    job = client.research.research("Django best practices", wait=False)
    status = client.research.job_status(job.request_uuid)
"""

from __future__ import annotations

from ._resource import AsyncResearchResource, ResearchResource
from ..._api.generated.research.research__apix__research.models import (
    AsyncResearchResponse,
    JobStatus,
    ResearchRequestList,
    ResearchRequestRequest,
    ResearchResponse,
    SearchRequestRequest,
    SerperResult,
    CrawledPage,
)

__all__ = [
    "ResearchResource",
    "AsyncResearchResource",
    # Models
    "AsyncResearchResponse",
    "JobStatus",
    "ResearchRequestList",
    "ResearchRequestRequest",
    "ResearchResponse",
    "SearchRequestRequest",
    "SerperResult",
    "CrawledPage",
]
