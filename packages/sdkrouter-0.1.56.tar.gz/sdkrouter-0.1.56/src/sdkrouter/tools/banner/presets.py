"""Enums and presets for the banner generator."""

from __future__ import annotations

from enum import Enum


# ── Image quality enum ────────────────────────────────────────────────────────

class BannerQuality(str, Enum):
    """Image generation quality."""
    STANDARD = "standard"
    HD       = "hd"


# ── Image style enum ──────────────────────────────────────────────────────────

class BannerImageStyle(str, Enum):
    """Image generation style (affects rendering approach)."""
    NATURAL = "natural"
    VIVID   = "vivid"


# ── Image model enum ──────────────────────────────────────────────────────────

class BannerModel(str, Enum):
    """Image generation model alias."""
    CHEAP    = "@cheap"     # google/gemini-2.5-flash-image
    FAST     = "@fast"      # google/gemini-2.5-flash-image
    BALANCED = "@balanced"  # openai/gpt-5-image-mini
    SMART    = "@smart"     # google/gemini-3-pro-image-preview


# ── LLM model enum ────────────────────────────────────────────────────────────

class BannerLLMModel(str, Enum):
    """LLM model alias for prompt generation."""
    CHEAP    = "@cheap"
    FAST     = "@fast"
    BALANCED = "@balanced"
    SMART    = "@smart"


# ── Size enum ─────────────────────────────────────────────────────────────────

class BannerSize(str, Enum):
    """Image size / aspect ratio preset."""
    GITHUB = "github"   # 1792x1024 — README.md hero (16:9)
    SOCIAL = "social"   # 1200x630  — Twitter / LinkedIn card
    OG     = "og"       # 1200x630  — OpenGraph meta image
    WIDE   = "wide"     # 1792x512  — Wide website banner
    SQUARE = "square"   # 1024x1024 — npm / PyPI avatar / icon

    def dimensions(self) -> str:
        return _SIZE_DIMENSIONS[self]


_SIZE_DIMENSIONS: dict[BannerSize, str] = {
    BannerSize.GITHUB: "1792x1024",
    BannerSize.SOCIAL: "1200x630",
    BannerSize.OG:     "1200x630",
    BannerSize.WIDE:   "1792x512",
    BannerSize.SQUARE: "1024x1024",
}

# Keep dict alias for backwards compat / image_gen API
PRESETS: dict[str, str] = {s.value: s.dimensions() for s in BannerSize}


# ── Visual style enum ─────────────────────────────────────────────────────────
# These are HINTS passed to the LLM — not final prompts.
# The LLM always runs; the preset only steers the aesthetic direction.

class BannerStyle(str, Enum):
    """Visual style hint for LLM prompt generation."""

    # Dark navy, frosted glass panels, neon teal — API gateways, SDKs, LLM routers
    GLASSMORPHISM = "glassmorphism"

    # Pastel 3D boxes, geometric layout — CLI tools, data pipelines, microservices
    ISOMETRIC = "isometric"

    # Glowing nodes in deep space, data streams — AI/ML, vector search, LLMs
    AI_NETWORK = "ai_network"

    # Neon circuit lines, holographic, matrix rain — GPU tools, real-time systems
    CYBERPUNK = "cyberpunk"

    # White lines on navy, technical schematic — DevOps, infrastructure, Docker
    BLUEPRINT = "blueprint"

    # Smooth gradient, geometric, SaaS feel — web frameworks, open-source libs
    MINIMAL = "minimal"

    # Light beams, motion blur, fiber optic — CDN, proxy, shortlinks
    SPEED = "speed"

    # Friendly 3D mascot, studio lighting — beginner tools, educational projects
    PIXAR = "pixar"

    # Iridescent surfaces, rainbow refraction — AI assistants, next-gen APIs
    HOLOGRAPHIC = "holographic"

    # Flowing organic gradient, glassmorphism — SaaS products, productivity tools
    GRADIENT_MESH = "gradient_mesh"

    def hint(self) -> str:
        """Short aesthetic description passed to the LLM as a style direction."""
        return _STYLE_HINTS[self]


_STYLE_HINTS: dict[BannerStyle, str] = {
    BannerStyle.GLASSMORPHISM: (
        "Dark glassmorphism aesthetic: deep navy background, floating frosted-glass panels "
        "with subtle blue glow, interconnected neon teal data nodes, purple-teal-navy palette."
    ),
    BannerStyle.ISOMETRIC: (
        "Isometric 3D illustration: clean modular boxes with connecting arrows, "
        "soft pastel tech palette (lavender, mint, cream), matte finish, subtle drop shadows."
    ),
    BannerStyle.AI_NETWORK: (
        "Cinematic AI network: glowing nodes floating in deep space (#060610), "
        "multi-colored data streams, extreme depth of field, orange-purple-teal accents."
    ),
    BannerStyle.CYBERPUNK: (
        "Cyberpunk neon grid: electric blue and purple circuit lines on dark grid, "
        "holographic interface elements, matrix-inspired data rain, reflective dark surface."
    ),
    BannerStyle.BLUEPRINT: (
        "Engineering blueprint: precise white and cyan lines on deep navy, grid overlay, "
        "microservice architecture schematic, clean geometric forms, subtle node glow."
    ),
    BannerStyle.MINIMAL: (
        "Minimal gradient: smooth indigo-to-violet gradient, abstract geometric shapes, "
        "light soft background, glassmorphism card elements, modern SaaS aesthetic."
    ),
    BannerStyle.SPEED: (
        "Speed / fiber optic: light beams at extreme speed, motion blur in electric white "
        "and cyan, deep black background, global infrastructure feel."
    ),
    BannerStyle.PIXAR: (
        "Pixar/Disney 3D render quality (like Inside Out or The Incredibles): "
        "characters with BIG emotive eyes, exaggerated poses, over-the-top reactions, "
        "studio three-point lighting with colored accent glow, vivid saturated colors, "
        "subsurface scattering, global illumination, rich materials. "
        "4-panel comic strip format with humor, sarcasm, and developer culture references."
    ),
    BannerStyle.HOLOGRAPHIC: (
        "Holographic iridescent: translucent surfaces reflecting rainbow spectrum, "
        "futuristic floating panels, deep dark background, crystalline geometric shapes."
    ),
    BannerStyle.GRADIENT_MESH: (
        "Abstract gradient mesh: flowing organic shapes blending electric blue, deep purple "
        "and warm coral, glassmorphism overlay, smooth transitions, modern SaaS flair."
    ),
}


# ── Image model family resolver ───────────────────────────────────────────────

class ImageModelFamily(str, Enum):
    """Image generation model family — determines prompt style rules.

    Only families actually available through SDKRouter/OpenRouter:
    - DALLE:  OpenAI image models (gpt-image-1, gpt-5-image-mini, dall-e-3)
    - GEMINI: Google Gemini image models (gemini-2.5-flash-image, gemini-3-pro-image)
    - UNKNOWN: fallback → uses DALLE rules (safe default)
    """
    DALLE   = "dalle"
    GEMINI  = "gemini"
    UNKNOWN = "unknown"


_DALLE_PATTERNS = (
    # OpenAI image models (GPT-image-1, DALL-E 3, gpt-image family)
    "dall-e", "dalle", "gpt-image", "gpt-5-image", "openai/",
)
_GEMINI_PATTERNS = (
    # Google Gemini image generation (via OpenRouter)
    "gemini", "google/", "imagen",
)

# @-alias → resolved family.
# Based on SDKRouter's actual model routing:
#   @cheap / @fast  → google/gemini-2.5-flash-image   (Gemini)
#   @balanced       → openai/gpt-5-image-mini          (DALL-E/GPT-image)
#   @smart          → google/gemini-3-pro-image-preview (Gemini)
_ALIAS_FAMILY: dict[str, ImageModelFamily] = {
    "@cheap":    ImageModelFamily.GEMINI,
    "@fast":     ImageModelFamily.GEMINI,
    "@balanced": ImageModelFamily.DALLE,
    "@smart":    ImageModelFamily.GEMINI,
}


def resolve_model_family(model: str) -> ImageModelFamily:
    """Resolve an image model alias/id to its prompt-engineering family.

    Supports:
    - @-aliases: @cheap, @fast, @balanced, @smart
    - OpenAI: gpt-image-1, dall-e-3, openai/gpt-5-image-mini
    - Google Gemini: google/gemini-2.5-flash-image, gemini-3-pro-image-preview

    Returns ImageModelFamily.UNKNOWN (→ DALLE rules) for unrecognised models.
    """
    m = model.lower().strip()

    if m in _ALIAS_FAMILY:
        return _ALIAS_FAMILY[m]

    # Unknown @-alias → default to Gemini (most common in our stack)
    if m.startswith("@"):
        return ImageModelFamily.GEMINI

    for pat in _GEMINI_PATTERNS:
        if pat in m:
            return ImageModelFamily.GEMINI

    for pat in _DALLE_PATTERNS:
        if pat in m:
            return ImageModelFamily.DALLE

    return ImageModelFamily.UNKNOWN


# ── Defaults ──────────────────────────────────────────────────────────────────

DEFAULT_SIZE      = BannerSize.GITHUB
DEFAULT_STYLE     = BannerStyle.PIXAR
DEFAULT_MODEL     = BannerModel.SMART
DEFAULT_LLM_MODEL = BannerLLMModel.SMART
DEFAULT_QUALITY   = BannerQuality.HD
DEFAULT_IMAGE_STYLE = BannerImageStyle.VIVID


__all__ = [
    "BannerSize",
    "BannerStyle",
    "BannerModel",
    "BannerLLMModel",
    "BannerQuality",
    "BannerImageStyle",
    "ImageModelFamily",
    "PRESETS",
    "resolve_model_family",
    "DEFAULT_SIZE",
    "DEFAULT_STYLE",
    "DEFAULT_MODEL",
    "DEFAULT_LLM_MODEL",
    "DEFAULT_QUALITY",
    "DEFAULT_IMAGE_STYLE",
]
