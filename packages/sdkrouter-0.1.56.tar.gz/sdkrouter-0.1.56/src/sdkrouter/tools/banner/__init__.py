"""Banner / hero image generator for README.md and other project files.

The LLM always runs and writes a model-aware image generation prompt based on:
- Project context (README, title, description, GitHub URL)
- Visual style direction (BannerStyle enum)
- Target image model's prompt rules (DALL-E vs Flux vs Flux Kontext)

Example:
    from sdkrouter import SDKRouter
    from sdkrouter.tools.banner import BannerStyle, BannerSize

    client = SDKRouter(api_key="sk_live_xxx")

    # LLM picks style automatically from README context
    result = client.banner.generate(
        source="README.md",
        output="assets/banner.png",
    )

    # Steer the LLM with a visual style preset (enum)
    result = client.banner.generate(
        source="README.md",
        preset=BannerStyle.GLASSMORPHISM,   # aesthetic direction for LLM
        size=BannerSize.GITHUB,             # 1792x1024
        model="@smart",
        output="banner.png",
    )

    # String values also work
    result = client.banner.generate(
        title="My API Gateway",
        preset="cyberpunk",
        size="social",
        output="social.png",
    )

    # Dry run — see what prompt the LLM generates
    result = client.banner.generate(
        source="README.md",
        preset=BannerStyle.AI_NETWORK,
        dry_run=True,
    )
    print(result.prompt)
"""

from .presets import (
    BannerSize,
    BannerStyle,
    BannerModel,
    BannerLLMModel,
    BannerQuality,
    BannerImageStyle,
    ImageModelFamily,
    PRESETS,
    resolve_model_family,
    DEFAULT_SIZE,
    DEFAULT_STYLE,
    DEFAULT_MODEL,
    DEFAULT_LLM_MODEL,
    DEFAULT_QUALITY,
    DEFAULT_IMAGE_STYLE,
)
from ._types import BannerResult
from .resource import BannerResource, AsyncBannerResource

__all__ = [
    "BannerResource",
    "AsyncBannerResource",
    "BannerResult",
    # Enums
    "BannerSize",
    "BannerStyle",
    "BannerModel",
    "BannerLLMModel",
    "BannerQuality",
    "BannerImageStyle",
    "ImageModelFamily",
    # Helpers
    "PRESETS",
    "resolve_model_family",
    # Defaults
    "DEFAULT_SIZE",
    "DEFAULT_STYLE",
    "DEFAULT_MODEL",
    "DEFAULT_LLM_MODEL",
    "DEFAULT_QUALITY",
    "DEFAULT_IMAGE_STYLE",
]
