"""Telegram Bot API proxy tool.

Two HTTP clients are used:
- api_url  (Django)   → bot management (register, list, deactivate, set_webhook)
- telegram_url (FastAPI telegram_service) → proxy calls (send, call any method)
"""

import logging
from ..._config import SDKConfig
from ..._api.client import (
    BaseResource, AsyncBaseResource,
    SyncTelegramTelegramAPI, TelegramTelegramAPI,
)
from ._types import BotInfo, ChannelMessage, TelegramResult, MTProtoMessage, MTProtoUserInfo
from ._bot import BotMixin, AsyncBotMixin
from ._proxy import ProxyMixin, AsyncProxyMixin
from ._mtproto import MTProtoMixin, AsyncMTProtoMixin
from .monitor import AsyncMonitorMixin, ChannelMonitor, MonitorConfig, MonitorAlert

logger = logging.getLogger(__name__)


class TelegramResource(BotMixin, ProxyMixin, MTProtoMixin, BaseResource):
    """Telegram Bot API proxy — sync.

    Example:
        ```python
        from sdkrouter import SDKRouter

        client = SDKRouter(api_key="sk_live_xxx")

        # Register a bot (once)
        bot = client.telegram.register(
            alias="support_bot",
            token="7123456789:AAF...",
            callback_url="https://myapp.com/updates",
        )

        # Send a message
        client.telegram.send_message(
            bot="support_bot",
            chat_id=123456,
            text="Hello!",
        )

        # Any Telegram API method
        client.telegram.call("support_bot", "answerCallbackQuery",
                             callback_query_id="abc", text="Done!")
        ```
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)                              # api_url for CRUD
        self._api = SyncTelegramTelegramAPI(self._http_client)
        # Separate client pointing at telegram_service
        self._tg_client = self._factory.create_sync_client(use_telegram_url=True)


class AsyncTelegramResource(
    AsyncBotMixin, AsyncProxyMixin, AsyncMTProtoMixin, AsyncMonitorMixin, AsyncBaseResource,
):
    """Telegram Bot API proxy — async."""

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = TelegramTelegramAPI(self._http_client)
        self._tg_client = self._factory.create_async_client(use_telegram_url=True)


__all__ = [
    "TelegramResource",
    "AsyncTelegramResource",
    "BotInfo",
    "ChannelMessage",
    "TelegramResult",
    "MTProtoMessage",
    "MTProtoUserInfo",
    "ChannelMonitor",
    "MonitorConfig",
    "MonitorAlert",
]
