"""Pydantic models for monitor alerts and LLM analysis."""

from __future__ import annotations

from pydantic import BaseModel, Field


class MonitorAlert(BaseModel):
    """Alert yielded by the channel monitor."""

    message_id: int
    channel: str
    topic: str
    urgency: str = "low"  # "low" | "medium" | "high"
    summary: str = ""
    original_text: str = ""
    timestamp: str = ""
    sender_id: int | None = None

    model_config = {"extra": "allow"}


class MessageAnalysis(BaseModel):
    """LLM analysis of a single message (internal)."""

    message_id: int = Field(description="Original message_id from input")
    is_alert: bool = Field(description="True if message matches any monitored topic")
    topic: str = Field(default="", description="Which topic matched (empty if none)")
    urgency: str = Field(default="low", description="low / medium / high")
    summary: str = Field(default="", description="1-2 sentence summary in Russian")


class BatchAnalysis(BaseModel):
    """LLM analysis of a batch of messages (internal)."""

    results: list[MessageAnalysis]
