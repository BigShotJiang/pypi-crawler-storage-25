"""Monitor configuration model."""

from __future__ import annotations

from pydantic import BaseModel, Field


class MonitorConfig(BaseModel):
    """Configuration for the Telegram channel monitor."""

    account: str = "main"
    channels: list[str] = Field(description="Channels to monitor (e.g. ['@forklogAI'])")
    topics: list[str] = Field(description="Topics to watch for via LLM analysis")
    bot: str = ""
    admin_ids: list[int | str] = Field(
        default_factory=list,
        description="Chat IDs to send alerts to via bot",
    )
    model: str = "deepseek/deepseek-chat-v3-0324"
    interval: float = 10.0
    batch_size: int = 50
    max_concurrent_llm: int = 5
    min_text_length: int = 10
    max_text_length: int = 2000
    prompt_template: str | None = None

    model_config = {"extra": "allow"}
