"""HTML formatting for monitor alerts sent via Telegram bot."""

from __future__ import annotations

from ._types import MonitorAlert

URGENCY_ICON = {"high": "🔴", "medium": "🟡", "low": "🟢"}


def format_alert_html(alert: MonitorAlert) -> str:
    """Format a MonitorAlert as HTML for Telegram bot message."""
    icon = URGENCY_ICON.get(alert.urgency, "⚪")
    text = alert.original_text[:400] if alert.original_text else ""

    parts = [
        f"{icon} <b>{alert.topic}</b>",
        f"📢 {alert.channel} • #{alert.message_id}",
        "",
        alert.summary,
    ]

    if text:
        parts.append("")
        parts.append(f"<blockquote>{text}</blockquote>")

    return "\n".join(parts)
