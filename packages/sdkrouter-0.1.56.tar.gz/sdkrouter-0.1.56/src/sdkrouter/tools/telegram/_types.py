from pydantic import BaseModel
from typing import Any


class BotInfo(BaseModel):
    alias: str
    bot_username: str = ""
    bot_id: int | None = None
    is_active: bool = True
    webhook_set: bool = False
    callback_url: str = ""
    consecutive_errors: int = 0
    last_used_at: Any = None
    created_at: Any = None

    model_config = {"extra": "allow"}


class TelegramResult(BaseModel):
    """Raw Telegram API response (pass-through from proxy)."""
    ok: bool
    result: Any = None
    description: str = ""
    error_code: int = 0


class MTProtoMessage(BaseModel):
    """Sent message result from MTProto."""
    message_id: int
    date: str
    text: str = ""


class ChannelMessage(BaseModel):
    """Message from a channel/chat (MTProto)."""
    message_id: int
    date: str = ""
    text: str | None = None
    sender_id: int | None = None

    model_config = {"extra": "allow"}


class MTProtoUserInfo(BaseModel):
    """Account info from MTProto /me."""
    tg_user_id: int
    first_name: str = ""
    last_name: str = ""
    username: str = ""
    phone: str = ""

    model_config = {"extra": "allow"}
