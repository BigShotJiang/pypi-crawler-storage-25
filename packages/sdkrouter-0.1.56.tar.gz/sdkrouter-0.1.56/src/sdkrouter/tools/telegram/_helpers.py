"""Shared request helpers to deduplicate sync/async HTTP calls."""

from typing import Any

import httpx


def _sync_request(client: httpx.Client, method: str, path: str, **kwargs: Any) -> Any:
    """Execute a sync HTTP request, raise on error, return parsed JSON."""
    fn = getattr(client, method.lower())
    resp = fn(path, **kwargs)
    resp.raise_for_status()
    return resp.json()


async def _async_request(client: httpx.AsyncClient, method: str, path: str, **kwargs: Any) -> Any:
    """Execute an async HTTP request, raise on error, return parsed JSON."""
    fn = getattr(client, method.lower())
    resp = await fn(path, **kwargs)
    resp.raise_for_status()
    return resp.json()
