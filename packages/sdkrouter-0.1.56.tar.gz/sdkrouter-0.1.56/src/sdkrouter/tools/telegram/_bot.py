"""Bot management methods (Django API).

These use the generated API client (`self._api`) and cannot be easily
deduplicated because sync/async clients have different interfaces.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..._api.generated.telegram.telegram__apix__telegram.models import (
    TelegramRegisterBotRequest as RegisterBotRequest,
    TelegramSetWebhookRequest as SetWebhookRequest,
)
from ._types import BotInfo

if TYPE_CHECKING:
    from ..._api.client import SyncTelegramTelegramAPI, TelegramTelegramAPI


class BotMixin:
    """Sync bot management methods — mixed into TelegramResource."""

    _api: SyncTelegramTelegramAPI

    def register(self, alias: str, token: str, callback_url: str = "") -> BotInfo:
        """Register a Telegram bot. Token is encrypted server-side, never returned."""
        result = self._api.bots_register_create(
            RegisterBotRequest(alias=alias, token=token, callback_url=callback_url)
        )
        return BotInfo.model_validate(result.model_dump())

    def list_bots(self) -> list[BotInfo]:
        """List all bots registered under the current API key."""
        result = self._api.bots_list_list()
        items = result if isinstance(result, list) else getattr(result, "results", [result])
        return [BotInfo.model_validate(b.model_dump()) for b in items]

    def set_webhook(self, bot: str, callback_url: str) -> BotInfo:
        """Update the callback URL for incoming updates."""
        result = self._api.bots_set_webhook_create(
            bot, SetWebhookRequest(callback_url=callback_url)
        )
        return BotInfo.model_validate(result.model_dump())

    def deactivate(self, bot: str) -> BotInfo:
        """Deactivate a bot (proxy calls rejected, registration preserved)."""
        result = self._api.bots_deactivate_create(bot)
        return BotInfo.model_validate(result.model_dump())

    def delete(self, bot: str) -> None:
        """Permanently delete a bot (removes webhook from Telegram first)."""
        self._api.bots_delete_destroy(bot)


class AsyncBotMixin:
    """Async bot management methods — mixed into AsyncTelegramResource."""

    _api: TelegramTelegramAPI

    async def register(self, alias: str, token: str, callback_url: str = "") -> BotInfo:
        """Register a Telegram bot. Token is encrypted server-side, never returned."""
        result = await self._api.bots_register_create(
            RegisterBotRequest(alias=alias, token=token, callback_url=callback_url)
        )
        return BotInfo.model_validate(result.model_dump())

    async def list_bots(self) -> list[BotInfo]:
        """List all bots registered under the current API key."""
        result = await self._api.bots_list_list()
        items = result if isinstance(result, list) else getattr(result, "results", [result])
        return [BotInfo.model_validate(b.model_dump()) for b in items]

    async def set_webhook(self, bot: str, callback_url: str) -> BotInfo:
        """Update the callback URL for incoming updates."""
        result = await self._api.bots_set_webhook_create(
            bot, SetWebhookRequest(callback_url=callback_url)
        )
        return BotInfo.model_validate(result.model_dump())

    async def deactivate(self, bot: str) -> BotInfo:
        """Deactivate a bot (proxy calls rejected, registration preserved)."""
        result = await self._api.bots_deactivate_create(bot)
        return BotInfo.model_validate(result.model_dump())

    async def delete(self, bot: str) -> None:
        """Permanently delete a bot (removes webhook from Telegram first)."""
        await self._api.bots_delete_destroy(bot)
