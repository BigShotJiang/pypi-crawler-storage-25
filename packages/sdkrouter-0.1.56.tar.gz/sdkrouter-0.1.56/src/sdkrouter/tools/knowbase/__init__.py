"""Knowledge Base tool — manage projects, documents, sources and search.

Modular knowledge base capabilities:
- Projects: CRUD for KB projects
- Documents: upload Markdown/text, bulk ingest via ZIP/directory, polling
- Sources: GitHub repository crawling
- Search: semantic vector search

Example::

    from sdkrouter import SDKRouter

    client = SDKRouter(api_key="sk_live_xxx")

    # Create a project
    project = client.knowbase.projects.create(name="My Docs", slug="my-docs")

    # Upload a document
    doc = client.knowbase.documents("my-docs").upload(
        title="API Guide", content="# API Guide\\n...",
    )

    # Bulk ingest a directory and wait for completion
    resp = client.knowbase.documents("my-docs").upload_dir("/path/to/docs")
    status = client.knowbase.documents("my-docs").wait_for_archive_done(resp.job_id)

    # Add a GitHub source and trigger crawl
    source = client.knowbase.sources("my-docs").add(url="https://github.com/org/repo")
    client.knowbase.sources("my-docs").crawl(source.id)

    # Search
    results = client.knowbase.search("my-docs", "how to authenticate")
"""

from __future__ import annotations

# Re-export main resources (backward compatible with tools/knowbase.py)
from ._resource import AsyncKnowledgeBaseResource, KnowledgeBaseResource

# Re-export models consumed by callers
from ..._api.generated.knowbase.knowbase__apix__knowbase.models import (
    ArchiveBulkCreateResponse,
    ArchiveJobStatus,
    DataSource,
    DataSourceCreateRequest,
    DataSourceRequest,
    Document,
    DocumentUploadRequest,
    KBSearchResponse,
    KnowbaseProjectsDocumentsBulkCreateRequest,
    PaginatedDataSourceList,
    PaginatedDocumentList,
    PaginatedProjectList,
    PatchedDataSourceRequest,
    PatchedProjectRequest,
    Project,
    ProjectCreate,
    ProjectCreateRequest,
    SearchRequestRequest,
)

__all__ = [
    # Main resources (backward compatible)
    "KnowledgeBaseResource",
    "AsyncKnowledgeBaseResource",
    # Models
    "Project",
    "ProjectCreate",
    "PaginatedProjectList",
    "Document",
    "PaginatedDocumentList",
    "DataSource",
    "PaginatedDataSourceList",
    "KBSearchResponse",
    "SearchRequestRequest",
    "KnowbaseProjectsDocumentsBulkCreateRequest",
    "ArchiveBulkCreateResponse",
    "ArchiveJobStatus",
]
