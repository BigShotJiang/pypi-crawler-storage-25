"""Proxy assignment domain — sync and async mixins."""

from __future__ import annotations

from typing import Any

from ...exceptions import api_error_handler, async_api_error_handler
from ..._api.generated.proxies.proxies__apix__proxies.models import (
    PaginatedProxyAssignmentList,
    ProxyAssignment,
    ProxyAssignmentRequest,
    PatchedProxyAssignmentRequest,
)


class _AssignmentsMixin:
    """Sync assignment methods."""

    _api: Any

    @api_error_handler
    def list_assignments(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        search: str | None = None,
        ordering: str | None = None,
    ) -> PaginatedProxyAssignmentList:
        """List proxy assignments."""
        return self._api.assignments_list(page=page, page_size=page_size, search=search, ordering=ordering)

    @api_error_handler
    def get_assignment(self, assignment_id: str) -> ProxyAssignment:
        """Get assignment details."""
        return self._api.assignments_retrieve(assignment_id)

    @api_error_handler
    def create_assignment(
        self,
        *,
        proxy: str,
        parser_id: str,
        session_id: str | None = None,
        is_active: bool | None = None,
        priority: int | None = None,
    ) -> ProxyAssignment:
        """Create a proxy assignment."""
        request = ProxyAssignmentRequest(
            proxy=proxy,
            parser_id=parser_id,
            session_id=session_id,
            is_active=is_active,
            priority=priority,
        )
        return self._api.assignments_create(request)

    @api_error_handler
    def update_assignment(
        self,
        assignment_id: str,
        *,
        proxy: str | None = None,
        parser_id: str | None = None,
        session_id: str | None = None,
        is_active: bool | None = None,
        priority: int | None = None,
    ) -> ProxyAssignment:
        """Update an assignment (partial update)."""
        request = PatchedProxyAssignmentRequest(
            proxy=proxy,
            parser_id=parser_id,
            session_id=session_id,
            is_active=is_active,
            priority=priority,
        )
        return self._api.assignments_partial_update(assignment_id, request)

    @api_error_handler
    def delete_assignment(self, assignment_id: str) -> bool:
        """Delete an assignment."""
        self._api.assignments_destroy(assignment_id)
        return True

    @api_error_handler
    def get_active_assignments(self) -> list[ProxyAssignment]:
        """Get active assignments."""
        return self._api.assignments_active_retrieve()


class _AsyncAssignmentsMixin:
    """Async assignment methods."""

    _api: Any

    @async_api_error_handler
    async def list_assignments(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        search: str | None = None,
        ordering: str | None = None,
    ) -> PaginatedProxyAssignmentList:
        """List proxy assignments."""
        return await self._api.assignments_list(page=page, page_size=page_size, search=search, ordering=ordering)

    @async_api_error_handler
    async def get_assignment(self, assignment_id: str) -> ProxyAssignment:
        """Get assignment details."""
        return await self._api.assignments_retrieve(assignment_id)

    @async_api_error_handler
    async def create_assignment(
        self,
        *,
        proxy: str,
        parser_id: str,
        session_id: str | None = None,
        is_active: bool | None = None,
        priority: int | None = None,
    ) -> ProxyAssignment:
        """Create a proxy assignment."""
        request = ProxyAssignmentRequest(
            proxy=proxy,
            parser_id=parser_id,
            session_id=session_id,
            is_active=is_active,
            priority=priority,
        )
        return await self._api.assignments_create(request)

    @async_api_error_handler
    async def update_assignment(
        self,
        assignment_id: str,
        *,
        proxy: str | None = None,
        parser_id: str | None = None,
        session_id: str | None = None,
        is_active: bool | None = None,
        priority: int | None = None,
    ) -> ProxyAssignment:
        """Update an assignment (partial update)."""
        request = PatchedProxyAssignmentRequest(
            proxy=proxy,
            parser_id=parser_id,
            session_id=session_id,
            is_active=is_active,
            priority=priority,
        )
        return await self._api.assignments_partial_update(assignment_id, request)

    @async_api_error_handler
    async def delete_assignment(self, assignment_id: str) -> bool:
        """Delete an assignment."""
        await self._api.assignments_destroy(assignment_id)
        return True

    @async_api_error_handler
    async def get_active_assignments(self) -> list[ProxyAssignment]:
        """Get active assignments."""
        return await self._api.assignments_active_retrieve()
