# arya-core-types

Minimal stdlib-only ID primitives for ARYA Labs packages.

## Install

```bash
pip install git+https://github.com/ARYA-Labs-PBC/arya-core-types.git
```

## Usage

```python
from arya_core_types import new_id, DEFAULT_SEED

record_id = new_id("record")   # "record_<32-hex-chars>"
seed = DEFAULT_SEED            # 135356
```

## Zero dependencies

`arya-core-types` uses only the Python standard library (`uuid`).
