"""Core ID primitives — stdlib only, zero non-stdlib deps."""
from __future__ import annotations

import uuid

DEFAULT_SEED: int = 135356


def new_id(prefix: str) -> str:
    """Return a globally-unique ``prefix``-namespaced identifier."""
    return f"{prefix}_{uuid.uuid4().hex}"
