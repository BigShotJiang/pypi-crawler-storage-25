"""arya-core-types — minimal stdlib-only ID primitives for ARYA Labs packages."""
from arya_core_types._core import DEFAULT_SEED, new_id

__version__ = "0.1.0"
__all__ = ["DEFAULT_SEED", "new_id"]
