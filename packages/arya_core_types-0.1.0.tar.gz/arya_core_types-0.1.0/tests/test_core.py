import pytest
from arya_core_types import DEFAULT_SEED, new_id


def test_new_id_prefix():
    assert new_id("foo").startswith("foo_")


def test_new_id_unique():
    ids = {new_id("x") for _ in range(100)}
    assert len(ids) == 100


def test_default_seed():
    assert DEFAULT_SEED == 135356


def test_improvement_proposal_not_exported():
    with pytest.raises(ImportError):
        from arya_core_types import ImprovementProposal  # noqa: F401
