"""
NXcanSAS I/O for Sizes (size distribution) results.

Saves and loads size distribution fitting results in the same NXcanSAS HDF5
file that already contains experimental SAS data, mirroring the pattern used
by nxcansas_unified.py.  Results are stored under:

    entry/sizes_results   (NXprocess group)

Datasets stored
---------------
Q                  — Q vector [Å^-1]
intensity_data     — measured intensity [cm^-1]
intensity_error    — measurement uncertainty [cm^-1]  (if available)
intensity_model    — fitted model intensity [cm^-1]
residuals          — normalised residuals (I_data - I_model) / error
r_grid             — radius bin centres [Å]
distribution       — volume size distribution P(r) [volume fraction / Å]
number_dist        — number size distribution N(r) [1 / Å]
cumul_vol_dist     — cumulative volume distribution (running integral from r_min)
cumul_num_dist     — cumulative number distribution (running integral from r_min)
distribution_std   — per-bin std of P(r) across Monte Carlo repetitions (if available)

Group attributes (fit results)
-------------------------------
chi_squared, volume_fraction, rg, n_iterations, q_power

Group attributes (model / grid setup)
--------------------------------------
shape, contrast, aspect_ratio,
r_min, r_max, n_bins, log_spacing,
background, power_law_B, power_law_P,
method, error_scale,
maxent_sky_background, maxent_stability, maxent_max_iter,
regularization_evalue, regularization_min_ratio,
tnnls_approach_param, tnnls_max_iter,
montecarlo_n_repetitions, montecarlo_convergence, montecarlo_max_iter,
power_law_q_min, power_law_q_max,
background_q_min, background_q_max,
cursor_q_min, cursor_q_max,
timestamp, program
"""

from __future__ import annotations

import h5py
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Optional


_GROUP = 'entry/sizes_results'
_PROGRAM = 'pyirena.core.sizes'


def save_sizes_results(
    filepath: Path,
    q: np.ndarray,
    intensity_data: np.ndarray,
    intensity_model: np.ndarray,
    residuals: np.ndarray,
    r_grid: np.ndarray,
    distribution: np.ndarray,
    params: dict,
    intensity_error: Optional[np.ndarray] = None,
    distribution_std: Optional[np.ndarray] = None,
) -> None:
    """
    Save size distribution fitting results to an NXcanSAS HDF5 file.

    The file must already exist (created by ``create_nxcansas_file`` or the
    data selector workflow).  If a ``sizes_results`` group already exists it
    is deleted and recreated.

    Args:
        filepath:        Path to the existing NXcanSAS HDF5 file.
        q:               Q vector [Å^-1].
        intensity_data:  Measured intensity [cm^-1].
        intensity_model: Fitted model intensity [cm^-1].
        residuals:       Normalised residuals (I_data - I_model) / error.
        r_grid:          Radius bin centres [Å].
        distribution:    Size distribution P(r) [volume fraction / Å].
        params:          Dict of scalar metadata to store as group attributes.
                         All keys are optional.  Fit results:
                           ``chi_squared``, ``volume_fraction``, ``rg``,
                           ``n_iterations``, ``q_power``.
                         Model / grid setup:
                           ``shape``, ``contrast``, ``aspect_ratio``,
                           ``r_min``, ``r_max``, ``n_bins``, ``log_spacing``,
                           ``background``, ``power_law_B``, ``power_law_P``,
                           ``method``, ``error_scale``,
                           ``maxent_sky_background``, ``maxent_stability``,
                           ``maxent_max_iter``, ``regularization_evalue``,
                           ``regularization_min_ratio``,
                           ``tnnls_approach_param``, ``tnnls_max_iter``,
                           ``montecarlo_n_repetitions``,
                           ``montecarlo_convergence``, ``montecarlo_max_iter``,
                           ``power_law_q_min``, ``power_law_q_max``,
                           ``background_q_min``, ``background_q_max``,
                           ``cursor_q_min``, ``cursor_q_max``.
        intensity_error:  Measurement uncertainty [cm^-1]; stored if provided.
        distribution_std: Per-bin std of P(r) across Monte Carlo repetitions;
                          stored if provided (Monte Carlo method only).
    """
    filepath = Path(filepath)
    timestamp = datetime.now().isoformat()

    mode = 'a' if filepath.exists() else 'w'
    with h5py.File(filepath, mode) as f:
        # Remove existing group if present
        if _GROUP in f:
            del f[_GROUP]

        grp = f.require_group(_GROUP)
        grp.attrs['NX_class'] = 'NXprocess'
        grp.attrs['program']   = _PROGRAM
        grp.attrs['timestamp'] = timestamp

        # Key fit results stored as scalar datasets (browseable/collectable in HDF5 viewer)
        _dataset_keys = ('chi_squared', 'volume_fraction', 'rg', 'n_iterations', 'q_power')
        for k in _dataset_keys:
            if k in params and params[k] is not None:
                try:
                    grp.create_dataset(k, data=float(params[k]))
                except (TypeError, ValueError):
                    grp.attrs[k] = params[k]

        # Model / grid setup stored as attributes (too many to be individual datasets)
        _attr_keys = (
            'shape', 'contrast', 'aspect_ratio',
            'r_min', 'r_max', 'n_bins', 'log_spacing',
            'background', 'power_law_B', 'power_law_P',
            'method', 'error_scale',
            'maxent_sky_background', 'maxent_stability', 'maxent_max_iter',
            'regularization_evalue', 'regularization_min_ratio',
            'tnnls_approach_param', 'tnnls_max_iter',
            'montecarlo_n_repetitions',
            'montecarlo_convergence', 'montecarlo_max_iter',
            'power_law_q_min', 'power_law_q_max',
            'background_q_min', 'background_q_max',
            'cursor_q_min', 'cursor_q_max',
        )
        for k in _attr_keys:
            if k in params and params[k] is not None:
                grp.attrs[k] = params[k]

        # Store arrays
        grp.create_dataset('Q',                 data=q.astype('f8'),              compression='gzip')
        grp.create_dataset('intensity_data',    data=intensity_data.astype('f8'), compression='gzip')
        grp.create_dataset('intensity_model',   data=intensity_model.astype('f8'), compression='gzip')
        grp.create_dataset('residuals',         data=residuals.astype('f8'),      compression='gzip')
        grp.create_dataset('r_grid',            data=r_grid.astype('f8'),         compression='gzip')
        grp.create_dataset('distribution',      data=distribution.astype('f8'),   compression='gzip')

        if intensity_error is not None:
            grp.create_dataset('intensity_error', data=intensity_error.astype('f8'), compression='gzip')

        if distribution_std is not None:
            grp.create_dataset('distribution_std', data=distribution_std.astype('f8'), compression='gzip')
            grp['distribution_std'].attrs['units'] = 'volume_fraction/angstrom'

        # ── Derived distributions ────────────────────────────────────────────
        # Number distribution: N(r) = P(r) / V(r),  V(r) = (4/3)πr³
        V_r = (4.0 / 3.0) * np.pi * r_grid ** 3
        num_dist = np.where(V_r > 0, distribution / V_r, 0.0)

        # Cumulative distributions: running integral from r_min using the
        # trapezoidal rule over bin-centre spacing.
        dr = np.diff(r_grid, prepend=r_grid[0])
        cumul_vol = np.cumsum(distribution * dr)
        cumul_num = np.cumsum(num_dist * dr)

        grp.create_dataset('number_dist',    data=num_dist.astype('f8'),   compression='gzip')
        grp.create_dataset('cumul_vol_dist', data=cumul_vol.astype('f8'),  compression='gzip')
        grp.create_dataset('cumul_num_dist', data=cumul_num.astype('f8'),  compression='gzip')

        # Units annotations
        grp['Q'].attrs['units']              = '1/angstrom'
        grp['intensity_data'].attrs['units'] = '1/cm'
        grp['intensity_model'].attrs['units'] = '1/cm'
        grp['r_grid'].attrs['units']         = 'angstrom'
        grp['distribution'].attrs['units']   = 'volume_fraction/angstrom'
        grp['number_dist'].attrs['units']    = '1/angstrom'
        grp['cumul_vol_dist'].attrs['units'] = 'volume_fraction'
        grp['cumul_num_dist'].attrs['units'] = 'dimensionless'


def load_sizes_results(filepath: Path) -> dict:
    """
    Load size distribution results from an NXcanSAS HDF5 file.

    Args:
        filepath: Path to the NXcanSAS HDF5 file.

    Returns:
        dict with keys:
            ``Q``, ``intensity_data``, ``intensity_model``, ``residuals``,
            ``r_grid``, ``distribution``, ``number_dist``,
            ``cumul_vol_dist``, ``cumul_num_dist``,
            ``intensity_error`` (may be None),
            and all scalar metadata stored as group attributes
            (fit results: ``chi_squared``, ``volume_fraction``, ``rg``,
             ``n_iterations``, ``q_power``; model setup: ``shape``,
             ``contrast``, ``aspect_ratio``, ``r_min``, ``r_max``,
             ``n_bins``, ``log_spacing``, ``background``, ``power_law_B``,
             ``power_law_P``, ``method``, ``error_scale``,
             ``maxent_sky_background``, ``maxent_stability``,
             ``maxent_max_iter``, ``regularization_evalue``,
             ``regularization_min_ratio``, ``tnnls_approach_param``,
             ``tnnls_max_iter``, ``power_law_q_min``, ``power_law_q_max``,
             ``background_q_min``, ``background_q_max``,
             ``cursor_q_min``, ``cursor_q_max``,
             ``timestamp``, ``program``).

    Raises:
        KeyError:  if the file does not contain a ``sizes_results`` group.
        OSError:   if the file cannot be opened.
    """
    filepath = Path(filepath)
    with h5py.File(filepath, 'r') as f:
        if _GROUP not in f:
            raise KeyError(
                f"No sizes_results group found in {filepath.name}. "
                "Run the Sizes fitting tool first."
            )
        grp = f[_GROUP]

        result: dict = {}

        # Arrays
        result['Q']              = grp['Q'][:]
        result['intensity_data'] = grp['intensity_data'][:]
        result['intensity_model'] = grp['intensity_model'][:]
        result['residuals']      = grp['residuals'][:]
        result['r_grid']         = grp['r_grid'][:]
        result['distribution']   = grp['distribution'][:]

        if 'intensity_error' in grp:
            result['intensity_error'] = grp['intensity_error'][:]
        else:
            result['intensity_error'] = None

        if 'distribution_std' in grp:
            result['distribution_std'] = grp['distribution_std'][:]
        else:
            result['distribution_std'] = None

        for key in ('number_dist', 'cumul_vol_dist', 'cumul_num_dist'):
            result[key] = grp[key][:] if key in grp else None

        # Scalar metadata: fit results may be datasets (new format) or attrs (old format)
        _dataset_keys = ('chi_squared', 'volume_fraction', 'rg', 'n_iterations', 'q_power')
        for k in _dataset_keys:
            if k in grp and isinstance(grp[k], h5py.Dataset):
                try:
                    result[k] = float(grp[k][()])
                except Exception:
                    result[k] = grp.attrs.get(k)
            else:
                result[k] = grp.attrs.get(k)

        # Remaining metadata from attributes only
        for k in (
            # Model / grid setup
            'shape', 'contrast', 'aspect_ratio',
            'r_min', 'r_max', 'n_bins', 'log_spacing',
            'background', 'power_law_B', 'power_law_P',
            'method', 'error_scale',
            # Method-specific parameters
            'maxent_sky_background', 'maxent_stability', 'maxent_max_iter',
            'regularization_evalue', 'regularization_min_ratio',
            'tnnls_approach_param', 'tnnls_max_iter',
            'montecarlo_n_repetitions',
            'montecarlo_convergence', 'montecarlo_max_iter',
            # Q ranges used during fitting
            'power_law_q_min', 'power_law_q_max',
            'background_q_min', 'background_q_max',
            'cursor_q_min', 'cursor_q_max',
            # Administrative
            'timestamp', 'program',
        ):
            result[k] = grp.attrs.get(k)

        # Backward compatibility: old files stored 'mcsas_*' attribute names
        # and method='mcsas'.  Map them to the new 'montecarlo_*' names.
        for old_k, new_k in (
            ('mcsas_n_repetitions', 'montecarlo_n_repetitions'),
            ('mcsas_convergence',   'montecarlo_convergence'),
            ('mcsas_max_iter',      'montecarlo_max_iter'),
        ):
            if result.get(new_k) is None and grp.attrs.get(old_k) is not None:
                result[new_k] = grp.attrs.get(old_k)
        if result.get('method') == 'mcsas':
            result['method'] = 'montecarlo'

    return result


def print_sizes_results(results: dict) -> None:
    """Pretty-print size distribution results to the console."""
    print("=" * 60)
    print("  Size Distribution Fitting Results")
    print("=" * 60)
    print(f"  Shape:           {results.get('shape', 'N/A')}")
    print(f"  Method:          {results.get('method', 'N/A')}")
    print(f"  Contrast (Δρ)²:  {results.get('contrast', 'N/A'):.4g} ×10²⁰ cm⁻⁴")
    print(f"  Chi-squared:     {results.get('chi_squared', 'N/A'):.4f}")
    print(f"  Volume fraction: {results.get('volume_fraction', 'N/A'):.4g}")
    print(f"  Rg:              {results.get('rg', 'N/A'):.2f} Å")
    print(f"  Iterations:      {results.get('n_iterations', 'N/A')}")
    r = results.get('r_grid')
    if r is not None:
        print(f"  R range:         {r.min():.1f} – {r.max():.1f} Å")
    print(f"  Timestamp:       {results.get('timestamp', 'N/A')}")
    print("=" * 60)
