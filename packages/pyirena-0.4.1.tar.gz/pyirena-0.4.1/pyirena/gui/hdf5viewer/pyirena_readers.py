"""
PyirenaReaders — knows where pyirena tools store their results in HDF5.

All functions accept a file path and return a normalised dict suitable for
GraphWindow.add_curve() calls.  Every function is safe to call on a file
that doesn't have the expected data — it returns None in that case.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import h5py
import numpy as np


# ── Wildcard path resolver ────────────────────────────────────────────────

def _resolve_wildcard(f: h5py.File, hdf5_path: str) -> str | None:
    """Resolve ``*`` segments in an HDF5 path to the first matching group.

    Example: ``/entry/*/sastransmission_spectrum/T`` will walk into the
    first child of ``/entry/`` that contains ``sastransmission_spectrum/T``.

    Multiple ``*`` segments are supported.  Returns the resolved path or
    None if no match is found.  Attribute suffixes (``@attr``) are
    preserved.
    """
    # Fast path — no wildcards
    if '*' not in hdf5_path:
        return hdf5_path

    # Separate trailing @attr if present
    attr_suffix = ''
    path = hdf5_path
    if '@' in path:
        path, attr_suffix = path.rsplit('@', 1)
        attr_suffix = '@' + attr_suffix

    parts = [p for p in path.split('/') if p]
    matches = ['']  # start at root

    for part in parts:
        next_matches = []
        for prefix in matches:
            node_path = prefix or '/'
            try:
                node = f[node_path]
            except KeyError:
                continue
            if part == '*':
                # Expand to all child group/dataset names
                if hasattr(node, 'keys'):
                    for child_name in node.keys():
                        next_matches.append(f'{prefix}/{child_name}')
            else:
                candidate = f'{prefix}/{part}'
                if candidate in f:
                    next_matches.append(candidate)
        matches = next_matches
        if not matches:
            return None

    if not matches:
        return None
    return matches[0] + attr_suffix


# ── Detection ──────────────────────────────────────────────────────────────

def detect_available_data(filepath: str | Path) -> list[str]:
    """
    Return a list of data-type keys available in *filepath*.

    Keys ∈ {"nxcansas", "unified_fit", "sizes", "waxs", "simple_fit", "modeling"}.
    """
    available = []
    try:
        with h5py.File(str(filepath), "r") as f:
            if _has_nxcansas(f):
                available.append("nxcansas")
            if "entry/unified_fit_results" in f:
                available.append("unified_fit")
            if "entry/sizes_results" in f:
                available.append("sizes")
            if "entry/waxs_peakfit_results" in f:
                available.append("waxs")
            if "entry/simple_fit_results" in f:
                available.append("simple_fit")
            if "entry/modeling_results" in f:
                available.append("modeling")
    except Exception:
        pass
    return available


def _has_nxcansas(f: h5py.File) -> bool:
    """Return True if the file has at least one NXcanSAS entry."""
    found = []
    def _visitor(name, obj):
        if isinstance(obj, h5py.Group):
            css = obj.attrs.get("canSAS_class", b"")
            if isinstance(css, bytes):
                css = css.decode("utf-8", errors="ignore")
            if css == "SASentry":
                found.append(name)
                return True   # stop visiting
    try:
        f.visititems(_visitor)
    except Exception:
        pass
    return bool(found)


# ── NXcanSAS ───────────────────────────────────────────────────────────────

def read_nxcansas(filepath: str | Path) -> dict | None:
    """
    Read the first NXcanSAS entry.

    Returns {"Q", "I", "dI" (or None), "label"} or None on failure.
    """
    try:
        from pyirena.io.hdf5 import readGenericNXcanSAS
        result = readGenericNXcanSAS(
            str(Path(filepath).parent),
            Path(filepath).name,
        )
        if result is None:
            return None
        return {
            "Q":     np.asarray(result["Q"],         float),
            "I":     np.asarray(result["Intensity"],  float),
            "dI":    np.asarray(result["Error"],      float) if result.get("Error") is not None else None,
            "label": result.get("label", Path(filepath).stem),
        }
    except Exception:
        return None


# ── Unified Fit ────────────────────────────────────────────────────────────

def read_unified_fit(filepath: str | Path) -> dict | None:
    """
    Read Unified Fit results.

    Returns {
        "Q", "I_model", "I_data" (may be None),
        "levels": [{"level", "Rg", "G", "B", "P", "ETA", "PACK", …}],
        "chi2", "background", "label"
    } or None.
    """
    try:
        from pyirena.io.nxcansas_unified import load_unified_fit_results
        res = load_unified_fit_results(Path(filepath))
        if not res:
            return None
        _id = res.get("intensity_data")
        return {
            "Q":       np.asarray(res["Q"],              float),
            "I_model": np.asarray(res["intensity_model"], float),
            "I_data":  np.asarray(_id, float) if _id is not None and len(_id) > 0 else None,
            "levels":  res.get("levels", []),
            "chi2":    res.get("chi_squared"),
            "background": res.get("background"),
            "label":   Path(filepath).stem,
        }
    except Exception:
        return None


# ── Size Distribution ──────────────────────────────────────────────────────

def read_sizes(filepath: str | Path) -> dict | None:
    """
    Read Size Distribution results.

    Returns {
        "Q", "I_model", "r", "distribution", "distribution_std" (may be None),
        "number_dist", "cumul_vol_dist", "cumul_num_dist" (may be None),
        "chi2", "label"
    } or None.
    """
    try:
        from pyirena.io.nxcansas_sizes import load_sizes_results
        res = load_sizes_results(Path(filepath))
        if not res:
            return None
        dist_std = res.get("distribution_std")

        def _opt(key):
            v = res.get(key)
            return np.asarray(v, float) if v is not None else None

        return {
            "Q":              np.asarray(res["Q"],              float),
            "I_model":        np.asarray(res["intensity_model"], float),
            "r":              np.asarray(res["r_grid"],          float),
            "distribution":   np.asarray(res["distribution"],   float),
            "distribution_std": np.asarray(dist_std, float) if dist_std is not None else None,
            "number_dist":    _opt("number_dist"),
            "cumul_vol_dist": _opt("cumul_vol_dist"),
            "cumul_num_dist": _opt("cumul_num_dist"),
            "chi2":           res.get("chi_squared"),
            "label":          Path(filepath).stem,
        }
    except Exception:
        return None


# ── WAXS Peak Fit ──────────────────────────────────────────────────────────

def read_waxs(filepath: str | Path) -> dict | None:
    """
    Read WAXS Peak Fit results.

    Returns {
        "Q", "I_fit", "I_bg",
        "peaks": [{"shape", "Q0", "A", "FWHM", "Q_peak", "I_peak"}],
        "chi2", "label"
    } or None.
    """
    try:
        from pyirena.io.nxcansas_waxs_peakfit import load_waxs_peakfit_results
        res = load_waxs_peakfit_results(Path(filepath))
        if not res:
            return None
        return {
            "Q":     np.asarray(res.get("Q",      []), float),
            "I_fit": np.asarray(res.get("I_fit",  []), float),
            "I_bg":  np.asarray(res.get("I_bg",   []), float),
            "peaks": res.get("peaks", []),
            "chi2":  res.get("chi_squared"),
            "label": Path(filepath).stem,
        }
    except Exception:
        return None


# ── Simple Fits ────────────────────────────────────────────────────────────

def read_simple_fit(filepath: str | Path) -> dict | None:
    """
    Read Simple Fits results.

    Returns {
        "Q", "I_model", "params", "chi2", "model_name", "label"
    } or None.
    """
    try:
        from pyirena.io.nxcansas_simple_fits import load_simple_fit_results
        res = load_simple_fit_results(Path(filepath))
        if not res:
            return None
        return {
            "Q":         np.asarray(res.get("Q",       []), float),
            "I_model":   np.asarray(res.get("I_model", []), float),
            "params":    res.get("params",     {}),
            "chi2":      res.get("chi_squared"),
            "model_name": res.get("model", ""),
            "label":     Path(filepath).stem,
        }
    except Exception:
        return None


# ── Modeling ───────────────────────────────────────────────────────────────

def read_modeling(filepath: str | Path) -> dict | None:
    """
    Read Modeling tool results.

    Returns {
        "Q", "I_model",
        "populations": [{"population_index", "pop_type", "enabled", "label",
                          "derived", "uf_params", "peak_params", …}],
        "chi2", "background", "q_min", "q_max", "label"
    } or None.
    """
    try:
        from pyirena.io.nxcansas_modeling import load_modeling_results
        res = load_modeling_results(Path(filepath))
        if not res:
            return None
        return {
            "Q":           np.asarray(res["model_q"],  float),
            "I_model":     np.asarray(res["model_I"],  float),
            "populations": res.get("populations", []),
            "chi2":        res.get("chi_squared"),
            "background":  res.get("background"),
            "q_min":       res.get("q_min"),
            "q_max":       res.get("q_max"),
            "label":       Path(filepath).stem,
        }
    except Exception:
        return None


def _collect_modeling(filepath, item: str, pop_index: int = 1) -> float | None:
    """
    Extract a single scalar from Modeling results.

    Global items: "chi2", "background"
    UF params (pop_index selects population): "G", "Rg", "B", "P", "RgCO", "ETA", "PACK"
    DP params: "position", "amplitude", "width", "eta_voigt"
    SD derived: "volume_fraction", "vol_mean_r", "num_mean_r", "specific_surface"
    SD direct: "scale", "contrast"
    SD form-factor: "ff_aspect_ratio", "ff_length",
                    "ff_sld_core", "ff_sld_shell", "ff_sld_solvent",
                    "ff_t_shell", "ff_r_core_fixed"
    SD core-shell derived: "r_total_mean"
    pop_index: 1-based population index (ignored for global items).
    """
    res = read_modeling(filepath)
    if res is None:
        return None
    if item in ("chi2", "chi_squared"):
        return res.get("chi2")
    if item == "background":
        return res.get("background")
    # Population-level items
    pops = res.get("populations", [])
    pop = next((p for p in pops if p.get("population_index") == pop_index), None)
    if pop is None:
        return None
    derived = pop.get("derived", {})
    lookup = {
        # UF Level params (flat keys on pop dict)
        "G":                pop.get("G"),
        "Rg":               pop.get("Rg"),
        "B":                pop.get("B"),
        "P":                pop.get("P"),
        "RgCO":             pop.get("RgCO"),
        "ETA":              pop.get("ETA"),
        "PACK":             pop.get("PACK"),
        # Diffraction Peak params
        "position":         pop.get("position"),
        "amplitude":        pop.get("amplitude"),
        "width":            pop.get("width"),
        "eta_voigt":        pop.get("eta_voigt"),
        # Size Distribution derived quantities (from 'derived' sub-group)
        "volume_fraction":  derived.get("volume_fraction"),
        "vol_mean_r":       derived.get("vol_mean_r"),
        "num_mean_r":       derived.get("num_mean_r"),
        "specific_surface": derived.get("specific_surface"),
        # Size Distribution direct params
        "scale":            pop.get("scale"),
        "contrast":         pop.get("contrast"),
        # Size Distribution form-factor params
        "ff_aspect_ratio":  pop.get("ff_params", {}).get("aspect_ratio"),
        "ff_length":        pop.get("ff_params", {}).get("length"),
        "ff_sld_core":      pop.get("ff_params", {}).get("sld_core"),
        "ff_sld_shell":     pop.get("ff_params", {}).get("sld_shell"),
        "ff_sld_solvent":   pop.get("ff_params", {}).get("sld_solvent"),
        "ff_t_shell":       pop.get("ff_params", {}).get("t_shell"),
        "ff_r_core_fixed":  pop.get("ff_params", {}).get("r_core_fixed"),
        # Core-shell derived
        "r_total_mean":     derived.get("r_total_mean"),
    }
    val = lookup.get(item)
    return float(val) if val is not None else None


# ── Arbitrary dataset ──────────────────────────────────────────────────────

def read_dataset(filepath: str | Path, hdf5_path: str) -> np.ndarray | None:
    """
    Read any 1D or scalar dataset from an HDF5 file.

    Wildcard ``*`` segments are resolved to the first matching child group.

    Returns a numpy array, or None on failure.
    """
    try:
        with h5py.File(str(filepath), "r") as f:
            resolved = _resolve_wildcard(f, hdf5_path)
            if resolved is None:
                return None
            ds = f[resolved]
            data = ds[()]
            if isinstance(data, (bytes, np.bytes_)):
                return None   # string dataset
            arr = np.asarray(data, float)
            return arr.flatten() if arr.ndim > 1 else arr
    except Exception:
        return None


# ── Value collection ───────────────────────────────────────────────────────

def collect_value(filepath: str | Path, spec: dict) -> float | None:
    """
    Extract a single scalar value from *filepath* according to *spec*.

    spec examples::

        {"type": "unified_fit", "item": "Rg", "level": 1}
        {"type": "unified_fit", "item": "G",  "level": 2}
        {"type": "unified_fit", "item": "chi2"}
        {"type": "sizes",      "item": "chi2"}
        {"type": "sizes",      "item": "volume_fraction"}
        {"type": "waxs",       "item": "Q0",  "peak": 0}
        {"type": "waxs",       "item": "A",   "peak": 0}
        {"type": "waxs",       "item": "chi2"}
        {"type": "simple_fit", "item": "param", "param_name": "Rg"}
        {"type": "simple_fit", "item": "chi2"}
        {"type": "custom",     "path": "/entry/unified_fit_results/level_1"}
                                                  # reads @Rg attr or dataset
    """
    data_type = spec.get("type", "")
    item      = spec.get("item", "")

    try:
        if data_type == "unified_fit":
            return _collect_unified(filepath, item, spec.get("level", 1))

        if data_type == "sizes":
            return _collect_sizes(filepath, item)

        if data_type == "waxs":
            return _collect_waxs(filepath, item, spec.get("peak", 0))

        if data_type == "simple_fit":
            return _collect_simple_fit(filepath, item, spec.get("param_name", ""))

        if data_type == "modeling":
            return _collect_modeling(filepath, item, spec.get("population", 1))

        if data_type == "custom":
            return read_metadata_value(filepath, spec.get("path", ""))

    except Exception:
        pass
    return None


def _read_scalar_value(node, key: str) -> float | None:
    """Read a scalar from an HDF5 node: dataset first (new format), attr fallback (old)."""
    try:
        if key in node and isinstance(node[key], h5py.Dataset):
            return float(node[key][()])
        val = node.attrs.get(key)
        return float(val) if val is not None else None
    except Exception:
        return None


def _collect_unified(filepath, item: str, level: int) -> float | tuple | None:
    try:
        with h5py.File(str(filepath), "r") as f:
            grp = f["entry/unified_fit_results"]
            if item == "chi2":
                return _read_scalar_value(grp, "chi_squared")
            if item == "background":
                val = _read_scalar_value(grp, "background")
                err = _read_scalar_value(grp, "background_err")
                if val is not None and err is not None and np.isfinite(err):
                    return (val, err)
                return val
            level_grp = grp[f"level_{level}"]
            val = _read_scalar_value(level_grp, item)
            if val is None:
                return None
            # For primary params, also try to find a paired _err dataset
            if not item.endswith("_err"):
                err = _read_scalar_value(level_grp, f"{item}_err")
                if err is not None and np.isfinite(err):
                    return (val, err)
            return val
    except Exception:
        return None


def _collect_sizes(filepath, item: str) -> float | None:
    try:
        with h5py.File(str(filepath), "r") as f:
            grp = f["entry/sizes_results"]
            return _read_scalar_value(grp, item)
    except Exception:
        return None


def _collect_waxs(filepath, item: str, peak: int) -> float | tuple | None:
    try:
        with h5py.File(str(filepath), "r") as f:
            grp = f["entry/waxs_peakfit_results"]
            if item == "chi2":
                return _read_scalar_value(grp, "chi_squared")
            peak_name = f"peak_{peak+1:02d}"
            pk_grp = grp[peak_name]
            # Explicit std request (e.g. "Q0_err")
            if item.endswith("_err"):
                base = item[:-4]
                if "params_std" in pk_grp and base in pk_grp["params_std"]:
                    return float(pk_grp["params_std"][base][()])
                return None
            # Primary param — also fetch paired std
            params_grp = pk_grp["params"]
            val = float(params_grp[item][()])
            if "params_std" in pk_grp and item in pk_grp["params_std"]:
                std = float(pk_grp["params_std"][item][()])
                if np.isfinite(std):
                    return (val, std)
            return val
    except Exception:
        return None


def _collect_simple_fit(filepath, item: str, param_name: str) -> float | tuple | None:
    try:
        with h5py.File(str(filepath), "r") as f:
            grp = f["entry/simple_fit_results"]
            if item == "chi2":
                return _read_scalar_value(grp, "chi_squared")
            if item == "param" and param_name:
                # chi2 passed as param_name (from UI combo)
                if param_name == "chi2":
                    return _read_scalar_value(grp, "chi_squared")
                # Explicit std request (e.g. "Rg_err")
                if param_name.endswith("_err"):
                    base = param_name[:-4]
                    if "params_std" in grp and base in grp["params_std"]:
                        return float(grp["params_std"][base][()])
                    return None
                # Primary param — also fetch paired std
                val = float(grp["params"][param_name][()])
                if "params_std" in grp and param_name in grp["params_std"]:
                    std = float(grp["params_std"][param_name][()])
                    if np.isfinite(std):
                        return (val, std)
                return val
    except Exception:
        return None


def read_metadata_value(filepath: str | Path, hdf5_path: str) -> float | None:
    """
    Read a scalar (attribute or dataset) from *hdf5_path* in *filepath*.

    Supports both dataset paths (``/entry/foo/bar``) and attribute paths
    (``/entry/foo/bar@attr_name``).

    Wildcard ``*`` segments are resolved to the first matching child group,
    e.g. ``/entry/*/sastransmission_spectrum/T``.
    """
    if not hdf5_path:
        return None
    try:
        with h5py.File(str(filepath), "r") as f:
            resolved = _resolve_wildcard(f, hdf5_path)
            if resolved is None:
                return None
            if "@" in resolved:
                path, attr = resolved.rsplit("@", 1)
                path = path.rstrip("/") or "/"
                val = f[path].attrs[attr]
            else:
                val = f[resolved][()]
            if hasattr(val, 'flat') and val.size == 1:
                val = val.flat[0]
            if isinstance(val, (bytes, np.bytes_)):
                val = val.decode("utf-8", errors="replace")
            return float(val)
    except Exception:
        return None


# ── Multi-item collection ──────────────────────────────────────────────────

def read_hdf5_item(
    filepath: str | Path,
    hdf5_path: str,
    reduction: str = 'sum',
) -> tuple[object, str]:
    """
    Read an HDF5 dataset or attribute and reduce arrays to a scalar.

    Parameters
    ----------
    filepath : str or Path
    hdf5_path : str
        HDF5 internal path, optionally with ``@attr_name`` suffix.
    reduction : {'sum', 'mean', 'min', 'max'}
        How to collapse arrays to a single number.  Ignored for scalars
        and strings.

    Returns
    -------
    (value, kind) where *kind* is one of:
        ``'scalar'`` — value is float
        ``'string'`` — value is str
        ``'array'``  — value is float (after reduction)
        ``'error'``  — value is None (read failure)
    """
    if not hdf5_path:
        return None, 'error'
    try:
        with h5py.File(str(filepath), 'r') as f:
            resolved = _resolve_wildcard(f, hdf5_path)
            if resolved is None:
                return None, 'error'
            if '@' in resolved:
                path, attr = resolved.rsplit('@', 1)
                path = path.rstrip('/') or '/'
                raw = f[path].attrs[attr]
            else:
                raw = f[resolved][()]
    except Exception:
        return None, 'error'

    # String types
    if isinstance(raw, (bytes, np.bytes_)):
        return raw.decode('utf-8', errors='replace'), 'string'
    if isinstance(raw, str):
        return raw, 'string'
    if isinstance(raw, np.ndarray) and raw.dtype.kind in ('S', 'U'):
        return ', '.join(str(v) for v in raw.flat), 'string'

    # Numeric
    try:
        arr = np.asarray(raw, dtype=float)
    except (TypeError, ValueError):
        return str(raw), 'string'

    if arr.ndim == 0 or arr.size == 1:
        return float(arr.flat[0]), 'scalar'

    # Array — apply reduction
    ops = {
        'sum':  np.nansum,
        'mean': np.nanmean,
        'min':  np.nanmin,
        'max':  np.nanmax,
    }
    fn = ops.get(reduction.lower(), np.nansum)
    return float(fn(arr)), 'array'


# ── X-axis helpers for Collect Values ─────────────────────────────────────

def extract_sort_key_value(filepath: str | Path, sort_index: int) -> float | None:
    """
    Extract a numeric X value from the filename using the sort key at *sort_index*.

    Uses the same _SORT_KEY functions as FileTreeWidget.
    """
    from .file_tree import _SORT_KEYS
    name = Path(filepath).name
    try:
        val = _SORT_KEYS[sort_index](name)
        return float(val) if val != float("inf") else None
    except Exception:
        return None
