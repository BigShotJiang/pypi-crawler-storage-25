"""
Validates predict() output.
Raises descriptive ValidationError on invalid formats.
"""
from __future__ import annotations

VALID_COINS = {"kapcoin-usd_train", "metucoin-usd_train", "tamcoin-usd_train"}
VALID_LEVERAGES = {1, 2, 3, 5, 10}
VALID_SIGNALS = {-1, 0, 1}
MAX_TOTAL_ALLOCATION = 1.0


class ValidationError(Exception):
    pass


def validate(decisions: list[dict]) -> None:
    """
    Validates predict() output. Raises ValidationError if invalid.

    Every candle must contain exactly one entry per valid coin — no omissions,
    no duplicates. To keep a position open, re-state it with the same signal
    and allocation. To close one, set signal=0 and allocation=0.0.

    Expected format:
        [
            {"coin": "kapcoin-usd_train",  "signal": 1, "allocation": 0.5, "leverage": 10},
            {"coin": "metucoin-usd_train", "signal": 0, "allocation": 0.0, "leverage": 1},
            {"coin": "tamcoin-usd_train",  "signal": 0, "allocation": 0.0, "leverage": 1},
        ]
    """
    if not isinstance(decisions, list):
        raise ValidationError(
            f"predict() must return a list, got '{type(decisions).__name__}'."
        )

    seen_coins: set[str] = set()
    total_allocation = 0.0

    for i, decision in enumerate(decisions):
        _validate_decision(i, decision, seen_coins)
        signal     = decision["signal"]
        allocation = decision["allocation"]
        if signal != 0:
            total_allocation += allocation

    missing = VALID_COINS - seen_coins
    if missing:
        raise ValidationError(
            f"predict() must return one decision per coin. Missing: {sorted(missing)}."
        )

    if round(total_allocation, 10) > MAX_TOTAL_ALLOCATION:
        raise ValidationError(
            f"Total allocation of active positions {total_allocation:.4f} cannot exceed 1.0."
        )


def _validate_decision(index: int, decision: dict, seen_coins: set[str]) -> None:
    if not isinstance(decision, dict):
        raise ValidationError(
            f"Decision[{index}] must be a dict, got '{type(decision).__name__}'."
        )

    required_keys = {"coin", "signal", "allocation", "leverage"}
    missing = required_keys - decision.keys()
    if missing:
        raise ValidationError(
            f"Decision[{index}] missing key(s): {missing}"
        )

    coin = decision["coin"]
    if coin not in VALID_COINS:
        raise ValidationError(
            f"Decision[{index}]: invalid coin '{coin}'. "
            f"Valid coins: {sorted(VALID_COINS)}"
        )
    if coin in seen_coins:
        raise ValidationError(
            f"Decision[{index}]: '{coin}' listed more than once."
        )
    seen_coins.add(coin)

    signal = decision["signal"]
    if isinstance(signal, bool) or signal not in VALID_SIGNALS:
        raise ValidationError(
            f"Decision[{index}] ({coin}): signal {signal!r} is invalid. "
            f"Valid signals: {sorted(VALID_SIGNALS)}"
        )

    allocation = decision["allocation"]
    if isinstance(allocation, bool) or not isinstance(allocation, (int, float)):
        raise ValidationError(
            f"Decision[{index}] ({coin}): 'allocation' must be numeric, "
            f"got '{type(allocation).__name__}'."
        )
    if not (0.0 <= allocation <= 1.0):
        raise ValidationError(
            f"Decision[{index}] ({coin}): allocation {allocation} is invalid, "
            f"must be in range [0.0, 1.0]."
        )
    if signal == 0 and allocation != 0.0:
        raise ValidationError(
            f"Decision[{index}] ({coin}): signal=0 but allocation is {allocation}, must be 0."
        )

    leverage = decision["leverage"]
    if signal != 0 and (isinstance(leverage, bool) or leverage not in VALID_LEVERAGES):
        raise ValidationError(
            f"Decision[{index}] ({coin}): leverage {leverage!r} is invalid. "
            f"Valid leverages: {sorted(VALID_LEVERAGES)}"
        )

    for key in ("take_profit", "stop_loss"):
        if key not in decision:
            continue
        value = decision[key]
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValidationError(
                f"Decision[{index}] ({coin}): '{key}' must be a number or None, "
                f"got '{type(value).__name__}'."
            )
        if value <= 0:
            raise ValidationError(
                f"Decision[{index}] ({coin}): '{key}' must be positive, got {value}."
            )
