"""
cnlib — Algorithmic Trading Competition Library

Basic usage:
    from cnlib.base_strategy import BaseStrategy
    from cnlib import backtest
"""
from .base_strategy import BaseStrategy
from .portfolio import Portfolio, Position
from .validator import ValidationError, validate
from . import backtest

__version__ = "0.1.4"
__all__ = [
    "BaseStrategy",
    "Portfolio",
    "Position",
    "ValidationError",
    "validate",
    "backtest",
]
