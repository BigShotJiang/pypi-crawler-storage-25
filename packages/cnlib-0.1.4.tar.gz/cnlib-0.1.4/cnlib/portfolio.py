"""
Portfolio management: opening/closing positions, P&L and liquidation logic.

Liquidation rules (checked against the candle's intrabar extreme):
  Long  → liquidated when Low  ≤ entry * (1 - 1/leverage)
  Short → liquidated when High ≥ entry * (1 + 1/leverage)
PnL and opens continue to use the close price.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Position:
    coin: str
    direction: int      # 1=long, -1=short
    leverage: int
    entry_price: float
    capital: float      # actual capital allocated to this position ($)
    take_profit: float | None = None   # close at this price if favourable
    stop_loss:   float | None = None   # close at this price if adverse

    def tp_sl_hit(self, close: float) -> bool:
        """True if the candle close has reached take_profit or stop_loss."""
        if self.direction == 1:  # long
            if self.take_profit is not None and close >= self.take_profit:
                return True
            if self.stop_loss is not None and close <= self.stop_loss:
                return True
        else:                    # short
            if self.take_profit is not None and close <= self.take_profit:
                return True
            if self.stop_loss is not None and close >= self.stop_loss:
                return True
        return False

    @property
    def liquidation_price(self) -> float:
        """Price at which this position gets liquidated."""
        if self.leverage == 0:
            raise ValueError("leverage must be non-zero")
        if self.direction == 1:  # long
            return self.entry_price * (1.0 - 1.0 / self.leverage)
        else:                    # short
            return self.entry_price * (1.0 + 1.0 / self.leverage)

    def pnl(self, current_price: float) -> float:
        """Current profit/loss of the position ($)."""
        price_change_ratio = (current_price - self.entry_price) / self.entry_price
        return self.capital * self.direction * self.leverage * price_change_ratio

    def is_liquidated(self, current_price: float) -> bool:
        """Returns True if the price has hit the liquidation threshold."""
        if self.direction == 1:
            return current_price <= self.liquidation_price
        else:
            return current_price >= self.liquidation_price


@dataclass
class Portfolio:
    initial_capital: float = 3000.0
    cash: float = field(init=False)
    positions: dict[str, Position] = field(default_factory=dict)

    # Statistics tracking
    total_liquidation_count: int = field(default=0, init=False)
    total_liquidation_loss: float = field(default=0.0, init=False)

    # Current price caches — set at the start of each update cycle
    _current_prices: dict[str, float] = field(default_factory=dict, init=False, repr=False)
    _current_highs:  dict[str, float] = field(default_factory=dict, init=False, repr=False)
    _current_lows:   dict[str, float] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        self.cash = self.initial_capital

    @property
    def portfolio_value(self) -> float:
        """Cash + current value of all open positions."""
        return self.cash + sum(
            pos.capital + pos.pnl(self._price_for(coin))
            for coin, pos in self.positions.items()
        )

    def _price_for(self, coin: str) -> float:
        price = self._current_prices.get(coin)
        if price is None:
            raise KeyError(f"No current price for '{coin}' — data gap?")
        return price

    def update_prices(
        self,
        prices: dict[str, float],
        highs: dict[str, float] | None = None,
        lows:  dict[str, float] | None = None,
    ) -> None:
        """Update current candle prices. Highs/lows default to close if omitted."""
        self._current_prices = prices
        self._current_highs  = highs if highs is not None else prices
        self._current_lows   = lows  if lows  is not None else prices

    def open_position(
        self,
        coin: str,
        direction: int,
        leverage: int,
        allocation: float,
        take_profit: float | None = None,
        stop_loss:   float | None = None,
    ) -> Optional[str]:
        """
        Opens a new position.

        allocation: fraction of current equity (portfolio_value) to allocate.
        When unrealized losses reduce free cash below the equity-based ask, an
        error is returned and the open is skipped — no partial fills.
        Iteration order of caller-provided decisions determines priority.

        Returns: error message (str) or None on success.
        """
        if coin in self.positions:
            return f"A position for {coin} is already open."

        price = self._current_prices.get(coin)
        if price is None:
            return f"No current price found for {coin}."

        allocated_capital = self.portfolio_value * allocation
        if allocated_capital > self.cash:
            return (
                f"{coin}: requested ${allocated_capital:.2f} of equity "
                f"but only ${self.cash:.2f} cash available "
                f"(unrealized losses may have reduced free cash)."
            )

        if allocated_capital <= 0:
            return f"{coin}: insufficient cash."

        self.cash -= allocated_capital
        self.positions[coin] = Position(
            coin=coin,
            direction=direction,
            leverage=leverage,
            entry_price=price,
            capital=allocated_capital,
            take_profit=take_profit,
            stop_loss=stop_loss,
        )
        return None

    def close_position(self, coin: str) -> float:
        """
        Closes a position and returns capital + P&L to cash.
        Returns: realised P&L ($).
        """
        if coin not in self.positions:
            return 0.0

        pos = self.positions.pop(coin)
        gain = pos.pnl(self._price_for(coin))
        returned = pos.capital + gain

        if returned < -1e-9:
            raise RuntimeError(
                f"close_position({coin}): unexpected negative return {returned:.6f} — "
                "check position math or liquidation handling."
            )
        self.cash += returned
        return gain

    def process_liquidations(self) -> list[str]:
        """
        Closes all positions that have hit their liquidation price intrabar.
        Longs trigger on the candle Low, shorts on the candle High.
        Returns: list of liquidated coin names.
        """
        liquidated = []
        for coin, pos in list(self.positions.items()):
            if pos.direction == 1:
                trigger = self._current_lows.get(coin, self._price_for(coin))
            else:
                trigger = self._current_highs.get(coin, self._price_for(coin))
            if pos.is_liquidated(trigger):
                liquidated.append(coin)
                self.total_liquidation_loss += pos.capital  # entire capital is lost
                del self.positions[coin]
                # Cash is NOT returned; capital is completely wiped out
                self.total_liquidation_count += 1
        return liquidated

    def update_positions(
        self,
        decisions: list[dict],
        prices: dict[str, float],
        highs: dict[str, float] | None = None,
        lows:  dict[str, float] | None = None,
    ) -> dict:
        """
        Executes all portfolio operations for a single candle close:
          1. Update prices
          2. Check intrabar liquidations
          3. Check take_profit / stop_loss (against close)
          4. Close positions where signal=0 or direction changed
          5. Open new positions (carrying their optional TP/SL)

        Decision semantics:
          signal=0             → close any open position for that coin.
          signal matches open  → hold (no action; TP/SL stays as originally set).
          signal differs       → flip direction (close then open).
          no open position     → open a new one.
        The validator requires every coin to appear exactly once per candle,
        so "hold" must be expressed by re-stating the current signal — there
        is no implicit hold. Decisions are processed in the order provided;
        the strategy is responsible for prioritization when total allocation
        approaches the cash limit.

        Returns: summary dict for this cycle.
        """
        self.update_prices(prices, highs, lows)

        # 1. Liquidations (intrabar)
        liquidated = self.process_liquidations()

        # 2. Take-profit / stop-loss (at candle close)
        tp_sl_closed: list[str] = []
        for coin, pos in list(self.positions.items()):
            if pos.tp_sl_hit(self._price_for(coin)):
                self.close_position(coin)
                tp_sl_closed.append(coin)

        # 3. Process signals
        closed = list(tp_sl_closed)
        opened = []
        failed_opens: list[dict] = []
        # Coins closed by liquidation or TP/SL this candle are "spent" — the
        # strategy cannot re-enter on the same candle. A new entry requires an
        # explicit decision on a subsequent candle.
        spent = set(liquidated) | set(tp_sl_closed)

        for decision in decisions:
            coin       = decision["coin"]
            signal     = decision["signal"]
            allocation = decision["allocation"]
            leverage   = decision["leverage"]
            take_profit = decision.get("take_profit")
            stop_loss   = decision.get("stop_loss")

            existing = self.positions.get(coin)

            if signal == 0:
                # Explicit close signal
                if existing:
                    self.close_position(coin)
                    closed.append(coin)
                continue

            if coin in spent:
                # Already exited this candle via liquidation or TP/SL.
                continue

            # Active signal
            if existing:
                if existing.direction != signal:
                    # Direction flip → close then open
                    self.close_position(coin)
                    closed.append(coin)
                else:
                    # Same direction already open → leave it
                    continue

            error = self.open_position(
                coin, signal, leverage, allocation,
                take_profit=take_profit, stop_loss=stop_loss,
            )
            if error is None:
                opened.append(coin)
            else:
                failed_opens.append({"coin": coin, "error": error})

        return {
            "liquidated":      liquidated,
            "tp_sl_closed":    tp_sl_closed,
            "closed":          closed,
            "opened":          opened,
            "failed_opens":    failed_opens,
            "cash":            self.cash,
            "portfolio_value": self.portfolio_value,
        }

    def summary(self) -> dict:
        """Final state summary."""
        value = self.portfolio_value
        return {
            "cash":                    round(self.cash, 2),
            "portfolio_value":         round(value, 2),
            "net_pnl":                 round(value - self.initial_capital, 2),
            "return_pct":              round((value / self.initial_capital - 1) * 100, 4),
            "total_liquidations":      self.total_liquidation_count,
            "total_liquidation_loss":  round(self.total_liquidation_loss, 2),
            "open_positions":          len(self.positions),
        }
