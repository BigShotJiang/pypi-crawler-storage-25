"""
Abstract base class that all strategies must inherit from.

Usage:
    class MyStrategy(BaseStrategy):
        def predict(self, data):
            ...
            return [...]
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import pandas as pd

_DATA_DIR = Path(__file__).parent / "data"
COINS = ["kapcoin-usd_train", "metucoin-usd_train", "tamcoin-usd_train"]


class BaseStrategy(ABC):
    """
    Base class for all strategies.

    Attributes:
        candle_index: Current candle index (0-based).
        coin_data   : {coin: DataFrame} sliced up to and including candle_index.
                      Future candles are not accessible.
    """

    def __init__(self) -> None:
        self.candle_index: int = 0
        self._full_data: dict[str, pd.DataFrame] = {}

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------

    @property
    def coin_data(self) -> dict[str, pd.DataFrame]:
        """{coin: DataFrame} sliced to [0 .. candle_index] inclusive."""
        end = self.candle_index + 1
        return {coin: df.iloc[:end] for coin, df in self._full_data.items()}

    def get_data(self, data_dir: Path | None = None) -> dict[str, pd.DataFrame]:
        """
        Reads parquet files into private storage. The public `coin_data`
        property exposes only candles up to `candle_index`.

        Args:
            data_dir: Path to the directory containing parquet files.
                      Defaults to the data/ directory bundled with the package.
        """
        directory = data_dir or _DATA_DIR
        for coin in COINS:
            file = directory / f"{coin}.parquet"
            if not file.exists():
                raise FileNotFoundError(f"Data file not found: {file}")
            self._full_data[coin] = pd.read_parquet(file)

        required = {"Date", "Open", "High", "Low", "Close", "Volume"}
        for coin, df in self._full_data.items():
            missing = required - set(df.columns)
            if missing:
                raise ValueError(f"{coin}.parquet missing columns: {missing}")

        lengths = {coin: len(df) for coin, df in self._full_data.items()}
        if len(set(lengths.values())) != 1:
            raise ValueError(f"Coin DataFrames have unequal lengths: {lengths}")

        return self.coin_data

    def _candle_data(self, index: int) -> dict[str, pd.DataFrame]:
        """Returns all coin data up to and including the given index.

        Each DataFrame is a copy — safe to mutate without corrupting storage.
        """
        return {
            coin: df.iloc[: index + 1].copy()
            for coin, df in self._full_data.items()
        }

    def current_prices(self, index: int) -> dict[str, float]:
        """Returns the closing prices for the current candle."""
        return {
            coin: float(df["Close"].iat[index])
            for coin, df in self._full_data.items()
        }

    def current_highs(self, index: int) -> dict[str, float]:
        """Returns the high prices for the current candle."""
        return {
            coin: float(df["High"].iat[index])
            for coin, df in self._full_data.items()
        }

    def current_lows(self, index: int) -> dict[str, float]:
        """Returns the low prices for the current candle."""
        return {
            coin: float(df["Low"].iat[index])
            for coin, df in self._full_data.items()
        }

    # ------------------------------------------------------------------
    # Abstract method — implemented by the user
    # ------------------------------------------------------------------

    @abstractmethod
    def predict(self, data: dict[str, Any]) -> list[dict]:
        """
        Called on every candle close.

        Args:
            data: {coin: DataFrame} — full OHLCV history up to the current candle.

        Returns:
            A list of dicts — exactly one entry per coin, every candle:
            [{"coin": str, "signal": int, "allocation": float, "leverage": int,
              "take_profit": float | None, "stop_loss": float | None}, ...]

            signal     : 1=long, -1=short, 0=close any open position
            allocation : fraction of current equity (0.0–1.0), total cannot exceed 1.0
            leverage   : 1, 2, 3, 5, or 10
            take_profit: optional. If the candle close reaches this price in the
                         favourable direction (≥ for long, ≤ for short), the
                         position is closed at that close.
            stop_loss  : optional. If the candle close reaches this price in the
                         adverse direction (≤ for long, ≥ for short), the
                         position is closed at that close.

        All three coins must be listed every call. To hold an open position,
        re-state the same signal; to stay flat, use signal=0, allocation=0.0.
        Omitting a coin raises ValidationError. take_profit and stop_loss are
        only set at open; they stay fixed for the lifetime of the position
        and are checked at every subsequent candle's close before predict()
        makes its next decision.
        """
        ...
