"""
Backtest engine.

On every candle close:
  1. Call predict()
  2. Validate the output
  3. Update the portfolio
  4. Record the results
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

from .base_strategy import BaseStrategy
from .portfolio import Portfolio
from .validator import ValidationError, validate


@dataclass
class BacktestResult:
    """Data structure returned at the end of a backtest run."""

    initial_capital: float
    final_portfolio_value: float
    net_pnl: float
    return_pct: float
    total_candles: int
    total_trades: int               # opens + explicit closes (excludes liquidations)
    total_liquidations: int
    total_liquidation_loss: float
    validation_errors: int
    strategy_errors: int = 0
    failed_opens: int = 0
    portfolio_series: list[dict] = field(default_factory=list)
    trade_history: list[dict] = field(default_factory=list)
    failed_open_history: list[dict] = field(default_factory=list)

    def print_summary(self) -> None:
        """Prints results to the console in a formatted table."""
        print("=" * 55)
        print("  BACKTEST RESULTS")
        print("=" * 55)
        print(f"  Initial Capital     : ${self.initial_capital:>12,.2f}")
        print(f"  Final Portfolio     : ${self.final_portfolio_value:>12,.2f}")
        print(f"  Net P&L             : ${self.net_pnl:>+12,.2f}")
        print(f"  Return              :  {self.return_pct:>+11.4f}%")
        print("-" * 55)
        print(f"  Total Candles       : {self.total_candles:>13,}")
        print(f"  Total Trades        : {self.total_trades:>13,}")
        print(f"  Liquidations        : {self.total_liquidations:>13,}")
        print(f"  Liquidation Loss    : ${self.total_liquidation_loss:>12,.2f}")
        print(f"  Validation Errors   : {self.validation_errors:>13,}")
        print(f"  Strategy Errors     : {self.strategy_errors:>13,}")
        print(f"  Failed Opens        : {self.failed_opens:>13,}")
        print("=" * 55)

    def portfolio_dataframe(self) -> pd.DataFrame:
        """Returns the portfolio time series as a DataFrame."""
        return pd.DataFrame(self.portfolio_series)


def run(
    strategy: BaseStrategy,
    initial_capital: float = 3000.0,
    start_candle: int = 0,
    data_dir: Path | None = None,
    silent: bool = False,
) -> BacktestResult:
    """
    Runs the backtest.

    Args:
        strategy        : An instance of a BaseStrategy subclass.
        initial_capital : Starting cash ($).
        start_candle    : Candle index to start from (for warm-up periods).
        data_dir        : Path to parquet files (None = default).
        silent          : If True, suppresses progress output.

    Returns:
        BacktestResult instance.
    """
    # --- Setup ---
    strategy.get_data(data_dir)
    portfolio = Portfolio(initial_capital=initial_capital)

    first_coin = next(iter(strategy._full_data.values()))
    total_candles = len(first_coin)

    portfolio_series: list[dict] = []
    trade_history: list[dict] = []
    failed_open_history: list[dict] = []
    total_trades = 0
    validation_errors = 0
    strategy_errors = 0
    failed_opens = 0

    if not silent:
        print(f"Backtest starting: {total_candles} candles, start_candle={start_candle}")

    # --- Main loop ---
    for i in range(start_candle, total_candles):
        strategy.candle_index = i

        # Current data + prices
        data = strategy._candle_data(i)
        prices = strategy.current_prices(i)
        highs  = strategy.current_highs(i)
        lows   = strategy.current_lows(i)
        portfolio.update_prices(prices, highs, lows)

        # Call predict()
        try:
            decisions: list[dict[str, Any]] = strategy.predict(data)
        except Exception as exc:
            if not silent:
                print(f"  [Candle {i}] predict() EXCEPTION ({type(exc).__name__}): {exc}")
            strategy_errors += 1
            _record(portfolio_series, i, portfolio, prices)
            continue

        # Validate
        try:
            validate(decisions)
        except ValidationError as exc:
            if not silent:
                print(f"  [Candle {i}] ValidationError: {exc}")
            validation_errors += 1
            _record(portfolio_series, i, portfolio, prices)
            continue

        # Update portfolio
        turn = portfolio.update_positions(decisions, prices, highs, lows)

        # Update trade count
        opened = len(turn["opened"])
        closed = len(turn["closed"])
        total_trades += opened + closed

        # Record trade history (only on active candles)
        if opened or closed:
            trade_history.append({
                "candle_index":    i,
                "timestamp":       first_coin.iloc[i]["Date"],
                "opened":          turn["opened"],
                "closed":          turn["closed"],
                "liquidated":      turn["liquidated"],
                "portfolio_value": round(turn["portfolio_value"], 2),
            })

        # Record failed opens
        for fail in turn.get("failed_opens", []):
            failed_opens += 1
            failed_open_history.append({
                "candle_index": i,
                "timestamp":    first_coin.iloc[i]["Date"],
                "coin":         fail["coin"],
                "error":        fail["error"],
            })

        _record(portfolio_series, i, portfolio, prices)

        if not silent and i % 100 == 0:
            print(f"  Candle {i:>4}/{total_candles}  Portfolio: ${portfolio.portfolio_value:,.2f}")

    # --- Result ---
    s = portfolio.summary()
    return BacktestResult(
        initial_capital=initial_capital,
        final_portfolio_value=s["portfolio_value"],
        net_pnl=s["net_pnl"],
        return_pct=s["return_pct"],
        total_candles=total_candles - start_candle,
        total_trades=total_trades,
        total_liquidations=s["total_liquidations"],
        total_liquidation_loss=s["total_liquidation_loss"],
        validation_errors=validation_errors,
        strategy_errors=strategy_errors,
        failed_opens=failed_opens,
        portfolio_series=portfolio_series,
        trade_history=trade_history,
        failed_open_history=failed_open_history,
    )


def _record(
    series: list[dict],
    index: int,
    portfolio: Portfolio,
    prices: dict[str, float],
) -> None:
    """Appends the current portfolio state to the series."""
    series.append({
        "candle_index":    index,
        "portfolio_value": round(portfolio.portfolio_value, 2),
        "cash":            round(portfolio.cash, 2),
        **{f"{c}_price": round(p, 4) for c, p in prices.items()},
    })
