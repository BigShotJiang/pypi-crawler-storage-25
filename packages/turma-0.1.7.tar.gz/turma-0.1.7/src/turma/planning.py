"""Planning orchestration for the Turma CLI."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Sequence

from turma.authoring.base import AuthorBackend
from turma.authoring.claude import ClaudeAuthorBackend
from turma.authoring.codex import CodexAuthorBackend
from turma.authoring.gemini import GeminiAuthorBackend
from turma.authoring.opencode import OpenCodeAuthorBackend
from turma.config import ConfigError, load_config
from turma.errors import PlanningError

ARTIFACT_ORDER = ["proposal", "design", "tasks"]
QUESTION_PATTERNS = (
    "could you clarify",
    "can you clarify",
    "i need to understand",
    "i don't have context",
    "my best guess",
    "which direction should i take",
)
BACKEND_FEATURE_TOKENS = {"backend", "provider", "opencode", "codex", "claude", "gemini"}
OFF_TARGET_BACKEND_PATTERNS = (
    "microservices-based architecture",
    "ai-driven coding assistance",
    "project management capabilities",
    "roll out the integration to users",
    "update the user interface",
    "beads task tracking system",
    "package.json",
    "api integration",
    "rest api",
    "deploy the changes",
    "monitor performance",
    "production environment",
    "rollout plan",
)


def run_planning(feature: str) -> None:
    """Run single-pass author planning for a feature."""
    # Step 1: Load config
    try:
        config = load_config()
    except ConfigError as exc:
        raise PlanningError(str(exc)) from exc

    author_model = config.planning.author_model

    # Step 2: Validate .agents/author.md
    author_path = Path.cwd() / ".agents" / "author.md"
    if not author_path.exists():
        raise PlanningError(
            ".agents/author.md not found. Create it before running turma plan."
        )
    author_role = author_path.read_text()

    # Step 3: Check CLIs on PATH
    if shutil.which("openspec") is None:
        raise PlanningError(
            "openspec CLI not found. Install it: npm install -g @fission-ai/openspec"
        )
    backend = _get_backend(author_model)

    # Step 4: Fail if change already exists
    change_dir = Path.cwd() / "openspec" / "changes" / feature
    if change_dir.exists():
        raise PlanningError(
            f"openspec/changes/{feature}/ already exists. "
            "Remove it or pick a different feature name."
        )

    print("loading config from turma.toml")
    print(f"author model: {author_model}")
    print(f"creating change: {feature}")

    # Step 5: Scaffold change
    _run_openspec(
        ["openspec", "new", "change", feature],
        step=f"scaffolding change {feature}",
    )

    # Step 6: Generate artifacts in fixed order
    written_artifacts: dict[str, Path] = {}

    for artifact_id in ARTIFACT_ORDER:
        print(f"generating {artifact_id} (this may take 1-2 min) ...", end=" ", flush=True)

        instructions = _get_instructions(artifact_id, feature)
        output_path = change_dir / instructions["outputPath"]

        # Read dependency content
        dep_content = _read_dependencies(instructions, written_artifacts)

        # Assemble prompt
        repo_context = _build_repo_context()
        prompt = _build_prompt(
            author_role=author_role,
            instructions=instructions,
            dep_content=dep_content,
            feature=feature,
            repo_context=repo_context,
        )

        # Run claude
        raw_output = backend.generate(prompt, author_model, timeout=300)

        # Write output
        artifact_text = _validate_artifact_output(
            raw_output,
            artifact_id,
            instructions.get("template", ""),
            feature,
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(artifact_text)
        written_artifacts[artifact_id] = output_path

        print("done")

    # Step 7: Summary
    print(f"\nplanning complete. artifacts written to openspec/changes/{feature}/")


def _get_backend(model: str) -> AuthorBackend:
    """Return the author backend for the configured model."""
    if "/" in model:
        return OpenCodeAuthorBackend()
    if model.startswith("claude-"):
        return ClaudeAuthorBackend()
    if (
        model.startswith("gpt-")
        or model.startswith("codex-")
        or re.match(r"^o\d", model)
    ):
        return CodexAuthorBackend()
    if model.startswith("gemini-"):
        return GeminiAuthorBackend()
    raise PlanningError(
        f"unsupported planning author model: {model}. "
        "Supported prefixes: claude-*, gpt-*, codex-*, o*, gemini-*, or provider/model format."
    )


def _run_openspec(
    cmd: Sequence[str],
    *,
    step: str,
) -> subprocess.CompletedProcess[str]:
    """Run an OpenSpec subprocess and raise PlanningError on failure."""
    result = subprocess.run(list(cmd), capture_output=True, text=True)
    if result.returncode != 0:
        detail = (
            result.stderr.strip()
            or result.stdout.strip()
            or "unknown error"
        )
        raise PlanningError(
            f"{step} failed: {cmd[0]} exited with {result.returncode}\n{detail}"
        )
    return result


def _get_instructions(artifact_id: str, feature: str) -> dict:
    """Get openspec instructions JSON for an artifact."""
    result = _run_openspec(
        [
            "openspec", "instructions", artifact_id,
            "--change", feature, "--json",
        ],
        step=f"loading instructions for {artifact_id}",
    )

    return _extract_instructions_json(result.stdout, artifact_id)


def _extract_instructions_json(raw: str, artifact_id: str) -> dict:
    """Extract the JSON payload from openspec instructions output."""
    start = raw.find("{")
    if start == -1:
        raise PlanningError(
            f"failed to parse openspec instructions for {artifact_id}: "
            "no JSON object found"
        )

    json_text = raw[start:]

    try:
        return json.loads(json_text)
    except json.JSONDecodeError as exc:
        preview = raw.strip()[:200]
        raise PlanningError(
            f"failed to parse openspec instructions for {artifact_id}: {exc}\n"
            f"raw output: {preview}"
        ) from exc


def _build_repo_context() -> str:
    """Build a compact summary of the repository for prompt grounding."""
    cwd = Path.cwd()
    lines = [
        "This is the Turma repository — a Python CLI tool.",
        "Language: Python. Build tool: setuptools + uv. No JavaScript, no package.json.",
        "",
        "Source layout:",
    ]

    src_dir = cwd / "src" / "turma"
    if src_dir.exists():
        for p in sorted(src_dir.rglob("*.py")):
            if "__pycache__" in str(p):
                continue
            rel = p.relative_to(cwd)
            lines.append(f"  {rel}")

    tests_dir = cwd / "tests"
    if tests_dir.exists():
        lines.append("")
        lines.append("Test files:")
        for p in sorted(tests_dir.glob("test_*.py")):
            rel = p.relative_to(cwd)
            lines.append(f"  {rel}")

    # Include a compact sample of an existing backend to show the pattern
    authoring_dir = src_dir / "authoring" if src_dir.exists() else None
    if authoring_dir and authoring_dir.exists():
        for backend_file in sorted(authoring_dir.glob("*.py")):
            if backend_file.name in ("__init__.py", "base.py"):
                continue
            sample_lines = backend_file.read_text().splitlines()[:25]
            lines.append("")
            lines.append(f"Existing backend pattern ({backend_file.name}):")
            for line in sample_lines:
                lines.append(f"  {line}")
            break  # one example is enough

    config = cwd / "turma.example.toml"
    if config.exists():
        lines.append("")
        lines.append("Config template: turma.example.toml")

    readme = cwd / "README.md"
    if readme.exists():
        first_lines = readme.read_text().splitlines()[:5]
        lines.append("")
        lines.append("README excerpt:")
        for line in first_lines:
            lines.append(f"  {line}")

    return "\n".join(lines)


def _read_dependencies(
    instructions: dict,
    written_artifacts: dict[str, Path],
) -> str:
    """Read content of completed dependency artifacts."""
    parts = []
    for dep in instructions.get("dependencies", []):
        dep_id = dep["id"]
        if dep_id in written_artifacts:
            content = written_artifacts[dep_id].read_text()
            parts.append(f"<{dep_id}>\n{content}\n</{dep_id}>")
    return "\n\n".join(parts)


def _build_prompt(
    author_role: str,
    instructions: dict,
    dep_content: str,
    feature: str,
    repo_context: str = "",
) -> str:
    """Assemble the author prompt for a single artifact."""
    artifact_id = instructions["artifactId"]
    instruction = instructions.get("instruction", "")
    template = instructions.get("template", "")
    context = instructions.get("context", "")
    rules = instructions.get("rules", "")

    parts = [
        f"You are an author agent. Your role:\n\n<role>\n{author_role}\n</role>",
        f'You are creating the "{artifact_id}" artifact for change "{feature}".',
    ]

    if repo_context:
        parts.append(f"<repo-context>\n{repo_context}\n</repo-context>")

    parts.extend([
        f"<instructions>\n{instruction}\n</instructions>",
        f"<template>\n{template}\n</template>",
    ])

    if context:
        parts.append(f"<context>\n{context}\n</context>")

    if rules:
        parts.append(f"<rules>\n{rules}\n</rules>")

    if dep_content:
        parts.append(f"<dependencies>\n{dep_content}\n</dependencies>")

    parts.append(
        "Output ONLY the artifact markdown content. "
        "No preamble, no commentary, no code fences."
    )
    parts.append(
        "Do not ask clarifying questions. If context is limited, make the "
        "most reasonable implementation-oriented assumptions you can from the "
        "feature name, provided instructions, and repository context."
    )
    parts.append(
        "Return a complete artifact, not notes about what information is missing."
    )
    parts.append(
        "Stay grounded in the requested feature and the existing Turma codebase. "
        "Do not invent unrelated product changes, new user-facing systems, "
        "UI work, microservices, rollout plans, or broad architecture shifts "
        "unless the instructions explicitly require them."
    )
    parts.append(
        "For backend or provider features, focus on concrete code-level changes "
        "such as CLI invocation, backend routing, config, tests, validation, "
        "and smoke-test behavior."
    )
    parts.append(
        "Mirror the existing backend pattern in src/turma/authoring/. "
        "If the repository already contains backends like claude.py or codex.py, "
        "follow that file shape and the existing routing in src/turma/planning.py "
        "instead of inventing new modules, APIs, services, or frameworks."
    )
    parts.append(
        "Do not propose Beads integration, package.json changes, REST/API layers, "
        "or module names outside the current src/turma/authoring/ backend pattern "
        "unless the instructions explicitly require them."
    )
    parts.append(
        "Do not invent new config keys if the existing config format already "
        "supports the feature (e.g. provider/model format in author_model). "
        "Do not add deployment, monitoring, rollout, or production-readiness "
        "tasks. Scope all work to code, tests, config template, and docs "
        "within this repository."
    )

    return "\n\n".join(parts)


def _validate_artifact_output(
    raw: str,
    artifact_id: str,
    template: str,
    feature: str,
) -> str:
    """Reject empty or obviously non-artifact model output."""
    text = raw.strip()
    if not text:
        raise PlanningError(
            f"generating {artifact_id} failed: author returned empty output"
        )

    text = _strip_wrapping_code_fence(text)
    text = _strip_leading_preamble(text)
    lowered = text.lower()
    if any(pattern in lowered for pattern in QUESTION_PATTERNS):
        raise PlanningError(
            f"generating {artifact_id} failed: author asked for clarification "
            "instead of producing the artifact"
        )

    if "?" in text:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if lines and all(re.search(r"\?$", line) for line in lines[:2]):
            raise PlanningError(
                f"generating {artifact_id} failed: author returned a follow-up "
                "question instead of the artifact"
            )

    missing_headings = [
        heading for heading in _extract_template_headings(template)
        if heading not in text
    ]
    if missing_headings:
        raise PlanningError(
            f"generating {artifact_id} failed: output is missing required "
            f"template headings: {', '.join(missing_headings)}"
        )

    _validate_feature_relevance(text, artifact_id, feature)

    return text + "\n"


def _validate_feature_relevance(
    text: str,
    artifact_id: str,
    feature: str,
) -> None:
    """Reject obviously off-target artifacts for backend/provider feature work."""
    tokens = set(re.findall(r"[a-z0-9]+", feature.lower()))
    if not tokens.intersection(BACKEND_FEATURE_TOKENS):
        return

    lowered = text.lower()
    for pattern in OFF_TARGET_BACKEND_PATTERNS:
        if pattern in lowered:
            raise PlanningError(
                f"generating {artifact_id} failed: output drifted into unrelated "
                f"product-planning content ({pattern})"
            )

    if "opencode_planning.py" in lowered:
        raise PlanningError(
            f"generating {artifact_id} failed: output invented a backend module "
            "instead of reusing the existing authoring backend pattern"
        )

    known_backends = {
        "src/turma/authoring/claude.py",
        "src/turma/authoring/codex.py",
        "src/turma/authoring/opencode.py",
        "src/turma/authoring/gemini.py",
    }
    if "src/turma/authoring/" in lowered and not any(
        b in lowered for b in known_backends
    ):
        raise PlanningError(
            f"generating {artifact_id} failed: output referenced an unexpected "
            "backend module path instead of the existing src/turma/authoring/ pattern"
        )


def _strip_leading_preamble(text: str) -> str:
    """Drop conversational lines before the first markdown heading."""
    lines = text.splitlines()
    for index, line in enumerate(lines):
        if re.match(r"^#{1,6}\s+\S", line.strip()):
            return "\n".join(lines[index:]).strip()
    return text


def _strip_wrapping_code_fence(text: str) -> str:
    """Remove a single outer markdown fence if the whole artifact is wrapped."""
    lines = text.splitlines()
    if len(lines) < 3:
        return text

    first = lines[0].strip()
    last = lines[-1].strip()
    if not first.startswith("```") or last != "```":
        return text

    return "\n".join(lines[1:-1]).strip()


def _extract_template_headings(template: str) -> list[str]:
    """Return the markdown headings required by the template."""
    headings = []
    for line in template.splitlines():
        stripped = line.strip()
        if re.match(r"^#{1,6}\s+\S", stripped):
            if "<!--" in stripped or "-->" in stripped:
                continue
            headings.append(stripped)
    return headings
