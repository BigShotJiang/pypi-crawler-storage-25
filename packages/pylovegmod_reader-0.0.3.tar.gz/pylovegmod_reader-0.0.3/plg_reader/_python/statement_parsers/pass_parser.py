from __future__ import annotations

from ..file_parse_dt import Line
from ..ir_builder_dt import IRNode, IRPass
from ._helpers import extract_trailing_comment, is_kw, tokens


class PassParser:
    @staticmethod
    def parse(line: Line) -> list[IRNode] | None:
        t = tokens(line)
        if not is_kw(t, "pass"):
            return None

        _, comment = extract_trailing_comment(t, 1)
        nodes: list[IRNode] = [IRPass(pos=t[0].pos)]
        if comment:
            nodes.append(comment)

        return nodes
