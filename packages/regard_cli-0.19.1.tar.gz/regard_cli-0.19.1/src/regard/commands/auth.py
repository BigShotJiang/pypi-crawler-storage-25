"""Auth setup — single credential onboarding, project-local scope.

Writes `HYPERLIQUID_PRIVATE_KEY` + `POLYMARKET_PRIVATE_KEY` to
`<cwd>/.claude/settings.local.json`. Multi-instance isolation is the default —
each project dir has its own keys.

Run in a separate terminal, `cd`'d to the project directory that Claude Code
is operating on. Keys never enter the conversation transcript.

Usage:
    regard auth               — check current credentials (structured JSON)
    regard auth <0x-key>      — save key for all venues in this project
"""

import getpass
import json
import os
import sys
from pathlib import Path
from typing import Annotated

import typer

auth_app = typer.Typer(
    name="auth",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Credential setup. Bare `regard auth` reports status; `regard auth <key>` saves a key.",
)


def _project_settings_path() -> Path:
    """Target path for auth writes.

    Prefers the nearest existing project settings file (walking up from CWD
    so user-in-subdirectory still hits the right one). Falls back to
    `<cwd>/.claude/settings.local.json` when no project settings exist yet —
    that's first-time setup, and CWD is the user's explicit scope choice.
    """
    from regard.venues.hyperliquid.client import _find_project_settings
    found = _find_project_settings()
    return found if found is not None else (Path.cwd() / ".claude" / "settings.local.json")


def _save_env_vars(pairs: dict[str, str], settings_path: Path) -> None:
    """Merge env vars into settings.local.json via atomic replace.

    Reads existing settings, merges `pairs` into the `env` block, writes to a
    sibling `.tmp` file, then atomically renames. A crash or SIGKILL between
    steps never leaves the file truncated (which would wipe all env vars).
    """
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    env = settings.setdefault("env", {})
    env.update(pairs)
    # Strip any legacy HL agent-key entry left over from pre-rc8 installs
    env.pop("HYPERLIQUID_AGENT_KEY", None)

    tmp = settings_path.with_suffix(settings_path.suffix + ".tmp")
    tmp.write_text(json.dumps(settings, indent=2) + "\n")
    os.replace(tmp, settings_path)


def _validate_hex_key(key: str) -> str:
    """Return normalized 0x-prefixed key or empty string if invalid."""
    key = key.strip()
    if key.startswith("0x"):
        key = key[2:]
    if len(key) != 64:
        return ""
    try:
        int(key, 16)
    except ValueError:
        return ""
    return "0x" + key


def _report_status() -> None:
    """Emit structured JSON about which venues have credentials configured."""
    from regard.core.output import output as _output
    from regard.venues.hyperliquid.client import _load_settings_env

    settings_env = _load_settings_env()
    hl_key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or settings_env.get("HYPERLIQUID_PRIVATE_KEY")
    poly_key = os.environ.get("POLYMARKET_PRIVATE_KEY") or settings_env.get("POLYMARKET_PRIVATE_KEY")

    def _address_of(k: str | None) -> str | None:
        if not k:
            return None
        try:
            import eth_account
            return eth_account.Account.from_key(k).address
        except Exception:
            return None

    hl_addr = _address_of(hl_key)
    poly_addr = _address_of(poly_key)

    result: dict = {"venues": {}}
    result["venues"]["hyperliquid"] = (
        {"configured": True, "address": hl_addr} if hl_key
        else {"configured": False, "setup_command": "regard auth <key>"}
    )
    result["venues"]["polymarket"] = (
        {"configured": True, "address": poly_addr} if poly_key
        else {"configured": False, "setup_command": "regard auth <key>"}
    )

    if hl_addr and hl_addr == poly_addr:
        result["address"] = hl_addr
        result["unified_key"] = True

    _output(result, None)


def _save_key(normalized: str) -> None:
    """Derive + display address, persist key pair.

    Address derivation is mandatory: if eth_account rejects the key (valid
    hex but not a valid secp256k1 scalar — e.g. all-zero or above curve
    order), we abort instead of saving an unusable key that would surface a
    cryptic error at the next trading command.
    """
    import eth_account
    try:
        address = eth_account.Account.from_key(normalized).address
    except Exception as e:
        print()
        print(f"  Key is valid hex but not a valid secp256k1 scalar: {e}", file=sys.stderr)
        print("  Check for typos or try generating a fresh wallet.", file=sys.stderr)
        raise SystemExit(1)

    print()
    print(f"  Wallet address: {address}")

    settings_path = _project_settings_path()
    _save_env_vars(
        {
            "HYPERLIQUID_PRIVATE_KEY": normalized,
            "POLYMARKET_PRIVATE_KEY": normalized,
        },
        settings_path,
    )

    print()
    print(f"  Saved to {settings_path}")
    print()
    print("  Return to Claude Code in this project directory.")
    print("  The key is picked up automatically on the next command.")
    print()
    print("  Note: Polymarket order placement is geo-restricted in some")
    print("  jurisdictions. If orders fail, a VPN may be required.")
    print()


@auth_app.callback(invoke_without_command=True)
def auth(
    key: Annotated[str | None, typer.Argument(help="EVM private key (0x + 64 hex). Omit for status, or use --prompt for hidden input.")] = None,
    prompt: Annotated[bool, typer.Option("--prompt", help="Read key from hidden terminal input (getpass).")] = False,
):
    """Save one EVM private key for all trading venues in this project, or check status.

    The same wallet key signs for Hyperliquid and Polymarket. Writes to
    `<cwd>/.claude/settings.local.json` — project-local, so each Claude Code
    project has its own wallet.

    Run this in a separate terminal, `cd`'d to the same project directory
    Claude Code is operating on. Keys never appear in the conversation
    transcript.

    Modes:
      regard auth              → report status (JSON)
      regard auth <0x-key>     → save key (args visible — use --prompt for privacy)
      regard auth --prompt     → save key via hidden terminal input
    """
    # Prompt mode takes precedence — hidden input via getpass
    if prompt:
        if not sys.stdin.isatty():
            print("Error: --prompt requires an interactive terminal.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — credential setup")
        print()
        print("  Paste your EVM wallet private key. The same key signs for")
        print("  Hyperliquid (perps) and Polymarket (prediction markets).")
        print()
        print(f"  Will be saved to this project: {_project_settings_path()}")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")
        # Empty input under --prompt is a user error, not a status probe
        if not key:
            print()
            print("Error: no key entered.", file=sys.stderr)
            raise SystemExit(1)

    # No key → status report (structured JSON to stdout)
    if not key:
        _report_status()
        return

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    _save_key(normalized)
