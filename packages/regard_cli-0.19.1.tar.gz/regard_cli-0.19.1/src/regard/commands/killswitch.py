"""Killswitch — emergency close all positions, cancel all orders, transfer all funds."""

import sys

import typer

from regard.core.output import die, output


def _log(msg: str):
    """Progress output to stderr — doesn't break JSON on stdout."""
    print(msg, file=sys.stderr, flush=True)

killswitch_app = typer.Typer(
    name="killswitch",
    invoke_without_command=True,
    help="Emergency close all positions, cancel all orders, transfer all funds.",
)


def _get_killswitch_address() -> str | None:
    from regard.venues.hyperliquid.client import _load_settings_env
    return _load_settings_env().get("KILLSWITCH_ADDRESS")


def _get_killswitch_slippage() -> float:
    from regard.commands.config import DEFAULT_KILLSWITCH_SLIPPAGE, _effective_slippage
    from regard.venues.hyperliquid.client import _load_settings_env
    val = _load_settings_env().get("KILLSWITCH_SLIPPAGE")
    result = _effective_slippage(val)
    if val and result == DEFAULT_KILLSWITCH_SLIPPAGE:
        _log(f"  WARN: KILLSWITCH_SLIPPAGE={val} invalid or out of range (0.001-0.5), using default {DEFAULT_KILLSWITCH_SLIPPAGE}")
    return result


@killswitch_app.callback()
def killswitch(
    ctx: typer.Context,
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would happen without executing"),
):
    """Cancel all orders, market-close all positions, transfer all funds across all venues."""
    dest = _get_killswitch_address()
    if not dest:
        from pathlib import Path

        from regard.venues.hyperliquid.client import _find_project_settings
        if _find_project_settings() is None:
            die("validation_error", "NO_PROJECT_SETTINGS",
                f"No project settings found. regard is project-local — looked in {Path.cwd()} and above.",
                hint="cd to the project directory where you set up auth + killswitch, then re-run",
                exit_code=2)
        die("validation_error", "NO_KILLSWITCH_ADDRESS",
            "No killswitch address configured for this project",
            hint="Run: regard config set killswitch-address 0x<your-emergency-destination>",
            exit_code=2)

    if dry_run:
        _log("[killswitch] DRY RUN — no actions will be taken")

    results = {"destination": dest, "dry_run": dry_run, "hl": None, "poly": None}

    _log(f"[killswitch] destination: {dest}")

    # --- Hyperliquid ---
    _log("[killswitch] Hyperliquid")
    try:
        results["hl"] = _kill_hl(dest, dry_run=dry_run)
    except SystemExit:
        raise
    except Exception as e:
        _log(f"[killswitch] HL error: {e}")
        results["hl"] = {"error": str(e)}

    # --- Polymarket ---
    _log("[killswitch] Polymarket")
    try:
        results["poly"] = _kill_poly(dest, dry_run=dry_run)
    except SystemExit:
        raise
    except Exception as e:
        _log(f"[killswitch] Poly error: {e}")
        results["poly"] = {"error": str(e)}

    output(results, None)


def _kill_hl(dest: str, dry_run: bool = False) -> dict:
    from regard.venues.hyperliquid.client import (
        get_address,
        get_all_orders,
        get_all_positions,
        get_dex_balances,
        get_exchange,
        get_spot_balances,
    )
    from regard.venues.hyperliquid.resolver import get_resolver

    exchange = get_exchange()
    info = exchange.info
    addr = get_address()

    # Load HIP-3 dex metadata so SDK's name_to_asset works for all coins
    resolver = get_resolver(info)
    resolver._load_dexes()

    # 1. Cancel all orders
    all_orders = get_all_orders(info, addr)
    cancelled = 0
    cancel_error = None
    if all_orders:
        _log(f"  cancelling {len(all_orders)} orders:")
        for o in all_orders:
            is_trigger = o.get("isTrigger", False)
            otype = "stop" if is_trigger else "limit"
            raw_side = o.get("side", "?")
            oside = "buy" if raw_side in ("B", "b", "buy") else "sell" if raw_side in ("A", "a", "sell") else raw_side
            oprice = o.get("triggerPx", o.get("limitPx", "?")) if is_trigger else o.get("limitPx", "?")
            _log(f"    {o['coin']} {oside} {o.get('sz', '?')} @ ${oprice} ({otype})")
        if not dry_run:
            try:
                cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in all_orders]
                resp = exchange.bulk_cancel(cancel_requests)
                # Count actual successful cancellations from response
                statuses = resp.get("response", {}).get("data", {}).get("statuses", []) if isinstance(resp, dict) else []
                if statuses:
                    cancelled = sum(1 for s in statuses if "success" in s)
                    failed = sum(1 for s in statuses if "error" in s)
                    if failed:
                        cancel_error = f"{failed}/{len(statuses)} cancellations failed"
                else:
                    cancelled = len(all_orders)
            except Exception as e:
                _log(f"    FAIL: {e}")
                cancel_error = str(e)
        else:
            cancelled = len(all_orders)
        _log(f"  {'would cancel' if dry_run else 'cancelled'} {cancelled}")
    else:
        _log("  no open orders")

    # 2. Close all positions at market via SDK market_close
    slippage = _get_killswitch_slippage()
    positions = get_all_positions(info, addr)
    all_mids = {}
    try:
        from regard.venues.hyperliquid.client import get_all_mids
        all_mids = get_all_mids(info)
    except Exception:
        pass
    _log(f"  closing {len(positions)} positions (slippage {slippage:.1%}):")
    closed = []
    for pos in positions:
        coin = pos["coin"]
        szi = float(pos["szi"])
        if szi == 0:
            continue
        side = "buy" if szi < 0 else "sell"
        size = abs(szi)
        direction = "long" if szi > 0 else "short"
        mid = float(all_mids.get(coin, 0))
        notional = f" (~${size * mid:,.2f})" if mid else ""
        _log(f"    {coin} {direction} {size} @ ${mid:,.2f}{notional}" if mid else f"    {coin} {direction} {size}")
        if dry_run:
            _log("      would close")
            closed.append({"asset": coin, "side": side, "size": size, "status": "dry_run"})
            continue
        try:
            resp = exchange.market_close(coin, slippage=slippage)
            if resp is None:
                _log("    FAIL: not found by SDK")
                closed.append({"asset": coin, "side": side, "size": size, "error": "market_close returned None — position not found by SDK"})
                continue
            if resp.get("status") == "err":
                _log(f"    FAIL: {resp.get('response', '')}")
                closed.append({"asset": coin, "side": side, "size": size, "error": resp.get("response", str(resp))})
                continue
            statuses = resp.get("response", {}).get("data", {}).get("statuses", [])
            if statuses and "filled" in statuses[0]:
                filled = statuses[0]["filled"]
                _log(f"      filled @ ${filled.get('avgPx', '?')}")
                closed.append({"asset": coin, "side": side, "size": filled.get("totalSz", str(size)), "avg_price": filled.get("avgPx", ""), "status": "filled"})
            elif statuses and "error" in statuses[0]:
                _log(f"    FAIL: {statuses[0]['error']}")
                closed.append({"asset": coin, "side": side, "size": size, "error": statuses[0]["error"]})
            else:
                _log("    FAIL: no fill")
                closed.append({"asset": coin, "side": side, "size": size, "error": "no fill — IOC expired", "response": str(statuses)})
        except Exception as e:
            _log(f"    FAIL: {e}")
            closed.append({"asset": coin, "side": side, "size": size, "error": str(e)})

    # 2b. Re-check for positions opened during close loop (concurrent sessions)
    if not dry_run:
        try:
            new_positions = [p for p in get_all_positions(info, addr) if float(p.get("szi", 0)) != 0]
            if new_positions:
                _log(f"  {len(new_positions)} new positions appeared during close — closing")
                for pos in new_positions:
                    coin = pos["coin"]
                    szi = float(pos["szi"])
                    side = "buy" if szi < 0 else "sell"
                    size = abs(szi)
                    _log(f"  {coin} {side} {size}")
                    try:
                        resp = exchange.market_close(coin, slippage=slippage)
                        if resp and resp.get("status") != "err":
                            statuses = resp.get("response", {}).get("data", {}).get("statuses", [])
                            if statuses and "filled" in statuses[0]:
                                filled = statuses[0]["filled"]
                                _log(f"      filled @ ${filled.get('avgPx', '?')}")
                                closed.append({"asset": coin, "side": side, "size": filled.get("totalSz", str(size)), "avg_price": filled.get("avgPx", ""), "status": "filled"})
                                continue
                        closed.append({"asset": coin, "side": side, "size": size, "error": "re-check close failed"})
                    except Exception as e:
                        closed.append({"asset": coin, "side": side, "size": size, "error": str(e)})
        except Exception:
            pass  # re-check is best-effort

    # 3. Transfer all funds to destination
    _log(f"  transferring funds to {dest}")
    transferred = []
    from regard.venues.hyperliquid.client import get_account_mode
    is_unified = get_account_mode(info, addr) == "unifiedAccount"

    # Build token name → send_asset identifier map
    # Canonical tokens (like USDC) use plain name. Non-canonical (USDH, USDE, USDT0)
    # need "NAME:tokenId" format for the Hyperliquid API.
    token_send_name = {}
    try:
        spot_meta = info.spot_meta()
        for t in spot_meta["tokens"]:
            if t.get("isCanonical", False):
                token_send_name[t["name"]] = t["name"]
            else:
                token_send_name[t["name"]] = f"{t['name']}:{t['tokenId']}"
    except Exception as e:
        _log(f"  WARN: spot_meta failed ({e}) — transfers will use plain token names")

    if is_unified:
        # Unified accounts: all equity in spot. Use send_asset to transfer to destination.
        # spot_transfer is disabled on unified accounts; send_asset(dest, "spot", "spot", ...) works.
        # Re-read balances fresh (positions just closed, balances may have changed).
        try:
            spot = get_spot_balances(info, addr)
            for s in spot:
                bal = float(s["balance"])
                if bal <= 0.02:
                    continue  # skip sub-cent dust — API rejects tiny transfers
                # Leave tiny dust to avoid "Insufficient balance" from rounding
                send_amount = round(bal - 0.01, 6)
                send_name = token_send_name.get(s["token"], s["token"])
                _log(f"    {s['token']} {send_amount}")
                if dry_run:
                    _log("      would send")
                    transferred.append({"source": "spot", "token": s["token"], "amount": send_amount, "status": "dry_run"})
                else:
                    try:
                        resp = exchange.send_asset(dest, "spot", "spot", send_name, send_amount)
                        if resp.get("status") == "err":
                            _log(f"      FAIL: {resp.get('response', '')}")
                            transferred.append({"source": "spot", "token": s["token"], "error": resp.get("response", str(resp))})
                        else:
                            _log("      sent")
                            transferred.append({"source": "spot", "token": s["token"], "amount": send_amount})
                    except Exception as e:
                        _log(f"      FAIL: {e}")
                        transferred.append({"source": "spot", "token": s["token"], "error": str(e)})
        except Exception as e:
            transferred.append({"source": "spot", "error": str(e)})
    else:
        # Standard accounts: perp + spot + HIP-3 dex balances
        # Order: perp USDC → dex→spot consolidation → wait → spot sweep

        # 3a. Default perp USDC
        try:
            state = info.user_state(addr)
            withdrawable = float(state.get("withdrawable", "0"))
            if withdrawable > 0.01:
                _log(f"    USDC {withdrawable}")
                if dry_run:
                    _log("      would send")
                    transferred.append({"source": "perp", "token": "USDC", "amount": withdrawable, "status": "dry_run"})
                else:
                    resp = exchange.usd_transfer(withdrawable, dest)
                    if resp and resp.get("status") == "err":
                        _log(f"      FAIL: {resp.get('response', '')}")
                        transferred.append({"source": "perp", "token": "USDC", "error": resp.get("response", str(resp))})
                    else:
                        _log("      sent")
                        transferred.append({"source": "perp", "token": "USDC", "amount": withdrawable})
        except Exception as e:
            transferred.append({"source": "perp", "token": "USDC", "error": str(e)})

        # 3b. HIP-3 dex balances → consolidate to spot via send_asset
        consolidated_any = False
        try:
            from regard.venues.hyperliquid.client import get_collateral_map
            coll_map = get_collateral_map(info)
            dex_bals = get_dex_balances(info, addr)
            for d in dex_bals:
                dex = d.get("dex", "")
                if not dex or dex in ("spot", "default"):
                    continue
                val = float(d.get("account_value", 0))
                if val <= 0.01:
                    continue
                token_name = coll_map.get(dex, ("USDC", 0))[0]
                send_name = token_send_name.get(token_name, token_name)
                try:
                    _log(f"    dex:{dex} → spot  {token_name} {val}")
                    if dry_run:
                        _log("      would consolidate")
                        transferred.append({"source": f"dex:{dex}", "token": token_name, "amount": val, "consolidated": True, "status": "dry_run"})
                    else:
                        exchange.send_asset(addr, dex, "spot", send_name, val)
                        _log("      consolidated")
                        transferred.append({"source": f"dex:{dex}", "token": token_name, "amount": val, "consolidated": True})
                    consolidated_any = True
                except Exception as e:
                    _log(f"      FAIL: {e}")
                    transferred.append({"source": f"dex:{dex}", "token": token_name, "error": str(e)})
        except Exception as e:
            transferred.append({"source": "dex_scan", "error": str(e)})

        # 3c. Wait for dex→spot settlement before sweeping
        if consolidated_any and not dry_run:
            import time
            _log("    waiting for settlement (3s)")
            time.sleep(3)

        # 3d. Sweep all spot balances to destination
        try:
            spot = get_spot_balances(info, addr)
            for s in spot:
                bal = float(s["balance"])
                if bal <= 0:
                    continue
                send_amount = round(bal - 0.01, 6) if bal > 0.02 else bal
                if send_amount <= 0:
                    continue
                send_name = token_send_name.get(s["token"], s["token"])
                _log(f"    {s['token']} {send_amount}")
                if dry_run:
                    _log("      would send")
                    transferred.append({"source": "spot", "token": s["token"], "amount": send_amount, "status": "dry_run"})
                else:
                    try:
                        exchange.spot_transfer(send_amount, dest, send_name)
                        _log("      sent")
                        transferred.append({"source": "spot", "token": s["token"], "amount": send_amount})
                    except Exception as e:
                        _log(f"      FAIL: {e}")
                        transferred.append({"source": "spot", "token": s["token"], "error": str(e)})
        except Exception as e:
            transferred.append({"source": "spot", "error": str(e)})

        # 3e. Final default perp sweep — catches USDC consolidated from USDC-collateral dexes
        if not dry_run:
            try:
                state = info.user_state(addr)
                withdrawable = float(state.get("withdrawable", "0"))
                if withdrawable > 0.01:
                    resp = exchange.usd_transfer(withdrawable, dest)
                    if resp and resp.get("status") == "err":
                        transferred.append({"source": "perp_final", "token": "USDC", "error": resp.get("response", str(resp))})
                    else:
                        transferred.append({"source": "perp_final", "token": "USDC", "amount": withdrawable})
            except Exception as e:
                transferred.append({"source": "perp_final", "token": "USDC", "error": str(e)})

    result = {
        "cancelled_orders": cancelled,
        "closed_positions": closed,
        "transferred": transferred,
    }
    if cancel_error is not None:
        result["cancel_error"] = cancel_error
    return result


def _ctf_redeem(condition_id: str, size: float, token_id: str) -> dict:
    from regard.venues.polymarket.client import ctf_redeem
    result = ctf_redeem(condition_id, size, token_id)
    _log(f"      redeemed (tx {result['tx']})")
    return result


def _ctf_merge(condition_id: str, size: float, token_id: str,
               neg_risk: bool = False) -> dict:
    from regard.venues.polymarket.client import ctf_merge
    result = ctf_merge(condition_id, size, token_id, neg_risk=neg_risk)
    _log(f"      merged (tx {result['tx']})")
    return result


def _clob_sell(clob, token_id: str, close_side: str, size: float, closed: list):
    """Market-sell a position on the CLOB. Appends result to closed list."""
    try:
        from py_clob_client_v2.clob_types import MarketOrderArgs, OrderType
        from py_clob_client_v2.order_builder.constants import BUY as CLOB_BUY
        from py_clob_client_v2.order_builder.constants import SELL as CLOB_SELL
        order_side = CLOB_SELL if close_side == "SELL" else CLOB_BUY
        order_args = MarketOrderArgs(
            token_id=token_id,
            amount=size,
            side=order_side,
        )
        signed = clob.create_market_order(order_args)
        resp = clob.post_order(signed, OrderType.FOK)
        # Check fill status — FOK can return 200 with no fill
        if not isinstance(resp, dict):
            closed.append({"token_id": token_id, "side": close_side, "size": size,
                           "error": f"unexpected response: {resp}"})
            return
        if not resp.get("success", False):
            closed.append({"token_id": token_id, "side": close_side, "size": size,
                           "error": resp.get("errorMsg") or "order rejected"})
            return
        status = resp.get("status", "unknown")
        if status == "delayed":
            # Sports markets apply a 3-second matching delay — order is live, not failed
            closed.append({"token_id": token_id, "side": close_side, "size": size, "status": "delayed"})
            return
        if status != "matched":
            closed.append({"token_id": token_id, "side": close_side, "size": size,
                           "error": f"FOK not filled (status: {status})"})
            return
        closed.append({"token_id": token_id, "side": close_side, "size": size, "status": "filled"})
    except Exception as e:
        closed.append({"token_id": token_id, "error": str(e)})


def _kill_poly(dest: str, dry_run: bool = False) -> dict:
    from regard.venues.polymarket.client import CONTRACTS, _get_key, get_clob_client, get_web3

    # Check if Polymarket is configured
    try:
        _get_key()
    except SystemExit:
        return {"skipped": "not configured"}

    # Try CLOB client — skip geo pre-check so close-only jurisdictions
    # can still sell existing positions. If fully blocked, individual CLOB
    # ops will fail per-operation. On-chain ops always work regardless.
    from regard.venues.polymarket.client import PolymarketNotSetUp
    clob = None
    try:
        clob = get_clob_client()
    except PolymarketNotSetUp as e:
        _log(f"  INFO: {e} (skipping CLOB — on-chain sweep still runs)")
    except Exception as e:
        _log(f"  WARN: CLOB init failed ({e}) — CLOB ops skipped, on-chain ops will proceed")

    # 1. Cancel all orders
    cancel_error = None
    if clob:
        _log("  cancelling orders")
        if not dry_run:
            try:
                clob.cancel_all()
            except Exception as e:
                _log(f"    FAIL: {e}")
                cancel_error = str(e)
    elif not clob and not dry_run:
        cancel_error = "CLOB unavailable"

    # 2. Close all positions
    from regard.venues.polymarket.client import get_positions
    positions_error = None
    try:
        pos_list = get_positions(raise_on_error=True)
    except Exception as e:
        _log(f"  WARN: failed to fetch positions: {e}")
        positions_error = str(e)
        pos_list = []

    # Build merge plan: shared logic computes min(YES, NO) per condition
    # and looks up negRisk routing. Killswitch consumes the plan for execution.
    from regard.venues.polymarket.client import plan_merges
    merge_plan = plan_merges(pos_list)
    merge_sizes = {m["condition_id"]: m["merge_size"] for m in merge_plan}
    neg_risk_map = {m["condition_id"]: m["neg_risk"] for m in merge_plan}

    merged_conditions = set()

    _log(f"  closing {len(pos_list)} positions:")
    closed = []
    for p in pos_list:
        size = float(p.get("size", 0) or 0)
        if size == 0:
            continue
        token_id = p.get("asset_id", "")
        condition_id = p.get("condition_id", "")
        side = p.get("side", "")
        close_side = "SELL" if side == "BUY" else "BUY"
        market_name = p.get("market", "")
        outcome = p.get("outcome", "")
        # Human-readable label: "Gavin Newsom Election — YES 10 shares"
        label = f"{market_name} — {outcome} {size} shares" if market_name else f"{token_id[:16]}... {size} shares"

        if p.get("redeemable") and condition_id:
            # Resolved market — redeem winning tokens for pUSD on-chain
            _log(f"    {label} (redeem — market resolved)")
            if dry_run:
                closed.append({"token_id": token_id, "action": "redeem", "size": size, "status": "dry_run"})
                continue
            try:
                closed.append(_ctf_redeem(condition_id, size, token_id))
            except Exception as e:
                _log(f"      FAIL: {e}")
                closed.append({"token_id": token_id, "action": "redeem", "error": str(e)})
        elif p.get("mergeable") and condition_id:
            if condition_id in merged_conditions:
                # Second leg — only sell residual if this leg is larger than merge amount
                merge_amount = merge_sizes.get(condition_id, size)
                residual = size - merge_amount
                if residual > 0:
                    if clob:
                        _log(f"    {label} — sell residual {residual} shares (post-merge)")
                        _clob_sell(clob, token_id, close_side, residual, closed)
                    else:
                        closed.append({"token_id": token_id, "side": close_side, "size": residual, "error": "CLOB unavailable"})
                else:
                    _log(f"    {label} — skip (fully merged)")
                continue
            merge_amount = merge_sizes.get(condition_id, size)
            # Hold both outcomes — merge for pUSD on-chain (cheaper than CLOB sell)
            _log(f"    {label} (merge — both outcomes held, {merge_amount} shares)")
            if dry_run:
                merged_conditions.add(condition_id)
                closed.append({"token_id": token_id, "action": "merge", "size": merge_amount, "status": "dry_run"})
                residual = size - merge_amount
                if residual > 0:
                    closed.append({"token_id": token_id, "side": close_side, "size": residual, "status": "dry_run"})
                continue
            try:
                closed.append(_ctf_merge(condition_id, merge_amount, token_id,
                                         neg_risk=neg_risk_map.get(condition_id, False)))
                merged_conditions.add(condition_id)
            except Exception as e:
                _log(f"      FAIL: {e} — falling back to CLOB sell")
                closed.append({"token_id": token_id, "action": "merge", "error": str(e)})
                if clob:
                    _clob_sell(clob, token_id, close_side, size, closed)
                continue
            # Sell residual shares from this leg if larger than merge amount
            residual = size - merge_amount
            if residual > 0:
                if clob:
                    _log(f"    {label} — sell residual {residual} shares (post-merge)")
                    _clob_sell(clob, token_id, close_side, residual, closed)
                else:
                    closed.append({"token_id": token_id, "side": close_side, "size": residual, "error": "CLOB unavailable"})
        else:
            # Active market — FOK sell on CLOB
            _log(f"    {label} (market sell)")
            if dry_run:
                closed.append({"token_id": token_id, "side": close_side, "size": size, "status": "dry_run"})
                continue
            if clob:
                _clob_sell(clob, token_id, close_side, size, closed)
            else:
                closed.append({"token_id": token_id, "side": close_side, "size": size, "error": "CLOB unavailable"})

    # No Poly recheck — the Data API (data-api.polymarket.com) has settlement lag
    # and returns stale positions after fills. A recheck against it would always
    # see the just-closed positions and try to re-sell them, causing 400 errors.
    # The HL recheck works because its API reflects live state. If positions are
    # missed here, running killswitch again will catch them.

    # Wait for CLOB sell proceeds to settle on-chain before reading balances.
    # CLOB matches are off-chain; the pUSD transfer to the wallet is async.
    # Without this wait, the balance read misses sell proceeds and leaves them stranded.
    had_clob_sells = any(c.get("status") in ("filled", "delayed") and "action" not in c for c in closed)
    if had_clob_sells and not dry_run:
        import time
        _log("  waiting 5s for CLOB settlement...")
        time.sleep(5)

    # In dry-run, project proceeds from merge/sell/redeem into the balance estimate.
    # Binary (neg_risk=False) markets can be pre-V2 (USDC.e collateral) or post-V2 (pUSD);
    # resolve per-position by matching token_id against both derivations. NegRisk markets
    # return the current-era collateral (pUSD). CLOB sells settle in pUSD on V2.
    # merge: merge_size × $1 (YES + NO = $1 collateral)
    # sell: sell_size × cur_price (approximate)
    # redeem: size × $1 (resolved = full value)
    projected_pusd = 0.0
    projected_usdc_e = 0.0
    if dry_run:
        from regard.venues.polymarket.client import resolve_binary_collateral
        # Build lookups from the original positions list keyed by token_id
        pos_by_token = {p.get("asset_id", ""): p for p in pos_list}
        price_by_token = {k: float(v.get("cur_price", 0) or 0) for k, v in pos_by_token.items()}

        def _projected_collateral(token_id: str) -> str:
            """Return the collateral address this position's proceeds would land in."""
            p = pos_by_token.get(token_id) or {}
            if p.get("neg_risk"):
                return CONTRACTS["PUSD"]  # NegRiskAdapter returns current-era collateral
            cid = p.get("condition_id", "")
            outcome = p.get("outcome", "yes")
            if not cid:
                return CONTRACTS["PUSD"]
            try:
                return resolve_binary_collateral(cid, token_id, outcome)
            except Exception:
                return CONTRACTS["PUSD"]  # fallback — unresolved defaults to current era

        for c in closed:
            sz = float(c.get("size", 0) or 0)
            token_id = c.get("token_id", "")
            if c.get("action") in ("merge", "redeem"):
                addr = _projected_collateral(token_id)
                if addr == CONTRACTS["USDC_E"]:
                    projected_usdc_e += sz
                else:
                    projected_pusd += sz
            elif c.get("side") and c.get("status") == "dry_run":
                # CLOB sells settle in pUSD on V2 regardless of market era
                projected_pusd += sz * price_by_token.get(token_id, 0.5)

    # 3. Transfer all tokens on Polygon to destination
    _log(f"  transferring tokens to {dest}")
    transferred = []
    try:
        import eth_account

        w3 = get_web3()
        key = _get_key()
        account = eth_account.Account.from_key(key)
        sender = w3.to_checksum_address(account.address)
        dest_checksum = w3.to_checksum_address(dest)
        nonce = w3.eth.get_transaction_count(sender, "pending")

        from regard.core.evm import (
            EVMSafetyError,
            get_erc20_balance,
            get_safe_gas_price,
            transfer_erc20,
            transfer_native,
        )

        USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"
        tokens = [
            ("pUSD", CONTRACTS["PUSD"]),
            ("USDC.e", CONTRACTS["USDC_E"]),
            ("USDC", USDC_NATIVE),
        ]

        pending_gas = 0
        # Pre-check: enough POL for gas? (ERC-20 transfers need ~100k gas each)
        # In dry-run, include projected merge/sell proceeds — they'd create an
        # ERC-20 balance that needs gas to transfer even though it's zero now.
        pol_balance = w3.eth.get_balance(sender)
        gas_price = w3.eth.gas_price
        erc20_gas = 100_000
        erc20_count = 0
        for _, addr in tokens:
            bal = get_erc20_balance(w3, sender, addr)
            if dry_run and addr == CONTRACTS["PUSD"] and projected_pusd > 0:
                bal += int(round(projected_pusd * 1e6))
            if dry_run and addr == CONTRACTS["USDC_E"] and projected_usdc_e > 0:
                bal += int(round(projected_usdc_e * 1e6))
            if bal > 0:
                erc20_count += 1
        estimated_gas_needed = erc20_count * erc20_gas * gas_price + 21000 * gas_price
        if pol_balance < estimated_gas_needed and erc20_count > 0:
            _log(f"  WARN: POL balance ({pol_balance / 1e18:.6f}) may be insufficient for {erc20_count} ERC-20 transfers (need ~{estimated_gas_needed / 1e18:.6f})")

        # In dry-run, simulate the POL drain from on-chain ops that WOULD run
        # before the final POL transfer. Without this, the projected POL transfer
        # amount overshoots actual by 5-15% on cycles with merges/redeems.
        # Observed gas on Polygon mainnet: CTF/negRisk merge ~150k, CTF redeem
        # ~100k, ERC-20 transfer ~100k (safety margin over actual ~50-65k).
        if dry_run:
            merge_count = sum(1 for c in closed if c.get("action") == "merge")
            redeem_count = sum(1 for c in closed if c.get("action") == "redeem")
            pending_gas = (
                merge_count * 150_000
                + redeem_count * 100_000
                + erc20_count * erc20_gas
            ) * gas_price

        for label, token_addr in tokens:
            try:
                balance = get_erc20_balance(w3, sender, token_addr)
                # In dry-run, add projected merge/sell/redeem proceeds to the matching slot
                if dry_run and label == "pUSD" and projected_pusd > 0:
                    balance += int(round(projected_pusd * 1e6))
                if dry_run and label == "USDC.e" and projected_usdc_e > 0:
                    balance += int(round(projected_usdc_e * 1e6))
                if balance == 0:
                    continue
                _log(f"    {label} {balance / 1e6}")
                if dry_run:
                    transferred.append({"token": label, "amount": balance / 1e6, "status": "dry_run"})
                    continue
                tx_hash = transfer_erc20(w3, account, dest_checksum, token_addr, balance, nonce=nonce)
                _log(f"      sent tx 0x{tx_hash.hex()}")
                transferred.append({"token": label, "amount": balance / 1e6, "tx_hash": f"0x{tx_hash.hex()}"})
                pending_gas += erc20_gas * w3.eth.gas_price
                nonce += 1
            except Exception as e:
                err_msg = str(e)
                if "insufficient funds" in err_msg.lower():
                    err_msg = "insufficient POL for gas"
                _log(f"      FAIL: {err_msg}")
                transferred.append({"token": label, "error": err_msg})
                # Only increment nonce if the tx may have been broadcast.
                # EVMSafetyError means simulation rejected — nonce not consumed.
                if not isinstance(e, EVMSafetyError):
                    nonce += 1

        # Transfer native POL (keep gas for this tx + any pending ERC-20 txs)
        # If any position close failed, reserve POL for a future recovery run's
        # ERC-20 transfer — otherwise the next killswitch can sell the stranded
        # shares but has no gas to transfer the pUSD proceeds.
        has_stranded = any("error" in c for c in closed) and not dry_run
        recovery_reserve = (100_000 + 21_000) * (w3.eth.gas_price if has_stranded else 0)
        try:
            pol_balance = w3.eth.get_balance(sender)
            gas_price = get_safe_gas_price(w3)
            # 50% headroom on the this-tx gas portion: transfer_native re-fetches
            # gas_price independently, so a price spike between snapshots can
            # otherwise push tx_cost above what we reserved. pending_gas is
            # already-spent so doesn't need a buffer; recovery_reserve is
            # already buffered upstream.
            gas_cost = int(21000 * gas_price * 1.5) + pending_gas + recovery_reserve
            if pol_balance > gas_cost * 2:
                send_amount = pol_balance - gas_cost
                _log(f"    POL {send_amount / 1e18:.6f}")
                if dry_run:
                    transferred.append({"token": "POL", "amount": send_amount / 1e18, "status": "dry_run"})
                else:
                    tx_hash = transfer_native(w3, account, dest_checksum, send_amount)
                    _log(f"      sent tx 0x{tx_hash.hex()}")
                    transferred.append({"token": "POL", "amount": send_amount / 1e18, "tx_hash": f"0x{tx_hash.hex()}"})
        except Exception as e:
            transferred.append({"token": "POL", "error": str(e)})

    except Exception as e:
        transferred.append({"error": str(e)})

    cancel_status = "all" if cancel_error is None else f"failed: {cancel_error}"
    result = {"cancelled_orders": cancel_status, "closed_positions": closed, "transferred": transferred}
    if not clob:
        result["clob_unavailable"] = True
    if positions_error:
        result["positions_fetch_error"] = positions_error
    return result
