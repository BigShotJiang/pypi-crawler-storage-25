"""Watchers — long-running REST pollers that emit JSONL events on threshold crossings.

Paired with Claude Code's Monitor tool: the agent arms a watcher, Monitor
consumes its stdout, and matching events wake the session. Architecture is
REST-polling by design — WebSocket feeds drop events under stress and the
latency tier is minutes, not milliseconds.

Output contract (stdout only, line-buffered):
    {"ts":"2026-04-21T15:52:00Z","event":"<name>","watcher":"<type>",...}

Exit codes:
    0  clean shutdown (SIGTERM/SIGINT)
    2  usage / validation error (via die())
    3  auth error
    4  venue error on startup
"""

import json
import signal
import sys
import threading
from datetime import datetime, timezone
from typing import Annotated

import typer

from regard.core.output import die
from regard.venues.hyperliquid.client import (
    get_address,
    get_all_mids,
    get_all_positions,
    get_dex_balances,
    get_info,
)

watch_app = typer.Typer(
    name="watch",
    no_args_is_help=True,
    help="Long-running REST pollers that emit JSONL alerts on threshold crossings.",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Loop scaffold — shared signal handling, JSONL emission, poll cycle.
# ---------------------------------------------------------------------------

_shutdown = threading.Event()


def _install_signal_handlers():
    """Trap SIGTERM/SIGINT so the loop exits cleanly."""
    def handler(_signum, _frame):
        _shutdown.set()
    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)


def _emit(event: dict) -> None:
    """Write one JSONL event to stdout and flush."""
    event.setdefault("ts", datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    sys.stdout.write(json.dumps(event, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def _normalize_asset(asset: str) -> str:
    """Uppercase asset name, preserving lowercase HIP-3 dex prefix.

    HL API keys are case-sensitive (BTC, ETH, xyz:TSLA). The rest of the CLI
    routes through a case-insensitive resolver; watchers do raw dict/universe
    lookups, so we normalize here.
    """
    if ":" in asset:
        dex, name = asset.split(":", 1)
        return f"{dex}:{name.upper()}"
    return asset.upper()


def _validate_interval(interval: int) -> None:
    """`threading.Event.wait(0)` / `.wait(-1)` return immediately — would hammer the API."""
    if interval <= 0:
        die("validation_error", "INVALID_INTERVAL", "--interval must be > 0", param="interval")


def _run_loop(watcher: str, interval: int, poll_fn) -> None:
    """Run poll_fn() every `interval` seconds until SIGTERM.

    poll_fn should emit its own threshold events via _emit(). This scaffold
    handles signal wiring, interval sleep, and consecutive-error reporting.
    """
    _install_signal_handlers()
    consecutive_errors = 0
    while not _shutdown.is_set():
        try:
            poll_fn()
            if consecutive_errors > 0:
                _emit({"event": "watch_recovered", "watcher": watcher, "after_errors": consecutive_errors})
                consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            if consecutive_errors == 3:  # emit once at 3 to avoid spam, then stay quiet
                _emit({"event": "watch_error", "watcher": watcher, "err": str(e), "consecutive": consecutive_errors})
        _shutdown.wait(interval)


# ---------------------------------------------------------------------------
# drawdown — alert when total equity drops N% from a baseline.
# ---------------------------------------------------------------------------

@watch_app.command()
def drawdown(
    baseline: Annotated[float, typer.Option("--baseline", help="Reference equity in USD (typically captured at yolo start)")],
    threshold_pct: Annotated[float, typer.Option("--threshold-pct", help="Drawdown % that triggers the alert")],
    interval: Annotated[int, typer.Option("--interval", help="Seconds between polls")] = 30,
    once: Annotated[bool, typer.Option("--once", help="Run one poll cycle and exit (for testing)")] = False,
):
    """Emit drawdown_alert when portfolio drops >threshold_pct from baseline."""
    if baseline <= 0:
        die("validation_error", "INVALID_BASELINE", "--baseline must be > 0", param="baseline")
    if threshold_pct <= 0:
        die("validation_error", "INVALID_THRESHOLD", "--threshold-pct must be > 0", param="threshold_pct")
    _validate_interval(interval)

    info = get_info()
    address = get_address()

    state = {"triggered": False}

    def poll():
        balances = get_dex_balances(info, address)
        if not balances:
            raise RuntimeError("no balances returned from API")
        current = sum(float(b.get("account_value", 0)) for b in balances)
        pct = (baseline - current) / baseline * 100
        if pct >= threshold_pct and not state["triggered"]:
            _emit({
                "event": "drawdown_alert",
                "watcher": "drawdown",
                "pct": round(pct, 2),
                "baseline": baseline,
                "current": round(current, 2),
                "threshold_pct": threshold_pct,
            })
            state["triggered"] = True
        elif pct < threshold_pct and state["triggered"]:
            _emit({
                "event": "drawdown_recovered",
                "watcher": "drawdown",
                "pct": round(pct, 2),
                "baseline": baseline,
                "current": round(current, 2),
            })
            state["triggered"] = False

    if once:
        poll()
        return
    _run_loop("drawdown", interval, poll)


# ---------------------------------------------------------------------------
# liquidation — alert when any position is close to its liquidation price.
# ---------------------------------------------------------------------------

@watch_app.command()
def liquidation(
    proximity_pct: Annotated[float, typer.Option("--proximity-pct", help="Alert when a position is within N%% of its liquidation price")],
    interval: Annotated[int, typer.Option("--interval", help="Seconds between polls")] = 30,
    once: Annotated[bool, typer.Option("--once", help="Run one poll cycle and exit")] = False,
):
    """Emit liquidation_warning when any open position is close to its liq price."""
    if proximity_pct <= 0:
        die("validation_error", "INVALID_PROXIMITY", "--proximity-pct must be > 0", param="proximity_pct")
    _validate_interval(interval)

    info = get_info()
    address = get_address()
    at_risk: set[str] = set()

    def poll():
        positions = get_all_positions(info, address)
        mids = get_all_mids(info)
        currently_at_risk: set[str] = set()
        for pos in positions:
            size = float(pos.get("szi", 0))
            if size == 0:
                continue
            coin = pos.get("coin", "")
            liq_str = pos.get("liquidationPx")
            if liq_str is None or liq_str == "":
                continue  # no liq price (e.g. cross-margin with zero isolation)
            try:
                liq = float(liq_str)
                mark = float(mids.get(coin, 0))
            except (TypeError, ValueError):
                continue
            if mark <= 0 or liq <= 0:
                continue
            if size > 0:  # long: liq < mark
                proximity = (mark - liq) / mark * 100
            else:  # short: liq > mark
                proximity = (liq - mark) / mark * 100
            if proximity < proximity_pct:
                currently_at_risk.add(coin)
                if coin not in at_risk:
                    _emit({
                        "event": "liquidation_warning",
                        "watcher": "liquidation",
                        "asset": coin,
                        "side": "long" if size > 0 else "short",
                        "size": abs(size),
                        "mark": mark,
                        "liq": liq,
                        "proximity_pct": round(proximity, 2),
                        "threshold_pct": proximity_pct,
                    })
        # Emit recovery for any previously-at-risk asset that's no longer at risk
        for coin in at_risk - currently_at_risk:
            _emit({"event": "liquidation_cleared", "watcher": "liquidation", "asset": coin})
        at_risk.clear()
        at_risk.update(currently_at_risk)

    if once:
        poll()
        return
    _run_loop("liquidation", interval, poll)


# ---------------------------------------------------------------------------
# price — alert when an asset crosses above/below user-specified thresholds.
# ---------------------------------------------------------------------------

@watch_app.command()
def price(
    asset: Annotated[str, typer.Argument(help="Asset symbol (e.g. BTC, ETH, HYPE)")],
    above: Annotated[float | None, typer.Option("--above", help="Alert when price rises above this level")] = None,
    below: Annotated[float | None, typer.Option("--below", help="Alert when price falls below this level")] = None,
    interval: Annotated[int, typer.Option("--interval", help="Seconds between polls")] = 15,
    once: Annotated[bool, typer.Option("--once", help="Run one poll cycle and exit")] = False,
):
    """Emit price_cross when asset price crosses an --above or --below threshold."""
    if above is None and below is None:
        die("validation_error", "MISSING_THRESHOLD", "Provide --above and/or --below")
    if above is not None and below is not None and above <= below:
        die("validation_error", "INVALID_RANGE", "--above must be greater than --below")
    _validate_interval(interval)

    info = get_info()
    resolved_asset = _normalize_asset(asset)
    state = {"above_triggered": False, "below_triggered": False}

    def poll():
        mids = get_all_mids(info)
        raw = mids.get(resolved_asset)
        if raw is None:
            raise RuntimeError(f"asset '{resolved_asset}' not found in mids")
        current = float(raw)

        if above is not None:
            if current > above and not state["above_triggered"]:
                _emit({
                    "event": "price_cross",
                    "watcher": "price",
                    "asset": resolved_asset,
                    "direction": "above",
                    "price": current,
                    "threshold": above,
                })
                state["above_triggered"] = True
            elif current <= above:
                state["above_triggered"] = False

        if below is not None:
            if current < below and not state["below_triggered"]:
                _emit({
                    "event": "price_cross",
                    "watcher": "price",
                    "asset": resolved_asset,
                    "direction": "below",
                    "price": current,
                    "threshold": below,
                })
                state["below_triggered"] = True
            elif current >= below:
                state["below_triggered"] = False

    if once:
        poll()
        return
    _run_loop("price", interval, poll)


# ---------------------------------------------------------------------------
# funding — alert when an asset's hourly funding rate exceeds a threshold.
# ---------------------------------------------------------------------------

@watch_app.command()
def funding(
    asset: Annotated[str, typer.Argument(help="Asset symbol (e.g. BTC, ETH)")],
    threshold_hourly_pct: Annotated[float, typer.Option("--threshold-hourly-pct", help="Alert when abs(hourly funding rate) >= this percent (e.g. 0.05 = 0.05%%/hr)")],
    interval: Annotated[int, typer.Option("--interval", help="Seconds between polls")] = 300,
    once: Annotated[bool, typer.Option("--once", help="Run one poll cycle and exit")] = False,
):
    """Emit funding_spike when asset's hourly funding rate's abs value >= threshold."""
    if threshold_hourly_pct <= 0:
        die("validation_error", "INVALID_THRESHOLD", "--threshold-hourly-pct must be > 0")
    _validate_interval(interval)

    info = get_info()
    resolved_asset = _normalize_asset(asset)
    state = {"triggered": False}

    def poll():
        dex = resolved_asset.split(":")[0] if ":" in resolved_asset else ""
        if dex:
            ctxs = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex})
        else:
            ctxs = info.meta_and_asset_ctxs()
        funding_raw = None
        for a_info, a_ctx in zip(ctxs[0]["universe"], ctxs[1]):
            if a_info.get("name") == resolved_asset:
                funding_raw = a_ctx.get("funding")
                break
        if funding_raw is None:
            raise RuntimeError(f"funding not found for asset '{resolved_asset}'")
        hourly_pct = float(funding_raw) * 100
        abs_pct = abs(hourly_pct)
        if abs_pct >= threshold_hourly_pct and not state["triggered"]:
            _emit({
                "event": "funding_spike",
                "watcher": "funding",
                "asset": resolved_asset,
                "hourly_pct": round(hourly_pct, 6),
                "abs_hourly_pct": round(abs_pct, 6),
                "threshold_hourly_pct": threshold_hourly_pct,
                "direction": "long_pays" if hourly_pct > 0 else "short_pays",
            })
            state["triggered"] = True
        elif abs_pct < threshold_hourly_pct and state["triggered"]:
            _emit({
                "event": "funding_normalized",
                "watcher": "funding",
                "asset": resolved_asset,
                "hourly_pct": round(hourly_pct, 6),
            })
            state["triggered"] = False

    if once:
        poll()
        return
    _run_loop("funding", interval, poll)
