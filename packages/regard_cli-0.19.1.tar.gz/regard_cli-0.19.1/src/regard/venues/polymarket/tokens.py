"""Polygon token registry — hardcoded, version-controlled.

Contract addresses are security-critical: a wrong address sends funds to a
black hole. This registry is hardcoded in source (not config) so that changes
require a code commit + release, reviewed in git. The set of Polygon tokens
we support is small and stable.

Adding a new token: open a PR, add to POLYGON_TOKENS, review, merge, release.
"""

from regard.core.output import die

POLYGON_TOKENS: dict[str, dict] = {
    "pusd": {
        "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB",
        "decimals": 6,
        "name": "pUSD (Polymarket USD)",
    },
    "usdc_e": {
        "address": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
        "decimals": 6,
        "name": "USDC.e (Bridged)",
    },
    "usdc": {
        "address": "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",
        "decimals": 6,
        "name": "USDC (Native)",
    },
    "pol": {
        "address": None,  # native token, no contract
        "decimals": 18,
        "name": "POL",
    },
}


def resolve_token(name: str) -> dict:
    """Resolve token name to registry entry. Dies if unknown."""
    token = POLYGON_TOKENS.get(name.lower())
    if not token:
        available = ", ".join(POLYGON_TOKENS)
        die(
            "validation_error",
            "UNKNOWN_TOKEN",
            f"Unknown Polygon token: '{name}'. Available: {available}",
            hint=f"regard poly send <amount> --to <label> --token <{available}>",
        )
    return token
