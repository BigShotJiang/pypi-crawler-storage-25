"""Polymarket venue — prediction market trading."""

import typer

poly_app = typer.Typer(
    name="poly",
    no_args_is_help=True,
    help="Polymarket prediction market trading. JSON output by default.",
    pretty_exceptions_enable=False,
)


@poly_app.callback()
def poly_main(ctx: typer.Context):
    """Polymarket trading CLI."""
    ctx.ensure_object(dict)


# Register all poly venue commands — must be after poly_app is defined
from regard.venues.polymarket.commands import act, orient, research, review  # noqa: E402, F401
