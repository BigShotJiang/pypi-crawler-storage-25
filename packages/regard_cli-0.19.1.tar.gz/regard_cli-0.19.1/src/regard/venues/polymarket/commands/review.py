"""Review commands — trades."""

from datetime import datetime, timezone
from typing import Annotated

import typer

from regard.core.output import make_table, output
from regard.venues.polymarket.client import get_clob_client
from regard.venues.polymarket.main import poly_app


@poly_app.command()
def trades(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 20,
):
    """Recent trade history."""
    opts = ctx.obj
    clob = get_clob_client()

    try:
        resp = clob.get_trades()
        trade_list = resp if isinstance(resp, list) else []
    except Exception:
        trade_list = []

    # Normalize to newest-first before slicing. `get_trades()` empirically
    # returns newest-first today, so `[:limit]` was accidentally correct — but
    # a silent SDK sort-order flip would return the N OLDEST fills. Sort
    # explicitly to make the contract robust regardless of upstream order.
    try:
        trade_list = sorted(
            trade_list,
            key=lambda t: int(t.get("match_time", "0") or "0"),
            reverse=True,
        )
    except (ValueError, TypeError):
        pass  # Malformed match_time — keep upstream order rather than raise.

    result = []
    for t in trade_list[:limit]:
        # Compute fee from rate: price * size * fee_rate_bps / 10000
        try:
            fee = str(round(
                float(t.get("price", 0)) * float(t.get("size", 0))
                * float(t.get("fee_rate_bps", 0)) / 10000, 6
            ))
        except (ValueError, TypeError):
            fee = "0"

        # Convert Unix epoch match_time to ISO 8601
        match_time = t.get("match_time", "")
        try:
            created_at = datetime.fromtimestamp(
                int(match_time), tz=timezone.utc
            ).strftime("%Y-%m-%dT%H:%M:%SZ") if match_time else ""
        except (ValueError, TypeError, OSError):
            created_at = ""

        result.append({
            "trade_id": t.get("id", ""),
            "market": t.get("market", ""),
            "asset_id": t.get("asset_id", ""),
            "side": t.get("side", ""),
            "price": t.get("price", ""),
            "size": t.get("size", ""),
            "fee": fee,
            "fee_rate_bps": t.get("fee_rate_bps", ""),
            "outcome": t.get("outcome", ""),
            "status": t.get("status", ""),
            "created_at": created_at,
        })

    output(result, opts["fields"], display=_display_trades(result))


_TRADE_COLS = [
    ("market", "Market", "<"),
    ("side", "Side", "<"),
    ("outcome", "Outcome", "<"),
    ("size", "Size", ">"),
    ("price", "Price", ">"),
    ("fee", "Fee", ">"),
    ("status", "Status", "<"),
    ("created_at", "Time", "<"),
]


def _shorten(s: str, width: int = 18) -> str:
    if not s or len(s) <= width:
        return s
    return s[: width - 1] + "…"


def _display_trades(trades: list[dict]) -> str:
    if not trades:
        return "No trades"
    rows = [{**t, "market": _shorten(t.get("market", ""))} for t in trades]
    return make_table(rows, _TRADE_COLS)
