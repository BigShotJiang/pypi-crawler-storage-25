"""Project-local directory resolution — shared between auth, proposals, send log.

A regard project is any directory containing `.claude/settings.local.json`.
All runtime state (proposals, events.jsonl, send_log.jsonl) lives under
`<project>/.regard/` alongside it.

Walk-up lookup from CWD lets users run `regard` from any subdirectory of the
project (analogous to git finding `.git/`). Traversal stops BEFORE $HOME so
the global `~/.claude/` is never picked up as a project root.
"""

from pathlib import Path

from regard.core.output import die


def find_project_dir(cwd: str | None = None) -> Path | None:
    """Walk up from CWD for a dir containing `.claude/settings.local.json`.

    Returns the project root (the dir *containing* `.claude/`, not the
    `.claude/` dir itself). Stops before $HOME — reaching HOME without a
    match returns None, since `~/.claude/` is legacy global scope that
    v0.17+ doesn't treat as a project.
    """
    try:
        home = Path.home().resolve()
        cur = (Path(cwd) if cwd else Path.cwd()).resolve()
    except Exception:
        return None
    while True:
        if cur == home:
            return None
        if (cur / ".claude" / "settings.local.json").exists():
            return cur
        parent = cur.parent
        if parent == cur:
            return None
        cur = parent


def find_project_settings(cwd: str | None = None) -> Path | None:
    """Return the path to `<project>/.claude/settings.local.json`, or None."""
    project = find_project_dir(cwd)
    if project is None:
        return None
    return project / ".claude" / "settings.local.json"


def get_regard_dir(cwd: str | None = None) -> Path:
    """Return `<project>/.regard/`, creating it + `pending/` eagerly.

    Dies with NO_PROJECT_SETTINGS if no project dir is found. Eager creation
    mirrors how `regard auth` eagerly writes `.claude/settings.local.json`
    on first setup — the runtime state dir exists as soon as the CLI runs
    from a valid project.
    """
    project = find_project_dir(cwd)
    if project is None:
        die(
            "auth_error", "NO_PROJECT_SETTINGS",
            f"No project settings found. regard is project-local — looked in {Path.cwd()} and above.",
            hint="cd to the project directory where you set up auth, then re-run",
            exit_code=3,
        )
    regard_dir = project / ".regard"
    regard_dir.mkdir(parents=True, exist_ok=True)
    (regard_dir / "pending").mkdir(exist_ok=True)
    return regard_dir
