"""Append-only audit log for transfer-related events.

Logs to `<project>/.regard/send_log.jsonl` (project-local since v0.19).
Every address book mutation and send command event (proposed, approved,
executed, rejected, failed) is recorded.
"""

import json
import time

from regard.core.project_dir import get_regard_dir


def log_event(event: str, **fields) -> None:
    """Append a single audit event.

    Args:
        event: event type (e.g. "proposed", "approved", "executed", "rejected", "failed")
        **fields: arbitrary key-value pairs (command, venue, from, to, amount, etc.)
    """
    log_file = get_regard_dir() / "send_log.jsonl"
    record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event}
    record.update(fields)
    with open(log_file, "a") as f:
        f.write(json.dumps(record, separators=(",", ":")) + "\n")
