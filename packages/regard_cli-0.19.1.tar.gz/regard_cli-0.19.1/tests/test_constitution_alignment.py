"""Constitution Article IV — orchestration mock alignment with golden fixtures.

These tests enforce that conftest constants for known assets equal the golden
fixture entries by name. Regressions to hand-authored exchange shapes become
CI failures, not silent ambushes that ship to mainnet.
"""

from tests.conftest import META_AND_ASSET_CTXS, SPOT_META, load_fixture
from tests.test_act import MOCK_SPOT_META as ACT_SPOT_META
from tests.test_killswitch import SPOT_META as KILLSWITCH_SPOT_META


def test_perp_universe_entries_match_golden():
    """Every conftest perp universe entry must equal the golden fixture entry by name.

    Drift between conftest and the recorded API response means orchestration
    tests pass against impossible inputs (e.g., 50x BTC orders the real exchange
    rejects at 40x). Constitution Article IV: orchestration mock shapes for
    known assets MUST be derived from golden fixtures.
    """
    golden = load_fixture("hyperliquid", "meta_and_asset_ctxs")
    golden_by_name = {e["name"]: e for e in golden[0]["universe"]}

    for entry in META_AND_ASSET_CTXS[0]["universe"]:
        name = entry["name"]
        assert name in golden_by_name, (
            f"conftest references {name!r} but golden fixture has no such asset"
        )
        assert entry == golden_by_name[name], (
            f"conftest universe entry for {name!r} drifted from golden:\n"
            f"  conftest: {entry}\n"
            f"  golden:   {golden_by_name[name]}"
        )


def _assert_tokens_match_golden(tokens: list, source: str) -> None:
    golden = load_fixture("hyperliquid", "spot_meta")
    golden_by_name = {t["name"]: t for t in golden["tokens"]}
    for entry in tokens:
        name = entry["name"]
        assert name in golden_by_name, (
            f"{source} references spot token {name!r} but golden fixture has no such token"
        )
        assert entry == golden_by_name[name], (
            f"{source} spot token entry for {name!r} drifted from golden:\n"
            f"  {source}: {entry}\n"
            f"  golden:   {golden_by_name[name]}"
        )


def test_spot_token_entries_match_golden():
    """Every conftest spot token must equal the golden fixture entry by name.

    Token indices and decimals are exchange-determined facts. Drift between
    conftest's hand-authored values and the recorded API (e.g., HYPE at index
    1 in conftest vs 150 in mainnet) silently breaks any test exercising
    spot_user_state parsing or token resolution.
    """
    _assert_tokens_match_golden(SPOT_META["tokens"], "conftest")


def test_killswitch_spot_tokens_match_golden():
    """test_killswitch.py SPOT_META entries must equal the golden fixture by name.

    Local per-module mocks for known assets have the same drift risk as
    conftest constants (the original 0.15.0rc12 state had USDT0 at index 400
    in test_killswitch but 268 in the golden, never caught because the test
    asserted its own wrong value).
    """
    _assert_tokens_match_golden(KILLSWITCH_SPOT_META["tokens"], "test_killswitch")


def test_act_spot_tokens_match_golden():
    """test_act.py MOCK_SPOT_META entries must equal the golden fixture by name."""
    _assert_tokens_match_golden(ACT_SPOT_META["tokens"], "test_act")
