"""Proposal system tests — lifecycle CRUD, event stream, workspace dir, idempotency,
and CLI-level approve command tests.
"""

import json
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from regard.core.proposal import (
    EXECUTORS,
    SAFETY_VALIDATORS,
    approve_proposal,
    claim_proposal,
    create_proposal,
    find_approved_result,
    get_executor,
    get_workspace_dir,
    list_pending,
    read_events,
    read_proposal,
    register_executor,
    register_safety_validator,
    reject_proposal,
)
from regard.main import app


def _seed_project(path):
    """Create `.claude/settings.local.json` under path so find_project_dir() recognizes it."""
    from pathlib import Path as _Path
    p = _Path(path)
    (p / ".claude").mkdir(parents=True, exist_ok=True)
    (p / ".claude" / "settings.local.json").write_text("{}")
    return str(p)


@pytest.fixture
def workspace(tmp_path):
    """Provide a temp project dir as CWD for proposal tests.

    Seeds `.claude/settings.local.json` so the project-dir walk-up lookup
    in get_regard_dir() resolves to this tmp dir.
    """
    fake_cwd = tmp_path / "regard-computer"
    fake_cwd.mkdir(parents=True, exist_ok=True)
    return _seed_project(fake_cwd)


@pytest.fixture(autouse=True)
def _clear_executors():
    """Clear executor registry between tests."""
    EXECUTORS.clear()
    yield
    EXECUTORS.clear()


# ---------------------------------------------------------------------------
# Workspace directory
# ---------------------------------------------------------------------------


class TestWorkspaceDir:
    def test_creates_dirs(self, workspace):
        ws = get_workspace_dir(workspace)
        assert ws.exists()
        assert (ws / "pending").exists()
        assert (ws / "pending").is_dir()

    def test_is_dot_regard_in_project(self, workspace):
        """Workspace is `<project>/.regard/`, not a hashed global path."""
        ws = get_workspace_dir(workspace)
        assert ws.name == ".regard"
        assert ws.parent == get_workspace_dir(workspace).parent
        assert (ws.parent / ".claude" / "settings.local.json").exists()

    def test_deterministic(self, workspace):
        ws1 = get_workspace_dir(workspace)
        ws2 = get_workspace_dir(workspace)
        assert ws1 == ws2

    def test_different_projects_different_dirs(self, tmp_path):
        a = _seed_project(tmp_path / "project-a")
        b = _seed_project(tmp_path / "project-b")
        assert get_workspace_dir(a) != get_workspace_dir(b)

    def test_idempotent_mkdir(self, workspace):
        ws1 = get_workspace_dir(workspace)
        ws2 = get_workspace_dir(workspace)
        assert ws1 == ws2
        assert ws1.exists()

    @pytest.mark.no_project_seed
    def test_dies_when_no_project(self, tmp_path, monkeypatch):
        """No `.claude/settings.local.json` anywhere up the tree → NO_PROJECT_SETTINGS."""
        orphan = tmp_path / "no-project-here"
        orphan.mkdir()
        # Stop walk-up before filesystem root (tmp_path is outside $HOME)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        with pytest.raises(SystemExit):
            get_workspace_dir(str(orphan))


# ---------------------------------------------------------------------------
# Proposal lifecycle: create → read → approve
# ---------------------------------------------------------------------------


class TestProposalLifecycle:
    def test_create_returns_proposal(self, workspace):
        p = create_proposal("hl", "order", {"asset": "BTC"}, {"mark_price": "69000"}, [], cwd=workspace)
        assert p["id"].startswith("p_")
        assert len(p["id"]) == 14  # p_ + 12 hex
        assert p["venue"] == "hl"
        assert p["command"] == "order"
        assert p["status"] == "pending"
        assert p["params"] == {"asset": "BTC"}
        assert p["checks"] == {"mark_price": "69000"}
        assert p["warnings"] == []
        assert "created_at" in p

    def test_create_writes_pending_file(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        ws = get_workspace_dir(workspace)
        pending_path = ws / "pending" / f"{p['id']}.json"
        assert pending_path.exists()
        stored = json.loads(pending_path.read_text())
        assert stored["id"] == p["id"]

    def test_create_appends_proposed_event(self, workspace):
        p = create_proposal("hl", "order", {"asset": "BTC"}, {}, ["SIZE_WARNING"], cwd=workspace)
        events = read_events(cwd=workspace)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "proposed"
        assert e["id"] == p["id"]
        assert e["venue"] == "hl"
        assert e["command"] == "order"
        assert e["params"] == {"asset": "BTC"}
        assert e["warnings"] == ["SIZE_WARNING"]

    def test_read_existing_proposal(self, workspace):
        p = create_proposal("hl", "cancel", {"oid": 123}, {}, [], cwd=workspace)
        read = read_proposal(p["id"], cwd=workspace)
        assert read is not None
        assert read["id"] == p["id"]
        assert read["command"] == "cancel"

    def test_read_nonexistent_returns_none(self, workspace):
        assert read_proposal("p_000000000000", cwd=workspace) is None

    def test_approve_deletes_pending(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], {"status": "filled", "oid": 42}, cwd=workspace)
        assert read_proposal(p["id"], cwd=workspace) is None

    def test_approve_appends_event(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], {"status": "filled"}, cwd=workspace)
        events = read_events(cwd=workspace)
        assert len(events) == 2  # proposed + approved
        approved = events[1]
        assert approved["event"] == "approved"
        assert approved["id"] == p["id"]
        assert approved["result"] == {"status": "filled"}

    def test_reject_deletes_pending(self, workspace):
        p = create_proposal("hl", "order", {}, {"mark_price": "69000"}, [], cwd=workspace)
        reject_proposal(p["id"], "price_delta", cwd=workspace, delta="2.3%")
        assert read_proposal(p["id"], cwd=workspace) is None

    def test_reject_appends_event_with_extras(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        reject_proposal(p["id"], "price_delta", cwd=workspace, delta="2.3%", old_price="69000", new_price="70587")
        events = read_events(cwd=workspace)
        rejected = events[1]
        assert rejected["event"] == "rejected"
        assert rejected["reason"] == "price_delta"
        assert rejected["delta"] == "2.3%"
        assert rejected["old_price"] == "69000"
        assert rejected["new_price"] == "70587"


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


class TestIdempotency:
    def test_find_approved_result(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        result = {"status": "filled", "oid": 42}
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], result, cwd=workspace)
        cached = find_approved_result(p["id"], cwd=workspace)
        assert cached == result

    def test_find_approved_result_not_approved(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        assert find_approved_result(p["id"], cwd=workspace) is None

    def test_find_approved_result_rejected(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        reject_proposal(p["id"], "user_cancelled", cwd=workspace)
        assert find_approved_result(p["id"], cwd=workspace) is None

    def test_find_among_multiple(self, workspace):
        p1 = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        p2 = create_proposal("hl", "cancel", {}, {}, [], cwd=workspace)
        claim_proposal(p1["id"], cwd=workspace)
        approve_proposal(p1["id"], {"oid": 1}, cwd=workspace)
        reject_proposal(p2["id"], "changed_mind", cwd=workspace)
        assert find_approved_result(p1["id"], cwd=workspace) == {"oid": 1}
        assert find_approved_result(p2["id"], cwd=workspace) is None


# ---------------------------------------------------------------------------
# list_pending
# ---------------------------------------------------------------------------


class TestListPending:
    def test_empty(self, workspace):
        assert list_pending(cwd=workspace) == []

    def test_lists_created_proposals(self, workspace):
        create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        create_proposal("hl", "stop", {}, {}, [], cwd=workspace)
        pending = list_pending(cwd=workspace)
        assert len(pending) == 2
        commands = {p["command"] for p in pending}
        assert commands == {"order", "stop"}

    def test_excludes_approved(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        create_proposal("hl", "stop", {}, {}, [], cwd=workspace)
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], {}, cwd=workspace)
        pending = list_pending(cwd=workspace)
        assert len(pending) == 1
        assert pending[0]["command"] == "stop"

    def test_excludes_rejected(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        reject_proposal(p["id"], "test", cwd=workspace)
        assert list_pending(cwd=workspace) == []


# ---------------------------------------------------------------------------
# Stale pending TTL
# ---------------------------------------------------------------------------


class TestPendingTTL:
    """Pending proposals auto-reject after _PENDING_TTL_HOURS."""

    def _age_proposal(self, workspace: str, proposal_id: str, hours: int) -> None:
        """Rewrite a pending file with an older `created_at` to simulate age."""
        from datetime import datetime, timedelta, timezone
        ws = get_workspace_dir(workspace)
        path = ws / "pending" / f"{proposal_id}.json"
        data = json.loads(path.read_text())
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%SZ")
        data["created_at"] = old_ts
        path.write_text(json.dumps(data, separators=(",", ":")))

    def test_list_pending_expires_stale(self, workspace):
        """list_pending() auto-rejects proposals older than 24h."""
        p_stale = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        p_fresh = create_proposal("hl", "cancel", {}, {}, [], cwd=workspace)
        self._age_proposal(workspace, p_stale["id"], hours=25)

        pending = list_pending(cwd=workspace)
        assert len(pending) == 1
        assert pending[0]["id"] == p_fresh["id"]

        # The stale proposal is rejected with reason expired_ttl
        events = read_events(cwd=workspace)
        rejections = [e for e in events if e["event"] == "rejected"]
        assert len(rejections) == 1
        assert rejections[0]["id"] == p_stale["id"]
        assert rejections[0]["reason"] == "expired_ttl"

        # Pending file is gone
        ws = get_workspace_dir(workspace)
        assert not (ws / "pending" / f"{p_stale['id']}.json").exists()

    def test_read_proposal_returns_none_for_stale(self, workspace):
        """read_proposal() returns None (and auto-rejects) for stale pending files."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        self._age_proposal(workspace, p["id"], hours=25)

        assert read_proposal(p["id"], cwd=workspace) is None
        events = read_events(cwd=workspace)
        rejections = [e for e in events if e["event"] == "rejected"]
        assert len(rejections) == 1
        assert rejections[0]["reason"] == "expired_ttl"

    def test_fresh_proposals_unaffected(self, workspace):
        """Proposals under 24h old are not expired."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        self._age_proposal(workspace, p["id"], hours=23)

        pending = list_pending(cwd=workspace)
        assert len(pending) == 1
        assert read_proposal(p["id"], cwd=workspace) is not None

    def test_boundary_24h(self, workspace):
        """At exactly 24h the proposal is expired (>= TTL)."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        self._age_proposal(workspace, p["id"], hours=24)

        assert list_pending(cwd=workspace) == []


# ---------------------------------------------------------------------------
# Event stream integrity
# ---------------------------------------------------------------------------


class TestEventStream:
    def test_events_in_order(self, workspace):
        p1 = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        p2 = create_proposal("hl", "cancel", {}, {}, [], cwd=workspace)
        claim_proposal(p1["id"], cwd=workspace)
        approve_proposal(p1["id"], {"oid": 1}, cwd=workspace)
        reject_proposal(p2["id"], "test", cwd=workspace)

        events = read_events(cwd=workspace)
        assert len(events) == 4
        assert [e["event"] for e in events] == ["proposed", "proposed", "approved", "rejected"]
        assert events[0]["id"] == p1["id"]
        assert events[1]["id"] == p2["id"]
        assert events[2]["id"] == p1["id"]
        assert events[3]["id"] == p2["id"]

    def test_events_are_valid_json(self, workspace):
        create_proposal("hl", "order", {"key": "value"}, {}, [], cwd=workspace)
        ws = get_workspace_dir(workspace)
        raw = (ws / "events.jsonl").read_text()
        for line in raw.strip().splitlines():
            json.loads(line)  # must not raise

    def test_empty_event_stream(self, workspace):
        assert read_events(cwd=workspace) == []

    def test_events_have_timestamps(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], {}, cwd=workspace)
        events = read_events(cwd=workspace)
        for e in events:
            assert "ts" in e
            assert e["ts"].endswith("Z")


# ---------------------------------------------------------------------------
# Executor registry
# ---------------------------------------------------------------------------


class TestExecutorRegistry:
    def test_register_and_get(self):
        def fake_order(params):
            return {"status": "filled"}
        register_executor("hl", "order", fake_order)
        assert get_executor("hl", "order") is fake_order

    def test_get_unregistered_returns_none(self):
        assert get_executor("hl", "order") is None

    def test_multiple_registrations(self):
        fn1 = lambda p: "order"
        fn2 = lambda p: "cancel"
        register_executor("hl", "order", fn1)
        register_executor("hl", "cancel", fn2)
        assert get_executor("hl", "order") is fn1
        assert get_executor("hl", "cancel") is fn2

    def test_overwrite(self):
        fn1 = lambda p: "v1"
        fn2 = lambda p: "v2"
        register_executor("hl", "order", fn1)
        register_executor("hl", "order", fn2)
        assert get_executor("hl", "order") is fn2


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_approve_nonexistent_still_logs_event(self, workspace):
        """Approving a non-existent proposal still appends the event (for recovery)."""
        approve_proposal("p_000000000000", {"recovered": True}, cwd=workspace)
        events = read_events(cwd=workspace)
        assert len(events) == 1
        assert events[0]["event"] == "approved"

    def test_reject_nonexistent_still_logs_event(self, workspace):
        reject_proposal("p_000000000000", "manual_cleanup", cwd=workspace)
        events = read_events(cwd=workspace)
        assert len(events) == 1
        assert events[0]["event"] == "rejected"

    def test_proposal_ids_are_unique(self, workspace):
        from unittest.mock import patch
        ids = set()
        with patch("regard.core.proposal._check_rate_limit"):
            for _ in range(100):
                p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
                ids.add(p["id"])
        assert len(ids) == 100

    def test_params_and_checks_are_freeform(self, workspace):
        """params/checks can be anything — no schema at proposal level."""
        p = create_proposal(
            "hl", "order",
            {"asset": "BTC", "size": "0.1", "nested": {"deep": True}},
            {"mark_price": "69000", "custom": [1, 2, 3]},
            [{"code": "WARN", "message": "test"}],
            cwd=workspace,
        )
        read = read_proposal(p["id"], cwd=workspace)
        assert read is not None
        assert read["params"]["nested"]["deep"] is True
        assert read["checks"]["custom"] == [1, 2, 3]
        assert read["warnings"][0]["code"] == "WARN"

    def test_multiple_venues(self, workspace):
        """Proposals from different venues coexist in the same workspace."""
        p1 = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        p2 = create_proposal("poly", "order", {}, {}, [], cwd=workspace)
        pending = list_pending(cwd=workspace)
        assert len(pending) == 2
        venues = {p["venue"] for p in pending}
        assert venues == {"hl", "poly"}


# ---------------------------------------------------------------------------
# Security + safety fixes (peer review findings)
# ---------------------------------------------------------------------------


class TestPathTraversal:
    """Proposal IDs must be validated to prevent path traversal."""

    def test_read_rejects_traversal(self, workspace):
        with pytest.raises(ValueError, match="Invalid proposal ID"):
            read_proposal("../../etc/passwd", cwd=workspace)

    def test_read_rejects_slashes(self, workspace):
        with pytest.raises(ValueError, match="Invalid proposal ID"):
            read_proposal("p_abc/../../x", cwd=workspace)

    def test_approve_rejects_traversal(self, workspace):
        with pytest.raises(ValueError, match="Invalid proposal ID"):
            approve_proposal("../evil", {}, cwd=workspace)

    def test_reject_rejects_traversal(self, workspace):
        with pytest.raises(ValueError, match="Invalid proposal ID"):
            reject_proposal("p_../../bad", "test", cwd=workspace)

    def test_valid_id_passes(self, workspace):
        """A properly formatted ID does not raise."""
        read_proposal("p_abcdef012345", cwd=workspace)  # returns None, no error


class TestAtomicClaim:
    """claim_proposal uses atomic rename to prevent double-execution."""

    def test_claim_removes_pending(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        assert claim_proposal(p["id"], cwd=workspace) is True
        assert read_proposal(p["id"], cwd=workspace) is None

    def test_claim_twice_second_fails(self, workspace):
        """Only one claim succeeds — second returns False."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        assert claim_proposal(p["id"], cwd=workspace) is True
        assert claim_proposal(p["id"], cwd=workspace) is False

    def test_claim_nonexistent_returns_false(self, workspace):
        assert claim_proposal("p_000000000000", cwd=workspace) is False

    def test_no_claiming_file_left_behind(self, workspace):
        """The .claiming temp file is cleaned up after claim."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        ws = get_workspace_dir(workspace)
        claim_proposal(p["id"], cwd=workspace)
        claiming_files = list((ws / "pending").glob("*.claiming"))
        assert claiming_files == []

    def test_claim_then_approve_logs_event(self, workspace):
        """Full flow: claim → execute → approve_proposal logs event."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        claim_proposal(p["id"], cwd=workspace)
        approve_proposal(p["id"], {"oid": 42}, cwd=workspace)
        events = read_events(cwd=workspace)
        approved = [e for e in events if e["event"] == "approved"]
        assert len(approved) == 1
        assert approved[0]["result"] == {"oid": 42}


class TestLogThenAct:
    """Event stream is written before pending file mutation."""

    def test_create_event_before_pending(self, workspace):
        """proposed event exists even if we could read it before pending file."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        events = read_events(cwd=workspace)
        assert len(events) == 1
        assert events[0]["event"] == "proposed"
        assert events[0]["id"] == p["id"]

    def test_reject_event_before_unlink(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        reject_proposal(p["id"], "test", cwd=workspace)
        events = read_events(cwd=workspace)
        assert events[-1]["event"] == "rejected"
        # pending file is gone
        assert read_proposal(p["id"], cwd=workspace) is None


class TestReservedKeyFilter:
    """reject_proposal must not allow extra kwargs to overwrite audit fields."""

    def test_reserved_keys_dropped(self, workspace):
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        reject_proposal(p["id"], "price_delta", cwd=workspace,
                        event="approved", id="p_ddd000000000", ts="1970-01-01T00:00:00Z",
                        delta="2.3%")
        events = read_events(cwd=workspace)
        rejected = [e for e in events if e["event"] == "rejected"]
        assert len(rejected) == 1
        e = rejected[0]
        # Core fields preserved
        assert e["event"] == "rejected"  # not "approved"
        assert e["id"] == p["id"]  # not "p_ddd000000000"
        assert e["ts"] != "1970-01-01T00:00:00Z"
        # Safe extra passed through
        assert e["delta"] == "2.3%"

    def test_reason_cannot_be_overridden_via_extra(self, workspace):
        """Python prevents reason= in **extra since it's a named param — verify at language level."""
        p = create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        with pytest.raises(TypeError, match="multiple values"):
            reject_proposal(p["id"], "price_delta", cwd=workspace, reason="hijack")


# ---------------------------------------------------------------------------
# CLI-level approve command tests (via CliRunner)
# ---------------------------------------------------------------------------


def _parse(result) -> dict:
    """Parse CliRunner stdout as JSON."""
    stdout = result.stdout.strip() if result.stdout else ""
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Non-JSON stdout (exit={result.exit_code}): {stdout!r}")


class TestApproveCommand:
    """Test `regard approve <id>` via CliRunner."""

    def test_happy_path(self, workspace, monkeypatch):
        """Create proposal, register executor, approve → get execution result."""
        monkeypatch.chdir(workspace)
        runner = CliRunner()
        p = create_proposal("hl", "order", {"asset": "BTC", "side": "buy", "size": "0.1"}, {}, [], cwd=workspace)
        execution_result = {"status": "filled", "oid": 200001, "asset": "BTC", "avg_price": "69666.0"}

        def fake_executor(params):
            return execution_result

        register_executor("hl", "order", fake_executor)
        with patch("regard.core.proposal.read_proposal", side_effect=lambda pid, **kw: read_proposal(pid, cwd=workspace)), \
             patch("regard.core.proposal.find_approved_result", side_effect=lambda pid, **kw: find_approved_result(pid, cwd=workspace)), \
             patch("regard.core.proposal.claim_proposal", side_effect=lambda pid, **kw: claim_proposal(pid, cwd=workspace)), \
             patch("regard.core.proposal.approve_proposal", side_effect=lambda pid, res, **kw: approve_proposal(pid, res, cwd=workspace)):
            result = runner.invoke(app, ["approve", p["id"]])

        data = _parse(result)
        assert data["ok"] is True
        assert data["data"]["status"] == "filled"
        assert data["data"]["oid"] == 200001

    def test_unknown_id(self, workspace):
        """Approving a non-existent proposal returns structured error."""
        runner = CliRunner()
        with patch("regard.core.proposal.read_proposal", return_value=None), \
             patch("regard.core.proposal.find_approved_result", return_value=None):
            result = runner.invoke(app, ["approve", "p_000000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "PROPOSAL_NOT_FOUND"

    def test_idempotency(self):
        """Approving an already-approved proposal returns cached result."""
        runner = CliRunner()
        cached_result = {"status": "filled", "oid": 42}
        with patch("regard.core.proposal.find_approved_result", return_value=cached_result):
            result = runner.invoke(app, ["approve", "p_aaa000000000"])

        data = _parse(result)
        assert data["ok"] is True
        assert data["data"]["status"] == "already_approved"
        assert data["data"]["result"] == cached_result

    def test_no_executor(self):
        """Approving with no executor registered returns internal error."""
        runner = CliRunner()
        proposal = {"id": "p_bbb000000000", "venue": "hl", "command": "order",
                     "params": {}, "checks": {}, "warnings": [], "status": "pending"}
        with patch("regard.core.proposal.read_proposal", return_value=proposal), \
             patch("regard.core.proposal.find_approved_result", return_value=None), \
             patch("regard.core.proposal.get_executor", return_value=None):
            result = runner.invoke(app, ["approve", "p_bbb000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "NO_EXECUTOR"

    def test_execution_failure(self, workspace, monkeypatch):
        """Executor raises → venue error with execution_state."""
        monkeypatch.chdir(workspace)
        runner = CliRunner()
        proposal = {"id": "p_bbb000000000", "venue": "hl", "command": "order",
                     "params": {"asset": "BTC"}, "checks": {}, "warnings": [], "status": "pending"}

        def failing_executor(params):
            raise RuntimeError("exchange unavailable")

        with patch("regard.core.proposal.read_proposal", return_value=proposal), \
             patch("regard.core.proposal.find_approved_result", return_value=None), \
             patch("regard.core.proposal.get_executor", return_value=failing_executor), \
             patch("regard.core.proposal.claim_proposal", return_value=True):
            result = runner.invoke(app, ["approve", "p_bbb000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "EXECUTION_FAILED"
        assert data["error"]["execution_state"] == "unknown"

    def test_price_delta_rejection(self):
        """Price moved beyond threshold → reject + structured error."""
        runner = CliRunner()
        proposal = {"id": "p_ccc000000000", "venue": "hl", "command": "order",
                     "params": {"asset": "BTC"}, "checks": {"mark_price": "69000"},
                     "warnings": [], "status": "pending"}

        with patch("regard.core.proposal.read_proposal", return_value=proposal), \
             patch("regard.core.proposal.find_approved_result", return_value=None), \
             patch("regard.main._fetch_current_price", return_value="70000"), \
             patch("regard.core.proposal.reject_proposal") as mock_reject:
            result = runner.invoke(app, ["approve", "p_ccc000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "PRICE_DELTA_EXCEEDED"
        assert "old_price" in data["error"]
        assert "new_price" in data["error"]
        mock_reject.assert_called_once()

    def test_price_delta_within_threshold(self, workspace, monkeypatch):
        """Price within threshold → proceed to execute."""
        monkeypatch.chdir(workspace)
        runner = CliRunner()
        p = create_proposal("hl", "order", {"asset": "BTC"}, {"mark_price": "69000"}, [], cwd=workspace)
        execution_result = {"status": "filled", "oid": 99}

        def ok_executor(params):
            return execution_result

        register_executor("hl", "order", ok_executor)
        with patch("regard.core.proposal.read_proposal", side_effect=lambda pid, **kw: read_proposal(pid, cwd=workspace)), \
             patch("regard.core.proposal.find_approved_result", side_effect=lambda pid, **kw: find_approved_result(pid, cwd=workspace)), \
             patch("regard.core.proposal.claim_proposal", side_effect=lambda pid, **kw: claim_proposal(pid, cwd=workspace)), \
             patch("regard.core.proposal.approve_proposal", side_effect=lambda pid, res, **kw: approve_proposal(pid, res, cwd=workspace)), \
             patch("regard.main._fetch_current_price", return_value="69100"):
            result = runner.invoke(app, ["approve", p["id"]])

        data = _parse(result)
        assert data["ok"] is True
        assert data["data"]["status"] == "filled"

    def test_approve_produces_valid_json_envelope(self):
        """Contract: approve always produces valid JSON with ok/data/meta or ok/error."""
        runner = CliRunner()
        # Error path
        with patch("regard.core.proposal.read_proposal", return_value=None), \
             patch("regard.core.proposal.find_approved_result", return_value=None):
            result = runner.invoke(app, ["approve", "p_000000000000"])
        data = _parse(result)
        assert "ok" in data
        assert data["ok"] is False
        assert "error" in data

    def test_invalid_proposal_id_produces_json(self):
        """Malformed proposal ID returns JSON error, not traceback."""
        runner = CliRunner()
        result = runner.invoke(app, ["approve", "../evil"])
        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "INVALID_PROPOSAL_ID"

    def test_schema_includes_approve(self):
        """The approve command should appear in `regard schema` output."""
        runner = CliRunner()
        result = runner.invoke(app, ["schema"])
        data = _parse(result)
        names = [c["name"] for c in data["data"]["commands"]]
        assert "approve" in names
        approve_cmd = [c for c in data["data"]["commands"] if c["name"] == "approve"][0]
        assert approve_cmd["class"] == "human-only"


class TestRateLimit:
    """Rate limit tests — Constitution Article II."""

    def test_proposal_rate_limit(self, workspace):
        """Creating more than 10 proposals in 5 minutes dies."""
        from regard.core.proposal import _RATE_LIMIT
        for i in range(_RATE_LIMIT):
            create_proposal("hl", "order", {"i": i}, {}, [], cwd=workspace)
        with pytest.raises(SystemExit) as exc_info:
            create_proposal("hl", "order", {"i": "overflow"}, {}, [], cwd=workspace)
        assert exc_info.value.code == 5

    def test_rate_limit_error_message(self, workspace, capsys):
        """Rate limit error has retryable flag and descriptive message."""
        from regard.core.proposal import _RATE_LIMIT
        for i in range(_RATE_LIMIT):
            create_proposal("hl", "order", {"i": i}, {}, [], cwd=workspace)
        with pytest.raises(SystemExit):
            create_proposal("hl", "order", {}, {}, [], cwd=workspace)
        output = json.loads(capsys.readouterr().out)
        assert output["ok"] is False
        assert output["error"]["code"] == "PROPOSAL_RATE_EXCEEDED"
        assert output["error"]["retryable"] is True

    def test_execution_rate_limit_mechanism(self, workspace):
        """Execution rate limit mechanism fires after too many approvals."""
        from datetime import datetime, timezone

        from regard.core.proposal import _RATE_LIMIT, _append_event, _check_rate_limit, get_workspace_dir

        ws = get_workspace_dir(workspace)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for i in range(_RATE_LIMIT):
            _append_event(ws, {"event": "approved", "id": f"p_{i:012d}", "ts": ts, "result": {}})

        with pytest.raises(SystemExit) as exc_info:
            _check_rate_limit(ws, "approved", "EXECUTION_RATE_EXCEEDED")
        assert exc_info.value.code == 5

    def test_execution_rate_limit_wired_in_approve(self, workspace):
        """Integration: approve command fires execution rate limit before claiming."""
        from datetime import datetime, timezone

        from regard.core.proposal import _RATE_LIMIT, _append_event, get_workspace_dir

        runner = CliRunner()
        ws = get_workspace_dir(workspace)

        # Seed enough approved events to trip the limit
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for i in range(_RATE_LIMIT):
            _append_event(ws, {"event": "approved", "id": f"p_{i:012d}", "ts": ts, "result": {}})

        # Create a real pending proposal
        p = create_proposal("hl", "order", {"asset": "BTC"}, {}, [], cwd=workspace)

        def ok_executor(params):
            return {"status": "filled"}

        register_executor("hl", "order", ok_executor)
        with patch("regard.core.proposal.read_proposal", side_effect=lambda pid, **kw: read_proposal(pid, cwd=workspace)), \
             patch("regard.core.proposal.find_approved_result", side_effect=lambda pid, **kw: find_approved_result(pid, cwd=workspace)), \
             patch("regard.core.proposal.get_workspace_dir", return_value=ws):
            result = runner.invoke(app, ["approve", p["id"]])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "EXECUTION_RATE_EXCEEDED"

        # Proposal should still exist (not consumed by claim)
        assert read_proposal(p["id"], cwd=workspace) is not None

    def test_safety_validator_preserves_proposal(self, workspace, monkeypatch):
        """Pre-claim safety validator fires → pending file survives, retry works."""
        from regard.core.output import die
        monkeypatch.chdir(workspace)

        runner = CliRunner()
        p = create_proposal("hl", "order", {"asset": "BTC"}, {}, [], cwd=workspace)

        def strict_validator(params):
            die("validation_error", "SENDER_MISMATCH", "wrong key for this proposal")

        def ok_executor(params):
            return {"status": "filled"}

        register_safety_validator("hl", "order", strict_validator)
        register_executor("hl", "order", ok_executor)
        try:
            with patch("regard.core.proposal.read_proposal", side_effect=lambda pid, **kw: read_proposal(pid, cwd=workspace)), \
                 patch("regard.core.proposal.find_approved_result", side_effect=lambda pid, **kw: find_approved_result(pid, cwd=workspace)), \
                 patch("regard.core.proposal.claim_proposal", side_effect=lambda pid, **kw: claim_proposal(pid, cwd=workspace)):
                result = runner.invoke(app, ["approve", p["id"]])
        finally:
            SAFETY_VALIDATORS.pop(("hl", "order"), None)

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "SENDER_MISMATCH"

        # The proposal must survive so the user can fix the env and retry
        assert read_proposal(p["id"], cwd=workspace) is not None


class TestPriceFetchFailClosed:
    """Price fetch fail-closed — Constitution Article II."""

    def test_price_fetch_none_dies(self):
        """When _fetch_current_price returns None, approve dies."""
        runner = CliRunner()
        proposal = {"id": "p_ddd000000000", "venue": "hl", "command": "order",
                     "params": {"asset": "BTC"}, "checks": {"mark_price": "69000"},
                     "warnings": [], "status": "pending"}

        with patch("regard.core.proposal.read_proposal", return_value=proposal), \
             patch("regard.core.proposal.find_approved_result", return_value=None), \
             patch("regard.main._fetch_current_price", return_value=None):
            result = runner.invoke(app, ["approve", "p_ddd000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "PRICE_FETCH_FAILED"
        assert data["error"]["retryable"] is True
        assert data["error"]["execution_state"] == "not_executed"

    def test_non_numeric_price_dies(self):
        """When current price is non-numeric, approve dies with PRICE_CHECK_FAILED."""
        runner = CliRunner()
        proposal = {"id": "p_eee000000000", "venue": "hl", "command": "order",
                     "params": {"asset": "BTC"}, "checks": {"mark_price": "69000"},
                     "warnings": [], "status": "pending"}

        with patch("regard.core.proposal.read_proposal", return_value=proposal), \
             patch("regard.core.proposal.find_approved_result", return_value=None), \
             patch("regard.main._fetch_current_price", return_value="N/A"):
            result = runner.invoke(app, ["approve", "p_eee000000000"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "PRICE_CHECK_FAILED"
        assert data["error"]["execution_state"] == "not_executed"
