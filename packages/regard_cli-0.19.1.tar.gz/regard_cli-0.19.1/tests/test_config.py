"""Tests for regard config command."""

import json
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


def test_config_show_default():
    """config show returns default polygon_rpc when no override set."""
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://rpc.regard.computer/regard/evm/137"
    assert rpc["source"] == "default"
    assert rpc["default"] == rpc["current"]


def test_config_show_custom(tmp_path, monkeypatch):
    """config show reflects POLYGON_RPC from project-local settings file."""
    # Use distinct HOME and CWD so the settings walk-up doesn't stop at HOME
    # before reaching our project dir.
    project = tmp_path / "project"
    project.mkdir()
    settings = project / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"POLYGON_RPC": "https://custom-rpc.example.com"}}))
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://custom-rpc.example.com"
    assert rpc["source"] == "settings"
    assert rpc["default"] == "https://rpc.regard.computer/regard/evm/137"


# ---------------------------------------------------------------------------
# `regard config set` — writes project-local settings
# ---------------------------------------------------------------------------


def _project_env(path):
    """Parse the env block from a settings.local.json file."""
    return json.loads(path.read_text()).get("env", {})


class TestConfigSetKillswitchAddress:
    def test_valid_address_written(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        addr = "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"
        result = runner.invoke(app, ["config", "set", "killswitch-address", addr])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["ok"] is True
        assert data["data"]["value"] == addr

        settings_path = project / ".claude" / "settings.local.json"
        assert _project_env(settings_path)["KILLSWITCH_ADDRESS"] == addr

    def test_invalid_address_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-address", "0xbadbad"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_ADDRESS"
        # File should NOT exist — we validate before touching disk
        assert not (project / ".claude" / "settings.local.json").exists()

    def test_rejects_same_as_trading_wallet(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        trading_addr = "0x1234567890abcdef1234567890abcdef12345678"
        # Seed a trading key so _trading_address() resolves to trading_addr
        mock_account = MagicMock(address=trading_addr)
        with patch("eth_account.Account.from_key", return_value=mock_account):
            with patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64}):
                result = runner.invoke(app, ["config", "set", "killswitch-address", trading_addr])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "SAME_AS_TRADING_WALLET"


class TestConfigSetSlippage:
    def test_valid_slippage(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "0.15"])
        assert result.exit_code == 0
        settings_path = project / ".claude" / "settings.local.json"
        assert _project_env(settings_path)["KILLSWITCH_SLIPPAGE"] == "0.15"

    def test_out_of_range(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "1.5"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_SLIPPAGE"

    def test_non_numeric(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "abc"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_SLIPPAGE"


class TestConfigSetUrl:
    def test_polygon_rpc(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "polygon-rpc", "https://my-rpc.example.com"])
        assert result.exit_code == 0
        settings_path = project / ".claude" / "settings.local.json"
        assert _project_env(settings_path)["POLYGON_RPC"] == "https://my-rpc.example.com"

    def test_rejects_non_url(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "polygon-rpc", "not-a-url"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_URL"


class TestConfigSetUnknownKey:
    def test_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "mystery-setting", "value"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "UNKNOWN_SETTING"
        # Error should list valid keys
        assert "killswitch-address" in envelope["error"]["message"]


class TestConfigSetPreservesOtherEntries:
    def test_merges_without_clobbering(self, tmp_path, monkeypatch):
        """Writing KILLSWITCH_ADDRESS must not wipe other env or top-level keys."""
        project = tmp_path / "project"
        project.mkdir()
        settings_path = project / ".claude" / "settings.local.json"
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({
            "permissions": {"allow": ["Bash(ls)"]},
            "env": {
                "HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64,
                "POLYMARKET_PRIVATE_KEY": "0x" + "a" * 64,
                "UNRELATED_VAR": "keep",
            },
        }))

        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(
            app,
            ["config", "set", "killswitch-address", "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"],
        )
        assert result.exit_code == 0

        data = json.loads(settings_path.read_text())
        assert data["permissions"]["allow"] == ["Bash(ls)"]
        assert data["env"]["HYPERLIQUID_PRIVATE_KEY"] == "0x" + "a" * 64
        assert data["env"]["POLYMARKET_PRIVATE_KEY"] == "0x" + "a" * 64
        assert data["env"]["UNRELATED_VAR"] == "keep"
        assert data["env"]["KILLSWITCH_ADDRESS"] == "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"
