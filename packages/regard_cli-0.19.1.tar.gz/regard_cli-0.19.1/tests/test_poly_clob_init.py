"""Tests for `get_clob_client` L2-auth handshake.

Surfaced during bonbonki onboarding: a wallet that has never traded on
Polymarket gets a 400 from `/auth/derive-api-key` ("Could not derive api key!")
because `deriveApiKey` only works for wallets that already have credentials.
The SDK's `create_or_derive_api_key` tries `createApiKey` first, falling back
to derive — that's the right call for first-time wallets. We want:

1. get_clob_client() uses `create_or_derive_api_key` so first-time wallets
   get credentials created automatically.
2. The SDK's stderr noise silenced during the handshake (we're handling
   exceptions ourselves).
3. Genuine auth failures → `PolymarketNotSetUp` with a remedy that actually
   matches the cause, distinct from geo-blocks and network errors.
"""

import logging
from unittest.mock import MagicMock, patch

import pytest

# A valid hex key that eth_account will accept (for address derivation)
FAKE_KEY = "0x" + "1" + "2" * 63


def _env_with_poly_key():
    """Minimal env dict with a valid-length POLYMARKET_PRIVATE_KEY.

    `patch.dict(os.environ, ..., clear=True)` guarantees this test's env is
    isolated from shell inheritance AND from whatever state earlier tests
    may have left in place.
    """
    return {"POLYMARKET_PRIVATE_KEY": FAKE_KEY}


def test_clob_init_uses_create_or_derive(tmp_path, monkeypatch):
    """get_clob_client() calls create_or_derive_api_key (not derive-only)."""
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    from regard.venues.polymarket.client import get_clob_client

    mock_client = MagicMock()
    mock_creds = MagicMock()
    mock_client.create_or_derive_api_key.return_value = mock_creds

    with patch.dict("os.environ", _env_with_poly_key(), clear=True), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY):
        with patch("py_clob_client_v2.client.ClobClient", return_value=mock_client):
            result = get_clob_client()

    mock_client.create_or_derive_api_key.assert_called_once()
    mock_client.derive_api_key.assert_not_called()
    mock_client.set_api_creds.assert_called_once_with(mock_creds)
    assert result is mock_client


def test_clob_init_maps_not_set_up(tmp_path, monkeypatch):
    """400 'Could not derive api key' → PolymarketNotSetUp with actionable remedy."""
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    from regard.venues.polymarket.client import PolymarketNotSetUp, get_clob_client

    mock_client = MagicMock()
    mock_client.create_or_derive_api_key.side_effect = Exception("Could not derive api key!")

    with patch.dict("os.environ", _env_with_poly_key(), clear=True), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY):
        with patch("py_clob_client_v2.client.ClobClient", return_value=mock_client):
            with pytest.raises(PolymarketNotSetUp) as exc_info:
                get_clob_client()

    msg = str(exc_info.value)
    assert "could not issue L2 credentials" in msg
    # No more misattributed "run regard poly approve" remedy
    assert "regard poly approve" not in msg


def test_clob_init_maps_create_failure(tmp_path, monkeypatch):
    """400 'Could not create api key' also → PolymarketNotSetUp."""
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    from regard.venues.polymarket.client import PolymarketNotSetUp, get_clob_client

    mock_client = MagicMock()
    mock_client.create_or_derive_api_key.side_effect = Exception("Could not create api key!")

    with patch.dict("os.environ", _env_with_poly_key(), clear=True), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY):
        with patch("py_clob_client_v2.client.ClobClient", return_value=mock_client):
            with pytest.raises(PolymarketNotSetUp):
                get_clob_client()


def test_clob_init_other_errors_passthrough(tmp_path, monkeypatch):
    """Non-auth errors (geo, network, etc.) propagate as-is."""
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    from regard.venues.polymarket.client import PolymarketNotSetUp, get_clob_client

    mock_client = MagicMock()
    mock_client.create_or_derive_api_key.side_effect = Exception("403 Forbidden: geo-restricted")

    with patch.dict("os.environ", _env_with_poly_key(), clear=True), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY):
        with patch("py_clob_client_v2.client.ClobClient", return_value=mock_client):
            with pytest.raises(Exception) as exc_info:
                get_clob_client()

    # Original exception preserved, NOT wrapped as PolymarketNotSetUp
    assert not isinstance(exc_info.value, PolymarketNotSetUp)
    assert "geo-restricted" in str(exc_info.value)


def test_clob_init_silences_sdk_logger(tmp_path, monkeypatch):
    """During the auth handshake, py_clob_client_v2 logger is raised to CRITICAL.

    Ensures the [py_clob_client_v2] request error line no longer spams stderr
    when we're about to handle the failure ourselves.
    """
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    from regard.venues.polymarket.client import get_clob_client

    sdk_logger = logging.getLogger("py_clob_client_v2")
    original_level = sdk_logger.level
    observed_level_during_call = []

    mock_client = MagicMock()

    def capture_level():
        observed_level_during_call.append(sdk_logger.level)
        raise Exception("Could not derive api key!")

    mock_client.create_or_derive_api_key.side_effect = capture_level

    with patch.dict("os.environ", _env_with_poly_key(), clear=True), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY):
        with patch("py_clob_client_v2.client.ClobClient", return_value=mock_client):
            try:
                get_clob_client()
            except Exception:
                pass

    # Logger was silenced during the call...
    assert observed_level_during_call == [logging.CRITICAL]
    # ...and restored afterwards
    assert sdk_logger.level == original_level
