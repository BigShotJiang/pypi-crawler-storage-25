"""SKILL.md contract tests — verify documented commands match CLI reality.

Uses generate_schema() to introspect the live command tree instead of
parsing --help output. Per CLI Constitution Article V: "SKILL.md is validated
against the live schema — not against help-text scraping."
"""

import re
from pathlib import Path

import pytest

from regard.main import app, generate_schema

# ---------------------------------------------------------------------------
# Extract documented commands from SKILL.md
# ---------------------------------------------------------------------------

SKILL_PATH = Path(__file__).parent.parent.parent / "tabtabtabTABtab" / "regard-computer" / "skills" / "regard-computer" / "SKILL.md"


def _extract_hl_commands() -> list[str]:
    """Extract `regard hl <cmd>` examples from SKILL.md CLI reference section."""
    if not SKILL_PATH.exists():
        return []
    content = SKILL_PATH.read_text()
    pattern = r"`regard hl ([a-z][a-z0-9-]*)"
    return sorted(set(re.findall(pattern, content)))


def _extract_poly_commands() -> list[str]:
    """Extract `regard poly <cmd>` examples from SKILL.md."""
    if not SKILL_PATH.exists():
        return []
    content = SKILL_PATH.read_text()
    pattern = r"`regard poly ([a-z][a-z0-9-]*)"
    return sorted(set(re.findall(pattern, content)))


def _get_actual_commands(prefix: str) -> set[str]:
    """Get actual registered command names from the live schema."""
    schema = generate_schema(app)
    commands = set()
    for cmd in schema["commands"]:
        name = cmd["name"]
        if name.startswith(f"{prefix}."):
            rest = name[len(prefix) + 1:]
            if "." not in rest:  # only direct children
                commands.add(rest)
    return commands


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

DOCUMENTED_HL = _extract_hl_commands()
DOCUMENTED_POLY = _extract_poly_commands()


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_all_hl_commands_documented():
    """Every actual HL command must appear in SKILL.md."""
    actual = _get_actual_commands("hl")
    documented = set(DOCUMENTED_HL)
    undocumented = actual - documented
    assert not undocumented, f"HL commands exist but not in SKILL.md: {undocumented}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_all_poly_commands_documented():
    """Every actual poly command must appear in SKILL.md."""
    actual = _get_actual_commands("poly")
    documented = set(DOCUMENTED_POLY)
    undocumented = actual - documented
    assert not undocumented, f"Poly commands exist but not in SKILL.md: {undocumented}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_hl_docs():
    """Every documented HL command must still exist in the CLI."""
    actual = _get_actual_commands("hl")
    documented = set(DOCUMENTED_HL)
    stale = documented - actual
    assert not stale, f"SKILL.md references non-existent HL commands: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_poly_docs():
    """Every documented poly command must still exist in the CLI."""
    actual = _get_actual_commands("poly")
    documented = set(DOCUMENTED_POLY)
    stale = documented - actual
    assert not stale, f"SKILL.md references non-existent poly commands: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_documented_command_count():
    """Sanity check — SKILL.md should document a reasonable number of commands."""
    assert len(DOCUMENTED_HL) >= 15, f"Only {len(DOCUMENTED_HL)} HL commands documented"
    assert len(DOCUMENTED_POLY) >= 8, f"Only {len(DOCUMENTED_POLY)} poly commands documented"
