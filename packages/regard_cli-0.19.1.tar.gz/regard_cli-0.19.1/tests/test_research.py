"""Tests for research commands — assets, prices, book, funding, candles, pulse."""

import json

from regard.main import app

HIP3_PERP_DEXS = [{"name": "default"}, {"name": "xyz"}]
HIP3_ALL_PERP_METAS = [
    # default dex (index 0) — matches META_AND_ASSET_CTXS from conftest
    {"universe": [{"name": "BTC"}, {"name": "ETH"}, {"name": "SOL"}], "marginTables": [], "collateralToken": 0},
    # xyz dex
    {"universe": [{"name": "xyz:TSLA"}, {"name": "xyz:NVDA"}], "marginTables": [], "collateralToken": 0},
]
HIP3_ANNOTATIONS = [["xyz:TSLA", {"category": "stocks"}], ["xyz:NVDA", {"category": "stocks"}]]
HIP3_META_AND_ASSET_CTXS = [
    {
        "universe": [
            {"name": "TSLA", "maxLeverage": 5},
            {"name": "NVDA", "maxLeverage": 5},
        ]
    },
    [
        {
            "markPx": "250.0", "oraclePx": "250.5", "prevDayPx": "240.0",
            "funding": "0.0003", "openInterest": "1000000.00",
            "dayNtlVlm": "50000000.00", "premium": "0.0001",
        },
        {
            "markPx": "130.0", "oraclePx": "130.2", "prevDayPx": "135.0",
            "funding": "-0.0005", "openInterest": "800000.00",
            "dayNtlVlm": "30000000.00", "premium": "-0.0002",
        },
    ],
]


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestAssets:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "assets"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_search(self, runner, patched):
        result = runner.invoke(app, ["hl", "assets", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_sort_name(self, runner, patched):
        result = runner.invoke(app, ["hl", "assets", "--sort", "name"])
        assert result.exit_code == 0
        d = data(result)
        names = [a["asset"] for a in d]
        assert names == sorted(names)


class TestPrices:
    def test_all_mids(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "prices"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_specific(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "prices", "BTC"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_multiple(self, runner, patched):
        result = runner.invoke(app, ["hl", "prices", "BTC", "ETH"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 2
        assert {r["asset"] for r in d} == {"BTC", "ETH"}

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "prices", "FAKECOIN"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "UNKNOWN_ASSET"


class TestBook:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "book", "BTC"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_depth(self, runner, patched):
        result = runner.invoke(app, ["hl", "book", "BTC", "--depth", "2"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d["bids"]) == 2
        assert len(d["asks"]) == 2


class TestFunding:
    def test_current_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "funding"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_current_specific(self, runner, patched):
        result = runner.invoke(app, ["hl", "funding", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_history(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "funding", "BTC", "--history", "--limit", "3"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_history_requires_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "funding", "--history"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_ARGUMENT"


class TestCandles:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "candles", "BTC", "1h", "--limit", "2"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_invalid_interval(self, runner, patched):
        result = runner.invoke(app, ["hl", "candles", "BTC", "2d"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_INTERVAL"


class TestPulse:
    def test_basic(self, runner, patched, snapshot):
        """Pulse with default perps only (no HIP-3 dexes in mock)."""
        result = runner.invoke(app, ["hl", "pulse"])
        assert result.exit_code == 0
        d = data(result)
        assert "movers" in d
        assert "volume" in d
        assert "funding" in d
        assert "signals" in d
        assert "spot_movers" in d
        assert "spot_volume" in d
        assert d["total_assets"] == 4  # BTC, ETH, SOL + xyz:TSLA from mock
        assert d["total_spot_assets"] == 2  # HYPE/USDC, PURR/USDC from mock

    def test_top_option(self, runner, patched):
        result = runner.invoke(app, ["hl", "pulse", "--top", "1"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d["movers"]) == 1
        assert len(d["volume"]) == 1
        assert len(d["funding"]) == 1

    def test_with_hip3(self, runner, patched):
        """Pulse scans HIP-3 deployer assets when available."""
        mock_info = patched["info"]

        def mock_post(path, body):
            t = body.get("type")
            if t == "allPerpMetas":
                return HIP3_ALL_PERP_METAS
            if t == "perpConciseAnnotations":
                return HIP3_ANNOTATIONS
            if t == "metaAndAssetCtxs" and body.get("dex") == "xyz":
                return HIP3_META_AND_ASSET_CTXS
            return []

        mock_info.post.side_effect = mock_post

        result = runner.invoke(app, ["hl", "pulse"])
        assert result.exit_code == 0
        d = data(result)
        assert d["total_assets"] == 5  # 3 default + 2 HIP-3
        all_names = {a["asset"] for a in d["movers"]}
        assert "TSLA" in all_names or "NVDA" in all_names  # HIP-3 assets appear
        # HIP-3 assets should have category from annotations
        hip3_assets = [a for a in d["movers"] if a["asset"] in ("TSLA", "NVDA")]
        for a in hip3_assets:
            assert a["asset_class"] == "tradfi"
            assert a["category"] == "stocks"

    def test_signals(self, runner, patched):
        """Composite signals flag assets in 2+ top lists."""
        result = runner.invoke(app, ["hl", "pulse"])
        assert result.exit_code == 0
        d = data(result)
        # With 3 mock assets, all appear in movers + volume + funding
        # so all should be composite signals
        for sig in d["signals"]:
            assert len(sig["flags"]) >= 2
            assert "asset" in sig

    def test_spot_movers(self, runner, patched):
        """Pulse includes spot movers and volume."""
        result = runner.invoke(app, ["hl", "pulse"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d["spot_movers"]) == 2
        # Spot movers have no funding fields
        for m in d["spot_movers"]:
            assert "asset" in m
            assert "change_24h" in m
            assert "funding_rate" not in m

    def test_spot_unavailable(self, runner, patched):
        """Pulse handles spot data unavailability gracefully."""
        patched["info"].spot_meta_and_asset_ctxs.side_effect = Exception("unavailable")
        result = runner.invoke(app, ["hl", "pulse"])
        assert result.exit_code == 0
        d = data(result)
        assert d["spot_movers"] == []
        assert d["spot_volume"] == []
        assert d["total_spot_assets"] == 0
