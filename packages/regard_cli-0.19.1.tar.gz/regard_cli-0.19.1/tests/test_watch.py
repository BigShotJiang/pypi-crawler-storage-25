"""Tests for regard watch — REST-polling watchers that emit JSONL alerts.

Tests use --once mode to exercise poll logic without the loop scaffold.
Debounce state is tested by calling poll() directly through the module.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.commands.watch import _emit, watch_app
from regard.main import app


@pytest.fixture
def runner():
    return CliRunner()


def _parse_jsonl(stdout: str) -> list[dict]:
    """Parse stdout into a list of JSON events. Skips empty lines."""
    return [json.loads(line) for line in stdout.strip().splitlines() if line.strip()]


# ---------------------------------------------------------------------------
# drawdown
# ---------------------------------------------------------------------------


def _patch_drawdown(balances):
    """Patch the imports drawdown uses. `balances` = list[dict] returned by get_dex_balances."""
    patches = [
        patch("regard.commands.watch.get_info", return_value=MagicMock()),
        patch("regard.commands.watch.get_address", return_value="0xTEST"),
        patch("regard.commands.watch.get_dex_balances", return_value=balances),
    ]
    return patches


def test_drawdown_fires_alert_when_over_threshold(runner):
    patches = _patch_drawdown([{"dex": "default", "account_value": "850.00", "positions": 1}])
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "drawdown", "--baseline", "1000", "--threshold-pct", "10", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "drawdown_alert"
        assert e["watcher"] == "drawdown"
        assert e["pct"] == 15.0
        assert e["baseline"] == 1000.0
        assert e["current"] == 850.0
        assert e["threshold_pct"] == 10.0
        assert "ts" in e
    finally:
        for p in patches:
            p.stop()


def test_drawdown_silent_when_below_threshold(runner):
    patches = _patch_drawdown([{"dex": "default", "account_value": "950.00", "positions": 0}])
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "drawdown", "--baseline", "1000", "--threshold-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


def test_drawdown_validation_baseline_zero(runner):
    result = runner.invoke(app, ["watch", "drawdown", "--baseline", "0", "--threshold-pct", "10", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["ok"] is False
    assert envelope["error"]["code"] == "INVALID_BASELINE"


def test_drawdown_validation_threshold_zero(runner):
    result = runner.invoke(app, ["watch", "drawdown", "--baseline", "1000", "--threshold-pct", "0", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_THRESHOLD"


def test_drawdown_debounce_and_recovery():
    """Cross → emit once, stay triggered → no re-emit, recover → recovered event."""
    # Import the underlying function to call poll directly, bypassing the --once return
    from regard.commands import watch as watch_mod

    balances_seq = [
        [{"dex": "default", "account_value": "1000.00"}],  # start: no drawdown
        [{"dex": "default", "account_value": "800.00"}],    # cross: 20% drawdown
        [{"dex": "default", "account_value": "700.00"}],    # sustained: deeper, no re-emit
        [{"dex": "default", "account_value": "950.00"}],    # recover
    ]
    captured: list[dict] = []

    with patch.object(watch_mod, "get_info", return_value=MagicMock()), \
         patch.object(watch_mod, "get_address", return_value="0xTEST"), \
         patch.object(watch_mod, "get_dex_balances", side_effect=balances_seq), \
         patch.object(watch_mod, "_emit", side_effect=captured.append):

        # Build the poll closure the way the command does
        baseline = 1000.0
        threshold_pct = 10.0
        state = {"triggered": False}
        info = watch_mod.get_info()
        address = watch_mod.get_address()

        def poll():
            balances = watch_mod.get_dex_balances(info, address)
            if not balances:
                raise RuntimeError("no balances")
            current = sum(float(b.get("account_value", 0)) for b in balances)
            pct = (baseline - current) / baseline * 100
            if pct >= threshold_pct and not state["triggered"]:
                watch_mod._emit({"event": "drawdown_alert", "watcher": "drawdown", "pct": pct})
                state["triggered"] = True
            elif pct < threshold_pct and state["triggered"]:
                watch_mod._emit({"event": "drawdown_recovered", "watcher": "drawdown", "pct": pct})
                state["triggered"] = False

        poll()  # 1000 → no drawdown → silent
        poll()  # 800 → 20% → alert
        poll()  # 700 → 30% sustained → silent (debounced)
        poll()  # 950 → 5% → recovered

    assert [e["event"] for e in captured] == ["drawdown_alert", "drawdown_recovered"]
    assert captured[0]["pct"] == 20.0
    assert captured[1]["pct"] == 5.0


# ---------------------------------------------------------------------------
# liquidation
# ---------------------------------------------------------------------------


def _patch_liquidation(positions, mids):
    patches = [
        patch("regard.commands.watch.get_info", return_value=MagicMock()),
        patch("regard.commands.watch.get_address", return_value="0xTEST"),
        patch("regard.commands.watch.get_all_positions", return_value=positions),
        patch("regard.commands.watch.get_all_mids", return_value=mids),
    ]
    return patches


def test_liquidation_fires_for_long_near_liq(runner):
    # Long BTC at mark 100, liq 95 → proximity = 5% → alert at threshold 10%
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": "95.00"}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "liquidation_warning"
        assert e["asset"] == "BTC"
        assert e["side"] == "long"
        assert e["proximity_pct"] == 5.0
        assert e["threshold_pct"] == 10.0
    finally:
        for p in patches:
            p.stop()


def test_liquidation_fires_for_short_near_liq(runner):
    # Short ETH at mark 100, liq 108 → proximity = 8% → alert at threshold 10%
    positions = [{"coin": "ETH", "szi": "-1.0", "liquidationPx": "108.00"}]
    mids = {"ETH": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["side"] == "short"
        assert events[0]["proximity_pct"] == 8.0
    finally:
        for p in patches:
            p.stop()


def test_liquidation_silent_when_safe(runner):
    # Long BTC at mark 100, liq 50 → proximity 50% → safe under 10% threshold
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": "50.00"}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


def test_liquidation_silent_when_no_positions(runner):
    patches = _patch_liquidation([], {})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


def test_liquidation_skips_positions_without_liq_price(runner):
    # Zero liquidationPx (can happen with cross-margin zero-isolation) should be skipped.
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": ""}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


# ---------------------------------------------------------------------------
# price
# ---------------------------------------------------------------------------


def _patch_price(mids):
    patches = [
        patch("regard.commands.watch.get_info", return_value=MagicMock()),
        patch("regard.commands.watch.get_all_mids", return_value=mids),
    ]
    return patches


def test_price_fires_above(runner):
    patches = _patch_price({"BTC": "96000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "BTC", "--above", "95000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "price_cross"
        assert e["direction"] == "above"
        assert e["price"] == 96000.0
        assert e["threshold"] == 95000.0
    finally:
        for p in patches:
            p.stop()


def test_price_fires_below(runner):
    patches = _patch_price({"BTC": "79000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "BTC", "--below", "80000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert events[0]["direction"] == "below"
    finally:
        for p in patches:
            p.stop()


def test_price_validation_no_thresholds(runner):
    result = runner.invoke(app, ["watch", "price", "BTC", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "MISSING_THRESHOLD"


def test_price_validation_invalid_range(runner):
    result = runner.invoke(app, ["watch", "price", "BTC", "--above", "100", "--below", "200", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_RANGE"


def test_price_asset_not_found_raises(runner):
    patches = _patch_price({"BTC": "96000.0"})  # no UNKNOWN
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "UNKNOWN", "--above", "1", "--once"])
        # poll() raises; --once doesn't catch, so Typer's exception handler fires
        assert result.exit_code != 0
    finally:
        for p in patches:
            p.stop()


# ---------------------------------------------------------------------------
# funding
# ---------------------------------------------------------------------------


def _make_info_with_funding(funding_rate: str):
    info = MagicMock()
    info.meta_and_asset_ctxs.return_value = [
        {"universe": [{"name": "BTC"}]},
        [{"funding": funding_rate, "markPx": "100"}],
    ]
    return info


def test_funding_fires_spike(runner):
    info = _make_info_with_funding("0.001")  # 0.1%/hr, way above 0.01% threshold
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "funding_spike"
        assert e["asset"] == "BTC"
        assert e["hourly_pct"] == 0.1
        assert e["direction"] == "long_pays"


def test_funding_fires_negative_spike(runner):
    info = _make_info_with_funding("-0.001")  # -0.1%/hr
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert events[0]["direction"] == "short_pays"
        assert events[0]["hourly_pct"] == -0.1


def test_funding_silent_when_below_threshold(runner):
    info = _make_info_with_funding("0.00001")  # 0.001%/hr, below 0.01% threshold
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""


def test_funding_asset_not_found_raises(runner):
    info = MagicMock()
    info.meta_and_asset_ctxs.return_value = [{"universe": [{"name": "ETH"}]}, [{"funding": "0"}]]
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.001", "--once"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Output contract — _emit produces valid JSONL with expected keys
# ---------------------------------------------------------------------------


def test_emit_produces_single_jsonl_line(capsys):
    _emit({"event": "test", "watcher": "unit", "value": 42})
    captured = capsys.readouterr()
    # Exactly one line, valid JSON, ts auto-added
    lines = captured.out.strip().splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["event"] == "test"
    assert event["watcher"] == "unit"
    assert event["value"] == 42
    assert "ts" in event
    # ISO 8601 Z format
    assert event["ts"].endswith("Z")


def test_emit_preserves_explicit_ts(capsys):
    _emit({"event": "test", "ts": "2020-01-01T00:00:00Z"})
    event = json.loads(capsys.readouterr().out.strip())
    assert event["ts"] == "2020-01-01T00:00:00Z"


def test_watch_app_has_all_four_subcommands():
    """Surface check: all four watchers are registered."""
    runner = CliRunner()
    result = runner.invoke(watch_app, ["--help"])
    assert "drawdown" in result.stdout
    assert "liquidation" in result.stdout
    assert "price" in result.stdout
    assert "funding" in result.stdout


# ---------------------------------------------------------------------------
# Peer-review regression tests: interval validation + symbol normalization
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("args", [
    ["watch", "drawdown", "--baseline", "1000", "--threshold-pct", "10", "--interval", "0", "--once"],
    ["watch", "liquidation", "--proximity-pct", "10", "--interval", "0", "--once"],
    ["watch", "price", "BTC", "--above", "1", "--interval", "0", "--once"],
    ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--interval", "0", "--once"],
])
def test_interval_zero_rejected(runner, args):
    """--interval 0 would produce a tight poll loop; must be rejected at validation time."""
    result = runner.invoke(app, args)
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_INTERVAL"


@pytest.mark.parametrize("args", [
    ["watch", "price", "BTC", "--above", "1", "--interval", "-5", "--once"],
])
def test_interval_negative_rejected(runner, args):
    result = runner.invoke(app, args)
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_INTERVAL"


def test_price_lowercase_symbol_normalizes(runner):
    """`btc` should be uppercased before HL dict lookup — matches rest of CLI."""
    patches = _patch_price({"BTC": "96000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "btc", "--above", "95000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "BTC"  # emission uses normalized form
    finally:
        for p in patches:
            p.stop()


def test_funding_lowercase_symbol_normalizes(runner):
    info = _make_info_with_funding("0.001")  # name in mock is "BTC"
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "btc", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "BTC"


def test_price_hip3_symbol_preserves_lowercase_prefix(runner):
    """`xyz:tsla` → `xyz:TSLA` — HIP-3 dex prefix stays lowercase, name uppercases."""
    patches = _patch_price({"xyz:TSLA": "350.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "xyz:tsla", "--above", "300", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "xyz:TSLA"
    finally:
        for p in patches:
            p.stop()


def test_normalize_asset_helper():
    """Direct test of the normalization helper."""
    from regard.commands.watch import _normalize_asset
    assert _normalize_asset("btc") == "BTC"
    assert _normalize_asset("BTC") == "BTC"
    assert _normalize_asset("xyz:tsla") == "xyz:TSLA"
    assert _normalize_asset("XYZ:TSLA") == "XYZ:TSLA"  # user explicitly capped dex — preserve
    assert _normalize_asset("xyz:TSLA") == "xyz:TSLA"
