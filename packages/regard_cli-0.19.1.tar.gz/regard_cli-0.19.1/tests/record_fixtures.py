"""Record golden fixtures from real Hyperliquid API.

Standalone script — NOT a pytest flag. Run explicitly:

    python tests/record_fixtures.py

No auth needed — the HL Info API is public. Uses well-known public addresses
to capture representative response shapes. Addresses are sanitized before
writing (replaced with 0xFIXTURE...).

Validates each response against Pydantic models with extra="forbid" to catch
model drift immediately during recording.
"""

import json
import time
from pathlib import Path

from hyperliquid.info import Info
from pydantic import ConfigDict

from regard.venues.hyperliquid.models import (
    ActiveAssetData,
    AssetCtx,
    AssetInfo,
    Candle,
    Fill,
    FrontendOrder,
    FundingEntry,
    L2Snapshot,
    PerpDexInfo,
    PerpMetaEntry,
    SpotBalance,
    SpotMeta,
    UserState,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "hyperliquid"

# Well-known public addresses — these are NOT our addresses.
# Used by the HL SDK's own test cassettes and visible on-chain.
# Selected for having active state (positions, orders, spot balances).
ADDR_WITH_POSITIONS = "0x31ca8395cf837de08b24da3f660e77761dfb974b"  # 189 positions, 100 orders
ADDR_WITH_ORDERS = ADDR_WITH_POSITIONS  # Same — has open orders
ADDR_WITH_SPOT = "0xCB331197E84f135AB9Ed6FB51Cd9757c0bd29d0D"  # 25 spot balances
ADDR_WITH_FILLS = "0xb7b6f3cea3f66bf525f5d8f965f6dbf6d9b017b2"


def _sanitize_address(data, addr: str) -> None:
    """Replace a specific address with a redacted placeholder in-place."""
    placeholder = "0xFIXTURE" + "0" * (len(addr) - 10)
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, str) and v.lower() == addr.lower():
                data[k] = placeholder
            else:
                _sanitize_address(v, addr)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if isinstance(item, str) and item.lower() == addr.lower():
                data[i] = placeholder
            else:
                _sanitize_address(item, addr)


def _sanitize_fills(fills: list[dict]) -> list[dict]:
    """Deep-sanitize fill data: randomize hashes, oids, timestamps, and PnL.

    Tx hashes are on-chain-resolvable and can identify wallets even after
    address sanitization. We preserve the shape but replace values.
    """
    import hashlib
    sanitized = []
    for i, fill in enumerate(fills):
        f = dict(fill)
        # Replace tx hash with deterministic but non-real hash
        if "hash" in f and f["hash"]:
            f["hash"] = "0x" + hashlib.sha256(f"fixture_fill_{i}".encode()).hexdigest()
        # Replace oid with sequential fixture ID
        if "oid" in f:
            f["oid"] = 900000 + i
        if "tid" in f:
            f["tid"] = 800000 + i
        # Offset timestamps to a fixed base (2024-01-01 00:00:00 UTC)
        if "time" in f:
            f["time"] = 1704067200000 + i * 3600000  # 1h apart
        # Zero out PnL (correlated with real trades)
        if "closedPnl" in f:
            f["closedPnl"] = "0.0"
        sanitized.append(f)
    return sanitized


def _sanitize(data, addresses: list[str]):
    """Sanitize all known addresses from fixture data."""
    for addr in addresses:
        _sanitize_address(data, addr)
    return data


def _validate_forbid(model_cls, data, label: str):
    """Validate data against model with extra='forbid' to catch unknown fields."""
    # Create a strict subclass for testing
    strict_config = ConfigDict(extra="forbid")

    class StrictModel(model_cls):
        model_config = strict_config

    try:
        if isinstance(data, list):
            for i, item in enumerate(data):
                StrictModel.model_validate(item)
        else:
            StrictModel.model_validate(data)
        print(f"  [OK] {label}")
    except Exception as e:
        print(f"  [WARN] {label}: {e}")
        print("         Model may need updating for new API fields")


def _write(name: str, data) -> None:
    path = FIXTURES_DIR / f"{name}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    print(f"  wrote {path.relative_to(FIXTURES_DIR.parent.parent)}")


def record_hyperliquid():
    print("Recording Hyperliquid fixtures...")
    print("  Using public addresses (no auth needed)")

    info = Info(skip_ws=True)
    addresses = [ADDR_WITH_POSITIONS, ADDR_WITH_ORDERS, ADDR_WITH_SPOT, ADDR_WITH_FILLS]

    # --- Global endpoints (no address needed) ---

    print("\n  all_mids...")
    all_mids = info.all_mids()
    _write("all_mids", all_mids)

    print("  meta_and_asset_ctxs (default dex)...")
    meta_ctxs = info.meta_and_asset_ctxs()
    _write("meta_and_asset_ctxs", meta_ctxs)
    # Validate meta
    meta_info = meta_ctxs[0] if isinstance(meta_ctxs, (list, tuple)) else meta_ctxs
    if isinstance(meta_info, dict) and "universe" in meta_info:
        _validate_forbid(AssetInfo, meta_info["universe"][:3], "AssetInfo (sample)")
    # Validate asset contexts
    asset_ctxs = meta_ctxs[1] if isinstance(meta_ctxs, (list, tuple)) and len(meta_ctxs) > 1 else []
    if asset_ctxs:
        _validate_forbid(AssetCtx, asset_ctxs[:3], "AssetCtx (sample)")

    print("  spot_meta...")
    spot_meta = info.spot_meta()
    _write("spot_meta", spot_meta)
    _validate_forbid(SpotMeta, spot_meta, "SpotMeta")

    print("  perpDexs...")
    perp_dexs = info.post("/info", {"type": "perpDexs"})
    _write("perp_dexs", perp_dexs)
    non_null_dexs = [d for d in perp_dexs if d is not None]
    if non_null_dexs:
        _validate_forbid(PerpDexInfo, non_null_dexs[:3], "PerpDexInfo (non-null sample)")

    print("  allPerpMetas...")
    all_perp_metas = info.post("/info", {"type": "allPerpMetas"})
    _write("all_perp_metas", all_perp_metas)
    if all_perp_metas:
        _validate_forbid(PerpMetaEntry, all_perp_metas[:3], "PerpMetaEntry (sample)")

    print("  perpConciseAnnotations...")
    annotations = info.post("/info", {"type": "perpConciseAnnotations"})
    _write("perp_annotations", annotations)

    # --- L2 book ---

    print("  l2_snapshot (BTC)...")
    l2 = info.l2_snapshot("BTC")
    _write("l2_snapshot", l2)
    _validate_forbid(L2Snapshot, l2, "L2Snapshot")

    # --- Funding ---

    print("  funding_history (BTC)...")
    now_ms = int(time.time() * 1000)
    funding = info.funding_history("BTC", startTime=now_ms - 86400000)
    _write("funding_history", funding)
    if funding:
        _validate_forbid(FundingEntry, funding[:3], "FundingEntry (sample)")

    # --- Candles ---

    print("  candles (BTC, 1h)...")
    candles = info.candles_snapshot("BTC", "1h", startTime=now_ms - 86400000, endTime=now_ms)
    _write("candles", candles)
    if candles:
        _validate_forbid(Candle, candles[:3], "Candle (sample)")

    # --- User-specific endpoints (public addresses) ---

    print(f"\n  user_state ({ADDR_WITH_POSITIONS[:10]}...)...")
    user_state = info.user_state(ADDR_WITH_POSITIONS)
    _sanitize(user_state, addresses)
    _write("user_state", user_state)
    _validate_forbid(UserState, user_state, "UserState")

    print(f"  spot_user_state ({ADDR_WITH_SPOT[:10]}...)...")
    spot_state = info.spot_user_state(ADDR_WITH_SPOT)
    _sanitize(spot_state, addresses)
    _write("spot_user_state", spot_state)
    if "balances" in spot_state:
        _validate_forbid(SpotBalance, spot_state["balances"][:3], "SpotBalance (sample)")

    print(f"  frontend_open_orders ({ADDR_WITH_ORDERS[:10]}...)...")
    open_orders = info.frontend_open_orders(ADDR_WITH_ORDERS)
    _sanitize(open_orders, addresses)
    _write("frontend_open_orders", open_orders)
    if open_orders:
        _validate_forbid(FrontendOrder, open_orders[:3], "FrontendOrder (sample)")

    print(f"  user_fills ({ADDR_WITH_FILLS[:10]}...)...")
    fills = info.user_fills(ADDR_WITH_FILLS)
    _sanitize(fills, addresses)
    fills_capped = fills[:20] if fills else []
    fills_capped = _sanitize_fills(fills_capped)  # Randomize hashes, oids, timestamps
    _write("user_fills", fills_capped)
    if fills_capped:
        _validate_forbid(Fill, fills_capped[:3], "Fill (sample)")

    print(f"\n  activeAssetData ({ADDR_WITH_POSITIONS[:10]}..., BTC)...")
    active = info.post("/info", {"type": "activeAssetData", "user": ADDR_WITH_POSITIONS, "coin": "BTC"})
    _sanitize(active, addresses)
    _write("active_asset_data", active)
    if isinstance(active, dict):
        _validate_forbid(ActiveAssetData, active, "ActiveAssetData")

    # --- HIP-3 dex example ---

    print("  meta_and_asset_ctxs (xyz dex)...")
    try:
        xyz_ctxs = info.post("/info", {"type": "metaAndAssetCtxs", "dex": "xyz"})
        _write("meta_and_asset_ctxs_xyz", xyz_ctxs)
    except Exception as e:
        print(f"    skipped: {e}")

    print(f"\nDone. Fixtures written to {FIXTURES_DIR.relative_to(FIXTURES_DIR.parent.parent)}/")


# ---------------------------------------------------------------------------
# Polymarket — Gamma API (public, no auth needed)
# ---------------------------------------------------------------------------

POLY_FIXTURES_DIR = Path(__file__).parent / "fixtures" / "polymarket"


def _write_poly(name: str, data) -> None:
    path = POLY_FIXTURES_DIR / f"{name}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    print(f"  wrote {path.relative_to(POLY_FIXTURES_DIR.parent.parent)}")


def _validate_poly_forbid(model_cls, data, label: str):
    """Validate Poly data against model with extra='forbid'."""
    strict_config = ConfigDict(extra="forbid")

    class StrictModel(model_cls):
        model_config = strict_config

    try:
        if isinstance(data, list):
            for item in data[:3]:
                StrictModel.model_validate(item)
        else:
            StrictModel.model_validate(data)
        print(f"  [OK] {label}")
    except Exception as e:
        print(f"  [WARN] {label}: {e}")
        print("         Model may need updating for new API fields")


def record_polymarket():
    from regard.venues.polymarket.models import GammaEvent, GammaMarket

    print("\nRecording Polymarket fixtures (Gamma API — public, no auth)...")

    import httpx
    gamma = httpx.Client(base_url="https://gamma-api.polymarket.com", timeout=30)

    # --- Market (single) ---
    print("\n  gamma market (active, by search)...")
    resp = gamma.get("/markets", params={"limit": 3, "active": "true", "closed": "false"})
    markets = resp.json()
    if markets:
        _write_poly("gamma_markets", markets[:3])
        _validate_poly_forbid(GammaMarket, markets[:3], "GammaMarket")
    else:
        print("    no markets found")

    # --- Market (by condition ID) — use a known stable market ---
    print("  gamma market (by numeric ID)...")
    # Get a specific market by ID to test the single-market response shape
    if markets:
        market_id = markets[0].get("id", "")
        if market_id:
            resp = gamma.get(f"/markets/{market_id}")
            if resp.status_code == 200:
                single_market = resp.json()
                _write_poly("gamma_market_single", single_market)
                _validate_poly_forbid(GammaMarket, single_market, "GammaMarket (single)")

    # --- Event ---
    print("  gamma event (active)...")
    resp = gamma.get("/events", params={"limit": 2, "active": "true", "closed": "false"})
    events = resp.json()
    if events:
        _write_poly("gamma_events", events[:2])
        _validate_poly_forbid(GammaEvent, events[:2], "GammaEvent")
    else:
        print("    no events found")

    gamma.close()
    print(f"\nDone. Fixtures written to {POLY_FIXTURES_DIR.relative_to(POLY_FIXTURES_DIR.parent.parent)}/")


# ---------------------------------------------------------------------------
# Polymarket — CLOB + Data API (needs auth + active state on wallet)
#
# Run during a playbook cycle when wallet 1 has positions and open orders:
#
#     python tests/record_fixtures.py --poly-clob
#
# Requires POLYMARKET_PRIVATE_KEY in env. VPN must be on (Dublin).
# ---------------------------------------------------------------------------


def _sanitize_poly_address(data, addr: str) -> None:
    """Replace a specific address with a redacted placeholder."""
    placeholder = "0xFIXTURE" + "0" * (len(addr) - 10)
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, str) and v.lower() == addr.lower():
                data[k] = placeholder
            else:
                _sanitize_poly_address(v, addr)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if isinstance(item, str) and item.lower() == addr.lower():
                data[i] = placeholder
            else:
                _sanitize_poly_address(item, addr)


def _sanitize_poly_trades(trades: list[dict]) -> list[dict]:
    """Sanitize trade data: replace IDs, hashes, timestamps, UUIDs, and counterparty addresses."""
    import hashlib
    sanitized = []
    for i, t in enumerate(trades):
        t = dict(t)
        if "id" in t:
            t["id"] = f"fixture_trade_{i}"
        # Transaction hash — API uses snake_case
        for key in ("transaction_hash", "transactionHash"):
            if key in t:
                t[key] = "0x" + hashlib.sha256(f"fixture_poly_trade_{i}".encode()).hexdigest()
        # Taker order ID — resolvable to wallet
        if "taker_order_id" in t:
            t["taker_order_id"] = "0x" + hashlib.sha256(f"fixture_taker_{i}".encode()).hexdigest()
        # Owner UUID — stable user identifier
        if "owner" in t:
            t["owner"] = f"fixture-owner-{i:04d}-0000-0000-000000000000"
        # Timestamps
        if "match_time" in t:
            t["match_time"] = str(1704067200 + i * 3600)
        if "last_update" in t:
            t["last_update"] = str(1704067200 + i * 3600 + 10)
        if "created_at" in t:
            t["created_at"] = f"2024-01-01T{i:02d}:00:00Z"
        # Counterparty maker_orders — sanitize addresses, order IDs, UUIDs
        if "maker_orders" in t and isinstance(t["maker_orders"], list):
            sanitized_makers = []
            for j, m in enumerate(t["maker_orders"]):
                m = dict(m)
                if "maker_address" in m:
                    m["maker_address"] = "0xFIXTURE_MAKER" + f"{j:026d}"
                if "order_id" in m:
                    m["order_id"] = "0x" + hashlib.sha256(f"fixture_maker_order_{i}_{j}".encode()).hexdigest()
                if "owner" in m:
                    m["owner"] = f"fixture-maker-{i:04d}-{j:04d}-0000-000000000000"
                sanitized_makers.append(m)
            t["maker_orders"] = sanitized_makers
        sanitized.append(t)
    return sanitized


def record_polymarket_clob():
    """Record CLOB and Data API fixtures from live wallet state.

    Call after placing positions + orders during a playbook cycle.
    """
    import httpx

    from regard.venues.polymarket.client import DATA_API_BASE, get_address, get_clob_client
    from regard.venues.polymarket.models import (
        ClobBalanceAllowance,
        ClobOrder,
        ClobOrderBook,
        ClobTrade,
        DataApiPosition,
    )

    print("\nRecording Polymarket CLOB + Data API fixtures...")
    print("  Requires: VPN on, wallet with positions + open orders")

    address = get_address()
    print(f"  Wallet: {address[:10]}...")

    # --- Data API: positions (public, no auth) ---
    print("\n  data_api positions...")
    resp = httpx.get(
        f"{DATA_API_BASE}/positions",
        params={"user": address, "sizeThreshold": 0, "limit": 10},
        timeout=30.0,
    )
    resp.raise_for_status()
    positions = resp.json()
    if positions:
        _sanitize_poly_address(positions, address)
        _write_poly("data_api_positions", positions[:5])
        _validate_poly_forbid(DataApiPosition, positions[:5], "DataApiPosition")
    else:
        print("    WARN: no positions — run after placing orders in a playbook cycle")
        _write_poly("data_api_positions", [])

    # --- CLOB API (needs auth) ---
    clob = get_clob_client()

    print("  clob get_balance_allowance...")
    from py_clob_client_v2.clob_types import AssetType, BalanceAllowanceParams
    balance = clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))
    _write_poly("clob_balance_allowance", balance)
    _validate_poly_forbid(ClobBalanceAllowance, balance, "ClobBalanceAllowance")

    print("  clob get_open_orders...")
    orders = clob.get_open_orders()
    if orders:
        _sanitize_poly_address(orders, address)
        _write_poly("clob_open_orders", orders[:5])
        _validate_poly_forbid(ClobOrder, orders[:5], "ClobOrder")
    else:
        print("    WARN: no open orders — run after placing resting limit orders")
        _write_poly("clob_open_orders", [])

    print("  clob get_trades...")
    trades = clob.get_trades()
    trade_list = trades if isinstance(trades, list) else []
    if trade_list:
        _sanitize_poly_address(trade_list, address)
        trade_list = _sanitize_poly_trades(trade_list[:10])
        _write_poly("clob_trades", trade_list)
        _validate_poly_forbid(ClobTrade, trade_list[:3], "ClobTrade")
    else:
        print("    no trades (may be empty if no recent fills)")
        _write_poly("clob_trades", [])

    # --- Order book (public, but use CLOB client for consistent shape) ---
    # Use first position's token_id if available, else first order's
    sample_token_id = None
    if positions:
        sample_token_id = positions[0].get("asset", "")
    elif orders:
        sample_token_id = orders[0].get("asset_id", "")

    if sample_token_id:
        print(f"  clob get_order_book ({sample_token_id[:20]}...)...")
        book = clob.get_order_book(sample_token_id)
        _write_poly("clob_order_book", book)
        _validate_poly_forbid(ClobOrderBook, book, "ClobOrderBook")

        print(f"  clob get_fee_rate_bps ({sample_token_id[:20]}...)...")
        fee_rate = clob.get_fee_rate_bps(sample_token_id)
        _write_poly("clob_fee_rate", {"token_id": sample_token_id, "fee_rate_bps": fee_rate})
    else:
        print("    skipping order_book + fee_rate (no token_id available)")

    print(f"\nDone. Fixtures written to {POLY_FIXTURES_DIR.relative_to(POLY_FIXTURES_DIR.parent.parent)}/")


if __name__ == "__main__":
    import sys
    if "--poly-clob" in sys.argv:
        record_polymarket_clob()
    elif "--poly" in sys.argv:
        record_polymarket()
    elif "--hl" in sys.argv:
        record_hyperliquid()
    else:
        record_hyperliquid()
        record_polymarket()
