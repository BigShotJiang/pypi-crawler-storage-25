"""Dex matrix tests — verify commands work across default + HIP-3 dexes.

Stacked @pytest.mark.parametrize generates the cross-product automatically.
Would have caught: cancel-all missing HIP-3, funding empty for HIP-3,
any command that only queries the default dex.
"""

import json

import pytest

from regard.main import app

# ---------------------------------------------------------------------------
# Commands that should return valid JSON for both default and HIP-3 assets
# ---------------------------------------------------------------------------

DEXES_AND_ASSETS = [
    ("default", "BTC"),
    ("hip3", "xyz:TSLA"),
]

RESEARCH_COMMANDS = [
    lambda asset: ["hl", "prices", asset],
    lambda asset: ["hl", "book", asset],
    lambda asset: ["hl", "funding", asset],
    lambda asset: ["hl", "funding", asset, "--history", "--limit", "2"],
    lambda asset: ["hl", "candles", asset, "1h", "--limit", "2"],
    lambda asset: ["hl", "assets", asset],
]

ACT_READ_COMMANDS = [
    lambda asset: ["hl", "preflight", asset, "buy", "0.01"],
]


@pytest.mark.parametrize("dex_type,asset", DEXES_AND_ASSETS, ids=lambda x: x)
@pytest.mark.parametrize("cmd_fn", RESEARCH_COMMANDS,
                         ids=lambda f: f("X")[1])  # use command name as id
def test_research_across_dexes(runner, patched, dex_type, asset, cmd_fn):
    """Every research command must produce valid JSON for both default and HIP-3 assets."""
    args = cmd_fn(asset)
    result = runner.invoke(app, args)
    stdout = result.stdout.strip()
    assert "Traceback" not in stdout, f"Traceback for {args}: {stdout[:200]}"
    data = json.loads(stdout)
    assert "ok" in data, f"Missing 'ok' for {args}"
    # For research commands, both should succeed (ok=True)
    assert data["ok"] is True, f"Failed for {args}: {data}"


@pytest.mark.parametrize("dex_type,asset", DEXES_AND_ASSETS, ids=lambda x: x)
@pytest.mark.parametrize("cmd_fn", ACT_READ_COMMANDS,
                         ids=lambda f: f("X")[1])
def test_act_read_across_dexes(runner, patched, dex_type, asset, cmd_fn):
    """Preflight and other read-only act commands work across dexes."""
    args = cmd_fn(asset)
    result = runner.invoke(app, args)
    stdout = result.stdout.strip()
    data = json.loads(stdout)
    assert "ok" in data
    assert data["ok"] is True


# ---------------------------------------------------------------------------
# Verify dex parameter propagation — the API must actually receive the dex
# ---------------------------------------------------------------------------

def test_cancel_all_queries_all_dexes(runner, patched):
    """cancel-all must use get_all_orders (which queries all dexes),
    not open_orders (default only)."""
    info = patched["info"]
    runner.invoke(app, ["hl", "cancel-all"])
    # Verify perpDexs was called (dex discovery)
    post_calls = [c for c in info.post.call_args_list
                  if c[0][1].get("type") == "perpDexs"]
    assert len(post_calls) > 0, "cancel-all did not query perpDexs for dex discovery"


def test_funding_queries_hip3_dexes(runner, patched):
    """funding (no args) must return data from HIP-3 dexes too."""
    result = runner.invoke(app, ["hl", "funding"])
    data = json.loads(result.stdout)
    assert data["ok"] is True
    assets = [r["asset"] for r in data["data"]]
    # Must include both default perps and HIP-3
    assert "BTC" in assets, "Missing default perp BTC"
    assert "xyz:TSLA" in assets, "Missing HIP-3 asset xyz:TSLA"


def test_orders_queries_hip3_dexes(runner, patched):
    """orders must use frontend_open_orders across all dexes."""
    info = patched["info"]
    runner.invoke(app, ["hl", "orders"])
    # frontend_open_orders is called for default dex
    assert info.frontend_open_orders.called
    # perpDexs is called for dex discovery
    post_calls = [c for c in info.post.call_args_list
                  if c[0][1].get("type") == "perpDexs"]
    assert len(post_calls) > 0


def test_positions_queries_hip3_dexes(runner, patched):
    """positions must query clearinghouseState across all dexes."""
    info = patched["info"]
    runner.invoke(app, ["hl", "positions"])
    # Should call clearinghouseState for xyz dex
    ch_calls = [c for c in info.post.call_args_list
                if c[0][1].get("type") == "clearinghouseState" and c[0][1].get("dex") == "xyz"]
    assert len(ch_calls) > 0, "positions did not query xyz dex"
