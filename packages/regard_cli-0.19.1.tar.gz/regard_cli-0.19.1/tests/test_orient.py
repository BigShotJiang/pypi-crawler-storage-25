"""Tests for orient commands — status, balance, positions, orders."""

import json
from unittest.mock import patch

from regard.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestStatus:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "status"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_fields(self, runner, patched):
        result = runner.invoke(app, ["--fields", "account_value,withdrawable", "hl", "status"])
        assert result.exit_code == 0
        d = data(result)
        assert set(d.keys()) == {"account_value", "withdrawable"}


class TestBalance:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "balance"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_spot_balances_present(self, runner, patched):
        result = runner.invoke(app, ["hl", "balance"])
        assert result.exit_code == 0
        d = data(result)
        assert d["account_mode"] == "standard"
        assert len(d["spot_balances"]) == 2
        tokens = {b["token"] for b in d["spot_balances"]}
        assert tokens == {"USDC", "HYPE"}

    def test_empty_spot(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.orient.get_spot_balances", return_value=[]):
            result = runner.invoke(app, ["hl", "balance"])
            assert result.exit_code == 0
            d = data(result)
            assert d["spot_balances"] == []

    def test_unified_mode(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.orient.get_account_mode", return_value="unifiedAccount"):
            result = runner.invoke(app, ["hl", "status"])
            assert result.exit_code == 0
            assert data(result)["account_mode"] == "unifiedAccount"


class TestPositions:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "positions", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_empty(self, runner, patched):
        patched["info"].user_state.return_value = {
            "crossMarginSummary": {"accountValue": "100.00"},
            "withdrawable": "100.00",
            "assetPositions": [],
        }
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == []


class TestSpotBalances:
    def test_basic(self, runner, patched):
        result = runner.invoke(app, ["hl", "spot-balances"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 2
        tokens = {b["token"] for b in d}
        assert tokens == {"USDC", "HYPE"}

    def test_display_present(self, runner, patched):
        """spot-balances MUST include a display field like peer orient reads."""
        result = runner.invoke(app, ["hl", "spot-balances"])
        assert result.exit_code == 0
        env = parse(result)
        assert "display" in env
        assert "Token" in env["display"]
        assert "USDC" in env["display"]
        assert "HYPE" in env["display"]

    def test_display_empty(self, runner, patched):
        from unittest.mock import patch as mp
        with mp("regard.venues.hyperliquid.commands.orient.get_spot_balances", return_value=[]):
            result = runner.invoke(app, ["hl", "spot-balances"])
            assert result.exit_code == 0
            env = parse(result)
            assert env["display"] == "No spot balances"

    def test_empty(self, runner, patched):
        from unittest.mock import patch as mp
        with mp("regard.venues.hyperliquid.commands.orient.get_spot_balances", return_value=[]):
            result = runner.invoke(app, ["hl", "spot-balances"])
            assert result.exit_code == 0
            assert data(result) == []

    def test_address_override(self, runner, patched):
        """--address MUST route the query to the supplied wallet."""
        other = "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"
        from unittest.mock import patch as mp
        with mp(
            "regard.venues.hyperliquid.commands.orient.get_address",
            side_effect=lambda explicit=None: explicit or "0xTEST",
        ) as ga:
            result = runner.invoke(app, ["hl", "spot-balances", "--address", other])
            assert result.exit_code == 0
            ga.assert_called_once_with(other)


class TestOrders:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "orders", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_trigger_order_tif_none(self, runner, patched):
        """Regression: trigger orders (TP/SL) return tif=None from API."""
        patched["info"].frontend_open_orders.return_value = [
            {
                "coin": "BTC",
                "oid": 100003,
                "side": "A",
                "limitPx": "80000.0",
                "sz": "0.001",
                "orderType": "Take Profit Market",
                "tif": None,
                "reduceOnly": True,
                "timestamp": 1773000000000,
            }
        ]
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        d = data(result)
        assert d[0]["tif"] is None
        assert d[0]["type"] == "take profit market"

    def test_non_trigger_order_with_triggerPx_zero(self, runner, patched):
        """Regression: API returns triggerPx='0.0' for non-trigger orders on HIP-3 dexes.
        The truthy string '0.0' was used instead of limitPx."""
        patched["info"].frontend_open_orders.return_value = [
            {
                "coin": "BTCD",
                "oid": 100004,
                "side": "B",
                "limitPx": "10.0",
                "triggerPx": "0.0",
                "sz": "0.2",
                "orderType": "Limit",
                "tif": "Gtc",
                "reduceOnly": False,
                "isTrigger": False,
                "timestamp": 1773000000000,
            }
        ]
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        d = data(result)
        assert d[0]["price"] == "10.0"
