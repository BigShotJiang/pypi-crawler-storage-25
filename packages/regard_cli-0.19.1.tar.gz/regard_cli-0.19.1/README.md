# regard-cli

AI trading partner for the unified speculator. Multi-venue trading CLI consumed by the [regard-computer](https://github.com/akegaviar/tabtabtabTABtab) Claude Code skill.

## Install

```bash
uv tool install regard-cli
```

## Usage

```bash
# Read commands (no auth needed)
regard hl prices BTC ETH
regard hl book BTC --depth 10
regard hl assets TSLA
regard hl funding BTC --history
regard hl candles BTC 1h --limit 50

# Account commands (needs HYPERLIQUID_AGENT_KEY or --address)
regard hl status
regard hl balance
regard hl positions
regard hl orders
regard hl fills

# Write commands (needs HYPERLIQUID_AGENT_KEY)
regard hl order BTC buy 0.1 --market
regard hl order BTC buy 0.1 95000 --tp 100000 --sl 90000
regard hl cancel 77738308
regard hl cancel-all BTC
regard hl leverage BTC 10
```

## Auth

Set `HYPERLIQUID_AGENT_KEY` env var with your Hyperliquid agent wallet key (can trade, cannot withdraw). Master address auto-resolved via `userRole` API.

Read-only commands work without auth using `--address`.

## Design

- Venue-first sub-commands (`regard hl`, `regard poly`, ...)
- Output envelope: `{"ok": true, "data": ..., "meta": {"timestamp": ...}}`
- Structured errors with type/code/message, recovery hints, retryable flag
- Exit codes: 0=success, 2=validation, 3=auth, 4=venue, 5=rate_limit, 6=network
- Field projection via `--fields`
- HIP-3 asset auto-resolution (e.g. `TSLA` → `xyz:TSLA`)
- CLI-first, MCP-ready — every command maps 1:1 to an MCP tool definition

## License

MIT
