"""
Data module for siege_utilities.

After ELE-2437, ``data/`` narrowed to hold statistics primitives
(``data.statistics``) + the RDH provider shim. Other concerns moved:

- Engine abstractions → :mod:`siege_utilities.engines`
- Sample datasets + crosswalks → :mod:`siege_utilities.reference`

Top-level imports at this package are preserved (re-exports from the
new homes) for one deprecation window so existing callers still work.
"""

# Reference data (moved to siege_utilities.reference but re-exported here)
from ..reference.sample_data import (
    load_sample_data,
    list_available_datasets,
    get_dataset_info,
    get_census_boundaries,
    get_census_data,
    join_boundaries_and_data,
    create_sample_dataset,
    generate_synthetic_population,
    generate_synthetic_businesses,
    generate_synthetic_housing,
    HOUSING_LOCALE_PRESETS,
    SAMPLE_DATASETS,
    CENSUS_SAMPLES,
    SYNTHETIC_SAMPLES,
)

# RDH provider moved to geo/providers/ under ELE-2438 (D3). Top-level
# data.* re-export is preserved so existing callers continue to work
# without a deprecation warning through this path.
from ..geo.providers.redistricting_data_hub import (
    RDHClient,
    RDHDataset,
    RDHDataFormat,
    RDHDatasetType,
    RDH_BASE_URL,
    US_STATES,
    polsby_popper,
    reock,
    convex_hull_ratio,
    schwartzberg,
    compute_compactness,
    compare_plans,
    demographic_profile,
    fetch_enacted_plan,
    fetch_precinct_results,
    fetch_cvap,
    fetch_pl94171,
    fetch_demographic_summary,
    CompactnessScores,
    RDH_SITE_URL,
)

# Engine abstractions (moved to siege_utilities.engines but re-exported here)
from ..engines.dataframe_engine import (
    Engine,
    PANDAS,
    DUCKDB,
    SPARK,
    POSTGIS,
    DataFrameEngine,
    PandasEngine,
    DuckDBEngine,
    SparkEngine,
    PostGISEngine,
    get_engine,
)

__all__ = [
    # Core functions
    'load_sample_data',
    'list_available_datasets', 
    'get_dataset_info',
    
    # Census samples
    'get_census_boundaries',
    'get_census_data',
    'join_boundaries_and_data',
    'create_sample_dataset',
    
    # Synthetic generation
    'generate_synthetic_population',
    'generate_synthetic_businesses',
    'generate_synthetic_housing',
    'HOUSING_LOCALE_PRESETS',

    # Dataset info
    'SAMPLE_DATASETS',
    'CENSUS_SAMPLES',
    'SYNTHETIC_SAMPLES',

    # Redistricting Data Hub
    'RDHClient',
    'RDHDataset',
    'RDHDataFormat',
    'RDHDatasetType',
    'RDH_BASE_URL',
    'US_STATES',
    'polsby_popper',
    'reock',
    'convex_hull_ratio',
    'schwartzberg',
    'compute_compactness',
    'compare_plans',
    'demographic_profile',
    'fetch_enacted_plan',
    'fetch_precinct_results',
    'fetch_cvap',
    'fetch_pl94171',
    'fetch_demographic_summary',
    'CompactnessScores',
    'RDH_SITE_URL',

    # Engine-agnostic DataFrame operations
    'Engine',
    'PANDAS',
    'DUCKDB',
    'SPARK',
    'POSTGIS',
    'DataFrameEngine',
    'PandasEngine',
    'DuckDBEngine',
    'SparkEngine',
    'PostGISEngine',
    'get_engine',
]

# Package metadata
__version__ = "1.0.0"
__description__ = "Sample datasets and synthetic data generation for testing and learning"
