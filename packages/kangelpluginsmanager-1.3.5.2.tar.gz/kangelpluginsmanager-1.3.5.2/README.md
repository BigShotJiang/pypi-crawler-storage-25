# KangelPluginsManager

Plugin store and management system for exteraGram/AyuGram clients.

## Installation

```bash
pip install KangelPluginsManager
```

## Usage

```python
from kangelpluginsmanager import KangelPluginsManagerPlugin

# The plugin class provides full store functionality
plugin = KangelPluginsManagerPlugin()
```

## Structure

- `kangelpluginsmanager.plugin` — Main plugin class
- `kangelpluginsmanager.methods` — Utilities, telemetry (mkStats), helpers
- `kangelpluginsmanager.assests.locale` — Translations (en/ru)

## Requirements

- Python >= 3.9
- exteraGram / AyuGram >= 12.1.1

## License

MIT
