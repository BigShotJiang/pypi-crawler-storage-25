from .plugin import KangelPluginsManagerPlugin 
