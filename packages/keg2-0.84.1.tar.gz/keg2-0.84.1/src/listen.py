from ch36_world_app.w1_app import ETLApp


def main():
    """Entry point for the keg2 listen CLI."""
    ETLApp().mainloop()


if __name__ == "__main__":
    main()
