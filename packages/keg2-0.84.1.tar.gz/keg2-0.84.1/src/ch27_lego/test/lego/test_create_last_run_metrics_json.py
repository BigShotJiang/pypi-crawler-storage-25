from ch00_py.file_toolbox import open_json
from ch17_brick.brick_db_tool import create_brick_sorted_table
from ch18_etl_config._ref.ch18_path import create_last_run_metrics_path
from ch18_etl_config.etl_sqlstr import create_sound_and_heard_tables
from ch27_lego.lego_core import create_last_run_metrics_json
from os.path import exists as os_path_exists
from ref.keywords import Ch27Keywords as kw
from sqlite3 import Cursor


def test_create_last_run_metrics_json_CreatesFile(cursor0: Cursor, temp3_fs):
    # ESTABLISH
    spark1 = 1
    spark3 = 3
    spark9 = 9
    moment_mstr_dir = str(temp3_fs)
    last_run_metrics_path = create_last_run_metrics_path(moment_mstr_dir)
    create_sound_and_heard_tables(cursor0)
    agg_bk00103_tablename = f"bk00103_{kw.b_agg}"
    agg_bk00103_columns = [kw.spark_num]
    create_brick_sorted_table(cursor0, agg_bk00103_tablename, agg_bk00103_columns)
    agg_bk00103_insert_sqlstr = f"""
INSERT INTO {agg_bk00103_tablename} ({kw.spark_num})
VALUES ('{spark1}'), ('{spark1}'), ('{spark9}');"""
    cursor0.execute(agg_bk00103_insert_sqlstr)

    agg_bk00144_tablename = f"bk00144_{kw.b_agg}"
    agg_bk00144_columns = [kw.spark_num]
    create_brick_sorted_table(cursor0, agg_bk00144_tablename, agg_bk00144_columns)
    agg_bk00144_insert_sqlstr = f"""
INSERT INTO {agg_bk00144_tablename} ({kw.spark_num})
VALUES ('{spark3}');"""
    cursor0.execute(agg_bk00144_insert_sqlstr)
    assert not os_path_exists(last_run_metrics_path)

    # WHEN
    create_last_run_metrics_json(cursor0, moment_mstr_dir)

    # THEN
    assert os_path_exists(last_run_metrics_path)
    last_run_metrics_dict = open_json(last_run_metrics_path)
    max_b_agg_spark_num_str = "max_b_agg_spark_num"
    assert max_b_agg_spark_num_str in set(last_run_metrics_dict.keys())
    max_b_agg_spark_num = last_run_metrics_dict.get(max_b_agg_spark_num_str)
    assert max_b_agg_spark_num == spark9
