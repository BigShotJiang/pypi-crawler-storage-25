from setuptools import setup, find_packages

setup(
    name='HyTech_STT',
    version='0.1',
    author='Muhammad Abdullah',
    description='This is Speech-to-text package created by Muhammad Abdullah,'
)
packages = find_packages(),
install_requirements = [
    'selenium',
    'webdriver_manager'
]