import math
import logging

# 注册模块级日志
logger = logging.getLogger(__name__)

def calculate_height_by_shadow(dist_px: float, gsd: float, sun_ele_deg: float) -> float:
    """
    
    参数:
        dist_px (float): 视觉模型提取的【塔底】至【影尖】的欧氏距离(像素)
        gsd (float): 影像的地面采样率 (GSD, m/px)
        sun_ele_deg (float): 太阳高度角 (角度制, 0~90)
        
    返回:
        float: 反演出的风机真实物理高度 (米)
    """
    # 1. 像素距离转化为地面实际物理影长
    shadow_len_m = dist_px * gsd
    
    if shadow_len_m <= 0:
        logger.warning(f"Abnormal shadow length ({shadow_len_m}m) detected. Skipping.")
        return 0.0
        
    # 2. 角度合法性边界防御
    if sun_ele_deg <= 0 or sun_ele_deg >= 90:
        logger.error(f"Invalid solar elevation: {sun_ele_deg}°. Must be in range (0, 90).")
        return 0.0
        
    alpha_rad = math.radians(sun_ele_deg)
    
    # 3. 核心物理投影真理
    height = shadow_len_m * math.tan(alpha_rad)
    
    logger.debug(f"Inversion complete -> L: {shadow_len_m:.2f}m, α: {sun_ele_deg:.2f}°, H: {height:.2f}m")
    return abs(height)