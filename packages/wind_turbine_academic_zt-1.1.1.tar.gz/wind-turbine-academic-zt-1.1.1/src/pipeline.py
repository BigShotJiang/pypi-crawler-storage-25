import logging
from pathlib import Path
import pandas as pd

from src.geometry import calculate_height_by_shadow

logger = logging.getLogger(__name__)

class WindTurbinePipeline:
    def __init__(self, gsd: float, sun_ele: float):
        """
        初始化端到端流水线
        """
        self.gsd = gsd
        self.sun_ele = sun_ele
        logger.info(f"Pipeline initialized: GSD={self.gsd}m, Sun_Elevation={self.sun_ele:.2f}°")

    def execute(self, tiff_path: Path, output_dir: str = "output") -> Path:
        """
        运行全流程推理与测绘解算
        """
        logger.info(f"Starting processing sequence for image: {tiff_path.name}")
        
        # ---------------------------------------------------------
        # 【模型推理挂载点】
        # 这里模拟你的 YOLOv8 模型输出。你需要将这里的 mock 替换为实际的推理逻辑
        # bx, by = base_x, base_y (塔底); sx, sy = shadow_x, shadow_y (影尖)
        # ---------------------------------------------------------
        mock_detections = [
            {"id": 1, "bx": 120.0, "by": 340.0, "sx": 150.0, "sy": 390.0},
            {"id": 2, "bx": 450.0, "by": 710.0, "sx": 481.0, "sy": 761.0}
        ]
        
        results = []
        for det in mock_detections:
            # 1. 计算特征点像素距离
            dx = det["sx"] - det["bx"]
            dy = det["sy"] - det["by"]
            dist_px = (dx**2 + dy**2) ** 0.5
            
            # 2. 调用核心反演引擎
            height = calculate_height_by_shadow(
                dist_px=dist_px, 
                gsd=self.gsd, 
                sun_ele_deg=self.sun_ele
            )
            
            # 3. 收集格式化数据
            results.append({
                "Target_ID": det["id"],
                "Pixel_Distance": round(dist_px, 2),
                "Shadow_Length_Meters": round(dist_px * self.gsd, 2),
                "Height_Meters": round(height, 2)
            })
            
        # 结果结构化落盘
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        csv_file = out_path / "final_heights.csv"
        
        df = pd.DataFrame(results)
        df.to_csv(csv_file, index=False, encoding="utf-8")
        
        logger.info(f"Pipeline execution completed. Processed {len(results)} instances.")
        logger.info(f"Results saved to: {csv_file.absolute()}")
        
        return csv_file