import xml.etree.ElementTree as ET
import logging
from typing import Optional

logger = logging.getLogger(__name__)

def extract_elevation_from_xml(xml_path: str) -> Optional[float]:
    """
    从遥感标准 XML 元数据中安全提取太阳高度角
    
    参数:
        xml_path (str): XML 文件路径
        
    返回:
        Optional[float]: 成功则返回高度角，失败返回 None
    """
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        # 优先匹配天顶角 (Zenith) 并执行互补转换 (如 GF-2 格式)
        zenith_node = root.find(".//SolarZenith")
        if zenith_node is not None and zenith_node.text:
            sun_ele = 90.0 - float(zenith_node.text)
            logger.info(f"XML Engine -> Found Zenith, converted to Elevation: {sun_ele:.4f}°")
            return sun_ele
            
        # 备选匹配直接提供高度角 (Elevation) 的格式
        ele_node = root.find(".//SolarElevation")
        if ele_node is not None and ele_node.text:
            sun_ele = float(ele_node.text)
            logger.info(f"XML Engine -> Found direct Elevation: {sun_ele:.4f}°")
            return sun_ele
            
        logger.error(f"XML Engine -> No valid solar geometry tags found in {xml_path}.")
        return None
        
    except ET.ParseError:
        logger.error(f"XML Engine -> File {xml_path} is corrupted or not well-formed.")
        return None
    except Exception as e:
        logger.error(f"XML Engine -> Unexpected parsing exception: {str(e)}")
        return None