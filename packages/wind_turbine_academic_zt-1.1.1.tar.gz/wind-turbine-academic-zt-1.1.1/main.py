import argparse
import sys
import logging
from datetime import datetime
from pathlib import Path

from src.xml_parser import extract_elevation_from_xml
from src.ephemeris import get_solar_elevation
from src.pipeline import WindTurbinePipeline

# 1. 配置全局工业规范分层日志系统
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("WindTurbineCLI")

def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Academic Wind Turbine Height Estimator (Streamlined Engine)"
    )
    
    # 基础核心参数
    parser.add_argument('--tiff', type=str, required=True, help='Path to target TIFF image')
    parser.add_argument('--gsd', type=float, required=True, help='Ground Sample Distance (m/px)')
    
    # 构建严格的“三选一”输入互斥锁
    source_group = parser.add_mutually_exclusive_group(required=True)
    source_group.add_argument('--xml', type=str, help='[Track 1] Path to XML metadata')
    source_group.add_argument('--sun_ele', type=float, help='[Track 2] Direct input of solar elevation angle')
    source_group.add_argument('--ephemeris', action='store_true', help='[Track 3] Trigger ephemeris calculation via lat/lon/time')
    
    # Track 3 专属参数 (仅在开启 --ephemeris 时有效)
    parser.add_argument('--lat', type=float, help='Latitude for ephemeris (e.g. 38.25)')
    parser.add_argument('--lon', type=float, help='Longitude for ephemeris (e.g. 107.10)')
    parser.add_argument('--time', type=str, help='UTC Time for ephemeris (YYYY-MM-DD HH:MM:SS)')

    return parser.parse_args()

def main():
    args = parse_arguments()
    tiff_path = Path(args.tiff)
    
    if not tiff_path.exists():
        logger.error(f"Target image not found: {tiff_path}")
        sys.exit(1)

    sun_ele = None
    
    # ---------------------------------------------------------
    # 智能数据路由树 (Data Routing Tree)
    # ---------------------------------------------------------
    if args.xml:
        logger.info("Initializing Track 1: XML Metadata Parsing")
        sun_ele = extract_elevation_from_xml(args.xml)
        
    elif args.sun_ele is not None:
        logger.info("Initializing Track 2: Manual Angle Injection")
        sun_ele = args.sun_ele
        
    elif args.ephemeris:
        logger.info("Initializing Track 3: Astronomical Ephemeris Engine")
        # 星历模式前置校验
        if args.lat is None or args.lon is None or args.time is None:
            logger.error("Ephemeris mode strictly requires --lat, --lon, and --time arguments.")
            sys.exit(1)
        try:
            utc_dt = datetime.strptime(args.time, "%Y-%m-%d %H:%M:%S")
            sun_ele = get_solar_elevation(args.lat, args.lon, utc_dt)
        except ValueError:
            logger.error("Time string format error. Please strictly use 'YYYY-MM-DD HH:MM:SS'")
            sys.exit(1)
            
    # 核心参数阻断检查
    if sun_ele is None:
        logger.critical("Initialization aborted: Solar elevation angle could not be resolved.")
        sys.exit(1)

    # ---------------------------------------------------------
    # 实例化并驱动业务流水线
    # ---------------------------------------------------------
    try:
        pipeline = WindTurbinePipeline(gsd=args.gsd, sun_ele=sun_ele)
        pipeline.execute(tiff_path=tiff_path)
    except Exception as e:
        logger.critical(f"Pipeline encountered a fatal error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()