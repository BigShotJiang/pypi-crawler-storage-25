config_object = {
    "org_id": "",
    "client_id": "",
    "secret": "",
    "date_limit": 0,
    "token": "",
    "scopes":"",
    "imsEndpoint":"https://ims-na1.adobelogin.com",
    "oauthTokenEndpoint": "",
}
header = {"Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer ",
          "x-api-key": ""
          }
endpoints = {
    "global": 'https://cja.adobe.io'
}
