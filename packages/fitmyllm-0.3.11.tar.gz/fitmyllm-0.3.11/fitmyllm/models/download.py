"""GGUF download from HuggingFace — no extra dependencies, just httpx."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

import httpx

from ..config import get_models_dir

HF_API = "https://huggingface.co/api/models"
HEADERS = {
    "User-Agent": "fitmyllm/0.3 (https://fitmyllm.com)",
}


def resolve_gguf_url(repo: str, quant_level: str) -> str | None:
    """Find the GGUF download URL for a specific quant level in a HF repo.

    Args:
        repo: HuggingFace repo ID, e.g. "bartowski/Llama-3.2-3B-Instruct-GGUF"
        quant_level: e.g. "Q4_K_M", "Q5_K_M", "Q8_0"

    Returns:
        Direct download URL or None if not found.
    """
    try:
        resp = httpx.get(f"{HF_API}/{repo}", headers=HEADERS, timeout=15.0)
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError(f"Repository {repo} requires authentication (gated model)")
        if e.response.status_code == 404:
            raise RuntimeError(f"Repository {repo} not found on HuggingFace")
        return None
    except Exception:
        return None

    siblings = data.get("siblings", [])
    quant_lower = quant_level.lower()

    # Look for GGUF files matching the quant level
    candidates = []
    for s in siblings:
        fname = s.get("rfilename", "")
        if not fname.endswith(".gguf"):
            continue
        # Match quant level in filename (case-insensitive)
        if quant_lower in fname.lower():
            candidates.append(fname)

    if not candidates:
        return None

    # Prefer exact quant match, then shortest filename
    candidates.sort(key=len)
    best = candidates[0]

    return f"https://huggingface.co/{repo}/resolve/main/{best}"


def download_gguf(
    url: str,
    filename: str | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Path:
    """Download a GGUF file to the models directory.

    Supports resume if a partial download (.part file) exists.

    Args:
        url: Direct download URL.
        filename: Override filename (default: extract from URL).
        progress_callback: Called with (bytes_downloaded, total_bytes).

    Returns:
        Path to the downloaded file.

    Raises:
        RuntimeError: On download failure with a descriptive message.
    """
    models_dir = get_models_dir()
    models_dir.mkdir(parents=True, exist_ok=True)

    if filename is None:
        filename = url.split("/")[-1].split("?")[0]

    dest = models_dir / filename
    part = dest.with_suffix(dest.suffix + ".part")

    # Resume support: check if partial file exists
    resume_from = 0
    if part.exists():
        resume_from = part.stat().st_size

    headers = dict(HEADERS)
    if resume_from > 0:
        headers["Range"] = f"bytes={resume_from}-"

    try:
        with httpx.stream(
            "GET", url,
            headers=headers,
            follow_redirects=True,
            timeout=httpx.Timeout(connect=15.0, read=60.0, write=60.0, pool=15.0),
        ) as resp:
            if resp.status_code == 401:
                raise RuntimeError(
                    "This model requires authentication. "
                    "It may be a gated model — accept terms at huggingface.co first."
                )
            if resp.status_code == 403:
                raise RuntimeError(
                    "Access denied. The model may require you to accept terms "
                    "on HuggingFace before downloading."
                )
            resp.raise_for_status()

            # Handle resume response
            if resp.status_code == 206:
                # Partial content — resume
                total = resume_from + int(resp.headers.get("content-length", 0))
                downloaded = resume_from
                mode = "ab"
            else:
                # Full download (or server doesn't support range)
                total = int(resp.headers.get("content-length", 0))
                downloaded = 0
                resume_from = 0
                mode = "wb"

            with open(part, mode) as f:
                for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total)

    except RuntimeError:
        raise
    except httpx.ConnectError:
        raise RuntimeError(
            "Cannot connect to HuggingFace. Check your internet connection."
        )
    except httpx.TimeoutException:
        if part.exists() and part.stat().st_size > 0:
            raise RuntimeError(
                f"Download timed out ({part.stat().st_size // (1024*1024)}MB downloaded). "
                f"Run again to resume from where it stopped."
            )
        raise RuntimeError("Download timed out. Check your internet connection.")
    except Exception as e:
        raise RuntimeError(f"Download failed: {e}")

    # Atomic rename on completion
    part.rename(dest)
    return dest
