"""Benchmark screen — select a model and run a speed test."""

from __future__ import annotations

import time

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Input
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from ..backends import get_backend, detect_backends
from ..widgets import get_key

BENCH_PROMPT = (
    "Write a Python function to sort a list using quicksort. "
    "Include docstring and type hints."
)


class BenchSubmitScreen(Screen):
    """Select a model from installed/recommended list and run a benchmark."""

    DEFAULT_CSS = "BenchSubmitScreen { layout: vertical; }"

    BINDINGS = [
        Binding("m", "manual_input", "Manual", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._models: list[dict] = []  # [{name, source, backend_name, tag}]
        self._loaded = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("\n  [bold]Run Benchmark[/]  [dim]Loading models...[/]\n", id="bench-header")
        yield DataTable(id="bench-table", cursor_type="row")
        yield Input(
            placeholder="Or type a model tag manually and press Enter...",
            id="bench-manual",
        )
        yield VerticalScroll(Static("", id="bench-results"))
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#bench-table", DataTable)
        table.add_columns("", "Model", "Source")
        # Hide manual input by default
        self.query_one("#bench-manual", Input).display = False
        self._load_models()

    def action_manual_input(self) -> None:
        """Toggle manual model input."""
        inp = self.query_one("#bench-manual", Input)
        inp.display = not inp.display
        if inp.display:
            inp.focus()

    @work(thread=True)
    def _load_models(self) -> None:
        """Discover models from all available backends + API recommendations."""
        models: list[dict] = []
        seen: set[str] = set()

        # 1. Installed models from all detected backends
        backends = detect_backends()
        for backend in backends:
            try:
                for m in backend.list_models():
                    name = m.get("name", "")
                    if name and name not in seen:
                        seen.add(name)
                        models.append({
                            "name": name,
                            "source": f"installed ({backend.name})",
                            "backend_name": backend.name,
                            "tag": name,
                            "status": "[green]\u2713 installed[/]",
                        })
            except Exception:
                pass

        # 2. Recommended models from API (if GPU is known)
        try:
            from .. import api, config
            key = get_key()
            gpu = config.get_preferred_gpu()
            if key and gpu:
                result = api.recommend(key, gpu)
                recs = result.get("recommendations", [])
                for r in recs[:5]:  # top 5 recommendations
                    m = r.get("model", {})
                    q = r.get("quant", {})
                    tag = q.get("ollama_tag", "")
                    name = m.get("name", "")
                    display = f"{name} ({q.get('level', '')})"
                    if display not in seen and tag:
                        seen.add(display)
                        models.append({
                            "name": display,
                            "source": f"recommended for {gpu}",
                            "backend_name": "ollama",
                            "tag": tag,
                            "status": "[cyan]\u2605 recommended[/]",
                            "predicted_speed": r.get("speed_toks"),
                        })
        except Exception:
            pass

        self._models = models
        self._loaded = True
        self.app.call_from_thread(self._populate_table)

    def _populate_table(self) -> None:
        header = self.query_one("#bench-header", Static)
        table = self.query_one("#bench-table", DataTable)
        table.clear()

        if not self._models:
            header.update(
                "\n  [bold]Run Benchmark[/]  "
                "[yellow]No models found — start Ollama or llama-server, "
                "or press [bold]m[/bold] for manual input[/]\n"
            )
            return

        header.update(
            f"\n  [bold]Run Benchmark[/]  "
            f"[dim]{len(self._models)} models · Select and press Enter · "
            f"[bold]m[/bold] for manual input[/]\n"
        )

        for m in self._models:
            table.add_row(m["status"], m["name"], f"[dim]{m['source']}[/]")

        table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._models or event.cursor_row >= len(self._models):
            return
        model = self._models[event.cursor_row]
        self._run_benchmark(
            model["tag"],
            model["name"],
            model.get("backend_name"),
            model.get("predicted_speed"),
        )

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "bench-manual" and event.value.strip():
            tag = event.value.strip()
            self._run_benchmark(tag, tag, None, None)

    @work(thread=True)
    def _run_benchmark(
        self,
        tag: str,
        display_name: str,
        backend_name: str | None,
        predicted_speed: float | None,
    ) -> None:
        results = self.query_one("#bench-results", Static)
        self.app.call_from_thread(
            results.update,
            f"  [dim]Running benchmark for {escape(display_name)}...[/]\n"
            f"  [dim]Prompt: 'Write a Python quicksort function'[/]\n",
        )

        # Get the right backend
        backend = get_backend(backend_name)
        if backend is None:
            self.app.call_from_thread(
                results.update,
                "  [red]No inference backend available.[/]\n"
                "  [dim]Start Ollama or llama-server first.[/]",
            )
            return

        try:
            messages = [{"role": "user", "content": BENCH_PROMPT}]
            response_text = ""
            token_count = 0
            start = time.time()

            for chunk in backend.stream_chat(tag, messages, timeout=120.0):
                if chunk.content:
                    response_text += chunk.content
                    token_count += 1  # count actual streamed tokens
                if chunk.done:
                    break

            elapsed = time.time() - start
            toks_per_sec = token_count / elapsed if elapsed > 0 else 0

            lines = (
                f"\n  ─── [bold cyan]Benchmark Results[/] ───\n\n"
                f"  [dim]Model[/]        [bold]{escape(display_name)}[/]\n"
                f"  [dim]Backend[/]      {backend.name} ({backend.base_url})\n"
                f"  [dim]Tokens[/]       {token_count}\n"
                f"  [dim]Time[/]         {elapsed:.1f}s\n"
                f"  [dim]Speed[/]        [bold green]~{toks_per_sec:.1f} tok/s[/]\n"
            )

            if predicted_speed:
                delta = toks_per_sec - predicted_speed
                delta_pct = (delta / predicted_speed * 100) if predicted_speed > 0 else 0
                color = "green" if delta >= 0 else "red"
                lines += (
                    f"  [dim]Predicted[/]    {predicted_speed:.1f} tok/s\n"
                    f"  [dim]Delta[/]        [{color}]{delta:+.1f} tok/s ({delta_pct:+.0f}%)[/]\n"
                )

            safe_output = escape(response_text[:500])
            lines += (
                f"\n  ─── [bold cyan]Output Preview[/] ───\n\n"
                f"  {safe_output}{'...' if len(response_text) > 500 else ''}\n"
            )

            self.app.call_from_thread(results.update, lines)

        except ConnectionError:
            self.app.call_from_thread(
                results.update,
                f"  [red]Cannot connect to {backend.name} at {backend.base_url}[/]\n"
                f"  [dim]Is it running?[/]",
            )
        except Exception as e:
            self.app.call_from_thread(
                results.update,
                f"  [red]Error:[/] {escape(str(e))}",
            )
