"""Tests for payment link and order MCP tools."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError
from tools.payment_links import register_payment_link_tools
from tools.orders import register_order_tools


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _FakeMCP:
    """Minimal MCP stub that captures registered tool functions."""

    def __init__(self):
        self.tools = {}

    def tool(self, name, description):
        def decorator(fn):
            self.tools[name] = fn
            return fn
        return decorator
def _make_token_manager(token="test-access-token"):
    """Create a token manager stub for PineLabsClient test instances."""
    manager = MagicMock()
    manager.get_access_token = AsyncMock(return_value=token)
    return manager


def _mock_headers(token="test-token"):
    """Return a mock Authorization header dict."""
    return {"authorization": f"Bearer {token}"}


def _make_mcp_and_register_payment_tools(client):
    """Create a FakeMCP, register tools, return the captured tool functions."""
    mcp = _FakeMCP()
    register_payment_link_tools(mcp, client)
    return mcp.tools


def _make_mcp_and_register_order_tools(client):
    """Create a FakeMCP, register order tools, return the captured tool functions."""
    mcp = _FakeMCP()
    register_order_tools(mcp, client)
    return mcp.tools


# ---------------------------------------------------------------------------
# create_payment_link
# ---------------------------------------------------------------------------

class TestCreatePaymentLink:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.post = AsyncMock(return_value={"payment_link_id": "pl-new", "status": "CREATED"})
        return c

    @pytest.mark.asyncio
    async def test_success_minimal(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert data["payment_link_id"] == "pl-new"
        assert data["status"] == "CREATED"
        client.post.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_success_full(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=100000,
            currency="INR",
            customer_email="test@example.com",
            customer_first_name="John",
            customer_last_name="Doe",
            customer_mobile="9876543210",
            customer_country_code="+91",
            customer_id="cust-123",
            description="Test order",
            expire_by="2026-06-01T10:00Z",
            allowed_payment_methods=["CARD", "UPI"],
            billing_address1="123 St",
            billing_city="Mumbai",
            billing_state="MH",
            billing_country="India",
            billing_pincode="400001",
            billing_full_name="John Doe",
            shipping_address1="456 Ave",
            shipping_city="Delhi",
            shipping_state="DL",
            shipping_country="India",
            shipping_pincode="110001",
            shipping_full_name="John Doe",
        )
        data = json.loads(result)
        assert data["status"] == "CREATED"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.post = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_missing_email_and_mobile(self, client):
        """Customer requires at least email or mobile — returns validation error."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
        )
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"
        assert "email" in data["error"].lower() or "mobile" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_invalid_payment_method(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
            allowed_payment_methods=["BITCOIN"],
        )
        data = json.loads(result)
        assert "error" in data
        assert "Invalid payment method" in data["error"]

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(400, "BAD", "Bad request")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert data["error"] == "Bad request"
        assert data["code"] == "BAD"
        assert data["status_code"] == 400

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.post = AsyncMock(side_effect=RuntimeError("connection lost"))
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()
        assert "connection lost" not in data["error"]

    @pytest.mark.asyncio
    async def test_with_mobile_only(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_mobile="9876543210",
        )
        data = json.loads(result)
        assert data["status"] == "CREATED"

    @pytest.mark.asyncio
    async def test_invalid_merchant_ref(self, client):
        """merchant_payment_link_reference with unsafe chars triggers validation error."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
            merchant_payment_link_reference="ref/with;bad chars",
        )
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"

    @pytest.mark.asyncio
    async def test_invalid_expire_by(self, client):
        """An invalid expire_by string triggers validation error."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
            expire_by="not-a-date",
        )
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"

    @pytest.mark.asyncio
    async def test_with_product_details(self, client):
        """Product code and amount create product_details in the request."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
            product_code="redmi_10",
            product_amount=45000,
        )
        data = json.loads(result)
        assert data["status"] == "CREATED"
        # Verify the request payload included product_details
        call_args = client.post.call_args
        payload = call_args[0][1]
        assert "product_details" in payload
        assert payload["product_details"][0]["product_code"] == "redmi_10"

    @pytest.mark.asyncio
    async def test_with_cart_coupon_discount(self, client):
        """cart_coupon_discount_amount should be included in the request."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50000,
            customer_email="a@b.com",
            cart_coupon_discount_amount=5000,
        )
        data = json.loads(result)
        assert data["status"] == "CREATED"
        call_args = client.post.call_args
        payload = call_args[0][1]
        assert "cart_coupon_discount_amount" in payload

    @pytest.mark.asyncio
    async def test_pydantic_validation_error(self, client):
        """Invalid amount value should trigger pydantic validation error."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=-100,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"

    @pytest.mark.asyncio
    async def test_amount_validation_error(self, client):
        """Amount below minimum (100) is caught by the except block in Step 5."""
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["create_payment_link"](
            amount_value=50,
            customer_email="a@b.com",
        )
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"
        assert data["status_code"] == 422


# ---------------------------------------------------------------------------
# get_payment_link_by_id
# ---------------------------------------------------------------------------

class TestGetPaymentLinkById:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.get = AsyncMock(return_value={"payment_link_id": "pl-123", "status": "CREATED"})
        return c

    @pytest.mark.asyncio
    async def test_success(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="pl-123")
        data = json.loads(result)
        assert data["payment_link_id"] == "pl-123"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.get = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_id_too_long(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="x" * 51)
        data = json.loads(result)
        assert "error" in data
        assert "at most 50 characters" in data["error"]

    @pytest.mark.asyncio
    async def test_empty_id(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="")
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.get = AsyncMock(
            side_effect=PineLabsAPIError(404, "NOT_FOUND", "Not found")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="pl-bad")
        data = json.loads(result)
        assert data["code"] == "NOT_FOUND"

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.get = AsyncMock(side_effect=RuntimeError("timeout"))
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_id"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()
        assert "timeout" not in data["error"]


# ---------------------------------------------------------------------------
# get_payment_link_by_merchant_reference
# ---------------------------------------------------------------------------

class TestGetPaymentLinkByMerchantRef:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.get = AsyncMock(return_value={"merchant_ref": "ref-001", "status": "CREATED"})
        return c

    @pytest.mark.asyncio
    async def test_success(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference="ref-001"
        )
        data = json.loads(result)
        assert data["merchant_ref"] == "ref-001"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.get = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference="ref-001"
        )
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_ref_too_long(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference="x" * 51
        )
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_empty_ref(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference=""
        )
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.get = AsyncMock(
            side_effect=PineLabsAPIError(404, "NOT_FOUND", "Not found")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference="ref-bad"
        )
        data = json.loads(result)
        assert data["code"] == "NOT_FOUND"

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.get = AsyncMock(side_effect=RuntimeError("boom"))
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["get_payment_link_by_merchant_reference"](
            merchant_payment_link_reference="ref-001"
        )
        data = json.loads(result)
        assert "error" in data


# ---------------------------------------------------------------------------
# cancel_payment_link
# ---------------------------------------------------------------------------

class TestCancelPaymentLink:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.put = AsyncMock(return_value={"payment_link_id": "pl-123", "status": "CANCELLED"})
        return c

    @pytest.mark.asyncio
    async def test_success(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="pl-123")
        data = json.loads(result)
        assert data["status"] == "CANCELLED"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.put = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_id_too_long(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="x" * 51)
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_empty_id(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="")
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.put = AsyncMock(
            side_effect=PineLabsAPIError(409, "CONFLICT", "Cannot cancel")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="pl-123")
        data = json.loads(result)
        assert data["code"] == "CONFLICT"

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.put = AsyncMock(side_effect=RuntimeError("connection refused"))
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["cancel_payment_link"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data


# ---------------------------------------------------------------------------
# resend_payment_link_notification
# ---------------------------------------------------------------------------

class TestResendPaymentLinkNotification:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.patch = AsyncMock(return_value={"payment_link_id": "pl-123", "status": "CREATED"})
        return c

    @pytest.mark.asyncio
    async def test_success(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="pl-123")
        data = json.loads(result)
        assert data["status"] == "CREATED"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.patch = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_id_too_long(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="x" * 51)
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_empty_id(self, client):
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="")
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.patch = AsyncMock(
            side_effect=PineLabsAPIError(400, "EXPIRED", "Link expired")
        )
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="pl-123")
        data = json.loads(result)
        assert data["code"] == "EXPIRED"

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.patch = AsyncMock(side_effect=RuntimeError("network down"))
        tools = _make_mcp_and_register_payment_tools(client)
        result = await tools["resend_payment_link_notification"](payment_link_id="pl-123")
        data = json.loads(result)
        assert "error" in data


# ---------------------------------------------------------------------------
# get_order_by_order_id
# ---------------------------------------------------------------------------

class TestGetOrderByOrderId:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.get = AsyncMock(return_value={"order_id": "ord-1", "status": "PROCESSED"})
        return c

    @pytest.mark.asyncio
    async def test_success(self, client):
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="ord-1")
        data = json.loads(result)
        assert data["order_id"] == "ord-1"
        assert data["status"] == "PROCESSED"

    @pytest.mark.asyncio
    async def test_missing_auth(self, client):
        client.get = AsyncMock(
            side_effect=RuntimeError("Client credentials not configured")
        )
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="ord-1")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_api_error(self, client):
        client.get = AsyncMock(
            side_effect=PineLabsAPIError(404, "NOT_FOUND", "Order not found")
        )
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="ord-bad")
        data = json.loads(result)
        assert data["code"] == "NOT_FOUND"
        assert data["status_code"] == 404

    @pytest.mark.asyncio
    async def test_unexpected_error(self, client):
        client.get = AsyncMock(side_effect=RuntimeError("dns failure"))
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="ord-1")
        data = json.loads(result)
        assert "error" in data
        assert "internal error" in data["error"].lower()
        assert "dns failure" not in data["error"]

    @pytest.mark.asyncio
    async def test_invalid_order_id(self, client):
        """Order ID with unsafe characters triggers validation error."""
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="ord/bad;id")
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"

    @pytest.mark.asyncio
    async def test_empty_order_id(self, client):
        """Empty order ID triggers validation error."""
        tools = _make_mcp_and_register_order_tools(client)
        result = await tools["get_order_by_order_id"](order_id="")
        data = json.loads(result)
        assert "error" in data


# ==========================================================================
# Refund Tools
# ==========================================================================

from tools.refunds import register_refund_tools


def _make_mcp_and_register_refund_tools(client):
    """Create a mock MCP, register refund tools, return the captured tool functions."""
    tools = {}

    class FakeMCP:
        def tool(self, name, description):
            def decorator(fn):
                tools[name] = fn
                return fn
            return decorator

    mcp = FakeMCP()
    register_refund_tools(mcp, client)
    return tools


# ---------------------------------------------------------------------------
# create_refund
# ---------------------------------------------------------------------------

@pytest.mark.skip(reason="create_refund tool is disabled")
class TestCreateRefund:
    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.post = AsyncMock(return_value={
            "order_id": "ref-1",
            "parent_order_id": "ord-1",
            "status": "PROCESSED",
            "type": "REFUND",
        })
        return c

    # -----------------------------------------------------------------------
    # Happy path
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_success_full_refund_minimal(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-min")
        data = json.loads(result)
        assert data["status"] == "PROCESSED"
        assert data["type"] == "REFUND"
        client.post.assert_awaited_once()
        path_arg = client.post.call_args[0][0]
        assert path_arg == "/pay/v1/refunds/ord-1"

    @pytest.mark.asyncio
    async def test_success_full_refund_all_fields(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=100000,
            currency="INR",
            merchant_order_reference="my-ref-001",
            merchant_metadata={"key1": "DD"},
        )
        data = json.loads(result)
        assert data["status"] == "PROCESSED"
        payload_arg = client.post.call_args[0][1]
        assert payload_arg["merchant_order_reference"] == "my-ref-001"
        assert payload_arg["merchant_metadata"] == {"key1": "DD"}
        assert "order_amount" in payload_arg

    @pytest.mark.asyncio
    async def test_custom_currency(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-cur", currency="USD")
        payload_arg = client.post.call_args[0][1]
        assert payload_arg["order_amount"]["currency"] == "USD"

    # -----------------------------------------------------------------------
    # order_id validation (F-001)
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_invalid_order_id_path_traversal(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="../admin", amount_value=50000, merchant_order_reference="ref-1")
        data = json.loads(result)
        assert "error" in data
        assert "order_id" in data["error"]

    @pytest.mark.asyncio
    async def test_invalid_order_id_empty(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="", amount_value=50000, merchant_order_reference="ref-1")
        data = json.loads(result)
        assert "error" in data
        assert "order_id" in data["error"]

    @pytest.mark.asyncio
    async def test_invalid_order_id_special_chars(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord?id=1", amount_value=50000, merchant_order_reference="ref-1")
        data = json.loads(result)
        assert "error" in data
        assert "order_id" in data["error"]

    # -----------------------------------------------------------------------
    # Multi-cart partial refund (products)
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_with_products(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=10000,
            merchant_order_reference="ref-prod",
            products=[{
                "product_code": "SM-S908",
                "product_imei": "123456789",
                "product_amount_value": 10000,
                "product_amount_currency": "INR",
            }],
        )
        data = json.loads(result)
        assert data["status"] == "PROCESSED"
        payload_arg = client.post.call_args[0][1]
        assert "products" in payload_arg
        assert len(payload_arg["products"]) == 1
        product = payload_arg["products"][0]
        assert product["product_code"] == "SM-S908"
        assert product["product_imei"] == "123456789"
        assert "product_amount" in product

    @pytest.mark.asyncio
    async def test_with_products_no_amount(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](
            order_id="ord-1",
            amount_value=10000,
            merchant_order_reference="ref-pna",
            products=[{"product_code": "X", "product_imei": "Y"}],
        )
        payload_arg = client.post.call_args[0][1]
        assert "products" in payload_arg
        product = payload_arg["products"][0]
        # product_amount is None so excluded by model_dump(exclude_none=True)
        assert "product_amount" not in product

    @pytest.mark.asyncio
    async def test_with_multiple_products(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](
            order_id="ord-1",
            amount_value=20000,
            merchant_order_reference="ref-mp",
            products=[
                {"product_code": "A", "product_imei": "1"},
                {"product_code": "B", "product_imei": "2"},
            ],
        )
        payload_arg = client.post.call_args[0][1]
        assert len(payload_arg["products"]) == 2

    @pytest.mark.asyncio
    async def test_invalid_product_missing_product_code(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=10000,
            merchant_order_reference="ref-ipc",
            products=[{"product_imei": "123"}],
        )
        data = json.loads(result)
        assert "error" in data
        assert "Invalid product data" in data["error"]

    @pytest.mark.asyncio
    async def test_product_without_imei_is_valid(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=10000,
            merchant_order_reference="ref-ipi",
            products=[{"product_code": "X"}],
        )
        data = json.loads(result)
        assert data["status"] == "PROCESSED"

    # -----------------------------------------------------------------------
    # Split settlement refund
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_with_split_info(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=20000,
            merchant_order_reference="ref-si",
            split_type="AMOUNT",
            split_details=[{
                "parent_order_split_settlement_id": "ss-1",
                "split_merchant_id": "m-1",
                "merchant_settlement_reference": "msr-1",
                "amount_value": 20000,
                "amount_currency": "INR",
                "status": "DO_NOT_RECOVER",
            }],
        )
        data = json.loads(result)
        assert data["status"] == "PROCESSED"
        payload_arg = client.post.call_args[0][1]
        assert "split_info" in payload_arg
        assert payload_arg["split_info"]["split_type"] == "AMOUNT"
        assert len(payload_arg["split_info"]["split_details"]) == 1

    @pytest.mark.asyncio
    async def test_with_split_type_only_no_details(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](
            order_id="ord-1",
            amount_value=20000,
            merchant_order_reference="ref-stnd",
            split_type="AMOUNT",
        )
        payload_arg = client.post.call_args[0][1]
        assert "split_info" in payload_arg
        assert payload_arg["split_info"]["split_type"] == "AMOUNT"
        assert "split_details" not in payload_arg["split_info"]

    @pytest.mark.asyncio
    async def test_split_detail_without_amount(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](
            order_id="ord-1",
            amount_value=20000,
            merchant_order_reference="ref-sdna",
            split_type="AMOUNT",
            split_details=[{
                "parent_order_split_settlement_id": "ss-1",
                "split_merchant_id": "m-1",
                "merchant_settlement_reference": "msr-1",
            }],
        )
        payload_arg = client.post.call_args[0][1]
        split_detail = payload_arg["split_info"]["split_details"][0]
        # amount is None so excluded by model_dump(exclude_none=True)
        assert "amount" not in split_detail

    @pytest.mark.asyncio
    async def test_invalid_split_detail_missing_required_field(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1",
            amount_value=20000,
            merchant_order_reference="ref-ismr",
            split_type="AMOUNT",
            split_details=[{"split_merchant_id": "m-1"}],
        )
        data = json.loads(result)
        assert "error" in data
        assert "Invalid split detail data" in data["error"]

    @pytest.mark.asyncio
    async def test_multiple_split_details(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](
            order_id="ord-1",
            amount_value=40000,
            merchant_order_reference="ref-msd",
            split_type="AMOUNT",
            split_details=[
                {
                    "parent_order_split_settlement_id": "ss-1",
                    "split_merchant_id": "m-1",
                    "merchant_settlement_reference": "msr-1",
                    "amount_value": 20000,
                },
                {
                    "parent_order_split_settlement_id": "ss-2",
                    "split_merchant_id": "m-2",
                    "merchant_settlement_reference": "msr-2",
                    "amount_value": 20000,
                },
            ],
        )
        payload_arg = client.post.call_args[0][1]
        assert len(payload_arg["split_info"]["split_details"]) == 2

    # -----------------------------------------------------------------------
    # Validation errors
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_amount_below_minimum(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50, merchant_order_reference="ref-abm")
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"
        assert data["status_code"] == 422

    @pytest.mark.asyncio
    async def test_amount_above_maximum(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=100_000_001, merchant_order_reference="ref-aam")
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "VALIDATION_ERROR"
        assert data["status_code"] == 422

    # -----------------------------------------------------------------------
    # API errors
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_api_error_400(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(400, "BAD_REQUEST", "Invalid refund")
        )
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-400")
        data = json.loads(result)
        assert data["code"] == "BAD_REQUEST"
        assert data["status_code"] == 400
        assert "error" in data

    @pytest.mark.asyncio
    async def test_api_error_404_order_not_found(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(404, "NOT_FOUND", "Order not found")
        )
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-404")
        data = json.loads(result)
        assert data["code"] == "NOT_FOUND"
        assert data["status_code"] == 404

    @pytest.mark.asyncio
    async def test_api_error_409_already_refunded(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(409, "CONFLICT", "Order already fully refunded")
        )
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-409")
        data = json.loads(result)
        assert data["code"] == "CONFLICT"
        assert data["status_code"] == 409

    @pytest.mark.asyncio
    async def test_api_error_422(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(422, "UNPROCESSABLE", "Refund exceeds order amount")
        )
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-422")
        data = json.loads(result)
        assert data["code"] == "UNPROCESSABLE"
        assert data["status_code"] == 422

    @pytest.mark.asyncio
    async def test_api_error_500(self, client):
        client.post = AsyncMock(
            side_effect=PineLabsAPIError(500, "INTERNAL", "Server error")
        )
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-500")
        data = json.loads(result)
        assert data["code"] == "INTERNAL"
        assert data["status_code"] == 500

    # -----------------------------------------------------------------------
    # Unexpected errors
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_unexpected_runtime_error(self, client):
        client.post = AsyncMock(side_effect=RuntimeError("connection lost"))
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-rte")
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "INTERNAL_ERROR"
        assert data["status_code"] == 500

    @pytest.mark.asyncio
    async def test_unexpected_timeout_error(self, client):
        client.post = AsyncMock(side_effect=TimeoutError("timed out"))
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-toe")
        data = json.loads(result)
        assert "error" in data
        assert data["code"] == "INTERNAL_ERROR"
        assert data["status_code"] == 500

    # -----------------------------------------------------------------------
    # Payload verification
    # -----------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_correct_api_path(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](order_id="v1-123-aa-xyz", amount_value=50000, merchant_order_reference="ref-path")
        path_arg = client.post.call_args[0][0]
        assert path_arg == "/pay/v1/refunds/v1-123-aa-xyz"

    @pytest.mark.asyncio
    async def test_client_post_receives_path_and_payload_only(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](order_id="v1-123-aa-xyz", amount_value=50000, merchant_order_reference="ref-tok")
        args = client.post.call_args[0]
        assert args[0] == "/pay/v1/refunds/v1-123-aa-xyz"
        assert isinstance(args[1], dict)
        # idempotency_key defaults to None when not provided
        assert args[2] is None

    @pytest.mark.asyncio
    async def test_payload_excludes_none_fields(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        await tools["create_refund"](order_id="ord-1", amount_value=50000, merchant_order_reference="ref-excl")
        payload_arg = client.post.call_args[0][1]
        assert "products" not in payload_arg
        assert "split_info" not in payload_arg
        assert "merchant_metadata" not in payload_arg


@pytest.mark.skip(reason="create_refund tool is disabled")
class TestRefundEdgeCases:
    """Phase 4 (F-034): edge-case tests at tool layer."""

    @pytest.fixture
    def client(self):
        c = PineLabsClient(base_url="https://fake.test/api", token_manager=_make_token_manager())
        c.post = AsyncMock(return_value={
            "order_id": "ref-1",
            "parent_order_id": "ord-1",
            "status": "PROCESSED",
            "type": "REFUND",
        })
        return c

    @pytest.mark.asyncio
    async def test_whitespace_order_id_rejected(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="   ", amount_value=50000, merchant_order_reference="ref-ws")
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_order_id_with_special_chars_rejected(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](order_id="ord/../etc", amount_value=50000, merchant_order_reference="ref-sp")
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_empty_products_list_treated_as_none(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1", amount_value=50000, merchant_order_reference="ref-ep",
            products=[]
        )
        payload_arg = client.post.call_args[0][1]
        assert "products" not in payload_arg

    @pytest.mark.asyncio
    async def test_empty_split_details_treated_as_none(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        result = await tools["create_refund"](
            order_id="ord-1", amount_value=50000, merchant_order_reference="ref-esd",
            split_type="AMOUNT", split_details=[]
        )
        payload_arg = client.post.call_args[0][1]
        split_info = payload_arg.get("split_info", {})
        assert split_info.get("split_details") is None or "split_details" not in split_info

    @pytest.mark.asyncio
    async def test_order_id_max_length_accepted(self, client):
        client.post = AsyncMock(return_value={"status": "PROCESSED"})
        tools = _make_mcp_and_register_refund_tools(client)
        long_id = "a" * 100
        result = await tools["create_refund"](order_id=long_id, amount_value=50000, merchant_order_reference="ref-long")
        data = json.loads(result)
        assert "error" not in data

    @pytest.mark.asyncio
    async def test_order_id_over_max_length_rejected(self, client):
        tools = _make_mcp_and_register_refund_tools(client)
        long_id = "a" * 101
        result = await tools["create_refund"](order_id=long_id, amount_value=50000, merchant_order_reference="ref-toolong")
        data = json.loads(result)
        assert "error" in data
