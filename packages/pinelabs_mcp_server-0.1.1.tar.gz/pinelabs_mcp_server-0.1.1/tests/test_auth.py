"""Tests for shared authentication utilities."""

import pytest

from utils.auth import extract_bearer_token


class TestSharedExtractBearerToken:
    def test_valid_token(self):
        token = extract_bearer_token({"authorization": "Bearer abc123"})
        assert token == "abc123"

    def test_missing_header(self):
        with pytest.raises(ValueError, match="Missing or invalid Authorization"):
            extract_bearer_token({})

    def test_empty_header(self):
        with pytest.raises(ValueError, match="Missing or invalid Authorization"):
            extract_bearer_token({"authorization": ""})

    def test_no_bearer_prefix(self):
        with pytest.raises(ValueError, match="Missing or invalid Authorization"):
            extract_bearer_token({"authorization": "Token abc"})

    def test_bearer_only_whitespace(self):
        with pytest.raises(ValueError, match="Missing or invalid Authorization"):
            extract_bearer_token({"authorization": "Bearer   "})

    def test_case_sensitive_bearer(self):
        with pytest.raises(ValueError, match="Missing or invalid Authorization"):
            extract_bearer_token({"authorization": "bearer abc123"})

    def test_token_with_special_chars(self):
        token = extract_bearer_token({"authorization": "Bearer eyJ0eXAi.abc.def"})
        assert token == "eyJ0eXAi.abc.def"
