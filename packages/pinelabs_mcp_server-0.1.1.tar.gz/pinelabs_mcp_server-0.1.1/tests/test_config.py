"""Tests for config.py — Settings and Environment."""

import os
from unittest.mock import patch

import pytest

from config import Environment, BASE_URLS, Settings


class TestEnvironmentEnum:
    def test_uat(self):
        assert Environment.UAT.value == "uat"

    def test_prod(self):
        assert Environment.PROD.value == "prod"


class TestBaseURLs:
    def test_uat_url(self):
        assert "pluraluat" in BASE_URLS[Environment.UAT]

    def test_prod_url(self):
        assert "pluralpay" in BASE_URLS[Environment.PROD]


class TestSettings:
    @patch.dict(os.environ, {
        "PINELABS_ENV": "uat",
        "PORT": "9000",
        "HOST": "127.0.0.1",
        "LOG_LEVEL": "debug",
    }, clear=True)
    def test_uat_settings(self):
        s = Settings()
        assert s.environment == Environment.UAT
        assert s.base_url == BASE_URLS[Environment.UAT]
        assert s.port == 9000
        assert s.host == "127.0.0.1"
        assert s.log_level == "DEBUG"

    @patch.dict(os.environ, {"PINELABS_ENV": "prod"}, clear=True)
    def test_prod_settings(self):
        s = Settings()
        assert s.environment == Environment.PROD
        assert s.base_url == BASE_URLS[Environment.PROD]

    @patch.dict(os.environ, {"PINELABS_ENV": "invalid_env_value"}, clear=True)
    def test_invalid_env_falls_back_to_uat(self):
        s = Settings()
        assert s.environment == Environment.UAT

    @patch.dict(os.environ, {
        "PINELABS_BASE_URL": "https://custom.url/api",
    }, clear=False)
    def test_custom_base_url_override(self):
        s = Settings()
        assert s.base_url == "https://custom.url/api"

    @patch.dict(os.environ, {}, clear=True)
    def test_all_defaults(self):
        # With completely empty env, should get sane defaults
        s = Settings()
        assert s.environment == Environment.UAT
        assert s.port == 8000
        assert s.host == "0.0.0.0"
        assert s.log_level == "INFO"
        assert s.base_url == BASE_URLS[Environment.UAT]

    @patch.dict(os.environ, {"PINELABS_ENV": "UAT"}, clear=True)
    def test_uppercase_env_is_lowered(self):
        s = Settings()
        assert s.environment == Environment.UAT

    @patch.dict(os.environ, {"LOG_LEVEL": "WARNING"}, clear=True)
    def test_log_level_uppercased(self):
        s = Settings()
        assert s.log_level == "WARNING"

    @patch.dict(os.environ, {"HTTP_TIMEOUT": "15.0"}, clear=True)
    def test_http_timeout_from_env(self):
        s = Settings()
        assert s.http_timeout == 15.0

    @patch.dict(os.environ, {}, clear=True)
    def test_http_timeout_default(self):
        s = Settings()
        assert s.http_timeout == 30.0

    @patch.dict(os.environ, {"LOG_FORMAT": "json"}, clear=True)
    def test_log_format_json(self):
        s = Settings()
        assert s.log_format == "json"

    @patch.dict(os.environ, {}, clear=True)
    def test_log_format_default(self):
        s = Settings()
        assert s.log_format == "text"

    @patch.dict(os.environ, {}, clear=True)
    def test_redis_defaults(self):
        s = Settings()
        assert s.redis_host == "localhost"
        assert s.redis_port == 6379
        assert s.redis_db == 0
        assert s.redis_max_connections == 50
        assert s.redis_token_ttl_seconds == 3000

    @patch.dict(os.environ, {
        "REDIS_HOST": "custom-redis.example.com",
        "REDIS_PORT": "6380",
        "REDIS_DB": "2",
        "REDIS_MAX_CONNECTIONS": "100",
        "REDIS_TOKEN_TTL_SECONDS": "1800",
    }, clear=True)
    def test_redis_custom_values(self):
        s = Settings()
        assert s.redis_host == "custom-redis.example.com"
        assert s.redis_port == 6380
        assert s.redis_db == 2
        assert s.redis_max_connections == 100
        assert s.redis_token_ttl_seconds == 1800
