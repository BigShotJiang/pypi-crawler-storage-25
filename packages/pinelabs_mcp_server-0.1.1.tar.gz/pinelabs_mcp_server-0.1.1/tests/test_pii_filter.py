"""Tests for utils/pii_filter.py — PII masking functions and configuration."""

import logging
import os
import re
import tempfile
from unittest.mock import patch

import pytest
import yaml

from utils.pii_filter import (
    _mask_email,
    _mask_name,
    _mask_phone,
    _mask_id,
    _mask_address,
    _mask_redact,
    _get_mask_strategy,
    filter_pii,
    load_pii_config,
    strip_sensitive_keys,
    PII_STRIP_KEYS,
)


# ---------------------------------------------------------------------------
# Individual masking strategies
# ---------------------------------------------------------------------------


class TestMaskEmail:
    def test_standard_email(self):
        assert _mask_email("john@example.com") == "j***@e***.com"

    def test_non_string_returns_redacted(self):
        assert _mask_email(12345) == "[REDACTED]"

    def test_no_at_sign_returns_redacted(self):
        assert _mask_email("noemail") == "[REDACTED]"

    def test_empty_local_part(self):
        result = _mask_email("@example.com")
        assert "***" in result

    def test_domain_without_dot(self):
        result = _mask_email("user@localhost")
        # domain has no dot → falls into single-part domain branch
        assert result == "u***@l***"

    def test_empty_domain_part_before_dot(self):
        result = _mask_email("user@.com")
        assert result == "u***@***.com"


class TestMaskName:
    def test_normal_name(self):
        assert _mask_name("Kevin") == "K***"

    def test_none_returns_redacted(self):
        assert _mask_name(None) == "[REDACTED]"

    def test_empty_string_returns_redacted(self):
        assert _mask_name("") == "[REDACTED]"

    def test_integer_value(self):
        assert _mask_name(42) == "4***"


class TestMaskPhone:
    def test_standard_phone(self):
        assert _mask_phone("9876543210") == "******3210"

    def test_none_returns_redacted(self):
        assert _mask_phone(None) == "[REDACTED]"

    def test_empty_string_returns_redacted(self):
        assert _mask_phone("") == "[REDACTED]"

    def test_short_phone(self):
        assert _mask_phone("1234") == "****"

    def test_integer_phone(self):
        result = _mask_phone(9876543210)
        assert result.endswith("3210")


class TestMaskId:
    def test_standard_id(self):
        assert _mask_id("123456") == "****56"

    def test_none_returns_redacted(self):
        assert _mask_id(None) == "[REDACTED]"

    def test_empty_string_returns_redacted(self):
        assert _mask_id("") == "[REDACTED]"

    def test_short_id(self):
        assert _mask_id("AB") == "****"

    def test_integer_id(self):
        assert _mask_id(789) == "*89"


class TestMaskAddress:
    def test_standard_address(self):
        assert _mask_address("10 Downing Street") == "10 ***"

    def test_non_string_returns_redacted(self):
        assert _mask_address(None) == "[REDACTED]"

    def test_empty_string_returns_redacted(self):
        assert _mask_address("") == "[REDACTED]"

    def test_single_word_address(self):
        assert _mask_address("Mumbai") == "***"


class TestMaskRedact:
    def test_any_value_returns_redacted(self):
        assert _mask_redact("secret") == "[REDACTED]"

    def test_none_returns_redacted(self):
        assert _mask_redact(None) == "[REDACTED]"

    def test_integer_returns_redacted(self):
        assert _mask_redact(42) == "[REDACTED]"


# ---------------------------------------------------------------------------
# Configuration loading
# ---------------------------------------------------------------------------


class TestLoadPiiConfig:
    def test_load_from_valid_yaml(self):
        config = {
            "pii_fields": [
                {"pattern": "email", "strategy": "email"},
                {"pattern": "phone", "strategy": "phone"},
            ]
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            yaml.dump(config, f)
            f.flush()
            load_pii_config(f.name)

        # Verify rules were loaded — email field should match
        assert _get_mask_strategy("email") == "email"
        assert _get_mask_strategy("phone") == "phone"
        os.unlink(f.name)

    def test_missing_config_file(self, caplog):
        with caplog.at_level(logging.WARNING):
            load_pii_config("/nonexistent/path/config.yaml")
        assert "not found" in caplog.text
        # Should fall back to built-in default rules, not disable filtering
        assert _get_mask_strategy("first_name") == "name"
        assert _get_mask_strategy("mobile_number") == "phone"
        assert _get_mask_strategy("country_code") == "redact"

    def test_unknown_strategy_defaults_to_redact(self, caplog):
        config = {
            "pii_fields": [
                {"pattern": "secret_field", "strategy": "unknown_strategy"},
            ]
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            yaml.dump(config, f)
            f.flush()
            with caplog.at_level(logging.WARNING):
                load_pii_config(f.name)

        assert "Unknown masking strategy" in caplog.text
        # Should still be loaded with 'redact' instead
        assert _get_mask_strategy("secret_field") == "redact"
        os.unlink(f.name)

    def test_invalid_regex_pattern_skipped(self, caplog):
        config = {
            "pii_fields": [
                {"pattern": "[invalid(", "strategy": "email"},
            ]
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            yaml.dump(config, f)
            f.flush()
            with caplog.at_level(logging.WARNING):
                load_pii_config(f.name)

        assert "Invalid regex" in caplog.text
        os.unlink(f.name)

    def test_empty_yaml_file(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write("")
            f.flush()
            load_pii_config(f.name)
        # Should not crash — no rules loaded
        os.unlink(f.name)


# ---------------------------------------------------------------------------
# filter_pii
# ---------------------------------------------------------------------------


class TestFilterPii:
    @pytest.fixture(autouse=True)
    def _load_config(self):
        """Load a test PII config before each test in this class."""
        config = {
            "pii_fields": [
                {"pattern": "email_id|email", "strategy": "email"},
                {"pattern": "first_name|last_name", "strategy": "name"},
                {"pattern": "mobile_number", "strategy": "phone"},
                {"pattern": "customer_id", "strategy": "id"},
                {"pattern": "address1", "strategy": "address"},
                {"pattern": "pincode", "strategy": "redact"},
            ]
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            yaml.dump(config, f)
            f.flush()
            load_pii_config(f.name)
        yield
        os.unlink(f.name)

    def test_masks_email_field(self):
        data = {"email_id": "john@example.com", "status": "CREATED"}
        result = filter_pii(data)
        assert result["email_id"] == "j***@e***.com"
        assert result["status"] == "CREATED"

    def test_masks_name_field(self):
        data = {"first_name": "Kevin"}
        result = filter_pii(data)
        assert result["first_name"] == "K***"

    def test_masks_phone_field(self):
        data = {"mobile_number": "9876543210"}
        result = filter_pii(data)
        assert result["mobile_number"] == "******3210"

    def test_masks_id_field(self):
        data = {"customer_id": "CUST123"}
        result = filter_pii(data)
        assert result["customer_id"] == "*****23"

    def test_masks_address_field(self):
        data = {"address1": "10 Downing Street"}
        result = filter_pii(data)
        assert result["address1"] == "10 ***"

    def test_redacts_pincode(self):
        data = {"pincode": "400001"}
        result = filter_pii(data)
        assert result["pincode"] == "[REDACTED]"

    def test_nested_dict(self):
        data = {
            "customer": {
                "first_name": "Alice",
                "email_id": "alice@test.com",
            }
        }
        result = filter_pii(data)
        assert result["customer"]["first_name"] == "A***"
        assert result["customer"]["email_id"] == "a***@t***.com"

    def test_list_of_dicts(self):
        data = [{"first_name": "Bob"}, {"first_name": "Eve"}]
        result = filter_pii(data)
        assert result[0]["first_name"] == "B***"
        assert result[1]["first_name"] == "E***"

    def test_primitive_passthrough(self):
        assert filter_pii("hello") == "hello"
        assert filter_pii(42) == 42
        assert filter_pii(None) is None

    def test_pii_field_with_nested_dict_value_recurses(self):
        """If a PII field key has a dict value, it should recurse, not mask."""
        data = {"first_name": {"nested": "value"}}
        result = filter_pii(data)
        # The dict should be recursed into, not masked
        assert isinstance(result["first_name"], dict)

    def test_not_initialized_warning(self, caplog):
        """If _initialized is False, filter_pii returns data unfiltered."""
        import utils.pii_filter as pii_mod

        original = pii_mod._initialized
        pii_mod._initialized = False
        try:
            with caplog.at_level(logging.WARNING):
                result = filter_pii({"email_id": "test@test.com"})
            assert result["email_id"] == "test@test.com"
            assert "not initialized" in caplog.text
        finally:
            pii_mod._initialized = original


# ---------------------------------------------------------------------------
# strip_sensitive_keys
# ---------------------------------------------------------------------------

class TestStripSensitiveKeys:
    def test_strips_utr_number_from_flat_dict(self):
        data = {"utr_number": "410092786849", "total_amount": 50000}
        result = strip_sensitive_keys(data, PII_STRIP_KEYS)
        assert "utr_number" not in result
        assert result["total_amount"] == 50000

    def test_strips_utr_number_from_nested_list(self):
        data = {
            "data": [
                {"utr_number": "410092786849", "total_amount": 50000},
                {"utr_number": "999999999999", "total_amount": 30000},
            ]
        }
        result = strip_sensitive_keys(data, PII_STRIP_KEYS)
        for item in result["data"]:
            assert "utr_number" not in item
            assert "total_amount" in item

    def test_strips_bank_fields(self):
        data = {
            "bank_acc_number": "1234567890",
            "bank_name": "HDFC",
            "bank_ifsc_code": "HDFC0001234",
            "total_amount": 100,
        }
        result = strip_sensitive_keys(data, PII_STRIP_KEYS)
        assert "bank_acc_number" not in result
        assert "bank_name" not in result
        assert "bank_ifsc_code" not in result
        assert result["total_amount"] == 100

    def test_strips_deeply_nested_keys(self):
        data = {
            "settlement": {
                "details": {
                    "utr_number": "410092786849",
                    "status": "SETTLED",
                }
            }
        }
        result = strip_sensitive_keys(data, PII_STRIP_KEYS)
        assert "utr_number" not in result["settlement"]["details"]
        assert result["settlement"]["details"]["status"] == "SETTLED"

    def test_preserves_non_sensitive_keys(self):
        data = {"order_id": "v1-123", "status": "PROCESSED", "amount": 5000}
        result = strip_sensitive_keys(data, PII_STRIP_KEYS)
        assert result == data

    def test_handles_primitive_input(self):
        assert strip_sensitive_keys("hello", PII_STRIP_KEYS) == "hello"
        assert strip_sensitive_keys(42, PII_STRIP_KEYS) == 42
        assert strip_sensitive_keys(None, PII_STRIP_KEYS) is None

    def test_utr_number_in_pii_strip_keys(self):
        """Verify utr_number is present in the centralized PII_STRIP_KEYS set."""
        assert "utr_number" in PII_STRIP_KEYS

