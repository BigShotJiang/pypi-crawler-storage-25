"""Tests for utils/tracing.py — OpenTelemetry tracing setup."""

from unittest.mock import patch, MagicMock

import pytest
from opentelemetry import trace

from utils.tracing import init_tracing, get_tracer, reset_tracing_state


class TestInitTracing:
    """Tests for init_tracing initialization."""

    def setup_method(self):
        reset_tracing_state()

    def teardown_method(self):
        reset_tracing_state()

    def test_init_without_endpoint(self):
        """When no OTLP endpoint is configured, tracing initializes without error."""
        init_tracing(service_name="test-svc")
        tracer = get_tracer("test")
        assert tracer is not None

    def test_init_with_console_export(self):
        """Console export mode should initialize without error."""
        init_tracing(service_name="test-console", console_export=True)
        tracer = get_tracer("test")
        assert tracer is not None

    @patch("utils.tracing.OTLPSpanExporter")
    @patch("utils.tracing.BatchSpanProcessor")
    def test_init_with_otlp_endpoint(self, mock_bsp, mock_exporter):
        """When OTLP endpoint is provided, exporter and processor are created."""
        init_tracing(
            service_name="test-otlp",
            otlp_endpoint="http://localhost:4317",
        )
        mock_exporter.assert_called_once_with(
            endpoint="http://localhost:4317", insecure=True
        )
        mock_bsp.assert_called_once()

    def test_init_idempotent(self):
        """Calling init_tracing multiple times only initializes once."""
        init_tracing(service_name="test-idem")
        # Second call should be a no-op
        with patch("utils.tracing.TracerProvider") as mock_provider:
            init_tracing(service_name="test-idem-2")
            mock_provider.assert_not_called()

    def test_sample_rate(self):
        """Custom sample rate should be accepted."""
        init_tracing(service_name="test-rate", sample_rate=0.5)
        tracer = get_tracer("test")
        assert tracer is not None

    def test_reset_allows_reinit(self):
        """After reset, init_tracing should work again."""
        init_tracing(service_name="test-reset-1")
        reset_tracing_state()
        # Should not raise
        init_tracing(service_name="test-reset-2")


class TestGetTracer:
    """Tests for get_tracer."""

    def test_returns_tracer(self):
        tracer = get_tracer("my-component")
        assert tracer is not None

    def test_default_name(self):
        tracer = get_tracer()
        assert tracer is not None

    def test_tracer_creates_span(self):
        reset_tracing_state()
        init_tracing(service_name="test-span")
        tracer = get_tracer("test")
        with tracer.start_as_current_span("test-operation") as span:
            assert span is not None
            span.set_attribute("test.key", "test-value")
        reset_tracing_state()
