"""Tests for PineLabsClient in clients/pinelabs_client.py."""

import json
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import respx

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError, _normalize_path
from utils.circuit_breaker import CircuitBreaker


BASE_URL = "https://fake.pinelabs.test/api"
TOKEN = "test-token-xyz"


def _make_token_manager() -> MagicMock:
    """Create a token manager stub returning a stable token for tests."""
    manager = MagicMock()
    manager.get_access_token = AsyncMock(return_value=TOKEN)
    return manager


def _make_client(max_retries: int = 0, base_backoff: float = 0.0) -> PineLabsClient:
    """Create a PineLabsClient with a lenient circuit breaker for testing."""
    cb = CircuitBreaker(fail_max=100, reset_timeout=1, name="test_cb")
    return PineLabsClient(
        base_url=BASE_URL,
        token_manager=_make_token_manager(),
        max_retries=max_retries,
        base_backoff=base_backoff,
        circuit_breaker=cb,
    )


# ---------------------------------------------------------------------------
# PineLabsAPIError
# ---------------------------------------------------------------------------

class TestPineLabsAPIError:
    def test_error_message(self):
        err = PineLabsAPIError(
            status_code=400,
            code="INVALID_REQUEST",
            message="Bad request",
            payload={"detail": "missing field"},
        )
        assert err.status_code == 400
        assert err.code == "INVALID_REQUEST"
        assert err.message == "Bad request"
        assert err.payload == {"detail": "missing field"}
        assert "[400] INVALID_REQUEST: Bad request" in str(err)

    def test_error_default_payload(self):
        err = PineLabsAPIError(status_code=500, code="ERR", message="fail")
        assert err.payload == {}


# ---------------------------------------------------------------------------
# _build_headers
# ---------------------------------------------------------------------------

class TestBuildHeaders:
    def test_headers_contain_auth(self, pinelabs_client):
        headers = pinelabs_client._build_headers(TOKEN)
        assert headers["Authorization"] == f"Bearer {TOKEN}"

    def test_headers_contain_content_type(self, pinelabs_client):
        headers = pinelabs_client._build_headers(TOKEN)
        assert headers["Content-Type"] == "application/json"

    def test_headers_contain_request_id(self, pinelabs_client):
        headers = pinelabs_client._build_headers(TOKEN)
        assert "Request-ID" in headers
        # UUID4 format check
        parts = headers["Request-ID"].split("-")
        assert len(parts) == 5

    def test_headers_contain_timestamp(self, pinelabs_client):
        headers = pinelabs_client._build_headers(TOKEN)
        assert "Request-Timestamp" in headers
        assert headers["Request-Timestamp"].endswith("Z")

    def test_request_id_unique(self, pinelabs_client):
        h1 = pinelabs_client._build_headers(TOKEN)
        h2 = pinelabs_client._build_headers(TOKEN)
        assert h1["Request-ID"] != h2["Request-ID"]


# ---------------------------------------------------------------------------
# POST
# ---------------------------------------------------------------------------

class TestPost:
    @respx.mock
    @pytest.mark.asyncio
    async def test_post_success(self, pinelabs_client):
        expected = {"payment_link_id": "pl-123", "status": "CREATED"}
        respx.post(f"{BASE_URL}/pay/v1/paymentlink").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.post(
            "/pay/v1/paymentlink", {"amount": 50000}, TOKEN
        )
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_api_error_json(self, pinelabs_client):
        error_body = {
            "code": "INVALID_AMOUNT",
            "message": "Amount too low",
            "additionalErrorPayload": {"min": 100},
        }
        respx.post(f"{BASE_URL}/pay/v1/paymentlink").mock(
            return_value=httpx.Response(400, json=error_body)
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await pinelabs_client.post("/pay/v1/paymentlink", {}, TOKEN)
        assert exc_info.value.status_code == 400
        assert exc_info.value.code == "INVALID_AMOUNT"
        assert exc_info.value.payload == {"min": 100}

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_api_error_non_json(self, pinelabs_client):
        respx.post(f"{BASE_URL}/pay/v1/paymentlink").mock(
            return_value=httpx.Response(502, text="Bad Gateway")
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await pinelabs_client.post("/pay/v1/paymentlink", {}, TOKEN)
        assert exc_info.value.status_code == 502
        assert exc_info.value.code == "UNKNOWN_ERROR"


# ---------------------------------------------------------------------------
# GET
# ---------------------------------------------------------------------------

class TestGet:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_success(self, pinelabs_client):
        expected = {"payment_link_id": "pl-123", "status": "CREATED"}
        respx.get(f"{BASE_URL}/pay/v1/paymentlink/pl-123").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.get("/pay/v1/paymentlink/pl-123")
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_404(self, pinelabs_client):
        error_body = {"code": "NOT_FOUND", "message": "Payment link not found"}
        respx.get(f"{BASE_URL}/pay/v1/paymentlink/invalid").mock(
            return_value=httpx.Response(404, json=error_body)
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await pinelabs_client.get("/pay/v1/paymentlink/invalid")
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# PUT
# ---------------------------------------------------------------------------

class TestPut:
    @respx.mock
    @pytest.mark.asyncio
    async def test_put_success(self, pinelabs_client):
        expected = {"payment_link_id": "pl-123", "status": "CANCELLED"}
        respx.put(f"{BASE_URL}/pay/v1/paymentlink/pl-123/cancel").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.put("/pay/v1/paymentlink/pl-123/cancel")
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_put_with_payload(self, pinelabs_client):
        expected = {"ok": True}
        respx.put(f"{BASE_URL}/test/path").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.put("/test/path", {"key": "val"})
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_put_error(self, pinelabs_client):
        error_body = {"code": "INVALID_STATE", "message": "Cannot cancel"}
        respx.put(f"{BASE_URL}/pay/v1/paymentlink/pl-123/cancel").mock(
            return_value=httpx.Response(409, json=error_body)
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await pinelabs_client.put("/pay/v1/paymentlink/pl-123/cancel")
        assert exc_info.value.status_code == 409


# ---------------------------------------------------------------------------
# PATCH
# ---------------------------------------------------------------------------

class TestPatch:
    @respx.mock
    @pytest.mark.asyncio
    async def test_patch_success(self, pinelabs_client):
        expected = {"payment_link_id": "pl-123", "status": "CREATED"}
        respx.patch(f"{BASE_URL}/pay/v1/paymentlink/pl-123/notify").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.patch("/pay/v1/paymentlink/pl-123/notify")
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_patch_with_payload(self, pinelabs_client):
        expected = {"ok": True}
        respx.patch(f"{BASE_URL}/test/path").mock(
            return_value=httpx.Response(200, json=expected)
        )
        result = await pinelabs_client.patch("/test/path", {"data": "value"})
        assert result == expected

    @respx.mock
    @pytest.mark.asyncio
    async def test_patch_error(self, pinelabs_client):
        error_body = {"code": "EXPIRED", "message": "Link expired"}
        respx.patch(f"{BASE_URL}/pay/v1/paymentlink/pl-123/notify").mock(
            return_value=httpx.Response(400, json=error_body)
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await pinelabs_client.patch("/pay/v1/paymentlink/pl-123/notify")
        assert exc_info.value.status_code == 400


# ---------------------------------------------------------------------------
# _handle_response edge cases
# ---------------------------------------------------------------------------

class TestHandleResponse:
    def test_201_accepted(self, pinelabs_client):
        resp = httpx.Response(201, json={"id": "new"})
        result = PineLabsClient._handle_response(resp)
        assert result == {"id": "new"}

    def test_200_empty_json_body(self, pinelabs_client):
        """200 in 2xx range with an empty JSON body should return an empty dict."""
        resp = httpx.Response(200, json={})
        result = PineLabsClient._handle_response(resp)
        assert result == {}

    def test_204_no_content(self, pinelabs_client):
        """204 No Content returns empty dict."""
        resp = httpx.Response(204)
        result = PineLabsClient._handle_response(resp)
        assert result == {}

    def test_error_without_standard_fields(self, pinelabs_client):
        """Error JSON without code/message fields falls back to defaults."""
        resp = httpx.Response(500, json={"unexpected": "data"})
        with pytest.raises(PineLabsAPIError) as exc_info:
            PineLabsClient._handle_response(resp)
        assert exc_info.value.code == "UNKNOWN_ERROR"
        assert exc_info.value.message == "Unknown error occurred"

    def test_error_empty_body(self, pinelabs_client):
        """Non-JSON error body falls through to the except branch."""
        resp = httpx.Response(500, text="Internal Server Error")
        with pytest.raises(PineLabsAPIError) as exc_info:
            PineLabsClient._handle_response(resp)
        assert exc_info.value.code == "UNKNOWN_ERROR"
        assert "Internal Server Error" in exc_info.value.message


# ---------------------------------------------------------------------------
# _normalize_path
# ---------------------------------------------------------------------------

class TestNormalizePath:
    def test_paymentlink_create_passthrough(self):
        assert _normalize_path("/pay/v1/paymentlink") == "/pay/v1/paymentlink"

    def test_paymentlink_by_id(self):
        assert _normalize_path("/pay/v1/paymentlink/pl-v1-abc123") == "/pay/v1/paymentlink/{paymentLinkId}"

    def test_paymentlink_cancel(self):
        assert _normalize_path("/pay/v1/paymentlink/pl-v1-abc123/cancel") == "/pay/v1/paymentlink/{paymentLinkId}/cancel"

    def test_paymentlink_notify(self):
        assert _normalize_path("/pay/v1/paymentlink/pl-v1-abc123/notify") == "/pay/v1/paymentlink/{paymentLinkId}/notify"

    def test_paymentlink_by_merchant_ref(self):
        assert _normalize_path("/pay/v1/paymentlink/ref/my-ref-001") == "/pay/v1/paymentlink/ref/{merchantRef}"

    def test_orders_by_id(self):
        assert _normalize_path("/pay/v1/orders/v1-12345-aa-xyz") == "/pay/v1/orders/{orderId}"

    def test_unknown_path_passthrough(self):
        assert _normalize_path("/unknown/path") == "/unknown/path"


# ---------------------------------------------------------------------------
# close
# ---------------------------------------------------------------------------

class TestClose:
    @pytest.mark.asyncio
    async def test_close_releases_client(self, pinelabs_client):
        # Force client creation
        pinelabs_client._get_client()
        assert pinelabs_client._client is not None
        await pinelabs_client.close()
        assert pinelabs_client._client is None

    @pytest.mark.asyncio
    async def test_close_when_no_client(self, pinelabs_client):
        """Closing without an active client should not raise."""
        assert pinelabs_client._client is None
        await pinelabs_client.close()  # Should be a no-op


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------

class TestRetryLogic:
    @respx.mock
    @pytest.mark.asyncio
    async def test_retry_on_502(self):
        """Retryable 502 should be retried, then succeed on second attempt."""
        client = _make_client(max_retries=1)
        route = respx.get(f"{BASE_URL}/pay/v1/paymentlink/pl-123")
        route.side_effect = [
            httpx.Response(502, text="Bad Gateway"),
            httpx.Response(200, json={"status": "ok"}),
        ]
        result = await client.get("/pay/v1/paymentlink/pl-123")
        assert result == {"status": "ok"}
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_retry_on_503(self):
        """Retryable 503 should be retried, then succeed."""
        client = _make_client(max_retries=1)
        route = respx.get(f"{BASE_URL}/pay/v1/paymentlink/pl-123")
        route.side_effect = [
            httpx.Response(503, text="Service Unavailable"),
            httpx.Response(200, json={"ok": True}),
        ]
        result = await client.get("/pay/v1/paymentlink/pl-123")
        assert result["ok"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_retry_exhausted_raises(self):
        """When all retries are exhausted on retryable status, raise error."""
        client = _make_client(max_retries=1)
        respx.get(f"{BASE_URL}/pay/v1/paymentlink/pl-123").mock(
            return_value=httpx.Response(502, text="Bad Gateway"),
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.get("/pay/v1/paymentlink/pl-123")
        assert exc_info.value.status_code == 502

    @respx.mock
    @pytest.mark.asyncio
    async def test_retry_on_connect_error(self):
        """ConnectError should be retried, then succeed."""
        client = _make_client(max_retries=1)
        route = respx.get(f"{BASE_URL}/pay/v1/paymentlink/pl-123")
        route.side_effect = [
            httpx.ConnectError("Connection refused"),
            httpx.Response(200, json={"recovered": True}),
        ]
        result = await client.get("/pay/v1/paymentlink/pl-123")
        assert result["recovered"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_connect_error_exhausted_raises(self):
        """When all retries exhausted on ConnectError, raise PineLabsAPIError."""
        client = _make_client(max_retries=1)
        respx.get(f"{BASE_URL}/test/path").mock(
            side_effect=httpx.ConnectError("refused"),
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.get("/test/path")
        assert exc_info.value.code == "CONNECTION_ERROR"
        assert "Failed to connect" in exc_info.value.message

    @respx.mock
    @pytest.mark.asyncio
    async def test_timeout_error_retried(self):
        """TimeoutException should be retried like ConnectError."""
        client = _make_client(max_retries=1)
        route = respx.post(f"{BASE_URL}/pay/v1/paymentlink")
        route.side_effect = [
            httpx.TimeoutException("read timeout"),
            httpx.Response(200, json={"created": True}),
        ]
        result = await client.post("/pay/v1/paymentlink", {"amount": 100}, TOKEN)
        assert result["created"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_non_retryable_api_error_not_retried(self):
        """A 400 error should NOT be retried — it should raise immediately."""
        client = _make_client(max_retries=2)
        route = respx.post(f"{BASE_URL}/pay/v1/paymentlink")
        route.mock(
            return_value=httpx.Response(400, json={
                "code": "BAD_REQUEST",
                "message": "Invalid payload",
            })
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.post("/pay/v1/paymentlink", {}, TOKEN)
        assert exc_info.value.status_code == 400
        # Should only have been called once (no retries)
        assert route.call_count == 1


# ---------------------------------------------------------------------------
# Circuit Breaker
# ---------------------------------------------------------------------------

class TestCircuitBreaker:
    @respx.mock
    @pytest.mark.asyncio
    async def test_circuit_breaker_trips_after_failures(self):
        """Circuit breaker should open after fail_max consecutive failures."""
        cb = CircuitBreaker(fail_max=2, reset_timeout=60, name="test_trip")
        client = PineLabsClient(
            base_url=BASE_URL,
            token_manager=_make_token_manager(),
            max_retries=0,
            circuit_breaker=cb,
        )
        respx.get(f"{BASE_URL}/test/path").mock(
            side_effect=httpx.ConnectError("refused"),
        )

        # First two calls should raise CONNECTION_ERROR
        for _ in range(2):
            with pytest.raises(PineLabsAPIError) as exc_info:
                await client.get("/test/path")
            assert exc_info.value.code == "CONNECTION_ERROR"

        # Third call should fail with CIRCUIT_OPEN (circuit is now open)
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.get("/test/path")
        assert exc_info.value.code == "CIRCUIT_OPEN"
        assert exc_info.value.status_code == 503


# ---------------------------------------------------------------------------
# Idempotency Key
# ---------------------------------------------------------------------------

class TestIdempotencyKey:
    def test_build_headers_includes_idempotency_key(self, pinelabs_client):
        """Headers should include Idempotency-Key when provided."""
        headers = pinelabs_client._build_headers(TOKEN, idempotency_key="idem-123")
        assert headers["Idempotency-Key"] == "idem-123"

    def test_build_headers_no_idempotency_key(self, pinelabs_client):
        """Headers should not include Idempotency-Key when not provided."""
        headers = pinelabs_client._build_headers(TOKEN)
        assert "Idempotency-Key" not in headers

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_auto_generates_idempotency_key(self, pinelabs_client):
        """POST should auto-generate an idempotency key if not provided."""
        route = respx.post(f"{BASE_URL}/pay/v1/paymentlink").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        await pinelabs_client.post("/pay/v1/paymentlink", {"amount": 100}, TOKEN)
        # Verify that the Idempotency-Key header was sent
        request = route.calls[0].request
        assert "idempotency-key" in {k.lower() for k in dict(request.headers)}


# ---------------------------------------------------------------------------
# Configurable Timeout
# ---------------------------------------------------------------------------

class TestConfigurableTimeout:
    def test_custom_timeout(self):
        """Client should use custom timeout value."""
        client = PineLabsClient(
            base_url=BASE_URL,
            token_manager=_make_token_manager(),
            timeout=15.0,
            circuit_breaker=CircuitBreaker(fail_max=100, reset_timeout=1, name="timeout_test"),
        )
        http_client = client._get_client()
        assert http_client.timeout.connect == 15.0

    def test_default_timeout(self):
        """Client should default to 30.0 if no timeout specified."""
        cb = CircuitBreaker(fail_max=100, reset_timeout=1, name="default_timeout_test")
        client = PineLabsClient(base_url=BASE_URL, token_manager=_make_token_manager(), circuit_breaker=cb)
        http_client = client._get_client()
        assert http_client.timeout.connect == 30.0
