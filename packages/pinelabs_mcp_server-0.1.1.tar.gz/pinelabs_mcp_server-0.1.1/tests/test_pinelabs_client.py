"""Tests for PineLabsClient: error handling, retries, idempotency key, and response parsing."""

import json
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import respx

from clients.pinelabs_client import (
    PineLabsAPIError,
    PineLabsClient,
)
from utils.circuit_breaker import CircuitBreaker


BASE_URL = "https://test.example.com/api"
TOKEN = "test-token-xyz"


def _make_client(**overrides) -> PineLabsClient:
    """Create a PineLabsClient with a lenient circuit breaker for testing."""
    cb = CircuitBreaker(fail_max=100, reset_timeout=1, name="test_pinelabs_cb")
    mock_token_manager = MagicMock()
    mock_token_manager.get_access_token = AsyncMock(return_value=TOKEN)
    defaults = dict(
        base_url=BASE_URL,
        token_manager=mock_token_manager,
        max_retries=0,
        base_backoff=0.0,
        circuit_breaker=cb,
    )
    defaults.update(overrides)
    return PineLabsClient(**defaults)


def _mock_response(status_code: int, json_body: dict | None = None) -> MagicMock:
    """Create a mock httpx.Response for _handle_response unit tests."""
    response = MagicMock(spec=httpx.Response)
    response.status_code = status_code
    response.content = json.dumps(json_body).encode() if json_body is not None else b""
    if json_body is not None:
        response.json.return_value = json_body
    else:
        response.json.side_effect = json.JSONDecodeError("no body", "", 0)
        response.text = "Server Error"
    return response


# ---------------------------------------------------------------------------
# PineLabsClient._handle_response
# ---------------------------------------------------------------------------

class TestHandleResponse:
    def test_success_2xx(self) -> None:
        resp = _mock_response(200, {"status": "ok"})
        assert PineLabsClient._handle_response(resp) == {"status": "ok"}

    def test_success_201(self) -> None:
        resp = _mock_response(201, {"id": "123"})
        assert PineLabsClient._handle_response(resp) == {"id": "123"}

    def test_error_with_json_body(self) -> None:
        resp = _mock_response(400, {"code": "INVALID", "message": "Bad", "additionalErrorPayload": {"x": 1}})
        with pytest.raises(PineLabsAPIError) as exc_info:
            PineLabsClient._handle_response(resp)
        assert exc_info.value.status_code == 400
        assert exc_info.value.code == "INVALID"
        assert exc_info.value.payload == {"x": 1}

    def test_error_no_json_body(self) -> None:
        resp = _mock_response(500)
        with pytest.raises(PineLabsAPIError) as exc_info:
            PineLabsClient._handle_response(resp)
        assert exc_info.value.status_code == 500
        assert exc_info.value.code == "UNKNOWN_ERROR"
        assert exc_info.value.payload == {}


# ---------------------------------------------------------------------------
# PineLabsClient method tests
# ---------------------------------------------------------------------------

class TestPost:
    @respx.mock
    @pytest.mark.asyncio
    async def test_post_success(self) -> None:
        client = _make_client()
        respx.post(f"{BASE_URL}/pay/v1/test").mock(
            return_value=httpx.Response(200, json={"result": "ok"})
        )
        result = await client.post("/pay/v1/test", {"key": "val"}, TOKEN)
        assert result == {"result": "ok"}

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_sends_idempotency_key(self) -> None:
        client = _make_client()
        route = respx.post(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"result": "ok"})
        )
        await client.post("/test", {"k": "v"}, idempotency_key="idem-123")
        req = route.calls[0].request
        assert req.headers.get("idempotency-key") == "idem-123"

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_auto_generates_idempotency_key(self) -> None:
        """POST auto-generates an Idempotency-Key when none is provided."""
        client = _make_client()
        route = respx.post(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"result": "ok"})
        )
        await client.post("/test", {"k": "v"}, TOKEN)
        req = route.calls[0].request
        assert "idempotency-key" in req.headers

    @respx.mock
    @pytest.mark.asyncio
    async def test_post_api_error(self) -> None:
        client = _make_client()
        respx.post(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(401, json={"code": "UNAUTHENTICATED", "message": "bad"})
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.post("/test", {}, TOKEN)
        assert exc_info.value.status_code == 401


class TestGet:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_success(self) -> None:
        client = _make_client()
        respx.get(f"{BASE_URL}/pay/v1/test").mock(
            return_value=httpx.Response(200, json={"data": "value"})
        )
        result = await client.get("/pay/v1/test")
        assert result == {"data": "value"}


class TestPut:
    @respx.mock
    @pytest.mark.asyncio
    async def test_put_sends_idempotency_key(self) -> None:
        client = _make_client()
        route = respx.put(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        await client.put("/test", TOKEN, idempotency_key="idem-456")
        req = route.calls[0].request
        assert req.headers.get("idempotency-key") == "idem-456"


class TestPatch:
    @respx.mock
    @pytest.mark.asyncio
    async def test_patch_success(self) -> None:
        client = _make_client()
        respx.patch(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"patched": True})
        )
        result = await client.patch("/test", TOKEN)
        assert result == {"patched": True}


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------

class TestRequestWithRetries:
    @respx.mock
    @pytest.mark.asyncio
    async def test_retries_on_5xx_for_get(self) -> None:
        """GET (retryable) should retry on 502 then succeed."""
        client = _make_client(max_retries=1)
        route = respx.get(f"{BASE_URL}/test")
        route.side_effect = [
            httpx.Response(502, text="Bad Gateway"),
            httpx.Response(200, json={"ok": True}),
        ]
        result = await client.get("/test")
        assert result == {"ok": True}
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_retries_on_5xx_for_post(self) -> None:
        """POST should also retry on transient 502."""
        client = _make_client(max_retries=1)
        route = respx.post(f"{BASE_URL}/test")
        route.side_effect = [
            httpx.Response(502, text="Bad Gateway"),
            httpx.Response(200, json={"ok": True}),
        ]
        result = await client.post("/test", {}, TOKEN)
        assert result == {"ok": True}
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_timeout_raises_api_error(self) -> None:
        """Transport timeout with no retries should raise PineLabsAPIError."""
        client = _make_client(max_retries=0)
        respx.post(f"{BASE_URL}/test").mock(
            side_effect=httpx.TimeoutException("timeout")
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.post("/test", {}, TOKEN)
        assert exc_info.value.code == "CONNECTION_ERROR"

    @respx.mock
    @pytest.mark.asyncio
    async def test_retries_on_timeout_for_get(self) -> None:
        """GET should retry after transport error then succeed."""
        client = _make_client(max_retries=1)
        route = respx.get(f"{BASE_URL}/test")
        route.side_effect = [
            httpx.TimeoutException("timeout"),
            httpx.Response(200, json={"ok": True}),
        ]
        result = await client.get("/test")
        assert result == {"ok": True}
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_exhausted_retries_raise(self) -> None:
        """GET that exhausts all retries should raise PineLabsAPIError."""
        client = _make_client(max_retries=2)
        respx.get(f"{BASE_URL}/test").mock(
            side_effect=httpx.TimeoutException("timeout"),
        )
        with pytest.raises(PineLabsAPIError) as exc_info:
            await client.get("/test")
        assert exc_info.value.code == "CONNECTION_ERROR"


# ---------------------------------------------------------------------------
# PineLabsAPIError
# ---------------------------------------------------------------------------

class TestPineLabsAPIError:
    def test_str_repr(self) -> None:
        err = PineLabsAPIError(500, "CODE", "msg")
        assert "[500]" in str(err)
        assert "CODE" in str(err)

    def test_payload_default(self) -> None:
        err = PineLabsAPIError(400, "C", "M")
        assert err.payload == {}


# ---------------------------------------------------------------------------
# close
# ---------------------------------------------------------------------------

class TestClose:
    @pytest.mark.asyncio
    async def test_close_releases_client(self) -> None:
        client = _make_client()
        client._get_client()
        assert client._client is not None
        await client.close()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_when_no_client(self) -> None:
        """Closing without an active client should not raise."""
        client = _make_client()
        assert client._client is None
        await client.close()
