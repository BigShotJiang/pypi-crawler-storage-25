"""Tests for Redis-backed authorization token caching.

Covers:
- cache hit: token found in Redis → returned directly, no fetch
- cache miss: token not in Redis → fetched, stored, then returned
- same client_id on second call reuses cached token
- different client_ids use separate keys
- Redis unavailable: falls back to direct token generation
- TTL is set correctly
- connection pooling (Redis client reused)
- security: no raw secrets/tokens logged
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from auth.token_cache import TokenCache, _mask_id
from auth.token_manager import TokenManager
from utils.metrics import (
    TOKEN_CACHE_HITS,
    TOKEN_CACHE_MISSES,
    TOKEN_CACHE_ERRORS,
    TOKEN_CACHE_WRITES,
    TOKEN_CACHE_DELETES,
    REDIS_UP,
    AUTH_TOKEN_REQUESTS,
)

# Valid UUID-format client IDs for tests
_CID_1 = "8ba31498-3eb1-4ac9-8eaf-4fc4620b528f"
_CID_A = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_CID_B = "11111111-2222-3333-4444-555555555555"
_SECRET = "00000000000000000000000000000000"


# ---------------------------------------------------------------------------
# TokenCache unit tests
# ---------------------------------------------------------------------------


class TestTokenCache:
    """Test the TokenCache Redis wrapper in isolation (Redis mocked)."""

    @pytest.fixture
    def mock_redis(self):
        r = AsyncMock()
        return r

    @pytest.fixture
    def cache(self, mock_redis):
        tc = TokenCache.__new__(TokenCache)
        tc._default_ttl = 3000
        tc._redis = mock_redis
        tc._pool = AsyncMock()
        return tc

    # --- get_token ---

    @pytest.mark.asyncio
    async def test_get_token_cache_hit(self, cache, mock_redis):
        mock_redis.get.return_value = "cached-access-token"
        result = await cache.get_token("client-abc")
        assert result == "cached-access-token"
        mock_redis.get.assert_awaited_once_with("mcp_auth_token:client-abc")

    @pytest.mark.asyncio
    async def test_get_token_cache_miss(self, cache, mock_redis):
        mock_redis.get.return_value = None
        result = await cache.get_token("client-abc")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_token_redis_unavailable(self, cache, mock_redis):
        mock_redis.get.side_effect = ConnectionError("Redis down")
        result = await cache.get_token("client-abc")
        assert result is None  # graceful degradation

    # --- set_token ---

    @pytest.mark.asyncio
    async def test_set_token_default_ttl(self, cache, mock_redis):
        await cache.set_token("client-abc", "new-token")
        mock_redis.set.assert_awaited_once_with("mcp_auth_token:client-abc", "new-token", ex=3000)

    @pytest.mark.asyncio
    async def test_set_token_custom_ttl(self, cache, mock_redis):
        await cache.set_token("client-abc", "new-token", ttl_seconds=600)
        mock_redis.set.assert_awaited_once_with("mcp_auth_token:client-abc", "new-token", ex=600)

    @pytest.mark.asyncio
    async def test_set_token_redis_unavailable(self, cache, mock_redis):
        mock_redis.set.side_effect = ConnectionError("Redis down")
        # Should not raise
        await cache.set_token("client-abc", "new-token")

    # --- delete_token ---

    @pytest.mark.asyncio
    async def test_delete_token(self, cache, mock_redis):
        await cache.delete_token("client-abc")
        mock_redis.delete.assert_awaited_once_with("mcp_auth_token:client-abc")

    @pytest.mark.asyncio
    async def test_delete_token_redis_unavailable(self, cache, mock_redis):
        mock_redis.delete.side_effect = ConnectionError("Redis down")
        await cache.delete_token("client-abc")  # should not raise

    # --- connect ---

    @pytest.mark.asyncio
    async def test_connect_success(self, cache, mock_redis):
        mock_redis.ping.return_value = True
        await cache.connect()  # should not raise
        mock_redis.ping.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_connect_redis_unavailable(self, cache, mock_redis):
        mock_redis.ping.side_effect = ConnectionError("Redis down")
        await cache.connect()  # should not raise (graceful degradation)

    # --- close ---

    @pytest.mark.asyncio
    async def test_close(self, cache, mock_redis):
        await cache.close()
        mock_redis.aclose.assert_awaited_once()
        cache._pool.disconnect.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_close_redis_error(self, cache, mock_redis):
        mock_redis.aclose.side_effect = Exception("close error")
        await cache.close()  # should not raise


class TestTokenCacheMetricsIntegration:
    """Verify that TokenCache operations emit Prometheus metrics."""

    @pytest.fixture
    def mock_redis(self):
        return AsyncMock()

    @pytest.fixture
    def cache(self, mock_redis):
        tc = TokenCache.__new__(TokenCache)
        tc._default_ttl = 3000
        tc._redis = mock_redis
        tc._pool = AsyncMock()
        return tc

    @pytest.mark.asyncio
    async def test_cache_hit_increments_hit_counter(self, cache, mock_redis):
        mock_redis.get.return_value = "token"
        before = TOKEN_CACHE_HITS._value.get()
        await cache.get_token("client-abc")
        assert TOKEN_CACHE_HITS._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_cache_miss_increments_miss_counter(self, cache, mock_redis):
        mock_redis.get.return_value = None
        before = TOKEN_CACHE_MISSES._value.get()
        await cache.get_token("client-abc")
        assert TOKEN_CACHE_MISSES._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_get_error_increments_error_counter(self, cache, mock_redis):
        mock_redis.get.side_effect = ConnectionError("down")
        before = TOKEN_CACHE_ERRORS.labels(operation="get")._value.get()
        await cache.get_token("client-abc")
        assert TOKEN_CACHE_ERRORS.labels(operation="get")._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_set_increments_write_counter(self, cache, mock_redis):
        before = TOKEN_CACHE_WRITES._value.get()
        await cache.set_token("client-abc", "tok")
        assert TOKEN_CACHE_WRITES._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_set_error_increments_error_counter(self, cache, mock_redis):
        mock_redis.set.side_effect = ConnectionError("down")
        before = TOKEN_CACHE_ERRORS.labels(operation="set")._value.get()
        await cache.set_token("client-abc", "tok")
        assert TOKEN_CACHE_ERRORS.labels(operation="set")._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_delete_increments_delete_counter(self, cache, mock_redis):
        before = TOKEN_CACHE_DELETES._value.get()
        await cache.delete_token("client-abc")
        assert TOKEN_CACHE_DELETES._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_delete_error_increments_error_counter(self, cache, mock_redis):
        mock_redis.delete.side_effect = ConnectionError("down")
        before = TOKEN_CACHE_ERRORS.labels(operation="delete")._value.get()
        await cache.delete_token("client-abc")
        assert TOKEN_CACHE_ERRORS.labels(operation="delete")._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_connect_success_sets_redis_up(self, cache, mock_redis):
        mock_redis.ping.return_value = True
        await cache.connect()
        assert REDIS_UP._value.get() == 1

    @pytest.mark.asyncio
    async def test_connect_failure_sets_redis_down(self, cache, mock_redis):
        mock_redis.ping.side_effect = ConnectionError("down")
        await cache.connect()
        assert REDIS_UP._value.get() == 0

    @pytest.mark.asyncio
    async def test_get_success_sets_redis_up(self, cache, mock_redis):
        REDIS_UP._value.set(0)
        mock_redis.get.return_value = "tok"
        await cache.get_token("client-abc")
        assert REDIS_UP._value.get() == 1

    @pytest.mark.asyncio
    async def test_set_success_sets_redis_up(self, cache, mock_redis):
        REDIS_UP._value.set(0)
        await cache.set_token("client-abc", "tok")
        assert REDIS_UP._value.get() == 1

    @pytest.mark.asyncio
    async def test_delete_success_sets_redis_up(self, cache, mock_redis):
        REDIS_UP._value.set(0)
        await cache.delete_token("client-abc")
        assert REDIS_UP._value.get() == 1


class TestMaskId:
    def test_short_id(self):
        assert _mask_id("ab") == "ab***"

    def test_long_id(self):
        assert _mask_id("8ba31498-3eb1-4ac9-8eaf") == "8ba31498***"


# ---------------------------------------------------------------------------
# TokenManager integration tests (with mocked cache + mocked HTTP)
# ---------------------------------------------------------------------------


class TestTokenManagerWithCache:
    """Test that TokenManager uses the cache correctly."""

    @pytest.fixture
    def mock_cache(self):
        cache = AsyncMock(spec=TokenCache)
        return cache

    @pytest.fixture
    def manager(self, mock_cache):
        return TokenManager(
            token_url="https://fake.pinelabs.test/api/auth/v1/token",
            timeout=5.0,
            token_cache=mock_cache,
        )

    @pytest.mark.asyncio
    async def test_cache_hit_skips_fetch(self, manager, mock_cache):
        """When a token exists in cache, no HTTP call is made."""
        mock_cache.get_token.return_value = "cached-token-xyz"

        token = await manager.get_access_token(_CID_1, _SECRET)

        assert token == "cached-token-xyz"
        mock_cache.get_token.assert_awaited_once_with(_CID_1)
        mock_cache.set_token.assert_not_awaited()  # no store on hit

    @pytest.mark.asyncio
    async def test_cache_miss_fetches_and_stores(self, manager, mock_cache):
        """On cache miss, fetch from Pine Labs and store in Redis."""
        mock_cache.get_token.return_value = None

        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = "new-token-abc"
            token = await manager.get_access_token(_CID_1, _SECRET)

        assert token == "new-token-abc"
        mock_cache.get_token.assert_awaited_once_with(_CID_1)
        mock_cache.set_token.assert_awaited_once_with(_CID_1, "new-token-abc")

    @pytest.mark.asyncio
    async def test_second_request_same_client_uses_cache(self, manager, mock_cache):
        """Subsequent requests for the same client_id hit cache."""
        mock_cache.get_token.side_effect = [None, "cached-token-xyz"]

        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = "new-token-abc"

            token1 = await manager.get_access_token(_CID_1, _SECRET)
            token2 = await manager.get_access_token(_CID_1, _SECRET)

        assert token1 == "new-token-abc"
        assert token2 == "cached-token-xyz"
        assert mock_fetch.await_count == 1  # only called once (cache miss)

    @pytest.mark.asyncio
    async def test_different_client_ids_separate_keys(self, manager, mock_cache):
        """Different client_ids use different cache keys."""
        mock_cache.get_token.return_value = None

        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.side_effect = ["token-A", "token-B"]

            t1 = await manager.get_access_token(_CID_A, _SECRET)
            t2 = await manager.get_access_token(_CID_B, _SECRET)

        assert t1 == "token-A"
        assert t2 == "token-B"
        assert mock_cache.get_token.await_count == 2
        mock_cache.set_token.assert_any_await(_CID_A, "token-A")
        mock_cache.set_token.assert_any_await(_CID_B, "token-B")

    @pytest.mark.asyncio
    async def test_redis_unavailable_falls_back_to_fetch(self, manager, mock_cache):
        """When Redis is down, token is still fetched normally."""
        mock_cache.get_token.return_value = None
        mock_cache.set_token.return_value = None

        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = "fallback-token"
            token = await manager.get_access_token(_CID_1, _SECRET)

        # get_token returns None (graceful degradation in TokenCache) → fetch happens
        assert token == "fallback-token"
        mock_fetch.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_missing_credentials_raises(self, manager):
        """Empty credentials still raise RuntimeError regardless of cache."""
        with pytest.raises(RuntimeError, match="Client credentials not configured"):
            await manager.get_access_token("", _SECRET)

        with pytest.raises(RuntimeError, match="Client credentials not configured"):
            await manager.get_access_token(_CID_1, "")

    @pytest.mark.asyncio
    async def test_invalid_client_id_format_raises(self, manager):
        """Malformed client_id raises ValueError."""
        with pytest.raises(ValueError, match="Invalid client_id format"):
            await manager.get_access_token("not-a-valid-uuid!", _SECRET)


class TestTokenManagerWithoutCache:
    """Test that TokenManager works without a cache (backwards compatibility)."""

    @pytest.fixture
    def manager(self):
        return TokenManager(
            token_url="https://fake.pinelabs.test/api/auth/v1/token",
            timeout=5.0,
            token_cache=None,
        )

    @pytest.mark.asyncio
    async def test_no_cache_fetches_directly(self, manager):
        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = "direct-token"
            token = await manager.get_access_token(_CID_1, _SECRET)

        assert token == "direct-token"
        mock_fetch.assert_awaited_once_with(_CID_1, _SECRET)

    @pytest.mark.asyncio
    async def test_no_cache_always_fetches(self, manager):
        with patch.object(manager, "_fetch_token", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = "direct-token"
            await manager.get_access_token(_CID_1, _SECRET)
            await manager.get_access_token(_CID_1, _SECRET)

        assert mock_fetch.await_count == 2  # no caching, always fetches


# ---------------------------------------------------------------------------
# Connection pooling verification
# ---------------------------------------------------------------------------


class TestTokenCacheConnectionPooling:
    """Verify that the connection pool is created once and reused."""

    def test_pool_created_once(self):
        """Instantiating TokenCache creates a single connection pool."""
        with patch("auth.token_cache.aioredis.ConnectionPool") as MockPool, \
             patch("auth.token_cache.aioredis.Redis"):
            MockPool.return_value = MagicMock()
            _ = TokenCache(
                redis_host="localhost",
                redis_port=6379,
                redis_db=0,
                max_connections=50,
            )
            MockPool.assert_called_once_with(
                host="localhost",
                port=6379,
                db=0,
                max_connections=50,
                decode_responses=True,
            )


# ---------------------------------------------------------------------------
# Auth token fetch metrics integration tests
# ---------------------------------------------------------------------------


class TestTokenManagerMetricsIntegration:
    """Verify that TokenManager._fetch_token emits auth token metrics."""

    @pytest.fixture
    def manager(self):
        return TokenManager(
            token_url="https://fake.pinelabs.test/api/auth/v1/token",
            timeout=5.0,
            token_cache=None,
        )

    @pytest.mark.asyncio
    async def test_fetch_success_emits_metric(self, manager):
        before = AUTH_TOKEN_REQUESTS.labels(status="success")._value.get()
        with patch("auth.token_manager.httpx.AsyncClient") as MockClient:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"access_token": "tok-abc"}
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client
            await manager._fetch_token(_CID_1, _SECRET)
        assert AUTH_TOKEN_REQUESTS.labels(status="success")._value.get() == before + 1

    @pytest.mark.asyncio
    async def test_fetch_error_emits_metric(self, manager):
        before = AUTH_TOKEN_REQUESTS.labels(status="error")._value.get()
        with patch("auth.token_manager.httpx.AsyncClient") as MockClient:
            mock_resp = MagicMock()
            mock_resp.status_code = 401
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client
            with pytest.raises(RuntimeError):
                await manager._fetch_token(_CID_1, _SECRET)
        assert AUTH_TOKEN_REQUESTS.labels(status="error")._value.get() == before + 1
