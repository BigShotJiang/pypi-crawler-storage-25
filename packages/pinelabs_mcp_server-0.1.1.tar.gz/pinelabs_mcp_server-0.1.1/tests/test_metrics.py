"""Tests for utils/metrics.py — Prometheus metrics and instrumentation."""

import asyncio
import json
import time
from unittest.mock import patch, MagicMock

import pytest
from prometheus_client import REGISTRY

from utils.metrics import (
    TOOL_REQUESTS,
    TOOL_DURATION,
    TOOL_ACTIVE,
    API_REQUESTS,
    API_DURATION,
    API_ERRORS,
    API_RETRIES,
    TOKEN_CACHE_HITS,
    TOKEN_CACHE_MISSES,
    TOKEN_CACHE_ERRORS,
    TOKEN_CACHE_WRITES,
    TOKEN_CACHE_DELETES,
    AUTH_TOKEN_REQUESTS,
    AUTH_TOKEN_DURATION,
    CIRCUIT_BREAKER_STATE,
    CIRCUIT_BREAKER_TRANSITIONS,
    CIRCUIT_BREAKER_REJECTIONS,
    REDIS_UP,
    BUSINESS_OUTCOMES,
    track_tool_call,
    instrumented_tool,
    record_api_request,
    record_api_error,
    record_api_retry,
    record_cache_hit,
    record_cache_miss,
    record_cache_error,
    record_cache_write,
    record_cache_delete,
    record_auth_token_fetch,
    record_circuit_breaker_state,
    record_circuit_breaker_transition,
    record_circuit_breaker_rejection,
    record_redis_up,
    record_business_outcome,
    start_metrics_server,
    reset_metrics_server_state,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_counter_value(counter, labels: dict) -> float:
    """Get the current value of a Prometheus counter with the given labels."""
    try:
        return counter.labels(**labels)._value.get()
    except Exception:
        return 0.0


def _get_gauge_value(gauge, labels: dict) -> float:
    """Get the current value of a Prometheus gauge with the given labels."""
    try:
        return gauge.labels(**labels)._value.get()
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# track_tool_call (sync context manager)
# ---------------------------------------------------------------------------

class TestTrackToolCall:
    """Tests for the sync track_tool_call context manager."""

    def test_success_increments_counter(self):
        before = _get_counter_value(TOOL_REQUESTS, {"tool": "test_sync_ok", "status": "success"})
        with track_tool_call("test_sync_ok"):
            pass
        after = _get_counter_value(TOOL_REQUESTS, {"tool": "test_sync_ok", "status": "success"})
        assert after == before + 1

    def test_error_increments_counter(self):
        before = _get_counter_value(TOOL_REQUESTS, {"tool": "test_sync_err", "status": "error"})
        with pytest.raises(ValueError):
            with track_tool_call("test_sync_err"):
                raise ValueError("boom")
        after = _get_counter_value(TOOL_REQUESTS, {"tool": "test_sync_err", "status": "error"})
        assert after == before + 1

    def test_records_duration(self):
        with track_tool_call("test_sync_dur"):
            time.sleep(0.01)
        # Histogram should have at least one observation
        sample = REGISTRY.get_sample_value(
            "mcp_tool_request_duration_seconds_count",
            {"tool": "test_sync_dur"},
        )
        assert sample is not None and sample >= 1

    def test_active_gauge_returns_to_zero(self):
        with track_tool_call("test_sync_gauge"):
            val = _get_gauge_value(TOOL_ACTIVE, {"tool": "test_sync_gauge"})
            assert val == 1
        val = _get_gauge_value(TOOL_ACTIVE, {"tool": "test_sync_gauge"})
        assert val == 0


# ---------------------------------------------------------------------------
# instrumented_tool (async decorator)
# ---------------------------------------------------------------------------

class TestInstrumentedTool:
    """Tests for the async instrumented_tool decorator."""

    @pytest.mark.asyncio
    async def test_success_response(self):
        @instrumented_tool("test_async_ok")
        async def my_tool():
            return json.dumps({"status": "ok"})

        before = _get_counter_value(TOOL_REQUESTS, {"tool": "test_async_ok", "status": "success"})
        result = await my_tool()
        after = _get_counter_value(TOOL_REQUESTS, {"tool": "test_async_ok", "status": "success"})
        assert after == before + 1
        assert "ok" in result

    @pytest.mark.asyncio
    async def test_error_response_string(self):
        """When the tool returns an error JSON string, status should be 'error'."""

        @instrumented_tool("test_async_err_str")
        async def my_tool():
            return json.dumps({"error": "something went wrong"})

        before = _get_counter_value(
            TOOL_REQUESTS, {"tool": "test_async_err_str", "status": "error"}
        )
        result = await my_tool()
        after = _get_counter_value(
            TOOL_REQUESTS, {"tool": "test_async_err_str", "status": "error"}
        )
        assert after == before + 1
        assert "error" in result

    @pytest.mark.asyncio
    async def test_exception_records_error(self):
        @instrumented_tool("test_async_exc")
        async def my_tool():
            raise RuntimeError("kaboom")

        before = _get_counter_value(
            TOOL_REQUESTS, {"tool": "test_async_exc", "status": "error"}
        )
        with pytest.raises(RuntimeError, match="kaboom"):
            await my_tool()
        after = _get_counter_value(
            TOOL_REQUESTS, {"tool": "test_async_exc", "status": "error"}
        )
        assert after == before + 1

    @pytest.mark.asyncio
    async def test_duration_recorded(self):
        @instrumented_tool("test_async_dur")
        async def my_tool():
            await asyncio.sleep(0.01)
            return "done"

        await my_tool()
        sample = REGISTRY.get_sample_value(
            "mcp_tool_request_duration_seconds_count",
            {"tool": "test_async_dur"},
        )
        assert sample is not None and sample >= 1

    @pytest.mark.asyncio
    async def test_active_gauge(self):
        active_during: float | None = None

        @instrumented_tool("test_async_gauge")
        async def my_tool():
            nonlocal active_during
            active_during = _get_gauge_value(TOOL_ACTIVE, {"tool": "test_async_gauge"})
            return "ok"

        await my_tool()
        assert active_during == 1
        after = _get_gauge_value(TOOL_ACTIVE, {"tool": "test_async_gauge"})
        assert after == 0


# ---------------------------------------------------------------------------
# API metric helpers
# ---------------------------------------------------------------------------

class TestAPIMetrics:
    """Tests for record_api_request, record_api_error, record_api_retry."""

    def test_record_api_request(self):
        before = _get_counter_value(
            API_REQUESTS, {"method": "GET", "path": "/test", "status_code": "200"}
        )
        record_api_request("GET", "/test", 200, 0.5)
        after = _get_counter_value(
            API_REQUESTS, {"method": "GET", "path": "/test", "status_code": "200"}
        )
        assert after == before + 1

    def test_record_api_request_duration(self):
        record_api_request("POST", "/dur", 201, 1.23)
        sample = REGISTRY.get_sample_value(
            "pinelabs_api_request_duration_seconds_count",
            {"method": "POST", "path": "/dur"},
        )
        assert sample is not None and sample >= 1

    def test_record_api_error(self):
        before = _get_counter_value(
            API_ERRORS, {"method": "GET", "path": "/err", "error_type": "TIMEOUT"}
        )
        record_api_error("GET", "/err", "TIMEOUT")
        after = _get_counter_value(
            API_ERRORS, {"method": "GET", "path": "/err", "error_type": "TIMEOUT"}
        )
        assert after == before + 1

    def test_record_api_retry(self):
        before = _get_counter_value(
            API_RETRIES, {"method": "PUT", "path": "/retry"}
        )
        record_api_retry("PUT", "/retry")
        after = _get_counter_value(
            API_RETRIES, {"method": "PUT", "path": "/retry"}
        )
        assert after == before + 1


# ---------------------------------------------------------------------------
# Metrics server lifecycle
# ---------------------------------------------------------------------------

class TestMetricsServer:
    """Tests for start_metrics_server idempotency."""

    def test_start_metrics_server_only_once(self):
        reset_metrics_server_state()
        with patch("utils.metrics.start_http_server") as mock_start:
            start_metrics_server(port=19999)
            start_metrics_server(port=19999)  # second call should be a no-op
            mock_start.assert_called_once_with(19999)
        reset_metrics_server_state()

    def test_reset_allows_restart(self):
        reset_metrics_server_state()
        with patch("utils.metrics.start_http_server") as mock_start:
            start_metrics_server(port=19998)
            reset_metrics_server_state()
            start_metrics_server(port=19997)
            assert mock_start.call_count == 2
        reset_metrics_server_state()


# ---------------------------------------------------------------------------
# Token cache metrics
# ---------------------------------------------------------------------------

class TestTokenCacheMetrics:
    """Tests for token cache metric helpers."""

    def test_record_cache_hit(self):
        before = TOKEN_CACHE_HITS._value.get()
        record_cache_hit()
        assert TOKEN_CACHE_HITS._value.get() == before + 1

    def test_record_cache_miss(self):
        before = TOKEN_CACHE_MISSES._value.get()
        record_cache_miss()
        assert TOKEN_CACHE_MISSES._value.get() == before + 1

    def test_record_cache_error_get(self):
        before = _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "get"})
        record_cache_error("get")
        assert _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "get"}) == before + 1

    def test_record_cache_error_set(self):
        before = _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "set"})
        record_cache_error("set")
        assert _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "set"}) == before + 1

    def test_record_cache_error_delete(self):
        before = _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "delete"})
        record_cache_error("delete")
        assert _get_counter_value(TOKEN_CACHE_ERRORS, {"operation": "delete"}) == before + 1

    def test_record_cache_write(self):
        before = TOKEN_CACHE_WRITES._value.get()
        record_cache_write()
        assert TOKEN_CACHE_WRITES._value.get() == before + 1

    def test_record_cache_delete(self):
        before = TOKEN_CACHE_DELETES._value.get()
        record_cache_delete()
        assert TOKEN_CACHE_DELETES._value.get() == before + 1


# ---------------------------------------------------------------------------
# Auth token fetch metrics
# ---------------------------------------------------------------------------

class TestAuthTokenMetrics:
    """Tests for auth token fetch metric helpers."""

    def test_record_auth_token_fetch_success(self):
        before = _get_counter_value(AUTH_TOKEN_REQUESTS, {"status": "success"})
        record_auth_token_fetch("success", 0.5)
        assert _get_counter_value(AUTH_TOKEN_REQUESTS, {"status": "success"}) == before + 1

    def test_record_auth_token_fetch_error(self):
        before = _get_counter_value(AUTH_TOKEN_REQUESTS, {"status": "error"})
        record_auth_token_fetch("error", 1.0)
        assert _get_counter_value(AUTH_TOKEN_REQUESTS, {"status": "error"}) == before + 1

    def test_record_auth_token_fetch_duration(self):
        record_auth_token_fetch("success", 0.123)
        sample = REGISTRY.get_sample_value(
            "pinelabs_auth_token_duration_seconds_count", {}
        )
        assert sample is not None and sample >= 1


# ---------------------------------------------------------------------------
# Circuit breaker metrics
# ---------------------------------------------------------------------------

class TestCircuitBreakerMetrics:
    """Tests for circuit breaker metric helpers."""

    def test_record_circuit_breaker_state_closed(self):
        record_circuit_breaker_state("test_cb", "closed")
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_cb"}) == 0

    def test_record_circuit_breaker_state_open(self):
        record_circuit_breaker_state("test_cb", "open")
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_cb"}) == 1

    def test_record_circuit_breaker_state_half_open(self):
        record_circuit_breaker_state("test_cb", "half_open")
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_cb"}) == 2

    def test_record_circuit_breaker_transition(self):
        before = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_cb_tr", "from_state": "closed", "to_state": "open"},
        )
        record_circuit_breaker_transition("test_cb_tr", "closed", "open")
        after = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_cb_tr", "from_state": "closed", "to_state": "open"},
        )
        assert after == before + 1
        # Should also update the state gauge
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_cb_tr"}) == 1

    def test_record_circuit_breaker_rejection(self):
        before = _get_counter_value(
            CIRCUIT_BREAKER_REJECTIONS, {"name": "test_cb_rej"}
        )
        record_circuit_breaker_rejection("test_cb_rej")
        after = _get_counter_value(
            CIRCUIT_BREAKER_REJECTIONS, {"name": "test_cb_rej"}
        )
        assert after == before + 1


# ---------------------------------------------------------------------------
# Redis availability metric
# ---------------------------------------------------------------------------

class TestRedisAvailabilityMetric:
    """Tests for Redis availability gauge."""

    def test_record_redis_up_true(self):
        record_redis_up(True)
        assert REDIS_UP._value.get() == 1

    def test_record_redis_up_false(self):
        record_redis_up(False)
        assert REDIS_UP._value.get() == 0


# ---------------------------------------------------------------------------
# Business outcome metrics
# ---------------------------------------------------------------------------

class TestBusinessOutcomeMetrics:
    """Tests for business outcome metric helpers."""

    def test_record_payment_link_success(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "payment_link", "status": "success"}
        )
        record_business_outcome("payment_link", "success")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "payment_link", "status": "success"}
        )
        assert after == before + 1

    def test_record_payment_link_failed(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "payment_link", "status": "failed"}
        )
        record_business_outcome("payment_link", "failed")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "payment_link", "status": "failed"}
        )
        assert after == before + 1

    def test_record_checkout_order_success(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "checkout_order", "status": "success"}
        )
        record_business_outcome("checkout_order", "success")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "checkout_order", "status": "success"}
        )
        assert after == before + 1

    def test_record_refund_success(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "refund", "status": "success"}
        )
        record_business_outcome("refund", "success")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "refund", "status": "success"}
        )
        assert after == before + 1

    def test_record_order_cancel_success(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "order_cancel", "status": "success"}
        )
        record_business_outcome("order_cancel", "success")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "order_cancel", "status": "success"}
        )
        assert after == before + 1

    def test_record_settlement_release_success(self):
        before = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "settlement_release", "status": "success"}
        )
        record_business_outcome("settlement_release", "success")
        after = _get_counter_value(
            BUSINESS_OUTCOMES, {"operation": "settlement_release", "status": "success"}
        )
        assert after == before + 1

    def test_invalid_status_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid business outcome status"):
            record_business_outcome("payment_link", "created")
