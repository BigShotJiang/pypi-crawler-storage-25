"""Tests for Pydantic models in models/payment_links.py."""

import pytest
from pydantic import ValidationError

from models.payment_links import (
    Address,
    AddressType,
    AllowedPaymentMethod,
    Amount,
    CreatePaymentLinkRequest,
    Customer,
    ProductDetail,
)


# ---------------------------------------------------------------------------
# Amount
# ---------------------------------------------------------------------------

class TestAmount:
    def test_valid_amount(self):
        a = Amount(value=50000, currency="INR")
        assert a.value == 50000
        assert a.currency == "INR"

    def test_default_currency(self):
        a = Amount(value=100)
        assert a.currency == "INR"

    def test_minimum_value(self):
        a = Amount(value=100)
        assert a.value == 100

    def test_maximum_value(self):
        a = Amount(value=100_000_000)
        assert a.value == 100_000_000

    def test_below_minimum_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            Amount(value=99)
        assert "greater than or equal to 100" in str(exc_info.value)

    def test_above_maximum_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            Amount(value=100_000_001)
        assert "less than or equal to 100000000" in str(exc_info.value)

    def test_missing_value_raises(self):
        with pytest.raises(ValidationError):
            Amount()


# ---------------------------------------------------------------------------
# Address
# ---------------------------------------------------------------------------

class TestAddress:
    def test_full_address(self):
        addr = Address(
            address1="123 Main St",
            address2="Apt 4",
            address3="Floor 2",
            pincode="560001",
            city="Bangalore",
            state="Karnataka",
            country="India",
            full_name="John Doe",
            address_type=AddressType.HOME,
            address_category="billing",
        )
        assert addr.address1 == "123 Main St"
        assert addr.address_type == AddressType.HOME
        assert addr.address_category == "billing"

    def test_minimal_address(self):
        addr = Address()
        assert addr.address1 is None
        assert addr.city is None

    def test_address_type_enum(self):
        assert AddressType.HOME.value == "HOME"
        assert AddressType.WORK.value == "WORK"
        assert AddressType.OTHER.value == "OTHER"

    def test_pincode_too_short(self):
        with pytest.raises(ValidationError):
            Address(pincode="12")  # min_length=3

    def test_address1_too_long(self):
        with pytest.raises(ValidationError):
            Address(address1="x" * 101)  # max_length=100

    def test_city_too_long(self):
        with pytest.raises(ValidationError):
            Address(city="x" * 51)  # max_length=50

    def test_pincode_max_length(self):
        with pytest.raises(ValidationError):
            Address(pincode="1" * 12)  # max_length=11


# ---------------------------------------------------------------------------
# Customer
# ---------------------------------------------------------------------------

class TestCustomer:
    def test_customer_with_email(self):
        c = Customer(email_id="test@example.com")
        assert c.email_id == "test@example.com"
        assert c.mobile_number is None

    def test_customer_with_mobile(self):
        c = Customer(mobile_number="9876543210")
        assert c.mobile_number == "9876543210"
        assert c.email_id is None

    def test_customer_with_both(self):
        c = Customer(email_id="a@b.com", mobile_number="9876543210")
        assert c.email_id == "a@b.com"
        assert c.mobile_number == "9876543210"

    def test_customer_missing_email_and_mobile_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            Customer()
        assert "email_id" in str(exc_info.value) or "mobile_number" in str(exc_info.value)

    def test_customer_full_details(self):
        c = Customer(
            email_id="kevin@example.com",
            first_name="Kevin",
            last_name="Bob",
            customer_id="1234567890",
            mobile_number="9876543210",
            country_code="+91",
            billing_address=Address(address1="Billing St", city="Mumbai"),
            shipping_address=Address(address1="Shipping St", city="Delhi"),
        )
        assert c.first_name == "Kevin"
        assert c.billing_address.city == "Mumbai"
        assert c.shipping_address.city == "Delhi"

    def test_mobile_too_short(self):
        with pytest.raises(ValidationError):
            Customer(mobile_number="123")  # min_length=10

    def test_mobile_too_long(self):
        with pytest.raises(ValidationError):
            Customer(mobile_number="1" * 21)  # max_length=20

    def test_email_too_long(self):
        with pytest.raises(ValidationError):
            Customer(email_id="a" * 50 + "@b.com")  # max_length=50

    def test_customer_id_too_long(self):
        with pytest.raises(ValidationError):
            Customer(email_id="a@b.com", customer_id="x" * 20)  # max_length=19

    def test_country_code_too_long(self):
        with pytest.raises(ValidationError):
            Customer(email_id="a@b.com", country_code="+12345678")  # max_length=5


# ---------------------------------------------------------------------------
# AllowedPaymentMethod enum
# ---------------------------------------------------------------------------

class TestAllowedPaymentMethod:
    def test_all_values(self):
        expected = {"CARD", "UPI", "POINTS", "NETBANKING", "WALLET", "CREDIT_EMI", "DEBIT_EMI"}
        actual = {m.value for m in AllowedPaymentMethod}
        assert actual == expected

    def test_invalid_method(self):
        with pytest.raises(ValueError):
            AllowedPaymentMethod("BITCOIN")


# ---------------------------------------------------------------------------
# ProductDetail
# ---------------------------------------------------------------------------

class TestProductDetail:
    def test_minimal_product(self):
        p = ProductDetail(product_code="redmi_10")
        assert p.product_code == "redmi_10"
        assert p.product_amount is None

    def test_product_with_amount(self):
        p = ProductDetail(
            product_code="iphone_15",
            product_amount=Amount(value=5000000, currency="INR"),
        )
        assert p.product_amount.value == 5000000

    def test_product_with_coupon_discount(self):
        p = ProductDetail(
            product_code="iphone_15",
            product_coupon_discount_amount=Amount(value=10000, currency="INR"),
        )
        assert p.product_coupon_discount_amount.value == 10000

    def test_missing_product_code_raises(self):
        with pytest.raises(ValidationError):
            ProductDetail()


# ---------------------------------------------------------------------------
# CreatePaymentLinkRequest
# ---------------------------------------------------------------------------

class TestCreatePaymentLinkRequest:
    def test_minimal_request(self):
        req = CreatePaymentLinkRequest(
            amount=Amount(value=50000),
            merchant_payment_link_reference="ref-001",
            customer=Customer(email_id="a@b.com"),
        )
        assert req.amount.value == 50000
        assert req.merchant_payment_link_reference == "ref-001"
        assert req.description is None

    def test_full_request(self):
        req = CreatePaymentLinkRequest(
            amount=Amount(value=100000, currency="INR"),
            merchant_payment_link_reference="ref-full",
            customer=Customer(email_id="a@b.com", mobile_number="9876543210"),
            description="Test payment",
            expire_by="2026-06-01T10:00Z",
            allowed_payment_methods=[AllowedPaymentMethod.CARD, AllowedPaymentMethod.UPI],
            product_details=[ProductDetail(product_code="item_1")],
            cart_coupon_discount_amount=Amount(value=500),
            merchant_metadata={"key1": "value1"},
        )
        assert req.description == "Test payment"
        assert len(req.allowed_payment_methods) == 2
        assert len(req.product_details) == 1
        assert req.merchant_metadata["key1"] == "value1"

    def test_missing_amount_raises(self):
        with pytest.raises(ValidationError):
            CreatePaymentLinkRequest(
                merchant_payment_link_reference="ref-001",
                customer=Customer(email_id="a@b.com"),
            )

    def test_missing_customer_raises(self):
        with pytest.raises(ValidationError):
            CreatePaymentLinkRequest(
                amount=Amount(value=50000),
                merchant_payment_link_reference="ref-001",
            )

    def test_missing_reference_raises(self):
        with pytest.raises(ValidationError):
            CreatePaymentLinkRequest(
                amount=Amount(value=50000),
                customer=Customer(email_id="a@b.com"),
            )

    def test_reference_too_long_raises(self):
        with pytest.raises(ValidationError):
            CreatePaymentLinkRequest(
                amount=Amount(value=50000),
                merchant_payment_link_reference="x" * 51,
                customer=Customer(email_id="a@b.com"),
            )

    def test_reference_empty_raises(self):
        with pytest.raises(ValidationError):
            CreatePaymentLinkRequest(
                amount=Amount(value=50000),
                merchant_payment_link_reference="",
                customer=Customer(email_id="a@b.com"),
            )

    def test_exclude_none_serialization(self):
        req = CreatePaymentLinkRequest(
            amount=Amount(value=50000),
            merchant_payment_link_reference="ref-001",
            customer=Customer(email_id="a@b.com"),
        )
        data = req.model_dump(exclude_none=True)
        assert "description" not in data
        assert "expire_by" not in data
        assert "allowed_payment_methods" not in data
        assert "product_details" not in data
        assert "amount" in data
        assert "customer" in data


# ==========================================================================
# Refund Models
# ==========================================================================

from models.refunds import (
    RefundAmount,
    RefundProductAmount,
    RefundProduct,
    SplitAmount,
    SplitDetail,
    SplitInfo,
    CreateRefundRequest,
)


# ---------------------------------------------------------------------------
# RefundAmount
# ---------------------------------------------------------------------------

class TestRefundAmount:
    def test_valid_amount(self):
        a = RefundAmount(value=50000, currency="INR")
        assert a.value == 50000
        assert a.currency == "INR"

    def test_default_currency(self):
        a = RefundAmount(value=1000)
        assert a.currency == "INR"

    def test_minimum_value(self):
        a = RefundAmount(value=100)
        assert a.value == 100

    def test_maximum_value(self):
        a = RefundAmount(value=100_000_000)
        assert a.value == 100_000_000

    def test_below_minimum_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            RefundAmount(value=99)
        assert "greater than or equal to 100" in str(exc_info.value)

    def test_above_maximum_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            RefundAmount(value=100_000_001)
        assert "less than or equal to 100000000" in str(exc_info.value)

    def test_missing_value_raises(self):
        with pytest.raises(ValidationError):
            RefundAmount()


# ---------------------------------------------------------------------------
# RefundProductAmount
# ---------------------------------------------------------------------------

class TestRefundProductAmount:
    def test_valid_product_amount(self):
        a = RefundProductAmount(value=10000, currency="INR")
        assert a.value == 10000

    def test_default_currency(self):
        a = RefundProductAmount(value=5000)
        assert a.currency == "INR"

    def test_minimum_value(self):
        a = RefundProductAmount(value=100)
        assert a.value == 100

    def test_maximum_value(self):
        a = RefundProductAmount(value=100_000_000)
        assert a.value == 100_000_000

    def test_below_minimum_raises(self):
        with pytest.raises(ValidationError):
            RefundProductAmount(value=99)

    def test_above_maximum_raises(self):
        with pytest.raises(ValidationError):
            RefundProductAmount(value=100_000_001)

    def test_missing_value_raises(self):
        with pytest.raises(ValidationError):
            RefundProductAmount()


# ---------------------------------------------------------------------------
# RefundProduct
# ---------------------------------------------------------------------------

class TestRefundProduct:
    def test_valid_product(self):
        p = RefundProduct(
            product_code="SM-S908",
            product_imei="123456789",
            product_amount=RefundProductAmount(value=5000),
        )
        assert p.product_code == "SM-S908"
        assert p.product_imei == "123456789"
        assert p.product_amount.value == 5000

    def test_product_without_amount(self):
        p = RefundProduct(product_code="X", product_imei="Y")
        assert p.product_amount is None

    def test_missing_product_code_raises(self):
        with pytest.raises(ValidationError):
            RefundProduct(product_imei="123456789")

    def test_missing_product_imei_is_none(self):
        p = RefundProduct(product_code="SM-S908")
        assert p.product_imei is None

    def test_missing_both_raises(self):
        with pytest.raises(ValidationError):
            RefundProduct()


# ---------------------------------------------------------------------------
# SplitAmount
# ---------------------------------------------------------------------------

class TestSplitAmount:
    def test_valid_split_amount(self):
        a = SplitAmount(value=20000, currency="INR")
        assert a.value == 20000
        assert a.currency == "INR"

    def test_default_currency(self):
        a = SplitAmount(value=500)
        assert a.currency == "INR"

    def test_below_minimum_raises(self):
        with pytest.raises(ValidationError):
            SplitAmount(value=50)

    def test_above_maximum_raises(self):
        with pytest.raises(ValidationError):
            SplitAmount(value=100_000_001)


# ---------------------------------------------------------------------------
# SplitDetail
# ---------------------------------------------------------------------------

class TestSplitDetail:
    def test_valid_split_detail(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="v1-250513063000-aa-UBAnaE-ss-g",
            split_merchant_id="merchant-1",
            merchant_settlement_reference="msr-001",
            amount=SplitAmount(value=20000),
            status="DO_NOT_RECOVER",
        )
        assert sd.parent_order_split_settlement_id == "v1-250513063000-aa-UBAnaE-ss-g"
        assert sd.split_merchant_id == "merchant-1"
        assert sd.merchant_settlement_reference == "msr-001"
        assert sd.amount.value == 20000
        assert sd.status == "DO_NOT_RECOVER"

    def test_split_detail_without_optional_fields(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="ss-1",
            split_merchant_id="m-1",
            merchant_settlement_reference="msr-1",
        )
        assert sd.amount is None
        assert sd.status is None

    def test_missing_parent_order_id_raises(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                split_merchant_id="m-1",
                merchant_settlement_reference="msr-1",
            )

    def test_missing_split_merchant_id_raises(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="ss-1",
                merchant_settlement_reference="msr-1",
            )

    def test_missing_merchant_settlement_ref_raises(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="ss-1",
                split_merchant_id="m-1",
            )

    def test_parent_order_id_max_length(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="x" * 51,
                split_merchant_id="m-1",
                merchant_settlement_reference="msr-1",
            )

    def test_merchant_settlement_ref_empty(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="ss-1",
                split_merchant_id="m-1",
                merchant_settlement_reference="",
            )

    def test_merchant_settlement_ref_max_length(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="ss-1",
                split_merchant_id="m-1",
                merchant_settlement_reference="x" * 51,
            )

    def test_status_do_not_recover(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="ss-1",
            split_merchant_id="m-1",
            merchant_settlement_reference="msr-1",
            status="DO_NOT_RECOVER",
        )
        assert sd.status == "DO_NOT_RECOVER"

    def test_status_none(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="ss-1",
            split_merchant_id="m-1",
            merchant_settlement_reference="msr-1",
        )
        assert sd.status is None


# ---------------------------------------------------------------------------
# SplitInfo
# ---------------------------------------------------------------------------

class TestSplitInfo:
    def test_valid_split_info(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="ss-1",
            split_merchant_id="m-1",
            merchant_settlement_reference="msr-1",
        )
        si = SplitInfo(split_type="AMOUNT", split_details=[sd])
        assert si.split_type == "AMOUNT"
        assert len(si.split_details) == 1

    def test_split_info_without_details(self):
        si = SplitInfo(split_type="AMOUNT")
        assert si.split_details is None

    def test_missing_split_type_raises(self):
        with pytest.raises(ValidationError):
            SplitInfo()


# ---------------------------------------------------------------------------
# CreateRefundRequest
# ---------------------------------------------------------------------------

class TestCreateRefundRequest:
    def test_minimal_request(self):
        req = CreateRefundRequest(
            merchant_order_reference="ref-1",
            order_amount=RefundAmount(value=50000),
        )
        assert req.merchant_order_reference == "ref-1"
        assert req.order_amount.value == 50000
        assert req.merchant_metadata is None
        assert req.products is None
        assert req.split_info is None

    def test_full_request(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="ss-1",
            split_merchant_id="m-1",
            merchant_settlement_reference="msr-1",
        )
        req = CreateRefundRequest(
            merchant_order_reference="ref-full",
            order_amount=RefundAmount(value=100000, currency="INR"),
            merchant_metadata={"key1": "DD", "key2": "XOF"},
            products=[
                RefundProduct(
                    product_code="SM-S908",
                    product_imei="123456789",
                    product_amount=RefundProductAmount(value=50000),
                )
            ],
            split_info=SplitInfo(split_type="AMOUNT", split_details=[sd]),
        )
        assert req.merchant_order_reference == "ref-full"
        assert req.order_amount.value == 100000
        assert req.merchant_metadata["key1"] == "DD"
        assert len(req.products) == 1
        assert req.split_info.split_type == "AMOUNT"

    def test_missing_merchant_order_reference_raises(self):
        with pytest.raises(ValidationError):
            CreateRefundRequest(
                order_amount=RefundAmount(value=50000),
            )

    def test_missing_order_amount_raises(self):
        with pytest.raises(ValidationError):
            CreateRefundRequest(
                merchant_order_reference="ref-1",
            )

    def test_empty_merchant_order_reference_raises(self):
        with pytest.raises(ValidationError):
            CreateRefundRequest(
                merchant_order_reference="",
                order_amount=RefundAmount(value=50000),
            )

    def test_merchant_order_reference_too_long_raises(self):
        with pytest.raises(ValidationError):
            CreateRefundRequest(
                merchant_order_reference="x" * 51,
                order_amount=RefundAmount(value=50000),
            )

    def test_merchant_metadata_optional(self):
        req = CreateRefundRequest(
            merchant_order_reference="ref-1",
            order_amount=RefundAmount(value=50000),
        )
        assert req.merchant_metadata is None

    def test_products_optional(self):
        req = CreateRefundRequest(
            merchant_order_reference="ref-1",
            order_amount=RefundAmount(value=50000),
        )
        assert req.products is None

    def test_split_info_optional(self):
        req = CreateRefundRequest(
            merchant_order_reference="ref-1",
            order_amount=RefundAmount(value=50000),
        )
        assert req.split_info is None

    def test_exclude_none_serialization(self):
        req = CreateRefundRequest(
            merchant_order_reference="ref-1",
            order_amount=RefundAmount(value=50000),
        )
        data = req.model_dump(exclude_none=True)
        assert "merchant_order_reference" in data
        assert "order_amount" in data
        assert "merchant_metadata" not in data
        assert "products" not in data
        assert "split_info" not in data


class TestRefundModelEdgeCases:
    """Phase 4 (F-034): edge-case validation tests."""

    def test_currency_lowercase_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=100, currency="inr")

    def test_currency_mixed_case_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=100, currency="Inr")

    def test_currency_too_short_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=100, currency="IN")

    def test_currency_too_long_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=100, currency="INRR")

    def test_currency_numeric_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=100, currency="123")

    def test_currency_valid_usd(self):
        amt = RefundAmount(value=100, currency="USD")
        assert amt.currency == "USD"

    def test_split_type_invalid_rejected(self):
        with pytest.raises(ValidationError):
            SplitInfo(split_type="PERCENTAGE")

    def test_split_detail_status_invalid_rejected(self):
        with pytest.raises(ValidationError):
            SplitDetail(
                parent_order_split_settlement_id="s1",
                split_merchant_id="m1",
                merchant_settlement_reference="ref1",
                status="RECOVER",
            )

    def test_split_detail_status_valid(self):
        sd = SplitDetail(
            parent_order_split_settlement_id="s1",
            split_merchant_id="m1",
            merchant_settlement_reference="ref1",
            status="DO_NOT_RECOVER",
        )
        assert sd.status == "DO_NOT_RECOVER"

    def test_amount_below_minimum_rejected(self):
        with pytest.raises(ValidationError):
            RefundAmount(value=99)

    def test_amount_at_minimum_accepted(self):
        amt = RefundAmount(value=100)
        assert amt.value == 100

    def test_product_imei_none_by_default(self):
        p = RefundProduct(product_code="P1")
        assert p.product_imei is None
