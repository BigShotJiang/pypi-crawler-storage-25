"""Tests for utils/errors.py — structured error response utilities."""

import json

from utils.errors import (
    error_response,
    api_error_response,
    auth_error_response,
    validation_error_response,
    unexpected_error_response,
)


class TestErrorResponse:
    def test_basic_error(self):
        result = json.loads(error_response(error="Something failed"))
        assert result["error"] == "Something failed"
        assert result["code"] == "INTERNAL_ERROR"
        assert "status_code" not in result

    def test_with_status_code(self):
        result = json.loads(
            error_response(error="Bad input", code="BAD_REQUEST", status_code=400)
        )
        assert result["code"] == "BAD_REQUEST"
        assert result["status_code"] == 400

    def test_with_details(self):
        result = json.loads(
            error_response(error="err", details={"field": "amount"})
        )
        assert result["details"] == {"field": "amount"}

    def test_sanitizes_email(self):
        result = json.loads(
            error_response(error="Error for user@example.com")
        )
        assert "user@example.com" not in result["error"]
        assert "[REDACTED]" in result["error"]

    def test_sanitizes_phone(self):
        result = json.loads(
            error_response(error="Error for 9876543210")
        )
        assert "9876543210" not in result["error"]
        assert "[REDACTED]" in result["error"]


class TestApiErrorResponse:
    def test_shape(self):
        result = json.loads(api_error_response("Not found", "NOT_FOUND", 404))
        assert result["error"] == "Not found"
        assert result["code"] == "NOT_FOUND"
        assert result["status_code"] == 404

    def test_with_details(self):
        result = json.loads(
            api_error_response("err", "ERR", 400, details={"min": 100})
        )
        assert result["details"] == {"min": 100}


class TestAuthErrorResponse:
    def test_shape(self):
        result = json.loads(auth_error_response("Missing token"))
        assert result["error"] == "Missing token"
        assert result["code"] == "AUTH_ERROR"
        assert result["status_code"] == 401


class TestValidationErrorResponse:
    def test_shape(self):
        result = json.loads(validation_error_response("Field required"))
        assert result["error"] == "Field required"
        assert result["code"] == "VALIDATION_ERROR"
        assert result["status_code"] == 422


class TestUnexpectedErrorResponse:
    def test_shape(self):
        result = json.loads(
            unexpected_error_response(RuntimeError("boom"), "create link")
        )
        assert "internal error" in result["error"].lower()
        assert "create link" in result["error"]
        assert "boom" not in result["error"]
        assert result["code"] == "INTERNAL_ERROR"
        assert result["status_code"] == 500

    def test_default_context(self):
        result = json.loads(unexpected_error_response(RuntimeError("x")))
        assert "operation" in result["error"]
        assert "x" not in result["error"].split("operation")[-1]

    def test_sanitizes_pii(self):
        result = json.loads(
            unexpected_error_response(
                RuntimeError("Failed for user@test.com"), "process"
            )
        )
        assert "user@test.com" not in result["error"]
