"""Tests for utils/health.py — Health and readiness check endpoints."""

import pytest
from starlette.testclient import TestClient
from starlette.applications import Starlette

from utils.health import health_check, readiness_check, register_health_endpoint, set_circuit_breaker
from utils.circuit_breaker import CircuitBreaker, STATE_CLOSED, STATE_OPEN


class TestHealthCheck:
    """Tests for the health check endpoint."""

    @pytest.fixture
    def app(self):
        """Create a minimal Starlette app with the health route."""
        app = Starlette()
        register_health_endpoint(app)
        return app

    @pytest.fixture
    def client(self, app):
        return TestClient(app)

    def test_health_returns_200(self, client):
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_body_structure(self, client):
        response = client.get("/health")
        body = response.json()
        assert body["status"] == "healthy"
        assert body["service"] == "pinelabs-mcp-server"
        assert "uptime_seconds" in body
        assert isinstance(body["uptime_seconds"], (int, float))

    def test_health_uptime_positive(self, client):
        response = client.get("/health")
        body = response.json()
        assert body["uptime_seconds"] >= 0


class TestReadinessCheck:
    """Tests for the readiness check endpoint."""

    @pytest.fixture
    def app(self):
        """Create a minimal Starlette app with the health/readiness routes."""
        app = Starlette()
        register_health_endpoint(app)
        return app

    @pytest.fixture
    def client(self, app):
        return TestClient(app)

    def test_ready_returns_200_when_circuit_closed(self, client):
        cb = CircuitBreaker(fail_max=5, reset_timeout=60, name="test")
        set_circuit_breaker(cb)
        response = client.get("/ready")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ready"
        assert body["circuit_breaker"] == STATE_CLOSED

    def test_ready_returns_503_when_circuit_open(self, client):
        cb = CircuitBreaker(fail_max=1, reset_timeout=60, name="test")
        set_circuit_breaker(cb)
        # Trip the circuit breaker
        cb.record_failure()
        assert cb.current_state == STATE_OPEN

        response = client.get("/ready")
        assert response.status_code == 503
        body = response.json()
        assert body["status"] == "degraded"
        assert body["circuit_breaker"] == STATE_OPEN

    def test_ready_returns_200_when_no_circuit_breaker_set(self, client):
        set_circuit_breaker(None)
        response = client.get("/ready")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ready"
        assert body["circuit_breaker"] == "unknown"


class TestRegisterHealthEndpoint:
    """Tests for register_health_endpoint."""

    def test_registers_on_starlette_app(self):
        app = Starlette()
        register_health_endpoint(app)
        # Verify the route was added
        client = TestClient(app)
        resp = client.get("/health")
        assert resp.status_code == 200

    def test_registers_ready_endpoint(self):
        app = Starlette()
        register_health_endpoint(app)
        client = TestClient(app)
        resp = client.get("/ready")
        assert resp.status_code in (200, 503)

    def test_warns_if_no_add_route(self, caplog):
        """If the app doesn't have add_route, log a warning."""

        class FakeApp:
            pass

        register_health_endpoint(FakeApp())
        assert "Could not register /health" in caplog.text
