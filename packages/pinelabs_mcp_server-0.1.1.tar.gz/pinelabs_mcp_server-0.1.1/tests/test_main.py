"""Tests for main.py — server creation."""

import asyncio
from unittest.mock import AsyncMock
from unittest.mock import patch, MagicMock

import pytest

from auth.credentials import get_client_credentials
from main import create_server, ClientCredentialsMiddleware


class TestCreateServer:
    def test_creates_fastmcp_instance(self):
        mcp, _middleware, _cache = create_server()
        assert mcp is not None
        # FastMCP has a name attribute
        assert mcp.name == "pinelabs-mcp-server"

    def test_server_has_instructions(self):
        mcp, _middleware, _cache = create_server()
        assert "Pine Labs" in (mcp.instructions or "")

    def test_tools_are_registered(self):
        mcp, _middleware, _cache = create_server()
        # Use the public async list_tools API to verify registered tools
        tools = asyncio.run(mcp.list_tools())
        tool_names = [t.name for t in tools]
        expected_tools = [
            "create_payment_link",
            "get_payment_link_by_id",
            "get_payment_link_by_merchant_reference",
            "cancel_payment_link",
            "resend_payment_link_notification",
            "cancel_order",
            "get_order_by_order_id",
            "create_order",
            "create_upi_intent_payment_with_qr",
            "get_payment_link_details",
            "get_order_details",
            "get_refund_order_details",
            "search_transaction",
        ]
        for name in expected_tools:
            assert name in tool_names, f"Tool '{name}' not registered"

    def test_server_returns_valid_mcp(self):
        """create_server should return a fully configured FastMCP instance."""
        mcp, _middleware, _cache = create_server()
        assert mcp.name == "pinelabs-mcp-server"
        assert mcp.instructions is not None


class TestClientCredentialsMiddleware:
    @pytest.mark.asyncio
    async def test_request_credentials_reset_after_request(self):
        seen_credentials: list[tuple[str, str]] = []
        previous_credentials = get_client_credentials()

        async def app(scope, receive, send):
            seen_credentials.append(get_client_credentials())

        middleware = ClientCredentialsMiddleware(app)
        send = AsyncMock()

        await middleware(
            {
                "type": "http",
                "headers": [
                    (b"x-client-id", b"client-a"),
                    (b"x-client-secret", b"secret-a"),
                ],
            },
            AsyncMock(),
            send,
        )

        assert seen_credentials == [("client-a", "secret-a")]
        assert get_client_credentials() == previous_credentials

    @pytest.mark.asyncio
    async def test_missing_headers_fail_closed(self):
        """When headers are missing, get_client_credentials() should raise inside the request."""
        raised = []

        async def app(scope, receive, send):
            try:
                get_client_credentials()
            except RuntimeError:
                raised.append(True)

        middleware = ClientCredentialsMiddleware(app)

        await middleware(
            {"type": "http", "headers": []},
            AsyncMock(),
            AsyncMock(),
        )

        assert raised == [True]
