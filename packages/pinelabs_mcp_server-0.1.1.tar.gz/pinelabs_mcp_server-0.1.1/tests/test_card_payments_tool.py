# """
# Tests for tools/card_payments.py — create_card_payment tool.
#
# DISABLED: card_payments tool is not registered in main.py.
# Uncomment when register_card_payment_tools is re-enabled.
# """
#
# import json
# from unittest.mock import patch, AsyncMock
#
# import pytest
#
# from clients.pinelabs_client import PineLabsAPIError
# from tests.conftest import _FakeMCP, AUTH_HEADERS
# from tools.card_payments import register_card_payment_tools
#
#
# @pytest.fixture()
# def tool(fake_mcp, mock_client):
#     register_card_payment_tools(fake_mcp, mock_client)
#     return fake_mcp.tools["create_card_payment"]
#
#
# # ---------------------------------------------------------------------------
# # Happy path
# # ---------------------------------------------------------------------------
#
# class TestCreateCardPaymentHappyPath:
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_direct_card_payment(self, _mock_headers, tool, mock_client) -> None:
#         mock_client.post = AsyncMock(return_value={"status": "PENDING_3DS"})
#
#         result = json.loads(await tool(
#             order_id="v1-123-aa-abc",
#             card_name="Jane Doe",
#             amount_value=1100,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="12",
#             card_expiry_year="2030",
#         ))
#         assert result["status"] == "PENDING_3DS"
#         mock_client.post.assert_awaited_once()
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_token_payment(self, _mock_headers, tool, mock_client) -> None:
#         mock_client.post = AsyncMock(return_value={"status": "SUCCESS"})
#
#         result = json.loads(await tool(
#             order_id="v1-123-aa-abc",
#             card_name="Jane Doe",
#             amount_value=5000,
#             use_token=True,
#             token_last4_digit="1111",
#             token_expiry_month="12",
#             token_expiry_year="2030",
#             token_value="tok-123",
#             token_cryptogram="/wAAAAAAl9SX1H==",
#             token_txn_type="NETWORK_TOKEN",
#         ))
#         assert result["status"] == "SUCCESS"
#
#
# # ---------------------------------------------------------------------------
# # Missing auth
# # ---------------------------------------------------------------------------
#
# class TestCreateCardPaymentMissingAuth:
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", side_effect=ValueError("no headers"))
#     async def test_missing_auth(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "AUTH_ERROR"
#         assert result["status_code"] == 401
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value={"authorization": "Basic abc"})
#     async def test_bad_auth_scheme(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "AUTH_ERROR"
#
#
# # ---------------------------------------------------------------------------
# # API error
# # ---------------------------------------------------------------------------
#
# class TestCreateCardPaymentAPIError:
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_api_error(self, _mock_headers, tool, mock_client) -> None:
#         mock_client.post = AsyncMock(
#             side_effect=PineLabsAPIError(400, "UPSTREAM_BAD_REQUEST", "Upstream service rejected the request")
#         )
#
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "UPSTREAM_BAD_REQUEST"
#         assert result["status_code"] == 400
#
#
# # ---------------------------------------------------------------------------
# # Unexpected error
# # ---------------------------------------------------------------------------
#
# class TestCreateCardPaymentUnexpectedError:
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_unexpected_exception(self, _mock_headers, tool, mock_client) -> None:
#         mock_client.post = AsyncMock(side_effect=RuntimeError("boom"))
#
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "INTERNAL_ERROR"
#         assert result["status_code"] == 500
#
#
# # ---------------------------------------------------------------------------
# # Input validation
# # ---------------------------------------------------------------------------
#
# class TestCreateCardPaymentValidation:
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_invalid_order_id(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="../../etc/passwd",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_missing_card_fields(self, _mock_headers, tool) -> None:
#         """Direct card payment without card_number should fail validation."""
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_token_missing_required_fields(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             use_token=True,
#             token_last4_digit="1111",
#             # missing other token fields
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_alt_token_requires_cvv(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             use_token=True,
#             token_last4_digit="1111",
#             token_expiry_month="12",
#             token_expiry_year="2030",
#             token_value="tok-1",
#             token_cryptogram="crypt-1",
#             token_txn_type="ALT_TOKEN",
#             # no token_cvv
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_merchant_ref_too_long(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             merchant_payment_reference="x" * 51,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_mcc_missing_required_fields(self, _mock_headers, tool) -> None:
#         """MCC transaction with partial risk fields should fail."""
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#             risk_email="test@example.com",
#             # Missing risk_first_name, risk_last_name, device_channel, browser_ipaddress
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_native_otp_incomplete_device_info(self, _mock_headers, tool) -> None:
#         """Native OTP flow with partial device fields should fail."""
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#             device_channel="browser",
#             # Missing other required browser fields
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#
#     @pytest.mark.asyncio
#     @patch("tools.card_payments.get_http_headers", return_value=AUTH_HEADERS)
#     async def test_base_amount_non_inr_rejected(self, _mock_headers, tool) -> None:
#         result = json.loads(await tool(
#             order_id="order-1",
#             card_name="Test",
#             amount_value=1000,
#             card_number="4111111111111111",
#             card_cvv="123",
#             card_expiry_month="01",
#             card_expiry_year="2030",
#             risk_email="test@example.com",
#             risk_first_name="John",
#             risk_last_name="Doe",
#             device_channel="browser",
#             browser_ipaddress="1.2.3.4",
#             base_amount_value=500,
#             base_amount_currency="USD",
#         ))
#         assert result["code"] == "VALIDATION_ERROR"
#         assert "INR" in result["error"]

