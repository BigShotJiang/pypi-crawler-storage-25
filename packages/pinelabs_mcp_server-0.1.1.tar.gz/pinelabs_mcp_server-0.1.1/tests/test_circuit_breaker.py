"""Tests for the circuit breaker utility in utils/circuit_breaker.py."""

import pytest

from utils.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerError,
    STATE_CLOSED,
    STATE_OPEN,
    STATE_HALF_OPEN,
)
from utils.metrics import (
    CIRCUIT_BREAKER_STATE,
    CIRCUIT_BREAKER_TRANSITIONS,
    CIRCUIT_BREAKER_REJECTIONS,
)


class TestCircuitBreakerStates:
    def test_initial_state_is_closed(self):
        cb = CircuitBreaker(fail_max=3, reset_timeout=10)
        assert cb.current_state == STATE_CLOSED

    def test_opens_after_fail_max(self):
        cb = CircuitBreaker(fail_max=2, reset_timeout=10)
        cb.record_failure()
        assert cb.current_state == STATE_CLOSED
        cb.record_failure()
        assert cb.current_state == STATE_OPEN

    def test_success_resets_to_closed(self):
        cb = CircuitBreaker(fail_max=2, reset_timeout=10)
        cb.record_failure()
        cb.record_success()
        assert cb.current_state == STATE_CLOSED
        assert cb._fail_count == 0

    def test_transitions_to_half_open_after_timeout(self):
        cb = CircuitBreaker(fail_max=1, reset_timeout=0.01)
        cb.record_failure()
        # With very short reset_timeout, wait for it to transition
        import time
        time.sleep(0.02)
        assert cb.current_state == STATE_HALF_OPEN


class TestCircuitBreakerCallAsync:
    @pytest.mark.asyncio
    async def test_call_succeeds_in_closed(self):
        cb = CircuitBreaker(fail_max=3, reset_timeout=10)

        async def ok():
            return "result"

        result = await cb.call_async(ok)
        assert result == "result"
        assert cb.current_state == STATE_CLOSED

    @pytest.mark.asyncio
    async def test_call_records_failure_on_exception(self):
        cb = CircuitBreaker(fail_max=3, reset_timeout=10)

        async def fail():
            raise ValueError("boom")

        with pytest.raises(ValueError):
            await cb.call_async(fail)
        assert cb._fail_count == 1

    @pytest.mark.asyncio
    async def test_call_rejected_when_open(self):
        cb = CircuitBreaker(fail_max=1, reset_timeout=9999)

        async def fail():
            raise ValueError("boom")

        # Trip the circuit
        with pytest.raises(ValueError):
            await cb.call_async(fail)
        assert cb.current_state == STATE_OPEN

        # Next call should be rejected
        with pytest.raises(CircuitBreakerError):
            await cb.call_async(fail)

    @pytest.mark.asyncio
    async def test_half_open_success_resets_to_closed(self):
        cb = CircuitBreaker(fail_max=1, reset_timeout=0.01)

        async def fail():
            raise ValueError("boom")

        async def ok():
            return "ok"

        # Trip the circuit
        with pytest.raises(ValueError):
            await cb.call_async(fail)

        # Wait for reset_timeout
        import time
        time.sleep(0.02)
        assert cb.current_state == STATE_HALF_OPEN

        # Successful probe resets to CLOSED
        result = await cb.call_async(ok)
        assert result == "ok"
        assert cb.current_state == STATE_CLOSED

    @pytest.mark.asyncio
    async def test_half_open_failure_reopens(self):
        cb = CircuitBreaker(fail_max=1, reset_timeout=0.01)

        async def fail():
            raise ValueError("boom")

        # Trip the circuit
        with pytest.raises(ValueError):
            await cb.call_async(fail)

        import time
        time.sleep(0.02)
        assert cb.current_state == STATE_HALF_OPEN

        # Failed probe reopens the circuit — fail_count increments and
        # immediately re-opens since fail_max=1
        with pytest.raises(ValueError):
            await cb.call_async(fail)
        # After failure in half_open, it goes back to OPEN. Check the internal
        # state directly since current_state may transition if timeout is tiny.
        assert cb._state == STATE_OPEN


# ---------------------------------------------------------------------------
# Circuit breaker metric emission tests
# ---------------------------------------------------------------------------


def _get_gauge_value(gauge, labels: dict) -> float:
    try:
        return gauge.labels(**labels)._value.get()
    except Exception:
        return 0.0


def _get_counter_value(counter, labels: dict) -> float:
    try:
        return counter.labels(**labels)._value.get()
    except Exception:
        return 0.0


class TestCircuitBreakerMetricsEmission:
    """Verify that CircuitBreaker operations emit Prometheus metrics."""

    def test_initial_state_sets_gauge_to_closed(self):
        cb = CircuitBreaker(fail_max=3, reset_timeout=10, name="test_init_gauge")
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_init_gauge"}) == 0

    def test_opening_emits_transition(self):
        cb = CircuitBreaker(fail_max=2, reset_timeout=9999, name="test_open_tr")
        before = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_open_tr", "from_state": "closed", "to_state": "open"},
        )
        cb.record_failure()
        cb.record_failure()  # triggers OPEN
        after = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_open_tr", "from_state": "closed", "to_state": "open"},
        )
        assert after == before + 1
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_open_tr"}) == 1

    def test_success_after_half_open_emits_transition_to_closed(self):
        import time
        cb = CircuitBreaker(fail_max=1, reset_timeout=0.01, name="test_ho_close")
        cb.record_failure()
        time.sleep(0.02)
        _ = cb.current_state  # triggers HALF_OPEN transition
        before = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_ho_close", "from_state": "half_open", "to_state": "closed"},
        )
        cb.record_success()
        after = _get_counter_value(
            CIRCUIT_BREAKER_TRANSITIONS,
            {"name": "test_ho_close", "from_state": "half_open", "to_state": "closed"},
        )
        assert after == before + 1
        assert _get_gauge_value(CIRCUIT_BREAKER_STATE, {"name": "test_ho_close"}) == 0

    @pytest.mark.asyncio
    async def test_rejection_increments_counter(self):
        cb = CircuitBreaker(fail_max=1, reset_timeout=9999, name="test_reject")

        async def fail():
            raise ValueError("boom")

        with pytest.raises(ValueError):
            await cb.call_async(fail)

        before = _get_counter_value(
            CIRCUIT_BREAKER_REJECTIONS, {"name": "test_reject"}
        )
        with pytest.raises(CircuitBreakerError):
            await cb.call_async(fail)
        after = _get_counter_value(
            CIRCUIT_BREAKER_REJECTIONS, {"name": "test_reject"}
        )
        assert after == before + 1
