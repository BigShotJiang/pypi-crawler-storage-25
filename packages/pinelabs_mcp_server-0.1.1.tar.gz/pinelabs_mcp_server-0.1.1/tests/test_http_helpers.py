import json

import pytest

from utils.http_helpers import extract_bearer_token, json_error


def test_json_error_with_status_code() -> None:
    payload = json.loads(json_error("VALIDATION_ERROR", "Bad input", 400))
    assert payload == {
        "code": "VALIDATION_ERROR",
        "message": "Bad input",
        "status_code": 400,
    }


def test_json_error_without_status_code() -> None:
    payload = json.loads(json_error("INTERNAL_ERROR", "Unexpected failure"))
    assert payload == {
        "code": "INTERNAL_ERROR",
        "message": "Unexpected failure",
    }


def test_extract_bearer_token_success() -> None:
    token = extract_bearer_token({"authorization": "Bearer sample-token"})
    assert token == "sample-token"


def test_extract_bearer_token_invalid_header() -> None:
    with pytest.raises(ValueError):
        extract_bearer_token({"authorization": "Basic abc"})
