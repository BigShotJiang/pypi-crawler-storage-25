"""
Async HTTP client for Pine Labs API.

Uses TokenManager to auto-generate access tokens from client credentials.
Auto-generates Request-ID (UUID) and Request-Timestamp (ISO 8601) for each call.
Features: connection pooling, retry with backoff for transient failures, 204 handling,
  Prometheus metrics recording, OpenTelemetry tracing, circuit breaker.
"""

import json
import os
import re
import uuid
import time
import logging
import asyncio
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from opentelemetry.trace import StatusCode
from opentelemetry import propagate

from utils.pii_filter import filter_pii
from utils.metrics import record_api_request, record_api_error, record_api_retry
from utils.tracing import get_tracer
from utils.circuit_breaker import CircuitBreaker, CircuitBreakerError, STATE_OPEN
from auth.token_manager import TokenManager

logger = logging.getLogger("pinelabs-mcp-server.client")

# HTTP status codes that are safe to retry (server-side / transient)
_RETRYABLE_STATUS_CODES = frozenset({429, 502, 503, 504})

# Route-template patterns for normalizing dynamic path segments in metric labels.
# Order matters: more specific patterns must come first.
_ROUTE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"/pay/v1/paymentlink/ref/[^/]+$"), "/pay/v1/paymentlink/ref/{merchantRef}"),
    (re.compile(r"/pay/v1/paymentlink/[^/]+/cancel$"), "/pay/v1/paymentlink/{paymentLinkId}/cancel"),
    (re.compile(r"/pay/v1/paymentlink/[^/]+/notify$"), "/pay/v1/paymentlink/{paymentLinkId}/notify"),
    (re.compile(r"/pay/v1/paymentlink/[^/]+$"), "/pay/v1/paymentlink/{paymentLinkId}"),
    (re.compile(r"/pay/v1/orders/[^/]+/settlementId/[^/]+/release$"), "/pay/v1/orders/{orderId}/settlementId/{settlementId}/release"),
    (re.compile(r"/pay/v1/orders/[^/]+/settlementId/[^/]+/cancel$"), "/pay/v1/orders/{orderId}/settlementId/{settlementId}/cancel"),
    (re.compile(r"/pay/v1/orders/[^/]+/payments$"), "/pay/v1/orders/{orderId}/payments"),
    (re.compile(r"/pay/v1/orders/[^/]+/cancel$"), "/pay/v1/orders/{orderId}/cancel"),
    (re.compile(r"/pay/v1/orders$"), "/pay/v1/orders"),
    (re.compile(r"/pay/v1/orders/[^/]+$"), "/pay/v1/orders/{orderId}"),
    (re.compile(r"/settlements/v1/detail/[^/]+$"), "/settlements/v1/detail/{utr}"),
    (re.compile(r"/checkout/v1/orders$"), "/checkout/v1/orders"),
    (re.compile(r"/settlements/v1/list$"), "/settlements/v1/list"),
    (re.compile(r"/mcp/v1/payment-link/details$"), "/mcp/v1/payment-link/details"),
    (re.compile(r"/mcp/v1/order/details$"), "/mcp/v1/order/details"),
    (re.compile(r"/mcp/v1/refund/order/details$"), "/mcp/v1/refund/order/details"),
    (re.compile(r"/mcp/v1/refund/order/[^/]+$"), "/mcp/v1/refund/order/{orderId}"),
    (re.compile(r"/mcp/v1/search/transaction/[^/]+$"), "/mcp/v1/search/transaction/{transactionId}"),
    (re.compile(r"/mcp/v1/merchant/transactions/success-rate$"), "/mcp/v1/merchant/transactions/success-rate"),
]


def _normalize_path(path: str) -> str:
    """Replace dynamic path segments with route-template placeholders.

    Keeps metric label cardinality low so Prometheus queries
    can aggregate by route instead of per-ID.

    >>> _normalize_path("/pay/v1/paymentlink/pl-v1-abc/cancel")
    '/pay/v1/paymentlink/{paymentLinkId}/cancel'
    >>> _normalize_path("/pay/v1/paymentlink")
    '/pay/v1/paymentlink'
    """
    for pattern, template in _ROUTE_PATTERNS:
        if pattern.search(path):
            return template
    return path


class PineLabsAPIError(Exception):
    """Raised when Pine Labs API returns an error response."""

    def __init__(self, status_code: int, code: str, message: str, payload: dict | None = None):
        self.status_code = status_code
        self.code = code
        self.message = message
        self.payload = payload or {}
        super().__init__(f"[{status_code}] {code}: {message}")


class PineLabsClient:
    """Async HTTP client for Pine Labs API with connection pooling, retry, and circuit breaker."""

    def __init__(
        self,
        base_url: str,
        token_manager: TokenManager,
        max_retries: int = 3,
        base_backoff: float = 1.0,
        timeout: Optional[float] = None,
        circuit_breaker: Optional[CircuitBreaker] = None,
    ) -> None:
        self.base_url = base_url
        self._token_manager = token_manager
        self._max_retries = max_retries
        self._base_backoff = base_backoff
        self._timeout = timeout or float(os.getenv("HTTP_TIMEOUT", "30.0"))
        self._client: httpx.AsyncClient | None = None
        self._circuit_breaker = circuit_breaker or CircuitBreaker(
            fail_max=5,
            reset_timeout=60,
            name="pinelabs_api",
        )

    def _get_client(self) -> httpx.AsyncClient:
        """Get or lazily create the shared HTTP client (connection pooling)."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self._timeout, verify=True)
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    def _build_headers(
        self,
        bearer_token: str,
        idempotency_key: Optional[str] = None,
    ) -> dict[str, str]:
        """Build request headers with auth, request ID, timestamp, and optional idempotency key."""
        headers = {
            "Authorization": f"Bearer {bearer_token}",
            "Content-Type": "application/json",
            "Request-ID": str(uuid.uuid4()),
            "Request-Timestamp": datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%S.%fZ"
            ),
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return headers

    def _inject_trace_context(self, headers: dict[str, str]) -> None:
        """Inject OpenTelemetry trace context into outgoing request headers."""
        propagate.inject(headers)

    async def _execute_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> httpx.Response:
        """Execute a single HTTP request against Pine Labs API.

        Args:
            method: HTTP method name ('get', 'post', 'put', 'patch').
            url: Full URL for the request.
            headers: Request headers dict.
            payload: Optional JSON request body.
            params: Optional query parameters.

        Returns:
            The httpx Response object.
        """
        client = self._get_client()
        kwargs: dict[str, Any] = {"headers": headers}
        if payload is not None:
            kwargs["json"] = payload
        if params is not None:
            kwargs["params"] = params
        return await getattr(client, method)(url, **kwargs)

    def _record_success_metrics(
        self,
        method: str,
        route: str,
        status_code: int,
        elapsed: float,
        span: Any,
    ) -> None:
        """Record Prometheus metrics and span attributes for a successful request."""
        record_api_request(method.upper(), route, status_code, elapsed)
        span.set_attribute("http.status_code", status_code)

    def _record_failure_metrics(
        self,
        method: str,
        route: str,
        status_code: int,
        error_code: str,
        elapsed: float,
        span: Any,
        exc: Exception,
    ) -> None:
        """Record Prometheus metrics and span attributes for a failed request."""
        record_api_request(method.upper(), route, status_code, elapsed)
        record_api_error(method.upper(), route, error_code)
        span.set_status(StatusCode.ERROR, str(exc))
        span.record_exception(exc)

    async def _request(
        self,
        method: str,
        path: str,
        payload: dict | None = None,
        idempotency_key: Optional[str] = None,
        params: dict | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Central request handler with retry logic, circuit breaker, and tracing.

        Retries on network errors (ConnectError, TimeoutException) and
        retryable HTTP status codes (429, 502, 503, 504) with exponential backoff.
        Records Prometheus metrics, creates OpenTelemetry spans, and uses a
        circuit breaker to prevent cascading failures.

        Args:
            method: HTTP method name ('get', 'post', 'put', 'patch').
            path: API path (e.g., '/pay/v1/paymentlink').
            payload: Optional JSON request body.
            idempotency_key: Optional idempotency key for POST/PUT/PATCH requests.
            params: Optional query parameters for GET requests.
            extra_headers: Optional additional headers to include in the request.

        Returns:
            Parsed JSON response as dict.

        Raises:
            PineLabsAPIError: If API returns a non-retryable error or retries exhausted.
        """
        from auth.credentials import get_client_credentials
        client_id, client_secret = get_client_credentials()
        bearer_token = await self._token_manager.get_access_token(
            client_id, client_secret,
        )
        url = f"{self.base_url}{path}"
        headers = self._build_headers(bearer_token, idempotency_key)
        if extra_headers:
            headers.update(extra_headers)
        request_id = headers["Request-ID"]
        max_attempts = 1 + self._max_retries
        route = _normalize_path(path)

        tracer = get_tracer()
        last_exc: Exception | None = None

        with tracer.start_as_current_span(
            f"pinelabs.{method.upper()} {route}",
            attributes={
                "http.method": method.upper(),
                "http.url": url,
                "http.route": route,
                "http.path": path,
                "pinelabs.request_id": request_id,
            },
        ) as span:
            # Inject trace context into outgoing headers for distributed tracing
            self._inject_trace_context(headers)

            trace_id = format(span.get_span_context().trace_id, "032x")
            logger.info(
                "%s %s | Request-ID: %s | Trace-ID: %s",
                method.upper(), path, request_id, trace_id,
            )

            # Check circuit breaker state before attempting requests
            if self._circuit_breaker.current_state == STATE_OPEN:
                logger.warning(
                    "Circuit breaker OPEN for %s %s | Request-ID: %s",
                    method.upper(), path, request_id,
                )
                record_api_error(method.upper(), route, "CIRCUIT_OPEN")
                span.set_status(StatusCode.ERROR, "Circuit breaker open")
                raise PineLabsAPIError(
                    status_code=503,
                    code="CIRCUIT_OPEN",
                    message="Service temporarily unavailable (circuit breaker open)",
                )

            request_start = time.perf_counter()

            for attempt in range(max_attempts):
                try:
                    response = await self._circuit_breaker.call_async(
                        self._execute_request, method, url, headers, payload, params,
                    )

                    # Retry on transient server errors (if attempts remain)
                    if (
                        response.status_code in _RETRYABLE_STATUS_CODES
                        and attempt < max_attempts - 1
                    ):
                        wait = self._base_backoff * (2 ** attempt)
                        logger.warning(
                            "Retryable status %d on %s %s (attempt %d/%d). "
                            "Retrying in %.1fs | Request-ID: %s | Trace-ID: %s",
                            response.status_code,
                            method.upper(),
                            path,
                            attempt + 1,
                            max_attempts,
                            wait,
                            request_id,
                            trace_id,
                        )
                        record_api_retry(method.upper(), route)
                        span.add_event(
                            "retry",
                            {"attempt": attempt + 1, "status_code": response.status_code},
                        )
                        await asyncio.sleep(wait)
                        continue

                    result = self._handle_response(response)
                    span.set_status(StatusCode.OK)

                    # Record success metrics
                    elapsed = time.perf_counter() - request_start
                    self._record_success_metrics(
                        method, route, response.status_code, elapsed, span,
                    )

                    return result

                except CircuitBreakerError:
                    elapsed = time.perf_counter() - request_start
                    record_api_request(method.upper(), route, 0, elapsed)
                    record_api_error(method.upper(), route, "CIRCUIT_OPEN")
                    span.set_status(StatusCode.ERROR, "Circuit breaker tripped")
                    raise PineLabsAPIError(
                        status_code=503,
                        code="CIRCUIT_OPEN",
                        message="Service temporarily unavailable (circuit breaker open)",
                    )

                except (httpx.ConnectError, httpx.TimeoutException) as exc:
                    last_exc = exc
                    if attempt < max_attempts - 1:
                        wait = self._base_backoff * (2 ** attempt)
                        logger.warning(
                            "Transient error on %s %s (attempt %d/%d): %s. "
                            "Retrying in %.1fs | Request-ID: %s | Trace-ID: %s",
                            method.upper(),
                            path,
                            attempt + 1,
                            max_attempts,
                            type(exc).__name__,
                            wait,
                            request_id,
                            trace_id,
                        )
                        record_api_retry(method.upper(), route)
                        span.add_event(
                            "retry",
                            {"attempt": attempt + 1, "error": type(exc).__name__},
                        )
                        await asyncio.sleep(wait)
                        continue

                    elapsed = time.perf_counter() - request_start
                    self._record_failure_metrics(
                        method, route, 0, "CONNECTION_ERROR", elapsed, span, exc,
                    )

                    raise PineLabsAPIError(
                        status_code=0,
                        code="CONNECTION_ERROR",
                        message=f"Failed to connect after {max_attempts} attempts: {exc}",
                    ) from exc

                except PineLabsAPIError as exc:
                    # Non-retryable API error from _handle_response
                    elapsed = time.perf_counter() - request_start
                    self._record_failure_metrics(
                        method, route, exc.status_code, exc.code, elapsed, span, exc,
                    )
                    span.set_attribute("http.status_code", exc.status_code)
                    raise

        # Should not reach here, but just in case
        if last_exc:
            raise PineLabsAPIError(
                status_code=0,
                code="CONNECTION_ERROR",
                message=f"Request failed after {max_attempts} attempts",
            ) from last_exc
        raise PineLabsAPIError(
            status_code=0,
            code="UNKNOWN_ERROR",
            message="Request failed unexpectedly",
        )

    async def post(
        self,
        path: str,
        payload: dict,
        idempotency_key: Optional[str] = None,
    ) -> dict[str, Any]:
        """Make a POST request to Pine Labs API.

        Args:
            path: API path (e.g., '/pay/v1/paymentlink').
            payload: JSON request body.
            idempotency_key: Optional idempotency key to prevent duplicate operations.

        Returns:
            Parsed JSON response as dict.
        """
        if idempotency_key is None:
            idempotency_key = str(uuid.uuid4())
        return await self._request("post", path, payload, idempotency_key)

    async def get(
        self,
        path: str,
        params: dict | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make a GET request to Pine Labs API.

        Args:
            path: API path (e.g., '/pay/v1/paymentlink/pl-123').
            params: Optional query parameters.
            extra_headers: Optional additional headers to include in the request.

        Returns:
            Parsed JSON response as dict.
        """
        return await self._request("get", path, params=params, extra_headers=extra_headers)

    async def put(
        self,
        path: str,
        payload: dict | None = None,
        idempotency_key: Optional[str] = None,
    ) -> dict[str, Any]:
        """Make a PUT request to Pine Labs API.

        Args:
            path: API path.
            payload: Optional JSON request body.
            idempotency_key: Optional idempotency key to prevent duplicate operations.

        Returns:
            Parsed JSON response as dict.
        """
        if idempotency_key is None:
            idempotency_key = str(uuid.uuid4())
        return await self._request("put", path, payload, idempotency_key)

    async def patch(
        self,
        path: str,
        payload: dict | None = None,
        idempotency_key: Optional[str] = None,
    ) -> dict[str, Any]:
        """Make a PATCH request to Pine Labs API.

        Args:
            path: API path.
            payload: Optional JSON request body.
            idempotency_key: Optional idempotency key to prevent duplicate operations.

        Returns:
            Parsed JSON response as dict.
        """
        return await self._request("patch", path, payload, idempotency_key)

    @staticmethod
    def _handle_response(response: httpx.Response) -> dict[str, Any]:
        """Handle API response, raising PineLabsAPIError on failure.

        Args:
            response: The httpx Response object.

        Returns:
            Parsed and PII-filtered JSON response as dict.

        Raises:
            PineLabsAPIError: If the response indicates an error (non-2xx status).
        """
        if 200 <= response.status_code < 300:
            # Handle 204 No Content and empty response bodies
            if response.status_code == 204 or not response.content:
                return {}
            data = response.json()
            return filter_pii(data)

        # Parse Pine Labs error response
        try:
            error_body = response.json()
            raise PineLabsAPIError(
                status_code=response.status_code,
                code=error_body.get("code", "UNKNOWN_ERROR"),
                message=error_body.get("message", "Unknown error occurred"),
                payload=error_body.get("additionalErrorPayload"),
            )
        except json.JSONDecodeError:
            raise PineLabsAPIError(
                status_code=response.status_code,
                code="UNKNOWN_ERROR",
                message=response.text or "Unknown error occurred",
            )
