"""
Health check endpoint for Pine Labs MCP Server.

Provides lightweight HTTP health endpoints for Kubernetes
liveness and readiness probes.  Runs on the main app port as
Starlette routes added to the FastMCP app.
"""

from __future__ import annotations

import time
import logging
from typing import Any, Optional

from starlette.requests import Request
from starlette.responses import JSONResponse

from utils.circuit_breaker import CircuitBreaker, STATE_OPEN

logger = logging.getLogger("pinelabs-mcp-server.health")

_start_time: float = time.time()
_circuit_breaker: Optional[CircuitBreaker] = None


def set_circuit_breaker(cb: CircuitBreaker) -> None:
    """Register the circuit breaker instance for readiness checks."""
    global _circuit_breaker
    _circuit_breaker = cb


async def health_check(request: Request) -> JSONResponse:
    """Return server liveness status (always healthy if process is running).

    Response body::

        {
            "status": "healthy",
            "uptime_seconds": 123.45,
            "service": "pinelabs-mcp-server"
        }
    """
    uptime = round(time.time() - _start_time, 2)
    body: dict[str, Any] = {
        "status": "healthy",
        "uptime_seconds": uptime,
        "service": "pinelabs-mcp-server",
    }
    return JSONResponse(body, status_code=200)


async def readiness_check(request: Request) -> JSONResponse:
    """Return server readiness status.

    Reports degraded (503) when the circuit breaker is OPEN, indicating
    the upstream Pine Labs API is unreachable.

    Response body::

        {
            "status": "ready" | "degraded",
            "uptime_seconds": 123.45,
            "service": "pinelabs-mcp-server",
            "circuit_breaker": "closed" | "open" | "half_open"
        }
    """
    uptime = round(time.time() - _start_time, 2)
    cb_state = _circuit_breaker.current_state if _circuit_breaker else "unknown"
    is_ready = cb_state != STATE_OPEN

    body: dict[str, Any] = {
        "status": "ready" if is_ready else "degraded",
        "uptime_seconds": uptime,
        "service": "pinelabs-mcp-server",
        "circuit_breaker": cb_state,
    }
    return JSONResponse(body, status_code=200 if is_ready else 503)


def register_health_endpoint(app: Any) -> None:
    """Add ``/health`` and ``/ready`` routes to a Starlette/FastAPI/FastMCP app.

    Args:
        app: An object that exposes ``.add_route()`` (Starlette Application).
    """
    if hasattr(app, "add_route"):
        app.add_route("/health", health_check, methods=["GET"])
        app.add_route("/ready", readiness_check, methods=["GET"])
        logger.info("Health endpoint registered at /health, readiness at /ready")
    else:
        logger.warning(
            "Could not register /health — app does not support add_route"
        )
