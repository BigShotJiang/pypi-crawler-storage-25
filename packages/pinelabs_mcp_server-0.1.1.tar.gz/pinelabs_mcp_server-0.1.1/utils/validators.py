"""
Shared validation utilities for Pine Labs MCP Server.

Provides reusable functions for resource ID validation
and timestamp validation — used across all tool modules.
"""

import re
from datetime import datetime, timedelta, timezone

# Allowed characters in resource IDs
_SAFE_ID_PATTERN = re.compile(r"^[a-zA-Z0-9\-_]+$")
_SAFE_ID_PATTERN_DOTS = re.compile(r"^[a-zA-Z0-9\-_.]+$")


def validate_resource_id(
    value: str, field_name: str, max_length: int = 50, *, allow_dots: bool = False
) -> str:
    """Validate a resource ID used in URL path segments.

    Ensures the ID is non-empty, within length limits, and contains only
    safe characters (no path-traversal or injection vectors).

    Args:
        value: The ID value to validate.
        field_name: Human-readable field name for error messages.
        max_length: Maximum allowed length (default: 50).
        allow_dots: If True, allow dots in the ID (e.g. for payment_link_id
            or order_id). Defaults to False per Pine Labs merchant reference spec.

    Returns:
        The validated and stripped ID string.

    Raises:
        ValueError: If the ID is empty, too long, or contains unsafe characters.
    """
    if not value or not value.strip():
        raise ValueError(f"{field_name} is required and must not be empty.")

    value = value.strip()

    if len(value) > max_length:
        raise ValueError(
            f"{field_name} must be at most {max_length} characters."
        )

    pattern = _SAFE_ID_PATTERN_DOTS if allow_dots else _SAFE_ID_PATTERN
    if not pattern.match(value):
        allowed = "alphanumeric characters, hyphens, underscores, and dots" if allow_dots else "alphanumeric characters, hyphens, and underscores"
        raise ValueError(
            f"{field_name} contains invalid characters. "
            f"Only {allowed} are allowed."
        )

    return value


def validate_expire_by(expire_by: str) -> None:
    """Validate an ISO 8601 expiry timestamp.

    Checks that the timestamp is parseable, in the future, and within
    the Pine Labs API maximum of 180 days.

    Args:
        expire_by: ISO 8601 timestamp string (e.g., '2025-03-21T08:29Z').

    Raises:
        ValueError: If the timestamp is invalid, in the past, or too far out.
    """
    try:
        # Python 3.11+ supports Z suffix natively, but be safe
        dt = datetime.fromisoformat(expire_by.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        raise ValueError(
            "expire_by must be a valid ISO 8601 timestamp "
            "(e.g., 2025-03-21T08:29Z or 2025-03-21T08:29:00+05:30)."
        )

    now = datetime.now(timezone.utc)

    # Ensure timezone-aware comparison
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    if dt <= now:
        raise ValueError("expire_by must be a future timestamp.")

    max_expiry = now + timedelta(days=180)
    if dt > max_expiry:
        raise ValueError("expire_by must be within 180 days from now.")
