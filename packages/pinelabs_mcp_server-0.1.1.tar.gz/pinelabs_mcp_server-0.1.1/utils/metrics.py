"""
Prometheus metrics definitions and metrics server for Pine Labs MCP Server.

Exposes metrics on a dedicated HTTP port (default 8889) at /metrics,
matching the Helm/Prometheus annotations in values.uat.yaml.

Metrics exported:
  - mcp_tool_requests_total       (Counter)   — tool invocations by tool/status
  - mcp_tool_request_duration_seconds (Histogram) — tool latency by tool
  - mcp_tool_active_requests      (Gauge)     — in-flight tool calls by tool
  - pinelabs_api_requests_total   (Counter)   — upstream API calls by method/path/status
  - pinelabs_api_request_duration_seconds (Histogram) — upstream API latency
  - pinelabs_api_errors_total     (Counter)   — upstream API errors by type
  - pinelabs_api_retries_total    (Counter)   — upstream API retries
  - pinelabs_token_cache_hits_total   (Counter)   — token cache hits
  - pinelabs_token_cache_misses_total (Counter)   — token cache misses
  - pinelabs_token_cache_errors_total (Counter)   — token cache errors by operation
  - pinelabs_token_cache_writes_total (Counter)   — token cache writes
  - pinelabs_token_cache_deletes_total (Counter)  — token cache deletes
  - pinelabs_auth_token_requests_total (Counter)  — OAuth2 token fetches by status
  - pinelabs_auth_token_duration_seconds (Histogram) — OAuth2 token fetch latency
  - pinelabs_circuit_breaker_state    (Gauge)     — circuit breaker state
  - pinelabs_circuit_breaker_transitions_total (Counter) — state transitions
  - pinelabs_circuit_breaker_rejections_total  (Counter) — rejected requests
  - pinelabs_redis_up             (Gauge)     — Redis reachability
  - pinelabs_business_outcomes_total (Counter) — business outcome counters
"""

from __future__ import annotations

import functools
import logging
import time
from contextlib import contextmanager
from typing import Any, Callable, Generator

from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    start_http_server,
)

logger = logging.getLogger("pinelabs-mcp-server.metrics")

# ---------------------------------------------------------------------------
# MCP Tool-level metrics
# ---------------------------------------------------------------------------

TOOL_REQUESTS = Counter(
    "mcp_tool_requests_total",
    "Total MCP tool invocations",
    ["tool", "status"],
)

TOOL_DURATION = Histogram(
    "mcp_tool_request_duration_seconds",
    "Duration of MCP tool invocations in seconds",
    ["tool"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
)

TOOL_ACTIVE = Gauge(
    "mcp_tool_active_requests",
    "Number of in-flight MCP tool calls",
    ["tool"],
)

# ---------------------------------------------------------------------------
# Pine Labs API-level metrics
# ---------------------------------------------------------------------------

API_REQUESTS = Counter(
    "pinelabs_api_requests_total",
    "Total upstream Pine Labs API calls",
    ["method", "path", "status_code"],
)

API_DURATION = Histogram(
    "pinelabs_api_request_duration_seconds",
    "Duration of upstream Pine Labs API calls in seconds",
    ["method", "path"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
)

API_ERRORS = Counter(
    "pinelabs_api_errors_total",
    "Total upstream Pine Labs API errors",
    ["method", "path", "error_type"],
)

API_RETRIES = Counter(
    "pinelabs_api_retries_total",
    "Total upstream Pine Labs API retry attempts",
    ["method", "path"],
)

# ---------------------------------------------------------------------------
# Token cache metrics
# ---------------------------------------------------------------------------

TOKEN_CACHE_HITS = Counter(
    "pinelabs_token_cache_hits_total",
    "Total token cache hits",
)

TOKEN_CACHE_MISSES = Counter(
    "pinelabs_token_cache_misses_total",
    "Total token cache misses",
)

TOKEN_CACHE_ERRORS = Counter(
    "pinelabs_token_cache_errors_total",
    "Total token cache errors",
    ["operation"],
)

TOKEN_CACHE_WRITES = Counter(
    "pinelabs_token_cache_writes_total",
    "Total token cache write operations",
)

TOKEN_CACHE_DELETES = Counter(
    "pinelabs_token_cache_deletes_total",
    "Total token cache delete operations",
)

# ---------------------------------------------------------------------------
# Auth token fetch metrics
# ---------------------------------------------------------------------------

AUTH_TOKEN_REQUESTS = Counter(
    "pinelabs_auth_token_requests_total",
    "Total OAuth2 token fetch requests to Pine Labs",
    ["status"],
)

AUTH_TOKEN_DURATION = Histogram(
    "pinelabs_auth_token_duration_seconds",
    "Duration of OAuth2 token fetch requests in seconds",
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
)

# ---------------------------------------------------------------------------
# Circuit breaker metrics
# ---------------------------------------------------------------------------

CIRCUIT_BREAKER_STATE = Gauge(
    "pinelabs_circuit_breaker_state",
    "Current circuit breaker state (0=closed, 1=open, 2=half_open)",
    ["name"],
)

CIRCUIT_BREAKER_TRANSITIONS = Counter(
    "pinelabs_circuit_breaker_transitions_total",
    "Total circuit breaker state transitions",
    ["name", "from_state", "to_state"],
)

CIRCUIT_BREAKER_REJECTIONS = Counter(
    "pinelabs_circuit_breaker_rejections_total",
    "Total requests rejected by circuit breaker",
    ["name"],
)

# ---------------------------------------------------------------------------
# Redis availability metric
# ---------------------------------------------------------------------------

REDIS_UP = Gauge(
    "pinelabs_redis_up",
    "Whether Redis is reachable (1=up, 0=down)",
)

# ---------------------------------------------------------------------------
# Business outcome metrics
# ---------------------------------------------------------------------------

BUSINESS_OUTCOMES = Counter(
    "pinelabs_business_outcomes_total",
    "Business outcome counters for payment operations",
    ["operation", "status"],
)


# ---------------------------------------------------------------------------
# Helper: context manager for tool instrumentation
# ---------------------------------------------------------------------------

@contextmanager
def track_tool_call(tool_name: str) -> Generator[None, None, None]:
    """Context manager that records metrics around a tool invocation.

    Usage::

        with track_tool_call("create_payment_link"):
            result = await do_work()

    On exit it increments the request counter (status="success" or "error")
    and records duration.  The caller should let exceptions propagate
    naturally — they will be caught here to record the error metric.
    """
    TOOL_ACTIVE.labels(tool=tool_name).inc()
    start = time.perf_counter()
    status = "success"
    try:
        yield
    except Exception:
        status = "error"
        raise
    finally:
        elapsed = time.perf_counter() - start
        TOOL_ACTIVE.labels(tool=tool_name).dec()
        TOOL_REQUESTS.labels(tool=tool_name, status=status).inc()
        TOOL_DURATION.labels(tool=tool_name).observe(elapsed)


def instrumented_tool(tool_name: str) -> Callable:
    """Decorator that adds Prometheus metrics and OpenTelemetry tracing to an async tool.

    Wraps an async tool function to automatically record:
    - Active request gauge (in-flight calls)
    - Request counter (by tool name and success/error status)
    - Duration histogram (latency)
    - OpenTelemetry span with tool name

    Error detection: if the return value is a string containing ``"error"``
    (matching the structured error responses from ``utils.errors``), the
    invocation is recorded as ``status="error"``.

    Usage::

        @mcp.tool(name="my_tool", description="...")
        @instrumented_tool("my_tool")
        async def my_tool(...) -> str:
            ...

    Note: Place ``@instrumented_tool`` **below** (so it is applied *before*)
    ``@mcp.tool``. Because decorators are applied from the bottom up in
    Python, this lets FastMCP (via ``@mcp.tool``) see the original signature
    through ``functools.wraps`` / ``__wrapped__``.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            from utils.tracing import get_tracer
            from opentelemetry.trace import StatusCode

            tracer = get_tracer()
            with tracer.start_as_current_span(f"tool.{tool_name}") as span:
                TOOL_ACTIVE.labels(tool=tool_name).inc()
                start = time.perf_counter()
                try:
                    result = await func(*args, **kwargs)
                    # Detect structured error responses returned as strings
                    status = (
                        "error"
                        if isinstance(result, str) and '"error"' in result
                        else "success"
                    )
                    TOOL_REQUESTS.labels(tool=tool_name, status=status).inc()
                    if status == "error":
                        span.set_status(StatusCode.ERROR)
                    return result
                except Exception as exc:
                    TOOL_REQUESTS.labels(tool=tool_name, status="error").inc()
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    raise
                finally:
                    elapsed = time.perf_counter() - start
                    TOOL_ACTIVE.labels(tool=tool_name).dec()
                    TOOL_DURATION.labels(tool=tool_name).observe(elapsed)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Helper: record API call metrics
# ---------------------------------------------------------------------------

def record_api_request(
    method: str,
    path: str,
    status_code: int,
    duration: float,
) -> None:
    """Record metrics for a completed Pine Labs API call."""
    API_REQUESTS.labels(method=method, path=path, status_code=str(status_code)).inc()
    API_DURATION.labels(method=method, path=path).observe(duration)


def record_api_error(method: str, path: str, error_type: str) -> None:
    """Record an API error metric."""
    API_ERRORS.labels(method=method, path=path, error_type=error_type).inc()


def record_api_retry(method: str, path: str) -> None:
    """Record an API retry attempt."""
    API_RETRIES.labels(method=method, path=path).inc()


# ---------------------------------------------------------------------------
# Helper: record token cache metrics
# ---------------------------------------------------------------------------

def record_cache_hit() -> None:
    """Record a token cache hit."""
    TOKEN_CACHE_HITS.inc()


def record_cache_miss() -> None:
    """Record a token cache miss."""
    TOKEN_CACHE_MISSES.inc()


def record_cache_error(operation: str) -> None:
    """Record a token cache error for the given operation (get/set/delete)."""
    TOKEN_CACHE_ERRORS.labels(operation=operation).inc()


def record_cache_write() -> None:
    """Record a successful token cache write."""
    TOKEN_CACHE_WRITES.inc()


def record_cache_delete() -> None:
    """Record a successful token cache delete."""
    TOKEN_CACHE_DELETES.inc()


# ---------------------------------------------------------------------------
# Helper: record auth token fetch metrics
# ---------------------------------------------------------------------------

def record_auth_token_fetch(status: str, duration: float) -> None:
    """Record an OAuth2 token fetch attempt."""
    AUTH_TOKEN_REQUESTS.labels(status=status).inc()
    AUTH_TOKEN_DURATION.observe(duration)


# ---------------------------------------------------------------------------
# Helper: record circuit breaker metrics
# ---------------------------------------------------------------------------

_STATE_VALUES = {"closed": 0, "open": 1, "half_open": 2}


def record_circuit_breaker_state(name: str, state: str) -> None:
    """Set the current circuit breaker state gauge."""
    CIRCUIT_BREAKER_STATE.labels(name=name).set(_STATE_VALUES.get(state, -1))


def record_circuit_breaker_transition(
    name: str, from_state: str, to_state: str
) -> None:
    """Record a circuit breaker state transition."""
    CIRCUIT_BREAKER_TRANSITIONS.labels(
        name=name, from_state=from_state, to_state=to_state
    ).inc()
    record_circuit_breaker_state(name, to_state)


def record_circuit_breaker_rejection(name: str) -> None:
    """Record a request rejected by the circuit breaker."""
    CIRCUIT_BREAKER_REJECTIONS.labels(name=name).inc()


# ---------------------------------------------------------------------------
# Helper: record Redis availability
# ---------------------------------------------------------------------------

def record_redis_up(is_up: bool) -> None:
    """Set the Redis availability gauge (1=up, 0=down)."""
    REDIS_UP.set(1 if is_up else 0)


# ---------------------------------------------------------------------------
# Helper: record business outcomes
# ---------------------------------------------------------------------------

_VALID_OUTCOME_STATUSES = frozenset({"success", "failed"})


def record_business_outcome(operation: str, status: str) -> None:
    """Record a business outcome for a payment operation.

    Args:
        operation: The operation type (e.g. ``payment_link``, ``checkout_order``,
            ``refund``, ``order_cancel``, ``settlement_release``,
            ``settlement_cancel``).
        status: Must be ``"success"`` or ``"failed"``.

    Raises:
        ValueError: If *status* is not one of the allowed values.
    """
    if status not in _VALID_OUTCOME_STATUSES:
        raise ValueError(
            f"Invalid business outcome status {status!r}; "
            f"allowed values: {sorted(_VALID_OUTCOME_STATUSES)}"
        )
    BUSINESS_OUTCOMES.labels(operation=operation, status=status).inc()


# ---------------------------------------------------------------------------
# Metrics server lifecycle
# ---------------------------------------------------------------------------

_metrics_server_started = False


def start_metrics_server(port: int = 8889) -> None:
    """Start the Prometheus metrics HTTP server on the given port.

    Safe to call multiple times — only starts once.
    """
    global _metrics_server_started
    if _metrics_server_started:
        return
    start_http_server(port)
    _metrics_server_started = True
    logger.info("Prometheus metrics server started on port %d", port)


def reset_metrics_server_state() -> None:
    """Reset the started flag (for testing only)."""
    global _metrics_server_started
    _metrics_server_started = False
