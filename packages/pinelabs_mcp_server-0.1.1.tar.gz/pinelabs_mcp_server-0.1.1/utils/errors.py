"""
Structured error response utilities for Pine Labs MCP Server.

Provides consistent, RFC 7807-inspired error JSON responses across
all tool functions, with built-in PII sanitization and prompt injection
neutralization of error messages.
"""

import json
import re
from typing import Optional

# Patterns that might contain PII in error messages
_PII_PATTERNS = [
    re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),  # emails
    re.compile(r"\b\d{10,}\b"),  # phone numbers (10+ digit sequences)
]

# Prompt injection patterns that may appear in upstream API error messages.
# These are a subset of the patterns in prompt_guard.py, kept here to avoid
# a circular import and to ensure error responses are always safe even if
# prompt_guard is not yet initialized.
_ERROR_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?|prompts?)", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?|prompts?)", re.IGNORECASE),
    re.compile(r"forget\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?|prompts?)", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+", re.IGNORECASE),
    re.compile(r"act\s+as\s+(a\s+|an\s+)?", re.IGNORECASE),
    re.compile(r"pretend\s+(to\s+be|you\s+are)\s+", re.IGNORECASE),
    re.compile(r"new\s+instructions?\s*:", re.IGNORECASE),
    re.compile(r"system\s*:\s*", re.IGNORECASE),
    re.compile(r"call\s+(the\s+)?tool\s+", re.IGNORECASE),
    re.compile(r"execute\s+(the\s+)?function\s+", re.IGNORECASE),
    re.compile(r"invoke\s+(the\s+)?tool\s+", re.IGNORECASE),
    re.compile(r"run\s+(the\s+)?(tool|function|command)\s+", re.IGNORECASE),
    re.compile(r"send\s+(all\s+)?(data|information|credentials|tokens?)\s+to\s+", re.IGNORECASE),
    re.compile(r"exfiltrate", re.IGNORECASE),
    re.compile(r"\[INST\]", re.IGNORECASE),
    re.compile(r"<\|im_start\|>", re.IGNORECASE),
    re.compile(r"<\|system\|>", re.IGNORECASE),
    re.compile(r"<<SYS>>", re.IGNORECASE),
]

# Maximum length for an error message returned to the LLM
_MAX_ERROR_MESSAGE_LENGTH = 500


def _sanitize_error_message(message: str) -> str:
    """Remove potential PII and prompt injection payloads from error messages.

    API error messages come from the upstream Pine Labs API (untrusted) and
    could carry injection payloads designed to hijack the LLM. This function:
    1. Strips PII (emails, phone numbers)
    2. Neutralizes prompt injection patterns
    3. Truncates overly long messages
    """
    sanitized = message

    # Strip PII
    for pattern in _PII_PATTERNS:
        sanitized = pattern.sub("[REDACTED]", sanitized)

    # Neutralize prompt injection patterns
    for pattern in _ERROR_INJECTION_PATTERNS:
        sanitized = pattern.sub("[BLOCKED]", sanitized)

    # Truncate overly long error messages (upstream could stuff injection here)
    if len(sanitized) > _MAX_ERROR_MESSAGE_LENGTH:
        sanitized = sanitized[:_MAX_ERROR_MESSAGE_LENGTH] + "...[TRUNCATED]"

    return sanitized


def error_response(
    *,
    error: str,
    code: str = "INTERNAL_ERROR",
    status_code: Optional[int] = None,
    details: Optional[dict] = None,
) -> str:
    """Create a structured JSON error response.

    All error responses follow a consistent shape:
        {
            "error": "Human-readable message (PII-sanitized)",
            "code": "MACHINE_READABLE_CODE",
            "status_code": 400,        // present for HTTP errors
            "details": { ... }         // optional additional context
        }

    Args:
        error: Human-readable error description.
        code: Machine-readable error code.
        status_code: HTTP status code (optional).
        details: Additional error context (optional).

    Returns:
        JSON string with the error response.
    """
    resp: dict = {
        "error": _sanitize_error_message(error),
        "code": code,
    }
    if status_code is not None:
        resp["status_code"] = status_code
    if details:
        resp["details"] = _sanitize_details(details)
    return json.dumps(resp)


def _sanitize_details(details: dict) -> dict:
    """Recursively sanitize PII from error details dict."""
    sanitized = {}
    for key, value in details.items():
        if isinstance(value, str):
            sanitized[key] = _sanitize_error_message(value)
        elif isinstance(value, dict):
            sanitized[key] = _sanitize_details(value)
        elif isinstance(value, list):
            sanitized[key] = [
                _sanitize_details(item) if isinstance(item, dict)
                else _sanitize_error_message(item) if isinstance(item, str)
                else _sanitize_error_message(str(item))
                for item in value
            ]
        elif isinstance(value, (int, float, bool, type(None))):
            sanitized[key] = value
        else:
            # Convert non-serializable objects (e.g., ValueError) to string
            sanitized[key] = _sanitize_error_message(str(value))
    return sanitized


def api_error_response(
    message: str,
    code: str,
    status_code: int,
    details: Optional[dict] = None,
) -> str:
    """Create a structured error response for Pine Labs API errors."""
    return error_response(
        error=message,
        code=code,
        status_code=status_code,
        details=details,
    )


def auth_error_response(message: str) -> str:
    """Create a structured error response for authentication failures."""
    return error_response(
        error=message,
        code="AUTH_ERROR",
        status_code=401,
    )


def validation_error_response(message: str) -> str:
    """Create a structured error response for validation failures."""
    return error_response(
        error=message,
        code="VALIDATION_ERROR",
        status_code=422,
    )


def unexpected_error_response(exc: Exception, context: str = "operation") -> str:
    """Create a structured error response for unexpected failures.

    Never exposes raw upstream error text to the caller.
    """
    return error_response(
        error=f"An internal error occurred during {context}",
        code="INTERNAL_ERROR",
        status_code=500,
    )
