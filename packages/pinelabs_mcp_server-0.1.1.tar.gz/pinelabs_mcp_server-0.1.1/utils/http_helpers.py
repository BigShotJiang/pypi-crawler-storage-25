"""Shared HTTP/tool helpers for auth extraction and JSON error responses."""

from __future__ import annotations

import json
from typing import Mapping, Any


def json_error(code: str, message: str, status_code: int | None = None) -> str:
    """Build a consistent sanitized JSON error response."""
    payload: dict[str, Any] = {"code": code, "message": message}
    if status_code is not None:
        payload["status_code"] = status_code
    return json.dumps(payload)


def extract_bearer_token(headers: Mapping[str, str]) -> str:
    """Extract a bearer token from incoming request headers."""
    auth = headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise ValueError(
            "Missing or invalid Authorization header. "
            "Expected 'Bearer <token>' in your MCP client configuration."
        )
    return auth[len("Bearer ") :]
