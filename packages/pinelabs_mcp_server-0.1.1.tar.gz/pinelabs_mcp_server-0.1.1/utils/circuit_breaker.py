"""
Lightweight async-compatible circuit breaker for Pine Labs MCP Server.

Implements the standard three-state circuit breaker pattern:
  - CLOSED: Requests flow normally. Failures are counted.
  - OPEN: Requests are immediately rejected. After ``reset_timeout`` seconds,
    transitions to HALF_OPEN.
  - HALF_OPEN: A single probe request is allowed. On success, resets to CLOSED;
    on failure, reopens to OPEN.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Awaitable, Callable

from utils.metrics import (
    record_circuit_breaker_state,
    record_circuit_breaker_transition,
    record_circuit_breaker_rejection,
)

logger = logging.getLogger("pinelabs-mcp-server.circuit_breaker")

# States
STATE_CLOSED = "closed"
STATE_OPEN = "open"
STATE_HALF_OPEN = "half_open"


class CircuitBreakerError(Exception):
    """Raised when the circuit breaker is open and rejects a request."""


class CircuitBreaker:
    """Async-compatible circuit breaker.

    Args:
        fail_max: Number of consecutive failures before opening the circuit.
        reset_timeout: Seconds to wait in OPEN state before transitioning to HALF_OPEN.
        name: Human-readable name for logging.
    """

    def __init__(
        self,
        fail_max: int = 5,
        reset_timeout: float = 60.0,
        name: str = "default",
    ) -> None:
        self.fail_max = fail_max
        self.reset_timeout = reset_timeout
        self.name = name
        self._state = STATE_CLOSED
        self._fail_count = 0
        self._last_failure_time: float = 0.0
        record_circuit_breaker_state(self.name, STATE_CLOSED)

    @property
    def current_state(self) -> str:
        """Return the current circuit breaker state, transitioning to
        HALF_OPEN if the reset timeout has elapsed while OPEN."""
        if self._state == STATE_OPEN:
            if time.monotonic() - self._last_failure_time >= self.reset_timeout:
                old_state = self._state
                self._state = STATE_HALF_OPEN
                record_circuit_breaker_transition(self.name, old_state, STATE_HALF_OPEN)
                logger.info(
                    "Circuit breaker '%s' transitioned to HALF_OPEN", self.name
                )
        return self._state

    def record_success(self) -> None:
        """Record a successful request, resetting the circuit to CLOSED."""
        self._fail_count = 0
        if self._state != STATE_CLOSED:
            old_state = self._state
            logger.info("Circuit breaker '%s' reset to CLOSED", self.name)
            self._state = STATE_CLOSED
            record_circuit_breaker_transition(self.name, old_state, STATE_CLOSED)

    def record_failure(self) -> None:
        """Record a failed request, potentially opening the circuit."""
        self._fail_count += 1
        self._last_failure_time = time.monotonic()
        if self._fail_count >= self.fail_max:
            old_state = self._state
            self._state = STATE_OPEN
            if old_state != STATE_OPEN:
                record_circuit_breaker_transition(self.name, old_state, STATE_OPEN)
            logger.warning(
                "Circuit breaker '%s' OPENED after %d failures",
                self.name,
                self._fail_count,
            )

    async def call_async(
        self,
        func: Callable[..., Awaitable[Any]],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Execute ``func`` through the circuit breaker.

        Args:
            func: An async callable to execute.
            *args: Positional arguments for ``func``.
            **kwargs: Keyword arguments for ``func``.

        Returns:
            The return value of ``func``.

        Raises:
            CircuitBreakerError: If the circuit is OPEN and the reset timeout
                has not yet elapsed.
        """
        state = self.current_state

        if state == STATE_OPEN:
            record_circuit_breaker_rejection(self.name)
            raise CircuitBreakerError(
                f"Circuit breaker '{self.name}' is OPEN — request rejected"
            )

        try:
            result = await func(*args, **kwargs)
            self.record_success()
            return result
        except Exception:
            self.record_failure()
            raise
