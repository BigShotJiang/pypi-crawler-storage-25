"""Shared input-validation helpers for MCP tool modules."""

import re

# Alphanumeric + hyphens — covers Pine Labs order IDs, settlement IDs, UTRs
_SAFE_PATH_PARAM_RE = re.compile(r"^[a-zA-Z0-9\-]{1,128}$")


def validate_path_param(value: str, name: str) -> str | None:
    """Validate a value that will be interpolated into a URL path segment.

    Returns:
        None if valid; an error message string if invalid.
    """
    if not value or not value.strip():
        return f"{name} must not be empty."
    if not _SAFE_PATH_PARAM_RE.match(value):
        return f"{name} contains invalid characters. Only alphanumeric and hyphens are allowed."
    return None
