"""Shared authentication utilities for MCP tools."""


def extract_bearer_token(headers: dict) -> str:
    """Extract Bearer token from Authorization header.

    Raises:
        ValueError: If the Authorization header is missing, empty,
                    or doesn't start with 'Bearer '.
    """
    auth = headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise ValueError(
            "Missing or invalid Authorization header. "
            "Expected 'Bearer <token>' in your MCP client configuration."
        )
    token = auth[len("Bearer "):]
    if not token.strip():
        raise ValueError(
            "Missing or invalid Authorization header. "
            "Expected 'Bearer <token>' in your MCP client configuration."
        )
    return token
