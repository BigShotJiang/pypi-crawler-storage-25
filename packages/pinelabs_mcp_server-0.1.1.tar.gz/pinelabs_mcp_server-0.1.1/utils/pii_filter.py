"""
PII (Personally Identifiable Information) filter for API responses.

Provides configurable field-name-based PII masking that recursively walks
API response dicts/lists and masks values for known PII fields.

Configuration is loaded from a YAML file (default: pii_config.yaml).
"""

import logging
import os
import re
from typing import Any

import yaml

logger = logging.getLogger("pinelabs-mcp-server.pii_filter")

# Module-level state: compiled PII field patterns + strategy mapping
_pii_rules: list[tuple[re.Pattern, str]] = []
_initialized: bool = False

# Default PII rules used as fallback when the YAML config file is missing.
_DEFAULT_PII_FIELDS: list[dict[str, str]] = [
    {"pattern": "email_id|email|customer_email", "strategy": "email"},
    {"pattern": "first_name|last_name|full_name|customer_name|customer_first_name|customer_last_name|billing_full_name|shipping_full_name|payeeName", "strategy": "name"},
    {"pattern": "mobile_number|phone|customer_mobile", "strategy": "phone"},
    {"pattern": "customer_id", "strategy": "id"},
    {"pattern": "address1|address2|address3|billing_address1|billing_address2|billing_address3|shipping_address1|shipping_address2|shipping_address3", "strategy": "address"},
    {"pattern": "pincode|zip|billing_pincode|shipping_pincode", "strategy": "redact"},
    {"pattern": "country_code", "strategy": "redact"},
    {"pattern": "last4_digit", "strategy": "redact"},
    {"pattern": "bank_acc_number|bank_account_number|account_number", "strategy": "redact"},
    {"pattern": "bank_ifsc_code|ifsc_code", "strategy": "redact"},
    {"pattern": "product_imei", "strategy": "redact"},
    {"pattern": "utr_number", "strategy": "redact"},
]


# ---------------------------------------------------------------------------
# Masking strategies
# ---------------------------------------------------------------------------

def _mask_email(value: str) -> str:
    """Mask email: 'john@example.com' → 'j***@e***.com'"""
    if not isinstance(value, str) or "@" not in value:
        return "[REDACTED]"
    local, domain = value.rsplit("@", 1)
    domain_parts = domain.rsplit(".", 1)
    masked_local = f"{local[0]}***" if local else "***"
    if len(domain_parts) == 2:
        masked_domain = (
            f"{domain_parts[0][0]}***.{domain_parts[1]}"
            if domain_parts[0]
            else f"***.{domain_parts[1]}"
        )
    else:
        masked_domain = f"{domain[0]}***" if domain else "***"
    return f"{masked_local}@{masked_domain}"


def _mask_name(value: Any) -> str:
    """Mask name: 'Kevin' → 'K***'"""
    if value is None or value == "":
        return "[REDACTED]"
    value = str(value)
    return f"{value[0]}***"


def _mask_phone(value: Any) -> str:
    """Mask phone: '9876543210' → '******3210'"""
    if value is None or value == "":
        return "[REDACTED]"
    s = str(value).strip()
    if len(s) <= 4:
        return "****"
    return "*" * (len(s) - 4) + s[-4:]


def _mask_id(value: Any) -> str:
    """Mask ID: '123456' → '****56'"""
    if value is None or value == "":
        return "[REDACTED]"
    s = str(value).strip()
    if len(s) <= 2:
        return "****"
    return "*" * (len(s) - 2) + s[-2:]


def _mask_address(value: str) -> str:
    """Mask address: '10 Downing Street' → '10 ***'"""
    if not isinstance(value, str) or not value:
        return "[REDACTED]"
    parts = value.split(" ", 1)
    if len(parts) == 1:
        return "***"
    return f"{parts[0]} ***"


def _mask_redact(_value: Any) -> str:
    """Full redaction: any value → '[REDACTED]'"""
    return "[REDACTED]"


# Strategy name → masking function
_STRATEGY_MAP: dict[str, Any] = {
    "email": _mask_email,
    "name": _mask_name,
    "phone": _mask_phone,
    "id": _mask_id,
    "address": _mask_address,
    "redact": _mask_redact,
}


# ---------------------------------------------------------------------------
# Configuration loading
# ---------------------------------------------------------------------------

def load_pii_config(config_path: str) -> None:
    """
    Load PII field configuration from a YAML file.

    Compiles field-name patterns into regex objects for fast matching.
    Must be called once at startup before filter_pii() is used.

    If the config file is not found, built-in default PII rules are used
    as a fallback so that filtering is never silently disabled.

    Args:
        config_path: Path to the YAML configuration file.
    """
    global _pii_rules, _initialized

    if not os.path.exists(config_path):
        logger.warning(
            "PII config file not found at '%s'. Using built-in default PII rules.",
            config_path,
        )
        pii_fields = _DEFAULT_PII_FIELDS
    else:
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        pii_fields = config.get("pii_fields", [])

    _pii_rules = []

    for entry in pii_fields:
        pattern_str = entry.get("pattern", "")
        strategy = entry.get("strategy", "redact")

        if strategy not in _STRATEGY_MAP:
            logger.warning(
                "Unknown masking strategy '%s' for pattern '%s'. "
                "Defaulting to 'redact'.",
                strategy,
                pattern_str,
            )
            strategy = "redact"

        try:
            compiled = re.compile(f"^({pattern_str})$", re.IGNORECASE)
        except re.error as exc:
            logger.warning(
                "Invalid regex pattern '%s' in PII config: %s. Skipping entry.",
                pattern_str,
                exc,
            )
            continue
        _pii_rules.append((compiled, strategy))

    _initialized = True
    logger.info(
        "PII filter loaded %d field pattern(s) from '%s'",
        len(_pii_rules),
        config_path,
    )


# ---------------------------------------------------------------------------
# PII filtering
# ---------------------------------------------------------------------------

def _get_mask_strategy(field_name: str) -> str | None:
    """Return the masking strategy for a field name, or None if not PII."""
    for pattern, strategy in _pii_rules:
        if pattern.match(field_name):
            return strategy
    return None


def filter_pii(data: Any) -> Any:
    """
    Recursively walk a dict/list and mask PII field values.

    - Dict keys are matched against configured PII field patterns.
    - If a key matches, its value is masked using the configured strategy.
    - Nested dicts and lists are traversed recursively.
    - Non-dict/list values are returned as-is.

    This function is idempotent: applying it twice yields the same result.

    Args:
        data: API response data (dict, list, or primitive).

    Returns:
        A new data structure with PII fields masked.
    """
    if not _initialized:
        logger.warning(
            "PII filter not initialized. Call load_pii_config() first. "
            "Returning data unfiltered.",
        )
        return data

    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            strategy = _get_mask_strategy(key)
            if strategy and not isinstance(value, (dict, list)):
                # Mask the primitive value
                mask_fn = _STRATEGY_MAP[strategy]
                result[key] = mask_fn(value)
            else:
                # Recurse into nested structures or pass through non-PII keys
                result[key] = filter_pii(value)
        return result

    elif isinstance(data, list):
        return [filter_pii(item) for item in data]

    else:
        return data


# ---------------------------------------------------------------------------
# Sensitive key stripping
# ---------------------------------------------------------------------------

# Centralized strip-key sets — one per tool / use-case.
# Any tool can import the set it needs.  To add or remove a field, edit here.
PII_STRIP_KEYS: frozenset[str] = frozenset({
    # Bank / financial
    "bank_acc_number",
    "bank_account_number",
    "bank_ifsc_code",
    "bank_name",
    "account_number",
    "ifsc_code",
    "release_amount",
    # Customer identifiers
    "customer_email",
    "customer_mobile",
    "customer_name",
    "customer_first_name",
    "customer_last_name",
    # Address fields
    "billing_address1",
    "billing_address2",
    "billing_address3",
    "billing_city",
    "billing_state",
    "billing_country",
    "billing_pincode",
    "billing_full_name",
    "shipping_address1",
    "shipping_address2",
    "shipping_address3",
    "shipping_city",
    "shipping_state",
    "shipping_country",
    "shipping_pincode",
    "shipping_full_name",
    # Location fields (generic keys returned by Pine Labs)
    "city",
    "state",
    "country",
    "pincode",
    # Device identifiers
    "product_imei",
    # Callback URLs (internal endpoints, not needed by LLM)
    "callback_url",
    "failure_callback_url",
    "utr_number"
})


def strip_sensitive_keys(
    data: Any,
    keys_to_strip: frozenset[str],
    _depth: int = 0,
) -> Any:
    """Recursively remove sensitive keys from an API response.

    Walks the data structure and **drops** any dict key whose name appears
    in ``keys_to_strip``.  The key and its entire value are removed so they
    never reach the LLM context.  All other keys are preserved unchanged.

    This is intentionally generic: each tool defines its own ``frozenset``
    of keys to strip.  Adding or removing a field is a one-line edit.

    Usage::

        _MY_TOOL_STRIP_KEYS = frozenset({"order_id", "settlement_id"})
        cleaned = strip_sensitive_keys(api_response, _MY_TOOL_STRIP_KEYS)

    Args:
        data: API response data (dict, list, or primitive).
        keys_to_strip: Set of key names whose entries must be removed.
        _depth: Internal recursion depth counter (prevents stack overflow).

    Returns:
        A new data structure with the specified keys removed at every
        nesting level.
    """
    if _depth > 50:
        return data

    if isinstance(data, dict):
        return {
            key: strip_sensitive_keys(value, keys_to_strip, _depth + 1)
            for key, value in data.items()
            if key not in keys_to_strip
        }
    elif isinstance(data, list):
        return [strip_sensitive_keys(item, keys_to_strip, _depth + 1) for item in data]
    return data
