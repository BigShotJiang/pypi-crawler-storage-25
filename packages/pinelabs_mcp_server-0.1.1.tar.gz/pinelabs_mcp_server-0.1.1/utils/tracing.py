"""
OpenTelemetry tracing setup for Pine Labs MCP Server.

Configures a tracer provider with OTLP exporter (when endpoint is set)
or a no-op provider (when tracing is disabled / no endpoint configured).

Usage::

    from utils.tracing import init_tracing, get_tracer

    init_tracing(service_name="pinelabs-mcp-server", otlp_endpoint="http://otel:4317")
    tracer = get_tracer()

    with tracer.start_as_current_span("my_operation") as span:
        span.set_attribute("key", "value")
        ...
"""

from __future__ import annotations

import logging
from typing import Optional

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SimpleSpanProcessor,
    ConsoleSpanExporter,
)
from opentelemetry.sdk.resources import Resource, SERVICE_NAME
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.trace import Tracer

logger = logging.getLogger("pinelabs-mcp-server.tracing")

_SERVICE_NAME_DEFAULT = "pinelabs-mcp-server"
_initialized = False


def init_tracing(
    service_name: str = _SERVICE_NAME_DEFAULT,
    otlp_endpoint: Optional[str] = None,
    sample_rate: float = 1.0,
    console_export: bool = False,
) -> None:
    """Initialize the OpenTelemetry tracer provider.

    Args:
        service_name: Service name used in trace resource attributes.
        otlp_endpoint: gRPC endpoint for the OTLP collector (e.g. ``http://otel-collector:4317``).
                       If ``None`` or empty, tracing is effectively a no-op
                       (unless ``console_export`` is True).
        sample_rate: Fraction of traces to sample (0.0–1.0). Default 1.0 = all.
        console_export: If True, also export spans to stderr (useful for debugging).
    """
    global _initialized
    if _initialized:
        return

    resource = Resource.create({SERVICE_NAME: service_name})

    # Choose sampler based on rate
    from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
    sampler = TraceIdRatioBased(sample_rate)

    provider = TracerProvider(resource=resource, sampler=sampler)

    if otlp_endpoint:
        otlp_exporter = OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
        logger.info(
            "OTLP trace exporter configured: endpoint=%s, sample_rate=%.2f",
            otlp_endpoint,
            sample_rate,
        )

    if console_export:
        provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
        logger.info("Console trace exporter enabled")

    if not otlp_endpoint and not console_export:
        logger.info("No trace exporter configured — tracing spans will be discarded")

    trace.set_tracer_provider(provider)
    _initialized = True
    logger.info("OpenTelemetry tracing initialized: service=%s", service_name)


def get_tracer(name: str = _SERVICE_NAME_DEFAULT) -> Tracer:
    """Return a tracer instance bound to the current provider."""
    return trace.get_tracer(name)


def reset_tracing_state() -> None:
    """Reset the initialization flag (for testing only)."""
    global _initialized
    _initialized = False
