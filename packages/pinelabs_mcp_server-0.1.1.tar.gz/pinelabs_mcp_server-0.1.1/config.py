"""
Configuration for Pine Labs MCP Server.

Reads non-secret config from environment variables.
Client credentials (client_id, client_secret) are used to auto-generate
access tokens via the Pine Labs OAuth2 token endpoint.
"""

import os
from enum import Enum

from dotenv import load_dotenv

# Only load .env in local development; in Docker/K8s env vars come from the orchestrator
if os.path.exists(".env"):
    load_dotenv()


class Environment(str, Enum):
    UAT = "uat"
    PROD = "prod"


# Base URL mapping per environment
BASE_URLS = {
    Environment.UAT: "https://pluraluat.v2.pinepg.in/api",
    Environment.PROD: "https://api.pluralpay.in/api",
}


# Token endpoint mapping per environment
TOKEN_URLS = {
    Environment.UAT: "https://pluraluat.v2.pinepg.in/api/auth/v1/token",
    Environment.PROD: "https://api.pluralpay.in/api/auth/v1/token",
}


class Settings:
    """Server settings loaded from environment variables."""

    def __init__(self) -> None:
        env_str = os.getenv("PINELABS_ENV", "uat").lower()
        try:
            self.environment = Environment(env_str)
        except ValueError:
            self.environment = Environment.UAT

        # Allow explicit base URL override
        self.base_url: str = os.getenv(
            "PINELABS_BASE_URL",
            BASE_URLS[self.environment],
        )

        self.port: int = int(os.getenv("PORT", "8000"))
        self.host: str = os.getenv("HOST", "0.0.0.0")
        self.log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()
        self.log_format: str = os.getenv("LOG_FORMAT", "text")  # "text" or "json"
        self.pii_config_path: str = os.getenv("PII_CONFIG_PATH", "pii_config.yaml")
        self.timeout_seconds: float = float(os.getenv("PINELABS_TIMEOUT_SECONDS", "15"))

        # CORS: comma-separated allowed origins (empty = no CORS)
        cors_raw = os.getenv("CORS_ORIGINS", "")
        self.cors_origins: list[str] = [
            o.strip() for o in cors_raw.split(",") if o.strip()
        ]

        # --- Observability ---
        self.metrics_port: int = int(os.getenv("METRICS_PORT", "8889"))
        self.metrics_enabled: bool = os.getenv("METRICS_ENABLED", "true").lower() == "true"

        # OpenTelemetry tracing (empty = tracing disabled)
        self.otlp_endpoint: str = os.getenv("OTLP_ENDPOINT", "")
        self.trace_sample_rate: float = float(os.getenv("TRACE_SAMPLE_RATE", "1.0"))
        self.trace_console_export: bool = os.getenv("TRACE_CONSOLE_EXPORT", "false").lower() == "true"
        self.service_name: str = os.getenv("SERVICE_NAME", "pinelabs-mcp-server")

        # HTTP client settings
        self.http_timeout: float = float(os.getenv("HTTP_TIMEOUT", "30.0"))

        # Token endpoint URL (client_id and client_secret come from request headers)
        self.token_url: str = os.getenv(
            "PINELABS_TOKEN_URL",
            TOKEN_URLS[self.environment],
        )

        # --- Redis (authorization token cache) ---
        self.redis_host: str = os.getenv("REDIS_HOST", "localhost")
        self.redis_port: int = int(os.getenv("REDIS_PORT", "6379"))
        self.redis_db: int = int(os.getenv("REDIS_DB", "0"))
        self.redis_max_connections: int = int(os.getenv("REDIS_MAX_CONNECTIONS", "50"))
        self.redis_token_ttl_seconds: int = int(os.getenv("REDIS_TOKEN_TTL_SECONDS", "3000"))


# Singleton instance
settings = Settings()
