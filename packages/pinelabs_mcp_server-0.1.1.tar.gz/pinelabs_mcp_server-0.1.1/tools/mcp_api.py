"""
Pine Labs MCP API tools.

Defines tools that proxy to the settlement-api MCP endpoints (/mcp/v1):
1. get_payment_link_details — Fetch payment link details within a date range
2. get_order_details — Fetch order details within a date range
3. get_refund_order_details — Fetch refund order details within a date range
4. get_refund_order_by_id — Fetch refund order details by order ID
5. search_transaction — Search for a transaction by transaction ID

All endpoints require a merchant_id header.
"""

import json
import logging
import re
from datetime import datetime
from typing import Optional

from fastmcp import FastMCP

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError
from utils.errors import (
    api_error_response,
    validation_error_response,
    unexpected_error_response,
)
from utils.prompt_guard import (
    TOOL_TRUST_PREFIX,
    TOOL_TRUST_SUFFIX,
    sanitize_output,
    sanitize_tool_inputs,
    wrap_tool_response,
    secure_tool,
)
from utils.pii_filter import strip_sensitive_keys, filter_pii, PII_STRIP_KEYS
from utils.validation import validate_path_param

_SAFE_MERCHANT_ID_RE = re.compile(r"^[a-zA-Z0-9\-_]{1,128}$")

logger = logging.getLogger("pinelabs-mcp-server.tools.mcp_api")


def _validate_date_range(start_date: str, end_date: str) -> str | None:
    """Validate start_date and end_date as ISO 8601, logical order, and max 60-day range.

    Returns None on success, or an error message string on failure.
    """
    try:
        dt_start = datetime.fromisoformat(start_date)
        dt_end = datetime.fromisoformat(end_date)
    except (ValueError, TypeError):
        return "start_date and end_date must be valid ISO 8601 timestamps."

    if dt_end < dt_start:
        return "end_date must not be before start_date."
    if (dt_end - dt_start).total_seconds() > 60 * 86400:
        return "Date range must not exceed 60 days."

    return None


def _validate_pagination(
    page: Optional[int], per_page: Optional[int]
) -> str | None:
    """Validate pagination parameters. Returns None on success or error message."""
    if page is not None and page < 1:
        return "page must be >= 1."
    if per_page is not None:
        if per_page < 1 or per_page > 100:
            return "per_page must be between 1 and 100."
    return None


def _validate_merchant_id(merchant_id: str) -> str | None:
    """Validate merchant_id format. Returns None on success or error message."""
    if not merchant_id or not merchant_id.strip():
        return "merchant_id is required and must not be empty."
    if not _SAFE_MERCHANT_ID_RE.match(merchant_id):
        return "merchant_id contains invalid characters. Only alphanumeric, hyphens, and underscores are allowed (max 128 chars)."
    return None


def register_mcp_api_tools(mcp: FastMCP, client: PineLabsClient) -> None:
    """Register all MCP API tools on the FastMCP server."""

    @secure_tool(mcp, name="get_payment_link_details", description=(
            TOOL_TRUST_PREFIX
            + "Fetch payment link details within a date range from Pine Labs. "
            "Returns payment link information including status, amounts, and metadata. "
            "Maximum date range is 60 days. Requires merchant_id."
            + TOOL_TRUST_SUFFIX
        ),
    )
    async def get_payment_link_details(
        merchant_id: str,
        start_date: str,
        end_date: str,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
    ) -> str:
        """
        Fetch payment link details within a date range.

        Args:
            merchant_id: Merchant identifier for the request.
            start_date: Start date in ISO 8601 format (e.g., 2024-10-01T00:00:00).
                         Maximum date range is 60 days.
            end_date: End date in ISO 8601 format (e.g., 2024-10-09T23:59:59).
                       Maximum date range is 60 days.
            page: Page number to retrieve.
            per_page: Number of records per page.

        Returns:
            JSON string with payment link details.
        """
        mid_err = _validate_merchant_id(merchant_id)
        if mid_err:
            return validation_error_response(mid_err)

        date_err = _validate_date_range(start_date, end_date)
        if date_err:
            return validation_error_response(date_err)

        pag_err = _validate_pagination(page, per_page)
        if pag_err:
            return validation_error_response(pag_err)

        params: dict[str, str] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if page is not None:
            params["page"] = str(page)
        if per_page is not None:
            params["per_page"] = str(per_page)

        try:
            logger.info(
                "Fetching payment link details: merchant_id=%s start_date=%s end_date=%s",
                merchant_id, start_date, end_date,
            )
            response = await client.get(
                "/mcp/v1/payment-link/details",
                params=params,
                extra_headers={"merchant-id": merchant_id},
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(e.message, e.code, e.status_code)
        except Exception as e:
            logger.error("Unexpected error fetching payment link details: %s", e)
            return unexpected_error_response(e, "fetching payment link details")

    @secure_tool(mcp, name="get_order_details", description=(
            TOOL_TRUST_PREFIX
            + "Fetch order details within a date range from Pine Labs. "
            "Returns order information including status, amounts, and metadata. "
            "Maximum date range is 60 days. Requires merchant_id."
            + TOOL_TRUST_SUFFIX
        ),
    )
    async def get_order_details(
        merchant_id: str,
        start_date: str,
        end_date: str,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
    ) -> str:
        """
        Fetch order details within a date range.

        Args:
            merchant_id: Merchant identifier for the request.
            start_date: Start date in ISO 8601 format (e.g., 2024-10-01T00:00:00).
                         Maximum date range is 60 days.
            end_date: End date in ISO 8601 format (e.g., 2024-10-09T23:59:59).
                       Maximum date range is 60 days.
            page: Page number to retrieve.
            per_page: Number of records per page.

        Returns:
            JSON string with order details.
        """
        mid_err = _validate_merchant_id(merchant_id)
        if mid_err:
            return validation_error_response(mid_err)

        date_err = _validate_date_range(start_date, end_date)
        if date_err:
            return validation_error_response(date_err)

        pag_err = _validate_pagination(page, per_page)
        if pag_err:
            return validation_error_response(pag_err)

        params: dict[str, str] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if page is not None:
            params["page"] = str(page)
        if per_page is not None:
            params["per_page"] = str(per_page)

        try:
            logger.info(
                "Fetching order details: merchant_id=%s start_date=%s end_date=%s",
                merchant_id, start_date, end_date,
            )
            response = await client.get(
                "/mcp/v1/order/details",
                params=params,
                extra_headers={"merchant-id": merchant_id},
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(e.message, e.code, e.status_code)
        except Exception as e:
            logger.error("Unexpected error fetching order details: %s", e)
            return unexpected_error_response(e, "fetching order details")

    @secure_tool(mcp, name="get_refund_order_details", description=(
            TOOL_TRUST_PREFIX
            + "Fetch refund order details within a date range from Pine Labs. "
            "Returns refund information including status, amounts, and metadata. "
            "Maximum date range is 60 days. Requires merchant_id."
            + TOOL_TRUST_SUFFIX
        ),
    )
    async def get_refund_order_details(
        merchant_id: str,
        start_date: str,
        end_date: str,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
    ) -> str:
        """
        Fetch refund order details within a date range.

        Args:
            merchant_id: Merchant identifier for the request.
            start_date: Start date in ISO 8601 format (e.g., 2024-10-01T00:00:00).
                         Maximum date range is 60 days.
            end_date: End date in ISO 8601 format (e.g., 2024-10-09T23:59:59).
                       Maximum date range is 60 days.
            page: Page number to retrieve.
            per_page: Number of records per page.

        Returns:
            JSON string with refund order details.
        """
        mid_err = _validate_merchant_id(merchant_id)
        if mid_err:
            return validation_error_response(mid_err)

        date_err = _validate_date_range(start_date, end_date)
        if date_err:
            return validation_error_response(date_err)

        pag_err = _validate_pagination(page, per_page)
        if pag_err:
            return validation_error_response(pag_err)

        params: dict[str, str] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if page is not None:
            params["page"] = str(page)
        if per_page is not None:
            params["per_page"] = str(per_page)

        try:
            logger.info(
                "Fetching refund order details: merchant_id=%s start_date=%s end_date=%s",
                merchant_id, start_date, end_date,
            )
            response = await client.get(
                "/mcp/v1/refund/order/details",
                params=params,
                extra_headers={"merchant-id": merchant_id},
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(e.message, e.code, e.status_code)
        except Exception as e:
            logger.error("Unexpected error fetching refund order details: %s", e)
            return unexpected_error_response(e, "fetching refund order details")

    # @secure_tool(mcp, name="get_refund_order_by_id", description=(
    #         TOOL_TRUST_PREFIX
    #         + "Fetch refund order details by order ID from Pine Labs. "
    #         "Returns detailed refund information for a specific order. "
    #         "Requires merchant_id."
    #         + TOOL_TRUST_SUFFIX
    #     ),
    # )
    # async def get_refund_order_by_id(
    #     merchant_id: str,
    #     order_id: str,
    # ) -> str:
    #     """
    #     Fetch refund order details by order ID.
    #
    #     Args:
    #         merchant_id: Merchant identifier for the request.
    #         order_id: Unique identifier of the order.
    #
    #     Returns:
    #         JSON string with refund order details for the specified order.
    #     """
    #     mid_err = _validate_merchant_id(merchant_id)
    #     if mid_err:
    #         return validation_error_response(mid_err)
    #
    #     oid_err = validate_path_param(order_id, "order_id")
    #     if oid_err:
    #         return validation_error_response(oid_err)
    #
    #     try:
    #         path = f"/mcp/v1/refund/order/{order_id}"
    #         logger.info(
    #             "Fetching refund order by ID: merchant_id=%s order_id=%s",
    #             merchant_id, order_id,
    #         )
    #         response = await client.get(
    #             path,
    #             extra_headers={"merchant-id": merchant_id},
    #         )
    #         response = strip_sensitive_keys(response, PII_STRIP_KEYS)
    #         response = filter_pii(response)
    #         return json.dumps(sanitize_output(response), indent=2)
    #
    #     except PineLabsAPIError as e:
    #         logger.error("Pine Labs API error: %s", e)
    #         return api_error_response(e.message, e.code, e.status_code)
    #     except Exception as e:
    #         logger.error("Unexpected error fetching refund order by ID: %s", e)
    #         return unexpected_error_response(e, "fetching refund order by ID")

    @secure_tool(mcp, name="search_transaction", description=(
            TOOL_TRUST_PREFIX
            + "Search for a transaction by transaction ID in Pine Labs. "
            "Returns transaction details including status, amounts, and metadata. "
            "Requires merchant_id."
            + TOOL_TRUST_SUFFIX
        ),
    )
    async def search_transaction(
        merchant_id: str,
        transaction_id: str,
    ) -> str:
        """
        Search for a transaction by transaction ID.

        Args:
            merchant_id: Merchant identifier for the request.
            transaction_id: Unique identifier of the transaction.

        Returns:
            JSON string with transaction details.
        """
        mid_err = _validate_merchant_id(merchant_id)
        if mid_err:
            return validation_error_response(mid_err)

        tid_err = validate_path_param(transaction_id, "transaction_id")
        if tid_err:
            return validation_error_response(tid_err)

        try:
            path = f"/mcp/v1/search/transaction/{transaction_id}"
            logger.info(
                "Searching transaction: merchant_id=%s transaction_id=%s",
                merchant_id, transaction_id,
            )
            response = await client.get(
                path,
                extra_headers={"merchant-id": merchant_id},
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(e.message, e.code, e.status_code)
        except Exception as e:
            logger.error("Unexpected error searching transaction: %s", e)
            return unexpected_error_response(e, "searching transaction")
