"""
Pine Labs Get Order MCP tool.

Defines the get_order_by_order_id tool that:
1. Validates and sanitizes order_id
2. Calls Pine Labs API to retrieve order details (token auto-managed by client)
3. Returns the result
"""

import json
import logging

from opentelemetry import trace
from fastmcp import FastMCP

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError
from utils.validators import validate_resource_id
from utils.errors import (
    api_error_response,
    validation_error_response,
    unexpected_error_response,
)
from utils.metrics import instrumented_tool
from utils.http_helpers import extract_bearer_token, json_error
from utils.prompt_guard import (
    TOOL_TRUST_PREFIX,
    TOOL_TRUST_SUFFIX,
    DESTRUCTIVE_TOOL_SUFFIX,
    sanitize_output,
    sanitize_tool_inputs,
    wrap_tool_response,
    secure_tool,
)
from utils.metrics import instrumented_tool, record_business_outcome
from utils.pii_filter import strip_sensitive_keys, filter_pii, PII_STRIP_KEYS

logger = logging.getLogger("pinelabs-mcp-server.tools.orders")


def _get_correlation_id() -> str:
    """Get the current correlation ID (trace ID) for log correlation."""
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if ctx and ctx.trace_id:
        return format(ctx.trace_id, "032x")
    return "no-trace"

def register_order_tools(mcp: FastMCP, client: PineLabsClient) -> None:
    """Register all order tools on the FastMCP server."""

    @secure_tool(mcp, name="cancel_order", description=(
            TOOL_TRUST_PREFIX
            + "Cancel a pre-authorized payment against a Pine Labs order. "
            "Can only be used when the order was created with pre_auth=true. "
            "Returns the cancelled order details including status and payment info."
            + TOOL_TRUST_SUFFIX
            + DESTRUCTIVE_TOOL_SUFFIX
        ),
    )
    @instrumented_tool("cancel_order")
    async def cancel_order(
        order_id: str,
    ) -> str:
        """
        Cancel a pre-authorized order by order ID.

        This cancels the payment against an order that was created with
        pre_auth set to true.

        Args:
            order_id: Unique identifier of the order in the Pine Labs database.
                      Example: v1-5757575757-aa-hU1rUd

        Returns:
            JSON string with cancelled order details including:
            - order_id: Order identifier
            - status: CANCELLED
            - type: Order type (CHARGE)
            - order_amount: Amount and currency
            - pre_auth: Whether pre-authorization was enabled
            - payments: List of payment attempts with CANCELLED status
            - purchase_details: Customer and merchant metadata
            - created_at / updated_at: Timestamps
        """
        # Step 1: Validate and sanitize order_id
        try:
            order_id = validate_resource_id(order_id, "order_id", allow_dots=True)
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs Cancel Order API
        try:
            path = f"/pay/v1/orders/{order_id}/cancel"
            logger.info(
                "Cancelling order: order_id=%s, correlation_id=%s",
                order_id,
                _get_correlation_id(),
            )

            response = await client.put(path)
            record_business_outcome("order_cancel", "success")
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)
        except PineLabsAPIError as e:
            record_business_outcome("order_cancel", "failed")
            logger.error(
                "Pine Labs API error: code=%s status=%d, correlation_id=%s",
                e.code,
                e.status_code,
                _get_correlation_id(),
            )
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            record_business_outcome("order_cancel", "failed")
            logger.error(
                "Unexpected error cancelling order: %s, correlation_id=%s",
                type(e).__name__,
                _get_correlation_id(),
            )
            return unexpected_error_response(e, "cancel order")

    @secure_tool(mcp, name="get_order_by_order_id", description=(
            TOOL_TRUST_PREFIX
            + "Retrieve order details from Pine Labs by order ID. "
            "Returns comprehensive order information including status, "
            "payment details, refunds, customer info, and more."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("get_order_by_order_id")
    async def get_order_by_order_id(
        order_id: str,
    ) -> str:
        """
        Get order details by order ID from Pine Labs.

        Args:
            order_id: Unique identifier of the order in the Pine Labs database.
                      Example: v1-4405071524-aa-qlAtAf

        Returns:
            JSON string with order details including:
            - order_id: Order identifier
            - status: Order status (CREATED, PROCESSED, FAILED, AUTHORIZED,
                      PARTIALLY_CAPTURED, PARTIALLY_REFUNDED, FULLY_REFUNDED, CANCELLED)
            - type: Order type (CHARGE, REFUND)
            - order_amount: Amount and currency
            - payments: List of payment attempts with method, status, and acquirer data
            - refunds: List of refunds (if any)
            - purchase_details: Customer and merchant metadata
            - created_at / updated_at: Timestamps
        """
        # Step 1: Validate and sanitize order_id
        try:
            order_id = validate_resource_id(order_id, "order_id", allow_dots=True)
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs API
        try:
            path = f"/pay/v1/orders/{order_id}"
            logger.info(
                "Fetching order: order_id=%s, correlation_id=%s",
                order_id,
                _get_correlation_id(),
            )

            response = await client.get(path)
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)
        except PineLabsAPIError as e:
            logger.error(
                "Pine Labs API error: code=%s status=%d, correlation_id=%s",
                e.code,
                e.status_code,
                _get_correlation_id(),
            )
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            logger.error(
                "Unexpected error fetching order: %s, correlation_id=%s",
                type(e).__name__,
                _get_correlation_id(),
            )
            return unexpected_error_response(e, "fetch order")
