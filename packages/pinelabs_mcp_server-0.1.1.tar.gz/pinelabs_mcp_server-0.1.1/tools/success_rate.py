"""
Pine Labs Merchant Success Rate MCP tool.

Defines the get_merchant_success_rate tool that:
1. Parses natural-language or exact datetime strings via dateparser
2. Validates the requested date range (max 7 days)
3. Calls the Pine Labs analytics API to retrieve transaction success-rate metrics
   (authentication handled via token manager)
4. Returns the result

Both start_date and end_date accept natural-language expressions (e.g. "5 hours ago",
"now", "yesterday at 00:00") as well as exact 'YYYY-MM-DD HH:MM:SS' strings.
dateparser resolves them to concrete datetimes using the server's real clock.
"""

import json
import logging
from datetime import datetime

import dateparser
import httpx
from fastmcp import FastMCP

from auth.credentials import get_client_credentials
from clients.pinelabs_client import PineLabsClient
from config import settings
from utils.errors import (
    api_error_response,
    validation_error_response,
    unexpected_error_response,
)

logger = logging.getLogger("pinelabs-mcp-server.tools.success_rate")

# Maximum allowed date range for success-rate queries
_MAX_RANGE_DAYS = 7

# Date format expected by the success-rate API
_API_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_SR_PATH = "/mcp/v1/merchant/transactions/success-rate"


def register_success_rate_tools(mcp: FastMCP, client: PineLabsClient) -> None:
    """Register the merchant success-rate tool on the FastMCP server."""

    @mcp.tool(
        name="get_merchant_success_rate",
        description=(
            "Fetch the transaction success rate (SR) for the merchant's account over a given "
            "date-time range. Returns success rate percentage.\n\n"
            "Both start_date and end_date accept natural-language datetime expressions "
            "OR exact 'YYYY-MM-DD HH:MM:SS' strings. The server resolves them using its "
            "real clock — the LLM does NOT need to know the current date/time.\n\n"
            "Examples:\n"
            "  - 'last 5 hours'    → start_date='5 hours ago', end_date='now'\n"
            "  - 'today\\'s SR'     → start_date='today at 00:00:00', end_date='now'\n"
            "  - 'yesterday\\'s SR' → start_date='yesterday at 00:00:00', end_date='yesterday at 23:59:59'\n"
            "  - 'last 7 days'     → start_date='7 days ago at 00:00:00', end_date='now'\n"
            "  - exact dates       → start_date='2026-04-01 00:00:00', end_date='2026-04-07 23:59:59'\n\n"
            "Constraints:\n"
            "  - Maximum date range: 7 days\n"
            "  - start_date must not be after end_date\n"
        ),
    )
    async def get_merchant_success_rate(
        start_date: str,
        end_date: str = "now",
    ) -> str:
        """
        Fetch merchant transaction success rate for a date range.

        Args:
            start_date: Natural-language datetime (e.g., '5 hours ago', 'yesterday at 00:00')
                        or exact 'YYYY-MM-DD HH:MM:SS' string. Maximum range is 7 days.
            end_date: Natural-language datetime (e.g., 'now', 'yesterday at 23:59:59')
                      or exact 'YYYY-MM-DD HH:MM:SS' string. Defaults to 'now'.

        Returns:
            JSON string with success-rate metrics including overall success rate,
            total transaction count, successful and failed transaction counts,
            and a per-payment-method breakdown.
        """
        # Step 1: Parse dates — accepts natural language ("5 hours ago", "now")
        # as well as exact "YYYY-MM-DD HH:MM:SS" / ISO 8601 strings.
        # Explicitly use IST so timestamps are consistent regardless of server timezone.
        _parser_settings = {"PREFER_DATES_FROM": "past", "RETURN_AS_TIMEZONE_AWARE": False, "TIMEZONE": "Asia/Kolkata"}
        dt_start = dateparser.parse(start_date.strip(), settings=_parser_settings)
        dt_end = dateparser.parse(end_date.strip(), settings=_parser_settings)

        if dt_start is None or dt_end is None:
            return validation_error_response(
                "Could not parse start_date or end_date. Use natural language "
                "(e.g., '5 hours ago', 'yesterday at 00:00') or 'YYYY-MM-DD HH:MM:SS' format."
            )

        # Step 2: Logical order check
        if dt_end < dt_start:
            return validation_error_response("end_date must not be before start_date.")

        # Step 3: Enforce max 7-day range (60s buffer for clock drift between parsing steps)
        if (dt_end - dt_start).total_seconds() > _MAX_RANGE_DAYS * 86400 + 60:
            return validation_error_response(
                f"Date range must not exceed {_MAX_RANGE_DAYS} days."
            )

        # Step 4: Build query parameters using the format the API expects
        params: dict[str, str] = {
            "start_date": dt_start.strftime(_API_DATE_FORMAT),
            "end_date": dt_end.strftime(_API_DATE_FORMAT),
        }

        # Step 5: Obtain auth token and call Pine Labs analytics API
        url = f"{settings.base_url}{_SR_PATH}"
        try:
            client_id, client_secret = get_client_credentials()
            bearer_token = await client._token_manager.get_access_token(
                client_id, client_secret,
            )
            headers = {"Authorization": f"Bearer {bearer_token}"}

            logger.info(
                "Fetching merchant success rate: start_date=%s end_date=%s",
                params["start_date"],
                params["end_date"],
            )
            async with httpx.AsyncClient(verify=True) as http_client:
                response = await http_client.get(url, params=params, headers=headers)
                response.raise_for_status()
                return json.dumps(response.json(), indent=2)

        except httpx.HTTPStatusError as e:
            logger.error("SR API HTTP error: status=%s", e.response.status_code)
            try:
                body = e.response.json()
                code = body.get("code", "API_ERROR")
                message = body.get("message") or body.get("error", "Request failed")
            except Exception:
                code = "API_ERROR"
                message = "Request failed"
            return api_error_response(message, code, e.response.status_code)
        except httpx.RequestError as e:
            logger.error("SR API request error: %s", e)
            return unexpected_error_response(e, "fetching merchant success rate")
        except Exception as e:
            logger.error("Unexpected error fetching merchant success rate: %s", e)
            return unexpected_error_response(e, "fetching merchant success rate")

