"""
Pine Labs Payment Link MCP tool.

Defines payment link tools that:
1. Validates params via Pydantic models
2. Calls Pine Labs API (token auto-managed by client)
3. Returns the result
"""

import json
import logging
import uuid
from typing import Optional

from pydantic import ValidationError
from fastmcp import FastMCP

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError
from models.payment_links import (
    Amount,
    Address,
    AllowedPaymentMethod,
    CreatePaymentLinkRequest,
    Customer,
    ProductDetail,
)
from utils.validators import validate_resource_id, validate_expire_by
from utils.errors import (
    api_error_response,
    validation_error_response,
    unexpected_error_response,
)
from utils.prompt_guard import (
    TOOL_TRUST_PREFIX,
    TOOL_TRUST_SUFFIX,
    DESTRUCTIVE_TOOL_SUFFIX,
    sanitize_output,
    sanitize_tool_inputs,
    wrap_tool_response,
    secure_tool,
)
from utils.metrics import instrumented_tool, record_business_outcome
from utils.pii_filter import strip_sensitive_keys, filter_pii, PII_STRIP_KEYS

logger = logging.getLogger("pinelabs-mcp-server.tools.payment_links")


def _sanitize_validation_error(e: Exception) -> str:
    """Format a validation error without echoing user-provided input (PII safety)."""
    if isinstance(e, ValidationError):
        return json.dumps(e.errors(include_input=False), default=str)
    return str(e)

def register_payment_link_tools(mcp: FastMCP, client: PineLabsClient) -> None:
    """Register all payment link tools on the FastMCP server."""

    @secure_tool(mcp, name="create_payment_link", description=(
            TOOL_TRUST_PREFIX
            + "Create a new Pine Labs payment link. "
            "Returns a short URL that customers can use to make payments. "
            "Requires amount (in paisa) and customer details."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("create_payment_link")
    async def create_payment_link(
        amount_value: int,
        currency: str = "INR",
        customer_email: Optional[str] = None,
        customer_first_name: Optional[str] = None,
        customer_last_name: Optional[str] = None,
        customer_mobile: Optional[str] = None,
        customer_country_code: Optional[str] = None,
        customer_id: Optional[str] = None,
        description: Optional[str] = None,
        expire_by: Optional[str] = None,
        allowed_payment_methods: Optional[list[str]] = None,
        merchant_payment_link_reference: Optional[str] = None,
        billing_address1: Optional[str] = None,
        billing_address2: Optional[str] = None,
        billing_address3: Optional[str] = None,
        billing_city: Optional[str] = None,
        billing_state: Optional[str] = None,
        billing_country: Optional[str] = None,
        billing_pincode: Optional[str] = None,
        billing_full_name: Optional[str] = None,
        shipping_address1: Optional[str] = None,
        shipping_address2: Optional[str] = None,
        shipping_address3: Optional[str] = None,
        shipping_city: Optional[str] = None,
        shipping_state: Optional[str] = None,
        shipping_country: Optional[str] = None,
        shipping_pincode: Optional[str] = None,
        shipping_full_name: Optional[str] = None,
        merchant_metadata: Optional[dict[str, str]] = None,
        product_code: Optional[str] = None,
        product_amount: Optional[int] = None,
        cart_coupon_discount_amount: Optional[int] = None,
    ) -> str:
        """
        Create a Pine Labs payment link.

        Args:
            amount_value: Amount in paisa (e.g., 50000 = Rs.500). Min: 100, Max: 100000000
            currency: Three-letter ISO currency code (default: INR)
            customer_email: Customer email address
            customer_first_name: Customer first name
            customer_last_name: Customer last name
            customer_mobile: Customer mobile number (10-20 digits)
            customer_country_code: Country code for mobile (e.g., +91). Defaults to +91
            customer_id: Customer ID in Pine Labs database
            description: Payment description (e.g., "Payment for Order #12345")
            expire_by: Expiry timestamp in ISO 8601 (e.g., 2025-03-21T08:29Z). Max 180 days
            allowed_payment_methods: Payment methods to offer: CARD, UPI, POINTS, NETBANKING, WALLET, CREDIT_EMI, DEBIT_EMI
            merchant_payment_link_reference: Your unique reference for this payment link (1-50 chars, for idempotency/reconciliation). Auto-generated if not provided.
            billing_address1: Billing address line 1
            billing_address2: Billing address line 2
            billing_address3: Billing address line 3
            billing_city: Billing city
            billing_state: Billing state
            billing_country: Billing country
            billing_pincode: Billing pincode
            billing_full_name: Billing full name
            shipping_address1: Shipping address line 1
            shipping_address2: Shipping address line 2
            shipping_address3: Shipping address line 3
            shipping_city: Shipping city
            shipping_state: Shipping state
            shipping_country: Shipping country
            shipping_pincode: Shipping pincode
            shipping_full_name: Shipping full name
            merchant_metadata: Custom key-value metadata (e.g., {"order_id": "12345"})
            product_code: Product identifier (e.g., "redmi_10"). If provided, creates a product_details entry.
            product_amount: Product amount in paisa. Used only when product_code is provided.
            cart_coupon_discount_amount: Cart-level coupon discount in paisa.

        Returns:
            JSON string with payment link details including the payment URL
        """
        # Step 1: Validate and set merchant reference (idempotency key)
        if merchant_payment_link_reference:
            try:
                merchant_payment_link_reference = validate_resource_id(
                    merchant_payment_link_reference,
                    "merchant_payment_link_reference",
                    max_length=50,
                )
            except ValueError as e:
                return validation_error_response(str(e))
        else:
            # Auto-generate a unique reference ID (32 hex chars)
            merchant_payment_link_reference = uuid.uuid4().hex

        # Step 2: Validate expire_by if provided
        if expire_by:
            try:
                validate_expire_by(expire_by)
            except ValueError as e:
                return validation_error_response(str(e))

        # Step 2b: Scan free-text inputs for prompt injection
        injection_err = sanitize_tool_inputs(
            description=description,
            merchant_metadata=merchant_metadata,
        )
        if injection_err:
            return validation_error_response(injection_err)

        # Step 3: Build nested objects from flat params
        try:
            # -- Billing address
            billing_address = None
            billing_fields = {
                "address1": billing_address1,
                "address2": billing_address2,
                "address3": billing_address3,
                "city": billing_city,
                "state": billing_state,
                "country": billing_country,
                "pincode": billing_pincode,
                "full_name": billing_full_name,
            }
            if any(v is not None for v in billing_fields.values()):
                billing_address = Address(
                    address_category="billing",
                    **{k: v for k, v in billing_fields.items() if v is not None},
                )

            # -- Shipping address
            shipping_address = None
            shipping_fields = {
                "address1": shipping_address1,
                "address2": shipping_address2,
                "address3": shipping_address3,
                "city": shipping_city,
                "state": shipping_state,
                "country": shipping_country,
                "pincode": shipping_pincode,
                "full_name": shipping_full_name,
            }
            if any(v is not None for v in shipping_fields.values()):
                shipping_address = Address(
                    address_category="shipping",
                    **{k: v for k, v in shipping_fields.items() if v is not None},
                )

            # -- Customer
            customer = Customer(
                email_id=customer_email,
                first_name=customer_first_name,
                last_name=customer_last_name,
                mobile_number=customer_mobile,
                country_code=customer_country_code,
                customer_id=customer_id,
                billing_address=billing_address,
                shipping_address=shipping_address,
            )
        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # -- Allowed payment methods
        payment_methods = None
        if allowed_payment_methods:
            try:
                payment_methods = [
                    AllowedPaymentMethod(m.upper()) for m in allowed_payment_methods
                ]
            except ValueError:
                valid = [e.value for e in AllowedPaymentMethod]
                return validation_error_response(
                    f"Invalid payment method. Allowed values: {valid}"
                )

        # -- Product details / Cart coupon discount
        product_details = None
        cart_coupon = None
        try:
            if product_code:
                pd_kwargs: dict = {"product_code": product_code}
                if product_amount is not None:
                    pd_kwargs["product_amount"] = Amount(
                        value=product_amount,
                        currency=currency,
                    )
                product_details = [ProductDetail(**pd_kwargs)]
            if cart_coupon_discount_amount is not None:
                cart_coupon = Amount(
                    value=cart_coupon_discount_amount,
                    currency=currency,
                )
        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # Step 4: Build the full request model (Pydantic validates everything)
        try:
            request_body = CreatePaymentLinkRequest(
                amount=Amount(value=amount_value, currency=currency),
                merchant_payment_link_reference=merchant_payment_link_reference,
                customer=customer,
                description=description,
                expire_by=expire_by,
                allowed_payment_methods=payment_methods,
                product_details=product_details,
                cart_coupon_discount_amount=cart_coupon,
                merchant_metadata=merchant_metadata,
            )
        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # Step 5: Call Pine Labs API
        try:
            payload = request_body.model_dump(exclude_none=True)
            logger.info(
                "Creating payment link: payment_link_ref=%s amount=%s %s",
                merchant_payment_link_reference,
                amount_value,
                currency,
            )
            response = await client.post(
                "/pay/v1/paymentlink",
                payload,
            )
            record_business_outcome("payment_link", "success")
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            record_business_outcome("payment_link", "failed")
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            record_business_outcome("payment_link", "failed")
            logger.error("Unexpected error creating payment link: %s", e)
            return unexpected_error_response(e, "create payment link")

    @secure_tool(mcp, name="get_payment_link_by_id", description=(
            TOOL_TRUST_PREFIX
            + "Fetch a Pine Labs payment link by its payment link ID. "
            "Returns the full payment link details including status, amount, "
            "customer info, and more."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("get_payment_link_by_id")
    async def get_payment_link_by_id(
        payment_link_id: str,
    ) -> str:
        """
        Get a Pine Labs payment link by its ID.

        Args:
            payment_link_id: Unique identifier of the payment link
                             (e.g., pl-v1-5757575757-aa-hU1rUd). Max 50 characters.

        Returns:
            JSON string with payment link details including status, amount,
            customer info, product details, and timestamps.
        """
        # Step 1: Validate payment_link_id
        try:
            payment_link_id = validate_resource_id(payment_link_id, "payment_link_id", allow_dots=True)
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs API
        try:
            logger.info(
                "Fetching payment link: payment_link_id=%s",
                payment_link_id,
            )
            response = await client.get(
                f"/pay/v1/paymentlink/{payment_link_id}",
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            logger.error("Unexpected error fetching payment link: %s", e)
            return unexpected_error_response(e, "fetch payment link")

    @secure_tool(mcp, name="get_payment_link_by_merchant_reference", description=(
            TOOL_TRUST_PREFIX
            + "Fetch a Pine Labs payment link by its merchant payment link reference. "
            "Returns the full payment link details including status, amount, "
            "customer info, and more."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("get_payment_link_by_merchant_reference")
    async def get_payment_link_by_merchant_reference(
        merchant_payment_link_reference: str,
    ) -> str:
        """
        Get a Pine Labs payment link by its merchant payment link reference.

        Args:
            merchant_payment_link_reference: Unique merchant reference for the payment link.
                                             Max 50 characters.

        Returns:
            JSON string with payment link details including status, amount,
            customer info, product details, and timestamps.
        """
        # Step 1: Validate reference
        try:
            merchant_payment_link_reference = validate_resource_id(
                merchant_payment_link_reference, "merchant_payment_link_reference"
            )
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs API
        try:
            logger.info(
                "Fetching payment link by merchant ref: %s",
                merchant_payment_link_reference,
            )
            response = await client.get(
                f"/pay/v1/paymentlink/ref/{merchant_payment_link_reference}",
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            logger.error("Unexpected error fetching payment link by merchant ref: %s", e)
            return unexpected_error_response(e, "fetch payment link")

    @secure_tool(mcp, name="cancel_payment_link", description=(
            TOOL_TRUST_PREFIX
            + "Cancel a Pine Labs payment link. "
            "Only payment links with status CREATED can be cancelled. "
            "Returns the updated payment link details with status CANCELLED."
            + TOOL_TRUST_SUFFIX
            + DESTRUCTIVE_TOOL_SUFFIX
        ),
    )
    @instrumented_tool("cancel_payment_link")
    async def cancel_payment_link(
        payment_link_id: str,
    ) -> str:
        """
        Cancel a Pine Labs payment link.

        Args:
            payment_link_id: Unique identifier of the payment link
                             (e.g., pl-v1-5757575757-aa-hU1rUd). Max 50 characters.

        Returns:
            JSON string with cancelled payment link details.
        """
        # Step 1: Validate payment_link_id
        try:
            payment_link_id = validate_resource_id(payment_link_id, "payment_link_id", allow_dots=True)
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs API (PUT with no body)
        try:
            logger.info(
                "Cancelling payment link: payment_link_id=%s",
                payment_link_id,
            )
            response = await client.put(
                f"/pay/v1/paymentlink/{payment_link_id}/cancel",
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            logger.error("Unexpected error cancelling payment link: %s", e)
            return unexpected_error_response(e, "cancel payment link")

    @secure_tool(mcp, name="resend_payment_link_notification", description=(
            TOOL_TRUST_PREFIX
            + "Resend a Pine Labs payment link notification to the customer. "
            "Sends the payment link again via the original notification channel "
            "(email/SMS). Only works for active (CREATED) payment links."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("resend_payment_link_notification")
    async def resend_payment_link_notification(
        payment_link_id: str,
    ) -> str:
        """
        Resend a payment link notification to the customer.

        Args:
            payment_link_id: Unique identifier of the payment link
                             (e.g., pl-v1-5757575757-aa-hU1rUd). Max 50 characters.

        Returns:
            JSON string with payment link details after resending notification.
        """
        # Step 1: Validate payment_link_id
        try:
            payment_link_id = validate_resource_id(payment_link_id, "payment_link_id", allow_dots=True)
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 2: Call Pine Labs API (PATCH with no body)
        try:
            logger.info(
                "Resending notification for payment link: payment_link_id=%s",
                payment_link_id,
            )
            response = await client.patch(
                f"/pay/v1/paymentlink/{payment_link_id}/notify",
            )
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            logger.error("Pine Labs API error: %s", e)
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            logger.error("Unexpected error resending payment link notification: %s", e)
            return unexpected_error_response(e, "resend notification")
