"""
Pine Labs Create Checkout Order (Generate Checkout Link) MCP tool.

Defines the create_order tool that:
1. Validates params via Pydantic models
2. Calls Pine Labs API to generate a checkout link (token auto-managed by client)
3. Returns the result
"""

import json
import logging
from typing import Optional

from pydantic import ValidationError
from opentelemetry import trace
from fastmcp import FastMCP

from clients.pinelabs_client import PineLabsClient, PineLabsAPIError
from models.payment_links import Address, Amount
from models.checkout_orders import (
    CartDetails,
    CartItem,
    CheckoutAllowedPaymentMethod,
    CheckoutCustomer,
    CheckoutProduct,
    CreateCheckoutOrderRequest,
    IntegrationMode,
    PurchaseDetails,
)
from utils.validators import validate_resource_id
from utils.errors import (
    api_error_response,
    validation_error_response,
    unexpected_error_response,
)
from utils.metrics import instrumented_tool, record_business_outcome
from utils.prompt_guard import (
    TOOL_TRUST_PREFIX,
    TOOL_TRUST_SUFFIX,
    sanitize_output,
    sanitize_tool_inputs,
    wrap_tool_response,
    secure_tool,
)
from utils.pii_filter import strip_sensitive_keys, filter_pii, PII_STRIP_KEYS

logger = logging.getLogger("pinelabs-mcp-server.tools.checkout_orders")


def _get_correlation_id() -> str:
    """Get the current correlation ID (trace ID) for log correlation."""
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if ctx and ctx.trace_id:
        return format(ctx.trace_id, "032x")
    return "no-trace"


def _sanitize_validation_error(e: Exception) -> str:
    """Format a validation error without echoing user-provided input (PII safety)."""
    if isinstance(e, ValidationError):
        return json.dumps(e.errors(include_input=False), default=str)
    return str(e)


def register_checkout_order_tools(mcp: FastMCP, client: PineLabsClient) -> None:
    """Register all checkout order tools on the FastMCP server."""

    @secure_tool(mcp, name="create_order", description=(
            TOOL_TRUST_PREFIX
            + "Create a new Pine Labs checkout order and generate a checkout link. "
            "Returns an order ID and redirect URL that customers can use to make payments. "
            "Requires a merchant order reference and amount (in paisa). "
            "Supports REDIRECT, IFRAME, and SDK integration modes. "
            "Note: For TPV (Third Party Validation) orders requiring bank account details, "
            "use a separate secure server-side flow — bank details cannot be provided through this tool."
            + TOOL_TRUST_SUFFIX
        ),
    )
    @instrumented_tool("create_order")
    async def create_order(
        merchant_order_reference: str,
        amount_value: int,
        currency: str = "INR",
        integration_mode: Optional[str] = None,
        pre_auth: Optional[bool] = None,
        allowed_payment_methods: Optional[list[str]] = None,
        notes: Optional[str] = None,
        callback_url: Optional[str] = None,
        failure_callback_url: Optional[str] = None,
        customer_email: Optional[str] = None,
        customer_first_name: Optional[str] = None,
        customer_last_name: Optional[str] = None,
        customer_mobile: Optional[str] = None,
        customer_country_code: Optional[str] = None,
        customer_id: Optional[str] = None,
        billing_address1: Optional[str] = None,
        billing_address2: Optional[str] = None,
        billing_address3: Optional[str] = None,
        billing_city: Optional[str] = None,
        billing_state: Optional[str] = None,
        billing_country: Optional[str] = None,
        billing_pincode: Optional[str] = None,
        billing_full_name: Optional[str] = None,
        shipping_address1: Optional[str] = None,
        shipping_address2: Optional[str] = None,
        shipping_address3: Optional[str] = None,
        shipping_city: Optional[str] = None,
        shipping_state: Optional[str] = None,
        shipping_country: Optional[str] = None,
        shipping_pincode: Optional[str] = None,
        shipping_full_name: Optional[str] = None,
        merchant_metadata: Optional[dict[str, str]] = None,
        product_code: Optional[str] = None,
        product_amount: Optional[int] = None,
    ) -> str:
        """
        Create a Pine Labs checkout order (generate checkout link).

        Args:
            merchant_order_reference: Unique identifier for the order (1-50 chars). Used for idempotency/reconciliation.
            amount_value: Transaction amount in paisa (e.g., 1100 = Rs.11). Min: 100, Max: 100000000
            currency: Three-letter ISO currency code (default: INR)
            integration_mode: Integration mode: REDIRECT (default), IFRAME, or SDK
            pre_auth: Whether pre-authorization is required (default: false)
            allowed_payment_methods: Payment methods to offer: CARD, UPI, POINTS, NETBANKING, WALLET, CREDIT_EMI, DEBIT_EMI, BNPL
            notes: Note to show against the order (e.g., Order1)
            callback_url: URL to redirect customers on success
            failure_callback_url: URL to redirect customers on failure
            customer_email: Customer email address
            customer_first_name: Customer first name
            customer_last_name: Customer last name
            customer_mobile: Customer mobile number (10-20 digits)
            customer_country_code: Country code for mobile (e.g., 91). Defaults to 91
            customer_id: Customer ID in Pine Labs database
            billing_address1: Billing address line 1
            billing_address2: Billing address line 2
            billing_address3: Billing address line 3
            billing_city: Billing city
            billing_state: Billing state
            billing_country: Billing country
            billing_pincode: Billing pincode
            billing_full_name: Billing full name
            shipping_address1: Shipping address line 1
            shipping_address2: Shipping address line 2
            shipping_address3: Shipping address line 3
            shipping_city: Shipping city
            shipping_state: Shipping state
            shipping_country: Shipping country
            shipping_pincode: Shipping pincode
            shipping_full_name: Shipping full name
            merchant_metadata: Custom key-value metadata (max 10 pairs, 256 chars each)
            product_code: Product code for EMI orders (e.g., redm_1)
            product_amount: Product amount in paisa (used with product_code)

        Returns:
            JSON string with checkout order details including:
            - order_id: Order identifier
            - token: Redirect token
            - redirect_url: URL for customer checkout
            - response_code: HTTP response code
            - response_message: Success/error message
        """
        # Step 1: Validate merchant_order_reference
        try:
            merchant_order_reference = validate_resource_id(
                merchant_order_reference,
                "merchant_order_reference",
                max_length=50,
            )
        except ValueError as e:
            return validation_error_response(str(e))

        # Step 1b: Scan free-text inputs for prompt injection
        injection_err = sanitize_tool_inputs(
            notes=notes,
            callback_url=callback_url,
            failure_callback_url=failure_callback_url,
            merchant_metadata=merchant_metadata,
        )
        if injection_err:
            return validation_error_response(injection_err)

        # Step 2: Build nested objects from flat params
        try:
            # -- Billing address
            billing_address = None
            billing_fields = {
                "address1": billing_address1,
                "address2": billing_address2,
                "address3": billing_address3,
                "city": billing_city,
                "state": billing_state,
                "country": billing_country,
                "pincode": billing_pincode,
                "full_name": billing_full_name,
            }
            if any(v is not None for v in billing_fields.values()):
                billing_address = Address(
                    address_category="billing",
                    **{k: v for k, v in billing_fields.items() if v is not None},
                )

            # -- Shipping address
            shipping_address = None
            shipping_fields = {
                "address1": shipping_address1,
                "address2": shipping_address2,
                "address3": shipping_address3,
                "city": shipping_city,
                "state": shipping_state,
                "country": shipping_country,
                "pincode": shipping_pincode,
                "full_name": shipping_full_name,
            }
            if any(v is not None for v in shipping_fields.values()):
                shipping_address = Address(
                    address_category="shipping",
                    **{k: v for k, v in shipping_fields.items() if v is not None},
                )

            # -- Customer (only build if at least one field provided)
            customer = None
            customer_fields = {
                "email_id": customer_email,
                "first_name": customer_first_name,
                "last_name": customer_last_name,
                "mobile_number": customer_mobile,
                "country_code": customer_country_code,
                "customer_id": customer_id,
                "billing_address": billing_address,
                "shipping_address": shipping_address,
            }
            if any(v is not None for v in customer_fields.values()):
                customer = CheckoutCustomer(**customer_fields)

            # -- Purchase details (only build if we have customer or metadata)
            purchase_details = None
            if customer or merchant_metadata:
                purchase_details = PurchaseDetails(
                    customer=customer,
                    merchant_metadata=merchant_metadata,
                )

        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # Step 3: Validate and parse allowed payment methods
        payment_methods = None
        if allowed_payment_methods:
            try:
                payment_methods = [
                    CheckoutAllowedPaymentMethod(m.upper()) for m in allowed_payment_methods
                ]
            except ValueError:
                valid = [e.value for e in CheckoutAllowedPaymentMethod]
                return validation_error_response(
                    f"Invalid payment method. Allowed values: {valid}"
                )

        # Step 4: Validate and parse integration mode
        mode = None
        if integration_mode:
            try:
                mode = IntegrationMode(integration_mode.upper())
            except ValueError:
                valid = [e.value for e in IntegrationMode]
                return validation_error_response(
                    f"Invalid integration mode. Allowed values: {valid}"
                )

        # Step 5: Build product list (for EMI orders)
        products = None
        try:
            if product_code:
                pd_kwargs: dict = {"product_code": product_code}
                if product_amount is not None:
                    pd_kwargs["product_amount"] = Amount(
                        value=product_amount,
                        currency=currency,
                    )
                products = [CheckoutProduct(**pd_kwargs)]
        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # Step 6: Build the full request model (Pydantic validates everything)
        try:
            request_body = CreateCheckoutOrderRequest(
                merchant_order_reference=merchant_order_reference,
                order_amount=Amount(value=amount_value, currency=currency),
                integration_mode=mode,
                pre_auth=pre_auth,
                allowed_payment_methods=payment_methods,
                notes=notes,
                callback_url=callback_url,
                failure_callback_url=failure_callback_url,
                purchase_details=purchase_details,
                product=products,
            )
        except (ValidationError, ValueError) as e:
            return validation_error_response(_sanitize_validation_error(e))

        # Step 7: Call Pine Labs API
        try:
            payload = request_body.model_dump(exclude_none=True)
            logger.info(
                "Creating checkout order: merchant_ref=%s amount=%s %s, correlation_id=%s",
                merchant_order_reference,
                amount_value,
                currency,
                _get_correlation_id(),
            )

            response = await client.post(
                "/checkout/v1/orders",
                payload,
            )
            record_business_outcome("checkout_order", "success")
            response = strip_sensitive_keys(response, PII_STRIP_KEYS)
            response = filter_pii(response)
            return json.dumps(sanitize_output(response), indent=2)

        except PineLabsAPIError as e:
            record_business_outcome("checkout_order", "failed")
            logger.error(
                "Pine Labs API error: code=%s status=%d, correlation_id=%s",
                e.code,
                e.status_code,
                _get_correlation_id(),
            )
            return api_error_response(
                e.message, e.code, e.status_code, e.payload or None
            )
        except Exception as e:
            record_business_outcome("checkout_order", "failed")
            logger.error(
                "Unexpected error creating checkout order: %s, correlation_id=%s",
                type(e).__name__,
                _get_correlation_id(),
            )
            return unexpected_error_response(e, "create checkout order")
