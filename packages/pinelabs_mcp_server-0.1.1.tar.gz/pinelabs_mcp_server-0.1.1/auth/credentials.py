"""
Per-request client credential storage.

Uses a ``ContextVar`` so each ASGI request / asyncio task gets its own
copy of (client_id, client_secret) — no shared mutable state.

This module is deliberately dependency-free to avoid circular imports
(both ``main`` and ``clients.pinelabs_client`` import from here).
"""

from contextvars import ContextVar, Token

# Set by ClientCredentialsMiddleware, read by PineLabsClient._request()
_credentials_var: ContextVar[tuple[str, str]] = ContextVar("client_credentials")


def set_client_credentials(client_id: str, client_secret: str) -> Token[tuple[str, str]]:
    """Store client credentials for the current request context.

    Returns the context token so callers can restore the previous value in a
    ``finally`` block and avoid leaking credentials across requests.
    """
    return _credentials_var.set((client_id, client_secret))


def reset_client_credentials(token: Token[tuple[str, str]]) -> None:
    """Restore the previous request credential context."""
    _credentials_var.reset(token)


def get_client_credentials() -> tuple[str, str]:
    """Return (client_id, client_secret) for the current request context.

    Raises ``RuntimeError`` if credentials have not been set (no middleware
    in the call chain) **or** if the middleware received empty/missing
    ``X-Client-Id`` / ``X-Client-Secret`` headers.
    """
    try:
        creds = _credentials_var.get()
    except LookupError:
        raise RuntimeError(
            "Client credentials not configured. "
            "Provide X-Client-Id and X-Client-Secret headers in your MCP client configuration."
        )
    client_id, client_secret = creds
    if not client_id or not client_secret:
        raise RuntimeError(
            "Client credentials not configured. "
            "Provide X-Client-Id and X-Client-Secret headers in your MCP client configuration."
        )
    return creds
