"""
Redis-backed authorization token cache for Pine Labs MCP Server.

Uses a shared ``redis.asyncio`` connection pool so every request reuses
connections instead of creating new ones.  Falls back to direct token
generation if Redis is unavailable (graceful degradation).
"""

from __future__ import annotations

import logging
from typing import Optional

import redis.asyncio as aioredis
from redis.exceptions import ConnectionError
from opentelemetry import trace

from utils.metrics import (
    record_cache_hit,
    record_cache_miss,
    record_cache_error,
    record_cache_write,
    record_cache_delete,
    record_redis_up,
)

logger = logging.getLogger("pinelabs-mcp-server.auth.token_cache")
_tracer = trace.get_tracer("pinelabs-mcp-server.auth.token_cache")

_KEY_PREFIX = "mcp_auth_token:"


def _get_trace_id() -> str:
    """Return the current OTel trace-id hex string, or 'none'."""
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if ctx and ctx.trace_id:
        return format(ctx.trace_id, "032x")
    return "none"


class TokenCache:
    """Thin async wrapper around Redis for caching OAuth2 access tokens.

    Args:
        redis_host: Redis server hostname.
        redis_port: Redis server port.
        redis_db: Redis database number.
        max_connections: Maximum size of the connection pool.
        default_ttl: Default TTL in seconds for cached tokens.
    """

    def __init__(
        self,
        redis_host: str,
        redis_port: int = 6379,
        redis_db: int = 0,
        max_connections: int = 50,
        default_ttl: int = 3000,
    ) -> None:
        self._default_ttl = default_ttl
        self._pool = aioredis.ConnectionPool(
            host=redis_host,
            port=redis_port,
            db=redis_db,
            max_connections=max_connections,
            decode_responses=True,
        )
        self._redis = aioredis.Redis(connection_pool=self._pool)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Verify Redis connectivity at startup.

        Logs a warning and continues if Redis is unreachable (graceful degradation).
        """
        try:
            await self._redis.ping()
            record_redis_up(True)
            logger.info(
                "Redis token cache connected (host=%s, port=%s, db=%s, pool_size=%s)",
                self._pool.connection_kwargs.get("host"),
                self._pool.connection_kwargs.get("port"),
                self._pool.connection_kwargs.get("db"),
                self._pool.max_connections,
            )
        except ConnectionError:
            record_redis_up(False)
            logger.warning(
                "Redis token cache unavailable at startup — "
                "token caching will be skipped until Redis recovers",
            )
        except Exception:
            record_redis_up(False)
            logger.warning(
                "Unexpected error connecting to Redis at startup",
                exc_info=True,
            )

    async def close(self) -> None:
        """Shut down the connection pool."""
        try:
            await self._redis.aclose()
        except Exception as exc:
            logger.warning(
                "Error closing Redis client: %s",
                exc,
                exc_info=True,
            )
        finally:
            try:
                await self._pool.disconnect()
            except Exception as exc:
                logger.warning(
                    "Error disconnecting Redis pool: %s",
                    exc,
                    exc_info=True,
                )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def get_token(self, client_id: str) -> Optional[str]:
        """Return the cached access token for *client_id*, or ``None``."""
        key = f"{_KEY_PREFIX}{client_id}"
        with _tracer.start_as_current_span("token_cache.get", attributes={"client_id": _mask_id(client_id)}):
            try:
                token = await self._redis.get(key)
                record_redis_up(True)
                if token:
                    record_cache_hit()
                    logger.info(
                        "Token cache HIT for client_id=%s trace_id=%s",
                        _mask_id(client_id),
                        _get_trace_id(),
                    )
                else:
                    record_cache_miss()
                    logger.info(
                        "Token cache MISS for client_id=%s trace_id=%s",
                        _mask_id(client_id),
                        _get_trace_id(),
                    )
                return token
            except ConnectionError:
                record_cache_error("get")
                record_redis_up(False)
                logger.warning(
                    "Redis unavailable during GET for client_id=%s trace_id=%s — skipping cache",
                    _mask_id(client_id),
                    _get_trace_id(),
                )
                return None
            except Exception:
                record_cache_error("get")
                logger.warning(
                    "Unexpected error during cache GET for client_id=%s trace_id=%s",
                    _mask_id(client_id),
                    _get_trace_id(),
                    exc_info=True,
                )
                return None

    async def set_token(
        self,
        client_id: str,
        token: str,
        ttl_seconds: Optional[int] = None,
    ) -> None:
        """Store *token* for *client_id* with a TTL (default 50 min / 3000 s)."""
        key = f"{_KEY_PREFIX}{client_id}"
        ttl = ttl_seconds if ttl_seconds is not None else self._default_ttl
        with _tracer.start_as_current_span("token_cache.set", attributes={"client_id": _mask_id(client_id), "ttl": ttl}):
            try:
                await self._redis.set(key, token, ex=ttl)
                record_cache_write()
                record_redis_up(True)
                logger.info(
                    "Token stored in Redis for client_id=%s with TTL=%ds trace_id=%s",
                    _mask_id(client_id),
                    ttl,
                    _get_trace_id(),
                )
            except ConnectionError:
                record_cache_error("set")
                record_redis_up(False)
                logger.warning(
                    "Redis unavailable during SET for client_id=%s trace_id=%s — token not cached",
                    _mask_id(client_id),
                    _get_trace_id(),
                )
            except Exception:
                record_cache_error("set")
                logger.warning(
                    "Unexpected error during cache SET for client_id=%s trace_id=%s",
                    _mask_id(client_id),
                    _get_trace_id(),
                    exc_info=True,
                )

    async def delete_token(self, client_id: str) -> None:
        """Invalidate the cached token for *client_id*."""
        key = f"{_KEY_PREFIX}{client_id}"
        with _tracer.start_as_current_span("token_cache.delete", attributes={"client_id": _mask_id(client_id)}):
            try:
                await self._redis.delete(key)
                record_cache_delete()
                record_redis_up(True)
            except ConnectionError:
                record_cache_error("delete")
                record_redis_up(False)
                logger.warning(
                    "Redis unavailable during DELETE for client_id=%s trace_id=%s",
                    _mask_id(client_id),
                    _get_trace_id(),
                )
            except Exception:
                record_cache_error("delete")
                logger.warning(
                    "Unexpected error during cache DELETE for client_id=%s trace_id=%s",
                    _mask_id(client_id),
                    _get_trace_id(),
                    exc_info=True,
                )

def _mask_id(client_id: str) -> str:
    """Mask a client_id for safe logging (show first 8 chars)."""
    if len(client_id) <= 8:
        return client_id[:2] + "***"
    return client_id[:8] + "***"
