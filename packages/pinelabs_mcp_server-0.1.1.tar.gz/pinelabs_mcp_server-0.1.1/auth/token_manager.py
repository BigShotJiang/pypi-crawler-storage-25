"""
OAuth2 Client Credentials token manager for Pine Labs API.

Fetches an access token using client_id / client_secret.
When a ``TokenCache`` is provided, tokens are cached in Redis so that
repeated requests for the same client_id reuse the cached token instead
of calling the Pine Labs token endpoint on every tool execution.
"""

import logging
import re
import time
from typing import Optional

import httpx
from opentelemetry import trace

from auth.token_cache import TokenCache
from utils.metrics import record_auth_token_fetch

logger = logging.getLogger("pinelabs-mcp-server.auth")
_tracer = trace.get_tracer("pinelabs-mcp-server.auth")

# UUID-style client_id pattern (hex + hyphens, 32-40 chars)
_CLIENT_ID_RE = re.compile(r"^[a-fA-F0-9\-]{32,40}$")


class TokenManager:
    """Fetches OAuth2 client_credentials tokens, with optional Redis caching."""

    def __init__(
        self,
        token_url: str,
        timeout: float = 30.0,
        token_cache: Optional[TokenCache] = None,
    ) -> None:
        self._token_url = token_url
        self._timeout = timeout
        self._cache = token_cache

    async def get_access_token(self, client_id: str, client_secret: str) -> str:
        """Return an access token — from cache if available, otherwise freshly fetched.

        Args:
            client_id: OAuth2 client ID from request headers.
            client_secret: OAuth2 client secret from request headers.

        Returns:
            The access token string.

        Raises:
            RuntimeError: If credentials are missing or the token request fails.
            ValueError: If client_id format is invalid.
        """
        if not client_id or not client_secret:
            raise RuntimeError(
                "Client credentials not configured. "
                "Provide X-Client-Id and X-Client-Secret headers in your MCP client configuration."
            )

        if not _CLIENT_ID_RE.match(client_id):
            raise ValueError("Invalid client_id format.")

        masked = client_id[:8] + "***"

        with _tracer.start_as_current_span("token_manager.get_access_token", attributes={"client_id": masked}):
            # --- Check cache first ---
            if self._cache is not None:
                cached = await self._cache.get_token(client_id)
                if cached:
                    logger.info("Using cached token from Redis for client_id=%s", masked)
                    return cached

            # --- Cache miss: fetch from Pine Labs ---
            logger.info("No cached token found for client_id=%s — generating new token", masked)
            token = await self._fetch_token(client_id, client_secret)

            # --- Store in cache ---
            if self._cache is not None:
                await self._cache.set_token(client_id, token)

            return token

    async def _fetch_token(self, client_id: str, client_secret: str) -> str:
        """Call the Pine Labs OAuth2 token endpoint and return the access token."""
        payload = {
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": "client_credentials",
        }

        logger.info("Fetching new access token from %s", self._token_url)

        start = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=self._timeout, verify=True) as http:
                response = await http.post(
                    self._token_url,
                    json=payload,
                    headers={
                        "accept": "application/json",
                        "content-type": "application/json",
                    },
                )

            elapsed = time.perf_counter() - start

            if response.status_code != 200:
                record_auth_token_fetch("error", elapsed)
                logger.error(
                    "Token request failed: status=%d",
                    response.status_code,
                )
                raise RuntimeError(
                    f"Failed to obtain access token: HTTP {response.status_code}"
                )

            data = response.json()
            access_token = data["access_token"]

            record_auth_token_fetch("success", elapsed)
            logger.info("Access token obtained successfully")
            return access_token
        except RuntimeError:
            raise
        except Exception:
            elapsed = time.perf_counter() - start
            record_auth_token_fetch("error", elapsed)
            raise
