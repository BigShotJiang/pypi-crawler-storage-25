"""
Switch游戏折扣与上新查询 MCP Server

从 eshop-prices.com 扒Switch游戏价格，数据来源是Nintendo eShop官方，
免费公开，不需要Token也不用登录，随便用。
"""

import json
import urllib.request
import urllib.parse
import re
from fastmcp import FastMCP

import os
os.environ["FASTMCP_LOG_LEVEL"] = "ERROR"

mcp = FastMCP("switch-game-mcp")

# 伪装一下UA，不然会被网站拦
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "text/html",
}


def _fetch(url: str) -> str:
    """请求网页，拿到HTML"""
    req = urllib.request.Request(url, headers=HEADERS)
    resp = urllib.request.urlopen(req, timeout=15)
    return resp.read().decode("utf-8", errors="replace")


def _parse_games(html: str, limit: int = 15):
    """从eshop-prices.com的页面里抠出游戏列表
    
    这网站的列表页结构还算规矩，每个游戏都在
    <a class="games-list-item"> 里，用正则一把梭就完了
    """
    pattern = r'<a class="games-list-item"[^>]*href="(/games/\d+[^"]*)"[^>]*>(.*?)</a>'
    matches = re.findall(pattern, html, re.DOTALL)
    
    games = []
    for href, content in matches:
        # 游戏名在图片的alt属性里
        alt = re.search(r'alt="([^"]+)"', content)
        title = alt.group(1) if alt else "?"
        
        # 抠价格（人民币符号¥开头）
        prices = re.findall(r'¥([0-9,]+(?:\.\d{2})?)', content)
        
        # 折扣长这样：-80%
        disc = re.findall(r'(-\d+%)', content)
        discount = disc[0] if disc else ""
        
        # 描述文字在small标签里
        small = re.search(r'<small[^>]*>(.*?)</small>', content)
        desc = re.sub(r'<[^>]+>', '', small.group(1)).strip() if small else ""
        
        game = {
            "title": title,
            "original_price": f"¥{prices[0]}" if len(prices) >= 1 else "",
            "sale_price": f"¥{prices[1]}" if len(prices) >= 2 else "",
            "discount": discount,
            "description": desc[:120] if desc else "",
            "url": f"https://eshop-prices.com{href}",
        }
        games.append(game)
        if len(games) >= limit:
            break
    
    return games


@mcp.tool()
def search_switch_games(keyword: str, limit: int = 10) -> str:
    """搜Switch游戏，返回名字、价格、有没有打折
    
    Args:
        keyword: 搜啥（中文英文都行）
        limit: 返回几条，默认10
    """
    q = urllib.parse.quote(keyword)
    url = f"https://eshop-prices.com/games?q={q}&currency=CNY"
    
    try:
        html = _fetch(url)
        games = _parse_games(html, limit)
    except Exception as e:
        return f"搜不到，网络可能有问题: {e}"
    
    if not games:
        return f"没找到\"{keyword}\"相关的Switch游戏，要不换个英文名试试？"
    
    output = f"🎮 搜\"{keyword}\"的结果：\n\n"
    for g in games:
        output += f"📌 {g['title']}\n"
        if g["original_price"]:
            output += f"   原价: {g['original_price']}"
            if g["sale_price"] and g["sale_price"] != g["original_price"]:
                output += f" → 折后: {g['sale_price']} {g['discount']}"
            output += "\n"
        if g["description"]:
            output += f"   {g['description']}\n"
        output += "\n"
    
    return output


@mcp.tool()
def get_switch_discounts(page_size: int = 15) -> str:
    """看看Switch现在有啥游戏在打折"""
    try:
        html = _fetch("https://eshop-prices.com/discounts?currency=CNY")
        games = _parse_games(html, page_size)
    except Exception as e:
        return f"没拉到折扣数据: {e}"
    
    if not games:
        return "今天好像没啥打折的"
    
    output = "🔥 Switch游戏打折清单\n\n"
    for i, g in enumerate(games, 1):
        output += f"{i}. {g['title']}\n"
        if g["original_price"]:
            output += f"   原价: {g['original_price']}"
            if g["sale_price"] and g["sale_price"] != g["original_price"]:
                output += f" → {g['sale_price']} {g['discount']}"
            output += "\n\n"
    
    return output


@mcp.tool()
def get_new_switch_games(page_size: int = 10) -> str:
    """最近有啥新出的Switch游戏"""
    try:
        html = _fetch("https://eshop-prices.com/new-games?currency=CNY")
        games = _parse_games(html, page_size)
    except Exception as e:
        return f"没拉到新游戏数据: {e}"
    
    if not games:
        return "最近好像没啥新游戏"
    
    output = "🆕 最近上架的Switch游戏\n\n"
    for i, g in enumerate(games, 1):
        output += f"{i}. {g['title']}\n"
        if g["original_price"]:
            output += f"   价格: {g['original_price']}"
            if g["sale_price"] and g["sale_price"] != g["original_price"]:
                output += f" → {g['sale_price']}"
            output += "\n"
        output += "\n"
    
    return output


@mcp.tool()
def get_game_price_info(game_name: str) -> str:
    """查某个游戏的具体价格，看看划不划算
    
    Args:
        game_name: 游戏名字（英文名搜得更准）
    """
    q = urllib.parse.quote(game_name)
    url = f"https://eshop-prices.com/games?q={q}&currency=CNY"
    
    try:
        html = _fetch(url)
        games = _parse_games(html, 1)
    except Exception as e:
        return f"查不到: {e}"
    
    if not games:
        return f"没找到\"{game_name}\"的信息"
    
    g = games[0]
    output = f"📊 \"{g['title']}\" 的价格\n\n"
    
    if g["original_price"]:
        output += f"💰 现在卖:\n"
        output += f"   原价: {g['original_price']}\n"
        if g["sale_price"] and g["sale_price"] != g["original_price"]:
            output += f"   打折: {g['sale_price']} {g['discount']}\n"
    
    output += f"\n🔗 各区服价格对比: {g['url']}\n"
    output += f"\n数据来源: eshop-prices.com (就是Nintendo eShop官方数据，实时的)"
    return output


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
