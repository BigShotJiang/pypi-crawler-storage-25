# Switch Game MCP Server

Switch游戏折扣与上新查询 MCP Server，基于 MCP (Model Context Protocol) 协议。

数据来源：[eshop-prices.com](https://eshop-prices.com)（Nintendo eShop 官方各区服价格数据，实时更新）

## 功能

| 工具 | 描述 |
|------|------|
| search_switch_games | 搜Switch游戏，返回名字、价格、有没有打折 |
| get_switch_discounts | 看看现在有啥游戏在打折 |
| get_new_switch_games | 最近有啥新出的Switch游戏 |
| get_game_price_info | 查某个游戏的具体价格，划不划算 |

## 安装

```bash
pip install switch-game-mcp
```

## 启动

```bash
switch-game-mcp
```

或者用 uvx（不用装）：

```bash
uvx switch-game-mcp
```

## MCP客户端配置

```json
{
  "mcpServers": {
    "switch_game_mcp": {
      "command": "uvx",
      "args": ["switch-game-mcp@latest"],
      "env": {}
    }
  }
}
```

## 环境变量

这个服务不需要配任何环境变量，装好直接用。

## 数据说明

本服务使用 [eshop-prices.com](https://eshop-prices.com) 作为数据源，该网站汇总了 Nintendo Switch eShop 各区域（日服、美服、港服、欧服等）的官方价格数据。
价格以人民币（CNY）显示。

## 协议

MIT
