class LLMConfigError(Exception):
    pass

class LLMProviderError(Exception):
    pass
