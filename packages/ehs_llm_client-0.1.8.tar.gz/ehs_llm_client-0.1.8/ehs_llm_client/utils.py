from datetime import datetime
from dateutil.parser import isoparse


def to_timestamp(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.timestamp()
    if isinstance(value, str):
        return isoparse(value).timestamp()
    raise TypeError(f"Unsupported time type: {type(value)}")
