"""Tests for HMAC webhook signature verification."""

import hashlib
import hmac

from simplymsg import SimplyMsg, verify_webhook_signature

SECRET = "whsec_test_secret"
BODY = b'{"event":"message.delivered","data":{"sessionId":"s_1"}}'


def _sign(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def test_valid_signature():
    sig = _sign(BODY, SECRET)
    assert verify_webhook_signature(BODY, sig, SECRET) is True


def test_accepts_sha256_prefix():
    sig = "sha256=" + _sign(BODY, SECRET)
    assert verify_webhook_signature(BODY, sig, SECRET) is True


def test_rejects_tampered_body():
    sig = _sign(BODY, SECRET)
    assert verify_webhook_signature(BODY + b" ", sig, SECRET) is False


def test_rejects_invalid_signature():
    assert verify_webhook_signature(BODY, "deadbeef", SECRET) is False


def test_rejects_empty_signature():
    assert verify_webhook_signature(BODY, "", SECRET) is False


def test_rejects_empty_secret():
    sig = _sign(BODY, SECRET)
    assert verify_webhook_signature(BODY, sig, "") is False


def test_accepts_str_body():
    body_str = BODY.decode("utf-8")
    sig = _sign(BODY, SECRET)
    assert verify_webhook_signature(body_str, sig, SECRET) is True


def test_static_method_on_simplymsg_class():
    sig = _sign(BODY, SECRET)
    assert SimplyMsg.verify_webhook(BODY, sig, SECRET) is True
