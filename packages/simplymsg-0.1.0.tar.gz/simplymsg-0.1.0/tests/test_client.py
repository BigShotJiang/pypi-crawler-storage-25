"""Tests for the SimplyMsg sync client.

Uses httpx's MockTransport to avoid any network calls — every test injects
a transport that produces deterministic responses based on the request.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Dict, List, Tuple

import httpx
import pytest

from simplymsg import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    SimplyMsg,
    ValidationError,
)


def make_client(handler: Callable[[httpx.Request], httpx.Response]) -> Tuple[SimplyMsg, List[httpx.Request]]:
    """Build a SimplyMsg client whose underlying transport is replaced
    with a mock that returns whatever the handler decides."""
    seen: List[httpx.Request] = []

    def wrapped(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return handler(request)

    http = httpx.Client(transport=httpx.MockTransport(wrapped), base_url="https://api.test")
    return SimplyMsg(api_key="wsk_test", http_client=http), seen


def envelope_ok(data: Any) -> httpx.Response:
    return httpx.Response(200, json={"success": True, "data": data})


def envelope_err(status: int, error: str, headers: Dict[str, str] | None = None) -> httpx.Response:
    return httpx.Response(status, json={"success": False, "error": error}, headers=headers or {})


def test_requires_api_key():
    with pytest.raises(ValueError, match="api_key is required"):
        SimplyMsg(api_key="")


def test_authorization_header_present():
    client, seen = make_client(lambda r: envelope_ok([]))
    client.sessions.list()
    assert seen[0].headers["authorization"] == "Bearer wsk_test"


def test_envelope_unwrapping():
    client, _ = make_client(lambda r: envelope_ok([{"id": "s_1"}]))
    assert client.sessions.list() == [{"id": "s_1"}]


def test_raises_authentication_error_on_401():
    client, _ = make_client(lambda r: envelope_err(401, "Bad key"))
    with pytest.raises(AuthenticationError):
        client.sessions.list()


def test_raises_not_found_on_404():
    client, _ = make_client(lambda r: envelope_err(404, "Missing"))
    with pytest.raises(NotFoundError):
        client.sessions.get("nope")


def test_raises_validation_error_on_400():
    client, _ = make_client(lambda r: envelope_err(400, "Bad input"))
    with pytest.raises(ValidationError):
        client.messages.send(session_id="x", to="y", type="text", message="")


def test_rate_limit_error_extracts_retry_after():
    client, _ = make_client(lambda r: envelope_err(429, "slow", {"X-RateLimit-Reset": "42"}))
    with pytest.raises(RateLimitError) as exc:
        client.sessions.list()
    assert exc.value.retry_after == 42


def test_send_text_body():
    client, seen = make_client(lambda r: envelope_ok({"messageId": "msg_1"}))
    client.messages.send(session_id="sess_1", to="1234", type="text", message="Hi")
    body = json.loads(seen[0].content)
    assert body == {"sessionId": "sess_1", "to": "1234", "type": "text", "message": "Hi"}


def test_send_image_body_with_camelcase_translation():
    client, seen = make_client(lambda r: envelope_ok({"messageId": "msg_1"}))
    client.messages.send(
        session_id="sess_1",
        to="1234",
        type="image",
        media_url="https://example.com/x.jpg",
        caption="Hi",
        mime_type="image/jpeg",
    )
    body = json.loads(seen[0].content)
    assert body == {
        "sessionId": "sess_1",
        "to": "1234",
        "type": "image",
        "mediaUrl": "https://example.com/x.jpg",
        "caption": "Hi",
        "mimeType": "image/jpeg",
    }


def test_forwards_idempotency_key():
    client, seen = make_client(lambda r: envelope_ok({"messageId": "msg_1"}))
    client.messages.send(
        session_id="s", to="t", type="text", message="hi",
        idempotency_key="order-42",
    )
    assert seen[0].headers["idempotency-key"] == "order-42"


def test_list_messages_attaches_query_params():
    client, seen = make_client(
        lambda r: envelope_ok({"messages": [], "total": 0, "limit": 50, "offset": 0})
    )
    client.messages.list(session_id="s_1", status="DELIVERED", limit=10)
    url = str(seen[0].url)
    assert "sessionId=s_1" in url
    assert "status=DELIVERED" in url
    assert "limit=10" in url


def test_list_messages_drops_none():
    client, seen = make_client(
        lambda r: envelope_ok({"messages": [], "total": 0, "limit": 50, "offset": 0})
    )
    client.messages.list(session_id="s_1")
    url = str(seen[0].url)
    assert "status=" not in url
    assert "limit=" not in url


def test_context_manager_closes_transport():
    handler = lambda r: envelope_ok([])
    http = httpx.Client(transport=httpx.MockTransport(handler), base_url="https://api.test")
    with SimplyMsg(api_key="wsk_test", http_client=http) as c:
        c.sessions.list()
    # No assertion — just confirm no exception on __exit__
