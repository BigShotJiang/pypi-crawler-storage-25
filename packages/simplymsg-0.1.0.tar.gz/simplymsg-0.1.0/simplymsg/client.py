"""SimplyMsg SDK — sync + async client.

The synchronous :class:`SimplyMsg` uses ``httpx.Client``; the asynchronous
:class:`AsyncSimplyMsg` uses ``httpx.AsyncClient``. Both share the same
resource layout (``client.messages``, ``client.sessions``, etc.) for parity.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import httpx

from .errors import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    SimplyMsgError,
    ValidationError,
)
from .webhooks import verify_webhook_signature

__SDK_VERSION__ = "0.1.0"
_DEFAULT_BASE_URL = "https://simplymsg.com"
_DEFAULT_TIMEOUT = 30.0


def _drop_none(d: Dict[str, Any]) -> Dict[str, Any]:
    """Strip None / "" values from a dict before sending over the wire."""
    return {k: v for k, v in d.items() if v is not None and v != ""}


def _build_send_body(
    *,
    session_id: str,
    to: str,
    type: str,
    message: Optional[str] = None,
    media_url: Optional[str] = None,
    caption: Optional[str] = None,
    mime_type: Optional[str] = None,
    file_name: Optional[str] = None,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    name: Optional[str] = None,
    address: Optional[str] = None,
    contact_name: Optional[str] = None,
    contact_phone: Optional[str] = None,
) -> Dict[str, Any]:
    """Translate snake_case kwargs into the camelCase JSON body."""
    return _drop_none({
        "sessionId": session_id,
        "to": to,
        "type": type,
        "message": message,
        "mediaUrl": media_url,
        "caption": caption,
        "mimeType": mime_type,
        "fileName": file_name,
        "latitude": latitude,
        "longitude": longitude,
        "name": name,
        "address": address,
        "contactName": contact_name,
        "contactPhone": contact_phone,
    })


def _map_error(status: int, body: Dict[str, Any], headers: httpx.Headers) -> SimplyMsgError:
    """Translate an HTTP error response into the most specific exception."""
    message = body.get("error") if isinstance(body, dict) else None
    message = message or f"HTTP {status}"
    if status == 400:
        return ValidationError(message)
    if status == 401:
        return AuthenticationError(message)
    if status == 403:
        return PermissionError(message)
    if status == 404:
        return NotFoundError(message)
    if status == 429:
        try:
            retry_after = int(headers.get("X-RateLimit-Reset", "60"))
        except (TypeError, ValueError):
            retry_after = 60
        return RateLimitError(message, retry_after=retry_after)
    if status >= 500:
        return ServerError(message, status_code=status)
    return SimplyMsgError(message, status_code=status)


def _handle_response(response: httpx.Response) -> Any:
    """Unwrap the ``{success, data}`` envelope or raise a typed error."""
    try:
        body = response.json()
    except ValueError:
        if response.is_success:
            return None
        raise ServerError(
            f"Non-JSON response: {response.text[:200]}",
            status_code=response.status_code,
        )

    if response.is_success:
        if isinstance(body, dict) and body.get("success") is True and "data" in body:
            return body["data"]
        return body

    raise _map_error(response.status_code, body if isinstance(body, dict) else {}, response.headers)


def _common_headers(api_key: str, idempotency_key: Optional[str], user_agent: str) -> Dict[str, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "User-Agent": user_agent,
    }
    if idempotency_key:
        headers["Idempotency-Key"] = idempotency_key
    return headers


# ──────────────────────────────────────────────────────────────────
# Sync client
# ──────────────────────────────────────────────────────────────────

class _SyncTransport:
    """Internal HTTP helper used by all sync resources."""

    def __init__(self, api_key: str, base_url: str, timeout: float, user_agent: str,
                 http_client: Optional[httpx.Client] = None):
        self._api_key = api_key
        self._user_agent = user_agent
        # Allow callers to inject a pre-configured httpx.Client (e.g. for tests).
        self._client = http_client or httpx.Client(base_url=base_url, timeout=timeout)
        self._owned_client = http_client is None

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        headers = _common_headers(self._api_key, idempotency_key, self._user_agent)
        try:
            response = self._client.request(
                method,
                path,
                params=_drop_none(params or {}),
                json=json,
                headers=headers,
            )
        except httpx.TimeoutException as e:
            raise NetworkError(f"Request timed out: {e}", cause=e) from e
        except httpx.HTTPError as e:
            raise NetworkError(f"Network error: {e}", cause=e) from e
        return _handle_response(response)

    def close(self) -> None:
        if self._owned_client:
            self._client.close()


class _MessagesSync:
    def __init__(self, t: _SyncTransport):
        self._t = t

    def send(
        self,
        *,
        session_id: str,
        to: str,
        type: str,
        message: Optional[str] = None,
        media_url: Optional[str] = None,
        caption: Optional[str] = None,
        mime_type: Optional[str] = None,
        file_name: Optional[str] = None,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        name: Optional[str] = None,
        address: Optional[str] = None,
        contact_name: Optional[str] = None,
        contact_phone: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        body = _build_send_body(
            session_id=session_id, to=to, type=type, message=message,
            media_url=media_url, caption=caption, mime_type=mime_type,
            file_name=file_name, latitude=latitude, longitude=longitude,
            name=name, address=address, contact_name=contact_name,
            contact_phone=contact_phone,
        )
        return self._t.request("POST", "/api/messages/send", json=body,
                                idempotency_key=idempotency_key)

    def list(
        self,
        *,
        session_id: Optional[str] = None,
        status: Optional[str] = None,
        to: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._t.request("GET", "/api/messages", params={
            "sessionId": session_id, "status": status, "to": to,
            "limit": limit, "offset": offset,
        })

    def get(self, message_id: str) -> Dict[str, Any]:
        return self._t.request("GET", f"/api/messages/{message_id}")

    def send_bulk(
        self,
        *,
        session_id: str,
        messages: List[Dict[str, Any]],
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._t.request(
            "POST",
            "/api/messages/send/bulk",
            json={"sessionId": session_id, "messages": messages},
            idempotency_key=idempotency_key,
        )

    def batch(self, batch_id: str) -> Dict[str, Any]:
        return self._t.request("GET", f"/api/messages/batch/{batch_id}")


class _SessionsSync:
    def __init__(self, t: _SyncTransport):
        self._t = t

    def list(self) -> List[Dict[str, Any]]:
        return self._t.request("GET", "/api/sessions")

    def create(self, *, name: str) -> Dict[str, Any]:
        return self._t.request("POST", "/api/sessions", json={"name": name})

    def get(self, session_id: str) -> Dict[str, Any]:
        return self._t.request("GET", f"/api/sessions/{session_id}")

    def reconnect(self, session_id: str) -> Dict[str, Any]:
        return self._t.request("POST", f"/api/sessions/{session_id}")

    def qr(self, session_id: str) -> Dict[str, Any]:
        return self._t.request("GET", f"/api/sessions/{session_id}/qr")

    def delete(self, session_id: str) -> Dict[str, Any]:
        return self._t.request("DELETE", f"/api/sessions/{session_id}")


class _WebhooksSync:
    def __init__(self, t: _SyncTransport):
        self._t = t

    def list(self) -> List[Dict[str, Any]]:
        return self._t.request("GET", "/api/webhooks")

    def create(self, *, url: str, events: List[str]) -> Dict[str, Any]:
        return self._t.request("POST", "/api/webhooks", json={"url": url, "events": events})

    def get(self, webhook_id: str) -> Dict[str, Any]:
        return self._t.request("GET", f"/api/webhooks/{webhook_id}")

    def update(self, webhook_id: str, **changes: Any) -> Dict[str, Any]:
        body = _drop_none({
            "url": changes.get("url"),
            "events": changes.get("events"),
            "isActive": changes.get("is_active"),
        })
        return self._t.request("PATCH", f"/api/webhooks/{webhook_id}", json=body)

    def delete(self, webhook_id: str) -> Dict[str, Any]:
        return self._t.request("DELETE", f"/api/webhooks/{webhook_id}")

    @staticmethod
    def verify(raw_body: Union[bytes, str], signature: str, secret: str) -> bool:
        return verify_webhook_signature(raw_body, signature, secret)


class _ApiKeysSync:
    def __init__(self, t: _SyncTransport):
        self._t = t

    def list(self) -> List[Dict[str, Any]]:
        return self._t.request("GET", "/api/keys")

    def create(self, *, name: str, expires_in_days: Optional[int] = None) -> Dict[str, Any]:
        body = _drop_none({"name": name, "expiresInDays": expires_in_days})
        return self._t.request("POST", "/api/keys", json=body)

    def revoke(self, key_id: str) -> Dict[str, Any]:
        return self._t.request("DELETE", f"/api/keys/{key_id}")


class SimplyMsg:
    """Synchronous SimplyMsg client.

    Args:
        api_key: Your SimplyMsg API key (required).
        base_url: Override the API base URL. Default: ``https://simplymsg.com``.
        timeout: Per-request timeout in seconds. Default: 30.
        user_agent: Override the User-Agent header.
        http_client: Inject a custom ``httpx.Client`` (e.g., for testing
            against a mock transport). The client will not be closed by
            :meth:`close` if injected.

    Usage::

        client = SimplyMsg(api_key="wsk_...")
        result = client.messages.send(
            session_id="sess_abc",
            to="14155551234",
            type="text",
            message="Hello",
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ):
        if not api_key:
            raise ValueError("SimplyMsg: api_key is required")
        self._transport = _SyncTransport(
            api_key=api_key,
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            user_agent=user_agent or f"simplymsg-python/{__SDK_VERSION__}",
            http_client=http_client,
        )
        self.messages = _MessagesSync(self._transport)
        self.sessions = _SessionsSync(self._transport)
        self.webhooks = _WebhooksSync(self._transport)
        self.api_keys = _ApiKeysSync(self._transport)

    @staticmethod
    def verify_webhook(raw_body: Union[bytes, str], signature: str, secret: str) -> bool:
        """Static helper — verify a webhook signature without instantiating a client."""
        return verify_webhook_signature(raw_body, signature, secret)

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "SimplyMsg":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ──────────────────────────────────────────────────────────────────
# Async client
# ──────────────────────────────────────────────────────────────────

class _AsyncTransport:
    """Internal async HTTP helper used by all async resources."""

    def __init__(self, api_key: str, base_url: str, timeout: float, user_agent: str,
                 http_client: Optional[httpx.AsyncClient] = None):
        self._api_key = api_key
        self._user_agent = user_agent
        self._client = http_client or httpx.AsyncClient(base_url=base_url, timeout=timeout)
        self._owned_client = http_client is None

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        headers = _common_headers(self._api_key, idempotency_key, self._user_agent)
        try:
            response = await self._client.request(
                method,
                path,
                params=_drop_none(params or {}),
                json=json,
                headers=headers,
            )
        except httpx.TimeoutException as e:
            raise NetworkError(f"Request timed out: {e}", cause=e) from e
        except httpx.HTTPError as e:
            raise NetworkError(f"Network error: {e}", cause=e) from e
        return _handle_response(response)

    async def close(self) -> None:
        if self._owned_client:
            await self._client.aclose()


class _MessagesAsync:
    def __init__(self, t: _AsyncTransport):
        self._t = t

    async def send(self, *, session_id: str, to: str, type: str, idempotency_key: Optional[str] = None,
                    **kwargs: Any) -> Dict[str, Any]:
        body = _build_send_body(session_id=session_id, to=to, type=type, **kwargs)
        return await self._t.request("POST", "/api/messages/send", json=body,
                                      idempotency_key=idempotency_key)

    async def list(self, **params: Any) -> Dict[str, Any]:
        return await self._t.request("GET", "/api/messages", params={
            "sessionId": params.get("session_id"),
            "status": params.get("status"),
            "to": params.get("to"),
            "limit": params.get("limit"),
            "offset": params.get("offset"),
        })

    async def get(self, message_id: str) -> Dict[str, Any]:
        return await self._t.request("GET", f"/api/messages/{message_id}")

    async def send_bulk(self, *, session_id: str, messages: List[Dict[str, Any]],
                         idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        return await self._t.request(
            "POST", "/api/messages/send/bulk",
            json={"sessionId": session_id, "messages": messages},
            idempotency_key=idempotency_key,
        )

    async def batch(self, batch_id: str) -> Dict[str, Any]:
        return await self._t.request("GET", f"/api/messages/batch/{batch_id}")


class _SessionsAsync:
    def __init__(self, t: _AsyncTransport):
        self._t = t

    async def list(self) -> List[Dict[str, Any]]:
        return await self._t.request("GET", "/api/sessions")

    async def create(self, *, name: str) -> Dict[str, Any]:
        return await self._t.request("POST", "/api/sessions", json={"name": name})

    async def get(self, session_id: str) -> Dict[str, Any]:
        return await self._t.request("GET", f"/api/sessions/{session_id}")

    async def reconnect(self, session_id: str) -> Dict[str, Any]:
        return await self._t.request("POST", f"/api/sessions/{session_id}")

    async def qr(self, session_id: str) -> Dict[str, Any]:
        return await self._t.request("GET", f"/api/sessions/{session_id}/qr")

    async def delete(self, session_id: str) -> Dict[str, Any]:
        return await self._t.request("DELETE", f"/api/sessions/{session_id}")


class _WebhooksAsync:
    def __init__(self, t: _AsyncTransport):
        self._t = t

    async def list(self) -> List[Dict[str, Any]]:
        return await self._t.request("GET", "/api/webhooks")

    async def create(self, *, url: str, events: List[str]) -> Dict[str, Any]:
        return await self._t.request("POST", "/api/webhooks", json={"url": url, "events": events})

    async def get(self, webhook_id: str) -> Dict[str, Any]:
        return await self._t.request("GET", f"/api/webhooks/{webhook_id}")

    async def update(self, webhook_id: str, **changes: Any) -> Dict[str, Any]:
        body = _drop_none({
            "url": changes.get("url"),
            "events": changes.get("events"),
            "isActive": changes.get("is_active"),
        })
        return await self._t.request("PATCH", f"/api/webhooks/{webhook_id}", json=body)

    async def delete(self, webhook_id: str) -> Dict[str, Any]:
        return await self._t.request("DELETE", f"/api/webhooks/{webhook_id}")

    @staticmethod
    def verify(raw_body: Union[bytes, str], signature: str, secret: str) -> bool:
        return verify_webhook_signature(raw_body, signature, secret)


class _ApiKeysAsync:
    def __init__(self, t: _AsyncTransport):
        self._t = t

    async def list(self) -> List[Dict[str, Any]]:
        return await self._t.request("GET", "/api/keys")

    async def create(self, *, name: str, expires_in_days: Optional[int] = None) -> Dict[str, Any]:
        body = _drop_none({"name": name, "expiresInDays": expires_in_days})
        return await self._t.request("POST", "/api/keys", json=body)

    async def revoke(self, key_id: str) -> Dict[str, Any]:
        return await self._t.request("DELETE", f"/api/keys/{key_id}")


class AsyncSimplyMsg:
    """Asynchronous SimplyMsg client. Mirrors :class:`SimplyMsg`."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ):
        if not api_key:
            raise ValueError("SimplyMsg: api_key is required")
        self._transport = _AsyncTransport(
            api_key=api_key,
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            user_agent=user_agent or f"simplymsg-python/{__SDK_VERSION__}",
            http_client=http_client,
        )
        self.messages = _MessagesAsync(self._transport)
        self.sessions = _SessionsAsync(self._transport)
        self.webhooks = _WebhooksAsync(self._transport)
        self.api_keys = _ApiKeysAsync(self._transport)

    @staticmethod
    def verify_webhook(raw_body: Union[bytes, str], signature: str, secret: str) -> bool:
        return verify_webhook_signature(raw_body, signature, secret)

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> "AsyncSimplyMsg":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
