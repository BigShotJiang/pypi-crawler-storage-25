"""Official Python SDK for SimplyMsg — the WhatsApp messaging API.

Quickstart::

    from simplymsg import SimplyMsg

    client = SimplyMsg(api_key="wsk_...")
    result = client.messages.send(
        session_id="sess_abc",
        to="14155551234",
        type="text",
        message="Your code is 4821",
    )
    print(result["messageId"])
"""

from .client import SimplyMsg, AsyncSimplyMsg
from .errors import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    SimplyMsgError,
    ValidationError,
)
from .webhooks import verify_webhook_signature

__version__ = "0.1.0"

__all__ = [
    "SimplyMsg",
    "AsyncSimplyMsg",
    "verify_webhook_signature",
    "SimplyMsgError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
]
