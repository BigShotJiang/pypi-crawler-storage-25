"""HMAC-SHA256 verification for incoming SimplyMsg webhook payloads."""

from __future__ import annotations

import hashlib
import hmac
from typing import Union


def verify_webhook_signature(
    raw_body: Union[bytes, str],
    signature: str,
    secret: str,
) -> bool:
    """Constant-time verification of a SimplyMsg webhook payload.

    The server signs the raw request body with HMAC-SHA256 using your
    webhook secret and sends the hex digest in the ``X-Webhook-Signature``
    header, prefixed with ``sha256=``.

    Args:
        raw_body: The raw request body as ``bytes`` or ``str``. Use the
            unparsed body — extra whitespace from ``json.dumps`` will
            break verification.
        signature: Value of the ``X-Webhook-Signature`` header (with or
            without the ``sha256=`` prefix).
        secret: The secret returned when you created the webhook.

    Returns:
        True if the signature is valid, False otherwise.
    """
    if not signature or not secret:
        return False

    # Strip optional "sha256=" prefix.
    incoming = signature[7:] if signature.startswith("sha256=") else signature

    body_bytes = raw_body.encode("utf-8") if isinstance(raw_body, str) else raw_body
    expected = hmac.new(
        secret.encode("utf-8"),
        body_bytes,
        hashlib.sha256,
    ).hexdigest()

    # Length mismatch shortcut — compare_digest tolerates it but we save the work.
    if len(incoming) != len(expected):
        return False

    return hmac.compare_digest(incoming, expected)
