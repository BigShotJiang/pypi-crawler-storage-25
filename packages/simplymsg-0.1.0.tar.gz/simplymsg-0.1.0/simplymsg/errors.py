"""Typed exception hierarchy for SimplyMsg API responses.

Callers can catch specific subclasses to differentiate auth from rate-limit
from network failures::

    try:
        client.messages.send(...)
    except RateLimitError as e:
        time.sleep(e.retry_after)
    except AuthenticationError:
        ...
"""

from __future__ import annotations

from typing import Optional


class SimplyMsgError(Exception):
    """Base class for all SimplyMsg SDK errors."""

    def __init__(self, message: str, status_code: int = 0, code: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class AuthenticationError(SimplyMsgError):
    """401 — API key is missing, invalid, or revoked."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401, code="authentication_error")


class PermissionError(SimplyMsgError):
    """403 — API key lacks permission for this operation."""

    def __init__(self, message: str = "Insufficient permissions for this operation"):
        super().__init__(message, status_code=403, code="permission_error")


class NotFoundError(SimplyMsgError):
    """404 — Resource (session, message, webhook, etc.) does not exist."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, status_code=404, code="not_found")


class ValidationError(SimplyMsgError):
    """400 — Request body or query params failed validation."""

    def __init__(self, message: str):
        super().__init__(message, status_code=400, code="validation_error")


class RateLimitError(SimplyMsgError):
    """429 — You exceeded the rate limit. Wait `retry_after` seconds before retrying."""

    def __init__(self, message: str, retry_after: int):
        super().__init__(message, status_code=429, code="rate_limit_error")
        self.retry_after = retry_after


class ServerError(SimplyMsgError):
    """5xx — Server failed to process the request. Safe to retry with backoff."""

    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message, status_code=status_code, code="server_error")


class NetworkError(SimplyMsgError):
    """0 — Failed to reach the server (DNS, timeout, connection refused)."""

    def __init__(self, message: str, cause: Optional[BaseException] = None):
        super().__init__(message, status_code=0, code="network_error")
        self.cause = cause
