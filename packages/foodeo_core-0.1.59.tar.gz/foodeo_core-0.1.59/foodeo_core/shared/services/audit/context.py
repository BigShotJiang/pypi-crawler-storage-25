from datetime import datetime, timezone
from typing import Any, Mapping, Optional

from pydantic import BaseModel, Field

from foodeo_core.shared.enums import FromClient


class AuditContext(BaseModel):
    actor_id: Optional[int] = None
    tmp_actor_id: Optional[int] = None
    correlation_id: Optional[str] = None
    from_client: FromClient = FromClient.web
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Mapping[str, Any] = Field(default_factory=dict)
