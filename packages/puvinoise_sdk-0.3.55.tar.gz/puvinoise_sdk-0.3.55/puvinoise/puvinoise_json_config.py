"""
Centralized resolution and logging for PUVINoise JSON identity files.

All agent/environment JSON is read ONLY from::

    <project_root>/.puvinoise/

Flat file structure (v2)::

    <project_root>/.puvinoise/env_<env_name>.json  — one file per environment
    <project_root>/.puvinoise/agent_<id>.json      — per-agent identity

where *project_root* is the supplied working directory, defaulting to
``os.getcwd()`` — **no parent-directory walk**, no environment-variable
overrides for JSON paths, no reads from the repository root outside
``.puvinoise/``.

``.env.puvinoise`` (dotenv) is handled elsewhere; this module is **JSON only**.

Environment name resolution (priority order)
--------------------------------------------
1. ``cli_env_name`` — explicit ``--env`` flag passed to the CLI
2. ``PUVINOISE_ENV_NAME`` environment variable
3. ``agent_*.json`` → ``env_name`` field (first agent file, sorted)
4. Auto-detect: if exactly one ``env_*.json`` exists, use it
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("puvinoise.json_config")

LOG_PREFIX = "[puvinoise]"

# Directory name under project root (single source for all JSON state).
PUVINOISE_SUBDIR = ".puvinoise"

# Flat-file env pattern: .puvinoise/env_<slug>.json
ENV_FILE_PREFIX = "env_"
ENV_FILE_GLOB = "env_*.json"

# Agent glob is unchanged.
AGENT_JSON_GLOB = "agent_*.json"

# ── Deprecated constants kept for backward compat ────────────────────────────
# These names were exported by the old implementation.  Code that imports them
# will still compile; the values are only used internally for legacy detection.
ENVIRONMENTS_SUBDIR = "environments"        # old nested folder — no longer written
ENV_JSON_FILENAME = "env.json"              # old single-env file — no longer written

_probe_logged = False
_env_missing_logged = False
_agent_missing_logged = False


# ─── Project root helpers ─────────────────────────────────────────────────────

def resolve_project_root(cwd: Optional[Path] = None) -> Path:
    """Absolute project root (directory that contains ``.puvinoise/``)."""
    base = Path.cwd() if cwd is None else Path(cwd)
    return base.resolve()


def resolve_puvinoise_dir(cwd: Optional[Path] = None) -> Path:
    """``<project_root>/.puvinoise`` — may or may not exist."""
    return resolve_project_root(cwd) / PUVINOISE_SUBDIR


def log_loading_config_from_puvinoise(cwd: Optional[Path] = None) -> None:
    """
    One-time informational log when the SDK first probes JSON config location.

    Does not create the directory. Safe when absent (degraded mode).
    """
    global _probe_logged
    if _probe_logged:
        return
    _probe_logged = True
    d = resolve_puvinoise_dir(cwd)
    print(f"{LOG_PREFIX} Loading config from {d}/")
    if d.is_dir():
        print(f"{LOG_PREFIX} Found .puvinoise directory")
    else:
        print(f"{LOG_PREFIX} .puvinoise/ not found (continuing without local JSON config)")


# ─── Agent file helpers (unchanged) ──────────────────────────────────────────

def list_agent_json_paths(cwd: Optional[Path] = None) -> List[Path]:
    """Sorted ``agent_*.json`` paths under ``.puvinoise/``; empty if missing."""
    state_dir = resolve_puvinoise_dir(cwd)
    if not state_dir.is_dir():
        return []
    return sorted(state_dir.glob(AGENT_JSON_GLOB))


# ─── Flat-file env helpers ────────────────────────────────────────────────────

def _sanitize_env_name_segment(env_name: str) -> str:
    """Normalize *env_name* to a safe file-name segment (no path separators)."""
    s = (env_name or "").strip()
    s = re.sub(r"[/\\]", "_", s)
    return s


def env_named_json_path(env_name: str, cwd: Optional[Path] = None) -> Path:
    """
    Canonical path for ``.puvinoise/env_<env_name>.json``.

    The segment is sanitized (``/`` and ``\\`` replaced with ``_``) but otherwise
    preserved as-is; callers are responsible for passing a non-empty slug.
    """
    safe = _sanitize_env_name_segment(env_name)
    if not safe:
        raise ValueError(f"env_name must be non-empty (got {env_name!r})")
    return resolve_puvinoise_dir(cwd) / f"{ENV_FILE_PREFIX}{safe}.json"


def list_env_json_paths(cwd: Optional[Path] = None) -> List[Path]:
    """
    Sorted ``env_*.json`` paths under ``.puvinoise/``.

    Only returns files whose name starts with ``env_`` (not the legacy ``env.json``).
    """
    state_dir = resolve_puvinoise_dir(cwd)
    if not state_dir.is_dir():
        return []
    return sorted(state_dir.glob(ENV_FILE_GLOB))


def resolve_active_env_name(
    cli_env_name: Optional[str] = None,
    cwd: Optional[Path] = None,
) -> Tuple[str, str]:
    """
    Resolve the active environment name from priority sources.

    Priority:
      1. *cli_env_name*         — explicit ``--env`` CLI flag
      2. ``PUVINOISE_ENV_NAME`` — environment variable
      3. ``agent_*.json``       — ``env_name`` field of the first agent state file
      4. Auto-detect            — if exactly one ``env_*.json`` exists, infer slug
         from its filename (``env_<slug>.json``).

    Returns ``(env_name, source_label)`` where *source_label* describes which
    source provided the name.  Returns ``("", "not_found")`` when nothing resolves.
    """
    # 1. Explicit CLI flag.
    if cli_env_name and cli_env_name.strip():
        return cli_env_name.strip(), "cli:--env"

    # 2. Environment variable.
    env_var_val = (os.environ.get("PUVINOISE_ENV_NAME") or "").strip()
    if env_var_val:
        return env_var_val, "env_var:PUVINOISE_ENV_NAME"

    # 3. Derive from agent state file.
    for p in list_agent_json_paths(cwd):
        data = read_json_dict(p)
        if data:
            name = str(data.get("env_name") or "").strip()
            if name:
                return name, f"agent_state:{p.name}"

    # 4. Auto-detect: exactly one env_*.json present.
    env_files = list_env_json_paths(cwd)
    if len(env_files) == 1:
        stem = env_files[0].stem                   # e.g. "env_production"
        slug = stem[len(ENV_FILE_PREFIX):]          # → "production"
        if slug:
            return slug, f"auto:{env_files[0].name}"

    return "", "not_found"


def load_named_env_json(
    env_name: str,
    cwd: Optional[Path] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load ``.puvinoise/env_<env_name>.json``.

    Returns ``(data, path)`` on success, ``({}, None)`` when absent or unreadable.
    Never raises.
    """
    if not (env_name or "").strip():
        return {}, None
    try:
        path = env_named_json_path(env_name, cwd)
    except ValueError:
        return {}, None
    if not path.is_file():
        return {}, None
    data = read_json_dict(path)
    if data:
        return data, path
    return {}, None


# ─── Legacy path helpers (kept for callers that still import them) ────────────

def env_json_path(cwd: Optional[Path] = None) -> Path:
    """
    **Deprecated** — returns the old ``.puvinoise/env.json`` path.

    This file is no longer written.  Use :func:`env_named_json_path` or
    :func:`load_env_json_if_present` for the flat ``env_<name>.json`` structure.
    Kept so that callers in ``bind_sidecar.py`` and ``bootstrap.py`` that check
    ``env_json_path(...).is_file()`` for legacy detection still compile without
    modification.
    """
    return resolve_puvinoise_dir(cwd) / ENV_JSON_FILENAME


def environment_json_path(env_name: str, cwd: Optional[Path] = None) -> Path:
    """
    **Deprecated** — previously returned ``.puvinoise/environments/<env_name>.json``.

    The ``environments/`` sub-folder is no longer used.  This function now maps
    directly to the flat :func:`env_named_json_path` so that any remaining
    callers continue to find their data.
    """
    return env_named_json_path(env_name, cwd)


# ─── Primary env loader ───────────────────────────────────────────────────────

def load_env_json_if_present(
    cwd: Optional[Path] = None,
    cli_env_name: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load the active ``env_<env_name>.json`` from ``.puvinoise/``.

    Resolution order for *env_name* (when not supplied via *cli_env_name*):
      1. ``PUVINOISE_ENV_NAME`` environment variable
      2. ``agent_*.json`` → ``env_name`` field
      3. Auto-detect if exactly one ``env_*.json`` exists

    If a legacy ``env.json`` is detected, a migration notice is printed and
    ``({}, None)`` is returned — no fallback reads are performed.

    Returns ``({}, None)`` when no matching file is found.
    """
    log_loading_config_from_puvinoise(cwd)

    resolved_name, source = resolve_active_env_name(cli_env_name, cwd)

    if not resolved_name:
        # Check for the legacy env.json and emit a clear migration message.
        legacy = resolve_puvinoise_dir(cwd) / ENV_JSON_FILENAME
        if legacy.is_file():
            print(
                f"{LOG_PREFIX} WARNING: legacy .puvinoise/env.json found — no longer supported.\n"
                f"{LOG_PREFIX}   Re-bind this folder:\n"
                f"{LOG_PREFIX}     puvinoise bindcar --token <prt_...> --env <name>"
            )
        else:
            global _env_missing_logged
            if not _env_missing_logged:
                _env_missing_logged = True
                print(f"{LOG_PREFIX} Env config not found (continuing)")
        return {}, None

    data, path = load_named_env_json(resolved_name, cwd)
    if data:
        print(
            f"{LOG_PREFIX} Env config: {path.name}"
            f"  (env={resolved_name}, source={source})"
        )
        logger.info("json_config: loaded %s (source=%s)", path, source)
        return data, path

    # Name resolved but the file is missing.
    env_file = f"{ENV_FILE_PREFIX}{_sanitize_env_name_segment(resolved_name)}.json"
    print(
        f"{LOG_PREFIX} Env config not found: .puvinoise/{env_file} missing\n"
        f"{LOG_PREFIX}   Re-bind: puvinoise bindcar --token <prt_...> --env {resolved_name}"
    )
    return {}, None


def read_json_dict(path: Path) -> Dict[str, Any]:
    """Parse JSON object from *path*; empty dict on missing/malformed (no throw)."""
    try:
        if not path.is_file():
            return {}
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception as exc:  # noqa: BLE001
        logger.debug("json_config: failed to read %s: %s", path, exc)
    return {}


def load_agent_json_first(
    cwd: Optional[Path] = None,
    *,
    exact_agent_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load the first matching ``agent_*.json`` under ``.puvinoise/``.

    If *exact_agent_id* is set, tries ``agent_<id>.json`` first.
    If several ``agent_*.json`` exist, logs a warning and uses the first in sorted order.
    """
    log_loading_config_from_puvinoise(cwd)
    state_dir = resolve_puvinoise_dir(cwd)
    global _agent_missing_logged
    if not state_dir.is_dir():
        if not _agent_missing_logged:
            _agent_missing_logged = True
            print(f"{LOG_PREFIX} Agent config: .puvinoise/ missing (continuing)")
        return {}, None

    if exact_agent_id:
        safe_id = (exact_agent_id or "").strip().replace("/", "_").replace("\\", "_")
        exact = state_dir / f"agent_{safe_id}.json"
        if exact.is_file():
            data = read_json_dict(exact)
            if data:
                print(f"{LOG_PREFIX} Agent config loaded from {exact.name}")
                logger.info("json_config: loaded agent state from %s", exact)
                return data, exact

    files = sorted(state_dir.glob(AGENT_JSON_GLOB))
    if not files:
        if not _agent_missing_logged:
            _agent_missing_logged = True
            print(f"{LOG_PREFIX} Agent config not found (no agent_*.json in .puvinoise/)")
        return {}, None
    if len(files) > 1:
        names = ", ".join(f.name for f in files)
        msg = (
            f"{LOG_PREFIX} WARNING: multiple agent JSON files in {state_dir}: {names} — "
            f"using {files[0].name}"
        )
        print(msg)
        logger.warning("json_config: multiple agent_*.json; picking first: %s", files[0])

    path = files[0]
    data = read_json_dict(path)
    if data:
        print(f"{LOG_PREFIX} Agent config loaded from {path.name}")
        logger.info("json_config: loaded agent state from %s", path)
        return data, path
    print(f"{LOG_PREFIX} Agent config file unreadable (continuing)")
    return {}, None


__all__ = [
    "LOG_PREFIX",
    "PUVINOISE_SUBDIR",
    "ENV_FILE_PREFIX",
    "ENV_FILE_GLOB",
    "AGENT_JSON_GLOB",
    # Deprecated (kept for backward compat imports)
    "ENVIRONMENTS_SUBDIR",
    "ENV_JSON_FILENAME",
    # Project helpers
    "resolve_project_root",
    "resolve_puvinoise_dir",
    "log_loading_config_from_puvinoise",
    # Agent helpers
    "list_agent_json_paths",
    "load_agent_json_first",
    # Flat env helpers (new)
    "env_named_json_path",
    "list_env_json_paths",
    "resolve_active_env_name",
    "load_named_env_json",
    # Legacy path stubs
    "env_json_path",
    "environment_json_path",
    # Primary loaders
    "read_json_dict",
    "load_env_json_if_present",
]
