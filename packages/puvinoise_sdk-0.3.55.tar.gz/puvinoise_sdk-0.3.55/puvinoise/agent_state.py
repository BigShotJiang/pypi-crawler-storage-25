"""
agent_state.py — Two-layer identity state management for PUVINoise.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FINAL DATA CONTRACT  (v1.0)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

.puvinoise/env.json  — environment-level, written by puvinoise-bind --env-only
──────────────────────────────────────────────────────────────────
REQUIRED  version      str  "1.0"
REQUIRED  env_id       str  "env_xxxxxxxxxxxxxxxx"
REQUIRED  base_url     str  "https://app.puvilabs.com"
REQUIRED  created_at   str  ISO-8601 UTC ("2026-04-22T10:00:00Z")
REQUIRED  env_name     str  human-readable slug (CLI or backend — never null)
REQUIRED  environment str  mirrors env_name (same string)
OPTIONAL  tenant_id    str  non-secret scope id written by bindcar (available before agent register)
MUST NOT  api_key       — credentials belong ONLY in agent_<id>.json
MUST NOT  agent_id      — runtime identity belongs ONLY in agent_<id>.json
MUST NOT  runtime_*     — no runtime state here

.puvinoise/agent_<id>.json  — agent-level, written on first SDK run / auto-register
──────────────────────────────────────────────────────────────────
REQUIRED  version        str  "1.0"
REQUIRED  agent_id       str  "agt_xxxxxxxxxxxxxxxx"
REQUIRED  env_id         str  — must match env.json:env_id
REQUIRED  env_name       str  — slug from bind (CLI `--env` or backend); required for telemetry
REQUIRED  base_url       str  — must match env.json:base_url
REQUIRED  api_key        str  — MANDATORY; SDK will not init without this
REQUIRED  tenant_id      str  — scopes telemetry to the correct tenant
REQUIRED  agent_name     str  — canonical name used for registration
REQUIRED  status         str  "active"
REQUIRED  registered_at  str  ISO-8601 UTC
REQUIRED  sdk_version    str  e.g. "0.3.4"
OPTIONAL  last_used_at   str  ISO-8601 UTC  (updated each run)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IDENTITY RESOLUTION  (JSON under .puvinoise/ only; degraded mode if absent)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    load_identity(workdir):
        1. agent state  → .puvinoise/agent_<id>.json   (authoritative — wins if present)
        2. env state    → .puvinoise/env.json           (bootstrap-only fallback)
        3. empty dict   → degraded mode (no throw; callers use validation / init paths)

    Resolution is FILES-ONLY for JSON paths.  No env-var *path* overrides.
    If PUVINOISE_* env vars are present → warn and ignore.

VALIDATION  (enforced by validate_agent_state / validate_env_state)
──────────────────────────────────────────────────────────────────
• env.json            required fields present; api_key / agent_id absent.
• agent_<id>.json     required fields present; api_key non-empty.
• Cross-file check    agent_<id>.env_id  == env.json:env_id
                      agent_<id>.base_url == env.json:base_url

Legacy files (.puvinoise_env.json, .puvinoise_bind_state.json) are NOT read.
No silent failures — every write is validated with _verify_exists().

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PUBLIC API
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STATE_FORMAT_VERSION
ENV_STATE_REQUIRED_FIELDS
AGENT_STATE_REQUIRED_FIELDS
AGENT_STATE_FORBIDDEN_IN_ENV

get_agent_state_dir(base)                       → Path
get_env_state_path(base)                        → Path
get_agent_state_path(base, agent_id)            → Path

save_env_state(env_id, base_url, workdir, *,
               env_name, tenant_id, created_at, ...) → Path
               (raises ``RuntimeError`` if ``env_id`` or ``env_name`` is missing)
load_env_state(workdir)                         → (dict, Path | None)
validate_env_state(workdir)                     → None   (raises ValueError on contract violation)

save_agent_state(agent_id, env_id, base_url, workdir, *,
                 api_key, tenant_id, agent_name, status,
                 registered_at, sdk_version,
                 last_used_at, env_name=None)    → Path   (raises RuntimeError on failure)
patch_agent_state_env_name(workdir, env_name, *, agent_id=None, env_id=None) → List[Path]
patch_agent_state_environment_binding(workdir, *, env_name, env_id=None, agent_id=None) → List[Path]
load_agent_state(workdir, agent_id=None)        → (dict, Path | None)
validate_agent_state(workdir)                   → None   (raises ValueError on contract violation)

load_identity(workdir)                          → dict   (may be {} if no JSON; degraded mode)
find_all_agent_states(base)                     → [Path]
invalidate_agent_state(workdir)                 → bool   (deletes agent_<id>.json, True on success)
"""

from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from puvinoise.puvinoise_json_config import (
    AGENT_JSON_GLOB,
    ENV_FILE_GLOB,
    ENV_FILE_PREFIX,
    ENV_JSON_FILENAME,
    PUVINOISE_SUBDIR,
    env_json_path,
    env_named_json_path,
    list_agent_json_paths,
    list_env_json_paths,
    load_agent_json_first,
    load_env_json_if_present,
    resolve_active_env_name,
    resolve_puvinoise_dir,
)

logger = logging.getLogger("puvinoise.agent_state")

# ─── Constants (re-export names expected by importers) ─────────────────────────

STATE_FORMAT_VERSION = "1.0"

AGENT_STATE_SUBDIR = PUVINOISE_SUBDIR
# ENV_STATE_FILENAME is kept for backward-compat imports; the actual file is
# now env_<env_name>.json — use get_env_state_path(base) or env_named_json_path().
ENV_STATE_FILENAME = ENV_JSON_FILENAME
AGENT_STATE_GLOB = AGENT_JSON_GLOB

# ─── Contract schemas ─────────────────────────────────────────────────────────

# Fields that MUST be present in a valid env_<name>.json.
ENV_STATE_REQUIRED_FIELDS: tuple = ("env_id", "env_name", "base_url", "created_at")

# Fields that MUST NOT appear in env_<name>.json.
# api_key, agent_id → credentials / runtime identity belong ONLY in agent_<id>.json
# tenant_id is intentionally NOT forbidden here: it is a non-secret scope identifier
# written by bindcar so load_binding() can return it before agent registration completes.
AGENT_STATE_FORBIDDEN_IN_ENV: tuple = ("api_key", "agent_id")

# Fields that MUST be present in a valid agent_<id>.json.
AGENT_STATE_REQUIRED_FIELDS: tuple = (
    "version",
    "agent_id",
    "env_id",
    "env_name",
    "base_url",
    "api_key",
    "tenant_id",
    "agent_name",
    "status",
    "registered_at",
    "sdk_version",
)


# ─── Path helpers ─────────────────────────────────────────────────────────────


def get_agent_state_dir(base: Path) -> Path:
    """Return the .puvinoise/ directory under *base* (CWD/project root)."""
    return resolve_puvinoise_dir(base)


def get_env_state_path(base: Path) -> Path:
    """
    Return the active environment state file path.

    In the flat-file structure this is the first ``env_*.json`` found under
    ``.puvinoise/``.  Falls back to the legacy ``env.json`` path (which will not
    exist) if no ``env_*.json`` is found — this keeps ``is_file()`` checks in
    callers like ``bootstrap.py`` working correctly (they get ``False`` rather
    than a crash when no env file exists yet).
    """
    files = list_env_json_paths(base)
    if files:
        return files[0]
    # Legacy path returned when nothing exists yet (will not exist on disk).
    return env_json_path(base)


def get_agent_state_path(base: Path, agent_id: str) -> Path:
    """Return the canonical per-agent state file path for *agent_id*."""
    safe_id = (agent_id or "unknown").strip().replace("/", "_").replace("\\", "_")
    return get_agent_state_dir(base) / f"agent_{safe_id}.json"


REGISTRATION_PENDING_FILENAME = "registration_pending.json"


def get_registration_pending_path(base: Path) -> Path:
    """Local hint file: last agent_name used when registration failed (for operators / tooling)."""
    return get_agent_state_dir(base) / REGISTRATION_PENDING_FILENAME


def save_registration_pending(workdir: Path, agent_name: str) -> None:
    try:
        name = (agent_name or "").strip()
        if not name:
            return
        path = get_registration_pending_path(workdir)
        _make_state_dir(path.parent)
        payload = {
            "agent_name": name,
            "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        logger.debug("save_registration_pending failed: %s", exc)


def clear_registration_pending(workdir: Path) -> None:
    try:
        path = get_registration_pending_path(workdir)
        if path.is_file():
            path.unlink()
    except Exception as exc:  # noqa: BLE001
        logger.debug("clear_registration_pending failed: %s", exc)


# ─── Write ────────────────────────────────────────────────────────────────────


def save_env_state(
    env_id: str,
    base_url: str,
    workdir: Path,
    *,
    environment: Optional[str] = None,
    env_name: Optional[str] = None,
    tenant_id: Optional[str] = None,
    deploy_version: Optional[str] = None,
    region: Optional[str] = None,
    created_at: Optional[str] = None,
) -> Path:
    """
    Write ``.puvinoise/env_<env_name>.json`` with environment identity.

    Written by ``puvinoise bindcar`` after token validation, and by
    ``puvinoise-bind --env-only`` for bootstrap-only workflows.

    Mandatory: ``env_id``, ``env_name`` (non-empty).  The file is named after
    the slug so multiple environments can coexist as flat files in ``.puvinoise/``.
    Existing keys in a prior file of the same name are merged; binding fields
    overwrite. ``api_key`` / ``agent_id`` are stripped if present in the prior file.

    Raises ``RuntimeError`` on any failure — callers MUST NOT swallow this.
    Post-write validation confirms the file exists before returning.
    """
    eid = (env_id or "").strip()
    if not eid:
        raise RuntimeError("[puvinoise-bind] env_id is required but missing")

    raw_name = (env_name or "").strip()
    raw_env = (environment or "").strip()
    if raw_name and raw_env and raw_name != raw_env:
        raise RuntimeError(
            "[puvinoise-bind] env_name and environment disagree; pass a single slug as env_name."
        )
    slug = raw_name or raw_env
    if not slug:
        raise RuntimeError("[puvinoise-bind] env_name is required but missing")

    # Flat-file path: .puvinoise/env_<slug>.json
    path = env_named_json_path(slug, workdir)
    _make_state_dir(path.parent)

    _now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    existing: Dict[str, Any] = {}
    if path.is_file():
        try:
            raw = path.read_text(encoding="utf-8")
            if raw.strip():
                loaded = json.loads(raw)
                if isinstance(loaded, dict):
                    existing = loaded
        except Exception:
            existing = {}

    for _bad in AGENT_STATE_FORBIDDEN_IN_ENV:
        existing.pop(_bad, None)

    tenant_merged = (tenant_id if tenant_id is not None else existing.get("tenant_id"))
    tenant_id_value = (str(tenant_merged).strip() if tenant_merged else None) or None

    version_merged = deploy_version if deploy_version is not None else existing.get("version")
    version_value = (str(version_merged).strip() if version_merged else None) or None

    region_merged = region if region is not None else existing.get("region")
    region_value = (str(region_merged).strip() if region_merged else None) or None

    created_merged = created_at if created_at is not None else existing.get("created_at")
    created_value = (str(created_merged).strip() if created_merged else None) or _now

    bu_new = (base_url or "").strip().rstrip("/")
    bu_old = str(existing.get("base_url") or "").strip().rstrip("/")
    bu_final = bu_new or bu_old
    if not bu_final:
        raise RuntimeError("[puvinoise-bind] base_url is required but missing")

    content: Dict[str, Any] = dict(existing)
    content["env_id"] = eid
    content["env_name"] = slug
    content["base_url"] = bu_final
    content["created_at"] = created_value
    content["tenant_id"] = tenant_id_value
    content["version"] = version_value
    content["region"] = region_value

    print(f"[puvinoise-bind] resolved env_id={eid}", file=sys.stderr)
    print(f"[puvinoise-bind] resolved env_name={slug}", file=sys.stderr)
    print(f"[puvinoise-bind] writing .puvinoise/{path.name}", file=sys.stderr)

    _write_json(path, content)
    _verify_exists(path)
    _set_permissions(path)
    abs_path = path.resolve()
    print(f"[puvinoise] wrote file: {abs_path}")
    return abs_path


def patch_agent_state_environment_binding(
    workdir: Path,
    *,
    env_name: str,
    env_id: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> List[Path]:
    """
    Set ``env_id`` and ``env_name`` on existing ``agent_*.json`` files only.

    Does not create new agent files and does not modify ``api_key``, ``tenant_id``,
    or ``agent_id``. ``env_id`` is taken from *env_id*, or else ``env.json``.

    Raises ``RuntimeError`` if ``env_name`` is empty or ``env_id`` cannot be resolved.
    """
    slug = (env_name or "").strip()
    if not slug:
        raise RuntimeError("[puvinoise-bind] env_name is required but missing")

    eid = (env_id or "").strip()
    if not eid:
        try:
            ed, _ = load_env_json_if_present(workdir)
            if ed:
                eid = str(ed.get("env_id") or "").strip()
        except Exception:
            pass
    if not eid:
        raise RuntimeError("[puvinoise-bind] env_id is required but missing")

    if agent_id:
        candidates: List[Path] = [get_agent_state_path(workdir, agent_id)]
    else:
        candidates = list_agent_json_paths(workdir)
    out: List[Path] = []
    for path in candidates:
        if not path.is_file():
            continue
        try:
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw) if raw.strip() else {}
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        same_name = str(data.get("env_name") or "").strip() == slug
        same_id = str(data.get("env_id") or "").strip() == eid
        if same_name and same_id:
            continue
        try:
            data["env_name"] = slug
            data["env_id"] = eid
            _write_json(path, data)
            _verify_exists(path)
            _set_permissions(path)
            resolved = path.resolve()
            out.append(resolved)
            print(
                f"[puvinoise-bind] writing env_name={slug}",
                file=sys.stderr,
            )
        except Exception:
            continue
    return out


def patch_agent_state_env_name(
    workdir: Path,
    env_name: str,
    *,
    agent_id: Optional[str] = None,
    env_id: Optional[str] = None,
) -> List[Path]:
    """
    Same as :func:`patch_agent_state_environment_binding` when ``env_id`` is known.

    If ``env_id`` is omitted, it is read from ``env.json``.
    Empty *env_name* → no-op (returns ``[]``) for backward compatibility; callers
    that require strict validation should use ``patch_agent_state_environment_binding``.
    """
    slug = (env_name or "").strip()
    if not slug:
        return []
    return patch_agent_state_environment_binding(
        workdir,
        env_name=slug,
        env_id=env_id,
        agent_id=agent_id,
    )


def save_agent_state(
    agent_id: str,
    env_id: str,
    base_url: str,
    workdir: Path,
    *,
    api_key: Optional[str] = None,
    tenant_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    status: str = "active",
    registered_at: Optional[str] = None,
    sdk_version: Optional[str] = None,
    last_used_at: Optional[str] = None,
    env_name: Optional[str] = None,
) -> Path:
    """
    Write ``.puvinoise/agent_<agent_id>.json`` with full agent identity.

    This file is the AUTHORITATIVE single source of truth for all SDK identity
    resolution.  After this file exists, the SDK NEVER reads env vars for
    credentials or identity — it reads from here exclusively.

    Required fields (contract v1.0):
        version, agent_id, env_id, base_url, api_key, tenant_id,
        agent_name, status, registered_at, sdk_version.

    Optional fields:
        last_used_at  — updated by the SDK on each successful run.

    ``env_name`` may be passed explicitly; if omitted, it is taken **only** from
    ``.puvinoise/env.json`` keys ``env_name`` / ``environment`` (values written by
    ``puvinoise bind`` / ``bindcar`` from the CLI or backend). OS ``.env`` files are
    never read. If still empty, raises ``RuntimeError``.
    invalid; the SDK will refuse to init on subsequent runs.
    ``tenant_id`` scopes telemetry to the correct tenant in multi-tenant deployments.
    ``agent_name`` is the canonical registration name (normalized slug).
    ``sdk_version`` is detected automatically if not supplied.

    Raises ``RuntimeError`` on any failure — do NOT wrap in a bare except.
    Post-write validation confirms the file exists before returning.
    """
    aid = (agent_id or "unknown").strip()
    path = get_agent_state_path(workdir, aid)
    _make_state_dir(path.parent)

    _now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Detect sdk_version if not supplied.
    if not sdk_version:
        try:
            from importlib.metadata import version as _imv
            sdk_version = str(_imv("puvinoise-sdk"))
        except Exception:
            try:
                import puvinoise as _pv
                sdk_version = str(getattr(_pv, "__version__", "unknown"))
            except Exception:
                sdk_version = "unknown"

    _key = (api_key or "").strip()
    _tid = (tenant_id or "").strip()
    _name = (agent_name or "").strip()

    # HARD FAIL: both api_key and tenant_id are MANDATORY for a valid agent state file.
    # Writing an incomplete file would silently break SDK init on subsequent runs and
    # disable behaviour pipeline attribution.  Callers MUST supply both or the contract fails.
    if not _key:
        raise RuntimeError(
            f"Cannot write agent state for {aid}: api_key is empty.\n"
            "  api_key is MANDATORY — the SDK will not initialise on subsequent runs without it.\n"
            "  Ensure POST /api/agent-register returns agent.apiKey and it is passed here.\n"
            "  Fix: delete .puvinoise/ and re-run 'puvinoise run' after checking your API key."
        )
    if not _tid:
        raise RuntimeError(
            f"Cannot write agent state for {aid}: tenant_id is empty.\n"
            "  tenant_id is MANDATORY — the behaviour pipeline cannot attribute events without it.\n"
            "  Ensure POST /api/agent-register returns agent.tenantId and it is passed here.\n"
            "  Fix: delete .puvinoise/ and re-run 'puvinoise run' after verifying the backend response."
        )

    _resolved_env = (env_name or "").strip()
    if not _resolved_env:
        try:
            env_data, _ = load_env_json_if_present(workdir)
            if env_data:
                _resolved_env = str(
                    env_data.get("env_name") or env_data.get("environment") or ""
                ).strip()
        except Exception:
            pass
    if not _resolved_env:
        raise RuntimeError("[puvinoise-bind] env_name is required but missing")

    print(
        f"[puvinoise-bind] writing env_name={_resolved_env}",
        file=sys.stderr,
    )

    content: Dict[str, Any] = {
        "version": STATE_FORMAT_VERSION,
        "agent_id": aid,
        "env_id": env_id,
        "env_name": _resolved_env,
        "base_url": base_url.rstrip("/"),
        "api_key": _key,
        "tenant_id": _tid,
        "status": (status or "active").strip(),
        "registered_at": (registered_at or _now).strip(),
        "sdk_version": (sdk_version or "unknown").strip(),
    }
    if _name:
        content["agent_name"] = _name
    _lused = (last_used_at or "").strip()
    if _lused:
        content["last_used_at"] = _lused
    _write_json(path, content)
    _verify_exists(path)
    _set_permissions(path)
    abs_path = path.resolve()
    print(f"[puvinoise] wrote file: {abs_path}")
    return abs_path


# ─── Read ─────────────────────────────────────────────────────────────────────


def load_env_state(
    workdir: Path,
    cli_env_name: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load environment state from ``.puvinoise/env_<env_name>.json`` in *workdir*.

    *cli_env_name* allows the caller to supply an explicit environment name
    (e.g. from the ``--env`` CLI flag).  When omitted, env_name is resolved from
    (in priority order): ``PUVINOISE_ENV_NAME`` env var → ``agent_*.json.env_name``
    → auto-detect if exactly one ``env_*.json`` exists.

    Returns ``(state_dict, path)`` on success, ``({}, None)`` when absent.
    Only reads ``<workdir>/.puvinoise/`` — no parent walk, no env path overrides.
    """
    return load_env_json_if_present(workdir, cli_env_name=cli_env_name)


def load_agent_state(
    workdir: Path,
    agent_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load agent state from ``.puvinoise/agent_*.json`` in *workdir*.

    If *agent_id* is given, looks for ``agent_<id>.json`` first (via the shared loader).
    If several ``agent_*.json`` files exist, logs a warning and uses the first in sorted order.

    Returns ``(state_dict, path)`` on success, ``({}, None)`` when absent.
    Does NOT read legacy files (.puvinoise_env.json etc).
    """
    return load_agent_json_first(workdir, exact_agent_id=agent_id)


def load_identity(workdir: Path) -> Dict[str, Any]:
    """
    Deterministic identity resolution from JSON under ``<workdir>/.puvinoise/`` only.
    Agent state overrides env state.

    Resolution order:
      1. ``.puvinoise/agent_*.json``  — agent state (present after first run)
      2. ``.puvinoise/env.json``      — env state (present after bootstrap)
      3. ``{}``                       — neither found; SDK continues in degraded mode

    Rules:
      • No reads outside ``.puvinoise/``
      • No environment-variable overrides for JSON file locations
    """
    agent_data, agent_path = load_agent_state(workdir)
    if agent_data:
        logger.debug("agent_state: identity resolved from agent state %s", agent_path)
        return agent_data

    env_data, env_path = load_env_state(workdir)
    if env_data:
        logger.debug("agent_state: identity resolved from env state %s", env_path)
        return env_data

    state_dir = get_agent_state_dir(workdir)
    print(
        "[puvinoise] No agent or env JSON identity under .puvinoise/ — continuing in degraded mode"
    )
    logger.warning(
        "agent_state: no identity JSON in %s (expected agent_*.json or env.json)",
        state_dir,
    )
    return {}


# ─── Discovery ────────────────────────────────────────────────────────────────


def find_all_agent_states(base: Path) -> List[Path]:
    """Return all ``.puvinoise/agent_*.json`` files directly under *base*."""
    return list_agent_json_paths(base)


def invalidate_agent_state(workdir: Path) -> bool:
    """
    Delete ``agent_<id>.json`` from *workdir* and log an actionable message.

    Called when the platform returns HTTP 401 — the stored api_key is invalid
    and the agent must re-register to obtain a fresh one.

    Returns ``True`` if a file was found and deleted; ``False`` if nothing was found.
    Never raises — deletion failures are logged but do not crash the caller.
    """
    state_dir = get_agent_state_dir(workdir)
    files = sorted(state_dir.glob(AGENT_STATE_GLOB)) if state_dir.is_dir() else []
    if not files:
        logger.warning(
            "agent_state: invalidate requested but no agent_<id>.json found in %s", state_dir
        )
        return False

    deleted = False
    for f in files:
        try:
            f.unlink()
            logger.error(
                "agent_state: INVALIDATED %s — credentials rejected by platform (HTTP 401)", f
            )
            import sys as _sys
            _sys.stderr.write(
                f"[puvinoise] CREDENTIALS INVALID — {f.name} has been deleted.\n"
                "  Agent credentials were rejected by the platform (HTTP 401).\n"
                "  Re-registration is required before the next run.\n"
                "  Fix: run 'puvinoise run --agent-name <name> python <file>' to re-register.\n"
            )
            _sys.stderr.flush()
            deleted = True
        except OSError as exc:
            logger.error("agent_state: failed to delete %s during invalidation: %s", f, exc)

    return deleted


# ─── Contract validation ──────────────────────────────────────────────────────


def validate_env_state(workdir: Path, env_name: Optional[str] = None) -> None:
    """
    Validate the active ``env_<env_name>.json`` against the data contract.

    *env_name* may be supplied explicitly; when omitted, env_name is resolved via
    the normal priority chain (PUVINOISE_ENV_NAME → agent_*.json → auto-detect).

    Rules enforced:
      • All ENV_STATE_REQUIRED_FIELDS must be present and non-empty.
      • No field in AGENT_STATE_FORBIDDEN_IN_ENV may be present
        (api_key / agent_id must never appear in env_<name>.json).

    Raises ``ValueError`` with an actionable message on any violation.
    Returns ``None`` silently on success.
    """
    data, path = load_env_state(workdir, cli_env_name=env_name)
    if not data:
        state_dir = get_agent_state_dir(workdir)
        raise ValueError(
            f"No env_<name>.json found in {state_dir}/.\n"
            "Run 'puvinoise bindcar --token <prt_...> --env <name>' to bootstrap."
        )

    errors: List[str] = []

    for field in ENV_STATE_REQUIRED_FIELDS:
        val = data.get(field)
        if not val or not str(val).strip():
            errors.append(f"  • Required field '{field}' is missing or empty.")

    for field in AGENT_STATE_FORBIDDEN_IN_ENV:
        if field in data:
            errors.append(
                f"  • Forbidden field '{field}' found in {path.name} — "
                "credentials must only appear in agent_<id>.json."
            )

    if errors:
        raise ValueError(
            f"{path.name} contract violation ({path}):\n" + "\n".join(errors) + "\n"
            "Fix: delete .puvinoise/ and re-run 'puvinoise bindcar --token <prt_...> --env <name>'."
        )

    logger.debug("agent_state: %s contract valid (%s)", path.name, path)


def validate_agent_state(workdir: Path) -> None:
    """
    Validate ``.puvinoise/agent_<id>.json`` against the data contract,
    including a cross-file consistency check against ``env.json``.

    Rules enforced:
      1. All AGENT_STATE_REQUIRED_FIELDS must be present and non-empty.
         In particular, ``api_key`` MUST be non-empty — the SDK will not
         init without it.
      2. ``env_id`` must match ``env.json:env_id`` (cross-file check).
      3. ``base_url`` must match ``env.json:base_url`` (cross-file check).

    If env.json is absent, cross-file checks are skipped (bootstrap-only mode).

    Raises ``ValueError`` with an actionable message on any violation.
    Returns ``None`` silently on success.
    """
    # Multiple agent files — contract violation for validation (loader picks first with warning).
    paths = list_agent_json_paths(workdir)
    if len(paths) > 1:
        names = ", ".join(p.name for p in paths)
        raise ValueError(
            f"Multiple agent state files in {get_agent_state_dir(workdir)}:\n"
            f"  {names}\n"
            "Keep only one agent_<id>.json or remove extras before validation.\n"
            "  Fix: rm extra files or reset: rm -rf .puvinoise && puvinoise-bind --env-only"
        )

    agent_data, agent_path = load_agent_state(workdir)
    if not agent_data:
        raise ValueError(
            f"No agent_<id>.json found in {get_agent_state_dir(workdir)}.\n"
            "Run 'puvinoise run --agent-name <name> python <file>' to auto-register."
        )

    errors: List[str] = []

    for field in AGENT_STATE_REQUIRED_FIELDS:
        val = agent_data.get(field)
        if not val or not str(val).strip():
            errors.append(f"  • Required field '{field}' is missing or empty.")

    # Cross-file consistency: compare against env_<name>.json if it exists.
    # Use the env_name from the agent file itself so we always compare against
    # the right flat-file (env_production.json, env_staging.json, etc.).
    agent_env_name = str(agent_data.get("env_name") or "").strip()
    env_data, env_path = load_env_state(workdir, cli_env_name=agent_env_name or None)
    if env_data:
        persisted_env_id = str(agent_data.get("env_id") or "").strip()
        canonical_env_id = str(env_data.get("env_id") or "").strip()
        if persisted_env_id and canonical_env_id and persisted_env_id != canonical_env_id:
            errors.append(
                f"  • env_id mismatch: agent_<id>.json has '{persisted_env_id}' "
                f"but {env_path.name} has '{canonical_env_id}'.\n"
                "    Reset: rm -rf .puvinoise && puvinoise bindcar --token <prt_...> --env <name>"
            )

        persisted_base = str(agent_data.get("base_url") or "").strip().rstrip("/")
        canonical_base = str(env_data.get("base_url") or "").strip().rstrip("/")
        if persisted_base and canonical_base and persisted_base != canonical_base:
            errors.append(
                f"  • base_url mismatch: agent_<id>.json has '{persisted_base}' "
                f"but {env_path.name} has '{canonical_base}'.\n"
                "    Reset: rm -rf .puvinoise && puvinoise bindcar --token <prt_...> --env <name>"
            )

        canonical_ename = str(env_data.get("env_name") or "").strip()
        if canonical_ename and agent_env_name and agent_env_name != canonical_ename:
            errors.append(
                f"  • env_name mismatch: agent_<id>.json has '{agent_env_name}' "
                f"but {env_path.name} has '{canonical_ename}'.\n"
                "    Re-run: puvinoise bindcar --token <prt_...> --env <name>"
            )

    if errors:
        raise ValueError(
            f"agent_<id>.json contract violation ({agent_path}):\n"
            + "\n".join(errors)
        )

    logger.debug("agent_state: agent_<id>.json contract valid (%s)", agent_path)


# ─── Internal helpers ─────────────────────────────────────────────────────────


def _make_state_dir(d: Path) -> None:
    """Create directory *d* and all parents.  Raises ``RuntimeError`` on failure."""
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(
            f"Cannot create state directory {d}: {exc}\n"
            "Check directory permissions and try again."
        ) from exc
    # Hard verification — a filesystem that silently swallowed the mkdir would
    # produce a confusing "file written but not found" error further down.
    if not d.is_dir():
        raise RuntimeError(
            f"Failed to create state directory {d}.\n"
            "mkdir returned without error but the directory does not exist.\n"
            "Check file system permissions and available inodes."
        )


def _write_json(path: Path, content: Dict[str, Any]) -> None:
    """Write *content* as JSON to *path*.  Raises ``RuntimeError`` on failure.

    If *path* already exists as read-only (0o444), it is temporarily made
    writable for the duration of the write, then locked back to read-only by
    the ``_set_permissions`` call that follows every ``_write_json`` call.
    """
    try:
        if path.exists():
            # Temporarily unlock so we can overwrite the read-only file.
            try:
                os.chmod(path, 0o600)
            except Exception:  # noqa: BLE001
                pass
        path.write_text(json.dumps(content, indent=2), encoding="utf-8")
    except OSError as exc:
        raise RuntimeError(f"Cannot write state file {path}: {exc}") from exc


def _verify_exists(path: Path) -> None:
    """Raise ``RuntimeError`` if *path* does not exist after a write."""
    if not path.is_file():
        raise RuntimeError(
            f"File write appeared to succeed but {path} does not exist.\n"
            "Check available disk space and file system permissions."
        )


def _set_permissions(path: Path) -> None:
    """Set 0o444 (read-only for all) on *path* (best-effort; failure is not fatal).

    The agent state file must never be hand-edited — making it read-only prevents
    accidental corruption and reinforces that identity is managed exclusively by the SDK.
    """
    try:
        os.chmod(path, 0o444)
    except Exception:  # noqa: BLE001
        pass


def _read_json(path: Path) -> Dict[str, Any]:
    """Return parsed JSON dict from *path*, or ``{}`` on any read/parse error."""
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception:  # noqa: BLE001
        pass
    return {}
