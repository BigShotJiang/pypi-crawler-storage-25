"""
Deterministic environment binding for PUVINoise (bindcar).

* Validates registration token with the platform (read-only inspect).
* Writes the active environment to ``.puvinoise/env_<env_name>.json`` (flat file).

``puvinoise run`` reads ``.puvinoise/agent_*.json`` (priority) or the resolved
``env_<env_name>.json`` — NOT ``.env.puvinoise``.
``.env.puvinoise`` is reserved for SSL certificate configuration only.

File structure
--------------
  .puvinoise/env_<slug>.json    — one flat file per named environment
  .puvinoise/agent_<id>.json    — per-agent identity (written by puvinoise run)

The old ``.puvinoise/env.json`` and ``.puvinoise/environments/`` are no longer
written.  Callers that still have an ``env.json`` will see a migration notice
from ``puvinoise_json_config.load_env_json_if_present``.
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from puvinoise.agent_state import (
    load_env_state,
    patch_agent_state_environment_binding,
    save_env_state,
)
from puvinoise.puvinoise_json_config import (
    list_env_json_paths,
    load_named_env_json,
    read_json_dict,
)
from puvinoise.ssl_startup import probe_https_to_base_url, report_ssl_backend_and_warnings


def _env_slug(name: str) -> str:
    s = (name or "").strip().lower().replace(" ", "_")
    s = re.sub(r"[^a-z0-9._-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "environment"


def _post_inspect(base_url: str, registration_token: str, timeout: float = 45.0) -> Dict[str, Any]:
    url = f"{base_url.rstrip('/')}/api/bindcar/inspect"
    body = json.dumps({"registration_token": registration_token}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
            data = json.loads(detail) if detail else {}
        except Exception:
            data = {}
        err = (data.get("error") if isinstance(data, dict) else None) or str(e)
        raise RuntimeError(str(err)) from e


def _read_current_binding(workdir: Path) -> Tuple[Dict[str, Any], Optional[str], Optional[str]]:
    """
    Returns (state_dict, env_id, env_display_name) from the active env_<name>.json.
    Returns ({}, None, None) when no binding exists.
    """
    data, _ = load_env_state(workdir)
    if not data:
        return {}, None, None
    eid = str(data.get("env_id") or "").strip() or None
    name = str(data.get("env_name") or "").strip() or None
    return data, eid, name


def _confirm_switch(current_label: str, new_name: str) -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        r = input(
            f"This folder is currently bound to {current_label}.\n"
            f"You are attempting to switch to {new_name}.\n"
            "Overwrite active binding? [y/N]: "
        ).strip().lower()
    except EOFError:
        return False
    return r in ("y", "yes")


def cmd_bindcar(args) -> int:
    token = (getattr(args, "token", None) or "").strip()
    if not token:
        print("puvinoise bindcar: --token is required", file=sys.stderr)
        return 2

    base_url = (getattr(args, "base_url", None) or os.getenv("PUVINOISE_BASE_URL", "") or "").strip()
    if not base_url:
        print(
            "puvinoise bindcar: set PUVINOISE_BASE_URL or pass --base-url <url>",
            file=sys.stderr,
        )
        return 2

    report_ssl_backend_and_warnings()
    probe_https_to_base_url(base_url)

    workdir = Path.cwd().resolve()

    try:
        payload = _post_inspect(base_url, token)
    except RuntimeError as e:
        print(f"puvinoise bindcar: token validation failed: {e}", file=sys.stderr)
        return 1

    if not payload.get("ok"):
        print("puvinoise bindcar: unexpected response from server", file=sys.stderr)
        return 1

    new_env_id = str(payload.get("env_id") or "").strip()
    new_env_name = str(payload.get("env_name") or "").strip()
    tenant_id = str(payload.get("tenant_id") or "").strip()
    resolved_base = str(payload.get("base_url") or base_url).strip().rstrip("/")

    cli_env = (getattr(args, "env_slug", None) or "").strip()
    final_env_name = cli_env or new_env_name

    if not new_env_id:
        print("[puvinoise-bind] env_id is required but missing", file=sys.stderr)
        print("puvinoise bindcar: server response missing env_id", file=sys.stderr)
        return 1
    if not tenant_id:
        print("puvinoise bindcar: server response missing tenant_id", file=sys.stderr)
        return 1
    if not final_env_name:
        print("[puvinoise-bind] env_name is required but missing", file=sys.stderr)
        print(
            "puvinoise bindcar: pass --env <name> or use a token that includes env_name.",
            file=sys.stderr,
        )
        return 1

    _current_data, cur_id, cur_name = _read_current_binding(workdir)
    cur_label = cur_name or cur_id or "(unknown)"

    if cur_id and cur_id == new_env_id:
        sync_name = (cli_env or cur_name or final_env_name or "").strip()
        if sync_name:
            try:
                patch_agent_state_environment_binding(
                    workdir,
                    env_name=sync_name,
                    env_id=new_env_id,
                )
            except RuntimeError as e:
                print(f"puvinoise bindcar: {e}", file=sys.stderr)
                return 1
        print(f"✔ Already bound to environment: {cur_name or final_env_name}")
        print(
            "[puvinoise-bindcar] Next: `puvinoise onboard` or `puvinoise run --agent-name <name> ...`",
            file=sys.stderr,
        )
        return 0

    if cur_id and cur_id != new_env_id:
        print(
            f"⚠ This folder is currently bound to {cur_label}\n"
            f"You are attempting to switch to {final_env_name}",
            file=sys.stderr,
        )
        force = bool(getattr(args, "force", False))
        if not force and not _confirm_switch(cur_label, final_env_name):
            if not sys.stdin.isatty():
                print(
                    "puvinoise bindcar: non-interactive session — re-run with --force to switch binding.",
                    file=sys.stderr,
                )
            return 3

    if cur_id is None and _current_data:
        # An env file exists but env_id is missing — corrupted.
        print(
            "⚠ An env_*.json exists in .puvinoise/ but env_id is missing or unreadable.",
            file=sys.stderr,
        )
        if not bool(getattr(args, "force", False)):
            print(
                "puvinoise bindcar: fix the file or re-run with --force to replace it.",
                file=sys.stderr,
            )
            return 3

    # Write binding to .puvinoise/env_<slug>.json — single source of truth.
    # Registration token is NOT persisted — it was used only for this inspect call.
    bound_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    written_path = save_env_state(
        new_env_id,
        resolved_base,
        workdir,
        env_name=final_env_name,
        tenant_id=tenant_id,
        created_at=bound_at,
    )

    try:
        patch_agent_state_environment_binding(
            workdir,
            env_name=final_env_name,
            env_id=new_env_id,
        )
    except RuntimeError as e:
        print(f"puvinoise bindcar: {e}", file=sys.stderr)
        return 1

    slug = _env_slug(final_env_name)
    print(f"✔ Active environment: {final_env_name}  (file: .puvinoise/env_{slug}.json)")
    print(f"[puvinoise-bindcar] wrote {written_path}", file=sys.stderr)
    print(
        "[puvinoise-bindcar] Next: register this folder — "
        "`puvinoise onboard` (prompts for agent name) or "
        "`puvinoise run --agent-name <name> ...`",
        file=sys.stderr,
    )
    return 0


def _find_saved_env(workdir: Path, name: str) -> Optional[Path]:
    """
    Find a saved environment file under ``.puvinoise/`` by env_name or slug.

    Searches the flat ``env_*.json`` files directly — no ``environments/``
    sub-folder is used.
    """
    want = (name or "").strip().lower()
    if not want:
        return None

    for p in sorted(list_env_json_paths(workdir)):
        try:
            data = read_json_dict(p)
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        stored_name = str(data.get("env_name") or "").strip().lower()
        if stored_name == want:
            return p
        # Also match by slug derived from the filename (env_<slug>.json).
        stem = p.stem   # "env_production"
        if stem.startswith("env_"):
            file_slug = stem[4:].lower()
            if file_slug == want:
                return p

    return None


def cmd_switch(args) -> int:
    name = (getattr(args, "env_name", None) or "").strip()
    if not name:
        print("puvinoise switch: environment name is required", file=sys.stderr)
        return 2

    workdir = Path.cwd().resolve()
    p = _find_saved_env(workdir, name)
    if not p or not p.is_file():
        print(
            f"puvinoise switch: no saved environment '{name}' under .puvinoise/\n"
            "  Available files: "
            + ", ".join(f.name for f in list_env_json_paths(workdir))
            if list_env_json_paths(workdir)
            else f"puvinoise switch: no saved environment '{name}' under .puvinoise/ (no env_*.json files found)",
            file=sys.stderr,
        )
        return 1

    try:
        data = read_json_dict(p)
    except Exception as e:
        print(f"puvinoise switch: corrupted env file: {e}", file=sys.stderr)
        return 1

    if not isinstance(data, dict):
        print("puvinoise switch: invalid env file", file=sys.stderr)
        return 1

    eid = str(data.get("env_id") or "").strip()
    ename = str(data.get("env_name") or "").strip()
    tid = str(data.get("tenant_id") or "").strip()
    base = str(data.get("base_url") or "").strip().rstrip("/")
    if not eid or not ename or not tid or not base:
        print("puvinoise switch: env file missing env_id, env_name, tenant_id, or base_url", file=sys.stderr)
        return 1

    report_ssl_backend_and_warnings()
    probe_https_to_base_url(base)

    # save_env_state writes (or re-writes) env_<slug>.json — idempotent for same env.
    written_path = save_env_state(
        eid,
        base,
        workdir,
        env_name=ename,
        tenant_id=tid,
    )
    slug = _env_slug(ename)
    print(f"✔ Active environment: {ename}  (file: .puvinoise/env_{slug}.json)")
    print(f"[puvinoise-switch] updated {written_path}", file=sys.stderr)
    try:
        patch_agent_state_environment_binding(
            workdir,
            env_name=ename,
            env_id=eid,
        )
    except RuntimeError as e:
        print(f"puvinoise switch: {e}", file=sys.stderr)
        return 1
    return 0


def _add_bindcar_arguments(p) -> None:
    p.add_argument("--token", required=True, help="Registration token (prt_...) from the PUVINoise UI")
    p.add_argument(
        "--base-url",
        dest="base_url",
        default=None,
        help="Platform base URL (overrides PUVINOISE_BASE_URL)",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Non-interactive: allow switching away from an existing binding",
    )
    p.add_argument(
        "--env",
        dest="env_slug",
        default="",
        metavar="NAME",
        help=(
            "Environment slug for telemetry (optional). Overrides server env_name; written to "
            ".puvinoise/env_<name>.json and synced to agent_*.json."
        ),
    )


def register_bindcar_subparser(sub) -> None:
    p = sub.add_parser(
        "bindcar",
        help="Bind this folder to a platform environment (writes .puvinoise/env_<name>.json)",
        description=(
            "Validate a registration token with the server and persist the active environment "
            "to .puvinoise/env_<env_name>.json (flat file)."
        ),
    )
    _add_bindcar_arguments(p)
    p.set_defaults(func=cmd_bindcar)

    pb = sub.add_parser(
        "bind",
        help="Alias for bindcar — bind this folder to a platform environment",
        description=(
            "Same as ``puvinoise bindcar``: validate a token and persist env_id + env_name."
        ),
    )
    _add_bindcar_arguments(pb)
    pb.set_defaults(func=cmd_bindcar)


def register_switch_subparser(sub) -> None:
    p = sub.add_parser(
        "switch",
        help="Activate a previously saved environment (no server call)",
        description=(
            "Switch to a named environment by re-writing its .puvinoise/env_<name>.json "
            "as the active binding.  The file must already exist from a prior `puvinoise bindcar`."
        ),
    )
    p.add_argument("env_name", help="Saved environment name or slug")
    p.set_defaults(func=cmd_switch)
