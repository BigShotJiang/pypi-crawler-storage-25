"""Configuration handling for fedctl."""
