from __future__ import annotations

import os
from typing import Optional

from .schema import FedctlConfig, EffectiveConfig


def get_effective_config(
    cfg: FedctlConfig,
    profile_name: Optional[str] = None,
    endpoint: Optional[str] = None,
    namespace: Optional[str] = None,
    token: Optional[str] = None,
) -> EffectiveConfig:
    name = profile_name or os.environ.get("FEDCTL_PROFILE") or cfg.active_profile
    if name not in cfg.profiles:
        raise ValueError(f"Unknown profile '{name}'. Use `fedctl profile ls`.")

    p = cfg.profiles[name]

    env_endpoint = os.environ.get("FEDCTL_ENDPOINT")
    env_namespace = os.environ.get("FEDCTL_NAMESPACE")
    env_token = os.environ.get("NOMAD_TOKEN")

    eff_endpoint = endpoint or env_endpoint or p.endpoint
    eff_namespace = (
        _normalize_namespace(namespace)
        or _normalize_namespace(env_namespace)
        or _normalize_namespace(p.namespace)
        or "default"
    )

    eff_token = token or env_token

    return EffectiveConfig(
        profile_name=name,
        endpoint=eff_endpoint,
        namespace=eff_namespace,
        nomad_token=eff_token,
    )


def _normalize_namespace(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    normalized = value.strip()
    return normalized if normalized else None
