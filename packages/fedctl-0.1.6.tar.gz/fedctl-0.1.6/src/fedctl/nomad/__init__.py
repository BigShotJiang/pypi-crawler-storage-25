"""Nomad HTTP client helpers."""
