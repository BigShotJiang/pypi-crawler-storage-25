import logging
from dataclasses import dataclass, field
from enum import StrEnum, unique
from typing import TYPE_CHECKING, Self, cast
from uuid import UUID, uuid4
from xml.etree.ElementTree import Element, ParseError, SubElement, fromstring, tostring

from pyreqwest.client import Client, ClientBuilder
from pyreqwest.exceptions import StatusError

from .exceptions import AuthenticationError, WinRMTransportError, WSManFaultError

if TYPE_CHECKING:
    from types import TracebackType

logger = logging.getLogger('rwinrm')


@unique
class WSManAction(StrEnum):
    # WS-Management URIs
    GET = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Get'
    GET_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/GetResponse'
    PUT = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Put'
    PUT_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/PutResponse'
    CREATE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create'
    CREATE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/CreateResponse'
    DELETE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete'
    DELETE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/DeleteResponse'
    ENUMERATE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/Enumerate'
    ENUMERATE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/EnumerateResponse'
    PULL = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/Pull'
    PULL_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/PullResponse'

    # MS-WSMV URIs
    COMMAND = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'
    COMMAND_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandResponse'
    CONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Connect'
    CONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ConnectResponse'
    DISCONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Disconnect'
    DISCONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/DisconnectResponse'
    RECEIVE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive'
    RECEIVE_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ReceiveResponse'
    RECONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Reconnect'
    RECONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ReconnectResponse'
    SEND = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Send'
    SEND_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/SendResponse'
    SIGNAL = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal'
    SIGNAL_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/SignalResponse'


NAMESPACES: dict[str, str] = {
    's': 'http://www.w3.org/2003/05/soap-envelope',
    'xs': 'http://www.w3.org/2001/XMLSchema',
    'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
    'wsa': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
    'wsman': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
    'wsmid': 'http://schemas.dmtf.org/wbem/wsman/identify/1/wsmanidentity.xsd',
    'wsmanfault': 'http://schemas.microsoft.com/wbem/wsman/1/wsmanfault',
    'cim': 'http://schemas.dmtf.org/wbem/wscim/1/common',
    'wsmv': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
    'cfg': 'http://schemas.microsoft.com/wbem/wsman/1/config',
    'sub': 'http://schemas.microsoft.com/wbem/wsman/1/subscription',
    'rsp': 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell',
    'm': 'http://schemas.microsoft.com/wbem/wsman/1/machineid',
    'cert': 'http://schemas.microsoft.com/wbem/wsman/1/config/service/certmapping',
    'plugin': 'http://schemas.microsoft.com/wbem/wsman/1/config/PluginConfiguration',
    'wsen': 'http://schemas.xmlsoap.org/ws/2004/09/enumeration',
    'wsdl': 'http://schemas.xmlsoap.org/wsdl',
    'wst': 'http://schemas.xmlsoap.org/ws/2004/09/transfer',
    'wsp': 'http://schemas.xmlsoap.org/ws/2004/09/policy',
    'wse': 'http://schemas.xmlsoap.org/ws/2004/08/eventing',
    'i': 'http://schemas.microsoft.com/wbem/wsman/1/cim/interactive.xsd',
    'xml': 'http://www.w3.org/XML/1998/namespace',
    'pwsh': 'http://schemas.microsoft.com/powershell',
}


@dataclass(slots=True, frozen=True)
class HTTPTransport:
    server_url: str
    username: str
    password: str
    client: Client = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            'client',
            ClientBuilder()
            .base_url(self.server_url + '/' if not self.server_url.endswith('/') else self.server_url)
            .default_cookie_store(enable=True)
            .default_headers(
                {
                    'Content-Type': 'application/soap+xml;charset=UTF-8',
                },
            )
            .build(),
        )

    async def send(self, body: bytes) -> str:
        logger.debug("Sending request to '%s' with body '%s'", self.server_url, body)
        request = self.client.post(self.server_url).basic_auth(self.username, self.password).body_bytes(body).build()
        response = await request.send()
        result = await response.text()
        logger.debug("Received response from '%s': status=%s, body=%s", self.server_url, response.status, result)
        try:
            response.error_for_status()
        except StatusError as err:
            if response.status == 401:
                logger.exception('Authentication failed for user %s (status=%s)', self.username, response.status)
                raise AuthenticationError from err
            raise WinRMTransportError(protocol='http', code=response.status, response_text=result) from err
        return result

    async def close(self) -> None:
        await self.client.close()


@dataclass(slots=True, frozen=True)
class WSManSet:
    element_name: str
    child_element_name: str
    must_understand: bool
    values: list = field(default_factory=list)

    def add_option(self, name: str, value: str, attributes: dict | None = None) -> None:
        attributes = attributes if attributes is not None else {}
        self.values.append((name, value, attributes))

    def pack(self) -> Element:
        s = NAMESPACES['s']
        wsman = NAMESPACES['wsman']
        element = Element(f'{{{wsman}}}{self.element_name}')
        if self.must_understand:
            element.set(f'{{{s}}}mustUnderstand', 'true')

        for key, value, attributes in self.values:
            SubElement(element, f'{{{wsman}}}{self.child_element_name}', Name=key, attrib=attributes).text = str(value)

        return element


class OptionSet(WSManSet):
    def __init__(self) -> None:
        super().__init__('OptionSet', 'Option', must_understand=True)


class SelectorSet(WSManSet):
    def __init__(self) -> None:
        super().__init__('SelectorSet', 'Selector', must_understand=False)


@dataclass(slots=True)
class WSMan:
    transport: HTTPTransport
    locale: str = 'en-US'
    data_locale: str = 'en-US'
    max_envelope_size: int = 153600
    max_payload_size: int = field(init=False)
    operation_timeout: int = 20
    session_id: UUID = field(init=False, default_factory=uuid4)

    def __post_init__(self) -> None:
        logger.debug(
            'Initialising WSMan class with maximum envelope size of %s and operation timeout of %s',
            self.max_envelope_size,
            self.operation_timeout,
        )
        self.max_payload_size = self._calc_envelope_size(self.max_envelope_size)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.close()

    async def _get_server_config(self) -> Element:
        return await self.get(resource_uri='http://schemas.microsoft.com/wbem/wsman/1/config')

    def _calc_envelope_size(self, max_envelope_size: int) -> int:
        empty_uuid = '00000000-0000-0000-0000-000000000000'

        selector_set = SelectorSet()
        selector_set.add_option('ShellId', empty_uuid)
        _, header = self._create_header(
            action=WSManAction.SEND,
            resource_uri='http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd',
            selector_set=selector_set,
        )

        rsp = NAMESPACES['rsp']

        send = Element(f'{{{rsp}}}')
        SubElement(send, f'{{{rsp}}}Stream', Name='stdin', CommandId=empty_uuid).text = ''

        s = NAMESPACES['s']
        envelope = Element(f'{{{s}}}Envelope')
        envelope.append(header)
        envelope.append(send)

        envelope_size = len(envelope) + 256
        max_bytes_size = max_envelope_size - envelope_size

        return int(max_bytes_size / 4 * 3)

    async def update_max_payload_size(self, max_payload_size: int | None) -> None:
        if max_payload_size is None:
            config = await self._get_server_config()
            max_size_kb_et = config.find('cfg:Config/cfg:MaxEnvelopeSizekb', namespaces=NAMESPACES)
            max_size_kb = max_size_kb_et.text if max_size_kb_et is not None else None
            if not max_size_kb:
                logger.warning('Invalid MaxEnvelopeSizekb from server, using 0')
                max_payload_size = 0
            else:
                max_payload_size = int(max_size_kb) * 1024

        self.max_payload_size = max_payload_size
        self.max_envelope_size = self._calc_envelope_size(max_payload_size)

    def _create_header(
        self,
        action: str,
        resource_uri: str,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> tuple[str, Element]:
        logger.debug(
            'Creating WSMan header (Action: %s, Resource URI: %s, Option Set: %s, Selector Set: %s',
            action,
            resource_uri,
            option_set,
            selector_set,
        )

        s = NAMESPACES['s']
        wsa = NAMESPACES['wsa']
        wsman = NAMESPACES['wsman']
        wsmv = NAMESPACES['wsmv']
        xml = NAMESPACES['xml']

        header = Element(f'{{{s}}}Header')

        SubElement(header, f'{{{wsa}}}Action', attrib={f'{{{s}}}mustUnderstand': 'true'}).text = action

        SubElement(
            header,
            f'{{{wsmv}}}DataLocale',
            attrib={f'{{{s}}}mustUnderstand': 'false', f'{{{xml}}}lang': self.data_locale},
        )

        SubElement(
            header,
            f'{{{wsman}}}Locale',
            attrib={f'{{{s}}}mustUnderstand': 'false', f'{{{xml}}}lang': self.locale},
        )

        SubElement(header, f'{{{wsman}}}MaxEnvelopeSize', attrib={f'{{{s}}}mustUnderstand': 'true'}).text = str(
            self.max_envelope_size,
        )

        message_id = str(uuid4()).upper()
        SubElement(header, f'{{{wsa}}}MessageID').text = f'uuid:{message_id}'

        SubElement(header, f'{{{wsman}}}OperationTimeout').text = f'PT{timeout or self.operation_timeout}S'

        reply_to = SubElement(header, f'{{{wsa}}}ReplyTo')
        SubElement(
            reply_to,
            f'{{{wsa}}}Address',
            attrib={f'{{{s}}}mustUnderstand': 'true'},
        ).text = 'http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous'

        SubElement(header, f'{{{wsman}}}ResourceURI', attrib={f'{{{s}}}mustUnderstand': 'true'}).text = resource_uri

        SubElement(
            header,
            f'{{{wsmv}}}SessionId',
            attrib={f'{{{s}}}mustUnderstand': 'false'},
        ).text = f'uuid:{str(self.session_id).upper()}'

        SubElement(header, f'{{{wsa}}}To').text = self.transport.server_url

        if option_set is not None:
            header.append(option_set.pack())

        if selector_set is not None:
            header.append(selector_set.pack())

        return message_id, header

    async def _invoke(
        self,
        action: WSManAction | str,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        s = NAMESPACES['s']
        envelope = Element(f'{{{s}}}Envelope')

        message_id, header = self._create_header(str(action), resource_uri, option_set, selector_set, timeout)
        message_id = f'uuid:{message_id}'
        envelope.append(header)

        body = SubElement(envelope, f'{{{s}}}Body')
        if resource is not None:
            body.append(resource)

        xml = tostring(envelope, encoding='utf-8', method='xml')
        try:
            response = await self.transport.send(xml)
        except WinRMTransportError as err:
            try:
                raise self._parse_wsman_fault(xml_text=err.response_text)
            except ParseError:
                logger.exception(
                    'Failed to parse WSManFault message on WinRM error response, raising original WinRMTransportError',
                )
                raise

        response_xml = fromstring(response)
        relates_to_et = response_xml.find('s:Header/wsa:RelatesTo', namespaces=NAMESPACES)
        relates_to = relates_to_et.text if relates_to_et is not None else ''

        if message_id != relates_to:
            logger.exception(
                'Received related id does not match related expected message id: Sent: %s, Received: %s',
                message_id,
                relates_to,
            )
            raise RuntimeError
        return response_xml

    @staticmethod
    def _parse_wsman_fault(xml_text: str) -> WSManFaultError:
        xml = fromstring(xml_text)
        code: str | int = -1
        reason: str | None = None
        machine: str | None = None
        provider: str | None = None
        provider_path: str | None = None
        provider_fault: str | None = None

        wsman_fault = None

        fault = xml.find('s:Body/s:Fault', namespaces=NAMESPACES)
        if fault is not None:
            code_info = fault.find('s:Code/s:Subcode/s:Value', namespaces=NAMESPACES)
            if code_info is not None and code_info.text:
                code = code_info.text
            else:
                code_info = fault.find('s:Code/s:Value', namespaces=NAMESPACES)
                if code_info is not None and code_info.text:
                    code = code_info.text

            reason_info = fault.find('s:Reason/s:Text', namespaces=NAMESPACES)
            if reason_info is not None:
                reason = reason_info.text

            wsman_fault = fault.find('s:Detail/wsmanfault:WSManFault', namespaces=NAMESPACES)

        if wsman_fault is not None:
            code = int(wsman_fault.attrib.get('Code', code))
            machine = wsman_fault.attrib.get('Machine')

            message_info = wsman_fault.find('wsmanfault:Message', namespaces=NAMESPACES)
            if message_info is not None:
                reason = message_info.text or reason

            provider_info = wsman_fault.find('wsmanfault:Message/wsmanfault:ProviderFault', namespaces=NAMESPACES)
            if provider_info is not None:
                provider = provider_info.attrib.get('provider')
                provider_path = provider_info.attrib.get('path')
                provider_fault = provider_info.text

        reason = reason.strip() if reason else None
        provider_fault = provider_fault.strip() if provider_fault else None

        return WSManFaultError(
            code=code,
            machine=machine,
            reason=reason,
            provider=provider,
            provider_path=provider_path,
            provider_fault=provider_fault,
        )

    async def close(self) -> None:
        await self.transport.close()

    async def command(
        self,
        resource_uri: str,
        resource: Element,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.COMMAND, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def connect(
        self,
        resource_uri: str,
        resource: Element,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.CONNECT, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def disconnect(
        self,
        resource_uri: str,
        resource: Element,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.DISCONNECT, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def reconnect(
        self,
        resource_uri: str,
        resource: Element,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.RECONNECT, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def create(
        self,
        resource_uri: str,
        resource: Element,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.CREATE, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def delete(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.DELETE, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def enumerate(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.ENUMERATE, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def get(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.GET, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def pull(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.PULL, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def put(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.PUT, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def receive(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.RECEIVE, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def send(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.SEND, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def signal(
        self,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(WSManAction.SIGNAL, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))

    async def custom(
        self,
        action: str,
        resource_uri: str,
        resource: Element | None = None,
        option_set: OptionSet | None = None,
        selector_set: SelectorSet | None = None,
        timeout: int | None = None,
    ) -> Element:
        result = await self._invoke(action, resource_uri, resource, option_set, selector_set, timeout)
        return cast('Element', result.find('s:Body', namespaces=NAMESPACES))
