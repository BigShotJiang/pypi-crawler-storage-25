import logging
from dataclasses import dataclass, make_dataclass
from typing import Any
from xml.etree.ElementTree import Element, SubElement

from .wsman import NAMESPACES, SelectorSet, WSMan

logger = logging.getLogger('wsmanio')


def clean_namespace(tag: str) -> str:
    """Удаляет namespace из XML-тега вида {namespace}TagName"""
    if '}' in tag:
        return tag.split('}', 1)[1]
    return tag


def create_wmi_object(cls_name: str, data: dict[str, str | None]) -> Any:
    clean_fields = {clean_namespace(key): value for key, value in data.items()}
    cls = make_dataclass(
        cls_name=clean_namespace(cls_name),
        fields=[(field_name, type(field_type)) for field_name, field_type in clean_fields.items()],
        frozen=True,
        slots=True,
    )
    return cls(**clean_fields)


@dataclass(frozen=True, slots=True)
class WMIQueryResult:
    wsman: WSMan
    namespace: str
    context: str

    async def __aiter__(self):
        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/*'
        wsen = NAMESPACES['wsen']
        context = self.context

        while True:
            resource = Element(f'{{{wsen}}}Pull')
            SubElement(resource, f'{{{wsen}}}EnumerationContext').text = context
            SubElement(resource, f'{{{wsen}}}MaxElements').text = '10'
            body = await self.wsman.pull(
                resource_uri=resource_uri,
                resource=resource,
            )

            for item in body.findall('wsen:PullResponse/wsen:Items/*', namespaces=NAMESPACES):
                yield create_wmi_object(cls_name=item.tag, data={child.tag: child.text for child in item})

            end_of_sequence = body.find('wsen:PullResponse/wsen:EndOfSequence', namespaces=NAMESPACES)
            if end_of_sequence is not None:
                break

            context = body.find('wsen:PullResponse/wsen:EnumerationContext', namespaces=NAMESPACES)
            if context is None:
                raise RuntimeError
            context = context.text

    async def all(self) -> list[Any]:
        return [obj async for obj in self]


@dataclass(frozen=True, slots=True)
class WMIMethodInvoker:
    wsman: WSMan
    namespace: str
    class_name: str
    method: str

    async def __call__(
        self,
        selectors: dict[str, str] | None = None,
        arguments: dict[str, Any] | None = None,
    ) -> Any:
        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/{self.class_name}'
        resource = Element(f'{{{resource_uri}}}{self.method}_INPUT')
        if arguments:
            for key, value in arguments.items():
                SubElement(resource, f'{{{resource_uri}}}{key}').text = value

        selector_set = None
        if selectors:
            selector_set = SelectorSet()
            for key, value in selectors.items():
                selector_set.add_option(name=key, value=value)

        body = await self.wsman.custom(
            action=f'{resource_uri}/{self.method}',
            resource_uri=resource_uri,
            resource=resource,
            selector_set=selector_set,
        )
        output = body.find(f'.//{{*}}{self.method}_OUTPUT')
        if output is None:
            logger.exception('Unable to find output')
            raise RuntimeError
        return create_wmi_object(
            cls_name=f'{self.class_name}_{self.method}',
            data={child.tag: child.text for child in output},
        )


@dataclass(frozen=True, slots=True)
class WMIClass:
    wsman: WSMan
    namespace: str
    class_name: str

    async def __call__(self, **selectors: str) -> Any:
        if not selectors:
            raise ValueError

        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/{self.class_name}'

        selector_set = SelectorSet()
        for key, value in selectors.items():
            selector_set.add_option(name=key, value=value)

        body = await self.wsman.get(
            resource_uri=resource_uri,
            selector_set=selector_set,
        )
        result = body.find('./*')
        if result is None:
            raise RuntimeError

        return create_wmi_object(cls_name=self.class_name, data={child.tag: child.text for child in result})

    def __getattr__(self, method: str) -> WMIMethodInvoker:
        return WMIMethodInvoker(wsman=self.wsman, namespace=self.namespace, class_name=self.class_name, method=method)


@dataclass(frozen=True, slots=True)
class WMINamespace:
    wsman: WSMan
    name: str

    def __getattr__(self, class_name: str) -> WMIClass:
        return WMIClass(wsman=self.wsman, namespace=self.name, class_name=class_name)

    async def query(self, query: str) -> WMIQueryResult:
        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.name}/*'

        wsen = NAMESPACES['wsen']
        resource = Element(f'{{{wsen}}}Enumerate')
        wsman = NAMESPACES['wsman']
        SubElement(
            resource,
            f'{{{wsman}}}Filter',
            attrib={'Dialect': 'http://schemas.microsoft.com/wbem/wsman/1/WQL'},
        ).text = query

        body = await self.wsman.enumerate(resource_uri=resource_uri, resource=resource)
        context = body.find('wsen:EnumerateResponse/wsen:EnumerationContext', namespaces=NAMESPACES)
        if context is None:
            raise RuntimeError
        if context.text is None:
            raise RuntimeError
        return WMIQueryResult(wsman=self.wsman, namespace=self.name, context=context.text)


@dataclass(frozen=True, slots=True)
class WMIClient:
    wsman: WSMan

    @property
    def cimv2(self) -> WMINamespace:
        return WMINamespace(wsman=self.wsman, name='root/cimv2')

    @property
    def virtualization(self) -> WMINamespace:
        return WMINamespace(wsman=self.wsman, name='root/virtualization/v2')

    def namespace(self, name: str) -> WMINamespace:
        return WMINamespace(wsman=self.wsman, name=name)
