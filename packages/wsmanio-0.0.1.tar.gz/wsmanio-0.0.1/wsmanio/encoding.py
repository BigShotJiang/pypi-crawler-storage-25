from enum import StrEnum


class Encoding(StrEnum):
    CP437 = 'cp437'
    CP720 = 'cp720'
    CP737 = 'cp737'
    CP775 = 'cp775'
    CP850 = 'cp850'
    CP852 = 'cp852'
    CP855 = 'cp855'
    CP857 = 'cp857'
    CP858 = 'cp858'
    CP860 = 'cp860'
    CP861 = 'cp861'
    CP862 = 'cp862'
    CP863 = 'cp863'
    CP864 = 'cp864'
    CP865 = 'cp865'
    CP866 = 'cp866'
    CP869 = 'cp869'

    CP874 = 'cp874'
    CP1250 = 'cp1250'
    CP1251 = 'cp1251'
    CP1252 = 'cp1252'
    CP1253 = 'cp1253'
    CP1254 = 'cp1254'
    CP1255 = 'cp1255'
    CP1256 = 'cp1256'
    CP1257 = 'cp1257'
    CP1258 = 'cp1258'

    UTF8 = 'utf-8'
    UTF16 = 'utf-16'
    UTF16_LE = 'utf-16-le'
    UTF16_BE = 'utf-16-be'
    UTF32 = 'utf-32'
    UTF32_LE = 'utf-32-le'
    UTF32_BE = 'utf-32-be'
    UTF7 = 'utf-7'

    SHIFT_JIS = 'shift_jis'
    EUC_JP = 'euc_jp'
    GB2312 = 'gb2312'
    GBK = 'gbk'
    GB18030 = 'gb18030'
    BIG5 = 'big5'
    EUC_KR = 'euc_kr'

    ISO8859_1 = 'iso-8859-1'
    ISO8859_2 = 'iso-8859-2'
    ISO8859_3 = 'iso-8859-3'
    ISO8859_4 = 'iso-8859-4'
    ISO8859_5 = 'iso-8859-5'
    ISO8859_6 = 'iso-8859-6'
    ISO8859_7 = 'iso-8859-7'
    ISO8859_8 = 'iso-8859-8'
    ISO8859_9 = 'iso-8859-9'
    ISO8859_13 = 'iso-8859-13'
    ISO8859_15 = 'iso-8859-15'

    ASCII = 'ascii'
    KOI8_R = 'koi8-r'
    KOI8_U = 'koi8-u'


    @property
    def codepage(self) -> int:
        mapping = {
            self.UTF8: 65001,
            self.UTF7: 65000,
            self.UTF16: 1200,
            self.UTF16_LE: 1200,
            self.UTF16_BE: 1201,
            self.UTF32: 12000,
            self.UTF32_LE: 12000,
            self.UTF32_BE: 12001,
            self.ASCII: 20127,
            self.SHIFT_JIS: 932,
            self.GB2312: 936,
            self.GBK: 936,
            self.GB18030: 54936,
            self.BIG5: 950,
            self.EUC_KR: 949,
            self.KOI8_R: 20866,
            self.KOI8_U: 21866,
        }

        if self in mapping:
            return mapping[self]

        if self.value.startswith('cp'):
            return int(self.value[2:])

        raise ValueError
