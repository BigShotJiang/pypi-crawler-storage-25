"""Step 64 — TUI shells UX: footer counter + no-flicker repaints.

Two regressions guarded here, both small enough that the operator
notices immediately when either breaks but neither has a natural
unit-test home elsewhere:

1. ``MonitorPanelModal`` repaints (refresh tick every 1.5 s) used
   to call ``ListView.clear() + append(...)`` and
   ``RichLog.clear() + write(...)`` unconditionally — which made
   the highlighted row blink and the tail flash, even on an idle
   shell. The fix wraps both repaints in a "did anything visible
   change?" guard (``_rows_signature`` for the list,
   ``(mid, header, body)`` for the output pane). This test pins
   the guard: a refresh with identical inputs MUST NOT clear the
   widgets.

2. The TUI ``#status-footer`` had no indication that background
   shells were alive — Ctrl+S / /shells was undiscoverable. The
   fix adds a ``shells <live>[+<exited>]`` segment, suppressed
   entirely at (0, 0). This test pins the count read against a
   synthetic per-session monitors.json sidecar.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_tui.app import _rows_signature  # noqa: E402


# ---------------------------------------------------------------------------
# Part 1 — repaint dedup signature
# ---------------------------------------------------------------------------

def test_rows_signature_stable_when_visible_fields_unchanged() -> None:
    """Two sidecar reads that produced the same alive/pid/id/command
    tuples must yield the same signature — that's what tells the
    modal's _refresh to skip the ListView rebuild and stop flicker."""
    rows_a = [
        {"alive": True, "pid": 1234, "monitor_id": "abc", "command": "tail -F /var/log/syslog",
         "log_path": "/tmp/abc.log"},
        {"alive": True, "pid": 5678, "monitor_id": "def", "command": "watch -n1 df -h",
         "log_path": "/tmp/def.log"},
    ]
    # log_path differs — the modal doesn't render it, so the signature
    # must NOT count it. Otherwise unrelated backend churn (e.g. log
    # rotation moving the path) would force a repaint.
    rows_b = [
        {"alive": True, "pid": 1234, "monitor_id": "abc", "command": "tail -F /var/log/syslog",
         "log_path": "/tmp/abc-rotated.log"},
        {"alive": True, "pid": 5678, "monitor_id": "def", "command": "watch -n1 df -h",
         "log_path": "/tmp/def-rotated.log"},
    ]
    assert _rows_signature(rows_a) == _rows_signature(rows_b)


def test_rows_signature_changes_on_alive_transition() -> None:
    """A monitor going alive→exited MUST flip the signature so the
    modal repaints — the dead-row class change is operator-visible."""
    base = {"pid": 9, "monitor_id": "m", "command": "sleep 1"}
    alive = [{**base, "alive": True}]
    exited = [{**base, "alive": False}]
    assert _rows_signature(alive) != _rows_signature(exited)


def test_rows_signature_changes_on_new_row() -> None:
    """A new monitor appearing in the sidecar must change the signature."""
    one = [{"alive": True, "pid": 1, "monitor_id": "a", "command": "x"}]
    two = one + [{"alive": True, "pid": 2, "monitor_id": "b", "command": "y"}]
    assert _rows_signature(one) != _rows_signature(two)


# ---------------------------------------------------------------------------
# Part 2 — footer counter reads the live sidecar
# ---------------------------------------------------------------------------

def _entry(monitor_id: str, alive_pid: int | None) -> dict[str, Any]:
    """One synthetic sidecar entry. ``alive_pid`` is the PID to record
    — pass ``os.getpid()`` to look alive, an obviously-dead high PID
    to look exited."""
    return {
        "monitor_id": monitor_id,
        "command": f"sleep 1  # {monitor_id}",
        "cwd": "/tmp",
        "pid": alive_pid if alive_pid is not None else 2_000_000_000,
        "started_at": time.time(),
        "exit_code": None,
        "log_path": f"/tmp/{monitor_id}.log",
        "read_cursor": 0,
    }


def _write_sidecar(sessions_dir: Path, sid: str, entries: list[dict[str, Any]]) -> None:
    (sessions_dir / f"{sid}.monitors.json").write_text(
        json.dumps(entries, indent=2) + "\n", encoding="utf-8",
    )


class _FakeAgentCfg:
    """Minimal stand-in for AgentConfig — only the field the helper reads."""
    def __init__(self, sessions_dir: Path) -> None:
        self.sessions_dir = str(sessions_dir)


def _make_app_stub(sessions_dir: Path, sid: str):
    """Build the bare minimum object for ``_read_shell_count`` to work
    without spinning up Textual / the ACP client. The method only
    touches ``self._sid``, ``self.agent_cfg.sessions_dir``, and the
    cache fields, so a hand-rolled namespace is sufficient and lets
    us assert behaviour without modal/runtime overhead."""
    # ``_read_shell_count`` lives on AgentChatApp (alongside
    # _refresh_status_bar) — not on the base ChatApp. Bypass __init__
    # so we don't need to spin up Textual + the ACP client just to
    # exercise a pure-Python helper.
    from rtxclaw_tui.app import AgentChatApp
    stub = AgentChatApp.__new__(AgentChatApp)
    stub._sid = sid
    stub.agent_cfg = _FakeAgentCfg(sessions_dir)
    stub._shell_count_cache = (0, 0)
    stub._shell_count_at = 0.0
    return stub


def test_read_shell_count_zero_with_no_sidecar(tmp_path: Path) -> None:
    """Fresh session, no monitors started — counter is (0, 0). The
    footer suppresses the segment in this case so the bar stays clean."""
    app = _make_app_stub(tmp_path, "fresh-sid")
    assert app._read_shell_count() == (0, 0)


def test_read_shell_count_zero_when_no_session() -> None:
    """No active session — early return as (0, 0). Guards the first-
    paint window between mount and ``_ensure_session``."""
    app = _make_app_stub(Path("/tmp"), sid=None)
    app._sid = None
    assert app._read_shell_count() == (0, 0)


def test_read_shell_count_counts_alive_and_exited(tmp_path: Path) -> None:
    """A sidecar with mixed PIDs surfaces as ``(live, exited)``. The
    footer renders ``shells L+M`` from this pair — the operator's
    only signal that exited shells are still pinned in the panel."""
    sid = "s1"
    _write_sidecar(tmp_path, sid, [
        _entry("alive1", os.getpid()),
        _entry("alive2", os.getpid()),
        _entry("dead1",  None),
    ])
    app = _make_app_stub(tmp_path, sid)
    live, exited = app._read_shell_count()
    assert (live, exited) == (2, 1)


def test_read_shell_count_caches_for_3s(tmp_path: Path) -> None:
    """The spinner ticks at ~4 Hz; the cache must hold for ~3 s so we
    don't re-read the sidecar on every paint. Validate by writing a
    second sidecar AFTER the first read — the cached value must
    persist until the TTL expires."""
    sid = "s1"
    _write_sidecar(tmp_path, sid, [_entry("a", os.getpid())])
    app = _make_app_stub(tmp_path, sid)
    assert app._read_shell_count() == (1, 0)
    # Append a second monitor — would change the count if re-read.
    _write_sidecar(tmp_path, sid, [
        _entry("a", os.getpid()),
        _entry("b", os.getpid()),
    ])
    # Within the TTL → still serves the cached (1, 0).
    assert app._read_shell_count() == (1, 0)
    # Manually expire the cache and verify the fresh read picks up the change.
    app._shell_count_at = 0.0
    assert app._read_shell_count() == (2, 0)
