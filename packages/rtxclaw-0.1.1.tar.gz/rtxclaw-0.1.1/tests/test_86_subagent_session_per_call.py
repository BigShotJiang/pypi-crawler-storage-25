"""Step 86 — a session per subagent.

A subagent is nothing more than an agent with a parent session: the
``Agent`` / ``BatchAgent`` tool path must create a FRESH child rtxclaw
session per subagent invocation (keyed by the tool call id), each
back-linked to the parent via a first-class ``parent_session_id``.

Before this change subagents were keyed by ``(parent_sid, engine_kind)``
via the ``<parent>.delegate_<engine>.json`` sidecar: a 2nd
``Agent(subagent_type="codex")`` under the same parent RESUMED the 1st
codex child session, and a batch fan-out of same-engine entries raced
on one shared session. (Observed in the logs of session
``20260520T160119297737-ba39df31132e``: the codex audit and the codex
final-review shared one child session.)

Coverage:
  * Session model carries ``parent_session_id`` (field + header + db
    column) and it round-trips through JSONL + sessions.db.
  * ``_drive_child_agent_turn`` keys a fresh session per call id and
    stamps ``parent_session_id``; the same call id resumes; absence of
    a call id keeps the slash-command per-engine resume behaviour.
  * ``_default_run_tool`` threads ``_rtxclaw_call_id`` for the subagent
    tool family; ``_shim_batch_agent`` gives each entry a unique id.
  * The existing parent↔child back-link tokens (test_80) survive.
"""

from __future__ import annotations

import inspect
import types

import pytest

from rtxclaw_core.agents import delegate_shims as ds
from rtxclaw_core.agents.engine import EngineKind, TextDelta, TurnDone


# ---------------------------------------------------------------------------
# Session model: parent_session_id is first-class + persisted
# ---------------------------------------------------------------------------


def test_session_carries_parent_session_id_in_model_and_header() -> None:
    from rtxclaw_core.session import Session

    s = Session.new(
        system_prompt="x", model="m", endpoint="e",
        parent_session_id="PARENT-123",
    )
    assert s.parent_session_id == "PARENT-123"
    assert s._header_dict().get("parent_session_id") == "PARENT-123"

    from rtxclaw_core.agents.session_log import _session_header
    assert _session_header(s).get("parent_session_id") == "PARENT-123"


def test_parent_session_id_is_a_sessions_meta_column() -> None:
    from rtxclaw_core.session_index import _SESSIONS_META_COLUMNS

    names = {n for n, _ in _SESSIONS_META_COLUMNS}
    assert "parent_session_id" in names


def test_parent_session_id_round_trips_jsonl_and_db(tmp_path) -> None:
    from rtxclaw_core import session_reader as sr
    from rtxclaw_core.session_writer import SessionWriter
    from rtxclaw_core.session_index import SessionIndex, connect_sessions_db

    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    sid = "child-sid-1"

    w = SessionWriter(sdir, sid, engine="codex_cli", flush_ms=0)
    w.session_started({
        "agent_name": "codex",
        "engine": "codex_cli",
        "parent_session_id": "PARENT-XYZ",
    })
    w.close()

    # (a) JSONL header carries the back-link.
    hdr = None
    for raw in (sdir / f"{sid}.jsonl").read_bytes().split(b"\n"):
        if not raw:
            continue
        ev = sr.decode_line(raw)
        if ev and ev.get("type") == "session_started":
            hdr = ev
    assert hdr is not None, "session_started not found in JSONL"
    assert hdr.get("parent_session_id") == "PARENT-XYZ"

    # (b) sessions.db column is populated after indexing.
    SessionIndex(home).tail(sid)
    con = connect_sessions_db(sdir / "sessions.db")
    try:
        row = con.execute(
            "SELECT parent_session_id FROM sessions_meta WHERE session_hash=?",
            (sid,),
        ).fetchone()
    finally:
        con.close()
    assert row is not None and row[0] == "PARENT-XYZ"


# ---------------------------------------------------------------------------
# Functional: _drive_child_agent_turn keys one session per subagent call
# ---------------------------------------------------------------------------


class _FakeEngine:
    kind = EngineKind.CODEX_CLI

    def is_available(self):
        return (True, "")

    def read_state(self, sdir, sid):
        return types.SimpleNamespace(engine_session_id=f"eng-{sid}")


class _FakeAgent:
    """Minimal stand-in for an rtxclaw child Agent, recording every
    ``create_session`` so the test can assert one-session-per-call."""

    def __init__(self, sessions_dir):
        self.sessions_dir = sessions_dir
        self.engine = _FakeEngine()
        self._n = 0
        self._sessions: dict = {}
        self.created: list[dict] = []

    def delegate_sidecar_path(self, parent_sid, kind):
        suffix = {
            EngineKind.CLAUDE_CLI: "delegate_claude",
            EngineKind.CODEX_CLI: "delegate_codex",
            EngineKind.ANTIGRAVITY_CLI: "delegate_antigravity",
        }.get(kind, f"delegate_{getattr(kind, 'value', kind)}")
        return self.sessions_dir / f"{parent_sid}.{suffix}.json"

    def get_session(self, sid):
        return self._sessions.get(sid)

    def create_session(self, *, workspace_cwd="", workspace_origin="",
                       parent_session_id="", **_kw):
        self._n += 1
        h = f"child-{self._n}"
        self.created.append({
            "hash": h,
            "parent_session_id": parent_session_id,
            "workspace_origin": workspace_origin,
        })
        s = types.SimpleNamespace(hash=h)
        self._sessions[h] = s
        return s

    async def run_turn(self, child_sid, prompt, *, mode=None, cwd=None, model=None):
        yield TextDelta(text=f"body[{child_sid}]", channel="content")
        yield TurnDone(state="ok")


@pytest.fixture
def fake_agent(tmp_path, monkeypatch):
    fake = _FakeAgent(tmp_path)
    monkeypatch.setattr(
        "rtxclaw_core.agents.factory.load_agent", lambda _name: fake,
    )
    return fake


@pytest.mark.asyncio
async def test_distinct_call_ids_get_distinct_sessions(fake_agent, tmp_path) -> None:
    parent = "PARENTSID"
    r1 = await ds._drive_child_agent_turn("codex", {
        "prompt": "p1", "_rtxclaw_parent_session_id": parent,
        "_rtxclaw_call_id": "call_A",
    })
    r2 = await ds._drive_child_agent_turn("codex", {
        "prompt": "p2", "_rtxclaw_parent_session_id": parent,
        "_rtxclaw_call_id": "call_B",
    })
    assert r1.ok and r2.ok
    # One fresh session per subagent invocation — NOT a shared one.
    assert len(fake_agent.created) == 2
    assert fake_agent.created[0]["hash"] != fake_agent.created[1]["hash"]
    # Each child back-links to the parent (first-class field + origin).
    for c in fake_agent.created:
        assert c["parent_session_id"] == parent
        assert c["workspace_origin"] == f"delegate:{parent}"
    # Per-call sidecars, keyed by call id (not collapsed onto one).
    assert (tmp_path / f"{parent}.subagent.call_A.delegate_codex.json").exists()
    assert (tmp_path / f"{parent}.subagent.call_B.delegate_codex.json").exists()


@pytest.mark.asyncio
async def test_same_call_id_resumes_one_session(fake_agent) -> None:
    parent = "PARENTSID"
    args = {
        "prompt": "p", "_rtxclaw_parent_session_id": parent,
        "_rtxclaw_call_id": "call_A",
    }
    await ds._drive_child_agent_turn("codex", dict(args))
    await ds._drive_child_agent_turn("codex", dict(args))
    # A retry of the SAME subagent call resumes its session.
    assert len(fake_agent.created) == 1


@pytest.mark.asyncio
async def test_no_call_id_keeps_per_engine_resume(fake_agent, tmp_path) -> None:
    # Slash-command path (/codex): no call id → per-engine sidecar →
    # the continuing-conversation session is reused across turns.
    parent = "PARENTSID"
    await ds._drive_child_agent_turn(
        "codex", {"prompt": "p", "_rtxclaw_parent_session_id": parent},
    )
    await ds._drive_child_agent_turn(
        "codex", {"prompt": "p2", "_rtxclaw_parent_session_id": parent},
    )
    assert len(fake_agent.created) == 1
    assert (tmp_path / f"{parent}.delegate_codex.json").exists()
    # Even the slash-command child gets the first-class parent link.
    assert fake_agent.created[0]["parent_session_id"] == parent


# ---------------------------------------------------------------------------
# Dispatch threading: the call id reaches the shim
# ---------------------------------------------------------------------------


def test_default_run_tool_threads_call_id_for_subagent_family() -> None:
    from rtxclaw_agent import acp_bridge

    src = inspect.getsource(acp_bridge._default_run_tool)
    assert "_rtxclaw_call_id" in src
    # Scoped to the subagent tool family so other tool args stay stable.
    assert '"Agent"' in src and '"BatchAgent"' in src


def test_batch_agent_gives_each_entry_a_unique_call_id() -> None:
    from rtxclaw_core.tools.runners import _shim_batch_agent

    src = inspect.getsource(_shim_batch_agent)
    assert "_rtxclaw_call_id" in src
    # Per-entry id derived from the batch id (e.g. f"{batch_cid}.{i}").
    assert "_entry_args" in src


def test_drive_child_agent_turn_keys_per_call_and_stamps_parent() -> None:
    src = inspect.getsource(ds._drive_child_agent_turn)
    assert "_rtxclaw_call_id" in src
    assert "parent_session_id=parent_sid" in src
    # Back-link tokens that test_80 also pins must survive.
    assert "delegate:{parent_sid}" in src
    assert "rtxclaw_child_session_id" in src
    assert "engine_session_id" in src
    assert "parent_sid[:12]" not in src
