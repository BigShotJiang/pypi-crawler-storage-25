"""Step 88 — memory-synth failure backoff + log dedup.

Regression cover for the heartbeat synth storm (2026-05-21): a
misconfigured upstream key made ``_maybe_synthesize_memory`` re-hit the
synth LLM EVERY tick and log the identical error verbatim — 38 copies
of ``memory: synth error: http: HTTPStatusError: ... 401 Unauthorized``
in one day. The scheduler now backs off exponentially after a failure
and logs each distinct error once.

Pure in-process: the helper math is tested directly; the integration
test injects a fake ``synth_memory`` + records ``_log`` — no LLM, no
network, no daemons.
"""
from __future__ import annotations

import asyncio
import time
import types

from rtxclaw_agent.heartbeat import (
    HeartbeatScheduler,
    _SYNTH_MAX_BACKOFF_TICKS,
    _synth_backoff_decision,
)


# ---------------------------------------------------------------------------
# pure policy helper
# ---------------------------------------------------------------------------

def test_backoff_logs_first_error_and_sets_cooldown() -> None:
    streak, last, cooldown, should_log = _synth_backoff_decision(
        now=1000.0, interval_s=60.0,
        fail_streak=0, last_error=None, new_error="boom",
    )
    assert streak == 1
    assert last == "boom"
    assert should_log is True
    # First failure → 2**0 == 1 tick of cooldown.
    assert cooldown == 1000.0 + 1 * 60.0


def test_backoff_dedups_identical_error() -> None:
    _, _, _, should_log = _synth_backoff_decision(
        now=0.0, interval_s=60.0,
        fail_streak=3, last_error="same", new_error="same",
    )
    assert should_log is False


def test_backoff_logs_when_error_changes() -> None:
    _, _, _, should_log = _synth_backoff_decision(
        now=0.0, interval_s=60.0,
        fail_streak=3, last_error="old", new_error="new",
    )
    assert should_log is True


def test_backoff_is_capped() -> None:
    # A huge streak must not produce an unbounded cooldown.
    _, _, cooldown, _ = _synth_backoff_decision(
        now=0.0, interval_s=1.0,
        fail_streak=40, last_error="x", new_error="x",
    )
    assert cooldown == _SYNTH_MAX_BACKOFF_TICKS * 1.0


# ---------------------------------------------------------------------------
# integration: cooldown skips the LLM + dedups the log line
# ---------------------------------------------------------------------------

def _make_scheduler(tmp_path):
    cfg = types.SimpleNamespace(
        home=tmp_path,
        upstream_endpoint="http://stub/v1",
        upstream_model="stub-model",
        memory_synth_enabled=True,
        heartbeat_interval_s=1000,
    )
    sched = HeartbeatScheduler(cfg, app=None)
    logs: list[str] = []
    sched._log = logs.append  # type: ignore[method-assign]
    return sched, logs


def test_persistent_401_logs_once_and_backs_off(tmp_path, monkeypatch) -> None:
    sched, logs = _make_scheduler(tmp_path)

    calls = {"n": 0}

    async def _fake_synth(home, *, upstream_endpoint, upstream_model):
        calls["n"] += 1
        return {
            "ok": False,
            "error": "http: HTTPStatusError: 401 Unauthorized",
        }

    import rtxclaw_memory.memory_synth as ms
    monkeypatch.setattr(ms, "synth_memory", _fake_synth)

    async def _go():
        for _ in range(3):
            await sched._maybe_synthesize_memory()

    asyncio.run(_go())

    # First tick called the synth + logged once; the next two ticks were
    # inside the cooldown window, so the LLM was NOT re-hit and no extra
    # log line was emitted.
    assert calls["n"] == 1, f"synth should be hit once, not {calls['n']}x"
    assert len(logs) == 1, f"identical error must log once; got {logs!r}"
    assert "401 Unauthorized" in logs[0]
    assert sched._synth_fail_streak == 1
    assert sched._synth_cooldown_until > time.monotonic()


def test_success_resets_failure_state(tmp_path, monkeypatch) -> None:
    sched, logs = _make_scheduler(tmp_path)
    # Pretend we'd failed before and are currently OUT of cooldown.
    sched._synth_fail_streak = 5
    sched._synth_last_error = "old error"
    sched._synth_cooldown_until = 0.0

    async def _fake_synth(home, *, upstream_endpoint, upstream_model):
        return {"ok": True, "changed": False, "reason": "no new dailies",
                "duration_s": 0.01}

    import rtxclaw_memory.memory_synth as ms
    monkeypatch.setattr(ms, "synth_memory", _fake_synth)

    asyncio.run(sched._maybe_synthesize_memory())

    assert sched._synth_fail_streak == 0
    assert sched._synth_last_error is None
    assert sched._synth_cooldown_until == 0.0
