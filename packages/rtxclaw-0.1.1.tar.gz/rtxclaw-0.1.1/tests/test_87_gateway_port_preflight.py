"""Step 87 — gateway pre-flight port guard.

Regression cover for the "zombie gateway" pathology (2026-05-21): a
restart racing the predecessor's socket drain (or an accidental
double-start) made hypercorn's bind raise ``OSError(98)`` *inside* the
serve task. The exception was never retrieved, the process kept awaiting
``stop_event`` as a non-serving zombie, and it had already overwritten
the pidfile to point at itself — 14 such crashes in one day's gateway
log.

``serve_gateway`` now pre-flights the port via ``_await_port_free``
before writing the pidfile / scheduling the serve task: it waits briefly
for a draining predecessor to release the socket and refuses to start
(leaving the existing pidfile intact) if it stays held.

These tests drive ``_await_port_free`` directly with an injected
holder function + no-op sleep, so they're pure in-process — no real
sockets, no daemons, no ``pgrep``/``kill``.

The pre-flight only NARROWS the race, though: hypercorn still binds
inside the serve task, so a bind ``OSError(98)`` can still fire there
after the check (or in a double-start race). ``_await_serve_or_stop``
guards that residual window — the tests at the bottom of this file drive
it directly: a serve task raising ``OSError(98)`` returns the exception
(no hang), while a normal stop returns ``None``.
"""
from __future__ import annotations

import asyncio

from rtxclaw_agent.gateway import _await_port_free


async def _noop_sleep(_seconds: float) -> None:
    return None


def test_port_free_from_start_returns_none() -> None:
    """No listener ever holds the port → returns None immediately."""
    def _holder(_host: str, _port: int):
        return None

    out = asyncio.run(
        _await_port_free("127.0.0.1", 7700, 5.0,
                         holder_fn=_holder, sleep=_noop_sleep)
    )
    assert out is None


def test_port_frees_within_window() -> None:
    """A draining predecessor releases the socket mid-wait → returns
    None once the holder disappears (the restart-race happy path)."""
    state = {"polls": 0}

    def _holder(_host: str, _port: int):
        state["polls"] += 1
        # Held for the first two polls, free afterwards.
        return 4242 if state["polls"] <= 2 else None

    out = asyncio.run(
        _await_port_free("127.0.0.1", 7700, 5.0,
                         holder_fn=_holder, sleep=_noop_sleep)
    )
    assert out is None
    assert state["polls"] >= 3, "should have re-polled until the port freed"


def test_port_held_past_timeout_returns_holder_pid() -> None:
    """The port never frees → returns the holding pid so the caller can
    refuse to start and leave the live holder's pidfile intact."""
    def _holder(_host: str, _port: int):
        return 9999

    out = asyncio.run(
        _await_port_free("127.0.0.1", 7700, 0.0,
                         holder_fn=_holder, sleep=_noop_sleep)
    )
    assert out == 9999


def test_other_user_sentinel_propagates() -> None:
    """``-1`` (port held by another user — pid not visible) is surfaced
    verbatim rather than being treated as free."""
    def _holder(_host: str, _port: int):
        return -1

    out = asyncio.run(
        _await_port_free("127.0.0.1", 7700, 0.0,
                         holder_fn=_holder, sleep=_noop_sleep)
    )
    assert out == -1


# --- _await_serve_or_stop: the serve-task-failure path -------------------
#
# The pre-flight only narrows the zombie window; hypercorn still binds
# inside the serve task, so a bind OSError(98) can fire there after the
# check (or in a double-start race). _await_serve_or_stop must surface
# that failure instead of hanging forever on stop_event — these tests
# exercise that seam directly (no real sockets / daemons).
import contextlib  # noqa: E402

from rtxclaw_agent.gateway import _await_serve_or_stop  # noqa: E402


def test_serve_task_failure_returns_exception_without_hanging() -> None:
    """A serve task that dies with OSError(98) → the helper returns that
    exception (so the caller exits non-zero) rather than awaiting
    stop_event forever as a non-serving zombie."""
    async def _run():
        async def _boom():
            raise OSError(98, "Address already in use")
        hc = asyncio.create_task(_boom())
        stop = asyncio.Event()  # never set — only the serve failure ends it
        return await asyncio.wait_for(
            _await_serve_or_stop(hc, stop), timeout=2.0,
        )

    exc = asyncio.run(_run())
    assert isinstance(exc, OSError) and exc.errno == 98


def test_stop_event_returns_none_while_serving() -> None:
    """A normal stop (stop_event set) returns None even though the serve
    task is still running — the clean-shutdown path."""
    async def _run():
        async def _serve_forever():
            await asyncio.Event().wait()  # runs until cancelled
        hc = asyncio.create_task(_serve_forever())
        stop = asyncio.Event()
        stop.set()
        try:
            return await asyncio.wait_for(
                _await_serve_or_stop(hc, stop), timeout=2.0,
            )
        finally:
            hc.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await hc

    assert asyncio.run(_run()) is None
