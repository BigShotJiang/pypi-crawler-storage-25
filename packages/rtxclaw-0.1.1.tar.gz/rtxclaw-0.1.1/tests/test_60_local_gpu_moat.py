"""Step 60 — local-GPU moat: detect → select → auto-wire.

Pure-function unit tests (no real nvidia-smi, no network) for
:mod:`rtxclaw_core.local_gpu`, the "one command and you're chatting with
your own GPU" path. The behaviours that matter:

- detection degrades to "no GPU" on any nvidia-smi failure (so a GPU-less
  box cleanly falls back to the cloud default);
- the GPU profile → model table returns the recommended models for the
  known cards and a VRAM-class heuristic for everything else;
- :func:`auto_local_setup` is GPU-GATED — it must return None when there's
  no GPU even if some OpenAI-compatible server happens to answer locally
  (e.g. a routing proxy), and it must pick the right context window from
  the table on the detect-first path.
"""
from __future__ import annotations

import subprocess

from rtxclaw_core import local_gpu as lg


# ---- helpers -------------------------------------------------------------

def _profile(name: str, count: int, vram_mib: int) -> lg.GpuProfile:
    return lg.GpuProfile(gpus=tuple(lg.GpuInfo(name, vram_mib) for _ in range(count)))


class _FakeRun:
    def __init__(self, stdout: str, returncode: int = 0):
        self.stdout = stdout
        self.returncode = returncode


# ---- detection -----------------------------------------------------------

def test_detect_gpus_empty_without_nvidia_smi(monkeypatch):
    monkeypatch.setattr(lg.shutil, "which", lambda _x: None)
    assert lg.detect_gpus() == []
    assert lg.gpu_profile() is None


def test_detect_gpus_parses_csv(monkeypatch):
    monkeypatch.setattr(lg.shutil, "which", lambda _x: "/usr/bin/nvidia-smi")
    monkeypatch.setattr(
        lg.subprocess, "run",
        lambda *a, **k: _FakeRun("NVIDIA GeForce RTX 5090, 32607\n"
                                 "NVIDIA GeForce RTX 5090, 32607\n"),
    )
    gpus = lg.detect_gpus()
    assert [g.name for g in gpus] == ["NVIDIA GeForce RTX 5090"] * 2
    assert gpus[0].vram_mib == 32607
    p = lg.gpu_profile()
    assert p is not None and p.count == 2
    assert p.total_vram_gib == round(2 * 32607 / 1024, 1)
    assert "RTX 5090" in p.short_name() and p.short_name().startswith("2×")


def test_detect_gpus_handles_nonzero_exit(monkeypatch):
    monkeypatch.setattr(lg.shutil, "which", lambda _x: "/usr/bin/nvidia-smi")
    monkeypatch.setattr(lg.subprocess, "run",
                        lambda *a, **k: _FakeRun("", returncode=9))
    assert lg.detect_gpus() == []


def test_detect_gpus_swallows_subprocess_error(monkeypatch):
    monkeypatch.setattr(lg.shutil, "which", lambda _x: "/usr/bin/nvidia-smi")

    def _boom(*a, **k):
        raise subprocess.SubprocessError("boom")

    monkeypatch.setattr(lg.subprocess, "run", _boom)
    assert lg.detect_gpus() == []


# ---- table + heuristic ---------------------------------------------------

def test_table_returns_recommended_models():
    # House model = Qwen3.6-27B; each GPU family → a different DOWNLOADABLE
    # quant + serving recipe per GPU family.
    g5090 = lg.select_model_for_profile(_profile("NVIDIA GeForce RTX 5090", 2, 32607))
    assert g5090.model_id == "Qwen/Qwen3.6-27B-FP8" and g5090.context_window == 262_144
    assert g5090.tool_parser == "qwen3_coder" and g5090.reasoning_parser == "qwen3"
    # Ampere 3090 (no fp8) → the downloadable AWQ-Int4 build, qwen3_xml parser.
    g3090 = lg.select_model_for_profile(_profile("NVIDIA GeForce RTX 3090", 2, 24576))
    assert g3090.model_id == "cyankiwi/Qwen3.6-27B-AWQ-BF16-INT4"
    assert g3090.context_window == 96_000 and g3090.tool_parser == "qwen3_xml"
    pro = lg.select_model_for_profile(
        _profile("NVIDIA RTX PRO 6000 Blackwell Max-Q", 1, 98304))
    assert pro.model_id == "Qwen/Qwen3.6-27B-FP8" and pro.tool_parser == "qwen3_coder"


def test_each_gpu_profile_has_its_own_recipe():
    # 2×5090: fp8, qwen3_coder, FlashAttn-2, NO custom-all-reduce disable.
    g5090 = lg.select_model_for_profile(_profile("NVIDIA GeForce RTX 5090", 2, 32607))
    assert dict(g5090.env).get("VLLM_FLASH_ATTN_VERSION") == "2"
    a5090 = lg._vllm_capability_args(g5090, tp=2)
    assert "--disable-custom-all-reduce" not in a5090
    assert a5090[a5090.index("--tool-call-parser") + 1] == "qwen3_coder"
    # 2×3090: AWQ, qwen3_xml, max-num-seqs 2 + custom-all-reduce disabled.
    g3090 = lg.select_model_for_profile(_profile("NVIDIA GeForce RTX 3090", 2, 24576))
    assert dict(g3090.env).get("NCCL_P2P_DISABLE") == "1"
    a3090 = lg._vllm_capability_args(g3090, tp=2)
    assert "--disable-custom-all-reduce" in a3090 and "--max-num-seqs" in a3090
    assert a3090[a3090.index("--tool-call-parser") + 1] == "qwen3_xml"
    # the two configs are genuinely different
    assert g5090.model_id != g3090.model_id and a5090 != a3090


def test_heuristic_qwen25_uses_hermes_no_reasoning():
    c = lg.select_model_for_profile(_profile("NVIDIA RTX 4090", 1, 24576))
    assert "Qwen2.5" in c.model_id
    assert c.tool_parser == "hermes" and c.reasoning_parser == ""


def test_heuristic_for_unknown_card_scales_with_vram():
    big = lg.select_model_for_profile(_profile("NVIDIA H100", 2, 81920))   # 160 GiB
    assert "72B" in big.model_id
    mid = lg.select_model_for_profile(_profile("NVIDIA RTX 4090", 1, 24576))  # 24 GiB
    assert "7B" in mid.model_id
    tiny = lg.select_model_for_profile(_profile("NVIDIA RTX 3050", 1, 4096))  # 4 GiB
    assert tiny is None  # too small to serve anything sensible


# ---- probe ---------------------------------------------------------------

class _FakeResp:
    def __init__(self, status, payload):
        self.status_code = status
        self._payload = payload

    def json(self):
        return self._payload


def test_probe_returns_first_live_server(monkeypatch):
    def fake_get(url, timeout=0):
        if "127.0.0.1:8000" in url:
            return _FakeResp(200, {"data": [{"id": "qwen3.6-27b-fp8"}]})
        raise lg.httpx.HTTPError("refused")

    monkeypatch.setattr(lg.httpx, "get", fake_get)
    srv = lg.probe_local_server(timeout=0.1)
    assert srv is not None
    assert srv.model_id == "qwen3.6-27b-fp8"
    assert srv.base_url == "http://127.0.0.1:8000/v1"


def test_probe_returns_none_when_nothing_listens(monkeypatch):
    monkeypatch.setattr(lg.httpx, "get",
                        lambda *a, **k: (_ for _ in ()).throw(lg.httpx.HTTPError("x")))
    assert lg.probe_local_server(timeout=0.1) is None


# ---- orchestrator: GPU-gated -------------------------------------------

def test_auto_setup_none_without_gpu_even_if_server_answers(monkeypatch):
    # The critical invariant: a routing proxy on :8000 must NOT make a
    # GPU-less box claim a local model.
    monkeypatch.setattr(lg, "gpu_profile", lambda: None)
    monkeypatch.setattr(
        lg, "probe_local_server",
        lambda *a, **k: lg.LocalServer("http://127.0.0.1:8000/v1", "x", "vllm"))
    assert lg.auto_local_setup() is None


def test_auto_setup_detect_first_uses_table_context_window(monkeypatch):
    monkeypatch.setattr(lg, "gpu_profile",
                        lambda: _profile("NVIDIA GeForce RTX 5090", 2, 32607))
    monkeypatch.setattr(
        lg, "probe_local_server",
        lambda *a, **k: lg.LocalServer("http://127.0.0.1:8000/v1",
                                       "qwen3.6-27b-fp8", "vllm"))
    setup = lg.auto_local_setup()
    assert setup is not None
    assert setup.provisioned is False
    assert setup.row["contextWindow"] == 262_144   # from the table, not default
    assert setup.row["baseUrl"] == "http://127.0.0.1:8000/v1"
    assert setup.row["apiKeyEnv"] == ""            # local: no key
    assert setup.row["backend"] == "vllm"


def test_auto_setup_skips_provision_when_disabled(monkeypatch):
    monkeypatch.setattr(lg, "gpu_profile",
                        lambda: _profile("NVIDIA GeForce RTX 4090", 1, 24576))
    monkeypatch.setattr(lg, "probe_local_server", lambda *a, **k: None)
    called = {"provision": False}
    monkeypatch.setattr(lg, "provision_model",
                        lambda *a, **k: called.__setitem__("provision", True))
    assert lg.auto_local_setup(allow_provision=False) is None
    assert called["provision"] is False


def test_auto_setup_cold_provision_caps_context(monkeypatch):
    monkeypatch.setattr(lg, "gpu_profile",
                        lambda: _profile("NVIDIA GeForce RTX 5090", 2, 32607))
    monkeypatch.setattr(lg, "probe_local_server", lambda *a, **k: None)
    monkeypatch.setattr(
        lg, "provision_model",
        lambda *a, **k: lg.LocalServer("http://127.0.0.1:8000/v1",
                                       "Qwen/Qwen2.5-32B-Instruct", "vllm"))
    setup = lg.auto_local_setup(allow_provision=True)
    assert setup is not None and setup.provisioned is True
    # table ctx for dual-5090 is 262144, but a fresh serve is capped to 32k.
    assert setup.row["contextWindow"] == 32_768
    assert setup.row["id"] == "Qwen/Qwen2.5-32B-Instruct"


# ---- cold-start: model id must be downloadable -------------------------

def test_provision_model_id_pins_env(monkeypatch):
    monkeypatch.setenv("RTXCLAW_PROVISION_MODEL", "meta-llama/Llama-3.1-8B-Instruct")
    p = _profile("NVIDIA GeForce RTX 3090", 2, 24576)
    choice = lg.select_model_for_profile(p)  # table id has no "/"
    assert lg._provision_model_id(choice, p) == "meta-llama/Llama-3.1-8B-Instruct"


def test_provision_model_id_swaps_local_only_id_for_public(monkeypatch):
    monkeypatch.delenv("RTXCLAW_PROVISION_MODEL", raising=False)
    # A choice carrying a non-downloadable local-only id (no "/") must be
    # swapped for the public VRAM-heuristic id at provision time.
    p = _profile("NVIDIA GeForce RTX 5090", 2, 32607)
    local = lg.ModelChoice("qwen3.6-27b-local", "vllm", 262_144, "local weights")
    pid = lg._provision_model_id(local, p)
    assert pid.startswith("Qwen/") and "/" in pid  # → downloadable heuristic id


def test_provision_model_id_uses_real_hf_table_id_for_ampere(monkeypatch):
    # 3090 entry is now a real HF repo → provisioned as-is, not swapped.
    monkeypatch.delenv("RTXCLAW_PROVISION_MODEL", raising=False)
    p = _profile("NVIDIA GeForce RTX 3090", 2, 24576)
    choice = lg.select_model_for_profile(p)
    assert lg._provision_model_id(choice, p) == "cyankiwi/Qwen3.6-27B-AWQ-BF16-INT4"


def test_provision_model_id_keeps_real_hf_id(monkeypatch):
    monkeypatch.delenv("RTXCLAW_PROVISION_MODEL", raising=False)
    p = _profile("NVIDIA GeForce RTX 3060", 2, 12288)
    choice = lg.select_model_for_profile(p)       # already a Qwen/… id
    assert lg._provision_model_id(choice, p) == choice.model_id


# ---- cold-start: vLLM launcher discovery -------------------------------

def test_resolve_vllm_launch_prefers_env_bin(monkeypatch, tmp_path):
    binp = tmp_path / "vllm"
    binp.write_text("#!/bin/sh\n")
    monkeypatch.setenv("RTXCLAW_VLLM_BIN", str(binp))
    assert lg._resolve_vllm_launch("X/Y")[:2] == [str(binp), "serve"]


def test_resolve_vllm_launch_uses_path(monkeypatch):
    monkeypatch.delenv("RTXCLAW_VLLM_BIN", raising=False)
    monkeypatch.setattr(lg.shutil, "which", lambda x: "/usr/bin/vllm" if x == "vllm" else None)
    assert lg._resolve_vllm_launch("X/Y") == ["/usr/bin/vllm", "serve", "X/Y"]


def test_resolve_vllm_launch_none_when_absent(monkeypatch):
    monkeypatch.delenv("RTXCLAW_VLLM_BIN", raising=False)
    monkeypatch.setattr(lg.shutil, "which", lambda x: None)
    monkeypatch.setattr(lg, "_module_available", lambda m: False)
    assert lg._resolve_vllm_launch("X/Y") is None


def test_vllm_capability_args_uses_choice_recipe():
    fp8 = lg.ModelChoice("Qwen/Qwen3.6-27B-FP8", "vllm", 262_144, "",
                         tool_parser="qwen3_coder", reasoning_parser="qwen3")
    a = lg._vllm_capability_args(fp8, tp=2)
    assert "--enable-auto-tool-choice" in a
    assert a[a.index("--tool-call-parser") + 1] == "qwen3_coder"
    assert a[a.index("--reasoning-parser") + 1] == "qwen3"
    assert "--disable-custom-all-reduce" in a       # tp>1
    # AWQ build → qwen3_xml
    awq = lg.ModelChoice("cyankiwi/Qwen3.6-27B-AWQ-BF16-INT4", "vllm", 96_000, "",
                         tool_parser="qwen3_xml", reasoning_parser="qwen3")
    assert lg._vllm_capability_args(awq, tp=2)[2] == "qwen3_xml"
    # Qwen2.5 single-GPU → hermes tool parser, no reasoning, no all-reduce flag
    h = lg.ModelChoice("Qwen/Qwen2.5-7B-Instruct", "vllm", 32_768, "",
                       tool_parser="hermes", reasoning_parser="")
    b = lg._vllm_capability_args(h, tp=1)
    assert b == ["--enable-auto-tool-choice", "--tool-call-parser", "hermes"]


def test_attach_uses_live_max_model_len(monkeypatch):
    # When the running server reports max_model_len, the saved row uses it
    # (faithful to the box's live config) over the table default.
    monkeypatch.setattr(lg, "gpu_profile",
                        lambda: _profile("NVIDIA GeForce RTX 5090", 2, 32607))
    monkeypatch.setattr(
        lg, "probe_local_server",
        lambda *a, **k: lg.LocalServer("http://127.0.0.1:8000/v1",
                                       "qwen3.6-27b-fp8", "vllm",
                                       max_model_len=262_144))
    setup = lg.auto_local_setup()
    assert setup.row["contextWindow"] == 262_144


def test_vllm_env_forces_nccl_settings_on_multigpu(monkeypatch):
    monkeypatch.delenv("NCCL_P2P_DISABLE", raising=False)
    e = lg._vllm_env(tp=2)
    assert e["NCCL_P2P_DISABLE"] == "1"
    assert e["VLLM_WORKER_MULTIPROC_METHOD"] == "spawn"
    # single GPU: don't impose multi-GPU NCCL tweaks
    monkeypatch.delenv("NCCL_P2P_DISABLE", raising=False)
    assert "NCCL_P2P_DISABLE" not in lg._vllm_env(tp=1)


def test_progress_bar_renders_percent_and_gb():
    gb = 1024 ** 3
    s = lg._progress_bar(int(8 * gb), int(16 * gb))
    assert "50%" in s and "8.0/16.0 GB" in s and "█" in s and "░" in s
    full = lg._progress_bar(int(16 * gb), int(16 * gb))
    assert "100%" in full and "░" not in full
    # unknown total → GB-only, no crash, no divide-by-zero
    assert "3.0 GB" in lg._progress_bar(int(3 * gb), None)
    assert "3.0 GB" in lg._progress_bar(int(3 * gb), 0)


def test_provision_marker_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(lg, "_marker_path", lambda: str(tmp_path / "provisioning.json"))
    assert lg.read_provision_marker() is None
    lg.write_provision_marker("a/b", "http://127.0.0.1:8000/v1", "b")
    m = lg.read_provision_marker()
    assert m and m["repo"] == "a/b" and m["state"] == "provisioning"
    lg.mark_provision_error("boom")
    assert lg.read_provision_marker()["state"] == "error"
    assert lg.read_provision_marker()["error"] == "boom"
    lg.clear_provision_marker()
    assert lg.read_provision_marker() is None


def test_provision_status_phases(tmp_path, monkeypatch):
    monkeypatch.setattr(lg, "_marker_path", lambda: str(tmp_path / "m.json"))
    monkeypatch.setattr(lg, "_hf_cache_path", lambda r: str(tmp_path))
    lg._TOTAL_CACHE.clear()
    assert lg.provision_status() is None            # no marker → nothing in flight
    lg.write_provision_marker("cyankiwi/X", "http://127.0.0.1:8000/v1", "x")

    monkeypatch.setattr(lg, "_server_model", lambda b: None)
    monkeypatch.setattr(lg, "_hf_total_bytes", lambda r: 100)
    monkeypatch.setattr(lg, "_dir_bytes", lambda p: 0)
    assert lg.provision_status()["phase"] == "starting"
    lg._TOTAL_CACHE.clear()
    monkeypatch.setattr(lg, "_dir_bytes", lambda p: 50)
    assert lg.provision_status()["phase"] == "downloading"
    lg._TOTAL_CACHE.clear()
    monkeypatch.setattr(lg, "_dir_bytes", lambda p: 100)
    assert lg.provision_status()["phase"] == "loading"
    monkeypatch.setattr(lg, "_server_model", lambda b: "x")
    st = lg.provision_status()
    assert st["phase"] == "ready" and st["server_up"] is True


def test_hf_cache_path_maps_repo(monkeypatch):
    monkeypatch.delenv("HF_HOME", raising=False)
    p = lg._hf_cache_path("cyankiwi/Qwen3.6-27B-AWQ-BF16-INT4")
    assert p.endswith("hub/models--cyankiwi--Qwen3.6-27B-AWQ-BF16-INT4")
    monkeypatch.setenv("HF_HOME", "/tmp/hf")
    assert lg._hf_cache_path("a/b") == "/tmp/hf/hub/models--a--b"


def test_model_cached_detection(tmp_path, monkeypatch):
    cache = tmp_path / "models--a--b"
    monkeypatch.setattr(lg, "_hf_cache_path", lambda r: str(cache))
    assert lg._model_cached("a/b") is False              # nothing on disk
    snap = cache / "snapshots" / "rev"
    snap.mkdir(parents=True)
    (snap / "model.safetensors").write_bytes(b"weights")
    assert lg._model_cached("a/b") is True               # complete weights, no .incomplete
    blobs = cache / "blobs"
    blobs.mkdir()
    (blobs / "abc.incomplete").write_bytes(b"partial")
    assert lg._model_cached("a/b") is False              # in-progress download
    assert lg._has_incomplete(str(cache)) is True


def test_python_for_vllm_prefers_312(monkeypatch):
    monkeypatch.setattr(lg.shutil, "which",
                        lambda x: "/usr/bin/python3.12" if x == "python3.12" else None)
    assert lg._python_for_vllm() == "/usr/bin/python3.12"


def test_ensure_vllm_launch_returns_existing(monkeypatch):
    monkeypatch.setattr(lg, "_resolve_vllm_launch",
                        lambda mid: ["/usr/bin/vllm", "serve", mid])
    # already-available vLLM → never installs
    monkeypatch.setattr(lg, "_python_for_vllm",
                        lambda: (_ for _ in ()).throw(AssertionError("should not install")))
    assert lg._ensure_vllm_launch("X/Y", allow_install=True) == ["/usr/bin/vllm", "serve", "X/Y"]


def test_ensure_vllm_launch_no_install_when_disallowed(monkeypatch):
    monkeypatch.setattr(lg, "_resolve_vllm_launch", lambda mid: None)
    called = {"py": False}
    monkeypatch.setattr(lg, "_python_for_vllm",
                        lambda: called.__setitem__("py", True) or "/usr/bin/python3.12")
    assert lg._ensure_vllm_launch("X/Y", allow_install=False) is None
    assert called["py"] is False  # didn't even look for a python to install with


def test_provision_commits_to_vllm_no_ollama_hijack(monkeypatch):
    # When vLLM is available, a launch failure must NOT silently fall to a
    # different/smaller model via ollama (that broke "best model").
    p = _profile("NVIDIA GeForce RTX 3090", 2, 24576)
    choice = lg.select_model_for_profile(p)
    monkeypatch.setattr(lg, "_ensure_vllm_launch",
                        lambda mid, allow_install: ["vllm", "serve", mid])
    monkeypatch.setattr(lg, "_launch_vllm", lambda *a, **k: None)  # launch fails
    hijacked = {"ollama": False}
    monkeypatch.setattr(lg.shutil, "which",
                        lambda x: "/usr/bin/ollama" if x == "ollama" else None)
    monkeypatch.setattr(lg, "_launch_ollama",
                        lambda c: hijacked.__setitem__("ollama", True))
    assert lg.provision_model(choice, p) is None
    assert hijacked["ollama"] is False


def test_provision_uses_ollama_only_when_vllm_unavailable(monkeypatch):
    p = _profile("NVIDIA RTX 4090", 1, 24576)
    choice = lg.select_model_for_profile(p)
    monkeypatch.setattr(lg, "_ensure_vllm_launch", lambda mid, allow_install: None)
    monkeypatch.setattr(lg.shutil, "which",
                        lambda x: "/usr/bin/ollama" if x == "ollama" else None)
    monkeypatch.setattr(lg, "_launch_ollama",
                        lambda c: lg.LocalServer("http://127.0.0.1:11434/v1",
                                                 "qwen3", "ollama"))
    srv = lg.provision_model(choice, p)
    assert srv is not None and srv.backend == "ollama"
