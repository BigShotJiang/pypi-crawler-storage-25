"""Step 22 — ``/plugin`` end-to-end (TUI driven via tmux + Telegram parity).

Goal: prove the ``/plugin`` slash command is wired up so an operator
can *search* the marketplace and *install* a plugin (skills /
commands / hooks / MCP) from inside both the TUI and the Telegram
bot. The TUI surface is driven through a real ``tmux`` session
(same harness as ``test_05_tui_smoke`` / ``test_11_tui_commands``) so
we exercise the actual rendering path the operator sees.

The marketplace search step uses the curated built-in registry in
``rtxclaw_core.plugins._BUILTIN_MARKETPLACE`` (so the test works
offline). The install step uses a local fixture plugin built inside
the test ``tmp_path`` — local-path install is ``shutil.copytree``,
which is hermetic and doesn't require ``git`` reachability.

Both halves of the goal — ``/plugin search`` and ``/plugin install``
— land their results in the TUI transcript, so we ``capture-pane``
and assert on the rendered text rather than on internal state.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

import pytest

from conftest import RTXCLAW_BIN


# Per-test @pytest.mark.slow below — file is mixed (4 tmux-driven slow
# tests + 1 pure-unit marketplace-name-resolution test). File-level
# pytestmark would exile the unit test to tier-3 along with the others.

SCROLL = 4000
SETTLE_TIMEOUT_S = 30.0


# --------------------------------------------------------------------------
# tmux helpers (parallel to test_11's helpers — duplicated rather than
# re-imported because pytest's collection order doesn't guarantee
# test_11 has been loaded; keeping this file self-contained makes
# ``pytest tests/test_22_plugin_command.py`` a one-stop reproducer).
# --------------------------------------------------------------------------


def _capture(session: str, scrollback: int = SCROLL) -> str:
    cp = subprocess.run(
        ["tmux", "capture-pane", "-t", session, "-p", "-J",
         "-S", f"-{scrollback}"],
        capture_output=True, text=True, timeout=10,
    )
    return cp.stdout if cp.returncode == 0 else ""


def _send_text(session: str, text: str) -> None:
    subprocess.run(
        ["tmux", "send-keys", "-t", session, text], check=True,
    )
    time.sleep(0.2)
    subprocess.run(
        ["tmux", "send-keys", "-t", session, "Enter"], check=True,
    )


def _wait_chrome(session: str, timeout: float = 30.0) -> str:
    """Block until the TUI footer is rendered (``mode:`` token)."""
    deadline = time.time() + timeout
    pane = ""
    while time.time() < deadline:
        pane = _capture(session)
        if "mode:" in pane.lower():
            return pane
        time.sleep(0.4)
    return pane


def _wait_for_text(
    session: str, needle: str, *, timeout: float = SETTLE_TIMEOUT_S,
) -> str:
    """Send-then-poll-pane helper. The ``/plugin`` handler is a
    local TUI command (no model round-trip), so the response should
    land within a couple seconds — but we poll up to ``timeout`` to
    keep this resilient on a busy box.
    """
    deadline = time.time() + timeout
    pane = ""
    while time.time() < deadline:
        pane = _capture(session)
        if needle.lower() in pane.lower():
            return pane
        time.sleep(0.4)
    return pane


def _send_and_wait_for(
    session: str, text: str, needle: str,
    *, timeout: float = SETTLE_TIMEOUT_S,
) -> str:
    _send_text(session, text)
    return _wait_for_text(session, needle, timeout=timeout)


# --------------------------------------------------------------------------
# fixtures
# --------------------------------------------------------------------------


@pytest.fixture
def local_fixture_plugin(tmp_path: Path) -> Path:
    """Build a tiny plugin tree at ``tmp_path/hello-fixture`` shipping
    a skill, a command, a hooks block, and an MCP server stub.

    This is enough surface to prove the install path picks up all
    component types — the goal explicitly says "skill hook mcp etc".
    """
    root = tmp_path / "hello-fixture"
    (root / "skills" / "hello").mkdir(parents=True)
    (root / "skills" / "hello" / "SKILL.md").write_text(
        "---\nname: hello\ndescription: smoke skill\n---\n\n"
        "Hello from the fixture plugin.\n",
        encoding="utf-8",
    )
    (root / "commands").mkdir(parents=True)
    (root / "commands" / "hello.md").write_text(
        "---\nname: hello\n---\n\nrun: echo hi\n",
        encoding="utf-8",
    )
    (root / "hooks").mkdir(parents=True)
    (root / "hooks" / "hooks.json").write_text(
        json.dumps({"PostToolUse": []}, indent=2) + "\n",
        encoding="utf-8",
    )
    # MCP bundle. Use a stub `command` that won't actually be spawned
    # by the install path — the install side only copies files; MCP
    # spawn only happens when the model issues a tool call.
    (root / ".mcp.json").write_text(
        json.dumps({
            "mcpServers": {
                "hello-mcp": {
                    "command": "echo",
                    "args": ["hello-from-mcp"],
                    "transport": "stdio",
                },
            },
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    # CC-style manifest.
    (root / ".claude-plugin").mkdir(parents=True)
    (root / ".claude-plugin" / "plugin.json").write_text(
        json.dumps({
            "name": "hello-fixture",
            "version": "0.0.1",
            "description": "smoke plugin for /plugin tests",
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    return root


@pytest.fixture
def tmux_session(
    require_tmux: str,  # noqa: ARG001
    bootstrapped_venv: Path,  # noqa: ARG001
    sandbox_env, scaffolded_agent: Path,  # noqa: ARG001
    running_daemon: Path,  # noqa: ARG001
):
    """Headless TUI launched against the running daemon.

    Mirrors the pattern in ``test_11_tui_commands.tmux_session`` so
    the ``/plugin`` handler runs against the same agent runtime an
    operator would see.
    """
    name = f"rtxclaw-plugin-test-{os.getpid()}"
    cp = subprocess.run(
        ["tmux", "new-session", "-d", "-s", name,
         "-c", str(RTXCLAW_BIN.parent), "-x", "220", "-y", "55",
         str(RTXCLAW_BIN)],
        env=sandbox_env, capture_output=True, text=True,
    )
    if cp.returncode != 0:
        pytest.fail(
            f"tmux new-session failed (rc={cp.returncode}):\n{cp.stderr}",
        )
    try:
        yield name
    finally:
        subprocess.run(
            ["tmux", "kill-session", "-t", name],
            capture_output=True,
        )


# --------------------------------------------------------------------------
# core /plugin tests — exercise the goal directly
# --------------------------------------------------------------------------


@pytest.mark.slow
def test_plugin_search_renders_marketplace(
    tmux_session: str, report_dir: Path,
) -> None:
    """``/plugin search mcp`` should surface the curated MCP entries
    from the built-in marketplace inside the TUI transcript.

    Asserts on:
    - At least one result line containing a known MCP entry name.
    - The ``install:`` hint line so the operator knows how to act.

    This proves the search wiring (``rtxclaw_core.plugins.search`` →
    ``AgentChatApp._cmd_plugin``) reaches the renderer.
    """
    _wait_chrome(tmux_session)
    pane = _send_and_wait_for(
        tmux_session, "/plugin search mcp", "mcp-", timeout=30,
    )
    out = report_dir / "tui_22_plugin_search_mcp.txt"
    out.write_text(pane or "(empty)")
    p = pane.lower()
    assert "mcp-" in p, (
        "`/plugin search mcp` produced no MCP marketplace row.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )
    assert "install:" in p, (
        "`/plugin search` missing the per-row install hint — "
        "renderer regression.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )


@pytest.mark.slow
def test_plugin_search_skill_keyword(
    tmux_session: str, report_dir: Path,
) -> None:
    """``/plugin search skill`` returns at least the ``superpowers``
    bundle (tagged ``skills``)."""
    _wait_chrome(tmux_session)
    pane = _send_and_wait_for(
        tmux_session, "/plugin search skill", "superpowers", timeout=30,
    )
    (report_dir / "tui_22_plugin_search_skill.txt").write_text(
        pane or "(empty)",
    )
    assert "superpowers" in pane.lower(), (
        "`/plugin search skill` didn't surface the superpowers entry — "
        "marketplace tag-matching regressed.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )


@pytest.mark.slow
def test_plugin_install_local_fixture(
    tmux_session: str, report_dir: Path,
    local_fixture_plugin: Path, sandbox_home: Path,
) -> None:
    """``/plugin install <local-path>`` copies the fixture into
    ``~/.rtxclaw/plugins/`` and prints the component summary
    (skills/commands/hooks/mcpServers).

    This is the install half of the goal: from inside the TUI,
    drop a skill+hook+MCP bundle on disk. The fixture carries all
    four component types so we verify the component scanner picks
    them up.
    """
    _wait_chrome(tmux_session)

    pane = _send_and_wait_for(
        tmux_session,
        f"/plugin install {local_fixture_plugin}",
        "installed",
        timeout=30,
    )
    (report_dir / "tui_22_plugin_install_local.txt").write_text(
        pane or "(empty)",
    )

    p = pane.lower()
    assert "installed" in p, (
        f"`/plugin install <fixture>` didn't print success:\n{pane[-2000:]}"
    )
    # The fixture defines all four component types; the renderer's
    # `components` summary should mention each one.
    for tok in ("skills=1", "commands=1", "hooks=1", "mcpservers=1"):
        assert tok in p, (
            f"component summary missing {tok!r} after install — "
            "Plugin.components() / discovery regressed.\n"
            f"Pane tail:\n{pane[-2000:]}"
        )

    # Verify the install actually landed on disk under the sandbox.
    dst = sandbox_home / "plugins" / "hello-fixture"
    assert dst.is_dir(), (
        f"install path didn't write into the sandbox plugins root: "
        f"{dst} missing"
    )
    assert (dst / "skills" / "hello" / "SKILL.md").is_file(), (
        "skill file not copied to plugins root"
    )
    assert (dst / ".mcp.json").is_file(), (
        "MCP bundle not copied to plugins root"
    )

    # /plugin list should now include the freshly-installed plugin.
    pane = _send_and_wait_for(
        tmux_session, "/plugin list", "hello-fixture", timeout=15,
    )
    (report_dir / "tui_22_plugin_list_after_install.txt").write_text(
        pane or "(empty)",
    )
    assert "hello-fixture" in pane.lower(), (
        "freshly-installed plugin not visible to `/plugin list`.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )


def test_plugin_install_marketplace_name_resolution(
    tmp_path: Path, sandbox_env: dict[str, str],
) -> None:
    """``/plugin install <name>`` should resolve a bare token against
    the marketplace and surface the source URL in the error path
    (we install a name with an unreachable URL on purpose so the
    test stays offline — the assertion is that name resolution
    fired, not that ``git clone`` succeeded).

    This is the marketplace-resolution unit check; the TUI install
    path delegates to the same ``rtxclaw_core.plugins.install``.
    """
    # Force a sandbox home so the test doesn't write to ~/.rtxclaw.
    env = dict(sandbox_env)
    env["RTXCLAW_HOME"] = str(tmp_path / "rtxclaw")

    code = (
        "import sys; sys.path.insert(0, 'src')\n"
        "from rtxclaw_core import plugins as p\n"
        "ent = p.resolve_marketplace_name('superpowers')\n"
        "assert ent is not None, 'superpowers should be in builtin marketplace'\n"
        "assert ent.source.startswith('http'), ent.source\n"
        "print('ok', ent.name, ent.source)\n"
    )
    cp = subprocess.run(
        ["python3", "-c", code],
        env=env, cwd=str(RTXCLAW_BIN.parent),
        capture_output=True, text=True, timeout=20,
    )
    assert cp.returncode == 0, (
        f"marketplace name resolution failed:\nstdout: {cp.stdout}\n"
        f"stderr: {cp.stderr}"
    )
    assert "ok superpowers" in cp.stdout, cp.stdout


@pytest.mark.slow
def test_plugin_search_unknown_query_acks(
    tmux_session: str, report_dir: Path,
) -> None:
    """A nonsense query should print a "no matches" line, NOT crash
    the chrome — important so a typo doesn't dump a traceback into
    the user's chat."""
    _wait_chrome(tmux_session)
    pane = _send_and_wait_for(
        tmux_session,
        "/plugin search zzz-nonexistent-keyword-9k4",
        "no marketplace",
        timeout=30,
    )
    (report_dir / "tui_22_plugin_search_empty.txt").write_text(
        pane or "(empty)",
    )
    assert "no marketplace" in pane.lower(), (
        "empty-search ack missing:\n" + pane[-2000:]
    )
    assert "mode:" in pane.lower(), (
        "empty-search broke the chrome:\n" + pane[-1500:]
    )
