from __future__ import annotations

import asyncio
import json
import os

from rtxclaw_core.tools.runners import (
    run_delegate_claude_async,
    run_delegate_codex_async,
)


def test_delegate_claude_logs_resume_error_and_retries_fresh(
    tmp_path,
    monkeypatch,
) -> None:
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fake_claude = fake_bin / "claude"
    fake_claude.write_text(
        """#!/usr/bin/env python3
import json
import sys

if "--resume" in sys.argv:
    print(json.dumps({
        "type": "result",
        "session_id": "old-claude-session",
        "is_error": True,
        "subtype": "error_during_execution",
        "api_error_status": 400,
        "terminal_reason": "api_error",
        "result": "prompt is too long",
        "usage": {"input_tokens": 1},
        "modelUsage": {"claude-test": {"contextWindow": 100}},
    }), flush=True)
else:
    print(json.dumps({
        "type": "assistant",
        "session_id": "new-claude-session",
        "message": {
            "content": [{"type": "text", "text": "fresh ok"}],
        },
    }), flush=True)
    print(json.dumps({
        "type": "result",
        "session_id": "new-claude-session",
        "is_error": False,
    }), flush=True)
""",
        encoding="utf-8",
    )
    fake_claude.chmod(0o755)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    agent_home = tmp_path / "agent"
    sid = "rtx-session-1"
    state_file = sessions_dir / f"{sid}.delegate_claude.json"
    state_file.write_text(
        json.dumps({"claude_session_id": "old-claude-session"}),
        encoding="utf-8",
    )

    monkeypatch.setenv("PATH", f"{fake_bin}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.setenv("RTXCLAW_SESSION_ID", sid)
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(sessions_dir))
    monkeypatch.setenv("RTXCLAW_AGENT_HOME", str(agent_home))
    monkeypatch.setenv("RTXCLAW_PERMISSION_MODE", "auto")

    result = asyncio.run(run_delegate_claude_async({"prompt": "verify"}))

    assert result.ok is True
    assert "fresh ok" in result.content
    assert json.loads(state_file.read_text(encoding="utf-8")) == {
        "claude_session_id": "new-claude-session",
    }

    log_text = (agent_home / "logs" / "gateway.log").read_text(encoding="utf-8")
    assert "DELEGATE_CLAUDE_ERROR" in log_text
    assert '"subtype"="error_during_execution"' not in log_text
    assert 'subtype="error_during_execution"' in log_text
    assert 'api_error_status=400' in log_text
    assert 'terminal_reason="api_error"' in log_text
    assert 'result_preview="prompt is too long"' in log_text
    assert 'usage={"input_tokens": 1}' in log_text
    assert 'model_usage={"claude-test": {"contextWindow": 100}}' in log_text
    assert "DELEGATE_CLAUDE_RETRY_FRESH" in log_text
    assert "DELEGATE_CLAUDE_RETRY_FRESH_DONE" in log_text
    assert 'stale_claude_session_id="old-claude-session"' in log_text
    assert 'ok=true' in log_text


def test_delegate_codex_logs_turn_failed_details(tmp_path, monkeypatch) -> None:
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fake_codex = fake_bin / "codex"
    fake_codex.write_text(
        """#!/usr/bin/env python3
import json

print(json.dumps({
    "type": "thread.started",
    "thread_id": "codex-thread-1",
}), flush=True)
print(json.dumps({
    "type": "turn.failed",
    "error": {
        "type": "context_length_exceeded",
        "message": "input context is too large",
    },
}), flush=True)
""",
        encoding="utf-8",
    )
    fake_codex.chmod(0o755)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    agent_home = tmp_path / "agent"
    sid = "rtx-session-2"

    monkeypatch.setenv("PATH", f"{fake_bin}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.setenv("RTXCLAW_SESSION_ID", sid)
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(sessions_dir))
    monkeypatch.setenv("RTXCLAW_AGENT_HOME", str(agent_home))
    monkeypatch.setenv("RTXCLAW_AGENT_NAME", "scraper")
    monkeypatch.setenv("RTXCLAW_PERMISSION_MODE", "auto")

    result = asyncio.run(run_delegate_codex_async({"prompt": "verify"}))

    assert result.ok is False
    assert "codex reported error: input context is too large" in result.content

    log_text = (agent_home / "logs" / "gateway.log").read_text(encoding="utf-8")
    assert "DELEGATE_CODEX_ERROR" in log_text
    assert 'reason="reported_error"' in log_text
    assert 'message_preview="input context is too large"' in log_text
    assert 'codex_thread_id="codex-thread-1"' in log_text
    assert 'agent_name="scraper"' in log_text
    assert 'prompt_chars=6' in log_text
