"""Step 24 — secrets scrubber.

Every text field the session log persists to disk runs through
``scrub_text`` / ``scrub_value`` before reaching ``Session.save``.
The corpus then ships out to fine-tune SFT pipelines, AWQ
calibration runs, and shared diagnostic archives — so a real
credential leaking into a session JSON is a downstream incident.

This file pins the redaction contract:

- Every registered pattern fires on a representative positive case.
- Every pattern leaves benign neighbouring text intact (no
  over-redaction of e.g. plain English that happens to look like a
  long alphanum string).
- ``scrub_text`` is idempotent — running it on already-scrubbed
  text is a no-op.
- ``scrub_value`` walks nested dicts / lists without mutating the
  input (the in-memory ``tool_calls`` list also feeds the live
  model context; mutating it would poison subsequent rounds).
"""
from __future__ import annotations

import pytest

from rtxclaw_core.secrets_scrubber import (
    list_pattern_names,
    scrub_text,
    scrub_value,
)


# ---- positive cases — every pattern fires --------------------------


@pytest.mark.parametrize(
    "needle, expected_kind",
    [
        # Provider-specific keys
        ("sk-abcdefghijklmnopqrstuv0123",                 "OPENAI_KEY"),
        ("sk-proj-AbCdEf1234567890qrstuvwx",              "OPENAI_KEY"),
        ("sk-ant-api03-AbCdEfGhIjKlMnOpQrStUv",            "ANTHROPIC_KEY"),
        # Google API keys are AIza + exactly 35 chars (39 total).
        ("AIzaSyA1234567890abcdefghijklmnopqrst_-",         "GOOGLE_API_KEY"),
        ("ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789",       "GITHUB_TOKEN"),
        ("ghs_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789",       "GITHUB_TOKEN"),
        ("AKIAIOSFODNN7EXAMPLE",                          "AWS_ACCESS_KEY_ID"),
        ("ASIAQWERTYUIOPASDFGH",                          "AWS_ACCESS_KEY_ID"),
        ("xoxb-1234567890-abcdefghijklmnopqrstuv",         "SLACK_TOKEN"),
        ("sk_live_AbCdEfGhIjKlMnOpQrStUv01",               "STRIPE_KEY"),
        ("rk_test_aBcDeFgHiJkLmNoPqRsTuVwX",               "STRIPE_KEY"),
        ("8776611756:AAFDnqmC-z9tto3IeTHvMqzMTAcryM3PeeA", "TELEGRAM_BOT_TOKEN"),
        # JWT
        (
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMifQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
            "JWT",
        ),
        # Context-prefix patterns
        ("password=hunter2",                              "CREDENTIAL"),
        ("api_key: my-super-secret-key-here",             "CREDENTIAL"),
        # `--api-key foo` (space form) doesn't match the keyword=value
        # CREDENTIAL pattern, so CLI_FLAG_CREDENTIAL is the only fit.
        ("--api-key 1234567890abcdef",                    "CLI_FLAG_CREDENTIAL"),
        # `--token=value` IS also a `keyword=value` shape and the
        # more-general CREDENTIAL pattern (registered first) wins.
        # That's the right outcome — CREDENTIAL fires; redaction
        # happens. CLI_FLAG_CREDENTIAL covers the bare-space form.
        ("--token=abcdef1234567890",                      "CREDENTIAL"),
        ("Authorization: Bearer abcdefghijklmnopqrstuvwxyz", "BEARER_AUTH"),
        # ENV_CREDENTIAL fires only when the value DOESN'T also
        # match a more-specific provider-key pattern. Use a
        # non-provider-shaped 24-char alnum payload.
        ("DEPLOY_API_KEY=abcdefghijklmnop12345678",         "ENV_CREDENTIAL"),
    ],
)
def test_pattern_fires_on_known_secret(needle: str, expected_kind: str) -> None:
    body = f"benign prefix {needle} benign suffix"
    out = scrub_text(body)
    assert needle not in out, (
        f"pattern {expected_kind!r} did NOT redact its secret. "
        f"input={needle!r}  output={out!r}"
    )
    assert f"<<REDACTED:{expected_kind}>>" in out, (
        f"pattern {expected_kind!r} fired but emitted the wrong sentinel: "
        f"{out!r}"
    )
    # Benign neighbouring text survives.
    assert "benign prefix" in out
    assert "benign suffix" in out


def test_private_key_block_is_redacted() -> None:
    """Multi-line ``-----BEGIN…END-----`` blocks. Tests DOTALL flag
    application — a PEM key spans many lines and a non-DOTALL regex
    would miss it entirely.
    """
    pem = (
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIIEpAIBAAKCAQEAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"
        "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n"
        "-----END RSA PRIVATE KEY-----"
    )
    body = f"here is my key:\n{pem}\n(end of key)"
    out = scrub_text(body)
    assert "BEGIN RSA PRIVATE KEY" not in out
    assert "MIIEpAIBAA" not in out
    assert "<<REDACTED:PRIVATE_KEY_BLOCK>>" in out
    assert "here is my key" in out
    assert "(end of key)" in out


# ---- false-positive guards -----------------------------------------


@pytest.mark.parametrize(
    "benign",
    [
        "the cat sat on the mat",
        "https://example.com/foo/bar?q=1",
        "qwen3.6-27b-fp8",                  # model name (no `=`/`:` credential context)
        "hello world",
        "Run pytest -v on test_22",
        "I love coding in python 3.12",
        # Long but clearly not a secret — no provider prefix or
        # credential context.
        "the quick brown fox jumps over the lazy dog 0123456789",
    ],
)
def test_no_redaction_on_benign_text(benign: str) -> None:
    out = scrub_text(benign)
    assert out == benign, (
        f"scrubber over-redacted benign text: {benign!r} -> {out!r}"
    )


# ---- idempotence ---------------------------------------------------


def test_scrub_is_idempotent() -> None:
    body = (
        "sk-abcdefghijklmnopqrstuv0123 plus "
        "ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789 plus "
        "password=hunter2"
    )
    once = scrub_text(body)
    twice = scrub_text(once)
    assert once == twice, (
        f"scrubber not idempotent:\n  pass 1: {once!r}\n  pass 2: {twice!r}"
    )
    # And the original secrets are gone.
    assert "sk-abcdefghijklmnopqrstuv" not in once
    assert "ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789" not in once
    assert "hunter2" not in once


# ---- empty / non-string short-circuits -----------------------------


@pytest.mark.parametrize("v", ["", None, 42, 3.14, True, False])
def test_scrub_text_short_circuits_non_string(v):
    assert scrub_text(v) == v


# ---- scrub_value tree walk -----------------------------------------


def test_scrub_value_walks_nested_structures() -> None:
    payload = {
        "user": "please run with password=hunter2",
        "model": "qwen3.6-27b-fp8",
        "tool_calls": [
            {
                "name": "Bash",
                "arguments": {
                    "command": "curl -H 'Authorization: Bearer abcdefghijklmnop1234567890' https://x",
                    "criticality": "read_only",
                },
            },
            {
                "name": "Read",
                "arguments": {"path": "/etc/passwd"},
            },
        ],
        "metrics": {"completion_tokens": 100, "endpoint": "https://api.x/v1"},
    }
    out = scrub_value(payload)

    # Original payload UNCHANGED (we hand the same list back to the
    # model for the next round — mutation would poison context).
    assert payload["user"] == "please run with password=hunter2"
    assert payload["tool_calls"][0]["arguments"]["command"].startswith("curl")

    # Scrubbed payload has redactions where expected.
    assert "hunter2" not in out["user"]
    assert "<<REDACTED:CREDENTIAL>>" in out["user"]
    cmd = out["tool_calls"][0]["arguments"]["command"]
    assert "abcdefghijklmnop1234567890" not in cmd
    assert "<<REDACTED:BEARER_AUTH>>" in cmd

    # Non-secret fields untouched.
    assert out["model"] == "qwen3.6-27b-fp8"
    assert out["tool_calls"][1]["arguments"]["path"] == "/etc/passwd"
    assert out["metrics"]["completion_tokens"] == 100


def test_scrub_value_preserves_non_string_primitives() -> None:
    payload = {"n": 42, "x": 3.14, "flag": True, "nada": None}
    out = scrub_value(payload)
    assert out == payload


def test_scrub_value_handles_bytes() -> None:
    """A bytes blob carrying a credential gets decoded, scrubbed,
    and returned as a text string. Without this, a code path that
    accidentally passes bytes into a tool argument would dump the
    raw PEM into the corpus untouched."""
    pem = b"-----BEGIN RSA PRIVATE KEY-----\nMIIxxx\n-----END RSA PRIVATE KEY-----"
    out = scrub_value(pem)
    assert isinstance(out, str)
    assert "MIIxxx" not in out
    assert "<<REDACTED:PRIVATE_KEY_BLOCK>>" in out


def test_scrub_value_handles_set_and_tuple() -> None:
    """Sets and tuples are JSON-incompatible; the scrubber
    normalises to a list so downstream ``json.dumps`` works AND
    scrubs each element."""
    s = {"sk-abcdefghijklmnopqrstuv0123", "plain"}
    out = scrub_value(s)
    assert isinstance(out, list)
    assert sorted(out) == sorted(["<<REDACTED:OPENAI_KEY>>", "plain"])
    t = ("password=hunter2", "ok")
    out_t = scrub_value(t)
    assert isinstance(out_t, list)
    assert "<<REDACTED:CREDENTIAL>>" in out_t[0]
    assert out_t[1] == "ok"


def test_scrub_value_unknown_type_returns_redaction_sentinel() -> None:
    """An unknown object type (custom class, numpy array, etc.)
    gets a typed sentinel instead of silent pass-through. The
    pass-through would risk leaking its ``__repr__`` to disk via a
    subsequent ``json.dumps`` fallback."""
    class _Opaque:
        def __repr__(self) -> str:
            return "secret repr"

    out = scrub_value(_Opaque())
    assert isinstance(out, str)
    assert out == "<<REDACTED:UNKNOWN_TYPE:_Opaque>>"


@pytest.mark.parametrize(
    "needle, expected_kind",
    [
        # HashiCorp Vault
        ("hvs.AAAAAQJ9C0fGZ_QwertyUiOpAsDfGhJkLmNoPqRsTuVwXyZ", "VAULT_TOKEN"),
        ("s.aBcDeFgHiJkLmNoPqRsTuVwX",                          "VAULT_LEGACY_TOKEN"),
        # npm registry auth token
        ("//registry.npmjs.org/:_authToken=aBcDeFgHiJkLmNoPq", "NPM_AUTH_TOKEN"),
        # Docker config basic-auth (JSON form)
        ('"auth": "dXNlcjpwYXNzd29yZA=="',                    "DOCKER_AUTH"),
    ],
)
def test_extended_patterns_fire(needle: str, expected_kind: str) -> None:
    """fix_20260519 round-5: gemini round-4 critical finding —
    the scrubber registry was missing HashiCorp Vault tokens, npm
    .npmrc auth tokens, and Docker config basic-auth blobs. Each
    of these has a distinctive idiom that the generic
    ``CREDENTIAL`` pattern can't catch (``_authToken`` breaks the
    ``\\btoken`` boundary; ``auth`` is too generic standalone;
    Vault prefixes have no keyword context)."""
    body = f"benign {needle} benign"
    out = scrub_text(body)
    assert needle not in out, (
        f"pattern {expected_kind!r} did not redact: {out!r}"
    )
    assert f"<<REDACTED:{expected_kind}>>" in out


# ---- list_pattern_names contract -----------------------------------


def test_pattern_registry_is_non_empty_and_unique() -> None:
    names = list(list_pattern_names())
    assert names, "pattern registry must not be empty"
    assert len(set(names)) == len(names), (
        f"duplicate pattern names: {names}"
    )
