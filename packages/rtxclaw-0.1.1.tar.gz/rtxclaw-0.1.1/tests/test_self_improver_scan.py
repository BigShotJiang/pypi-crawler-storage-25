"""Tests for the cold-path periodic scanner. Verifies the work-list
selection logic and that each selected session triggers the hot-path
wrapper with event=periodic."""
import json
import subprocess
import textwrap
from pathlib import Path

import pytest

SCAN_SRC = Path(__file__).resolve().parents[1] / "assets" / "self-improver" / "self-improver-scan.sh"
WRAPPER_SRC = Path(__file__).resolve().parents[1] / "assets" / "self-improver" / "self-improver.sh"


@pytest.fixture
def stage(tmp_path, monkeypatch):
    rtxhome = tmp_path / "rtxhome"
    src_repo = tmp_path / "src" / "rtxclaw"
    bin_dir = tmp_path / "bin"
    (rtxhome / "scripts").mkdir(parents=True)
    (rtxhome / "agents" / "main" / "sessions").mkdir(parents=True)
    (rtxhome / "agents" / "main" / "session_reviews").mkdir(parents=True)
    (src_repo / "scripts").mkdir(parents=True)
    bin_dir.mkdir(parents=True)

    for src, name in ((SCAN_SRC, "self-improver-scan.sh"),
                      (WRAPPER_SRC, "self-improver.sh")):
        dst = rtxhome / "scripts" / name
        dst.write_text(src.read_text())
        dst.chmod(0o755)

    (src_repo / "scripts" / "self-improver-prompt.md").write_text(
        "{session_id} {event} {transcript_path} {agent_name}"
    )

    marker = tmp_path / "claude.call"
    fake = bin_dir / "claude"
    fake.write_text(f"#!/usr/bin/env bash\necho \"$*\" >> {marker}\n")
    fake.chmod(0o755)
    import os
    monkeypatch.setenv("PATH", f"{bin_dir}:{os.environ['PATH']}")
    monkeypatch.setenv("RTXCLAW_HOME", str(rtxhome))
    monkeypatch.setenv("RTXCLAW_SOURCE_DIR", str(src_repo))
    return {"rtxhome": rtxhome, "src_repo": src_repo, "marker": marker}


def _write_session(rtxhome, session_id, mtime_minutes_ago):
    p = rtxhome / "agents" / "main" / "sessions" / f"{session_id}.json"
    p.write_text(json.dumps({"agent_name": "main", "turns": []}))
    import os, time
    now = time.time()
    backdated = now - mtime_minutes_ago * 60
    os.utime(p, (backdated, backdated))
    return p


def test_scan_skips_recent_sessions(stage):
    _write_session(stage["rtxhome"], "fresh", mtime_minutes_ago=5)
    proc = subprocess.run(
        [str(stage["rtxhome"] / "scripts" / "self-improver-scan.sh")],
        capture_output=True, text=True, timeout=15,
    )
    assert proc.returncode == 0, proc.stderr
    import time; time.sleep(0.3)
    assert not stage["marker"].exists(), "scan must skip mtime < 30 min"


def test_scan_picks_quiet_sessions_without_sidecar(stage):
    _write_session(stage["rtxhome"], "quiet1", mtime_minutes_ago=45)
    subprocess.run(
        [str(stage["rtxhome"] / "scripts" / "self-improver-scan.sh")],
        capture_output=True, text=True, timeout=15, check=True,
    )
    import time; time.sleep(0.5)
    assert stage["marker"].exists(), "scan must trigger wrapper for quiet sessions"


def test_scan_skips_sessions_with_matching_sidecar(stage):
    p = _write_session(stage["rtxhome"], "reviewed", mtime_minutes_ago=45)
    import hashlib
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    sidecar = stage["rtxhome"] / "agents" / "main" / "session_reviews" / "reviewed.json"
    sidecar.write_text(json.dumps({"session_hash": h, "status": "clean"}))
    subprocess.run(
        [str(stage["rtxhome"] / "scripts" / "self-improver-scan.sh")],
        capture_output=True, text=True, timeout=15, check=True,
    )
    import time; time.sleep(0.3)
    assert not stage["marker"].exists(), "scan must skip already-reviewed sessions"


def test_scan_re_reviews_when_session_hash_changed(stage):
    p = _write_session(stage["rtxhome"], "appended", mtime_minutes_ago=45)
    sidecar = stage["rtxhome"] / "agents" / "main" / "session_reviews" / "appended.json"
    sidecar.write_text(json.dumps({"session_hash": "stale-hash", "status": "clean"}))
    subprocess.run(
        [str(stage["rtxhome"] / "scripts" / "self-improver-scan.sh")],
        capture_output=True, text=True, timeout=15, check=True,
    )
    import time; time.sleep(0.5)
    assert stage["marker"].exists(), "scan must re-review when session was appended-to"
