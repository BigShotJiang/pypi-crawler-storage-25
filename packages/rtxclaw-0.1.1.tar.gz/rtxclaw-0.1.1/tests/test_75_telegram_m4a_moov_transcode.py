"""Step 75 — Telegram m4a (MP4/MOV) → MP3 transcode for moov-at-end files.

Telegram voice notes arrive as OGG/Opus and stream fine. But an audio
*file* attached as a Telegram ``audio`` message is frequently an m4a
(AAC in an MP4 container). Most phone / app encoders write the ``moov``
index atom at the **end** of the file (i.e. NOT ``+faststart``).

The transcoder used to feed audio to ffmpeg via ``pipe:0`` (stdin),
which is **non-seekable**. For an MP4/M4A whose ``moov`` atom is at the
end, ffmpeg can't seek back to the audio ``mdat`` once it finally reads
the index — it bails out with ``"partial file" / "Error during
demuxing: Invalid data found"`` and emits a **header-only MP3**
(~140–220 bytes) **while still exiting 0**. The old
``returncode != 0 or not stdout`` guard didn't catch that, so the bot
POSTed an empty MP3 to the TB07 Qwen3-ASR endpoint, which rejected it
with ``HTTP 400 "Invalid or unsupported audio file."`` → the user saw
"⚠️ empty transcription".

Small m4a files (a few tens of KB) happen to fit inside ffmpeg's pipe
buffer and transcode fine, which is why the bug only shows up on
real-sized recordings. This test synthesizes a *large* moov-at-end m4a
(> the pipe buffer) so it reproduces the failure on the old codepath,
and passes once the transcoder hands ffmpeg a seekable input.

Skips cleanly if no ffmpeg can be located (its own operator warning).
"""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import pytest

from rtxclaw_telegram.bot import _resolve_ffmpeg, _transcode_to_mp3


@pytest.fixture(scope="module")
def ffmpeg_path() -> str:
    p = _resolve_ffmpeg()
    if not p:
        pytest.skip(
            "no ffmpeg available — install imageio-ffmpeg "
            "(in src/requirements.txt) or apt install ffmpeg"
        )
    return p


@pytest.fixture(scope="module")
def moov_at_end_m4a(ffmpeg_path: str) -> bytes:
    """A real m4a (AAC/MP4) with the ``moov`` atom at the END.

    Generated to a seekable temp *file* (not a pipe) so ffmpeg writes
    the default non-faststart layout — moov last. Made long enough
    (~120 s) that the resulting file comfortably exceeds ffmpeg's
    non-seekable input buffer, which is the condition that breaks the
    pipe-based transcode."""
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "sample.m4a"
        proc = subprocess.run(
            [
                ffmpeg_path, "-loglevel", "error", "-y",
                "-f", "lavfi", "-i", "sine=frequency=330:duration=120",
                "-c:a", "aac", str(out),
            ],
            capture_output=True,
        )
        if proc.returncode != 0 or not out.exists():
            pytest.skip(
                f"local ffmpeg can't synthesize m4a "
                f"(rc={proc.returncode} stderr={proc.stderr[:200]!r})"
            )
        data = out.read_bytes()
    # MP4/M4A magic is the "ftyp" box at offset 4; sanity-check, and
    # confirm we built something big enough to defeat the pipe buffer.
    assert data[4:8] == b"ftyp", f"not an MP4 container: {data[:12]!r}"
    assert len(data) > 200_000, (
        f"synth m4a too small to exercise the pipe-buffer path: {len(data)} B"
    )
    return data


def test_transcode_m4a_moov_at_end_yields_real_mp3(moov_at_end_m4a: bytes) -> None:
    """A moov-at-end m4a must transcode to a *real* MP3, not a
    header-only stub.

    On the old pipe-based codepath this returns ~140–220 bytes (an ID3
    tag with no audio frames) — which downstream STT rejects as
    "Invalid or unsupported audio file". The seekable-input fix yields
    a full MP3 proportional to the 120 s of audio."""
    mp3 = _transcode_to_mp3(moov_at_end_m4a, sample_rate=16000, channels=1)
    assert mp3 is not None, "transcode returned None for a valid m4a"
    # A header-only failure is < ~300 B; 120 s of 16 kHz mono mp3 is
    # tens of KB. Anything under a few KB means ffmpeg never decoded
    # the audio (the moov-at-end-over-a-pipe bug).
    assert len(mp3) > 5_000, (
        f"transcode produced only {len(mp3)} bytes — looks header-only, "
        f"ffmpeg failed to decode the moov-at-end m4a (pipe seek bug)"
    )
    head = mp3[:3]
    assert head == b"ID3" or (
        len(mp3) >= 2 and mp3[0] == 0xFF and (mp3[1] & 0xE0) == 0xE0
    ), f"mp3 header doesn't look right: {head!r} / {mp3[:4]!r}"
