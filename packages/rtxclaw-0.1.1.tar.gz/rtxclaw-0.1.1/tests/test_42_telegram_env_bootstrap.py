"""Step 42 — Telegram bot ``.env`` bootstrap.

Voice input was failing in production with ``🎙 voice input received
but STT is not configured (set OPENROUTER_API_KEY)`` even though the
operator HAD ``OPENROUTER_API_KEY=...`` set in
``~/.rtxclaw/agents/main/.env`` (where every other rtxclaw component
reads it from). The bot was inheriting only the spawn shell's
``os.environ`` — it never read any ``.env`` file the way an agent
does.

The fix adds two bootstrap loaders called from ``acp_main`` BEFORE
``AcpTelegramBot.run`` reads ``OPENROUTER_API_KEY``:

  1. ``<telegram_home>/.env`` — bot-specific secrets.
  2. ``<agents_root>/<default_agent>/.env`` — falls back to the
     agent's credential set so the operator doesn't have to
     duplicate keys across two .env files.

This file pins:

* ``_load_env_file`` parses ``KEY=value``, comments, blank lines,
  and matched-quoted values; it does NOT clobber already-set
  non-empty env vars.
* ``_bootstrap_env`` reads BOTH files in priority order.
* The agent ``.env`` path resolves through ``$RTXCLAW_HOME`` so the
  fixture's tmp_path layout is respected — without this, a CI run
  would either pick up the developer's real ~/.rtxclaw or skip the
  agent-env branch entirely.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from rtxclaw_telegram.bot import _bootstrap_env, _load_env_file
from rtxclaw_telegram.config import TelegramConfig


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect both telegram + agents trees under tmp_path.

    ``RTXCLAW_HOME`` is the workspace root that
    ``rtxclaw_telegram.config.telegram_home`` and
    ``rtxclaw_core.agent.agents_root`` both honour, so a single env
    var keeps the test fully isolated from the developer's real
    ``~/.rtxclaw``.
    """
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    # Make sure no ambient OPENROUTER_API_KEY leaks in from the dev
    # shell; the assertions below need to observe whether the loader
    # populated the var.
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("STT_TEST_KEY", raising=False)
    monkeypatch.delenv("STT_QUOTED", raising=False)
    monkeypatch.delenv("STT_COMMENT", raising=False)
    return tmp_path


def test_load_env_file_parses_basic(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    env = isolated_home / ".env"
    env.write_text(
        "# this is a comment\n"
        "\n"
        "OPENROUTER_API_KEY=sk-or-v1-abc\n"
        "STT_QUOTED=\"hello world\"\n"
        "STT_COMMENT=value # trailing junk is part of the value\n",
        encoding="utf-8",
    )

    added = _load_env_file(env)

    # Three real KEY=value lines (comment + blank dropped).
    assert added == 3
    assert os.environ["OPENROUTER_API_KEY"] == "sk-or-v1-abc"
    # Matched quotes get stripped.
    assert os.environ["STT_QUOTED"] == "hello world"
    # We don't try to be a full shell parser — trailing ``# …`` stays
    # part of the value (operator should quote if they want it
    # different).
    assert os.environ["STT_COMMENT"] == "value # trailing junk is part of the value"


def test_load_env_file_does_not_clobber_existing(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An existing non-empty env var wins over the .env file (so a
    systemd ``Environment=`` or shell-exported override is durable).
    """
    monkeypatch.setenv("OPENROUTER_API_KEY", "from-shell")
    env = isolated_home / ".env"
    env.write_text("OPENROUTER_API_KEY=from-file\n", encoding="utf-8")

    added = _load_env_file(env)

    assert added == 0
    assert os.environ["OPENROUTER_API_KEY"] == "from-shell"


def test_load_env_file_missing_path_returns_zero(
    isolated_home: Path,
) -> None:
    assert _load_env_file(isolated_home / "nope.env") == 0


def test_bootstrap_env_picks_up_agent_env(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The bug case: only the AGENT'S .env carries the OpenRouter
    key; the bot must inherit it through the bootstrap.
    """
    # Layout matches production:
    #   <home>/telegram/.env             (no OPENROUTER_API_KEY)
    #   <home>/agents/main/.env          (OPENROUTER_API_KEY=...)
    tg_dir = isolated_home / "telegram"
    tg_dir.mkdir(parents=True)
    (tg_dir / ".env").write_text("PATH=/usr/bin\n", encoding="utf-8")

    agent_dir = isolated_home / "agents" / "main"
    agent_dir.mkdir(parents=True)
    (agent_dir / ".env").write_text(
        "OPENROUTER_API_KEY=sk-or-v1-from-agent\n", encoding="utf-8",
    )
    # The agent .env loader path goes through ``AgentConfig.load`` —
    # need a minimal valid config.json so the load doesn't raise.
    (agent_dir / "config.json").write_text(
        '{"name": "main", "host": "127.0.0.1", "port": 7700, '
        '"endpoint": "http://localhost:8000/v1", "model": "test"}\n',
        encoding="utf-8",
    )

    tg_cfg = TelegramConfig(default_agent="main")
    loaded = _bootstrap_env(tg_cfg)

    paths = [p.name for p, _ in loaded]
    assert ".env" in paths
    # Both files should have been visited (telegram first, agent second).
    assert len(loaded) == 2
    # The agent's key landed in os.environ — STT will be wired.
    assert os.environ.get("OPENROUTER_API_KEY") == "sk-or-v1-from-agent"


def test_bootstrap_env_telegram_wins_over_agent(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If both files set the same key, the telegram-home .env wins
    (it's loaded first; subsequent loads don't overwrite). Pins the
    priority order so a future refactor can't silently invert it.
    """
    tg_dir = isolated_home / "telegram"
    tg_dir.mkdir(parents=True)
    (tg_dir / ".env").write_text(
        "OPENROUTER_API_KEY=from-telegram-home\n", encoding="utf-8",
    )

    agent_dir = isolated_home / "agents" / "main"
    agent_dir.mkdir(parents=True)
    (agent_dir / ".env").write_text(
        "OPENROUTER_API_KEY=from-agent-home\n", encoding="utf-8",
    )
    (agent_dir / "config.json").write_text(
        '{"name": "main", "host": "127.0.0.1", "port": 7700, '
        '"endpoint": "http://localhost:8000/v1", "model": "test"}\n',
        encoding="utf-8",
    )

    tg_cfg = TelegramConfig(default_agent="main")
    _bootstrap_env(tg_cfg)

    assert os.environ["OPENROUTER_API_KEY"] == "from-telegram-home"


def test_bootstrap_env_missing_agent_does_not_crash(
    isolated_home: Path,
) -> None:
    """Missing / unreadable default-agent config must not block the
    bot from loading its own .env (the agent fallback is a
    convenience, not a requirement)."""
    tg_dir = isolated_home / "telegram"
    tg_dir.mkdir(parents=True)
    (tg_dir / ".env").write_text(
        "OPENROUTER_API_KEY=from-telegram-only\n", encoding="utf-8",
    )

    # No agents/main/ at all.
    tg_cfg = TelegramConfig(default_agent="missing-agent")
    loaded = _bootstrap_env(tg_cfg)

    assert os.environ["OPENROUTER_API_KEY"] == "from-telegram-only"
    # Only the telegram .env contributed.
    assert all("agents" not in str(p) for p, _ in loaded)
