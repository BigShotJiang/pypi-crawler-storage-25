"""Backend delegate context preamble: correctness + size budget.

Regression coverage for the bug where `/claude` (and `/codex` /
`/antigravity`) reached the delegated CLI with NO rtxclaw conversation
context — so the model "didn't know what was happening."

Root cause: the Agent flushes the CURRENT delegate turn (user = the
`__RTXCLAW_DELEGATE__:…` sentinel) into ``session.turns`` on the
``ToolCallStarted`` event, which the direct-dispatch path emits BEFORE
`_build_direct_delegate_preamble` runs. The preamble's `last_same` scan
did not skip in-progress turns, so it matched the *current* turn, left
`unsynced` empty, and produced an empty preamble — on every call.

Also covers the missing TOTAL size cap: a long main-agent session must
not hand the CLI a preamble larger than its model context window.
"""

from __future__ import annotations

import types

from rtxclaw_core.agents.local_llm import (
    _build_direct_delegate_preamble,
    _delegate_resume_available,
    _direct_preamble_total_budget,
)

SENTINEL = '__RTXCLAW_DELEGATE__:delegate_claude:{"prompt":"confirm this"}'


def _sess(turns):
    return types.SimpleNamespace(turns=turns)


def test_first_call_forwards_prior_context_despite_inprogress_current_turn():
    # The Agent has already flushed the current delegate turn (in_progress,
    # user=sentinel) into session.turns. The preamble must STILL forward the
    # prior local-model turn (regression: previously returned "").
    sess = _sess([
        {"user": "my endpoint is qwen at 10.0.0.80", "content": "Noted.", "in_progress": False},
        {"user": SENTINEL, "content": "", "in_progress": True},
    ])
    out = _build_direct_delegate_preamble(sess, "delegate_claude")
    assert out, "preamble must not be empty when prior turns exist"
    assert "qwen at 10.0.0.80" in out
    assert "You were invoked from inside an rtxclaw session" in out  # first-call header


def test_between_calls_forwards_only_unsynced_turns():
    # After a completed delegate, only the turns SINCE it are forwarded
    # (the CLI's own --resume carries the rest). The current in-progress
    # delegate turn must not collapse the window.
    sess = _sess([
        {"user": SENTINEL, "content": "earlier claude reply", "in_progress": False},
        {"user": "now remember TB10 = 2x5090", "content": "Understood.", "in_progress": False},
        {"user": SENTINEL, "content": "", "in_progress": True},
    ])
    out = _build_direct_delegate_preamble(sess, "delegate_claude")
    assert "TB10 = 2x5090" in out                      # the between turn IS forwarded
    assert "earlier claude reply" not in out           # the resumed turn is NOT re-sent
    assert "Additional rtxclaw turns since your last invocation" in out  # resume header


def test_no_prior_turns_returns_empty():
    sess = _sess([{"user": SENTINEL, "content": "", "in_progress": True}])
    assert _build_direct_delegate_preamble(sess, "delegate_claude") == ""


def test_total_budget_trims_oldest_and_marks_elision():
    budget = _direct_preamble_total_budget("delegate_claude")
    big = [
        {"user": f"q{i} " + "x" * 9000, "content": f"a{i} " + "y" * 9000, "in_progress": False}
        for i in range(40)
    ]
    big.append({"user": SENTINEL, "content": "", "in_progress": True})
    out = _build_direct_delegate_preamble(_sess(big), "delegate_claude")
    # Under budget (plus the fixed header/wrapper overhead).
    assert len(out) < budget + 4000
    assert "older turn(s) omitted" in out      # elision marked
    assert "q39" in out                        # newest kept
    assert "q0 " not in out                     # oldest dropped


def test_budget_is_per_engine_and_env_overridable(monkeypatch):
    assert _direct_preamble_total_budget("delegate_antigravity") > _direct_preamble_total_budget("delegate_claude")
    monkeypatch.setenv("RTXCLAW_DELEGATE_MAX_PREAMBLE_CHARS", "5000")
    assert _direct_preamble_total_budget("delegate_claude") == 5000
    assert _direct_preamble_total_budget("delegate_codex") == 5000


# --- Finding B: resume decision must track the CLI's real --resume state ---

def test_not_resumable_forwards_all_turns_including_prior_delegate():
    # A prior delegate turn exists but the child has no resumable session
    # (failed/aborted first call). The CLI cold-starts, so the preamble must
    # forward EVERYTHING — including the prior delegate's reply — not just
    # the post-delegate slice.
    sess = _sess([
        {"user": SENTINEL, "content": "earlier claude reply", "in_progress": False},
        {"user": "between turn about TB10", "content": "ok", "in_progress": False},
        {"user": SENTINEL, "content": "", "in_progress": True},
    ])
    out = _build_direct_delegate_preamble(sess, "delegate_claude", resumable=False)
    assert "earlier claude reply" in out          # cold start → re-send it
    assert "between turn about TB10" in out
    assert "You were invoked from inside an rtxclaw session" in out


def test_resumable_uses_resume_shortcut():
    sess = _sess([
        {"user": SENTINEL, "content": "earlier claude reply", "in_progress": False},
        {"user": "between turn about TB10", "content": "ok", "in_progress": False},
        {"user": SENTINEL, "content": "", "in_progress": True},
    ])
    out = _build_direct_delegate_preamble(sess, "delegate_claude", resumable=True)
    assert "earlier claude reply" not in out      # carried by the CLI's --resume
    assert "between turn about TB10" in out


def test_resume_available_is_safe_without_session_state():
    # No session hash and unknown tool → False, never raises.
    assert _delegate_resume_available(types.SimpleNamespace(), "delegate_claude") is False
    assert _delegate_resume_available(types.SimpleNamespace(hash="x"), "delegate_unknown") is False
