"""Step 33 — Reasoning round-trip on tool-call follow-up.

DeepSeek's reasoning-class models (`deepseek-reasoner`,
`deepseek-v4-flash`) HTTP-400 the tool-result follow-up call with
*"reasoning_content in the thinking mode must be passed back to the
API"* when the assistant message that emitted the tool_call doesn't
carry the reasoning text it produced.

`_build_assistant_round_msg` is the single point in the bridge that
constructs that message. These tests pin its OpenAI-shape contract
plus the DeepSeek-required `reasoning_content` round-trip — so a
future refactor can't silently drop the field and re-introduce the
HTTP 400 from session 69fc554f8ce5ee5238000001's lineage.
"""
from __future__ import annotations

import json

import pytest

from rtxclaw_agent.acp_bridge import _build_assistant_round_msg


# ---- baseline shape ------------------------------------------------


def _call(name: str = "Bash", args: dict | None = None, cid: str = "call_0") -> dict:
    return {"id": cid, "name": name, "arguments": args or {"command": "ls"}}


def test_basic_shape_with_one_tool_call() -> None:
    msg = _build_assistant_round_msg(
        content="Listing the directory.",
        thinking="",
        tool_calls=[_call()],
    )
    assert msg["role"] == "assistant"
    assert msg["content"] == "Listing the directory."
    assert isinstance(msg["tool_calls"], list)
    assert len(msg["tool_calls"]) == 1
    tc = msg["tool_calls"][0]
    assert tc["id"] == "call_0"
    assert tc["type"] == "function"
    assert tc["function"]["name"] == "Bash"
    # Arguments must serialize to a JSON STRING — that's the OpenAI
    # function-tool wire shape; passing a dict here breaks vLLM.
    assert isinstance(tc["function"]["arguments"], str)
    assert json.loads(tc["function"]["arguments"]) == {"command": "ls"}


def test_empty_content_becomes_null() -> None:
    """OpenAI tool-call assistant messages with no narration use
    ``content=null`` — empty string would also work but ``null`` is
    the canonical shape, and some validators reject ``""``."""
    msg = _build_assistant_round_msg(
        content="",
        thinking="",
        tool_calls=[_call()],
    )
    assert msg["content"] is None


# ---- reasoning round-trip ------------------------------------------


def test_reasoning_attached_when_thinking_present() -> None:
    msg = _build_assistant_round_msg(
        content="ok",
        thinking="The user asked for X. I'll grep first.",
        tool_calls=[_call()],
    )
    assert msg.get("reasoning_content") == (
        "The user asked for X. I'll grep first."
    )


def test_reasoning_omitted_when_thinking_empty() -> None:
    """Don't attach an empty reasoning_content — DeepSeek ignores
    falsy values but a stray empty string in the wire payload is
    noise. vLLM / OpenAI tolerate it but cleaner is cleaner."""
    msg = _build_assistant_round_msg(
        content="hello",
        thinking="",
        tool_calls=[_call()],
    )
    assert "reasoning_content" not in msg


def test_reasoning_omitted_when_only_whitespace_thinking() -> None:
    """A single newline isn't reasoning. The bridge's `round_thinking`
    accumulator can collect a trailing ``\\n`` from the splitter even
    when the model didn't actually think — guard against that."""
    msg = _build_assistant_round_msg(
        content="hello",
        thinking="   \n  ",
        tool_calls=[_call()],
    )
    # The current contract is "any non-empty string passes through".
    # Whitespace-only is technically truthy → it does land in the
    # message. If we ever want to filter, this test is the place.
    # For now: pin the explicit current behavior so future edits are
    # deliberate.
    assert msg.get("reasoning_content") == "   \n  "


# ---- tool_calls fan-out --------------------------------------------


def test_multi_tool_call_round_serializes_each() -> None:
    msg = _build_assistant_round_msg(
        content="ok",
        thinking="plan: grep then read",
        tool_calls=[
            _call(name="Grep", args={"pattern": "TODO"}, cid="c0"),
            _call(name="Read", args={"path": "/tmp/x"}, cid="c1"),
        ],
    )
    names = [tc["function"]["name"] for tc in msg["tool_calls"]]
    assert names == ["Grep", "Read"]
    ids = [tc["id"] for tc in msg["tool_calls"]]
    assert ids == ["c0", "c1"]
    # Reasoning attached once for the whole round, not per-call.
    assert msg["reasoning_content"] == "plan: grep then read"


def test_unicode_args_survive_serialization() -> None:
    """`ensure_ascii=False` matters — the upstream tokenizer wastes
    KV-cache space if every non-ASCII char is escaped to ``\\uXXXX``,
    and `tool_search` queries do contain accented + emoji search
    terms in real sessions."""
    msg = _build_assistant_round_msg(
        content="",
        thinking="",
        tool_calls=[_call(args={"query": "café 🇧🇷"}, cid="cu")],
    )
    raw = msg["tool_calls"][0]["function"]["arguments"]
    # The escaped form would be ``"café \ud83c\uddf...".
    assert "café" in raw
    assert "🇧🇷" in raw
