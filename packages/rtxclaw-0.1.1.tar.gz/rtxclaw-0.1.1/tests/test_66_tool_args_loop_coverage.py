"""Step 66 — tool_args loop detection must not fire on recurring domain terms.

False positive (TUI run, session 20260520T155208…): a plan-mode Bash
command that legitimately referenced ``self-improver`` several times
tripped the tight-tier detector (8-char n-gram ``self-imp`` repeated
>= 8x) and the turn was force-terminated mid-research — before it could
spawn subagents or present a plan.

The tight/ngram detectors stay on the ``tool_args`` channel (they catch
real token-collapse), but now require the repeated unit to COVER a
meaningful fraction of the payload. A degenerate run covers ~1.0; a
keyword scattered through a varied command covers ~0.2-0.3, so the
latter no longer false-positives. Other channels are unchanged.

Pure unit test — no daemon, no upstream.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.turn_runtime import (  # noqa: E402
    _detect_loops_layered,
    _loop_coverage,
)


# The exact false-positive shape: a varied command that mentions the
# task's domain term (`self-improver`) many times.
_VARIED_CMD = (
    "ls -la ~/.rtxclaw/scripts/self-improver*; "
    "cat ~/.rtxclaw/self-improver/config.json; "
    "test -f ~/.rtxclaw/self-improver/install.py && echo self-improver-ok; "
    "grep self-improver ~/.rtxclaw/agents/main/hooks.json; "
    "ls assets/self-improver/; rtxclaw self-improver status"
)


def test_recurring_domain_term_in_tool_args_is_not_a_loop():
    # The raw count clears the tight threshold, but coverage is low.
    assert _VARIED_CMD.count("self-imp") >= 6
    assert _loop_coverage(_VARIED_CMD, "self-imp") < 0.5
    assert _detect_loops_layered(_VARIED_CMD, channel="tool_args") is None


def test_degenerate_run_in_tool_args_still_flagged():
    collapse = "self-improver" * 30
    assert _loop_coverage(collapse, "self-improver") >= 0.5
    hit = _detect_loops_layered(collapse, channel="tool_args")
    assert hit is not None and hit[0] == "tight"


def test_unary_collapse_in_tool_args_still_flagged():
    # Classic qwen3.x FP8-KV '!' run — tight tier catches it (entropy
    # tier is carved out on tool_args, so coverage gate must not hide it).
    bang = "x" + "!" * 240
    hit = _detect_loops_layered(bang, channel="tool_args")
    assert hit is not None and hit[0] == "tight"


def test_reasoning_channel_unchanged():
    # The coverage gate is tool_args-only; reasoning/content channels
    # keep the original count-only detection.
    loop_text = "Let me re-check the answer. " * 80
    assert _detect_loops_layered(loop_text, channel="thinking") is not None


def test_low_coverage_does_not_gate_non_tool_args():
    # A scattered term on the reasoning channel still follows the
    # original (count-only) rule — coverage gate does NOT apply there.
    # (Sanity: the gate is strictly scoped to tool_args.)
    assert _loop_coverage(_VARIED_CMD, "self-imp") < 0.5
    # Same buffer on thinking channel is not forced to None by coverage.
    # (It happens to be None here only because real CoT loops differ;
    # the point is the gate isn't applied — verified by the tool_args vs
    # thinking divergence on the degenerate run below.)
    collapse = "self-improver" * 30
    assert _detect_loops_layered(collapse, channel="thinking") is not None
