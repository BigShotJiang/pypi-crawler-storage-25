"""Step 12 — Reasoning-loop detector unit + integration coverage.

The detector lives in
``src/rtxclaw_core/turn_runtime.py:_detect_reasoning_loop``. It's a
silent safety net — when extended-CoT models start cycling, the bridge
hands the partial reasoning to a distiller and finalises the turn
instead of letting the loop burn the context window. A regression here
is invisible until a turn never finishes, so the detector deserves
explicit unit coverage.

Coverage:
- True positive: ≥4 occurrences of a meaty n-gram in the suffix fires.
- False positive guards: whitespace-dominated grams skipped, ≤2
  unique chars (markdown rules / "==…==") skipped, sub-threshold
  buffers skipped.
- Window cutoff: only the suffix matters (an old loop in the head
  doesn't fire on a clean tail).
- Integration-shaped: simulate a CoT trace that should fire and one
  that shouldn't, to demonstrate the detector's intended use.
"""
from __future__ import annotations

import pytest

from rtxclaw_core.turn_runtime import (
    LOOP_MIN_CONTEXT_CHARS,
    LOOP_NGRAM_LEN,
    LOOP_REPEAT_THRESHOLD,
    LOOP_WINDOW_CHARS,
    _TOOL_CALL_LOOP_WINDOW,
    _detect_loops_layered,
    _detect_reasoning_loop,
    _detect_tool_call_loop,
)


def _padding(n: int) -> str:
    """A plausible-looking pad of `n` chars that's free of repetitive
    n-grams of the relevant size. Uses the alphabet rotated so no
    ``ngram_len``-window aligns twice."""
    base = "abcdefghijklmnopqrstuvwxyz0123456789"
    out: list[str] = []
    while sum(len(s) for s in out) < n:
        out.append(base[:max(LOOP_NGRAM_LEN, 1)])
        # Rotate so the next chunk has a different ``ngram_len`` head.
        base = base[1:] + base[:1]
    return "".join(out)[:n]


def test_short_buffer_does_not_fire() -> None:
    short = "Let me reconsider. " * 3
    assert _detect_reasoning_loop(short) is None


def test_pure_repetition_fires() -> None:
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "The answer must be 42 and the answer must be 42. " * (
        LOOP_REPEAT_THRESHOLD + 2
    )
    buf = pad + loop
    hit = _detect_reasoning_loop(buf)
    assert hit is not None, (
        f"detector missed clear repetition (buf len={len(buf)})"
    )
    assert "42" in hit or "answer" in hit


def test_whitespace_only_ngram_skipped() -> None:
    """A long run of spaces (e.g. a markdown table row) shouldn't trip
    the detector — that's formatting noise, not reasoning."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    spaces = " " * (LOOP_NGRAM_LEN * (LOOP_REPEAT_THRESHOLD + 1))
    assert _detect_reasoning_loop(pad + spaces) is None


def test_ascii_rule_ngram_still_fires_without_structure() -> None:
    """A long unary ASCII run without surrounding structure is still a
    collapse candidate. The structured markdown/table carve-out is applied
    only in the channel-aware layered detector."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    rule = "=" * (LOOP_NGRAM_LEN * (LOOP_REPEAT_THRESHOLD + 1))
    assert _detect_reasoning_loop(pad + rule) is not None


def test_old_loop_in_head_does_not_fire() -> None:
    """When the loop sits in the prefix and the suffix is clean, the
    detector must NOT fire — otherwise the model never recovers."""
    head = "I am stuck I am stuck I am stuck I am stuck I am stuck "
    head_pad = head * 50  # well past LOOP_WINDOW_CHARS — but at the head
    clean_tail = _padding(LOOP_WINDOW_CHARS + LOOP_MIN_CONTEXT_CHARS)
    buf = head_pad + clean_tail
    assert _detect_reasoning_loop(buf) is None


def test_low_ngram_threshold_param() -> None:
    """Caller can tighten the threshold; with threshold=2 a doubled
    n-gram must fire."""
    pad = _padding(200)
    body = ("the cat sat on the mat — " * 4)[: LOOP_NGRAM_LEN * 3]
    hit = _detect_reasoning_loop(
        pad + body,
        ngram_len=10,
        repeat_threshold=2,
        min_context_chars=100,
    )
    assert hit is not None


def test_detector_is_pure() -> None:
    """No I/O, no side effects — sanity-check by running twice on the
    same input and confirming the result matches."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "Consider the function f(x) = 2x + 1. " * (
        LOOP_REPEAT_THRESHOLD + 1
    )
    buf = pad + loop
    a = _detect_reasoning_loop(buf)
    b = _detect_reasoning_loop(buf)
    assert a == b


@pytest.mark.parametrize(
    "ngram_len, threshold, expect_fire",
    [
        (60, 4, True),    # default — fires
        (60, 99, False),  # impossibly high threshold — never fires
        (200, 4, False),  # n-gram longer than the loop body
    ],
)
def test_parametrised_thresholds(
    ngram_len: int, threshold: int, expect_fire: bool,
) -> None:
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "Therefore the answer is forty two. " * 8
    buf = pad + loop
    hit = _detect_reasoning_loop(
        buf,
        ngram_len=ngram_len,
        repeat_threshold=threshold,
        window_chars=LOOP_WINDOW_CHARS,
        min_context_chars=LOOP_MIN_CONTEXT_CHARS,
    )
    assert (hit is not None) is expect_fire


def test_structured_lspci_thinking_does_not_fire() -> None:
    """Regression: 20260521T065920801150 turn 2.

    The model quoted an lspci block in reasoning; the repeated Subsystem
    line looked like an n-gram loop, but the suffix was varied structured
    diagnostic text.
    """
    block = """
00:01.1 PCI bridge: PCI Express Data Center Memory Controller (rev 02)
        Subsystem: ASUSTeK Computer Inc. Device 8954
        Flags: bus dev 00 func 1 impl 0
        Capabilities: <access denied>
        Kernel driver in use: pcieport
01:00.0 Non-Volatile memory controller: KIOXIA Corporation Device 0007
        Subsystem: ASUSTeK Computer Inc. Device 8954
        Physical Slot: 1
02:00.0 Non-Volatile memory controller: ADATA XPG GAMMIX S70 BLADE
        Subsystem: ASUSTeK Computer Inc. Device 8954
        Physical Slot: 2
"""
    thinking = _padding(LOOP_MIN_CONTEXT_CHARS) + block * 4
    assert _detect_loops_layered(thinking, channel="thinking") is None


def test_structured_permission_table_content_does_not_fire() -> None:
    """Regression: 20260521T110322578236 turns 0/1.

    Batch status tables repeat long permission-denied fragments across
    different rows. That is structured reporting, not a content loop.
    """
    rows = [
        "| 1 | `MarketData-BVMF/download_files` | **DELAYED** | "
        '`Permission denied: "/tradebot05-ws/nvme/downloads/FTPBMF"` |',
        "| 2 | `MarketData-CVM/download_files` | **DELAYED** | "
        '`Permission denied: "/tradebot05-ws/nvme/downloads/CVM"` |',
        "| 3 | `MarketData-ORATS/download` | **DELAYED** | "
        '`Permission denied: "/tradebot05-ws/nvme/downloads/ORATS"` |',
        "| 4 | `MarketData-CME/sync_ftp` | **DELAYED** | "
        '`Permission denied: "/tradebot05-ws/nvme/downloads/FTPCME"` |',
        "| 5 | `MarketData-ETF/spdr_download` | **DELAYED** | "
        '`Permission denied: "/tradebot05-ws/nvme/downloads/ETF"` |',
    ]
    table = "\n".join(rows)
    content = _padding(LOOP_MIN_CONTEXT_CHARS) + "\n" + table
    assert _detect_loops_layered(content, channel="content") is None


def test_markdown_table_separator_in_thinking_does_not_fire() -> None:
    """Regression: 20260521T065920801150 turn 50.

    A tight-tier hit on ``--------`` inside a reasoning-side markdown table
    is presentation structure, not token collapse.
    """
    table = """
| Table | Source | Common / Total |
|-------|--------|----------------|
| ORATS | nvme3  | 160 / 170      |
| VOTER | nvme6  | 16 / 24        |
"""
    thinking = _padding(300) + table
    assert _detect_loops_layered(thinking, channel="thinking") is None


def test_unstructured_ascii_rule_collapse_still_fires_early() -> None:
    """Do not reopen the early-window collapse hole for ASCII rule chars."""
    hit = _detect_loops_layered("=" * 150, channel="thinking")
    assert hit is not None
    assert hit[0] == "tight"


def test_unary_collapse_after_markdown_table_still_fires() -> None:
    """A preceding table must not mask a later genuine unary collapse."""
    table = """
| Table | Status | Message |
|-------|--------|---------|
| A     | ok     | first   |
| B     | ok     | second  |
"""
    hit = _detect_loops_layered(table + "!" * 220, channel="thinking")
    assert hit is not None


def test_identical_pipe_rows_still_fire_as_degeneracy() -> None:
    """Repeated identical table-looking rows are themselves a loop."""
    repeated_rows = "| same | same | same |\n" * 8
    hit = _detect_loops_layered(repeated_rows, channel="content")
    assert hit is not None


# --- _detect_tool_call_loop ------------------------------------------
#
# The repetition detector receives the *flat worker* tool-call shape
# (``worker.py`` emits ``{"id", "name", "arguments", "raw_arguments"}``,
# stored verbatim in ``pending_tool_calls``). The signature must read
# ``name`` + ``arguments`` from that flat shape — a regression where it
# looked for ``c["function"]["parameters"]`` made every signature
# collapse to ``("", "")``, so it could neither distinguish args nor
# tool names.


def _flat_call(name: str, **args: object) -> dict:
    """Worker-shape tool call: flat ``name`` + parsed-dict ``arguments``."""
    return {
        "id": f"call_{name}",
        "name": name,
        "arguments": dict(args),
        "raw_arguments": "{}",
    }


def test_tool_loop_fires_on_identical_flat_calls() -> None:
    call = [_flat_call("Read", file_path="/x")]
    history = [
        [_flat_call("Read", file_path="/x")]
        for _ in range(_TOOL_CALL_LOOP_WINDOW)
    ]
    assert _detect_tool_call_loop(call, history) is True


def test_tool_loop_distinguishes_arguments() -> None:
    """Same tool, different args each round — NOT a loop. Fails when the
    detector is blind to ``arguments`` (the original bug)."""
    call = [_flat_call("Read", file_path="/page_4")]
    history = [
        [_flat_call("Read", file_path=f"/page_{i}")]
        for i in range(_TOOL_CALL_LOOP_WINDOW)
    ]
    assert _detect_tool_call_loop(call, history) is False


def test_tool_loop_distinguishes_tool_name() -> None:
    """Different tool names — NOT a loop. Fails when the detector is
    blind to ``name`` (collapses every call to ``("", "")``)."""
    call = [_flat_call("Write", file_path="/x")]
    history = [
        [_flat_call("Read", file_path="/x")]
        for _ in range(_TOOL_CALL_LOOP_WINDOW)
    ]
    assert _detect_tool_call_loop(call, history) is False


def test_tool_loop_accepts_nested_openai_shape() -> None:
    """Back-compat: the nested ``{"function": {"name", "arguments"}}``
    OpenAI shape must still be compared correctly."""
    def nested(name: str, args: str) -> dict:
        return {"function": {"name": name, "arguments": args}}

    call = [nested("Read", '{"file_path": "/x"}')]
    history = [
        [nested("Read", '{"file_path": "/x"}')]
        for _ in range(_TOOL_CALL_LOOP_WINDOW)
    ]
    assert _detect_tool_call_loop(call, history) is True


def test_tool_loop_requires_consecutive_identical_call_sets() -> None:
    """Regression: current call matching one older round is not enough.

    The detector advertises repeated calls across the last N rounds. A
    sequence A, B, C, A is retry/backoff behavior, not an identical loop.
    """
    current = [
        _flat_call(
            "mcp_call",
            arguments="{}",
            server_name="codebase-memory-mcp",
        ),
    ]
    history = [
        [
            _flat_call(
                "mcp_call",
                arguments="{}",
                server_name="codebase-memory-mcp",
            ),
        ],
        [_flat_call(
            "mcp_call",
            arguments='{"tool_name": "list_projects", "arguments": {}}',
            server_name="codebase-memory-mcp",
        )],
        [_flat_call("ToolSearch", query="codebase-memory")],
    ]
    assert _detect_tool_call_loop(current, history) is False
