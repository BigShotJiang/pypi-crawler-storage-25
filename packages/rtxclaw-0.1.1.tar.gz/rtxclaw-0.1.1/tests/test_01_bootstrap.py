"""Step 01 — bootstrap. Cold venv create, sentinel, warm reuse, reinstall, no-bootstrap.

Each test mutates ``$RTXCLAW_VENV`` directly so we can exercise the
launcher's state machine (cold start, sentinel hit, forced reinstall,
no-bootstrap path) without polluting other tests' state.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from conftest import RTXCLAW_BIN


@pytest.fixture
def cold_venv(sandbox_env, sandbox_venv: Path):
    """Wipe the sandbox venv before the test so cold-start logic runs."""
    if sandbox_venv.exists():
        shutil.rmtree(sandbox_venv)
    yield sandbox_venv


def _run_help(env, timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        [str(RTXCLAW_BIN), "--help"],
        env=env, capture_output=True, text=True, timeout=timeout,
    )


def test_cold_start_creates_venv_and_sentinel(cold_venv: Path, sandbox_env) -> None:
    cp = _run_help(sandbox_env)
    assert cp.returncode == 0, f"cold ./rtxclaw --help failed:\n{cp.stderr}"
    assert (cold_venv / "bin" / "python").exists(), "venv python missing"
    assert (cold_venv / ".rtxclaw_installed").exists(), "install sentinel missing"


def test_warm_run_skips_install(sandbox_env, sandbox_venv: Path) -> None:
    # Force one cold start so the sentinel exists.
    if not (sandbox_venv / ".rtxclaw_installed").exists():
        _run_help(sandbox_env)
    cp = _run_help(sandbox_env)
    assert cp.returncode == 0
    combined = cp.stdout + cp.stderr
    assert "installing" not in combined, f"warm run still installed:\n{combined}"


def test_force_reinstall_runs_install(sandbox_env, sandbox_venv: Path) -> None:
    if not (sandbox_venv / ".rtxclaw_installed").exists():
        _run_help(sandbox_env)
    env = dict(sandbox_env, RTXCLAW_REINSTALL="1")
    cp = _run_help(env)
    assert cp.returncode == 0
    combined = cp.stdout + cp.stderr
    assert "installing" in combined, f"RTXCLAW_REINSTALL did not trigger install:\n{combined}"


def test_no_bootstrap_uses_existing_venv(sandbox_env, sandbox_venv: Path) -> None:
    if not (sandbox_venv / ".rtxclaw_installed").exists():
        _run_help(sandbox_env)
    env = dict(sandbox_env, RTXCLAW_NO_BOOTSTRAP="1")
    cp = _run_help(env)
    assert cp.returncode == 0, f"no-bootstrap launch failed:\n{cp.stderr}"


def test_no_bootstrap_without_venv_errors(sandbox_env, sandbox_venv: Path) -> None:
    if sandbox_venv.exists():
        shutil.rmtree(sandbox_venv)
    env = dict(sandbox_env, RTXCLAW_NO_BOOTSTRAP="1")
    cp = _run_help(env)
    assert cp.returncode != 0, "no-bootstrap with no venv should error"
    assert "venv python missing" in cp.stderr or "venv python missing" in cp.stdout
