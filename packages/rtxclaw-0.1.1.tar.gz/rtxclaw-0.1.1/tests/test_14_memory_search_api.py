"""Step 14 — Memory search + embedding pipeline coverage.

Exercises ``rtxclaw_memory.memory_tools.memory_search`` directly so a
regression in the privacy gate, parameter validation, or fall-back
ordering is caught at the function boundary (no daemon, no telegram,
no tmux).

The integration-shaped path (model → tool dispatch → memory_search) is
already covered by ``test_07_memory.py``. This file is the unit-level
contract suite the canonical test_07 was missing.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_memory.memory_tools import memory_search


@pytest.fixture
def memory_home(tmp_path: Path) -> Path:
    """Build a synthetic agent home with a curated MEMORY.md and a
    daily file so search has real material to bind to."""
    home = tmp_path / "agent_home"
    home.mkdir()
    (home / "MEMORY.md").write_text(
        "# Project state\n\n"
        "- The flagship sovereign-inference TUI agent is **rtxclaw**.\n"
        "- Hardware: RTX 3060 / 4090 / 5090 cluster.\n"
        "- Cypherpunk principles guide the design.\n",
        encoding="utf-8",
    )
    daily = home / "memory"
    daily.mkdir()
    (daily / "2026-05-05.md").write_text(
        "# 2026-05-05\n\n"
        "- Investigated the auto-compaction bug fingerprinted 4aea829f.\n"
        "- Confirmed vLLM 400 when tool message dangles after compaction.\n",
        encoding="utf-8",
    )
    return home


def test_refuses_non_private_origin(memory_home: Path) -> None:
    body = memory_search(
        "rtxclaw", workspace_origin="group_chat",
        agent_home=memory_home,
    )
    assert body.startswith("memory_search refused"), body[:200]


def test_accepts_known_private_origins(memory_home: Path) -> None:
    for origin in ("", "tui", "oneshot", "telegram", "heartbeat"):
        body = memory_search(
            "rtxclaw", workspace_origin=origin,
            agent_home=memory_home,
        )
        assert not body.startswith("memory_search refused"), (
            f"private origin {origin!r} was refused:\n{body[:200]}"
        )


def test_empty_query_errors(memory_home: Path) -> None:
    body = memory_search(
        "  ", workspace_origin="tui", agent_home=memory_home,
    )
    assert "query required" in body, body[:200]


def test_returns_no_match_string_for_unknown_topic(memory_home: Path) -> None:
    body = memory_search(
        "tributary minnow alkaloid",
        workspace_origin="tui", agent_home=memory_home,
    )
    # Either it found something (vector hit on neutral chars — unlikely
    # given our small corpus) OR it's the canonical no-match string.
    if "no matches" in body:
        assert "tributary minnow alkaloid" in body
    else:
        assert body.startswith("# memory_search:")


def test_returns_hits_for_known_term(memory_home: Path) -> None:
    body = memory_search(
        "rtxclaw cypherpunk hardware",
        workspace_origin="tui", agent_home=memory_home,
        min_score=0.0, relevance_floor=0.0, top_k=5,
    )
    assert body.startswith("# memory_search:"), body[:200]
    assert "MEMORY.md" in body or "rtxclaw" in body.lower()


def test_param_coercion(memory_home: Path) -> None:
    """Out-of-range params clamp; non-numeric falls back silently."""
    body = memory_search(
        "rtxclaw",
        workspace_origin="tui",
        agent_home=memory_home,
        top_k=99,             # clamped to 20
        min_score=2.0,        # clamped to 1.0
        relevance_floor=-1.0, # clamped to 0.0
    )
    # No exception — the call succeeded with clamped values.
    assert isinstance(body, str)
    assert not body.startswith("memory_search failed"), body[:200]


def test_no_agent_home_in_env_returns_failure(tmp_path: Path) -> None:
    """When the runner can't resolve agent_home from env, the tool
    returns a structured failure string (not a traceback)."""
    # Deliberately don't pass agent_home, and tmp_path won't be
    # detected as the agent root via env vars.
    import os
    saved = {
        "RTXCLAW_AGENT_HOME": os.environ.pop("RTXCLAW_AGENT_HOME", None),
        "RTXCLAW_SESSIONS_DIR": os.environ.pop("RTXCLAW_SESSIONS_DIR", None),
    }
    try:
        body = memory_search("anything", workspace_origin="tui")
        assert "agent home not resolvable" in body or "failed:" in body
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v
