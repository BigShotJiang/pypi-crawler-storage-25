"""Step 30 — Tool deferral + ``tool_search`` coverage.

The bridge ships ~30 builtin tools. Sending the full schema list to
the upstream model on every turn costs ~10K tokens of prefill — most
of which the model never uses. New deferral path:

* ``Tool.core: bool`` marks the small "always loaded" set
  (file ops + grep + exec + todo + tool_search itself).
* ``ToolRegistry.deferred_catalog_block()`` renders a 1-line summary
  of every non-core tool into the system prompt. The model picks
  names from this catalog.
* ``run_tool_search`` runner returns the full JSON schemas for
  matched tools as part of its tool result.
* The bridge parses ``selected: name1, name2`` from the runner
  output and promotes those names — next worker round's ``tools[]``
  payload includes their schemas.

These tests pin the runner output shape, the parser contract, and
the registry split so a future refactor can't silently regress the
prefill-budget win (~8K tokens saved per turn).
"""
from __future__ import annotations

import json

import pytest

from rtxclaw_core.agents.local_llm import LocalLLMEngine
from rtxclaw_core.tools import BUILTIN_TOOLS, ToolRegistry
from rtxclaw_core.tools.runners import run_tool_search


# ---- registry split -------------------------------------------------


def test_core_set_includes_essential_tools() -> None:
    reg = ToolRegistry(BUILTIN_TOOLS)
    core_names = {t.name for t in reg.core_tools()}
    must_be_core = {
        "ToolSearch", "Read", "list_dir", "Grep",
        "Bash", "Write", "Edit", "TodoWrite",
        # `SkillSearch` is the canonical skill discovery entrypoint —
        # taught as a primitive in the SKILLS block of the system
        # prompt. Leaving it deferred made small models skip the
        # ToolSearch hop and ignore skills entirely. (Renamed from
        # the older bare `Skill` tool in commit e5b252b.)
        "SkillSearch",
    }
    assert must_be_core.issubset(core_names), (
        f"core tools missing essentials: {must_be_core - core_names}"
    )


def test_deferred_set_excludes_core_tools() -> None:
    reg = ToolRegistry(BUILTIN_TOOLS)
    core_names = {t.name for t in reg.core_tools()}
    deferred_names = {t.name for t in reg.deferred_tools()}
    assert not (core_names & deferred_names), (
        "a tool can't be both core and deferred"
    )
    assert len(deferred_names) >= 10, (
        f"deferred set looks empty: {deferred_names}"
    )


def test_filtered_schemas_includes_only_named() -> None:
    reg = ToolRegistry(BUILTIN_TOOLS)
    out = reg.filtered_schemas({"Read", "Grep"})
    names = [s["function"]["name"] for s in out]
    assert names == ["Read", "Grep"]


def test_filtered_schemas_preserves_canonical_order() -> None:
    """Schema list must follow ``BUILTIN_TOOLS`` order so the prefix
    the upstream sees is byte-stable across rounds."""
    reg = ToolRegistry(BUILTIN_TOOLS)
    # Pass names in a different order from the canonical list:
    out = reg.filtered_schemas({"Grep", "Read", "list_dir"})
    names = [s["function"]["name"] for s in out]
    canonical = [t.name for t in BUILTIN_TOOLS if t.name in
                 {"Grep", "Read", "list_dir"}]
    assert names == canonical


def test_deferred_catalog_block_lists_every_deferred_tool() -> None:
    reg = ToolRegistry(BUILTIN_TOOLS)
    block = reg.deferred_catalog_block()
    deferred_names = [t.name for t in reg.deferred_tools()]
    assert "# DEFERRED TOOLS" in block
    for name in deferred_names:
        assert f"**{name}**" in block, (
            f"deferred tool {name!r} missing from catalog block"
        )


def test_deferred_catalog_block_empty_when_no_deferred() -> None:
    """Edge case: a registry with only core tools should emit no
    block at all (no dangling header)."""
    reg = ToolRegistry(tuple(t for t in BUILTIN_TOOLS if t.core))
    assert reg.deferred_catalog_block() == ""


# ---- runner output shape --------------------------------------------


def test_select_query_returns_named_tools() -> None:
    res = run_tool_search({
        "query": "select:WebSearch,memory_search",
        "criticality": "read_only",
    })
    assert res.ok
    first_line = res.content.splitlines()[0]
    assert first_line.startswith("selected:")
    assert "WebSearch" in first_line
    assert "memory_search" in first_line


def test_keyword_query_ranks_name_match_above_description() -> None:
    """``query="memory"`` should put memory_* tools first because
    name matches score higher than description matches."""
    res = run_tool_search({"query": "memory", "criticality": "read_only"})
    assert res.ok
    first_line = res.content.splitlines()[0]
    assert first_line.startswith("selected:")
    rest = first_line.split(":", 1)[1]
    names = [n.strip() for n in rest.split(",")]
    assert names[0].startswith("memory_"), (
        f"keyword 'memory' should rank a memory_* tool first; got {names}"
    )


def test_no_match_returns_ok_with_message() -> None:
    res = run_tool_search({
        "query": "select:nonexistent_tool_name",
        "criticality": "read_only",
    })
    assert res.ok
    assert "no tools matched" in res.content


def test_empty_query_errors() -> None:
    res = run_tool_search({"query": "", "criticality": "read_only"})
    assert not res.ok


def test_selected_tools_emit_valid_json_schemas() -> None:
    """The ``<functions>`` block contains one full JSON schema per
    selected tool. Each schema must parse and have the OpenAI
    function-tool shape."""
    res = run_tool_search({
        "query": "select:WebSearch",
        "criticality": "read_only",
    })
    assert res.ok
    # Extract the JSON line(s) between <functions>...</functions>.
    inside_fn = False
    payloads: list[dict] = []
    for line in res.content.splitlines():
        if line.strip() == "<functions>":
            inside_fn = True
            continue
        if line.strip() == "</functions>":
            break
        if inside_fn and line.strip():
            payloads.append(json.loads(line))
    assert len(payloads) == 1
    assert payloads[0]["type"] == "function"
    assert payloads[0]["function"]["name"] == "WebSearch"
    assert "parameters" in payloads[0]["function"]


def test_max_results_caps_keyword_results() -> None:
    res = run_tool_search({
        "query": "tool",
        "max_results": 2,
        "criticality": "read_only",
    })
    assert res.ok
    first_line = res.content.splitlines()[0]
    rest = first_line.split(":", 1)[1] if first_line.startswith("selected:") else ""
    names = [n.strip() for n in rest.split(",") if n.strip()]
    assert 1 <= len(names) <= 2


# ---- runner-output parser contract ----------------------------------
# Re-targeted onto ``LocalLLMEngine._parse_tool_search_selected`` after
# ``CoreBackend._parse_tool_search_selection`` was removed in commit
# 5e6591e. Behavior moved into the engine — these tests still pin the
# load-bearing invariant: tool_search promotion sees the right names,
# regardless of whether the model used a ``select:`` literal query or a
# keyword query that the runner resolved.


def test_parse_tool_search_selected_extracts_names() -> None:
    body = (
        "selected: WebSearch, memory_search, remember\n\n"
        "<functions>\n{...}\n</functions>"
    )
    out = LocalLLMEngine._parse_tool_search_selected(body)
    assert out == {"WebSearch", "memory_search", "remember"}


def test_parse_tool_search_selected_handles_real_runner_output() -> None:
    """End-to-end: feed the runner output back into the parser. This is
    the regression catch for the 2026-05-18 silent break in keyword
    tool_search promotion — when the engine only looked at the model's
    INPUT query and ignored the runner's OUTPUT, the runner-selected
    names never made it into the next round's tools[]."""
    res = run_tool_search({
        "query": "select:WebSearch,memory_search",
        "criticality": "read_only",
    })
    out = LocalLLMEngine._parse_tool_search_selected(res.content)
    assert out == {"WebSearch", "memory_search"}


def test_parse_returns_empty_when_no_selection_line() -> None:
    assert LocalLLMEngine._parse_tool_search_selected(
        "ToolSearch: no tools matched 'foo'."
    ) == set()
    assert LocalLLMEngine._parse_tool_search_selected("") == set()


def test_parse_only_consumes_first_nonblank_line() -> None:
    """A ``selected:`` later in the body must NOT be consumed — the
    runner contract is that ``selected:`` is the FIRST non-blank
    line, so a stray match buried in a tool description is just
    text."""
    body = (
        "garbage prefix\n\n"
        "selected: WebSearch\n"
    )
    out = LocalLLMEngine._parse_tool_search_selected(body)
    assert out == set()


def test_parse_preserves_case_for_registry_lookup() -> None:
    """Tool registry lookup is case-sensitive; the parser MUST NOT
    lowercase the extracted names even though it does case-insensitive
    prefix matching. Regression catch for a bug discovered during the
    2026-05-18 fix."""
    out = LocalLLMEngine._parse_tool_search_selected(
        "SELECTED: WebSearch, BatchAgent\n"
    )
    assert out == {"WebSearch", "BatchAgent"}
