"""Step 54 — Follow-up fixes for PR #228 (per-agent secrets).

After codex + gemini reviewed the merged PR they flagged 14 issues
ranging from blocking (migration silently breaks MCP, save() persists
secrets to 644 config.json, headline feature doesn't apply to CLI
agents) down to year-2 papercuts (no SIGHUP reload, sync-secrets lies
about restart success). This file pins the invariants the follow-up
PR must restore.

Bugs covered (numbers match the review write-up):

  B1  shared secrets.env loaded into os.environ at gateway boot
  B2  empty string in api_keys BLOCKS env fallback (membership, not falsy)
  B3  ${VAR} header expansion checks self.api_keys first
  B4  AgentConfig.save() excludes api_keys from the persisted JSON
  B5  migrate_secrets reads mcpServers (camelCase) too
  B6  CLI engine subprocess spawn receives cfg.api_keys in its env
  B8  _load_agent_secrets warns when secrets.env is world-readable
  B9  format_dotenv rejects newline-containing values
  B10 migrate_secrets default is a known-providers allowlist
  B12 sync-secrets.sh tracks per-host restart_ok flag
"""
from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path

import pytest


def _make_cfg(**kwargs):
    """Minimal AgentConfig with one OpenRouter row referencing
    OPENROUTER_API_KEY."""
    from rtxclaw_core.agent import AgentConfig
    defaults = dict(
        name="main",
        upstream_endpoint="https://openrouter.ai/api/v1",
        upstream_model="moonshotai/kimi-k2.6",
        models=[{
            "alias": "kimi",
            "baseUrl": "https://openrouter.ai/api/v1",
            "id": "moonshotai/kimi-k2.6",
            "apiKeyEnv": "OPENROUTER_API_KEY",
        }],
    )
    defaults.update(kwargs)
    return AgentConfig(**defaults)


# ---------------------------------------------------------------------------
# B2 — empty string in api_keys MUST block env fallback
# ---------------------------------------------------------------------------


def test_b2_empty_api_keys_value_blocks_env_fallback(monkeypatch) -> None:
    """Operator workflow: 'I want the scraper agent to NEVER hit
    OpenRouter, so I'll put OPENROUTER_API_KEY= in its secrets.env to
    block.' Pre-fix the empty string was falsy → fell through to env →
    silently used the shared key. Per-agent attribution defeated."""
    cfg = _make_cfg(api_keys={"OPENROUTER_API_KEY": ""})
    monkeypatch.setenv("OPENROUTER_API_KEY", "ENV-SHOULD-NOT-WIN")
    headers = cfg.upstream_headers()
    # Empty per-agent override → no Authorization (the operator wants
    # this agent NOT to authenticate).
    assert "Authorization" not in headers


def test_b2_audit_distinguishes_disabled_from_missing(monkeypatch) -> None:
    """``audit_api_keys()`` must distinguish 'operator explicitly
    blanked this' from 'nobody set it' so the boot log doesn't lie."""
    cfg = _make_cfg(api_keys={"OPENROUTER_API_KEY": ""})
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    audit = cfg.audit_api_keys()
    assert audit["OPENROUTER_API_KEY"] in (
        "agent-local-empty", "disabled", "agent-empty",
    ), f"unexpected audit status {audit['OPENROUTER_API_KEY']!r}"


# ---------------------------------------------------------------------------
# B3 — ${VAR} header expansion checks api_keys first
# ---------------------------------------------------------------------------


def test_b3_var_header_expansion_uses_api_keys(monkeypatch) -> None:
    """Header-based providers (x-api-key for Bedrock/Azure, etc.) must
    also pick up the per-agent override."""
    from rtxclaw_core.agent import AgentConfig
    cfg = AgentConfig(
        name="main",
        upstream_endpoint="https://bedrock.example/v1",
        upstream_model="claude-3-bedrock",
        models=[{
            "alias": "bedrock",
            "baseUrl": "https://bedrock.example/v1",
            "id": "claude-3-bedrock",
            "headers": {"x-api-key": "${BEDROCK_KEY}"},
        }],
        api_keys={"BEDROCK_KEY": "agent-local-bedrock-key"},
    )
    monkeypatch.setenv("BEDROCK_KEY", "env-bedrock-key")
    headers = cfg.upstream_headers()
    assert headers.get("x-api-key") == "agent-local-bedrock-key"


# ---------------------------------------------------------------------------
# B4 — AgentConfig.save() excludes api_keys
# ---------------------------------------------------------------------------


def test_b4_save_excludes_api_keys(tmp_path: Path, monkeypatch) -> None:
    """First time the operator toggles heartbeat / re-runs the wizard,
    AgentConfig.save() writes the per-agent JSON. api_keys MUST NOT
    round-trip — that'd duplicate every secret into a 644 file that
    isn't gitignored by name."""
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = _make_cfg(api_keys={"OPENROUTER_API_KEY": "super-secret"})
    (tmp_path / "agents" / "main").mkdir(parents=True)
    cfg.save()
    body = (tmp_path / "agents" / "main" / "config.json").read_text(encoding="utf-8")
    parsed = json.loads(body)
    assert "api_keys" not in parsed, (
        f"AgentConfig.save() leaked api_keys into config.json:\n{body}"
    )
    # And the secret value never appears anywhere in the file.
    assert "super-secret" not in body


# ---------------------------------------------------------------------------
# B5 — migrate_secrets reads mcpServers (camelCase)
# ---------------------------------------------------------------------------


def test_b5_migration_handles_camelcase_mcpservers(tmp_path: Path) -> None:
    """The runtime canonical key for MCP server config is camelCase
    ``mcpServers``; the wizard writes that. Migration was reading only
    snake_case ``mcp_servers`` so wizard-built installs reported 0
    keys and stripped nothing — the kimi bug ships through."""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
    try:
        import migrate_secrets as ms
    finally:
        sys.path.pop(0)

    cfg = {
        "mcpServers": {  # canonical camelCase, not snake_case
            "youtube": {
                "command": "python",
                "args": ["-m", "youtube_mcp"],
                "env": {"OPENROUTER_API_KEY": "sk-or-from-mcp"},
            },
        },
    }
    (tmp_path / "config.json").write_text(
        json.dumps(cfg), encoding="utf-8",
    )

    from_mcp, raw_cfg = ms.gather_from_config_mcp_env(tmp_path)
    assert from_mcp.get("OPENROUTER_API_KEY") == "sk-or-from-mcp", (
        "migration didn't pick up keys from mcpServers (camelCase) — "
        "wizard-built configs would still ship the kimi bug"
    )
    stripped_cfg, stripped_names = ms.strip_mcp_env_blocks(raw_cfg)
    assert "youtube" in stripped_names
    assert "env" not in stripped_cfg["mcpServers"]["youtube"]


# ---------------------------------------------------------------------------
# B8 — _load_agent_secrets warns on world-readable file
# ---------------------------------------------------------------------------


def test_b8_warns_on_world_readable_secrets(tmp_path: Path, caplog) -> None:
    from rtxclaw_core.agent import _load_agent_secrets

    sec = tmp_path / "secrets.env"
    sec.write_text("OPENROUTER_API_KEY=secret\n", encoding="utf-8")
    os.chmod(sec, 0o644)  # world-readable

    with caplog.at_level(logging.WARNING, logger="rtxclaw.agent"):
        out = _load_agent_secrets(tmp_path, "main")

    assert out.get("OPENROUTER_API_KEY") == "secret"
    # Warning fired and mentions the offending file + mode.
    msgs = " ".join(r.getMessage() for r in caplog.records)
    assert "644" in msgs or "world" in msgs.lower() or "mode" in msgs.lower()
    assert str(sec) in msgs or "secrets.env" in msgs


def test_b8_no_warn_on_strict_mode(tmp_path: Path, caplog) -> None:
    from rtxclaw_core.agent import _load_agent_secrets
    sec = tmp_path / "secrets.env"
    sec.write_text("OPENROUTER_API_KEY=secret\n", encoding="utf-8")
    os.chmod(sec, 0o600)
    with caplog.at_level(logging.WARNING, logger="rtxclaw.agent"):
        _load_agent_secrets(tmp_path, "main")
    assert not [r for r in caplog.records if "mode" in r.getMessage().lower()]


# ---------------------------------------------------------------------------
# B9 — format_dotenv rejects newline-containing values
# ---------------------------------------------------------------------------


def test_b9_format_dotenv_rejects_newlines() -> None:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
    try:
        import migrate_secrets as ms
    finally:
        sys.path.pop(0)

    bad_keys = {"BLOOMBERG_PEM_TOKEN": "line1\nline2"}
    with pytest.raises((ValueError, RuntimeError, SystemExit)):
        ms.format_dotenv(bad_keys)


def test_b9_format_dotenv_preserves_existing_comments(tmp_path: Path) -> None:
    """Operator hand-curates `# OpenRouter section` headers. Re-running
    migrate_secrets must NOT clobber comments / blank-line grouping —
    pre-fix every re-run rewrote the file from scratch."""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
    try:
        import migrate_secrets as ms
    finally:
        sys.path.pop(0)

    existing = (
        "# === Providers (operator-organized) ===\n"
        "\n"
        "# OpenRouter sub-accounts\n"
        "OPENROUTER_API_KEY=old-value\n"
        "\n"
        "# OpenAI Projects\n"
        "OPENAI_API_KEY=oai-old\n"
    )
    sec = tmp_path / "secrets.env"
    sec.write_text(existing, encoding="utf-8")
    new_keys = {
        "OPENROUTER_API_KEY": "new-value",   # update existing
        "OPENAI_API_KEY": "oai-old",         # unchanged
        "ANTHROPIC_API_KEY": "anth-new",     # new key, appended
    }
    out = ms.format_dotenv(new_keys, existing_text=existing)
    # Comments preserved.
    assert "# === Providers (operator-organized) ===" in out
    assert "# OpenRouter sub-accounts" in out
    assert "# OpenAI Projects" in out
    # Updated value lands inline (replaces the old KEY= line).
    assert "OPENROUTER_API_KEY=new-value" in out
    assert "old-value" not in out
    # Unchanged value untouched.
    assert "OPENAI_API_KEY=oai-old" in out
    # New key appended at the end.
    assert "ANTHROPIC_API_KEY=anth-new" in out


# ---------------------------------------------------------------------------
# B10 — allowlist default
# ---------------------------------------------------------------------------


def test_b10_allowlist_drops_unrelated_secrets() -> None:
    """The catch-all regex (`_API_KEY|_TOKEN|_BEARER|_SECRET`) scoops
    up GIT_TOKEN, GITEA_TOKEN, ALPHAVANTAGE_TOKEN, etc. — none of
    which are provider keys, and shipping them across hosts via
    sync-secrets is cross-host secret leakage. Default behaviour must
    be an allowlist of known providers."""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
    try:
        import migrate_secrets as ms
    finally:
        sys.path.pop(0)

    candidates = {
        "OPENROUTER_API_KEY": "or",
        "OPENAI_API_KEY": "oai",
        "ANTHROPIC_API_KEY": "anth",
        "XAI_API_KEY": "xai",
        "DEEPSEEK_API_KEY": "ds",
        "GROQ_API_KEY": "groq",
        # Not provider keys — must be excluded by default.
        "GITEA_TOKEN": "g",
        "GIT_TOKEN": "g2",
        "ALPHAVANTAGE_TOKEN": "av",
        "SHAREDDATA_TOKEN": "sd",
        "CLOUDFLARE_TOKEN": "cf",
    }
    kept = ms.filter_provider_keys(candidates, include_all=False)
    # Provider keys kept.
    assert "OPENROUTER_API_KEY" in kept
    assert "OPENAI_API_KEY" in kept
    assert "ANTHROPIC_API_KEY" in kept
    assert "XAI_API_KEY" in kept
    assert "DEEPSEEK_API_KEY" in kept
    assert "GROQ_API_KEY" in kept
    # Non-provider keys dropped.
    assert "GITEA_TOKEN" not in kept
    assert "GIT_TOKEN" not in kept
    assert "ALPHAVANTAGE_TOKEN" not in kept
    assert "SHAREDDATA_TOKEN" not in kept
    assert "CLOUDFLARE_TOKEN" not in kept

    # --include-all opt-in restores the legacy catch-all behaviour.
    all_kept = ms.filter_provider_keys(candidates, include_all=True)
    assert "GITEA_TOKEN" in all_kept


# ---------------------------------------------------------------------------
# B1 — shared secrets.env is loaded into os.environ at gateway boot
# ---------------------------------------------------------------------------


def test_b1_load_shared_secrets_to_environ(tmp_path: Path, monkeypatch) -> None:
    """Stripping the MCP `env:` blocks only works if the shared
    secrets get pushed into the process env so the MCP launcher's
    `{**os.environ, **server.env}` chain still carries them."""
    from rtxclaw_agent import gateway as gw

    sec = tmp_path / "secrets.env"
    sec.write_text(
        "OPENROUTER_API_KEY=shared-or\n"
        "YOUTUBE_TRANSCRIPT_KEY=shared-yt\n",
        encoding="utf-8",
    )
    os.chmod(sec, 0o600)

    # Pre-existing env wins (don't clobber what systemd / shell set).
    monkeypatch.setenv("OPENROUTER_API_KEY", "pre-existing-env")
    monkeypatch.delenv("YOUTUBE_TRANSCRIPT_KEY", raising=False)

    gw.load_shared_secrets_into_environ(tmp_path)

    # Pre-existing env preserved (setdefault semantics).
    assert os.environ["OPENROUTER_API_KEY"] == "pre-existing-env"
    # Missing env populated from secrets.env.
    assert os.environ["YOUTUBE_TRANSCRIPT_KEY"] == "shared-yt"


def test_b1_no_shared_file_is_noop(tmp_path: Path) -> None:
    from rtxclaw_agent import gateway as gw
    # Just verify it doesn't raise.
    gw.load_shared_secrets_into_environ(tmp_path)


# ---------------------------------------------------------------------------
# B6 — CLI delegate spawn env injection
# ---------------------------------------------------------------------------


def test_b6_build_delegate_spawn_env_overlays_api_keys(monkeypatch) -> None:
    """When the engine passed ``_spawn_env_overrides`` (per-agent
    api_keys), the runner must produce an env where overrides WIN
    over os.environ, and other env vars pass through. That's how
    each CLI agent's claude/codex/gemini subprocess hits its OWN
    provider sub-account."""
    from rtxclaw_core.tools.runners import _build_delegate_spawn_env

    monkeypatch.setenv("OPENROUTER_API_KEY", "from-process-env")
    monkeypatch.setenv("PATH", "/usr/bin:/bin")
    args = {
        "_spawn_env_overrides": {"OPENROUTER_API_KEY": "from-per-agent-secrets"},
    }
    env = _build_delegate_spawn_env(args)
    assert env is not None
    # Per-agent override wins.
    assert env["OPENROUTER_API_KEY"] == "from-per-agent-secrets"
    # Unrelated env vars pass through.
    assert env["PATH"] == "/usr/bin:/bin"


def test_b6_build_delegate_spawn_env_returns_none_when_no_overrides() -> None:
    """No overrides → return None so the runner passes ``env=None``
    and the subprocess inherits the parent's env verbatim (legacy
    behaviour preserved for agents with empty api_keys)."""
    from rtxclaw_core.tools.runners import _build_delegate_spawn_env
    assert _build_delegate_spawn_env({}) is None
    assert _build_delegate_spawn_env({"_spawn_env_overrides": {}}) is None
    assert _build_delegate_spawn_env(
        {"_spawn_env_overrides": None},
    ) is None
