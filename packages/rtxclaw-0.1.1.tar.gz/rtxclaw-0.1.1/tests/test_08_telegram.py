"""Step 08 — telegram bot (standalone service).

The Telegram bot is its own service (``rtxclaw-telegram.service``)
with its own home at ``~/.rtxclaw/telegram/``. It is **no longer**
spawned by the agent gateway. These tests cover:

1. The module is importable in the user's venv.
2. ``rtxclaw configure --telegram-bot-token`` writes to the bot's own
   config (``<telegram_home>/config.json``), not the per-agent file.
3. The token round-trips through Telegram's ``getMe`` API.
4. ``rtxclaw telegram start`` daemonises the bot, ``stop`` reaps it,
   and the process appears in ``pgrep`` while running. The agent's
   gateway stays running across this — proving decoupling.

Drives the **real** Telegram bot resolved by the
``configured_telegram_token`` / ``configured_telegram_chat_id``
fixtures (sourced from ``tests/.env``). No fakes — if the credentials
aren't populated, the session aborts in
``conftest.py::configured_telegram_token`` exactly the same way the
upstream-endpoint check aborts in step 06.
"""
from __future__ import annotations

import inspect
import json
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Any

import pytest

from conftest import RTXCLAW_BIN



# Per-test @pytest.mark.slow below — file mixes 5 daemon/network/venv
# tests with 1 pure-unit decoupling assertion
# (test_runtime_no_longer_spawns_poller). File-level pytestmark would
# exile the unit test along with the others.

# ---- tier 1: always ------------------------------------------------------


@pytest.mark.slow
def test_telegram_module_imports(run_in_venv) -> None:
    cp = run_in_venv(
        "import rtxclaw_telegram.bot as _; "
        "import rtxclaw_telegram.config as _c; "
        "import rtxclaw_telegram.cli as _cli; "
        "print('ok')",
    )
    assert cp.returncode == 0, cp.stderr
    assert "ok" in cp.stdout


def _telegram_home(sandbox_home: Path) -> Path:
    return sandbox_home / "telegram"


@pytest.mark.slow
def test_configure_persists_token(
    sandbox_home: Path, scaffolded_agent: Path, run_rtxclaw,
    configured_telegram_token: str,
) -> None:
    """``--telegram-bot-token`` lands in the bot's standalone config,
    NOT in the per-agent file.
    """
    cp = run_rtxclaw(
        "configure", "--agent", "main",
        "--telegram-bot-token", configured_telegram_token,
    )
    assert cp.returncode == 0, cp.stderr

    bot_cfg_path = _telegram_home(sandbox_home) / "config.json"
    assert bot_cfg_path.is_file(), f"missing {bot_cfg_path}"
    bot_cfg = json.loads(bot_cfg_path.read_text())
    assert bot_cfg.get("bot_token") == configured_telegram_token

    # The agent config must NOT carry the token any more — that's the
    # whole point of decoupling.
    agent_cfg = json.loads((scaffolded_agent / "config.json").read_text())
    assert "telegram_bot_token" not in agent_cfg


@pytest.mark.slow
def test_configure_persists_allowed_chat_ids(
    sandbox_home: Path, run_rtxclaw,
    configured_telegram_chat_id: str,
) -> None:
    cp = run_rtxclaw(
        "configure", "--agent", "main",
        "--telegram-allowed-chat-ids", configured_telegram_chat_id,
    )
    assert cp.returncode == 0, (
        f"--telegram-allowed-chat-ids failed:\n{cp.stderr}"
    )
    bot_cfg_path = _telegram_home(sandbox_home) / "config.json"
    assert bot_cfg_path.is_file(), f"missing {bot_cfg_path}"
    bot_cfg = json.loads(bot_cfg_path.read_text())
    raw = bot_cfg.get("allowed_chat_ids") or []
    assert int(configured_telegram_chat_id) in raw


@pytest.mark.slow
def test_telegram_token_reaches_api(configured_telegram_token: str) -> None:
    """getMe round-trip — proves the token actually authenticates."""
    import urllib.request
    url = f"https://api.telegram.org/bot{configured_telegram_token}/getMe"
    with urllib.request.urlopen(url, timeout=10) as resp:
        body = json.loads(resp.read())
    assert body.get("ok") is True, f"getMe failed: {body}"
    assert "result" in body and "id" in body["result"], body


def test_runtime_no_longer_spawns_poller() -> None:
    """The agent runtime must NOT spawn the Telegram bot any more.

    Decoupling assertion: the gateway / acp-stdio entry points
    should not reference the Telegram poller. Both the legacy
    ``runtime.serve`` and its successor ``gateway.serve_gateway``
    are checked — whichever one exists in the current architecture
    must keep its hands off ``rtxclaw_telegram.bot``.
    """
    targets: list[Any] = []
    # Legacy per-agent daemon entry point. Gone in the gateway
    # architecture, but the back-compat stub may still ship for
    # transition releases — guard the lookup.
    try:
        import rtxclaw_agent.runtime as r
        if hasattr(r, "serve"):
            targets.append(r.serve)
    except ImportError:
        pass
    # Current gateway entry point. ``serve_gateway`` runs the
    # single-process child manager + ACP HTTP listener. Adding the
    # Telegram poller back into that flow would re-couple them.
    try:
        from rtxclaw_agent.gateway import serve_gateway
        targets.append(serve_gateway)
    except ImportError:
        pass
    # Modern stdio entry point. Per-agent stdio child for the
    # gateway — also must not pull the bot in.
    try:
        from rtxclaw_agent.acp_stdio_main import serve_acp_stdio
        targets.append(serve_acp_stdio)
    except ImportError:
        pass

    assert targets, (
        "no agent serve entry point found — neither runtime.serve nor "
        "gateway.serve_gateway nor acp_stdio_main.serve_acp_stdio is "
        "importable"
    )
    for fn in targets:
        src = inspect.getsource(fn)
        assert "_spawn_telegram_poller" not in src, (
            f"{fn.__qualname__} still spawns the Telegram poller — "
            "decoupling regressed"
        )
        assert "rtxclaw_telegram.bot" not in src, (
            f"{fn.__qualname__} still launches rtxclaw_telegram.bot directly"
        )


# ---- standalone bot lifecycle -------------------------------------------


def _pgrep_poller(home: Path | None = None) -> int | None:
    """Find a ``python -m rtxclaw_telegram.bot`` process.

    When ``home`` is given, only return pids whose ``RTXCLAW_HOME``
    env var matches ``home`` — so a developer running this on a
    machine that already has a real production bot (rooted at
    ``~/.rtxclaw/telegram``) doesn't see the production process and
    misreport it as a test-bot leak.
    """
    cp = subprocess.run(
        ["pgrep", "-f", r"python.* -m rtxclaw_telegram\.bot"],
        capture_output=True, text=True,
    )
    if cp.returncode != 0:
        return None
    pids = [int(x) for x in cp.stdout.split() if x.strip().isdigit()]
    if not pids:
        return None
    if home is None:
        return pids[0]
    wanted = str(Path(home).resolve())
    for pid in pids:
        try:
            env_blob = Path(f"/proc/{pid}/environ").read_bytes()
        except OSError:
            continue
        for entry in env_blob.split(b"\0"):
            if entry.startswith(b"RTXCLAW_HOME="):
                if entry[len(b"RTXCLAW_HOME="):].decode("utf-8", "replace") == wanted:
                    return pid
                break
    return None


@pytest.mark.slow
def test_telegram_start_stop(
    sandbox_home: Path, scaffolded_agent: Path, run_rtxclaw,
    configured_telegram_token: str,
) -> None:
    """``rtxclaw telegram start`` daemonises the bot independently of
    any agent. Stopping the agent does NOT kill the bot.
    """
    # Configure the bot.
    cp = run_rtxclaw(
        "configure", "--agent", "main",
        "--telegram-bot-token", configured_telegram_token,
    )
    assert cp.returncode == 0, cp.stderr

    # Make sure the bot starts in a clean state.
    run_rtxclaw("telegram", "stop")
    time.sleep(0.5)

    cp = run_rtxclaw("telegram", "start", timeout=30)
    assert cp.returncode == 0, f"telegram start failed:\n{cp.stderr}"

    pid = None
    for _ in range(20):
        pid = _pgrep_poller(sandbox_home)
        if pid:
            break
        time.sleep(0.5)
    assert pid, "no python -m rtxclaw_telegram.bot process appeared"

    # Bot lives on its own under <home>/telegram/.
    tg_home = _telegram_home(sandbox_home)
    assert (tg_home / "telegram.pid").is_file()
    assert (tg_home / "logs" / "telegram.log").is_file()

    # Stop via the standalone CLI; the agent gateway is irrelevant.
    cp = run_rtxclaw("telegram", "stop", timeout=15)
    assert cp.returncode == 0, f"telegram stop failed:\n{cp.stderr}"

    time.sleep(1)
    still = _pgrep_poller(sandbox_home)
    if still:
        try:
            os.kill(still, signal.SIGTERM)
        except ProcessLookupError:
            pass
        pytest.fail(f"bot (pid={still}) survived telegram stop")
