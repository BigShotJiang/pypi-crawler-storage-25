"""Step 54 — images are made safe for the selected model.

Background: a user attached an image to a session whose selected
model was ``deepseek-v4-flash`` — a text-only model. The bridge
translated the image into the OpenAI ``image_url`` multi-part shape
(test_39 pins that), the worker POSTed it to DeepSeek, and DeepSeek
rejected it::

    HTTP 400: unknown variant `image_url`, expected `text`

Worse, the offending message stayed in the transcript, so every
subsequent turn re-sent it and re-failed until the session was
dropped.

The fix wires the previously-unused ``capabilities`` model-config
field (and the ``has_capability`` / ``find_model_with_capability``
helpers) into the worker-spawn path: when the selected model is NOT
vision-capable, ``image_url`` parts are routed to the first
vision-capable model for a one-shot transcription and spliced back as
text. When no vision model is configured (or transcription fails) the
image becomes a short placeholder so the turn still runs.

Tests pin: passthrough for vision models, transcribe-and-splice for
text-only models, graceful placeholder on missing-vision-model and on
transcription failure, and that text-only prompts are untouched.
"""
from __future__ import annotations

import pytest

from rtxclaw_agent import acp_bridge
from rtxclaw_agent.acp_bridge import (
    CoreBackend,
    _message_image_parts,
    _resolve_images_for_model,
)
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.session import Session


# ---- fixtures ------------------------------------------------------

_VISION_URL = "https://openrouter.ai/api/v1"
_TEXT_URL = "https://api.deepseek.com/v1"

_IMAGE_PART = {
    "type": "image_url",
    "image_url": {"url": "data:image/jpeg;base64,aGVsbG8="},
}


def _backend() -> CoreBackend:
    cfg = AgentConfig(name="t", system="sys")
    cfg.models = [
        {
            "alias": "deepseek",
            "baseUrl": _TEXT_URL,
            "id": "deepseek-v4-flash",
            "backend": "unknown",
            "capabilities": [],
        },
        {
            "alias": "kimi",
            "baseUrl": _VISION_URL,
            "id": "moonshotai/kimi-k2.6",
            "backend": "unknown",
            "capabilities": ["vision"],
        },
    ]
    return CoreBackend(cfg)


def _session(endpoint: str, model: str) -> Session:
    return Session.new(
        system_prompt="sys", model=model, endpoint=endpoint, system_mode="auto",
    )


@pytest.fixture(autouse=True)
def _clear_cache():
    acp_bridge._TRANSCRIPTION_CACHE.clear()
    yield
    acp_bridge._TRANSCRIPTION_CACHE.clear()


# ---- _message_image_parts -----------------------------------------


def test_message_image_parts_finds_images() -> None:
    content = [{"type": "text", "text": "look"}, dict(_IMAGE_PART)]
    parts = _message_image_parts(content)
    assert len(parts) == 1 and parts[0]["type"] == "image_url"


def test_message_image_parts_empty_for_string_content() -> None:
    assert _message_image_parts("just text") == []
    assert _message_image_parts([{"type": "text", "text": "x"}]) == []


# ---- passthrough / no-op cases ------------------------------------


@pytest.mark.asyncio
async def test_text_only_messages_untouched() -> None:
    """No image anywhere → messages returned as-is, no model lookup."""
    backend = _backend()
    sess = _session(_TEXT_URL, "deepseek-v4-flash")
    msgs = [{"role": "user", "content": "hello"}]
    out = await _resolve_images_for_model(backend, sess, msgs)
    assert out == msgs


@pytest.mark.asyncio
async def test_vision_model_passes_image_through(monkeypatch) -> None:
    """Selected model IS vision-capable → image_url survives untouched
    and the vision-transcription worker is never spawned."""
    backend = _backend()
    sess = _session(_VISION_URL, "moonshotai/kimi-k2.6")

    async def _boom(*a, **k):  # pragma: no cover - must not be called
        raise AssertionError("transcription worker spawned for a vision model")

    monkeypatch.setattr(acp_bridge, "_run_oneshot_worker", _boom)

    msgs = [{"role": "user", "content": [{"type": "text", "text": "hi"}, dict(_IMAGE_PART)]}]
    out = await _resolve_images_for_model(backend, sess, msgs)
    assert _message_image_parts(out[0]["content"]), "image_url must survive for a vision model"


# ---- transcribe-and-splice ----------------------------------------


@pytest.mark.asyncio
async def test_text_model_transcribes_and_splices(monkeypatch) -> None:
    """Selected model is text-only + a vision model is configured →
    image_url is replaced with the vision model's transcription."""
    backend = _backend()
    sess = _session(_TEXT_URL, "deepseek-v4-flash")

    captured: dict = {}

    async def _fake(cfg, vision_row, image_parts, caption):
        captured["row"] = dict(vision_row)
        captured["caption"] = caption
        captured["n"] = len(image_parts)
        return "a red error dialog reading 'page failed to load'"

    monkeypatch.setattr(acp_bridge, "_transcribe_image_parts", _fake)

    msgs = [{
        "role": "user",
        "content": [
            {"type": "text", "text": "[Turn 0] what is this?"},
            dict(_IMAGE_PART),
        ],
    }]
    out = await _resolve_images_for_model(backend, sess, msgs)

    # Routed to the vision-capable row, not the selected text-only one.
    assert captured["row"]["alias"] == "kimi"
    assert captured["n"] == 1
    assert "what is this?" in captured["caption"]

    # image_url is gone; the transcription + original text remain.
    assert not _message_image_parts(out[0]["content"])
    flat = out[0]["content"]
    assert isinstance(flat, str), "all-text content should collapse to a string"
    assert "what is this?" in flat
    assert "page failed to load" in flat


@pytest.mark.asyncio
async def test_transcription_failure_falls_back_to_placeholder(monkeypatch) -> None:
    """Vision call raises → image becomes a placeholder, turn not crashed."""
    backend = _backend()
    sess = _session(_TEXT_URL, "deepseek-v4-flash")

    async def _fail(*a, **k):
        raise RuntimeError("openrouter 401")

    monkeypatch.setattr(acp_bridge, "_transcribe_image_parts", _fail)

    msgs = [{"role": "user", "content": [dict(_IMAGE_PART)]}]
    out = await _resolve_images_for_model(backend, sess, msgs)

    assert not _message_image_parts(out[0]["content"])
    flat = out[0]["content"]
    assert "could not be transcribed" in flat
    assert "openrouter 401" in flat


@pytest.mark.asyncio
async def test_no_vision_model_configured_uses_placeholder() -> None:
    """No model carries the ``vision`` capability → image becomes a
    placeholder rather than crashing the text-only upstream."""
    cfg = AgentConfig(name="t", system="sys")
    cfg.models = [{
        "alias": "deepseek",
        "baseUrl": _TEXT_URL,
        "id": "deepseek-v4-flash",
        "backend": "unknown",
        "capabilities": [],
    }]
    backend = CoreBackend(cfg)
    sess = _session(_TEXT_URL, "deepseek-v4-flash")

    msgs = [{"role": "user", "content": [{"type": "text", "text": "hi"}, dict(_IMAGE_PART)]}]
    out = await _resolve_images_for_model(backend, sess, msgs)

    assert not _message_image_parts(out[0]["content"])
    flat = out[0]["content"]
    assert "no vision-capable model is configured" in flat
    assert "hi" in flat


@pytest.mark.asyncio
async def test_transcription_cache_avoids_resend(monkeypatch) -> None:
    """The same image replayed across turns is transcribed once."""
    backend = _backend()
    sess = _session(_TEXT_URL, "deepseek-v4-flash")

    calls = {"n": 0}

    async def _fake_worker(request, *, timeout_s: float = 90.0):
        calls["n"] += 1
        return "TRANSCRIPT"

    monkeypatch.setattr(acp_bridge, "_run_oneshot_worker", _fake_worker)

    msgs = [{"role": "user", "content": [dict(_IMAGE_PART)]}]
    await _resolve_images_for_model(backend, sess, list(msgs))
    await _resolve_images_for_model(backend, sess, list(msgs))
    assert calls["n"] == 1, "second resolve of the same image must hit the cache"
