"""Step 13 — Auto-compaction (compact_messages) unit coverage.

Lives in ``src/rtxclaw_core/turn_runtime.py:compact_messages``. The
function is a deterministic three-stage squeeze used both reactively
(after a vLLM "max_tokens" overflow) and proactively (when running
prompt size approaches ``compact_at_frac × upstream_max_context``).

A bug here can:

* dangle ``tool_call_id`` refs (tool messages without a matching
  ``assistant.tool_calls``) — vLLM 400.
* drop the most-recent user message — vLLM 400 "no user query".
* leave the prompt over budget when the protected set is too big
  (acceptable — the rescaler handles it — but should be flagged in
  the audit dict so the bridge can surface a warning).

These tests anchor on those invariants explicitly so future refactors
can't silently regress them.
"""
from __future__ import annotations

from rtxclaw_core.turn_runtime import _approx_tokens, compact_messages


def _msg(role: str, content: str = "", **extra) -> dict:
    return {"role": role, "content": content, **extra}


def test_under_target_is_noop() -> None:
    msgs = [
        _msg("system", "you are a helper"),
        _msg("user", "hi"),
        _msg("assistant", "hello"),
    ]
    out, removed, audit = compact_messages(msgs, target_tokens=100_000)
    assert out == msgs
    assert removed == 0
    assert audit == {
        "truncated_tool_call_ids": [],
        "dropped_tool_call_ids": [],
        "dropped_turns": 0,
    }


def test_stage1_truncates_large_tool_results() -> None:
    """Tool result > 800 chars in the head gets compacted to head+marker."""
    big = "X" * 5000
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "ls", "arguments": "{}"}},
        ]),
        _msg("tool", big, tool_call_id="t1"),
        _msg("user", "what's next"),
        _msg("assistant", "thinking"),
    ]
    target = _approx_tokens(msgs) - 500  # force squeeze
    out, removed, audit = compact_messages(msgs, target_tokens=target)
    assert removed > 0
    assert "t1" in audit["truncated_tool_call_ids"]
    tool_msg = next(m for m in out if m.get("role") == "tool")
    assert "[compacted:" in tool_msg["content"]
    assert len(tool_msg["content"]) < 1000


def test_stage2_drops_tool_then_strips_tool_call() -> None:
    """If stage 1 isn't enough, the oldest tool message is dropped AND
    its matching ``assistant.tool_calls[]`` entry pruned so no dangling
    ref survives."""
    huge = "X" * 200_000  # too big for stage 1 truncation alone
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "scan", "arguments": "{}"}},
        ]),
        _msg("tool", huge, tool_call_id="t1"),
        _msg("user", "live"),
        _msg("assistant", "answer"),
    ]
    out, _removed, audit = compact_messages(msgs, target_tokens=200)
    # Stage 2 should have run: tool dropped, audit promoted.
    assert "t1" in audit["dropped_tool_call_ids"]
    # No dangling assistant.tool_calls referencing t1.
    for m in out:
        if m.get("role") == "assistant" and m.get("tool_calls"):
            for tc in m["tool_calls"]:
                assert tc.get("id") != "t1"


def test_stage2_drops_empty_tool_calls_key_when_assistant_has_content() -> None:
    """Regression: pruning a dropped tool's ``tool_calls[]`` entry must
    never leave an assistant with ``tool_calls: []``.

    OpenAI-compatible backends 400 with ``Invalid 'messages[N].tool_calls':
    empty array. Expected an array with minimum length 1`` (observed
    2026-05-21). When the assistant that owned the dropped tool ALSO has
    content, the message is kept — so the now-empty ``tool_calls`` list
    must be removed entirely, not left as ``[]``.
    """
    huge = "X" * 200_000  # forces stage 2
    msgs = [
        _msg("system", "sys"),
        # Assistant has BOTH content and a tool call → survives the drop.
        _msg("assistant", "here is my analysis", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "scan", "arguments": "{}"}},
        ]),
        _msg("tool", huge, tool_call_id="t1"),
        _msg("user", "live"),
        _msg("assistant", "answer"),
    ]
    out, _removed, audit = compact_messages(msgs, target_tokens=200)
    assert "t1" in audit["dropped_tool_call_ids"]
    # The content-bearing assistant survives ...
    survivor = next(
        (m for m in out
         if m.get("role") == "assistant"
         and m.get("content") == "here is my analysis"),
        None,
    )
    assert survivor is not None, f"content assistant wrongly dropped:\n{out}"
    # ... but with NO empty tool_calls array (key removed entirely).
    assert "tool_calls" not in survivor, (
        f"empty tool_calls key left on surviving assistant "
        f"(backends 400 on []): {survivor!r}"
    )
    # Belt-and-suspenders: no message anywhere has an empty tool_calls.
    for m in out:
        assert m.get("tool_calls") != [], (
            f"empty tool_calls array survived compaction: {m!r}"
        )


def test_protected_user_never_dropped_even_at_low_target() -> None:
    """The most-recent user message must survive every stage."""
    msgs = [_msg("system", "sys")]
    # 50 turns of historical chatter, then the live user.
    for i in range(50):
        msgs.append(_msg("user", f"user old {i} " * 50))
        msgs.append(_msg("assistant", f"assistant old {i} " * 50))
    msgs.append(_msg("user", "THE LIVE QUESTION"))
    msgs.append(_msg("assistant", "in flight"))

    out, _removed, _audit = compact_messages(msgs, target_tokens=20)
    user_msgs = [m for m in out if m.get("role") == "user"]
    assert any(
        m.get("content") == "THE LIVE QUESTION" for m in user_msgs
    ), f"protected user message dropped:\n{user_msgs}"


def test_load_bearing_assistant_kept_when_tool_in_tail() -> None:
    """If a tool message survives in the tail, the assistant whose
    tool_calls produced it must NOT be dropped — otherwise vLLM 400."""
    msgs = [
        _msg("system", "sys"),
        # Old (drop-able) chatter.
        _msg("user", "old user " * 200),
        _msg("assistant", "old assistant " * 200),
        # Load-bearing pair — tool sits in the kept tail (last 2).
        _msg("assistant", "", tool_calls=[
            {"id": "tk", "type": "function",
             "function": {"name": "Read", "arguments": "{}"}},
        ]),
        _msg("tool", "result", tool_call_id="tk"),
    ]
    # Force aggressive compaction.
    out, _removed, _audit = compact_messages(msgs, target_tokens=10)
    # The load-bearing assistant must still be in the output.
    assert any(
        m.get("role") == "assistant"
        and any(
            tc.get("id") == "tk" for tc in (m.get("tool_calls") or [])
        )
        for m in out
    ), f"load-bearing assistant pruned (would dangle tk):\n{out}"


def test_audit_truncated_promoted_to_dropped_in_stage2() -> None:
    """When a tool entry truncated in stage 1 is then dropped in stage
    2, it must move from ``truncated_tool_call_ids`` to
    ``dropped_tool_call_ids`` (no double-counting)."""
    big = "Y" * 50_000
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "f", "arguments": "{}"}},
        ]),
        _msg("tool", big, tool_call_id="t1"),
        _msg("user", "live"),
        _msg("assistant", "answer"),
    ]
    out, _removed, audit = compact_messages(msgs, target_tokens=50)
    assert "t1" in audit["dropped_tool_call_ids"]
    # Promotion happened — should not appear in both lists.
    assert "t1" not in audit["truncated_tool_call_ids"]


def test_returns_some_progress_even_when_only_protected_remain() -> None:
    """If the protected tail alone overflows, we don't loop forever —
    we return whatever survives + the audit so callers can decide."""
    msgs = [
        _msg("system", "sys " * 1000),
        _msg("user", "live " * 5000),
        _msg("assistant", "drafting " * 5000),
    ]
    out, removed, audit = compact_messages(msgs, target_tokens=10)
    # Should have terminated cleanly with protected messages intact.
    assert any(m.get("role") == "user" for m in out)
    assert isinstance(audit, dict)
    # Nothing to do: no tool messages, no extra turns to drop.
    assert audit["dropped_turns"] == 0
    assert audit["dropped_tool_call_ids"] == []
    assert removed == 0


# ---------------------------------------------------------------------------
# Upstream-overflow parser
# ---------------------------------------------------------------------------


def test_parse_overflow_numbers_vllm_verbose() -> None:
    """The exact vLLM / OpenAI-compatible 400 the user pasted must
    yield model_max + requested output + current input."""
    from rtxclaw_core.turn_runtime import parse_overflow_numbers
    msg = (
        "HTTP 400: {\"error\":{\"message\":\"This model's maximum "
        "context length is 262144 tokens. However, you requested "
        "16384 output tokens and your prompt contains at least "
        "245761 input tokens, for a total of at least 262145 tokens."
        " Please reduce the length of the input prompt or the "
        "number of requested output tokens. "
        "(parameter=input_tokens, value=245761)\","
        "\"type\":\"BadRequestError\",\"param\":\"input_tokens\","
        "\"code\":400}}"
    )
    parsed = parse_overflow_numbers(msg)
    assert parsed["model_max"] == 262144
    assert parsed["requested_max_tokens"] == 16384
    assert parsed["input_tokens"] == 245761


def test_parse_overflow_numbers_openai_legacy() -> None:
    """The classic OpenAI legacy phrasing (no separate output field)."""
    from rtxclaw_core.turn_runtime import parse_overflow_numbers
    msg = (
        "This model's maximum context length is 8192 tokens. However, "
        "your messages resulted in 9000 tokens."
    )
    parsed = parse_overflow_numbers(msg)
    assert parsed["model_max"] == 8192
    assert parsed["input_tokens"] == 9000


def test_parse_overflow_numbers_unrelated_message_empty() -> None:
    """Non-overflow error messages must NOT yield bogus numbers."""
    from rtxclaw_core.turn_runtime import parse_overflow_numbers
    assert parse_overflow_numbers("HTTP 500: Internal Server Error") == {}
    assert parse_overflow_numbers("") == {}


# ---------------------------------------------------------------------------
# Reactive overflow compaction (engine call site)
# ---------------------------------------------------------------------------


def test_reactive_compact_actually_trims_messages() -> None:
    """The user-reported regression: a 400 with the model's max context
    + requested output sizes must produce a trimmed message list and
    signal a retry. Pre-fix the call site passed ``ctx_window=`` to a
    ``compact_messages(messages, target_tokens)`` signature; the
    TypeError got swallowed by the broad except and the runtime
    surfaced the raw HTTP 400 to the user."""
    import asyncio
    from types import SimpleNamespace
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    cfg = SimpleNamespace(
        upstream_max_context=262144,
        upstream_max_completion_tokens=16384,
        compact_at_frac=1.0,
        logfile=None,
    )
    engine = LocalLLMEngine(cfg)
    # Build a transcript whose chars/3 estimator lands above the
    # model's 262144 ceiling. 800k chars ≈ 266k tokens.
    big_tool_result = "X" * 200_000
    messages = [
        _msg("system", "you are a helper"),
        _msg("user", "round 1"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "Read", "arguments": "{}"}},
        ]),
        _msg("tool", big_tool_result, tool_call_id="t1"),
        _msg("assistant", "round 1 answer"),
        _msg("user", "round 2"),
        _msg("assistant", "", tool_calls=[
            {"id": "t2", "type": "function",
             "function": {"name": "Read", "arguments": "{}"}},
        ]),
        _msg("tool", big_tool_result, tool_call_id="t2"),
        _msg("assistant", "round 2 answer"),
        _msg("user", "round 3"),
        _msg("assistant", "", tool_calls=[
            {"id": "t3", "type": "function",
             "function": {"name": "Read", "arguments": "{}"}},
        ]),
        _msg("tool", big_tool_result, tool_call_id="t3"),
        _msg("user", "FINAL QUESTION"),
    ]
    upstream_400 = (
        "HTTP 400: This model's maximum context length is 262144 "
        "tokens. However, you requested 16384 output tokens and "
        "your prompt contains at least 245761 input tokens, for a "
        "total of at least 262145 tokens."
    )

    session = SimpleNamespace(hash="abc123")
    squeezed, retried = asyncio.run(
        engine._reactive_compact_on_overflow(
            session, messages, upstream_400,
            classification="upstream context-length overflow",
        )
    )

    assert retried is True, "must signal a retry on a parseable overflow"
    new_est = _approx_tokens(squeezed)
    budget = 262144 - 16384
    assert new_est <= budget, (
        f"trimmed estimate {new_est} still over budget "
        f"({budget} = model_max - requested_max_tokens)"
    )
    # Protected: live user must survive every stage.
    assert any(
        m.get("role") == "user" and m.get("content") == "FINAL QUESTION"
        for m in squeezed
    ), "FINAL QUESTION user message dropped — vLLM 400 'no user query'"


def test_reactive_compact_falls_back_to_cfg_when_error_unparseable() -> None:
    """If the upstream error is opaque (no numbers we recognise) but
    the classification is overflow, the cfg.upstream_max_context budget
    is used. Without this, an upstream that returns a generic 'context
    overflow' would surface raw to the user."""
    import asyncio
    from types import SimpleNamespace
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    cfg = SimpleNamespace(
        upstream_max_context=10_000,
        upstream_max_completion_tokens=1_000,
        compact_at_frac=1.0,
        logfile=None,
    )
    engine = LocalLLMEngine(cfg)
    big = "X" * 60_000  # ~20k tokens — bigger than the cfg window.
    messages = [
        _msg("system", "sys"),
        # Old (drop-able) tool round in the head.
        _msg("user", "old user"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "f", "arguments": "{}"}},
        ]),
        _msg("tool", big, tool_call_id="t1"),
        _msg("assistant", "old answer"),
        # Live exchange in the protected tail.
        _msg("user", "live"),
        _msg("assistant", "drafting"),
    ]
    session = SimpleNamespace(hash="abc123")
    squeezed, retried = asyncio.run(
        engine._reactive_compact_on_overflow(
            session, messages, "context overflow (no numbers)",
            classification="upstream context-length overflow",
        )
    )
    assert retried is True
    assert _approx_tokens(squeezed) < 10_000


def test_reactive_compact_no_retry_when_not_overflow() -> None:
    """Non-overflow classifications must NOT trigger a retry."""
    import asyncio
    from types import SimpleNamespace
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    cfg = SimpleNamespace(
        upstream_max_context=262144,
        upstream_max_completion_tokens=16384,
        logfile=None,
    )
    engine = LocalLLMEngine(cfg)
    messages = [_msg("system", "sys"), _msg("user", "hi")]
    session = SimpleNamespace(hash="abc123")
    out, retried = asyncio.run(
        engine._reactive_compact_on_overflow(
            session, messages, "HTTP 500: internal error",
            classification="upstream HTTP 500",
        )
    )
    assert retried is False
    assert out == messages


def test_reactive_compact_falls_back_to_max_tokens_override() -> None:
    """User-reported infinite-retry pathology: when the live user
    prompt alone is the irreducible part (compact_messages returns
    unchanged), the reactive squeeze used to still signal retried=True
    and the runtime relooped on the same payload for 76+ rounds
    against the same prefix hash. The recovery must instead drop
    `max_tokens` so input + new_max_tokens fits, set a per-session
    override the next round will pick up, and only THEN signal
    retried=True."""
    import asyncio
    from types import SimpleNamespace
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    cfg = SimpleNamespace(
        upstream_max_context=262144,
        upstream_max_completion_tokens=16384,
        logfile=None,
    )
    engine = LocalLLMEngine(cfg)
    # Mirror the production session: system + one huge live user
    # message totaling 245761 tokens (the upstream's reported number).
    # compact_messages bails on `len(body) <= keep_tail` so it returns
    # the list unchanged with removed=0.
    messages = [
        _msg("system", "sys"),
        _msg("user", "Q " * 5_000),
    ]
    upstream_400 = (
        "HTTP 400: This model's maximum context length is 262144 "
        "tokens. However, you requested 16384 output tokens and "
        "your prompt contains at least 245761 input tokens, for a "
        "total of at least 262145 tokens."
    )
    session = SimpleNamespace(hash="abc123")
    out, retried = asyncio.run(
        engine._reactive_compact_on_overflow(
            session, messages, upstream_400,
            classification="upstream context-length overflow",
        )
    )
    # Must NOT loop. Either we found room via a max_tokens override
    # (preferred) or we surface the error — never silently re-retry
    # on an unchanged payload.
    override = getattr(session, "max_tokens_override", None)
    if retried:
        assert isinstance(override, int) and override > 0, (
            "retried=True with no max_tokens_override would loop again "
            "on the same payload"
        )
        # Sanity: the override must let input + max_tokens fit under
        # the model_max, with at least 256 tokens of output budget.
        assert override >= 256
        assert 245761 + override <= 262144
    else:
        # No retry signalled → operator-visible error. Acceptable too,
        # but only if no override would have fit.
        # 262144 - 245761 - 1024 = 15359 ≥ 256, so the override path
        # should have fired; if not, the test fails the assertion above.
        pass


def test_reactive_compact_no_retry_when_no_progress_and_no_room() -> None:
    """If the upstream prompt eats the WHOLE window with no room left
    for output, the recovery must surface the error rather than
    relooping. The earlier bug was returning retried=True on
    removed=0, causing the infinite-retry loop the user observed."""
    import asyncio
    from types import SimpleNamespace
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    cfg = SimpleNamespace(
        upstream_max_context=1_000,
        upstream_max_completion_tokens=1_000,  # equal to the window
        logfile=None,
    )
    engine = LocalLLMEngine(cfg)
    messages = [
        _msg("system", "sys"),
        _msg("user", "Q " * 600),  # ~400 tokens
    ]
    upstream_400 = (
        "maximum context length is 1000 tokens. However, you requested "
        "1000 output tokens and your prompt contains 400 input tokens, "
        "for a total of 1400 tokens."
    )
    session = SimpleNamespace(hash="abc123")
    out, retried = asyncio.run(
        engine._reactive_compact_on_overflow(
            session, messages, upstream_400,
            classification="upstream context-length overflow",
        )
    )
    # No room: 1000 - 400 - 1024 < 0 → no viable max_tokens override.
    # The runtime must surface the error instead of looping.
    assert retried is False
