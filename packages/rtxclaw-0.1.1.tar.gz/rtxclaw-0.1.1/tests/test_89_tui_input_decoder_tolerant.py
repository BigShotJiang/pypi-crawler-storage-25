"""Step 89 — Textual input thread tolerates non-UTF-8 stdin bytes.

Regression for the ``UnicodeDecodeError: 'utf-8' codec can't decode
byte 0x86 ... invalid start byte`` crash. Textual's Linux input thread
(``textual/drivers/linux_driver.py::run_input_thread``) decoded raw
stdin with a *strict* incremental UTF-8 decoder, so a single non-UTF-8
byte — a legacy X10 mouse report (coord bytes are ``value + 32`` and
exceed ``0x7F``), an Alt/Meta high-bit key, or a non-UTF-8 paste over
SSH — killed the input thread and panicked the app. With the input
thread dead, keystrokes stopped being read: the same bug also showed up
as the TUI "freezing" / lagging.

``rtxclaw_tui.input_hardening.install_tolerant_input_decoder()`` swaps
Textual's decoder factory for one that decodes with ``errors="replace"``.
These tests prove:

1. the *unpatched* strict decoder really raises on byte ``0x86``
   (documents the root cause exactly as reported);
2. after install, Textual's module-level factory yields a decoder that
   turns the stray byte into U+FFFD instead of raising;
3. incremental decoding of a legitimately split multibyte sequence
   still reconstructs correctly (no regression for real UTF-8 input);
4. the installer is idempotent.

Pure unit test — no sandbox/daemon/endpoint, no TTY. It only imports
``codecs`` and ``textual.drivers.linux_driver`` (importable headless).
"""
from __future__ import annotations

import codecs

import pytest


def test_strict_utf8_incremental_decoder_raises_on_high_byte():
    """Baseline: exactly what Textual did, and why it crashed.

    Uses ``codecs.getincrementaldecoder`` directly (never patched), so
    this assertion is independent of install order in this file.
    """
    decode = codecs.getincrementaldecoder("utf-8")().decode  # strict
    with pytest.raises(UnicodeDecodeError):
        decode(b"ab\x86cd", final=False)


def test_install_makes_textual_decoder_tolerant():
    from rtxclaw_tui.input_hardening import install_tolerant_input_decoder

    assert install_tolerant_input_decoder() is True

    # Reconstruct the decoder exactly how run_input_thread does it:
    #   utf8_decoder = getincrementaldecoder("utf-8")().decode
    from textual.drivers import linux_driver as ld

    decode = ld.getincrementaldecoder("utf-8")().decode
    out = decode(b"ab\x86cd", final=False)
    assert out == "ab�cd"  # stray 0x86 -> U+FFFD, no exception


def test_tolerant_decoder_preserves_split_multibyte():
    from rtxclaw_tui.input_hardening import install_tolerant_input_decoder

    install_tolerant_input_decoder()
    from textual.drivers import linux_driver as ld

    decode = ld.getincrementaldecoder("utf-8")().decode
    # "✅" is U+2705 -> bytes E2 9C 85. Split across two os.read() chunks:
    # the incremental decoder must BUFFER the valid-but-incomplete head
    # (not replace it), then complete it on the next chunk.
    first = decode(b"x\xe2\x9c", final=False)
    assert first == "x"  # partial head buffered; no premature U+FFFD
    second = decode(b"\x85y", final=False)
    assert second == "✅y"


def test_install_is_idempotent():
    from rtxclaw_tui.input_hardening import install_tolerant_input_decoder

    assert install_tolerant_input_decoder() is True
    assert install_tolerant_input_decoder() is True  # second call: no-op

    from textual.drivers import linux_driver as ld

    decode = ld.getincrementaldecoder("utf-8")().decode
    assert decode(b"\x86", final=False) == "�"
