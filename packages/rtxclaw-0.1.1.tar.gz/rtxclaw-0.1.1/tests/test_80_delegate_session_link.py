"""rtxclaw ↔ delegate session-id linkage.

When the main agent delegates (/claude /codex /antigravity), the parent
rtxclaw session must be linked to the delegate's session in BOTH
directions and to the CLI's own resume token:

  parent rtxclaw sid  ──▶  child rtxclaw sid (agents/<engine>/sessions/)
                      ──▶  engine_session_id (CLI --resume token)
  child rtxclaw sid   ──▶  parent rtxclaw sid (workspace_origin back-link)

Coverage:
  * the child session back-links the FULL parent sid (not a 12-char prefix);
  * the direct-dispatch path surfaces the child rtxclaw sid + engine sid
    onto the parent turn record (metrics) so the link is queryable from the
    parent session log, not just the loose delegate sidecar;
  * a turn record carrying the link round-trips through the JSONL log and
    sessions.db.
"""

from __future__ import annotations

import inspect


def test_child_session_back_links_full_parent_sid() -> None:
    from rtxclaw_core.agents import delegate_shims as ds

    src = inspect.getsource(ds._drive_child_agent_turn)
    # FULL parent sid in the child's workspace_origin — NOT a truncated
    # ``parent_sid[:12]`` prefix (which loses the exact back-link).
    assert "delegate:{parent_sid}" in src
    assert "parent_sid[:12]" not in src
    # The parent→child→engine sidecar carries the whole mapping.
    assert "rtxclaw_child_session_id" in src
    assert "engine_session_id" in src


def test_direct_dispatch_surfaces_child_session_link_on_parent_turn() -> None:
    from rtxclaw_core.agents import local_llm

    src = inspect.getsource(local_llm.LocalLLMEngine._run_direct_tool_call)
    # Reads the child rtxclaw session id back-channel the shim sets...
    assert "_rtxclaw_child_session_id_out" in src
    assert "_rtxclaw_engine_session_id_out" in src
    # ...and records it on the parent turn so the link is queryable.
    assert "delegate_child_session_id" in src
    assert "delegate_engine_session_id" in src


def test_run_turn_folds_delegate_link_into_turn_record() -> None:
    from rtxclaw_core.agents import local_llm

    src = inspect.getsource(local_llm.LocalLLMEngine.run_turn)
    # The direct-dispatch branch folds the TurnDone metrics (carrying the
    # delegate link) into the engine audit, which record_turn persists.
    assert "_engine_audit" in src
    assert "metrics" in src


def test_delegate_link_round_trips_through_jsonl_and_sessions_db(tmp_path) -> None:
    """A parent turn carrying the delegate link in its metrics is readable
    from both the JSONL log and (after indexing) the turn_events table."""
    from rtxclaw_core import session_reader as sr
    from rtxclaw_core.session_writer import SessionWriter

    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    sid = "rtx-parent-link"
    link = {
        "direct_dispatch": "delegate_claude",
        "delegate_engine": "claude",
        "delegate_child_session_id": "06a0da632ce974288000657c128122f1",
        "delegate_engine_session_id": "claude-sess-XYZ",
    }

    w = SessionWriter(sdir, sid, engine="local_llm", flush_ms=0)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="__RTXCLAW_DELEGATE__:delegate_claude:{}", permission_mode="auto", cwd="/w")
    w.turn_ended(turn_idx=0, user="__RTXCLAW_DELEGATE__:delegate_claude:{}", final_content="hi from claude", metrics=link)
    w.close()

    found = None
    for raw in (sdir / f"{sid}.jsonl").read_bytes().split(b"\n"):
        if not raw:
            continue
        ev = sr.decode_line(raw)
        if ev and ev.get("type") == "turn_ended":
            found = (ev.get("metrics") or {})
    assert found is not None, "turn_ended record not found in JSONL"
    assert found.get("delegate_child_session_id") == link["delegate_child_session_id"]
    assert found.get("delegate_engine_session_id") == "claude-sess-XYZ"
