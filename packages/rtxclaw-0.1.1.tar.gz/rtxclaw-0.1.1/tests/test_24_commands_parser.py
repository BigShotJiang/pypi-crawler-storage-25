"""Step 24 — Slash-command parser + normalizer coverage.

``rtxclaw_core.commands`` owns the slash-command parsing and the
normalizers used by both the bot and the TUI to turn user-facing
strings (``/mode plan``, ``/reasoning streaming``) into wire-level
values. Drift here means commands silently fail or land on the wrong
endpoint, so each alias and edge case earns its own assertion.

Coverage:
- ``parse_command`` accepts every alias / shortcut.
- Telegram's ``/cmd@BotName`` group-mention syntax is stripped.
- ``/on``, ``/off``, ``/stream`` shortcuts inject their level as
  ``arg``.
- Empty / non-slash inputs return None.
- ``normalize_*`` functions accept every documented synonym and
  reject everything else with None.
"""
from __future__ import annotations

import pytest

from rtxclaw_core.commands import (
    MODE_VALID,
    normalize_mode,
    normalize_reasoning_level,
    normalize_thinking,
    normalize_tool_output,
    parse_command,
)


# ---- parse_command --------------------------------------------------


def test_parse_returns_none_for_non_slash_input() -> None:
    assert parse_command("hello world") is None
    assert parse_command("") is None
    assert parse_command("    ") is None


def test_parse_basic_command() -> None:
    p = parse_command("/help")
    assert p is not None
    assert p.name == "help"
    assert p.arg == ""


def test_parse_command_with_arg() -> None:
    p = parse_command("/model server1")
    assert p is not None
    assert p.name == "model"
    assert p.arg == "server1"


def test_parse_strips_botname_suffix() -> None:
    """Telegram groups deliver commands as ``/cmd@BotName arg``."""
    p = parse_command("/help@rtxclawai_bot")
    assert p is not None
    assert p.name == "help"


def test_parse_lowercases_command() -> None:
    p = parse_command("/HELP")
    assert p is not None
    assert p.name == "help"


@pytest.mark.parametrize(
    "raw,expected_name",
    [
        ("/models", "models"),
        ("/model", "model"),
        ("/reason", "reasoning"),
        ("/reasoning", "reasoning"),
        ("/on", "reasoning"),
        ("/off", "reasoning"),
        ("/stream", "reasoning"),
        ("/mode", "mode"),
        ("/status", "status"),
        ("/help", "help"),
        ("/new", "new"),
        ("/sessions", "sessions"),
        ("/history", "history"),
        ("/refresh", "refresh"),
        ("/abort", "abort"),
        ("/stop", "abort"),
        ("/compact", "compact"),
        ("/todo", "todo"),
        ("/todos", "todo"),
        ("/restart", "restart"),
        ("/tool", "tool"),
        ("/tools", "tool"),
    ],
)
def test_parse_aliases(raw: str, expected_name: str) -> None:
    p = parse_command(raw)
    assert p is not None
    assert p.name == expected_name, (
        f"alias {raw!r} mapped to {p.name!r}, expected {expected_name!r}"
    )


def test_on_off_stream_inject_arg() -> None:
    """``/on`` / ``/off`` / ``/stream`` are shortcuts for
    ``/reasoning <level>``; the parser must inject the level into
    ``arg`` when the user didn't pass one explicitly."""
    for shortcut, level in (("/on", "on"), ("/off", "off"),
                            ("/stream", "stream")):
        p = parse_command(shortcut)
        assert p is not None
        assert p.arg == level, (
            f"{shortcut} didn't inject level — got arg={p.arg!r}"
        )


def test_unknown_command_keeps_raw_name() -> None:
    """Unrecognized commands fall through with the slash stripped —
    let the caller (bot/TUI) decide whether to route or reject."""
    p = parse_command("/coffee make-it-strong")
    assert p is not None
    assert p.name == "coffee"
    assert p.arg == "make-it-strong"


# ---- normalize_reasoning_level --------------------------------------


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("on", "on"), ("On", "on"), ("ON", "on"),
        ("true", "on"), ("yes", "on"), ("1", "on"),
        ("show", "on"), ("enable", "on"),
        ("off", "off"), ("false", "off"), ("no", "off"),
        ("0", "off"), ("hide", "off"), ("disable", "off"),
        ("stream", "stream"), ("streaming", "stream"),
        ("live", "stream"), ("draft", "stream"),
        ("invalid", None), ("", None), ("maybe", None),
    ],
)
def test_normalize_reasoning_level(raw: str, expected) -> None:
    assert normalize_reasoning_level(raw) == expected


# ---- normalize_mode -------------------------------------------------


def test_normalize_mode_accepts_each_valid_mode() -> None:
    for mode in MODE_VALID:
        assert normalize_mode(mode) == mode
        assert normalize_mode(mode.upper()) == mode


def test_normalize_mode_rejects_unknown() -> None:
    assert normalize_mode("rampage") is None
    assert normalize_mode("") is None


# ---- normalize_thinking ---------------------------------------------


@pytest.mark.parametrize("raw,expected", [
    ("on", True), ("true", True), ("yes", True), ("enable", True),
    ("off", False), ("false", False), ("no", False), ("disable", False),
    ("stream", None), ("", None), ("kinda", None),
])
def test_normalize_thinking(raw: str, expected) -> None:
    assert normalize_thinking(raw) is expected


# ---- normalize_tool_output ------------------------------------------


@pytest.mark.parametrize("raw,expected", [
    # off-bucket synonyms
    ("off", "off"), ("false", "off"), ("no", "off"),
    ("0", "off"), ("hidden", "off"), ("disable", "off"),
    # on-bucket synonyms (header only)
    ("on", "on"), ("true", "on"), ("yes", "on"),
    ("1", "on"), ("show", "on"), ("visible", "on"),
    ("enable", "on"), ("header", "on"), ("headers", "on"),
    # stream-bucket synonyms (header + body)
    ("stream", "stream"), ("streaming", "stream"),
    ("live", "stream"), ("verbose", "stream"), ("all", "stream"),
    # rejected
    ("loud", None), ("", None), ("kinda", None),
])
def test_normalize_tool_output(raw: str, expected) -> None:
    assert normalize_tool_output(raw) == expected
