"""Step 28 — Plan-step extraction + checklist behaviour.

The TUI's bottom-of-screen plan checklist (``#plan-checklist``) is
populated from ``plan_pass`` tool-call body content. The parser
``rtxclaw_core.plan_steps.extract_plan_steps`` accepts numbered,
bulleted, JSON, and plain-text plan formats and returns a flat list
of step strings.

The cursor on the resulting checklist advances **only** on explicit
``todo complete [indexes]`` actions — not heuristically on every
non-todo tool call. The old heuristic double-counted: a turn that
fired 17 tool calls against a 4-step plan blew past the end while
the model was still working on step 1, so the operator saw "all
done" while the agent was mid-chain.

These tests pin the parser shape so a future plan-classifier prompt
tweak doesn't silently empty the checklist.
"""
from __future__ import annotations

import pytest


@pytest.fixture
def extract():
    """Use the standalone parser exposed in ``rtxclaw_core.plan_steps``
    so the test doesn't drag in Textual / rich at import time."""
    from rtxclaw_core.plan_steps import extract_plan_steps
    return extract_plan_steps


def test_numbered_list(extract) -> None:
    body = "1. Read README\n2. Inspect src\n3. Run tests"
    assert extract(body) == ["Read README", "Inspect src", "Run tests"]


def test_paren_numbered_list(extract) -> None:
    body = "1) first\n2) second\n3) third"
    assert extract(body) == ["first", "second", "third"]


def test_bulleted_list(extract) -> None:
    body = "- step a\n* step b\n• step c"
    assert extract(body) == ["step a", "step b", "step c"]


def test_json_subtasks(extract) -> None:
    body = '{"subtasks": ["x", "y", "z"]}'
    assert extract(body) == ["x", "y", "z"]


def test_json_steps(extract) -> None:
    body = '{"steps": ["alpha", "beta"]}'
    assert extract(body) == ["alpha", "beta"]


def test_empty_returns_empty(extract) -> None:
    assert extract("") == []
    assert extract("   ") == []


def test_mixed_with_prose(extract) -> None:
    """Bullets win over prose — extra preamble lines are dropped."""
    body = (
        "Plan summary:\n\n"
        "1. first thing\n"
        "2. second thing\n\n"
        "(end of plan)"
    )
    assert extract(body) == ["first thing", "second thing"]


def test_plain_text_fallback(extract) -> None:
    """No bullets, no JSON — each non-blank line becomes a step."""
    body = "do this\nthen do that\nfinally cleanup"
    assert extract(body) == ["do this", "then do that", "finally cleanup"]


def test_caps_at_widget_budget(extract) -> None:
    """Plain-text fallback caps at 12 lines so a runaway plan
    doesn't overflow the bottom-of-TUI checklist widget."""
    body = "\n".join(f"step {i}" for i in range(20))
    out = extract(body)
    assert len(out) == 12


def test_strips_whitespace(extract) -> None:
    body = "1.    extra spaces around   \n2. tabs\there"
    out = extract(body)
    assert out[0] == "extra spaces around"
    assert out[1].startswith("tabs")


def test_json_non_dict_falls_through(extract) -> None:
    """A bare JSON list at the root isn't valid plan shape; the
    parser falls through to the bullet/text path."""
    body = '["a", "b"]'
    # Not bullets / not numbered → plain-text fallback treats as 1 line.
    assert extract(body) == ['["a", "b"]']


# ---- TUI plan-checklist behaviour -----------------------------------


def _make_app_for_plans():
    """Construct an ``AgentChatApp`` with the bare attributes the
    plan-checklist methods touch, bypassing ``__init__`` (which
    builds Textual widgets / loads disk state).

    Mirrors the pattern used in test_41 — we only need ``_plans``
    and a stub ``query_one`` / no-op render so we can exercise
    ``set_plan_checklist`` / ``advance_plan_step`` /
    ``_handle_todo_tool_call`` without standing up a real Textual
    runtime.
    """
    from unittest.mock import MagicMock
    from rtxclaw_tui.app import AgentChatApp

    app = AgentChatApp.__new__(AgentChatApp)
    app._plans = []
    # The render method walks ``query_one("#plan-checklist", Static)``;
    # short-circuit it via a no-op so the test doesn't need the widget.
    app.query_one = MagicMock(side_effect=Exception("no widget"))
    return app


# ---------------------------------------------------------------------------
# Schema note
# ---------------------------------------------------------------------------
# The TUI plan-checklist uses the single-plan model introduced in
# commit ``5bc3be4`` (2026-05-10). ``_plans`` is a 0-or-1-element list
# whose sole entry has shape ``{"items": [{"content", "activeForm",
# "status"}]}``. The legacy multi-plan stack with ``{"steps":[str],
# "cursor":int}`` was removed by design — Claude Code's TodoWrite gives
# each session exactly one plan that gets replaced/merged in place. The
# tests below pin the current model; the multi-plan-stack tests that
# used to live here were deleted because the behaviours they described
# no longer exist (and shouldn't).


def _statuses(plan: dict) -> list[str]:
    return [it.get("status") or "pending" for it in (plan.get("items") or [])]


def _contents(plan: dict) -> list[str]:
    return [it.get("content") or "" for it in (plan.get("items") or [])]


def test_set_plan_checklist_drops_done_plan_on_new_replace() -> None:
    """When a new ``replace`` lands while the prior plan is fully
    complete, the prior plan is dropped — the new one's items are the
    ONLY thing left on the footer. Without this guard the renderer
    would carry struck-through rows forward into every subsequent
    plan."""
    app = _make_app_for_plans()
    app.set_plan_checklist(["a", "b", "c"])
    for _ in range(3):
        app.advance_plan_step()
    assert len(app._plans) == 1
    assert _statuses(app._plans[0]) == ["completed"] * 3

    app.set_plan_checklist(["x", "y"])
    assert len(app._plans) == 1
    assert _contents(app._plans[0]) == ["x", "y"]
    assert _statuses(app._plans[0]) == ["pending", "pending"]


def test_handle_todo_replace_drops_done_plan() -> None:
    """Same drop-and-replace, but exercised end-to-end through
    ``_handle_todo_tool_call`` — the path the model actually hits
    when it emits ``todo(action="replace")``."""
    app = _make_app_for_plans()
    app.set_plan_checklist(["a", "b"])
    app.advance_plan_step()
    app.advance_plan_step()
    assert _statuses(app._plans[0]) == ["completed", "completed"]

    app._handle_todo_tool_call({
        "action": "replace",
        "items": [{"content": "new1"}, {"content": "new2"}],
    })
    assert len(app._plans) == 1
    assert _contents(app._plans[0]) == ["new1", "new2"]
    assert _statuses(app._plans[0]) == ["pending", "pending"]


def test_handle_todo_replace_same_steps_merges_into_existing() -> None:
    """Regression guard for session 69ff1bf6a5e3410fa7000001, turn 3:
    a 5-step plan got 4 explicit ``complete`` calls, then the model
    re-emitted ``replace`` with the same 5 items all marked done.
    Without the in-place merge the operator saw a duplicate plan
    appear with all 5 rows ticked instead of the original plan's 5th
    row ticking. The current single-plan model merges by content set
    so the existing plan's status array is forward-advanced in place.
    """
    app = _make_app_for_plans()
    steps = ["s1", "s2", "s3", "s4", "s5"]
    app.set_plan_checklist(steps)
    for _ in range(4):
        app.advance_plan_step()
    assert len(app._plans) == 1
    assert _statuses(app._plans[0]) == [
        "completed", "completed", "completed", "completed", "pending",
    ]

    app._handle_todo_tool_call({
        "action": "replace",
        "items": [{"content": s, "status": "done"} for s in steps],
    })

    assert len(app._plans) == 1, (
        f"replace with same content list must merge, not duplicate; "
        f"got {app._plans!r}"
    )
    assert _contents(app._plans[0]) == steps
    # Every row now reads as done (merge forwarded statuses).
    assert all(s in ("completed", "done") for s in _statuses(app._plans[0]))


def test_handle_todo_replace_same_steps_partial_done_never_regresses() -> None:
    """The merge path is forward-only: when a re-emit marks some rows
    as ``pending`` that were previously ``in_progress`` / ``completed``,
    the rendered status MUST stay at the more-advanced state. A stale
    nudge from the model can't visually rewind a row."""
    app = _make_app_for_plans()
    steps = ["s1", "s2", "s3"]
    app.set_plan_checklist(steps)
    app.advance_plan_step()  # s1 now completed
    assert _statuses(app._plans[0]) == ["completed", "pending", "pending"]

    # Partial done re-emit advances s2 from pending → completed.
    app._handle_todo_tool_call({
        "action": "replace",
        "items": [
            {"content": "s1", "status": "done"},
            {"content": "s2", "status": "done"},
            {"content": "s3", "status": "pending"},
        ],
    })
    assert len(app._plans) == 1
    statuses = _statuses(app._plans[0])
    assert statuses[0] in ("completed", "done")
    assert statuses[1] in ("completed", "done")
    assert statuses[2] == "pending"

    # All-pending re-emit must NOT visually regress already-done rows.
    app._handle_todo_tool_call({
        "action": "replace",
        "items": [{"content": s, "status": "pending"} for s in steps],
    })
    assert len(app._plans) == 1
    statuses = _statuses(app._plans[0])
    assert statuses[0] in ("completed", "done"), (
        f"s1 regressed from completed → {statuses[0]!r}"
    )
    assert statuses[1] in ("completed", "done"), (
        f"s2 regressed from completed → {statuses[1]!r}"
    )
