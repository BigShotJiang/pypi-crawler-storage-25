"""Step 36 — `[CURRENT TODO LIST]` injection.

Background: ``_build_messages`` in ``rtxclaw_agent.acp_bridge`` replays
prior turns using only ``t.get("content")`` (the assistant's final
text). Tool calls and tool results — including the ``todo`` tool's
echoed checklist — are dropped. For aborted turns or turns with no
final text, the next turn starts blind to the persisted plan and
re-fires ``todo(replace=…)``, overwriting the prior plan with a
near-duplicate.

The fix surfaces the live ``.todos.json`` as a per-round
``[CURRENT TODO LIST — …]`` user-side reminder, mirroring how pinned
facts and the rolling compaction summary are injected.

These tests pin the pure helper so a future refactor can't silently
break the visibility contract.
"""
from __future__ import annotations

from rtxclaw_core.turn_runtime import (
    _inject_compaction_summary,
    _inject_current_todos,
    _inject_pinned_facts,
)


def _system_user(user_text: str = "hi") -> list[dict]:
    return [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": user_text},
    ]


def test_inject_renders_pending_and_done_marks() -> None:
    todos = [
        {"content": "first", "status": "pending"},
        {"content": "second", "status": "done"},
    ]
    out = _inject_current_todos(_system_user(), todos)
    body = out[1]["content"]
    assert body.startswith("[CURRENT TODO LIST")
    assert "- [ ] 0: first" in body
    assert "- [x] 1: second" in body


def test_inject_lands_after_system_before_live_user() -> None:
    todos = [{"content": "do x", "status": "pending"}]
    out = _inject_current_todos(_system_user("real user msg"), todos)
    assert [m["role"] for m in out] == ["system", "user", "user"]
    assert out[0]["content"] == "sys"
    assert out[1]["content"].startswith("[CURRENT TODO LIST")
    assert out[2]["content"] == "real user msg"


def test_empty_todos_strips_prior_marker() -> None:
    todos = [{"content": "do x", "status": "pending"}]
    msgs = _inject_current_todos(_system_user(), todos)
    assert any(
        isinstance(m.get("content"), str)
        and m["content"].startswith("[CURRENT TODO LIST")
        for m in msgs
    )
    cleared = _inject_current_todos(msgs, [])
    assert all(
        not (
            isinstance(m.get("content"), str)
            and m["content"].startswith("[CURRENT TODO LIST")
        )
        for m in cleared
    )


def test_idempotent_under_repeated_calls() -> None:
    todos = [{"content": "do x", "status": "pending"}]
    once = _inject_current_todos(_system_user(), todos)
    twice = _inject_current_todos(once, todos)
    assert len(once) == len(twice)
    todo_msgs = [
        m for m in twice
        if isinstance(m.get("content"), str)
        and m["content"].startswith("[CURRENT TODO LIST")
    ]
    assert len(todo_msgs) == 1


def test_canonical_order_with_pinned_and_summary() -> None:
    """Order must be: system → pinned → rolling summary → todos → tail.

    Each helper inserts at "first slot after the system+earlier-marker
    block" — so the test exercises that the todo helper sits
    *after* both pinned facts and the rolling summary, not between
    them or before them.
    """
    msgs = _system_user("live tail")
    msgs = _inject_pinned_facts(msgs, ["fact-a"])
    msgs = _inject_compaction_summary(msgs, "older-context-rollup")
    msgs = _inject_current_todos(
        msgs, [{"content": "carry-over plan item", "status": "pending"}]
    )
    roles = [m["role"] for m in msgs]
    assert roles == ["system", "user", "user", "user", "user"]
    assert msgs[1]["content"].startswith("[PINNED FACTS")
    assert msgs[2]["content"].startswith("[ROLLING COMPACTION SUMMARY")
    assert msgs[3]["content"].startswith("[CURRENT TODO LIST")
    assert msgs[4]["content"] == "live tail"


def test_skips_items_with_blank_content() -> None:
    """A corrupt-ish entry with empty content should drop silently
    rather than render a bare bullet ``- [ ] 0:`` that wastes a token
    and confuses the model."""
    todos = [
        {"content": "real", "status": "pending"},
        {"content": "   ", "status": "pending"},
        {"content": "", "status": "done"},
    ]
    out = _inject_current_todos(_system_user(), todos)
    body = out[1]["content"]
    assert "- [ ] 0: real" in body
    # Empty entries should not appear as bullets.
    assert body.count("- [") == 1
