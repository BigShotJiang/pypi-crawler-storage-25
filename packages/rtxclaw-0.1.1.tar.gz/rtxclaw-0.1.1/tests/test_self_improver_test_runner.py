"""Tests the regression-test runner. Exercises the script directly
(not inside Docker — Docker exercises the same logic in the same
script). The Docker wrapping is verified by the e2e test in Task 12.

The host-side wrapper (``scripts/run-self-improver-tests.sh``) routes
to ``docker run`` by default; the inner-script stash logic lives in
``scripts/run-self-improver-tests-inner.sh``. These unit tests pass
``--no-docker`` so they exercise the inner logic without recursive
Docker. See ``test_runner_invokes_docker_wrapper_by_default`` for the
regression that pins the default-mode Docker invocation."""
import os
import stat
import subprocess
import textwrap
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
RUNNER_HOST_SRC = REPO_ROOT / "scripts" / "run-self-improver-tests.sh"
RUNNER_INNER_SRC = REPO_ROOT / "scripts" / "run-self-improver-tests-inner.sh"


@pytest.fixture
def sandbox(tmp_path):
    """Stage a fake `worktree` with one source file + a regression test."""
    wt = tmp_path / "sandbox"
    (wt / "src" / "rtxclaw_core").mkdir(parents=True)
    (wt / "tests").mkdir(parents=True)
    (wt / "scripts").mkdir(parents=True)
    (wt / "src" / "rtxclaw_core" / "buggy.py").write_text("def add(a,b): return a+b\n")
    (wt / "tests" / "test_selfimprover_fix_deadbeef.py").write_text(textwrap.dedent("""\
        from rtxclaw_core.buggy import add
        def test_regression_fixed():
            assert add(2, 2) == 4
    """))
    subprocess.run(["git", "init", "-q", "-b", "main", str(wt)], check=True)
    subprocess.run(["git", "-C", str(wt), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(wt), "config", "user.name", "t"], check=True)
    subprocess.run(["git", "-C", str(wt), "add", "."], check=True)
    subprocess.run(["git", "-C", str(wt), "commit", "-q", "-m", "init"], check=True)

    runner_host = wt / "scripts" / "run-self-improver-tests.sh"
    runner_inner = wt / "scripts" / "run-self-improver-tests-inner.sh"
    runner_host.write_text(RUNNER_HOST_SRC.read_text())
    runner_host.chmod(0o755)
    runner_inner.write_text(RUNNER_INNER_SRC.read_text())
    runner_inner.chmod(0o755)
    return wt


def test_runner_passes_when_regression_test_passes(sandbox):
    """The regression test must fail on baseline AND pass on patched.
    Simulate 'patch present' by writing an uncommitted diff in the
    worktree, and write a regression test that's only true with the
    patched comment present."""
    (sandbox / "src" / "rtxclaw_core" / "buggy.py").write_text(
        "def add(a,b): return a+b  # fixed\n"
    )
    (sandbox / "tests" / "test_selfimprover_fix_deadbeef.py").write_text(textwrap.dedent("""\
        from pathlib import Path
        def test_regression_fixed():
            body = Path('src/rtxclaw_core/buggy.py').read_text()
            assert '# fixed' in body, 'baseline should fail; patched should pass'
    """))

    proc = subprocess.run(
        [str(sandbox / "scripts" / "run-self-improver-tests.sh"),
         "--no-docker",
         "test_selfimprover_fix_deadbeef.py"],
        cwd=str(sandbox), capture_output=True, text=True, timeout=60,
    )
    assert proc.returncode == 0, f"runner failed: {proc.stdout}\n{proc.stderr}"


def test_runner_fails_when_regression_test_is_tautology(sandbox):
    """If the regression test passes against BOTH baseline and patched,
    it's not a real test — the runner must fail."""
    (sandbox / "tests" / "test_selfimprover_fix_deadbeef.py").write_text(textwrap.dedent("""\
        def test_always_passes():
            assert 1 == 1
    """))
    (sandbox / "src" / "rtxclaw_core" / "buggy.py").write_text("def add(a,b): return a+b\n# unrelated\n")
    proc = subprocess.run(
        [str(sandbox / "scripts" / "run-self-improver-tests.sh"),
         "--no-docker",
         "test_selfimprover_fix_deadbeef.py"],
        cwd=str(sandbox), capture_output=True, text=True, timeout=60,
    )
    assert proc.returncode != 0, "runner must reject tautology test"
    assert "baseline" in (proc.stdout + proc.stderr).lower(), (
        "runner must explain why it rejected the test"
    )


def test_runner_invokes_docker_wrapper_by_default(tmp_path, monkeypatch):
    """Bug #2 regression: the host-side wrapper MUST exec ``docker run``
    by default. Without ``--no-docker`` it had been running host pytest
    directly, breaking the §8 isolation guarantee."""
    # Stage scripts (no git init needed — we never reach the inner script).
    wt = tmp_path / "wt"
    (wt / "scripts").mkdir(parents=True)
    for name in ("run-self-improver-tests.sh", "run-self-improver-tests-inner.sh"):
        dst = wt / "scripts" / name
        dst.write_text((REPO_ROOT / "scripts" / name).read_text())
        dst.chmod(0o755)

    # Stub docker — record argv on `docker run` and exit 0; pretend the
    # image already exists so the wrapper does not bail with the
    # "image missing" banner.
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    marker = tmp_path / "docker.call"
    fake = bin_dir / "docker"
    fake.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env bash
        # `docker image inspect …` → pretend the image exists.
        if [ "$1" = "image" ]; then exit 0; fi
        # Record the `docker run …` invocation.
        echo "$@" > {marker}
        exit 0
    """))
    fake.chmod(0o755)
    monkeypatch.setenv("PATH", f"{bin_dir}:{os.environ['PATH']}")

    # Run with default (Docker) mode — no ``--no-docker`` flag.
    proc = subprocess.run(
        [str(wt / "scripts" / "run-self-improver-tests.sh"),
         "test_anything.py"],
        cwd=str(wt), capture_output=True, text=True, timeout=30,
        env={**os.environ, "PATH": f"{bin_dir}:{os.environ['PATH']}",
             "SELFIMPROVER_WORKTREE": str(wt)},
    )
    assert proc.returncode == 0, f"wrapper exited non-zero: {proc.stderr}"
    assert marker.exists(), (
        f"host wrapper did not invoke `docker run` — stderr:\n{proc.stderr}"
    )
    args = marker.read_text()
    assert "run --rm" in args, f"missing `run --rm` in docker args: {args!r}"
    assert "--network=none" in args, f"missing --network=none: {args!r}"
    assert "rtxclaw-test:local" in args, f"wrong image tag: {args!r}"
    assert "/sandbox/scripts/run-self-improver-tests-inner.sh" in args, (
        f"inner script not invoked inside container: {args!r}"
    )

    # Bug 9a regression: must override the image's tests/run.sh
    # ENTRYPOINT, otherwise docker prepends it to argv and the inner
    # script is never reached (exec becomes "tests/run.sh <inner> <reg>"
    # → not found at /sandbox).
    assert "--entrypoint /sandbox/scripts/run-self-improver-tests-inner.sh" in args, (
        "docker run must override the image's tests/run.sh ENTRYPOINT — "
        "without --entrypoint, the inner script is never executed. "
        f"Got: {args!r}"
    )

    # Bug 9b regression: the worktree mount must be writable —
    # git stash push/pop in the inner script mutates .git/. The :ro
    # draft prevented the baseline/patched gate from running at all.
    assert f"-v {wt}:/sandbox:rw" in args, (
        "worktree mount must be `:rw` (git stash mutates .git/); the :ro "
        f"draft prevented the baseline/patched gate from running. Got: {args!r}"
    )

    # The trailing argv to docker (after the image name) must be the
    # regression-test filename — NOT the inner-script path (which now
    # belongs in --entrypoint instead).
    assert args.rstrip().endswith("test_anything.py"), (
        f"docker run's tail argv must be the regression test filename; "
        f"got: {args!r}"
    )


def test_runner_protects_fp_named_helper_modules_from_stash(sandbox):
    """Bug #8 regression: if Claude's regression test imports a helper
    module whose name embeds the fingerprint, the helper must survive
    the stash — otherwise the baseline run gets an ImportError, not a
    real test failure, and the runner has no way to tell them apart."""
    # The regression test (with fingerprint deadbeef) imports a helper
    # whose name also embeds deadbeef.
    (sandbox / "src" / "rtxclaw_core" / "buggy.py").write_text(
        "def add(a,b): return a+b  # fixed\n"
    )
    (sandbox / "tests" / "_selfimprover_fix_deadbeef_helpers.py").write_text(
        "EXPECTED_TOKEN = '# fixed'\n"
    )
    (sandbox / "tests" / "test_selfimprover_fix_deadbeef.py").write_text(textwrap.dedent("""\
        from pathlib import Path
        from _selfimprover_fix_deadbeef_helpers import EXPECTED_TOKEN
        def test_regression_fixed():
            body = Path('src/rtxclaw_core/buggy.py').read_text()
            assert EXPECTED_TOKEN in body, 'baseline should fail; patched should pass'
    """))

    proc = subprocess.run(
        [str(sandbox / "scripts" / "run-self-improver-tests.sh"),
         "--no-docker",
         "test_selfimprover_fix_deadbeef.py"],
        cwd=str(sandbox), capture_output=True, text=True, timeout=60,
    )
    assert proc.returncode == 0, (
        "runner failed despite the fp-named helper being protected from "
        f"the stash. stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )


def test_runner_rejects_collection_error_as_baseline_failure(sandbox):
    """Bug #8 second guard: if the baseline run fails because of an
    ImportError or other collection error (not a real test failure),
    the runner must NOT silently treat that as 'baseline failed as
    expected' — that would let a broken regression test slip through
    and falsely validate Claude's fix."""
    # Patch present.
    (sandbox / "src" / "rtxclaw_core" / "buggy.py").write_text(
        "def add(a,b): return a+b  # fixed\n"
    )
    # Regression test imports a module that DOESN'T EXIST in the
    # baseline OR the patched tree.
    (sandbox / "tests" / "test_selfimprover_fix_deadbeef.py").write_text(textwrap.dedent("""\
        from totally_nonexistent_module import anything  # noqa
        def test_regression_fixed():
            assert anything == 1
    """))

    proc = subprocess.run(
        [str(sandbox / "scripts" / "run-self-improver-tests.sh"),
         "--no-docker",
         "test_selfimprover_fix_deadbeef.py"],
        cwd=str(sandbox), capture_output=True, text=True, timeout=60,
    )
    assert proc.returncode != 0, (
        "runner must reject collection-error as not-a-real-baseline-failure"
    )
    combined = (proc.stdout + proc.stderr).lower()
    assert "collection" in combined or "import" in combined or "infrastructure" in combined, (
        "runner must explain that baseline failed for the wrong reason "
        f"(collection / import error). Output:\n{proc.stdout}\n{proc.stderr}"
    )
