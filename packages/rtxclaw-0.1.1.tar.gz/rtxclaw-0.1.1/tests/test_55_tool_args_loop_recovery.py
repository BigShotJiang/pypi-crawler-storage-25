"""Step 55 — Worker-side loop self-abort must route through recovery,
not the hard-cancel path.

Background (2026-05-18 incident, sid=6a0b00a0cd41): a deepseek-v4-flash
turn writing 9 markdown sections via ``OutputSection`` aborted on round
14 with no operator input. Root cause: ``worker.py`` emits
``aborted`` after ``tool_args_loop`` fires; the engine's ``aborted``
handler at ``local_llm.py:1316`` treats this identically to an
operator ESC (sets ``_cancelled[sid] = True``), so the post-stream
``rs.loop_detected`` recovery cascade (distill → force-terminate →
continuation-nudge) is unreachable. Two reviewers (codex + gemini)
confirmed the structural bug.

Fix:
1. Worker emits ``{"kind": "aborted", "reason": "tool_args_loop"}``.
2. Engine distinguishes operator-aborted (bare) from
   worker-self-aborted (``reason`` set): the latter breaks out of
   consume but leaves ``_cancelled`` alone so the post-stream
   ``rs.loop_detected`` branch runs.
3. ``_detect_loops_layered`` accepts ``channel="tool_args"`` and
   skips the two entropy detectors there — they were tuned for the
   reasoning channel and false-positive on JSON-encoded prose /
   markdown bodies.
4. Round metrics persist the loop event so a future incident can be
   diagnosed from the session JSON instead of code archeology.
"""
from __future__ import annotations

import asyncio
import json
import types
from pathlib import Path

from rtxclaw_core.agents.engine import (
    EngineKind,
    EngineSessionState,
    PermissionRequested,
    TurnDone,
    TurnRequest,
)
from rtxclaw_core.agents.local_llm import LocalLLMEngine
from rtxclaw_core.turn_runtime import _detect_loops_layered


# --------------------------------------------------------------------------
# Stubs (mirrors test_22)
# --------------------------------------------------------------------------

class _Sess:
    hash = "looptest01"
    endpoint = "http://stub/v1"
    model = "stub-model"
    workspace_cwd = ""
    system_prompt = ""
    turns: list = []
    round_metrics: list = []


class _Turn:
    def __init__(self) -> None:
        self.proc = None
        self.metrics: dict = {}

    def stop(self, *args, **kwargs) -> None:  # noqa: D401, ARG002
        pass


def _make_engine(spawn):
    cfg = types.SimpleNamespace(
        upstream_max_context=8000,
        permission_mode="auto",
        reasoning_visibility="off",
        upstream_model="stub-model",
        distill_max_recoveries=0,   # disable distill recursion in tests
        _max_rounds=4,
    )

    async def _runner(*args, **kwargs):  # never invoked in these tests
        return (True, "", False, False)

    eng = LocalLLMEngine(cfg, worker_spawner=spawn, tool_runner=_runner)
    eng._build_messages_simple = (  # type: ignore[method-assign]
        lambda s, uc, sp, pre: [{"role": "user", "content": str(uc)}]
    )
    return eng


def _run(eng):
    sess = _Sess()
    sess.round_metrics = []
    req = TurnRequest(
        prompt="write sections", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={"session": sess, "hook_engine": None,
               "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"}},
    )
    state = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )

    async def _go():
        events = []
        async for ev in eng.run_turn(
            req, state, sessions_dir=Path("/tmp"), turn_id="turn-1",
        ):
            events.append(ev)
            if isinstance(ev, PermissionRequested):
                ev.response.set_result("allow")
        return events, sess

    return asyncio.run(_go())


# --------------------------------------------------------------------------
# Engine routing tests
# --------------------------------------------------------------------------

def test_bare_aborted_is_hard_cancel() -> None:
    """A worker emitting bare ``{"kind": "aborted"}`` (operator ESC /
    SIGTERM path) must terminate the turn with ``state="aborted"`` and
    must NOT enter the loop-recovery cascade.
    """
    spawns = {"n": 0}

    async def _spawn(engine, session, messages, turn_id, env):
        spawns["n"] += 1

        async def _stream():
            yield {"kind": "content", "text": "partial..."}
            yield {"kind": "aborted"}     # bare — operator cancel shape

        return _Turn(), _stream()

    eng = _make_engine(_spawn)
    events, _sess = _run(eng)
    done = [e for e in events if isinstance(e, TurnDone)]
    assert done, "engine must emit TurnDone"
    assert done[-1].state == "aborted", (
        f"bare aborted must hard-cancel; got state={done[-1].state!r}"
    )
    assert spawns["n"] == 1, "no recovery rounds for operator cancel"


def test_aborted_with_loop_reason_routes_through_recovery() -> None:
    """When the worker self-aborts because its in-flight loop detector
    fired (``aborted`` carrying ``reason="tool_args_loop"``), the engine
    must NOT treat it as a hard cancel.

    Round 0 emits the loop event + aborted-with-reason. The engine
    should leave ``_cancelled[sid]`` False, see ``rs.loop_detected``
    set, and route through the post-stream recovery branch — which in
    this stub harness (no DISTILL.md, no hook) ultimately spawns at
    least one more worker round and produces a TurnDone state that is
    NOT ``"aborted"``.
    """
    spawns = {"n": 0}

    async def _spawn(engine, session, messages, turn_id, env):
        spawns["n"] += 1
        n = spawns["n"]

        async def _stream():
            if n == 1:
                yield {
                    "kind": "tool_args_loop",
                    "index": 0,
                    "name": "OutputSection",
                    "tier": "entropy_bigram",
                    "evidence": "H2=2.45bits unique_bigrams=18",
                    "args_chars": 1503,
                }
                yield {"kind": "aborted", "reason": "tool_args_loop"}
            else:
                yield {"kind": "content", "text": "recovered."}
                yield {"kind": "metrics", "finish_reason": "stop",
                       "completion_tokens": 2, "model": "stub-model"}
                yield {"kind": "done"}

        return _Turn(), _stream()

    eng = _make_engine(_spawn)
    events, sess = _run(eng)
    done = [e for e in events if isinstance(e, TurnDone)]
    assert done, "engine must emit TurnDone"
    assert done[-1].state != "aborted", (
        "worker self-abort must not hard-cancel the turn — recovery "
        "cascade should run instead; got state="
        f"{done[-1].state!r}"
    )
    assert spawns["n"] >= 2, (
        "engine must spawn at least one recovery round after a "
        f"tool_args_loop self-abort; got spawns={spawns['n']}"
    )
    assert eng._cancelled.get(sess.hash) is not True, (
        "worker self-abort must not flip _cancelled[sid]=True"
    )


def test_tool_args_loop_evidence_persists_into_round_metrics() -> None:
    """The ``tool_args_loop`` event's diagnostic fields (tier, evidence,
    args_chars) must survive into ``session.round_metrics`` so the next
    incident can be triaged from the session JSON.

    Pre-fix: the abort path breaks out of consume before any metrics
    event arrives, ``rs.metrics`` stays None, ``_record_round_metrics``
    never fires, evidence is logged-and-lost.
    """
    async def _spawn(engine, session, messages, turn_id, env):
        async def _stream():
            yield {
                "kind": "tool_args_loop",
                "index": 0,
                "name": "OutputSection",
                "tier": "entropy_bigram",
                "evidence": "H2=2.45bits unique_bigrams=18",
                "args_chars": 1503,
            }
            yield {"kind": "aborted", "reason": "tool_args_loop"}

        return _Turn(), _stream()

    eng = _make_engine(_spawn)
    _events, sess = _run(eng)
    assert sess.round_metrics, (
        "tool_args_loop evidence must be persisted as a round metric "
        "even when the worker exits before the metrics event"
    )
    first = sess.round_metrics[0]
    assert first.get("loop_detected") is True
    assert first.get("loop_tier") == "entropy_bigram"
    assert "H2=" in str(first.get("loop_evidence") or "")
    assert first.get("loop_args_chars") == 1503
    assert first.get("loop_tool_name") == "OutputSection"


# --------------------------------------------------------------------------
# Channel-aware detector tests
# --------------------------------------------------------------------------

def _json_args(content: str) -> str:
    """Mimic the streamed tool-arguments shape the worker accumulates."""
    return json.dumps(
        {"section_name": "Summary", "criticality": "read_only",
         "content": content},
        ensure_ascii=False,
    )


def test_layered_detector_default_keeps_entropy_tiers() -> None:
    """Without a channel kwarg the layered detector must still run all
    four tiers (back-compat — the reasoning channel relies on them).

    Synthetic input: ``"abcx " * 50 + "xyza " * 50`` — proven in
    ``test_45`` to fire ``_detect_entropy_collapse`` because the
    250-char suffix has only 7 unique chars (a, b, c, x, space, y, z).
    """
    buf = ("abcx " * 50) + ("xyza " * 50)
    hit = _detect_loops_layered(buf)
    assert hit is not None, (
        "default channel must still fire on low-entropy collapse"
    )


def test_layered_detector_tool_args_channel_skips_entropy_tiers() -> None:
    """On ``channel='tool_args'`` the layered detector must skip the
    two entropy tiers. ``tight`` and ``ngram`` are still applied
    because they catch real token-collapse patterns even in structured
    payloads.

    Uses the same low-entropy input as the previous test (proven
    entropy-trigger) and verifies that with the tool_args channel the
    layered detector returns either ``None`` OR a non-entropy tier —
    never one of the entropy tiers.
    """
    buf = ("abcx " * 50) + ("xyza " * 50)

    default_hit = _detect_loops_layered(buf)
    tool_args_hit = _detect_loops_layered(buf, channel="tool_args")

    assert default_hit is not None  # established in the previous test
    if tool_args_hit is not None:
        assert tool_args_hit[0] not in {"entropy", "entropy_bigram"}, (
            f"tool_args channel must suppress entropy tiers, got "
            f"{tool_args_hit!r}"
        )


def test_layered_detector_tool_args_channel_still_catches_tight_loops() -> None:
    """``channel='tool_args'`` must not disable the tight-loop detector
    — a genuine token-collapse inside tool arguments should still fire.
    """
    pad = "abcdefghijklmnop" * 8
    collapse = ("xyz " * 40)
    buf = pad + collapse
    hit = _detect_loops_layered(buf, channel="tool_args")
    assert hit is not None, (
        "tool_args channel must still catch tight loops"
    )
    assert hit[0] in {"tight", "ngram"}
