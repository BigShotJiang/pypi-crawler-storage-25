"""Graceful CLI-bridge abort: SIGINT → 15s grace → escalate.

Covers ``ExternalCliEngine.abort`` (the path backing ``/abort`` /
``/stop`` on a delegated claude/codex/antigravity turn):

* first press (force=False) sends a friendly SIGINT and waits up to
  ``CLI_GRACEFUL_ABORT_S`` for the driver to reach its terminal stream
  event — if it finishes in time, NO SIGTERM/SIGKILL is sent (the turn
  and the CLI's own ``--resume`` state are preserved);
* on timeout it escalates SIGTERM→SIGKILL via ``_terminate_group``;
* second press (force=True) cancels the driver immediately (hard kill);
* no live proc registered → falls back to a plain driver cancel.

These run the abort logic against a fake driver task + fake proc so no
real ``claude -p`` subprocess is spawned.
"""
import asyncio
import signal

import pytest

from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
import rtxclaw_core.tools.runners as runners
import rtxclaw_core.agents.external_cli as external_cli


class _FakeProc:
    """Minimal stand-in for an asyncio subprocess in abort()."""

    def __init__(self) -> None:
        self.pid = 4242
        self.stdin = None


@pytest.fixture()
def cli_engine():
    return ClaudeCliEngine()


@pytest.fixture()
def recorded_signals(monkeypatch):
    """Capture every signal abort() routes through the runner kill
    helpers, without touching a real process group."""
    sigs: list[int] = []
    monkeypatch.setattr(
        runners, "_kill_group",
        lambda proc, sig=signal.SIGTERM: sigs.append(sig),
        raising=True,
    )

    async def _fake_terminate(proc, *, grace_s=1.0):
        sigs.append(signal.SIGTERM)
        sigs.append(signal.SIGKILL)

    monkeypatch.setattr(runners, "_terminate_group", _fake_terminate, raising=True)
    return sigs


@pytest.mark.asyncio
async def test_graceful_completion_sends_only_sigint(cli_engine, recorded_signals):
    """Driver finishes within the grace window → SIGINT only, no kill."""
    tid = "turn-graceful"
    proc = _FakeProc()
    done = asyncio.get_event_loop().create_future()

    async def _drive():
        await done
        return None

    task = asyncio.create_task(_drive())
    cli_engine._active_procs[tid] = task
    cli_engine._active_cli_procs[tid] = proc

    async def _finish_soon():
        await asyncio.sleep(0.05)
        if not done.done():
            done.set_result(None)

    asyncio.create_task(_finish_soon())
    await cli_engine.abort(tid, force=False)

    assert signal.SIGINT in recorded_signals
    assert signal.SIGKILL not in recorded_signals
    assert signal.SIGTERM not in recorded_signals


@pytest.mark.asyncio
async def test_timeout_escalates_to_sigkill(cli_engine, recorded_signals, monkeypatch):
    """Driver ignores SIGINT past the grace window → SIGTERM→SIGKILL."""
    monkeypatch.setattr(external_cli, "CLI_GRACEFUL_ABORT_S", 0.05, raising=False)
    tid = "turn-stuck"
    proc = _FakeProc()

    async def _drive():
        await asyncio.sleep(10)

    task = asyncio.create_task(_drive())
    cli_engine._active_procs[tid] = task
    cli_engine._active_cli_procs[tid] = proc

    await cli_engine.abort(tid, force=False)

    assert signal.SIGINT in recorded_signals
    assert signal.SIGKILL in recorded_signals
    await asyncio.sleep(0)
    assert task.cancelled() or task.done()


@pytest.mark.asyncio
async def test_force_cancels_immediately(cli_engine, recorded_signals):
    """Second press (force=True) → immediate driver cancel, no grace."""
    tid = "turn-force"
    proc = _FakeProc()

    async def _drive():
        await asyncio.sleep(10)

    task = asyncio.create_task(_drive())
    cli_engine._active_procs[tid] = task
    cli_engine._active_cli_procs[tid] = proc

    await cli_engine.abort(tid, force=True)
    await asyncio.sleep(0)

    assert task.cancelled()
    # force path must not send any friendly/escalation signals
    assert signal.SIGINT not in recorded_signals


@pytest.mark.asyncio
async def test_no_proc_falls_back_to_cancel(cli_engine, recorded_signals):
    """No registered proc (between rounds) → plain driver cancel."""
    tid = "turn-noproc"

    async def _drive():
        await asyncio.sleep(10)

    task = asyncio.create_task(_drive())
    cli_engine._active_procs[tid] = task
    # deliberately do NOT register _active_cli_procs[tid]

    await cli_engine.abort(tid, force=False)
    await asyncio.sleep(0)

    assert task.cancelled()
    assert signal.SIGINT not in recorded_signals


@pytest.mark.asyncio
async def test_abort_unknown_turn_is_noop(cli_engine, recorded_signals):
    """abort() on an unknown turn id is a silent no-op."""
    await cli_engine.abort("nonexistent", force=False)
    assert recorded_signals == []
