"""Step 89 — ACP stdio wire framing: newline-delimited JSON.

The Agent Client Protocol (the protocol Zed and Cursor speak) frames
JSON-RPC 2.0 messages over stdio as **newline-delimited JSON**: one
compact JSON object per line, terminated by ``\\n`` (tolerant of
``\\r\\n`` on Windows). There is NO ``Content-Length`` header — that's
the LSP / MCP-stdio framing, which is wrong for ACP.

These are fast, daemon-free unit tests of the two framing primitives in
:mod:`rtxclaw_acp.protocol.jsonrpc` — ``read_message`` /
``write_message`` — which back :class:`StdioTransport` (the only consumer
of them). WS / HTTP transports carry their own framing and are out of
scope here.
"""
from __future__ import annotations

import asyncio
import json

import pytest

from rtxclaw_acp.protocol.jsonrpc import (
    JsonRpcFramingError,
    JsonRpcRequest,
    parse_message,
    read_message,
    write_message,
)


# ---- helpers --------------------------------------------------------


class _CapturingWriter:
    """Minimal ``StreamWriter`` stand-in: records everything written."""

    def __init__(self) -> None:
        self.buf = bytearray()

    def write(self, data: bytes) -> None:
        self.buf.extend(data)

    async def drain(self) -> None:  # pragma: no cover - trivial
        return None


def _reader_from(data: bytes, *, limit: int | None = None, eof: bool = True):
    reader = (
        asyncio.StreamReader(limit=limit) if limit else asyncio.StreamReader()
    )
    reader.feed_data(data)
    if eof:
        reader.feed_eof()
    return reader


async def _write_to_bytes(payload) -> bytes:
    w = _CapturingWriter()
    await write_message(w, payload)
    return bytes(w.buf)


async def _aread(data: bytes, *, limit: int | None = None) -> bytes:
    # Build the StreamReader INSIDE the running loop — constructing it
    # eagerly outside ``asyncio.run`` trips "no current event loop".
    return await read_message(_reader_from(data, limit=limit))


# ---- write framing --------------------------------------------------


def test_write_is_newline_delimited_with_no_content_length_header() -> None:
    body = {"jsonrpc": "2.0", "id": 1, "method": "initialize"}
    raw = asyncio.run(_write_to_bytes(body))

    # Newline-terminated, exactly one trailing newline, no header block.
    assert raw.endswith(b"\n"), raw
    assert raw.count(b"\n") == 1, "message must occupy exactly one line"
    assert b"Content-Length" not in raw, "ACP framing has no Content-Length header"
    assert b"\r\n\r\n" not in raw, "ACP framing has no LSP header terminator"
    # The line (sans newline) is the compact JSON body.
    assert json.loads(raw[:-1].decode("utf-8")) == body


def test_write_serializes_compactly() -> None:
    raw = asyncio.run(_write_to_bytes({"jsonrpc": "2.0", "id": 1, "method": "x"}))
    # Compact separators → no ", " or ": " spacing on the wire.
    assert b", " not in raw and b": " not in raw


def test_write_escapes_embedded_newline_keeping_one_line() -> None:
    # A string containing a raw newline MUST be escaped so the message
    # stays a single line — otherwise NDJSON framing splits one message
    # into two.
    body = {"jsonrpc": "2.0", "id": 1, "method": "x", "params": {"t": "a\nb"}}
    raw = asyncio.run(_write_to_bytes(body))
    assert raw.count(b"\n") == 1, "embedded newline leaked onto the wire"
    assert json.loads(raw[:-1].decode("utf-8")) == body


# ---- read framing ---------------------------------------------------


def test_read_one_newline_delimited_message() -> None:
    body = b'{"jsonrpc":"2.0","id":1,"method":"initialize"}'
    out = asyncio.run(_aread(body + b"\n"))
    assert out == body


def test_read_back_to_back_messages() -> None:
    a = b'{"jsonrpc":"2.0","id":1,"method":"a"}'
    b = b'{"jsonrpc":"2.0","id":2,"method":"b"}'

    async def run() -> tuple[bytes, bytes]:
        reader = _reader_from(a + b"\n" + b + b"\n")
        return await read_message(reader), await read_message(reader)

    first, second = asyncio.run(run())
    assert first == a
    assert second == b


def test_read_tolerates_crlf_line_ending() -> None:
    body = b'{"jsonrpc":"2.0","id":1,"method":"a"}'
    out = asyncio.run(_aread(body + b"\r\n"))
    assert out == body, "trailing CR must be stripped (Windows CRLF)"


def test_read_skips_blank_lines() -> None:
    body = b'{"jsonrpc":"2.0","id":1,"method":"a"}'
    out = asyncio.run(_aread(b"\n\n" + body + b"\n"))
    assert out == body


def test_read_clean_eof_raises_framing_error_with_expected_prefix() -> None:
    # serve_until_close (and every transport EOF path) matches this exact
    # message prefix to shut down cleanly — keep it verbatim.
    with pytest.raises(JsonRpcFramingError) as exc:
        asyncio.run(_aread(b""))
    assert str(exc.value).startswith("EOF before any header bytes")


def test_read_eof_midline_returns_partial_message() -> None:
    # A final, well-formed message without a trailing newline is still a
    # message.
    body = b'{"jsonrpc":"2.0","id":1,"method":"a"}'
    out = asyncio.run(_aread(body))  # no trailing \n
    assert out == body


# ---- round trip + byte fidelity ------------------------------------


def test_round_trip_write_then_read() -> None:
    body = {"jsonrpc": "2.0", "id": 7, "method": "session/new", "params": {"cwd": "/x"}}

    async def run() -> bytes:
        raw = await _write_to_bytes(body)
        return await read_message(_reader_from(raw))

    out = asyncio.run(run())
    assert json.loads(out.decode("utf-8")) == body


def test_raw_message_round_trips_verbatim() -> None:
    # parse_message stores the line (sans newline) as raw_message;
    # write_message must re-emit it byte-identically plus exactly one \n.
    line = b'{"jsonrpc":"2.0","id":3,"method":"session/prompt","params":{"sessionId":"s"}}'
    msg = parse_message(line)
    assert isinstance(msg, JsonRpcRequest)
    raw = asyncio.run(_write_to_bytes(msg))
    assert raw == line + b"\n", "raw_message must survive a read→write round trip"


def test_large_message_round_trips_beyond_default_buffer() -> None:
    # Base64 image blocks blow past asyncio's default 64 KiB StreamReader
    # limit; the NDJSON reader must be constructed with a raised limit.
    big = "x" * (512 * 1024)  # 512 KiB payload, well over 64 KiB
    body = {"jsonrpc": "2.0", "id": 9, "method": "session/prompt", "params": {"blob": big}}

    async def run() -> bytes:
        raw = await _write_to_bytes(body)
        reader = _reader_from(raw, limit=64 * 1024 * 1024)
        return await read_message(reader)

    out = asyncio.run(run())
    assert json.loads(out.decode("utf-8")) == body


def test_acp_stream_limit_constant_is_generous() -> None:
    # The stdio stream/subprocess constructors size their read buffer off
    # this constant so large prompts (images) don't trip the line limit.
    from rtxclaw_acp.protocol import jsonrpc

    assert jsonrpc.ACP_STREAM_LIMIT >= 16 * 1024 * 1024
