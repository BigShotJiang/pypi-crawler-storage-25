"""Step 02 — workspace isolation.

``RTXCLAW_HOME`` must redirect every path resolver in the runtime, and
the real ``~/.rtxclaw/`` must stay untouched while sandboxed commands
run.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from conftest import RTXCLAW_BIN, REPO_ROOT


# Live prod activity (the long-running agent + telegram bot writing
# session JSON, daily logs, getUpdates offsets, etc.) constantly
# mutates a handful of well-known runtime-state paths under
# ``~/.rtxclaw``. The test below only cares that a *sandboxed* command
# doesn't leak files INTO the real home — not whether prod happened
# to bump a session mtime in the same second the test ran. We exclude
# those paths from the fingerprint so the test is robust against the
# operator running the suite while prod is active.
_RUNTIME_STATE_SUFFIXES: tuple[str, ...] = (
    "/sessions",
    "/memory",
    "/logs",
    "/errors",
    "/heartbeat-state.json",
    "/telegram/sessions.json",
    "/telegram/offset.json",
    "/telegram/telegram.pid",
    "/.git",
    # Skill runtimes write into their own subdirs while the suite runs.
    # nodriver-browser holds a live Chrome profile (cookies, LevelDB,
    # extension state) continuously updated by whatever browser is
    # attached to ``~/.rtxclaw/skills/nodriver-browser/profiles/``;
    # nothing the test could legitimately leak would land under a
    # skill's own dir. Excluding the whole skills tree keeps the
    # guard focused on operator-curated state (config, agent home,
    # telegram cfg).
    "/skills/",
    # Per-process discovery / call traces — the production agent
    # rewrites these on every MCP discovery cycle; not a test leak.
    "/mcp_calls.log",
    "/mcp_discovery.last",
    "/command_history.json",
)


def _is_runtime_state(path: str) -> bool:
    return any(s in path for s in _RUNTIME_STATE_SUFFIXES)


def _fingerprint(p: Path) -> set[tuple[float, str]]:
    if not p.is_dir():
        return set()
    out: set[tuple[float, str]] = set()
    for entry in p.rglob("*"):
        path_str = str(entry)
        if _is_runtime_state(path_str):
            continue
        try:
            out.add((entry.stat().st_mtime, path_str))
        except FileNotFoundError:
            pass
    return out


def test_resolvers_redirect_to_sandbox(run_in_venv, sandbox_home: Path) -> None:
    code = (
        "from rtxclaw_core.agent  import rtxclaw_root, agents_root\n"
        "from rtxclaw_core.errors import errors_dir\n"
        "from rtxclaw_agent.config import default_root\n"
        "print(rtxclaw_root())\nprint(agents_root())\n"
        "print(errors_dir())\nprint(default_root('main'))\n"
    )
    cp = run_in_venv(code)
    assert cp.returncode == 0, cp.stderr
    root, agents, errors, agent_main = cp.stdout.strip().splitlines()
    assert root == str(sandbox_home)
    assert agents == str(sandbox_home / "agents")
    assert errors == str(sandbox_home / "errors")
    assert agent_main == str(sandbox_home / "agents" / "main")


def test_real_home_untouched(sandbox_env, sandbox_home: Path) -> None:
    real = Path.home() / ".rtxclaw"
    before = _fingerprint(real)
    sandbox_home.mkdir(parents=True, exist_ok=True)
    # configure --show triggers the same path-resolution code paths a
    # real run would, then exits without writing anything if the config
    # is missing.
    subprocess.run(
        [str(RTXCLAW_BIN), "configure", "--show"],
        env=sandbox_env, capture_output=True, timeout=30,
    )
    after = _fingerprint(real)
    assert before == after, f"real ~/.rtxclaw changed: {after - before}"


def test_agents_home_overrides_workspace(run_in_venv, tmp_path: Path) -> None:
    """`RTXCLAW_AGENTS_HOME` is more specific and must win over `RTXCLAW_HOME`."""
    custom_agents = tmp_path / "agents"
    code = (
        f"import os\n"
        f"os.environ['RTXCLAW_AGENTS_HOME'] = {str(custom_agents)!r}\n"
        f"from rtxclaw_core.agent import rtxclaw_root, agents_root\n"
        f"print(rtxclaw_root())\nprint(agents_root())\n"
    )
    cp = run_in_venv(code)
    assert cp.returncode == 0, cp.stderr
    root, agents = cp.stdout.strip().splitlines()
    assert agents == str(custom_agents)
    assert root == str(custom_agents.parent)
