"""Step 41 — TUI render order with parallel tool calls.

Regression for the bug where a turn that emits multiple tool calls in
ONE round (e.g. several ``web_fetch`` calls fanned out by qwen3.6) ended
up rendering the next round's answer ABOVE one or more of the
tool_result widgets in the transcript. Visually:

    🔧 web_fetch(url=A)
    🔧 web_fetch(url=B)
    ✅ result A
    answer text from round 2  ←  WRONG — appears here
    ❌ result B
    [no further answer]

Root cause: ``_stream_via_agent`` eagerly mounted a fresh
``AssistantMessage`` after EVERY ``tool_result`` event so the prefill
counter could tick during round-2 prefill. With parallel tool results
that mount happened BETWEEN result A and result B, so the next
``chunk`` event landed in that prematurely-mounted assistant — visually
above the still-pending result B.

Fix: track in-flight tool_call_ids in ``_pending_tool_calls`` (set on
``tool_call``, cleared on ``tool_result``) and only ensure_assistant
once the set is empty (i.e. the LAST parallel sibling has resolved).

This test drives ``_stream_via_agent`` with a synthetic event sequence
and asserts the recorded mount order. No upstream model, no daemon —
the only side-effects observed are the order of widgets handed to
``transcript.mount``.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any, AsyncIterator, Iterable
from unittest.mock import MagicMock

import pytest

# `tests/conftest.py` adds src/ to sys.path; mirror that defensively for
# pytest-direct invocations that bypass conftest.
_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_tui.app import (  # noqa: E402
    AssistantMessage,
    AgentChatApp,
    ToolCallMessage,
    ToolResultMessage,
)


class _FakeTranscript:
    """Records mount() invocations in order so the test can assert the
    chronological transcript layout produced by ``_stream_via_agent``.

    Only the surface ``_stream_via_agent`` actually touches is
    implemented: ``mount`` (async), ``scroll_end``, ``query`` (returns
    [] so the streaming-tool-delta lookup is a no-op).
    """

    def __init__(self) -> None:
        self.mounted: list[Any] = []

    async def mount(self, widget: Any) -> None:
        self.mounted.append(widget)

    @property
    def children(self) -> list[Any]:
        # ``_ensure_assistant`` in ``rtxclaw_tui.app`` does
        # ``list(transcript.children)`` to walk previously-mounted
        # widgets when catching up late-arriving chunks (commit
        # 14bf624). Without this property the call AttributeError's
        # before any layout assertion can run.
        return list(self.mounted)

    def scroll_end(self, *, animate: bool = False) -> None:
        return None

    def query(self, *args: Any, **kwargs: Any) -> Iterable[Any]:
        return []

    async def wait_for_refresh(self) -> None:
        # The tool_call handler awaits this before mounting the
        # ToolCallMessage so Textual has a frame to lay out the
        # just-finalized AssistantMessage. In a real run it's a
        # `call_after_refresh` round-trip; for headless tests, a
        # no-op coroutine is enough.
        return None


def _events_parallel_two_calls() -> list[tuple[str, dict, str]]:
    """Wire shape the bridge produces for ONE round with TWO parallel
    tool calls plus a follow-up answer round."""
    tid = "tid-parallel"
    return [
        ("started", {"turn_id": tid}, tid),
        # Round 0: model decided to call two tools in parallel.
        ("tool_call", {
            "tool": "WebFetch",
            "call_id": "call_A",
            "arguments": {"url": "https://example.com/a"},
        }, tid),
        ("tool_call", {
            "tool": "WebFetch",
            "call_id": "call_B",
            "arguments": {"url": "https://example.com/b"},
        }, tid),
        # Both results arrive back-to-back (the asyncio.gather batch in
        # CoreBackend._execute_batch_parallel completes both subprocesses
        # before any round-1 chunk).
        ("tool_result", {
            "call_id": "call_A",
            "ok": True,
            "content": "result A body",
        }, tid),
        ("tool_result", {
            "call_id": "call_B",
            "ok": False,
            "content": "result B error",
        }, tid),
        # Round 1: model writes its answer using both results.
        ("chunk", {"choices": [{"delta": {"content": "the answer"}}]}, tid),
        ("done", {"state": "complete"}, tid),
    ]


def _make_session_turn_gen(events: list[tuple[str, dict, str]]):
    """Build a coroutine factory that returns a fresh async generator
    yielding the canned event triples each call."""
    async def _gen(*_args: Any, **_kwargs: Any) -> AsyncIterator[tuple[str, dict, str]]:
        for ev in events:
            yield ev
    return _gen


async def _drive(app: AgentChatApp, transcript: _FakeTranscript, text: str) -> None:
    """Patch ``query_one`` to return our fake transcript and run the
    SSE handler. Wraps ``_stream_via_agent`` directly — no Textual
    pilot, no event loop driver — because we only observe the order
    of widgets handed to ``transcript.mount``."""
    app.query_one = MagicMock(return_value=transcript)
    # ``_stream_via_agent`` calls these UI-only helpers; stub to no-ops
    # so we don't need a live Textual app context.
    app._set_worker_state = MagicMock()
    app._refresh_status_bar = MagicMock()
    app._set_status = MagicMock()
    app._refresh_title = MagicMock()
    app._maybe_start_next = MagicMock()  # bypass queue drain (no UI)

    # End-of-turn refresh hits ``_client.get_session``; return a
    # complete-enough Session payload so the post-loop block doesn't
    # raise. We don't assert anything about the resulting Session.
    async def _fake_get_session(_sid: str) -> dict:
        return {
            "hash": "h",
            "title": "t",
            "created_at": "2026-01-01T00:00:00Z",
            "system_prompt": "",
            "model": "test",
            "endpoint": "http://x",
            "turns": [],
            "context_window": 0,
        }
    app._client.get_session = _fake_get_session  # type: ignore[attr-defined]

    await app._stream_via_agent(text)


@pytest.fixture
def app() -> AgentChatApp:
    """Construct AgentChatApp with the bare attributes
    ``_stream_via_agent`` reads. We avoid ``__init__`` (which loads the
    system prompt + builds Textual widgets) and instead instantiate via
    ``__new__`` and populate just the fields the SSE handler touches."""
    a = AgentChatApp.__new__(AgentChatApp)
    a._sid = "sid-test"
    a._current_turn_id = None
    a._current_assistant = None
    a._pending_tool_calls = set()
    a.enable_thinking = False
    a.reasoning_visibility = "off"
    a._permission_mode = "auto"
    a._last_prompt_tokens = 0
    a._last_context_window = 0
    a._plans = []
    # Subagent-box + plan/section/question/update/harness-task
    # bookkeeping added by 14bf624 (built-in /goal command) +
    # subsequent harness commits — `_stream_via_agent` reaches for
    # these on tool_call AND tool_result events. Without them the
    # SSE handler AttributeError's and Textual's worker swallows it
    # silently → tool widgets stop mounting partway through.
    a._subagent_box_stack = []
    a._subagent_boxes_by_call = {}
    a._suppressed_subagent_calls = set()
    a._plan_call_ids = set()
    a._section_call_ids = set()
    a._user_question_call_ids = set()
    a._update_call_ids = set()
    a._harness_task_call_ids = set()
    a._pending_task_create_calls = {}
    a._subagent_done = 0
    a._subagent_failed = 0
    a._subagent_total = 0
    return a


def test_parallel_tool_results_render_above_next_round_assistant(app: AgentChatApp) -> None:
    """Two parallel tool_result events + a round-1 answer chunk →
    transcript order MUST be:

        ToolCallMessage(A)
        ToolCallMessage(B)
        ToolResultMessage(A)
        ToolResultMessage(B)
        AssistantMessage   ← receives the round-1 answer

    The bug placed the AssistantMessage between ToolResultMessage(A)
    and ToolResultMessage(B). This test pins the fix.
    """
    events = _events_parallel_two_calls()
    transcript = _FakeTranscript()

    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "do parallel fetch"))

    types = [type(w).__name__ for w in transcript.mounted]
    # The eager pre-loop ``_ensure_assistant`` mounts the first
    # AssistantMessage (round-0 prefill counter). After that, the
    # parallel-tool block must produce the chronological order:
    #     [AssistantMessage, ToolCall, ToolCall, ToolResult, ToolResult,
    #      AssistantMessage]
    expected_tail = [
        "ToolCallMessage",
        "ToolCallMessage",
        "ToolResultMessage",
        "ToolResultMessage",
        "AssistantMessage",
    ]
    assert types[0] == "AssistantMessage", (
        f"first mount should be the eager round-0 AssistantMessage, "
        f"got {types[:3]}"
    )
    assert types[1:] == expected_tail, (
        f"transcript layout drifted from chronological order.\n"
        f"got: {types}\nexpected tail after the round-0 assistant: "
        f"{expected_tail}"
    )

    # Critical invariant: NO AssistantMessage may sit between the two
    # ToolResultMessage widgets — that's the exact rendering bug.
    tr_indices = [i for i, t in enumerate(types) if t == "ToolResultMessage"]
    assert len(tr_indices) == 2, f"expected two tool-result widgets, got {tr_indices}"
    between = types[tr_indices[0] + 1 : tr_indices[1]]
    assert "AssistantMessage" not in between, (
        f"AssistantMessage was mounted between the two parallel "
        f"tool_result widgets — the bug. Slice between them: {between}"
    )


def test_pending_tool_calls_cleared_on_each_turn(app: AgentChatApp) -> None:
    """A prior turn that ended with stale entries in
    ``_pending_tool_calls`` (transport drop, ESC abort) must NOT
    suppress the eager next-round AssistantMessage on the next turn —
    ``_send_user_turn`` clears the set, but ``_stream_via_agent`` is
    the SSE handler so we verify here that the SET is fresh by the
    time the FIRST tool_result of a new turn arrives.

    Concretely: pre-populate the set with an old call_id, drive a
    single-call turn, and assert the eager assistant DID get mounted
    after the result."""
    # Simulate the cleanup that `_send_user_turn` performs before
    # spawning the worker:
    app._pending_tool_calls = {"stale_call_from_prev_turn"}
    app._pending_tool_calls.clear()

    tid = "tid-single"
    events = [
        ("started", {"turn_id": tid}, tid),
        ("tool_call", {"tool": "ping", "call_id": "c1", "arguments": {}}, tid),
        ("tool_result", {"call_id": "c1", "ok": True, "content": "pong"}, tid),
        ("chunk", {"choices": [{"delta": {"content": "ok"}}]}, tid),
        ("done", {"state": "complete"}, tid),
    ]

    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "ping"))

    types = [type(w).__name__ for w in transcript.mounted]
    # Eager pre-loop AM, then ToolCall, ToolResult, then the next-round
    # eager AM (the prefill-counter mount we want to keep firing).
    assert types == [
        "AssistantMessage",
        "ToolCallMessage",
        "ToolResultMessage",
        "AssistantMessage",
    ], f"unexpected mount sequence: {types}"
    # Set MUST be empty at end-of-turn for the next turn's eager mount.
    assert app._pending_tool_calls == set(), app._pending_tool_calls
