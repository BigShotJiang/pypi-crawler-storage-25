"""Validates the shipped hooks.json template loads with the rtxclaw
hook engine and registers the four expected events."""
import json
from pathlib import Path

TEMPLATE = Path(__file__).resolve().parents[1] / "assets" / "self-improver" / "hooks.json"


def test_template_parses():
    data = json.loads(TEMPLATE.read_text())
    assert "hooks" in data, "must have top-level 'hooks' key"


def test_template_registers_all_four_events():
    data = json.loads(TEMPLATE.read_text())
    expected = {"ReasoningLoopDetected", "PrematureTurnEnd",
                "PostToolUseFailure", "SessionError"}
    assert expected <= set(data["hooks"].keys()), \
        f"missing events: {expected - set(data['hooks'].keys())}"


def test_template_uses_async_and_wrapper_script():
    data = json.loads(TEMPLATE.read_text())
    for event, groups in data["hooks"].items():
        for group in groups:
            for hook in group["hooks"]:
                assert hook.get("async") is True, f"{event} hook must be async"
                assert "self-improver.sh" in hook["command"], \
                    f"{event} command must call self-improver.sh"


def test_template_does_not_hook_stop():
    """Stop is intentionally NOT hooked — periodic cold scan handles
    successful sessions instead. Regression guard against accidental
    re-introduction."""
    data = json.loads(TEMPLATE.read_text())
    assert "Stop" not in data["hooks"]


def test_template_loads_with_real_hook_engine():
    """Sanity: feed the template through the real loader; no warnings."""
    from rtxclaw_core import hooks as _hooks

    # Use whichever loader API exists. Try `HookEngine.from_file` first,
    # else load via the generic `load(...)`. If neither exists, fall
    # back to validating the JSON shape against `HOOK_EVENTS` membership.
    if hasattr(_hooks.HookEngine, "from_file"):
        engine = _hooks.HookEngine.from_file(str(TEMPLATE))
        events = set(engine.events()) if hasattr(engine, "events") else set()
        assert {"ReasoningLoopDetected", "PrematureTurnEnd",
                "PostToolUseFailure", "SessionError"} <= events
    else:
        # Fallback: every event in the template must be in HOOK_EVENTS.
        data = json.loads(TEMPLATE.read_text())
        for event in data["hooks"].keys():
            assert event in _hooks.HOOK_EVENTS, (
                f"hooks.json references unregistered event: {event}"
            )
