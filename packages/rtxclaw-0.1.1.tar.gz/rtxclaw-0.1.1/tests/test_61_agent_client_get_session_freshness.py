"""Step 61 — ``AgentClient.get_session`` re-reads turns from disk.

Regression for the ``/claude`` (and ``/codex`` / ``/gemini``) preamble
serving a stale prior conversation. The TUI's ``_run_claude`` builds
the preamble from ``self._client.get_session(sid)``. The old
implementation kept a per-sid ``_session_view`` cache and short-
circuited on ``if view.get('turns'): return cached`` — under the
(incorrect) belief that ``session_turn`` was folding streamed turn
deltas back into the cache. It isn't, so the cached snapshot froze at
whatever the disk held the first time ``get_session`` was called and
every later call served stale data.

Symptom captured in session ``6a0b12f0e189152add000001``: ``/claude is
this fix correct?`` was delegated with a preamble of
``[user] hi\\n=== end of conversation history ===`` even though the
real prior turn carried a multi-paragraph fix request. Claude correctly
replied "I don't see a fix in this conversation — the prior context
only shows 'hi'."

This test pins the contract: every ``get_session(sid)`` call re-reads
the persisted JSON, so turns appended between calls (by the same
frontend, by Telegram, by the cross-frontend poll, by an external CLI
writing the session file) surface on the next read.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_tui.agent_client import AgentClient  # noqa: E402


class _StubAgentConfig:
    """Stand-in for ``rtxclaw_core.agent.AgentConfig.load``.

    ``AgentClient.get_session`` only reads ``sessions_dir`` off the
    returned config object, so a dataclass-shaped stub is enough.
    """

    def __init__(self, sessions_dir: Path) -> None:
        self.sessions_dir = sessions_dir

    @classmethod
    def make_loader(cls, sessions_dir: Path):
        def _load(_name: str) -> "_StubAgentConfig":
            return cls(sessions_dir)
        return _load


def _write_session(
    sessions_dir: Path, sid: str, turns: list[dict], *,
    model: str = "test-model", endpoint: str = "http://x",
    backend: str = "test", context_window: int = 0,
    workspace_origin: str = "tui",
) -> None:
    """Persist a v2 session: a fresh ``<sid>.jsonl`` event log (session_started
    + one turn per entry) — the shape ``record_turn`` writes. Rebuilds from
    scratch each call (test fixture) so callers can express "disk now holds
    these turns / this model"."""
    from rtxclaw_core.session_writer import (
        close_session_writer, get_session_writer,
    )
    from rtxclaw_core.session_index import SessionIndex
    close_session_writer(sessions_dir, sid)
    for nm in (f"{sid}.jsonl", f".{sid}.lock"):
        try:
            (sessions_dir / nm).unlink()
        except FileNotFoundError:
            pass
    try:
        SessionIndex(sessions_dir.parent).remove_session(sid)
    except Exception:
        pass
    w = get_session_writer(sessions_dir, sid, engine="local_llm")
    w.session_started({
        "session_hash": sid, "created_at": "2026-01-01T00:00:00Z",
        "title": "test", "model": model, "endpoint": endpoint,
        "backend": backend, "context_window": context_window,
        "workspace_origin": workspace_origin, "engine": "local_llm",
    })
    for i, t in enumerate(turns):
        w.record_stream(
            turn_idx=i, user=t.get("user", ""),
            content=t.get("content", ""), terminal=True,
        )
    close_session_writer(sessions_dir, sid)


def _make_client() -> AgentClient:
    """Build an AgentClient with the connect path stubbed.

    ``AgentClient.__init__`` only sets local state, so we can construct
    one directly. ``_ensure_connected`` is async and normally opens the
    stdio child; replace it with a no-op coroutine so the disk-read
    path runs in isolation.
    """
    client = AgentClient(agent_name="main")

    async def _noop() -> None:
        return None

    client._ensure_connected = _noop  # type: ignore[assignment]
    return client


def test_get_session_picks_up_turns_appended_after_first_call(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A turn written to disk AFTER the first ``get_session`` is visible
    on the next call. The pre-fix cache returned the original 1-turn
    snapshot forever, which is what broke the /claude preamble."""
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        _StubAgentConfig.make_loader(sessions_dir),
    )

    sid = "test-sid-0001"
    _write_session(sessions_dir, sid, turns=[
        {"user": "hi", "content": "hello back"},
    ])

    client = _make_client()
    first = asyncio.run(client.get_session(sid))
    assert [t["user"] for t in first["turns"]] == ["hi"]

    # Simulate the agent persisting a second turn (e.g., the long fix
    # request that landed between two /claude calls in session
    # 6a0b12f0e189152add000001).
    _write_session(sessions_dir, sid, turns=[
        {"user": "hi", "content": "hello back"},
        {"user": "please fix the presencePenalty bug", "content": "..."},
    ])

    second = asyncio.run(client.get_session(sid))
    users = [t["user"] for t in second["turns"]]
    assert users == ["hi", "please fix the presencePenalty bug"], (
        "get_session must re-read turns from disk — the cache has no "
        "live-update path so a stale snapshot would feed wrong context "
        "to the /claude preamble builder."
    )


def test_get_session_does_not_mask_cross_frontend_model_change(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Another frontend (Telegram / second TUI) issuing ``/model gpu-c``
    persists the change to disk via ``session/set_config_option``.
    ``get_session`` must surface that fresh value, NOT overlay the
    stale ``gpu-a`` left in ``_session_view`` from this TUI's last
    hydration. The earlier overlay-everything fix would have pinned
    the TUI to ``gpu-a`` indefinitely; codex flagged this as a
    sticky-stale-cache regression."""
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        _StubAgentConfig.make_loader(sessions_dir),
    )

    sid = "test-sid-0002"
    # Initial disk + cache state agree on ``gpu-a``.
    _write_session(
        sessions_dir, sid, turns=[],
        model="gpu-a", endpoint="http://a", backend="vllm",
        context_window=32000,
    )

    client = _make_client()
    first = asyncio.run(client.get_session(sid))
    assert first["model"] == "gpu-a"
    # Cache now holds gpu-a — same as disk.

    # Cross-frontend mutation: another bridge client persisted gpu-c.
    _write_session(
        sessions_dir, sid, turns=[],
        model="gpu-c", endpoint="http://c", backend="sglang",
        context_window=128000,
    )

    second = asyncio.run(client.get_session(sid))
    assert second["model"] == "gpu-c", (
        "disk is the source of truth — a cross-frontend /model change "
        "must not be masked by a stale cached value from this client's "
        "prior hydration."
    )
    assert second["endpoint"] == "http://c"
    assert second["backend"] == "sglang"
    assert second["context_window"] == 128000


def test_status_command_reflects_disk_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``/status`` must read fresh disk state, not the cached
    ``_session_view``. Before the fix, ``/status`` showed whatever
    model was cached at first hydration — so a Telegram-side
    ``/model`` change was invisible to the TUI footer."""
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        _StubAgentConfig.make_loader(sessions_dir),
    )

    sid = "test-sid-0003"
    _write_session(sessions_dir, sid, turns=[])
    # Pre-seed cache with a STALE model so we'd see it if /status
    # bypassed get_session.
    client = _make_client()
    client._session_view[sid] = {
        "sid": sid, "turns": [],
        "model": "stale-cached", "endpoint": "http://stale",
        "backend": "stale-backend",
    }
    # Write a different value to disk.
    _write_session(
        sessions_dir, sid, turns=[],
        model="fresh-disk", endpoint="http://fresh", backend="fresh-backend",
    )

    out = asyncio.run(client.session_command(sid, "/status"))
    assert out["ok"]
    assert out["data"]["model"] == "fresh-disk"
    assert out["data"]["upstream"] == "http://fresh"
    assert out["data"]["backend"] == "fresh-backend"


def test_create_session_returns_bridge_chosen_upstream_not_agent_default(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the engine's ``set_config_option`` mutates the runtime
    cfg (e.g. user ran ``/model deepseek`` earlier this gateway run),
    the bridge creates new sessions with the mutated upstream while
    the disk-loaded ``agent_cfg`` still names the original default.
    ``create_session`` must return the BRIDGE's choice so the TUI
    footer shows the right model at startup instead of flipping from
    ``agent_cfg.upstream_model`` to the disk-persisted value the
    moment the first end-of-turn refresh runs ``get_session``.

    Repro: footer shows ``tb07`` at TUI start, transitions to
    ``deepseek`` after the first prompt — visible across every
    rtxclaw session created today (2026-05-18) on this box."""
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        _StubAgentConfig.make_loader(sessions_dir),
    )

    # AgentConfig.load is stubbed to a minimal class with only
    # ``sessions_dir``. Extend the stub with the upstream_* /
    # engine fields create_session reads for the default fallback.
    class _ExtendedCfg(_StubAgentConfig):
        engine = ""
        upstream_endpoint = "http://192.168.0.70:8001/v1"  # tb07
        upstream_model = "qwen3.6-27b-fp8"  # tb07
        upstream_max_context = 0
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        lambda _name: _ExtendedCfg(sessions_dir),
    )

    sid = "test-sid-0005"
    # Bridge persists session with deepseek (its runtime cfg was
    # mutated by an earlier /model deepseek). The TUI's agent_cfg
    # still says tb07.
    _write_session(
        sessions_dir, sid, turns=[],
        model="deepseek-v4-flash", endpoint="https://api.deepseek.com/v1",
        backend="openai-compat", context_window=128000,
        workspace_origin="acp",
    )

    client = _make_client()
    # Patch the connect path AND session_new so create_session can
    # run without spawning a real stdio child / opening a real ACP
    # connection.
    class _FakeAcp:
        async def session_new(self, *_a, **_k):
            return sid

    fake_acp = _FakeAcp()

    async def _ensure_connected_stub():
        return fake_acp

    client._ensure_connected = _ensure_connected_stub  # type: ignore[assignment]

    view = asyncio.run(client.create_session(
        workspace_cwd="/tmp", workspace_origin="tui",
    ))
    assert view["model"] == "deepseek-v4-flash", (
        "create_session must surface the bridge-persisted model "
        "(deepseek-v4-flash), not the agent_cfg upstream_model "
        "default (qwen3.6-27b-fp8) — otherwise the TUI footer "
        "lies until the first turn finishes."
    )
    assert view["endpoint"] == "https://api.deepseek.com/v1"
    assert view["backend"] == "openai-compat"
    assert view["context_window"] == 128000


def test_history_command_reflects_disk_turns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``/history`` must list turns from disk so an external-frontend
    turn (Telegram, OpenAI-compat) shows up here. Pre-fix this read
    the cache, which never picked up streamed turn deltas."""
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(
        "rtxclaw_core.agent.AgentConfig.load",
        _StubAgentConfig.make_loader(sessions_dir),
    )

    sid = "test-sid-0004"
    _write_session(sessions_dir, sid, turns=[
        {"user": "first", "content": "a"},
        {"user": "second", "content": "b"},
        {"user": "third", "content": "c"},
    ])
    # Cache holds an OLDER snapshot (1 turn). Pre-fix /history would
    # have shown only "first".
    client = _make_client()
    client._session_view[sid] = {
        "sid": sid,
        "turns": [{"user": "first", "content": "a"}],
    }

    out = asyncio.run(client.session_command(sid, "/history 5"))
    assert out["ok"]
    users = [t.get("user") for t in out["data"]["turns"]]
    assert users == ["first", "second", "third"]
