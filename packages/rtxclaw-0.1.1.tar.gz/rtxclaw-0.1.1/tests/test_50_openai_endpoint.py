"""OpenAI-compatible HTTP API at ``/openai/v1`` — real-operation tests.

Every test in this module exercises the **live** single-process
gateway running against the real upstream LLM configured via
``tests/.env`` (``RTXCLAW_TEST_ENDPOINT`` / ``RTXCLAW_TEST_MODEL``).
No fake ChildManager, no fake AcpClient, no scripted event stream —
the gateway is up, the agent is mounted, and ``/openai/v1/...`` is
the wire shape Open WebUI actually sees.

Routes verified:

- ``GET  /openai/v1/models``               — agent listing
- ``GET  /openai/v1/models/{name}``        — single agent
- ``POST /openai/v1/chat/completions``     — non-streaming + streaming
- ``POST /openai/v1/embeddings``           — text embeddings
- ``POST /openai/v1/audio/transcriptions`` — STT
- ``POST /openai/v1/audio/speech``         — TTS
- ``POST /openai/v1/responses``            — 404 stub
- ``GET  /openai/v1/slots``                — ``[]`` stub
- Bearer-token auth                        — when ``gateway.auth_token``
                                              is set in config.json.

Per-test setup uses the ``running_daemon`` fixture (gateway up on a
worker-isolated port) and resolves the bearer + base URL from the
sandbox config — same machinery the production gateway uses.
"""
from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest



# Slow tier: every test here drives running_daemon / scaffolded_agent.
# Excluded from pre-commit tier-1 via -m "not slow".
pytestmark = pytest.mark.slow

# ---------------------------------------------------------------------------
# real-gateway URL + bearer resolved from sandbox config
# ---------------------------------------------------------------------------


def _gateway_base_url(sandbox_home: Path) -> str:
    cfg_path = sandbox_home / "config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    gw = cfg.get("gateway") or {}
    host = gw.get("host") or "127.0.0.1"
    port = int(gw.get("port") or 27700)
    return f"http://{host}:{port}"


def _bearer(sandbox_home: Path) -> str | None:
    cfg_path = sandbox_home / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return (cfg.get("gateway") or {}).get("auth_token") or None


def _auth_headers(token: str | None) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"} if token else {}


_FORCED_BEARER = "test-bearer-rtxclaw-openai-50"


@pytest.fixture(scope="session")
def gateway_with_bearer(
    scaffolded_agent: Path, sandbox_home: Path, sandbox_env: dict,
) -> Path:
    """Like ``running_daemon`` but with ``gateway.auth_token`` set
    BEFORE the gateway boots. Every test_50 test thus exercises the
    real bearer-auth code path — there is no "bearer-less" branch in
    this module, only ``with valid bearer``.

    Idempotent: if a gateway is already running with the wrong (or
    no) auth_token, stop it first and start a fresh one.
    """
    import subprocess
    import time
    from conftest import RTXCLAW_BIN
    cfg_path = sandbox_home / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        cfg = {}
    gw = cfg.get("gateway") or {}
    desired_token = _FORCED_BEARER

    def _rtxclaw(*args: str, timeout: int = 60):
        return subprocess.run(
            [str(RTXCLAW_BIN), *args],
            env=sandbox_env, capture_output=True, text=True, timeout=timeout,
        )

    pidfile = sandbox_home / "gateway.pid"
    if gw.get("auth_token") != desired_token:
        if pidfile.exists():
            _rtxclaw("gateway", "stop", timeout=30)
            deadline = time.time() + 10
            while pidfile.exists() and time.time() < deadline:
                time.sleep(0.2)
        gw["auth_token"] = desired_token
        cfg["gateway"] = gw
        cfg_path.write_text(
            json.dumps(cfg, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    if not pidfile.exists():
        cp = _rtxclaw("gateway", "start", timeout=120)
        if cp.returncode != 0:
            pytest.fail(f"gateway start failed:\n{cp.stderr}")
        deadline = time.time() + 20
        while not pidfile.exists() and time.time() < deadline:
            time.sleep(0.2)
    return pidfile


@pytest.fixture
def openai_base(gateway_with_bearer: Path, sandbox_home: Path) -> str:  # noqa: ARG001
    """``http://<gateway-host>:<port>/openai/v1`` — the real route on
    the bearer-auth-enabled gateway."""
    return _gateway_base_url(sandbox_home).rstrip("/") + "/openai/v1"


@pytest.fixture
def bearer(sandbox_home: Path, gateway_with_bearer: Path) -> str:  # noqa: ARG001
    """Always returns a real bearer token (the one ``gateway_with_bearer``
    wrote into sandbox config). Never ``None`` — there is no
    bearer-less branch in this module."""
    tok = _bearer(sandbox_home)
    assert tok == _FORCED_BEARER, (
        f"gateway_with_bearer fixture failed to set auth_token; "
        f"got {tok!r}, expected {_FORCED_BEARER!r}"
    )
    return tok


# ---------------------------------------------------------------------------
# /models
# ---------------------------------------------------------------------------


def test_models_lists_agents(openai_base: str, bearer: str | None) -> None:
    """``GET /models`` enumerates the agents the gateway has mounted —
    at minimum the scaffolded ``main`` agent must appear with the
    ``rtxclaw/`` prefix."""
    r = httpx.get(f"{openai_base}/models", headers=_auth_headers(bearer), timeout=10.0)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["object"] == "list"
    ids = [m["id"] for m in body["data"]]
    assert "rtxclaw/main" in ids
    assert all(m["owned_by"] == "rtxclaw" for m in body["data"])
    assert all(m["object"] == "model" for m in body["data"])


def test_model_get_single_agent_prefixed(
    openai_base: str, bearer: str | None,
) -> None:
    r = httpx.get(
        f"{openai_base}/models/rtxclaw/main",
        headers=_auth_headers(bearer), timeout=10.0,
    )
    assert r.status_code == 200
    assert r.json()["id"] == "rtxclaw/main"


def test_model_get_single_agent_bare_compat(
    openai_base: str, bearer: str | None,
) -> None:
    """Bare ``<agent>`` (no ``rtxclaw/`` prefix) still resolves — OpenAI
    clients that hardcode model names without the prefix don't break."""
    r = httpx.get(
        f"{openai_base}/models/main",
        headers=_auth_headers(bearer), timeout=10.0,
    )
    assert r.status_code == 200
    assert r.json()["id"] == "rtxclaw/main"


def test_model_get_unknown_404(openai_base: str, bearer: str | None) -> None:
    r = httpx.get(
        f"{openai_base}/models/ghost",
        headers=_auth_headers(bearer), timeout=10.0,
    )
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# /chat/completions — non-streaming (real upstream LLM)
# ---------------------------------------------------------------------------


def test_chat_completions_non_streaming(
    openai_base: str, bearer: str | None,
) -> None:
    """One real chat-completions call: response body has the OpenAI
    shape, references the requested agent, finishes with a recognised
    reason, and produces non-empty assistant content."""
    r = httpx.post(
        f"{openai_base}/chat/completions",
        json={
            "model": "rtxclaw/main",
            "messages": [{"role": "user", "content": "Reply with the word 'pong' and nothing else."}],
        },
        headers=_auth_headers(bearer),
        timeout=120.0,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["object"] == "chat.completion"
    assert body["model"] == "rtxclaw/main"
    choice = body["choices"][0]
    assert choice["message"]["role"] == "assistant"
    assert isinstance(choice["message"]["content"], str)
    assert choice["message"]["content"].strip(), "empty assistant content"
    assert choice["finish_reason"] in ("stop", "length", "tool_calls")


def test_chat_completions_accepts_bare_model_for_compat(
    openai_base: str, bearer: str | None,
) -> None:
    """Bare ``main`` (no ``rtxclaw/`` prefix) still routes to the same
    agent and the response surfaces the public prefixed id."""
    r = httpx.post(
        f"{openai_base}/chat/completions",
        json={
            "model": "main",
            "messages": [{"role": "user", "content": "Say 'ok'."}],
        },
        headers=_auth_headers(bearer),
        timeout=120.0,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["model"] == "rtxclaw/main"


def test_chat_completions_history_serialised_for_agent(
    openai_base: str, bearer: str | None, sandbox_home: Path,
) -> None:
    """A multi-turn ``messages=[…]`` array must reach the agent as a
    structured prompt — system/user/assistant blocks preserved, not
    just the last user message. Verified by reading the on-disk
    session JSON the gateway wrote during the turn (no introspection
    fakes)."""
    r = httpx.post(
        f"{openai_base}/chat/completions",
        json={
            "model": "rtxclaw/main",
            "messages": [
                {"role": "system",    "content": "You answer in one digit."},
                {"role": "user",      "content": "What is 1+1?"},
                {"role": "assistant", "content": "2"},
                {"role": "user",      "content": "What is 2+2?"},
            ],
        },
        headers=_auth_headers(bearer),
        timeout=120.0,
    )
    assert r.status_code == 200, r.text

    # Find the most-recent session file for agent main and inspect the
    # last turn's ``user`` field — that's exactly what the openai
    # endpoint flattened the messages array into before handing it to
    # the agent.
    sessions_dir = sandbox_home / "agents" / "main" / "sessions"
    sessions = [
        p for p in sessions_dir.glob("*.json")
        if "." not in p.stem and "todos" not in p.name
    ]
    assert sessions, "no session files found"
    latest = max(sessions, key=lambda p: p.stat().st_mtime)
    sess = json.loads(latest.read_text(encoding="utf-8"))
    turns = sess.get("turns") or []
    assert turns, f"session {latest.name} has no turns"
    sent_text = turns[-1].get("user") or ""
    assert "[Caller-supplied system context]" in sent_text
    assert "You answer in one digit." in sent_text
    assert "[Prior conversation]" in sent_text
    assert "USER: What is 1+1?" in sent_text
    assert "ASSISTANT: 2" in sent_text
    assert "[Current message from user]" in sent_text
    assert "What is 2+2?" in sent_text


def test_chat_completions_unknown_model_404(
    openai_base: str, bearer: str | None,
) -> None:
    r = httpx.post(
        f"{openai_base}/chat/completions",
        json={"model": "ghost", "messages": [{"role": "user", "content": "hi"}]},
        headers=_auth_headers(bearer),
        timeout=10.0,
    )
    assert r.status_code == 404
    assert r.json()["error"]["code"] == "model_not_found"


def test_chat_completions_missing_messages_400(
    openai_base: str, bearer: str | None,
) -> None:
    r = httpx.post(
        f"{openai_base}/chat/completions",
        json={"model": "rtxclaw/main"},
        headers=_auth_headers(bearer),
        timeout=10.0,
    )
    assert r.status_code == 400


# ---------------------------------------------------------------------------
# /chat/completions — streaming (real upstream LLM)
# ---------------------------------------------------------------------------


def test_chat_completions_streaming_strict_sse_framing(
    openai_base: str, bearer: str | None,
) -> None:
    """``stream=true`` returns text/event-stream with strict
    ``data: {…}\\n\\n`` framing terminated by ``data: [DONE]``. First
    frame is a role-only delta, last frame carries finish_reason."""
    with httpx.stream(
        "POST",
        f"{openai_base}/chat/completions",
        json={
            "model": "rtxclaw/main",
            "messages": [{"role": "user", "content": "Count: one, two, three."}],
            "stream": True,
        },
        headers=_auth_headers(bearer),
        timeout=120.0,
    ) as r:
        assert r.status_code == 200, r.read()
        assert r.headers["content-type"].startswith("text/event-stream")
        body = r.read().decode("utf-8")

    frames = [
        line[len("data: "):]
        for line in body.split("\n\n")
        if line.startswith("data: ") and line != "data: [DONE]"
    ]
    assert frames, f"no SSE data frames: {body!r}"
    parsed = [json.loads(f) for f in frames]

    # First frame: role-only delta (OpenAI SSE convention).
    assert parsed[0]["choices"][0]["delta"] == {"role": "assistant"}

    # At least one content delta in the middle.
    middle_content = "".join(
        p["choices"][0]["delta"].get("content", "") or ""
        for p in parsed[1:-1]
    )
    assert middle_content.strip(), f"no content deltas in middle: {parsed!r}"

    # Final frame: empty delta + finish_reason set.
    assert parsed[-1]["choices"][0]["delta"] == {}
    assert parsed[-1]["choices"][0]["finish_reason"] in (
        "stop", "length", "tool_calls",
    )

    # Stream terminator.
    assert body.rstrip().endswith("data: [DONE]")


# ---------------------------------------------------------------------------
# auth — bearer enforcement is gateway-wide; covered by the real gateway
# only when ``gateway.auth_token`` is set in config.json.
# ---------------------------------------------------------------------------


def test_bearer_required_when_configured(
    openai_base: str, bearer: str,
) -> None:
    """The gateway runs with ``auth_token`` configured (set by the
    ``gateway_with_bearer`` fixture). Verify the real production
    auth code rejects missing / wrong tokens and accepts the right
    one. No skip path."""
    # Missing header → 401.
    r = httpx.get(f"{openai_base}/models", timeout=10.0)
    assert r.status_code == 401

    # Wrong token → 401.
    r = httpx.get(
        f"{openai_base}/models",
        headers={"Authorization": "Bearer wrong"},
        timeout=10.0,
    )
    assert r.status_code == 401

    # Right token → 200.
    r = httpx.get(
        f"{openai_base}/models",
        headers=_auth_headers(bearer),
        timeout=10.0,
    )
    assert r.status_code == 200


# ---------------------------------------------------------------------------
# stub endpoints
# ---------------------------------------------------------------------------


def test_responses_stub_404(openai_base: str, bearer: str | None) -> None:
    r = httpx.post(
        f"{openai_base}/responses",
        json={"model": "main"},
        headers=_auth_headers(bearer),
        timeout=10.0,
    )
    assert r.status_code == 404


def test_slots_stub_empty_list(openai_base: str, bearer: str | None) -> None:
    r = httpx.get(
        f"{openai_base}/slots",
        headers=_auth_headers(bearer),
        timeout=10.0,
    )
    assert r.status_code == 200
    assert r.json() == []


# ---------------------------------------------------------------------------
# /audio/* + /embeddings — real upstream OpenRouter calls
# ---------------------------------------------------------------------------


def _generate_mp3(text: str, out: Path) -> None:
    """Render `text` as a real MP3 via gTTS. Same helper pattern the
    telegram voice tests use — guarantees the upstream STT receives a
    valid MP3 (OpenRouter rejects empty/OGG payloads with HTTP 400)."""
    from gtts import gTTS  # type: ignore[import-not-found]
    gTTS(text, lang="en").save(str(out))


def test_audio_transcriptions_real_round_trip(
    openai_base: str, bearer: str, tmp_path: Path,
) -> None:
    """Generate a real MP3, POST to /audio/transcriptions, expect
    OpenRouter STT to return a 200 with a non-empty ``text`` field
    that contains a recognisable substring of the spoken phrase."""
    mp3 = tmp_path / "rtxclaw-test-stt.mp3"
    _generate_mp3("hello rtxclaw test", mp3)
    with mp3.open("rb") as fh:
        r = httpx.post(
            f"{openai_base}/audio/transcriptions",
            files={"file": ("stt.mp3", fh, "audio/mpeg")},
            data={"model": "openai/gpt-4o-transcribe"},
            headers=_auth_headers(bearer),
            timeout=120.0,
        )
    assert r.status_code == 200, r.text
    body = r.json()
    assert isinstance(body.get("text"), str)
    txt = body["text"].lower()
    # STT can mishear; we don't pin the whole phrase, just check the
    # response is non-trivial and roughly relevant.
    assert any(tok in txt for tok in ("hello", "rtx", "test")), (
        f"transcribed text {txt!r} doesn't match expected tokens"
    )


def test_audio_speech_real_round_trip(
    openai_base: str, bearer: str,
) -> None:
    """POST a short prompt to /audio/speech, expect OpenRouter TTS to
    return a non-empty audio payload with an audio/* content-type."""
    r = httpx.post(
        f"{openai_base}/audio/speech",
        json={
            "model": "openai/gpt-4o-mini-tts-2025-12-15",
            "voice": "alloy",
            "input": "hi",
        },
        headers=_auth_headers(bearer),
        timeout=120.0,
    )
    assert r.status_code == 200, r.text
    ctype = r.headers.get("content-type", "")
    assert ctype.startswith("audio/") or "octet-stream" in ctype, ctype
    body = r.content
    assert len(body) > 200, (
        f"TTS returned suspiciously small payload ({len(body)} bytes)"
    )


def test_embeddings_returns_or_501(
    openai_base: str, bearer: str,
) -> None:
    """``/embeddings`` 200s when an embedder is resolved on the host,
    or 501 with a clear message when none is configured. Either is
    correct — what's NOT correct is 500 or a hang."""
    r = httpx.post(
        f"{openai_base}/embeddings",
        json={"model": "rtxclaw-default", "input": "hello"},
        headers=_auth_headers(bearer),
        timeout=60.0,
    )
    assert r.status_code in (200, 501), r.text
    if r.status_code == 200:
        body = r.json()
        assert body.get("object") == "list"
        assert body["data"][0]["embedding"], "empty embedding vector"
