"""Regression: the post-stream chars/token ratio guard must NOT kill
legitimate thinking-mode turns.

Pre-fix_20260513b the ``ratio_floor`` was 1.5 chars/completion-token and
the guard fired regardless of ``finish_reason``. Empirically (gateway
log entries from sid=6a049b18e4a4 on 2026-05-13) this killed:

* Qwen3.6-27B-fp8 turns with ``completion_tokens=825,
  chars_per_token=1.079, finish_reason=tool_calls`` — the model emitted
  a long ``<think>`` block of compact reasoning tokens, then chose to
  call a tool. Upstream sent a clean ``tool_calls`` finish; the guard
  flagged it as a runaway loop anyway.
* Same shape on deepseek-v4-flash.

Fix:
1. Lower the default ratio floor 1.5 → 0.5. Real collapses we have
   evidence for (gemma-4 NVFP4 mtp) sit at 0.03-0.43 chars/token;
   legitimate Qwen/Deepseek thinking-mode reasoning sits at 1.0-1.2.
2. Skip the guard entirely when ``finish_reason in {"stop",
   "tool_calls"}``. A clean upstream termination means the model
   intentionally ended the round — high reasoning-to-content ratio
   reflects dense thinking, not a loop.

This test pins both surfaces: the worker's pre-classification
predicate and the engine's ``_check_ratio_loop`` backstop.
"""
from __future__ import annotations

from rtxclaw_core.agents.local_llm import (
    LOOP_CHARS_PER_TOKEN_MIN,
    LOOP_RATIO_MIN_TOKENS,
)


def _ratio_metrics(
    *,
    completion_tokens: int,
    chars: int,
    finish_reason: str | None,
    tokens_estimated: bool = False,
) -> dict[str, object]:
    """Build a metrics dict in the shape the worker emits."""
    return {
        "completion_tokens": completion_tokens,
        "completion_chars": chars,
        "chars_per_token": (
            round(chars / max(1, completion_tokens), 3)
            if not tokens_estimated else None
        ),
        "finish_reason": finish_reason,
        "tokens_estimated": tokens_estimated,
        "token_loop_suspected": False,  # backstop case (worker didn't set it)
    }


def test_ratio_floor_default_is_0_5() -> None:
    """Sanity: the constant moved 1.5 → 0.5."""
    assert LOOP_CHARS_PER_TOKEN_MIN == 0.5, (
        f"expected 0.5, got {LOOP_CHARS_PER_TOKEN_MIN}"
    )


def test_ratio_min_tokens_unchanged() -> None:
    """We did NOT change the min-tokens threshold; only the floor moved."""
    assert LOOP_RATIO_MIN_TOKENS == 500


def test_check_ratio_loop_skips_clean_tool_calls_finish() -> None:
    """The exact false-positive shape observed in gateway log:
    Qwen3.6 thinking-mode round, 825 completion tokens, 890 emitted chars
    (745 reasoning + 145 content), finish_reason="tool_calls". The
    backstop must NOT flag this as a loop."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    # Stub cfg so the floor lookup falls back to LOOP_CHARS_PER_TOKEN_MIN.
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()

    m = _ratio_metrics(
        completion_tokens=825,
        chars=890,  # ~1.079 chars/token
        finish_reason="tool_calls",
    )
    assert eng._check_ratio_loop(m) is None, (
        "_check_ratio_loop flagged a clean tool_calls round as a loop"
    )


def test_check_ratio_loop_skips_clean_stop_finish() -> None:
    """Same shape, different upstream signal (``stop``). Also must not
    flag — clean end-of-turn means the model chose to stop, not loop."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()
    m = _ratio_metrics(
        completion_tokens=600,
        chars=641,  # ~1.068 chars/token
        finish_reason="stop",
    )
    assert eng._check_ratio_loop(m) is None


def test_check_ratio_loop_still_catches_real_collapse() -> None:
    """The genuine token-collapse signature (gemma-4 NVFP4 mtp pattern):
    4634 completion tokens, 148 emitted chars, finish_reason="length".
    Ratio is 0.032 — well below the 0.5 floor — and finish_reason isn't
    a clean signal. Guard MUST still fire."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()
    m = _ratio_metrics(
        completion_tokens=4634,
        chars=148,  # ~0.032 chars/token
        finish_reason="length",
    )
    hit = eng._check_ratio_loop(m)
    assert hit is not None, "real collapse was missed"
    tier, evidence = hit
    assert tier == "ratio"
    assert "chars_per_token=" in evidence


def test_check_ratio_loop_still_catches_collapse_with_unknown_finish() -> None:
    """``finish_reason=None`` (upstream didn't say) is NOT a clean signal
    — keep the guard armed."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()
    m = _ratio_metrics(
        completion_tokens=600,
        chars=180,  # 0.3 chars/token — below floor
        finish_reason=None,
    )
    assert eng._check_ratio_loop(m) is not None


def test_check_ratio_loop_respects_token_floor() -> None:
    """Short turns (below LOOP_RATIO_MIN_TOKENS) are always exempt,
    even at degenerate ratios — too small a sample."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()
    m = _ratio_metrics(
        completion_tokens=200,  # < 500
        chars=10,                # 0.05 chars/token
        finish_reason="length",
    )
    assert eng._check_ratio_loop(m) is None


def test_check_ratio_loop_surfaces_worker_preclassification() -> None:
    """When the worker already set ``token_loop_suspected=True``, the
    backstop surfaces it as a ratio hit (regardless of finish_reason)."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine

    eng = LocalLLMEngine.__new__(LocalLLMEngine)
    eng.cfg = type("Cfg", (), {"loop_chars_per_token_min": 0})()
    m = _ratio_metrics(
        completion_tokens=4634,
        chars=148,
        finish_reason="length",
    )
    m["token_loop_suspected"] = True
    hit = eng._check_ratio_loop(m)
    assert hit is not None
    assert hit[0] == "ratio"
