"""Step 16 — ACP route conformance suite (stdio + HTTP).

Per operator request: "create a test agent on the test environment
that's just a copy of the main agent and test all the acp routes
between them with stdio and http."

Coverage:
- ``initialize`` round-trip on both transports → returns
  ``protocolVersion``, ``agentCapabilities``, ``agentInfo``.
- Capabilities advertised by the agent match what the server actually
  accepts (regression net for the audit-found ``promptCapabilities.image``
  drift).
- ``session/new`` → returns a non-empty sessionId; ``modes`` is a
  valid SessionModeState (availableModes + currentModeId).
- ``session/list`` returns a paginated dict with ``sessions``.
- ``session/set_mode("plan")`` succeeds and triggers a wire-level
  ``current_mode_update`` notification.
- ``session/close`` succeeds.
- ``session/cancel`` against a non-existent session returns cleanly
  (not an internal error — cancel is fire-and-forget).

Tests skip cleanly if the running daemon (HTTP) isn't reachable —
only the stdio path is mandatory because it doesn't depend on a
listener already being bound.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Optional

import pytest

from conftest import RTXCLAW_BIN
from rtxclaw_acp.client import spawn_stdio_agent, connect_http



# Slow tier: every test here drives running_daemon / scaffolded_agent.
# Excluded from pre-commit tier-1 via -m "not slow".
pytestmark = pytest.mark.slow

# ---- helpers --------------------------------------------------------


def _python_path_with_src() -> str:
    repo = Path(RTXCLAW_BIN).parent
    src = str(repo / "src")
    existing = os.environ.get("PYTHONPATH", "")
    return src + (os.pathsep + existing if existing else "")


@pytest.fixture
def stdio_agent_env(
    sandbox_env: dict[str, str], scaffolded_test_agent: Path,
):
    """Env block to spawn ``rtxclaw_agent.acp_stdio_main`` against the
    cloned test_agent home."""
    env = dict(sandbox_env)
    env["PYTHONPATH"] = _python_path_with_src()
    env["RTXCLAW_AGENT_NAME"] = "test_agent"
    env["RTXCLAW_AGENT_HOME"] = str(scaffolded_test_agent)
    return env


@pytest.fixture
def stdio_agent_cmd(stdio_agent_env, bootstrapped_venv: Path):
    """Argv list invoking the agent via the test venv's interpreter.

    Uses the canonical ``rtxclaw_agent acp-stdio <name>`` entry point
    (``cli._cmd_acp_stdio``) — ``rtxclaw_agent.acp_stdio_main`` is
    just the module that defines ``serve_acp_stdio``; running it
    with ``python -m`` does not invoke the server (no
    ``__main__`` block).
    """
    py = bootstrapped_venv / "bin" / "python"
    return [str(py), "-m", "rtxclaw_agent", "acp-stdio", "test_agent"]


# ---- stdio coverage ------------------------------------------------


def test_stdio_initialize_round_trip(
    stdio_agent_cmd: list[str], stdio_agent_env,
) -> None:
    async def run() -> dict[str, Any]:
        client, proc = await spawn_stdio_agent(
            stdio_agent_cmd, env=stdio_agent_env,
        )
        try:
            resp = await client.initialize()
            return {
                "protocolVersion": resp.protocol_version,
                "agentInfo": getattr(resp, "agent_info", None),
                "capabilities": resp.agent_capabilities.model_dump(
                    by_alias=True,
                ) if hasattr(resp.agent_capabilities, "model_dump")
                else dict(resp.agent_capabilities),
            }
        finally:
            await client.close()
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()

    out = asyncio.run(run())
    assert out["protocolVersion"], "no protocolVersion echoed"
    caps = out["capabilities"]
    # Spec compliance: image lie was the audit's HIGH finding. Either
    # the agent advertises image=true AND accepts image blocks, or it
    # advertises image=false. Both are legal; advertising true while
    # rejecting image blocks is NOT.
    prompt_caps = (caps.get("promptCapabilities") or {})
    image_advertised = bool(prompt_caps.get("image", False))
    if image_advertised:
        # Would need a separate prompt with an image block to verify
        # acceptance — guard against silent regressions by failing
        # loudly instead of silently when the SUPPORTED set drifts.
        from rtxclaw_acp.server.server import _SUPPORTED_CONTENT_BLOCK_TYPES
        assert "image" in _SUPPORTED_CONTENT_BLOCK_TYPES, (
            "agent advertises promptCapabilities.image=true but the "
            "dispatcher rejects 'image' content blocks — capability lie."
        )


def test_stdio_session_new_returns_modes_state(
    stdio_agent_cmd: list[str], stdio_agent_env,
) -> None:
    """Spec compliance audit (HIGH): NewSessionResponse must include a
    populated SessionModeState. The high-level ``client.session_new``
    extracts ``session_id`` and discards the rest, so we drop to the
    raw JSON-RPC path here to inspect ``modes``."""
    async def run() -> dict[str, Any]:
        client, proc = await spawn_stdio_agent(
            stdio_agent_cmd, env=stdio_agent_env,
        )
        try:
            await client.initialize()
            params = {
                "cwd": stdio_agent_env["RTXCLAW_AGENT_HOME"],
                "mcpServers": [],
            }
            raw_result = await client._call("session/new", params)  # noqa: SLF001
            return raw_result
        finally:
            await client.close()
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()

    out = asyncio.run(run())
    sid = out.get("sessionId")
    assert isinstance(sid, str) and sid, (
        f"session/new returned bogus sessionId: {out!r}"
    )
    modes = out.get("modes")
    assert modes is not None, (
        "session/new returned modes=None — clients can't drive set_mode"
    )
    assert "availableModes" in modes, modes
    assert "currentModeId" in modes, modes
    avail_ids = [m["id"] for m in modes["availableModes"]]
    assert {"auto", "ask", "plan"}.issubset(set(avail_ids)), avail_ids


def test_stdio_full_lifecycle(
    stdio_agent_cmd: list[str], stdio_agent_env,
) -> None:
    """Initialize → session/new → session/list → set_mode → close.

    No prompt round-trip (that needs the upstream LLM and would belong
    in test_10/test_11). This just smokes the JSON-RPC plumbing.
    """
    async def run() -> dict[str, Any]:
        client, proc = await spawn_stdio_agent(
            stdio_agent_cmd, env=stdio_agent_env,
        )
        try:
            await client.initialize()
            sid = await client.session_new(
                cwd=stdio_agent_env["RTXCLAW_AGENT_HOME"],
            )
            list_resp = await client.session_list()
            sids = [
                getattr(s, "session_id", None) for s in (list_resp.sessions or [])
            ]
            await client.session_set_mode(sid, "plan")
            await client.session_close(sid)
            return {
                "sid": sid,
                "list_includes_sid": sid in sids,
                "list_count": len(sids),
            }
        finally:
            await client.close()
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()

    out = asyncio.run(run())
    assert out["sid"], out
    # session/list may legitimately not include the just-created session
    # (the bridge filters zero-turn sessions in production), but the
    # call must succeed and return a list.
    assert isinstance(out["list_count"], int)


def test_stdio_cancel_no_in_flight_does_not_raise(
    stdio_agent_cmd: list[str], stdio_agent_env,
) -> None:
    """``session/cancel`` is a notification — sending it for a session
    with nothing in flight must not produce an error response."""
    async def run() -> None:
        client, proc = await spawn_stdio_agent(
            stdio_agent_cmd, env=stdio_agent_env,
        )
        try:
            await client.initialize()
            sid = await client.session_new(
                cwd=stdio_agent_env["RTXCLAW_AGENT_HOME"],
            )
            await client.session_cancel(sid)
        finally:
            await client.close()
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()

    asyncio.run(run())


# ---- HTTP coverage --------------------------------------------------


def _http_endpoint(sandbox_home: Path) -> str:
    """Return ``http://host:port`` of the running test gateway.

    ``RTXCLAW_TEST_ACP_HTTP`` overrides explicitly; otherwise we read
    ``gateway.host`` / ``gateway.port`` from the sandbox's
    ``config.json`` — the same values the ``scaffolded_agent`` fixture
    wrote when it pinned the gateway to a worker-isolated port
    (default 27700+worker_idx; NOT 7700 which is the production
    gateway). Pre-fix this used a literal ``127.0.0.1:7700`` fallback
    which collided with prod or, in CI, hit a closed port and surfaced
    as a flat ``httpx.ConnectError``.
    """
    override = os.environ.get("RTXCLAW_TEST_ACP_HTTP")
    if override:
        return override
    cfg_path = sandbox_home / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        cfg = {}
    gw = cfg.get("gateway") or {}
    host = gw.get("host") or "127.0.0.1"
    port = int(gw.get("port") or 27700)
    return f"http://{host}:{port}"


@pytest.fixture
def http_base_url(running_daemon: Path, sandbox_home: Path) -> str:  # noqa: ARG001
    """The HTTP base URL for agent ``main`` on the running gateway.

    The single-process gateway mounts each agent under
    ``/acp/<name>``; ``connect_http`` then appends ``/acp`` for the
    JSON-RPC route. So the per-agent base URL the client passes is
    ``http://<gateway-host>:<port>/acp/<agent>``.
    """
    return f"{_http_endpoint(sandbox_home).rstrip('/')}/acp/main"


def _bearer_token(sandbox_home: Path) -> Optional[str]:
    """Read ``gateway.auth_token`` from sandbox config so this test
    works whether the gateway was started bearer-less or with a token
    (e.g. when test_50 ran earlier in the session and persisted one)."""
    cfg_path = sandbox_home / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return (cfg.get("gateway") or {}).get("auth_token") or None


def test_http_initialize_round_trip(
    http_base_url: str, sandbox_home: Path,
) -> None:
    bearer = _bearer_token(sandbox_home)

    async def run() -> str:
        client = await connect_http(http_base_url, bearer_token=bearer)
        try:
            return str(getattr(client, "negotiated_protocol_version", "") or "")
        finally:
            await client.close()

    import httpx as _httpx
    try:
        pv = asyncio.run(run())
    except (ConnectionError, OSError, _httpx.HTTPError) as exc:
        pytest.fail(f"HTTP daemon not reachable at {http_base_url}: {exc}")
    assert pv, "HTTP initialize returned no protocol version"


def test_http_session_lifecycle(
    http_base_url: str, sandbox_home: Path,
) -> None:
    bearer = _bearer_token(sandbox_home)

    async def run() -> dict[str, Any]:
        client = await connect_http(http_base_url, bearer_token=bearer)
        try:
            sid = await client.session_new(cwd="/tmp")
            await client.session_set_mode(sid, "auto")
            await client.session_close(sid)
            return {"sid": sid}
        finally:
            await client.close()

    import httpx as _httpx
    try:
        out = asyncio.run(run())
    except (ConnectionError, OSError, _httpx.HTTPError) as exc:
        pytest.fail(f"HTTP daemon not reachable at {http_base_url}: {exc}")
    assert out["sid"]
