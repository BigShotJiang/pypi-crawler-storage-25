import pytest
from rtxclaw_telegram.bot import AcpTelegramBot, TG_GETFILE_MAX_BYTES, TG_LOCAL_MAX_BYTES
from rtxclaw_telegram.config import TelegramConfig

class _FakeAPI:
    def __init__(self, local): self.sends=[]; self.local_mode=local
    async def send_message(self, cid, text, *, message_thread_id=None, parse_mode=None):
        self.sends.append(text); return 1
    async def call(self, m, **k): return {"ok": True, "result": {}}

@pytest.fixture
def home(tmp_path, monkeypatch): monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path)); return tmp_path

def _bot(api, monkeypatch):
    b = AcpTelegramBot(TelegramConfig(default_agent="main"), acp_url="",
                       trusted_chats=set(), api=api, stt=lambda *a, **k: "",
                       download_audio=lambda *a, **k: None)
    monkeypatch.setattr(b, "_is_authorized", lambda c: True)
    monkeypatch.setattr(b, "_user_allowed", lambda s: True)
    streamed=[]
    async def spy(*a, **k): streamed.append(k)
    monkeypatch.setattr(b, "_stream_turn_for_chat", spy)
    return b, streamed

def _audio_update(size):
    return {"update_id": 1, "message": {"message_id": 1,
        "chat": {"id": 1, "type": "private"}, "from": {"id": 1, "is_bot": False},
        "audio": {"file_id": "F", "mime_type": "audio/mp4", "file_size": size}}}

@pytest.mark.asyncio
async def test_local_mode_allows_over_20mb(home, monkeypatch):
    api = _FakeAPI(local=True); bot, streamed = _bot(api, monkeypatch)
    await bot._handle_update(_audio_update(TG_GETFILE_MAX_BYTES + 50*1024*1024))
    assert len(streamed) == 1, "70MB should dispatch in local mode"

@pytest.mark.asyncio
async def test_local_mode_rejects_over_2gb(home, monkeypatch):
    api = _FakeAPI(local=True); bot, streamed = _bot(api, monkeypatch)
    await bot._handle_update(_audio_update(TG_LOCAL_MAX_BYTES + 1))
    assert streamed == [] and any("too" in s.lower() or "GB" in s for s in api.sends)

@pytest.mark.asyncio
async def test_cloud_mode_still_rejects_over_20mb(home, monkeypatch):
    api = _FakeAPI(local=False); bot, streamed = _bot(api, monkeypatch)
    await bot._handle_update(_audio_update(TG_GETFILE_MAX_BYTES + 5*1024*1024))
    assert streamed == [] and any("20 MB" in s for s in api.sends)
