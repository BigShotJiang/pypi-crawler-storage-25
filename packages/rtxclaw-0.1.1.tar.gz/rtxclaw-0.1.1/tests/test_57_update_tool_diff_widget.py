"""Step 57 — the ``Update`` tool + TUI code-diff widget.

New feature: a file-edit tool named ``Update`` (matching the label
Claude Code shows for file edits) whose calls render in the rtxclaw
TUI as a colored code-diff card — red removals / green additions —
so the operator sees exactly what changed.

The contract this pins:

* ``Update`` is a registered, **core** tool with Claude Code's
  ``file_path / old_string / new_string / replace_all`` shape.
* ``run_update_file`` applies the edit (same semantics as ``Edit``)
  and returns a **one-line summary** — never the diff itself. That
  is the load-bearing guarantee that the Telegram frontend shows no
  code diff: Telegram only ever echoes this summary, never the tool
  arguments, so the diff is structurally TUI-only.
* The TUI ``UpdateMessage`` widget computes the unified diff
  *client-side* from the call's arguments and renders it with +/-
  coloring; ``mark_result`` stamps it ✓/✗ when the tool finishes.
* ACP tool-kind classification treats ``Update`` as an ``edit`` tool.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# `tests/conftest.py` adds src/ to sys.path; mirror that defensively for
# pytest-direct invocations that bypass conftest.
_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.tools import BUILTIN_TOOLS, ToolRegistry  # noqa: E402
from rtxclaw_core.tools.runners import (  # noqa: E402
    _SYNC_RUNNERS,
    run_update_file,
)


# ---- registry -------------------------------------------------------


def test_update_tool_is_registered_and_core() -> None:
    """``Update`` must be a core tool — the model sees it without a
    ToolSearch hop, same as ``Edit``/``Write``."""
    tool = next((t for t in BUILTIN_TOOLS if t.name == "Update"), None)
    assert tool is not None, "Update missing from BUILTIN_TOOLS"
    assert tool.core is True, "Update must be a core tool"
    reg = ToolRegistry(BUILTIN_TOOLS)
    core_names = {t.name for t in reg.core_tools()}
    assert "Update" in core_names


def test_update_tool_has_claude_code_edit_schema() -> None:
    """Same parameter shape as Claude Code's edit tool."""
    tool = next(t for t in BUILTIN_TOOLS if t.name == "Update")
    props = tool.parameters["properties"]
    assert "file_path" in props
    assert "old_string" in props
    assert "new_string" in props
    assert "replace_all" in props
    required = tool.parameters["required"]
    assert {"file_path", "old_string", "new_string"}.issubset(set(required))


def test_update_tool_has_a_runner() -> None:
    assert _SYNC_RUNNERS.get("Update") is run_update_file


# ---- runner ---------------------------------------------------------


def test_run_update_file_applies_the_edit(tmp_path: Path) -> None:
    p = tmp_path / "f.py"
    p.write_text("a = 1\nb = 2\nc = 3\n")
    res = run_update_file(
        {"file_path": str(p), "old_string": "b = 2", "new_string": "b = 99"}
    )
    assert res.ok
    assert p.read_text() == "a = 1\nb = 99\nc = 3\n"


def test_run_update_file_returns_one_line_summary_not_a_diff(tmp_path: Path) -> None:
    """The result the MODEL (and Telegram) sees is a terse summary —
    never the diff. This is what keeps the code diff TUI-only: the
    Telegram frontend echoes this content, never the arguments."""
    p = tmp_path / "f.txt"
    p.write_text("hello world\n")
    res = run_update_file(
        {
            "file_path": str(p),
            "old_string": "hello world",
            "new_string": "goodbye world",
        }
    )
    assert res.ok
    # One line, starts with "updated", and carries no diff markers.
    assert "\n" not in res.content.strip()
    assert res.content.startswith("updated ")
    assert "@@" not in res.content
    assert not res.content.lstrip().startswith(("+", "-"))


def test_run_update_file_reports_failure_cleanly(tmp_path: Path) -> None:
    p = tmp_path / "f.txt"
    p.write_text("hello world\n")
    res = run_update_file(
        {"file_path": str(p), "old_string": "NOT THERE", "new_string": "x"}
    )
    assert not res.ok
    assert "not found" in res.content
    # File untouched on failure.
    assert p.read_text() == "hello world\n"


# ---- TUI widget -----------------------------------------------------


def test_update_message_renders_colored_unified_diff() -> None:
    from rtxclaw_tui.app import UpdateMessage

    card = UpdateMessage(
        "/tmp/foo.py",
        "a = 1\nb = 2\n",
        "a = 1\nb = 99\nc = 3\n",
        replace_all=False,
        call_id="call_1",
    )
    diff = card._diff_text()
    plain = diff.plain
    # Unified-diff body: hunk header + removed + added lines.
    assert "@@" in plain
    assert "-b = 2" in plain
    assert "+b = 99" in plain
    assert "+c = 3" in plain
    # The empty-name `--- ` / `+++ ` file headers are stripped (the
    # card's own header already names the file).
    assert "--- " not in plain
    assert "+++ " not in plain
    # +/- lines are actually styled (not plain text).
    styles = {str(span.style) for span in diff.spans}
    assert any("green" in s for s in styles)
    assert any("red" in s for s in styles)


def test_update_message_header_matches_claude_code_naming() -> None:
    from rtxclaw_tui.app import UpdateMessage

    card = UpdateMessage("/tmp/foo.py", "x", "y", call_id="c1")
    # In-flight marker, "Update(<path>)" — Claude Code's label.
    assert card._build_header() == "✎ Update(/tmp/foo.py)"
    card.mark_result(True)
    assert card._build_header() == "✓ Update(/tmp/foo.py)"
    card.mark_result(False)
    assert card._build_header() == "✗ Update(/tmp/foo.py)"


def test_update_message_flags_replace_all() -> None:
    from rtxclaw_tui.app import UpdateMessage

    card = UpdateMessage("/tmp/foo.py", "x", "y", replace_all=True)
    assert "(replace all)" in card._build_header()


def test_update_message_trims_huge_diffs() -> None:
    from rtxclaw_tui.app import UpdateMessage

    old = "\n".join(f"line {i}" for i in range(1000))
    new = "\n".join(f"changed {i}" for i in range(1000))
    card = UpdateMessage("/tmp/big.py", old, new)
    plain = card._diff_text().plain
    # Capped so a giant edit can't flood the transcript.
    assert "more diff line(s) trimmed" in plain
    assert plain.count("\n") <= UpdateMessage.MAX_DIFF_LINES + 1


# ---- ACP classification --------------------------------------------


def test_acp_classifies_update_as_an_edit_tool() -> None:
    from rtxclaw_core.agents.acp_translation import acp_kind_for_tool

    # `Update` must classify the same as `Edit`/`Write` so ACP
    # frontends treat it as a file-modification tool.
    assert acp_kind_for_tool("Edit") == "edit"
    assert acp_kind_for_tool("Update") == "edit"
