"""Step 37 — Telegram image dispatch + in-flight cleanup on bad payload.

Two-part regression for the image-from-Telegram crash observed
2026-05-08 in `agents/main/telegram/logs/telegram.log`:

1. The bot wrapped Telegram photos in ``acp.schema.ImageContent``,
   but ``PromptRequest.prompt`` is a discriminated union over the
   ``*Block`` variants. Pydantic rejected the payload with five
   "Input should be a valid dictionary or instance of …Block" errors
   and the user saw ``⚠️ agent error — see telegram.log``.

2. Because ``_iter_prompt`` registered the session in
   ``_prompt_streams`` BEFORE the offending ``PromptRequest`` was
   built, the validation failure left the session marked "in flight"
   forever. Every subsequent prompt on that session — even after the
   user issued ``/new`` and tried to send text — was rejected with
   ``a session/prompt is already in flight``, so the chat looked
   permanently wedged.

These tests pin both contracts so a future SDK bump or refactor
can't silently regress.
"""
from __future__ import annotations

import asyncio

import pytest

import acp.schema as _acp
from rtxclaw_acp.client.client import AcpClient
from rtxclaw_acp.protocol.transport import Transport


# ---- (1) ImageContentBlock is what PromptRequest accepts ----------


def test_image_content_block_passes_prompt_validation() -> None:
    """The fix replaces ``ImageContent`` with ``ImageContentBlock``;
    confirm the *Block* variant is what ``PromptRequest`` actually
    expects, so the bot's dispatch path won't raise mid-handler."""
    req = _acp.PromptRequest(
        session_id="sid",
        prompt=[
            _acp.TextContentBlock(type="text", text="caption"),
            _acp.ImageContentBlock(
                type="image",
                data="aGVsbG8=",  # b64('hello')
                mime_type="image/jpeg",
            ),
        ],
    )
    assert isinstance(req.prompt[1], _acp.ImageContentBlock)
    assert req.prompt[1].mime_type == "image/jpeg"


def test_bare_image_content_is_rejected_by_prompt_request() -> None:
    """Pin the negative: feeding the bare ``ImageContent`` model into
    ``PromptRequest.prompt`` MUST fail validation. If a future SDK
    revision quietly accepts both, this test will start passing under
    the old (buggy) code in ``handle_image_message`` too — and we'd
    lose the regression signal. Keep this strict."""
    from pydantic import ValidationError

    with pytest.raises(ValidationError) as excinfo:
        _acp.PromptRequest(
            session_id="sid",
            prompt=[
                _acp.ImageContent(
                    type="image",
                    data="aGVsbG8=",
                    mime_type="image/jpeg",
                ),
            ],
        )
    # The error mentions ImageContentBlock somewhere in the chain —
    # don't pin exact wording (pydantic phrasing changes), just the
    # discriminator-target name.
    assert "ImageContentBlock" in str(excinfo.value)


def test_bot_dispatches_image_content_block() -> None:
    """End-to-end: the bot's ``handle_image_message`` must hand
    ``_dispatch_blocks`` an ``ImageContentBlock`` (the type the ACP
    client's ``PromptRequest`` will then validate cleanly). Stubs the
    Telegram download + the dispatcher; asserts on the block list."""
    from rtxclaw_telegram.bot import AcpTelegramBot
    from rtxclaw_telegram.config import TelegramConfig

    cfg = TelegramConfig(
        bot_token="x",
        allowed_chat_ids=[1],
        trusted_chat_ids=[],
        default_agent="main",
    )

    captured: list = []

    async def fake_download_image(file_id: str):
        return (b"\x00" * 16, "/tmp/fake.jpg")

    bot = AcpTelegramBot(cfg, download_image=fake_download_image)

    async def fake_dispatch_blocks(chat_id, blocks, *, thread_id=None):
        captured.append(list(blocks))
        return "ok"

    bot._dispatch_blocks = fake_dispatch_blocks  # type: ignore[assignment]

    msg = {
        "photo": [{"file_id": "small", "width": 90, "height": 90},
                  {"file_id": "big", "width": 1280, "height": 720}],
        "caption": "look at this",
    }
    out = asyncio.run(bot.handle_image_message(1, msg))
    assert out == "ok"
    assert captured, "dispatch was never called"
    blocks = captured[0]
    assert len(blocks) == 2
    assert isinstance(blocks[0], _acp.TextContentBlock)
    assert blocks[0].text == "look at this"
    assert isinstance(blocks[1], _acp.ImageContentBlock)
    assert blocks[1].mime_type == "image/jpeg"


# ---- (2) _iter_prompt cleanup on validation failure ---------------


class _SilentTransport(Transport):
    """Minimal Transport that never reads/writes. We never start the
    read loop, so ``write_message`` shouldn't get called either —
    these tests exercise the validation-failure path that bails BEFORE
    bytes hit the wire."""

    async def read_message(self) -> bytes:
        await asyncio.Event().wait()  # block forever
        return b""

    async def write_message(self, payload: bytes) -> None:
        return None

    async def close(self) -> None:
        return None


def test_iter_prompt_releases_inflight_slot_on_validation_error() -> None:
    """Reproduce the wedged-session bug: an invalid block (a bare
    ``ImageContent``) makes ``PromptRequest`` raise during construction.
    The session must NOT be left registered in ``_prompt_streams`` —
    otherwise every subsequent ``session_prompt`` returns the
    "already in flight" error even after the user starts a fresh
    turn."""
    async def _run() -> None:
        client = AcpClient(_SilentTransport())
        sid = "sid-leak-check"
        bad_blocks = [
            _acp.ImageContent(
                type="image",
                data="aGVsbG8=",
                mime_type="image/jpeg",
            ),
        ]
        with pytest.raises(Exception):
            # Drive the async generator one step so the body runs.
            async for _ in client.session_prompt(sid, bad_blocks):  # noqa: B007
                break
        # The fix moved cleanup to a try/except wrapping the request
        # build + send; without it, the slot leaked.
        assert sid not in client._prompt_streams, (
            "session left registered in _prompt_streams after a "
            "validation failure — every subsequent prompt would be "
            "rejected as 'already in flight'"
        )
        # And a follow-up prompt must be allowed (we won't actually
        # let it complete — we just need it to get past the "already
        # in flight" guard).
        good_blocks = [_acp.TextContentBlock(type="text", text="hi")]
        gen = client.session_prompt(sid, good_blocks)
        # Just kicking the generator should NOT raise the AcpClientError
        # we're guarding against. We tear it down immediately so the
        # silent transport doesn't matter.
        try:
            await asyncio.wait_for(gen.__anext__(), timeout=0.1)
        except asyncio.TimeoutError:
            # Expected — the SilentTransport never delivers a response.
            pass
        finally:
            await gen.aclose()

    asyncio.run(_run())
