"""Step 35 — ``session/set_mode`` actually flips the permission gate.

Regression for the 2026-05-07 incident: the operator switched the TUI
to plan mode (``Shift+Tab``) mid-session and asked the model to draft a
script. The TUI footer correctly read ``mode: plan`` (the
``current_mode_update`` notification round-tripped) and the saved
``Session.system_mode`` was ``"plan"`` on disk — yet the model's
``write_file`` call ran anyway and a 10K-char source file got written
to a sibling repo before the user could intervene.

Root cause: the permission resolver read ``cfg.permission_mode``
(the static config, ``None`` → ``"auto"``) and never consulted the
live ``sess.system_mode`` that ``set_mode`` wrote. The gate stayed
in AUTO for the whole life of the session regardless of what the
frontend selected, which made plan mode purely cosmetic for any
session that started in auto.

The regression silently reappeared in the 5e6591e legacy-bridge
purge — the gate moved from ``CoreBackend._evaluator_for`` (which
honoured ``sess.system_mode``) to ``Agent.resolve_permission`` (which
did not). This file pins the contract at the smallest layer that
owns the decision (the helper ``Agent._effective_mode``) so a future
drive-by edit can't silently re-introduce the bug again:

- ``Agent._effective_mode`` MUST honour ``sess.system_mode`` first.
- A mode change between calls MUST reflect immediately (no policy
  caching — the resolver re-reads system_mode every call).
- The static ``cfg.permission_mode`` remains the fallback when the
  session hasn't been steered explicitly.
- A bogus ``system_mode`` (corrupted save, schema drift) falls back
  to AUTO, never silently elevating permissions.

Pure unit tests — no daemon, no upstream LLM.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.agents.agent import Agent
from rtxclaw_core.agents.factory import _engine_for, resolve_engine_kind
from rtxclaw_core.session import Session


def _build_agent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, *, permission_mode: str | None = None) -> Agent:
    """Construct an Agent with an isolated agents-home + minimal cfg."""
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(name="t", system="sys")
    if permission_mode is not None:
        cfg.permission_mode = permission_mode
    cfg.logfile.parent.mkdir(parents=True, exist_ok=True)
    engine = _engine_for(resolve_engine_kind(None), cfg)
    return Agent(cfg=cfg, engine=engine)


def _session(*, system_mode: str = "") -> Session:
    """Construct a minimal Session with the given system_mode."""
    return Session(
        hash="sid",
        title="t",
        created_at="2026-05-18T00:00:00Z",
        system_prompt="",
        model="m",
        endpoint="e",
        system_mode=system_mode,
    )


def test_effective_mode_honours_session_system_mode(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Plan-mode session must yield ``"plan"`` even when
    ``cfg.permission_mode`` is the default (``None`` → ``"auto"``).

    This is the exact path the 2026-05-07 bug walked: a session
    created against an auto-defaulting config, flipped to plan via
    ``set_mode``, and then asked to do work. Pre-fix, the resolver
    returned AUTO; post-fix it must return PLAN."""
    agent = _build_agent(tmp_path, monkeypatch)
    assert agent.permission_mode == "auto", (
        "harness invariant: cfg.permission_mode must default to auto "
        "for this test to mean anything"
    )
    sess = _session(system_mode="plan")
    assert agent._effective_mode(sess) == "plan"


def test_effective_mode_tracks_session_changes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Flipping ``sess.system_mode`` between calls must produce a fresh
    result with the new mode. Any policy caching on the agent side
    would let mutating tools run after a switch into plan."""
    agent = _build_agent(tmp_path, monkeypatch)
    sess = _session(system_mode="auto")

    assert agent._effective_mode(sess) == "auto"

    sess.system_mode = "plan"
    assert agent._effective_mode(sess) == "plan"

    sess.system_mode = "auto"
    assert agent._effective_mode(sess) == "auto"


def test_effective_mode_falls_back_to_cfg_when_session_mode_blank(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the session hasn't been steered (``system_mode=""``), the
    static ``cfg.permission_mode`` wins. This preserves operator
    intent for sessions that never call ``set_mode`` — a daemon
    started with ``permission_mode=ask`` must keep prompting."""
    agent = _build_agent(tmp_path, monkeypatch, permission_mode="ask")
    sess = _session(system_mode="")
    assert agent._effective_mode(sess) == "ask"


def test_effective_mode_falls_back_to_auto_when_session_mode_unrecognised(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A bogus ``system_mode`` (corrupted save, schema drift) must NOT
    crash and must NOT silently elevate permissions to a weaker mode
    — it falls back to AUTO regardless of what cfg says. The on-disk
    session JSON is operator-editable; a typo there shouldn't take
    the agent out, but it also must not accidentally yield ``plan``
    or anything else."""
    agent = _build_agent(tmp_path, monkeypatch, permission_mode="ask")
    sess = _session(system_mode="lol-not-a-mode")
    assert agent._effective_mode(sess) == "auto"


# ---- end-to-end: the gate actually fires ---------------------------------
#
# The unit tests above pin ``_effective_mode`` returning the right
# string. They do NOT prove ``resolve_permission`` actually consults
# it — a future refactor that drops the ``self._effective_mode(...)``
# call at agent.py:1296 would leave the helper present-but-unused, and
# every unit test above would still pass.
#
# The two end-to-end tests below close that gap by exercising
# ``resolve_permission`` and asserting decisions that REQUIRE the
# resolver to honour ``session.system_mode`` over ``cfg.permission_mode``.
# Both tests pick a `cfg/session` mode pair where the policy table
# yields OPPOSITE decisions for the two modes — so a regression to
# cfg-only mutation immediately flips the assertion.
#
# Specifically: ``PermissionPolicy.evaluate(Write, mutating)`` returns
# ``("allow", "")`` under ``auto`` but ``("ask", "...")`` under ``plan``;
# ``ask_user`` in plan mode hard-denies without ever touching
# ``outbound`` (permissions_integration.py L273-280), so the resolver
# returns ``"deny"`` deterministically. The destructive+Bash pairing
# used in the first iteration of this test was theater: with
# ``outbound=None`` BOTH modes resolved to ``"deny"`` (destructive →
# auto-mode ASK + "no outbound channel" default-deny ≡ plan-mode
# policy deny), so the test passed regardless of which mode the
# resolver was reading. Codex/gemini round-3 review caught this.


def _resolve(agent: Agent, sess: Session, *, tool: str, args: dict,
             criticality: str) -> str:
    """Build a PermissionRequested + await ``resolve_permission``."""
    import asyncio
    from rtxclaw_core.agents.engine import PermissionRequested

    async def _drive() -> str:
        fut = asyncio.get_running_loop().create_future()
        ev = PermissionRequested(
            call_id="c1",
            tool_name=tool,
            arguments=args,
            criticality=criticality,
            response=fut,
        )
        await agent.resolve_permission(ev, sess)
        assert fut.done()
        return str(fut.result())

    return asyncio.run(_drive())


def test_resolve_permission_denies_mutating_in_plan_session(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """**cfg=auto, session=plan, mutating Write** — fixed code reads
    session.system_mode → policy yields ``ask`` → plan-mode hard-deny
    in ``ask_user`` → final decision ``deny``. The regression
    (resolver reading ``self.permission_mode``) would read cfg=auto →
    policy yields ``allow`` directly, no ASK path, final decision
    ``allow``. The two paths produce OPPOSITE decisions, so this
    assertion goes red the moment ``resolve_permission`` stops
    consulting ``_effective_mode(session)``.
    """
    agent = _build_agent(tmp_path, monkeypatch)
    assert agent.permission_mode == "auto", "harness invariant"
    sess = _session(system_mode="plan")

    out = _resolve(agent, sess, tool="Write",
                   args={"path": "/tmp/scratch/x", "content": "y"},
                   criticality="mutating")
    assert out == "deny", (
        f"plan-mode mutating Write must be denied, got {out!r}. "
        "If you see 'allow' here, resolve_permission reverted to "
        "reading self.permission_mode (cfg) instead of "
        "self._effective_mode(session)."
    )


def test_resolve_permission_allows_mutating_in_auto_session_overriding_cfg(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """**cfg=plan, session=auto, mutating Write** — positive control.

    Fixed code reads session.system_mode=auto → policy yields ``allow``
    directly, decision = ``allow``. Regression reads cfg=plan → policy
    yields ``ask`` → plan-mode hard-deny → ``deny``. Opposite decisions
    again, but in the opposite direction from the test above — so the
    two tests together pin BOTH directions of the resolver's
    cfg-vs-session source-of-truth choice. A regression flips at least
    one of them.
    """
    agent = _build_agent(tmp_path, monkeypatch, permission_mode="plan")
    assert agent.permission_mode == "plan", "harness invariant"
    sess = _session(system_mode="auto")

    out = _resolve(agent, sess, tool="Write",
                   args={"path": "/tmp/scratch/x", "content": "y"},
                   criticality="mutating")
    assert out == "allow", (
        f"auto-mode mutating Write must be allowed, got {out!r}. "
        "If you see 'deny' here, resolve_permission reverted to "
        "reading self.permission_mode (cfg) instead of "
        "self._effective_mode(session)."
    )
