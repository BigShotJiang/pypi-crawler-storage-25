"""Step 67 — reasoning/content loop detection must not fire on a recurring
domain term, while still catching genuine medium-period collapse.

Ground truth (TUI run, session 20260520T143652503235 round 6): while
designing the self-improver, qwen3.6 enumerated the subsystem's files in
its chain-of-thought as a markdown list::

       - `assets/self-improver/self-improver.sh` — ✅
       - `assets/self-improver/self-improver-scan.sh` — ✅
       ...

The 8-char tight-tier n-gram ``/self-im`` cleared the repeat threshold
(>= 8 in a 240-char window) and the turn was force-terminated mid-design
— gateway.log: ``LOOP_DETECTED tier=tight evidence=/self-im
channel=thinking``. A legitimate file listing, not a collapse.

The tool_args coverage gate (step 66) does NOT help here: it is scoped to
the ``tool_args`` channel, and — critically — *coverage cannot be used on
the reasoning channel at all*. A genuine medium-period reasoning loop has
coverage just as low as a scattered keyword (a period-28 collapse covers
~0.30 of the window, same ballpark as the ``/self-im`` listing at ~0.27),
so a coverage gate would silently DROP real loops.

The discriminator that actually separates the two is *periodicity*: a
real collapse tiles the window, so the repeated unit is followed by a
SINGLE continuation (dominant share ~1.0) regardless of period length; a
domain term recurring through otherwise-varied text is followed by MANY
distinct continuations (share well below 0.5). See the empirical table in
``test_periodicity_separates_fp_from_real_loops`` below.

Pure unit test — no daemon, no upstream.
"""
from __future__ import annotations

import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.turn_runtime import (  # noqa: E402
    _detect_loops_layered,
    _loop_coverage,
    _ngram_periodicity,
)


# The exact reasoning slice that fired live (session 20260520T143652503235,
# turn 2 thinking buffer) — a markdown file listing, byte-for-byte.
_REAL_FP_THINKING = (
    "):**\n   - `assets/self-improver/self-improver.sh` — ✅\n   - "
    "`assets/self-improver/self-improver-scan.sh` — ✅\n   - "
    "`assets/self-improver/self-improver-gc.sh` — ✅\n   - "
    "`assets/self-improver/hooks.json` — ✅\n5. **Scripts:**\n   - "
    "`scripts/self-im"
)

# Same class, but as flowing prose (no markdown structure) — proves the fix
# is about the recurring term, not just line-structured output.
_PROSE_FP_THINKING = (
    "The self-improver hot path fires self-improver.sh, the self-improver "
    "scan path is self-improver-scan.sh, the self-improver gc path is "
    "self-improver-gc.sh, and the self-improver cron registers self-improver "
    "scanning. The self-improver design keeps self-improver state under "
    "self-improver runtime so the self-improver can recover."
)


def test_real_self_improver_listing_is_not_a_thinking_loop():
    """The captured FP slice must NOT trip the detector on the thinking
    channel (it did before this fix)."""
    # Sanity: it clears the raw tight-tier repeat count.
    assert _REAL_FP_THINKING.count("/self-im") >= 7
    assert _detect_loops_layered(_REAL_FP_THINKING, channel="thinking") is None


def test_scattered_domain_term_in_prose_is_not_a_thinking_loop():
    assert _PROSE_FP_THINKING.count("self-imp") >= 8
    assert _detect_loops_layered(_PROSE_FP_THINKING, channel="thinking") is None


def test_unary_collapse_still_fires_on_thinking():
    # Canonical qwen3.x FP8-KV '!' run.
    hit = _detect_loops_layered("x" + "!" * 240, channel="thinking")
    assert hit is not None and hit[0] == "tight"


def test_short_token_collapse_still_fires_on_thinking():
    hit = _detect_loops_layered("Let's " * 60, channel="thinking")
    assert hit is not None and hit[0] == "tight"


def test_identical_line_repetition_still_fires_on_thinking():
    # Same file repeated (degenerate), not a varied listing.
    hit = _detect_loops_layered("self-improver.sh\n" * 30, channel="thinking")
    assert hit is not None


def test_medium_period_loops_still_fire_on_thinking():
    """The regression a coverage gate would cause: genuine period-20..28
    reasoning loops have coverage ~0.30-0.40 (< 0.5) but are real
    collapses. Periodicity keeps them firing."""
    for unit in (
        "Let me verify this. ",         # period 20
        "I should check the config. ",  # period 27
        "Let me re-check the answer. ",  # period 28
    ):
        buf = unit * 48
        hit = _detect_loops_layered(buf, channel="thinking")
        assert hit is not None and hit[0] == "tight", (
            f"genuine period-{len(unit)} loop must still fire; got {hit}"
        )


def test_periodicity_separates_fp_from_real_loops():
    """The core invariant: real collapse tiles the window (share ~1.0);
    the scattered domain term does not (share < 0.5). Coverage, by
    contrast, does NOT separate them — documented here so a future change
    doesn't 'simplify' back to coverage on the reasoning channel."""
    # Real FP: low periodicity.
    assert _ngram_periodicity(_REAL_FP_THINKING, "/self-im") < 0.5
    # Canonical + medium-period collapses: maximal periodicity.
    assert _ngram_periodicity("x" + "!" * 240, "!!!!!!!!") == 1.0
    assert _ngram_periodicity("Let me re-check the answer. " * 48, "eck the ") == 1.0
    # Coverage cannot tell them apart (both low) — this is why we don't
    # use it here.
    assert _loop_coverage(_REAL_FP_THINKING, "/self-im") < 0.5
    assert _loop_coverage("Let me re-check the answer. " * 48, "eck the ") < 0.5


def test_content_channel_domain_term_also_suppressed():
    # The content channel gets the same tight-tier periodicity gate (in
    # addition to its existing structured-content carve-out).
    assert _detect_loops_layered(_PROSE_FP_THINKING, channel="content") is None


def test_tool_args_behavior_unchanged():
    # The tool_args channel keeps its coverage gate (step 66) — a
    # degenerate run still fires, a scattered term still doesn't.
    assert _detect_loops_layered("self-improver" * 30, channel="tool_args")[0] == "tight"
    varied = (
        "ls -la ~/.rtxclaw/scripts/self-improver*; "
        "cat ~/.rtxclaw/self-improver/config.json; "
        "grep self-improver ~/.rtxclaw/agents/main/hooks.json; "
        "ls assets/self-improver/; rtxclaw self-improver status"
    )
    assert _detect_loops_layered(varied, channel="tool_args") is None
