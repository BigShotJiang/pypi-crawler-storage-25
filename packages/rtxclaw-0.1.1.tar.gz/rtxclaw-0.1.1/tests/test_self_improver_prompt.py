"""Smoke tests for the Claude prompt template. The prompt is the most
load-bearing artifact of the self-improver — these tests verify it
doesn't lose required structure during refactors."""
from pathlib import Path

PROMPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "self-improver-prompt.md"


def test_prompt_exists():
    assert PROMPT_PATH.is_file(), f"missing prompt file: {PROMPT_PATH}"


def test_prompt_contains_required_placeholders():
    """Wrapper templates these in — drop one and runtime breaks."""
    body = PROMPT_PATH.read_text(encoding="utf-8")
    for tok in ("{session_id}", "{event}", "{transcript_path}", "{agent_name}"):
        assert tok in body, f"prompt is missing required placeholder: {tok}"


def test_prompt_describes_both_tiers():
    body = PROMPT_PATH.read_text(encoding="utf-8")
    assert "Tier 1" in body and "Tier 2" in body, "prompt must describe both analysis tiers"


def test_prompt_forbids_tool_outputs_at_tier_1():
    body = PROMPT_PATH.read_text(encoding="utf-8").lower()
    # The Tier-1 forbidden-reads guard is the design's load-bearing
    # cheapness lever — refactor must not delete it.
    assert "do not read" in body or "must not read" in body or "forbidden" in body, (
        "prompt must explicitly forbid reading tool outputs at Tier 1"
    )


def test_prompt_lists_all_typed_finding_kinds():
    body = PROMPT_PATH.read_text(encoding="utf-8")
    for kind in (
        "rtxclaw_logic_bug",
        "rtxclaw_prompt_bug",
        "rtxclaw_routing_bug",
        "rtxclaw_runtime_bug",
        "target_repo_bug",
        "user_abort",
        "benign",
    ):
        assert kind in body, f"prompt must list finding kind: {kind}"
