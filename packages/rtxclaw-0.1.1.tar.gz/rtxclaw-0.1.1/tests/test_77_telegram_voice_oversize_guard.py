"""Step 77 — oversize voice/audio is rejected with a clear message.

Telegram's cloud Bot API caps ``getFile`` (hence any bot-side file
download) at 20 MB. A larger audio attachment can't be fetched at all —
``getFile`` returns ``{"ok": false, "description": "file is too big"}``
and the old downloader returned ``None`` *silently*, so the user saw
the generic "⚠️ couldn't download voice" with no idea why.

The fix reads ``file_size`` off the incoming voice/audio object and, if
it's over the 20 MB cap, replies with an actionable message (the actual
size + why) and never attempts the doomed download.

This test drives ``_handle_update`` with an oversized ``audio`` message
and asserts: (1) a reply mentioning the 20 MB limit is sent, and
(2) ``_stream_turn_for_chat`` (the download/STT path) is never entered.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_telegram.bot import AcpTelegramBot, TG_GETFILE_MAX_BYTES
from rtxclaw_telegram.config import TelegramConfig


class _FakeAPI:
    def __init__(self) -> None:
        self.sends: list[str] = []

    async def send_message(self, chat_id, text, *, message_thread_id=None,
                           parse_mode=None):
        self.sends.append(text)
        return 1

    async def call(self, method, **params):
        return {"ok": True, "result": {}}


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    return tmp_path


@pytest.mark.asyncio
async def test_oversize_audio_rejected_without_download(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    api = _FakeAPI()
    bot = AcpTelegramBot(
        TelegramConfig(default_agent="main"),
        acp_url="",
        trusted_chats=set(),
        api=api,
        stt=lambda *a, **k: "",          # presence-only; never called
        download_audio=lambda *a, **k: None,
    )
    # Bypass the auth/allow gates (covered elsewhere) and spy on the
    # download/STT entrypoint so we can assert it's never reached.
    monkeypatch.setattr(bot, "_is_authorized", lambda cid: True)
    monkeypatch.setattr(bot, "_user_allowed", lambda sid: True)
    streamed: list = []

    async def _spy_stream(*a, **k):
        streamed.append((a, k))

    monkeypatch.setattr(bot, "_stream_turn_for_chat", _spy_stream)

    too_big = TG_GETFILE_MAX_BYTES + 5 * 1024 * 1024  # 25 MB
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 999, "type": "private"},
            "from": {"id": 8484692594, "is_bot": False},
            "audio": {
                "file_id": "BIGFILE",
                "mime_type": "audio/mp4",
                "file_size": too_big,
            },
        },
    }

    await bot._handle_update(update)

    # The download/STT path must NOT have been entered.
    assert streamed == [], "oversize audio should not reach _stream_turn_for_chat"
    # The user got a clear, actionable message citing the 20 MB cap.
    joined = "\n".join(api.sends)
    assert "20 MB" in joined, f"no 20 MB explanation sent; got {api.sends!r}"
    assert "25 MB" in joined, f"actual size not surfaced; got {api.sends!r}"


@pytest.mark.asyncio
async def test_normal_size_audio_still_dispatches(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A within-limit audio must still flow to the download/STT path —
    the guard only trips above 20 MB."""
    api = _FakeAPI()
    bot = AcpTelegramBot(
        TelegramConfig(default_agent="main"),
        acp_url="",
        trusted_chats=set(),
        api=api,
        stt=lambda *a, **k: "",
        download_audio=lambda *a, **k: None,
    )
    monkeypatch.setattr(bot, "_is_authorized", lambda cid: True)
    monkeypatch.setattr(bot, "_user_allowed", lambda sid: True)
    streamed: list = []

    async def _spy_stream(*a, **k):
        streamed.append((a, k))

    monkeypatch.setattr(bot, "_stream_turn_for_chat", _spy_stream)

    update = {
        "update_id": 2,
        "message": {
            "message_id": 11,
            "chat": {"id": 999, "type": "private"},
            "from": {"id": 8484692594, "is_bot": False},
            "audio": {
                "file_id": "OKFILE",
                "mime_type": "audio/mp4",
                "file_size": 3 * 1024 * 1024,  # 3 MB
            },
        },
    }

    await bot._handle_update(update)

    assert len(streamed) == 1, "within-limit audio should dispatch to STT path"
    assert streamed[0][1].get("voice_file_id") == "OKFILE"
