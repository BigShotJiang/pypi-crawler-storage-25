"""Tests for _TelegramAPI local_mode flag and RTXCLAW_TELEGRAM_API_BASE env knob."""
from rtxclaw_telegram.bot import _TelegramAPI, TELEGRAM_API


def test_local_mode_flag_from_api_base():
    cloud = _TelegramAPI("TOKEN")
    assert cloud.local_mode is False
    assert cloud._api_base == TELEGRAM_API
    local = _TelegramAPI("TOKEN", api_base="http://127.0.0.1:8081")
    assert local.local_mode is True


import asyncio
from pathlib import Path
from rtxclaw_telegram.bot import _make_default_audio_downloader

class _FakeLocalAPI:
    def __init__(self, file_path):
        self.local_mode = True
        self._file_path = file_path
        self._api_base = "http://127.0.0.1:8081"
        self._token = "TOKEN"
        import logging; self._log = logging.getLogger("t")
    async def call(self, method, **params):
        assert method == "getFile"
        return {"ok": True, "result": {"file_path": self._file_path}}

def test_local_mode_downloader_reads_disk(tmp_path, monkeypatch):
    monkeypatch.setenv("RTXCLAW_TELEGRAM_FILE_ROOT", str(tmp_path))
    f = tmp_path / "music" / "clip.mp3"
    f.parent.mkdir(parents=True)
    f.write_bytes(b"ID3-FAKE-AUDIO-BYTES")
    dl = _make_default_audio_downloader(_FakeLocalAPI(str(f)))
    data, name = asyncio.run(dl("file-id"))
    assert data == b"ID3-FAKE-AUDIO-BYTES"
    assert name == "clip.mp3"


def test_local_mode_downloader_rejects_path_outside_root(tmp_path, monkeypatch):
    monkeypatch.setenv("RTXCLAW_TELEGRAM_FILE_ROOT", str(tmp_path / "data"))
    (tmp_path / "data").mkdir()
    secret = tmp_path / "secret.env"           # sibling, OUTSIDE the root
    secret.write_text("TELEGRAM_API_HASH=topsecret")
    dl = _make_default_audio_downloader(_FakeLocalAPI(str(secret)))
    assert asyncio.run(dl("file-id")) is None   # refused, not read
