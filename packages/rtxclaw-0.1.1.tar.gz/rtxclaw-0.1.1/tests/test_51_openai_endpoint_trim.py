"""Step 51 — OpenAI-endpoint history trim (pure-unit).

Open WebUI sends the FULL chat history on every `/chat/completions`
request. `_serialise_history_as_prompt` collapses the array into one
big user-message text; if the result exceeds the agent's upstream
context window, vLLM returns HTTP 400 (`maximum context length is N
tokens. However, your prompt contains at least M input tokens`). The
agent-side reactive squeeze (`LocalLLMEngine._reactive_compact_on_overflow`)
can't help here because everything's already collapsed into a single
protected user message.

Fix: trim oldest non-system, non-final-user messages from the array
BEFORE serialising so the resulting prompt fits the agent's context.

Lives in ``src/rtxclaw_agent/openai_endpoint.py``.
"""
from __future__ import annotations


def _msg(role: str, content: str) -> dict:
    return {"role": role, "content": content}


def test_under_budget_is_noop() -> None:
    from rtxclaw_agent.openai_endpoint import trim_messages_to_char_budget
    msgs = [
        _msg("system", "you are a helper"),
        _msg("user", "hi"),
        _msg("assistant", "hello"),
        _msg("user", "how are you?"),
    ]
    out, dropped = trim_messages_to_char_budget(msgs, max_chars=10_000)
    assert out == msgs
    assert dropped == 0


def test_drops_oldest_non_system_non_last_user() -> None:
    """When over budget, oldest non-system / non-final-user messages
    go first. The system header and the trailing live user message
    must survive."""
    from rtxclaw_agent.openai_endpoint import trim_messages_to_char_budget
    big = "X" * 5_000
    msgs = [
        _msg("system", "sys"),
        _msg("user",      f"old user 1 {big}"),
        _msg("assistant", f"old assistant 1 {big}"),
        _msg("user",      f"old user 2 {big}"),
        _msg("assistant", f"old assistant 2 {big}"),
        _msg("user",      "LIVE QUESTION"),
    ]
    out, dropped = trim_messages_to_char_budget(msgs, max_chars=8_000)
    assert dropped >= 1
    # System and live user survive every stage.
    assert out[0]["role"] == "system"
    assert out[-1]["role"] == "user"
    assert out[-1]["content"] == "LIVE QUESTION"
    # Total chars below budget.
    total = sum(len(m.get("content", "")) for m in out)
    assert total <= 8_000


def test_preserves_last_user_even_when_too_big_alone() -> None:
    """If even the protected pair (system + last user) overflows the
    budget, the function still returns them — the caller decides what
    to do (we don't truncate user content here; that's a different
    failure mode handled by the agent-side `max_tokens_override`
    fallback)."""
    from rtxclaw_agent.openai_endpoint import trim_messages_to_char_budget
    msgs = [
        _msg("system", "X" * 5_000),
        _msg("user",   "X" * 5_000),
    ]
    out, dropped = trim_messages_to_char_budget(msgs, max_chars=100)
    # No droppable messages — protected set survives.
    assert dropped == 0
    assert len(out) == 2
    assert out[0]["role"] == "system"
    assert out[1]["role"] == "user"


def test_drops_in_pairs_to_avoid_orphan_assistant_at_head() -> None:
    """After trimming, the first non-system message must NOT be a
    bare assistant turn — an `assistant` reply makes no sense without
    its preceding user prompt. The trimmer drops paired turns when
    possible."""
    from rtxclaw_agent.openai_endpoint import trim_messages_to_char_budget
    msgs = [
        _msg("system", "sys"),
        _msg("user",      "u1 " + "X" * 3_000),
        _msg("assistant", "a1 " + "X" * 3_000),
        _msg("user",      "u2 " + "X" * 3_000),
        _msg("assistant", "a2 " + "X" * 3_000),
        _msg("user",      "LIVE"),
    ]
    out, _dropped = trim_messages_to_char_budget(msgs, max_chars=7_500)
    # The first message after the system block should not be a
    # dangling assistant.
    nonsys = [m for m in out if m["role"] != "system"]
    if nonsys:
        assert nonsys[0]["role"] != "assistant", (
            f"first non-system message is a dangling assistant: {nonsys[0]}"
        )


def test_flatten_strips_base64_data_uri() -> None:
    """Open WebUI sends pasted images as ``data:image/png;base64,<HUGE>``
    inside an ``image_url`` part. The previous implementation rendered
    the URL verbatim — a 200 KB image became ~200k chars of base64 in
    the user prompt and blew past the 64k-token cap even though the
    helper text was tiny. The flattener must replace data: URIs with
    a short placeholder; HTTP/HTTPS URLs are short, pass through.

    NOTE: this helper is only used for HISTORICAL (older) messages
    after the live-image pipeline has extracted images from the last
    user message. The lightweight placeholder is fine for old context.
    """
    from rtxclaw_agent.openai_endpoint import _flatten_message_content

    big_b64 = "iVBORw0KGgo" + "X" * 200_000
    data_uri = f"data:image/png;base64,{big_b64}"
    out = _flatten_message_content([
        {"type": "text", "text": "what is in this image?"},
        {"type": "image_url", "image_url": {"url": data_uri}},
    ])
    assert "what is in this image?" in out
    assert big_b64 not in out, "base64 body leaked into the flat prompt"
    assert "image" in out.lower()
    assert "png" in out.lower()
    assert len(out) < 1_000


def test_flatten_preserves_http_image_url() -> None:
    """HTTP/HTTPS image URLs are short — keep them verbatim so a
    vision-capable or tool-using model can fetch the image."""
    from rtxclaw_agent.openai_endpoint import _flatten_message_content
    out = _flatten_message_content([
        {"type": "text", "text": "describe"},
        {"type": "image_url", "image_url": {"url": "https://example.com/cat.png"}},
    ])
    assert "https://example.com/cat.png" in out
    assert "describe" in out


def test_extract_live_images_returns_acp_image_blocks() -> None:
    """Images on the LAST user message must be extracted as ACP-shape
    ``{type: image, data: <b64>, mimeType: <mime>}`` blocks so the
    agent's existing _resolve_images_for_model pipeline (transcribe
    for text-only models, forward for vision models) can run. The
    base64 body must reach the agent intact — only AFTER that does
    the lightweight placeholder substitute in the serialised history.
    """
    from rtxclaw_agent.openai_endpoint import build_prompt_blocks_from_messages

    b64 = "iVBORw0KGgoAAAA" + "X" * 200
    msgs = [
        {"role": "system", "content": "be brief"},
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "hello"},
        {"role": "user", "content": [
            {"type": "text", "text": "what is in this image?"},
            {"type": "image_url",
             "image_url": {"url": f"data:image/png;base64,{b64}"}},
        ]},
    ]
    blocks = build_prompt_blocks_from_messages(msgs)
    # First block carries the serialised history + live text — image
    # body is NOT in it (placeholder only).
    text_blocks = [b for b in blocks if b.get("type") == "text"]
    image_blocks = [b for b in blocks if b.get("type") == "image"]
    assert text_blocks, "must include at least one text block"
    assert image_blocks, "live image must surface as an ACP image block"

    # Image block fidelity: base64 body intact, mime preserved.
    assert image_blocks[0]["data"] == b64
    assert image_blocks[0]["mimeType"] == "image/png"

    # Serialised text: live user question survives, base64 does NOT
    # leak into it (the agent pipeline handles the bytes separately).
    combined_text = "\n".join(str(b.get("text", "")) for b in text_blocks)
    assert "what is in this image?" in combined_text
    assert b64 not in combined_text


def test_extract_live_images_falls_back_to_flatten_for_history() -> None:
    """Images in OLDER (non-last) messages become text placeholders
    via the flatten helper — we don't ship every historical image
    to the model as a vision payload (would explode prompt size and
    most models can't even consume vision in chat history)."""
    from rtxclaw_agent.openai_endpoint import build_prompt_blocks_from_messages

    old_b64 = "OLD" + "X" * 500
    msgs = [
        {"role": "user", "content": [
            {"type": "text", "text": "old turn with pic"},
            {"type": "image_url",
             "image_url": {"url": f"data:image/jpeg;base64,{old_b64}"}},
        ]},
        {"role": "assistant", "content": "ok"},
        {"role": "user", "content": "new turn (no image)"},
    ]
    blocks = build_prompt_blocks_from_messages(msgs)
    text_blocks = [b for b in blocks if b.get("type") == "text"]
    image_blocks = [b for b in blocks if b.get("type") == "image"]
    assert not image_blocks, "no live image — no ACP image blocks expected"
    combined_text = "\n".join(str(b.get("text", "")) for b in text_blocks)
    # Old image still acknowledged via the placeholder; base64 stripped.
    assert old_b64 not in combined_text
    assert "image" in combined_text.lower()
    assert "new turn (no image)" in combined_text


def test_hard_cap_constant_is_64k_tokens() -> None:
    """The endpoint hard-caps wire-layer input at 64k tokens for
    faster responses (user directive 2026-05-18). No cfg lookup, no
    iteration, no upstream parsing — just a single clamp before
    serialising. The constant is exposed for tests / introspection.
    """
    from rtxclaw_agent.openai_endpoint import (
        OPENAI_ENDPOINT_INPUT_TOKEN_CAP,
        OPENAI_ENDPOINT_INPUT_CHAR_CAP,
        _CHARS_PER_TOKEN_FLOOR,
    )
    assert OPENAI_ENDPOINT_INPUT_TOKEN_CAP == 64_000
    # Char cap derived from the token cap × chars/token floor.
    expected_chars = int(64_000 * _CHARS_PER_TOKEN_FLOOR)
    assert OPENAI_ENDPOINT_INPUT_CHAR_CAP == expected_chars


def test_handles_string_and_list_content_shapes() -> None:
    """OpenAI ``messages[i].content`` can be a string OR a list of
    {type, text/image_url} parts. The trimmer must count both shapes
    correctly so a vision request doesn't undercount."""
    from rtxclaw_agent.openai_endpoint import trim_messages_to_char_budget
    big_text_part = {"type": "text", "text": "X" * 5_000}
    msgs = [
        _msg("system", "sys"),
        {"role": "user", "content": [big_text_part]},
        _msg("assistant", "ok"),
        _msg("user", "LIVE"),
    ]
    out, dropped = trim_messages_to_char_budget(msgs, max_chars=1_000)
    # The big-list message should have been counted and dropped.
    assert dropped >= 1
    assert out[-1]["content"] == "LIVE"
