"""Step 25 — System-prompt loader coverage.

``rtxclaw_core.context.load_system_prompt`` concatenates the
operator's editable ``.md`` files (SOUL, USER, TOOLS, TOOLCALL,
AGENTS, plus mode-specific MODE-{PLAN,ASK,AUTO}.md) into the system
prompt. The composition is on the prefix-cache hot path — a silent
reorder breaks vLLM APC / SGLang RadixAttention reuse on every turn.

Coverage:
- Section ORDER is stable: WORKSPACE → SOUL → USER → TOOLS →
  TOOLCALL → AGENTS, mode file at the tail.
- Empty workspace + empty user_system → empty string (no labels).
- ``user_system`` extra block lands as ``# SYSTEM`` at the very end.
- Per-file cap (1 MiB) appends a truncation marker.
- Mode selection: only the active mode file is loaded, others are
  skipped.
- Unknown mode is silently dropped (defaults to no mode injection).
- Missing files are skipped without raising.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_core.context import (
    CONTEXT_FILE_MAX_BYTES,
    load_system_prompt,
)


def _populate(root: Path, files: dict[str, str]) -> None:
    for name, body in files.items():
        (root / name).write_text(body, encoding="utf-8")


def test_empty_workspace_returns_user_system_verbatim(tmp_path: Path) -> None:
    out = load_system_prompt("plain text", root=tmp_path)
    assert out == "plain text"


def test_empty_workspace_and_no_user_system_returns_empty(tmp_path: Path) -> None:
    assert load_system_prompt("", root=tmp_path) == ""


def test_section_order_is_workspace_soul_user_tools_toolcall_agents(
    tmp_path: Path,
) -> None:
    _populate(tmp_path, {
        "WORKSPACE.md": "# WORKSPACE\nws-body",
        "SOUL.md":      "# SOUL\nsoul-body",
        "USER.md":      "# USER\nuser-body",
        "TOOLS.md":     "# TOOLS\ntools-body",
        "TOOLCALL.md":  "# TOOLCALL\ntoolcall-body",
        "AGENTS.md":    "# AGENTS\nagents-body",
    })
    out = load_system_prompt("", root=tmp_path)
    # Verify each section appears AFTER the previous one — strict
    # ordering, not just presence.
    expected = ["ws-body", "soul-body", "user-body",
                "tools-body", "toolcall-body", "agents-body"]
    last = -1
    for label in expected:
        idx = out.find(label)
        assert idx > last, f"section {label!r} out of order in:\n{out}"
        last = idx


def test_mode_file_loaded_at_tail(tmp_path: Path) -> None:
    _populate(tmp_path, {
        "SOUL.md":      "soul-body",
        "MODE-PLAN.md": "PLAN-MODE-BODY",
        "MODE-ASK.md":  "ASK-MODE-BODY",
        "MODE-AUTO.md": "AUTO-MODE-BODY",
    })
    out = load_system_prompt("", root=tmp_path, mode="plan")
    assert "PLAN-MODE-BODY" in out
    assert "ASK-MODE-BODY" not in out
    assert "AUTO-MODE-BODY" not in out
    # Mode body must come AFTER the regular sections.
    assert out.find("PLAN-MODE-BODY") > out.find("soul-body")


def test_unknown_mode_is_silently_dropped(tmp_path: Path) -> None:
    _populate(tmp_path, {"SOUL.md": "soul"})
    # Should not raise, no mode block injected.
    out = load_system_prompt("", root=tmp_path, mode="nonsense")
    assert "soul" in out
    assert "MODE" not in out  # no synthetic header


def test_user_system_appended_with_label(tmp_path: Path) -> None:
    _populate(tmp_path, {"SOUL.md": "soul-body"})
    out = load_system_prompt(
        "extra fine print", root=tmp_path,
    )
    # `user_system` arrives last with the `# SYSTEM` heading.
    assert "# SYSTEM" in out
    assert "extra fine print" in out
    assert out.rfind("extra fine print") > out.rfind("soul-body")


def test_missing_files_are_skipped(tmp_path: Path) -> None:
    _populate(tmp_path, {"SOUL.md": "only soul"})
    out = load_system_prompt("", root=tmp_path)
    assert "only soul" in out
    # Other section markers must not synthesize empty content.
    assert "USER" not in out
    assert "AGENTS" not in out


def test_per_file_cap_truncates_with_marker(tmp_path: Path) -> None:
    """A runaway SOUL.md (1 MiB+) gets truncated to the cap with a
    marker so the operator notices instead of OOMing the daemon."""
    huge = "x" * (CONTEXT_FILE_MAX_BYTES + 1024)
    _populate(tmp_path, {"SOUL.md": huge})
    out = load_system_prompt("", root=tmp_path)
    assert "[... truncated by rtxclaw context loader" in out
    # Should be capped at the byte limit + the marker.
    assert len(out) <= CONTEXT_FILE_MAX_BYTES + 500


def test_mode_files_isolated_per_call(tmp_path: Path) -> None:
    """Switching mode between calls doesn't mix mode bodies — each
    call loads exactly one mode file."""
    _populate(tmp_path, {
        "MODE-PLAN.md": "<<PLAN>>",
        "MODE-ASK.md":  "<<ASK>>",
        "MODE-AUTO.md": "<<AUTO>>",
    })
    plan = load_system_prompt("", root=tmp_path, mode="plan")
    ask = load_system_prompt("", root=tmp_path, mode="ask")
    auto = load_system_prompt("", root=tmp_path, mode="auto")
    assert "<<PLAN>>" in plan and "<<ASK>>" not in plan and "<<AUTO>>" not in plan
    assert "<<ASK>>" in ask and "<<PLAN>>" not in ask and "<<AUTO>>" not in ask
    assert "<<AUTO>>" in auto and "<<PLAN>>" not in auto and "<<ASK>>" not in auto


def test_mode_none_skips_mode_injection(tmp_path: Path) -> None:
    _populate(tmp_path, {
        "SOUL.md": "soul",
        "MODE-PLAN.md": "<<PLAN>>",
    })
    out = load_system_prompt("", root=tmp_path, mode=None)
    assert "soul" in out
    assert "<<PLAN>>" not in out
