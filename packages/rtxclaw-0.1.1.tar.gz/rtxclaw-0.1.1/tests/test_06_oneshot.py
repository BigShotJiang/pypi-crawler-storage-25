"""Step 06 — one-shot CLI (`rtxclaw -p PROMPT`).

Drives the **real** upstream resolved by ``configured_endpoint``. The
``running_daemon`` fixture lives in conftest so test_05 / test_07 can
share it.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest



# NOT marked slow. test_03..06 are the boot+smoke chain that
# tests/select-affected.sh::ALWAYS_RUN forces into every tier-1 run.
# Marking them slow would let `-m "not slow"` silently filter them out,
# defeating the belt-and-suspenders against daemon-shape regressions
# (e.g. the wt_ms TURN_METRICS drop). The full suite (tier-3) runs them
# regardless of markers.

def test_oneshot_returns_stdout(running_daemon: Path, run_rtxclaw) -> None:
    prompt = os.environ.get("RTXCLAW_TEST_PROMPT", "reply with the single word: pong")
    cp = run_rtxclaw("-p", prompt, timeout=120)
    assert cp.returncode == 0, f"rtxclaw -p failed:\n{cp.stderr}"
    assert cp.stdout.strip(), "stdout was empty"


def test_plan_shortcut_runs(running_daemon: Path, run_rtxclaw) -> None:
    cp = run_rtxclaw("--plan", "-p", "list two file types you'd inspect to learn this repo", timeout=120)
    assert cp.returncode == 0, f"rtxclaw --plan -p failed:\n{cp.stderr}"


def test_oneshot_emits_turn_metrics_to_gateway_log(
    running_daemon: Path, run_rtxclaw,
) -> None:
    """Per-turn telemetry must land in ``gateway.log`` so operators
    can inspect prefill / ttft / gen tps without the TUI.

    The bridge writes ``TURN_METRICS <json>`` direct to stderr (the
    daemon's stderr is redirected to ``gateway.log`` by the launcher
    — using ``logging.getLogger`` would silently drop the line
    because the bridge logger has no FileHandler attached, only the
    bot's does).

    ``running_daemon`` yields ``<sandbox_home>/gateway.pid``; the
    gateway log lives at the sibling ``gateway.log``.
    """
    gw_log = running_daemon.parent / "gateway.log"
    cp = run_rtxclaw(
        "-p", "reply with the single word: ok",
        timeout=120,
    )
    assert cp.returncode == 0, f"oneshot failed:\n{cp.stderr}"

    # Generous flush window — the worker emits ``metrics`` to the
    # bridge over the IPC pipe, the bridge writes the TURN_METRICS
    # line to stderr, and the kernel buffers stderr until the
    # daemon's logger flushes. 10 s is well past the worst-case
    # tick under load.
    deadline = time.time() + 10
    body = ""
    while time.time() < deadline:
        if gw_log.is_file():
            body = gw_log.read_text(errors="replace")
            if "TURN_METRICS" in body:
                break
        time.sleep(0.5)
    assert "TURN_METRICS" in body, (
        "TURN_METRICS line missing from gateway.log — bridge metrics "
        "emission regressed. Recent log tail:\n"
        f"{body[-2000:]}"
    )
    assert "wt_ms" in body, "TURN_METRICS line lacks wt_ms"
