"""Regression: the CLI engines (claude_cli / codex_cli / gemini_cli)
must lock the spawn cwd to whatever directory minted the
``engine_session_id``, and use that cwd on every subsequent resume —
even when the frontend reattaches from a different directory.

Why this matters: Claude Code keys ``--resume <id>`` lookups by
``~/.claude/projects/<encoded-cwd>/<engine_session_id>.jsonl``. Codex
and Gemini have analogous cwd-keyed lookups. If the spawn cwd drifts
between the call that created the session and a later resume, the CLI
silently misses the on-disk conversation, reports
``error_during_execution``, and rtxclaw falls back to a fresh CLI
session — losing the entire prior context.

These tests pin the contract:
  (a) ``EngineSessionState`` persists ``spawn_cwd`` in the sidecar.
  (b) First-turn priming captures ``spawn_cwd`` from the request.
  (c) Resume turns ignore ``request.cwd`` when ``state.spawn_cwd`` is
      recorded and use the locked cwd instead.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path


def _fake_claude_argv_and_cwd_capture(
    bin_dir: Path, capture_path: Path,
) -> None:
    """Install a ``claude`` stub that records ``[argv, cwd]`` per
    invocation, then emits a minimal stream-json reply so the engine
    drives to ``TurnDone(state="ok")`` and surfaces a session_id.
    """
    bin_dir.mkdir(parents=True, exist_ok=True)
    stub = bin_dir / "claude"
    stub.write_text(
        f"""#!/usr/bin/env python3
import json, os, sys
sys.stdin.read()  # drain so parent stdin_task completes
with open({json.dumps(str(capture_path))}, "a", encoding="utf-8") as fh:
    fh.write(json.dumps([sys.argv, os.getcwd()]) + chr(10))
print(json.dumps({{
    "type": "assistant",
    "session_id": "stub-eid-AAA",
    "message": {{"content": [{{"type": "text", "text": "ok"}}]}},
}}), flush=True)
print(json.dumps({{
    "type": "result",
    "session_id": "stub-eid-AAA",
    "is_error": False,
}}), flush=True)
""",
        encoding="utf-8",
    )
    stub.chmod(0o755)


def _drain(engine, request, state, sessions_dir, turn_id):
    from rtxclaw_core.agents.engine import TurnDone

    async def _go():
        terminal = "none"
        async for ev in engine.run_turn(
            request, state, sessions_dir=sessions_dir, turn_id=turn_id,
        ):
            if isinstance(ev, TurnDone):
                terminal = ev.state
        return terminal

    return asyncio.run(_go())


# ----------------------------------------------------------------- (a)

def test_engine_session_state_round_trips_spawn_cwd(tmp_path) -> None:
    """``write_state`` → ``read_state`` round-trip preserves
    ``spawn_cwd``. Legacy sidecars (no ``spawn_cwd`` key) read back
    as empty string — back-compat must hold."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import EngineKind, EngineSessionState

    engine = ClaudeCliEngine()
    sessions_dir = tmp_path
    sid = "rtx-roundtrip"

    state = EngineSessionState(
        rtxclaw_session_id=sid,
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id="eid-1",
        priming_status="completed",
        spawn_cwd="/home/jcooloj/src/rtxclaw",
    )
    engine.write_state(sessions_dir, state)

    # On-disk JSON contains the new field.
    on_disk = json.loads(
        (sessions_dir / f"{sid}.claude_cli.json").read_text(encoding="utf-8")
    )
    assert on_disk["spawn_cwd"] == "/home/jcooloj/src/rtxclaw"

    # read_state round-trips it.
    loaded = engine.read_state(sessions_dir, sid)
    assert loaded.spawn_cwd == "/home/jcooloj/src/rtxclaw"

    # Legacy sidecar (no spawn_cwd key) → empty string, no crash.
    legacy_sid = "rtx-legacy"
    legacy_path = sessions_dir / f"{legacy_sid}.claude_cli.json"
    legacy_path.write_text(
        json.dumps({
            "rtxclaw_session_id": legacy_sid,
            "engine": "claude_cli",
            "engine_session_id": "eid-legacy",
            "priming_status": "completed",
        }),
        encoding="utf-8",
    )
    legacy_loaded = engine.read_state(sessions_dir, legacy_sid)
    assert legacy_loaded.engine_session_id == "eid-legacy"
    assert legacy_loaded.spawn_cwd == ""


# ----------------------------------------------------------------- (b)

def test_first_turn_captures_spawn_cwd_to_sidecar(
    tmp_path, monkeypatch,
) -> None:
    """On the first prime, the engine must persist ``spawn_cwd`` to
    the sidecar at the same moment it persists the new
    ``engine_session_id`` — so any subsequent resume can rely on it
    even if the very next turn aborts mid-stream."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import (
        EngineKind, EngineSessionState, TurnRequest,
    )

    capture = tmp_path / "argv_cwd.jsonl"
    _fake_claude_argv_and_cwd_capture(tmp_path / "bin", capture)
    monkeypatch.setenv(
        "PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}",
    )
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    spawn_dir = tmp_path / "workspace_one"
    spawn_dir.mkdir()

    sid = "rtx-first-prime"
    state = EngineSessionState(
        rtxclaw_session_id=sid,
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id="",
        priming_status="never",
    )
    request = TurnRequest(
        prompt="hello world",
        system_prompt="# SOUL\n\nbaseline\n",
        system_prompt_sha256="a" * 64,
        preamble=[],
        mode="auto",
        cwd=str(spawn_dir),
    )

    terminal = _drain(
        ClaudeCliEngine(), request, state, sessions_dir,
        turn_id="t-first",
    )
    assert terminal == "ok"

    # Sidecar must have BOTH engine_session_id AND spawn_cwd.
    saved = json.loads(
        (sessions_dir / f"{sid}.claude_cli.json").read_text(encoding="utf-8")
    )
    assert saved["engine_session_id"] == "stub-eid-AAA"
    assert saved["spawn_cwd"] == str(spawn_dir), (
        f"sidecar spawn_cwd not locked: {saved!r}"
    )

    # And the spawn actually ran in that cwd.
    rows = [json.loads(ln) for ln in capture.read_text().splitlines()]
    assert len(rows) == 1
    spawn_argv, spawn_cwd = rows[0]
    assert spawn_cwd == str(spawn_dir)


# ----------------------------------------------------------------- (c)

def test_resume_turn_uses_locked_spawn_cwd_not_request_cwd(
    tmp_path, monkeypatch,
) -> None:
    """When ``state.spawn_cwd`` is recorded AND we're resuming, the
    runner must spawn at the locked cwd — IGNORING any newer
    ``request.cwd`` from a reattach. This is the whole point of the
    lock: a frontend that reconnects from a different directory must
    not silently break ``--resume``."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import (
        EngineKind, EngineSessionState, TurnRequest,
    )

    capture = tmp_path / "argv_cwd.jsonl"
    _fake_claude_argv_and_cwd_capture(tmp_path / "bin", capture)
    monkeypatch.setenv(
        "PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}",
    )
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    original_spawn_dir = tmp_path / "workspace_original"
    original_spawn_dir.mkdir()
    new_cwd_dir = tmp_path / "workspace_after_reattach"
    new_cwd_dir.mkdir()

    sid = "rtx-resume-with-lock"
    state = EngineSessionState(
        rtxclaw_session_id=sid,
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id="prior-eid",
        priming_status="completed",
        priming_system_prompt_sha256="a" * 64,
        spawn_cwd=str(original_spawn_dir),
    )
    # Frontend reattached from a DIFFERENT cwd — request.cwd carries
    # the new one. The engine must still spawn at original_spawn_dir.
    request = TurnRequest(
        prompt="follow-up after reattach",
        system_prompt=None,
        system_prompt_sha256="a" * 64,
        preamble=[],
        mode="auto",
        cwd=str(new_cwd_dir),
    )

    terminal = _drain(
        ClaudeCliEngine(), request, state, sessions_dir,
        turn_id="t-resume",
    )
    assert terminal == "ok"

    rows = [json.loads(ln) for ln in capture.read_text().splitlines()]
    assert len(rows) == 1
    spawn_argv, spawn_cwd = rows[0]

    # Spawn cwd must be the locked one, NOT the request's new cwd.
    assert spawn_cwd == str(original_spawn_dir), (
        f"resume spawned at {spawn_cwd!r}; expected the locked "
        f"{str(original_spawn_dir)!r} (request.cwd was {str(new_cwd_dir)!r})"
    )
    # And it must have actually carried --resume <prior-eid>.
    assert "--resume" in spawn_argv
    assert spawn_argv[spawn_argv.index("--resume") + 1] == "prior-eid"
