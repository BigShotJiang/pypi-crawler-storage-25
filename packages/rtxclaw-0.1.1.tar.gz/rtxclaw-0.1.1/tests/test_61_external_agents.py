"""Step 61 — external coding-agent detection (`rtxclaw agents`).

Unit tests for ``default_scaffolds.detect_external_agents`` — the detect +
quick-install + configure feature: each known integration (Claude Code / Codex
/ Cursor / Antigravity) reports whether its CLI is on PATH and whether the
rtxclaw agent is configured on disk, plus a runnable install command.
"""
from __future__ import annotations

import shutil

from rtxclaw_core.agents import default_scaffolds as ds
import rtxclaw_core.agent as agentmod


def test_detect_external_agents(monkeypatch, tmp_path):
    monkeypatch.setattr(agentmod, "agents_root", lambda: tmp_path)
    # claude: installed + configured; codex: installed, not configured;
    # cursor/antigravity: neither.
    (tmp_path / "claude").mkdir()
    (tmp_path / "claude" / "config.json").write_text("{}")
    on_path = {"claude", "codex"}  # matched against each entry's cli_command
    monkeypatch.setattr(shutil, "which",
                        lambda c: f"/usr/bin/{c}" if c in on_path else None)

    rows = {r["short_name"]: r for r in ds.detect_external_agents()}
    assert set(rows) == {"claude", "codex", "cursor", "antigravity"}

    assert rows["claude"]["installed"] and rows["claude"]["configured"]
    assert rows["codex"]["installed"] and not rows["codex"]["configured"]
    # cursor's probe binary is "cursor-agent" (not "cursor") → not on path here
    assert rows["cursor"]["cli_command"] == "cursor-agent"
    assert not rows["cursor"]["installed"] and not rows["cursor"]["configured"]
    assert not rows["antigravity"]["installed"]

    # every entry carries a runnable install command + a human hint
    for r in rows.values():
        assert r["install_cmd"] and r["install_hint"]
    assert rows["codex"]["install_cmd"].startswith("npm install")
    assert rows["cursor"]["install_cmd"].startswith("curl ")


def test_external_agent_kinds_cover_the_four():
    kinds = ds.EXTERNAL_AGENT_KINDS
    shorts = {ds._KIND_DETAILS[k]["short_name"] for k in kinds}
    assert shorts == {"claude", "codex", "cursor", "antigravity"}
