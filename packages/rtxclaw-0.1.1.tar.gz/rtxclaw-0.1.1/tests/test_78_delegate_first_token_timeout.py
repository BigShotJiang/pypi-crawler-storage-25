"""Delegate CLI startup (first-token) timeout.

Regression coverage for the failure mode where `/claude` (or `/codex` /
`/antigravity`) from the main agent froze: the spawned CLI produced NO
output and the turn hung — claude until its 900s idle timer, codex and
antigravity forever (they had no read timeout) — so the operator saw a
dead turn and restarted the gateway.

The fix bounds the wait for the CLI's FIRST stream event separately
(`_delegate_readline` + `RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S`), so a
stalled startup fails fast with a clear error instead of a silent freeze.
"""

from __future__ import annotations

import asyncio
import os
import time

from rtxclaw_core.tools.runners import (
    _delegate_readline,
    run_delegate_antigravity_async,
    run_delegate_claude_async,
    run_delegate_codex_async,
)


class _HangReader:
    """A StreamReader stand-in whose readline() never returns."""

    async def readline(self) -> bytes:
        await asyncio.Event().wait()  # blocks forever
        return b""  # pragma: no cover


class _OneLineReader:
    """Returns one line, then blocks forever (mimics a CLI that emits an
    init event then stalls)."""

    def __init__(self, line: bytes) -> None:
        self._line = line
        self._sent = False

    async def readline(self) -> bytes:
        if self._sent:
            await asyncio.Event().wait()  # pragma: no cover
        self._sent = True
        return self._line


def test_delegate_readline_first_token_then_idle() -> None:
    async def run() -> None:
        hang = _HangReader()

        # Before the first event: bounded by the (tiny) first-token timeout.
        t0 = time.monotonic()
        try:
            await _delegate_readline(
                hang, got_first_event=False,
                first_token_timeout_s=0.05, idle_timeout_s=30.0,
            )
            raise AssertionError("expected TimeoutError on stalled startup")
        except asyncio.TimeoutError:
            pass
        assert time.monotonic() - t0 < 5.0, "did not use the short first-token bound"

        # After the first event: bounded by the idle timeout instead.
        t0 = time.monotonic()
        try:
            await _delegate_readline(
                hang, got_first_event=True,
                first_token_timeout_s=30.0, idle_timeout_s=0.05,
            )
            raise AssertionError("expected TimeoutError on idle stall")
        except asyncio.TimeoutError:
            pass
        assert time.monotonic() - t0 < 5.0, "did not switch to the idle bound"

        # A line that is available comes straight back.
        line = await _delegate_readline(
            _OneLineReader(b'{"x":1}\n'), got_first_event=False,
            first_token_timeout_s=1.0, idle_timeout_s=1.0,
        )
        assert line == b'{"x":1}\n'

    asyncio.run(run())


def _write_hanging_cli(tmp_path, name: str):
    """Create an executable `name` on a fresh bin dir that emits nothing
    and sleeps well past the test's first-token timeout."""
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir(exist_ok=True)
    script = fake_bin / name
    script.write_text(
        "#!/usr/bin/env python3\n"
        "import time, sys\n"
        "# Never read stdin, never emit a stream event — simulate a CLI\n"
        "# stalled in startup (hung SessionStart hook / auth / network).\n"
        "time.sleep(60)\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    return fake_bin


def _common_env(monkeypatch, tmp_path, fake_bin, sid: str) -> None:
    monkeypatch.setenv("PATH", f"{fake_bin}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.setenv("RTXCLAW_SESSION_ID", sid)
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(tmp_path / "sessions"))
    monkeypatch.setenv("RTXCLAW_AGENT_HOME", str(tmp_path / "agent"))
    monkeypatch.setenv("RTXCLAW_PERMISSION_MODE", "auto")
    # Fail fast: 1s instead of the 900s production default.
    monkeypatch.setenv("RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S", "1")
    (tmp_path / "sessions").mkdir(exist_ok=True)


def test_delegate_claude_startup_timeout(tmp_path, monkeypatch) -> None:
    fake_bin = _write_hanging_cli(tmp_path, "claude")
    _common_env(monkeypatch, tmp_path, fake_bin, "rtx-claude-stall")

    t0 = time.monotonic()
    result = asyncio.run(run_delegate_claude_async({"prompt": "confirm this"}))
    elapsed = time.monotonic() - t0

    assert result.ok is False
    assert "startup timeout" in result.content
    # Fast-fail: nowhere near the 900s idle window the freeze used to wait.
    assert elapsed < 20.0, f"runner took {elapsed:.1f}s — startup timeout did not fire"


def test_delegate_codex_startup_timeout(tmp_path, monkeypatch) -> None:
    fake_bin = _write_hanging_cli(tmp_path, "codex")
    _common_env(monkeypatch, tmp_path, fake_bin, "rtx-codex-stall")
    monkeypatch.setenv("RTXCLAW_AGENT_NAME", "scraper")

    t0 = time.monotonic()
    result = asyncio.run(run_delegate_codex_async({"prompt": "confirm this"}))
    elapsed = time.monotonic() - t0

    assert result.ok is False
    assert "startup timeout" in result.content
    assert elapsed < 20.0, f"runner took {elapsed:.1f}s — startup timeout did not fire"


def test_delegate_antigravity_startup_timeout(tmp_path, monkeypatch) -> None:
    fake_bin = _write_hanging_cli(tmp_path, "antigravity")
    _common_env(monkeypatch, tmp_path, fake_bin, "rtx-antigravity-stall")

    t0 = time.monotonic()
    result = asyncio.run(run_delegate_antigravity_async({"prompt": "confirm this"}))
    elapsed = time.monotonic() - t0

    assert result.ok is False
    assert "startup timeout" in result.content
    assert elapsed < 20.0, f"runner took {elapsed:.1f}s — startup timeout did not fire"
