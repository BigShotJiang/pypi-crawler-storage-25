"""Step 27 — System-prompt cache-boundary helper coverage.

The cache-boundary marker (``<!-- RTXCLAW_CACHE_BOUNDARY -->``)
splits the system prompt into a STABLE prefix (everything cached
across turns of a session) and a DYNAMIC suffix (refreshed on every
turn). The helpers in ``rtxclaw_core.system_prompt`` round-trip text
through that split — and they're directly mirrored from OpenClaw, so
even tiny semantic drift here breaks both projects' prefix-cache hit
rate.

Coverage:
- ``normalize_structured_prompt_section`` is idempotent and
  CRLF-stripping.
- ``split_system_prompt_cache_boundary`` returns None when no
  boundary is present.
- ``strip_system_prompt_cache_boundary`` reduces the marker to a
  single newline.
- ``prepend_system_prompt_addition_after_cache_boundary`` injects
  AFTER the boundary, ahead of the existing dynamic suffix, with
  exactly one blank line between addition and old suffix.
- Empty / non-string inputs degrade gracefully (no raises).
"""
from __future__ import annotations

import pytest

from rtxclaw_core.system_prompt import (
    SYSTEM_PROMPT_CACHE_BOUNDARY,
    normalize_structured_prompt_section,
    prepend_system_prompt_addition_after_cache_boundary,
    split_system_prompt_cache_boundary,
    strip_system_prompt_cache_boundary,
)


# ---- normalize_structured_prompt_section -----------------------------


def test_normalize_strips_crlf() -> None:
    inp = "line one\r\nline two\rline three"
    out = normalize_structured_prompt_section(inp)
    assert out == "line one\nline two\nline three"


def test_normalize_strips_trailing_whitespace_per_line() -> None:
    inp = "head  \nbody \t\nfoot"
    out = normalize_structured_prompt_section(inp)
    assert out == "head\nbody\nfoot"


def test_normalize_strips_outer_whitespace() -> None:
    inp = "   \n\n  body\n\n  "
    out = normalize_structured_prompt_section(inp)
    assert out == "body"


def test_normalize_idempotent() -> None:
    inp = "line one\r\nline two   \nline three"
    once = normalize_structured_prompt_section(inp)
    twice = normalize_structured_prompt_section(once)
    assert once == twice


def test_normalize_non_string_returns_empty() -> None:
    assert normalize_structured_prompt_section(None) == ""
    assert normalize_structured_prompt_section(42) == ""
    assert normalize_structured_prompt_section([]) == ""


# ---- split_system_prompt_cache_boundary ------------------------------


def test_split_returns_none_when_no_boundary() -> None:
    assert split_system_prompt_cache_boundary("just text") is None


def test_split_returns_two_halves() -> None:
    text = f"stable head{SYSTEM_PROMPT_CACHE_BOUNDARY}dynamic tail"
    out = split_system_prompt_cache_boundary(text)
    assert out is not None
    assert out["stable_prefix"] == "stable head"
    assert out["dynamic_suffix"] == "dynamic tail"


def test_split_strips_inner_whitespace() -> None:
    text = (
        f"prefix\n   \n{SYSTEM_PROMPT_CACHE_BOUNDARY}   \nsuffix"
    )
    out = split_system_prompt_cache_boundary(text)
    assert out is not None
    assert out["stable_prefix"] == "prefix"
    assert out["dynamic_suffix"] == "suffix"


def test_split_handles_only_first_marker() -> None:
    """If the prompt has more than one boundary, only the first is
    treated as the cut. Subsequent markers stay in the dynamic
    suffix verbatim."""
    text = (
        f"stable{SYSTEM_PROMPT_CACHE_BOUNDARY}"
        f"dynamic head{SYSTEM_PROMPT_CACHE_BOUNDARY}dynamic tail"
    )
    out = split_system_prompt_cache_boundary(text)
    assert out is not None
    assert out["stable_prefix"] == "stable"
    assert SYSTEM_PROMPT_CACHE_BOUNDARY in out["dynamic_suffix"]


# ---- strip_system_prompt_cache_boundary -----------------------------


def test_strip_replaces_marker_with_single_newline() -> None:
    text = f"a{SYSTEM_PROMPT_CACHE_BOUNDARY}b"
    assert strip_system_prompt_cache_boundary(text) == "a\nb"


def test_strip_no_boundary_unchanged() -> None:
    assert strip_system_prompt_cache_boundary("plain") == "plain"


# ---- prepend_system_prompt_addition_after_cache_boundary ------------


def test_addition_with_no_boundary_prepends_to_whole() -> None:
    """No boundary in the prompt → the addition leads with a blank
    line separator before the rest."""
    out = prepend_system_prompt_addition_after_cache_boundary(
        system_prompt="legacy body",
        system_prompt_addition="addition",
    )
    assert out == "addition\n\nlegacy body"


def test_addition_with_empty_addition_returns_unchanged() -> None:
    base = f"stable{SYSTEM_PROMPT_CACHE_BOUNDARY}dynamic"
    assert prepend_system_prompt_addition_after_cache_boundary(
        system_prompt=base,
        system_prompt_addition="",
    ) == base
    assert prepend_system_prompt_addition_after_cache_boundary(
        system_prompt=base,
        system_prompt_addition=None,
    ) == base


def test_addition_lands_after_boundary_before_dynamic_suffix() -> None:
    base = f"stable head{SYSTEM_PROMPT_CACHE_BOUNDARY}dynamic tail"
    out = prepend_system_prompt_addition_after_cache_boundary(
        system_prompt=base,
        system_prompt_addition="ADDED",
    )
    # Stable head + boundary + addition + double newline + dynamic tail.
    assert out.startswith("stable head")
    assert SYSTEM_PROMPT_CACHE_BOUNDARY in out
    # Order: ADDED comes BEFORE dynamic tail in the string.
    assert out.index("ADDED") < out.index("dynamic tail")
    # Stable head comes BEFORE ADDED.
    assert out.index("stable head") < out.index("ADDED")


def test_addition_with_empty_dynamic_suffix_becomes_suffix() -> None:
    """When the dynamic suffix is empty, the addition becomes the
    suffix (no trailing whitespace dance)."""
    base = f"stable{SYSTEM_PROMPT_CACHE_BOUNDARY}"
    out = prepend_system_prompt_addition_after_cache_boundary(
        system_prompt=base,
        system_prompt_addition="injected",
    )
    assert out == f"stable{SYSTEM_PROMPT_CACHE_BOUNDARY}injected"


def test_addition_normalises_input() -> None:
    """The addition runs through ``normalize_structured_prompt_section``
    — CRLFs and trailing whitespace are scrubbed."""
    base = f"stable{SYSTEM_PROMPT_CACHE_BOUNDARY}suffix"
    out = prepend_system_prompt_addition_after_cache_boundary(
        system_prompt=base,
        system_prompt_addition="messy   \r\nADDED  \r\n",
    )
    assert "messy\nADDED" in out
    assert "\r" not in out
