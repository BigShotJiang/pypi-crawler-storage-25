"""Step 53 — Per-agent API key secrets.

Production bug: ``OPENROUTER_API_KEY`` lived only inside
``~/.rtxclaw/config.json`` under ``mcp_servers.youtube.env``. That value
was injected only into the YouTube MCP subprocess; the gateway process
itself never saw it. ``cfg.upstream_headers()`` reads from
``os.environ`` only, came back empty, and the vision-model
transcription call to Kimi/OpenRouter 401'd ("No cookie auth
credentials found").

Beyond that bug, the operator needs DIFFERENT keys per agent so
provider-side dashboards (OpenRouter spend, OpenAI Project usage,
Anthropic Workspace limits, …) attribute traffic to the right agent.

Resolution order (highest precedence first):

  1. ``~/.rtxclaw/agents/<agent>/secrets.env`` — per-agent override
  2. ``~/.rtxclaw/secrets.env`` — shared fallback
  3. ``os.environ`` — anything systemd / shell injected

The lookup happens in ``AgentConfig.upstream_headers()``; loading is in
``AgentConfig.load()``. An ``audit_api_keys()`` helper returns the
resolution status per ``models[]`` row so the gateway can log a
single line at boot ("OPENROUTER_API_KEY=✓(agent-local) …") and
catch the kimi-style bug on the next restart, not the first 401.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# _parse_dotenv
# ---------------------------------------------------------------------------


def test_parse_dotenv_handles_quotes_comments_export() -> None:
    from rtxclaw_core.agent import _parse_dotenv
    text = """
# comment
OPENROUTER_API_KEY=sk-or-v1-plain
export OPENAI_API_KEY="sk-quoted"
ANTHROPIC_API_KEY='sk-single'
   XAI_API_KEY=sk-with-leading-space
EMPTY=
NO_VALUE
"""
    out = _parse_dotenv(text)
    assert out["OPENROUTER_API_KEY"] == "sk-or-v1-plain"
    assert out["OPENAI_API_KEY"] == "sk-quoted"
    assert out["ANTHROPIC_API_KEY"] == "sk-single"
    assert out["XAI_API_KEY"] == "sk-with-leading-space"
    assert out["EMPTY"] == ""
    assert "NO_VALUE" not in out


# ---------------------------------------------------------------------------
# _load_agent_secrets — shared fallback + per-agent override
# ---------------------------------------------------------------------------


def test_load_agent_secrets_merges_shared_and_per_agent(tmp_path: Path) -> None:
    """Per-agent values WIN over shared. Shared keys missing from
    per-agent FALL BACK to shared. Operator can keep common keys in
    shared and only override per-agent for the ones they want billed
    separately."""
    from rtxclaw_core.agent import _load_agent_secrets

    (tmp_path / "secrets.env").write_text(
        "OPENROUTER_API_KEY=shared-or\n"
        "OPENAI_API_KEY=shared-oai\n"
        "DEEPSEEK_API_KEY=shared-ds\n",
        encoding="utf-8",
    )
    agent_dir = tmp_path / "agents" / "main"
    agent_dir.mkdir(parents=True)
    (agent_dir / "secrets.env").write_text(
        "OPENROUTER_API_KEY=main-specific-or\n"
        "ANTHROPIC_API_KEY=main-specific-anth\n",
        encoding="utf-8",
    )

    out = _load_agent_secrets(tmp_path, "main")
    # Per-agent overrides shared.
    assert out["OPENROUTER_API_KEY"] == "main-specific-or"
    # Shared fallback for keys not in per-agent.
    assert out["OPENAI_API_KEY"] == "shared-oai"
    assert out["DEEPSEEK_API_KEY"] == "shared-ds"
    # Keys only in per-agent.
    assert out["ANTHROPIC_API_KEY"] == "main-specific-anth"


def test_load_agent_secrets_missing_files_returns_empty(tmp_path: Path) -> None:
    from rtxclaw_core.agent import _load_agent_secrets
    assert _load_agent_secrets(tmp_path, "main") == {}


def test_load_agent_secrets_per_agent_only(tmp_path: Path) -> None:
    """If no shared secrets.env exists, per-agent works alone."""
    from rtxclaw_core.agent import _load_agent_secrets
    agent_dir = tmp_path / "agents" / "coder"
    agent_dir.mkdir(parents=True)
    (agent_dir / "secrets.env").write_text(
        "OPENROUTER_API_KEY=coder-only\n",
        encoding="utf-8",
    )
    out = _load_agent_secrets(tmp_path, "coder")
    assert out == {"OPENROUTER_API_KEY": "coder-only"}


# ---------------------------------------------------------------------------
# upstream_headers — precedence
# ---------------------------------------------------------------------------


def _make_cfg(api_keys: dict[str, str]):
    """Minimal AgentConfig with a single OpenRouter row referencing
    OPENROUTER_API_KEY, with the given api_keys map."""
    from rtxclaw_core.agent import AgentConfig
    cfg = AgentConfig(
        name="main",
        upstream_endpoint="https://openrouter.ai/api/v1",
        upstream_model="moonshotai/kimi-k2.6",
        models=[{
            "alias": "kimi",
            "baseUrl": "https://openrouter.ai/api/v1",
            "id": "moonshotai/kimi-k2.6",
            "apiKeyEnv": "OPENROUTER_API_KEY",
        }],
        api_keys=dict(api_keys),
    )
    return cfg


def test_upstream_headers_prefers_api_keys_over_env(monkeypatch) -> None:
    """Per-agent api_keys must WIN over os.environ — that's how the
    operator gets per-agent cost attribution against the same provider."""
    cfg = _make_cfg({"OPENROUTER_API_KEY": "AGENT-LOCAL-KEY"})
    monkeypatch.setenv("OPENROUTER_API_KEY", "PROCESS-ENV-KEY")
    headers = cfg.upstream_headers()
    assert headers.get("Authorization") == "Bearer AGENT-LOCAL-KEY"


def test_upstream_headers_falls_back_to_env_when_api_keys_empty(
    monkeypatch,
) -> None:
    cfg = _make_cfg({})
    monkeypatch.setenv("OPENROUTER_API_KEY", "PROCESS-ENV-KEY")
    headers = cfg.upstream_headers()
    assert headers.get("Authorization") == "Bearer PROCESS-ENV-KEY"


def test_upstream_headers_no_key_no_authorization(monkeypatch) -> None:
    """Neither agent secrets nor env → no Authorization header (and the
    boot audit / startup warning will have flagged this)."""
    cfg = _make_cfg({})
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    headers = cfg.upstream_headers()
    assert "Authorization" not in headers


# ---------------------------------------------------------------------------
# audit_api_keys — boot-time visibility
# ---------------------------------------------------------------------------


def test_audit_api_keys_reports_per_row_status(monkeypatch) -> None:
    from rtxclaw_core.agent import AgentConfig

    cfg = AgentConfig(
        name="main",
        upstream_endpoint="http://local",
        upstream_model="local-model",
        models=[
            # Row 1: key in api_keys (per-agent file)
            {"alias": "kimi", "baseUrl": "https://openrouter.ai/api/v1",
             "id": "moonshotai/kimi-k2.6", "apiKeyEnv": "OPENROUTER_API_KEY"},
            # Row 2: key only in env
            {"alias": "grok", "baseUrl": "https://api.x.ai/v1",
             "id": "grok-4.3", "apiKeyEnv": "XAI_API_KEY"},
            # Row 3: declared but missing everywhere
            {"alias": "anth", "baseUrl": "https://api.anthropic.com/v1",
             "id": "claude-opus-4-7", "apiKeyEnv": "ANTHROPIC_API_KEY"},
            # Row 4: no apiKeyEnv at all (local / no auth)
            {"alias": "tb07", "baseUrl": "http://192.168.0.70:8001/v1",
             "id": "qwen3.6-27b-fp8"},
        ],
        api_keys={"OPENROUTER_API_KEY": "agent-local"},
    )
    monkeypatch.setenv("XAI_API_KEY", "env-only")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    audit = cfg.audit_api_keys()
    assert audit["OPENROUTER_API_KEY"] == "agent-local"
    assert audit["XAI_API_KEY"] == "env"
    assert audit["ANTHROPIC_API_KEY"] == "missing"
    # No-auth rows must NOT pollute the audit dict.
    assert all(
        k in ("OPENROUTER_API_KEY", "XAI_API_KEY", "ANTHROPIC_API_KEY")
        for k in audit
    )
