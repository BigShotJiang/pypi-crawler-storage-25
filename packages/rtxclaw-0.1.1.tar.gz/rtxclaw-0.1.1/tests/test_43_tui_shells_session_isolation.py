"""Step 43 — Shells widget MUST be session-scoped.

The Shells panel (``MonitorPanelModal``, opened via ``Ctrl+S`` /
``/shells`` / ``/monitors``) reads its row list from one specific
sidecar file: ``<sessions_dir>/<sid>.monitors.json``. Two different
rtxclaw sessions land their monitor metadata in two different
files; the panel for session A must NEVER show session B's shells
(or vice versa), and killing a monitor in one session's panel
must NOT touch the other session's sidecar.

This regression pins both invariants. The cross-pollination class
of bug would happen if someone refactored the sidecar to a
shared-per-agent file, or if the panel started reading by glob
instead of by exact path. The tests would fail loudly in either
case.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.tools.monitor import (  # noqa: E402
    live_monitors_for_session,
    load_sidecar,
)


def _write_sidecar(sessions_dir: Path, sid: str,
                   entries: list[dict[str, Any]]) -> Path:
    """Write a synthetic sidecar for ``sid`` and return its path.

    The entries use the CURRENT Python interpreter's PID so
    ``os.kill(pid, 0)`` reports them alive — that exercises the
    code path that filters by liveness, NOT the easier path that
    short-circuits on dead PIDs."""
    path = sessions_dir / f"{sid}.monitors.json"
    path.write_text(json.dumps(entries, indent=2) + "\n", encoding="utf-8")
    return path


def _entry(monitor_id: str, sid_label: str) -> dict[str, Any]:
    """Build a synthetic monitor entry tagged with which session it
    belongs to in the ``command`` field — makes assertion failures
    easy to read."""
    return {
        "monitor_id": monitor_id,
        "command": f"# belongs to {sid_label}",
        "cwd": "/tmp",
        "pid": os.getpid(),
        "started_at": time.time(),
        "exit_code": None,
        "log_path": f"/tmp/test-{monitor_id}.log",
        "read_cursor": 0,
    }


def test_two_sessions_see_disjoint_shells(tmp_path: Path) -> None:
    """The fundamental invariant: session A and session B share
    ``sessions_dir`` but their sidecar files name themselves apart,
    and ``live_monitors_for_session`` reads only the file matching
    its ``session_id`` argument."""
    _write_sidecar(tmp_path, "sessionA", [
        _entry("monA1", "A"),
        _entry("monA2", "A"),
    ])
    _write_sidecar(tmp_path, "sessionB", [
        _entry("monB1", "B"),
    ])

    rows_a = live_monitors_for_session(tmp_path, "sessionA")
    rows_b = live_monitors_for_session(tmp_path, "sessionB")

    ids_a = {r["monitor_id"] for r in rows_a}
    ids_b = {r["monitor_id"] for r in rows_b}
    assert ids_a == {"monA1", "monA2"}, ids_a
    assert ids_b == {"monB1"}, ids_b
    assert ids_a.isdisjoint(ids_b), f"cross-leak: {ids_a & ids_b!r}"


def test_unknown_session_sees_no_shells(tmp_path: Path) -> None:
    """A session that has never spawned a monitor (no sidecar file)
    returns an empty list — NOT all monitors in the directory."""
    _write_sidecar(tmp_path, "sessionA", [_entry("monA1", "A")])
    rows = live_monitors_for_session(tmp_path, "sessionC-never-existed")
    assert rows == [], rows


def test_killing_in_one_session_leaves_other_intact(tmp_path: Path) -> None:
    """The Shells panel's ``x`` (kill) action and the drop-on-dead
    cleanup both operate on the SELECTED row's session sidecar. A
    killed monitor in session A's sidecar must NOT cascade to
    session B's sidecar — they're entirely independent files."""
    path_a = _write_sidecar(tmp_path, "sessionA", [
        _entry("monA1", "A"),
        _entry("monA2", "A"),
    ])
    path_b = _write_sidecar(tmp_path, "sessionB", [
        _entry("monB1", "B"),
    ])

    # Simulate the panel's drop-dead action on session A: rewrite A's
    # sidecar without monA1 (this mirrors
    # ``MonitorPanelModal._drop_dead_entry`` line 2147).
    data_a = json.loads(path_a.read_text(encoding="utf-8"))
    keep = [e for e in data_a if e.get("monitor_id") != "monA1"]
    path_a.write_text(json.dumps(keep, indent=2) + "\n", encoding="utf-8")

    rows_a = live_monitors_for_session(tmp_path, "sessionA")
    rows_b = live_monitors_for_session(tmp_path, "sessionB")
    assert {r["monitor_id"] for r in rows_a} == {"monA2"}
    assert {r["monitor_id"] for r in rows_b} == {"monB1"}, (
        "killing in session A's sidecar leaked into session B"
    )


def test_sidecar_filename_is_exact_match_not_prefix(tmp_path: Path) -> None:
    """Defensive: a session id that is a PREFIX of another session id
    must NOT see the longer session's monitors. (E.g. ``abc`` must
    not pull in ``abc123``.) ``load_sidecar(path)`` is exact-path,
    so this invariant follows from the filename naming convention
    — but pin it in case anyone ever replaces the lookup with a
    glob or fuzzy match."""
    _write_sidecar(tmp_path, "abc", [_entry("monShort", "abc")])
    _write_sidecar(tmp_path, "abc123", [_entry("monLong", "abc123")])
    short = live_monitors_for_session(tmp_path, "abc")
    long_ = live_monitors_for_session(tmp_path, "abc123")
    assert {r["monitor_id"] for r in short} == {"monShort"}
    assert {r["monitor_id"] for r in long_} == {"monLong"}


def test_load_sidecar_returns_empty_for_missing_file(tmp_path: Path) -> None:
    """``load_sidecar`` is the lowest-level reader. A missing file
    returns ``[]`` — NOT a directory listing, NOT an error. This is
    what makes ``live_monitors_for_session`` safe to call from the
    panel before any monitor has ever been spawned in that session."""
    rows = load_sidecar(tmp_path / "no-such-session.monitors.json")
    assert rows == []
