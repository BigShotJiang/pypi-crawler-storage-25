"""Step 31 — ``read_file`` line-range slicing contract.

The runner used to ignore ``start_line`` / ``end_line`` entirely:
the schema didn't even declare them, so when the model passed a
slice request (``start_line=6430, end_line=6475``) the runtime
silently dropped the args and returned the whole file (capped at
``MAX_OUTPUT_BYTES``). That blew the model's context with up to
64 KB of unrelated source on every "read 45 lines" call, and on
small models it caused outright topic drift — one rtxclaw session
dumped the whole TUI ``app.py`` four times in a row, blew prompt
tokens past 110K, and the model hallucinated an entirely different
task between rounds.

These tests pin the new slicing contract so it can't silently
regress:

* Schema declares both ``start_line`` and ``end_line``.
* Runner returns only the requested 1-based inclusive range.
* String-coerced ints are accepted (the upstream tokenizer often
  emits them as quoted strings — exact behaviour from the original
  failing session).
* Invalid ranges (zero, negative, end < start) are rejected with
  a clean ``error: …`` message instead of producing garbage.
* Beyond-EOF slices return empty content, not an error.
* No-args call still reads the whole file (back-compat).
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_core.tools import BUILTIN_TOOLS
from rtxclaw_core.tools.runners import run_read_file


@pytest.fixture
def sample_file(tmp_path: Path) -> Path:
    """100-line file with each line containing its own 1-based index."""
    p = tmp_path / "sample.txt"
    p.write_text("\n".join(f"line-{i:03d}" for i in range(1, 101)) + "\n")
    return p


# ---- schema --------------------------------------------------------


def test_schema_declares_offset_and_limit() -> None:
    rf = next(t for t in BUILTIN_TOOLS if t.name == "Read")
    props = rf.parameters["properties"]
    # Claude Code's ``Read`` shape: ``file_path`` + ``offset`` (1-based
    # start line) + ``limit`` (lines to read). Without these declared
    # the upstream validator drops them as ``additionalProperties``.
    assert "file_path" in props
    assert "offset" in props
    assert "limit" in props
    assert props["offset"]["type"] == "integer"
    assert props["limit"]["type"] == "integer"


# ---- happy path ----------------------------------------------------


def test_full_file_read_unchanged(sample_file: Path) -> None:
    r = run_read_file({"path": str(sample_file)})
    assert r.ok
    lines = r.content.splitlines()
    assert lines[0] == "line-001"
    assert lines[-1] == "line-100"
    assert len(lines) == 100


def test_slice_returns_inclusive_range(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "start_line": 10,
        "end_line": 12,
    })
    assert r.ok
    assert r.content == "line-010\nline-011\nline-012\n"


def test_start_line_only_reads_to_eof(sample_file: Path) -> None:
    r = run_read_file({"path": str(sample_file), "start_line": 98})
    assert r.ok
    assert r.content == "line-098\nline-099\nline-100\n"


def test_end_line_only_reads_from_top(sample_file: Path) -> None:
    r = run_read_file({"path": str(sample_file), "end_line": 3})
    assert r.ok
    assert r.content == "line-001\nline-002\nline-003\n"


def test_string_coerced_ints_accepted(sample_file: Path) -> None:
    """The failing session passed start_line/end_line as strings
    (``"6430"`` / ``"6475"``). Tolerate that — it's a common upstream
    tokenizer quirk and there's no upside to rejecting it."""
    r = run_read_file({
        "path": str(sample_file),
        "start_line": "5",
        "end_line": "7",
    })
    assert r.ok
    assert r.content == "line-005\nline-006\nline-007\n"


def test_single_line_slice(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "start_line": 42,
        "end_line": 42,
    })
    assert r.ok
    assert r.content == "line-042\n"


# ---- edge cases ---------------------------------------------------


def test_beyond_eof_returns_empty(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "start_line": 9999,
        "end_line": 10000,
    })
    assert r.ok
    assert r.content == ""


def test_end_line_past_eof_returns_available(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "start_line": 99,
        "end_line": 9999,
    })
    assert r.ok
    assert r.content == "line-099\nline-100\n"


# ---- validation ----------------------------------------------------


def test_zero_offset_rejected(sample_file: Path) -> None:
    r = run_read_file({"path": str(sample_file), "offset": 0})
    assert not r.ok
    assert "offset must be >= 1" in r.content


def test_negative_line_rejected(sample_file: Path) -> None:
    r = run_read_file({"path": str(sample_file), "end_line": -3})
    assert not r.ok
    assert "end_line must be >= 1" in r.content


def test_end_before_start_rejected(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "offset": 50,
        "end_line": 10,
    })
    assert not r.ok
    assert "must be >= offset" in r.content


def test_non_integer_offset_rejected(sample_file: Path) -> None:
    r = run_read_file({
        "path": str(sample_file),
        "offset": "not-a-number",
    })
    assert not r.ok
    assert "offset must be an integer" in r.content


# ---- regression: the exact failing call from session 69fc4fdb ----


def test_repro_app_py_pm_synth_slice() -> None:
    """The original failure: the model asked for ``app.py`` lines
    around the ``pm_synth`` definition. The runner returned the whole
    file (capped to 64KB) and the small model lost the thread. After
    the fix, the slice should fit inside one screen — not flood context.

    The exact line numbers drift as ``app.py`` grows; we resolve them
    dynamically by grepping for the ``pm_synth`` token so the test
    keeps verifying the slicing contract instead of stale coordinates.
    """
    repo_root = Path(__file__).resolve().parents[1]
    app_py = repo_root / "src" / "rtxclaw_tui" / "app.py"
    if not app_py.exists():
        pytest.skip(f"{app_py} not present in this checkout")
    text = app_py.read_text(encoding="utf-8")
    lines = text.splitlines()
    pm_synth_line = next(
        (i + 1 for i, ln in enumerate(lines) if "pm_synth = pm_inner" in ln),
        None,
    )
    if pm_synth_line is None:
        pytest.skip("pm_synth subparser definition not found in app.py")
    start_line = pm_synth_line
    end_line = pm_synth_line + 31  # ~32-line window matches original repro
    r = run_read_file({
        "path": str(app_py),
        "start_line": start_line,
        "end_line": end_line,
    })
    assert r.ok
    # The slice must be small enough that it doesn't drown context:
    # 32 lines is ~1.2KB, well under MAX_OUTPUT_BYTES (64KB).
    assert len(r.content) < 4096, (
        f"slice came back too large ({len(r.content)} bytes) — "
        "did the runner stop honouring start_line/end_line again?"
    )
    # The pm_synth subparser definition lives in this range:
    assert "pm_synth" in r.content
    assert "synth" in r.content
