from __future__ import annotations

from rtxclaw_core.turn_runtime import (
    _detect_entropy_collapse,
    _detect_loops_layered,
    _detect_tight_loop,
)


def _unique_pad(n: int) -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    out: list[str] = []
    i = 0
    while len("".join(out)) < n:
        out.append(alphabet[i % len(alphabet):] + alphabet[:i % len(alphabet)])
        i += 1
    return "".join(out)[:n]


def test_tight_loop_catches_short_token_collapse() -> None:
    buf = _unique_pad(96) + "la la la " * 16
    hit = _detect_tight_loop(buf)
    assert hit is not None
    assert "la" in hit


def test_tight_loop_ignores_short_markdown_rule() -> None:
    """Replaces the old test_tight_loop_ignores_markdown_rule_noise.

    A short `====` markdown rule (<= 80 chars stripped) must remain
    a false positive carve-out (it never reaches the tight tier's
    own min_context_chars threshold). A long unary run is no longer
    markdown — it is degenerate output.
    """
    # 79 chars of `=` → buffer total just under tight's 80-char floor
    short_rule = "intro paragraph. " + ("=" * 60)
    assert _detect_tight_loop(short_rule) is None


def test_entropy_detector_catches_low_entropy_multichar_loop() -> None:
    buf = ("abcx " * 50) + ("xyza " * 50)
    hit = _detect_entropy_collapse(buf)
    assert hit is not None
    assert hit.startswith("H=")


def test_entropy_detector_catches_collapse_for_ascii_chars() -> None:
    """Regression — ASCII chars `-=*#_~` are NOT in _RULE_CHARS (each is
    a documented Qwen/Gemma FP8-KV collapse mode). Long unary runs of
    these must fire through the entropy tier. The pre-fix carve-out
    silently exempted them; the round-2 audit (codex F1 / gemini F5)
    narrowed _RULE_CHARS to box-drawing + middle-dot variants only.
    """
    for ch in "=*#_~-":
        hit = _detect_entropy_collapse(ch * 240)
        assert hit is not None, f"unary {ch!r}*240 entropy collapse must fire"


def test_entropy_detector_ignores_box_drawing_rules() -> None:
    """Box-drawing horizontals ARE in _RULE_CHARS — long markdown rules
    are presentation chrome, not collapse. The user-reported false
    positive (`tier=tight evidence='────────'`) was the trigger for
    this carve-out.
    """
    for ch in "─━═·•":
        assert _detect_entropy_collapse(ch * 240) is None, (
            f"box-drawing/middle-dot run {ch!r}*240 must be carved out"
        )


def test_layered_no_fp_on_user_reported_horizontal_rule() -> None:
    """Pins the user's EXACT production reproducer at the layered-
    dispatcher level. Round-3 audit (codex + gemini) both asked for
    this — the existing `test_entropy_detector_ignores_box_drawing_rules`
    only hits the entropy tier, so a regression in `_detect_tight_loop`
    or `_detect_reasoning_loop` rule-run handling would silently slip
    through. This test exercises the FULL path the production TUI
    traversed:

        ⚠ loop detected — pausing worker · tier=tight · evidence='────────'

    Must return None on every detector tier across both content and
    thinking channels for every rule-char variant the user could emit.
    """
    for ch in "─━═·•":
        for n in (8, 60, 80, 240, 500):
            for channel in ("content", "thinking", ""):
                hit = _detect_loops_layered(ch * n, channel=channel)
                assert hit is None, (
                    f"user FP regressed: {ch!r}*{n} on channel={channel!r} "
                    f"tripped {hit!r}"
                )

    # Also exercise the "rule embedded in prose" shape (the actual
    # shape the user's model emitted — markdown rule BETWEEN paragraphs).
    for tail in ("─" * 80, "═" * 100):
        buf = "Section A. " * 5 + "\n\n" + tail + "\n\nSection B."
        assert _detect_loops_layered(buf, channel="content") is None, (
            f"rule-between-prose tripped: tail={tail[:8]!r}*{len(tail)}"
        )


def test_layered_detector_reports_tight_before_entropy() -> None:
    hit = _detect_loops_layered(_unique_pad(96) + "tokenxyz " * 20)
    assert hit is not None
    tier, evidence = hit
    assert tier == "tight"
    assert evidence


def test_tight_loop_catches_single_char_collapse() -> None:
    """Qwen3.6+FP8-KV token-collapse pattern — `!`×N — must fire.

    Field reference: opencode#25129, QwenLM/Qwen3.6#145.
    """
    buf = _unique_pad(96) + "!" * 240
    hit = _detect_tight_loop(buf)
    assert hit is not None, "single-char `!` collapse must trip tight tier"


def test_tight_loop_catches_two_char_alternation() -> None:
    """Token-collapse can also rotate two glyphs, e.g. `!?` × N."""
    buf = _unique_pad(96) + "!?" * 120
    hit = _detect_tight_loop(buf)
    assert hit is not None


def test_tight_loop_catches_long_markdown_rule_like_output() -> None:
    """A 240-char `=` run is no longer 'markdown chrome', it is
    indistinguishable from token collapse. Catching this is correct,
    and the field bug shape (`!` × N) requires this carve-out to lift.
    """
    buf = _unique_pad(96) + "=" * 240
    assert _detect_tight_loop(buf) is not None


def test_entropy_detector_catches_single_char_collapse() -> None:
    """All-`!` is the lowest-entropy possible signal — must fire."""
    hit = _detect_entropy_collapse("!" * 240)
    assert hit is not None
    assert hit.startswith("H=")


def test_bigram_entropy_detector_catches_single_char_collapse() -> None:
    """Bigram entropy of all-`!` is also degenerate."""
    from rtxclaw_core.turn_runtime import _detect_bigram_entropy_collapse
    hit = _detect_bigram_entropy_collapse("!" * 240)
    assert hit is not None
    assert hit.startswith("H2=")


def test_entropy_detector_layered_catches_unary_collapse() -> None:
    """End-to-end: long all-`!` reaches the layered dispatcher."""
    hit = _detect_loops_layered(_unique_pad(2000) + "!" * 400)
    assert hit is not None
    tier, _evidence = hit
    assert tier in ("tight", "ngram", "entropy", "entropy_bigram")


def test_entropy_detector_catches_two_char_alternation() -> None:
    """`!?` * 100 is bigram-entropy degenerate (~1.0 bit). The
    existing `entropy < LOOP_ENTROPY_BITS` (2.5) check catches it.
    """
    hit = _detect_entropy_collapse("!?" * 100)
    assert hit is not None
    layered = _detect_loops_layered("!?" * 100)
    assert layered is not None


def test_session_6a0c3398_buffer_is_caught() -> None:
    """Regression for session 6a0c33987d2ea638e7000004 — Qwen3.6 on
    TB01:8001 emitted 3308 consecutive `!` after legitimate reasoning.
    All four detector tiers returned None. After this fix the layered
    dispatcher must hit on tight, ngram, entropy, or bigram_entropy.
    """
    legit_reasoning = (
        "The user is asking about GPU specs on TB01 and TB06 and what "
        "their gen TPS would be. From MEMORY.md, both have RTX 3090x2 "
        "running vLLM with qwen3.6-27b at TP=2. Let me search for this."
    )
    buf = legit_reasoning + "\n" + ("!" * 3300)
    hit = _detect_loops_layered(buf)
    assert hit is not None
    tier, _evidence = hit
    assert tier in ("tight", "ngram", "entropy", "entropy_bigram")


# --- T10: structured-content carve-out -----------------------------------


def test_layered_no_fp_on_markdown_table() -> None:
    table = "| Name | Age | City |\n|------|-----|------|\n" + "".join(
        f"| {n} | {a} | {c} |\n"
        for n, a, c in [
            ("Alice", 30, "NYC"), ("Bob", 25, "LA"), ("Carol", 35, "Chi"),
            ("Dave", 40, "SF"), ("Eve", 28, "Bos"), ("Frank", 33, "Sea"),
        ] * 5
    )
    assert _detect_loops_layered(table, channel="content") is None


def test_layered_no_fp_on_status_table() -> None:
    table = "| Server | Status | Latency |\n|---|---|---|\n" + "".join(
        f"| TB0{i%9+1} | OK | OK |\n" for i in range(30)
    )
    assert _detect_loops_layered(table, channel="content") is None


def test_layered_no_fp_on_varied_fenced_code() -> None:
    code = "```python\n" + (
        "def foo():\n    return 1\n\n"
        "def bar():\n    return 2\n\n"
        "def baz():\n    return 3\n\n"
    ) * 8 + "```\n"
    assert _detect_loops_layered(code, channel="content") is None


def test_layered_no_fp_on_fenced_ok_list() -> None:
    code = "```python\nitems = [\n" + ('    "ok",\n' * 60) + "]\n```\n"
    assert _detect_loops_layered(code, channel="content") is None


def test_layered_no_fp_on_varied_bullet_list() -> None:
    """Round-4 user case — bullet list with unique items."""
    bullets = (
        "- TB01-WS\n- TB02-WS\n- TB03-WS\n- TB04-WS\n- TB05-WS\n"
        "- TB06-WS\n- TB07-WS\n- TB08-WS\n- TB09-WS\n- TB10-WS\n"
        "- TB11-WS\n- TB12-WS\n"
    ) * 4
    assert _detect_loops_layered(bullets, channel="content") is None


def test_layered_catches_identical_bullets() -> None:
    """`- ok` × 60 is single-stripped-line degeneracy."""
    assert _detect_loops_layered("- ok\n" * 60, channel="content") is not None


def test_layered_no_fp_on_numbered_list() -> None:
    items = "".join(f"{i+1}. completed\n" for i in range(40))
    assert _detect_loops_layered(items, channel="content") is None


def test_layered_no_fp_on_dict_enabled() -> None:
    code = "```python\ncfg = {\n" + "".join(
        f'    "key_{i:02d}": "enabled",\n' for i in range(40)
    ) + "}\n```\n"
    assert _detect_loops_layered(code, channel="content") is None


def test_layered_no_fp_on_closed_fence_mermaid() -> None:
    """Round-4 user case — Mermaid diagram after closing fence."""
    diagram = "```mermaid\ngraph TD\n" + (
        "    A --> B\n    B --> C\n    C --> A\n"
    ) * 20 + "```\n"
    assert _detect_loops_layered(diagram, channel="content") is None


def test_layered_no_fp_on_sql_values() -> None:
    code = "```sql\nINSERT INTO logs VALUES\n" + "".join(
        f"  ('2026-{(i%12)+1:02d}-01', 'ok'),\n" for i in range(50)
    ) + ";\n```\n"
    assert _detect_loops_layered(code, channel="content") is None


def test_layered_no_fp_on_ascii_tree() -> None:
    tree = "```\n" + (
        "src/\n├── core/\n│   ├── a.py\n│   ├── b.py\n│   └── c.py\n"
        "├── tests/\n│   ├── a.py\n│   └── b.py\n"
    ) * 8 + "```\n"
    assert _detect_loops_layered(tree, channel="content") is None


def test_layered_catches_collapse_after_legit_prose() -> None:
    """Canary: legit prose then `!`*3000 must still fire — tail has
    no newlines so the carve-out's >=2 newlines hard-reject blocks it.
    """
    buf = "Normal reasoning. " * 100 + "!" * 3000
    assert _detect_loops_layered(buf, channel="content") is not None


def test_layered_catches_pure_collapse() -> None:
    """`!` * 3000 with no newlines → carve-out hard-rejects."""
    assert _detect_loops_layered("!" * 3000, channel="content") is not None
