"""Step 91 — ``/sessions`` ordering + displayed age.

``list_sessions_acp`` is the single source of truth behind every
``/sessions`` surface (TUI picker, Telegram list, ``rtxclaw session
list``). The contract the operator sees:

  * sessions come back **newest last-turn activity first**, and
  * the timestamp the UIs render as the relative age (``updatedAt``)
    reflects that **last activity**, not the session's creation time.

The old code stamped ``updatedAt`` with ``created_at``, so a session
last touched 1 min ago but created weeks ago rendered "weeks ago" and
sat at the top — a correctly *ordered* list that *looked* shuffled.
These tests pin both the order and the age field.

Pure-Python: rows are inserted straight into ``sessions_meta`` (no
JSONL), and ``refresh()`` only tails grown ``.jsonl`` files, so the
directly-seeded rows survive the read path.
"""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_agent.acp_bridge import list_sessions_acp  # noqa: E402
from rtxclaw_core.session_index import (  # noqa: E402
    SessionIndex,
    connect_sessions_db,
)


def _seed(home: Path, rows: list[dict]) -> None:
    """Create the schema and insert rows directly into sessions_meta."""
    SessionIndex(home)  # creates sessions/ + sessions.db + schema
    db = home / "sessions" / "sessions.db"
    con = connect_sessions_db(db)
    try:
        for r in rows:
            con.execute(
                "INSERT INTO sessions_meta "
                "(session_hash, created_at, title, workspace_cwd, "
                " last_turn_idx, last_turn_ts, updated_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (
                    r["sid"], r["created_at"], r["title"], str(home),
                    r["last_turn_idx"], r["last_turn_ts"], r["updated_at"],
                ),
            )
        con.commit()
    finally:
        con.close()


# Deliberately make creation-order DIFFER from activity-order so a sort
# by created_at can never accidentally pass these tests.
#
#   sid  created_at (ISO)         last activity (ms epoch)
#   A    2026-01-01 (oldest)      1_779_000_000_000 (newest)
#   B    2026-05-22 (newest)      1_778_000_000_000 (middle)
#   C    2026-03-15 (middle)      1_777_000_000_000 (oldest)
_ROWS = [
    {"sid": "aaaaaaaa", "title": "alpha",
     "created_at": "2026-01-01T00:00:00+00:00",
     "last_turn_idx": 5, "last_turn_ts": 1_779_000_000_000,
     "updated_at": 1_779_000_000_000},
    {"sid": "bbbbbbbb", "title": "bravo",
     "created_at": "2026-05-22T00:00:00+00:00",
     "last_turn_idx": 3, "last_turn_ts": 1_778_000_000_000,
     "updated_at": 1_778_000_000_000},
    {"sid": "cccccccc", "title": "charlie",
     "created_at": "2026-03-15T00:00:00+00:00",
     "last_turn_idx": 9, "last_turn_ts": 1_777_000_000_000,
     "updated_at": 1_777_000_000_000},
]


def test_sessions_ordered_by_last_activity_newest_first(tmp_path: Path) -> None:
    _seed(tmp_path, _ROWS)
    out = list_sessions_acp(tmp_path / "sessions", tmp_path)
    order = [s["sessionId"] for s in out["sessions"]]
    # By last activity: A (newest) > B > C. By created_at it would be
    # B > C > A — so this order proves the sort key is activity, not
    # creation.
    assert order == ["aaaaaaaa", "bbbbbbbb", "cccccccc"], order


def test_updated_at_reflects_last_activity_not_creation(tmp_path: Path) -> None:
    _seed(tmp_path, _ROWS)
    out = list_sessions_acp(tmp_path / "sessions", tmp_path)
    sessions = out["sessions"]

    def _dt(s: dict) -> datetime:
        return datetime.fromisoformat(s["updatedAt"])

    # The rendered age field must be strictly DESCENDING down the list:
    # the top session is the most recently active. Under the old
    # ``updatedAt = created_at`` behaviour the values would be
    # Jan(A) < Mar(C) < May(B) — not monotonic with the row order —
    # so this catches the regression.
    dts = [_dt(s) for s in sessions]
    assert dts[0] > dts[1] > dts[2], [s["updatedAt"] for s in sessions]

    # And concretely: session A was created in January but last active
    # in May, so its age field must NOT be its creation timestamp.
    by_sid = {s["sessionId"]: s for s in sessions}
    assert not by_sid["aaaaaaaa"]["updatedAt"].startswith("2026-01"), \
        by_sid["aaaaaaaa"]["updatedAt"]
