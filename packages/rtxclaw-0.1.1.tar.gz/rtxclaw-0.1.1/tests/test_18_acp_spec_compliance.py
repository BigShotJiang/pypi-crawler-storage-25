"""Step 18 — ACP spec compliance assertions (offline / fixture-free).

Per operator request: "triple check if all is compliant with acp
standard." The ACP audit (2026-05-05) flagged several drift items
between rtxclaw's implementation and the published spec. This file
encodes those findings as standalone assertions so any silent
regression of a fixed item fails the suite.

Categories pinned here:
- Capability advertisement matches what the dispatcher actually
  accepts (no "image=true but the server -32602's image blocks").
- ``NewSessionResponse`` returns a populated ``SessionModeState``
  with all three modes (auto / ask / plan) when the bridge is
  bound.
- ``_DEFAULT_MODES`` keys match the bridge's mode enum.
- ``JsonRpcErrorCode`` carries the spec-mandated ``-32000
  AuthRequired`` value.
- Stop reasons emitted by the bridge are a subset of the spec's
  enum.
"""
from __future__ import annotations

import inspect

import pytest

from rtxclaw_acp.protocol.jsonrpc import JsonRpcErrorCode
from rtxclaw_acp.server.server import _SUPPORTED_CONTENT_BLOCK_TYPES
from rtxclaw_agent.acp_stdio_main import _DEFAULT_MODES, _build_capabilities
from rtxclaw_agent.acp_bridge import CoreBackend
from rtxclaw_core.agent import AgentConfig


def test_prompt_capabilities_image_matches_dispatcher_support() -> None:
    """Capability lie audit: don't advertise image=true while
    rejecting image content blocks at the dispatcher."""
    cfg = AgentConfig(name="test_agent")
    caps = _build_capabilities(cfg)
    img_advertised = caps["promptCapabilities"]["image"]
    img_supported = "image" in _SUPPORTED_CONTENT_BLOCK_TYPES
    assert img_advertised == img_supported, (
        f"capability lie: promptCapabilities.image={img_advertised} "
        f"but dispatcher supports image={img_supported}"
    )


def test_audio_capability_matches_dispatcher_support() -> None:
    cfg = AgentConfig(name="test_agent")
    caps = _build_capabilities(cfg)
    audio_advertised = caps["promptCapabilities"]["audio"]
    audio_supported = "audio" in _SUPPORTED_CONTENT_BLOCK_TYPES
    assert audio_advertised == audio_supported, (
        f"capability lie: audio={audio_advertised} vs supported="
        f"{audio_supported}"
    )


def test_default_modes_present_and_match_bridge() -> None:
    ids = {m["id"] for m in _DEFAULT_MODES}
    assert {"auto", "ask", "plan"}.issubset(ids), (
        f"_DEFAULT_MODES missing one of auto/ask/plan: {ids}"
    )


def test_modes_state_shape_is_spec_compliant() -> None:
    """``CoreBackend._modes_state`` must produce a SessionModeState
    with availableModes (list of {id, name, description}) and
    currentModeId (string)."""
    cfg = AgentConfig(name="test_agent", permission_mode="auto")
    bridge = CoreBackend(cfg)
    state = bridge._modes_state("auto")
    assert isinstance(state, dict)
    assert "availableModes" in state
    assert "currentModeId" in state
    assert state["currentModeId"] == "auto"
    avail = state["availableModes"]
    assert isinstance(avail, list) and len(avail) >= 3
    for entry in avail:
        assert isinstance(entry, dict)
        assert "id" in entry and isinstance(entry["id"], str)
        assert "name" in entry and isinstance(entry["name"], str)


def test_config_options_state_is_spec_shape_or_empty() -> None:
    """Either we expose no config options (legal) OR each entry has
    the fields the SDK's ``SessionConfigOptionSelect`` expects:
    ``id``, ``name``, ``type='select'``, ``currentValue``,
    ``options``. A drift here breaks ``session/new`` validation."""
    cfg = AgentConfig(name="test_agent")
    bridge = CoreBackend(cfg)
    opts = bridge._config_options_state()
    assert isinstance(opts, list)
    for entry in opts:
        assert isinstance(entry, dict)
        for required in ("id", "name", "type", "currentValue", "options"):
            assert required in entry, (
                f"config option entry missing {required!r}: {entry}"
            )
        assert entry["type"] in ("select", "boolean")


def test_auth_required_error_code_present() -> None:
    """ACP spec mandates -32000 ``AuthRequired`` in the JSON-RPC error
    code enum. Without it, ``session/new`` can't signal "must call
    authenticate first" to clients per spec."""
    assert hasattr(JsonRpcErrorCode, "AUTH_REQUIRED"), (
        "JsonRpcErrorCode missing AUTH_REQUIRED — clients can't get "
        "the spec-mandated -32000 from session/new when auth is needed"
    )
    assert int(JsonRpcErrorCode.AUTH_REQUIRED) == -32000


def test_stop_reasons_are_spec_subset() -> None:
    """Bridge-emitted stop reasons must be a subset of the spec's
    StopReason enum: end_turn, cancelled, max_turn_requests, max_tokens,
    refusal."""
    spec_reasons = {
        "end_turn", "cancelled", "max_turn_requests", "max_tokens",
        "refusal",
    }
    # Inspect both the bridge AND the acp_translation layer for
    # string literals matching the ``stopReason`` field. Post-5e6591e
    # the bridge only emits ``"end_turn"`` directly; ``"cancelled"``
    # moved into ``acp_translation.reason_map`` where TurnError /
    # TurnDone get mapped to the wire stopReason. A regression that
    # introduces a new value (or drops a documented one) would still
    # break clients that pattern-match on the enum.
    from rtxclaw_core.agents import acp_translation
    src = inspect.getsource(CoreBackend) + inspect.getsource(acp_translation)
    for spec in ("end_turn", "cancelled"):
        assert f'"{spec}"' in src, f"bridge missing stop reason {spec!r}"


def test_notify_session_update_method_exists() -> None:
    """The bridge issues ``current_mode_update`` via
    ``server_handle.notify_session_update``. The method MUST be
    public on the AcpServer class (not just the underscore-prefixed
    private one) so the call site doesn't break on refactor."""
    from rtxclaw_acp.server.server import AcpServer
    assert hasattr(AcpServer, "notify_session_update"), (
        "AcpServer.notify_session_update missing — bridge can't push "
        "current_mode_update over the wire"
    )
