"""Step 29 — Bundled file-based slash commands (`/goal` and friends).

``rtxclaw_core.builtin_commands/`` is the lowest-precedence search-
path entry for ``rtxclaw_core.file_commands.command_search_paths``.
Commands shipped there must:

- Be discovered without the user setting anything up.
- Parse into a ``FileCommand`` with frontmatter intact.
- Expand ``$ARGUMENTS`` so ``/goal foo`` reaches the model as the
  body with ``foo`` substituted in.
- Be overridable by a user-installed copy at a higher-precedence
  dir (so an operator can fork the bundled prompt without forking
  the package).

This file pins both the wiring and the `/goal` body itself —
`/goal` is the first bundled command and is the Claude Code parity
entry from the feature map.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_core.file_commands import (
    command_search_paths,
    discover_commands,
    expand_command,
    find_command,
)


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch) -> Path:
    """Empty ``$HOME`` so user-side dirs (``~/.rtxclaw/commands/``,
    ``~/.claude/commands/``) resolve to empty tmp paths.

    Without this, the host operator's real commands would leak into
    discovery and the precedence test would be non-deterministic.
    The bundled-commands path (resolved relative to the package
    module) is independent of $HOME, so it still resolves correctly.
    """
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    # Some helpers also peek at RTXCLAW_HOME; pin it to an empty dir.
    monkeypatch.setenv("RTXCLAW_HOME", str(home / "rtxclaw"))
    # Drop any env override so the chain reflects the production
    # default precedence, not whatever the developer's shell exports.
    monkeypatch.delenv("RTXCLAW_COMMANDS_DIRS", raising=False)
    return home


# ---- search-path wiring --------------------------------------------------


def test_builtin_commands_dir_is_in_search_chain(fake_home: Path) -> None:
    """The bundled directory must be in the search chain at the
    lowest precedence — operators can override but never need to
    install anything to get `/goal` working."""
    chain = command_search_paths()
    bundled = [p for p in chain if p.name == "builtin_commands"]
    assert bundled, (
        "`builtin_commands` directory missing from command_search_paths — "
        "the bundled `/goal` would not ship.\n"
        f"chain: {chain}"
    )
    # It must be the LAST entry: any user-installed copy at a higher
    # precedence dir wins on name collision.
    assert chain[-1].name == "builtin_commands", (
        "bundled commands dir should be lowest precedence; got "
        f"chain order: {[p.name for p in chain]}"
    )


def test_claude_canonical_commands_dir_is_in_chain(fake_home: Path) -> None:
    """``~/.claude/commands/`` is the canonical Claude Code dir.
    The project's recent commits explicitly align skills/plugins/MCPs
    to CC's canonical layout — commands should follow the same rule
    so a `commands/*.md` written for CC works in rtxclaw too."""
    chain = command_search_paths()
    cc_dirs = [
        p for p in chain
        if str(p).endswith(str(Path(".claude") / "commands"))
    ]
    assert cc_dirs, (
        "`~/.claude/commands` missing from command_search_paths — "
        "Claude Code commands won't be picked up.\n"
        f"chain: {chain}"
    )


# ---- /goal — the first bundled command -----------------------------------


def test_goal_command_discovered_from_bundle(fake_home: Path) -> None:
    """`/goal` ships with the package and resolves without any
    user-side install step."""
    cmd = find_command("goal")
    assert cmd is not None, (
        "`/goal` not discoverable — bundled command failed to load. "
        "Check `src/rtxclaw_core/builtin_commands/goal.md` exists "
        "and parses."
    )
    assert cmd.name == "goal"
    assert cmd.source.name == "goal.md"
    assert cmd.source.parent.name == "builtin_commands", (
        f"`/goal` resolved from the wrong place: {cmd.source}"
    )


def test_goal_command_has_description_and_argument_hint(
    fake_home: Path,
) -> None:
    """Frontmatter must parse so `/commands` listings show the
    right description and arg shape — operators see this in the
    TUI / Telegram help panes."""
    cmd = find_command("goal")
    assert cmd is not None
    assert cmd.description, "`/goal` description empty — frontmatter regression"
    # ``argument-hint`` is YAML-frontmatter syntax (the file uses it
    # to signal `<completion-condition>`).
    assert "completion-condition" in cmd.argument_hint, (
        f"`/goal` argument_hint missing the expected token: "
        f"{cmd.argument_hint!r}"
    )


def test_goal_expand_substitutes_arguments(fake_home: Path) -> None:
    """The whole point of the command: `/goal <X>` becomes a model
    turn that quotes `<X>` verbatim. If $ARGUMENTS didn't substitute,
    the model would see the literal placeholder and refuse to
    proceed."""
    cmd = find_command("goal")
    assert cmd is not None
    condition = "every pytest in tests/ passes under -n auto"
    expanded = expand_command(cmd, condition)
    assert condition in expanded, (
        "`/goal` expansion did NOT substitute $ARGUMENTS — the model "
        "would see the placeholder, not the operator's condition.\n"
        f"head:\n{expanded[:400]}"
    )
    assert "$ARGUMENTS" not in expanded, (
        "$ARGUMENTS placeholder leaked through after expansion — "
        "_ARG_TOKEN_RE regression."
    )


def test_goal_body_carries_loop_handoff_instructions(
    fake_home: Path,
) -> None:
    """The /goal behaviour Claude Code documents is "Set goal; Claude
    works until met." — i.e. self-paced iteration. The bundled prompt
    must tell the model to use ``ScheduleWakeup`` (rtxclaw's dynamic
    /loop mechanism) for the next turn AND to stop when the condition
    is met. Without these two anchors the command degrades into a
    one-shot request, defeating the purpose."""
    cmd = find_command("goal")
    assert cmd is not None
    body = cmd.body.lower()
    assert "schedulewakeup" in body, (
        "`/goal` body doesn't mention `ScheduleWakeup` — without it "
        "the model won't self-pace into the next iteration.\n"
        f"body head:\n{cmd.body[:600]}"
    )
    # Both stop-on-met AND stop-on-block must be explicit — a
    # `/goal` that loops past a hard block is worse than no `/goal`.
    assert "stop" in body, (
        "`/goal` body should explicitly tell the model when to stop "
        "(both on completion and on genuine block)."
    )


# ---- precedence: user-installed copy overrides the bundle ----------------


def test_user_command_overrides_bundled(
    fake_home: Path, monkeypatch
) -> None:
    """An operator should be able to fork `/goal` (or any bundled
    command) just by dropping `~/.rtxclaw/commands/goal.md`. This is
    why the bundled dir is lowest precedence."""
    user_dir = fake_home / ".rtxclaw" / "commands"
    user_dir.mkdir(parents=True)
    user_goal = user_dir / "goal.md"
    user_goal.write_text(
        "---\ndescription: USER OVERRIDE\n---\n\n"
        "this is the operator's forked /goal body.\n",
        encoding="utf-8",
    )
    cmd = find_command("goal")
    assert cmd is not None
    assert cmd.source == user_goal, (
        "user-installed copy didn't override the bundled `/goal` — "
        f"resolved from {cmd.source}"
    )
    assert "USER OVERRIDE" in cmd.description


def test_bundled_goal_present_in_discover_listing(
    fake_home: Path,
) -> None:
    """`discover_commands()` returns the full deduplicated list —
    `/goal` must appear without any user setup so `/commands` shows
    it in fresh installs."""
    names = {c.name for c in discover_commands()}
    assert "goal" in names, (
        "`/goal` missing from `discover_commands()` listing — "
        "`/commands` would not surface it on a fresh install.\n"
        f"discovered: {sorted(names)}"
    )


# ---- TUI popup wiring — `/goal` must be visible in the slash-popup --------
#
# The TUI's autocomplete popup is fed by ``_matching_slash_commands``,
# which until 2026-05-16 read ONLY from the hardcoded
# ``SLASH_COMMAND_HELP`` table. File commands like ``/goal`` were
# discoverable from ``/commands`` but invisible to the popup — the
# bug the operator reported with "I don't see the /goal command in
# the tui." These tests pin the fix: a tiny module-level helper
# (``file_command_rows``) bridges ``discover_commands`` into the same
# tuple shape the popup uses, and ``merge_slash_command_rows`` joins
# them while preserving built-in precedence on token collision.


def test_file_command_rows_includes_bundled_goal(fake_home: Path) -> None:
    """`/goal` must surface as a popup-shaped tuple so the autocomplete
    popup picks it up. Token = ``/goal``, signature includes the
    argument hint, description is the frontmatter ``description``."""
    from rtxclaw_tui.app import file_command_rows
    rows = file_command_rows()
    goal_rows = [r for r in rows if r[0] == "/goal"]
    assert goal_rows, (
        "file_command_rows() didn't surface `/goal` — popup would "
        "still hide bundled file commands.\n"
        f"all rows: {rows}"
    )
    token, sig, desc = goal_rows[0]
    assert token == "/goal"
    assert "completion-condition" in sig, (
        f"signature missing argument hint: {sig!r}"
    )
    assert desc, "description empty — popup row would be unhelpful"


def test_file_command_rows_is_fail_soft_on_discovery_error(
    fake_home: Path, monkeypatch,
) -> None:
    """If ``discover_commands`` raises (e.g. malformed config), the
    popup helper must return ``[]`` rather than propagate — a broken
    commands dir can't be allowed to crash the chat input on every
    keystroke."""
    import rtxclaw_core.file_commands as fc
    def _boom(*_a, **_kw):
        raise RuntimeError("synthetic discovery failure")
    monkeypatch.setattr(fc, "discover_commands", _boom)
    from rtxclaw_tui.app import file_command_rows
    assert file_command_rows() == [], (
        "popup helper propagated a discovery exception — would crash "
        "the input box mid-typing"
    )


def test_merge_slash_command_rows_includes_file_commands(
    fake_home: Path,
) -> None:
    """The merged popup list = built-ins + file commands not already
    covered by built-ins. After merge, `/goal` is in; `/help` (built-
    in) is still there exactly once."""
    from rtxclaw_tui.app import (
        SLASH_COMMAND_HELP, file_command_rows, merge_slash_command_rows,
    )
    merged = merge_slash_command_rows(SLASH_COMMAND_HELP, file_command_rows())
    tokens = [r[0] for r in merged]
    assert "/goal" in tokens, (
        "`/goal` not in merged popup list — the popup would still "
        "miss the bundled command.\n"
        f"tokens: {tokens}"
    )
    assert tokens.count("/help") == 1, (
        f"`/help` duplicated or missing after merge: {tokens.count('/help')}"
    )


def test_merge_builtin_wins_on_token_collision(
    fake_home: Path,
) -> None:
    """An operator's ``~/.rtxclaw/commands/help.md`` should NOT shadow
    the built-in ``/help`` row in the popup — dispatch in
    ``on_input_submitted`` runs built-in handlers FIRST, so listing
    the file-command version would mislead the operator about what
    actually runs."""
    user_dir = fake_home / ".rtxclaw" / "commands"
    user_dir.mkdir(parents=True)
    (user_dir / "help.md").write_text(
        "---\ndescription: USER-FORKED HELP\n---\n\nforked\n",
        encoding="utf-8",
    )
    from rtxclaw_tui.app import (
        SLASH_COMMAND_HELP, file_command_rows, merge_slash_command_rows,
    )
    merged = merge_slash_command_rows(SLASH_COMMAND_HELP, file_command_rows())
    help_rows = [r for r in merged if r[0] == "/help"]
    assert len(help_rows) == 1, (
        f"`/help` collision not deduped: got {len(help_rows)} rows"
    )
    _, _, desc = help_rows[0]
    assert "USER-FORKED" not in desc, (
        "user `commands/help.md` shadowed the built-in `/help` in the "
        "popup — built-in handlers should always win.\n"
        f"resolved description: {desc!r}"
    )


def test_popup_prefix_g_offers_goal(fake_home: Path) -> None:
    """The original bug report: typing ``/g`` in the TUI should offer
    `/goal` (alongside `/gemini`). Without this, the operator's only
    way to discover the bundled `/goal` is to read source or run
    `/commands` — defeating the popup's purpose."""
    from rtxclaw_tui.app import (
        SLASH_COMMAND_HELP, file_command_rows, merge_slash_command_rows,
    )
    merged = merge_slash_command_rows(SLASH_COMMAND_HELP, file_command_rows())
    matches = [r[0] for r in merged if r[0].lower().startswith("/g")]
    assert "/goal" in matches, (
        "typing `/g` would NOT offer `/goal` in the popup — the "
        "operator-visible bug.\n"
        f"prefix-/g matches: {matches}"
    )
