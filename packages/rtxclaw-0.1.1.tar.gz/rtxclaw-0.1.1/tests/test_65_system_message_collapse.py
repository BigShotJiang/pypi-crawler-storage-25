"""Step 65 — collapse consecutive leading system messages.

Regression: with skill auto-invoke live, rtxclaw injects a below-cache-
boundary preamble as its own ``role="system"`` message right after the
main system prompt. The qwen3.x vLLM server (tb08) rejects a SECOND
system message with ``HTTP 400: "System message must be at the
beginning."`` — killing the turn before the model runs. (DeepSeek
tolerated it, which is why deepseek sessions worked while qwen didn't.)

``_collapse_leading_system_messages`` merges the contiguous leading run
of system messages into one (content-identical, order-preserved) so the
preamble survives on strict backends, while being a no-op when there's
only the single system prompt (caching unaffected).

Pure unit test — no daemon, no upstream.
"""
from __future__ import annotations

import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.agents.local_llm import (  # noqa: E402
    _collapse_leading_system_messages as collapse,
)


def test_two_leading_system_messages_merge():
    # The exact failing shape: [system, system(skill preamble), user].
    msgs = [
        {"role": "system", "content": "PROMPT"},
        {"role": "system", "content": "[Auto-invoked skill: x]"},
        {"role": "user", "content": "hi"},
    ]
    out = collapse(msgs)
    assert [m["role"] for m in out] == ["system", "user"]
    assert out[0]["content"] == "PROMPT\n\n[Auto-invoked skill: x]"
    assert out[1] == {"role": "user", "content": "hi"}


def test_three_leading_system_messages_merge_keep_transcript():
    msgs = [
        {"role": "system", "content": "A"},
        {"role": "system", "content": "B"},
        {"role": "system", "content": "C"},
        {"role": "user", "content": "u"},
        {"role": "assistant", "content": "a"},
        {"role": "user", "content": "u2"},
    ]
    out = collapse(msgs)
    assert [m["role"] for m in out] == ["system", "user", "assistant", "user"]
    assert out[0]["content"] == "A\n\nB\n\nC"


def test_single_system_is_noop():
    msgs = [{"role": "system", "content": "S"}, {"role": "user", "content": "u"}]
    assert collapse(msgs) == msgs


def test_no_system_is_noop():
    msgs = [{"role": "user", "content": "u"}]
    assert collapse(msgs) == msgs


def test_empty_is_noop():
    assert collapse([]) == []


def test_non_leading_system_left_alone():
    # A system message that is NOT at the start is not our concern here
    # (the assembler never emits one mid-transcript); only the leading
    # contiguous run is merged.
    msgs = [
        {"role": "system", "content": "S"},
        {"role": "user", "content": "u"},
        {"role": "system", "content": "mid"},
    ]
    out = collapse(msgs)
    # leading run is length 1 -> no merge; mid system left untouched.
    assert out == msgs
