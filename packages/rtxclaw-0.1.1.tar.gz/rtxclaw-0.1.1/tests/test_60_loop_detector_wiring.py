"""Integration tests for the engine-side loop-detector wiring.

These tests check that detectors defined in turn_runtime.py are
actually invoked from the engine streaming loop on both channels.
Failure here means the detector is correct in isolation but dead
in production.

NOTE on class name: the engine class is `LocalLLMEngine`
(local_llm.py:387), NOT `LocalLLM`. Tests below construct an empty
instance via `LocalLLMEngine.__new__(LocalLLMEngine)` and call
`_check_streamed_loop` as an unbound method — this avoids the heavy
`__init__` (which wants a full AgentConfig + event bus).
"""
from __future__ import annotations


def test_round_state_initializes_thinking_loop_chars() -> None:
    """RoundState must track both thinking and content check progress."""
    from rtxclaw_core.agents.local_llm import _RoundState
    rs = _RoundState()
    assert hasattr(rs, "thinking_loop_check_chars")
    assert hasattr(rs, "content_loop_check_chars")
    assert rs.thinking_loop_check_chars == 0


def test_check_streamed_loop_accepts_thinking_label() -> None:
    """Sanity: the helper must accept the thinking stream label without
    raising — this is the symmetric counterpart to the content branch.
    Buffer of 4500 `!` chars must trip a tier after Tasks 1+2 land.
    """
    from rtxclaw_core.agents.local_llm import LocalLLMEngine
    buf = ["!" * 4500]
    hit, _new = LocalLLMEngine._check_streamed_loop(
        LocalLLMEngine.__new__(LocalLLMEngine),  # type: ignore[arg-type]
        buf, 0, "thinking",
    )
    assert hit is not None, (
        "thinking-channel buffer of 4500 `!` chars must trip a tier; "
        "if this returns None the carve-outs from Task 1+2 didn't land"
    )


def test_detect_tool_call_loop_returns_true_on_three_identical_turns() -> None:
    """Algorithmic sanity — standalone primitive test."""
    from rtxclaw_core.turn_runtime import _detect_tool_call_loop
    call = [{"function": {"name": "read_file",
                          "parameters": {"path": "/foo.py"}}}]
    history = [call, call, call]
    assert _detect_tool_call_loop(call, history) is True


def test_detect_tool_call_loop_returns_false_when_parameters_differ() -> None:
    """Different path → not a loop."""
    from rtxclaw_core.turn_runtime import _detect_tool_call_loop
    a = [{"function": {"name": "read_file",
                       "parameters": {"path": "/a.py"}}}]
    b = [{"function": {"name": "read_file",
                       "parameters": {"path": "/b.py"}}}]
    assert _detect_tool_call_loop(b, [a, a, a]) is False


def test_detect_tool_call_loop_four_round_integration_simulation() -> None:
    """Simulate the engine wire-up: 4 rounds of identical calls feed a
    per-turn history; the 4th-round check must return True.

    Pins the per-TURN scope (history must NOT reset between rounds).
    """
    from rtxclaw_core.turn_runtime import (
        _detect_tool_call_loop,
        _TOOL_CALL_LOOP_WINDOW,
    )
    call = [{"function": {"name": "read_file",
                          "parameters": {"path": "/foo.py"}}}]
    tool_call_history: list[list[dict]] = []
    fired = False
    for _round_idx in range(4):
        if _detect_tool_call_loop(call, tool_call_history):
            fired = True
            break
        tool_call_history.append(list(call))
        if len(tool_call_history) > _TOOL_CALL_LOOP_WINDOW + 1:
            tool_call_history.pop(0)
        # Ring-trim contract — guard against future _TOOL_CALL_LOOP_WINDOW
        # bumps that forget to update the pop threshold.
        assert len(tool_call_history) <= _TOOL_CALL_LOOP_WINDOW + 1
    assert fired


def test_rotate_seed_changes_per_retry() -> None:
    """Different retry_idx must produce different seeds."""
    from rtxclaw_core.turn_runtime import _rotate_seed
    base = 42
    seeds = {_rotate_seed(base, i) for i in range(5)}
    assert len(seeds) == 5
    assert _rotate_seed(base, 0) == base


def test_rotate_seed_is_deterministic() -> None:
    from rtxclaw_core.turn_runtime import _rotate_seed
    assert _rotate_seed(42, 3) == _rotate_seed(42, 3)


def test_default_spawn_worker_rotates_seed_when_nudge_retry_count_set(
    monkeypatch,
) -> None:
    """Live-path wiring test: _default_spawn_worker (the actual function
    that writes the request dict to the worker subprocess) must rotate
    `seed` when nudge_retry_count > 0 and a base seed exists.
    """
    import asyncio
    import json
    import types
    import rtxclaw_agent.acp_bridge as bridge
    from rtxclaw_core.turn_runtime import _rotate_seed

    captured: dict[str, object] = {}

    def fake_build(*_a, **_kw):
        return {"seed": 42, "messages": [], "model": "y"}

    class _FakeStdin:
        async def drain(self):
            return None
        def write(self, b):
            captured.setdefault("payload_bytes", b)
        def close(self):
            return None
        async def wait_closed(self):
            return None

    class _FakeProc:
        def __init__(self):
            self.stdin = _FakeStdin()
            self.stdout = None
            self.stderr = None
        async def wait(self):
            return 0

    async def fake_create_subprocess_exec(*_a, **_kw):
        return _FakeProc()

    fake_sess = types.SimpleNamespace(
        hash="sid", endpoint="x", model="y",
        system_prompt="", turns=[],
    )

    class FakeBackend:
        cfg = types.SimpleNamespace()
        _promoted_tools: dict = {}
        def _session_for(self, sid):
            return fake_sess if sid == "sid" else None

    async def _passthrough(_b, _s, msgs):
        return msgs

    monkeypatch.setattr(bridge, "_build_worker_request", fake_build)
    monkeypatch.setattr(bridge, "_resolve_images_for_model", _passthrough)
    monkeypatch.setattr(
        bridge.asyncio, "create_subprocess_exec", fake_create_subprocess_exec,
    )
    # Stub the event-stream + TurnState plumbing
    monkeypatch.setattr(
        bridge, "_subprocess_event_stream",
        lambda *a, **kw: iter([]),
        raising=False,
    )

    async def go(nudge_retry_count: int) -> int:
        captured.clear()
        try:
            await bridge._default_spawn_worker(
                FakeBackend(), "sid", [], "tid",
                messages=[{"role": "user", "content": "hi"}],
                nudge_retry_count=nudge_retry_count,
            )
        except Exception:
            # Downstream stream construction may need more stubs;
            # we only care that the request payload was emitted.
            pass
        body = (captured.get("payload_bytes") or b"").decode("utf-8")
        return int(json.loads(body)["seed"])

    seed_0 = asyncio.run(go(0))
    seed_1 = asyncio.run(go(1))
    seed_2 = asyncio.run(go(2))
    assert seed_0 == 42, "no retry → seed unchanged"
    assert seed_1 == _rotate_seed(42, 1)
    assert seed_2 == _rotate_seed(42, 2)
    assert seed_1 != 42 and seed_2 != seed_1


def test_check_streamed_loop_fires_below_4096_on_tight_collapse() -> None:
    """A buffer below the old LOOP_WINDOW_CHARS=4096 gate must trip
    the engine streaming detector. Pre-T6 fix: 4096-char gate masked
    the tight tier's 80-char min_context_chars for the entire first
    4k of every stream.

    Buffer size chosen to clear both the min-context gate (80) AND
    LOOP_CHECK_STRIDE (1024 in local_llm.py mirror; cleared after
    T7 to the env default 300). 1100 chars is below 4096 (proves the
    gate moved) and above 1024 (clears the stride throttle).
    """
    from rtxclaw_core.agents.local_llm import LocalLLMEngine
    buf = ["!" * 1100]
    hit, _new = LocalLLMEngine._check_streamed_loop(
        LocalLLMEngine.__new__(LocalLLMEngine),  # type: ignore[arg-type]
        buf, 0, "content",
    )
    assert hit is not None, (
        "1100-char tight collapse must fire after T6 lowered the gate "
        "from LOOP_WINDOW_CHARS (4096) to LOOP_TIGHT_MIN_CONTEXT_CHARS (80)"
    )


def test_check_streamed_loop_threads_channel(monkeypatch) -> None:
    """The engine must pass channel=stream_label into _detect_loops_layered."""
    from rtxclaw_core.agents.local_llm import LocalLLMEngine
    captured: dict[str, object] = {}
    import rtxclaw_core.turn_runtime as tr
    original = tr._detect_loops_layered

    def _spy(text, *, channel="", **kw):
        captured["channel"] = channel
        return original(text, channel=channel, **kw)

    monkeypatch.setattr(tr, "_detect_loops_layered", _spy)
    eng = LocalLLMEngine.__new__(LocalLLMEngine)  # type: ignore[arg-type]
    buf = ["a" * 4500]
    LocalLLMEngine._check_streamed_loop(eng, buf, 0, "thinking")
    assert captured.get("channel") == "thinking", (
        "engine must thread stream_label as channel= into _detect_loops_layered"
    )


def test_loop_detect_env_var_propagates_to_local_llm(tmp_path) -> None:
    """Setting RTXCLAW_LOOP_DETECT=0 must disable engine streaming
    detection, not just turn_runtime detection.
    """
    import os
    import subprocess
    import sys
    from pathlib import Path

    repo_root = Path(__file__).resolve().parents[1]

    def _probe(env_overrides: dict, expect_in_stdout: str) -> str:
        env = {
            **os.environ,
            "PYTHONPATH": str(repo_root / "src"),
            **env_overrides,
        }
        out = subprocess.run(
            [
                sys.executable, "-c",
                "import rtxclaw_core.agents.local_llm as llm; "
                "print(repr(llm.LOOP_DETECT_ENABLED))"
            ],
            env=env,
            cwd=str(repo_root),
            capture_output=True, text=True, check=True,
        )
        assert expect_in_stdout in out.stdout, out.stdout
        return out.stdout

    _probe({"RTXCLAW_LOOP_DETECT": "0"}, "False")
    env_on = {k: v for k, v in os.environ.items()
              if k != "RTXCLAW_LOOP_DETECT"}
    env_on["PYTHONPATH"] = str(repo_root / "src")
    out_on = subprocess.run(
        [
            sys.executable, "-c",
            "import rtxclaw_core.agents.local_llm as llm; "
            "print(repr(llm.LOOP_DETECT_ENABLED))"
        ],
        env=env_on,
        cwd=str(repo_root),
        capture_output=True, text=True, check=True,
    )
    assert "True" in out_on.stdout, out_on.stdout


def test_dead_env_knobs_are_removed() -> None:
    """Env knobs with zero call sites are misleading; this test pins
    that DISTILL_RECOVERY_ENABLED and PRESEND_SCAN_ENABLED are gone.
    """
    import rtxclaw_core.turn_runtime as tr
    assert not hasattr(tr, "DISTILL_RECOVERY_ENABLED"), (
        "DISTILL_RECOVERY_ENABLED has zero call sites — delete it or wire it"
    )
    assert not hasattr(tr, "PRESEND_SCAN_ENABLED"), (
        "PRESEND_SCAN_ENABLED has zero call sites — delete it or wire it"
    )
