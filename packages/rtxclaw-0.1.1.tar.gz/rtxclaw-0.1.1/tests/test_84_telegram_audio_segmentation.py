import subprocess
import pytest
from rtxclaw_telegram.bot import _resolve_ffmpeg, _transcode_to_mp3

@pytest.fixture(scope="module")
def ffmpeg():
    p = _resolve_ffmpeg()
    if not p:
        pytest.skip("no ffmpeg")
    return p

@pytest.fixture(scope="module")
def long_wav(ffmpeg):
    # 12 minutes of tone -> forces multi-segment in a later task
    proc = subprocess.run([ffmpeg, "-loglevel", "error", "-f", "lavfi",
        "-i", "sine=frequency=300:duration=720", "-f", "wav", "pipe:1"],
        capture_output=True)
    if proc.returncode != 0:
        pytest.skip("ffmpeg synth failed")
    return proc.stdout

def test_transcode_accepts_timeout_param(long_wav):
    mp3 = _transcode_to_mp3(long_wav, sample_rate=16000, channels=1, timeout=600)
    assert mp3 is not None
    assert mp3[:3] == b"ID3" or mp3[0] == 0xFF


from rtxclaw_telegram.bot import _segment_audio, _transcribe_segments

def test_segment_audio_splits_into_chunks(long_wav):
    mp3 = _transcode_to_mp3(long_wav, sample_rate=16000, channels=1, timeout=600)
    chunks = _segment_audio(mp3, seconds=300)   # 720s / 300 -> 3 chunks
    assert len(chunks) == 3
    assert all(c[:3] == b"ID3" or c[0] == 0xFF for c in chunks)

def test_segment_audio_short_returns_single(ffmpeg):
    import subprocess
    short = subprocess.run([ffmpeg, "-loglevel", "error", "-f", "lavfi",
        "-i", "sine=frequency=300:duration=3", "-f", "wav", "pipe:1"],
        capture_output=True).stdout
    mp3 = _transcode_to_mp3(short, sample_rate=16000, channels=1)
    assert len(_segment_audio(mp3, seconds=300)) == 1

import asyncio as _aio
def test_transcribe_segments_stitches_in_order():
    seen = []
    async def fake_post(b):
        seen.append(len(b)); return f"part{len(seen)}"
    out = _aio.run(_transcribe_segments([b"a", b"bb", b"ccc"], fake_post))
    assert out == "part1\npart2\npart3"
