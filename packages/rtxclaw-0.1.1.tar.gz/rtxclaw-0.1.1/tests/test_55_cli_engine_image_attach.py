"""Regression: images attached to a CLI-engine agent must reach the CLI.

Before fix_20260514, ``ExternalCliEngine.run_turn`` only forwarded
``request.prompt`` (the text) to the legacy ``run_delegate_*_async``
runner — ``request.prompt_parts`` (the OpenAI-vision multi-part list
the gateway shim builds from a Telegram photo / TUI paste) was
silently dropped. A user who sent a screenshot to the ``claude`` agent
got a reply that never saw the image.

``claude_engine.prime_first_turn_prompt`` *had* image-handling code
(``--attach``) but it is dead on the live path — ``run_turn`` delegates
to the legacy runner, never calling it — and ``claude -p`` has no
``--attach`` flag anyway.

The fix: ``run_turn`` materializes every ``image_url`` part to a temp
file and inlines the paths into the prompt text (every supported CLI
reads images off disk via its own file tool), then unlinks the temp
files once the subprocess exits.

This test pins that contract:

* the image is decoded to a temp file the subprocess can actually read,
* the temp path is inlined into the stdin prompt,
* the temp file is cleaned up after the turn,
* a text-only prompt is untouched (no attachment block).
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import re
from pathlib import Path


# Arbitrary non-image bytes — the stub never decodes the file, it only
# proves it could open + read exactly what we materialized.
_FAKE_IMAGE_BYTES = b"\xff\xd8\xff\xe0RTXCLAW-TEST-IMAGE-PAYLOAD\x00\x01\x02\xff\xd9"


def _fake_claude_stdin_capture(bin_dir: Path, capture_path: Path) -> None:
    """Install a ``claude`` stub that records what it received.

    Writes one JSON line to ``capture_path`` with:

    * ``stdin`` — the full prompt piped in,
    * ``image_path`` — the first ``  - <path>`` line found in the
      attachment block (or ``None``),
    * ``image_readable`` — whether that path existed AND was readable
      *from inside the subprocess* (proves the temp file is live
      during the turn, not just a string in the prompt),
    * ``image_bytes_len`` — length of the bytes read back.

    Then emits a minimal valid stream-json reply so the engine drives
    to ``TurnDone(state="ok")``.
    """
    bin_dir.mkdir(parents=True, exist_ok=True)
    stub = bin_dir / "claude"
    stub.write_text(
        f"""#!/usr/bin/env python3
import json, re, sys
data = sys.stdin.read()
m = re.search(r'^\\s+-\\s+(\\S.*)$', data, re.MULTILINE)
image_path = m.group(1) if m else None
image_readable = False
image_bytes_len = 0
if image_path:
    try:
        with open(image_path, "rb") as fh:
            blob = fh.read()
        image_readable = True
        image_bytes_len = len(blob)
    except OSError:
        pass
with open({json.dumps(str(capture_path))}, "a", encoding="utf-8") as fh:
    fh.write(json.dumps({{
        "stdin": data,
        "image_path": image_path,
        "image_readable": image_readable,
        "image_bytes_len": image_bytes_len,
    }}) + chr(10))
print(json.dumps({{
    "type": "assistant",
    "session_id": "img-session-id",
    "message": {{"content": [{{"type": "text", "text": "saw it"}}]}},
}}), flush=True)
print(json.dumps({{
    "type": "result",
    "session_id": "img-session-id",
    "is_error": False,
}}), flush=True)
""",
        encoding="utf-8",
    )
    stub.chmod(0o755)


def _drain(engine, request, state, sessions_dir, turn_id):
    """Drive ``engine.run_turn`` to completion; return final TurnDone state."""
    from rtxclaw_core.agents.engine import TurnDone

    async def _go():
        terminal = "none"
        async for ev in engine.run_turn(
            request, state, sessions_dir=sessions_dir, turn_id=turn_id,
        ):
            if isinstance(ev, TurnDone):
                terminal = ev.state
        return terminal

    return asyncio.run(_go())


def _request(prompt, *, prompt_parts=None):
    from rtxclaw_core.agents.engine import TurnRequest

    return TurnRequest(
        prompt=prompt,
        system_prompt="# SOUL\n\nfirst-turn priming prompt\n",
        system_prompt_sha256="a" * 64,
        preamble=[],
        mode="auto",
        prompt_parts=list(prompt_parts or []),
    )


def _fresh_state():
    from rtxclaw_core.agents.engine import EngineKind, EngineSessionState

    return EngineSessionState(
        rtxclaw_session_id="rtx-img-test",
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id="",
        priming_status="never",
        priming_system_prompt_sha256="",
    )


def _prep_env(tmp_path, monkeypatch):
    capture = tmp_path / "capture.jsonl"
    _fake_claude_stdin_capture(tmp_path / "bin", capture)
    monkeypatch.setenv(
        "PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}"
    )
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    return capture, sessions_dir


def test_image_part_is_materialized_inlined_and_cleaned_up(
    tmp_path, monkeypatch,
) -> None:
    """A ``data:`` image part → a temp file the subprocess can read,
    its path inlined into the stdin prompt, and the temp file unlinked
    once the turn ends."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine

    capture, sessions_dir = _prep_env(tmp_path, monkeypatch)

    b64 = base64.b64encode(_FAKE_IMAGE_BYTES).decode("ascii")
    request = _request(
        "what's in this screenshot?",
        prompt_parts=[
            {"type": "text", "text": "what's in this screenshot?"},
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
            },
        ],
    )

    engine = ClaudeCliEngine()
    terminal = _drain(engine, request, _fresh_state(), sessions_dir, "t-img")
    assert terminal == "ok", f"engine drove to {terminal!r}, expected 'ok'"

    lines = capture.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1, f"expected 1 spawn, got {len(lines)}: {lines}"
    rec = json.loads(lines[0])

    # The caption text still rides on stdin...
    assert "what's in this screenshot?" in rec["stdin"]
    # ...alongside the attachment block.
    assert "The user attached 1 image" in rec["stdin"], (
        f"attachment block missing from stdin: {rec['stdin']!r}"
    )

    # The subprocess found a path AND could read the exact bytes we
    # materialized — the file was live on disk during the turn.
    img_path = rec["image_path"]
    assert img_path, f"no inlined image path found in stdin: {rec['stdin']!r}"
    assert "rtxclaw-attach-" in img_path, f"unexpected temp name: {img_path}"
    assert rec["image_readable"] is True, (
        f"subprocess could not read the materialized image at {img_path}"
    )
    assert rec["image_bytes_len"] == len(_FAKE_IMAGE_BYTES), (
        f"materialized {rec['image_bytes_len']} bytes, "
        f"expected {len(_FAKE_IMAGE_BYTES)}"
    )

    # ...and it's gone now — run_turn's finally unlinked it.
    assert not Path(img_path).exists(), (
        f"temp image {img_path} leaked — finally cleanup did not run"
    )


def test_multiple_images_all_materialized(tmp_path, monkeypatch) -> None:
    """Two image parts → two temp files, both inlined, both cleaned up,
    and the block pluralizes ('2 images')."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine

    capture, sessions_dir = _prep_env(tmp_path, monkeypatch)

    b64 = base64.b64encode(_FAKE_IMAGE_BYTES).decode("ascii")
    img_part = {
        "type": "image_url",
        "image_url": {"url": f"data:image/png;base64,{b64}"},
    }
    request = _request(
        "compare these",
        prompt_parts=[
            {"type": "text", "text": "compare these"},
            dict(img_part),
            dict(img_part),
        ],
    )

    engine = ClaudeCliEngine()
    terminal = _drain(engine, request, _fresh_state(), sessions_dir, "t-img2")
    assert terminal == "ok", f"engine drove to {terminal!r}, expected 'ok'"

    rec = json.loads(capture.read_text(encoding="utf-8").splitlines()[0])
    assert "The user attached 2 images" in rec["stdin"], (
        f"expected pluralized block, got: {rec['stdin']!r}"
    )
    paths = re.findall(r"^\s+-\s+(\S.*)$", rec["stdin"], re.MULTILINE)
    assert len(paths) == 2, f"expected 2 inlined paths, got {paths}"
    for p in paths:
        assert "rtxclaw-attach-" in p, f"unexpected temp name: {p}"
        assert not Path(p).exists(), f"temp image {p} leaked after turn"


def test_text_only_prompt_is_untouched(tmp_path, monkeypatch) -> None:
    """No image parts → stdin carries the bare prompt, no attachment
    block. Pins that the multimodal branch is inert for the common case."""
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine

    capture, sessions_dir = _prep_env(tmp_path, monkeypatch)

    request = _request("just a plain text question")
    engine = ClaudeCliEngine()
    terminal = _drain(engine, request, _fresh_state(), sessions_dir, "t-text")
    assert terminal == "ok", f"engine drove to {terminal!r}, expected 'ok'"

    rec = json.loads(capture.read_text(encoding="utf-8").splitlines()[0])
    assert "just a plain text question" in rec["stdin"]
    assert "The user attached" not in rec["stdin"], (
        f"attachment block leaked into a text-only prompt: {rec['stdin']!r}"
    )
    assert rec["image_path"] is None
