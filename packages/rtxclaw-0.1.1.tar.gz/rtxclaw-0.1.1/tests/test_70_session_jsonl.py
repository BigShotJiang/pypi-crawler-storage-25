"""Step 70 — v2 session log storage core (append-only JSONL + sessions.db).

Pure-Python unit tests for the storage layer that underpins the v2
session log: ``session_reader`` (line codec + tail + fold),
``session_writer`` (the single sink), and ``session_index``
(EventProjector + tail + rebuild + schema migration). No real LLM
endpoint required — these exercise the on-disk format directly.

Covers, per the design spec (docs/superpowers/specs/2026-05-19-...):
- CRC line codec round-trip + corruption rejection
- tail_jsonl partial-trailing-line tolerance + offset resume + CRC skip
- writer→fold round-trip lossless for the legacy turn dict shape
- secret scrubbing on every persisted leaf (incl. the live snapshot)
- privacy gates (persist_reasoning_traces / persist_tool_result_bodies)
- live_* populated mid-turn, cleared on turn_ended
- index tail idempotence (re-tail makes no duplicate rows)
- rebuild() reconstructs the index from JSONL
- concurrent writers under flock produce no torn / invalid lines
- schema migration: legacy frontend -> workspace_origin
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core import session_reader as sr  # noqa: E402
from rtxclaw_core.session_index import (  # noqa: E402
    SessionIndex,
    connect_sessions_db,
    ensure_schema,
)
from rtxclaw_core.session_writer import SessionWriter  # noqa: E402


# ---- line codec -----------------------------------------------------


def test_encode_decode_roundtrip():
    ev = {"v": "1", "type": "text_delta", "turn_idx": 0, "delta": "héllo → world"}
    line = sr.encode_line(ev)
    assert line.endswith(b"\n")
    assert line.count(b"\n") == 1
    # prefix is 8 hex + space
    assert line[8:9] == b" "
    back = sr.decode_line(line[:-1])
    assert back == ev


def test_decode_rejects_crc_mismatch():
    ev = {"type": "x", "a": 1}
    line = sr.encode_line(ev)[:-1]
    # Corrupt one byte of the payload (after the 9-char prefix).
    corrupted = bytearray(line)
    corrupted[-1] = corrupted[-1] ^ 0xFF
    assert sr.decode_line(bytes(corrupted)) is None


def test_decode_rejects_garbage():
    assert sr.decode_line(b"") is None
    assert sr.decode_line(b"not-a-line") is None
    assert sr.decode_line(b"deadbeef {bad json") is None
    assert sr.decode_line(b"shortpfx {}") is None  # prefix != 8 chars


# ---- tail reader ----------------------------------------------------


def test_tail_skips_partial_trailing_line(tmp_path):
    p = tmp_path / "s.jsonl"
    good = sr.encode_line({"type": "a", "n": 1})
    p.write_bytes(good + b"deadbe")  # second line has no terminator
    events = list(sr.tail_jsonl(p))
    assert len(events) == 1
    assert events[0][0]["type"] == "a"
    # end offset points just past the first '\n'
    assert events[0][1] == len(good)


def test_tail_resume_from_offset(tmp_path):
    p = tmp_path / "s.jsonl"
    l1 = sr.encode_line({"type": "a"})
    l2 = sr.encode_line({"type": "b"})
    p.write_bytes(l1 + l2)
    first = list(sr.tail_jsonl(p))
    assert [e["type"] for e, _ in first] == ["a", "b"]
    # resume from after the first line: only "b"
    resumed = list(sr.tail_jsonl(p, start_offset=len(l1)))
    assert [e["type"] for e, _ in resumed] == ["b"]


def test_tail_skips_corrupt_line_and_continues(tmp_path):
    p = tmp_path / "s.jsonl"
    l1 = sr.encode_line({"type": "a"})
    bad = b"00000000 {bad\n"
    l3 = sr.encode_line({"type": "c"})
    p.write_bytes(l1 + bad + l3)
    got = [e["type"] for e, _ in sr.tail_jsonl(p)]
    assert got == ["a", "c"]


def test_tail_missing_file_is_empty(tmp_path):
    assert list(sr.tail_jsonl(tmp_path / "nope.jsonl")) == []


# ---- writer round-trip ----------------------------------------------


def _mk_writer(tmp_path, sid="0123456789abcdef", **kw):
    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True, exist_ok=True)
    w = SessionWriter(sdir, sid, engine=kw.pop("engine", "local_llm"),
                      flush_ms=kw.pop("flush_ms", 0), **kw)
    return home, sdir, w


def test_writer_fold_roundtrip(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm",
                       "model": "qwen", "workspace_origin": "tui"})
    w.turn_started(turn_idx=0, user="hi there", permission_mode="auto", cwd="/w")
    w.round_started(turn_idx=0, round_idx=0, model="qwen")
    w.thinking_delta(turn_idx=0, round_idx=0, chunk="reason ")
    w.text_delta(turn_idx=0, round_idx=0, chunk="Hel")
    w.text_delta(turn_idx=0, round_idx=0, chunk="lo")
    w.tool_call(turn_idx=0, round_idx=0, call_id="c1", name="Read",
                arguments={"path": "/x"}, raw_arguments='{"path":"/x"}')
    w.tool_result(turn_idx=0, round_idx=0, call_id="c1", ok=True, content="body")
    w.round_ended(turn_idx=0, round_idx=0, metrics={"prompt_tokens": 3},
                  finish_reason="stop", tokenizer_id="o200k")
    w.turn_ended(turn_idx=0, user="hi there", final_content="Hello",
                 final_thinking="reason", metrics={"wall_time": 1.0})
    w.close()

    turns = sr.fold_jsonl_into_turns(sdir / f"{w.sid}.jsonl")
    assert len(turns) == 1
    t = turns[0]
    assert t["user"] == "hi there"
    assert t["content"] == "Hello"          # final_content wins
    assert t["thinking"] == "reason"
    assert t["permission_mode"] == "auto"
    assert t["cwd"] == "/w"
    assert t["engine"] == "local_llm"
    assert len(t["tool_calls"]) == 1
    assert t["tool_calls"][0]["name"] == "Read"
    assert len(t["tool_results"]) == 1
    assert t["tool_results"][0]["ok"] is True
    assert t["round_metrics"][0]["tokenizer_id"] == "o200k"
    assert t["metrics"]["wall_time"] == 1.0


def test_writer_scrubs_secrets(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    secret_user = "key sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ012 here"
    w.turn_started(turn_idx=0, user=secret_user, permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="export TOKEN=supersecretvalue123")
    w.tool_result(turn_idx=0, round_idx=0, call_id="c1", ok=True,
                  content="PASSWORD=hunter2pw")
    w.turn_ended(turn_idx=0, user=secret_user, final_content="ok")
    w.close()
    raw = (sdir / f"{w.sid}.jsonl").read_text()
    assert "sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ012" not in raw
    assert "supersecretvalue123" not in raw
    assert "hunter2pw" not in raw
    assert "REDACTED" in raw
    # sessions.db is a lazily-tailed index — refresh it, then check the
    # materialised title is scrubbed too.
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    row = con.execute(
        "SELECT title FROM sessions_meta WHERE session_hash=?", (w.sid,)
    ).fetchone()
    assert "sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ012" not in (row["title"] or "")


def test_privacy_gate_drops_thinking(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm",
                       "persist_reasoning_traces": False})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.thinking_delta(turn_idx=0, round_idx=0, chunk="SECRET REASONING")
    w.text_delta(turn_idx=0, round_idx=0, chunk="answer")
    w.turn_ended(turn_idx=0, user="q", final_content="answer",
                 final_thinking="SECRET REASONING")
    w.close()
    raw = (sdir / f"{w.sid}.jsonl").read_text()
    assert "SECRET REASONING" not in raw
    assert "thinking_delta" not in raw
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    row = con.execute(
        "SELECT live_thinking_so_far FROM sessions_meta WHERE session_hash=?",
        (w.sid,),
    ).fetchone()
    assert (row["live_thinking_so_far"] or "") == ""


def test_privacy_gate_drops_tool_body(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm",
                       "persist_tool_result_bodies": False})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.tool_call(turn_idx=0, round_idx=0, call_id="c1", name="Read", arguments={})
    w.tool_result(turn_idx=0, round_idx=0, call_id="c1", ok=True,
                  content="SENSITIVE FILE BODY")
    w.turn_ended(turn_idx=0, user="q", final_content="ok")
    w.close()
    raw = (sdir / f"{w.sid}.jsonl").read_text()
    assert "SENSITIVE FILE BODY" not in raw
    # meta row (call_id + ok + content_chars) still present
    assert "tool_result_meta" in raw


def test_live_snapshot_lifecycle(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="partial")
    # Mid-turn: tail the JSONL into the index, then the live snapshot
    # reflects the partial content.
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    mid = con.execute(
        "SELECT live_turn_idx, live_content_so_far FROM sessions_meta "
        "WHERE session_hash=?", (w.sid,),
    ).fetchone()
    assert mid["live_turn_idx"] == 0
    assert mid["live_content_so_far"] == "partial"
    w.turn_ended(turn_idx=0, user="q", final_content="partial done")
    w.close()
    SessionIndex(home).tail(w.sid)
    con2 = connect_sessions_db(sdir / "sessions.db")
    after = con2.execute(
        "SELECT live_turn_idx, live_content_so_far, last_turn_idx "
        "FROM sessions_meta WHERE session_hash=?", (w.sid,),
    ).fetchone()
    assert after["live_turn_idx"] is None
    assert after["live_content_so_far"] == ""
    assert after["last_turn_idx"] == 0


def test_live_last_event_offset_matches_file(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="x")
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    off = con.execute(
        "SELECT live_last_event_offset FROM sessions_meta WHERE session_hash=?",
        (w.sid,),
    ).fetchone()["live_last_event_offset"]
    size = (sdir / f"{w.sid}.jsonl").stat().st_size
    assert off == size  # end-offset == EOF after the last tailed write


# ---- index tail / rebuild -------------------------------------------


def test_tail_is_idempotent(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="kafka replication factor", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="set it to three")
    w.turn_ended(turn_idx=0, user="kafka replication factor",
                 final_content="set it to three")
    w.close()
    idx = SessionIndex(home)
    idx.tail(w.sid)  # populate the index from the JSONL (lazy index)
    con = connect_sessions_db(idx.db_path)

    def counts():
        te = con.execute("SELECT count(*) c FROM turn_events").fetchone()["c"]
        tn = con.execute("SELECT count(*) c FROM turns").fetchone()["c"]
        ft = con.execute("SELECT count(*) c FROM turns_fts").fetchone()["c"]
        return te, tn, ft

    before = counts()
    assert before != (0, 0, 0), "first tail indexed nothing"
    # Re-tail from scratch: reset cursor and re-apply every event.
    con.execute("UPDATE sessions_meta SET indexed_bytes=0 WHERE session_hash=?",
                (w.sid,))
    con.commit()
    idx.tail(w.sid)
    after = counts()
    assert before == after, f"re-tail changed row counts: {before} -> {after}"


def test_rebuild_reconstructs_index(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="unique kafka phrase xyz", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="answer body")
    w.turn_ended(turn_idx=0, user="unique kafka phrase xyz",
                 final_content="answer body")
    w.close()
    idx = SessionIndex(home)
    # Nuke the db and rebuild from JSONL alone.
    idx.db_path.unlink()
    for ext in ("-wal", "-shm"):
        p = Path(str(idx.db_path) + ext)
        if p.exists():
            p.unlink()
    idx2 = SessionIndex(home)
    stats = idx2.rebuild()
    assert stats["files"] == 1
    hits = idx2.search("unique kafka phrase", min_score=0.0)
    assert len(hits) == 1
    con = connect_sessions_db(idx2.db_path)
    row = con.execute(
        "SELECT last_turn_idx, title FROM sessions_meta WHERE session_hash=?",
        (w.sid,),
    ).fetchone()
    assert row["last_turn_idx"] == 0


def test_tail_resets_cursor_past_eof(tmp_path):
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="a")
    w.turn_ended(turn_idx=0, user="q", final_content="a")
    w.close()
    idx = SessionIndex(home)
    con = connect_sessions_db(idx.db_path)
    con.execute("UPDATE sessions_meta SET indexed_bytes=999999 WHERE session_hash=?",
                (w.sid,))
    con.commit()
    # Should detect offset > size, reset to 0, re-tail without error.
    idx.tail(w.sid)
    con2 = connect_sessions_db(idx.db_path)
    off = con2.execute(
        "SELECT indexed_bytes FROM sessions_meta WHERE session_hash=?", (w.sid,)
    ).fetchone()["indexed_bytes"]
    assert off == (sdir / f"{w.sid}.jsonl").stat().st_size


# ---- concurrency ----------------------------------------------------


def test_concurrent_writers_no_torn_lines(tmp_path):
    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    sid = "concurrentsid01"
    # Two writers on the SAME session (separate instances → separate
    # fds → contend on the flock). Each appends many events.
    ensure_schema(sdir / "sessions.db")
    w1 = SessionWriter(sdir, sid, engine="local_llm", flush_ms=0)
    w2 = SessionWriter(sdir, sid, engine="local_llm", flush_ms=0)
    w1.session_started({"agent_name": "main", "engine": "local_llm"})

    def hammer(w, base):
        for i in range(60):
            w.lifecycle(kind="nudge", payload={"reason": f"{base}-{i}",
                                               "blob": "x" * 200},
                        turn_idx=0)

    t1 = threading.Thread(target=hammer, args=(w1, "A"))
    t2 = threading.Thread(target=hammer, args=(w2, "B"))
    t1.start(); t2.start(); t1.join(); t2.join()
    w1.close(); w2.close()

    # Every line in the file must be CRC-valid and JSON-parseable.
    p = sdir / f"{sid}.jsonl"
    raw = p.read_bytes()
    n_lines = raw.count(b"\n")
    parsed = list(sr.tail_jsonl(p))
    assert len(parsed) == n_lines, "some lines failed CRC/parse (torn write)"
    # session_started + 120 nudges
    types = [e["type"] for e, _ in parsed]
    assert types.count("nudge") == 120


# ---- schema migration ----------------------------------------------


def test_migration_populated_turn_events_dedup(tmp_path):
    # review: Codex C1 — a legacy turn_events with ≥2 same-key rows
    # (e.g. two tool_calls in one turn) must not crash the v2 UNIQUE
    # index build. Migration backfills payload_hash + dedups.
    sdir = tmp_path / "sessions"
    sdir.mkdir(parents=True)
    db = sdir / "sessions.db"
    con = connect_sessions_db(db)
    con.executescript(
        "CREATE TABLE sessions_meta (session_hash TEXT PRIMARY KEY,"
        " title TEXT, created_at TEXT, frontend TEXT, updated_at INTEGER);"
        "CREATE TABLE turn_events (rowid INTEGER PRIMARY KEY AUTOINCREMENT,"
        " session_hash TEXT, turn_idx INTEGER, kind TEXT, ts INTEGER,"
        " payload_json TEXT);"
    )
    # Two identical-key tool_call rows + one distinct — pre-v2 shape.
    con.execute("INSERT INTO turn_events(session_hash,turn_idx,kind,ts,payload_json)"
                " VALUES ('s1',0,'tool_call',1,'{\"name\":\"Read\"}')")
    con.execute("INSERT INTO turn_events(session_hash,turn_idx,kind,ts,payload_json)"
                " VALUES ('s1',0,'tool_call',1,'{\"name\":\"Bash\"}')")
    con.commit()
    con.close()
    # Must not raise.
    ensure_schema(db)
    con2 = connect_sessions_db(db)
    cols = {r[1] for r in con2.execute("PRAGMA table_info(turn_events)")}
    assert "payload_hash" in cols
    n = con2.execute("SELECT count(*) c FROM turn_events").fetchone()["c"]
    assert n == 2  # distinct payloads survive; no spurious collapse


def test_indexed_bytes_advances_on_session_started(tmp_path):
    # review: Codex C3 / Gemini — a session_started-only session must
    # leave indexed_bytes at EOF, not 0.
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.flush_deltas()
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    off = con.execute(
        "SELECT indexed_bytes FROM sessions_meta WHERE session_hash=?", (w.sid,)
    ).fetchone()["indexed_bytes"]
    assert off == (sdir / f"{w.sid}.jsonl").stat().st_size
    assert off > 0


def test_restart_tail_preserves_fts_user_text(tmp_path):
    # review: Gemini #3 — a turn re-indexed by a FRESH projector after
    # a mid-turn cursor must still pair the user prompt into the FTS doc.
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="ZEBRAPHRASE about kafka tuning", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="answer text")
    w.turn_ended(turn_idx=0, final_content="answer text")  # NOTE: no user= passed
    w.close()
    # Wipe the index and re-tail with a fresh projector (simulates restart).
    idx = SessionIndex(home)
    for tbl in ("turn_events", "turns", "turns_fts", "sessions_meta"):
        connect_sessions_db(idx.db_path).execute(f"DELETE FROM {tbl}").connection.commit()
    con = connect_sessions_db(idx.db_path)
    con.execute("INSERT OR IGNORE INTO sessions_meta(session_hash,indexed_bytes) VALUES (?,0)",
                (w.sid,))
    con.commit()
    idx.tail(w.sid)  # fresh EventProjector inside
    hits = idx.search("ZEBRAPHRASE", min_score=0.0)
    assert len(hits) == 1, "user prompt lost from FTS after restart tail"


def test_turn_ended_return_is_scrubbed(tmp_path):
    # review: Codex C4 — the dict turn_ended returns (feeds memory) must
    # be scrubbed, not just the JSONL copy.
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    rec = w.turn_ended(turn_idx=0, user="q",
                       final_content="key sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ012 x")
    w.close()
    assert "sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ012" not in rec["content"]
    assert "REDACTED" in rec["content"]


def test_fd_leak_on_repeated_open_close(tmp_path):
    # review: Codex C2 — close() must release the lock fd.
    import os as _os
    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    ensure_schema(sdir / "sessions.db")

    def open_fds():
        return len(_os.listdir(f"/proc/{_os.getpid()}/fd"))

    base = open_fds()
    for i in range(25):
        w = SessionWriter(sdir, f"sid{i:04d}", engine="local_llm", flush_ms=0)
        w.session_started({"agent_name": "main", "engine": "local_llm"})
        w.close()
    leaked = open_fds() - base
    assert leaked <= 2, f"leaked {leaked} fds across 25 open/close cycles"


def test_delta_debounce_batches(tmp_path):
    # review: Codex test gap — flush_ms>0 should coalesce chunks.
    home, sdir, w = _mk_writer(tmp_path, flush_ms=100000)  # effectively never auto-flush
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    for c in "abcdef":
        w.text_delta(turn_idx=0, round_idx=0, chunk=c)
    w.turn_ended(turn_idx=0, final_content="abcdef")  # flushes the buffer
    w.close()
    events = [e for e, _ in sr.tail_jsonl(sdir / f"{w.sid}.jsonl")]
    n_text = sum(1 for e in events if e["type"] == "text_delta")
    assert n_text == 1, f"expected 1 coalesced text_delta, got {n_text}"
    folded = sr.fold_jsonl_into_turns(sdir / f"{w.sid}.jsonl")
    assert folded[0]["content"] == "abcdef"


def test_concurrent_tail_no_live_double_apply(tmp_path):
    # review: Codex/Gemini final C1 — two tail()s racing from a stale
    # cursor must not double-apply the live-column read-modify-append.
    import threading as _th
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    w.text_delta(turn_idx=0, round_idx=0, chunk="ABCD")  # in-flight, no turn_ended
    # Reset cursor to 0 so both tailers see the same stale start, then
    # fire them concurrently against the same db.
    con0 = connect_sessions_db(sdir / "sessions.db")
    con0.execute("UPDATE sessions_meta SET indexed_bytes=0, live_content_so_far='' "
                 "WHERE session_hash=?", (w.sid,))
    con0.commit()

    def _tail():
        SessionIndex(home).tail(w.sid, projector=None)

    ts = [_th.Thread(target=_tail) for _ in range(4)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    con = connect_sessions_db(sdir / "sessions.db")
    live = con.execute(
        "SELECT live_content_so_far FROM sessions_meta WHERE session_hash=?",
        (w.sid,),
    ).fetchone()["live_content_so_far"]
    assert live == "ABCD", f"live double-applied: {live!r}"


def test_inflight_fold_rescrubs_split_secret(tmp_path):
    # review: Codex final S1 — a secret split across two debounce flushes
    # is scrubbed per-chunk (each half passes); the in-flight fold must
    # re-scrub the reassembled content.
    home, sdir, w = _mk_writer(tmp_path, flush_ms=0)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.turn_started(turn_idx=0, user="q", permission_mode="auto")
    w.round_started(turn_idx=0, round_idx=0)
    # Split an OpenAI key across two delta events (each emitted separately
    # because flush_ms=0). Neither half matches on its own.
    w.text_delta(turn_idx=0, round_idx=0, chunk="key sk-proj-ABCDEFGH")
    w.text_delta(turn_idx=0, round_idx=0, chunk="IJKLMNOPQRSTUVWX012 end")
    # NOTE: no turn_ended — this is an in-flight turn.
    turns = sr.fold_jsonl_into_turns(sdir / f"{w.sid}.jsonl")
    assert turns and turns[0].get("in_progress") is True
    assert "sk-proj-ABCDEFGHIJKLMNOPQRSTUVWX012" not in turns[0]["content"], \
        "split secret reassembled in cleartext in the in-flight fold"


def test_error_turn_event_emitted(tmp_path):
    # review: Codex final S2 — an errored/aborted turn must produce an
    # 'error' turn_event so cmd_health can count it.
    home, sdir, w = _mk_writer(tmp_path)
    w.session_started({"agent_name": "main", "engine": "local_llm"})
    w.record_stream(
        turn_idx=0, user="q", content="", terminal=True,
        aborted=True, error="boom", error_classification="engine_exception",
    )
    w.close()
    SessionIndex(home).tail(w.sid)
    con = connect_sessions_db(sdir / "sessions.db")
    n = con.execute(
        "SELECT count(*) c FROM turn_events WHERE kind='error' AND session_hash=?",
        (w.sid,),
    ).fetchone()["c"]
    assert n == 1


def test_writer_registry_lru_evicts(tmp_path):
    # review: Codex/Gemini final C2 — the writer registry must be bounded
    # so the gateway doesn't leak fds.
    import rtxclaw_core.session_writer as swmod
    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    ensure_schema(sdir / "sessions.db")
    old_max = swmod._WRITERS_MAX
    swmod._WRITERS_MAX = 4
    try:
        for i in range(10):
            w = swmod.get_session_writer(sdir, f"lru{i:03d}", engine="local_llm")
            w.session_started({"agent_name": "main", "engine": "local_llm"})
        assert len(swmod._WRITERS) <= 4, "registry exceeded the LRU cap"
    finally:
        swmod._WRITERS_MAX = old_max
        for k in list(swmod._WRITERS):
            try:
                swmod._WRITERS[k].close()
            except Exception:
                pass
        swmod._WRITERS.clear()


def test_migration_frontend_to_workspace_origin(tmp_path):
    sdir = tmp_path / "sessions"
    sdir.mkdir(parents=True)
    db = sdir / "sessions.db"
    # Simulate a legacy v1 sessions.db with the old 5-column schema.
    con = connect_sessions_db(db)
    con.executescript(
        "CREATE TABLE sessions_meta ("
        " session_hash TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '',"
        " created_at TEXT NOT NULL DEFAULT '', frontend TEXT NOT NULL DEFAULT '',"
        " updated_at INTEGER NOT NULL DEFAULT 0);"
    )
    con.execute(
        "INSERT INTO sessions_meta(session_hash,title,frontend,updated_at) "
        "VALUES ('legacy01','old session','telegram',1)"
    )
    con.commit()
    con.close()
    # Run the v2 migration.
    ensure_schema(db)
    con2 = connect_sessions_db(db)
    cols = {r[1] for r in con2.execute("PRAGMA table_info(sessions_meta)")}
    assert "workspace_origin" in cols
    assert "live_content_so_far" in cols
    assert "indexed_bytes" in cols
    row = con2.execute(
        "SELECT workspace_origin FROM sessions_meta WHERE session_hash='legacy01'"
    ).fetchone()
    assert row["workspace_origin"] == "telegram"  # copied from frontend
