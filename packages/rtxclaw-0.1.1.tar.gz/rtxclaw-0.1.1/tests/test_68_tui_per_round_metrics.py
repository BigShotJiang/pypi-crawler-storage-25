"""Step 68 — every round's stats are shown in the TUI, including
rounds whose only output was tool calls.

Goal: rtxclaw must log AND show the per-round latency / token stats
for ALL rounds that generated thinking or output tokens — even a
round that emitted nothing but tool calls. That's what lets the
operator see the latency + token-generation impact of the tool-heavy
middle of a turn, not just the final cumulative number.

The infrastructure already ships per-round metrics to the TUI: the
worker emits one ``metrics`` event per round (``worker.py``), the
engine forwards it as a ``RoundComplete`` -> per-round ``usage_update``
(``acp_translation.py``), and the agent client tunnels the full
metrics dict through to the TUI ``metrics`` event (``agent_client.py``:
"so the TUI can stamp the stats line for EACH round, not just the
last one"). The bug was purely on the TUI side: ``_stream_via_agent``
never stamped the per-round event onto a bubble, because a round's
metrics arrive AFTER the next round's bubble has mounted (RoundComplete
is emitted post-tool-dispatch). So tool-only rounds showed no stats.

Fix: when a round closes (tool_call / auto_continue), stash its bubble
in ``_round_pending_assistant``; stamp the next ``metrics`` event onto
THAT bubble. The final (no-tool) round closes no bubble — its
cumulative turn stats are stamped at turn end as before.

This test drives ``_stream_via_agent`` with a synthetic event
sequence in the exact wire order and asserts the per-round metrics
landed on the right bubbles.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any, AsyncIterator, Iterable
from unittest.mock import MagicMock

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_tui.app import (  # noqa: E402
    AgentChatApp,
    AssistantMessage,
    ToolCallMessage,
    ToolResultMessage,
)


class _FakeTranscript:
    """Records every mount() call so the test can assert layout."""

    def __init__(self) -> None:
        self.mounted: list[Any] = []

    async def mount(self, widget: Any) -> None:
        self.mounted.append(widget)

    @property
    def children(self) -> list[Any]:
        return list(self.mounted)

    def scroll_end(self, *, animate: bool = False) -> None:
        return None

    def query(self, kind: Any = None) -> Iterable[Any]:
        if kind is ToolResultMessage:
            return [w for w in self.mounted if isinstance(w, ToolResultMessage)]
        return []

    async def wait_for_refresh(self) -> None:
        return None


# Per-round metrics for the FIRST round — a tool-call-ONLY round: the
# model thought, then emitted a tool call and no prose at all
# (content_tokens == 0). These are the stats that used to vanish.
_ROUND0_METRICS = {
    "model": "deepseek",
    "ttft_ms": 503.0,
    "prefill_ms": 120.0,
    "tps": 4.14,
    "wt_ms": 20629.0,
    "completion_tokens": 77,
    "reasoning_tokens": 77,
    "content_tokens": 0,
    "prompt_tokens": 39219,
    "context_window": 128000,
}

# Cumulative turn metrics, delivered on the final (no-tool) round via
# TurnDone -> usage_update: completion_tokens summed across both rounds.
_TURN_METRICS = {
    "model": "deepseek",
    "ttft_ms": 210.0,
    "tps": 88.3,
    "wt_ms": 22000.0,
    "completion_tokens": 177,
    "reasoning_tokens": 90,
    "content_tokens": 87,
    "prompt_tokens": 39500,
    "total_tokens": 39677,
    "context_window": 128000,
}


def _events_tool_only_round_then_text() -> list[tuple[str, dict, str]]:
    """Wire shape for a 2-round turn:

      round 0 — pure tool call (no thinking/content chunk at all), then
                the per-round metrics arrive AFTER the tool_result has
                mounted round 1's bubble (the real ordering).
      round 1 — the final text answer; cumulative metrics + done.
    """
    tid = "tid-metrics"
    return [
        ("started", {"turn_id": tid}, tid),
        # round 0: only a tool call — no chunk precedes it.
        ("tool_call", {
            "tool": "Read",
            "call_id": "c0",
            "arguments": {"file_path": "/x"},
        }, tid),
        ("tool_result", {
            "call_id": "c0",
            "ok": True,
            "content": "file contents",
        }, tid),
        # round 0's per-round metrics — arrive AFTER round 1's bubble
        # mounted (post tool_result _ensure_assistant).
        ("metrics", dict(_ROUND0_METRICS), tid),
        # round 1: the final prose answer.
        ("chunk", {"choices": [{"delta": {"content": "The answer is 42."}}]}, tid),
        # cumulative turn metrics (TurnDone -> usage_update).
        ("metrics", dict(_TURN_METRICS), tid),
        ("done", {"state": "ok"}, tid),
    ]


def _make_session_turn_gen(events: list[tuple[str, dict, str]]):
    async def _gen(*_args: Any, **_kwargs: Any) -> AsyncIterator[tuple[str, dict, str]]:
        for ev in events:
            yield ev
    return _gen


async def _drive(app: AgentChatApp, transcript: _FakeTranscript, text: str) -> None:
    app.query_one = MagicMock(return_value=transcript)
    app._set_worker_state = MagicMock()
    app._refresh_status_bar = MagicMock()
    app._set_status = MagicMock()
    app._refresh_title = MagicMock()
    app._maybe_start_next = MagicMock()

    async def _fake_get_session(_sid: str) -> dict:
        return {
            "hash": "h", "title": "t",
            "created_at": "2026-01-01T00:00:00Z",
            "system_prompt": "", "model": "test",
            "endpoint": "http://x", "turns": [],
            "context_window": 0,
        }
    app._client.get_session = _fake_get_session  # type: ignore[attr-defined]
    await app._stream_via_agent(text)


@pytest.fixture
def app() -> AgentChatApp:
    a = AgentChatApp.__new__(AgentChatApp)
    a._sid = "sid-test"
    a._current_turn_id = None
    a._current_assistant = None
    a._round_pending_assistant = None
    a._pending_tool_calls = set()
    a.enable_thinking = False
    a.reasoning_visibility = "off"
    a._permission_mode = "auto"
    a._last_prompt_tokens = 0
    a._last_context_window = 0
    a._plans = []
    a._subagent_box_stack = []
    a._subagent_boxes_by_call = {}
    a._suppressed_subagent_calls = set()
    a._plan_call_ids = set()
    a._section_call_ids = set()
    a._user_question_call_ids = set()
    a._update_call_ids = set()
    a._harness_task_call_ids = set()
    a._pending_task_create_calls = {}
    a._subagent_done = 0
    a._subagent_failed = 0
    a._subagent_total = 0
    return a


def _assistants(transcript: _FakeTranscript) -> list[AssistantMessage]:
    return [w for w in transcript.mounted if isinstance(w, AssistantMessage)]


def test_tool_only_round_gets_its_stats(app: AgentChatApp) -> None:
    """The tool-call-only round's bubble MUST carry its per-round
    latency/token stats — the headline guarantee of the goal."""
    events = _events_tool_only_round_then_text()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "do a thing"))

    assistants = _assistants(transcript)
    # Eager round-0 bubble (empty, tool-only) + round-1 text bubble.
    assert len(assistants) == 2, [type(w).__name__ for w in transcript.mounted]
    round0_bubble, round1_bubble = assistants

    # THE FIX: the tool-only round shows its per-round stats. Pre-fix
    # this bubble's `.metrics` was None — the stats were dropped.
    assert round0_bubble.metrics is not None, (
        "tool-call-only round dropped its stats — nothing stamped"
    )
    assert round0_bubble.metrics["completion_tokens"] == 77
    assert round0_bubble.metrics["reasoning_tokens"] == 77
    # Crucially a tool-only round (content_tokens == 0) still shows up.
    assert round0_bubble.metrics["content_tokens"] == 0
    assert round0_bubble.metrics["wt_ms"] == 20629.0


def test_final_round_gets_cumulative_turn_stats(app: AgentChatApp) -> None:
    """The final (no-tool) round's bubble carries the cumulative turn
    totals — summed across all rounds — stamped at turn end."""
    events = _events_tool_only_round_then_text()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "do a thing"))

    round1_bubble = _assistants(transcript)[1]
    assert round1_bubble.metrics is not None
    # Cumulative completion_tokens (77 + 100), distinct from round 0's 77.
    assert round1_bubble.metrics["completion_tokens"] == 177
    assert round1_bubble.metrics["total_tokens"] == 39677
    assert round1_bubble.content_text == "The answer is 42."


def test_per_round_stats_are_not_cross_attributed(app: AgentChatApp) -> None:
    """Round 0's stats land on round 0's bubble and round 1's
    (cumulative) stats land on round 1's — never swapped, even though
    round 0's metrics event arrives AFTER round 1's bubble mounted."""
    events = _events_tool_only_round_then_text()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "do a thing"))

    round0_bubble, round1_bubble = _assistants(transcript)
    assert round0_bubble.metrics["completion_tokens"] == 77
    assert round1_bubble.metrics["completion_tokens"] == 177
    # The pending slot is drained at end of turn.
    assert app._round_pending_assistant is None
