"""Step 15 — Skill discovery + registration with production skills.

Per operator request: "register some skill from production and test
the skill calls."

Coverage:
- Frontmatter parsing edge cases (flat keys, nested ``metadata`` dot
  paths, list values).
- ``discover_skills`` precedence: same-named skill in the agent's
  local ``skills/`` directory wins over ``~/.rtxclaw/skills`` and
  ``~/.openclaw/skills``.
- Real production skill round-trip: copy a skill from the host's
  ``~/.rtxclaw/skills`` (todo-skills if present) into the test agent
  and confirm it shows up in ``skills_summary_block`` + ``find_skill``.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

import pytest

from rtxclaw_core.skills import (
    discover_skills,
    find_skill,
    parse_skill_md,
    skills_summary_block,
)


@pytest.fixture
def agent_home(tmp_path: Path, monkeypatch) -> Path:
    """Empty agent home with isolated user-skill paths.

    We monkey-patch ``HOME`` so the ``~/.rtxclaw/skills`` and
    ``~/.openclaw/skills`` chain links resolve to empty tmp dirs —
    otherwise the host operator's real skills would leak into every
    discovery and the precedence test would be non-deterministic.
    """
    home = tmp_path / "agent"
    home.mkdir()
    fake_user = tmp_path / "fake_home"
    fake_user.mkdir()
    monkeypatch.setenv("HOME", str(fake_user))
    return home


def _write_skill(parent: Path, name: str, description: str,
                 body: str = "# Body\n") -> Path:
    sd = parent / name
    sd.mkdir(parents=True, exist_ok=True)
    skill_md = sd / "SKILL.md"
    skill_md.write_text(
        f"---\nname: {name}\ndescription: \"{description}\"\nversion: 0.1\n---\n\n{body}",
        encoding="utf-8",
    )
    return skill_md


def test_parse_minimal_frontmatter(tmp_path: Path) -> None:
    p = tmp_path / "x" / "SKILL.md"
    p.parent.mkdir()
    p.write_text(
        "---\nname: foo\ndescription: A small helper.\n---\n\nhello",
        encoding="utf-8",
    )
    s = parse_skill_md(p)
    assert s is not None
    assert s.name == "foo"
    assert "small helper" in s.description
    assert s.body.strip() == "hello"


def test_discover_returns_skills_sorted(agent_home: Path) -> None:
    skills_dir = agent_home / "skills"
    _write_skill(skills_dir, "zeta", "Z skill.")
    _write_skill(skills_dir, "alpha", "A skill.")
    _write_skill(skills_dir, "mike", "M skill.")
    out = discover_skills(agent_home)
    # `discover_skills` promises a name-sorted result; the bundled
    # `builtin_skills/` tree is always in the chain too, so assert the
    # sort invariant on the whole result + presence of our own skills.
    names = [s.name for s in out]
    assert names == sorted(names)
    for expected in ("alpha", "mike", "zeta"):
        assert expected in names


def test_local_skills_win_over_user_skills(
    agent_home: Path, tmp_path: Path, monkeypatch,
) -> None:
    """Same-named skill: agent's local copy must beat ``~/.rtxclaw/skills``."""
    fake_user = Path(os.environ["HOME"])
    user_skills = fake_user / ".rtxclaw" / "skills"
    user_skills.mkdir(parents=True)
    _write_skill(user_skills, "shareddata-core", "USER COPY")
    local_skills = agent_home / "skills"
    _write_skill(local_skills, "shareddata-core", "AGENT COPY")
    out = find_skill("shareddata-core", agent_home)
    assert out is not None
    assert "AGENT COPY" in out.description, (
        f"agent-local skill didn't win:\n{out.description}"
    )


def test_skills_summary_block_format(agent_home: Path) -> None:
    """The compact ``# SKILLS`` block reports a count + ``SkillSearch``
    pointer for on-demand skills (no per-skill headers — that's what
    keeps the prompt small when 200+ skills are installed). Individual
    on-demand skill names DO NOT appear in the block; the model
    discovers them via ``SkillSearch`` and reads them via ``Skill``.
    """
    skills_dir = agent_home / "skills"
    _write_skill(skills_dir, "foo", "Foo skill.")
    _write_skill(skills_dir, "bar", "Bar skill.")
    block = skills_summary_block(agent_home)
    assert "# SKILLS" in block
    assert "SkillSearch" in block, (
        "the block must point the model at the SkillSearch tool"
    )
    # On-demand skills are NOT listed by name (that was the old bloat).
    assert "**foo**" not in block and "**bar**" not in block, (
        "on-demand skills must not appear individually in the block — "
        "that's what SkillSearch is for"
    )
    # The on-demand count IS reported.
    # (Builtin skills may also be discovered; ours add to the count.)
    assert "On-demand (" in block


def test_empty_agent_emits_empty_summary(
    agent_home: Path, tmp_path: Path, monkeypatch,
) -> None:
    """No *enabled* skills → empty string — avoids a dangling # SKILLS
    header that wastes prompt tokens for nothing.

    The bundled ``builtin_skills/`` tree always ships at least one
    skill, so a truly empty discovery now only happens when the config
    gate disables them — which this also exercises.
    """
    import json as _json
    rtx = tmp_path / "rtxhome"
    rtx.mkdir()
    monkeypatch.setenv("RTXCLAW_HOME", str(rtx))
    disabled = {
        s.name: {"enabled": False}
        for s in discover_skills(agent_home, include_disabled=True)
    }
    (rtx / "config.json").write_text(
        _json.dumps({"skills": disabled}), encoding="utf-8",
    )
    assert skills_summary_block(agent_home) == ""


def test_empty_agent_emits_builtin_summary(agent_home: Path) -> None:
    """A fresh agent (no agent-local skills) still sees the
    package-shipped builtin skills via the SkillSearch pointer.

    The new contract: the ``# SKILLS`` block carries a count + a
    ``SkillSearch`` pointer for ON-DEMAND skills, not per-skill
    headers. So we assert the count matches the discovered set, not
    individual names — those are reachable via ``SkillSearch`` /
    ``Skill``.
    """
    block = skills_summary_block(agent_home)
    discovered = discover_skills(agent_home)
    if not discovered:
        assert block == ""
        return
    assert "# SKILLS" in block
    on_demand = [s for s in discovered if not s.always]
    if on_demand:
        assert "SkillSearch" in block
        assert f"On-demand ({len(on_demand)})" in block, block
    always = [s for s in discovered if s.always]
    for s in always:
        # always-active skills DO appear by name in the block (full body inline).
        assert f"### {s.name}" in block


_REAL_RTXCLAW_SKILLS = Path.home() / ".rtxclaw" / "skills"


@pytest.mark.skipif(
    not _REAL_RTXCLAW_SKILLS.is_dir(),
    reason="no production ~/.rtxclaw/skills/ on this host",
)
def test_production_skill_registers_on_test_agent(
    agent_home: Path,
) -> None:
    """Copy a real production skill into the test agent's skills dir
    and verify it surfaces via the discovery + summary path.

    Picks the first parseable skill from the operator's own
    ``~/.rtxclaw/skills`` so the test exercises actual frontmatter
    shapes the codebase encounters in the wild — not a synthetic
    fixture.

    The production path is captured via the module-level constant
    above (resolved at import time, before the fixture monkey-patches
    ``HOME``), so the discovery chain inside ``discover_skills`` still
    sees only the test agent's local copy.
    """
    candidates = []
    for d in _REAL_RTXCLAW_SKILLS.iterdir():
        skill_md = d / "SKILL.md"
        if not d.is_dir() or not skill_md.is_file():
            continue
        if parse_skill_md(skill_md) is not None:
            candidates.append(d)
    if not candidates:
        pytest.skip("no parseable skill in production skills dir")
    # Sort for stable selection across runs.
    candidates.sort(key=lambda p: p.name)
    src = candidates[0]
    dst_root = agent_home / "skills"
    dst_root.mkdir()
    dst = dst_root / src.name
    # Real production skills can carry runtime cruft we must NOT pull
    # into the test sandbox: Chrome ``profiles/`` dirs hold broken
    # ``SingletonLock`` symlinks pointing at PIDs of running browsers,
    # ``__pycache__`` is per-interpreter, ``*.lock`` files belong to
    # whichever real process spawned them. ``copytree`` follows
    # symlinks by default and would error on the dangling ones, so we
    # prune those before copy and preserve any remaining symlinks
    # in-place rather than dereferencing them.
    ignore = shutil.ignore_patterns(
        "profiles", "__pycache__", "*.lock", "SingletonLock*",
        "Singleton*", ".cache",
    )
    shutil.copytree(src, dst, symlinks=True, ignore=ignore)
    s = find_skill(src.name, agent_home)
    assert s is not None, (
        f"production skill {src.name!r} failed to register on the test agent"
    )
    assert s.name == src.name
    assert s.description, "production skill has empty description"
    block = skills_summary_block(agent_home)
    # The compact block reports an on-demand count + SkillSearch
    # pointer (not per-skill headers), so we assert the count includes
    # the just-registered skill and the pointer is present — the
    # model discovers the specific skill via SkillSearch / Skill.
    if not s.always:
        assert "SkillSearch" in block
        assert "On-demand" in block


def test_skills_config_gates_discovery(
    agent_home: Path, tmp_path: Path, monkeypatch,
) -> None:
    """The global config's ``skills`` map is an authoritative kill switch.

    A skill marked ``enabled: false`` in ``~/.rtxclaw/config.json``
    vanishes from ``discover_skills()`` / ``skills_summary_block`` /
    ``find_skill`` — but ``discover_skills(include_disabled=True)``
    still surfaces it (what ``rtxclaw skills list`` uses so an operator
    can see what to re-enable). A skill absent from the map defaults to
    enabled, so a freshly-dropped skill works without a config edit.
    """
    import json as _json

    # Pin RTXCLAW_HOME so `_load_skills_config()` reads OUR config, not
    # whatever a prior test left in the sandbox home.
    rtx_home = tmp_path / "rtxhome"
    rtx_home.mkdir()
    monkeypatch.setenv("RTXCLAW_HOME", str(rtx_home))

    skills_dir = agent_home / "skills"
    _write_skill(skills_dir, "alpha", "Enabled skill.")
    _write_skill(skills_dir, "bravo", "Disabled skill.")
    _write_skill(skills_dir, "charlie", "Not in the config map at all.")

    # alpha on, bravo off, charlie absent (→ defaults on).
    (rtx_home / "config.json").write_text(
        _json.dumps({"skills": {
            "alpha": {"enabled": True},
            "bravo": {"enabled": False},
        }}),
        encoding="utf-8",
    )

    # Subset assertions, not exact-equality: the bundled
    # `builtin_skills/` tree is always discovered too (and, absent from
    # this config, defaults to enabled).
    enabled = {s.name for s in discover_skills(agent_home)}
    assert {"alpha", "charlie"} <= enabled, (
        f"config-enabled / unlisted skills missing from discovery: {sorted(enabled)}"
    )
    assert "bravo" not in enabled, (
        f"`enabled: false` skill leaked into discovery: {sorted(enabled)}"
    )
    assert find_skill("bravo", agent_home) is None, "disabled skill still findable"
    assert "**bravo**" not in skills_summary_block(agent_home), (
        "disabled skill leaked into the system-prompt SKILLS block"
    )

    all_skills = {s.name for s in discover_skills(agent_home, include_disabled=True)}
    assert {"alpha", "bravo", "charlie"} <= all_skills, (
        f"include_disabled=True should surface every skill: {sorted(all_skills)}"
    )
