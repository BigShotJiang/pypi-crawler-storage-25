"""Step 39 — image content blocks land end-to-end.

Background: after the ImageContent → ImageContentBlock fix in
test_37, the user retried sending a Telegram photo and got
``-32602: prompt[1].type='image' not supported by this agent``.
Root cause: the agent's advertised
``promptCapabilities.image`` was False AND the dispatcher's
``_SUPPORTED_CONTENT_BLOCK_TYPES`` excluded ``"image"``, so the
ContentBlock was rejected at the wire boundary even though the
bridge's ``_blocks_to_user_content`` already knows how to translate
image blocks into the OpenAI multi-part ``image_url`` payload.

Tests in this file pin the new triple-aligned contract:

  advertised → dispatcher accepts → bridge consumes

Also covers the negative — audio is still rejected (its handler
path isn't wired) — so we don't accidentally let a future "advertise
everything" change leak through.
"""
from __future__ import annotations

import pytest

from rtxclaw_acp.server.server import _SUPPORTED_CONTENT_BLOCK_TYPES
from rtxclaw_agent.acp_stdio_main import _build_capabilities


# ---- advertisement ↔ dispatcher --------------------------------


def test_image_advertised_true() -> None:
    """The agent must claim it accepts images so vision-capable
    clients (Telegram bot, TUI when configured) actually send them."""
    caps = _build_capabilities(_DummyCfg())
    assert caps["promptCapabilities"]["image"] is True


def test_image_in_dispatcher_supported_set() -> None:
    """Dispatcher must accept ``image`` content blocks; rejecting
    them while advertising image=true is the capability-lie pattern
    the 2026-05-05 audit already flagged."""
    assert "image" in _SUPPORTED_CONTENT_BLOCK_TYPES


def test_text_and_resource_link_still_supported() -> None:
    """Don't regress the existing accept-list while expanding it."""
    assert "text" in _SUPPORTED_CONTENT_BLOCK_TYPES
    assert "resource_link" in _SUPPORTED_CONTENT_BLOCK_TYPES


def test_audio_not_advertised_and_not_supported() -> None:
    """Audio path isn't wired through to upstream (no STT in-bridge,
    Telegram does its own STT before sending). Both the advertisement
    and the dispatcher must keep refusing audio blocks; a flip to
    ``True`` here without a handler change would be a capability lie."""
    caps = _build_capabilities(_DummyCfg())
    assert caps["promptCapabilities"]["audio"] is False
    assert "audio" not in _SUPPORTED_CONTENT_BLOCK_TYPES


def test_embedded_context_not_advertised() -> None:
    """Same regression net for embedded resources / context blocks —
    those are accepted by some ACP-compliant agents but rtxclaw's
    bridge has no handler today."""
    caps = _build_capabilities(_DummyCfg())
    assert caps["promptCapabilities"]["embeddedContext"] is False


# ---- bridge consumes the block ------------------------------------


def test_bridge_translates_image_block_to_openai_multipart() -> None:
    """End-to-end shape pin: an image ContentBlock in the prompt list
    must come out as the OpenAI vision multi-part shape:

        [{"type": "text", "text": "..."},
         {"type": "image_url",
          "image_url": {"url": "data:<mime>;base64,<b64>"}}]

    A regression that drops the data URI (e.g. by passing through
    raw bytes or breaking the b64) leaves vision-capable upstreams
    with no usable image."""
    from rtxclaw_agent.acp_bridge import _blocks_to_user_content

    blocks = [
        {"type": "text", "text": "look at this"},
        {"type": "image", "data": "aGVsbG8=", "mimeType": "image/jpeg"},
    ]
    out = _blocks_to_user_content(blocks)
    assert isinstance(out, list), (
        "image present → bridge must return multi-part list, not the "
        "string-content shortcut"
    )
    text_parts = [p for p in out if p.get("type") == "text"]
    image_parts = [p for p in out if p.get("type") == "image_url"]
    assert text_parts and text_parts[0]["text"] == "look at this"
    assert image_parts, "image_url part missing"
    url = image_parts[0]["image_url"]["url"]
    assert url.startswith("data:image/jpeg;base64,"), url
    assert url.endswith(",aGVsbG8="), url


def test_bridge_string_shortcut_still_used_when_no_image() -> None:
    """Text-only prompt must keep returning a plain string — the
    multi-part shape balloons the request body and breaks
    upstreams that don't speak OpenAI vision (most local models)."""
    from rtxclaw_agent.acp_bridge import _blocks_to_user_content

    blocks = [{"type": "text", "text": "just text"}]
    out = _blocks_to_user_content(blocks)
    assert isinstance(out, str)
    assert out == "just text"


# ---- helpers -------------------------------------------------------


class _DummyCfg:
    """``_build_capabilities`` only inspects fields it doesn't care
    about; a bare object is enough to drive the call without standing
    up a real ``AgentConfig`` and its disk dependencies."""

    name = "main"
