"""Step 62 — ACP permission modal must not orphan on cancellation.

Regression for the production bug where a destructive-tool approval
prompt got stuck on screen forever after the agent aborted:

1. Agent requests permission for a destructive Bash → TUI pushes
   :class:`AcpPermissionModal` via ``push_screen_wait``.
2. User presses ESC → app-level priority binding hijacks the key
   (modal's own ESC reject never fires) and terminates the agent
   subprocess.
3. ACP connection drops → the inbound ``session/request_permission``
   handler task is cancelled.
4. ``push_screen_wait`` wraps its inner future in
   ``asyncio.shield`` (Textual 8.2.5), so the calling task gets
   ``CancelledError`` but the inner future stays pending —
   **the modal screen never gets popped**.
5. The modal sits frozen on top of the TUI; subsequent keys hit the
   app-level priority bindings (ESC still aborts) but the modal's
   own bindings ('a'/'s'/'r') route nowhere because the modal lost
   focus.

This suite pins the fix:

- :meth:`AgentChatApp._on_request_permission` catches both
  ``CancelledError`` (BaseException) and regular exceptions and
  force-pops the modal off the screen stack on the way out.
- :class:`AcpPermissionModal`'s ``escape`` binding is marked
  ``priority=True`` so it overrides the app-level abort and the
  modal can be rejected with ESC.

Pure unit test — exercises just the modal class + the
``_on_request_permission`` callback against a minimal stand-in App.
No daemon, no upstream model.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from textual.app import App  # noqa: E402

from rtxclaw_tui.app import (  # noqa: E402
    AcpPermissionModal,
    AgentChatApp,
)


# ---- binding precedence ---------------------------------------------


def test_escape_binding_is_priority():
    """ESC must reject the modal even though :class:`AgentChatApp`
    binds ESC → ``abort`` at App level with ``priority=True``. The
    only way a screen binding wins over an app priority binding is to
    set ``priority=True`` on the screen binding too — Textual checks
    priority bindings in App→screen→widget order, so app priority
    fires first by default."""
    esc = next(b for b in AcpPermissionModal.BINDINGS if b.key == "escape")
    assert esc.priority, (
        "AcpPermissionModal's escape binding must be priority=True so it "
        "overrides AgentChatApp's app-level escape-abort priority binding"
    )


# ---- cancellation cleanup -------------------------------------------


class _HostApp(App[None]):
    """Minimal stand-in for :class:`AgentChatApp` that wires only the
    method under test. We can't ``run_test()`` the real ``AgentChatApp``
    here without a live agent gateway, so we mount a barebones App and
    borrow the two unbound methods we exercise."""

    # Borrow unbound — same `self` semantics, no AgentChatApp __init__.
    _on_request_permission = AgentChatApp._on_request_permission
    _force_pop_acp_modal = AgentChatApp._force_pop_acp_modal

    async def call_under_test(self, params: dict) -> dict:
        return await self._on_request_permission(params)


_PARAMS = {
    "sessionId": "sid-test",
    "toolCall": {
        "toolCallId": "tc-1",
        "title": "Bash",
        "kind": "other",
        "rawInput": {"command": "rm -rf /tmp/x"},
    },
    "options": [
        {"optionId": "allow_once", "name": "Allow once", "kind": "allow_once"},
        {"optionId": "reject_once", "name": "Reject", "kind": "reject_once"},
    ],
}


def test_modal_popped_when_awaiter_cancelled():
    """The bug: cancelling the task that awaits ``push_screen_wait``
    leaves the modal on the screen stack. The fix: catch the
    cancellation, pop the modal, then re-raise so the cancellation
    still propagates.

    Note ``push_screen_wait`` requires a running Textual worker; we
    drive ``_on_request_permission`` via :meth:`App.run_worker` to
    mirror the ACP read loop call site, then cancel that worker."""

    async def _scenario():
        app = _HostApp()
        async with app.run_test() as pilot:
            worker = app.run_worker(
                app.call_under_test(_PARAMS),
                name="perm-test",
                exit_on_error=False,
            )
            # Yield until the modal is on the stack.
            for _ in range(50):
                await pilot.pause()
                if any(isinstance(s, AcpPermissionModal) for s in app.screen_stack):
                    break
            else:
                pytest.fail("AcpPermissionModal never pushed onto screen stack")

            assert isinstance(app.screen, AcpPermissionModal)

            # Now cancel the worker (mirrors what happens when the ACP
            # read loop's request handler task is cancelled).
            worker.cancel()

            # Give Textual a few frames to apply pop_screen.
            for _ in range(30):
                await pilot.pause()
                if not any(isinstance(s, AcpPermissionModal) for s in app.screen_stack):
                    break

            assert not any(
                isinstance(s, AcpPermissionModal) for s in app.screen_stack
            ), (
                "AcpPermissionModal is still on the screen stack after the "
                "awaiter was cancelled — modal would be stuck on screen for "
                "the user, swallowing key input"
            )

    asyncio.run(_scenario())


def test_modal_popped_when_callback_raises():
    """Non-cancellation exceptions must also force the modal off the
    stack — otherwise a transient error in the bridge would strand
    the user behind an unresponsive overlay."""

    async def _scenario():
        app = _HostApp()
        async with app.run_test() as pilot:
            real_push = app.push_screen_wait

            async def boom_push(screen, *args, **kwargs):
                # Push for real so the modal lands on the stack …
                app.push_screen(screen, wait_for_dismiss=True)
                await asyncio.sleep(0)
                raise RuntimeError("simulated teardown race")

            app.push_screen_wait = boom_push  # type: ignore[assignment]
            try:
                result = await app.call_under_test(_PARAMS)
            finally:
                app.push_screen_wait = real_push  # type: ignore[assignment]

            assert result == {
                "outcome": {"outcome": "selected", "optionId": "reject_once"}
            }
            for _ in range(20):
                await pilot.pause()
                if not any(isinstance(s, AcpPermissionModal) for s in app.screen_stack):
                    break
            assert not any(
                isinstance(s, AcpPermissionModal) for s in app.screen_stack
            ), "modal not popped on non-cancel exception path"

    asyncio.run(_scenario())
